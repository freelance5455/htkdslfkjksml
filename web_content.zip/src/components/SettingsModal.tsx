import React, { useState } from 'react';
import {
  X,
  User as UserIcon,
  Bot,
  MessageSquare,
  Palette,
  Volume2,
  Bell,
  Shield,
  CreditCard,
  Info,
  LogOut,
  Trash2,
  Download,
  Plus,
  Check,
  AlertTriangle,
  Loader2,
  ExternalLink,
  Sliders,
  Sparkles,
  HelpCircle,
  MessageCircle,
  Languages
} from 'lucide-react';
import { User, UserSettings, UserMemory } from '../types/auth';
import { ChatSession } from '../types/chat';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  settings: UserSettings;
  memories: UserMemory[];
  sessions: ChatSession[];
  isLight?: boolean;
  onUpdateSettings: (settings: Partial<UserSettings>) => Promise<void>;
  onUpdateProfile: (name: string, avatar?: string) => Promise<void>;
  onAddMemory: (text: string) => Promise<void>;
  onDeleteMemory: (id: string) => Promise<void>;
  onClearAllMemories: () => Promise<void>;
  onClearAllSessions: () => void;
  onDeleteAccount: () => Promise<void>;
  onLogout: () => void;
}

type TabType =
  | 'account'
  | 'ai'
  | 'chat'
  | 'appearance'
  | 'voice'
  | 'notifications'
  | 'privacy'
  | 'subscription'
  | 'about';

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  user,
  settings,
  memories,
  sessions,
  isLight = false,
  onUpdateSettings,
  onUpdateProfile,
  onAddMemory,
  onDeleteMemory,
  onClearAllMemories,
  onClearAllSessions,
  onDeleteAccount,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('account');
  const [name, setName] = useState(user?.name || '');
  const [avatar, setAvatar] = useState(user?.avatar || '');
  const [isSaving, setIsSaving] = useState(false);
  const [newMemoryText, setNewMemoryText] = useState('');
  const [showDeleteAccountConfirm, setShowDeleteAccountConfirm] = useState(false);
  const [showClearChatsConfirm, setShowClearChatsConfirm] = useState(false);
  const [showClearMemoriesConfirm, setShowClearMemoriesConfirm] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveProfile = async () => {
    if (!name.trim()) return;
    setIsSaving(true);
    try {
      await onUpdateProfile(name.trim(), avatar.trim() || undefined);
      showToast('تم حفظ الملف الشخصي بنجاح.');
    } catch (e: any) {
      alert(e.message || 'فشل حفظ الملف الشخصي');
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddMemorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryText.trim()) return;
    try {
      await onAddMemory(newMemoryText.trim());
      setNewMemoryText('');
      showToast('تمت إضافة الذكرى بنجاح.');
    } catch (e: any) {
      alert(e.message || 'فشل حفظ الذكرى');
    }
  };

  const handleExportData = () => {
    const dataToExport = {
      user,
      settings,
      memories,
      sessions,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `onyx-ai-export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('تم تصدير البيانات بنجاح.');
  };

  const handleExportChatsMarkdown = () => {
    let md = `# محادثات Onyx AI - ${user?.name || 'المستخدم'}\nتاريخ التصدير: ${new Date().toLocaleDateString('ar-EG')}\n\n`;
    sessions.forEach((s, idx) => {
      md += `## محادثة ${idx + 1}: ${s.title}\n`;
      md += `التاريخ: ${new Date(s.createdAt).toLocaleString('ar-EG')}\n\n`;
      s.messages.forEach((m) => {
        md += `### ${m.role === 'user' ? '👤 المستخدم' : '🤖 Onyx AI'}:\n${m.content}\n\n`;
      });
      md += '---\n\n';
    });
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `onyx-chats-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('تم تصدير المحادثات كملف Markdown.');
  };

  const navItems: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'account', label: 'الحساب', icon: <UserIcon className="w-4 h-4" /> },
    { id: 'ai', label: 'الذكاء الاصطناعي', icon: <Bot className="w-4 h-4" /> },
    { id: 'chat', label: 'المحادثات', icon: <MessageSquare className="w-4 h-4" /> },
    { id: 'appearance', label: 'المظهر', icon: <Palette className="w-4 h-4" /> },
    { id: 'voice', label: 'الصوت', icon: <Volume2 className="w-4 h-4" /> },
    { id: 'notifications', label: 'الإشعارات', icon: <Bell className="w-4 h-4" /> },
    { id: 'privacy', label: 'الخصوصية والبيانات', icon: <Shield className="w-4 h-4" /> },
    { id: 'subscription', label: 'الاشتراك', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'about', label: 'حول التطبيق', icon: <Info className="w-4 h-4" /> },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150"
      dir="rtl"
    >
      <div className={`w-full max-w-4xl h-[90vh] max-h-[720px] ${isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-[#121318] border-[#262734] text-neutral-200'} border rounded-3xl shadow-2xl flex flex-col md:flex-row overflow-hidden relative`}>
        {/* Toast */}
        {toastMessage && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 bg-blue-600 text-white text-xs font-semibold rounded-full shadow-lg animate-in fade-in slide-in-from-top-2">
            {toastMessage}
          </div>
        )}

        {/* Sidebar Nav */}
        <aside className={`w-full md:w-64 ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#0d0e13] border-[#1f202b]'} border-b md:border-b-0 md:border-l flex flex-col shrink-0`}>
          <div className={`p-4 sm:p-5 flex items-center justify-between border-b ${isLight ? 'border-slate-200' : 'border-[#1f202b]'}`}>
            <div className="flex items-center gap-2">
              <Sliders className="w-5 h-5 text-blue-500" />
              <h2 className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'} text-base`}>الإعدادات</h2>
            </div>
            <button
              onClick={onClose}
              className={`p-1.5 ${isLight ? 'text-slate-400 hover:text-slate-800 hover:bg-slate-200/60' : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'} rounded-xl md:hidden`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 overflow-x-auto md:overflow-y-auto p-2 md:p-3 flex md:flex-col gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-colors shrink-0 md:shrink text-right ${
                  activeTab === item.id
                    ? 'bg-[#2b66ff] text-white shadow-md'
                    : isLight
                    ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#1a1b24]'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </nav>

          {/* Quick Logout at bottom of sidebar on desktop */}
          <div className={`hidden md:block p-3 border-t ${isLight ? 'border-slate-200' : 'border-[#1f202b]'}`}>
            <button
              onClick={onLogout}
              className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-500 hover:bg-rose-500/10 rounded-xl transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>تسجيل الخروج</span>
            </button>
          </div>
        </aside>

        {/* Content Area */}
        <main className={`flex-1 flex flex-col ${isLight ? 'bg-white' : 'bg-[#121318]'} overflow-hidden`}>
          {/* Header on desktop */}
          <div className={`hidden md:flex items-center justify-between px-6 py-4 border-b ${isLight ? 'border-slate-200' : 'border-[#1f202b]'}`}>
            <h3 className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'} text-base`}>
              {navItems.find((n) => n.id === activeTab)?.label}
            </h3>
            <button
              onClick={onClose}
              className={`p-2 ${isLight ? 'text-slate-400 hover:text-slate-800 hover:bg-slate-100' : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'} rounded-xl transition-colors`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Scrollable Form Content */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            {/* 1. ACCOUNT TAB */}
            {activeTab === 'account' && (
              <div className="space-y-6">
                {/* Profile Card */}
                <div className={`p-4 sm:p-5 ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} border rounded-2xl flex flex-col sm:flex-row items-center gap-4`}>
                  <div className="relative">
                    {user?.avatar ? (
                      <img
                        src={user.avatar}
                        alt=""
                        className="w-16 h-16 rounded-full object-cover border-2 border-blue-500 shadow-md"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-2xl shadow-md">
                        {user?.name ? user.name[0].toUpperCase() : 'م'}
                      </div>
                    )}
                    <span className={`absolute bottom-0 right-0 w-4 h-4 rounded-full bg-emerald-500 border-2 ${isLight ? 'border-white' : 'border-[#171822]'}`} />
                  </div>

                  <div className="flex-1 text-center sm:text-right">
                    <div className="flex items-center justify-center sm:justify-start gap-2">
                      <h4 className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'} text-base`}>{user?.name}</h4>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-500 border border-blue-500/30 font-semibold">
                        {user?.plan === 'pro' ? 'خطة PRO' : 'خطة مجانية'}
                      </span>
                    </div>
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'} mt-0.5`}>{user?.email}</p>
                    <p className={`text-[11px] ${isLight ? 'text-slate-400' : 'text-neutral-500'} mt-1`}>
                      مزود الحساب: {user?.provider === 'google' ? 'Google Account' : 'البريد الإلكتروني'}
                    </p>
                  </div>
                </div>

                {/* Edit Profile Form */}
                <div className={`space-y-3 ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl`}>
                  <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-neutral-200'}`}>تعديل بيانات الحساب</h4>
                  <div>
                    <label className={`block text-[11px] ${isLight ? 'text-slate-600' : 'text-neutral-400'} mb-1`}>الاسم الكامل</label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className={`w-full ${isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-[#12131a] border-[#2b2c3d] text-white'} border rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-blue-500`}
                    />
                  </div>
                  <div>
                    <label className={`block text-[11px] ${isLight ? 'text-slate-600' : 'text-neutral-400'} mb-1`}>رابط الصورة الرمزية (اختياري)</label>
                    <input
                      type="url"
                      value={avatar}
                      onChange={(e) => setAvatar(e.target.value)}
                      placeholder="https://..."
                      className={`w-full ${isLight ? 'bg-white border-slate-200 text-slate-800 placeholder-slate-400' : 'bg-[#12131a] border-[#2b2c3d] text-white placeholder-neutral-500'} border rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-blue-500 text-left`}
                      dir="ltr"
                    />
                  </div>
                  <button
                    onClick={handleSaveProfile}
                    disabled={isSaving}
                    className="py-2 px-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50"
                  >
                    {isSaving && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    <span>حفظ التعديلات</span>
                  </button>
                </div>

                {/* Danger Zone */}
                <div className="space-y-3 bg-rose-950/20 border border-rose-900/40 p-4 sm:p-5 rounded-2xl">
                  <h4 className="text-xs font-semibold text-rose-500">إجراءات الحساب</h4>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className={`text-xs ${isLight ? 'text-slate-800' : 'text-white'} font-medium`}>تسجيل الخروج</p>
                      <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>إنهاء جلستك الحالية على هذا الجهاز</p>
                    </div>
                    <button
                      onClick={onLogout}
                      className={`px-3.5 py-2 ${isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-white'} text-xs font-semibold rounded-xl transition-colors`}
                    >
                      تسجيل الخروج
                    </button>
                  </div>

                  <div className="pt-3 border-t border-rose-900/30 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-xs text-rose-600 font-medium">حذف الحساب نهائياً</p>
                      <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>سيتم مسح حسابك، محادثاتك، وذكرياتك نهائياً دون استرجاع</p>
                    </div>
                    <button
                      onClick={() => setShowDeleteAccountConfirm(true)}
                      className="px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-xl transition-colors"
                    >
                      حذف الحساب
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 2. AI SETTINGS TAB */}
            {activeTab === 'ai' && (
              <div className="space-y-6">
                {/* Model Selector */}
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-3`}>
                  <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>نموذج الذكاء الاصطناعي الافتراضي</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {[
                      { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash', desc: 'النموذج الأحدث فائق السرعة والذكاء (افتراضي)' },
                      { id: 'gemini-3.1-pro-preview', name: 'Gemini 3.1 Pro', desc: 'للمهام المعقدة والتفكير البرمجي المعمق' },
                      { id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash Lite', desc: 'استجابات خفيفة وفورية' },
                      { id: 'gemini-flash-latest', name: 'Gemini Flash Latest', desc: 'أحدث إصدار محدث من Gemini Flash' },
                    ].map((m) => (
                      <button
                        key={m.id}
                        onClick={() => onUpdateSettings({ preferredModel: m.id })}
                        className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between ${
                          settings.preferredModel === m.id
                            ? 'bg-blue-600/15 border-blue-500 text-blue-500'
                            : isLight
                            ? 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                            : 'bg-[#12131a] border-[#2b2c3d] text-neutral-300 hover:border-neutral-600'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className={`font-semibold text-xs ${settings.preferredModel === m.id ? 'text-blue-500' : isLight ? 'text-slate-800' : 'text-white'}`}>{m.name}</span>
                          {settings.preferredModel === m.id && <Check className="w-3.5 h-3.5 text-blue-500" />}
                        </div>
                        <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'} mt-1`}>{m.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Response Style */}
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-3`}>
                  <div>
                    <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>شخصية وأسلوب الرد (Response Style)</h4>
                    <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'} mt-0.5`}>
                      يتحكم في نبرة ردود الذكاء الاصطناعي وصياغتها ومستوى التفصيل المطلوب
                    </p>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {[
                      { id: 'casual', label: 'عفوي', desc: 'طبيعي، ودود، وسلس دون رسمية زائدة' },
                      { id: 'balanced', label: 'متوازن (افتراضي)', desc: 'واضح ومباشر ومتزن بين الإيجاز والشرح' },
                      { id: 'formal', label: 'رسمي', desc: 'احترافي، أكاديمي، ومنظم بلغة رصينة' },
                      { id: 'strict', label: 'صارم', desc: 'حاسم ودقيق للحقائق دون تمهيد أو مجاملات' },
                      { id: 'concise', label: 'مختصر', desc: 'إجابات مباشرة بأقل قدر مناسب من الكلام' },
                      { id: 'detailed', label: 'مفصل', desc: 'شرح عميق وتفاصيل وأمثلة توضيحية غنية' },
                    ].map((s) => (
                      <button
                        key={s.id}
                        onClick={() => onUpdateSettings({ responseStyle: s.id as any })}
                        className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between ${
                          settings.responseStyle === s.id
                            ? 'bg-blue-600/15 border-blue-500 text-blue-500 font-semibold'
                            : isLight
                            ? 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                            : 'bg-[#12131a] border-[#2b2c3d] text-neutral-300 hover:border-neutral-600'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-semibold ${settings.responseStyle === s.id ? 'text-blue-500' : isLight ? 'text-slate-800' : 'text-white'}`}>
                            {s.label}
                          </span>
                          {settings.responseStyle === s.id && <Check className="w-3.5 h-3.5 text-blue-500 shrink-0" />}
                        </div>
                        <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'} mt-1 leading-snug`}>{s.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Default Language */}
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-2`}>
                  <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>لغة الرد الافتراضية</h4>
                  <select
                    value={settings.defaultLanguage}
                    onChange={(e) => onUpdateSettings({ defaultLanguage: e.target.value })}
                    className={`w-full ${isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-[#12131a] border-[#2b2c3d] text-white'} border rounded-xl px-3.5 py-2 text-xs focus:outline-none`}
                  >
                    <option value="العربية">العربية الفصحى (افتراضي)</option>
                    <option value="English">English</option>
                    <option value="Français">Français</option>
                    <option value="Deutsch">Deutsch</option>
                    <option value="Español">Español</option>
                  </select>
                </div>

                {/* Custom Instructions */}
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-2`}>
                  <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>تعليمات مخصصة (Custom Instructions)</h4>
                  <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                    أخبر الذكاء الاصطناعي بمعلومات عنك أو الطريقة التي تفضل أن يخاطبك بها في كل محادثة:
                  </p>
                  <textarea
                    rows={3}
                    value={settings.customInstructions}
                    onChange={(e) => onUpdateSettings({ customInstructions: e.target.value })}
                    placeholder="مثال: أنا مهندس برمجيات، أفضل الأمثلة بلغة TypeScript، ولا تكرر نفس النص في كل رد..."
                    className={`w-full ${isLight ? 'bg-white border-slate-200 text-slate-800 placeholder-slate-400' : 'bg-[#12131a] border-[#2b2c3d] text-white placeholder-neutral-500'} border rounded-xl p-3 text-xs focus:outline-none focus:border-blue-500 resize-none`}
                  />
                </div>

                {/* Smart Memory */}
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-4`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>الذاكرة الذكية (Smart Memory)</h4>
                      <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>تذكر تفضيلاتك وسياق محادثاتك عبر الجلسات</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.memoryEnabled}
                        onChange={(e) => onUpdateSettings({ memoryEnabled: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className={`w-11 h-6 ${isLight ? 'bg-slate-300' : 'bg-neutral-800'} peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600`}></div>
                    </label>
                  </div>

                  {settings.memoryEnabled && (
                    <div className={`pt-2 border-t ${isLight ? 'border-slate-200' : 'border-[#262736]'} space-y-3`}>
                      {/* Add Memory Form */}
                      <form onSubmit={handleAddMemorySubmit} className="flex gap-2">
                        <input
                          type="text"
                          value={newMemoryText}
                          onChange={(e) => setNewMemoryText(e.target.value)}
                          placeholder="أضف حقيقة أو تفضيل ليتذكره الذكاء الاصطناعي..."
                          className={`flex-1 ${isLight ? 'bg-white border-slate-200 text-slate-800 placeholder-slate-400' : 'bg-[#12131a] border-[#2b2c3d] text-white placeholder-neutral-500'} border rounded-xl px-3 py-1.5 text-xs focus:outline-none`}
                        />
                        <button
                          type="submit"
                          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1 shrink-0"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>إضافة</span>
                        </button>
                      </form>

                      {/* Memory List */}
                      {memories.length === 0 ? (
                        <p className={`text-[11px] ${isLight ? 'text-slate-400' : 'text-neutral-500'} text-center py-2`}>لا توجد ذكريات مسجلة حالياً.</p>
                      ) : (
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                          {memories.map((m) => (
                            <div
                              key={m.id}
                              className={`flex items-center justify-between p-2.5 ${isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-[#12131a] border-[#262736] text-neutral-200'} border rounded-xl text-xs`}
                            >
                              <span>{m.text}</span>
                              <button
                                onClick={() => onDeleteMemory(m.id)}
                                className={`${isLight ? 'text-slate-400 hover:text-rose-600' : 'text-neutral-500 hover:text-rose-400'} p-1 transition-colors`}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}

                      {memories.length > 0 && (
                        <button
                          onClick={() => setShowClearMemoriesConfirm(true)}
                          className="text-[11px] text-rose-500 hover:text-rose-600 font-medium"
                        >
                          مسح جميع الذكريات
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 3. CHAT SETTINGS TAB */}
            {activeTab === 'chat' && (
              <div className="space-y-6">
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-4`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>تأكيد قبل الحذف</h4>
                      <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>طلب تأكيد قبل حذف أية محادثة</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.confirmBeforeDelete}
                        onChange={(e) => onUpdateSettings({ confirmBeforeDelete: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className={`w-11 h-6 ${isLight ? 'bg-slate-300' : 'bg-neutral-800'} peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600`}></div>
                    </label>
                  </div>

                  <div className={`pt-3 border-t ${isLight ? 'border-slate-200' : 'border-[#262736]'} space-y-3`}>
                    <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>تصدير المحادثات</h4>
                    <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>حفظ محادثاتك محلياً على جهازك بصيغ مختلفة</p>
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={handleExportChatsMarkdown}
                        className={`px-3.5 py-2 ${isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-white'} rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors`}
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>تصدير بصيغة Markdown (.md)</span>
                      </button>
                      <button
                        onClick={handleExportData}
                        className={`px-3.5 py-2 ${isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-white'} rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors`}
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>تصدير كملف JSON</span>
                      </button>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-rose-900/40">
                    <h4 className="text-xs font-semibold text-rose-500">حذف المحادثات</h4>
                    <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'} mt-0.5`}>
                      مسح وإفراغ جميع محادثاتك وسجل الدردشة نهائياً من الحساب
                    </p>
                    <button
                      onClick={() => setShowClearChatsConfirm(true)}
                      className="mt-3 px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-xl flex items-center gap-2 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>مسح جميع المحادثات نهائياً</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 4. APPEARANCE TAB */}
            {activeTab === 'appearance' && (
              <div className="space-y-6">
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-3`}>
                  <div>
                    <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>النمط (Theme)</h4>
                    <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'} mt-0.5`}>
                      تبديل المظهر العام للتطبيق بين الوضع الداكن والوضع الفاتح أو مطابقة نظام التشغيل
                    </p>
                  </div>
                  <div className="grid grid-cols-3 gap-2.5">
                    {[
                      { id: 'dark', label: 'داكن (Dark)', icon: '🌙', desc: 'مظهر داكن مريح للعين' },
                      { id: 'light', label: 'فاتح (Light)', icon: '☀️', desc: 'مظهر ناصع ومشرق' },
                      { id: 'system', label: 'تلقائي (System)', icon: '💻', desc: 'مطابق للنظام' },
                    ].map((t) => (
                      <button
                        key={t.id}
                        onClick={() => onUpdateSettings({ theme: t.id as any })}
                        className={`p-3 rounded-xl border text-center transition-all ${
                          settings.theme === t.id
                            ? 'bg-blue-600/15 border-blue-500 text-blue-500 font-semibold shadow-sm'
                            : isLight
                            ? 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                            : 'bg-[#12131a] border-[#2b2c3d] text-neutral-300 hover:border-neutral-600'
                        }`}
                      >
                        <span className="text-xl block mb-1">{t.icon}</span>
                        <span className={`text-xs block font-semibold ${settings.theme === t.id ? 'text-blue-500' : isLight ? 'text-slate-800' : 'text-white'}`}>
                          {t.label}
                        </span>
                        <span className={`text-[10px] block mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                          {t.desc}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-3`}>
                  <div>
                    <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>حجم الخط</h4>
                    <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'} mt-0.5`}>
                      تغيير حجم النصوص في المحادثات والقوائم لتسهيل القراءة
                    </p>
                  </div>
                  <div className="grid grid-cols-3 gap-2.5">
                    {[
                      { id: 'small', label: 'صغير', sample: 'text-xs', desc: '12px' },
                      { id: 'medium', label: 'متوسط (افتراضي)', sample: 'text-sm', desc: '14px' },
                      { id: 'large', label: 'كبير', sample: 'text-base', desc: '16px' },
                    ].map((f) => (
                      <button
                        key={f.id}
                        onClick={() => onUpdateSettings({ fontSize: f.id as any })}
                        className={`p-2.5 rounded-xl border text-center transition-all ${
                          settings.fontSize === f.id
                            ? 'bg-blue-600/15 border-blue-500 text-blue-500 font-semibold'
                            : isLight
                            ? 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                            : 'bg-[#12131a] border-[#2b2c3d] text-neutral-300 hover:border-neutral-600'
                        }`}
                      >
                        <span className={`block font-semibold ${f.sample} ${settings.fontSize === f.id ? 'text-blue-500' : isLight ? 'text-slate-800' : 'text-white'}`}>
                          {f.label}
                        </span>
                        <span className={`text-[10px] block mt-0.5 ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{f.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-3`}>
                  <div>
                    <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>لون التمييز الأساسي</h4>
                    <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'} mt-0.5`}>
                      اللون المخصص للأزرار التفاعلية والإشارات
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2.5">
                    {[
                      { id: 'blue', color: 'bg-blue-500', label: 'أزرق ملكي' },
                      { id: 'cyan', color: 'bg-cyan-500', label: 'سماوي' },
                      { id: 'purple', color: 'bg-purple-500', label: 'بنفسجي' },
                      { id: 'emerald', color: 'bg-emerald-500', label: 'زمردي' },
                    ].map((c) => (
                      <button
                        key={c.id}
                        onClick={() => onUpdateSettings({ accentColor: c.id as any })}
                        className={`flex items-center gap-2 px-3.5 py-2 rounded-xl border text-xs transition-all ${
                          settings.accentColor === c.id
                            ? 'border-blue-500 bg-blue-500/10 font-semibold text-blue-500'
                            : isLight
                            ? 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                            : 'border-[#2b2c3d] bg-[#12131a] text-neutral-400 hover:border-neutral-600'
                        }`}
                      >
                        <span className={`w-3.5 h-3.5 rounded-full ${c.color} shrink-0`} />
                        <span>{c.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 5. VOICE TAB */}
            {activeTab === 'voice' && (
              <div className="space-y-6">
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-4`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>القراءة الصوتية (Text-to-Speech)</h4>
                      <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>تمكين الاستماع لإجابات الذكاء الاصطناعي</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.ttsEnabled}
                        onChange={(e) => onUpdateSettings({ ttsEnabled: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className={`w-11 h-6 ${isLight ? 'bg-slate-300' : 'bg-neutral-800'} peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600`}></div>
                    </label>
                  </div>

                  <div className={`pt-3 border-t ${isLight ? 'border-slate-200' : 'border-[#262736]'} space-y-3`}>
                    <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>اختيار الصوت</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'Aoede', name: 'Aoede', type: 'أنثوي - ناعم وطبيعي' },
                        { id: 'Kore', name: 'Kore', type: 'أنثوي - مشرق وحيوي' },
                        { id: 'Puck', name: 'Puck', type: 'ذكوري - هادئ ورصين' },
                        { id: 'Charon', name: 'Charon', type: 'ذكوري - عميق ودافئ' },
                        { id: 'Fenrir', name: 'Fenrir', type: 'ذكوري - قوي وواضح' },
                      ].map((v) => (
                        <button
                          key={v.id}
                          onClick={() => onUpdateSettings({ voiceName: v.id })}
                          className={`p-2.5 rounded-xl border text-right text-xs transition-all ${
                            settings.voiceName === v.id
                              ? 'bg-blue-600/15 border-blue-500 text-blue-500 font-semibold'
                              : isLight
                              ? 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                              : 'bg-[#12131a] border-[#2b2c3d] text-neutral-300'
                          }`}
                        >
                          <p className={`font-semibold ${settings.voiceName === v.id ? 'text-blue-500' : isLight ? 'text-slate-800' : 'text-white'}`}>{v.name}</p>
                          <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'} mt-0.5`}>{v.type}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className={`pt-3 border-t ${isLight ? 'border-slate-200' : 'border-[#262736]'} space-y-2`}>
                    <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>سرعة القراءة الصوتية ({settings.voiceSpeed}x)</h4>
                    <input
                      type="range"
                      min="0.75"
                      max="1.5"
                      step="0.25"
                      value={settings.voiceSpeed}
                      onChange={(e) => onUpdateSettings({ voiceSpeed: parseFloat(e.target.value) })}
                      className="w-full accent-blue-500"
                    />
                    <div className={`flex justify-between text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-500'}`}>
                      <span>0.75x</span>
                      <span>1.0x (افتراضي)</span>
                      <span>1.25x</span>
                      <span>1.5x</span>
                    </div>
                  </div>

                  <div className={`pt-3 border-t ${isLight ? 'border-slate-200' : 'border-[#262736]'} flex items-center justify-between`}>
                    <div>
                      <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>تشغيل تلقائي للصوت (Auto-play)</h4>
                      <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>قراءة الرد تلقائياً فور انتهائه</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.autoPlayAudio}
                        onChange={(e) => onUpdateSettings({ autoPlayAudio: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className={`w-11 h-6 ${isLight ? 'bg-slate-300' : 'bg-neutral-800'} peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600`}></div>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* 6. NOTIFICATIONS TAB */}
            {activeTab === 'notifications' && (
              <div className="space-y-6">
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-4`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>تمكين الإشعارات</h4>
                      <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>تلقي إشعارات عند اكتمال المهام والتحديثات</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.notificationsEnabled}
                        onChange={(e) => {
                          const val = e.target.checked;
                          if (val && typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
                            Notification.requestPermission();
                          }
                          onUpdateSettings({ notificationsEnabled: val });
                        }}
                        className="sr-only peer"
                      />
                      <div className={`w-11 h-6 ${isLight ? 'bg-slate-300' : 'bg-neutral-800'} peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600`}></div>
                    </label>
                  </div>

                  {settings.notificationsEnabled && (
                    <div className={`pt-3 border-t ${isLight ? 'border-slate-200' : 'border-[#262736]'} space-y-3`}>
                      <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>أنواع الإشعارات</h4>
                      {[
                        {
                          key: 'generationComplete',
                          title: 'اكتمال توليد الصور والملفات',
                          desc: 'إشعار فوري عند انتهاء تجهيز الصور المعقدة أو تحليل الملفات',
                        },
                        {
                          key: 'systemUpdates',
                          title: 'تحديثات النظام والميزات الجديدة',
                          desc: 'إشعار بالنماذج والإضافات المحدثة',
                        },
                        {
                          key: 'tips',
                          title: 'نصائح ذكية للاستخدام',
                          desc: 'اقتراحات مفيدة لتحسين أوامرك للذكاء الاصطناعي',
                        },
                      ].map((n) => (
                        <div key={n.key} className="flex items-center justify-between py-1.5">
                          <div>
                            <p className={`text-xs ${isLight ? 'text-slate-800' : 'text-neutral-200'} font-medium`}>{n.title}</p>
                            <p className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>{n.desc}</p>
                          </div>
                          <input
                            type="checkbox"
                            checked={(settings.notificationTypes as any)?.[n.key] ?? true}
                            onChange={(e) =>
                              onUpdateSettings({
                                notificationTypes: {
                                  ...settings.notificationTypes,
                                  [n.key]: e.target.checked,
                                },
                              })
                            }
                            className="w-4 h-4 accent-blue-500 rounded cursor-pointer"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 7. PRIVACY & DATA TAB */}
            {activeTab === 'privacy' && (
              <div className="space-y-6">
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-4`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>مشاركة البيانات لتحسين النماذج</h4>
                      <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                        السماح باستخدام المحادثات بشكل مجهول الهوية لتحسين أداء النماذج
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.dataSharingEnabled}
                        onChange={(e) => onUpdateSettings({ dataSharingEnabled: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className={`w-11 h-6 ${isLight ? 'bg-slate-300' : 'bg-neutral-800'} peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600`}></div>
                    </label>
                  </div>

                  <div className={`pt-3 border-t ${isLight ? 'border-slate-200' : 'border-[#262736]'} space-y-2`}>
                    <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>تصدير وتنزيل كافة بياناتك</h4>
                    <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>
                      احصل على نسخة كاملة من ملفك الشخصي، إعداداتك، ذكرياتك، ومحادثاتك بتنسيق JSON
                    </p>
                    <button
                      onClick={handleExportData}
                      className={`px-3.5 py-2 ${isLight ? 'bg-slate-200 hover:bg-slate-300 text-slate-800' : 'bg-neutral-800 hover:bg-neutral-700 text-white'} rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors`}
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>تنزيل أرشيف البيانات الكامل</span>
                    </button>
                  </div>

                  <div className={`pt-3 border-t ${isLight ? 'border-slate-200' : 'border-[#262736]'} space-y-2`}>
                    <h4 className={`text-xs font-semibold ${isLight ? 'text-slate-900' : 'text-white'}`}>السياسات والشروط</h4>
                    <div className="flex gap-4 text-xs text-blue-500">
                      <a href="#privacy" onClick={(e) => { e.preventDefault(); alert('سياسة الخصوصية: كافة محادثاتك وبياناتك مشفرة ولا يتم مشاركتها مع أطراف خارجية.'); }} className="hover:underline flex items-center gap-1">
                        <span>سياسة الخصوصية</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                      <a href="#terms" onClick={(e) => { e.preventDefault(); alert('شروط الخدمة: أنت تمتلك كافة حقوق المحتوى الناتج عن الذكاء الاصطناعي.'); }} className="hover:underline flex items-center gap-1">
                        <span>شروط الخدمة</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 8. SUBSCRIPTION TAB */}
            {activeTab === 'subscription' && (
              <div className="space-y-6">
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-4`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-500 border border-blue-500/30">
                        الخطة الحالية
                      </span>
                      <h4 className={`text-base font-bold ${isLight ? 'text-slate-900' : 'text-white'} mt-1`}>Onyx AI Professional</h4>
                      <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'}`}>وصول غير محدود لجميع نماذج Gemini وتوليد الصور الفوري</p>
                    </div>
                    <Sparkles className="w-8 h-8 text-blue-500 fill-blue-500/20" />
                  </div>

                  {/* Quotas */}
                  <div className={`space-y-2 pt-2 border-t ${isLight ? 'border-slate-200' : 'border-[#262736]'}`}>
                    <div className={`flex justify-between text-xs ${isLight ? 'text-slate-700' : 'text-neutral-300'}`}>
                      <span>الرسائل والاستفسارات الشهرية</span>
                      <span className="text-emerald-500 font-semibold">غير محدود</span>
                    </div>
                    <div className={`w-full h-2 ${isLight ? 'bg-slate-200' : 'bg-neutral-800'} rounded-full overflow-hidden`}>
                      <div className="w-[18%] h-full bg-blue-500 rounded-full" />
                    </div>

                    <div className={`flex justify-between text-xs ${isLight ? 'text-slate-700' : 'text-neutral-300'} pt-2`}>
                      <span>توليد الصور بدقة 4K</span>
                      <span className={`font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>14 / 100</span>
                    </div>
                    <div className={`w-full h-2 ${isLight ? 'bg-slate-200' : 'bg-neutral-800'} rounded-full overflow-hidden`}>
                      <div className="w-[14%] h-full bg-cyan-500 rounded-full" />
                    </div>
                  </div>

                  <button
                    onClick={() => showToast('أنت مشترك بالفعل في الباقة الاحترافية!')}
                    className="w-full py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-semibold rounded-xl text-xs shadow-lg transition-all"
                  >
                    إدارة الاشتراك والفوترة
                  </button>
                </div>
              </div>
            )}

            {/* 9. ABOUT TAB */}
            {activeTab === 'about' && (
              <div className="space-y-6">
                <div className={`${isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#171822] border-[#262736]'} p-4 sm:p-5 border rounded-2xl space-y-4`}>
                  <div className="text-center py-2">
                    <div className="w-12 h-12 mx-auto mb-2 rounded-2xl bg-blue-600/15 text-blue-500 flex items-center justify-center font-bold text-xl">
                      ⚡
                    </div>
                    <h4 className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'} text-base`}>OnyxMind AI</h4>
                    <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-neutral-400'} mt-0.5`}>الإصدار v2.5.0 (Gemini Multi-Engine)</p>
                  </div>

                  <div className={`space-y-2 pt-3 border-t ${isLight ? 'border-slate-200' : 'border-[#262736]'} text-xs`}>
                    <button
                      onClick={() => alert('مركز المساعدة: لأي استفسار تواصل معنا عبر support@onyx.ai')}
                      className={`w-full flex items-center justify-between p-2.5 ${isLight ? 'bg-white hover:bg-slate-100 border border-slate-200 text-slate-800' : 'bg-[#12131a] hover:bg-[#1a1b24] text-neutral-200'} rounded-xl transition-colors`}
                    >
                      <span className="flex items-center gap-2">
                        <HelpCircle className="w-4 h-4 text-blue-500" />
                        <span>مركز المساعدة والدعم</span>
                      </span>
                      <ExternalLink className={`w-3.5 h-3.5 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
                    </button>

                    <button
                      onClick={() => alert('شكراً لملاحظاتك! تم فتح قناة الدعم السريع.')}
                      className={`w-full flex items-center justify-between p-2.5 ${isLight ? 'bg-white hover:bg-slate-100 border border-slate-200 text-slate-800' : 'bg-[#12131a] hover:bg-[#1a1b24] text-neutral-200'} rounded-xl transition-colors`}
                    >
                      <span className="flex items-center gap-2">
                        <MessageCircle className="w-4 h-4 text-cyan-500" />
                        <span>إرسال ملاحظات واقتراحات</span>
                      </span>
                      <ExternalLink className={`w-3.5 h-3.5 ${isLight ? 'text-slate-400' : 'text-neutral-500'}`} />
                    </button>
                  </div>

                  <p className={`text-[11px] ${isLight ? 'text-slate-400' : 'text-neutral-500'} text-center pt-2`}>
                    جميع الحقوق محفوظة © {new Date().getFullYear()} OnyxMind AI
                  </p>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Confirmation Dialog: Delete Account */}
      {showDeleteAccountConfirm && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="w-full max-w-sm bg-[#16171f] border border-rose-800 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-white text-base">هل أنت متأكد من حذف الحساب؟</h4>
            <p className="text-xs text-neutral-400">
              سيتم حذف جميع المحادثات والذكريات والإعدادات نهائياً ولا يمكن استرجاعها مطلقاً.
            </p>
            <div className="flex gap-2.5 pt-2">
              <button
                onClick={() => setShowDeleteAccountConfirm(false)}
                className="flex-1 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold"
              >
                إلغاء
              </button>
              <button
                onClick={async () => {
                  setShowDeleteAccountConfirm(false);
                  await onDeleteAccount();
                }}
                className="flex-1 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold"
              >
                تأكيد الحذف النهائي
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Dialog: Clear All Chats */}
      {showClearChatsConfirm && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="w-full max-w-sm bg-[#16171f] border border-rose-800 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-white text-base">مسح جميع المحادثات؟</h4>
            <p className="text-xs text-neutral-400">
              سيتم حذف كافة جلسات المحادثات في حسابك نهائياً.
            </p>
            <div className="flex gap-2.5 pt-2">
              <button
                onClick={() => setShowClearChatsConfirm(false)}
                className="flex-1 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold"
              >
                إلغاء
              </button>
              <button
                onClick={() => {
                  setShowClearChatsConfirm(false);
                  onClearAllSessions();
                  showToast('تم مسح جميع المحادثات.');
                }}
                className="flex-1 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold"
              >
                مسح الكل
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Dialog: Clear All Memories */}
      {showClearMemoriesConfirm && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="w-full max-w-sm bg-[#16171f] border border-rose-800 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-white text-base">مسح جميع الذكريات؟</h4>
            <p className="text-xs text-neutral-400">
              سيفقد الذكاء الاصطناعي كافة المعلومات والتفضيلات المحفوظة عنك.
            </p>
            <div className="flex gap-2.5 pt-2">
              <button
                onClick={() => setShowClearMemoriesConfirm(false)}
                className="flex-1 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold"
              >
                إلغاء
              </button>
              <button
                onClick={async () => {
                  setShowClearMemoriesConfirm(false);
                  await onClearAllMemories();
                  showToast('تم مسح جميع الذكريات.');
                }}
                className="flex-1 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold"
              >
                مسح الذكريات
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
