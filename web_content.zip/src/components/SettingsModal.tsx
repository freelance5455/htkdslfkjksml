import React, { useState } from 'react';
import { GameEngine, QualityPreset, TimeOfDay } from '../game/core/GameEngine';
import { HUDManager, JoystickMode } from '../game/hud/HUDConfig';
import { DifficultyManager, DifficultyLevel, DifficultySettings } from '../game/difficulty/DifficultyManager';
import {
  DeviceProfileManager,
  DeviceProfileType,
  PROFILE_EXPLANATIONS,
  DeviceProfileConfig,
} from '../game/settings/DeviceProfileManager';
import { sound } from '../audio/SoundEngine';
import {
  Monitor,
  Sliders,
  Volume2,
  X,
  Check,
  Smartphone,
  Layout,
  Skull,
  LogOut,
  AlertTriangle,
  DoorOpen,
  Save,
  RotateCcw,
  Zap,
} from 'lucide-react';

interface SettingsModalProps {
  engine: GameEngine;
  onClose: () => void;
  onResume?: () => void;
  onOpenHUDEditor?: () => void;
  onLeaveGame?: () => void;
  isPaused?: boolean;
}

import { WEAPON_REGISTRY } from '../game/models/WeaponModels';
import { Crosshair, Info } from 'lucide-react';

type SettingsTab = 'general' | 'controls' | 'hud' | 'graphics' | 'audio' | 'gameplay' | 'device' | 'weapons';

export const SettingsModal: React.FC<SettingsModalProps> = ({
  engine,
  onClose,
  onResume,
  onOpenHUDEditor,
  onLeaveGame,
  isPaused = false,
}) => {
  const [tab, setTab] = useState<SettingsTab>('graphics');

  // Graphics state
  const [preset, setPreset] = useState<QualityPreset>(engine.graphics.preset);
  const [timeOfDay, setTimeOfDay] = useState<TimeOfDay>(engine.timeOfDay);
  const [resScale, setResScale] = useState<number>(engine.graphics.resolutionScale);
  const [fpsLimit, setFpsLimit] = useState<number>(engine.graphics.fpsLimit);
  const [dynamicRes, setDynamicRes] = useState<boolean>(engine.graphics.dynamicResolution);
  const [fov, setFov] = useState<number>(Math.round(engine.camera.fov));
  const [shadowQuality, setShadowQuality] = useState(engine.graphics.shadowQuality);
  const [shadowDistance, setShadowDistance] = useState(engine.graphics.shadowDistance);
  const [lightingQuality, setLightingQuality] = useState(engine.graphics.lightingQuality);
  const [waterQuality, setWaterQuality] = useState(engine.graphics.waterQuality);
  const [viewDistance, setViewDistance] = useState(engine.graphics.viewDistance);
  const [volumetric, setVolumetric] = useState(engine.graphics.volumetricEffects);

  // Controls state
  const [sensX, setSensX] = useState<number>(engine.player.sensX);
  const [sensY, setSensY] = useState<number>(engine.player.sensY);
  const [adsSens, setAdsSens] = useState<number>(engine.player.adsSensitivityMult);
  const [accel, setAccel] = useState<number>(engine.player.acceleration);
  const [joystickMode, setJoystickMode] = useState<JoystickMode>(() => HUDManager.load().joystickMode);
  const [doorMode, setDoorMode] = useState<'button' | 'automatic'>(engine.barricadesAndDoors.doorMode);

  // Audio state
  const [masterVol, setMasterVol] = useState<number>(0.85);
  const [sfxVol, setSfxVol] = useState<number>(0.85);
  const [zombieVol, setZombieVol] = useState<number>(0.8);
  const [voiceVol, setVoiceVol] = useState<number>(0.9);
  const [musicVol, setMusicVol] = useState<number>(0.45);

  // ADS options
  const [adsBehavior, setAdsBehavior] = useState<'tap' | 'hold' | 'hybrid'>(engine.player.adsBehavior);
  const [sniperSens, setSniperSens] = useState<number>(engine.player.sniperSensitivity);
  const [opticSens, setOpticSens] = useState<number>(engine.player.opticSensitivity);

  // Device profile (Persistent - Requirement 1)
  const [deviceProfile, setDeviceProfile] = useState<DeviceProfileType>(() => DeviceProfileManager.get().profile);
  const [highFpsMode, setHighFpsMode] = useState<boolean>(() => DeviceProfileManager.get().highFpsMode);

  // Difficulty state
  const [difficulty, setDifficulty] = useState<DifficultySettings>(() => DifficultyManager.get());

  // Leave Game Confirmation Modal
  const [showLeaveConfirm, setShowLeaveConfirm] = useState(false);

  const handleApplyPreset = (p: QualityPreset) => {
    sound.playUIClick();
    setPreset(p);
    engine.applyGraphics({ preset: p });
    setResScale(engine.graphics.resolutionScale);
    setShadowQuality(engine.graphics.shadowQuality);
    setLightingQuality(engine.graphics.lightingQuality);
    setWaterQuality(engine.graphics.waterQuality);
    setViewDistance(engine.graphics.viewDistance);
    setVolumetric(engine.graphics.volumetricEffects);
  };

  const applyProfileToEngine = (profileCfg: DeviceProfileConfig) => {
    engine.applyGraphics({
      resolutionScale: profileCfg.resolutionScale,
      shadowQuality: profileCfg.shadowQuality,
      shadowDistance: profileCfg.shadowDistance,
      waterQuality: profileCfg.waterQuality,
      reflectionQuality: profileCfg.reflectionQuality,
      cloudQuality: profileCfg.cloudQuality,
      volumetricEffects: profileCfg.volumetricEffects,
      viewDistance: profileCfg.viewDistance,
      fpsLimit: profileCfg.fpsLimit,
    });
    setResScale(profileCfg.resolutionScale);
    setShadowQuality(profileCfg.shadowQuality);
    setWaterQuality(profileCfg.waterQuality);
    setViewDistance(profileCfg.viewDistance);
    setFpsLimit(profileCfg.fpsLimit);
  };

  const handleDeviceProfileChange = (tier: DeviceProfileType) => {
    sound.playUIClick();
    setDeviceProfile(tier);
    const updated = DeviceProfileManager.setProfile(tier);
    setHighFpsMode(updated.highFpsMode);
    applyProfileToEngine(updated);
  };

  const handleResetToAutomatic = () => {
    sound.playUIClick();
    setDeviceProfile('automatic');
    const updated = DeviceProfileManager.resetToAutomatic();
    setHighFpsMode(updated.highFpsMode);
    applyProfileToEngine(updated);
  };

  const handleSaveProfile = () => {
    sound.playBuySound();
    const cur = DeviceProfileManager.get();
    cur.profile = deviceProfile;
    cur.highFpsMode = highFpsMode;
    DeviceProfileManager.save(cur);
  };

  const handleTimeOfDayChange = (tod: TimeOfDay) => {
    sound.playUIClick();
    setTimeOfDay(tod);
    engine.setTimeOfDay(tod);
  };

  const handleSensXChange = (val: number) => {
    setSensX(val);
    engine.player.sensX = val;
  };

  const handleSensYChange = (val: number) => {
    setSensY(val);
    engine.player.sensY = val;
  };

  const handleAdsSensChange = (val: number) => {
    setAdsSens(val);
    engine.player.adsSensitivityMult = val;
  };

  const handleAccelChange = (val: number) => {
    setAccel(val);
    engine.player.acceleration = val;
  };

  const handleJoystickModeChange = (mode: JoystickMode) => {
    sound.playUIClick();
    setJoystickMode(mode);
    const cfg = HUDManager.load();
    cfg.joystickMode = mode;
    HUDManager.save(cfg);
  };

  const handleDoorModeChange = (mode: 'button' | 'automatic') => {
    sound.playUIClick();
    setDoorMode(mode);
    engine.barricadesAndDoors.doorMode = mode;
  };

  const handleDifficultyPreset = (lvl: DifficultyLevel) => {
    sound.playUIClick();
    const updated = DifficultyManager.setLevel(lvl);
    setDifficulty(updated);
    engine.zombies.setDifficulty(updated);
  };

  const handleCustomDiff = (key: keyof DifficultySettings, val: any) => {
    const updated: DifficultySettings = {
      ...difficulty,
      level: 'custom',
      [key]: val,
    };
    DifficultyManager.set(updated);
    setDifficulty(updated);
    engine.zombies.setDifficulty(updated);
  };

  return (
    <div className="absolute inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 select-none">
      <div className="relative w-full max-w-3xl bg-zinc-950 border border-zinc-800 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex justify-between items-center px-4 sm:px-6 py-3 border-b border-zinc-800 bg-zinc-900/70">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                sound.playUIClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 font-teko text-xl tracking-wider uppercase font-semibold cursor-pointer active:scale-95 transition-all"
            >
              <span className="text-red-500 text-lg">←</span>
              <span>BACK</span>
            </button>

            <div className="h-6 w-[1px] bg-zinc-800 hidden sm:block" />

            <h2 className="text-2xl sm:text-3xl font-teko uppercase text-white font-bold tracking-wider hidden sm:block">
              {isPaused ? 'MISSION PAUSED' : 'SYSTEM CONFIGURATION'}
            </h2>

            {/* Tabs (Requirement 4: 8 Clean Modern Categories) */}
            <div className="flex gap-1.5 flex-wrap">
              {[
                { id: 'general', label: 'GENERAL', icon: Info },
                { id: 'controls', label: 'CONTROLS', icon: Sliders },
                { id: 'hud', label: 'HUD', icon: Layout },
                { id: 'graphics', label: 'GRAPHICS', icon: Monitor },
                { id: 'audio', label: 'AUDIO', icon: Volume2 },
                { id: 'gameplay', label: 'GAMEPLAY', icon: Skull },
                { id: 'device', label: 'DEVICE', icon: Smartphone },
                { id: 'weapons', label: 'WEAPONS', icon: Crosshair },
              ].map(t => {
                const Icon = t.icon;
                return (
                  <button
                    key={t.id}
                    onClick={() => {
                      sound.playUIClick();
                      setTab(t.id as SettingsTab);
                    }}
                    className={`px-2.5 py-1 rounded-lg font-mono-tech text-xs tracking-wider uppercase flex items-center gap-1 cursor-pointer transition-all ${
                      tab === t.id
                        ? 'bg-red-600 text-white font-bold shadow-md'
                        : 'bg-zinc-800/80 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{t.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => {
              sound.playUIClick();
              onClose();
            }}
            className="w-9 h-9 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div
          className="p-4 sm:p-6 overflow-y-auto max-h-[68vh] scroll-smooth"
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          {/* --- 1. GENERAL TAB --- */}
          {tab === 'general' && (
            <div className="flex flex-col gap-4">
              <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div>
                  <span className="font-teko text-2xl text-white font-bold block">BLACKOUT: DEAD RISING</span>
                  <span className="font-mono-tech text-xs text-zinc-400">Tactical 3D Zombie Survival FPS • 10 Theaters</span>
                </div>
                <span className="px-2.5 py-1 rounded bg-red-950 text-red-400 border border-red-800 font-mono-tech text-xs font-bold">
                  v2.4.0
                </span>
              </div>

              <div>
                <span className="text-zinc-500 font-mono-tech text-xs tracking-widest uppercase block mb-2 font-bold">
                  MAP TIME & ENVIRONMENT LIGHTING
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'day', label: 'Daylight (Clear)' },
                    { id: 'evening', label: 'Evening (Sunset)' },
                    { id: 'night', label: 'Night (Flashlight)' },
                  ].map(t => (
                    <button
                      key={t.id}
                      onClick={() => handleTimeOfDayChange(t.id as TimeOfDay)}
                      className={`py-2 px-3 rounded-xl border font-mono-tech text-xs tracking-wider uppercase transition-all cursor-pointer ${
                        timeOfDay === t.id
                          ? 'bg-zinc-800 border-amber-400 text-amber-300 font-bold'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-xl text-white tracking-wide">MASTER AUDIO MUTE</span>
                  <span className="font-mono-tech text-xs text-zinc-400">Toggle all in-game sound and music</span>
                </div>
                <button
                  onClick={() => {
                    sound.playUIClick();
                    sound.toggleMute();
                  }}
                  className="px-4 py-1.5 rounded-lg bg-zinc-800 border border-zinc-700 text-zinc-300 font-mono-tech text-xs cursor-pointer"
                >
                  TOGGLE MUTE
                </button>
              </div>
            </div>
          )}

          {/* --- 2. CONTROLS TAB --- */}
          {tab === 'controls' && (
            <div className="flex flex-col gap-4">
              {/* ADS Behavior Setting (Requirement 10 & 18) */}
              <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-xl text-white tracking-wide">ADS BUTTON BEHAVIOR</span>
                  <span className="font-mono-tech text-xs text-zinc-400">
                    Tap to toggle, Hold while aiming, or Hybrid (quick tap toggles, hold-release exits)
                  </span>
                </div>
                <div className="flex gap-1.5">
                  {(['tap', 'hold', 'hybrid'] as const).map(b => (
                    <button
                      key={b}
                      onClick={() => {
                        sound.playUIClick();
                        setAdsBehavior(b);
                        engine.player.adsBehavior = b;
                      }}
                      className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs uppercase cursor-pointer ${
                        adsBehavior === b ? 'bg-red-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sensitivities */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                    <span>HORIZONTAL SENSITIVITY</span>
                    <span className="text-red-400 font-bold">{sensX.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="3.0"
                    step="0.1"
                    value={sensX}
                    onChange={e => handleSensXChange(parseFloat(e.target.value))}
                    className="accent-red-500 cursor-pointer"
                  />
                </div>

                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                    <span>VERTICAL SENSITIVITY</span>
                    <span className="text-red-400 font-bold">{sensY.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="3.0"
                    step="0.1"
                    value={sensY}
                    onChange={e => handleSensYChange(parseFloat(e.target.value))}
                    className="accent-red-500 cursor-pointer"
                  />
                </div>

                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                    <span>ADS AIM SENSITIVITY</span>
                    <span className="text-red-400 font-bold">{Math.round(adsSens * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="1.5"
                    step="0.05"
                    value={adsSens}
                    onChange={e => handleAdsSensChange(parseFloat(e.target.value))}
                    className="accent-red-500 cursor-pointer"
                  />
                </div>

                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                    <span>SNIPER SCOPE SENSITIVITY</span>
                    <span className="text-red-400 font-bold">{Math.round(sniperSens * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="1.2"
                    step="0.05"
                    value={sniperSens}
                    onChange={e => {
                      const val = parseFloat(e.target.value);
                      setSniperSens(val);
                      engine.player.sniperSensitivity = val;
                    }}
                    className="w-full accent-red-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {/* --- 3. HUD CUSTOMIZER TAB --- */}
          {tab === 'hud' && (
            <div className="flex flex-col gap-4">
              <div className="p-4 rounded-xl bg-gradient-to-r from-red-950/60 to-zinc-900 border border-red-700/60 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-2xl text-white font-bold tracking-wide">
                    CUSTOMIZE ON-SCREEN HUD
                  </span>
                  <span className="font-mono-tech text-xs text-zinc-400">
                    Reposition, resize, or change transparency of every button with zero jitter
                  </span>
                </div>
                <button
                  onClick={() => {
                    sound.playUIClick();
                    if (onOpenHUDEditor) onOpenHUDEditor();
                  }}
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-2 shadow-lg shadow-red-600/30 cursor-pointer"
                >
                  <Layout className="w-5 h-5" />
                  <span>OPEN HUD EDITOR</span>
                </button>
              </div>

              {/* Fixed Center Crosshair Style Selector */}
              <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-3">
                <div className="flex justify-between items-center">
                  <span className="font-mono-tech text-xs text-amber-400 font-bold uppercase">
                    CENTER FIXED CROSSHAIR RETICLE STYLE
                  </span>
                  <span className="text-[10px] font-mono-tech text-zinc-500">
                    STAYS LOCKED CENTER
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'classic', label: 'Classic' },
                    { id: 'dot', label: 'Dot' },
                    { id: 'tactical', label: 'Tactical' },
                    { id: 'precision', label: 'Precision' },
                    { id: 'dynamic', label: 'Dynamic' },
                    { id: 'minimal', label: 'Minimal' },
                    { id: 'custom', label: 'Custom' },
                  ].map(s => (
                    <button
                      key={s.id}
                      onClick={() => {
                        sound.playUIClick();
                        const cfg = HUDManager.load();
                        cfg.crosshair.style = s.id as any;
                        HUDManager.save(cfg);
                      }}
                      className="py-2 px-2.5 rounded-lg border font-mono-tech text-xs cursor-pointer bg-zinc-950 border-zinc-800 text-zinc-300 hover:border-zinc-600"
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* --- 4. GRAPHICS TAB --- */}
          {tab === 'graphics' && (
            <div className="flex flex-col gap-5">
              <div>
                <span className="text-zinc-500 font-mono-tech text-xs tracking-widest uppercase block mb-2">
                  GRAPHICS QUALITY PRESET
                </span>
                <div className="grid grid-cols-4 gap-2">
                  {(['low', 'medium', 'high', 'very_high'] as QualityPreset[]).map(p => (
                    <button
                      key={p}
                      onClick={() => handleApplyPreset(p)}
                      className={`py-2.5 px-2 rounded-xl border font-teko text-xl tracking-wider uppercase font-bold transition-all cursor-pointer ${
                        preset === p
                          ? 'bg-red-600 border-red-400 text-white shadow-lg shadow-red-600/30'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      {p === 'very_high' ? 'ULTRA' : p.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-zinc-500 font-mono-tech text-xs tracking-widest uppercase block mb-2">
                  TIME & ATMOSPHERE
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'day', label: 'Daylight (Clear)' },
                    { id: 'evening', label: 'Evening (Sunset)' },
                    { id: 'night', label: 'Night (Flashlight)' },
                  ].map(t => (
                    <button
                      key={t.id}
                      onClick={() => handleTimeOfDayChange(t.id as TimeOfDay)}
                      className={`py-2 px-3 rounded-xl border font-mono-tech text-xs tracking-wider uppercase transition-all cursor-pointer ${
                        timeOfDay === t.id
                          ? 'bg-zinc-800 border-amber-400 text-amber-300'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* DISPLAY SECTION */}
              <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-3">
                <span className="font-mono-tech text-xs text-amber-400 font-bold uppercase">DISPLAY & RESOLUTION</span>
                
                {/* Resolution Scale (50% 360p, 60%, 70% 480p, 80%, 90% 720p, 100% 1080p) */}
                <div className="flex flex-col gap-1">
                  <div className="flex justify-between font-mono-tech text-xs text-zinc-300">
                    <span>RESOLUTION SCALE</span>
                    <span className="text-red-400 font-bold">
                      {Math.round(resScale * 100)}% ({resScale <= 0.55 ? '360p' : resScale <= 0.75 ? '480p' : resScale <= 0.88 ? '720p' : '1080p Native'})
                    </span>
                  </div>
                  <div className="grid grid-cols-6 gap-1">
                    {[
                      { val: 0.5, label: '360p' },
                      { val: 0.6, label: '60%' },
                      { val: 0.7, label: '480p' },
                      { val: 0.8, label: '80%' },
                      { val: 0.9, label: '720p' },
                      { val: 1.0, label: '1080p' },
                    ].map(r => (
                      <button
                        key={r.val}
                        onClick={() => {
                          sound.playUIClick();
                          setResScale(r.val);
                          engine.applyGraphics({ resolutionScale: r.val, preset: 'custom' });
                        }}
                        className={`py-1 rounded font-mono-tech text-xs font-bold cursor-pointer ${
                          Math.abs(resScale - r.val) < 0.04 ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {r.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* FPS Limit */}
                <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                  <span>TARGET FPS LIMIT</span>
                  <div className="flex gap-1">
                    {[30, 40, 60, 90, 120].map(f => (
                      <button
                        key={f}
                        onClick={() => {
                          sound.playUIClick();
                          setFpsLimit(f);
                          engine.applyGraphics({ fpsLimit: f, preset: 'custom' });
                        }}
                        className={`px-2 py-0.5 rounded font-mono-tech text-xs ${
                          fpsLimit === f ? 'bg-red-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Field of View */}
                <div className="flex flex-col gap-1">
                  <div className="flex justify-between font-mono-tech text-xs text-zinc-300">
                    <span>FIELD OF VIEW (FOV)</span>
                    <span className="text-cyan-400 font-bold">{fov}°</span>
                  </div>
                  <input
                    type="range"
                    min="65"
                    max="90"
                    step="1"
                    value={fov}
                    onChange={e => {
                      const val = parseInt(e.target.value);
                      setFov(val);
                      engine.camera.fov = val;
                      engine.camera.updateProjectionMatrix();
                    }}
                    className="accent-cyan-500 cursor-pointer"
                  />
                </div>

                {/* Dynamic Resolution Toggle */}
                <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                  <span>DYNAMIC RESOLUTION SCALING</span>
                  <button
                    onClick={() => {
                      sound.playUIClick();
                      const next = !dynamicRes;
                      setDynamicRes(next);
                      engine.applyGraphics({ dynamicResolution: next });
                    }}
                    className={`px-3 py-1 rounded font-mono-tech text-xs ${
                      dynamicRes ? 'bg-emerald-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    {dynamicRes ? 'ENABLED' : 'DISABLED'}
                  </button>
                </div>
              </div>

              {/* LIGHTING & SHADOWS SECTION */}
              <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-3">
                <span className="font-mono-tech text-xs text-amber-400 font-bold uppercase">LIGHTING & SHADOWS</span>

                {/* Shadow Quality */}
                <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                  <span>SHADOW QUALITY</span>
                  <div className="flex gap-1">
                    {(['off', 'low', 'medium', 'high', 'ultra'] as const).map(sq => (
                      <button
                        key={sq}
                        onClick={() => {
                          sound.playUIClick();
                          setShadowQuality(sq);
                          engine.applyGraphics({ shadowQuality: sq, preset: 'custom' });
                        }}
                        className={`px-2.5 py-0.5 rounded font-mono-tech text-xs uppercase ${
                          shadowQuality === sq ? 'bg-red-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {sq}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Shadow Distance */}
                <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                  <span>SHADOW DISTANCE</span>
                  <div className="flex gap-1">
                    {(['low', 'medium', 'high'] as const).map(sd => (
                      <button
                        key={sd}
                        onClick={() => {
                          sound.playUIClick();
                          setShadowDistance(sd);
                          engine.applyGraphics({ shadowDistance: sd, preset: 'custom' });
                        }}
                        className={`px-3 py-0.5 rounded font-mono-tech text-xs uppercase ${
                          shadowDistance === sd ? 'bg-red-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {sd}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Lighting Quality */}
                <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                  <span>LIGHTING QUALITY</span>
                  <div className="flex gap-1">
                    {(['low', 'medium', 'high', 'ultra'] as const).map(lq => (
                      <button
                        key={lq}
                        onClick={() => {
                          sound.playUIClick();
                          setLightingQuality(lq);
                          engine.applyGraphics({ lightingQuality: lq, preset: 'custom' });
                        }}
                        className={`px-2.5 py-0.5 rounded font-mono-tech text-xs uppercase ${
                          lightingQuality === lq ? 'bg-red-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {lq}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Volumetric Sun / Moon Rays */}
                <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                  <span>SUN & MOON VOLUMETRIC RAYS</span>
                  <div className="flex gap-1">
                    {(['off', 'low', 'high'] as const).map(vr => (
                      <button
                        key={vr}
                        onClick={() => {
                          sound.playUIClick();
                          setVolumetric(vr);
                          engine.applyGraphics({ volumetricEffects: vr, preset: 'custom' });
                        }}
                        className={`px-3 py-0.5 rounded font-mono-tech text-xs uppercase ${
                          volumetric === vr ? 'bg-amber-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {vr}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* ENVIRONMENT & WATER SECTION */}
              <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-3">
                <span className="font-mono-tech text-xs text-cyan-400 font-bold uppercase">ENVIRONMENT & WATER</span>

                {/* Water Quality */}
                <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                  <span>WATER QUALITY & REFLECTIONS</span>
                  <div className="flex gap-1">
                    {(['low', 'medium', 'high', 'ultra'] as const).map(wq => (
                      <button
                        key={wq}
                        onClick={() => {
                          sound.playUIClick();
                          setWaterQuality(wq);
                          engine.applyGraphics({ waterQuality: wq, preset: 'custom' });
                        }}
                        className={`px-2.5 py-0.5 rounded font-mono-tech text-xs uppercase ${
                          waterQuality === wq ? 'bg-cyan-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {wq}
                      </button>
                    ))}
                  </div>
                </div>

                {/* View Distance */}
                <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                  <span>VIEW DISTANCE (FOG RANGE)</span>
                  <div className="flex gap-1">
                    {(['low', 'medium', 'high', 'ultra'] as const).map(vd => (
                      <button
                        key={vd}
                        onClick={() => {
                          sound.playUIClick();
                          setViewDistance(vd);
                          engine.applyGraphics({ viewDistance: vd, preset: 'custom' });
                        }}
                        className={`px-2.5 py-0.5 rounded font-mono-tech text-xs uppercase ${
                          viewDistance === vd ? 'bg-cyan-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {vd}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* --- CONTROLS TAB --- */}
          {tab === 'controls' && (
            <div className="flex flex-col gap-4">
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-red-950/60 to-zinc-900 border border-red-700/60 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-2xl text-white font-bold tracking-wide">
                    CUSTOMIZE ON-SCREEN HUD
                  </span>
                  <span className="font-mono-tech text-xs text-zinc-400">
                    Reposition, resize, or change transparency of every button
                  </span>
                </div>
                <button
                  onClick={() => {
                    sound.playUIClick();
                    if (onOpenHUDEditor) onOpenHUDEditor();
                  }}
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-2 shadow-lg shadow-red-600/30 cursor-pointer"
                >
                  <Layout className="w-5 h-5" />
                  <span>OPEN HUD EDITOR</span>
                </button>
              </div>

              {/* Door Interaction Setting (Requirement 29) */}
              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-xl text-white tracking-wide flex items-center gap-1.5">
                    <DoorOpen className="w-4 h-4 text-emerald-400" />
                    DOOR INTERACTION MODE
                  </span>
                  <span className="font-mono-tech text-xs text-zinc-400">
                    Automatic opens doors when approaching; Button requires interact tap
                  </span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleDoorModeChange('button')}
                    className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs cursor-pointer ${
                      doorMode === 'button' ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    BUTTON (MANUAL)
                  </button>
                  <button
                    onClick={() => handleDoorModeChange('automatic')}
                    className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs cursor-pointer ${
                      doorMode === 'automatic' ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    AUTOMATIC
                  </button>
                </div>
              </div>

              {/* Joystick Mode */}
              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-xl text-white tracking-wide">JOYSTICK MODE</span>
                  <span className="font-mono-tech text-xs text-zinc-400">
                    Dynamic creates joystick at touch position; Fixed keeps it in corner
                  </span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleJoystickModeChange('dynamic')}
                    className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs cursor-pointer ${
                      joystickMode === 'dynamic' ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    DYNAMIC
                  </button>
                  <button
                    onClick={() => handleJoystickModeChange('fixed')}
                    className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs cursor-pointer ${
                      joystickMode === 'fixed' ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    FIXED
                  </button>
                </div>
              </div>

              {/* Auto Sprint Setting */}
              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-xl text-white tracking-wide">AUTO SPRINT (MOBILE)</span>
                  <span className="font-mono-tech text-xs text-zinc-400">
                    Pushing joystick forward past 50% automatically transitions into sprint
                  </span>
                </div>
                <button
                  onClick={() => {
                    sound.playUIClick();
                    engine.player.autoSprint = !engine.player.autoSprint;
                  }}
                  className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                    engine.player.autoSprint ? 'bg-red-600' : 'bg-zinc-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                      engine.player.autoSprint ? 'left-7' : 'left-1'
                    }`}
                  />
                </button>
              </div>

              {/* Sensitivity Sliders */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                    <span>HORIZONTAL SENSITIVITY</span>
                    <span className="text-red-400 font-bold">{sensX.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="3.0"
                    step="0.1"
                    value={sensX}
                    onChange={e => handleSensXChange(parseFloat(e.target.value))}
                    className="w-full accent-red-500 cursor-pointer"
                  />
                </div>

                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                    <span>VERTICAL SENSITIVITY</span>
                    <span className="text-red-400 font-bold">{sensY.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="3.0"
                    step="0.1"
                    value={sensY}
                    onChange={e => handleSensYChange(parseFloat(e.target.value))}
                    className="w-full accent-red-500 cursor-pointer"
                  />
                </div>

                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                    <span>ADS AIM SENSITIVITY</span>
                    <span className="text-red-400 font-bold">{Math.round(adsSens * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="1.5"
                    step="0.05"
                    value={adsSens}
                    onChange={e => handleAdsSensChange(parseFloat(e.target.value))}
                    className="w-full accent-red-500 cursor-pointer"
                  />
                </div>

                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                    <span>AIM ACCELERATION</span>
                    <span className="text-red-400 font-bold">{accel.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="2.0"
                    step="0.1"
                    value={accel}
                    onChange={e => handleAccelChange(parseFloat(e.target.value))}
                    className="w-full accent-red-500 cursor-pointer"
                  />
                </div>

                {/* Sniper Scope Sensitivity */}
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                    <span>SNIPER SCOPE SENSITIVITY</span>
                    <span className="text-red-400 font-bold">{Math.round(sniperSens * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="1.2"
                    step="0.05"
                    value={sniperSens}
                    onChange={e => {
                      const val = parseFloat(e.target.value);
                      setSniperSens(val);
                      engine.player.sniperSensitivity = val;
                    }}
                    className="w-full accent-red-500 cursor-pointer"
                  />
                </div>

                {/* Optic Sensitivity */}
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                    <span>OPTIC / REFLEX SENSITIVITY</span>
                    <span className="text-red-400 font-bold">{Math.round(opticSens * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="1.5"
                    step="0.05"
                    value={opticSens}
                    onChange={e => {
                      const val = parseFloat(e.target.value);
                      setOpticSens(val);
                      engine.player.opticSensitivity = val;
                    }}
                    className="w-full accent-red-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* ADS Behavior Setting (Requirement 10) */}
              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-xl text-white tracking-wide">ADS BUTTON BEHAVIOR</span>
                  <span className="font-mono-tech text-xs text-zinc-400">
                    Tap to toggle, Hold while aiming, or Hybrid (tap toggles, hold-release exits)
                  </span>
                </div>
                <div className="flex gap-1.5">
                  {(['tap', 'hold', 'hybrid'] as const).map(b => (
                    <button
                      key={b}
                      onClick={() => {
                        sound.playUIClick();
                        setAdsBehavior(b);
                        engine.player.adsBehavior = b;
                      }}
                      className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs uppercase cursor-pointer ${
                        adsBehavior === b ? 'bg-red-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* --- 5. GAMEPLAY TAB --- */}
          {tab === 'gameplay' && (
            <div className="flex flex-col gap-4">
              <div>
                <span className="text-zinc-500 font-mono-tech text-xs tracking-widest uppercase block mb-2 font-bold">
                  GAME DIFFICULTY LEVEL
                </span>
                <div className="grid grid-cols-4 gap-2">
                  {(['easy', 'normal', 'hard', 'custom'] as DifficultyLevel[]).map(lvl => (
                    <button
                      key={lvl}
                      onClick={() => handleDifficultyPreset(lvl)}
                      className={`py-2 px-2 rounded-xl border font-teko text-xl tracking-wider uppercase font-bold transition-all cursor-pointer ${
                        difficulty.level === lvl
                          ? 'bg-red-600 border-red-400 text-white shadow-lg shadow-red-600/30'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              {/* Door Interaction Mode (Requirement 4 & 5) */}
              <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-xl text-white tracking-wide flex items-center gap-1.5">
                    <DoorOpen className="w-4 h-4 text-emerald-400" />
                    DOOR INTERACTION MODE
                  </span>
                  <span className="font-mono-tech text-xs text-zinc-400">
                    Automatic opens doors when approaching; Button requires interact tap
                  </span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleDoorModeChange('button')}
                    className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs cursor-pointer ${
                      doorMode === 'button' ? 'bg-red-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    BUTTON (MANUAL)
                  </button>
                  <button
                    onClick={() => handleDoorModeChange('automatic')}
                    className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs cursor-pointer ${
                      doorMode === 'automatic' ? 'bg-red-600 text-white font-bold' : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    AUTOMATIC
                  </button>
                </div>
              </div>

              {/* Auto Sprint Setting */}
              <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-xl text-white tracking-wide">AUTO SPRINT (MOBILE)</span>
                  <span className="font-mono-tech text-xs text-zinc-400">
                    Pushing joystick forward past 50% automatically transitions into sprint
                  </span>
                </div>
                <button
                  onClick={() => {
                    sound.playUIClick();
                    engine.player.autoSprint = !engine.player.autoSprint;
                  }}
                  className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                    engine.player.autoSprint ? 'bg-red-600' : 'bg-zinc-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                      engine.player.autoSprint ? 'left-7' : 'left-1'
                    }`}
                  />
                </button>
              </div>

              {difficulty.level === 'custom' && (
                <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-3">
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                      <span>ZOMBIE HEALTH MULTIPLIER</span>
                      <span className="text-red-400 font-bold">{Math.round(difficulty.healthMultiplier * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="2.5"
                      step="0.1"
                      value={difficulty.healthMultiplier}
                      onChange={e => handleCustomDiff('healthMultiplier', parseFloat(e.target.value))}
                      className="accent-red-500 cursor-pointer"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                      <span>ZOMBIE ATTACK DAMAGE</span>
                      <span className="text-red-400 font-bold">{Math.round(difficulty.damageMultiplier * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="2.5"
                      step="0.1"
                      value={difficulty.damageMultiplier}
                      onChange={e => handleCustomDiff('damageMultiplier', parseFloat(e.target.value))}
                      className="accent-red-500 cursor-pointer"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-300">
                      <span>ZOMBIE SPEED (REALISTIC CONTROLLED)</span>
                      <span className="text-red-400 font-bold">{Math.round(difficulty.speedMultiplier * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.8"
                      max="1.2"
                      step="0.05"
                      value={difficulty.speedMultiplier}
                      onChange={e => handleCustomDiff('speedMultiplier', parseFloat(e.target.value))}
                      className="accent-red-500 cursor-pointer"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* --- 6. WEAPONS TAB --- */}
          {tab === 'weapons' && (
            <div className="flex flex-col gap-4">
              <span className="text-zinc-500 font-mono-tech text-xs tracking-widest uppercase font-bold">
                WEAPON ARSENAL & PERFORMANCE OVERVIEW
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {Object.values(WEAPON_REGISTRY).map(w => (
                  <div key={w.id} className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                    <div>
                      <span className="font-teko text-2xl text-white font-bold leading-none">{w.name}</span>
                      <span className="font-mono-tech text-[10px] text-red-400 uppercase block">{w.type}</span>
                    </div>
                    <div className="font-mono-tech text-xs text-zinc-400 text-right">
                      <div>DMG: <span className="text-white font-bold">{w.damage}</span></div>
                      <div>ROF: <span className="text-amber-400 font-bold">{w.fireRate}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* --- DEVICE PERFORMANCE PROFILES (Requirement 1, 2, 3, 4) --- */}
          {tab === 'device' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-mono-tech text-xs text-amber-400 uppercase font-bold block">
                    DEVICE PERFORMANCE PROFILE
                  </span>
                  <span className="text-[10px] font-mono-tech text-zinc-400">
                    Saves permanently across sessions and maps. Choose Automatic or lock your tier.
                  </span>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={handleResetToAutomatic}
                    className="px-3 py-1 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 font-mono-tech text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>RESET TO AUTOMATIC</span>
                  </button>
                  <button
                    onClick={handleSaveProfile}
                    className="px-3.5 py-1 rounded-xl bg-red-600 hover:bg-red-500 text-white font-mono-tech text-xs font-bold flex items-center gap-1 shadow-md cursor-pointer"
                  >
                    <Save className="w-3 h-3" />
                    <span>SAVE PROFILE</span>
                  </button>
                </div>
              </div>

              {/* High FPS Mode Toggle (Requirement 4) */}
              <div className="p-3.5 rounded-xl bg-zinc-900/70 border border-zinc-800 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="font-teko text-xl text-white tracking-wide flex items-center gap-1.5">
                    <Zap className="w-4 h-4 text-amber-400" />
                    HIGH FPS MODE
                  </span>
                  <span className="font-mono-tech text-xs text-zinc-400">
                    Optimizes frame consistency, camera smoothness and touch responsiveness.
                  </span>
                </div>
                <button
                  onClick={() => {
                    sound.playUIClick();
                    const next = !highFpsMode;
                    setHighFpsMode(next);
                    const cur = DeviceProfileManager.get();
                    cur.highFpsMode = next;
                    DeviceProfileManager.save(cur);
                  }}
                  className={`px-3 py-1 rounded-lg font-mono-tech text-xs font-bold cursor-pointer ${
                    highFpsMode ? 'bg-emerald-600 text-white' : 'bg-zinc-800 text-zinc-400'
                  }`}
                >
                  {highFpsMode ? 'ON' : 'OFF'}
                </button>
              </div>

              {/* Profiles List */}
              <div className="flex flex-col gap-2">
                {(['automatic', 'low_end', 'medium_end', 'high_end', 'flagship'] as DeviceProfileType[]).map(id => {
                  const expl = PROFILE_EXPLANATIONS[id];
                  const isSelected = deviceProfile === id;

                  return (
                    <div
                      key={id}
                      onClick={() => handleDeviceProfileChange(id)}
                      className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-zinc-900 border-red-500 shadow-lg shadow-red-500/20'
                          : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {/* Radio indicator */}
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            isSelected ? 'border-red-500 bg-red-600' : 'border-zinc-600 bg-zinc-950'
                          }`}
                        >
                          {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                        </div>

                        <div className="flex flex-col">
                          <div className="flex items-center gap-2">
                            <span className="font-teko text-2xl text-white font-bold leading-none">{expl.title}</span>
                            <span className="font-mono-tech text-[10px] text-amber-400 font-semibold">{expl.targetFps}</span>
                          </div>
                          <span className="font-mono-tech text-xs text-zinc-400 mt-0.5">{expl.desc}</span>
                        </div>
                      </div>

                      {isSelected && (
                        <span className="px-2.5 py-0.5 rounded bg-red-950 text-red-400 border border-red-700 font-mono-tech text-xs font-bold">
                          ACTIVE
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* --- AUDIO TAB --- */}
          {tab === 'audio' && (
            <div className="flex flex-col gap-4">
              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                  <span>MASTER VOLUME</span>
                  <span className="text-red-400 font-bold">{Math.round(masterVol * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={masterVol}
                  onChange={e => {
                    const val = parseFloat(e.target.value);
                    setMasterVol(val);
                    sound.setMasterVolume(val);
                  }}
                  className="w-full accent-red-500 cursor-pointer"
                />
              </div>

              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                  <span>FIREARM & COMBAT SFX</span>
                  <span className="text-red-400 font-bold">{Math.round(sfxVol * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={sfxVol}
                  onChange={e => {
                    const val = parseFloat(e.target.value);
                    setSfxVol(val);
                    sound.setSfxVolume(val);
                  }}
                  className="w-full accent-red-500 cursor-pointer"
                />
              </div>

              {/* Zombie Audio Volume (Requirement 1) */}
              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                  <span>ZOMBIE GROAN & ATTACK AUDIO</span>
                  <span className="text-red-400 font-bold">{Math.round(zombieVol * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={zombieVol}
                  onChange={e => {
                    const val = parseFloat(e.target.value);
                    setZombieVol(val);
                    sound.setZombieVolume(val);
                  }}
                  className="w-full accent-red-500 cursor-pointer"
                />
              </div>

              {/* Voice / Announcer Volume (Requirement 1) */}
              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                  <span>ANNOUNCER & TACTICAL VOICEOVER</span>
                  <span className="text-red-400 font-bold">{Math.round(voiceVol * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={voiceVol}
                  onChange={e => {
                    const val = parseFloat(e.target.value);
                    setVoiceVol(val);
                    sound.setVoiceVolume(val);
                  }}
                  className="w-full accent-red-500 cursor-pointer"
                />
              </div>

              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                <div className="flex justify-between items-center font-mono-tech text-xs text-zinc-300">
                  <span>AMBIENT THEATER MUSIC</span>
                  <span className="text-red-400 font-bold">{Math.round(musicVol * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={musicVol}
                  onChange={e => {
                    const val = parseFloat(e.target.value);
                    setMusicVol(val);
                    sound.setMusicVolume(val);
                  }}
                  className="w-full accent-red-500 cursor-pointer"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer with LEAVE GAME and RESUME buttons */}
        <div className="flex justify-between items-center px-4 sm:px-6 py-3 border-t border-zinc-800 bg-zinc-900/80">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                sound.playUIClick();
                onClose();
              }}
              className="px-4 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-teko text-xl tracking-wider uppercase font-bold rounded-xl border border-zinc-700 cursor-pointer active:scale-95 transition-all flex items-center gap-1.5"
            >
              <span className="text-red-500">←</span>
              <span>BACK</span>
            </button>

            {/* Requirement 27: LEAVE GAME button when paused */}
            {isPaused && onLeaveGame && (
              <button
                onClick={() => {
                  sound.playUIClick();
                  setShowLeaveConfirm(true);
                }}
                className="px-4 py-1.5 bg-red-950/80 hover:bg-red-900 text-red-300 font-teko text-xl tracking-wider uppercase font-bold rounded-xl border border-red-700 cursor-pointer active:scale-95 transition-all flex items-center gap-1.5"
              >
                <LogOut className="w-4 h-4" />
                <span>LEAVE GAME</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {isPaused && onResume && (
              <button
                onClick={() => {
                  sound.playUIClick();
                  onResume();
                }}
                className="px-6 py-1.5 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 text-white font-teko text-2xl tracking-wider uppercase font-bold rounded-xl shadow-xl shadow-red-600/30 flex items-center gap-2 cursor-pointer transition-all active:scale-95"
              >
                <Check className="w-5 h-5" />
                <span>RESUME GAME</span>
              </button>
            )}

            {!isPaused && (
              <button
                onClick={() => {
                  sound.playUIClick();
                  onClose();
                }}
                className="px-6 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white font-teko text-xl tracking-wider uppercase font-bold rounded-xl cursor-pointer active:scale-95 transition-all"
              >
                DONE
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Requirement 27: LEAVE GAME CONFIRMATION MODAL */}
      {showLeaveConfirm && (
        <div className="absolute inset-0 z-60 bg-black/90 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-zinc-950 border-2 border-red-600 rounded-2xl p-6 flex flex-col items-center text-center shadow-2xl animate-fade-in">
            <div className="w-14 h-14 rounded-full bg-red-950/80 border border-red-500 flex items-center justify-center mb-3">
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>

            <h3 className="text-3xl font-teko uppercase font-bold text-white tracking-wide leading-none">
              LEAVE CURRENT GAME?
            </h3>
            <p className="text-zinc-400 font-mono-tech text-xs mt-1 mb-6">
              Combat progress will end and you will return safely to the operational theaters menu.
            </p>

            <div className="w-full grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  sound.playUIClick();
                  setShowLeaveConfirm(false);
                }}
                className="py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-teko text-xl tracking-wider uppercase font-bold border border-zinc-700 cursor-pointer"
              >
                NO, STAY
              </button>

              <button
                onClick={() => {
                  sound.playUIClick();
                  setShowLeaveConfirm(false);
                  if (onLeaveGame) onLeaveGame();
                }}
                className="py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-teko text-xl tracking-wider uppercase font-bold shadow-lg shadow-red-600/40 cursor-pointer"
              >
                YES, LEAVE
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
