import React from 'react';
import {
  AccentColor,
  UserProfile,
  ACCENT_COLORS,
} from '../types/settings';
import {
  X,
  User,
  Palette,
  Pencil,
  RotateCcw,
  Sun,
  Moon,
  Check,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: 'dark' | 'light';
  onThemeChange: (theme: 'dark' | 'light') => void;
  accent: AccentColor;
  onAccentChange: (accent: AccentColor) => void;
  profile: UserProfile;
  onProfileChange: (profile: UserProfile) => void;
  onOpenEditSchedule: () => void;
  onOpenResetWeek: () => void;
}

const AVATAR_OPTIONS = ['🏋️', '⚡', '🦁', '🥊', '🦍', '🎯', '🔥', '🏆'];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  theme,
  onThemeChange,
  accent,
  onAccentChange,
  profile,
  onProfileChange,
  onOpenEditSchedule,
  onOpenResetWeek,
}) => {
  if (!isOpen) return null;

  const isDark = theme === 'dark';

  const handleNameChange = (name: string) => {
    onProfileChange({ ...profile, name });
  };

  const handleAvatarSelect = (avatar: string) => {
    onProfileChange({ ...profile, avatar });
  };

  const handleGoalSelect = (goal: string) => {
    onProfileChange({ ...profile, goal });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />
      <div
        className={`relative w-full max-w-md max-h-[88vh] overflow-y-auto rounded-3xl p-5 shadow-2xl z-10 transition-colors duration-200 border ${
          isDark
            ? 'bg-[#16171d] border-zinc-800 text-zinc-100'
            : 'bg-white border-zinc-200 text-zinc-800'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-zinc-700/30 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center text-sm font-bold">
              ⚙️
            </div>
            <h2 className="text-base font-extrabold tracking-tight">
              الإعدادات
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-full transition ${
              isDark
                ? 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                : 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content sections */}
        <div className="space-y-4">
          {/* 1. 👤 Profile */}
          <section
            className={`rounded-2xl p-4 border transition-colors ${
              isDark ? 'bg-[#121318] border-zinc-800/80' : 'bg-zinc-50/80 border-zinc-200/90'
            }`}
          >
            <div className="flex items-center gap-2 mb-3">
              <User className="w-4 h-4 text-emerald-500" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                الملف الشخصي
              </h3>
            </div>

            {/* Avatar & Name row */}
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-2xl bg-zinc-800/80 border border-zinc-700/60 flex items-center justify-center text-2xl shrink-0 shadow-inner">
                {profile.avatar || '🏋️'}
              </div>

              <div className="flex-1">
                <label className="block text-[11px] font-semibold text-zinc-400 mb-1">
                  الاسم / Nickname
                </label>
                <input
                  type="text"
                  value={profile.name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  placeholder="Champion"
                  className={`w-full rounded-xl px-3 py-1.5 text-xs font-bold outline-none transition border ${
                    isDark
                      ? 'bg-zinc-900 border-zinc-700 text-white focus:border-emerald-500'
                      : 'bg-white border-zinc-300 text-zinc-900 focus:border-emerald-500'
                  }`}
                />
              </div>
            </div>

            {/* Avatar picker */}
            <div className="mb-3">
              <label className="block text-[11px] font-semibold text-zinc-400 mb-1.5">
                الصورة الرمزية / Avatar
              </label>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {AVATAR_OPTIONS.map((av) => (
                  <button
                    key={av}
                    type="button"
                    onClick={() => handleAvatarSelect(av)}
                    className={`w-9 h-9 rounded-xl flex items-center justify-center text-base shrink-0 border transition-all active:scale-95 ${
                      profile.avatar === av
                        ? 'bg-emerald-500/20 border-emerald-500 shadow-sm scale-105'
                        : isDark
                        ? 'bg-zinc-900 border-zinc-800 hover:border-zinc-700'
                        : 'bg-white border-zinc-200 hover:border-zinc-300'
                    }`}
                  >
                    {av}
                  </button>
                ))}
              </div>
            </div>

            {/* Goal selector */}
            <div>
              <label className="block text-[11px] font-semibold text-zinc-400 mb-1.5">
                الهدف الرياضي
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { id: 'Muscle Gain', label: 'بناء عضلات (Muscle Gain)' },
                  { id: 'Strength', label: 'زيادة القوة (Strength)' },
                  { id: 'Fitness', label: 'لياقة عامة (Fitness)' },
                  { id: 'Custom', label: 'مخصص (Custom)' },
                ].map((g) => (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => handleGoalSelect(g.id)}
                    className={`px-2.5 py-1.5 rounded-xl text-[11px] font-semibold border text-center transition-all truncate ${
                      profile.goal === g.id
                        ? 'bg-emerald-500 text-black border-emerald-400 font-bold'
                        : isDark
                        ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                        : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                    }`}
                  >
                    {g.label}
                  </button>
                ))}
              </div>
            </div>
          </section>

          {/* 2. 🎨 Appearance */}
          <section
            className={`rounded-2xl p-4 border transition-colors ${
              isDark ? 'bg-[#121318] border-zinc-800/80' : 'bg-zinc-50/80 border-zinc-200/90'
            }`}
          >
            <div className="flex items-center gap-2 mb-3">
              <Palette className="w-4 h-4 text-emerald-500" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                المظهر
              </h3>
            </div>

            {/* Light / Dark Mode */}
            <div className="grid grid-cols-2 gap-2 mb-3.5">
              <button
                type="button"
                onClick={() => onThemeChange('light')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                  theme === 'light'
                    ? 'bg-amber-500 text-black border-amber-400 shadow-sm'
                    : isDark
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800'
                    : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                }`}
              >
                <Sun className="w-3.5 h-3.5" />
                <span>☀️ نهاري (Light)</span>
              </button>

              <button
                type="button"
                onClick={() => onThemeChange('dark')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                  theme === 'dark'
                    ? 'bg-zinc-800 text-white border-zinc-600 shadow-sm'
                    : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                }`}
              >
                <Moon className="w-3.5 h-3.5" />
                <span>🌙 ليلي (Dark)</span>
              </button>
            </div>

            {/* Accent Color Palette */}
            <div>
              <label className="block text-[11px] font-semibold text-zinc-400 mb-2">
                اللون الأساسي (Accent Color)
              </label>
              <div className="flex items-center justify-between gap-2">
                {ACCENT_COLORS.map((col) => (
                  <button
                    key={col.id}
                    type="button"
                    onClick={() => onAccentChange(col.id)}
                    className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all active:scale-95 ${
                      accent === col.id
                        ? 'ring-2 ring-offset-2 ring-emerald-500 scale-105'
                        : 'opacity-70 hover:opacity-100'
                    }`}
                    style={{
                      backgroundColor: col.primary,
                    }}
                    title={col.name}
                  >
                    {accent === col.id && (
                      <Check className="w-4 h-4 stroke-[3] text-white" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          </section>

          {/* 3. ✏️ Edit Schedule & 🔄 Reset Week actions */}
          <div className="space-y-2 pt-1">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenEditSchedule();
              }}
              className={`w-full py-2.5 px-4 rounded-2xl border text-xs font-bold transition flex items-center justify-between active:scale-98 ${
                isDark
                  ? 'bg-zinc-900 border-zinc-800 text-zinc-200 hover:bg-zinc-800'
                  : 'bg-zinc-100 border-zinc-200 text-zinc-800 hover:bg-zinc-200'
              }`}
            >
              <div className="flex items-center gap-2">
                <Pencil className="w-3.5 h-3.5 text-emerald-500" />
                <span>تعديل الخانات والترتيب</span>
              </div>
              <span className="text-zinc-500 text-[10px]">✏️</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenResetWeek();
              }}
              className={`w-full py-2.5 px-4 rounded-2xl border text-xs font-bold transition flex items-center justify-between active:scale-98 ${
                isDark
                  ? 'bg-zinc-900 border-zinc-800 text-zinc-200 hover:bg-zinc-800'
                  : 'bg-zinc-100 border-zinc-200 text-zinc-800 hover:bg-zinc-200'
              }`}
            >
              <div className="flex items-center gap-2">
                <RotateCcw className="w-3.5 h-3.5 text-amber-500" />
                <span>Reset Week (إعادة الأسبوع)</span>
              </div>
              <span className="text-zinc-500 text-[10px]">🔄</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
