import React, { useState } from 'react';
import {
  Settings,
  Lock,
  Unlock,
  Key,
  ShieldCheck,
  RotateCcw,
  Eye,
  EyeOff,
  Check,
  AlertTriangle,
  Mic,
  Camera,
  Layers,
  Sparkles,
  X,
  Wifi,
  WifiOff,
  Download,
  Package,
  Loader2,
  Copy
} from 'lucide-react';
import { AppSettings } from '../types';
import { hashPassword, saveSettings } from '../utils/storage';
import { downloadApkBlob, triggerDirectBrowserDownload, getFullApkDownloadUrl } from '../utils/downloadHelper';


interface SettingsModalProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
}) => {
  // Vault lock state
  const hasPassword = Boolean(settings.vaultPasswordHash);
  const [isUnlocked, setIsUnlocked] = useState(!hasPassword || !settings.isVaultLocked);
  const [enteredPassword, setEnteredPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [vaultError, setVaultError] = useState<string | null>(null);
  const [vaultSuccess, setVaultSuccess] = useState<string | null>(null);

  // Form fields
  const [formData, setFormData] = useState<AppSettings>({ ...settings });
  const [showKeys, setShowKeys] = useState(false);

  // Permission statuses
  const [micStatus, setMicStatus] = useState<string>('Unknown');
  const [camStatus, setCamStatus] = useState<string>('Unknown');

  // APK download state
  const [isDownloadingApk, setIsDownloadingApk] = useState(false);
  const [apkDownloadSuccess, setApkDownloadSuccess] = useState(false);
  const [apkDownloadError, setApkDownloadError] = useState<string | null>(null);
  const [copiedApkUrl, setCopiedApkUrl] = useState(false);

  const handleDownloadApkInSettings = async () => {
    setIsDownloadingApk(true);
    setApkDownloadError(null);
    try {
      const res = await downloadApkBlob();
      if (!res.success) {
        throw new Error(res.error || 'Download failed');
      }
      setIsDownloadingApk(false);
      setApkDownloadSuccess(true);
      setTimeout(() => setApkDownloadSuccess(false), 5000);
    } catch (e: any) {
      setIsDownloadingApk(false);
      setApkDownloadError(e?.message || 'Download error. Please use direct download link.');
    }
  };

  const handleCopyLinkInSettings = () => {
    const url = getFullApkDownloadUrl();
    navigator.clipboard.writeText(url).then(() => {
      setCopiedApkUrl(true);
      setTimeout(() => setCopiedApkUrl(false), 3000);
    });
  };


  // Verify entered password to unlock vault
  const handleUnlockVault = async () => {
    setVaultError(null);
    if (!enteredPassword) {
      setVaultError('Please enter your vault password.');
      return;
    }

    const hashed = await hashPassword(enteredPassword);
    if (hashed === settings.vaultPasswordHash) {
      setIsUnlocked(true);
      setVaultSuccess('API Vault unlocked successfully!');
      setTimeout(() => setVaultSuccess(null), 2500);
    } else {
      setVaultError('Incorrect password! Vault remains securely locked.');
    }
  };

  // Emergency Reset Vault (if password forgotten or requested)
  // "bina password ke vo bdle nahi to pura api.+ Password reset ho"
  const handleResetVault = () => {
    if (
      window.confirm(
        'Warning: Performing a Vault Reset will permanently wipe your saved API keys and password, restoring factory defaults. Do you wish to proceed?'
      )
    ) {
      const resetSettings: AppSettings = {
        ...formData,
        geminiApiKey: '',
        groqApiKey: '',
        vaultPasswordHash: '',
        isVaultLocked: false,
      };
      setFormData(resetSettings);
      onUpdateSettings(resetSettings);
      saveSettings(resetSettings);
      setIsUnlocked(true);
      setVaultSuccess('Vault has been reset to defaults.');
      setTimeout(() => setVaultSuccess(null), 3000);
    }
  };

  // Save Settings with optional new password
  const handleSave = async () => {
    setVaultError(null);

    let updatedHash = settings.vaultPasswordHash;

    if (newPassword) {
      if (newPassword !== confirmPassword) {
        setVaultError('New password and confirmation do not match.');
        return;
      }
      if (newPassword.length < 4) {
        setVaultError('Password must be at least 4 characters.');
        return;
      }
      updatedHash = await hashPassword(newPassword);
    }

    const finalSettings: AppSettings = {
      ...formData,
      vaultPasswordHash: updatedHash,
      isVaultLocked: Boolean(updatedHash), // Lock on save if password set
    };

    onUpdateSettings(finalSettings);
    saveSettings(finalSettings);
    setVaultSuccess('Settings saved successfully!');
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  // Request browser permissions
  const requestMicPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
      setMicStatus('Granted');
    } catch {
      setMicStatus('Denied');
    }
  };

  const requestCamPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      stream.getTracks().forEach((t) => t.stop());
      setCamStatus('Granted');
    } catch {
      setCamStatus('Denied');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-950 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60 sticky top-0 z-10 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-950 text-indigo-400 border border-indigo-500/30">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">App Settings & AI Configuration</h2>
              <p className="text-xs text-slate-400">Manage Gemini/Groq APIs, Hey Julli, and permissions</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {vaultError && (
            <div className="p-3 bg-rose-950/60 border border-rose-500/40 rounded-xl text-rose-200 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{vaultError}</span>
            </div>
          )}

          {vaultSuccess && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-200 text-xs flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{vaultSuccess}</span>
            </div>
          )}

          {/* OFFLINE / ONLINE OPERATIONAL MODE */}
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                {formData.offlineMode ? (
                  <WifiOff className="w-4 h-4 text-amber-400" />
                ) : (
                  <Wifi className="w-4 h-4 text-emerald-400" />
                )}
                App Operational Mode (Offline vs Online)
              </span>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                formData.offlineMode
                  ? 'bg-amber-950 text-amber-300 border border-amber-500/40'
                  : 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
              }`}>
                {formData.offlineMode ? 'OFFLINE MODE ACTIVE' : 'ONLINE CLOUD ACTIVE'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, offlineMode: false })}
                className={`p-3 rounded-xl border text-left transition-all ${
                  !formData.offlineMode
                    ? 'bg-emerald-950/50 border-emerald-500 shadow-md shadow-emerald-900/30 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-xs text-emerald-300">
                  <Wifi className="w-3.5 h-3.5" />
                  <span>Online Mode (All APIs Active)</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Enables Pollinations AI, Gemini, Groq, voice assistant intelligence, and cloud features below.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setFormData({ ...formData, offlineMode: true })}
                className={`p-3 rounded-xl border text-left transition-all ${
                  formData.offlineMode
                    ? 'bg-amber-950/50 border-amber-500 shadow-md shadow-amber-900/30 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-xs text-amber-300">
                  <WifiOff className="w-3.5 h-3.5" />
                  <span>Offline Mode (Zero Data)</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Local Vector Logo Engine, Offline Basic Math (+ - × ÷), Local Memory Notebook, and Cache.
                </p>
              </button>
            </div>
          </div>

          {/* 1. PASSWORD-PROTECTED API VAULT */}
          <div className="p-5 bg-gradient-to-r from-slate-900 to-indigo-950/40 border border-indigo-500/30 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {isUnlocked ? (
                  <Unlock className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Lock className="w-4 h-4 text-amber-400" />
                )}
                <h3 className="font-bold text-sm text-white">Password-Protected API Vault</h3>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-900 text-slate-300 border border-slate-700">
                {hasPassword ? (isUnlocked ? 'Unlocked' : 'Encrypted & Locked') : 'No Password Set'}
              </span>
            </div>

            {hasPassword && !isUnlocked ? (
              /* Locked Vault Prompt */
              <div className="space-y-3 p-4 bg-slate-950/80 rounded-xl border border-slate-800">
                <p className="text-xs text-slate-300">
                  Your Pollinations, Gemini & Groq API configurations are encrypted with a security password. Enter password to view or modify.
                </p>
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={enteredPassword}
                    onChange={(e) => setEnteredPassword(e.target.value)}
                    placeholder="Enter Vault Password / PIN..."
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    onClick={handleUnlockVault}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-colors"
                  >
                    Unlock
                  </button>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px]">
                  <span className="text-slate-500">Forgot password?</span>
                  <button
                    onClick={handleResetVault}
                    className="text-rose-400 hover:text-rose-300 underline font-medium"
                  >
                    Emergency Reset Vault (Wipes Keys)
                  </button>
                </div>
              </div>
            ) : (
              /* Unlocked Vault Controls */
              <div className="space-y-4">
                {/* Active Provider Selector */}
                <div className="flex items-center justify-between bg-slate-950 p-2 rounded-xl border border-slate-800 text-xs">
                  <span className="font-semibold text-slate-300">Active AI Provider:</span>
                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, activeProvider: 'pollinations' })}
                      className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                        formData.activeProvider === 'pollinations' ? 'bg-pink-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      🌸 Pollinations AI
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, activeProvider: 'gemini' })}
                      className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                        formData.activeProvider === 'gemini' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Google Gemini
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, activeProvider: 'groq' })}
                      className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                        formData.activeProvider === 'groq' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Groq AI
                    </button>
                  </div>
                </div>

                {/* Pollinations AI Config */}
                <div className="space-y-2.5 p-3.5 bg-slate-950/80 rounded-xl border border-pink-500/30">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-pink-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                      Pollinations AI Image Engine (Sequential Fallback)
                    </h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-pink-950 text-pink-300 border border-pink-500/30">
                      Endpoint 1 → Endpoint 2
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="text-[11px] text-slate-400 mb-1 block">1. Primary Endpoint</label>
                      <input
                        type="text"
                        value={formData.pollinationsEndpoint1}
                        onChange={(e) => setFormData({ ...formData, pollinationsEndpoint1: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono text-[11px]"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-slate-400 mb-1 block">2. Fallback Endpoint</label>
                      <input
                        type="text"
                        value={formData.pollinationsEndpoint2}
                        onChange={(e) => setFormData({ ...formData, pollinationsEndpoint2: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono text-[11px]"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="text-[11px] text-slate-400 mb-1 block">Pollinations API Key</label>
                      <input
                        type={showKeys ? 'text' : 'password'}
                        value={formData.pollinationsApiKey}
                        onChange={(e) => setFormData({ ...formData, pollinationsApiKey: e.target.value })}
                        placeholder="sk_..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono text-xs"
                      />
                    </div>
                  </div>
                </div>

                {/* Gemini Config */}
                <div className="space-y-2 p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                  <h4 className="text-xs font-bold text-indigo-300 flex items-center justify-between">
                    <span>Google Gemini Configuration</span>
                    <button
                      type="button"
                      onClick={() => setShowKeys(!showKeys)}
                      className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1"
                    >
                      {showKeys ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      {showKeys ? 'Hide Keys' : 'Show Keys'}
                    </button>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="text-[11px] text-slate-400 mb-1 block">Gemini Image/Logo Model</label>
                      <input
                        type="text"
                        value={formData.geminiModel}
                        onChange={(e) => setFormData({ ...formData, geminiModel: e.target.value })}
                        placeholder="gemini-3-pro-image-preview"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-slate-400 mb-1 block">Gemini API Key (Optional Override)</label>
                      <input
                        type={showKeys ? 'text' : 'password'}
                        value={formData.geminiApiKey}
                        onChange={(e) => setFormData({ ...formData, geminiApiKey: e.target.value })}
                        placeholder="Defaults to runtime key..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Groq Config */}
                <div className="space-y-2 p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
                  <h4 className="text-xs font-bold text-purple-300">Groq AI Configuration</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                    <div>
                      <label className="text-[11px] text-slate-400 mb-1 block">Groq Model</label>
                      <input
                        type="text"
                        value={formData.groqModel}
                        onChange={(e) => setFormData({ ...formData, groqModel: e.target.value })}
                        placeholder="llama-3.3-70b-versatile"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-slate-400 mb-1 block">Base URL</label>
                      <input
                        type="text"
                        value={formData.groqBaseUrl}
                        onChange={(e) => setFormData({ ...formData, groqBaseUrl: e.target.value })}
                        placeholder="https://api.groq.com/openai/v1"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-slate-400 mb-1 block">Groq API Key</label>
                      <input
                        type={showKeys ? 'text' : 'password'}
                        value={formData.groqApiKey}
                        onChange={(e) => setFormData({ ...formData, groqApiKey: e.target.value })}
                        placeholder="gsk_..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Set/Change Password */}
                <div className="p-3 bg-slate-950/90 rounded-xl border border-purple-500/20 text-xs space-y-2">
                  <h4 className="font-bold text-slate-200 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-indigo-400" />
                    {hasPassword ? 'Change Security Password' : 'Create Security Password for API Keys'}
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Once saved, these API credentials can only be accessed or modified by entering this password.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="New Security Password..."
                      className="bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-xs"
                    />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Confirm Password..."
                      className="bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-xs"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 2. HEY JULLI DIGITAL ASSISTANT CONTROLS */}
          <div className="p-5 bg-slate-900/50 border border-slate-800 rounded-2xl space-y-3">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-pink-400" />
              Hey Julli Assistant Controls
            </h3>

            <div className="space-y-3 text-xs">
              <label className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-white block">Launch Digital AI Assistant (Julli)</span>
                  <span className="text-[11px] text-slate-400">Enables floating animated mascot companion</span>
                </div>
                <input
                  type="checkbox"
                  checked={formData.julliEnabled}
                  onChange={(e) => setFormData({ ...formData, julliEnabled: e.target.checked })}
                  className="w-4 h-4 accent-indigo-600 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-white block">"Hey Julli" Wake-Word Engine</span>
                  <span className="text-[11px] text-slate-400">Listens continuously in background to wake immediately</span>
                </div>
                <input
                  type="checkbox"
                  checked={formData.julliWakeWordEnabled}
                  onChange={(e) => setFormData({ ...formData, julliWakeWordEnabled: e.target.checked })}
                  className="w-4 h-4 accent-indigo-600 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-white block">Voice Feedback (TTS)</span>
                  <span className="text-[11px] text-slate-400">Julli speaks responses aloud in natural conversational tone</span>
                </div>
                <input
                  type="checkbox"
                  checked={formData.julliVoiceFeedback}
                  onChange={(e) => setFormData({ ...formData, julliVoiceFeedback: e.target.checked })}
                  className="w-4 h-4 accent-indigo-600 rounded"
                />
              </label>
            </div>
          </div>

          {/* 3. DEVICE PERMISSIONS HUB */}
          <div className="p-5 bg-slate-900/50 border border-slate-800 rounded-2xl space-y-3">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Device Permissions
            </h3>
            <p className="text-xs text-slate-400">
              Grant permissions so Julli can listen to voice commands and take camera snapshots when asked.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Mic className="w-4 h-4 text-pink-400" />
                  <div>
                    <span className="font-bold text-white block">Microphone</span>
                    <span className="text-[10px] text-slate-400">Status: {micStatus}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={requestMicPermission}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-[11px] font-semibold"
                >
                  Request Mic
                </button>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Camera className="w-4 h-4 text-indigo-400" />
                  <div>
                    <span className="font-bold text-white block">Camera</span>
                    <span className="text-[10px] text-slate-400">Status: {camStatus}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={requestCamPermission}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-[11px] font-semibold"
                >
                  Request Cam
                </button>
              </div>
            </div>
          </div>

          {/* 4. REAL ANDROID APK PACKAGE DOWNLOAD LINK */}
          <div className="p-5 bg-gradient-to-r from-purple-950/60 via-slate-900 to-indigo-950/60 border border-purple-500/40 rounded-2xl flex flex-col gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-purple-900/60 border border-purple-400/40 text-purple-300 shrink-0">
                <Package className="w-7 h-7" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-extrabold text-white text-sm">Download Android APK (BrandMorph & Julli)</h4>
                <p className="text-xs text-purple-300 mt-0.5">Verified Binary APK • Exact Size: 7.09 MB • Version 1.0.0</p>
                <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400 font-mono">
                  <span>File: BrandMorph_Julli_v1.0.apk</span>
                  <span>•</span>
                  <span className="text-emerald-400">v1/v2/v3 Signed</span>
                </div>
              </div>
            </div>

            {apkDownloadError && (
              <div className="p-2 bg-rose-950/80 border border-rose-500/40 rounded-xl text-rose-300 text-xs">
                {apkDownloadError}
              </div>
            )}

            {apkDownloadSuccess && (
              <div className="p-2 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-400" />
                BrandMorph_Julli_v1.0.apk (7.09 MB) download shuru ho gaya hai!
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleDownloadApkInSettings}
                disabled={isDownloadingApk}
                className="flex-1 py-3 px-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-xl shadow-purple-600/30 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] disabled:opacity-50 cursor-pointer"
              >
                {isDownloadingApk ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Downloading 7.09 MB APK...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    Download APK (7.09 MB)
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => triggerDirectBrowserDownload()}
                className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-purple-200 rounded-xl text-xs font-semibold border border-purple-500/30 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                title="Direct Browser Download"
              >
                Direct Browser Tab
              </button>

              <button
                type="button"
                onClick={handleCopyLinkInSettings}
                className="py-3 px-3 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 flex items-center justify-center gap-1 transition-colors cursor-pointer"
                title="Copy full download URL"
              >
                {copiedApkUrl ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-300" />}
                {copiedApkUrl ? 'Copied!' : 'Copy URL'}
              </button>
            </div>
          </div>
        </div>


        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-end gap-3 sticky bottom-0 backdrop-blur-md">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs font-semibold"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" /> Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};
