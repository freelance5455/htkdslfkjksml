import React, { useState } from 'react';
import {
  ArrowLeft,
  Key,
  Sun,
  Moon,
  Info,
  CheckCircle2,
  Eye,
  EyeOff,
  ExternalLink,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSaveSettings: (newSettings: AppSettings) => void;
  hasEnvKey: boolean;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  hasEnvKey,
}) => {
  const [currentView, setCurrentView] = useState<'menu' | 'api' | 'appearance' | 'about'>('menu');
  const [inputKey, setInputKey] = useState<string>(settings.geminiApiKey || '');
  const [showKey, setShowKey] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSaveKey = () => {
    onSaveSettings({
      ...settings,
      geminiApiKey: inputKey.trim(),
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleThemeChange = (newTheme: 'dark' | 'light') => {
    onSaveSettings({
      ...settings,
      theme: newTheme,
    });
  };

  const isConnected = !!settings.geminiApiKey || hasEnvKey;

  // Masked key display helper
  const getMaskedKey = (key: string) => {
    if (!key) return '';
    if (key.length <= 8) return '••••••••';
    return `${key.slice(0, 6)}••••••••${key.slice(-4)}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#070913] text-white select-none overflow-y-auto animate-fade-in">
      {/* Top Header */}
      <div className="sticky top-0 z-30 flex items-center px-4 py-4 bg-[#070913]/95 backdrop-blur-md border-b border-white/5">
        <button
          onClick={() => {
            if (currentView !== 'menu') {
              setCurrentView('menu');
            } else {
              onClose();
            }
          }}
          className="p-2 rounded-full glass-panel text-slate-300 hover:text-white mr-3 active:scale-95 transition"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="text-lg font-bold text-white tracking-wide">
          {currentView === 'menu' && 'Settings'}
          {currentView === 'api' && 'API Settings'}
          {currentView === 'appearance' && 'Appearance'}
          {currentView === 'about' && 'About'}
        </h2>
      </div>

      <div className="max-w-md w-full mx-auto px-5 py-6">
        {/* ============================================================== */}
        {/* VIEW: MAIN SETTINGS MENU (Screen 5 from Screenshot)           */}
        {/* ============================================================== */}
        {currentView === 'menu' && (
          <div className="space-y-4">
            {/* 1. API Settings menu item */}
            <button
              onClick={() => setCurrentView('api')}
              className="w-full p-4 rounded-2xl glass-panel border border-white/5 hover:border-purple-500/40 flex items-center justify-between transition text-left active:scale-[0.99]"
            >
              <div className="flex items-center space-x-3.5">
                <div className="p-2.5 rounded-xl bg-purple-600/20 text-purple-300">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">API Settings</h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {isConnected ? 'API Key configured' : 'Add your Gemini API key to enable AI'}
                  </p>
                </div>
              </div>
              <span className="text-slate-500 text-lg">›</span>
            </button>

            {/* 2. Appearance menu item */}
            <button
              onClick={() => setCurrentView('appearance')}
              className="w-full p-4 rounded-2xl glass-panel border border-white/5 hover:border-purple-500/40 flex items-center justify-between transition text-left active:scale-[0.99]"
            >
              <div className="flex items-center space-x-3.5">
                <div className="p-2.5 rounded-xl bg-cyan-600/20 text-cyan-300">
                  <Sun className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Appearance</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Choose your preferred theme</p>
                </div>
              </div>
              <span className="text-slate-500 text-lg">›</span>
            </button>

            {/* 3. About menu item */}
            <button
              onClick={() => setCurrentView('about')}
              className="w-full p-4 rounded-2xl glass-panel border border-white/5 hover:border-purple-500/40 flex items-center justify-between transition text-left active:scale-[0.99]"
            >
              <div className="flex items-center space-x-3.5">
                <div className="p-2.5 rounded-xl bg-pink-600/20 text-pink-300">
                  <Info className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">About</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Developer info and app details</p>
                </div>
              </div>
              <span className="text-slate-500 text-lg">›</span>
            </button>

            {/* Theme Toggle section in main menu (Screen 5 bottom) */}
            <div className="pt-4">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5 px-1">
                Theme
              </h4>
              <div className="grid grid-cols-2 gap-3 p-1.5 rounded-2xl bg-black/40 border border-white/5">
                <button
                  onClick={() => handleThemeChange('light')}
                  className={`flex items-center justify-center space-x-2 py-3 rounded-xl text-xs font-semibold transition active:scale-95 ${
                    settings.theme === 'light'
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Sun className="w-4 h-4" />
                  <span>Light</span>
                </button>
                <button
                  onClick={() => handleThemeChange('dark')}
                  className={`flex items-center justify-center space-x-2 py-3 rounded-xl text-xs font-semibold transition active:scale-95 ${
                    settings.theme === 'dark'
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Moon className="w-4 h-4" />
                  <span>Dark</span>
                </button>
              </div>
            </div>

            {/* Version footer */}
            <div className="text-center text-xs text-slate-600 pt-8">
              AI Partner v1.0
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW: API SETTINGS (Screen 6 from Screenshot)                 */}
        {/* ============================================================== */}
        {currentView === 'api' && (
          <div className="space-y-5">
            {/* Input Card */}
            <div className="p-5 rounded-2xl glass-panel border border-white/10 space-y-4">
              <div>
                <h3 className="text-base font-bold text-white">Gemini API Key</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Enter your Google Gemini API key to enable real-time voice, vision, and palm
                  features.
                </p>
              </div>

              {/* Input field with show/hide toggle */}
              <div className="relative">
                <input
                  type={showKey ? 'text' : 'password'}
                  value={inputKey}
                  onChange={(e) => setInputKey(e.target.value)}
                  placeholder="Enter API key..."
                  className="w-full py-3.5 pl-4 pr-12 rounded-xl bg-black/60 border border-purple-500/30 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-purple-400 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowKey(!showKey)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition"
                >
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Masked status if saved */}
              {settings.geminiApiKey && !showKey && (
                <div className="text-[11px] text-purple-300 font-mono">
                  Saved: {getMaskedKey(settings.geminiApiKey)}
                </div>
              )}

              {/* Save Button */}
              <button
                onClick={handleSaveKey}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs tracking-wider transition shadow-lg shadow-purple-500/25 active:scale-98"
              >
                Save
              </button>

              {saveSuccess && (
                <p className="text-xs text-emerald-400 text-center font-medium animate-fade-in">
                  ✓ API Key saved securely!
                </p>
              )}
            </div>

            {/* Connection Status Card (Screen 6: "API Connected") */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 flex items-center space-x-3.5">
              <div
                className={`w-3 h-3 rounded-full ${
                  isConnected
                    ? 'bg-emerald-400 shadow-[0_0_10px_#34d399] animate-pulse'
                    : 'bg-amber-400'
                }`}
              />
              <div>
                <h4 className="text-xs font-bold text-white">
                  {isConnected ? 'API Connected' : 'No API Key Configured'}
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {isConnected
                    ? 'Your AI assistant is ready!'
                    : 'Enter your API key above to start talking.'}
                </p>
              </div>
            </div>

            {/* About Card at bottom of API Settings (Screen 6) */}
            <div className="p-4 rounded-2xl glass-panel border border-white/5 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-semibold text-slate-300">About</h4>
                <p className="text-xs font-bold text-purple-300 mt-0.5">
                  Developer: Shyam Kadam
                </p>
              </div>
              <span className="text-slate-500 text-lg">›</span>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW: APPEARANCE                                               */}
        {/* ============================================================== */}
        {currentView === 'appearance' && (
          <div className="space-y-4">
            <div className="p-5 rounded-2xl glass-panel border border-white/10 space-y-3">
              <h3 className="text-sm font-bold text-white">Theme Selection</h3>
              <p className="text-xs text-slate-400">
                Switch between futuristic Neon Dark mode and crisp Light mode.
              </p>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => handleThemeChange('dark')}
                  className={`p-4 rounded-2xl border flex flex-col items-center space-y-2 transition ${
                    settings.theme === 'dark'
                      ? 'border-purple-500 bg-purple-950/40 text-white'
                      : 'border-white/10 bg-black/40 text-slate-400'
                  }`}
                >
                  <Moon className="w-6 h-6 text-purple-400" />
                  <span className="text-xs font-semibold">Neon Dark</span>
                </button>

                <button
                  onClick={() => handleThemeChange('light')}
                  className={`p-4 rounded-2xl border flex flex-col items-center space-y-2 transition ${
                    settings.theme === 'light'
                      ? 'border-purple-500 bg-purple-950/40 text-white'
                      : 'border-white/10 bg-black/40 text-slate-400'
                  }`}
                >
                  <Sun className="w-6 h-6 text-yellow-400" />
                  <span className="text-xs font-semibold">Clean Light</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW: ABOUT                                                    */}
        {/* ============================================================== */}
        {currentView === 'about' && (
          <div className="space-y-4">
            <div className="p-5 rounded-2xl glass-panel border border-white/10 space-y-3">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                <h3 className="text-base font-bold text-white">AI.P</h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                A premium next-generation AI companion specializing in traditional astrology,
                palm-reading (जन्म रेखा) interpretations, relationship harmony, and future guidance.
              </p>

              <div className="pt-2 border-t border-white/10 space-y-2 text-xs">
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Developer</span>
                  <span className="font-semibold text-purple-300">Shyam Kadam</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Live Vision Engine</span>
                  <span className="font-semibold text-cyan-300">Gemini Live API</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Audio Format</span>
                  <span className="font-semibold text-slate-200">PCM16 (16kHz / 24kHz)</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Version</span>
                  <span className="font-semibold text-slate-200">1.0.0</span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 text-[11px] text-slate-400 leading-relaxed">
              Note: Palm reading is for entertainment, positive inspiration, and mindfulness. It is
              not a scientific or future prediction tool.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
