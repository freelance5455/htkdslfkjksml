import React from 'react';
import {
  X,
  Volume2,
  Bell,
  Clock,
  ShieldCheck,
  Play,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { PrayerSettings, AdhanVoice, AlarmTone } from '../types/prayer';
import { NotificationService } from '../services/notificationService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: PrayerSettings;
  onUpdateSettings: (newSettings: Partial<PrayerSettings>) => void;
  onTestAdhan: (voice?: AdhanVoice) => void;
  onTestAlarm: (tone?: AlarmTone) => void;
  onOpenBatteryGuide: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onTestAdhan,
  onTestAlarm,
  onOpenBatteryGuide,
}) => {
  if (!isOpen) return null;

  const [notificationState, setNotificationState] = React.useState<NotificationPermission>(
    NotificationService.getPermissionState()
  );

  const handleRequestPermission = async () => {
    const res = await NotificationService.requestPermission();
    setNotificationState(res);
  };

  const adhanVoices: { id: AdhanVoice; label: string; desc: string }[] = [
    { id: 'makkah', label: 'Makkah Al-Mukarramah', desc: 'Resonant Maqam Bayati Takbeer from the Grand Mosque' },
    { id: 'madinah', label: 'Al-Madinah Al-Munawwarah', desc: 'Serene & gentle melodic tone from Prophet’s Mosque' },
    { id: 'alaqsa', label: 'Al-Aqsa (Jerusalem)', desc: 'Reverent acoustic cadence inspired by Al-Aqsa' },
    { id: 'fajr_special', label: 'Fajr Special (الصلاة خير من النوم)', desc: 'With ascending "Prayer is better than sleep" cadence' },
    { id: 'melodic_bayati', label: 'Traditional Bayati Maqam', desc: 'Authentic microtonal harmonic intervals' },
    { id: 'soft_serene', label: 'Soft Serene Chants', desc: 'Gentle ambient morning tone' },
  ];

  const alarmTones: { id: AlarmTone; label: string; desc: string }[] = [
    { id: 'sacred_bell', label: 'Sacred Prayer Bell', desc: 'Deep brass acoustic singing bell with long decay' },
    { id: 'crystal_chime', label: 'Crystal Harmonic Chime', desc: 'Radiant 3-tone crystalline arpeggio' },
    { id: 'radiant_gong', label: 'Radiant Resonance Gong', desc: 'Rich warm meditation gong' },
    { id: 'gentle_acoustic', label: 'Gentle Acoustic Marimba', desc: 'Peaceful harmonic chord sequence' },
    { id: 'dawn_alarm', label: 'Dawn Rising Pulse', desc: 'Warming rising tone pulse' },
    { id: 'vibrant_chime', label: 'Vibrant Alert Tone', desc: 'Clear vibrant notification sequence' },
  ];

  const delayOptions = [0, 5, 10, 15, 20];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-3xl border border-emerald-900/60 bg-slate-900 shadow-2xl text-slate-100 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-950/70">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">Audio & Reminder Settings</h2>
            <p className="text-xs text-slate-400">Configure Adhan playback, separate Salah alarms, and audio profiles</p>
          </div>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-800 bg-slate-950 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* 1. Salah Reminder Delay Selector (Prompt: 0, 5, 10, 15, or 20 minutes) */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-sm font-semibold text-white flex items-center gap-2">
                  <Bell className="w-4 h-4 text-amber-400" />
                  Salah Alarm Delay (minutes after Adhan)
                </label>
                <p className="text-xs text-slate-400 mt-0.5">
                  After the Adhan plays, when should the separate Salah reminder alarm ring?
                </p>
              </div>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {delayOptions.map(mins => {
                const isSelected = settings.alarmDelayMinutes === mins;
                return (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => onUpdateSettings({ alarmDelayMinutes: mins })}
                    className={`rounded-xl py-2.5 px-3 text-center transition cursor-pointer border ${
                      isSelected
                        ? 'border-amber-500 bg-amber-950/70 text-amber-200 font-bold shadow-sm'
                        : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-sm font-mono">{mins}m</div>
                    <div className="text-[10px] text-slate-400">
                      {mins === 0 ? 'Exact Adhan' : mins === 10 ? 'Default' : `+${mins} min`}
                    </div>
                  </button>
                );
              })}
            </div>
            <div className="text-[11px] text-emerald-400/90 bg-emerald-950/40 border border-emerald-900/60 p-2.5 rounded-xl">
              ✓ Example: When Fajr Adhan is at 04:35 BST, your Salah alarm rings dynamically at{' '}
              <strong className="underline text-emerald-300">
                {minsToSampleTime('04:35', settings.alarmDelayMinutes)}
              </strong>.
            </div>
          </section>

          {/* 2. Time Format (12h vs 24h) */}
          <section className="space-y-2 border-t border-slate-800/80 pt-5">
            <label className="text-sm font-semibold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-400" />
              Time Display Format
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => onUpdateSettings({ timeFormat: '12h' })}
                className={`flex items-center justify-between rounded-xl p-3 border text-xs font-semibold transition cursor-pointer ${
                  settings.timeFormat === '12h'
                    ? 'border-emerald-500 bg-emerald-950/60 text-emerald-300'
                    : 'border-slate-800 bg-slate-950/50 text-slate-300 hover:border-slate-700'
                }`}
              >
                <span>12-Hour (04:35 AM / 03:13 PM)</span>
                {settings.timeFormat === '12h' && <Check className="w-4 h-4 text-emerald-400" />}
              </button>
              <button
                type="button"
                onClick={() => onUpdateSettings({ timeFormat: '24h' })}
                className={`flex items-center justify-between rounded-xl p-3 border text-xs font-semibold transition cursor-pointer ${
                  settings.timeFormat === '24h'
                    ? 'border-emerald-500 bg-emerald-950/60 text-emerald-300'
                    : 'border-slate-800 bg-slate-950/50 text-slate-300 hover:border-slate-700'
                }`}
              >
                <span>24-Hour (04:35 / 15:13)</span>
                {settings.timeFormat === '24h' && <Check className="w-4 h-4 text-emerald-400" />}
              </button>
            </div>
          </section>

          {/* 3. Adhan Voice Selection */}
          <section className="space-y-3 border-t border-slate-800/80 pt-5">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-sm font-semibold text-white flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                  Select Adhan Audio Voice
                </label>
                <p className="text-xs text-slate-400">Choose preferred Adhan recitation style</p>
              </div>
              <button
                type="button"
                onClick={() => onTestAdhan(settings.adhanVoice)}
                className="flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 transition cursor-pointer font-medium"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Test Current</span>
              </button>
            </div>

            <div className="space-y-2">
              {adhanVoices.map(voice => {
                const isSelected = settings.adhanVoice === voice.id;
                return (
                  <div
                    key={voice.id}
                    onClick={() => onUpdateSettings({ adhanVoice: voice.id })}
                    className={`flex items-center justify-between p-3 rounded-xl border transition cursor-pointer ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-950/50 text-white'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold">{voice.label}</div>
                      <div className="text-[11px] text-slate-400">{voice.desc}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          onTestAdhan(voice.id);
                        }}
                        className="p-1.5 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                        title="Preview this sound"
                      >
                        <Play className="w-3 h-3" />
                      </button>
                      {isSelected && <Check className="w-4 h-4 text-emerald-400" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* 4. Salah Alarm Tone Selection */}
          <section className="space-y-3 border-t border-slate-800/80 pt-5">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-sm font-semibold text-white flex items-center gap-2">
                  <Bell className="w-4 h-4 text-amber-400" />
                  Select Salah Alarm Tone
                </label>
                <p className="text-xs text-slate-400">Separate reminder ring sound</p>
              </div>
              <button
                type="button"
                onClick={() => onTestAlarm(settings.alarmTone)}
                className="flex items-center gap-1 text-xs text-amber-400 hover:text-amber-300 transition cursor-pointer font-medium"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Test Current</span>
              </button>
            </div>

            <div className="space-y-2">
              {alarmTones.map(tone => {
                const isSelected = settings.alarmTone === tone.id;
                return (
                  <div
                    key={tone.id}
                    onClick={() => onUpdateSettings({ alarmTone: tone.id })}
                    className={`flex items-center justify-between p-3 rounded-xl border transition cursor-pointer ${
                      isSelected
                        ? 'border-amber-500 bg-amber-950/40 text-white'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold">{tone.label}</div>
                      <div className="text-[11px] text-slate-400">{tone.desc}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          onTestAlarm(tone.id);
                        }}
                        className="p-1.5 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                        title="Preview this tone"
                      >
                        <Play className="w-3 h-3" />
                      </button>
                      {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* 5. Master Volume Slider */}
          <section className="space-y-2 border-t border-slate-800/80 pt-5">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="flex items-center gap-2 text-white">
                <Volume2 className="w-4 h-4 text-emerald-400" />
                Master Alert Volume
              </span>
              <span className="text-emerald-400 font-mono">{settings.volume}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              value={settings.volume}
              onChange={e => onUpdateSettings({ volume: parseInt(e.target.value, 10) })}
              className="w-full accent-emerald-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
            />
          </section>

          {/* 6. Notification Permissions & Battery Optimization Guide */}
          <section className="space-y-3 border-t border-slate-800/80 pt-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Background Permissions
                </div>
                <div className="text-xs text-slate-400">
                  Status: <span className="font-semibold text-emerald-400 uppercase">{notificationState}</span>
                </div>
              </div>
              {notificationState !== 'granted' && (
                <button
                  type="button"
                  onClick={handleRequestPermission}
                  className="rounded-xl bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500 transition cursor-pointer"
                >
                  Enable Notifications
                </button>
              )}
            </div>

            <div className="rounded-2xl border border-amber-900/50 bg-amber-950/30 p-3.5 flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-xs text-slate-300">
                <span className="font-semibold text-amber-300 block mb-0.5">Android Background Alarm Reliability</span>
                To guarantee Adhans and Alarms ring on time even when phone is locked or after reboot, disable Battery Optimization for Salat Sathi.
                <button
                  type="button"
                  onClick={onOpenBatteryGuide}
                  className="block mt-1 text-emerald-400 underline hover:text-emerald-300 font-semibold cursor-pointer"
                >
                  View Step-by-Step Device Setup Guide →
                </button>
              </div>
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 bg-slate-950/80 px-6 py-4 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-emerald-600 px-5 py-2 text-xs font-bold text-white hover:bg-emerald-500 transition cursor-pointer"
          >
            Save & Done
          </button>
        </div>
      </div>
    </div>
  );
};

function minsToSampleTime(baseTime: string, delayMinutes: number): string {
  const [h, m] = baseTime.split(':').map(Number);
  const total = h * 60 + m + delayMinutes;
  const hh = Math.floor(total / 60).toString().padStart(2, '0');
  const mm = (total % 60).toString().padStart(2, '0');
  return `${hh}:${mm}`;
}
