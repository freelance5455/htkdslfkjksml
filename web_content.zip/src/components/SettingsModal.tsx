import React, { useState } from 'react';
import {
  X,
  Settings,
  KeyRound,
  Type,
  FileText,
  Save,
  RotateCcw,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsModalProps {
  settings: AppSettings;
  isOpen: boolean;
  onClose: () => void;
  onSaveSettings: (newSettings: AppSettings) => Promise<void>;
}

const DEFAULT_SETTINGS: AppSettings = {
  admin_code: '805040',
  app_title: 'Grow Your Instagram',
  app_subtitle: 'Get real followers instantly ✨',
  form_title: 'Add Instagram Account',
  form_subtitle: 'अपना Instagram अकाउंट जोड़ें',
  coins_default: 500,
};

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  isOpen,
  onClose,
  onSaveSettings,
}) => {
  const [formData, setFormData] = useState<AppSettings>({ ...settings });
  const [saving, setSaving] = useState(false);
  const [successToast, setSuccessToast] = useState(false);

  if (!isOpen) return null;

  const handleChange = (field: keyof AppSettings, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onSaveSettings(formData);
      setSuccessToast(true);
      setTimeout(() => setSuccessToast(false), 3000);
    } catch (err) {
      console.error('Failed to save settings:', err);
    } finally {
      setSaving(false);
    }
  };

  const handleResetDefaults = () => {
    if (window.confirm('Reset all texts and code to default values?')) {
      setFormData({ ...DEFAULT_SETTINGS });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl bg-slate-900 border border-purple-500/40 p-6 sm:p-7 shadow-2xl shadow-purple-950/90">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-purple-500/15">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center shadow-md">
              <Settings className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                App Customization Settings
              </h3>
              <p className="text-xs text-purple-300/80">
                Customize titles, subtitles & secret Admin Access Code
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Alert */}
        {successToast && (
          <div className="mt-4 p-3 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-semibold">Settings updated and synced successfully!</span>
          </div>
        )}

        <form onSubmit={handleSave} className="mt-5 space-y-4">
          {/* 1. Admin Access Code */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-pink-500/30 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-pink-300 flex items-center gap-1.5 uppercase tracking-wider">
                <KeyRound className="w-4 h-4 text-pink-400" />
                1. Admin Access Code (गुप्त कोड)
              </label>
              <span className="text-[10px] text-slate-400 font-mono">Chatbot verification</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Users enter this code in the Chatbot to unlock the Admin Panel.
            </p>
            <input
              type="text"
              value={formData.admin_code}
              onChange={(e) => handleChange('admin_code', e.target.value)}
              placeholder="e.g. 805040"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-pink-500/40 focus:border-pink-400 focus:ring-1 focus:ring-pink-400 text-white font-mono font-bold text-sm tracking-widest outline-none"
              required
            />
          </div>

          {/* 2. App Title */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1">
              <Type className="w-3.5 h-3.5 text-purple-400" />
              2. App Title (Main Heading)
            </label>
            <input
              type="text"
              value={formData.app_title}
              onChange={(e) => handleChange('app_title', e.target.value)}
              placeholder="e.g. Grow Your Instagram"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-purple-500/30 focus:border-purple-400 text-white text-xs outline-none"
              required
            />
          </div>

          {/* 3. App Subtitle */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-purple-400" />
              3. App Subtitle (Main Heading Text)
            </label>
            <input
              type="text"
              value={formData.app_subtitle}
              onChange={(e) => handleChange('app_subtitle', e.target.value)}
              placeholder="e.g. Get real followers instantly ✨"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-purple-500/30 focus:border-purple-400 text-white text-xs outline-none"
              required
            />
          </div>

          {/* 4. Form Title */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1">
              <Type className="w-3.5 h-3.5 text-pink-400" />
              4. Form Title (Add Account Heading)
            </label>
            <input
              type="text"
              value={formData.form_title}
              onChange={(e) => handleChange('form_title', e.target.value)}
              placeholder="e.g. Add Instagram Account"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-purple-500/30 focus:border-purple-400 text-white text-xs outline-none"
              required
            />
          </div>

          {/* 5. Form Subtitle */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-pink-400" />
              5. Form Subtitle (Hindi Text under Form Title)
            </label>
            <input
              type="text"
              value={formData.form_subtitle}
              onChange={(e) => handleChange('form_subtitle', e.target.value)}
              placeholder="e.g. अपना Instagram अकाउंट जोड़ें"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-purple-500/30 focus:border-purple-400 text-white text-xs outline-none"
              required
            />
          </div>

          {/* Live Preview Box */}
          <div className="p-3.5 rounded-2xl bg-purple-950/30 border border-purple-500/20 text-xs">
            <span className="text-[10px] uppercase font-bold text-purple-300 font-mono block mb-1">
              Live Preview:
            </span>
            <div className="p-3 rounded-xl bg-slate-950/70 border border-purple-500/20 space-y-1">
              <h4 className="font-extrabold text-sm text-white">{formData.app_title}</h4>
              <p className="text-[11px] text-slate-300">{formData.app_subtitle}</p>
              <div className="mt-2 pt-2 border-t border-purple-500/10">
                <span className="text-xs font-bold text-pink-300">{formData.form_title}</span>
                <p className="text-[10px] text-purple-200/80">{formData.form_subtitle}</p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleResetDefaults}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Defaults</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
              >
                Close
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:brightness-110 active:scale-95 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-pink-900/50 transition-all disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving...' : 'Save Settings'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
