import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  X, 
  Volume2, 
  Music, 
  Mic, 
  Smartphone, 
  Globe, 
  Trash2, 
  ShieldCheck,
} from 'lucide-react';
import { GameSettings, Language } from '../types';
import { getTranslations } from '../services/i18n';
import { BannerAd } from './BannerAd';

interface SettingsModalProps {
  settings: GameSettings;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onResetProgress: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onResetProgress,
  onClose,
}) => {
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const t = getTranslations(settings.language || 'en');

  const toggleSetting = (key: keyof GameSettings) => {
    onUpdateSettings({
      ...settings,
      [key]: !settings[key],
    });
  };

  const handleSelectLanguage = (lang: Language) => {
    onUpdateSettings({
      ...settings,
      language: lang,
    });
  };

  const languages: { code: Language; label: string }[] = [
    { code: 'en', label: 'English' },
    { code: 'hi', label: 'हिन्दी' },
    { code: 'bn', label: 'বাংলা' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm select-none">
      <motion.div
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-800 shadow-2xl border border-slate-100 dark:border-slate-700 flex flex-col items-center relative overflow-hidden max-h-[92vh]"
      >
        <button
          id="btn-settings-close"
          type="button"
          onClick={onClose}
          aria-label={t.cancel}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-500 flex items-center justify-center active:scale-95 z-10"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="w-full p-5 pb-3 overflow-y-auto flex flex-col items-center">
          <h3 className="text-xl font-black text-slate-800 dark:text-white mb-0.5">
            {t.settingsTitle}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            {t.settingsSubtitle}
          </p>

          {/* Setting toggles list */}
          <div className="w-full space-y-2 mb-4">
            {/* Sound FX */}
            <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-sky-100 dark:bg-sky-950 text-sky-600 flex items-center justify-center">
                  <Volume2 className="w-4 h-4" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-xs font-bold text-slate-800 dark:text-white">
                    {t.soundEffects}
                  </span>
                  <span className="text-[10px] text-slate-400">{t.soundEffectsSub}</span>
                </div>
              </div>
              <button
                id="btn-setting-sound"
                type="button"
                onClick={() => toggleSetting('soundEnabled')}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  settings.soundEnabled ? 'bg-sky-500' : 'bg-slate-300 dark:bg-slate-600'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform ${
                    settings.soundEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Music */}
            <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-violet-100 dark:bg-violet-950 text-violet-600 flex items-center justify-center">
                  <Music className="w-4 h-4" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-xs font-bold text-slate-800 dark:text-white">
                    {t.ambientMusic}
                  </span>
                  <span className="text-[10px] text-slate-400">{t.ambientMusicSub}</span>
                </div>
              </div>
              <button
                id="btn-setting-music"
                type="button"
                onClick={() => toggleSetting('musicEnabled')}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  settings.musicEnabled ? 'bg-violet-500' : 'bg-slate-300 dark:bg-slate-600'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform ${
                    settings.musicEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Voice Reactions */}
            <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center">
                  <Mic className="w-4 h-4" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-xs font-bold text-slate-800 dark:text-white">
                    {t.voiceReactions}
                  </span>
                  <span className="text-[10px] text-slate-400">{t.voiceReactionsSub}</span>
                </div>
              </div>
              <button
                id="btn-setting-voice"
                type="button"
                onClick={() => toggleSetting('voiceEnabled')}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  settings.voiceEnabled ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-600'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform ${
                    settings.voiceEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Vibration / Haptics */}
            <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-600 flex items-center justify-center">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-xs font-bold text-slate-800 dark:text-white">
                    {t.hapticFeedback}
                  </span>
                  <span className="text-[10px] text-slate-400">{t.hapticFeedbackSub}</span>
                </div>
              </div>
              <button
                id="btn-setting-vibration"
                type="button"
                onClick={() => toggleSetting('vibrationEnabled')}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  settings.vibrationEnabled ? 'bg-amber-500' : 'bg-slate-300 dark:bg-slate-600'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform ${
                    settings.vibrationEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Language Selection: English, हिन्दी, বাংলা */}
            <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-700/60 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 flex items-center justify-center">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-xs font-bold text-slate-800 dark:text-white">
                      {t.language}
                    </span>
                    <span className="text-[10px] text-slate-400">{t.languageSub}</span>
                  </div>
                </div>
              </div>

              {/* 3 Dedicated Language Choices */}
              <div className="grid grid-cols-3 gap-1.5 pt-1">
                {languages.map((item) => {
                  const isSelected = (settings.language || 'en') === item.code;
                  return (
                    <button
                      key={item.code}
                      id={`btn-language-${item.code}`}
                      type="button"
                      onClick={() => handleSelectLanguage(item.code)}
                      className={`py-2 px-1 text-xs font-bold rounded-xl transition-all active:scale-95 text-center flex items-center justify-center ${
                        isSelected
                          ? 'bg-sky-500 text-white shadow-sm shadow-sky-500/30 ring-2 ring-sky-400'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-sky-300'
                      }`}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Reset progress */}
          <div className="w-full pt-2 border-t border-slate-200/70 dark:border-slate-700/70 flex flex-col items-center">
            {showConfirmReset ? (
              <div className="w-full p-2.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 text-center mb-2">
                <p className="text-xs font-bold text-rose-800 dark:text-rose-200 mb-2">
                  {t.resetConfirmTitle}
                </p>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      onResetProgress();
                      setShowConfirmReset(false);
                    }}
                    className="flex-1 py-1.5 rounded-xl bg-rose-600 text-white font-bold text-xs active:scale-95"
                  >
                    {t.yesReset}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowConfirmReset(false)}
                    className="flex-1 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs"
                  >
                    {t.cancel}
                  </button>
                </div>
              </div>
            ) : (
              <button
                id="btn-settings-reset"
                type="button"
                onClick={() => setShowConfirmReset(true)}
                className="text-xs font-semibold text-rose-500 hover:text-rose-600 flex items-center gap-1.5 py-1 mb-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t.resetProgress}</span>
              </button>
            )}

            <div className="flex items-center gap-1 text-[10px] text-slate-400">
              <ShieldCheck className="w-3 h-3 text-emerald-500" />
              <span>ArrowScape AdMob Ready v1.0.0</span>
            </div>
          </div>
        </div>

        {/* Real AdMob Banner Ad docked at bottom of Settings */}
        <div className="w-full overflow-hidden rounded-b-3xl">
          <BannerAd />
        </div>
      </motion.div>
    </div>
  );
};
