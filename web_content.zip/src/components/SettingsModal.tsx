import React from 'react';
import { SaveData } from '../types/game';
import { X, Volume2, Music, Eye, Activity, RotateCcw } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface SettingsModalProps {
  saveData: SaveData;
  onUpdateSettings: (newSettings: Partial<SaveData['settings']>) => void;
  onResetProgress: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  saveData,
  onUpdateSettings,
  onResetProgress,
  onClose
}) => {
  const settings = saveData.settings;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md select-none animate-in fade-in duration-150">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              SETTINGS
            </h2>
            <p className="text-xs text-slate-400">
              Audio, visuals, and accessibility options
            </p>
          </div>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onClose();
            }}
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Settings Toggles List */}
        <div className="py-4 space-y-3">
          {/* Sound FX */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center gap-3">
              <Volume2 className="w-5 h-5 text-cyan-400" />
              <div>
                <div className="text-xs sm:text-sm font-bold text-white">Sound Effects</div>
                <div className="text-[11px] text-slate-400">Tactile chords, chimes, and impacts</div>
              </div>
            </div>

            <button
              onClick={() => {
                const next = !settings.sound;
                onUpdateSettings({ sound: next });
                soundEngine.setMuted(!next);
              }}
              className={`w-12 h-7 rounded-full p-1 transition-colors ${
                settings.sound ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.sound ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Background Ambient Synth */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center gap-3">
              <Music className="w-5 h-5 text-purple-400" />
              <div>
                <div className="text-xs sm:text-sm font-bold text-white">Ambient Music</div>
                <div className="text-[11px] text-slate-400">Soothing generative synth pads</div>
              </div>
            </div>

            <button
              onClick={() => {
                const next = !settings.music;
                onUpdateSettings({ music: next });
                soundEngine.setMusicMuted(!next);
              }}
              className={`w-12 h-7 rounded-full p-1 transition-colors ${
                settings.music ? 'bg-purple-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.music ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Colorblind Assist Mode */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center gap-3">
              <Eye className="w-5 h-5 text-amber-400" />
              <div>
                <div className="text-xs sm:text-sm font-bold text-white">Colorblind Assist</div>
                <div className="text-[11px] text-slate-400">Overlay distinct geometric symbols</div>
              </div>
            </div>

            <button
              onClick={() => {
                onUpdateSettings({ colorblindMode: !settings.colorblindMode });
              }}
              className={`w-12 h-7 rounded-full p-1 transition-colors ${
                settings.colorblindMode ? 'bg-amber-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.colorblindMode ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Reduced Motion */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center gap-3">
              <Activity className="w-5 h-5 text-emerald-400" />
              <div>
                <div className="text-xs sm:text-sm font-bold text-white">Reduced Motion</div>
                <div className="text-[11px] text-slate-400">Disable screen shake and fireworks</div>
              </div>
            </div>

            <button
              onClick={() => {
                onUpdateSettings({ reducedMotion: !settings.reducedMotion });
              }}
              className={`w-12 h-7 rounded-full p-1 transition-colors ${
                settings.reducedMotion ? 'bg-emerald-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.reducedMotion ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Reset Save Data */}
        <div className="pt-2">
          <button
            onClick={() => {
              if (window.confirm('Reset all completed levels, coins, and high scores?')) {
                onResetProgress();
              }
            }}
            className="w-full py-2.5 rounded-xl border border-rose-900/60 text-rose-400 hover:bg-rose-950/40 font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET ALL PROGRESS</span>
          </button>
        </div>
      </div>
    </div>
  );
};
