import { useState } from 'react';
import { useGame } from '../context/GameContext';
import {
  X,
  Volume2,
  VolumeX,
  Music,
  RotateCcw,
  Check,
  Copy,
  AlertTriangle,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const {
    numberFormat,
    setNumberFormat,
    soundEnabled,
    setSoundEnabled,
    musicEnabled,
    setMusicEnabled,
    musicVolume,
    setMusicVolume,
    toggleMusic,
    resetAllProgress,
    exportSaveString,
    importSaveString,
  } = useGame();

  const [importInput, setImportInput] = useState('');
  const [exportedString, setExportedString] = useState('');
  const [copied, setCopied] = useState(false);
  const [importError, setImportError] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  const handleExport = () => {
    const str = exportSaveString();
    setExportedString(str);

    if (navigator?.clipboard?.writeText) {
      navigator.clipboard
        .writeText(str)
        .then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        })
        .catch(() => {
          // If clipboard permission is blocked, the user can still copy from the textarea below
        });
    }
  };

  const handleImport = () => {
    if (!importInput.trim()) return;
    const success = importSaveString(importInput.trim());
    if (success) {
      setImportInput('');
      setImportError(false);
      onClose();
    } else {
      setImportError(true);
    }
  };

  const handleReset = () => {
    resetAllProgress();
    setConfirmReset(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-12 sm:pt-16 p-4 bg-black/90 animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <h2 className="font-cinzel text-xl font-bold text-slate-100">
            Realm Settings
          </h2>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-6">
          {/* Number Display Format */}
          <div>
            <div className="text-xs uppercase font-semibold text-slate-400 mb-2">
              Number Notation
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setNumberFormat('SUFFIX')}
                className={`px-4 py-2.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                  numberFormat === 'SUFFIX'
                    ? 'border-amber-500 bg-amber-500/20 text-amber-300'
                    : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200'
                }`}
              >
                Fantasy Suffixes (1.45 M, 2.80 B)
              </button>
              <button
                onClick={() => setNumberFormat('SCIENTIFIC')}
                className={`px-4 py-2.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                  numberFormat === 'SCIENTIFIC'
                    ? 'border-amber-500 bg-amber-500/20 text-amber-300'
                    : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200'
                }`}
              >
                Scientific Notation (1.45e6)
              </button>
            </div>
          </div>

          {/* Audio & Music Settings */}
          <div className="space-y-3">
            <div className="text-xs uppercase font-semibold text-slate-400">
              Audio & Fantasy Music
            </div>

            {/* Background Music Theme */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Music className={`w-4 h-4 ${musicEnabled ? 'text-amber-400' : 'text-slate-500'}`} />
                  <div>
                    <div className="text-xs font-semibold text-slate-200">
                      Echoes of the Mana Spire
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Fantasy RPG Theme (Lute, Ambient Pad & Chimes)
                    </div>
                  </div>
                </div>
                <button
                  onClick={toggleMusic}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                    musicEnabled
                      ? 'border-amber-500/50 bg-amber-500/20 text-amber-300'
                      : 'border-slate-700 bg-slate-900 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {musicEnabled ? 'Playing' : 'Muted'}
                </button>
              </div>

              {/* Music Volume Slider */}
              {musicEnabled && (
                <div className="pt-2 border-t border-slate-900 flex items-center gap-3">
                  <span className="text-[11px] text-slate-400 min-w-16">Music Vol:</span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={musicVolume}
                    onChange={(e) => setMusicVolume(parseFloat(e.target.value))}
                    className="flex-1 accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                  />
                  <span className="text-[11px] font-mono text-amber-300 min-w-8 text-right">
                    {Math.round(musicVolume * 100)}%
                  </span>
                </div>
              )}
            </div>

            {/* Sound Effects Toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 hover:bg-slate-800/50 cursor-pointer"
            >
              <span className="flex items-center gap-2">
                {soundEnabled ? (
                  <Volume2 className="w-4 h-4 text-amber-400" />
                ) : (
                  <VolumeX className="w-4 h-4 text-slate-500" />
                )}
                <span>Synthesized Sound Effects (Clicks, Milestones, Coins)</span>
              </span>
              <span className="font-semibold text-amber-400">
                {soundEnabled ? 'Enabled' : 'Muted'}
              </span>
            </button>
          </div>

          {/* Save Management */}
          <div>
            <div className="text-xs uppercase font-semibold text-slate-400 mb-2">
              Save Archive Management
            </div>
            <div className="space-y-3">
              <div>
                <button
                  onClick={handleExport}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span className="text-emerald-300">Copied to Clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-amber-400" />
                      <span>Export Save Archive</span>
                    </>
                  )}
                </button>

                {exportedString && (
                  <div className="mt-2">
                    <textarea
                      readOnly
                      value={exportedString}
                      onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                      className="w-full h-16 bg-slate-950 border border-slate-800 rounded-xl p-2 text-[11px] font-mono text-slate-400 resize-none select-all focus:outline-none focus:border-amber-500"
                    />
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      Save string ready. Click to select all and copy.
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Paste Save Archive string here..."
                  value={importInput}
                  onChange={(e) => {
                    setImportInput(e.target.value);
                    setImportError(false);
                  }}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-amber-500"
                />
                <button
                  onClick={handleImport}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl transition-colors shrink-0 cursor-pointer"
                >
                  Import
                </button>
              </div>
              {importError && (
                <div className="text-[11px] text-rose-400">
                  Invalid archive format. Please check the pasted code.
                </div>
              )}
            </div>
          </div>

          {/* Hard Reset */}
          <div className="pt-4 border-t border-slate-800">
            {confirmReset ? (
              <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs">
                <div className="flex items-center gap-2 text-rose-400 font-semibold mb-2">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Are you sure? This erases all progress permanently.</span>
                </div>
                <div className="flex items-center justify-end gap-2 mt-3">
                  <button
                    onClick={() => setConfirmReset(false)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleReset}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold cursor-pointer"
                  >
                    Confirm Full Reset
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setConfirmReset(true)}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-rose-900/60 bg-rose-950/20 hover:bg-rose-950/40 text-rose-300 text-xs font-semibold transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Entire Realm from Scratch</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
