import React, { useEffect, useState } from 'react';
import { RotateCcw, Trash2, X } from 'lucide-react';
import {
  DEFAULT_PERSONALITY,
  PERSONALITY_PRESETS,
  type AppSettings,
  type GeminiModelId,
  type ThemeMode,
  type ThinkingPreset,
} from '../types/chat';

interface SettingsModalProps {
  open: boolean;
  settings: AppSettings;
  onClose: () => void;
  onSave: (next: AppSettings) => void;
  onClearAllChats: () => void;
}

export function SettingsModal({
  open,
  settings,
  onClose,
  onSave,
  onClearAllChats,
}: SettingsModalProps) {
  const [draft, setDraft] = useState<AppSettings>(settings);
  const [confirmClearAll, setConfirmClearAll] = useState(false);

  useEffect(() => {
    if (open) {
      setDraft(settings);
      setConfirmClearAll(false);
    }
  }, [open, settings]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 p-4 backdrop-blur-[2px]"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="settings-modal-title"
        onClick={(e) => e.stopPropagation()}
        className="max-h-[90vh] w-full max-w-[560px] overflow-y-auto rounded-2xl border border-slate-200 bg-white p-6 text-slate-900 shadow-2xl dark:border-[#293449] dark:bg-[#141a27] dark:text-[#edf2ff]"
      >
        <div className="flex items-center justify-between border-b border-slate-200 pb-4 dark:border-[#293449]">
          <h2 id="settings-modal-title" className="font-display text-lg font-bold">
            CB AI Settings
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close settings"
            className="grid h-8 w-8 place-items-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-[#9aa8c0] dark:hover:bg-[#1b2333] dark:hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-5 space-y-5">
          {/* Model */}
          <div>
            <label htmlFor="cb-model" className="block text-sm font-semibold text-slate-800 dark:text-[#cbd5e8]">
              Gemini Intelligence Mode
            </label>
            <select
              id="cb-model"
              value={draft.model}
              onChange={(e) => setDraft({ ...draft, model: e.target.value as GeminiModelId })}
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 focus:border-[#6478ff] focus:outline-none dark:border-[#293449] dark:bg-[#0d1320] dark:text-[#edf2ff]"
            >
              <option value="gemini-4-hydrogen">Balanced & Thoughtful (Gemini 4 Hydrogen)</option>
              <option value="gemini-3.1-flash-lite">Ultra Fast (Gemini 3.1 Flash Lite)</option>
            </select>
            <p className="mt-1.5 text-xs text-slate-500 dark:text-[#9aa8c0]">
              Balanced handles everyday questions, coding, and image analysis. Fast optimizes for instant replies.
            </p>
          </div>

          {/* Reasoning Depth */}
          {draft.model === 'gemini-4-hydrogen' && (
            <div>
              <label htmlFor="cb-thinking" className="block text-sm font-semibold text-slate-800 dark:text-[#cbd5e8]">
                Reasoning Depth
              </label>
              <select
                id="cb-thinking"
                value={draft.thinkingLevel}
                onChange={(e) => setDraft({ ...draft, thinkingLevel: e.target.value as ThinkingPreset })}
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 focus:border-[#6478ff] focus:outline-none dark:border-[#293449] dark:bg-[#0d1320] dark:text-[#edf2ff]"
              >
                <option value="AUTO">Automatic (Adaptive)</option>
                <option value="LOW">Low (Quickest responses)</option>
                <option value="MEDIUM">Medium (Balanced reasoning)</option>
                <option value="HIGH">High (Thorough problem solving)</option>
              </select>
            </div>
          )}

          {/* Personality */}
          <div>
            <div className="flex items-center justify-between gap-2">
              <label htmlFor="cb-personality" className="text-sm font-semibold text-slate-800 dark:text-[#cbd5e8]">
                CB AI Personality & Instructions
              </label>
              <button
                type="button"
                onClick={() => setDraft({ ...draft, personality: DEFAULT_PERSONALITY })}
                className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-[#5367dd] hover:bg-[#6478ff]/10 dark:text-[#8ea0ff]"
              >
                <RotateCcw className="h-3 w-3" />
                <span>Reset default</span>
              </button>
            </div>

            <div className="mt-2 flex flex-wrap gap-1.5">
              {PERSONALITY_PRESETS.map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => setDraft({ ...draft, personality: preset.prompt })}
                  className={`rounded-lg border px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    draft.personality.trim() === preset.prompt.trim()
                      ? 'border-[#6478ff] bg-[#6478ff]/15 text-[#5367dd] dark:text-[#a4b2ff]'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#cbd5e8] dark:hover:bg-[#222c3f]'
                  }`}
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <textarea
              id="cb-personality"
              rows={4}
              value={draft.personality}
              onChange={(e) => setDraft({ ...draft, personality: e.target.value })}
              className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm leading-relaxed text-slate-900 focus:border-[#6478ff] focus:outline-none dark:border-[#293449] dark:bg-[#0d1320] dark:text-[#edf2ff]"
            />
          </div>

          {/* Appearance */}
          <div>
            <label htmlFor="cb-theme" className="block text-sm font-semibold text-slate-800 dark:text-[#cbd5e8]">
              Appearance
            </label>
            <select
              id="cb-theme"
              value={draft.theme}
              onChange={(e) => setDraft({ ...draft, theme: e.target.value as ThemeMode })}
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 focus:border-[#6478ff] focus:outline-none dark:border-[#293449] dark:bg-[#0d1320] dark:text-[#edf2ff]"
            >
              <option value="dark">Dark</option>
              <option value="light">Light</option>
            </select>
          </div>

          {/* Local Storage */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 dark:border-[#293449] dark:bg-[#0d1320]">
            <label className="flex cursor-pointer items-center gap-2.5 text-sm font-medium text-slate-800 dark:text-[#edf2ff]">
              <input
                type="checkbox"
                checked={draft.remember}
                onChange={(e) => setDraft({ ...draft, remember: e.target.checked })}
                className="h-4 w-4 rounded border-slate-300 text-[#6478ff] focus:ring-[#6478ff]"
              />
              <span>Save chats on this device</span>
            </label>
            <p className="mt-1 pl-6 text-xs text-slate-500 dark:text-[#9aa8c0]">
              History stays in your browser&apos;s local storage and is never uploaded as an account profile.
            </p>
          </div>

          {/* Danger Zone */}
          <div className="flex items-center justify-between gap-3 rounded-xl border border-rose-200 bg-rose-50/70 px-3.5 py-3 dark:border-rose-900/50 dark:bg-rose-950/20">
            <div className="text-xs text-rose-800 dark:text-rose-200">
              Remove all saved conversations from this device.
            </div>
            {confirmClearAll ? (
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    onClearAllChats();
                    setConfirmClearAll(false);
                    onClose();
                  }}
                  className="rounded-lg bg-rose-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-rose-500 whitespace-nowrap shrink-0"
                >
                  Confirm
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClearAll(false)}
                  className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#cbd5e8] whitespace-nowrap shrink-0"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmClearAll(true)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-rose-300 bg-white px-3 py-1.5 text-xs font-semibold text-rose-700 hover:bg-rose-100 dark:border-rose-800 dark:bg-rose-950/60 dark:text-rose-200 dark:hover:bg-rose-900/60 whitespace-nowrap shrink-0"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Clear all</span>
              </button>
            )}
          </div>
        </div>

        <div className="mt-6 flex items-center justify-end gap-2.5 border-t border-slate-200 pt-4 dark:border-[#293449]">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#edf2ff] dark:hover:bg-[#222c3f]"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              onSave({
                ...draft,
                personality: draft.personality.trim() || DEFAULT_PERSONALITY,
              });
              onClose();
            }}
            className="rounded-xl bg-gradient-to-r from-[#6478ff] to-[#5367dd] px-4 py-2 text-sm font-semibold text-white hover:brightness-110"
          >
            Save settings
          </button>
        </div>
      </div>
    </div>
  );
}
