import React from 'react';
import { Bike, Gauge, SlidersHorizontal, Volume2, VolumeX, X } from 'lucide-react';
import type { BikeModelType, GameSettings, SensitivityPreset } from '../game/types';

interface SettingsModalProps {
  open: boolean;
  settings: GameSettings;
  currentModel: BikeModelType;
  muted: boolean;
  onClose: () => void;
  onSelectPreset: (preset: SensitivityPreset) => void;
  onChangeSteeringSensitivity: (value: number) => void;
  onChangeWheelieSensitivity: (value: number) => void;
  onToggleMute: () => void;
  onOpenWorkshop: () => void;
}

const MODEL_NAMES: Record<BikeModelType, string> = {
  cg_titan_160: 'CG 160 Titan',
  cg_fan_160: 'CG 160 Fan / Start',
  bros_160: 'NXR 160 Bros Trail',
};

export const SettingsModal: React.FC<SettingsModalProps> = ({
  open,
  settings,
  currentModel,
  muted,
  onClose,
  onSelectPreset,
  onChangeSteeringSensitivity,
  onChangeWheelieSensitivity,
  onToggleMute,
  onOpenWorkshop,
}) => {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3">
      <div className="w-full max-w-lg max-h-[90vh] flex flex-col bg-neutral-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <SlidersHorizontal className="w-5 h-5 text-amber-400" />
            <h2 className="font-display text-lg font-bold text-white">Configurações</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
            aria-label="Fechar Configurações"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Sensitivity Presets: Normal & Alta */}
          <section className="space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Gauge className="w-4 h-4 text-amber-400" />
                Sensibilidade da Direção
              </h3>
              <span className="text-xs font-mono-tabular text-amber-400">
                {settings.steeringSensitivity.toFixed(2)}x
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => onSelectPreset('normal')}
                className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                  settings.sensitivityPreset === 'normal'
                    ? 'border-amber-400 bg-amber-400/15 text-white'
                    : 'border-white/10 bg-neutral-800/70 text-neutral-300 hover:bg-neutral-800'
                }`}
              >
                <div className="text-sm font-bold">Sensibilidade Normal</div>
                <div className="text-[11px] text-neutral-400 mt-0.5">
                  Controle suave e preciso (1.00x)
                </div>
              </button>

              <button
                type="button"
                onClick={() => onSelectPreset('alta')}
                className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                  settings.sensitivityPreset === 'alta'
                    ? 'border-amber-400 bg-amber-400/15 text-white'
                    : 'border-white/10 bg-neutral-800/70 text-neutral-300 hover:bg-neutral-800'
                }`}
              >
                <div className="text-sm font-bold">Sensibilidade Alta</div>
                <div className="text-[11px] text-neutral-400 mt-0.5">
                  Resposta rápida para manobras (1.65x)
                </div>
              </button>
            </div>

            {/* Fine-tune Slider to move sensitivity freely */}
            <div className="bg-neutral-950/60 border border-white/10 rounded-xl p-3 space-y-2">
              <div className="flex items-center justify-between text-xs text-neutral-300">
                <span>Ajustar Sensibilidade (Direção)</span>
                <span className="font-mono-tabular font-semibold text-white">
                  {Math.round(settings.steeringSensitivity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0.7}
                max={2.2}
                step={0.05}
                value={settings.steeringSensitivity}
                onChange={(e) => onChangeSteeringSensitivity(parseFloat(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-neutral-500">
                <span>Suave (70%)</span>
                <span>Normal (100%)</span>
                <span>Alta (165%)</span>
                <span>Máx (220%)</span>
              </div>
            </div>
          </section>

          {/* Wheelie Sensitivity */}
          <section className="bg-neutral-950/60 border border-white/10 rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between text-xs text-neutral-300">
              <span>Sensibilidade do Grau (Empinar)</span>
              <span className="font-mono-tabular font-semibold text-white">
                {Math.round(settings.wheelieSensitivity * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0.8}
              max={1.6}
              step={0.05}
              value={settings.wheelieSensitivity}
              onChange={(e) => onChangeWheelieSensitivity(parseFloat(e.target.value))}
              className="w-full accent-orange-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-neutral-500">
              <span>Leve (80%)</span>
              <span>Normal (100%)</span>
              <span>Arisca (160%)</span>
            </div>
          </section>

          {/* Current Moto 160 & Sound Quick Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenWorkshop();
              }}
              className="flex items-center justify-between gap-2 p-3 rounded-xl border border-white/10 bg-neutral-800/70 hover:bg-neutral-800 text-left cursor-pointer"
            >
              <div>
                <div className="text-xs font-semibold text-white">Moto Atual</div>
                <div className="text-[11px] text-amber-400">{MODEL_NAMES[currentModel]}</div>
              </div>
              <Bike className="w-4 h-4 text-sky-400 shrink-0" />
            </button>

            <button
              type="button"
              onClick={onToggleMute}
              className="flex items-center justify-between gap-2 p-3 rounded-xl border border-white/10 bg-neutral-800/70 hover:bg-neutral-800 text-left cursor-pointer"
            >
              <div>
                <div className="text-xs font-semibold text-white">Áudio do Jogo</div>
                <div className="text-[11px] text-neutral-300">{muted ? 'Silenciado' : 'Som Ativado'}</div>
              </div>
              {muted ? (
                <VolumeX className="w-4 h-4 text-rose-400 shrink-0" />
              ) : (
                <Volume2 className="w-4 h-4 text-emerald-400 shrink-0" />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
