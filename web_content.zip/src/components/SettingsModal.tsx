import React from 'react';
import { AuthUser, GameSettings } from '../types/game';
import { SyncStatus } from '../services/firebaseSync';
import { X, Volume2, VolumeX, Smartphone, Zap, Cloud, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
  authUser: AuthUser | null;
  syncStatus: SyncStatus;
  onManualSync: () => void;
  onOpenAuth: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  authUser,
  syncStatus,
  onManualSync,
  onOpenAuth,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg bg-[#0c0c0c] border border-[#262626] rounded-2xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#202020] bg-[#121212]">
          <h2 className="text-lg font-bold tracking-tight text-white">SETTINGS &amp; SYNC</h2>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto max-h-[80vh]">
          {/* Audio & Haptic Controls */}
          <div>
            <h3 className="text-xs font-mono uppercase text-neutral-400 mb-3 tracking-wider">
              Gameplay Feedback
            </h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-3.5 bg-[#141414] border border-[#242424] rounded-xl">
                <div className="flex items-center gap-3">
                  {settings.soundEnabled ? (
                    <Volume2 className="w-5 h-5 text-white" />
                  ) : (
                    <VolumeX className="w-5 h-5 text-neutral-500" />
                  )}
                  <div>
                    <div className="text-sm font-medium text-white">Sound Effects</div>
                    <div className="text-xs text-neutral-400">Synthesized Web Audio sweeps &amp; pings</div>
                  </div>
                </div>
                <button
                  onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
                  className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                    settings.soundEnabled ? 'bg-white' : 'bg-neutral-800'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full transition-transform absolute top-1 ${
                      settings.soundEnabled
                        ? 'bg-black translate-x-7'
                        : 'bg-neutral-500 translate-x-1'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between p-3.5 bg-[#141414] border border-[#242424] rounded-xl">
                <div className="flex items-center gap-3">
                  <Smartphone className="w-5 h-5 text-white" />
                  <div>
                    <div className="text-sm font-medium text-white">Haptic Vibration</div>
                    <div className="text-xs text-neutral-400">Tactile pulse on collisions &amp; turns</div>
                  </div>
                </div>
                <button
                  onClick={() => onUpdateSettings({ hapticsEnabled: !settings.hapticsEnabled })}
                  className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                    settings.hapticsEnabled ? 'bg-white' : 'bg-neutral-800'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full transition-transform absolute top-1 ${
                      settings.hapticsEnabled
                        ? 'bg-black translate-x-7'
                        : 'bg-neutral-500 translate-x-1'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between p-3.5 bg-[#141414] border border-[#242424] rounded-xl">
                <div className="flex items-center gap-3">
                  <Zap className="w-5 h-5 text-white" />
                  <div>
                    <div className="text-sm font-medium text-white">Animation Speed</div>
                    <div className="text-xs text-neutral-400">Glide duration on arrow escapes</div>
                  </div>
                </div>
                <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-[#2a2a2a] rounded-lg">
                  <button
                    onClick={() => onUpdateSettings({ animationSpeed: 'normal' })}
                    className={`px-2.5 py-1 text-xs rounded font-medium transition-colors cursor-pointer ${
                      settings.animationSpeed === 'normal'
                        ? 'bg-white text-black font-bold'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    Normal
                  </button>
                  <button
                    onClick={() => onUpdateSettings({ animationSpeed: 'fast' })}
                    className={`px-2.5 py-1 text-xs rounded font-medium transition-colors cursor-pointer ${
                      settings.animationSpeed === 'fast'
                        ? 'bg-white text-black font-bold'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    Fast
                  </button>
                </div>
              </div>

              {/* Theme Selector */}
              <div className="flex items-center justify-between p-3.5 bg-[#141414] border border-[#242424] rounded-xl">
                <div>
                  <div className="text-sm font-medium text-white">Contrast Theme</div>
                  <div className="text-xs text-neutral-400">Paper Minimalist (Screenshot) vs OLED</div>
                </div>
                <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-[#2a2a2a] rounded-lg">
                  <button
                    onClick={() => onUpdateSettings({ contrastTheme: 'paper_light' })}
                    className={`px-2 py-1 text-xs rounded font-medium transition-colors cursor-pointer ${
                      settings.contrastTheme === 'paper_light'
                        ? 'bg-white text-black font-bold'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    Paper
                  </button>
                  <button
                    onClick={() => onUpdateSettings({ contrastTheme: 'pure_black' })}
                    className={`px-2 py-1 text-xs rounded font-medium transition-colors cursor-pointer ${
                      settings.contrastTheme === 'pure_black'
                        ? 'bg-white text-black font-bold'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    OLED
                  </button>
                  <button
                    onClick={() => onUpdateSettings({ contrastTheme: 'charcoal' })}
                    className={`px-2 py-1 text-xs rounded font-medium transition-colors cursor-pointer ${
                      settings.contrastTheme === 'charcoal'
                        ? 'bg-white text-black font-bold'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    Charcoal
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Cloud Synchronization Section */}
          <div>
            <h3 className="text-xs font-mono uppercase text-neutral-400 mb-3 tracking-wider flex items-center justify-between">
              <span>Firebase Cloud Firestore Sync</span>
              <span className="flex items-center gap-1 text-[11px] lowercase">
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    syncStatus.isOnline ? 'bg-emerald-400' : 'bg-amber-400'
                  }`}
                />
                {syncStatus.isOnline ? 'online' : 'offline'}
              </span>
            </h3>

            <div className="p-4 bg-[#141414] border border-[#242424] rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-white">
                    {authUser && !authUser.isGuest
                      ? authUser.displayName || 'Authenticated User'
                      : 'Guest Player (Local Mode)'}
                  </div>
                  <div className="text-xs font-mono text-neutral-400">
                    {authUser && !authUser.isGuest
                      ? authUser.email || `UID: ${authUser.uid}`
                      : 'Progress stored locally. Sign in to sync.'}
                  </div>
                </div>
                <button
                  onClick={onOpenAuth}
                  className="px-3 py-1.5 text-xs bg-white text-black font-bold rounded-lg hover:bg-neutral-200 transition-colors cursor-pointer"
                >
                  {authUser && !authUser.isGuest ? 'Account' : 'Sign In'}
                </button>
              </div>

              <div className="pt-2 border-t border-[#222222] text-xs space-y-1 font-mono text-neutral-400">
                <div className="flex justify-between">
                  <span>Firestore Path:</span>
                  <span className="text-neutral-300">
                    users/{authUser?.uid || 'guest'}/progress/main
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Last Cloud Synced:</span>
                  <span className="text-neutral-300">
                    {syncStatus.lastSyncedAt || 'Not yet synced'}
                  </span>
                </div>
                {syncStatus.pendingChanges && (
                  <div className="flex items-center gap-1.5 text-amber-400 text-[11px]">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>Queued offline changes waiting for network</span>
                  </div>
                )}
              </div>

              {authUser && !authUser.isGuest && (
                <button
                  onClick={onManualSync}
                  disabled={syncStatus.isSyncing}
                  className="w-full mt-2 py-2 flex items-center justify-center gap-2 bg-[#1c1c1c] hover:bg-[#282828] border border-[#333333] text-white text-xs font-medium rounded-lg transition-colors cursor-pointer"
                >
                  <RefreshCw
                    className={`w-3.5 h-3.5 ${syncStatus.isSyncing ? 'animate-spin' : ''}`}
                  />
                  <span>{syncStatus.isSyncing ? 'Syncing...' : 'Sync Cloud Progress Now'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
