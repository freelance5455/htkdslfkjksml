import React, { useState } from "react";
import { Key, Eye, EyeOff, Check, X, ShieldAlert, Sparkles, RefreshCw, Server, AlertCircle } from "lucide-react";
import { AppSettings } from "../types";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSaveSettings: (settings: AppSettings) => void;
  hasServerKey: boolean;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  hasServerKey
}) => {
  const [keyInput, setKeyInput] = useState(settings.customApiKey);
  const [showKey, setShowKey] = useState(false);
  const [selectedFont, setSelectedFont] = useState<"nastaliq" | "sans">(settings.selectedFont);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveSettings({
      ...settings,
      customApiKey: keyInput.trim(),
      selectedFont
    });
    onClose();
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json"
      };
      if (keyInput.trim()) {
        headers["x-gemini-api-key"] = keyInput.trim();
      }

      const res = await fetch("/api/generate", {
        method: "POST",
        headers,
        body: JSON.stringify({
          mode: "ghazal_shayari",
          topic: "ٹیسٹ شعر",
          format: "sher_2_line",
          tone: "romantic",
          style: "simple"
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setTestResult({
          success: true,
          message: "کنکشن کامیاب ہے! Gemini API کامیابی سے جواب دے رہا ہے۔"
        });
      } else {
        setTestResult({
          success: false,
          message: data.error || "کنکشن ناکام رہا۔ برائے مہربانی API Key کی درستگی چیک کریں۔"
        });
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: "سرور سے رابطہ قائم نہ ہو سکا۔ انٹرنیٹ کنکشن چیک کریں۔"
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-lg rounded-3xl bg-stone-900 border border-emerald-800/80 shadow-2xl p-6 relative overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-3 mb-5">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-950 border border-emerald-700/60 text-amber-400">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-urdu-title text-xl text-amber-200 font-bold">
                ترتیبات و API Setup
              </h3>
              <p className="text-[11px] font-ui text-stone-400">
                Google Gemini API & Display Settings
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-5">
          {/* Server / Cloud Key Status Notification */}
          <div className="p-3.5 rounded-2xl bg-stone-950 border border-stone-800 flex items-start gap-3">
            <Server className={`w-5 h-5 shrink-0 mt-0.5 ${hasServerKey ? "text-emerald-400" : "text-amber-400"}`} />
            <div className="text-xs">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-semibold text-stone-200 font-ui">
                  {hasServerKey ? "System Gemini API Key: Active" : "No Server Key Configured"}
                </span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                    hasServerKey
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                      : "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                  }`}
                >
                  {hasServerKey ? "فعال (Connected)" : "کسٹم کی کلید درج کریں"}
                </span>
              </div>
              <p className="font-urdu-sans text-stone-400 leading-relaxed">
                {hasServerKey
                  ? "سسٹم ماحولیاتی متغیر سے منسلک ہے۔ اگر آپ اپنی نجی Gemini Key استعمال کرنا چاہیں تو نیچے درج کر سکتے ہیں۔"
                  : "سسٹم میں خودکار کلید موجود نہیں ہے۔ AI ماڈل چلانے کے لیے نیچے اپنی Google Gemini API Key درج فرمائیں۔"}
              </p>
            </div>
          </div>

          {/* Secure API Key Field */}
          <div>
            <label
              htmlFor="gemini-api-key-input"
              className="block text-xs font-semibold font-urdu-sans text-stone-200 mb-1.5 flex items-center justify-between"
            >
              <span>محفوظ Gemini API Key درج کریں (Secure Field):</span>
              <span className="text-[10px] font-ui text-emerald-400">Encrypted Local Storage</span>
            </label>
            <div className="relative">
              <input
                id="gemini-api-key-input"
                type={showKey ? "text" : "password"}
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                placeholder="AIzaSy... (Google AI Studio Key)"
                className="w-full pr-4 pl-11 py-2.5 rounded-xl bg-stone-950 border border-stone-700 focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 focus:outline-none text-stone-100 font-mono text-sm tracking-wider shadow-inner"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute left-3 top-3 text-stone-400 hover:text-stone-200"
                title={showKey ? "چھپائیں" : "دکھائیں"}
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[10px] font-urdu-sans text-stone-400 mt-1.5">
              یہ کلید صرف آپ کے آلے میں محفوظ رہتی ہے اور ماڈل کی درخواستوں کے لیے پراکسی کی جاتی ہے۔
            </p>
          </div>

          {/* Test Connection Button & Status */}
          <div>
            <button
              type="button"
              onClick={handleTestConnection}
              id="test-connection-button"
              disabled={isTesting}
              className="w-full py-2 px-4 rounded-xl bg-stone-800 hover:bg-stone-700 active:scale-[0.99] text-stone-200 text-xs font-urdu-sans border border-stone-700 flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? "animate-spin text-amber-400" : ""}`} />
              <span>{isTesting ? "رابطہ ٹیسٹ کیا جا رہا ہے..." : "کنکشن ٹیسٹ کریں (Test Connection)"}</span>
            </button>

            {testResult && (
              <div
                className={`mt-2.5 p-2.5 rounded-xl border text-xs font-urdu-sans flex items-start gap-2 ${
                  testResult.success
                    ? "bg-emerald-950/60 border-emerald-600 text-emerald-200"
                    : "bg-rose-950/60 border-rose-600 text-rose-200"
                }`}
              >
                {testResult.success ? (
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                )}
                <span>{testResult.message}</span>
              </div>
            )}
          </div>

          {/* Typography Preference */}
          <div>
            <label className="block text-xs font-semibold font-urdu-sans text-stone-200 mb-1.5">
              شاعری کا پسندیدہ خط (Preferred Font Style):
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSelectedFont("nastaliq")}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  selectedFont === "nastaliq"
                    ? "bg-emerald-950 border-amber-400 text-amber-200 shadow-md"
                    : "bg-stone-950 border-stone-800 text-stone-400 hover:bg-stone-800"
                }`}
              >
                <span className="font-urdu text-lg block">نوری نستعلیق</span>
                <span className="text-[10px] font-ui text-stone-400">Noto Nastaliq Urdu</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedFont("sans")}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  selectedFont === "sans"
                    ? "bg-emerald-950 border-amber-400 text-amber-200 shadow-md"
                    : "bg-stone-950 border-stone-800 text-stone-400 hover:bg-stone-800"
                }`}
              >
                <span className="font-urdu-sans font-bold text-base block">نسخ / جدید سادہ</span>
                <span className="text-[10px] font-ui text-stone-400">Noto Sans Arabic</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="mt-6 pt-4 border-t border-stone-800 flex justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-stone-400 hover:text-stone-200 text-xs font-urdu-sans"
          >
            منسوخ کریں
          </button>
          <button
            type="button"
            onClick={handleSave}
            id="save-settings-button"
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-amber-500 hover:from-emerald-500 hover:to-amber-400 text-stone-950 font-bold text-xs font-urdu-sans shadow-md"
          >
            محفوظ کریں (Save)
          </button>
        </div>
      </div>
    </div>
  );
};
