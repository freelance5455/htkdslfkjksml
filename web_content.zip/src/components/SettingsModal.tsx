import React, { useState } from 'react';
import {
  X,
  Settings,
  Moon,
  Sun,
  Bell,
  Clock,
  Globe,
  Download,
  Trash2,
  Check,
} from 'lucide-react';
import { DOMAINS, TempBoxStore } from '../services/store.ts';

interface SettingsModalProps {
  onClose: () => void;
  onResetAccount: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose, onResetAccount }) => {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [pushNotifications, setPushNotifications] = useState(true);
  const [defaultLifetime, setDefaultLifetime] = useState('24h');
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [exported, setExported] = useState(false);

  const handleExportData = () => {
    const data = TempBoxStore.getState();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tempbox-gdpr-export-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setExported(true);
    setTimeout(() => setExported(false), 3000);
  };

  const handleConfirmWipe = () => {
    onResetAccount();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto text-slate-800">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1 rounded-full hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center mb-4">
          <Settings className="w-6 h-6" />
        </div>

        <h3 className="text-xl font-bold text-slate-900 mb-1">Preferences &amp; Privacy</h3>
        <p className="text-xs text-slate-500 mb-5">
          Manage your temporary storage settings, GDPR controls, and notification preferences.
        </p>

        <div className="space-y-4">
          {/* THEME SELECTOR */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Sun className="w-4 h-4 text-blue-600" />
              <div>
                <div className="text-xs font-bold text-slate-900">Color Palette</div>
                <div className="text-[11px] text-slate-500">White and Blue modern theme</div>
              </div>
            </div>
            <div className="inline-flex rounded-lg bg-white p-0.5 border border-slate-200 text-xs">
              <span className="px-3 py-1 bg-blue-600 text-white font-bold rounded-md">White &amp; Blue</span>
            </div>
          </div>

          {/* NOTIFICATIONS */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Bell className="w-4 h-4 text-blue-600" />
              <div>
                <div className="text-xs font-bold text-slate-900">Instant Notifications</div>
                <div className="text-[11px] text-slate-500">Sound and banner alert when OTP arrives</div>
              </div>
            </div>
            <button
              onClick={() => setPushNotifications(!pushNotifications)}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                pushNotifications ? 'bg-blue-600' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  pushNotifications ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* DEFAULT LIFETIME */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Clock className="w-4 h-4 text-blue-600" />
              <div>
                <div className="text-xs font-bold text-slate-900">Default Mailbox Lifetime</div>
                <div className="text-[11px] text-slate-500">Auto-expires after time window</div>
              </div>
            </div>
            <select
              value={defaultLifetime}
              onChange={(e) => setDefaultLifetime(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg text-xs px-2.5 py-1.5 text-slate-800 focus:outline-none focus:border-blue-500 font-semibold"
            >
              <option value="10m">10 Minutes</option>
              <option value="1h">1 Hour</option>
              <option value="24h">24 Hours</option>
              <option value="7d">7 Days (VIP)</option>
            </select>
          </div>

          {/* DOMAIN ROTATION POOL */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900 mb-2">
              <Globe className="w-4 h-4 text-blue-600" />
              <span>Active Inbound MX Domains ({DOMAINS.length})</span>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {DOMAINS.map((domain) => (
                <div
                  key={domain}
                  className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 font-mono text-[11px] text-blue-700 font-bold flex items-center justify-between"
                >
                  <span>@{domain}</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                </div>
              ))}
            </div>
          </div>

          {/* GDPR DATA EXPORT */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Download className="w-4 h-4 text-blue-600" />
              <div>
                <div className="text-xs font-bold text-slate-900">GDPR Data Portability Export</div>
                <div className="text-[11px] text-slate-500">Download complete unencrypted JSON archive</div>
              </div>
            </div>
            <button
              onClick={handleExportData}
              className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
            >
              {exported ? <Check className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
              <span>{exported ? 'Exported' : 'Export JSON'}</span>
            </button>
          </div>

          {/* GDPR ACCOUNT & DATA WIPE */}
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5">
            <div className="flex items-center gap-2 text-xs font-bold text-rose-700 mb-2">
              <Trash2 className="w-4 h-4 shrink-0" />
              <span>GDPR Right to Be Forgotten</span>
            </div>
            <p className="text-[11px] text-slate-600 mb-3">
              Permanently purges all active mailboxes, messages, rented numbers, encryption keys, and device identifiers from storage.
            </p>
            {showConfirmDelete ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={handleConfirmWipe}
                  className="flex-1 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-colors cursor-pointer shadow-sm"
                >
                  Yes, Permanently Wipe Everything
                </button>
                <button
                  onClick={() => setShowConfirmDelete(false)}
                  className="px-3 py-2 rounded-lg bg-white border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-100"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowConfirmDelete(true)}
                className="w-full py-2 rounded-lg bg-white hover:bg-rose-100 text-rose-700 border border-rose-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Delete Account &amp; All Data
              </button>
            )}
          </div>
        </div>

        {/* LEGAL LINKS */}
        <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
          <span>Zero Tracking SDKs • Client AES-256</span>
          <div className="flex items-center gap-3">
            <a href="#" className="hover:text-blue-600">Privacy Policy</a>
            <span>•</span>
            <a href="#" className="hover:text-blue-600">Terms of Service</a>
          </div>
        </div>
      </div>
    </div>
  );
};
