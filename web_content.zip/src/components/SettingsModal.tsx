import React, { useState } from 'react';
import {
  X,
  User,
  Target,
  Bell,
  Moon,
  Sun,
  RotateCcw,
  Download,
  Upload,
  AlertCircle,
  CheckCircle,
  Save
} from 'lucide-react';
import { AppState, UserProfile } from '../types';
import { exportDataAsJson, importDataFromJson, resetAppStateToDefaults } from '../utils/storage';
import { playChimeSound, requestNotificationPermission } from '../utils/notifications';

interface SettingsModalProps {
  isOpen: boolean;
  state: AppState;
  onClose: () => void;
  onUpdateProfile: (profile: UserProfile) => void;
  onResetTodayChecklist: () => void;
  onRestoreState: (newState: AppState) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  state,
  onClose,
  onUpdateProfile,
  onResetTodayChecklist,
  onRestoreState,
}) => {
  const [profile, setProfile] = useState<UserProfile>({ ...state.profile });
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(profile);
    setMessage({ text: 'Settings updated successfully!', type: 'success' });
    playChimeSound('complete');
    setTimeout(() => setMessage(null), 2500);
  };

  const handleExport = () => {
    const json = exportDataAsJson(state);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `glowup90_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setMessage({ text: 'Data exported successfully!', type: 'success' });
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const content = event.target?.result as string;
          const restored = importDataFromJson(content);
          onRestoreState(restored);
          setMessage({ text: 'Backup restored successfully!', type: 'success' });
          playChimeSound('celebration');
        } catch {
          setMessage({ text: 'Invalid backup file structure.', type: 'error' });
        }
      };
      reader.readAsText(file);
    }
  };

  const handleNotificationRequest = async () => {
    const perm = await requestNotificationPermission();
    if (perm === 'granted') {
      setProfile({ ...profile, notificationsEnabled: true });
      setMessage({ text: 'Notifications enabled for reminders!', type: 'success' });
    } else {
      setMessage({ text: 'Notification permission was not granted by browser.', type: 'error' });
    }
  };

  const handleResetChecklistConfirm = () => {
    if (confirm("Reset today's task checklist? This will uncheck tasks for today only, without erasing past history.")) {
      onResetTodayChecklist();
      setMessage({ text: "Today's checklist has been reset.", type: 'success' });
      playChimeSound('complete');
    }
  };

  const handleFactoryReset = () => {
    if (confirm('Reset entire app data to default 90-day plan? All custom changes will be reset.')) {
      const fresh = resetAppStateToDefaults();
      onRestoreState(fresh);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg rounded-3xl bg-white dark:bg-[#13151B] border border-slate-200 dark:border-slate-800 p-6 shadow-2xl my-8 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              App Settings & Targets
            </h2>
            <p className="text-xs text-slate-500">Configure your profile, targets, alarms, and data</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Close settings"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {message && (
          <div
            className={`p-3 rounded-2xl text-xs flex items-center gap-2 ${
              message.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-900/30'
                : 'bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border border-red-100 dark:border-red-900/30'
            }`}
          >
            {message.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{message.text}</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-4">
          {/* Profile Section */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-purple-600" />
              <span>User Profile</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Name
                </label>
                <input
                  type="text"
                  required
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Program Start Date
                </label>
                <input
                  type="date"
                  required
                  value={profile.startDate}
                  onChange={(e) => setProfile({ ...profile, startDate: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                90-Day Vision Tagline
              </label>
              <input
                type="text"
                value={profile.tagline}
                onChange={(e) => setProfile({ ...profile, tagline: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
              />
            </div>
          </div>

          {/* Daily Goals Section */}
          <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-purple-600" />
              <span>Daily Nutrition & Wellness Goals</span>
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Water (ml)</label>
                <input
                  type="number"
                  min={1000}
                  max={6000}
                  step={250}
                  value={profile.waterGoalMl}
                  onChange={(e) => setProfile({ ...profile, waterGoalMl: Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Calories (kcal)</label>
                <input
                  type="number"
                  min={1000}
                  max={5000}
                  step={50}
                  value={profile.calorieGoal}
                  onChange={(e) => setProfile({ ...profile, calorieGoal: Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Protein (g)</label>
                <input
                  type="number"
                  min={50}
                  max={300}
                  step={5}
                  value={profile.proteinGoalG}
                  onChange={(e) => setProfile({ ...profile, proteinGoalG: Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Target Wt (kg)</label>
                <input
                  type="number"
                  min={40}
                  max={200}
                  step={0.5}
                  value={profile.targetWeightKg}
                  onChange={(e) => setProfile({ ...profile, targetWeightKg: Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                />
              </div>
            </div>
          </div>

          {/* Notifications & Reminders */}
          <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
              <Bell className="w-3.5 h-3.5 text-purple-600" />
              <span>Alarm & Reminders</span>
            </h3>
            <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800">
              <div>
                <div className="text-xs font-semibold text-slate-900 dark:text-white">
                  System Browser Notifications
                </div>
                <div className="text-[11px] text-slate-400">
                  Receive alerts for scheduled workout, skincare & diet times
                </div>
              </div>
              <button
                type="button"
                onClick={handleNotificationRequest}
                className="py-1.5 px-3 rounded-xl bg-purple-600 text-white text-xs font-semibold hover:bg-purple-700 transition-colors"
              >
                Enable Notifications
              </button>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="submit"
              className="py-2.5 px-5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-md shadow-purple-600/20 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Settings</span>
            </button>
          </div>
        </form>

        {/* Data & Backup Section */}
        <div className="space-y-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            Data Backup & Maintenance
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              type="button"
              onClick={handleExport}
              className="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4 text-purple-600" />
              <span>Export JSON</span>
            </button>

            <label className="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer">
              <Upload className="w-4 h-4 text-purple-600" />
              <span>Restore Backup</span>
              <input type="file" accept=".json" onChange={handleImport} className="hidden" />
            </label>

            <button
              type="button"
              onClick={handleResetChecklistConfirm}
              className="p-3 rounded-2xl border border-amber-200 dark:border-amber-900/40 text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/20 text-xs font-medium flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset Today</span>
            </button>
          </div>

          <div className="pt-2 text-right">
            <button
              type="button"
              onClick={handleFactoryReset}
              className="text-[11px] text-red-500 hover:underline"
            >
              Reset to Original 90-Day Seed Data
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
