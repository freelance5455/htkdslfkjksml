import React, { useState } from 'react';
import {
  X,
  Languages,
  Moon,
  Sun,
  LayoutGrid,
  Eye,
  Clock,
  Bell,
  Check,
  RotateCcw,
  Sparkles,
  Sliders,
  Globe,
  Download,
  Archive,
} from 'lucide-react';
import { UserSettings, Language } from '../types';
import { getTranslations } from '../services/i18n';
import { DEFAULT_SETTINGS } from '../services/hebrewCalendarService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const currentLang = settings.language || 'en';
  const t = getTranslations(currentLang);
  const isRtl = currentLang === 'he';

  const [activeTab, setActiveTab] = useState<'language' | 'general' | 'zmanim' | 'display' | 'alerts'>('language');
  const [showSaveNotification, setShowSaveNotification] = useState(false);

  if (!isOpen) return null;

  const handleLanguageChange = (newLang: Language) => {
    onUpdateSettings({ language: newLang });
    setShowSaveNotification(true);
    setTimeout(() => setShowSaveNotification(false), 2500);
  };

  const handleResetDefaults = () => {
    if (window.confirm(isRtl ? 'האם לאפס את כל ההגדרות לברירת המחדל?' : 'Reset all settings to defaults?')) {
      onUpdateSettings(DEFAULT_SETTINGS);
      setShowSaveNotification(true);
      setTimeout(() => setShowSaveNotification(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-[#161616] border border-[#2A2A2A] rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
        dir={isRtl ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <div className="p-5 border-b border-[#2A2A2A] flex items-center justify-between bg-[#1A1A1A]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#C5A267]/15 border border-[#C5A267]/30 flex items-center justify-center text-[#C5A267]">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-serif font-bold text-[#EAEAEA]">
                {t.settingsTitle}
              </h3>
              <p className="text-xs text-[#888888]">
                {t.settingsSubtitle}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-[#222222] hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
            title={t.close}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 p-2 bg-[#121212] border-b border-[#2A2A2A] overflow-x-auto text-xs font-medium">
          <button
            onClick={() => setActiveTab('language')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'language'
                ? 'bg-[#C5A267] text-[#0F0F0F] font-semibold shadow-xs'
                : 'text-[#888888] hover:text-[#EAEAEA] hover:bg-[#1A1A1A]'
            }`}
          >
            <Languages className="w-3.5 h-3.5" />
            <span>{t.languageSection}</span>
          </button>

          <button
            onClick={() => setActiveTab('general')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'general'
                ? 'bg-[#C5A267] text-[#0F0F0F] font-semibold shadow-xs'
                : 'text-[#888888] hover:text-[#EAEAEA] hover:bg-[#1A1A1A]'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>{t.appearanceSection}</span>
          </button>

          <button
            onClick={() => setActiveTab('display')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'display'
                ? 'bg-[#C5A267] text-[#0F0F0F] font-semibold shadow-xs'
                : 'text-[#888888] hover:text-[#EAEAEA] hover:bg-[#1A1A1A]'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{t.displayPreferences}</span>
          </button>

          <button
            onClick={() => setActiveTab('zmanim')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'zmanim'
                ? 'bg-[#C5A267] text-[#0F0F0F] font-semibold shadow-xs'
                : 'text-[#888888] hover:text-[#EAEAEA] hover:bg-[#1A1A1A]'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{t.halachicOpinions}</span>
          </button>

          <button
            onClick={() => setActiveTab('alerts')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'alerts'
                ? 'bg-[#C5A267] text-[#0F0F0F] font-semibold shadow-xs'
                : 'text-[#888888] hover:text-[#EAEAEA] hover:bg-[#1A1A1A]'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>{t.notificationSettings}</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-sm">
          {/* TAB 1: LANGUAGE SWITCHER */}
          {activeTab === 'language' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              <div className="space-y-2">
                <h4 className="text-base font-bold text-[#EAEAEA] flex items-center gap-2">
                  <Languages className="w-4 h-4 text-[#C5A267]" />
                  <span>{t.languageSection}</span>
                </h4>
                <p className="text-xs text-[#888888]">
                  {t.languageDesc}
                </p>
              </div>

              {/* Language Switch Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Hebrew (RTL) Option */}
                <button
                  type="button"
                  onClick={() => handleLanguageChange('he')}
                  className={`p-5 rounded-2xl border text-right transition-all flex flex-col justify-between h-36 relative overflow-hidden group ${
                    currentLang === 'he'
                      ? 'border-[#C5A267] bg-[#C5A267]/10 ring-1 ring-[#C5A267]/40 shadow-lg'
                      : 'border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#222222] hover:border-[#3A3A3A]'
                  }`}
                  dir="rtl"
                >
                  <div className="flex items-start justify-between w-full">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">🇮🇱</span>
                      <span className="text-base font-bold font-serif-hebrew text-[#EAEAEA]">
                        עברית
                      </span>
                    </div>
                    {currentLang === 'he' && (
                      <span className="w-6 h-6 rounded-full bg-[#C5A267] text-[#0F0F0F] flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                    )}
                  </div>

                  <div>
                    <span className="text-xs font-semibold text-[#C5A267] block">
                      כיוון מימין לשמאל (RTL)
                    </span>
                    <p className="text-[11px] text-[#888888] mt-0.5">
                      ממשק שלם בעברית עם שמות החודשים, הזמנים, תאריכים בגימטריה והתראות.
                    </p>
                  </div>
                </button>

                {/* English (LTR) Option */}
                <button
                  type="button"
                  onClick={() => handleLanguageChange('en')}
                  className={`p-5 rounded-2xl border text-left transition-all flex flex-col justify-between h-36 relative overflow-hidden group ${
                    currentLang === 'en'
                      ? 'border-[#C5A267] bg-[#C5A267]/10 ring-1 ring-[#C5A267]/40 shadow-lg'
                      : 'border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#222222] hover:border-[#3A3A3A]'
                  }`}
                  dir="ltr"
                >
                  <div className="flex items-start justify-between w-full">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">🇺🇸</span>
                      <span className="text-base font-bold text-[#EAEAEA]">
                        English
                      </span>
                    </div>
                    {currentLang === 'en' && (
                      <span className="w-6 h-6 rounded-full bg-[#C5A267] text-[#0F0F0F] flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                    )}
                  </div>

                  <div>
                    <span className="text-xs font-semibold text-[#C5A267] block">
                      Left-to-Right Layout (LTR)
                    </span>
                    <p className="text-[11px] text-[#888888] mt-0.5">
                      Complete English interface with transliterated Hebrew dates, prayer times, and tools.
                    </p>
                  </div>
                </button>
              </div>

              {/* Preview Banner */}
              <div className="p-4 rounded-xl bg-[#121212] border border-[#2A2A2A] flex items-center justify-between text-xs">
                <span className="text-[#888888]">
                  {isRtl ? 'שפה נבחרת כעת:' : 'Currently active language:'}
                </span>
                <span className="font-bold text-[#C5A267] flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5" />
                  {currentLang === 'he' ? 'עברית (RTL - ימין לשמאל)' : 'English (LTR - Left to Right)'}
                </span>
              </div>
            </div>
          )}

          {/* TAB 2: GENERAL & APPEARANCE */}
          {activeTab === 'general' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              {/* Color Theme */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-[#888888] uppercase tracking-wider">
                  {t.theme}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ theme: 'dark', darkMode: true })}
                    className={`p-3.5 rounded-xl border flex items-center justify-center gap-2.5 font-medium text-xs transition-colors ${
                      settings.darkMode !== false
                        ? 'border-[#C5A267] bg-[#C5A267]/10 text-[#C5A267] font-semibold'
                        : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:bg-[#252525]'
                    }`}
                  >
                    <Moon className="w-4 h-4" />
                    <span>{t.darkMode}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ theme: 'light', darkMode: false })}
                    className={`p-3.5 rounded-xl border flex items-center justify-center gap-2.5 font-medium text-xs transition-colors ${
                      settings.darkMode === false
                        ? 'border-[#C5A267] bg-[#C5A267]/10 text-[#C5A267] font-semibold'
                        : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:bg-[#252525]'
                    }`}
                  >
                    <Sun className="w-4 h-4" />
                    <span>{t.lightMode}</span>
                  </button>
                </div>
              </div>

              {/* Default View Mode */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-[#888888] uppercase tracking-wider">
                  {t.defaultView}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['month', 'week', 'day', 'agenda'] as const).map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => onUpdateSettings({ viewMode: mode })}
                      className={`p-3 rounded-xl border text-xs font-semibold capitalize transition-colors ${
                        settings.viewMode === mode
                          ? 'border-[#C5A267] bg-[#C5A267]/10 text-[#C5A267]'
                          : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:bg-[#252525]'
                      }`}
                    >
                      {mode === 'month' && t.viewMonth}
                      {mode === 'week' && t.viewWeek}
                      {mode === 'day' && t.viewDay}
                      {mode === 'agenda' && t.viewAgenda}
                    </button>
                  ))}
                </div>
              </div>

              {/* Export Full Project ZIP */}
              <div className="space-y-2 pt-2 border-t border-[#2A2A2A]">
                <label className="block text-xs font-bold text-[#888888] uppercase tracking-wider">
                  {isRtl ? 'יצוא קוד המקור (ZIP)' : 'Export Full Project (ZIP)'}
                </label>
                <div className="p-4 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#C5A267]/15 border border-[#C5A267]/30 flex items-center justify-center text-[#C5A267] shrink-0">
                      <Archive className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-[#EAEAEA] block">
                        {isRtl ? 'הורדת כל קבצי הפרויקט כקובץ ZIP' : 'Download Complete Codebase (.ZIP)'}
                      </span>
                      <span className="text-[10px] text-[#888888]">
                        {isRtl
                          ? 'קובץ ארכיון שלם הכולל את כל רכיבי הלוח העברי, העיצוב, השירותים והגדרות הפרויקט'
                          : 'Complete archive including all React components, styles, Hebrew calendar engines, and config'}
                      </span>
                    </div>
                  </div>
                  <a
                    href="/api/download-zip"
                    download="hebrew-calendar-source.zip"
                    className="px-4 py-2 rounded-xl bg-[#C5A267] hover:bg-[#D4B37F] text-[#0F0F0F] font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isRtl ? 'הורד ZIP' : 'Download ZIP'}</span>
                  </a>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: DISPLAY PREFERENCES */}
          {activeTab === 'display' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <label className="block text-xs font-bold text-[#888888] uppercase tracking-wider">
                {t.displayPreferences}
              </label>

              <div className="space-y-3 bg-[#1A1A1A] p-4 rounded-xl border border-[#2A2A2A]">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-medium text-[#EAEAEA]">{t.showHebrewGematriya}</span>
                  <input
                    type="checkbox"
                    checked={settings.display?.showHebrewGematriya !== false}
                    onChange={(e) =>
                      onUpdateSettings({
                        display: { ...settings.display, showHebrewGematriya: e.target.checked } as any,
                      })
                    }
                    className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-medium text-[#EAEAEA]">{t.showSecularDates}</span>
                  <input
                    type="checkbox"
                    checked={settings.display?.showSecularDates !== false}
                    onChange={(e) =>
                      onUpdateSettings({
                        display: { ...settings.display, showSecularDates: e.target.checked } as any,
                      })
                    }
                    className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-medium text-[#EAEAEA]">{t.showParasha}</span>
                  <input
                    type="checkbox"
                    checked={settings.display?.showParasha !== false}
                    onChange={(e) =>
                      onUpdateSettings({
                        display: { ...settings.display, showParasha: e.target.checked } as any,
                      })
                    }
                    className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-medium text-[#EAEAEA]">{t.showOmer}</span>
                  <input
                    type="checkbox"
                    checked={settings.display?.showOmer !== false}
                    onChange={(e) =>
                      onUpdateSettings({
                        display: { ...settings.display, showOmer: e.target.checked } as any,
                      })
                    }
                    className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-medium text-[#EAEAEA]">{t.showDafYomi}</span>
                  <input
                    type="checkbox"
                    checked={settings.display?.showDafYomi !== false}
                    onChange={(e) =>
                      onUpdateSettings({
                        display: { ...settings.display, showDafYomi: e.target.checked } as any,
                      })
                    }
                    className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                  />
                </label>
              </div>
            </div>
          )}

          {/* TAB 4: HALACHIC ZMANIM & OPINIONS */}
          {activeTab === 'zmanim' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              {/* Candle Lighting Offset */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-[#888888]">
                  {t.shabbatOffset} ({t.minutesBeforeSunset})
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[18, 20, 30, 40].map((mins) => (
                    <button
                      key={mins}
                      type="button"
                      onClick={() =>
                        onUpdateSettings({
                          candleLightingOffset: mins,
                          zmanim: { ...settings.zmanim, shabbatOffset: mins } as any,
                        })
                      }
                      className={`py-2 rounded-lg border text-xs font-semibold ${
                        (settings.candleLightingOffset || settings.zmanim?.shabbatOffset) === mins
                          ? 'border-[#C5A267] bg-[#C5A267]/15 text-[#C5A267]'
                          : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:bg-[#252525]'
                      }`}
                    >
                      {mins} {isRtl ? 'דק׳' : 'min'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Havdalah Opinions */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-[#888888]">
                  {t.havdalahOpinion}
                </label>
                <select
                  value={settings.havdalahOpinion || settings.zmanim?.havdalahOpinion || '42'}
                  onChange={(e) =>
                    onUpdateSettings({
                      havdalahOpinion: e.target.value as any,
                      zmanim: { ...settings.zmanim, havdalahOpinion: e.target.value as any } as any,
                    })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
                >
                  <option value="8.5">
                    {isRtl ? '8.5 מעלות מתחת לאופק (~30-36 דקות)' : '8.5° below horizon (~30-36 min)'}
                  </option>
                  <option value="42">
                    {isRtl ? '42 דקות לאחר השקיעה (מנהג ארץ ישראל)' : '42 minutes after sunset (Standard Israel)'}
                  </option>
                  <option value="50">
                    {isRtl ? '50 דקות (חזון איש)' : '50 minutes (Chazon Ish)'}
                  </option>
                  <option value="72">
                    {isRtl ? '72 דקות - רבינו תם' : '72 minutes - Rabbeinu Tam'}
                  </option>
                </select>
              </div>

              {/* Calculation Opinion GRA vs MGA */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-[#888888]">
                  {t.zmanimCalculation}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({
                        zmanim: { ...settings.zmanim, opinion: 'gra' } as any,
                      })
                    }
                    className={`p-3 rounded-xl border text-xs text-left transition-colors ${
                      settings.zmanim?.opinion !== 'mga'
                        ? 'border-[#C5A267] bg-[#C5A267]/15 text-[#C5A267] font-semibold'
                        : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:bg-[#252525]'
                    }`}
                  >
                    <div className="font-bold">{t.graOpinion}</div>
                    <div className="text-[10px] text-[#888888] mt-0.5">
                      {isRtl ? 'שעות זמניות מהנץ ועד השקיעה' : 'Proportional hours from sunrise to sunset'}
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({
                        zmanim: { ...settings.zmanim, opinion: 'mga' } as any,
                      })
                    }
                    className={`p-3 rounded-xl border text-xs text-left transition-colors ${
                      settings.zmanim?.opinion === 'mga'
                        ? 'border-[#C5A267] bg-[#C5A267]/15 text-[#C5A267] font-semibold'
                        : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:bg-[#252525]'
                    }`}
                  >
                    <div className="font-bold">{t.mgaOpinion}</div>
                    <div className="text-[10px] text-[#888888] mt-0.5">
                      {isRtl ? 'מעלות השחר ועד צאת הכוכבים' : 'Proportional hours from dawn to nightfall'}
                    </div>
                  </button>
                </div>
              </div>

              {/* Elevation Adjustment */}
              <label className="flex items-center justify-between p-3 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] cursor-pointer">
                <div>
                  <span className="text-xs font-semibold text-[#EAEAEA] block">
                    {t.elevationAdjustment}
                  </span>
                  <span className="text-[10px] text-[#888888]">
                    {isRtl ? 'התאמה מדויקת של הנץ והשקיעה לפי גובה העיר' : 'Adjusts visible sunrise and sunset according to altitude'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.zmanim?.useElevation !== false}
                  onChange={(e) =>
                    onUpdateSettings({
                      zmanim: { ...settings.zmanim, useElevation: e.target.checked } as any,
                    })
                  }
                  className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                />
              </label>
            </div>
          )}

          {/* TAB 5: NOTIFICATIONS & ALERTS */}
          {activeTab === 'alerts' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <label className="block text-xs font-bold text-[#888888] uppercase tracking-wider">
                {t.notificationSettings}
              </label>

              <div className="space-y-3 bg-[#1A1A1A] p-4 rounded-xl border border-[#2A2A2A]">
                <label className="flex items-center justify-between cursor-pointer pb-3 border-b border-[#2A2A2A]">
                  <div>
                    <span className="text-xs font-semibold text-[#EAEAEA] block">{t.enableAlerts}</span>
                    <span className="text-[10px] text-[#888888]">
                      {isRtl ? 'הפעלת הודעות דחיפה בדפדפן' : 'Allow notifications in your browser'}
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.notifications.enabled}
                    onChange={(e) =>
                      onUpdateSettings({
                        notifications: { ...settings.notifications, enabled: e.target.checked },
                      })
                    }
                    className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-medium text-[#EAEAEA]">{t.shabbatCandleAlerts}</span>
                  <input
                    type="checkbox"
                    checked={settings.notifications.shabbatCandles}
                    onChange={(e) =>
                      onUpdateSettings({
                        notifications: { ...settings.notifications, shabbatCandles: e.target.checked },
                      })
                    }
                    className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-medium text-[#EAEAEA]">{t.holidayAlerts}</span>
                  <input
                    type="checkbox"
                    checked={settings.notifications.holidays}
                    onChange={(e) =>
                      onUpdateSettings({
                        notifications: { ...settings.notifications, holidays: e.target.checked },
                      })
                    }
                    className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-medium text-[#EAEAEA]">{t.dailyVerseNotification}</span>
                  <input
                    type="checkbox"
                    checked={settings.notifications.dailyVerse}
                    onChange={(e) =>
                      onUpdateSettings({
                        notifications: { ...settings.notifications, dailyVerse: e.target.checked },
                      })
                    }
                    className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-medium text-[#EAEAEA]">{t.personalEventReminders}</span>
                  <input
                    type="checkbox"
                    checked={settings.notifications.personalEvents}
                    onChange={(e) =>
                      onUpdateSettings({
                        notifications: { ...settings.notifications, personalEvents: e.target.checked },
                      })
                    }
                    className="w-4 h-4 rounded-sm border-[#3A3A3A] bg-[#161616] text-[#C5A267] focus:ring-0"
                  />
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#2A2A2A] bg-[#1A1A1A] flex items-center justify-between">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs text-[#888888] hover:text-rose-400 hover:bg-rose-950/20 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.resetDefaults}</span>
          </button>

          <div className="flex items-center gap-3">
            {showSaveNotification && (
              <span className="text-xs text-emerald-400 flex items-center gap-1 font-medium animate-in fade-in">
                <Check className="w-3.5 h-3.5" /> {t.savedSuccessfully}
              </span>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-[#C5A267] hover:bg-[#D4B37F] text-[#0F0F0F] font-bold text-xs shadow-md transition-colors"
            >
              {t.close}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
