/**
 * HELENA - Ajustes Modal
 * Controls speech speed, mute status, wake word, and app preferences.
 * Styled in dark green theme (--cor-anel, --cor-brilho, --cor-borda).
 */

import React from 'react';
import { Sliders, X, Volume2, VolumeX, Gauge } from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsModalProps {
  settings: AppSettings;
  isOpen: boolean;
  onClose: () => void;
  onUpdateSettings: (updated: Partial<AppSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  isOpen,
  onClose,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div 
        className="bg-[#030d06] border border-[#14502D] rounded-2xl max-w-md w-full p-5 space-y-5 shadow-2xl text-[#CDEBD8]"
        style={{ borderColor: 'var(--cor-borda)' }}
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#14502D]/60">
          <div className="flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-[#2FD16F]" />
            <h2 className="text-sm font-semibold text-white tracking-wide">Ajustes da HELENA</h2>
          </div>
          <button 
            onClick={onClose} 
            className="p-1 text-[#CDEBD8]/70 hover:text-white rounded min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Speech Rate Control */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-medium text-[#CDEBD8] flex items-center space-x-1.5">
              <Gauge className="w-3.5 h-3.5 text-[#2FD16F]" />
              <span>Velocidade da Fala:</span>
            </label>
            <span className="text-xs font-mono text-[#2FD16F]">{settings.speechRate.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.6"
            max="1.8"
            step="0.05"
            value={settings.speechRate}
            onChange={(e) => onUpdateSettings({ speechRate: parseFloat(e.target.value) })}
            className="w-full accent-[#0E7A3D] cursor-pointer h-2 bg-black/60 rounded-lg"
          />
          <div className="flex justify-between text-[10px] text-[#CDEBD8]/50 font-mono">
            <span>Mais calma (0.6x)</span>
            <span>Normal (1.0x)</span>
            <span>Rápida (1.8x)</span>
          </div>
        </div>

        {/* Audio Mute Switch */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-black/60 border border-[#14502D]/70">
          <div className="flex items-center space-x-2.5">
            {settings.speechMuted ? (
              <VolumeX className="w-4 h-4 text-rose-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-[#2FD16F]" />
            )}
            <div>
              <p className="text-xs font-medium text-white">Voz da HELENA</p>
              <p className="text-[10px] text-[#CDEBD8]/50">
                {settings.speechMuted ? 'Mudo (somente texto)' : 'Áudio e fala ativos'}
              </p>
            </div>
          </div>
          <button
            onClick={() => onUpdateSettings({ speechMuted: !settings.speechMuted })}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition min-h-[44px] ${
              settings.speechMuted
                ? 'bg-rose-950/40 border-rose-800 text-rose-300'
                : 'bg-[#0E7A3D]/40 border-[#2FD16F] text-white'
            }`}
          >
            {settings.speechMuted ? 'Desmutar' : 'Silenciar'}
          </button>
        </div>

        {/* Wake Word Preference */}
        <div className="space-y-1.5">
          <label className="text-xs font-medium text-[#CDEBD8]">Palavra de Ativação (Voz)</label>
          <input
            type="text"
            value={settings.wakeWord}
            onChange={(e) => onUpdateSettings({ wakeWord: e.target.value })}
            placeholder="Helena"
            className="w-full px-3 py-2 rounded-xl bg-black/60 border border-[#14502D] text-xs text-[#CDEBD8] focus:outline-none focus:border-[#2FD16F]"
          />
          <p className="text-[10px] text-[#CDEBD8]/50 font-mono">
            Diga "{settings.wakeWord}" para iniciar a escuta de comandos.
          </p>
        </div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-[#0E7A3D] hover:bg-[#17B35A] text-xs font-semibold text-white transition min-h-[44px]"
        >
          Concluir
        </button>
      </div>
    </div>
  );
};
