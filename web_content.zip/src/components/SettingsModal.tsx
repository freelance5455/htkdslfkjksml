import React, { useState } from 'react';
import { Settings, X, ShieldAlert, Cpu, Radio, Network, Check, Split, Ban, Wifi } from 'lucide-react';
import { VpnSettings, ProtocolType, DNSType } from '../types/vpn';
import { Language, TRANSLATIONS } from '../translations';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: VpnSettings;
  onUpdateSettings: (newSettings: VpnSettings) => void;
  language: Language;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  language,
}) => {
  const t = TRANSLATIONS[language];
  const [localSettings, setLocalSettings] = useState<VpnSettings>({ ...settings });

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateSettings(localSettings);
    onClose();
  };

  const protocols: { id: ProtocolType; name: string; desc: string }[] = [
    { id: 'wireguard', name: 'WireGuard (Recommended)', desc: 'Modern, high-speed cryptokey routing protocol with lowest battery drain' },
    { id: 'openvpn_udp', name: 'OpenVPN (UDP)', desc: 'Industry standard for high performance gaming & fast streaming' },
    { id: 'openvpn_tcp', name: 'OpenVPN (TCP)', desc: 'Reliable packet delivery, bypasses aggressive corporate firewalls' },
    { id: 'ikev2', name: 'IKEv2 / IPsec', desc: 'Fast reconnection when switching between Mobile Data & Wi-Fi' },
    { id: 'shadowsocks', name: 'Shadowsocks', desc: 'Anti-censorship obfuscated proxy protocol for restricted networks' },
  ];

  const dnsOptions: { id: DNSType; name: string; ip: string }[] = [
    { id: 'cloudflare', name: 'Cloudflare 1.1.1.1', ip: '1.1.1.1 · Fastest resolution & privacy' },
    { id: 'google', name: 'Google Public DNS', ip: '8.8.8.8 · High availability' },
    { id: 'adguard', name: 'AdGuard DNS', ip: '94.140.14.14 · Native ad & tracker blocker' },
    { id: 'quad9', name: 'Quad9 Security', ip: '9.9.9.9 · Malicious domain protection' },
  ];

  const sampleApps = [
    { id: 'browser', name: 'Chrome / Firefox / Edge' },
    { id: 'torrent', name: 'qBittorrent / P2P Client' },
    { id: 'banking', name: 'Online Banking & FinTech' },
    { id: 'streaming', name: 'Netflix / YouTube App' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-xl max-h-[90vh] shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
              <Settings className="w-4 h-4" />
            </div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
              {t.settingsTitle}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* 1. Protocol Selector */}
          <div>
            <label className="text-xs font-bold text-slate-900 dark:text-white block mb-1">
              {t.protocol}
            </label>
            <p className="text-xs text-slate-500 mb-3">{t.protocolDesc}</p>
            
            <div className="space-y-2">
              {protocols.map((p) => {
                const isSelected = localSettings.protocol === p.id;
                return (
                  <div
                    key={p.id}
                    onClick={() => setLocalSettings({ ...localSettings, protocol: p.id })}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500 text-slate-900 dark:text-white font-medium'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div>
                      <div className="font-bold">{p.name}</div>
                      <div className="text-[11px] text-slate-500">{p.desc}</div>
                    </div>
                    {isSelected && (
                      <div className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center shrink-0 ml-2">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* 2. Kill Switch */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-rose-500 mt-0.5 shrink-0" />
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  {t.killSwitch}
                </span>
                <span className="text-[11px] text-slate-500 block mt-0.5">
                  {t.killSwitchDesc}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setLocalSettings({ ...localSettings, killSwitch: !localSettings.killSwitch })}
              className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors shrink-0 ${
                localSettings.killSwitch ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  localSettings.killSwitch ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* 3. DNS Provider */}
          <div>
            <label className="text-xs font-bold text-slate-900 dark:text-white block mb-1">
              {t.customDnsTitle}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
              {dnsOptions.map((dns) => {
                const isSelected = localSettings.dnsProtection === dns.id;
                return (
                  <div
                    key={dns.id}
                    onClick={() => setLocalSettings({ ...localSettings, dnsProtection: dns.id })}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500 text-slate-900 dark:text-white font-medium'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="font-bold">{dns.name}</div>
                    <div className="text-[10px] text-slate-500 truncate">{dns.ip}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 4. Toggles: AdBlocker & Auto-Connect */}
          <div className="space-y-3">
            {/* Ad Block */}
            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Ban className="w-4 h-4 text-emerald-500" />
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white">CleanWeb Ad & Threat Blocker</div>
                  <div className="text-[11px] text-slate-500">{t.adBlockDesc}</div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setLocalSettings({ ...localSettings, blockAdsAndMalware: !localSettings.blockAdsAndMalware })}
                className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors shrink-0 ${
                  localSettings.blockAdsAndMalware ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    localSettings.blockAdsAndMalware ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Auto Connect */}
            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Wifi className="w-4 h-4 text-sky-500" />
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white">Auto-Connect on Public Wi-Fi</div>
                  <div className="text-[11px] text-slate-500">{t.autoConnectDesc}</div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setLocalSettings({ ...localSettings, autoConnectOnWifi: !localSettings.autoConnectOnWifi })}
                className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors shrink-0 ${
                  localSettings.autoConnectOnWifi ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    localSettings.autoConnectOnWifi ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Split Tunneling */}
            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Split className="w-4 h-4 text-purple-500" />
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white">Split Tunneling</div>
                  <div className="text-[11px] text-slate-500">{t.splitTunnelDesc}</div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setLocalSettings({ ...localSettings, splitTunneling: !localSettings.splitTunneling })}
                className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors shrink-0 ${
                  localSettings.splitTunneling ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    localSettings.splitTunneling ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-sm transition-colors"
          >
            {t.saveSettings}
          </button>
        </div>

      </div>
    </div>
  );
};
