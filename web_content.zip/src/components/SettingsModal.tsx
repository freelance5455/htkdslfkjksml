import React, { useState } from 'react';
import { ConnectionConfig } from '../types.ts';
import { X, Save, RotateCcw, ShieldAlert } from 'lucide-react';
import { sounds } from '../utils/audio.ts';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ConnectionConfig;
  onSave: (newConfig: ConnectionConfig) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onSave
}) => {
  const [host, setHost] = useState(config.host);
  const [port, setPort] = useState(config.port);
  const [key, setKey] = useState(config.key);
  const [refreshInterval, setRefreshInterval] = useState(config.refreshInterval);
  const [soundEnabled, setSoundEnabled] = useState(config.soundEnabled);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...config,
      host: host.trim(),
      port: port.trim(),
      key: key.trim(),
      refreshInterval,
      soundEnabled
    });
    if (soundEnabled) sounds.playClickSound();
    onClose();
  };

  const handleReset = () => {
    setHost('mchelden3.modrinth.gg');
    setPort('25809');
    setKey('change_me');
    setRefreshInterval(10);
    setSoundEnabled(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md rounded-2xl bg-zinc-900 border border-zinc-800 p-6 shadow-2xl space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div>
            <h2 className="text-lg font-bold text-white">ServerTap Verbindung</h2>
            <p className="text-xs text-zinc-400">
              Konfiguration des Minecraft ServerTap Plugins
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
              Server Host / Adresse
            </label>
            <input
              type="text"
              value={host}
              onChange={(e) => setHost(e.target.value)}
              placeholder="mchelden3.modrinth.gg"
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-800/80 border border-zinc-700 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                ServerTap Port
              </label>
              <input
                type="text"
                value={port}
                onChange={(e) => setPort(e.target.value)}
                placeholder="25809"
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-800/80 border border-zinc-700 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                Auto-Refresh
              </label>
              <select
                value={refreshInterval}
                onChange={(e) => setRefreshInterval(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-800/80 border border-zinc-700 text-sm text-white focus:outline-none focus:border-emerald-500"
              >
                <option value={5}>Alle 5 Sekunden</option>
                <option value={10}>Alle 10 Sekunden</option>
                <option value={30}>Alle 30 Sekunden</option>
                <option value={0}>Nur manuell</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
              ServerTap API Key
            </label>
            <input
              type="password"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="change_me"
              className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-800/80 border border-zinc-700 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500 font-mono"
              required
            />
            <p className="text-[11px] text-zinc-500 mt-1 flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5 text-zinc-400" />
              Wird sicher über den internen Express-Proxy übertragen.
            </p>
          </div>

          <div className="flex items-center justify-between pt-2">
            <span className="text-xs text-zinc-300 font-medium">
              Soundeffekte bei Spieler-Join/Aktionen
            </span>
            <input
              type="checkbox"
              checked={soundEnabled}
              onChange={(e) => setSoundEnabled(e.target.checked)}
              className="h-4 w-4 rounded border-zinc-700 text-emerald-500 focus:ring-emerald-500 bg-zinc-800 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-zinc-800">
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Zurücksetzen
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 rounded-xl text-xs font-medium text-zinc-300 hover:bg-zinc-800 transition-colors"
              >
                Abbrechen
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors shadow-sm"
              >
                <Save className="w-3.5 h-3.5" />
                Speichern
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
