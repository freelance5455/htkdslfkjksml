import React from 'react';
import { Settings, X, Volume2, VolumeX, RotateCcw, AlertTriangle, ShieldCheck, Sparkles } from 'lucide-react';
import { MatchSettings } from '../types';
import { toPersianDigits } from '../utils/snooker';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: MatchSettings;
  onUpdateSettings: (newSettings: Partial<MatchSettings>) => void;
  onResetFrame: () => void;
  onResetMatch: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onResetFrame,
  onResetMatch,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-md rounded-3xl bg-slate-900 border border-slate-700/80 p-5 shadow-2xl text-slate-100 flex flex-col max-h-[90vh] overflow-y-auto"
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-slate-800 text-slate-300 rounded-xl border border-slate-700">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">تنظیمات مسابقه</h2>
              <p className="text-xs text-slate-400">شخصی‌سازی قوانین و شرایط بازی</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Rule Mode Selection */}
        <div className="mb-4">
          <label className="block text-xs font-semibold text-slate-300 mb-2">حالت بازی و قوانین:</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({
                  ruleMode: 'custom',
                  redValue: 10,
                })
              }
              className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                settings.ruleMode === 'custom'
                  ? 'bg-emerald-950/40 border-emerald-500/60 text-emerald-300 shadow-md'
                  : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:bg-slate-800/40'
              }`}
            >
              <div className="flex items-center gap-1.5 font-bold text-xs mb-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>حالت سفارشی (قرمز = ۱۰)</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                مطابق کد پیش‌فرض، ضربه قرمز ۱۰ امتیاز و امکان کسر امتیاز خطا.
              </p>
            </button>

            <button
              type="button"
              onClick={() =>
                onUpdateSettings({
                  ruleMode: 'official',
                  redValue: 1,
                })
              }
              className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                settings.ruleMode === 'official'
                  ? 'bg-emerald-950/40 border-emerald-500/60 text-emerald-300 shadow-md'
                  : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:bg-slate-800/40'
              }`}
            >
              <div className="flex items-center gap-1.5 font-bold text-xs mb-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>قوانین رسمی اسنوکر (قرمز = ۱)</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                قرمز ۱ امتیاز، بریک استاندارد تا ۱۴۷ و جریمه خطا به حریف.
              </p>
            </button>
          </div>
        </div>

        {/* Number of Reds */}
        <div className="mb-4">
          <label className="block text-xs font-semibold text-slate-300 mb-2">تعداد توپ‌های قرمز:</label>
          <div className="grid grid-cols-3 gap-2">
            {[15, 10, 6].map((count) => (
              <button
                key={count}
                type="button"
                onClick={() =>
                  onUpdateSettings({
                    totalReds: count,
                    remainingReds: count,
                  })
                }
                className={`py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                  settings.totalReds === count
                    ? 'bg-emerald-600 text-white border-emerald-400'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                }`}
              >
                {toPersianDigits(count)} توپ {count === 15 ? '(کامل)' : ''}
              </button>
            ))}
          </div>
        </div>

        {/* Best of Frames */}
        <div className="mb-4">
          <label className="block text-xs font-semibold text-slate-300 mb-2">
            تعداد فریم‌های مسابقه (Best of):
          </label>
          <div className="grid grid-cols-5 gap-1.5">
            {[1, 3, 5, 7, 9].map((frames) => (
              <button
                key={frames}
                type="button"
                onClick={() => onUpdateSettings({ bestOfFrames: frames })}
                className={`py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                  settings.bestOfFrames === frames
                    ? 'bg-blue-600 text-white border-blue-400'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                }`}
              >
                {toPersianDigits(frames)} فریم
              </button>
            ))}
          </div>
        </div>

        {/* Sound toggle */}
        <div className="mb-5 bg-slate-950/40 border border-slate-800 p-3 rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            {settings.soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
            <span className="text-xs font-semibold text-slate-200">افکت‌های صوتی ضربات</span>
          </div>
          <button
            type="button"
            onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
            className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              settings.soundEnabled
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {settings.soundEnabled ? 'فعال' : 'غیرفعال'}
          </button>
        </div>

        {/* Reset Actions */}
        <div className="space-y-2 border-t border-slate-800 pt-3">
          <label className="block text-xs font-semibold text-slate-400">عملیات ریست:</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                if (window.confirm('آیا مایل به ریست کردن امتیازات فریم جاری هستید؟')) {
                  onResetFrame();
                  onClose();
                }
              }}
              className="py-2.5 bg-slate-800 hover:bg-slate-750 text-amber-300 border border-slate-700 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>ریست فریم جاری</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if (window.confirm('آیا مایل به ریست کامل کل مسابقه و همه فریم‌ها هستید؟')) {
                  onResetMatch();
                  onClose();
                }
              }}
              className="py-2.5 bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>ریست کل مسابقه</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-slate-800 text-center">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            تایید و بازگشت
          </button>
        </div>
      </div>
    </div>
  );
};
