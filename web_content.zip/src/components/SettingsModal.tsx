import React, { useRef, useState } from 'react';
import { useGame } from '../context/GameContext.tsx';
import { Settings, Download, Upload, RotateCcw, Clock, Sparkles, X } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const {
    player,
    setTimeSpeed,
    toggleRealtimeSync,
    exportSaveToJson,
    importSaveFromJson,
    resetGameData,
  } = useGame();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = importSaveFromJson(content);
        if (success) {
          setImportStatus('Nạp file dữ liệu JSON thành công! Đã khôi phục toàn bộ nông trại.');
          setTimeout(() => {
            setImportStatus(null);
            onClose();
          }, 1500);
        } else {
          setImportStatus('File JSON không hợp lệ! Vui lòng kiểm tra lại file đã xuất.');
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 animate-in fade-in">
      <div className="bg-stone-900 border-2 border-stone-700 rounded-3xl max-w-md w-full p-5 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-3">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-amber-300">Cài Đặt & Lưu Trữ Dữ Liệu</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-stone-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Time Speed Control */}
        <div className="space-y-1.5 text-xs">
          <label className="font-bold text-stone-300 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Tốc Độ Trôi Thời Gian Nông Trại:</span>
          </label>
          <div className="grid grid-cols-4 gap-2">
            {([1, 2, 5, 10] as const).map((spd) => (
              <button
                key={spd}
                type="button"
                onClick={() => setTimeSpeed(spd)}
                className={`py-2 rounded-xl font-black text-xs transition border ${
                  player.timeSpeed === spd
                    ? 'bg-amber-500 text-stone-950 border-amber-400 shadow-md ring-2 ring-amber-400/50'
                    : 'bg-stone-800 text-stone-300 border-stone-700 hover:bg-stone-750'
                }`}
              >
                {spd}x {spd === 1 ? '(Thực)' : ''}
              </button>
            ))}
          </div>
        </div>

        {/* Realtime clock toggle */}
        <div className="pt-2 border-t border-stone-800 text-xs">
          <label className="flex items-center justify-between cursor-pointer select-none bg-stone-950 p-2.5 rounded-xl border border-stone-800">
            <span className="text-stone-300 font-semibold">
              Đồng bộ 6 thời khắc theo giờ thực tế thiết bị
            </span>
            <input
              type="checkbox"
              checked={player.isRealtimeSync}
              onChange={toggleRealtimeSync}
              className="w-4 h-4 rounded text-amber-500 accent-amber-500 bg-stone-800 border-stone-600 focus:ring-0"
            />
          </label>
        </div>

        {/* Offline Backup & JSON Export/Import */}
        <div className="pt-2 border-t border-stone-800 space-y-2 text-xs">
          <div className="font-bold text-stone-300">Lưu Trữ An Toàn & Xuất/Nhập File:</div>
          <p className="text-[11px] text-stone-400">
            Game tự động lưu vào trình duyệt mỗi 5s và khi tắt màn hình. Bạn có thể xuất file .JSON để chuyển đổi giữa máy tính & điện thoại.
          </p>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={exportSaveToJson}
              className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 border border-amber-500/50 font-bold transition shadow"
            >
              <Download className="w-4 h-4" />
              <span>Xuất File .JSON</span>
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 font-bold transition"
            >
              <Upload className="w-4 h-4 text-emerald-400" />
              <span>Nạp File .JSON</span>
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>

          {importStatus && (
            <div className="p-2 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-300 text-xs font-semibold text-center animate-pulse">
              {importStatus}
            </div>
          )}
        </div>

        {/* Reset Game Section */}
        <div className="pt-2 border-t border-stone-800 text-xs space-y-2">
          {confirmReset ? (
            <div className="bg-rose-950/60 border border-rose-500/50 rounded-xl p-3 space-y-2">
              <p className="text-rose-200 font-bold text-xs text-center">
                Bạn có chắc chắn muốn xóa toàn bộ dữ liệu nông trại để bắt đầu lại từ Cấp 1 không?
              </p>
              <div className="flex justify-center gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="px-3 py-1 rounded-lg bg-stone-800 text-stone-300 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="button"
                  onClick={() => {
                    resetGameData();
                    setConfirmReset(false);
                    onClose();
                  }}
                  className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold"
                >
                  Xác Nhận Xóa Hết
                </button>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              className="w-full py-2 rounded-xl bg-stone-950 hover:bg-rose-950/40 text-rose-400 border border-rose-900/60 text-xs font-semibold transition flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Chơi Lại Từ Đầu (Reset Save)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
