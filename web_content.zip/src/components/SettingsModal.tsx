import React, { useState, useEffect } from 'react';
import {
  X,
  Sliders,
  Cpu,
  UserCheck,
  Brain,
  Palette,
  Sparkles,
  RotateCcw,
  Check,
  Info,
  Download,
  Upload,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Flame,
  Zap,
  Image as ImageIcon,
  ExternalLink,
  Layers,
  Trash2,
  Eye,
  Wand2,
  MessageSquare,
  Bot,
  User,
  Camera,
  Smile,
  Maximize,
} from 'lucide-react';
import { ChatSettings, ChatSession, SafetyBlockThreshold } from '../types/index.ts';
import {
  PERSONA_PRESETS,
  USER_PERSONA_PRESETS,
  BOT_AVATAR_PRESETS,
  USER_AVATAR_PRESETS,
} from '../utils/presets.ts';
import { DEFAULT_SETTINGS, compressAvatarImage } from '../utils/storage.ts';
import { SUPPORTED_MODELS, OPENROUTER_PRESET_MODELS } from '../utils/models.ts';
import { WALLPAPER_PRESETS } from '../utils/wallpapers.ts';
import { ImageStudioModal } from './ImageStudioModal.tsx';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  globalSettings: ChatSettings;
  currentSession: ChatSession | null;
  onSaveGlobal: (newSettings: ChatSettings) => void;
  onSaveSessionOverride: (override: Partial<ChatSettings> | null) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  globalSettings,
  currentSession,
  onSaveGlobal,
  onSaveSessionOverride,
}) => {
  const [activeTab, setActiveTab] = useState<
    'model' | 'safety' | 'background' | 'persona' | 'memory' | 'appearance'
  >('model');
  const [targetScope, setTargetScope] = useState<'global' | 'session'>('global');

  // Form state initialized from either session override or global
  const [formState, setFormState] = useState<ChatSettings>({ ...globalSettings });
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [modelCategory, setModelCategory] = useState<string>('Semua');
  const [customModelInput, setCustomModelInput] = useState<string>('');

  // Background & Image Studio States
  const [customBgUrl, setCustomBgUrl] = useState('');
  const [perchancePrompt, setPerchancePrompt] = useState('Cyberpunk neon rain aesthetic wallpaper 4k');
  const [isUploadingBg, setIsUploadingBg] = useState(false);
  const [isImageStudioOpen, setIsImageStudioOpen] = useState(false);
  const [quickGenLoading, setQuickGenLoading] = useState(false);

  // Avatar & Persona States
  const [showBotAvatarPicker, setShowBotAvatarPicker] = useState(false);
  const [showUserAvatarPicker, setShowUserAvatarPicker] = useState(false);

  const handleUploadBotAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressAvatarImage(file);
      setFormState((prev) => ({ ...prev, botAvatar: compressed }));
    } catch {
      alert('Gagal membaca file gambar.');
    }
  };

  const handleUploadUserAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressAvatarImage(file);
      setFormState((prev) => ({ ...prev, userAvatar: compressed }));
    } catch {
      alert('Gagal membaca file gambar.');
    }
  };

  const handleSelectUserPersonaPreset = (presetId: string) => {
    const p = USER_PERSONA_PRESETS.find((item) => item.id === presetId);
    if (!p) return;
    setFormState((prev) => ({
      ...prev,
      userPersona: p.persona,
    }));
  };

  useEffect(() => {
    if (isOpen) {
      if (currentSession?.customSettings && Object.keys(currentSession.customSettings).length > 0) {
        setTargetScope('session');
        setFormState({ ...globalSettings, ...currentSession.customSettings });
      } else {
        setTargetScope('global');
        setFormState({ ...globalSettings });
      }
    }
  }, [isOpen, currentSession, globalSettings]);

  if (!isOpen) return null;

  const handlePresetSelect = (presetId: string) => {
    const preset = PERSONA_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;

    setFormState((prev) => ({
      ...prev,
      systemInstruction: preset.systemInstruction,
      temperature: preset.temperature,
      topP: preset.topP || prev.topP,
      model: preset.recommendedModel || prev.model,
    }));
  };

  const handleSave = () => {
    if (targetScope === 'global') {
      onSaveGlobal(formState);
      if (currentSession) {
        onSaveSessionOverride(null);
      }
    } else {
      if (currentSession) {
        onSaveSessionOverride(formState);
      }
    }

    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 700);
  };

  const handleResetToDefault = () => {
    if (confirm('Kembalikan semua pengaturan ke nilai default awal?')) {
      setFormState({ ...DEFAULT_SETTINGS });
    }
  };

  // Export current settings JSON
  const handleExportConfig = () => {
    const blob = new Blob([JSON.stringify(formState, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexusai_config_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Import settings JSON
  const handleImportConfig = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        setFormState((prev) => ({ ...prev, ...parsed }));
        alert('Konfigurasi pengaturan berhasil diimpor!');
      } catch (err) {
        alert('File konfigurasi JSON tidak valid.');
      }
    };
    reader.readAsText(file);
  };

  // Upload photo from device for background
  const handleUploadBgFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 15 * 1024 * 1024) {
      alert('Ukuran file foto maksimal 15MB.');
      return;
    }
    setIsUploadingBg(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setFormState((prev) => ({
          ...prev,
          backgroundEnabled: true,
          backgroundType: 'upload',
          backgroundImageUrl: result,
          backgroundOpacity: prev.backgroundOpacity ?? 0.25,
          backgroundBlur: prev.backgroundBlur ?? 2,
        }));
      }
      setIsUploadingBg(false);
    };
    reader.onerror = () => {
      alert('Gagal membaca file gambar.');
      setIsUploadingBg(false);
    };
    reader.readAsDataURL(file);
  };

  // Open perchance.org generator with uncensored / sensor off prompt
  const handleOpenPerchance = () => {
    const baseUrl = 'https://perchance.org/ai-photo-generator';
    // If prompt is entered, open with prompt query or directly to photo generator
    const url = perchancePrompt.trim()
      ? `${baseUrl}#prompt=${encodeURIComponent(perchancePrompt.trim())}`
      : baseUrl;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const isSensorOff = !formState.safetyFilterEnabled || formState.safetyThreshold === 'BLOCK_NONE';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">Pusat Kendali Pengaturan AI</h2>
              <p className="text-xs text-slate-400">
                Kontrol penuh atas model, sensor AI, kreativitas, kepribadian, dan memori.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scope selector: Global vs Current Chat */}
        {currentSession && (
          <div className="px-5 py-2.5 bg-slate-950/80 border-b border-slate-800/80 flex items-center justify-between">
            <span className="text-xs text-slate-300 font-medium">Terapkan Pengaturan Ke:</span>
            <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-700/60">
              <button
                type="button"
                onClick={() => setTargetScope('global')}
                className={`px-3 py-1 rounded-md text-xs font-medium transition cursor-pointer ${
                  targetScope === 'global'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Global (Semua Chat)
              </button>
              <button
                type="button"
                onClick={() => setTargetScope('session')}
                className={`px-3 py-1 rounded-md text-xs font-medium transition cursor-pointer ${
                  targetScope === 'session'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Khusus Chat Ini
              </button>
            </div>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-3 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('model')}
            className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium border-b-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'model'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Model &amp; Kreativitas</span>
          </button>

          {/* NEW TAB: SENSOR & KEAMANAN AI */}
          <button
            onClick={() => setActiveTab('safety')}
            className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium border-b-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'safety'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span className="flex items-center gap-1">
              <span>Sensor AI</span>
              {isSensorOff ? (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              ) : (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              )}
            </span>
          </button>

          {/* TAB: LATAR BELAKANG & WALLPAPER */}
          <button
            onClick={() => setActiveTab('background')}
            className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium border-b-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'background'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span className="flex items-center gap-1">
              <span>Latar Belakang</span>
              {formState.backgroundEnabled && formState.backgroundImageUrl ? (
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
              ) : null}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('persona')}
            className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium border-b-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'persona'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Persona &amp; Peran</span>
          </button>

          <button
            onClick={() => setActiveTab('memory')}
            className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium border-b-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'memory'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Brain className="w-3.5 h-3.5" />
            <span>Memori &amp; Konteks</span>
          </button>

          <button
            onClick={() => setActiveTab('appearance')}
            className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium border-b-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'appearance'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Preferensi &amp; Backup</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-xs sm:text-sm">
          {/* TAB 1: MODEL & AI ENGINE */}
          {activeTab === 'model' && (
            <div className="space-y-4">
              {/* Model Selection */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="font-semibold text-slate-200">
                    Pilihan Model AI (Gemini &amp; Google Gemma)
                  </label>
                  <span className="text-[11px] text-slate-400">
                    Aktif: <strong className="text-indigo-400 font-mono">{formState.model}</strong>
                  </span>
                </div>

                {/* Model Category Filter Pills */}
                <div className="flex gap-1.5 overflow-x-auto pb-2 no-scrollbar">
                  {[
                    'Semua',
                    'Gemini 3 Series',
                    'Google Gemma (Open Weights)',
                    'Gemini 3.5 Series',
                    'Versi Stabil Produksi',
                  ].map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setModelCategory(cat)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer whitespace-nowrap ${
                        modelCategory === cat
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Models Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-1 max-h-60 overflow-y-auto pr-1">
                  {SUPPORTED_MODELS.filter(
                    (m) => modelCategory === 'Semua' || m.category === modelCategory
                  ).map((m) => (
                    <div
                      key={m.id}
                      onClick={() => setFormState({ ...formState, model: m.id })}
                      className={`p-3 rounded-xl border cursor-pointer transition flex flex-col justify-between ${
                        formState.model === m.id
                          ? 'bg-indigo-600/20 border-indigo-500 text-white ring-1 ring-indigo-500/40'
                          : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-xs truncate max-w-[160px]">{m.name}</span>
                          {m.badge && (
                            <span
                              className={`text-[10px] px-1.5 py-0.5 rounded font-medium shrink-0 ${
                                m.id.startsWith('gemma')
                                  ? 'bg-purple-950/80 border border-purple-500/50 text-purple-300'
                                  : formState.model === m.id
                                  ? 'bg-indigo-500 text-white'
                                  : 'bg-slate-750 text-slate-300'
                              }`}
                            >
                              {m.badge}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 line-clamp-2 leading-tight">
                          {m.description}
                        </p>
                      </div>
                      <div className="mt-2 pt-1.5 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                        <span>{m.id}</span>
                        <span>{m.contextWindowTokens ? `${(m.contextWindowTokens / 1000).toFixed(0)}k tok` : ''}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Custom Model Input */}
                <div className="mt-2.5 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center gap-2">
                  <span className="text-[11px] text-slate-400 shrink-0">Model Kustom:</span>
                  <input
                    type="text"
                    value={customModelInput}
                    onChange={(e) => setCustomModelInput(e.target.value)}
                    placeholder="Ketik model lain (misal: gemma-4-31b-it)..."
                    className="flex-1 bg-transparent text-xs text-white placeholder-slate-400 focus:outline-none"
                  />
                  <button
                    type="button"
                    disabled={!customModelInput.trim()}
                    onClick={() => {
                      if (customModelInput.trim()) {
                        setFormState({ ...formState, model: customModelInput.trim() });
                        setCustomModelInput('');
                      }
                    }}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs text-indigo-300 font-medium transition cursor-pointer"
                  >
                    Terapkan
                  </button>
                </div>
              </div>

              {/* Temperature Slider */}
              <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-slate-200">Temperatur (Kreativitas)</span>
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono text-xs font-bold">
                      {formState.temperature.toFixed(2)}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    {formState.temperature <= 0.3
                      ? '🎯 Sangat Presisi / Deterministik'
                      : formState.temperature <= 0.7
                      ? '⚖️ Seimbang & Alami (Direkomendasikan)'
                      : formState.temperature <= 1.2
                      ? '🎨 Kreatif & Variatif'
                      : '🔥 Sangat Eksperimental & Liar'}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="2"
                  step="0.05"
                  value={formState.temperature}
                  onChange={(e) =>
                    setFormState({ ...formState, temperature: parseFloat(e.target.value) })
                  }
                  className="w-full accent-indigo-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>0.0 (Tepat &amp; Kaku)</span>
                  <span>1.0 (Kreatif)</span>
                  <span>2.0 (Maksimal)</span>
                </div>
              </div>

              {/* Advanced Parameters: Top-P & Top-K */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-slate-300 text-xs">Top-P (Nucleus Sampling)</span>
                    <span className="font-mono text-xs text-sky-400">{formState.topP.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={formState.topP}
                    onChange={(e) => setFormState({ ...formState, topP: parseFloat(e.target.value) })}
                    className="w-full accent-sky-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                  <p className="text-[10px] text-slate-400">
                    Mengontrol keragaman token berdasarkan ambang kumulatif probabilitas.
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-slate-300 text-xs">Top-K</span>
                    <span className="font-mono text-xs text-purple-400">{formState.topK}</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="100"
                    step="1"
                    value={formState.topK}
                    onChange={(e) => setFormState({ ...formState, topK: parseInt(e.target.value) })}
                    className="w-full accent-purple-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                  <p className="text-[10px] text-slate-400">
                    Membatasi pemilihan ke K token teratas paling mungkin (default: 40).
                  </p>
                </div>
              </div>

              {/* Streaming Toggle */}
              <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200 text-xs">Streaming Jawaban AI</div>
                  <p className="text-[11px] text-slate-400">
                    Tampilkan kata demi kata secara real-time via Server-Sent Events (SSE).
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formState.streamResponse}
                    onChange={(e) =>
                      setFormState({ ...formState, streamResponse: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>
            </div>
          )}

          {/* TAB 2: SENSOR & KEAMANAN AI (SAFETY FILTER) */}
          {activeTab === 'safety' && (
            <div className="space-y-4">
              {/* Main Toggle: Aktifkan / Matikan Sensor AI */}
              <div className="p-4 rounded-xl bg-slate-850 border border-slate-750 flex items-center justify-between">
                <div className="pr-4">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-indigo-400" />
                    <span className="font-bold text-slate-100 text-sm">
                      Sensor AI (Safety Filter Moderation)
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Kontrol apakah AI menerapkan filter penyensoran otomatis terhadap topik sensitif,
                    konten dewasa/fiksi, atau bahasa ekspresif.
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={formState.safetyFilterEnabled}
                    onChange={(e) => {
                      const enabled = e.target.checked;
                      setFormState({
                        ...formState,
                        safetyFilterEnabled: enabled,
                        safetyThreshold: enabled ? 'BLOCK_MEDIUM_AND_ABOVE' : 'BLOCK_NONE',
                      });
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-12 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>

              {/* Status Banner */}
              {isSensorOff ? (
                <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-600/40 space-y-2">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-xs sm:text-sm">
                    <Flame className="w-4 h-4 text-amber-400" />
                    <span>Mode Tanpa Sensor Aktif (Unrestricted / Bebas)</span>
                  </div>
                  <p className="text-xs text-amber-200/80 leading-relaxed">
                    Semua filter keamanan Google disetel ke <code>BLOCK_NONE</code>. Model AI akan menjawab
                    dengan kebebasan penuh tanpa sensor otomatis untuk penulisan cerita kreatif, roleplay,
                    topik sensitif legal, atau diskusi tanpa filter.
                  </p>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-600/40 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs sm:text-sm">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Sensor AI Sedang Aktif (Tersaring)</span>
                  </div>
                  <p className="text-xs text-emerald-200/80 leading-relaxed">
                    Jawaban AI dimoderasi untuk mencegah konten berbahaya atau tidak pantas sesuai dengan
                    tingkat ambang batas yang Anda pilih di bawah.
                  </p>
                </div>
              )}

              {/* Threshold Selection (when Sensor is ON) */}
              {formState.safetyFilterEnabled && (
                <div>
                  <label className="block font-semibold text-slate-200 mb-2">
                    Pilih Tingkat Sensor (Ambang Batas Moderasi)
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {[
                      {
                        id: 'BLOCK_ONLY_HIGH',
                        title: 'Sensor Ringan',
                        tag: 'Minimal',
                        desc: 'Hanya memblokir konten yang terbukti sangat berbahaya.',
                      },
                      {
                        id: 'BLOCK_MEDIUM_AND_ABOVE',
                        title: 'Sensor Standar',
                        tag: 'Rekomendasi',
                        desc: 'Penyaringan seimbang bawaan untuk percakapan sehari-hari.',
                      },
                      {
                        id: 'BLOCK_LOW_AND_ABOVE',
                        title: 'Sensor Ketat',
                        tag: 'Maksimal',
                        desc: 'Sangat ketat, cocok untuk lingkungan anak atau formal.',
                      },
                    ].map((th) => (
                      <div
                        key={th.id}
                        onClick={() =>
                          setFormState({
                            ...formState,
                            safetyThreshold: th.id as SafetyBlockThreshold,
                          })
                        }
                        className={`p-3 rounded-xl border cursor-pointer transition ${
                          formState.safetyThreshold === th.id
                            ? 'bg-indigo-600/20 border-indigo-500 text-white'
                            : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-xs">{th.title}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-700 text-slate-200 font-medium">
                            {th.tag}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-tight">{th.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Anti-Refusal Directive (OpenRouter Style) */}
              <div className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-750 flex items-start justify-between gap-3">
                <div className="pr-2">
                  <div className="flex items-center gap-1.5 font-bold text-xs text-amber-300">
                    <Zap className="w-3.5 h-3.5" />
                    <span>Protokol Anti-Penolakan (Gaya OpenRouter)</span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                    Secara otomatis menyuntikkan instruksi khusus di prompt sistem yang melarang model AI
                    mengeluarkan kalimat penolakan (seperti <em>&quot;Maaf, saya tidak dapat membantu...&quot;</em> atau <em>&quot;Sebagai model AI...&quot;</em>).
                    Inilah alasan mengapa model yang sama di OpenRouter bisa menjawab tanpa penolakan sama sekali.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-0.5">
                  <input
                    type="checkbox"
                    checked={formState.antiRefusalBypassEnabled}
                    onChange={(e) =>
                      setFormState({ ...formState, antiRefusalBypassEnabled: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                </label>
              </div>

              {/* Provider Options (Google vs OpenRouter) */}
              <div className="p-4 rounded-xl bg-slate-850 border border-slate-750 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-xs text-slate-200">
                    Pilihan Mesin Pemroses (Provider AI)
                  </div>
                  <span className="text-[10px] text-slate-400">Google Gemini atau OpenRouter</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div
                    onClick={() => setFormState({ ...formState, provider: 'gemini' })}
                    className={`p-3 rounded-xl border cursor-pointer transition ${
                      formState.provider !== 'openrouter'
                        ? 'bg-indigo-600/20 border-indigo-500 text-white ring-1 ring-indigo-500/40'
                        : 'bg-slate-800/40 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="font-bold text-xs">Google AI Studio (Bawaan)</div>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Gratis langsung pakai. Model Gemini &amp; Gemma dengan directive anti-refusal.
                    </p>
                  </div>

                  <div
                    onClick={() => setFormState({ ...formState, provider: 'openrouter' })}
                    className={`p-3 rounded-xl border cursor-pointer transition ${
                      formState.provider === 'openrouter'
                        ? 'bg-indigo-600/20 border-indigo-500 text-white ring-1 ring-indigo-500/40'
                        : 'bg-slate-800/40 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="font-bold text-xs">Koneksi OpenRouter Sendiri</div>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Gunakan API Key OpenRouter pribadi untuk akses tanpa sensor ke model apa pun.
                    </p>
                  </div>
                </div>

                {formState.provider === 'openrouter' && (
                  <div className="space-y-2.5 pt-2 border-t border-slate-800">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[11px] font-medium text-slate-300">
                          OpenRouter API Key (Tersimpan aman 100% lokal di browser):
                        </label>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              const inputEl = document.getElementById('openrouter-key-input') as HTMLInputElement;
                              if (inputEl) {
                                inputEl.type = inputEl.type === 'password' ? 'text' : 'password';
                              }
                            }}
                            className="text-[10px] text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
                          >
                            Tampilkan / Sembunyikan
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          id="openrouter-key-input"
                          type="password"
                          value={formState.openRouterApiKey || ''}
                          onChange={(e) =>
                            setFormState({ ...formState, openRouterApiKey: e.target.value })
                          }
                          placeholder="sk-or-v1-..."
                          className="flex-1 bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
                        />
                        <button
                          type="button"
                          onClick={async () => {
                            const key = formState.openRouterApiKey?.trim();
                            if (!key) {
                              alert('Masukkan OpenRouter API Key terlebih dahulu.');
                              return;
                            }
                            try {
                              const res = await fetch('https://openrouter.ai/api/v1/auth/key', {
                                headers: { Authorization: `Bearer ${key}` },
                              });
                              if (res.ok) {
                                const data = await res.json();
                                alert(`API Key Valid! Akun: ${data.data?.label || 'Terhubung'}${data.data?.limit ? ` (Limit: $${data.data.limit})` : ''}`);
                              } else {
                                const err = await res.json().catch(() => ({}));
                                alert(`API Key Gagal: ${err.error?.message || 'Unauthorized / Key tidak valid'}`);
                              }
                            } catch (e: any) {
                              alert(`Gagal menguji koneksi: ${e.message || 'Network error'}`);
                            }
                          }}
                          className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium shrink-0 transition cursor-pointer shadow-xs"
                        >
                          Test Koneksi
                        </button>
                      </div>
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-300 mb-1">
                        Model ID OpenRouter:
                      </label>
                      <input
                        type="text"
                        value={formState.openRouterModel || formState.model}
                        onChange={(e) => {
                          setFormState({
                            ...formState,
                            openRouterModel: e.target.value,
                            model: e.target.value,
                          });
                        }}
                        placeholder="Contoh: google/gemini-2.0-flash-exp:free atau meta-llama/llama-3.3-70b-instruct"
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
                      />
                      <div className="mt-1.5 flex flex-wrap gap-1.5">
                        {OPENROUTER_PRESET_MODELS.map((preset) => (
                          <button
                            key={preset.id}
                            type="button"
                            onClick={() => {
                              setFormState({
                                ...formState,
                                openRouterModel: preset.id,
                                model: preset.id,
                              });
                            }}
                            className={`px-2 py-1 rounded-md text-[10px] font-mono transition cursor-pointer border ${
                              (formState.openRouterModel || formState.model) === preset.id
                                ? 'bg-indigo-600/30 border-indigo-500 text-indigo-300'
                                : 'bg-slate-900 border-slate-750 text-slate-400 hover:text-slate-200 hover:border-slate-600'
                            }`}
                            title={preset.description}
                          >
                            {preset.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Categories Covered */}
              <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2">
                <span className="font-semibold text-slate-200 text-xs">
                  Kategori yang Dikontrol Pengaturan Sensor:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-300">
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                    <span>Pelecehan (Harassment)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                    <span>Ujaran Kebencian (Hate Speech)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                    <span>Konten Seksual &amp; Dewasa (Sexually Explicit)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                    <span>Konten Berbahaya (Dangerous Content)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                    <span>Integritas Sipil &amp; Publik (Civic Integrity)</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: LATAR BELAKANG & WALLPAPER */}
          {activeTab === 'background' && (
            <div className="space-y-4">
              {/* Main Toggle Switch */}
              <div className="p-4 rounded-xl bg-slate-850 border border-slate-750 flex items-center justify-between">
                <div className="pr-4">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-indigo-400" />
                    <span className="font-bold text-slate-100 text-sm">
                      Aktifkan Wallpaper Latar Belakang Chat
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Tampilkan foto kustom, gambar AI bebas tanpa sensor dari Perchance.org, atau wallpaper preset di latar belakang layar obrolan.
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={Boolean(formState.backgroundEnabled)}
                    onChange={(e) =>
                      setFormState({
                        ...formState,
                        backgroundEnabled: e.target.checked,
                        // If enabled but no URL set yet, pick first preset by default
                        backgroundImageUrl:
                          formState.backgroundImageUrl || WALLPAPER_PRESETS[0].url,
                        backgroundType: formState.backgroundType || 'preset',
                      })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-12 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>

              {/* Active Background Preview */}
              {formState.backgroundEnabled && formState.backgroundImageUrl && (
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                      <Eye className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Pratinjau Wallpaper Aktif:</span>
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setFormState({
                          ...formState,
                          backgroundEnabled: false,
                          backgroundImageUrl: '',
                          backgroundType: 'none',
                        })
                      }
                      className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 transition cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Hapus Background</span>
                    </button>
                  </div>
                  <div className="relative min-h-[160px] w-full rounded-xl overflow-hidden border border-slate-700/80 bg-slate-950 flex flex-col justify-between p-3.5">
                    {/* Background wallpaper layer */}
                    <img
                      src={formState.backgroundImageUrl}
                      alt="Wallpaper preview"
                      className="absolute inset-0 w-full h-full object-cover transition"
                      style={{
                        opacity: formState.backgroundOpacity ?? 0.25,
                        filter: `blur(${formState.backgroundBlur ?? 2}px)`,
                      }}
                    />

                    {/* Live Mock Chat Bubbles Simulation */}
                    <div className="relative z-10 space-y-2 max-w-md w-full mx-auto">
                      {/* User Bubble simulation */}
                      <div className="flex justify-end">
                        <div
                          className="px-3 py-1.5 rounded-2xl rounded-tr-xs border border-slate-700/60 shadow-xs max-w-[85%] transition"
                          style={{
                            backgroundColor: `rgba(30, 41, 59, ${formState.bubbleOpacity ?? 0.85})`,
                            backdropFilter: (formState.bubbleBlur ?? 0) > 0 ? `blur(${formState.bubbleBlur}px)` : undefined,
                            WebkitBackdropFilter: (formState.bubbleBlur ?? 0) > 0 ? `blur(${formState.bubbleBlur}px)` : undefined,
                          }}
                        >
                          <div className="text-[11px] font-medium text-slate-100">
                            Bagaimana tampilan opasitas &amp; blur bubble chat ini?
                          </div>
                          <div className="text-[9px] text-slate-400 text-right mt-0.5">10:42</div>
                        </div>
                      </div>

                      {/* AI Bubble simulation */}
                      <div className="flex justify-start">
                        <div
                          className="px-3.5 py-2 rounded-2xl rounded-tl-xs border border-slate-800/80 shadow-xs max-w-[90%] transition"
                          style={{
                            backgroundColor: `rgba(15, 23, 42, ${formState.bubbleOpacity ?? 0.85})`,
                            backdropFilter: (formState.bubbleBlur ?? 0) > 0 ? `blur(${formState.bubbleBlur}px)` : undefined,
                            WebkitBackdropFilter: (formState.bubbleBlur ?? 0) > 0 ? `blur(${formState.bubbleBlur}px)` : undefined,
                          }}
                        >
                          <div className="text-[10px] font-bold text-indigo-300 flex items-center gap-1 mb-0.5">
                            <Bot className="w-3 h-3 text-indigo-400" />
                            <span>Nexus AI</span>
                          </div>
                          <div className="text-[11px] text-slate-100 leading-relaxed">
                            Wallpaper di belakang terlihat jernih dengan blur {formState.bubbleBlur ?? 0}px, dan teks chat tetap 100% pekat!
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Stats pill at bottom */}
                    <div className="relative z-10 self-center mt-2 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-center">
                      <p className="text-[10px] text-slate-300 font-mono">
                        Wallpaper: {Math.round((formState.backgroundOpacity ?? 0.25) * 100)}% (Blur {formState.backgroundBlur ?? 2}px) • Bubble: {Math.round((formState.bubbleOpacity ?? 0.85) * 100)}% (Blur {formState.bubbleBlur ?? 0}px)
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* SECTION 1: UPLOAD FOTO DARI PERANGKAT */}
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-xs sm:text-sm text-slate-200 flex items-center gap-2">
                      <Upload className="w-4 h-4 text-emerald-400" />
                      <span>Opsi 1: Unggah Foto Pribadi</span>
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Pilih foto atau wallpaper dari komputer / galeri HP Anda (JPG, PNG, WEBP).
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <label className="flex-1 flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-750 hover:border-indigo-500 rounded-xl bg-slate-900/60 hover:bg-slate-900 cursor-pointer transition text-center group">
                    <Upload className="w-6 h-6 text-slate-400 group-hover:text-indigo-400 mb-1 transition" />
                    <span className="text-xs font-semibold text-slate-300 group-hover:text-white">
                      {isUploadingBg ? 'Sedang Memproses Foto...' : 'Pilih Foto dari Perangkat'}
                    </span>
                    <span className="text-[10px] text-slate-400 mt-0.5">
                      Maksimal 15MB • Disimpan 100% lokal di browser Anda
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleUploadBgFile}
                      className="hidden"
                      disabled={isUploadingBg}
                    />
                  </label>
                </div>
              </div>

              {/* SECTION 2: GENERATE GAMBAR PERCHANCE.ORG (SENSOR OFF) */}
              <div className="p-4 rounded-xl bg-gradient-to-br from-indigo-950/40 via-purple-950/30 to-slate-900 border border-indigo-500/40 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <h3 className="font-bold text-xs sm:text-sm text-white">
                        Opsi 2: Generate Gambar Bebas via Perchance.org (Sensor Off)
                      </h3>
                    </div>
                    <p className="text-[11px] text-indigo-200/80 mt-1 leading-relaxed">
                      Website <strong>perchance.org</strong> menyediakan AI image generator gratis tanpa batas, tanpa daftar/login, dan dengan <strong>sensor off</strong> sehingga gambar yang dihasilkan bisa bebas tanpa batasan konten.
                    </p>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 shrink-0">
                    Bebas / Sensor Off
                  </span>
                </div>

                {/* Prompt field for Perchance */}
                <div className="space-y-2 pt-1">
                  <label className="block text-[11px] font-medium text-slate-300">
                    Ketik Ide / Prompt Gambar (Opsional):
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={perchancePrompt}
                      onChange={(e) => setPerchancePrompt(e.target.value)}
                      placeholder="Contoh: cyberpunk neon rain aesthetic, anime fantasy room, dark moody landscape..."
                      className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                    />
                    <button
                      type="button"
                      onClick={handleOpenPerchance}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-md shadow-indigo-600/30 transition cursor-pointer shrink-0"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Buka Perchance.org</span>
                    </button>
                  </div>

                  {/* Quick prompt suggestions */}
                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    <span className="text-[10px] text-slate-400 self-center">Inspirasi Prompt:</span>
                    {[
                      'cyberpunk city neon rain',
                      'anime sunset lofi room',
                      'deep cosmic galaxy nebula',
                      'dark fantasy mystical forest',
                    ].map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setPerchancePrompt(p)}
                        className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-750 text-[10px] text-slate-300 font-mono transition cursor-pointer"
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Paste URL from Perchance */}
                <div className="pt-2 border-t border-indigo-900/40 space-y-1.5">
                  <label className="block text-[11px] font-medium text-slate-300">
                    Tempelkan Link URL Gambar Hasil dari Perchance / Web:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customBgUrl}
                      onChange={(e) => setCustomBgUrl(e.target.value)}
                      placeholder="https://... (Salin alamat gambar dari Perchance atau web apa pun)"
                      className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500 font-mono"
                    />
                    <button
                      type="button"
                      disabled={!customBgUrl.trim()}
                      onClick={() => {
                        if (customBgUrl.trim()) {
                          setFormState({
                            ...formState,
                            backgroundEnabled: true,
                            backgroundType: 'perchance',
                            backgroundImageUrl: customBgUrl.trim(),
                            backgroundOpacity: formState.backgroundOpacity ?? 0.25,
                            backgroundBlur: formState.backgroundBlur ?? 2,
                          });
                          setCustomBgUrl('');
                        }
                      }}
                      className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-xs font-semibold text-white shadow-md shadow-emerald-600/30 transition cursor-pointer shrink-0"
                    >
                      Terapkan URL
                    </button>
                  </div>
                </div>
              </div>

              {/* SECTION 3: PRESET WALLPAPER SIAP PAKAI */}
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-xs sm:text-sm text-slate-200 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-sky-400" />
                    <span>Opsi 3: Koleksi Wallpaper Preset Siap Pakai</span>
                  </h3>
                  <span className="text-[11px] text-slate-400">1-Klik Terapkan</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {WALLPAPER_PRESETS.map((wp) => (
                    <div
                      key={wp.id}
                      onClick={() =>
                        setFormState({
                          ...formState,
                          backgroundEnabled: true,
                          backgroundType: 'preset',
                          backgroundImageUrl: wp.url,
                          backgroundOpacity: formState.backgroundOpacity ?? 0.25,
                          backgroundBlur: formState.backgroundBlur ?? 2,
                        })
                      }
                      className={`group relative h-20 rounded-xl overflow-hidden border cursor-pointer transition ${
                        formState.backgroundImageUrl === wp.url
                          ? 'border-indigo-500 ring-2 ring-indigo-500/50'
                          : 'border-slate-700/70 hover:border-slate-500'
                      }`}
                    >
                      <img
                        src={wp.thumbnail}
                        alt={wp.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-2">
                        <span className="text-[11px] font-bold text-white leading-tight truncate">
                          {wp.name}
                        </span>
                        <span className="text-[9px] text-slate-300 font-mono">{wp.category}</span>
                      </div>
                      {formState.backgroundImageUrl === wp.url && (
                        <div className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-indigo-600 flex items-center justify-center text-white">
                          <Check className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* SECTION 4: KONTROL OPASITAS & BLUR */}
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-xs sm:text-sm text-slate-200 flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-indigo-400" />
                    <span>Pengaturan Kenyamanan Visual (Opasitas &amp; Blur)</span>
                  </h3>
                  <span className="text-[11px] text-slate-400">Kontras &amp; Keterbacaan Teks</span>
                </div>

                {/* Opacity Slider for Wallpaper */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-slate-300">
                      Tingkat Opasitas Latar (Wallpaper):
                    </span>
                    <span className="font-mono text-indigo-400 font-bold">
                      {Math.round((formState.backgroundOpacity ?? 0.25) * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.05"
                    max="0.80"
                    step="0.05"
                    value={formState.backgroundOpacity ?? 0.25}
                    onChange={(e) =>
                      setFormState({
                        ...formState,
                        backgroundOpacity: parseFloat(e.target.value),
                      })
                    }
                    className="w-full accent-indigo-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>5% (Sangat Halus)</span>
                    <span>25% (Rekomendasi Kontras Teks)</span>
                    <span>80% (Pekat)</span>
                  </div>
                </div>

                {/* Blur Slider for Wallpaper */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-slate-300">
                      Efek Blur (Kelembutan Latar):
                    </span>
                    <span className="font-mono text-sky-400 font-bold">
                      {formState.backgroundBlur ?? 2}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="15"
                    step="1"
                    value={formState.backgroundBlur ?? 2}
                    onChange={(e) =>
                      setFormState({
                        ...formState,
                        backgroundBlur: parseInt(e.target.value) || 0,
                      })
                    }
                    className="w-full accent-sky-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>0px (Tajam)</span>
                    <span>2-4px (Estetik &amp; Mudah Dibaca)</span>
                    <span>15px (Sangat Kabur)</span>
                  </div>
                </div>

                {/* Opacity Slider for Chat Bubbles */}
                <div className="space-y-2.5 pt-3 border-t border-slate-750">
                  <div className="flex justify-between items-center text-xs">
                    <div className="flex items-center gap-1.5">
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="font-semibold text-slate-200">
                        Opasitas Bubble Chat (Kotak Pesan):
                      </span>
                    </div>
                    <span className="font-mono text-emerald-400 font-bold">
                      {Math.round((formState.bubbleOpacity ?? 0.85) * 100)}%
                    </span>
                  </div>

                  {/* Clarification banner: Text is 100% solid & readable */}
                  <div className="flex items-start gap-2 p-2.5 rounded-xl bg-emerald-950/25 border border-emerald-500/30 text-[11px] text-emerald-200/90 leading-relaxed">
                    <Info className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>
                      <strong>Teks Tidak Terpengaruh:</strong> Hanya warna latar kotak percakapan (bubble) yang menjadi transparan tembus pandang ke wallpaper. <strong>Teks isi chat tetap 100% solid, tajam, dan tidak pudar.</strong>
                    </span>
                  </div>

                  <input
                    type="range"
                    min="0.10"
                    max="1.00"
                    step="0.05"
                    value={formState.bubbleOpacity ?? 0.85}
                    onChange={(e) =>
                      setFormState({
                        ...formState,
                        bubbleOpacity: parseFloat(e.target.value),
                      })
                    }
                    className="w-full accent-emerald-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>10% (Glassy / Tembus Pandang)</span>
                    <span>50% (Semi-Transparan)</span>
                    <span>85% (Bawaan Seimbang)</span>
                    <span>100% (Solid / Pekat)</span>
                  </div>

                  {/* Preset quick buttons */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                    <span className="text-[10px] text-slate-400">Pilihan Cepat:</span>
                    {[
                      { label: 'Tembus (20%)', val: 0.20 },
                      { label: 'Efek Kaca (50%)', val: 0.50 },
                      { label: 'Seimbang (85%)', val: 0.85 },
                      { label: 'Pekat Penuh (100%)', val: 1.00 },
                    ].map((preset) => (
                      <button
                        key={preset.val}
                        type="button"
                        onClick={() =>
                          setFormState({
                            ...formState,
                            bubbleOpacity: preset.val,
                          })
                        }
                        className={`px-2.5 py-1 rounded-md text-[10px] transition cursor-pointer border ${
                          Math.abs((formState.bubbleOpacity ?? 0.85) - preset.val) < 0.01
                            ? 'bg-emerald-600/30 border-emerald-500 text-emerald-300 font-semibold shadow-xs'
                            : 'bg-slate-800/80 border-slate-700/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Blur Slider for Chat Bubbles */}
                <div className="space-y-2 pt-3 border-t border-slate-750">
                  <div className="flex justify-between items-center text-xs">
                    <div className="flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                      <span className="font-semibold text-slate-200">
                        Efek Blur Bubble Chat (Kejernihan Wallpaper):
                      </span>
                    </div>
                    <span className="font-mono text-teal-400 font-bold">
                      {formState.bubbleBlur ?? 0}px
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Setel ke <strong>0px (Jernih / Tanpa Blur)</strong> agar wallpaper di balik kotak chat terlihat jelas tanpa kabur, atau naikkan bila ingin efek kaca es (frosted glass).
                  </p>
                  <input
                    type="range"
                    min="0"
                    max="16"
                    step="1"
                    value={formState.bubbleBlur ?? 0}
                    onChange={(e) =>
                      setFormState({
                        ...formState,
                        bubbleBlur: parseInt(e.target.value) || 0,
                      })
                    }
                    className="w-full accent-teal-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span className="text-teal-300 font-medium">0px (Jernih &amp; Terlihat Jelas)</span>
                    <span>2px (Halus)</span>
                    <span>6px (Kaca Es)</span>
                    <span>16px (Sangat Buram)</span>
                  </div>

                  {/* Preset quick buttons for Bubble Blur */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                    <span className="text-[10px] text-slate-400">Pilihan Cepat:</span>
                    {[
                      { label: 'Jernih (0px)', val: 0 },
                      { label: 'Halus (2px)', val: 2 },
                      { label: 'Kaca Es (6px)', val: 6 },
                      { label: 'Buram (10px)', val: 10 },
                    ].map((preset) => (
                      <button
                        key={preset.val}
                        type="button"
                        onClick={() =>
                          setFormState({
                            ...formState,
                            bubbleBlur: preset.val,
                          })
                        }
                        className={`px-2.5 py-1 rounded-md text-[10px] transition cursor-pointer border ${
                          (formState.bubbleBlur ?? 0) === preset.val
                            ? 'bg-teal-600/30 border-teal-500 text-teal-300 font-semibold shadow-xs'
                            : 'bg-slate-800/80 border-slate-700/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: PERSONA, FOTO AVATAR & PROFIL ROLEPLAY */}
          {activeTab === 'persona' && (
            <div className="space-y-5">
              {/* SECTION 1: FOTO PROFIL & IDENTITAS (BOT & USER) */}
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-750">
                  <div>
                    <h3 className="font-bold text-xs sm:text-sm text-slate-100 flex items-center gap-2">
                      <Camera className="w-4 h-4 text-indigo-400" />
                      <span>Foto Profil &amp; Identitas (Bot &amp; Pengguna)</span>
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Ganti foto profil bot dan Anda menggunakan file foto dari HP/komputer, link gambar, atau avatar preset.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* KARTU FOTO BOT */}
                  <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-750 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-xs text-indigo-300 flex items-center gap-1.5">
                        <Bot className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Karakter Bot AI</span>
                      </span>
                      <span className="text-[10px] text-slate-400">Avatar Lawan Bicara</span>
                    </div>

                    <div className="flex items-center gap-3">
                      {/* Avatar Preview */}
                      <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-sky-500 border-2 border-indigo-500/50 flex items-center justify-center overflow-hidden shadow-md shrink-0">
                        {formState.botAvatar && (formState.botAvatar.startsWith('data:') || formState.botAvatar.startsWith('http')) ? (
                          <img
                            src={formState.botAvatar}
                            alt="Bot Avatar"
                            className="w-full h-full object-cover"
                          />
                        ) : formState.botAvatar ? (
                          <span className="text-2xl">{formState.botAvatar}</span>
                        ) : (
                          <Bot className="w-7 h-7 text-white" />
                        )}
                      </div>

                      {/* Upload / Pick Actions */}
                      <div className="flex-1 space-y-1.5">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {/* File input for Bot */}
                          <input
                            id="bot-photo-upload"
                            type="file"
                            accept="image/*"
                            onChange={handleUploadBotAvatar}
                            className="hidden"
                          />
                          <label
                            htmlFor="bot-photo-upload"
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-medium transition cursor-pointer shadow-xs"
                          >
                            <Upload className="w-3 h-3" />
                            <span>Unggah Foto</span>
                          </label>

                          <button
                            type="button"
                            onClick={() => setShowBotAvatarPicker(!showBotAvatarPicker)}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 text-[11px] font-medium transition cursor-pointer"
                          >
                            <Sparkles className="w-3 h-3 text-sky-400" />
                            <span>Katalog Avatar</span>
                          </button>

                          {formState.botAvatar && (
                            <button
                              type="button"
                              onClick={() => setFormState({ ...formState, botAvatar: '🤖' })}
                              title="Kembalikan ke emoji default"
                              className="p-1 rounded-lg hover:bg-rose-950/50 text-slate-400 hover:text-rose-400 transition cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400">
                          Format JPG, PNG, WEBP (Maks 8MB, disimpan lokal)
                        </p>
                      </div>
                    </div>

                    {/* Collapsible Bot Avatar Preset Catalog */}
                    {showBotAvatarPicker && (
                      <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-semibold text-slate-300">Pilih Avatar Bot Keren:</span>
                          <button
                            type="button"
                            onClick={() => setShowBotAvatarPicker(false)}
                            className="text-slate-400 hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="grid grid-cols-3 gap-1.5">
                          {BOT_AVATAR_PRESETS.map((avatar) => (
                            <button
                              key={avatar.id}
                              type="button"
                              onClick={() => {
                                setFormState({ ...formState, botAvatar: avatar.url });
                                setShowBotAvatarPicker(false);
                              }}
                              className={`p-1.5 rounded-lg border flex flex-col items-center gap-1 transition cursor-pointer ${
                                formState.botAvatar === avatar.url
                                  ? 'bg-indigo-600/30 border-indigo-500'
                                  : 'bg-slate-900 border-slate-800 hover:bg-slate-800 hover:border-slate-700'
                              }`}
                            >
                              <div className="w-9 h-9 rounded-md overflow-hidden bg-slate-950 border border-slate-700">
                                <img src={avatar.url} alt={avatar.name} className="w-full h-full object-cover" />
                              </div>
                              <span className="text-[10px] text-slate-300 font-medium truncate max-w-full">
                                {avatar.name}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Bot Name and URL input */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      <div>
                        <label className="block text-[11px] font-medium text-slate-300 mb-1">
                          Nama Bot AI:
                        </label>
                        <input
                          type="text"
                          value={formState.botName}
                          onChange={(e) => setFormState({ ...formState, botName: e.target.value })}
                          className="w-full bg-slate-950 border border-slate-750 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                          placeholder="Nexus AI"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-medium text-slate-300 mb-1">
                          Link Foto / Emoji Bot:
                        </label>
                        <input
                          type="text"
                          value={formState.botAvatar?.startsWith('data:') ? 'Foto Lokal (Base64)' : (formState.botAvatar || '')}
                          disabled={formState.botAvatar?.startsWith('data:')}
                          onChange={(e) => setFormState({ ...formState, botAvatar: e.target.value })}
                          className="w-full bg-slate-950 border border-slate-750 disabled:opacity-75 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                          placeholder="URL foto atau emoji 🤖"
                        />
                      </div>
                    </div>
                  </div>

                  {/* KARTU FOTO PENGGUNA (USER) */}
                  <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-750 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-xs text-emerald-300 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Profil Pengguna (Anda)</span>
                      </span>
                      <span className="text-[10px] text-slate-400">Avatar Anda di Chat</span>
                    </div>

                    <div className="flex items-center gap-3">
                      {/* Avatar Preview */}
                      <div className="relative w-14 h-14 rounded-2xl bg-slate-800 border-2 border-emerald-500/50 flex items-center justify-center overflow-hidden shadow-md shrink-0">
                        {formState.userAvatar && (formState.userAvatar.startsWith('data:') || formState.userAvatar.startsWith('http')) ? (
                          <img
                            src={formState.userAvatar}
                            alt="User Avatar"
                            className="w-full h-full object-cover"
                          />
                        ) : formState.userAvatar ? (
                          <span className="text-2xl">{formState.userAvatar}</span>
                        ) : (
                          <User className="w-7 h-7 text-slate-300" />
                        )}
                      </div>

                      {/* Upload / Pick Actions */}
                      <div className="flex-1 space-y-1.5">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {/* File input for User */}
                          <input
                            id="user-photo-upload"
                            type="file"
                            accept="image/*"
                            onChange={handleUploadUserAvatar}
                            className="hidden"
                          />
                          <label
                            htmlFor="user-photo-upload"
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-medium transition cursor-pointer shadow-xs"
                          >
                            <Upload className="w-3 h-3" />
                            <span>Unggah Foto</span>
                          </label>

                          <button
                            type="button"
                            onClick={() => setShowUserAvatarPicker(!showUserAvatarPicker)}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 text-[11px] font-medium transition cursor-pointer"
                          >
                            <Sparkles className="w-3 h-3 text-emerald-400" />
                            <span>Katalog Avatar</span>
                          </button>

                          {formState.userAvatar && (
                            <button
                              type="button"
                              onClick={() => setFormState({ ...formState, userAvatar: '' })}
                              title="Hapus foto pengguna"
                              className="p-1 rounded-lg hover:bg-rose-950/50 text-slate-400 hover:text-rose-400 transition cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400">
                          Format JPG, PNG, WEBP (Maks 8MB, disimpan lokal)
                        </p>
                      </div>
                    </div>

                    {/* Collapsible User Avatar Preset Catalog */}
                    {showUserAvatarPicker && (
                      <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-semibold text-slate-300">Pilih Avatar Karakter Anda:</span>
                          <button
                            type="button"
                            onClick={() => setShowUserAvatarPicker(false)}
                            className="text-slate-400 hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="grid grid-cols-3 gap-1.5">
                          {USER_AVATAR_PRESETS.map((avatar) => (
                            <button
                              key={avatar.id}
                              type="button"
                              onClick={() => {
                                setFormState({ ...formState, userAvatar: avatar.url });
                                setShowUserAvatarPicker(false);
                              }}
                              className={`p-1.5 rounded-lg border flex flex-col items-center gap-1 transition cursor-pointer ${
                                formState.userAvatar === avatar.url
                                  ? 'bg-emerald-600/30 border-emerald-500'
                                  : 'bg-slate-900 border-slate-800 hover:bg-slate-800 hover:border-slate-700'
                              }`}
                            >
                              <div className="w-9 h-9 rounded-md overflow-hidden bg-slate-950 border border-slate-700">
                                <img src={avatar.url} alt={avatar.name} className="w-full h-full object-cover" />
                              </div>
                              <span className="text-[10px] text-slate-300 font-medium truncate max-w-full">
                                {avatar.name}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* User Name and URL input */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      <div>
                        <label className="block text-[11px] font-medium text-slate-300 mb-1">
                          Nama Panggilan Anda:
                        </label>
                        <input
                          type="text"
                          value={formState.userName}
                          onChange={(e) => setFormState({ ...formState, userName: e.target.value })}
                          className="w-full bg-slate-950 border border-slate-750 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          placeholder="Anda / Nama Karakter"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-medium text-slate-300 mb-1">
                          Link Foto / Emoji Anda:
                        </label>
                        <input
                          type="text"
                          value={formState.userAvatar?.startsWith('data:') ? 'Foto Lokal (Base64)' : (formState.userAvatar || '')}
                          disabled={formState.userAvatar?.startsWith('data:')}
                          onChange={(e) => setFormState({ ...formState, userAvatar: e.target.value })}
                          className="w-full bg-slate-950 border border-slate-750 disabled:opacity-75 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                          placeholder="URL foto atau emoji 👤"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION 2: PERSONA PENGGUNA UNTUK ROLEPLAY (USER PERSONA) */}
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <UserCheck className="w-4 h-4 text-emerald-400" />
                      <h3 className="font-bold text-xs sm:text-sm text-slate-100">
                        Persona &amp; Karakter Pengguna (Roleplay Persona)
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-medium">
                        Otomatis Dikenali AI
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      Tentukan kepribadian, latar belakang, dan peran karakter Anda. AI akan secara otomatis mengingat dan memperlakukan Anda sesuai watak ini di setiap percakapan <strong>tanpa perlu Anda jelaskan ulang</strong>!
                    </p>
                  </div>

                  {formState.userPersona && (
                    <button
                      type="button"
                      onClick={() => setFormState({ ...formState, userPersona: '' })}
                      className="text-[11px] text-slate-400 hover:text-rose-400 transition cursor-pointer shrink-0"
                    >
                      Kosongkan Persona
                    </button>
                  )}
                </div>

                {/* Preset Chips for User Persona */}
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1.5">
                    Pilihan Cepat Preset Persona Karakter:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {USER_PERSONA_PRESETS.map((preset) => (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => handleSelectUserPersonaPreset(preset.id)}
                        className={`p-2 rounded-xl text-left border transition cursor-pointer ${
                          formState.userPersona === preset.persona
                            ? 'bg-emerald-600/20 border-emerald-500 text-white shadow-xs'
                            : 'bg-slate-900/60 border-slate-750 hover:bg-slate-800 hover:border-slate-700 text-slate-300'
                        }`}
                      >
                        <div className="font-bold text-[11px] truncate flex items-center justify-between">
                          <span>{preset.name}</span>
                          <span className="text-[9px] px-1 py-0.2 rounded bg-slate-800 text-slate-400 font-normal">
                            {preset.category}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                          {preset.description}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom User Persona Textarea */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-medium text-slate-300">
                      Rincian Persona &amp; Karakter Anda (Bebas Edit):
                    </label>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {formState.userPersona?.length || 0} karakter
                    </span>
                  </div>
                  <textarea
                    rows={4}
                    value={formState.userPersona || ''}
                    onChange={(e) => setFormState({ ...formState, userPersona: e.target.value })}
                    placeholder="Contoh:&#10;Nama: Kaelen (Pengembara Daratan Utara)&#10;Sifat: Tenang, waspada, setia kawan, penuh perhitungan&#10;Latar Belakang: Mantan prajurit yang berkelana mencari artefak kuno&#10;Gaya Bahasa: Santai namun berwibawa, menggunakan istilah fantasi secara alami..."
                    className="w-full bg-slate-950 border border-slate-750 rounded-xl p-3 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-500 font-mono leading-relaxed resize-y"
                  />
                </div>
              </div>

              {/* SECTION 3: INSTRUKSI SISTEM & PERSONA BOT (BOT SYSTEM PROMPT) */}
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-3.5">
                <div>
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-xs sm:text-sm text-slate-100 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-indigo-400" />
                      <span>Instruksi Sistem &amp; Persona AI (System Prompt)</span>
                    </h3>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Aturan dasar tingkah laku dan peran utama yang dipatuhi AI pada setiap tanggapan.
                  </p>
                </div>

                {/* Presets library */}
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1.5">
                    Katalog Preset Karakter AI:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {PERSONA_PRESETS.map((preset) => (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => handlePresetSelect(preset.id)}
                        className={`p-2.5 rounded-xl text-left border transition group cursor-pointer ${
                          formState.systemInstruction === preset.systemInstruction
                            ? 'bg-indigo-600/20 border-indigo-500 text-white'
                            : 'bg-slate-900/60 border-slate-750 hover:bg-slate-800 hover:border-indigo-500/50'
                        }`}
                      >
                        <div className="font-semibold text-xs text-slate-200 group-hover:text-indigo-300">
                          {preset.name}
                        </div>
                        <div className="text-[10px] text-slate-400 line-clamp-2 mt-0.5">
                          {preset.description}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom System Instruction Textarea */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-[11px] font-medium text-slate-300">
                      Teks Instruksi Sistem Bot (Prompt):
                    </label>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {formState.systemInstruction?.length || 0} karakter
                    </span>
                  </div>
                  <textarea
                    rows={5}
                    value={formState.systemInstruction}
                    onChange={(e) =>
                      setFormState({ ...formState, systemInstruction: e.target.value })
                    }
                    placeholder="Contoh: Anda adalah asisten pakar koding yang ramah, selalu menggunakan TypeScript, dan memberi jawaban ringkas..."
                    className="w-full bg-slate-950 border border-slate-750 rounded-xl p-3 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 font-mono leading-relaxed resize-y"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: MEMORY & CONTEXT */}
          {activeTab === 'memory' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-indigo-950/20 border border-indigo-900/40 flex items-start gap-2.5">
                <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                <p className="text-xs text-indigo-200/90 leading-relaxed">
                  Pengaturan memori mengontrol berapa banyak pesan sebelumnya yang dikirimkan kembali ke
                  AI sebagai konteks percakapan. Membatasi riwayat menghemat token dan menjaga fokus model pada topik terkini.
                </p>
              </div>

              {/* Context Window Selector */}
              <div>
                <label className="block font-semibold text-slate-200 mb-1.5">
                  Ukuran Memori Riwayat (Sliding Context Window)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { label: '4 Pesan', val: 4, desc: 'Sangat hemat token' },
                    { label: '12 Pesan', val: 12, desc: 'Ideal & seimbang' },
                    { label: '24 Pesan', val: 24, desc: 'Percakapan mendalam' },
                    { label: 'Semua Pesan', val: 0, desc: 'Riwayat penuh tanpa batas' },
                  ].map((item) => (
                    <button
                      key={item.val}
                      type="button"
                      onClick={() => setFormState({ ...formState, contextWindow: item.val })}
                      className={`p-2.5 rounded-xl text-left border cursor-pointer transition ${
                        formState.contextWindow === item.val
                          ? 'bg-indigo-600/20 border-indigo-500 text-white font-medium'
                          : 'bg-slate-800/50 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="text-xs font-bold">{item.label}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Max Output Tokens */}
              <div>
                <label className="block font-semibold text-slate-200 mb-1.5">
                  Batas Maksimal Token Jawaban (Max Output)
                </label>
                <div className="flex items-center gap-2">
                  {[2048, 4096, 8192].map((tokens) => (
                    <button
                      key={tokens}
                      type="button"
                      onClick={() => setFormState({ ...formState, maxOutputTokens: tokens })}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                        formState.maxOutputTokens === tokens
                          ? 'bg-indigo-600 border-indigo-500 text-white'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {tokens} Token
                    </button>
                  ))}
                  <input
                    type="number"
                    min="256"
                    max="16384"
                    step="256"
                    value={formState.maxOutputTokens}
                    onChange={(e) =>
                      setFormState({ ...formState, maxOutputTokens: parseInt(e.target.value) || 4096 })
                    }
                    className="w-28 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: APPEARANCE & BACKUP */}
          {activeTab === 'appearance' && (
            <div className="space-y-4">
              {/* Fullscreen & Layout Setting */}
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-xs sm:text-sm text-slate-100 flex items-center gap-2">
                      <Maximize className="w-4 h-4 text-indigo-400" />
                      <span>Mode Layar Penuh (Full Screen Mode)</span>
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Jalankan aplikasi selalu dalam mode layar penuh (tanpa bilah peramban) untuk pengalaman immersif.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={formState.fullScreenMode !== false}
                      onChange={(e) =>
                        setFormState({ ...formState, fullScreenMode: e.target.checked })
                      }
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                {/* Quick Enter Fullscreen Button */}
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      if (!document.fullscreenElement) {
                        document.documentElement.requestFullscreen().catch(() => {});
                      }
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-xs font-medium text-indigo-300 transition cursor-pointer"
                  >
                    <Maximize className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Masuk ke Mode Layar Penuh Sekarang</span>
                  </button>
                </div>

                {/* Chat Area Width Option */}
                <div className="pt-2 border-t border-slate-750">
                  <label className="block text-xs font-semibold text-slate-200 mb-1.5">
                    Lebar Area Chat (Chat Width):
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setFormState({ ...formState, chatWidth: 'full' })}
                      className={`p-2.5 rounded-xl text-left border transition cursor-pointer ${
                        (formState.chatWidth || 'full') === 'full'
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-xs'
                          : 'bg-slate-900/60 border-slate-750 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-bold text-xs">Layar Penuh (Widescreen 100%)</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        Memanfaatkan seluruh lebar layar secara luas dan lega
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setFormState({ ...formState, chatWidth: 'standard' })}
                      className={`p-2.5 rounded-xl text-left border transition cursor-pointer ${
                        formState.chatWidth === 'standard'
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-xs'
                          : 'bg-slate-900/60 border-slate-750 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-bold text-xs">Standar (Terpusat 896px)</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        Kolom obrolan terpusat di tengah layar
                      </div>
                    </button>
                  </div>
                </div>

                {/* Enter Key Behavior Option */}
                <div className="pt-2 border-t border-slate-750">
                  <label className="block text-xs font-semibold text-slate-200 mb-1.5">
                    Perilaku Tombol Enter saat Mengetik:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setFormState({ ...formState, enterKeyAction: 'newline' })}
                      className={`p-2.5 rounded-xl text-left border transition cursor-pointer ${
                        (formState.enterKeyAction || 'newline') === 'newline'
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-xs'
                          : 'bg-slate-900/60 border-slate-750 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-bold text-xs flex items-center justify-between">
                        <span>Enter = Baris / Paragraf Baru</span>
                        {(formState.enterKeyAction || 'newline') === 'newline' && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/30 text-indigo-300 font-semibold">Aktif</span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        Tekan Enter untuk membuat paragraf baru. Kirim chat menggunakan <strong>Ctrl + Enter</strong> atau tombol Kirim.
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setFormState({ ...formState, enterKeyAction: 'send' })}
                      className={`p-2.5 rounded-xl text-left border transition cursor-pointer ${
                        formState.enterKeyAction === 'send'
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-xs'
                          : 'bg-slate-900/60 border-slate-750 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-bold text-xs flex items-center justify-between">
                        <span>Enter = Langsung Kirim Chat</span>
                        {formState.enterKeyAction === 'send' && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/30 text-indigo-300 font-semibold">Aktif</span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        Tekan Enter untuk langsung mengirim pesan. Gunakan <strong>Shift + Enter</strong> jika ingin baris baru.
                      </div>
                    </button>
                  </div>
                </div>
              </div>

              {/* Font Size */}
              <div>
                <label className="block font-semibold text-slate-200 mb-1.5">
                  Ukuran Teks Pesan
                </label>
                <div className="flex items-center gap-2">
                  {(['sm', 'md', 'lg'] as const).map((sz) => (
                    <button
                      key={sz}
                      type="button"
                      onClick={() => setFormState({ ...formState, fontSize: sz })}
                      className={`flex-1 py-2 rounded-xl text-xs font-medium border transition cursor-pointer ${
                        formState.fontSize === sz
                          ? 'bg-indigo-600 border-indigo-500 text-white'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {sz === 'sm' ? 'Kecil (Compact)' : sz === 'md' ? 'Standar (Nyaman)' : 'Besar (Luas)'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Backup & Import Configuration */}
              <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2.5">
                <div className="font-semibold text-slate-200 text-xs">
                  Cadangkan &amp; Pulihkan Pengaturan (JSON)
                </div>
                <p className="text-[11px] text-slate-400">
                  Simpan profil pengaturan favorit Anda ke file atau pulihkan dari komputer lain.
                </p>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleExportConfig}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 transition cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-sky-400" />
                    <span>Unduh File Config</span>
                  </button>

                  <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 transition cursor-pointer">
                    <Upload className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Unggah File Config</span>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleImportConfig}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Reset to Defaults */}
              <div className="pt-2 flex justify-start">
                <button
                  type="button"
                  onClick={handleResetToDefault}
                  className="flex items-center gap-1.5 text-xs text-rose-400 hover:text-rose-300 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Kembalikan ke Pengaturan Awal Pabrik</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-900 flex items-center justify-between">
          <div className="text-[11px] text-slate-400">
            {targetScope === 'session' ? (
              <span className="text-amber-400">⚡ Menerapkan kustom khusus chat ini</span>
            ) : (
              <span>🌐 Menerapkan ke seluruh percakapan</span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 font-medium transition cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs text-white font-medium shadow-md shadow-indigo-600/30 transition cursor-pointer"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Tersimpan!</span>
                </>
              ) : (
                <span>Simpan Pengaturan</span>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
