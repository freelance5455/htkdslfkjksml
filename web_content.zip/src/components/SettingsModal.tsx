import React from 'react';
import { Globe, X } from 'lucide-react';
import type { Language, WallpaperId } from '../types/study';
import {
  BellDomeIcon,
  DropletPaletteIcon,
  ShieldWaveIcon,
  SunFocusIcon,
} from './LiquidIcons';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsModalProps {
  open: boolean;
  onClose: () => void;
  lang: Language;
  onToggleLanguage: () => void;
  bgAudioEnabled: boolean;
  wakeLockEnabled: boolean;
  notifPermission: NotificationPermission | 'unsupported';
  wallpaper: WallpaperId;
  onToggleBgAudio: () => void;
  onToggleWakeLock: () => void;
  onRequestNotifications: () => void;
  onCycleWallpaper: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  open,
  onClose,
  lang,
  onToggleLanguage,
  bgAudioEnabled,
  wakeLockEnabled,
  notifPermission,
  wallpaper,
  onToggleBgAudio,
  onToggleWakeLock,
  onRequestNotifications,
  onCycleWallpaper,
}) => {
  if (!open) return null;

  const isBn = lang === 'bn';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-md"
    >
      <div className="liquid-glass-elevated w-full max-w-md rounded-3xl p-6">
        <div className="flex items-center justify-between gap-4 border-b border-white/12 pb-4">
          <h2 id="settings-modal-title" className="text-base font-semibold text-white">
            {isBn ? 'সেটিংস' : 'Settings'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={isBn ? 'বন্ধ করুন' : 'Close'}
            className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-300 transition hover:bg-white/10 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-4 space-y-2.5">
          {/* Language Switcher */}
          <button
            type="button"
            onClick={onToggleLanguage}
            className="liquid-glass-tile flex w-full min-h-[50px] items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left"
          >
            <div className="flex items-center gap-3">
              <Globe className="h-5 w-5 text-sky-300" aria-hidden="true" />
              <span className="text-sm font-semibold text-white">
                {isBn ? 'ভাষা' : 'Language'}
              </span>
            </div>
            <span className="text-xs font-semibold text-sky-200 whitespace-nowrap">
              {isBn ? 'বাংলা' : 'English'}
            </span>
          </button>

          {/* Background Audio Guard */}
          <button
            type="button"
            onClick={onToggleBgAudio}
            className={`flex w-full min-h-[50px] items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left ${
              bgAudioEnabled ? 'liquid-glass-tile-active' : 'liquid-glass-tile'
            }`}
          >
            <div className="flex items-center gap-3">
              <ShieldWaveIcon active={bgAudioEnabled} className="h-5 w-5 text-sky-300" />
              <span className="text-sm font-semibold text-white">
                {isBn ? 'ব্যাকগ্রাউন্ড অডিও গার্ড' : 'Background Audio Guard'}
              </span>
            </div>
            <span className="text-xs font-semibold text-sky-200 whitespace-nowrap">
              {bgAudioEnabled ? (isBn ? 'চালু' : 'On') : isBn ? 'বন্ধ' : 'Off'}
            </span>
          </button>

          {/* Notifications */}
          <button
            type="button"
            onClick={onRequestNotifications}
            className={`flex w-full min-h-[50px] items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left ${
              notifPermission === 'granted' ? 'liquid-glass-tile-active' : 'liquid-glass-tile'
            }`}
          >
            <div className="flex items-center gap-3">
              <BellDomeIcon
                active={notifPermission === 'granted'}
                className="h-5 w-5 text-sky-300"
              />
              <span className="text-sm font-semibold text-white">
                {isBn ? 'অ্যালার্ম নোটিফিকেশন' : 'Alarm Notifications'}
              </span>
            </div>
            <span className="text-xs font-semibold text-sky-200 whitespace-nowrap">
              {notifPermission === 'granted'
                ? isBn
                  ? 'চালু'
                  : 'On'
                : isBn
                  ? 'অনুমতি দিন'
                  : 'Allow'}
            </span>
          </button>

          {/* Screen Wake Lock */}
          <button
            type="button"
            onClick={onToggleWakeLock}
            className={`flex w-full min-h-[50px] items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left ${
              wakeLockEnabled ? 'liquid-glass-tile-active' : 'liquid-glass-tile'
            }`}
          >
            <div className="flex items-center gap-3">
              <SunFocusIcon active={wakeLockEnabled} className="h-5 w-5 text-sky-300" />
              <span className="text-sm font-semibold text-white">
                {isBn ? 'স্ক্রিন ওয়েক-লক' : 'Screen Wake Lock'}
              </span>
            </div>
            <span className="text-xs font-semibold text-sky-200 whitespace-nowrap">
              {wakeLockEnabled ? (isBn ? 'চালু' : 'On') : isBn ? 'বন্ধ' : 'Off'}
            </span>
          </button>

          {/* Wallpaper Theme */}
          <button
            type="button"
            onClick={onCycleWallpaper}
            className="liquid-glass-tile flex w-full min-h-[50px] items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left"
          >
            <div className="flex items-center gap-3">
              <DropletPaletteIcon className="h-5 w-5 text-sky-300" />
              <span className="text-sm font-semibold text-white">
                {isBn ? 'ওয়াটার গ্লাস থিম' : 'Water Glass Theme'}
              </span>
            </div>
            <span className="text-xs font-semibold text-sky-200 whitespace-nowrap">
              {wallpaper === 'aurora'
                ? isBn
                  ? 'অরোরা'
                  : 'Aurora'
                : wallpaper === 'emerald'
                  ? isBn
                    ? 'এমেরাল্ড'
                    : 'Emerald'
                  : isBn
                    ? 'টোয়াইলাইট'
                    : 'Twilight'}
            </span>
          </button>
        </div>

        <div className="mt-5 flex items-center justify-between gap-3 border-t border-white/12 pt-4">
          <PWAInstallButton lang={lang} />
          <button
            type="button"
            onClick={onClose}
            className="ml-auto min-h-[42px] rounded-xl bg-white/15 px-5 py-2 text-xs font-semibold text-white transition hover:bg-white/25 whitespace-nowrap"
          >
            {isBn ? 'সম্পন্ন' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
};
