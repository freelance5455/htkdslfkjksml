import React from 'react';
import { X, Music, Volume2, SmartphoneNfc, HelpCircle, Shield, Sparkles, Smartphone, Download } from 'lucide-react';

interface SettingsModalProps {
  isMusicMuted: boolean;
  isSoundMuted: boolean;
  isHapticsEnabled: boolean;
  onToggleMusic: () => void;
  onToggleSound: () => void;
  onToggleHaptics: () => void;
  onShowTutorial: () => void;
  onOpenDownloadZip?: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isMusicMuted,
  isSoundMuted,
  isHapticsEnabled,
  onToggleMusic,
  onToggleSound,
  onToggleHaptics,
  onShowTutorial,
  onOpenDownloadZip,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-4 py-4 select-none animate-in fade-in duration-150">
      <div className="flex w-full max-w-sm flex-col rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h2 className="text-lg font-black text-white">SETTINGS</h2>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Toggles List */}
        <div className="flex flex-col gap-3 py-4">
          {/* Music Toggle */}
          <div className="flex items-center justify-between rounded-2xl bg-slate-950/60 p-3.5 border border-slate-800">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-400">
                <Music className="h-5 w-5" />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-sm font-bold text-white">Arcade Music</span>
                <span className="text-[11px] text-slate-400">Background synth beat</span>
              </div>
            </div>
            <button
              onClick={onToggleMusic}
              className={`relative h-6 w-11 rounded-full transition-colors ${
                !isMusicMuted ? 'bg-indigo-600' : 'bg-slate-800'
              }`}
            >
              <div
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${
                  !isMusicMuted ? 'left-5' : 'left-0.5'
                }`}
              />
            </button>
          </div>

          {/* Sound FX Toggle */}
          <div className="flex items-center justify-between rounded-2xl bg-slate-950/60 p-3.5 border border-slate-800">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400">
                <Volume2 className="h-5 w-5" />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-sm font-bold text-white">Sound Effects</span>
                <span className="text-[11px] text-slate-400">Taps, combos, fevers</span>
              </div>
            </div>
            <button
              onClick={onToggleSound}
              className={`relative h-6 w-11 rounded-full transition-colors ${
                !isSoundMuted ? 'bg-emerald-600' : 'bg-slate-800'
              }`}
            >
              <div
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${
                  !isSoundMuted ? 'left-5' : 'left-0.5'
                }`}
              />
            </button>
          </div>

          {/* Vibration / Haptics Toggle */}
          <div className="flex items-center justify-between rounded-2xl bg-slate-950/60 p-3.5 border border-slate-800">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400">
                <SmartphoneNfc className="h-5 w-5" />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-sm font-bold text-white">Vibration Haptics</span>
                <span className="text-[11px] text-slate-400">Tactile tap feedback</span>
              </div>
            </div>
            <button
              onClick={onToggleHaptics}
              className={`relative h-6 w-11 rounded-full transition-colors ${
                isHapticsEnabled ? 'bg-amber-600' : 'bg-slate-800'
              }`}
            >
              <div
                className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${
                  isHapticsEnabled ? 'left-5' : 'left-0.5'
                }`}
              />
            </button>
          </div>

          {/* View Tutorial Button */}
          <button
            onClick={() => {
              onClose();
              onShowTutorial();
            }}
            className="flex items-center justify-between rounded-2xl bg-slate-950/60 p-3.5 border border-slate-800 active:scale-98 transition-all hover:border-slate-700"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-500/20 text-blue-400">
                <HelpCircle className="h-5 w-5" />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-sm font-bold text-white">How to Play</span>
                <span className="text-[11px] text-slate-400">Quick 3-second guide</span>
              </div>
            </div>
            <span className="text-xs text-indigo-400 font-bold">Review</span>
          </button>

          {/* Download Android Project (.ZIP) */}
          <button
            onClick={() => {
              onClose();
              onOpenDownloadZip?.();
            }}
            className="flex items-center justify-between rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-950/60 to-emerald-950/60 p-3.5 border border-emerald-500/40 active:scale-98 transition-all hover:border-emerald-400"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400">
                <Smartphone className="h-5 w-5" />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-sm font-bold text-white flex items-center gap-1.5">
                  Android Project ZIP
                  <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[9px] font-bold text-emerald-400">
                    Latest
                  </span>
                </span>
                <span className="text-[11px] text-slate-400">Complete source & Studio build</span>
              </div>
            </div>
            <div className="flex items-center gap-1 text-xs text-emerald-400 font-bold">
              <Download className="h-3.5 w-3.5" />
              <span>Get ZIP</span>
            </div>
          </button>
        </div>

        {/* Build & Version Info */}
        <div className="pt-2 text-center text-[10px] text-slate-500 border-t border-slate-800">
          Color Rush Pro Edition v2.0 · Offline HTML5 Arcade
        </div>
      </div>
    </div>
  );
};
