import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Volume2, VolumeX, Music, Smartphone, Eye, RotateCcw, Info, Tv, Volume1, Sparkles, AlertTriangle, Maximize, Minimize, ShieldCheck, ChevronDown, ChevronUp } from 'lucide-react';
import { sound } from '../utils/audio';
import { admob, ADMOB_CONFIG } from '../utils/admob';
import { AdMobBanner } from './AdMobBanner';

interface SettingsModalProps {
  soundEnabled: boolean;
  musicEnabled: boolean;
  hapticsEnabled: boolean;
  colorblindEnabled: boolean;
  isFullscreen?: boolean;
  soundVolume?: number;
  musicVolume?: number;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onToggleHaptics: () => void;
  onToggleColorblind: () => void;
  onToggleFullscreen?: () => void;
  onChangeSoundVolume: (val: number) => void;
  onChangeMusicVolume: (val: number) => void;
  onResetProgress: () => void;
  onOpenAdMobTest: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  soundEnabled,
  musicEnabled,
  hapticsEnabled,
  colorblindEnabled,
  isFullscreen = false,
  soundVolume = 1.0,
  musicVolume = 0.9,
  onToggleSound,
  onToggleMusic,
  onToggleHaptics,
  onToggleColorblind,
  onToggleFullscreen,
  onChangeSoundVolume,
  onChangeMusicVolume,
  onResetProgress,
  onOpenAdMobTest,
  onClose,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);
  const [showAdMobDetails, setShowAdMobDetails] = useState(false);

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 select-none">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="crystal-card w-full max-w-sm rounded-3xl p-5 flex flex-col max-h-[92vh] overflow-y-auto shadow-[0_0_60px_rgba(0,0,0,0.7)] relative"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-white tracking-wide">SETTINGS</h2>
            <span className="text-[10px] font-black uppercase tracking-wider bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded-full border border-cyan-500/40">
              v2.4 Premium
            </span>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="crystal-button p-1.5 rounded-full text-slate-300 hover:text-white border-white/10 active:scale-95"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Options List */}
        <div className="py-4 space-y-3">
          {/* Background Music Card & Volume Slider */}
          <div className="p-3.5 rounded-2xl bg-slate-950/50 border border-white/10 space-y-2.5 shadow-inner">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-pink-500/20 border border-pink-500/30 flex items-center justify-center shadow-[0_0_8px_rgba(244,114,182,0.3)]">
                  <Music className={`w-4 h-4 ${musicEnabled ? 'text-pink-400' : 'text-slate-500'}`} />
                </div>
                <div className="text-left">
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    Background Music
                    <span className="text-[10px] bg-pink-500/30 text-pink-300 px-1.5 py-0.2 rounded font-black">
                      Orchestra
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Energetic multi-instrument beats
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  onToggleMusic();
                  sound.playClick();
                }}
                className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                  musicEnabled ? 'bg-pink-500 shadow-[0_0_10px_rgba(236,72,153,0.6)]' : 'bg-slate-800 border border-slate-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform shadow-md ${
                    musicEnabled ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Music Volume Slider */}
            {musicEnabled && (
              <div className="pt-1.5 border-t border-white/10 flex items-center gap-2.5">
                <Volume1 className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={musicVolume}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    onChangeMusicVolume(val);
                  }}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-pink-500"
                />
                <span className="text-xs font-bold text-pink-300 w-10 text-right shrink-0">
                  {Math.round(musicVolume * 100)}%
                </span>
              </div>
            )}
          </div>

          {/* Sound Audio Effects Card & Volume Slider */}
          <div className="p-3.5 rounded-2xl bg-slate-950/50 border border-white/10 space-y-2.5 shadow-inner">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center shadow-[0_0_8px_rgba(34,211,238,0.3)]">
                  {soundEnabled ? (
                    <Volume2 className="w-4 h-4 text-cyan-400" />
                  ) : (
                    <VolumeX className="w-4 h-4 text-slate-500" />
                  )}
                </div>
                <div className="text-left">
                  <h4 className="text-sm font-bold text-white">Sound Effects</h4>
                  <p className="text-[11px] text-slate-400">
                    Fluid, pouring & win audio
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  onToggleSound();
                  sound.playClick();
                }}
                className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                  soundEnabled ? 'bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.6)]' : 'bg-slate-800 border border-slate-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform shadow-md ${
                    soundEnabled ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Sound Volume Slider */}
            {soundEnabled && (
              <div className="pt-1.5 border-t border-white/10 flex items-center gap-2.5">
                <Volume1 className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={soundVolume}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    onChangeSoundVolume(val);
                    sound.playSelect();
                  }}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
                <span className="text-xs font-bold text-cyan-300 w-10 text-right shrink-0">
                  {Math.round(soundVolume * 100)}%
                </span>
              </div>
            )}
          </div>

          {/* Haptic Vibration Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/40 border border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center">
                <Smartphone className="w-4 h-4 text-purple-400" />
              </div>
              <div className="text-left">
                <h4 className="text-sm font-bold text-white">Haptic Feedback</h4>
                <p className="text-[11px] text-slate-400">
                  Vibrations on mobile taps
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                onToggleHaptics();
                sound.playClick();
              }}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                hapticsEnabled ? 'bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.6)]' : 'bg-slate-800 border border-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform shadow-md ${
                  hapticsEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Colorblind Mode Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/40 border border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center">
                <Eye className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-left">
                <h4 className="text-sm font-bold text-white">Colorblind Symbols</h4>
                <p className="text-[11px] text-slate-400">
                  Show symbols on liquid layers
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                onToggleColorblind();
                sound.playClick();
              }}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                colorblindEnabled ? 'bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.6)]' : 'bg-slate-800 border border-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform shadow-md ${
                  colorblindEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Fullscreen Immersive Mode Toggle */}
          {onToggleFullscreen && (
            <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/40 border border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-500/30 flex items-center justify-center">
                  {isFullscreen ? (
                    <Minimize className="w-4 h-4 text-sky-400" />
                  ) : (
                    <Maximize className="w-4 h-4 text-sky-400" />
                  )}
                </div>
                <div className="text-left">
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    Immersive Fullscreen
                    <span className="text-[10px] bg-sky-500/20 text-sky-300 px-1.5 py-0.2 rounded font-black border border-sky-500/30">
                      Android
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Hide status & navigation bars
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  onToggleFullscreen();
                  sound.playClick();
                }}
                className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
                  isFullscreen ? 'bg-sky-500 shadow-[0_0_10px_rgba(14,165,233,0.6)]' : 'bg-slate-800 border border-slate-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform shadow-md ${
                    isFullscreen ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          )}

          {/* Google AdMob Suite Section */}
          <div className="rounded-2xl bg-slate-950/70 border border-emerald-500/30 p-3.5 space-y-3 shadow-inner">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-400">
                <ShieldCheck className="w-4.5 h-4.5" />
                <h4 className="text-xs font-black uppercase tracking-wider text-white">
                  Google AdMob Ads
                </h4>
              </div>

              {/* Production Mode Status */}
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-bold text-slate-400">Ads Mode:</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
                  PRODUCTION
                </span>
              </div>
            </div>

            {/* Watch Rewarded Ad Action */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenAdMobTest();
              }}
              className="w-full py-2.5 px-3.5 rounded-xl bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border border-emerald-500/40 hover:border-emerald-400 text-emerald-300 font-black text-xs flex items-center justify-between active:scale-95 transition-all"
            >
              <div className="flex items-center gap-2">
                <Tv className="w-4 h-4 text-emerald-400" />
                <span>Verify Rewarded Ad (+150 Coins)</span>
              </div>
              <span className="bg-emerald-500 text-slate-950 px-2 py-0.5 rounded text-[10px] font-black uppercase">
                Watch
              </span>
            </button>

            {/* Toggle Unit IDs details */}
            <button
              onClick={() => {
                sound.playClick();
                setShowAdMobDetails(!showAdMobDetails);
              }}
              className="w-full text-[10px] font-bold text-slate-400 hover:text-slate-200 flex items-center justify-between pt-1 border-t border-slate-800"
            >
              <span>Configured Production Ad Units</span>
              {showAdMobDetails ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {showAdMobDetails && (
              <div className="space-y-1 text-[9px] font-mono text-slate-400 bg-slate-900/90 p-2 rounded-xl border border-slate-800 break-all text-left">
                <p><span className="text-cyan-400 font-bold">App ID:</span> {ADMOB_CONFIG.appId}</p>
                <p><span className="text-emerald-400 font-bold">Banner:</span> {ADMOB_CONFIG.bannerId}</p>
                <p><span className="text-amber-400 font-bold">Interstitial:</span> {ADMOB_CONFIG.interstitialId}</p>
                <p><span className="text-purple-400 font-bold">Reward:</span> {ADMOB_CONFIG.rewardId}</p>
                <p><span className="text-pink-400 font-bold">Rewarded Inter:</span> {ADMOB_CONFIG.rewardedInterstitialId}</p>
                <p><span className="text-sky-400 font-bold">App Open:</span> {ADMOB_CONFIG.appOpenId}</p>
                <p><span className="text-teal-400 font-bold">Native Adv:</span> {ADMOB_CONFIG.nativeAdvancedId}</p>
              </div>
            )}
          </div>
        </div>

        {/* How to Play Guide */}
        <div className="p-3 rounded-2xl bg-slate-950/70 border border-white/10 text-[11px] text-slate-300 space-y-1 my-1 shadow-inner">
          <div className="flex items-center gap-1.5 font-black text-cyan-300 mb-1">
            <Info className="w-3.5 h-3.5 text-cyan-400" />
            <span>HOW TO PLAY</span>
          </div>
          <p>• Tap a tube to lift it, then tap another tube to pour.</p>
          <p>• You can only pour if the destination has space and the same top color (or is empty).</p>
          <p>• Sort each tube into a single uniform color to win!</p>
        </div>

        {/* Reset Progress Section */}
        <div className="mt-2 pt-2 border-t border-white/10">
          <AnimatePresence mode="wait">
            {!confirmReset ? (
              <motion.button
                key="reset-btn"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => {
                  sound.playClick();
                  setConfirmReset(true);
                }}
                className="w-full py-2.5 px-4 rounded-xl border border-rose-500/40 text-rose-300 hover:bg-rose-500/15 text-xs font-bold flex items-center justify-center gap-2 active:scale-95 transition-all bg-rose-950/20"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset All Progress</span>
              </motion.button>
            ) : (
              <motion.div
                key="confirm-box"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="p-3.5 rounded-2xl bg-rose-950/70 border border-rose-500/60 text-left space-y-2.5 shadow-[0_0_20px_rgba(244,63,94,0.25)]"
              >
                <div className="flex items-center gap-2 text-rose-300">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span className="text-xs font-black uppercase tracking-wider">Reset Everything?</span>
                </div>
                <p className="text-[11px] text-rose-200/90 leading-relaxed">
                  All completed levels, stars, coins, and unlocked skins will be reset to Level 1.
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => {
                      sound.playClick();
                      setConfirmReset(false);
                    }}
                    className="flex-1 py-1.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-bold border border-white/10 active:scale-95 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      sound.playClick();
                      setConfirmReset(false);
                      onResetProgress();
                    }}
                    className="flex-1 py-1.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black shadow-[0_0_12px_rgba(225,29,72,0.6)] active:scale-95 transition-all"
                  >
                    Yes, Reset
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* AdMob Adaptive Banner */}
        <AdMobBanner className="pt-2" />
      </motion.div>
    </div>
  );
};
