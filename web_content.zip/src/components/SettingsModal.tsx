import React, { useState } from 'react';
import {
  Check,
  Languages,
  RefreshCw,
  RotateCcw,
  Save,
  Settings,
  Sliders,
  Trash2,
  Wrench,
  X,
} from 'lucide-react';
import {
  ExportImageQuality,
  PageSizePreset,
  StudioSettings,
  UILanguage,
} from '../types/pdf';
import { UI_COPY } from '../utils/i18n';

interface SettingsModalProps {
  isOpen: boolean;
  lang: UILanguage;
  settings: StudioSettings;
  hasActiveDoc: boolean;
  lastSavedAt: number | null;
  onClose: () => void;
  onToggleLang: (nextLang: UILanguage) => void;
  onUpdateSettings: (patch: Partial<StudioSettings>) => void;
  onSaveSnapshotNow: () => Promise<void>;
  onReparseCurrentPdf: () => Promise<void>;
  onReloadAllFonts: () => Promise<number>;
  onUnlockSelection: () => void;
  onClearCache: () => Promise<void>;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  lang,
  settings,
  hasActiveDoc,
  lastSavedAt,
  onClose,
  onToggleLang,
  onUpdateSettings,
  onSaveSnapshotNow,
  onReparseCurrentPdf,
  onReloadAllFonts,
  onUnlockSelection,
  onClearCache,
}) => {
  const [activeTab, setActiveTab] = useState<'general' | 'troubleshoot' | 'export'>(
    'general'
  );
  const [statusNotice, setStatusNotice] = useState<string | null>(null);
  const [isBusy, setIsBusy] = useState(false);

  if (!isOpen) return null;
  const t = UI_COPY[lang];

  const notify = (msg: string) => {
    setStatusNotice(msg);
    window.setTimeout(() => {
      setStatusNotice((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-[1px] flex items-center justify-center p-3 sm:p-4"
      onClick={onClose}
    >
      <div
        className="bg-white border border-slate-200 rounded-xl w-full max-w-xl max-h-[88vh] flex flex-col shadow-xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
              <Settings className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base font-semibold text-slate-900 truncate">
                {t.settingsTitle}
              </h2>
              <p className="text-xs text-slate-500 truncate">{t.settingsDesc}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            data-tooltip={t.close}
            aria-label={t.close}
            className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Section Tabs */}
        <div className="px-5 pt-3 border-b border-slate-200 bg-[#FAFAFB] flex items-center gap-2 shrink-0 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('general')}
            className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'general'
                ? 'border-blue-700 text-blue-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>{t.tabGeneral}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('troubleshoot')}
            className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'troubleshoot'
                ? 'border-blue-700 text-blue-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>{t.tabTroubleshoot}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('export')}
            className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'export'
                ? 'border-blue-700 text-blue-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Save className="w-3.5 h-3.5" />
            <span>{t.tabExport}</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1">
          {statusNotice && (
            <div className="px-3.5 py-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs font-medium text-emerald-800 flex items-center gap-2">
              <Check className="w-4 h-4 shrink-0" />
              <span>{statusNotice}</span>
            </div>
          )}

          {activeTab === 'general' && (
            <div className="space-y-5">
              {/* App Interface Language */}
              <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <Languages className="w-4 h-4 text-slate-500 shrink-0" />
                  <span className="text-xs font-semibold text-slate-800">
                    {t.uiLanguageLabel}
                  </span>
                </div>
                <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg shrink-0">
                  <button
                    type="button"
                    onClick={() => onToggleLang('bn')}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-md cursor-pointer ${
                      lang === 'bn'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    বাংলা
                  </button>
                  <button
                    type="button"
                    onClick={() => onToggleLang('en')}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-md cursor-pointer ${
                      lang === 'en'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    English
                  </button>
                </div>
              </div>

              {/* Default New Page Size */}
              <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <span className="text-xs font-semibold text-slate-800">
                  {t.defaultPageSizeLabel}
                </span>
                <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg shrink-0">
                  {(
                    [
                      { id: 'a4', label: 'A4' },
                      { id: 'letter', label: 'Letter' },
                      { id: 'legal', label: 'Legal' },
                    ] as Array<{ id: PageSizePreset; label: string }>
                  ).map((sz) => (
                    <button
                      key={sz.id}
                      type="button"
                      onClick={() => onUpdateSettings({ defaultPageSize: sz.id })}
                      className={`px-2.5 py-1 text-xs font-medium rounded-md cursor-pointer ${
                        settings.defaultPageSize === sz.id
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {sz.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Auto-save toggle + manual save */}
              <div className="space-y-2.5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="text-xs font-semibold text-slate-800">
                      {t.autosaveLabel}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {t.autosaveDesc}
                    </p>
                    {lastSavedAt && (
                      <p className="text-[11px] font-mono tabular-nums text-slate-400 mt-1">
                        {new Date(lastSavedAt).toLocaleTimeString()}
                      </p>
                    )}
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.autosaveEnabled}
                    onChange={(e) =>
                      onUpdateSettings({ autosaveEnabled: e.target.checked })
                    }
                    className="w-4 h-4 mt-0.5 accent-blue-700 cursor-pointer shrink-0"
                  />
                </div>

                {hasActiveDoc && (
                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={async () => {
                      setIsBusy(true);
                      try {
                        await onSaveSnapshotNow();
                        notify(t.snapshotSaved);
                      } finally {
                        setIsBusy(false);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{t.saveSnapshotNow}</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {activeTab === 'troubleshoot' && (
            <div className="space-y-4">
              {/* Paragraph Grouping Mode */}
              <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="text-xs font-semibold text-slate-800">
                    {t.paragraphGroupingLabel}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    {t.paragraphGroupingDesc}
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.paragraphGrouping}
                  onChange={(e) =>
                    onUpdateSettings({ paragraphGrouping: e.target.checked })
                  }
                  className="w-4 h-4 mt-0.5 accent-blue-700 cursor-pointer shrink-0"
                />
              </div>

              {/* Auto-Normalize Bangla & RTL */}
              <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="text-xs font-semibold text-slate-800">
                    {t.autoNormalizeLabel}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    {t.autoNormalizeDesc}
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.autoNormalizeText}
                  onChange={(e) =>
                    onUpdateSettings({ autoNormalizeText: e.target.checked })
                  }
                  className="w-4 h-4 mt-0.5 accent-blue-700 cursor-pointer shrink-0"
                />
              </div>

              {/* Action Buttons for Fixing Issues */}
              <div className="space-y-2">
                <button
                  type="button"
                  disabled={!hasActiveDoc || isBusy}
                  onClick={async () => {
                    setIsBusy(true);
                    try {
                      await onReparseCurrentPdf();
                      notify(t.reparseDone);
                    } finally {
                      setIsBusy(false);
                    }
                  }}
                  className="w-full py-2.5 px-3.5 bg-blue-700 hover:bg-blue-800 disabled:opacity-45 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{t.reparseCurrentPdf}</span>
                </button>

                <button
                  type="button"
                  disabled={isBusy}
                  onClick={async () => {
                    setIsBusy(true);
                    try {
                      const count = await onReloadAllFonts();
                      notify(`${count} ${t.fontsReloaded}`);
                    } finally {
                      setIsBusy(false);
                    }
                  }}
                  className="w-full py-2.5 px-3.5 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{t.reloadAllFontsBtn}</span>
                </button>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      onUnlockSelection();
                      notify(t.unlockDone);
                    }}
                    className="py-2 px-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{t.unlockSelectionBtn}</span>
                  </button>

                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={async () => {
                      setIsBusy(true);
                      try {
                        await onClearCache();
                        notify(t.clearCacheDone);
                      } finally {
                        setIsBusy(false);
                      }
                    }}
                    className="py-2 px-3 bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{t.clearCacheBtn}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'export' && (
            <div className="space-y-5">
              {/* Image Export Quality */}
              <div className="space-y-2 pb-4 border-b border-slate-100">
                <div className="text-xs font-semibold text-slate-800">
                  {t.exportQualityLabel}
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { id: 'hd', label: t.qualityHd },
                      { id: 'fullhd', label: t.qualityFullHd },
                      { id: 'uhd', label: t.qualityUhd },
                    ] as Array<{ id: ExportImageQuality; label: string }>
                  ).map((q) => (
                    <button
                      key={q.id}
                      type="button"
                      onClick={() => onUpdateSettings({ exportImageQuality: q.id })}
                      className={`py-2 px-2.5 rounded-lg border text-xs font-semibold cursor-pointer ${
                        settings.exportImageQuality === q.id
                          ? 'bg-blue-700 text-white border-blue-700'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {q.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Default Mask Padding */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-800">
                    {t.defaultMaskPaddingLabel}
                  </span>
                  <span className="text-xs font-mono tabular-nums text-slate-600">
                    {settings.defaultMaskPadding} pt
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={4}
                  step={0.5}
                  value={settings.defaultMaskPadding}
                  onChange={(e) =>
                    onUpdateSettings({
                      defaultMaskPadding: Number(e.target.value),
                    })
                  }
                  className="w-full accent-blue-700"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 bg-[#FAFAFB] flex justify-end shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
