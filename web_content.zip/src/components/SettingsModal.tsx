/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Volume2, Music, Smartphone, Keyboard, HelpCircle } from 'lucide-react';
import { GameSettings } from '../types/game';

interface SettingsModalProps {
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
  onResetProgress: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onResetProgress,
  onClose,
}) => {
  return (
    <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-none flex items-center justify-center p-4 z-50 pointer-events-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-md w-full p-6 text-center shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <h2 className="text-2xl font-black text-white italic tracking-wide">SETTINGS & GUIDE</h2>
          <button
            onClick={onClose}
            className="w-9 h-9 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex flex-col gap-5 my-4 overflow-y-auto pr-1 text-left">
          {/* Audio & Control Preferences */}
          <div className="flex flex-col gap-2.5">
            <span className="text-[11px] uppercase font-bold text-slate-400 tracking-wider">Preferences</span>

            {/* Sound FX Toggle */}
            <div className="flex items-center justify-between p-3 bg-slate-950/60 border border-slate-800 rounded-xl">
              <div className="flex items-center gap-2.5">
                <Volume2 className="w-5 h-5 text-emerald-400" />
                <div>
                  <div className="font-bold text-sm text-white">Sound Effects</div>
                  <div className="text-[11px] text-slate-400">Footsteps, coins, jumps & crashes</div>
                </div>
              </div>
              <button
                onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
                className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer ${
                  settings.soundEnabled ? 'bg-emerald-500' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.soundEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Music Toggle */}
            <div className="flex items-center justify-between p-3 bg-slate-950/60 border border-slate-800 rounded-xl">
              <div className="flex items-center gap-2.5">
                <Music className="w-5 h-5 text-cyan-400" />
                <div>
                  <div className="font-bold text-sm text-white">Arcade Funk Music</div>
                  <div className="text-[11px] text-slate-400">Procedural dynamic synth groove</div>
                </div>
              </div>
              <button
                onClick={() => onUpdateSettings({ musicEnabled: !settings.musicEnabled })}
                className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer ${
                  settings.musicEnabled ? 'bg-cyan-500' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.musicEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* On-screen Touch Controls Toggle */}
            <div className="flex items-center justify-between p-3 bg-slate-950/60 border border-slate-800 rounded-xl">
              <div className="flex items-center gap-2.5">
                <Smartphone className="w-5 h-5 text-amber-400" />
                <div>
                  <div className="font-bold text-sm text-white">Touch Arrow Buttons</div>
                  <div className="text-[11px] text-slate-400">Show on-screen mobile d-pad buttons</div>
                </div>
              </div>
              <button
                onClick={() => onUpdateSettings({ showTouchControls: !settings.showTouchControls })}
                className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer ${
                  settings.showTouchControls ? 'bg-amber-500' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.showTouchControls ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Controls Tutorial */}
          <div className="flex flex-col gap-2.5">
            <span className="text-[11px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
              How to Play & Controls
            </span>

            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl flex flex-col gap-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-1.5">
                <span className="text-slate-300 font-semibold flex items-center gap-2">
                  <Keyboard className="w-4 h-4 text-slate-500" />
                  Lane Switching
                </span>
                <span className="font-mono text-cyan-400 font-bold">Left / Right Arrows · A / D · Swipe</span>
              </div>

              <div className="flex items-center justify-between border-b border-slate-800/80 pb-1.5">
                <span className="text-slate-300 font-semibold">Jump Hurdles</span>
                <span className="font-mono text-emerald-400 font-bold">Up Arrow · Space · W · Swipe Up</span>
              </div>

              <div className="flex items-center justify-between border-b border-slate-800/80 pb-1.5">
                <span className="text-slate-300 font-semibold">Slide Low</span>
                <span className="font-mono text-amber-400 font-bold">Down Arrow · S · Swipe Down</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-300 font-semibold">Pause Run</span>
                <span className="font-mono text-rose-400 font-bold">Escape · P · Top Right Button</span>
              </div>
            </div>
          </div>

          {/* Reset Stats */}
          <div className="pt-2">
            <button
              onClick={() => {
                if (window.confirm('Reset all coins, high scores, and mission progress?')) {
                  onResetProgress();
                }
              }}
              className="text-xs text-rose-400 hover:text-rose-300 font-semibold cursor-pointer underline"
            >
              Reset Saved High Scores & Vault
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
