import React, { useState, useEffect } from 'react';
import { X, Volume2, Gamepad2, Keyboard, Vibrate, Check, Smartphone } from 'lucide-react';
import { controlsManager, KeyBindings } from '../game/controls';
import { soundSystem } from '../game/soundSystem';

interface SettingsModalProps {
  musicVolume: number;
  sfxVolume: number;
  showOnScreenButtons: boolean;
  gamepadVibration: boolean;
  onUpdateMusicVolume: (v: number) => void;
  onUpdateSfxVolume: (v: number) => void;
  onToggleOnScreenButtons: (v: boolean) => void;
  onToggleGamepadVibration: (v: boolean) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  musicVolume,
  sfxVolume,
  showOnScreenButtons,
  gamepadVibration,
  onUpdateMusicVolume,
  onUpdateSfxVolume,
  onToggleOnScreenButtons,
  onToggleGamepadVibration,
  onClose
}) => {
  const [bindings, setBindings] = useState<KeyBindings>(() => controlsManager.getBindings());
  const [listeningForAction, setListeningForAction] = useState<keyof KeyBindings | null>(null);
  const [connectedGamepad, setConnectedGamepad] = useState<string | null>(() =>
    controlsManager.getConnectedGamepadName()
  );

  useEffect(() => {
    const timer = setInterval(() => {
      setConnectedGamepad(controlsManager.getConnectedGamepadName());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Listen for key rebind
  useEffect(() => {
    if (!listeningForAction) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      e.preventDefault();
      const newBindings = { ...bindings, [listeningForAction]: e.code };
      setBindings(newBindings);
      controlsManager.saveBindings(newBindings);
      setListeningForAction(null);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [listeningForAction, bindings]);

  const handleResetBindings = () => {
    const defaults = {
      jump: 'ArrowUp',
      slide: 'ArrowDown',
      left: 'ArrowLeft',
      right: 'ArrowRight',
      board: 'KeyE',
      pause: 'Escape'
    };
    setBindings(defaults);
    controlsManager.saveBindings(defaults);
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 md:p-6 bg-slate-950/85">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-3xl w-full max-w-xl h-[88vh] max-h-[720px] shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-xl">
              ⚙️
            </div>
            <div>
              <h2 className="text-lg md:text-xl font-black text-white">الإعدادات وتخصيص التحكم</h2>
              <div className="text-xs text-slate-400">ضبط الصوت، أذرع التحكم الخارجية، وتعيين أزرار اللعب</div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-5">
          {/* 1. Audio Sliders */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-3 text-sm font-extrabold text-white">
              <Volume2 className="w-4 h-4 text-amber-400" />
              <span>مستوى الصوت والموسيقى الحماسية</span>
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs text-slate-400 font-bold mb-1">
                  <span>الموسيقى التصويرية:</span>
                  <span className="text-amber-400 font-bold">{Math.round(musicVolume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={musicVolume}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    onUpdateMusicVolume(v);
                    soundSystem.setVolumes(v, sfxVolume);
                  }}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-400 font-bold mb-1">
                  <span>المؤثرات وصوت ماما:</span>
                  <span className="text-amber-400 font-bold">{Math.round(sfxVolume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={sfxVolume}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    onUpdateSfxVolume(v);
                    soundSystem.setVolumes(musicVolume, v);
                  }}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* 2. Gamepad & External Controller Support */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2 text-sm font-extrabold text-white">
                <Gamepad2 className="w-4 h-4 text-cyan-400" />
                <span>دعم أجهزة التحكم الخارجية (Gamepad)</span>
              </div>
              <div
                className={`text-[11px] px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                  connectedGamepad ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
                }`}
              >
                <div className={`w-2 h-2 rounded-full ${connectedGamepad ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                <span>{connectedGamepad ? 'متصل وجاهز!' : 'لا يوجد جهاز متصل'}</span>
              </div>
            </div>

            <div className="text-xs text-slate-400 leading-relaxed mb-3">
              {connectedGamepad ? (
                <div className="text-emerald-300 font-bold">
                  الجهاز النشط: {connectedGamepad}
                </div>
              ) : (
                'قم بتوصيل ذراع التحكم بالبلوتوث أو الـ USB للعب بدقة واحترافية عالية.'
              )}
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300 bg-slate-900 p-2.5 rounded-xl border border-slate-800">
              <div>🕹️ عصا الأنالوج أو الأسهم: التوجيه</div>
              <div>🅰️ زر A / X: القفز العالي</div>
              <div>🅱️ زر B / دائرة: التزحلق والنزول</div>
              <div>❎ زر X / مربع: تشغيل الزلاجة</div>
            </div>
          </div>

          {/* 3. Customizable Key Bindings */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-sm font-extrabold text-white">
                <Keyboard className="w-4 h-4 text-emerald-400" />
                <span>تخصيص أزرار لوحة المفاتيح</span>
              </div>
              <button
                onClick={handleResetBindings}
                className="text-xs text-amber-400 hover:text-amber-300 font-bold underline cursor-pointer"
              >
                استعادة الافتراضي
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {[
                { label: 'القفز (Jump)', action: 'jump' as keyof KeyBindings },
                { label: 'التزحلق (Slide)', action: 'slide' as keyof KeyBindings },
                { label: 'تحرك يسار (Left)', action: 'left' as keyof KeyBindings },
                { label: 'تحرك يمين (Right)', action: 'right' as keyof KeyBindings },
                { label: 'الزلاجة (Hoverboard)', action: 'board' as keyof KeyBindings },
                { label: 'إيقاف مؤقت (Pause)', action: 'pause' as keyof KeyBindings }
              ].map(({ label, action }) => (
                <div
                  key={action}
                  className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between"
                >
                  <span className="text-xs text-slate-300 font-bold">{label}</span>
                  <button
                    onClick={() => setListeningForAction(action)}
                    className={`px-3 py-1 rounded-lg text-xs font-black transition-all ${
                      listeningForAction === action
                        ? 'bg-amber-400 text-slate-950 animate-pulse'
                        : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700'
                    }`}
                  >
                    {listeningForAction === action ? 'اضغط أي زر...' : bindings[action]}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* 4. Touch & Haptics Options */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <span>إظهار أزرار اللمس على الشاشة (للهاتف)</span>
              </div>
              <input
                type="checkbox"
                checked={showOnScreenButtons}
                onChange={(e) => onToggleOnScreenButtons(e.target.checked)}
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                <Vibrate className="w-4 h-4 text-purple-400" />
                <span>الاهتزاز اللمسي (Haptic Feedback)</span>
              </div>
              <input
                type="checkbox"
                checked={gamepadVibration}
                onChange={(e) => onToggleGamepadVibration(e.target.checked)}
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-900/90 flex justify-end">
          <button
            onClick={onClose}
            className="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>حفظ والعودة</span>
          </button>
        </div>
      </div>
    </div>
  );
};
