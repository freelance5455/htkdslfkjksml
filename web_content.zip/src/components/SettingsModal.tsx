import React, { useState, useMemo } from 'react';
import { X, Check, Type, Palette, Volume2, MoveDown, BookOpen, Layers, FileText, Book, Star, Search, Sparkles, Bell } from 'lucide-react';
import { UserSettings, AppTheme, ArabicFont, ReaderMode } from '../types';
import { RECITERS } from '../data/reciters';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  onOpenSalawatReminder?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onOpenSalawatReminder,
}) => {
  const [reciterSearchQuery, setReciterSearchQuery] = useState('');

  if (!isOpen) return null;

  const currentFavorites = settings.favoriteReciters || [];

  const toggleFavorite = (reciterId: string) => {
    let next: string[];
    if (currentFavorites.includes(reciterId)) {
      next = currentFavorites.filter(id => id !== reciterId);
    } else {
      next = [...currentFavorites, reciterId];
    }
    onUpdateSettings({ favoriteReciters: next });
  };

  const filteredReciters = RECITERS.filter(r => {
    if (!reciterSearchQuery.trim()) return true;
    const q = reciterSearchQuery.trim().toLowerCase();
    return r.name.toLowerCase().includes(q) || r.subname.toLowerCase().includes(q);
  });

  const themes: { id: AppTheme; label: string; previewClass: string }[] = [
    { id: 'emerald', label: 'أخضر وذهبي (كلاسيكي)', previewClass: 'bg-emerald-900 border-amber-400 text-amber-200' },
    { id: 'parchment', label: 'ورق المصحف (دافئ)', previewClass: 'bg-[#f4efe4] border-amber-700 text-stone-900' },
    { id: 'dark', label: 'الوضع الليلي (مريح)', previewClass: 'bg-stone-950 border-stone-700 text-stone-100' },
    { id: 'light', label: 'فاتح نقي', previewClass: 'bg-white border-stone-300 text-stone-900' },
  ];

  const fonts: { id: ArabicFont; label: string; fontClass: string }[] = [
    { id: 'amiri-quran', label: 'خط مصحف المدينة (أميري قرآن)', fontClass: "font-['Amiri_Quran',serif]" },
    { id: 'cairo', label: 'خط النسخ الحديث (القاهرة)', fontClass: "font-['Cairo',sans-serif]" },
    { id: 'scheherazade', label: 'خط شهرزاد النبوي', fontClass: "font-['Scheherazade_New',serif]" },
  ];

  const getFontFamilyStyle = (font: ArabicFont) => {
    switch (font) {
      case 'amiri-quran':
        return "'Amiri Quran', serif";
      case 'cairo':
        return "'Cairo', sans-serif";
      case 'scheherazade':
        return "'Scheherazade New', serif";
      default:
        return "'Amiri Quran', serif";
    }
  };

  return (
    <div
      id="settings-modal"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200"
    >
      <div className="w-full max-w-lg rounded-t-3xl sm:rounded-3xl bg-stone-50 dark:bg-stone-900 shadow-2xl border border-stone-200 dark:border-stone-800 max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-200 dark:border-stone-800 shrink-0 bg-stone-100/60 dark:bg-stone-950/60">
          <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <Palette className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            إعدادات القراءة والمظهر
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-200 dark:hover:bg-stone-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-6 overflow-y-auto flex-1">
          {/* Live Preview Card */}
          <div className="p-4 rounded-2xl bg-stone-100 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700 text-center">
            <div className="text-xs text-stone-500 dark:text-stone-400 mb-2 font-sans">
              معاينة حجم الخط ونمطه
            </div>
            <div
              style={{
                fontSize: `${settings.fontSize}px`,
                fontFamily: getFontFamilyStyle(settings.font),
                lineHeight: 1.8,
              }}
              className="text-stone-900 dark:text-stone-100 select-none py-1"
            >
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </div>
          </div>

          {/* Reading Mode Selection */}
          <div>
            <label className="block text-sm font-bold text-stone-800 dark:text-stone-200 mb-2.5 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              نمط القراءة المفضل
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => onUpdateSettings({ readerMode: 'pages' })}
                className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center gap-1.5 ${
                  settings.readerMode === 'pages'
                    ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold ring-1 ring-emerald-500'
                    : 'border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300'
                }`}
              >
                <Layers className="w-5 h-5" />
                <span className="text-xs">صفحة بصفحة</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateSettings({ readerMode: 'verses' })}
                className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center gap-1.5 ${
                  settings.readerMode === 'verses'
                    ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold ring-1 ring-emerald-500'
                    : 'border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300'
                }`}
              >
                <FileText className="w-5 h-5" />
                <span className="text-xs">آيات منفصلة</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateSettings({ readerMode: 'mushaf' })}
                className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center gap-1.5 ${
                  settings.readerMode === 'mushaf'
                    ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold ring-1 ring-emerald-500'
                    : 'border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300'
                }`}
              >
                <Book className="w-5 h-5" />
                <span className="text-xs">مصحف مستمر</span>
              </button>
            </div>
          </div>

          {/* Font Size Adjuster */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-bold text-stone-800 dark:text-stone-200 flex items-center gap-2">
                <Type className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                حجم خط الآيات
              </label>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                {settings.fontSize} بكسل
              </span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs text-stone-400">صغير</span>
              <input
                id="font-size-range"
                type="range"
                min={18}
                max={42}
                step={2}
                value={settings.fontSize}
                onChange={(e) => onUpdateSettings({ fontSize: Number(e.target.value) })}
                className="w-full accent-emerald-600 h-2 bg-stone-200 dark:bg-stone-700 rounded-lg cursor-pointer"
              />
              <span className="text-base text-stone-400 font-bold">كبير</span>
            </div>
          </div>

          {/* Font Family Selection */}
          <div>
            <label className="block text-sm font-bold text-stone-800 dark:text-stone-200 mb-2.5">
              نوع الخط القرآني
            </label>
            <div className="grid grid-cols-1 gap-2">
              {fonts.map((f) => (
                <button
                  key={f.id}
                  onClick={() => onUpdateSettings({ font: f.id })}
                  className={`w-full p-3 rounded-xl text-right flex items-center justify-between border transition ${
                    settings.font === f.id
                      ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 font-bold'
                      : 'border-stone-200 dark:border-stone-700 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200'
                  }`}
                >
                  <span className={f.fontClass}>{f.label}</span>
                  {settings.font === f.id && (
                    <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Theme Selection */}
          <div>
            <label className="block text-sm font-bold text-stone-800 dark:text-stone-200 mb-2.5">
              نمط المظهر والألوان
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              {themes.map((t) => (
                <button
                  key={t.id}
                  onClick={() => onUpdateSettings({ theme: t.id })}
                  className={`p-3 rounded-xl border text-right transition flex items-center justify-between ${t.previewClass} ${
                    settings.theme === t.id
                      ? 'ring-2 ring-emerald-500 ring-offset-2 dark:ring-offset-stone-900'
                      : 'opacity-85 hover:opacity-100'
                  }`}
                >
                  <span className="text-xs font-bold">{t.label}</span>
                  {settings.theme === t.id && <Check className="w-4 h-4" />}
                </button>
              ))}
            </div>
          </div>

          {/* Default Reciter */}
          <div>
            <label className="block text-sm font-bold text-stone-800 dark:text-stone-200 mb-2.5 flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              القارئ الافتراضي للتلاوة
            </label>
            <select
              id="settings-reciter-select"
              value={settings.selectedReciterId}
              onChange={(e) => onUpdateSettings({ selectedReciterId: e.target.value })}
              className="w-full p-3 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 text-sm font-medium focus:ring-2 focus:ring-emerald-500 outline-none"
            >
              {RECITERS.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name} ({r.subname})
                </option>
              ))}
            </select>
          </div>

          {/* Favorite Reciters Section for Quick Audio Switching */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-sm font-bold text-stone-800 dark:text-stone-200 flex items-center gap-2">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                القراء المفضلون (للتبديل السريع)
              </label>
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 font-bold">
                {currentFavorites.length} محدد
              </span>
            </div>
            <p className="text-xs text-stone-500 dark:text-stone-400 mb-3">
              حدد القراء الذين تحب الاستماع إليهم؛ ستظهر أسماؤهم كأزرار تبديل سريع مباشرة في شريط المشغل لتغيير القارئ فوراً دون إيقاف التلاوة.
            </p>

            {/* Reciter Search */}
            <div className="relative mb-2">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={reciterSearchQuery}
                onChange={(e) => setReciterSearchQuery(e.target.value)}
                placeholder="ابحث بين القراء لإضافتهم للمفضلة..."
                className="w-full pr-9 pl-3 py-2 text-xs rounded-xl bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Reciter Checkboxes / Selection List */}
            <div className="max-h-56 overflow-y-auto rounded-2xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800/80 divide-y divide-stone-100 dark:divide-stone-700/60 p-1">
              {filteredReciters.length === 0 ? (
                <div className="p-4 text-center text-xs text-stone-400">
                  لم يتم العثور على قارئ مطابق للبحث
                </div>
              ) : (
                filteredReciters.map((r) => {
                  const isFav = currentFavorites.includes(r.id);
                  const isDefault = settings.selectedReciterId === r.id;
                  return (
                    <div
                      key={`setting-reciter-${r.id}`}
                      onClick={() => toggleFavorite(r.id)}
                      className={`px-3 py-2.5 rounded-xl cursor-pointer flex items-center justify-between transition ${
                        isFav
                          ? 'bg-amber-50/80 dark:bg-amber-950/30'
                          : 'hover:bg-stone-50 dark:hover:bg-stone-700/40'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition ${
                            isFav
                              ? 'bg-amber-400 text-stone-950 shadow-xs'
                              : 'border border-stone-300 dark:border-stone-600 text-stone-300 dark:text-stone-600'
                          }`}
                        >
                          <Star className={`w-3.5 h-3.5 ${isFav ? 'fill-stone-950' : ''}`} />
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs sm:text-sm font-semibold text-stone-800 dark:text-stone-200 flex items-center gap-1.5 truncate">
                            <span>{r.name}</span>
                            {isDefault && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-normal">
                                الافتراضي
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-stone-500 dark:text-stone-400">
                            {r.subname}
                          </div>
                        </div>
                      </div>

                      <span
                        className={`text-[11px] font-medium shrink-0 mr-2 ${
                          isFav ? 'text-amber-600 dark:text-amber-400 font-bold' : 'text-stone-400'
                        }`}
                      >
                        {isFav ? 'مفضّل' : 'إضافة'}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Salawat Reminder Card */}
          <div className="p-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/5 dark:bg-emerald-950/20 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-bold text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                  <span>التذكير بالصلاة على النبي</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold">ﷺ</span>
                </div>
                <div className="text-xs text-stone-500 dark:text-stone-400">
                  {settings.salawatReminder?.enabled
                    ? `مفعّل كل ${settings.salawatReminder.intervalMinutes} دقيقة • بالخلفية وإشعارات دائمة`
                    : 'غير مفعّل - تنبيه دوري صوتي وبصري'}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenSalawatReminder?.();
              }}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs shrink-0"
            >
              ضبط التذكير
            </button>
          </div>

          {/* Auto Scroll Switch */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-2">
              <MoveDown className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <div>
                <div className="text-sm font-bold text-stone-800 dark:text-stone-200">
                  التمرير التلقائي مع التلاوة
                </div>
                <div className="text-xs text-stone-500 dark:text-stone-400">
                  مزامنة الشاشة تلقائياً مع الآية التي يتم تلاوتها
                </div>
              </div>
            </div>
            <input
              id="auto-scroll-toggle"
              type="checkbox"
              checked={settings.autoScroll}
              onChange={(e) => onUpdateSettings({ autoScroll: e.target.checked })}
              className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-100/80 dark:bg-stone-950/80 border-t border-stone-200 dark:border-stone-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm transition shadow-md"
          >
            حفظ وإغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
