import React from 'react';
import { X, Sun, Moon, Disc3, SkipForward } from 'lucide-react';
import { SOUNDTRACK_TRACKS, soundEngine } from '../audio/soundEngine';
import { TRANSLATIONS } from '../i18n/translations';
import { AudioSettings, Language, ThemeMode, TouchMode } from '../types/game';

interface SettingsModalProps {
  open: boolean;
  language: Language;
  theme: ThemeMode;
  audio: AudioSettings;
  touchMode: TouchMode;
  onClose: () => void;
  onChangeLanguage: (lang: Language) => void;
  onChangeTheme: (theme: ThemeMode) => void;
  onChangeAudio: (audio: AudioSettings) => void;
  onChangeTouchMode: (mode: TouchMode) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  open,
  language,
  theme,
  audio,
  touchMode,
  onClose,
  onChangeLanguage,
  onChangeTheme,
  onChangeAudio,
  onChangeTouchMode,
}) => {
  if (!open) return null;
  const t = TRANSLATIONS[language];

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-white dark:bg-[#0D1426] border border-slate-200 dark:border-slate-700 rounded-2xl p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
          <h2 className="font-display font-extrabold text-2xl text-slate-900 dark:text-white">
            {t.navSettings}
          </h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-5">
          {/* Language & Commentary */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
              {t.language}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  ['pt-BR', 'Português (BR)'],
                  ['es', 'Español (ES)'],
                  ['en', 'English (EN)'],
                ] as Array<[Language, string]>
              ).map(([code, label]) => (
                <button
                  key={code}
                  onClick={() => onChangeLanguage(code)}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold border ${
                    language === code
                      ? 'bg-amber-400 border-amber-400 text-slate-950'
                      : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Theme Mode */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
              {t.themeMode}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onChangeTheme('dark')}
                className={`py-2.5 px-3 rounded-lg text-xs font-semibold border flex items-center justify-center gap-2 ${
                  theme === 'dark'
                    ? 'bg-amber-400 border-amber-400 text-slate-950'
                    : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>{t.darkTheme}</span>
              </button>
              <button
                onClick={() => onChangeTheme('light')}
                className={`py-2.5 px-3 rounded-lg text-xs font-semibold border flex items-center justify-center gap-2 ${
                  theme === 'light'
                    ? 'bg-amber-400 border-amber-400 text-slate-950'
                    : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>{t.lightTheme}</span>
              </button>
            </div>
          </div>

          {/* Audio Controls */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-800 dark:text-slate-200">
                {t.commentaryLabel}
              </span>
              <button
                onClick={() => onChangeAudio({ ...audio, commentaryEnabled: !audio.commentaryEnabled })}
                className={`px-3 py-1 rounded-lg text-xs font-bold ${
                  audio.commentaryEnabled
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                }`}
              >
                {audio.commentaryEnabled ? 'ON' : 'OFF'}
              </button>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-800 dark:text-slate-200">
                {t.sfxLabel}
              </span>
              <button
                onClick={() => onChangeAudio({ ...audio, sfxEnabled: !audio.sfxEnabled })}
                className={`px-3 py-1 rounded-lg text-xs font-bold ${
                  audio.sfxEnabled
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                }`}
              >
                {audio.sfxEnabled ? 'ON' : 'OFF'}
              </button>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-800 dark:text-slate-200">
                {t.musicLabel}
              </span>
              <button
                onClick={() => {
                  soundEngine.unlock();
                  onChangeAudio({ ...audio, musicEnabled: !audio.musicEnabled });
                }}
                className={`px-3 py-1 rounded-lg text-xs font-bold ${
                  audio.musicEnabled
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                }`}
              >
                {audio.musicEnabled ? 'ON' : 'OFF'}
              </button>
            </div>
            <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 min-w-0">
                <Disc3 className="w-4 h-4 text-amber-500 dark:text-amber-400 shrink-0" />
                <div className="min-w-0">
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    {t.musicTrack}
                  </div>
                  <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                    {SOUNDTRACK_TRACKS[audio.trackIndex % SOUNDTRACK_TRACKS.length].title}
                  </div>
                </div>
              </div>
              <button
                onClick={() => {
                  soundEngine.unlock();
                  onChangeAudio({
                    ...audio,
                    musicEnabled: true,
                    trackIndex: (audio.trackIndex + 1) % SOUNDTRACK_TRACKS.length,
                  });
                }}
                className="shrink-0 px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-colors"
              >
                <SkipForward className="w-3.5 h-3.5" />
                <span>{t.changeMusic}</span>
              </button>
            </div>
          </div>

          {/* Mobile Touch Controls Override */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
              {t.touchControls}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  ['auto', t.touchAuto],
                  ['on', t.touchOn],
                  ['off', t.touchOff],
                ] as Array<[TouchMode, string]>
              ).map(([m, label]) => (
                <button
                  key={m}
                  onClick={() => onChangeTouchMode(m)}
                  className={`py-2 px-2 rounded-lg text-xs font-semibold border ${
                    touchMode === m
                      ? 'bg-amber-400 border-amber-400 text-slate-950'
                      : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
