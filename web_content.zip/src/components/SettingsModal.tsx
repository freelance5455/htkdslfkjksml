import React, { useState, useEffect } from 'react';
import {
  X,
  Server,
  Key,
  Volume2,
  User,
  ExternalLink,
  Cpu,
  PlusCircle,
  CheckCircle,
  Play,
  Gauge,
  Sliders,
  ShieldAlert,
  History,
  Trash2,
  CornerDownLeft,
  ChevronDown,
  ChevronUp,
  Radio,
} from 'lucide-react';
import { GROQ_API_KEYS, AUTHOR_INFO, RENDER_PRODUCTION_URL, GROQ_MODEL } from '../data/config';
import { groqService } from '../services/groqService';
import { deviceService } from '../services/deviceService';
import { voiceHistoryService, VoiceCommandItem } from '../services/voiceHistoryService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  isTTSActive: boolean;
  onToggleTTS: (val: boolean) => void;
  isContinuousMode?: boolean;
  onToggleContinuousMode?: () => void;
  onOpenCodeViewer: () => void;
  onDownloadZip: () => void;
  onApiKeyUpdated?: () => void;
  onSelectCommand?: (command: string) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  isTTSActive,
  onToggleTTS,
  isContinuousMode = false,
  onToggleContinuousMode,
  onOpenCodeViewer,
  onDownloadZip,
  onApiKeyUpdated,
  onSelectCommand,
}) => {
  const [useRender, setUseRender] = useState(groqService.getBackendMode().useRenderBackend);
  const [renderUrl, setRenderUrl] = useState(RENDER_PRODUCTION_URL);
  const [customKeyInput, setCustomKeyInput] = useState(groqService.getCustomApiKey());
  const [keySavedToast, setKeySavedToast] = useState(false);
  const currentKeyIndex = groqService.getBackendMode().currentKeyIndex;

  // Ovoz sozlamalari holatlari
  const initialVoice = deviceService.getVoiceSettings();
  const [voiceRate, setVoiceRate] = useState<number>(initialVoice.rate);
  const [voiceVolume, setVoiceVolume] = useState<number>(initialVoice.volume);
  const [voicePitch, setVoicePitch] = useState<number>(initialVoice.pitch);
  const [isPlayingTest, setIsPlayingTest] = useState(false);

  // Ovozli buyruqlar tarixi holatlari
  const [voiceHistory, setVoiceHistory] = useState<VoiceCommandItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const vs = deviceService.getVoiceSettings();
      setVoiceRate(vs.rate);
      setVoiceVolume(vs.volume);
      setVoicePitch(vs.pitch);
      setVoiceHistory(voiceHistoryService.getHistory());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackendChange = (isRender: boolean) => {
    setUseRender(isRender);
    groqService.setBackendMode(isRender, renderUrl);
  };

  const handleSaveCustomKey = () => {
    groqService.setCustomApiKey(customKeyInput);
    setKeySavedToast(true);
    setTimeout(() => setKeySavedToast(false), 2500);
    onApiKeyUpdated?.();
  };

  const handleRateChange = (newRate: number) => {
    setVoiceRate(newRate);
    deviceService.setVoiceSettings({ rate: newRate });
  };

  const handleVolumeChange = (newVol: number) => {
    setVoiceVolume(newVol);
    deviceService.setVoiceSettings({ volume: newVol });
  };

  const handlePitchChange = (newPitch: number) => {
    setVoicePitch(newPitch);
    deviceService.setVoiceSettings({ pitch: newPitch });
  };

  const handleTestVoice = () => {
    setIsPlayingTest(true);
    deviceService.speak("Assalomu alaykum, Sir! Jarvis ovoz sozlamalari sinovi muvaffaqiyatli bajarildi.", () => {
      setIsPlayingTest(false);
    });
  };

  const handleClearHistory = () => {
    voiceHistoryService.clearHistory();
    setVoiceHistory([]);
  };

  const handleExecuteHistoryItem = (cmd: string) => {
    onClose();
    if (onSelectCommand) {
      onSelectCommand(cmd);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-950 border border-cyan-500/40 rounded-xl overflow-hidden shadow-[0_0_35px_rgba(6,182,212,0.2)] max-h-[92vh] flex flex-col">
        {/* Yuqori sarlavha */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-cyan-500/20 bg-slate-900/60 shrink-0">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <span className="font-display text-sm tracking-wider text-cyan-300">
              JARVIS // TIZIM VA OVOZ SOZLAMALARI
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white transition-colors rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sozlamalar kontenti */}
        <div className="p-5 overflow-y-auto space-y-5 text-sm">
          
          {/* =========================================================
              OVOZLI BUYRUQLAR TARIXI (SO'NGGI 10 TA BUYRUQ)
              ========================================================= */}
          <div className="p-3.5 bg-slate-900/70 rounded-xl border border-cyan-500/30 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-cyan-300 uppercase tracking-wider">
                <History className="w-4 h-4 text-cyan-400" />
                <span>Ovozli Buyruqlar Tarixi ({voiceHistory.length}/10)</span>
              </div>
              <button
                type="button"
                onClick={() => setShowHistory(!showHistory)}
                className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 transition-colors font-medium cursor-pointer"
              >
                <span>{showHistory ? "Yashirish" : "Tarixni ko'rish"}</span>
                {showHistory ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>
            </div>

            {showHistory && (
              <div className="space-y-2 pt-2 border-t border-slate-800 animate-fadeIn">
                {voiceHistory.length === 0 ? (
                  <p className="text-xs text-slate-500 text-center py-3">
                    Hozircha ovozli buyruqlar tarixi mavjud emas, Sir.
                  </p>
                ) : (
                  <>
                    <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                      {voiceHistory.map((item, idx) => (
                        <div
                          key={item.id}
                          className="flex items-center justify-between p-2 rounded-lg bg-slate-950/70 border border-slate-800 hover:border-cyan-500/40 text-xs transition-colors"
                        >
                          <div className="flex items-center gap-2 overflow-hidden mr-2">
                            <span className="font-mono text-cyan-500 text-[10px]">#{idx + 1}</span>
                            <span className="text-slate-200 truncate font-medium">"{item.command}"</span>
                            <span className="text-[10px] text-slate-500 shrink-0 font-mono">
                              {item.formattedTime}
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleExecuteHistoryItem(item.command)}
                            className="p-1 text-cyan-400 hover:text-white rounded hover:bg-slate-800 shrink-0 transition-colors"
                            title="Ushbu buyruqni qayta ishga tushirish"
                          >
                            <CornerDownLeft className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        type="button"
                        onClick={handleClearHistory}
                        className="flex items-center gap-1 text-[11px] text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Tarixni tozalash</span>
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          {/* =========================================================
              DOIMIY TINGLASH REJIMI (HANDS-FREE / CONTINUOUS LISTENING)
              ========================================================= */}
          <div className="space-y-2 p-3.5 bg-slate-900/70 rounded-xl border border-rose-500/40">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-xs font-semibold text-rose-300 uppercase tracking-wider">
                <Radio className={`w-4 h-4 ${isContinuousMode ? 'text-rose-400 animate-pulse' : 'text-rose-500'}`} />
                Doimiy Tinglash Rejimi (Hands-Free)
              </label>
              <button
                type="button"
                onClick={() => onToggleContinuousMode?.()}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                  isContinuousMode ? 'bg-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.6)]' : 'bg-slate-700'
                }`}
                title={isContinuousMode ? "Doimiy tinglash yoqilgan" : "Doimiy tinglash o'chirilgan"}
              >
                <span
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-slate-950 shadow ring-0 transition duration-200 ease-in-out ${
                    isContinuousMode ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Ushbu rejim yoqilganda mikrofon doimiy faol bo'lib turadi. Siz ekranga teginmasdan buyruq bersangiz, Jarvis har bir gapni avtomatik qabul qilib javob beradi.
            </p>
            {isContinuousMode && (
              <div className="p-2 rounded bg-rose-950/50 border border-rose-500/30 text-[11px] text-rose-300 flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                </span>
                <span>Mikrofon hozirda uzluksiz tinglamoqda, Sir.</span>
              </div>
            )}
          </div>

          {/* =========================================================
              OVOZ SOZLAMALARI (TEZLIK, BALANDLIK, TEMBR VA TEST)
              ========================================================= */}
          <div className="space-y-3 p-3.5 bg-slate-900/70 rounded-xl border border-cyan-500/30">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-xs font-semibold text-cyan-300 uppercase tracking-wider">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                Jarvis Ovozini Sozlash (Tezlik va Balandlik)
              </label>
              <button
                type="button"
                onClick={() => onToggleTTS(!isTTSActive)}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                  isTTSActive ? 'bg-cyan-400' : 'bg-slate-700'
                }`}
                title={isTTSActive ? "Ovozli o'qish yoqilgan" : "Ovozli o'qish o'chirilgan"}
              >
                <span
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-slate-950 shadow ring-0 transition duration-200 ease-in-out ${
                    isTTSActive ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* 1. Ovoz tezligi (Rate) */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 flex items-center gap-1.5">
                  <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                  Ovoz tezligi (Speed):
                </span>
                <span className="font-mono text-cyan-300 font-bold">{voiceRate.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.1"
                value={voiceRate}
                onChange={(e) => handleRateChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0.5x (Sekin)</span>
                <span>1.0x (Normal)</span>
                <span>2.0x (Tez)</span>
              </div>
            </div>

            {/* 2. Ovoz balandligi (Volume) */}
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                  Ovoz balandligi (Volume):
                </span>
                <span className="font-mono text-cyan-300 font-bold">{Math.round(voiceVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={voiceVolume}
                onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>10%</span>
                <span>50%</span>
                <span>100%</span>
              </div>
            </div>

            {/* 3. Ovoz tembri (Pitch) */}
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                  Ovoz tembri (Pitch):
                </span>
                <span className="font-mono text-cyan-300 font-bold">{voicePitch.toFixed(1)}</span>
              </div>
              <input
                type="range"
                min="0.6"
                max="1.4"
                step="0.1"
                value={voicePitch}
                onChange={(e) => handlePitchChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>Yo'g'on / Past</span>
                <span>Standart</span>
                <span>Ingichka / Baland</span>
              </div>
            </div>

            {/* Ovozni sinab ko'rish tugmasi */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleTestVoice}
                disabled={isPlayingTest}
                className="w-full py-2 px-3 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-400/50 text-cyan-300 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isPlayingTest ? "Jarvis gapirmoqda..." : "Ovozni Sinab Ko'rish (Test)"}</span>
              </button>
            </div>
          </div>

          {/* Yangi API Kalit kiritish */}
          <div className="space-y-2 p-3 bg-cyan-950/30 rounded-lg border border-cyan-500/30">
            <label className="flex items-center gap-2 text-xs font-semibold text-cyan-300 uppercase tracking-wider">
              <PlusCircle className="w-4 h-4 text-cyan-400" />
              Yangi Shaxsiy API Kalit Kiritish (Groq)
            </label>
            <p className="text-[11px] text-slate-400">
              Mavjud 5 ta kalit o'rniga o'z kalitingizni ishlatmoqchi bo'lsangiz, kiriting:
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="gsk_... kalitingiz"
                value={customKeyInput}
                onChange={(e) => setCustomKeyInput(e.target.value)}
                className="flex-1 bg-slate-900 border border-cyan-500/30 rounded-lg px-3 py-1.5 text-xs text-cyan-200 outline-none focus:border-cyan-400 font-mono"
              />
              <button
                type="button"
                onClick={handleSaveCustomKey}
                className="px-3 py-1.5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs rounded-lg transition-colors cursor-pointer"
              >
                Saqlash
              </button>
            </div>
            {keySavedToast && (
              <div className="flex items-center gap-1.5 text-xs text-emerald-400 mt-1 font-mono">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Yangi API kalit faollashtirildi, Sir!</span>
              </div>
            )}
          </div>

          {/* Backend marshrutlash */}
          <div className="space-y-2.5">
            <label className="flex items-center gap-2 text-xs font-semibold text-slate-300 uppercase tracking-wider">
              <Server className="w-4 h-4 text-cyan-400" />
              AI So'rovlar Marshrutlash Rejimi
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleBackendChange(false)}
                className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                  !useRender
                    ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
                    : 'border-slate-800 bg-slate-900/40 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-medium text-xs">CORS-Free Server & Fallback</div>
                <div className="text-[11px] text-slate-400 mt-1">
                  5 ta kalit rotatsiyasi + Gemini zaxira
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleBackendChange(true)}
                className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                  useRender
                    ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
                    : 'border-slate-800 bg-slate-900/40 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-medium text-xs">Render FastAPI Server</div>
                <div className="text-[11px] text-slate-400 mt-1">
                  https://jarvis-ai-epk1.onrender.com
                </div>
              </button>
            </div>
          </div>

          {/* Groq 5 ta API Kalitlari Holati */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-xs font-semibold text-slate-300 uppercase tracking-wider">
                <Key className="w-4 h-4 text-cyan-400" />
                Mavjud 5 ta Groq Kalitlari
              </label>
              <span className="text-[11px] font-mono text-cyan-400">
                Model: {GROQ_MODEL}
              </span>
            </div>
            <div className="space-y-1.5 bg-slate-900/40 p-3 rounded-lg border border-slate-800">
              {GROQ_API_KEYS.map((key, idx) => {
                const isActive = idx === currentKeyIndex;
                const masked = `${key.slice(0, 8)}...${key.slice(-4)}`;
                return (
                  <div
                    key={idx}
                    className={`flex items-center justify-between text-xs py-1 px-2 rounded ${
                      isActive ? 'bg-cyan-950/60 text-cyan-300 font-medium' : 'text-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-mono">
                      <span>Kalit #{idx + 1}:</span>
                      <span className="text-slate-500">{masked}</span>
                    </div>
                    <span className="text-[10px] font-mono">
                      {isActive ? '● JORIY NAVBAT' : 'ZAXIRADA'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Android APK Ruxsatlari haqida qo'llanma */}
          <div className="p-3 bg-slate-900/60 rounded-lg border border-cyan-500/20 text-xs space-y-1.5">
            <div className="flex items-center gap-1.5 font-semibold text-cyan-300">
              <ShieldAlert className="w-4 h-4 text-cyan-400" />
              <span>Android APK-da Ruxsatlar So'rash</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Telefoningizda APK o'rnatilgach, ilova ochilishi bilan Mikrofon va Kamera ruxsatlarini so'raydi. AndroidManifest.xml fayli tayyor holatda ZIP arxivga kiritilgan.
            </p>
          </div>

          {/* Dasturchi */}
          <div className="p-3 bg-slate-900/60 rounded-lg border border-cyan-500/20 text-xs space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Dasturchi:</span>
              <span className="text-cyan-300 font-bold">{AUTHOR_INFO.name}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">GitHub:</span>
              <a
                href={AUTHOR_INFO.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="text-cyan-400 hover:underline flex items-center gap-1"
              >
                {AUTHOR_INFO.github}
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Telegram:</span>
              <a
                href={AUTHOR_INFO.telegramUrl}
                target="_blank"
                rel="noreferrer"
                className="text-cyan-400 hover:underline flex items-center gap-1"
              >
                {AUTHOR_INFO.telegram}
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Tugmalar */}
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenCodeViewer();
              }}
              className="flex-1 py-2.5 px-3 bg-slate-900 hover:bg-slate-850 border border-cyan-500/30 text-cyan-300 rounded-lg text-xs font-semibold text-center transition-colors cursor-pointer"
            >
              Kodlarni ko'rish (server.py)
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onDownloadZip();
              }}
              className="flex-1 py-2.5 px-3 bg-cyan-400 hover:bg-cyan-300 text-slate-950 rounded-lg text-xs font-bold text-center transition-colors shadow-sm cursor-pointer"
            >
              APK uchun ZIP yuklab olish
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
