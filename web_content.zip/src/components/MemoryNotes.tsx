import React, { useState } from 'react';
import { Bookmark, Plus, Trash2, Sparkles, Check, Tag } from 'lucide-react';
import { MemoryItem } from '../types';
import { deleteMemory, saveMemory } from '../utils/storage';

interface MemoryNotesProps {
  memories: MemoryItem[];
  onAddMemory: (memory: MemoryItem) => void;
  onDeleteMemory: (id: string) => void;
}

export const MemoryNotes: React.FC<MemoryNotesProps> = ({
  memories,
  onAddMemory,
  onDeleteMemory,
}) => {
  const [newText, setNewText] = useState('');
  const [category, setCategory] = useState<MemoryItem['category']>('fact');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;

    const item: MemoryItem = {
      id: `mem_${Date.now()}`,
      text: newText.trim(),
      category,
      timestamp: Date.now(),
    };

    onAddMemory(item);
    saveMemory(item);
    setNewText('');
  };

  const handleDelete = (id: string) => {
    onDeleteMemory(id);
    deleteMemory(id);
  };

  return (
    <div className="p-4 lg:p-6 w-full max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
          <Bookmark className="w-5 h-5 text-pink-400" />
          Julli Assistant Memory & Notes Notebook
        </h2>
        <p className="text-xs text-slate-400">
          Things Julli remembers about you, brand preferences, facts, and custom instructions ("Yaad Rakhna").
        </p>
      </div>

      {/* Add Memory Form */}
      <form onSubmit={handleCreate} className="glass-panel p-4 rounded-2xl border border-slate-800 space-y-3">
        <div className="flex gap-2">
          <input
            type="text"
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            placeholder='Add something for Julli to remember (e.g. "Brand primary color is Deep Indigo #4f46e5")...'
            className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-500"
          />
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as any)}
            className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none"
          >
            <option value="fact">Fact</option>
            <option value="brand">Brand Rule</option>
            <option value="preference">Preference</option>
            <option value="instruction">Instruction</option>
          </select>
          <button
            type="submit"
            disabled={!newText.trim()}
            className="px-4 py-2 bg-pink-600 hover:bg-pink-500 disabled:opacity-40 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-md shadow-pink-600/30"
          >
            <Plus className="w-4 h-4" /> Save Memory
          </button>
        </div>
      </form>

      {/* Memories List */}
      <div className="space-y-3">
        {memories.length === 0 ? (
          <div className="p-8 text-center border-2 border-dashed border-slate-800 rounded-2xl text-slate-500 text-xs">
            No memories stored yet. You can type here or speak to Julli: "Hey Julli yaad rakhna..."
          </div>
        ) : (
          memories.map((mem) => (
            <div
              key={mem.id}
              className="p-3.5 bg-slate-900/70 border border-slate-800 rounded-xl flex items-center justify-between gap-3 group hover:border-pink-500/30 transition-all"
            >
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-pink-400 shrink-0" />
                <div>
                  <p className="text-xs text-slate-200 font-medium">{mem.text}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] font-mono text-pink-400 uppercase tracking-wider">{mem.category}</span>
                    <span className="text-[10px] text-slate-500">
                      {new Date(mem.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => handleDelete(mem.id)}
                className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 transition-all"
                title="Delete Memory"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
