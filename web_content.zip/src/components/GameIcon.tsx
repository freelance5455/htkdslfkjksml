import {
  BookOpen,
  CheckCircle2,
  Headphones,
  Keyboard,
  Layers,
  Link2,
  PenTool,
  Puzzle,
  Shuffle,
  Sparkles,
} from 'lucide-react';
import type { GameModeId } from '../types';

interface GameIconProps {
  mode: GameModeId;
  className?: string;
}

export function GameIcon({ mode, className = 'w-5 h-5' }: GameIconProps) {
  switch (mode) {
    case 'listen_type':
      return <Headphones className={className} aria-hidden="true" />;
    case 'missing':
      return <Puzzle className={className} aria-hidden="true" />;
    case 'scramble':
      return <Shuffle className={className} aria-hidden="true" />;
    case 'type_en':
      return <Keyboard className={className} aria-hidden="true" />;
    case 'type_ar':
      return <PenTool className={className} aria-hidden="true" />;
    case 'mcq':
      return <CheckCircle2 className={className} aria-hidden="true" />;
    case 'tf':
      return <Layers className={className} aria-hidden="true" />;
    case 'match':
      return <Link2 className={className} aria-hidden="true" />;
    case 'mixed':
      return <Sparkles className={className} aria-hidden="true" />;
    case 'study':
      return <BookOpen className={className} aria-hidden="true" />;
  }
}
