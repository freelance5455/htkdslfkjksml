import React, { useState } from 'react';
import { Volume2, Edit3, Sparkles, Star, ArrowRight, ArrowLeft, ToggleLeft, ToggleRight } from 'lucide-react';
import { ENGLISH_ALPHABET } from '../data/learningData';
import { EnglishLetterItem } from '../types/curriculum';
import { sound } from '../utils/sound';

interface EnglishClassProps {
  childName: string;
  onTraceLetter: (item: { letter: string; name: string; example: string }) => void;
  onEarnStar: () => void;
}

export const EnglishClass: React.FC<EnglishClassProps> = ({
  childName,
  onTraceLetter,
  onEarnStar,
}) => {
  const [selectedLetter, setSelectedLetter] = useState<EnglishLetterItem>(ENGLISH_ALPHABET[0]);
  const [isCaseUpper, setIsCaseUpper] = useState(true);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [learnedLetters, setLearnedLetters] = useState<Set<string>>(new Set(['a']));

  const handleSelectLetter = (item: EnglishLetterItem) => {
    sound.playPopSound();
    setSelectedLetter(item);
    playLetterAudio(item);

    if (!learnedLetters.has(item.id)) {
      setLearnedLetters((prev) => new Set(prev).add(item.id));
      onEarnStar();
    }
  };

  const playLetterAudio = async (item: EnglishLetterItem) => {
    if (isPlayingAudio) return;
    setIsPlayingAudio(true);
    const textToSay = `Letter ${item.upper}! ${item.phonic}! ${item.upper} is for ${item.word}! ${item.sentence}`;
    await sound.speakWithGeminiOrLocal(textToSay, 'en');
    setIsPlayingAudio(false);
  };

  const handleNext = () => {
    const currentIndex = ENGLISH_ALPHABET.findIndex((l) => l.id === selectedLetter.id);
    const nextIndex = (currentIndex + 1) % ENGLISH_ALPHABET.length;
    handleSelectLetter(ENGLISH_ALPHABET[nextIndex]);
  };

  const handlePrev = () => {
    const currentIndex = ENGLISH_ALPHABET.findIndex((l) => l.id === selectedLetter.id);
    const prevIndex = (currentIndex - 1 + ENGLISH_ALPHABET.length) % ENGLISH_ALPHABET.length;
    handleSelectLetter(ENGLISH_ALPHABET[prevIndex]);
  };

  return (
    <div className="space-y-6">
      {/* Featured Big Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-sky-500 via-blue-600 to-indigo-700 p-6 sm:p-8 text-white shadow-xl border-4 border-sky-300">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Big Letter Card */}
          <div className="flex flex-col items-center">
            <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-3xl bg-white text-blue-700 flex flex-col items-center justify-center shadow-2xl border-4 border-yellow-300 animate-float">
              <span className="font-fun text-7xl sm:text-8xl font-black leading-none select-none tracking-tight">
                {isCaseUpper ? selectedLetter.upper : selectedLetter.lower}
              </span>
              <span className="text-xs sm:text-sm font-bold text-sky-600 mt-1">
                {selectedLetter.upper} {selectedLetter.lower} • {selectedLetter.word}
              </span>
            </div>

            <div className="mt-4 flex items-center gap-2">
              <button
                onClick={() => playLetterAudio(selectedLetter)}
                disabled={isPlayingAudio}
                className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-yellow-950 font-extrabold rounded-full text-sm shadow-lg flex items-center gap-2 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
              >
                <Volume2 className={`w-5 h-5 ${isPlayingAudio ? 'animate-bounce text-blue-700' : ''}`} />
                <span>{isPlayingAudio ? 'Speaking...' : 'Listen Phonics 🔊'}</span>
              </button>

              <button
                onClick={() =>
                  onTraceLetter({
                    letter: selectedLetter.upper,
                    name: `Letter ${selectedLetter.upper}`,
                    example: selectedLetter.word,
                  })
                }
                className="px-4 py-2 bg-white hover:bg-sky-50 text-blue-700 font-extrabold rounded-full text-sm shadow-lg flex items-center gap-2 active:scale-95 transition-all cursor-pointer"
              >
                <Edit3 className="w-5 h-5 text-blue-600" />
                <span>Trace Letter ✍️</span>
              </button>
            </div>
          </div>

          {/* Letter Info & Phonics */}
          <div className="flex-1 text-center md:text-right space-y-3">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3.5 py-1 rounded-full text-xs font-bold text-yellow-200">
              <Sparkles className="w-3.5 h-3.5" />
              <span>English ABC Class for {childName} 🇬🇧</span>
            </div>

            <h3 className="text-2xl sm:text-4xl font-extrabold text-white flex items-center justify-center md:justify-start gap-3">
              <span>{selectedLetter.upper} is for {selectedLetter.word}</span>
              <span className="text-4xl sm:text-5xl">{selectedLetter.emoji}</span>
            </h3>

            <div className="flex items-center justify-center md:justify-start gap-2 text-sm sm:text-base font-semibold text-sky-100">
              <span>اردو میں معنی:</span>
              <span className="font-urdu text-lg font-bold text-yellow-300">{selectedLetter.wordUrdu}</span>
            </div>

            <div className="bg-white/15 backdrop-blur-sm p-4 rounded-2xl border border-white/20 text-white">
              <p className="text-base sm:text-lg font-bold">
                "{selectedLetter.sentence}"
              </p>
              <div className="mt-2 inline-flex items-center gap-2 bg-blue-900/40 px-3 py-1 rounded-lg text-xs font-bold text-yellow-300">
                <span>فونِکس کی آواز:</span>
                <span>{selectedLetter.phonic}</span>
              </div>
            </div>

            {/* Navigation & Toggle */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrev}
                  className="px-3.5 py-1.5 bg-white/20 hover:bg-white/30 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <ArrowRight className="w-4 h-4" />
                  <span>Previous</span>
                </button>
                <span className="text-xs text-white/80 font-bold">
                  {ENGLISH_ALPHABET.findIndex((l) => l.id === selectedLetter.id) + 1} / 26
                </span>
                <button
                  onClick={handleNext}
                  className="px-3.5 py-1.5 bg-white/20 hover:bg-white/30 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Next</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>

              {/* Case Toggle Button */}
              <button
                onClick={() => setIsCaseUpper(!isCaseUpper)}
                className="px-3 py-1 bg-yellow-400 text-yellow-950 font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow"
              >
                {isCaseUpper ? <ToggleRight className="w-4 h-4 text-yellow-900" /> : <ToggleLeft className="w-4 h-4 text-yellow-900" />}
                <span>{isCaseUpper ? 'BIG LETTERS (A)' : 'small letters (a)'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of A-Z Letters */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl shadow-lg border-2 border-sky-100 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h4 className="text-xl font-extrabold text-slate-800 flex items-center gap-2">
            <span>ABC Alphabet Tray (A to Z)</span>
          </h4>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-sky-50 px-3 py-1.5 rounded-full">
            <span>Letters Mastered:</span>
            <span className="text-sky-600 font-extrabold">{learnedLetters.size} / 26</span>
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
          </div>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-9 gap-2.5 sm:gap-3">
          {ENGLISH_ALPHABET.map((item) => {
            const isSelected = selectedLetter.id === item.id;
            const isLearned = learnedLetters.has(item.id);

            return (
              <button
                key={item.id}
                onClick={() => handleSelectLetter(item)}
                className={`group relative p-2.5 sm:p-3 rounded-2xl flex flex-col items-center justify-center transition-all duration-200 cursor-pointer text-center ${
                  isSelected
                    ? 'bg-sky-500 text-white shadow-lg ring-4 ring-sky-200 scale-105'
                    : 'bg-sky-50/70 hover:bg-sky-100 text-slate-800 border-2 border-sky-100 hover:scale-105'
                }`}
              >
                {isLearned && (
                  <span className="absolute -top-1.5 -right-1.5 bg-amber-400 text-yellow-950 p-0.5 rounded-full text-[10px] shadow">
                    ⭐
                  </span>
                )}

                <span className="font-fun text-2xl sm:text-3xl font-black leading-tight">
                  {isCaseUpper ? item.upper : item.lower}
                </span>
                <span className={`text-[10px] sm:text-xs font-semibold mt-0.5 truncate max-w-full ${isSelected ? 'text-sky-100' : 'text-slate-600'}`}>
                  {item.word}
                </span>
                <span className="text-xs sm:text-sm mt-0.5">
                  {item.emoji}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
