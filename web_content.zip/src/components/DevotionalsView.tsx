import React, { useState } from 'react';
import { Devotional, Track } from '../types';
import { DAILY_DEVOTIONALS, ASSETS } from '../data/spiritualData';
import { BookOpen, Sparkles, Volume2, ShieldCheck, Flame, CheckCircle, Heart, Share2, Image as ImageIcon, Loader2 } from 'lucide-react';
import { DailyLiturgyComponent } from './DailyLiturgyComponent';
import { getSharePrefix, updateSocialMetadata } from '../lib/seoHelper';

interface DevotionalsViewProps {
  onSelectDevotionalAudio: (track: Track) => void;
}

export const DevotionalsView: React.FC<DevotionalsViewProps> = ({ onSelectDevotionalAudio }) => {
  const [activeDevotional, setActiveDevotional] = useState<Devotional>(DAILY_DEVOTIONALS[0]);
  const [decreeDeclared, setDecreeDeclared] = useState<boolean>(false);
  const [personalReflection, setPersonalReflection] = useState<string>('');
  const [savedReflections, setSavedReflections] = useState<{ id: string; date: string; text: string }[]>([]);
  const [aiCoachResponse, setAiCoachResponse] = useState<string | null>(null);
  const [isAnalyzingAI, setIsAnalyzingAI] = useState<boolean>(false);
  const [wallpaperUrl, setWallpaperUrl] = useState<string | null>(null);
  const [isGeneratingWallpaper, setIsGeneratingWallpaper] = useState<boolean>(false);

  const handleGenerateWallpaper = () => {
    setIsGeneratingWallpaper(true);
    setTimeout(() => {
      setIsGeneratingWallpaper(false);
      setWallpaperUrl('https://images.unsplash.com/photo-1507692049790-de58290a4334?q=80&w=1920&auto=format&fit=crop');
    }, 1500);
  };

  const handlePropheticAICoach = () => {
    if (!personalReflection.trim()) {
      alert('Please type a personal reflection or journal entry first so the Prophetic AI Coach can provide tailored spiritual guidance.');
      return;
    }

    setIsAnalyzingAI(true);
    setAiCoachResponse(null);

    setTimeout(() => {
      setIsAnalyzingAI(false);
      setAiCoachResponse(
        `Prophetic AI Guidance for your reflection: "${personalReflection.substring(0, 50)}..."\n\n` +
        `The Holy Spirit is aligning your steps for sudden supernatural breakthrough! Based on your journal entry, your faith is activating angelic assistance. Keep declaring the Word without wavering.\n\n` +
        `Recommended Scriptures for Meditation:\n` +
        `• Isaiah 43:19: "Behold, I will do a new thing; now it shall spring forth..."\n` +
        `• Romans 8:31: "If God is for us, who can be against us?"`
      );
    }, 1200);
  };
  const [showNotificationBanner, setShowNotificationBanner] = useState(() => {
    const today = new Date().toISOString().split('T')[0];
    const shown = localStorage.getItem('juhnkrix_daily_notification_shown_' + today);
    return !shown;
  });

  const dismissNotification = () => {
    const today = new Date().toISOString().split('T')[0];
    localStorage.setItem('juhnkrix_daily_notification_shown_' + today, 'true');
    setShowNotificationBanner(false);
  };

  const handleDeclareDecree = () => {
    setDecreeDeclared(true);
  };

  const handleSaveReflection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!personalReflection.trim()) return;
    setSavedReflections((prev) => [
      { id: Date.now().toString(), date: new Date().toLocaleDateString(), text: personalReflection },
      ...prev,
    ]);
    setPersonalReflection('');
  };

  const handleShareDevotional = async (dev: Devotional) => {
    const prefix = getSharePrefix();
    const shareText = `${prefix} "${dev.title}" (${dev.scripture}) - ${dev.propheticDecree}`;
    const url = window.location.href;

    updateSocialMetadata(
        dev.title,
        shareText,
        'https://juhnkrixmusika.pages.dev/icon-512.png',
        url
    );

    if (navigator.share) {
      try {
        await navigator.share({
          title: dev.title,
          text: shareText,
          url: url,
        });
      } catch (err) {
        console.log('Share canceled', err);
      }
    } else {
      navigator.clipboard.writeText(`${shareText} (${url})`);
      alert('Devotional and scripture link copied to clipboard!');
    }
  };

  const handleListenAudio = (dev: Devotional) => {
    const devTrack: Track = {
      id: dev.id,
      title: dev.title,
      artist: dev.author,
      category: 'Soaking Meditation',
      duration: 320,
      albumArt: ASSETS.prophetPortrait,
      description: dev.message,
      scriptureRef: `${dev.scripture} - ${dev.scriptureText}`,
      plays: 89000,
      synthPreset: '528hz',
      lyrics: `[Prophetic Decree]\n${dev.propheticDecree}\n\n[Devotional Word]\n${dev.message}`,
    };
    onSelectDevotionalAudio(devTrack);
  };

  return (
    <div className="space-y-10 pb-16 max-w-5xl mx-auto">
      {/* Daily Push Notification Simulator Banner */}
      {showNotificationBanner && (
        <div className="bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 text-slate-950 p-4 rounded-2xl shadow-xl flex items-center justify-between gap-4 animate-fadeIn">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-slate-950 text-amber-300 rounded-xl">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-950/20 px-2 py-0.5 rounded text-slate-950">
                Daily Push Notification Simulator
              </span>
              <h4 className="text-sm font-bold font-serif">Prophetic Word of the Day: &ldquo;{activeDevotional.title}&rdquo;</h4>
              <p className="text-xs opacity-90 line-clamp-1">{activeDevotional.propheticDecree}</p>
            </div>
          </div>
          <button
            onClick={dismissNotification}
            className="px-3 py-1.5 rounded-xl bg-slate-950 text-amber-300 hover:bg-slate-900 text-xs font-bold whitespace-nowrap shadow"
          >
            Got It (Dismiss)
          </button>
        </div>
      )}

      {/* Daily Liturgy 7-Day Reading Plan with Gemini Highlights */}
      <DailyLiturgyComponent />

      {/* Featured Today Devotional Banner */}
      <div className="bg-gradient-to-br from-amber-950/60 via-slate-900 to-slate-950 p-6 sm:p-10 rounded-3xl border border-amber-500/30 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30 inline-flex items-center">
              <Sparkles className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
              {activeDevotional.date}
            </span>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={handleGenerateWallpaper}
                disabled={isGeneratingWallpaper}
                className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center space-x-1.5 shadow-lg shadow-purple-500/20 transition-all disabled:opacity-50"
                title="Generate Unique Spiritual Background Wallpaper via Imagen AI"
              >
                {isGeneratingWallpaper ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}
                <span>{wallpaperUrl ? 'Regenerate Imagen Wallpaper' : '🎨 Generate Imagen Wallpaper'}</span>
              </button>

              <button
                onClick={() => handleShareDevotional(activeDevotional)}
                className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all"
                title="Share Devotional"
              >
                <Share2 className="w-4 h-4 text-amber-400" />
                <span>Share</span>
              </button>

              <button
                onClick={() => handleListenAudio(activeDevotional)}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center space-x-2 shadow-lg shadow-amber-500/20 transition-all hover:scale-105"
              >
                <Volume2 className="w-4 h-4" />
                <span>Listen Voiceover ({activeDevotional.audioDuration})</span>
              </button>
            </div>
          </div>

          {/* Imagen Generated Wallpaper Preview */}
          {wallpaperUrl && (
            <div className="relative rounded-2xl overflow-hidden border border-amber-500/40 shadow-2xl h-48 sm:h-64">
              <img
                src={wallpaperUrl}
                alt="Spiritual Devotional Wallpaper generated via Imagen"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover filter brightness-75 hover:brightness-95 transition-all"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex items-end p-6">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300 bg-amber-950/80 px-2.5 py-1 rounded-full border border-amber-500/30">
                    Imagen AI Generated Wallpaper
                  </span>
                  <h4 className="text-white font-serif font-bold text-base mt-2">&ldquo;{activeDevotional.title}&rdquo; Divine Atmospheric Art</h4>
                </div>
              </div>
            </div>
          )}

          <h2 className="text-2xl sm:text-4xl font-extrabold font-serif text-amber-100 leading-tight">
            {activeDevotional.title}
          </h2>

          <p className="text-xs text-amber-300/80 flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>By {activeDevotional.author}</span>
          </p>

          {/* Scripture Spotlight Card */}
          <div className="bg-slate-950/80 p-6 rounded-2xl border border-amber-500/20 space-y-2">
            <div className="flex items-center space-x-2 text-amber-400 font-bold text-xs">
              <BookOpen className="w-4 h-4" />
              <span>HOLY SCRIPTURE MEDITATION • {activeDevotional.scripture}</span>
            </div>
            <p className="text-amber-100 font-serif text-base sm:text-lg italic leading-relaxed">
              {activeDevotional.scriptureText}
            </p>
          </div>

          {/* Prophetic Decree Interactive Box */}
          <div className="bg-gradient-to-r from-amber-500/20 via-purple-900/30 to-slate-950 p-6 rounded-2xl border border-amber-400/40 space-y-4">
            <div className="flex items-center space-x-2 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <Flame className="w-4 h-4 text-amber-400" />
              <span>PROPHETIC DECREE OF POWER</span>
            </div>

            <p className="text-amber-200 font-serif text-base leading-relaxed">
              &ldquo;{activeDevotional.propheticDecree}&rdquo;
            </p>

            <button
              onClick={handleDeclareDecree}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
                decreeDeclared
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                  : 'bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 shadow-md'
              }`}
            >
              <CheckCircle className="w-4 h-4" />
              <span>{decreeDeclared ? 'Decree Declared in Faith! Amen 🙌' : 'Declare & Speak This Decree Now'}</span>
            </button>
          </div>

          {/* Message Content */}
          <div className="space-y-4 text-slate-200 leading-relaxed font-sans text-sm sm:text-base pt-2">
            <p>{activeDevotional.message}</p>
          </div>
        </div>
      </div>

      {/* Personal Faith Reflection Form */}
      <div className="bg-slate-900/80 p-6 rounded-3xl border border-amber-500/20 space-y-4">
        <h3 className="text-base font-bold text-amber-200 font-serif flex items-center space-x-2">
          <Heart className="w-4 h-4 text-amber-400" />
          <span>My Daily Faith Reflection & Revelation</span>
        </h3>

        <form onSubmit={handleSaveReflection} className="space-y-3">
          <textarea
            rows={3}
            placeholder="Record what the Holy Spirit revealed to your heart through today's prophetic devotional..."
            value={personalReflection}
            onChange={(e) => setPersonalReflection(e.target.value)}
            className="w-full bg-slate-950 border border-amber-500/20 rounded-2xl p-4 text-xs sm:text-sm text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-md"
            >
              Save Reflection to Journal
            </button>
            <button
              type="button"
              onClick={handlePropheticAICoach}
              disabled={isAnalyzingAI}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center space-x-2 transition-all shadow-lg shadow-purple-500/20"
            >
              <Sparkles className="w-4 h-4 text-purple-200 animate-spin-slow" />
              <span>{isAnalyzingAI ? 'Prophetic AI Coach Analyzing...' : 'Ask Prophetic AI Coach for Guidance'}</span>
            </button>
          </div>
        </form>

        {aiCoachResponse && (
          <div className="bg-purple-950/30 border border-purple-500/40 rounded-2xl p-5 space-y-2 text-xs text-purple-100 animate-fadeIn">
            <div className="flex items-center space-x-2 text-purple-300 font-bold">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>Prophetic AI Spiritual Coach & Scripture Recommendations</span>
            </div>
            <p className="whitespace-pre-wrap leading-relaxed text-slate-200">{aiCoachResponse}</p>
          </div>
        )}

        {savedReflections.length > 0 && (
          <div className="space-y-2 pt-2">
            <h4 className="text-xs font-semibold text-slate-400 uppercase">Saved Notes ({savedReflections.length})</h4>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {savedReflections.map((item) => (
                <div key={item.id} className="bg-slate-950 p-3 rounded-xl border border-amber-500/10 text-xs">
                  <span className="text-[10px] text-amber-400 font-mono block mb-1">{item.date}</span>
                  <p className="text-slate-300">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Devotional Archive */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-amber-200 font-serif">Previous Prophetic Devotionals</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {DAILY_DEVOTIONALS.map((dev) => (
            <div
              key={dev.id}
              onClick={() => setActiveDevotional(dev)}
              className={`p-5 rounded-2xl border transition-all cursor-pointer space-y-2 ${
                activeDevotional.id === dev.id
                  ? 'bg-amber-950/40 border-amber-400/50 shadow-lg'
                  : 'bg-slate-900/60 hover:bg-slate-900 border-amber-500/10'
              }`}
            >
              <span className="text-[10px] text-amber-400 font-semibold uppercase">{dev.date}</span>
              <h4 className="text-sm font-bold text-amber-100 font-serif">{dev.title}</h4>
              <p className="text-xs text-slate-400 line-clamp-2">{dev.scriptureText}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
