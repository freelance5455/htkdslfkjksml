import React, { useState } from 'react';
import { Volume2, Bell, X, BookOpen, Clock } from 'lucide-react';
import { ActiveAlarmState } from '../types/prayer';

interface AlarmRingingOverlayProps {
  activeAlarm: ActiveAlarmState | null;
  onDismiss: () => void;
  onSnooze: (minutes: number) => void;
}

export const AlarmRingingOverlay: React.FC<AlarmRingingOverlayProps> = ({
  activeAlarm,
  onDismiss,
  onSnooze,
}) => {
  const [showDua, setShowDua] = useState(false);

  if (!activeAlarm) return null;

  const isAdhan = activeAlarm.type === 'adhan';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-300">
      <div className="relative w-full max-w-lg rounded-3xl border border-emerald-500/40 bg-gradient-to-b from-slate-900 to-slate-950 p-6 sm:p-8 text-center shadow-2xl text-slate-100">
        {/* Pulsing visual halo */}
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-500/20 border-2 border-emerald-400 animate-pulse">
          {isAdhan ? (
            <Volume2 className="w-10 h-10 text-emerald-300 animate-bounce" />
          ) : (
            <Bell className="w-10 h-10 text-amber-300 animate-bounce" />
          )}
        </div>

        {/* Title */}
        <div className="mt-5">
          <div className="text-xs uppercase tracking-widest font-bold text-emerald-400">
            {isAdhan ? '🕌 Adhan In Progress' : '⏰ Separate Salah Reminder Alarm'}
          </div>
          <h2 className="mt-1 text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {activeAlarm.prayerLabel}
          </h2>
          <p className="mt-1 text-xs text-slate-300">
            {isAdhan
              ? 'The Adhan is now playing at the scheduled prayer time. Listen reverently.'
              : `${activeAlarm.delayMinutes || 10} minutes have elapsed since Adhan. Stand for Salah.`}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={onDismiss}
            className="w-full sm:w-auto flex-1 rounded-xl bg-emerald-600 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-900/50 hover:bg-emerald-500 transition cursor-pointer"
          >
            Dismiss & Silence Sound
          </button>

          {!isAdhan && (
            <button
              onClick={() => onSnooze(5)}
              className="w-full sm:w-auto rounded-xl border border-amber-600/60 bg-amber-950/40 px-4 py-3 text-xs font-semibold text-amber-300 hover:bg-amber-900/60 transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Clock className="w-4 h-4" />
              Snooze 5 Min
            </button>
          )}

          {isAdhan && (
            <button
              onClick={() => setShowDua(!showDua)}
              className="w-full sm:w-auto rounded-xl border border-slate-700 bg-slate-800 px-4 py-3 text-xs font-semibold text-slate-200 hover:bg-slate-700 transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <BookOpen className="w-4 h-4 text-emerald-400" />
              {showDua ? 'Hide Du’a' : 'Adhan Du’a'}
            </button>
          )}
        </div>

        {/* Islamic Du'a After Adhan Card */}
        {showDua && (
          <div className="mt-5 rounded-2xl border border-emerald-900/80 bg-emerald-950/40 p-4 text-left">
            <div className="text-xs font-bold text-emerald-300 mb-1">Du’a After the Adhan (Sahih Bukhari):</div>
            <div className="font-arabic text-base text-right leading-loose text-amber-200/90 dir-rtl">
              اللَّهُمَّ رَبَّ هَذِهِ الدَّعْوَةِ التَّامَّةِ، وَالصَّلَاةِ الْقَائِمَةِ، آتِ مُحَمَّدًا الْوَسِيلَةَ وَالْفَضِيلَةَ، وَابْعَثْهُ مَقَامًا مَحْمُودًا الَّذِي وَعَدْتَهُ
            </div>
            <div className="mt-2 text-[11px] text-slate-300 italic border-t border-emerald-900/60 pt-2">
              "O Allah, Lord of this perfect call and established prayer, grant Muhammad the intercession and distinction, and raise him to the praised position that You promised him."
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
