import React, {useRef, useState} from 'react';
import {Download, Smartphone, Upload, X} from 'lucide-react';
import type {PortableSaveData} from '../game/types';
import {usePWAInstall} from '../hooks/usePWAInstall';

interface ExtractModalProps {
  open: boolean;
  onExportSave: () => PortableSaveData;
  onImportSave: (data: PortableSaveData) => void;
  onClose: () => void;
}

export const ExtractModal: React.FC<ExtractModalProps> = ({
  open,
  onExportSave,
  onImportSave,
  onClose,
}) => {
  const {isInstallable, isInstalled, isIOS, install} = usePWAInstall();
  const [statusMsg, setStatusMsg] = useState<string>('');
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);

  if (!open) return null;

  const handleDownloadSave = () => {
    const data = onExportSave();
    const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'los-solis-v-save.json';
    a.click();
    URL.revokeObjectURL(url);
    setStatusMsg('Portable save exported as los-solis-v-save.json');
  };

  const handleUploadSave = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as PortableSaveData;
      onImportSave(parsed);
      setStatusMsg('Campaign save restored across devices.');
    } catch {
      setStatusMsg('Could not read save file. Please select a valid los-solis-v-save.json file.');
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 p-4">
      <div className="w-full max-w-lg rounded-xl border border-white/15 bg-[#0f151e] p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div>
            <h2 className="font-display text-xl font-bold text-white">
              Extract & Install Los Solis V
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Extract the full runnable game archive, install offline on mobile/PC, or transfer saves
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 bg-slate-900 text-slate-300 hover:text-white"
            aria-label="Close Extract Menu"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-5 space-y-3">
          {/* 1. Extract Complete Runnable Game Bundle (.zip) */}
          <a
            href="/api/extract-bundle.zip"
            download="los-solis-v-extractable.zip"
            onClick={() => setStatusMsg('Downloading complete extractable source & build bundle...')}
            className="flex min-h-[52px] w-full items-center justify-between rounded-xl border border-emerald-400/40 bg-emerald-500/15 px-4 py-3 text-left hover:bg-emerald-500/25"
          >
            <div>
              <div className="text-sm font-bold text-white">
                Download Extractable Game Bundle (.zip)
              </div>
              <div className="text-xs text-slate-300">
                Full source, Vite config, 3D engine & PWA assets ready to run locally
              </div>
            </div>
            <Download className="h-5 w-5 shrink-0 text-emerald-400" />
          </a>

          {/* 2. Install as Standalone App (Mobile / PC PWA) */}
          {!isInstalled && (
            <button
              type="button"
              onClick={() => {
                if (isInstallable) {
                  void install();
                } else if (isIOS) {
                  setShowIOSGuide((v) => !v);
                } else {
                  setStatusMsg('Use your browser address bar Install icon to add Los Solis V offline.');
                }
              }}
              className="flex min-h-[52px] w-full items-center justify-between rounded-xl border border-white/10 bg-slate-900/80 px-4 py-3 text-left hover:border-white/30"
            >
              <div>
                <div className="text-sm font-bold text-white">
                  {isIOS ? 'Install on iPhone / iPad' : 'Install App for Offline Play (PC & Mobile)'}
                </div>
                <div className="text-xs text-slate-400">
                  Caches game assets via Service Worker for standalone play
                </div>
              </div>
              <Smartphone className="h-5 w-5 shrink-0 text-sky-400" />
            </button>
          )}

          {showIOSGuide && (
            <div className="rounded-lg border border-sky-400/30 bg-sky-950/40 p-3 text-xs text-sky-100">
              1. Tap the <strong>Share</strong> button in Safari.<br />
              2. Scroll down and select <strong>Add to Home Screen</strong>.
            </div>
          )}

          {/* 3. Portable Save Export & Import */}
          <div className="grid grid-cols-1 gap-3 pt-2 sm:grid-cols-2">
            <button
              type="button"
              onClick={handleDownloadSave}
              className="flex min-h-[44px] items-center justify-center gap-2 rounded-lg border border-white/15 bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
            >
              <Download className="h-4 w-4 text-amber-400" />
              Export Save (.json)
            </button>
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="flex min-h-[44px] items-center justify-center gap-2 rounded-lg border border-white/15 bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
            >
              <Upload className="h-4 w-4 text-sky-400" />
              Import Save (.json)
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={handleUploadSave}
            />
          </div>

          {statusMsg && (
            <div className="rounded-lg border border-white/10 bg-slate-950 px-3 py-2 text-xs text-emerald-300">
              {statusMsg}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
