import { useMemo, useRef, useState, type ReactNode } from "react";

export function VirtualList<T>({
  items,
  rowHeight,
  render,
  className,
  overscan = 8,
}: {
  items: T[];
  rowHeight: number;
  render: (item: T, index: number) => ReactNode;
  className?: string;
  overscan?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [scroll, setScroll] = useState(0);
  const [h, setH] = useState(560);
  const start = Math.max(0, Math.floor(scroll / rowHeight) - overscan);
  const visible = Math.ceil(h / rowHeight) + overscan * 2;
  const end = Math.min(items.length, start + visible);
  const slice = useMemo(() => items.slice(start, end), [items, start, end]);

  return (
    <div
      ref={ref}
      className={className}
      onScroll={(e) => {
        const el = e.currentTarget;
        setScroll(el.scrollTop);
        setH(el.clientHeight);
      }}
    >
      <div style={{ height: items.length * rowHeight, position: "relative" }}>
        <div style={{ position: "absolute", top: start * rowHeight, left: 0, right: 0 }}>
          {slice.map((item, i) => render(item, start + i))}
        </div>
      </div>
    </div>
  );
}
