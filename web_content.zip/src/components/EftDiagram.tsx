import React, { useState } from 'react';
import { Sparkles, ChevronRight, CheckCircle2 } from 'lucide-react';

interface EftPoint {
  id: string;
  name: string;
  location: string;
  adultPhrase: string;
  childPhrase: string;
  xPercent: number; // For visual marker
  yPercent: number;
}

const EFT_POINTS: EftPoint[] = [
  {
    id: 'karate',
    name: 'Point Karaté',
    location: 'Tranchant externe de la main, entre la base du petit doigt et le poignet',
    adultPhrase: 'Même si je ressens cette tempête, je m’aime et je m’accepte profondément.',
    childPhrase: 'Même si je suis tout fâché, je suis un super enfant aimé !',
    xPercent: 82,
    yPercent: 70,
  },
  {
    id: 'top_head',
    name: 'Sommet du crâne',
    location: 'Au centre du dessus de la tête (le chapeau magique)',
    adultPhrase: 'Cette tension dans tout mon corps, j’autorise mon esprit à se poser.',
    childPhrase: 'Le chapeau magique qui chasse les gros nuages gris.',
    xPercent: 50,
    yPercent: 12,
  },
  {
    id: 'eyebrow',
    name: 'Début du sourcil',
    location: 'Au coin intérieur du sourcil, juste au-dessus du nez',
    adultPhrase: 'Toute cette anxiété accumulée, je l’accueille avec douceur.',
    childPhrase: 'Les petites lunettes magiques pour voir la lumière.',
    xPercent: 44,
    yPercent: 24,
  },
  {
    id: 'side_eye',
    name: 'Coin de l’œil',
    location: 'Sur l’os au coin externe de l’œil',
    adultPhrase: 'Toutes ces pensées d’urgence, je choisis de ralentir.',
    childPhrase: 'La petite étoile brillante qui me fait sourire.',
    xPercent: 62,
    yPercent: 26,
  },
  {
    id: 'under_eye',
    name: 'Sous l’œil',
    location: 'Sur l’os à environ 2 cm sous la pupille',
    adultPhrase: 'Mon cœur qui s’agite, je lui envoie un souffle apaisant.',
    childPhrase: 'Le petit coussin tout doux sous mes yeux.',
    xPercent: 50,
    yPercent: 33,
  },
  {
    id: 'under_nose',
    name: 'Sous le nez',
    location: 'Entre la base du nez et le milieu de la lèvre supérieure',
    adultPhrase: 'Je libère la peur de perdre le contrôle.',
    childPhrase: 'La moustache du petit chat malicieux !',
    xPercent: 50,
    yPercent: 40,
  },
  {
    id: 'chin',
    name: 'Creux du menton',
    location: 'Entre la lèvre inférieure et la pointe du menton',
    adultPhrase: 'Je suis en sécurité dans mon corps, ici et maintenant.',
    childPhrase: 'La barbichette de courage et de paix.',
    xPercent: 50,
    yPercent: 47,
  },
  {
    id: 'collarbone',
    name: 'Sous la clavicule',
    location: 'Juste sous la jonction de la clavicule et du sternum',
    adultPhrase: 'Je dépose le fardeau, j’ouvre mon cœur à la sérénité.',
    childPhrase: 'Le grand trésor de mon cœur plein d’amour.',
    xPercent: 38,
    yPercent: 55,
  },
  {
    id: 'under_arm',
    name: 'Sous le bras',
    location: 'Environ 10 cm sous l’aisselle (au niveau de la ligne de soutien-gorge)',
    adultPhrase: 'Paix dans mon corps, paix dans mon âme. Tout va bien.',
    childPhrase: 'Le câlin du petit ouistiti sous le bras !',
    xPercent: 22,
    yPercent: 63,
  },
];

interface EftDiagramProps {
  mode?: 'adult' | 'child';
}

export const EftDiagram: React.FC<EftDiagramProps> = ({ mode = 'adult' }) => {
  const [selectedPointIndex, setSelectedPointIndex] = useState<number>(0);

  const currentPoint = EFT_POINTS[selectedPointIndex];

  const handleNext = () => {
    setSelectedPointIndex((prev) => (prev + 1) % EFT_POINTS.length);
  };

  const handlePrev = () => {
    setSelectedPointIndex((prev) => (prev - 1 + EFT_POINTS.length) % EFT_POINTS.length);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-rose-100 dark:border-slate-800 shadow-sm max-w-xl mx-auto my-4">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div>
          <h4 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 text-base">
            <Sparkles className="w-4 h-4 text-rose-500" />
            {mode === 'child' ? 'Points Magiques de Tapping Enfant' : 'Guide Visuel des Points EFT'}
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Tapotez doucement 5 à 7 fois avec 2 doigts sur le point actif
          </p>
        </div>
        <div className="text-xs px-2.5 py-1 rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-semibold">
          Point {selectedPointIndex + 1} / {EFT_POINTS.length}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        {/* Silhouette Diagram with Points */}
        <div className="relative w-full h-64 bg-slate-50 dark:bg-slate-800/50 rounded-2xl flex items-center justify-center overflow-hidden border border-slate-100 dark:border-slate-700">
          {/* Simple Body Outline SVG */}
          <svg
            viewBox="0 0 200 300"
            className="w-full h-full text-slate-300 dark:text-slate-700 fill-current opacity-70"
          >
            {/* Head */}
            <circle cx="100" cy="50" r="32" />
            {/* Neck */}
            <rect x="92" y="80" width="16" height="20" rx="4" />
            {/* Shoulders & Torso */}
            <path d="M 50 100 C 60 90, 80 90, 100 90 C 120 90, 140 90, 150 100 C 160 110, 165 140, 165 180 C 165 210, 155 240, 145 270 L 55 270 C 45 240, 35 210, 35 180 C 35 140, 40 110, 50 100 Z" />
            {/* Arms */}
            <path d="M 40 105 L 18 190 A 8 8 0 0 0 32 195 L 48 125 Z" />
            <path d="M 160 105 L 182 190 A 8 8 0 0 1 168 195 L 152 125 Z" />
          </svg>

          {/* Interactive clickable markers */}
          {EFT_POINTS.map((pt, idx) => {
            const isSelected = idx === selectedPointIndex;
            return (
              <button
                key={pt.id}
                onClick={() => setSelectedPointIndex(idx)}
                className={`absolute w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all shadow-md transform -translate-x-1/2 -translate-y-1/2 ${
                  isSelected
                    ? 'bg-rose-500 text-white ring-4 ring-rose-200 dark:ring-rose-800 scale-125 z-20 animate-bounce'
                    : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-rose-100 hover:scale-110 z-10'
                }`}
                style={{
                  left: `${pt.xPercent}%`,
                  top: `${pt.yPercent}%`,
                }}
                title={pt.name}
              >
                {idx + 1}
              </button>
            );
          })}
        </div>

        {/* Details & Affirmation Card */}
        <div className="flex flex-col justify-between h-full space-y-4">
          <div className="p-4 rounded-2xl bg-rose-50/70 dark:bg-slate-800/80 border border-rose-100 dark:border-slate-700">
            <div className="text-xs font-semibold text-rose-600 dark:text-rose-400 uppercase tracking-wider mb-1">
              Étape active
            </div>
            <h5 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-1">
              {currentPoint.name}
            </h5>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-3">
              {currentPoint.location}
            </p>

            <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-rose-200/60 dark:border-slate-700 shadow-2xs">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400 block mb-1">
                {mode === 'child' ? 'Phrase magique à dire :' : 'Affirmation à répéter :'}
              </span>
              <p className="text-sm font-semibold text-rose-800 dark:text-rose-200 italic">
                "{mode === 'child' ? currentPoint.childPhrase : currentPoint.adultPhrase}"
              </p>
            </div>
          </div>

          {/* Stepper buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrev}
              className="flex-1 py-2 px-3 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              Point précédent
            </button>
            <button
              onClick={handleNext}
              className="flex-1 py-2 px-3 text-xs font-semibold rounded-xl bg-rose-500 text-white hover:bg-rose-600 shadow-xs flex items-center justify-center gap-1"
            >
              <span>Point suivant</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Points list chips */}
      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-1.5">
        {EFT_POINTS.map((pt, idx) => (
          <button
            key={pt.id}
            onClick={() => setSelectedPointIndex(idx)}
            className={`text-xs px-2.5 py-1 rounded-lg transition-all ${
              idx === selectedPointIndex
                ? 'bg-rose-600 text-white font-bold'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            {idx + 1}. {pt.name}
          </button>
        ))}
      </div>
    </div>
  );
};
