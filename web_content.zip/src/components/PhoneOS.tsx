import { useEffect, useMemo, useState } from "react";
import { store, useStore } from "../lib/store";
import {
  ACCENTS,
  ICON_SHAPES,
  WALLPAPERS,
  accentById,
  wallpaperById,
  type IconShape,
} from "../lib/phoneOS";
import { toFa } from "../lib/fa";
import { boop } from "../lib/sound";
import { fmtData } from "./PhoneApps";

/* ================================================================== */
/*  status bar                                                         */
/* ================================================================== */
export function StatusBar({ dark }: { dark: boolean }) {
  const seconds = useStore((s) => s.os.seconds);
  const saver = useStore((s) => s.os.saver);
  const data = useStore((s) => s.data);
  const vpn = useStore((s) => s.vpnOn);
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), seconds ? 1000 : 20000);
    return () => window.clearInterval(id);
  }, [seconds]);

  const txt = dark ? "text-white" : "text-slate-800";
  const clock = seconds
    ? `${toFa(now.getHours(), 2)}:${toFa(now.getMinutes(), 2)}:${toFa(now.getSeconds(), 2)}`
    : `${toFa(now.getHours(), 2)}:${toFa(now.getMinutes(), 2)}`;

  // battery reflects the data bundle, so the bar always means something
  const batt = Math.max(4, Math.min(100, Math.round((data / 20480) * 100)));

  return (
    <div
      className={`relative z-10 flex shrink-0 items-center justify-between px-4 pt-2 pb-1 text-[9.5px] font-black ${txt}`}
    >
      <span className="tabular-nums">{clock}</span>
      <span className="absolute top-1.5 left-1/2 h-4 w-16 -translate-x-1/2 rounded-full bg-slate-900" />
      <span className="flex items-center gap-1">
        {vpn && <span className="text-[8px]">VPN</span>}
        {saver && <span className="text-[9px]">🔋</span>}
        <span className="text-[8px]">▮▮▮</span>
        <span className="relative inline-block h-[9px] w-[17px] rounded-[3px] border border-current">
          <span
            className="absolute top-[1px] left-[1px] bottom-[1px] rounded-[1.5px]"
            style={{
              width: `${Math.max(6, batt * 0.14)}px`,
              background: saver ? "#F59E0B" : batt < 20 ? "#EF4444" : "currentColor",
            }}
          />
        </span>
      </span>
    </div>
  );
}

/* ================================================================== */
/*  lock screen                                                        */
/* ================================================================== */
export function LockScreen() {
  const os = useStore((s) => s.os);
  const points = useStore((s) => s.points);
  const msgs = useStore((s) => s.msgs);
  const wp = wallpaperById(os.wallpaper);
  const accent = accentById(os.accent);
  const [drag, setDrag] = useState(0);
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 20000);
    return () => window.clearInterval(id);
  }, []);

  const unread = msgs.filter((m) => m.from === "jeeko").length;
  const txt = wp.dark ? "text-white" : "text-slate-900";

  const days = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];

  return (
    <div className="relative flex h-full flex-col" style={{ background: wp.css }}>
      <StatusBar dark={wp.dark} />

      <div className={`flex flex-1 flex-col items-center pt-8 ${txt}`}>
        <div className="text-[11px] font-bold opacity-70">
          {days[now.getDay()]}
        </div>
        <div className="text-[52px] leading-none font-black tabular-nums">
          {toFa(now.getHours(), 2)}:{toFa(now.getMinutes(), 2)}
        </div>

        {/* notification cards */}
        <div className="mt-5 flex w-full flex-col gap-1.5 px-3">
          {unread > 0 && (
            <div
              className={`flex items-center gap-2 rounded-2xl px-2.5 py-2 backdrop-blur ${
                wp.dark ? "bg-white/15" : "bg-white/70"
              }`}
            >
              <span className="text-base">💬</span>
              <span className="min-w-0 flex-1 truncate text-[10.5px] font-bold">
                {toFa(unread)} پیام از جیکو
              </span>
            </div>
          )}
          <div
            className={`flex items-center gap-2 rounded-2xl px-2.5 py-2 backdrop-blur ${
              wp.dark ? "bg-white/15" : "bg-white/70"
            }`}
          >
            <span className="text-base">🪙</span>
            <span className="min-w-0 flex-1 truncate text-[10.5px] font-bold">
              موجودی: {toFa(points)} پوینت
            </span>
          </div>
        </div>
      </div>

      {/* slide to unlock */}
      <div className="px-5 pb-5">
        <div className={`mb-2 text-center text-[10px] font-bold ${txt} opacity-70`}>
          {os.ownerName}
        </div>
        <div
          className={`relative h-12 overflow-hidden rounded-full ${
            wp.dark ? "bg-white/15" : "bg-white/60"
          }`}
        >
          <div
            className="absolute inset-y-1 right-1 grid w-10 place-items-center rounded-full text-lg shadow-md transition-transform"
            style={{
              background: accent.color,
              transform: `translateX(${-drag}px)`,
            }}
          >
            🔓
          </div>
          <span
            className={`pointer-events-none absolute inset-0 grid place-items-center text-[11px] font-black ${txt} opacity-60`}
          >
            برای باز کردن بکش
          </span>
          <input
            type="range"
            min={0}
            max={100}
            value={0}
            onChange={(e) => {
              const v = Number(e.target.value);
              setDrag(v * 1.8);
              if (v > 70) {
                store.unlockPhone();
                boop();
              }
            }}
            onPointerUp={() => setDrag(0)}
            className="absolute inset-0 w-full cursor-pointer opacity-0"
            aria-label="باز کردن قفل"
          />
        </div>
        <button
          type="button"
          onClick={() => {
            store.unlockPhone();
            boop();
          }}
          className={`mt-2 w-full text-center text-[10px] font-bold ${txt} opacity-50`}
        >
          یا اینجا بزن
        </button>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  control centre                                                     */
/* ================================================================== */
export function ControlCentre({ onClose }: { onClose: () => void }) {
  const os = useStore((s) => s.os);
  const sound = useStore((s) => s.sound);
  const vpn = useStore((s) => s.vpnOn);
  const hasVpn = useStore((s) => s.installed.includes("vpn"));
  const data = useStore((s) => s.data);
  const accent = accentById(os.accent);

  const Toggle = ({
    on,
    icon,
    label,
    onClick,
    disabled,
  }: {
    on: boolean;
    icon: string;
    label: string;
    onClick: () => void;
    disabled?: boolean;
  }) => (
    <button
      type="button"
      disabled={disabled}
      onClick={() => {
        if (disabled) return;
        onClick();
        boop();
      }}
      className={`flex flex-col items-center gap-1 rounded-2xl px-2 py-3 transition active:scale-95 ${
        disabled ? "bg-white/5 opacity-40" : on ? "text-white" : "bg-white/12 text-white/70"
      }`}
      style={on && !disabled ? { background: accent.color } : undefined}
    >
      <span className="text-lg">{icon}</span>
      <span className="text-[9px] font-black">{label}</span>
    </button>
  );

  return (
    <div className="absolute inset-0 z-20 flex flex-col bg-slate-950/70 backdrop-blur-xl" onClick={onClose}>
      <div className="flex-1" />
      <div
        className="rounded-t-3xl bg-slate-900/80 p-3 pb-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-white/30" />

        <div className="grid grid-cols-4 gap-2">
          <Toggle on={sound} icon={sound ? "🔊" : "🔇"} label="صدا" onClick={() => store.toggleSound()} />
          <Toggle
            on={vpn}
            icon="🛡️"
            label="VPN"
            disabled={!hasVpn}
            onClick={() => store.toggleVpn()}
          />
          <Toggle
            on={os.saver}
            icon="🔋"
            label="ذخیره"
            onClick={() => store.setOS({ saver: !os.saver })}
          />
          <Toggle
            on={os.labels}
            icon="🏷️"
            label="برچسب"
            onClick={() => store.setOS({ labels: !os.labels })}
          />
        </div>

        {/* data meter */}
        <div className="mt-3 rounded-2xl bg-white/10 p-2.5">
          <div className="mb-1 flex justify-between text-[10px] font-black text-white/80">
            <span>📶 اینترنت</span>
            <span className="tabular-nums">{fmtData(data)}</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/15">
            <div
              className="h-full rounded-full transition-[width] duration-300"
              style={{
                width: `${Math.min(100, (data / 20480) * 100)}%`,
                background: accent.color,
              }}
            />
          </div>
        </div>

        {/* quick accent picker */}
        <div className="mt-3 flex items-center gap-2 rounded-2xl bg-white/10 p-2.5">
          <span className="text-[10px] font-black text-white/80">رنگ سیستم</span>
          <div className="flex flex-1 justify-end gap-1.5">
            {ACCENTS.map((a) => (
              <button
                key={a.id}
                type="button"
                aria-label={a.name}
                onClick={() => {
                  store.setOS({ accent: a.id });
                  boop();
                }}
                className={`size-6 rounded-full transition ${
                  os.accent === a.id ? "ring-2 ring-white ring-offset-2 ring-offset-slate-900" : ""
                }`}
                style={{ background: a.color }}
              />
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-3 w-full rounded-2xl bg-white/12 py-2 text-[11px] font-black text-white"
        >
          بستن
        </button>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  settings app                                                       */
/* ================================================================== */
export function SettingsApp({ allApps }: { allApps: { id: string; name: string; emoji: string }[] }) {
  const os = useStore((s) => s.os);
  const owner = useStore((s) => s.owner);
  const sound = useStore((s) => s.sound);
  const accent = accentById(os.accent);
  const [tab, setTab] = useState<"look" | "home" | "system">("look");

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="rounded-2xl bg-white p-2.5 ring-1 ring-slate-900/8">
      <div className="mb-2 text-[10.5px] font-black text-slate-700">{title}</div>
      {children}
    </div>
  );

  const Switch = ({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) => (
    <button
      type="button"
      onClick={() => {
        onClick();
        boop();
      }}
      className="flex w-full items-center justify-between py-1.5"
    >
      <span className="text-[11px] font-bold text-slate-700">{label}</span>
      <span
        className="relative h-5 w-9 rounded-full transition"
        style={{ background: on ? accent.color : "#CBD5E1" }}
      >
        <span
          className={`absolute top-0.5 size-4 rounded-full bg-white shadow transition-all ${
            on ? "right-0.5" : "right-4.5"
          }`}
        />
      </span>
    </button>
  );

  const order = useMemo(() => {
    const ids = allApps.map((a) => a.id);
    const seen = os.order.filter((i) => ids.includes(i));
    for (const i of ids) if (!seen.includes(i)) seen.push(i);
    return seen;
  }, [os.order, allApps]);

  return (
    <div className="flex flex-col gap-2">
      {/* tabs */}
      <div className="flex gap-1.5">
        {(
          [
            { id: "look", label: "ظاهر" },
            { id: "home", label: "صفحه اصلی" },
            { id: "system", label: "سیستم" },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => {
              setTab(t.id);
              boop();
            }}
            className="flex-1 rounded-xl py-1.5 text-[10.5px] font-black transition"
            style={
              tab === t.id
                ? { background: accent.color, color: "#fff" }
                : { background: "rgba(15,23,42,0.06)", color: "#475569" }
            }
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "look" && (
        <>
          <Section title="تصویر زمینه">
            <div className="grid grid-cols-4 gap-1.5">
              {WALLPAPERS.map((w) => (
                <button
                  key={w.id}
                  type="button"
                  onClick={() => {
                    store.setOS({ wallpaper: w.id });
                    boop();
                  }}
                  className={`aspect-[9/16] rounded-lg ring-2 transition ${
                    os.wallpaper === w.id ? "ring-slate-900" : "ring-transparent"
                  }`}
                  style={{ background: w.css }}
                  title={w.name}
                />
              ))}
            </div>
          </Section>

          <Section title="رنگ سیستم">
            <div className="flex flex-wrap gap-2">
              {ACCENTS.map((a) => (
                <button
                  key={a.id}
                  type="button"
                  onClick={() => {
                    store.setOS({ accent: a.id });
                    boop();
                  }}
                  className={`size-8 rounded-full transition ${
                    os.accent === a.id ? "ring-2 ring-slate-900 ring-offset-2" : ""
                  }`}
                  style={{ background: a.color }}
                  title={a.name}
                />
              ))}
            </div>
          </Section>

          <Section title="شکل آیکون">
            <div className="grid grid-cols-3 gap-1.5">
              {ICON_SHAPES.map((sh) => (
                <button
                  key={sh.id}
                  type="button"
                  onClick={() => {
                    store.setOS({ iconShape: sh.id as IconShape });
                    boop();
                  }}
                  className={`flex flex-col items-center gap-1 rounded-xl py-2 transition ${
                    os.iconShape === sh.id ? "bg-slate-900/10 ring-2 ring-slate-900" : "bg-slate-900/5"
                  }`}
                >
                  <span
                    className="size-7"
                    style={{ background: accent.color, borderRadius: sh.radius }}
                  />
                  <span className="text-[9px] font-bold text-slate-600">{sh.name}</span>
                </button>
              ))}
            </div>
          </Section>
        </>
      )}

      {tab === "home" && (
        <>
          <Section title="چیدمان">
            <div className="mb-2 flex gap-1.5">
              {([4, 5] as const).map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => {
                    store.setOS({ gridCols: n });
                    boop();
                  }}
                  className="flex-1 rounded-xl py-1.5 text-[10.5px] font-black transition"
                  style={
                    os.gridCols === n
                      ? { background: accent.color, color: "#fff" }
                      : { background: "rgba(15,23,42,0.06)", color: "#475569" }
                  }
                >
                  {toFa(n)} ستونه
                </button>
              ))}
            </div>
            <Switch
              on={os.labels}
              label="نمایش نام برنامه‌ها"
              onClick={() => store.setOS({ labels: !os.labels })}
            />
          </Section>

          <Section title="ترتیب و نمایش برنامه‌ها">
            <div className="flex flex-col gap-1">
              {order.map((id, i) => {
                const app = allApps.find((a) => a.id === id);
                if (!app) return null;
                const hidden = os.hidden.includes(id);
                const inDock = os.dock.includes(id);
                return (
                  <div
                    key={id}
                    className="flex items-center gap-1.5 rounded-xl bg-slate-900/4 px-1.5 py-1"
                  >
                    <span className="text-sm">{app.emoji}</span>
                    <span
                      className={`min-w-0 flex-1 truncate text-[10px] font-bold ${
                        hidden ? "text-slate-400 line-through" : "text-slate-700"
                      }`}
                    >
                      {app.name}
                    </span>
                    <button
                      type="button"
                      aria-label="بالا"
                      onClick={() => {
                        store.moveApp(id, -1, allApps.map((a) => a.id));
                        boop();
                      }}
                      disabled={i === 0}
                      className="size-5 rounded bg-slate-900/8 text-[10px] font-black text-slate-600 disabled:opacity-30"
                    >
                      ↑
                    </button>
                    <button
                      type="button"
                      aria-label="پایین"
                      onClick={() => {
                        store.moveApp(id, 1, allApps.map((a) => a.id));
                        boop();
                      }}
                      disabled={i === order.length - 1}
                      className="size-5 rounded bg-slate-900/8 text-[10px] font-black text-slate-600 disabled:opacity-30"
                    >
                      ↓
                    </button>
                    <button
                      type="button"
                      aria-label="داک"
                      onClick={() => {
                        store.toggleDock(id);
                        boop();
                      }}
                      className="size-5 rounded text-[10px] font-black"
                      style={{
                        background: inDock ? accent.color : "rgba(15,23,42,0.08)",
                        color: inDock ? "#fff" : "#475569",
                      }}
                    >
                      ⌂
                    </button>
                    <button
                      type="button"
                      aria-label="مخفی"
                      onClick={() => {
                        store.toggleHidden(id);
                        boop();
                      }}
                      className="size-5 rounded bg-slate-900/8 text-[10px] font-black text-slate-600"
                    >
                      {hidden ? "🚫" : "👁"}
                    </button>
                  </div>
                );
              })}
            </div>
            <div className="mt-1.5 text-[9px] font-bold text-slate-400">
              ⌂ یعنی پین به داک پایین (حداکثر ۴ تا)
            </div>
          </Section>
        </>
      )}

      {tab === "system" && (
        <>
          <Section title="عمومی">
            <Switch on={sound} label="صدای سیستم" onClick={() => store.toggleSound()} />
            <Switch
              on={os.seconds}
              label="نمایش ثانیه در ساعت"
              onClick={() => store.setOS({ seconds: !os.seconds })}
            />
            <Switch
              on={os.lockEnabled}
              label="صفحه قفل"
              onClick={() => store.setOS({ lockEnabled: !os.lockEnabled })}
            />
            <Switch
              on={os.saver}
              label="حالت ذخیره باتری"
              onClick={() => store.setOS({ saver: !os.saver })}
            />
          </Section>

          <Section title="نام مالک دستگاه">
            <input
              value={os.ownerName}
              maxLength={16}
              onChange={(e) => store.setOS({ ownerName: e.target.value })}
              className="w-full rounded-xl bg-slate-900/5 px-3 py-2 text-[11px] font-bold text-slate-800 outline-none"
            />
          </Section>

          <Section title="درباره">
            <div className="flex flex-col gap-1 text-[10px] font-bold text-slate-500">
              <div className="flex justify-between">
                <span>سیستم‌عامل</span>
                <span className="text-slate-800">JeekOS ۲.۰</span>
              </div>
              <div className="flex justify-between">
                <span>وضعیت مالک</span>
                <span className="text-slate-800">{owner ? "وارد شده" : "مهمان"}</span>
              </div>
            </div>
          </Section>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                store.closePhone();
                store.setOwnerOpen(true);
              }}
              className="rounded-xl bg-slate-900/8 py-2 text-[10.5px] font-black text-slate-700"
            >
              🔐 پنل مالک
            </button>
            <button
              type="button"
              onClick={() => {
                store.resetOS();
                boop();
              }}
              className="rounded-xl bg-rose-500/15 py-2 text-[10.5px] font-black text-rose-600"
            >
              بازنشانی ظاهر
            </button>
          </div>
        </>
      )}
    </div>
  );
}
