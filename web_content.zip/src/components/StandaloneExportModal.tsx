import React, { useState } from 'react';
import { getStandaloneIndexHtml } from '../services/standaloneHtmlGenerator';
import { 
  X, 
  Copy, 
  Check, 
  Download, 
  Code2, 
  FileCode, 
  CheckCircle2, 
  Sparkles,
  ExternalLink,
  Laptop
} from 'lucide-react';

interface StandaloneExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StandaloneExportModal: React.FC<StandaloneExportModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'preview' | 'instructions'>('preview');

  if (!isOpen) return null;

  const htmlContent = getStandaloneIndexHtml();

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(htmlContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      alert('Unable to copy directly. Please select all and copy from the code box.');
    }
  };

  const handleDownloadFile = () => {
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'index.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl shadow-cyan-950/60 overflow-hidden">
        
        {/* Modal Top Header */}
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <FileCode className="w-5 h-5 text-slate-950 font-bold" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-white text-base sm:text-lg">
                  Standalone Single File: <span className="text-cyan-400">index.html</span>
                </h3>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  100% Working
                </span>
              </div>
              <p className="text-xs text-slate-400">
                SL TIK TOK Video by Saleem Zakhme &bull; All-in-one standalone file (No server or build required)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Urdu & English Banner Info */}
        <div className="bg-slate-950/40 px-6 py-3 border-b border-slate-800 text-xs text-slate-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-emerald-300">
            <Sparkles className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>
              <strong>اردو / Hindi:</strong> یہ مکمل ورکنگ کوڈ ہے جس میں HTML، Tailwind اور TikTok API شامل ہیں۔
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('preview')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                activeTab === 'preview' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Code Preview
            </button>
            <button
              onClick={() => setActiveTab('instructions')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                activeTab === 'instructions' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              How to Run
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'preview' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400 pb-1">
                <span>File size: ~15 KB &bull; Standalone HTML5 + Tailwind CDN + Vanilla JS</span>
                <span className="text-cyan-400">tikwm.com API integrated</span>
              </div>

              {/* Code display block */}
              <div className="relative rounded-2xl bg-slate-950 border border-slate-800 p-4 font-mono text-xs text-slate-300 max-h-[380px] overflow-y-auto selection:bg-cyan-500 selection:text-white">
                <pre className="whitespace-pre">
                  <code>{htmlContent}</code>
                </pre>
              </div>
            </div>
          ) : (
            <div className="space-y-6 text-sm text-slate-300 py-2">
              <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800">
                <h4 className="text-white font-bold text-base mb-2 flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-cyan-400" />
                  اس فائل کو چلانے کا طریقہ (How to Use this index.html):
                </h4>
                <ol className="list-decimal list-inside space-y-2.5 text-slate-300 text-xs sm:text-sm pl-1">
                  <li>
                    نیچے دیئے گئے <strong className="text-emerald-400">"Download index.html File"</strong> بٹن پر کلک کریں یا پورا کوڈ کاپی کریں۔
                  </li>
                  <li>
                    ڈاؤن لوڈ کی ہوئی <code className="bg-slate-800 text-cyan-300 px-1.5 py-0.5 rounded">index.html</code> فائل کو اپنے کمپیوٹر میں کسی بھی فولڈر میں رکھیں۔
                  </li>
                  <li>
                    اس پر ڈبل کلک کریں! یہ گوگل کروم، فائر فاکس، مائیکروسافٹ ایج یا موبائل پر براہِ راست بغیر کسی سرور کے کھل جائے گی۔
                  </li>
                  <li>
                    اگر آپ اسے انٹرنیٹ پر لائیو کرنا چاہتے ہیں تو آپ اسے <strong>GitHub Pages, Netlify, Vercel, ya cPanel</strong> پر فری اپلوڈ کر سکتے ہیں۔
                  </li>
                </ol>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-950/50 border border-slate-800/80">
                  <h5 className="font-bold text-white text-sm mb-1">⚡ 100% Standalone</h5>
                  <p className="text-xs text-slate-400">
                    No npm install, no node.js needed. Everything is bundled inside this one file.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-950/50 border border-slate-800/80">
                  <h5 className="font-bold text-white text-sm mb-1">🚀 Real TikTok API</h5>
                  <p className="text-xs text-slate-400">
                    Fetches real videos and high quality MP4/MP3 downloads directly in the browser.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Actions Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/90 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-400 text-center sm:text-left">
            Saved also at: <code className="text-cyan-400 bg-slate-800 px-1.5 py-0.5 rounded">/standalone-index.html</code>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            {/* Copy Button */}
            <button
              onClick={handleCopyCode}
              className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 border border-slate-700 transition cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400">Code Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-cyan-400" />
                  <span>Copy All Code</span>
                </>
              )}
            </button>

            {/* Download File Button */}
            <button
              onClick={handleDownloadFile}
              className="flex-1 sm:flex-initial px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition-all duration-200 active:scale-95 cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-950" />
              <span>Download index.html</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
