import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Order } from '../types';
import {
  X,
  ShieldCheck,
  CreditCard,
  Smartphone,
  Landmark,
  Wallet,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  BookOpen,
  Printer,
  Sparkles,
  Info
} from 'lucide-react';
import { downloadEbookAsHtml } from '../utils/htmlDownloader';

export const CheckoutModal: React.FC = () => {
  const {
    checkoutOpen,
    setCheckoutOpen,
    cart,
    cartSubtotal,
    cartDiscount,
    cartTotal,
    appliedCoupon,
    userProfile,
    createOrder,
    setActiveTab,
    ebooks
  } = useApp();

  const [customerName, setCustomerName] = useState(userProfile.name || 'Arup Saikia');
  const [customerEmail, setCustomerEmail] = useState(userProfile.email || 'arup.saikia.assam@example.com');
  const [customerPhone, setCustomerPhone] = useState(userProfile.phone || '+91 98640 12345');
  const [state, setState] = useState(userProfile.state || 'Assam');
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Card' | 'NetBanking' | 'Wallet'>('UPI');
  const [upiApp, setUpiApp] = useState<'GPay' | 'PhonePe' | 'Paytm' | 'BHIM'>('PhonePe');
  const [cardDetails, setCardDetails] = useState({ number: '4532 •••• •••• 8821', name: 'ARUP SAIKIA', exp: '08/29' });
  const [selectedBank, setSelectedBank] = useState('State Bank of India (SBI)');

  // Step state: 'form' | 'processing' | 'confirmed'
  const [step, setStep] = useState<'form' | 'processing' | 'confirmed'>('form');
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  if (!checkoutOpen) return null;

  const handleProcessOrder = (isDemoSimulation: boolean) => {
    if (!customerName || !customerEmail || !customerPhone) {
      alert('Please fill out all contact details.');
      return;
    }

    setStep('processing');

    setTimeout(() => {
      const order = createOrder({
        customerName,
        customerEmail,
        customerPhone,
        state,
        paymentMethod: cartTotal === 0 ? 'Free' : paymentMethod,
        isDemoPayment: isDemoSimulation
      });
      setCompletedOrder(order);
      setStep('confirmed');
    }, 1200);
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/80 backdrop-blur-md transition-opacity"
        onClick={() => {
          if (step !== 'processing') setCheckoutOpen(false);
        }}
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] z-10 animate-in fade-in zoom-in-95 duration-150">
        {/* Top Header */}
        <div className="bg-[#0B192C] text-white px-4 py-3.5 flex items-center justify-between border-b border-[#1E3E62]">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm sm:text-base font-extrabold tracking-tight">
              {step === 'confirmed' ? 'Order Successful' : 'Secure Indian Checkout'}
            </h2>
          </div>
          {step !== 'processing' && (
            <button
              onClick={() => setCheckoutOpen(false)}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {step === 'processing' && (
            <div className="py-16 text-center space-y-4">
              <div className="w-16 h-16 border-4 border-amber-400 border-t-transparent rounded-full animate-spin mx-auto" />
              <h3 className="text-lg font-black text-[#0B192C]">
                Processing Payment with Indian Banking Gateway...
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Verifying bank checksum and digital signature. Please do not refresh or close this window.
              </p>
            </div>
          )}

          {step === 'confirmed' && completedOrder && (
            <div className="space-y-6">
              {/* Confirmed Banner */}
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center space-y-2">
                <div className="w-16 h-16 bg-emerald-600 text-white rounded-full flex items-center justify-center mx-auto shadow-md">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-emerald-900">
                  Payment Confirmed!
                </h2>
                <p className="text-xs sm:text-sm text-emerald-700 max-w-md mx-auto">
                  Your order <strong>#{completedOrder.orderNumber}</strong> has been successfully verified. Your ebooks are unlocked and ready in your library.
                </p>
                <div className="inline-block mt-1 bg-white border border-emerald-200 px-3 py-1 rounded-full text-xs font-mono font-bold text-slate-700">
                  Transaction ID: {completedOrder.transactionId}
                </div>
              </div>

              {/* Order Receipt Details */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200 text-xs text-slate-600">
                  <div>
                    <span className="block font-bold text-slate-900">Billed To:</span>
                    <span>{completedOrder.customerName} ({completedOrder.customerPhone})</span>
                    <span className="block text-[11px] text-slate-500">{completedOrder.customerEmail} • {completedOrder.state}</span>
                  </div>
                  <div className="text-right">
                    <span className="block font-bold text-slate-900">Date & Time:</span>
                    <span>{completedOrder.createdAt}</span>
                    <span className="block text-[11px] text-emerald-600 font-bold uppercase">{completedOrder.paymentStatus}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                    Purchased Study Material ({completedOrder.items.length})
                  </span>
                  {completedOrder.items.map((item, idx) => (
                    <div
                      key={idx}
                      className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <div>
                        <p className="font-bold text-slate-900">{item.title}</p>
                        <p className="text-[11px] text-slate-500">{item.language} • Full Digital Access</p>
                      </div>
                      <span className="font-black text-[#0B192C]">
                        {item.price === 0 ? 'FREE' : `₹${item.price}`}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-black text-[#0B192C]">
                  <span>Total Amount Paid</span>
                  <span>₹{completedOrder.total}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => {
                    setCheckoutOpen(false);
                    setActiveTab('my-books');
                  }}
                  className="flex-1 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm py-3 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Go to My Books & Start Reading</span>
                </button>

                <button
                  onClick={handlePrintReceipt}
                  className="flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs sm:text-sm py-3 px-4 rounded-xl transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Receipt</span>
                </button>
              </div>
            </div>
          )}

          {step === 'form' && (
            <div className="space-y-6">
              {/* Notice Banner about Production vs Demo Mode */}
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 flex items-start gap-3">
                <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="text-xs text-amber-900 space-y-1">
                  <p className="font-bold">Production Payment Architecture Ready</p>
                  <p className="text-[11px] leading-relaxed">
                    This checkout is wired for Indian payment options (UPI, RuPay/Cards, Net Banking). In live production with Razorpay/Cashfree credentials, payment signatures are validated via server webhooks before database unlock. In this preview, you can test the realistic payment simulation.
                  </p>
                </div>
              </div>

              {/* Student Billing Information */}
              <div>
                <h3 className="text-xs font-bold text-[#0B192C] uppercase tracking-wider mb-3">
                  Student & Contact Information
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Arup Saikia"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Email Address (For Invoices & Ebook Links) *
                    </label>
                    <input
                      type="email"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="e.g. student@gmail.com"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Mobile Number (+91) *
                    </label>
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="+91 98640 12345"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      State *
                    </label>
                    <select
                      value={state}
                      onChange={(e) => setState(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium outline-none focus:border-amber-500"
                    >
                      <option value="Assam">Assam</option>
                      <option value="West Bengal">West Bengal</option>
                      <option value="Bihar">Bihar</option>
                      <option value="Uttar Pradesh">Uttar Pradesh</option>
                      <option value="Delhi">Delhi NCR</option>
                      <option value="Tripura">Tripura</option>
                      <option value="Meghalaya">Meghalaya</option>
                      <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                      <option value="Other">Other State</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Payment Methods */}
              <div>
                <h3 className="text-xs font-bold text-[#0B192C] uppercase tracking-wider mb-3">
                  Select Indian Payment Method
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    { id: 'UPI', label: 'UPI / QR', icon: Smartphone, desc: 'PhonePe, GPay, Paytm' },
                    { id: 'Card', label: 'Debit / Credit', icon: CreditCard, desc: 'RuPay, Visa, Master' },
                    { id: 'NetBanking', label: 'Net Banking', icon: Landmark, desc: 'SBI, HDFC, AGVB' },
                    { id: 'Wallet', label: 'Wallets', icon: Wallet, desc: 'Paytm, Mobikwik' },
                  ].map((method) => {
                    const Icon = method.icon;
                    const isSelected = paymentMethod === method.id;
                    return (
                      <button
                        key={method.id}
                        type="button"
                        onClick={() => setPaymentMethod(method.id as any)}
                        className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                          isSelected
                            ? 'border-amber-500 bg-amber-50/50 ring-2 ring-amber-400'
                            : 'border-slate-200 bg-white hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <Icon className={`w-5 h-5 ${isSelected ? 'text-amber-600' : 'text-slate-500'}`} />
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-amber-600" />}
                        </div>
                        <div className="mt-2">
                          <p className="text-xs font-bold text-slate-900">{method.label}</p>
                          <p className="text-[10px] text-slate-500 truncate">{method.desc}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Method Specific UI */}
                <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
                  {paymentMethod === 'UPI' && (
                    <div className="space-y-3">
                      <span className="text-xs font-bold text-slate-700 block">
                        Choose your UPI App:
                      </span>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {['PhonePe', 'GPay', 'Paytm', 'BHIM'].map((app) => (
                          <button
                            key={app}
                            type="button"
                            onClick={() => setUpiApp(app as any)}
                            className={`p-2 rounded-lg text-xs font-bold border transition-colors ${
                              upiApp === app
                                ? 'bg-[#0B192C] text-amber-400 border-[#0B192C]'
                                : 'bg-white text-slate-700 border-slate-300'
                            }`}
                          >
                            {app}
                          </button>
                        ))}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        A UPI collect request will be sent to your registered mobile number for instant biometric approval.
                      </p>
                    </div>
                  )}

                  {paymentMethod === 'Card' && (
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between items-center text-slate-600 font-semibold">
                        <span>Saved RuPay / Debit Card</span>
                        <span className="text-emerald-700 font-bold">256-Bit SSL Encrypted</span>
                      </div>
                      <input
                        type="text"
                        value={cardDetails.number}
                        readOnly
                        className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono"
                      />
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={cardDetails.name}
                          readOnly
                          className="flex-1 bg-white border border-slate-300 rounded-lg p-2 uppercase"
                        />
                        <input
                          type="text"
                          value={cardDetails.exp}
                          readOnly
                          className="w-20 bg-white border border-slate-300 rounded-lg p-2 text-center"
                        />
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'NetBanking' && (
                    <div className="space-y-2 text-xs">
                      <label className="block text-slate-600 font-semibold">
                        Select Bank Portal:
                      </label>
                      <select
                        value={selectedBank}
                        onChange={(e) => setSelectedBank(e.target.value)}
                        className="w-full bg-white border border-slate-300 rounded-lg p-2"
                      >
                        <option>State Bank of India (SBI)</option>
                        <option>Assam Gramin Vikash Bank (AGVB)</option>
                        <option>HDFC Bank</option>
                        <option>Punjab National Bank (PNB)</option>
                        <option>ICICI Bank</option>
                        <option>Bank of Baroda</option>
                      </select>
                    </div>
                  )}

                  {paymentMethod === 'Wallet' && (
                    <div className="text-xs text-slate-600">
                      <p className="font-semibold text-slate-800">Supported Wallets: Paytm Wallet, Mobikwik, Amazon Pay</p>
                      <p className="text-[11px] text-slate-500 mt-1">
                        One-click checkout using linked phone balance.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Order Summary Confirmation */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Cart Items ({cart.length})</span>
                  <span>₹{cartSubtotal}</span>
                </div>
                {cartDiscount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-bold">
                    <span>Discount Coupon ({appliedCoupon?.code})</span>
                    <span>- ₹{cartDiscount}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-200 flex justify-between font-black text-sm text-[#0B192C]">
                  <span>Total Amount to Pay</span>
                  <span className="text-lg">₹{cartTotal}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={() => handleProcessOrder(true)}
                  className="w-full bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm py-3 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 group"
                >
                  <Sparkles className="w-4 h-4 text-slate-900" />
                  <span>
                    {cartTotal === 0 ? 'Claim Free Ebooks Now' : `Simulate Pay ₹${cartTotal} via ${paymentMethod}`}
                  </span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <p className="text-[11px] text-center text-slate-400">
                  🔒 By proceeding, you agree to NEXA EXAM BOOKS Terms & Conditions and 24-Hour Digital Refund Policy.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
