import { useEffect, useState, type FormEvent } from 'react';
import QRCode from 'qrcode';
import {
  Check,
  CheckCircle2,
  Clock,
  Copy,
  CreditCard,
  ExternalLink,
  Lock,
  Receipt,
  ShieldCheck,
  Smartphone,
  Wallet,
  X,
  XCircle,
} from 'lucide-react';
import { apiRequest } from '../api.ts';
import type { OrderItem, UpiConfig } from '../types.ts';
import { formatInrExact, formatNumber, formatPaymentMethodLabel } from '../utils/format.ts';

type CheckoutMethod = 'upi' | 'gpay' | 'phonepe' | 'paytm' | 'card_netbanking' | 'wallet';

interface CheckoutModalProps {
  open: boolean;
  order: OrderItem | null;
  walletTopupAmountInr: number | null;
  walletBalancePaise: number;
  paymentMode: 'upi_direct' | 'razorpay';
  upiConfig: UpiConfig;
  onClose: () => void;
  onPaymentUpdated: () => void;
  onOpenReceipt: (paymentCode: string) => void;
}

interface GatewaySession {
  paymentMode: 'upi_direct' | 'razorpay';
  paymentCode: string;
  gateway: string;
  gatewayOrderId: string;
  amountPaise: number;
  method: CheckoutMethod;
}

const GATEWAY_METHODS: Array<{ id: CheckoutMethod; label: string; subtitle: string; accent: string }> = [
  { id: 'upi', label: 'UPI QR / App', subtitle: 'Scan QR or Any UPI App', accent: 'text-cyan-300' },
  { id: 'gpay', label: 'Google Pay', subtitle: 'Instant UPI Intent', accent: 'text-emerald-300' },
  { id: 'phonepe', label: 'PhonePe', subtitle: 'UPI & Wallet', accent: 'text-violet-300' },
  { id: 'paytm', label: 'Paytm', subtitle: 'UPI / Paytm Bank', accent: 'text-sky-300' },
  { id: 'card_netbanking', label: 'Card / NetBanking', subtitle: 'Visa, Mastercard, RuPay', accent: 'text-amber-300' },
];

export function CheckoutModal({
  open,
  order,
  walletTopupAmountInr,
  walletBalancePaise,
  paymentMode,
  upiConfig,
  onClose,
  onPaymentUpdated,
  onOpenReceipt,
}: CheckoutModalProps) {
  const [method, setMethod] = useState<CheckoutMethod>('upi');
  const [gatewaySession, setGatewaySession] = useState<GatewaySession | null>(null);
  const [statusState, setStatusState] = useState<'select' | 'awaiting_payment' | 'captured' | 'pending' | 'failed'>(
    'select',
  );
  const [settledPaymentCode, setSettledPaymentCode] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [utrInput, setUtrInput] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) {
      setGatewaySession(null);
      setStatusState('select');
      setSettledPaymentCode(null);
      setStatusMessage('');
      setQrDataUrl('');
      setUtrInput('');
      setCopiedUpi(false);
      setError('');
      setMethod('upi');
    }
  }, [open, order?.id, walletTopupAmountInr]);

  const isTopup = Boolean(walletTopupAmountInr && !order);
  const amountPaise = order ? order.total_amount_paise : Math.round((walletTopupAmountInr || 0) * 100);
  const amountRupeesExact = (amountPaise / 100).toFixed(2);

  const isUpiFamily =
    gatewaySession !== null &&
    (gatewaySession.method === 'upi' ||
      gatewaySession.method === 'gpay' ||
      gatewaySession.method === 'phonepe' ||
      gatewaySession.method === 'paytm');

  const upiUri =
    gatewaySession && upiConfig.merchantUpiId
      ? `upi://pay?pa=${encodeURIComponent(upiConfig.merchantUpiId)}&pn=${encodeURIComponent(
          upiConfig.merchantName || 'SOCIAL BOOST',
        )}&am=${encodeURIComponent(amountRupeesExact)}&cu=INR&tr=${encodeURIComponent(
          gatewaySession.paymentCode,
        )}&tn=${encodeURIComponent(
          order ? `Order ${order.order_code}` : `Wallet Topup ${gatewaySession.paymentCode}`,
        )}`
      : '';

  useEffect(() => {
    if (!upiUri || !isUpiFamily || !upiConfig.upiDirectEnabled) {
      setQrDataUrl('');
      return;
    }
    let active = true;
    QRCode.toDataURL(upiUri, {
      width: 220,
      margin: 2,
      color: { dark: '#08071a', light: '#ffffff' },
    })
      .then((url) => {
        if (active) setQrDataUrl(url);
      })
      .catch(() => {
        if (active) setQrDataUrl('');
      });
    return () => {
      active = false;
    };
  }, [upiUri, isUpiFamily, upiConfig.upiDirectEnabled]);

  if (!open || (!order && !walletTopupAmountInr)) return null;

  const canUseWallet = Boolean(order && walletBalancePaise >= amountPaise);

  const handleInitiatePayment = async () => {
    setError('');
    setLoading(true);
    try {
      const payload = order
        ? { purpose: 'order_payment', orderId: order.id, method }
        : { purpose: 'wallet_topup', amountInr: walletTopupAmountInr, method };

      const res = await apiRequest<{
        settledImmediately?: boolean;
        paymentCode: string;
        status?: string;
        paymentMode?: 'upi_direct' | 'razorpay';
        gateway?: string;
        gatewayOrderId?: string;
        amountPaise?: number;
        method?: CheckoutMethod;
      }>('/api/payments/create-order', {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      if (res.settledImmediately) {
        setSettledPaymentCode(res.paymentCode);
        setStatusState('captured');
        setStatusMessage('Wallet balance verified and order queued for fulfillment.');
        onPaymentUpdated();
        return;
      }

      setGatewaySession({
        paymentMode: res.paymentMode || paymentMode,
        paymentCode: res.paymentCode,
        gateway: res.gateway || 'upi_direct',
        gatewayOrderId: res.gatewayOrderId || '',
        amountPaise: res.amountPaise || amountPaise,
        method,
      });
      setStatusState('awaiting_payment');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to initialize checkout.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyUpiId = async () => {
    if (!upiConfig.merchantUpiId) return;
    try {
      await navigator.clipboard.writeText(upiConfig.merchantUpiId);
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2000);
    } catch {
      // ignore clipboard restrictions
    }
  };

  const handleSubmitUtr = async (e: FormEvent) => {
    e.preventDefault();
    if (!gatewaySession) return;
    setError('');
    setLoading(true);
    try {
      const res = await apiRequest<{ ok: boolean; status: string; message: string }>(
        '/api/payments/submit-upi-utr',
        {
          method: 'POST',
          body: JSON.stringify({
            paymentCode: gatewaySession.paymentCode,
            utrNumber: utrInput,
          }),
        },
      );
      setSettledPaymentCode(gatewaySession.paymentCode);
      setStatusMessage(res.message);
      setStatusState('pending');
      onPaymentUpdated();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to submit UTR.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-md p-0 sm:p-4">
      <div className="w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl sb-surface p-6 space-y-5 max-h-[92dvh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div className="flex items-center gap-2.5">
            <Lock className="h-5 w-5 text-fuchsia-400" />
            <div>
              <h3 className="text-base font-bold text-gradient-aurora">
                {isTopup ? 'Add Funds to Wallet' : 'Secure Order Checkout'}
              </h3>
              <p className="text-xs text-slate-300">
                {order ? `${order.order_code} · ${order.service_name_snapshot}` : 'Account Balance Top-Up'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close checkout"
            className="min-h-[40px] min-w-[40px] rounded-xl bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-slate-200 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Amount Summary */}
        <div className="rounded-xl sb-surface-inner p-4 flex items-center justify-between gap-4">
          <div>
            <div className="text-xs text-slate-400">Amount Payable</div>
            <div className="text-2xl font-extrabold font-mono tabular-nums text-gradient-sunset mt-0.5">
              {formatInrExact(amountPaise)}
            </div>
            {order && (
              <div className="text-xs text-cyan-300 mt-1">
                {formatNumber(order.quantity)} {order.service_name_snapshot}
              </div>
            )}
          </div>
          <div className="text-right">
            <div className="text-xs text-slate-400">Receiving Mode</div>
            <div className="text-xs font-semibold text-emerald-300 mt-0.5">
              {paymentMode === 'razorpay' ? 'Razorpay Live Gateway' : 'Direct UPI QR & UTR'}
            </div>
          </div>
        </div>

        {/* Step 1: Select Method */}
        {statusState === 'select' && (
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="text-xs font-semibold text-cyan-200">Select Payment Method</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {GATEWAY_METHODS.map((item) => {
                  const selected = method === item.id;
                  const disabled = item.id === 'card_netbanking' && paymentMode !== 'razorpay';
                  return (
                    <button
                      key={item.id}
                      type="button"
                      disabled={disabled}
                      onClick={() => !disabled && setMethod(item.id)}
                      className={`min-h-[52px] rounded-xl border px-3.5 py-2.5 text-left transition-all flex items-center justify-between gap-2 ${
                        disabled
                          ? 'border-white/[0.06] sb-surface-inner opacity-50 cursor-not-allowed'
                          : selected
                            ? 'border-fuchsia-400 bg-fuchsia-500/15 text-white cursor-pointer'
                            : 'border-white/10 sb-surface-inner text-slate-200 hover:border-cyan-400/40 cursor-pointer'
                      }`}
                    >
                      <div>
                        <div className={`text-xs font-semibold ${selected ? 'text-white' : item.accent}`}>
                          {item.label}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {disabled ? 'Requires Razorpay Live Keys' : item.subtitle}
                        </div>
                      </div>
                      {item.id === 'card_netbanking' ? (
                        <CreditCard className="h-4 w-4 shrink-0 text-amber-300" />
                      ) : (
                        <Smartphone className="h-4 w-4 shrink-0 text-cyan-300" />
                      )}
                    </button>
                  );
                })}

                {order && (
                  <button
                    type="button"
                    disabled={!canUseWallet}
                    onClick={() => canUseWallet && setMethod('wallet')}
                    className={`min-h-[52px] rounded-xl border px-3.5 py-2.5 text-left transition-all flex items-center justify-between gap-2 ${
                      !canUseWallet
                        ? 'border-white/[0.06] sb-surface-inner text-slate-500 cursor-not-allowed opacity-55'
                        : method === 'wallet'
                          ? 'border-emerald-400 bg-emerald-500/15 text-white cursor-pointer'
                          : 'border-white/10 sb-surface-inner text-slate-200 hover:border-emerald-400/40 cursor-pointer'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-semibold text-emerald-300">Account Wallet</div>
                      <div className="text-[11px] font-mono text-slate-300">
                        Bal: {formatInrExact(walletBalancePaise)}
                      </div>
                    </div>
                    <Wallet className="h-4 w-4 shrink-0 text-emerald-300" />
                  </button>
                )}
              </div>
            </div>

            <div className="rounded-xl sb-surface-inner px-3.5 py-2.5 text-[11px] text-slate-300 leading-relaxed flex items-start gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                We never collect or store UPI PINs, OTPs, or card numbers. Payments are verified via UPI UTR matching or gateway webhooks—never screenshots.
              </span>
            </div>

            {error && (
              <div className="rounded-xl bg-rose-500/15 border border-rose-400/40 px-3.5 py-2.5 text-xs text-rose-200">
                {error}
              </div>
            )}

            <button
              type="button"
              disabled={loading}
              onClick={handleInitiatePayment}
              className="w-full min-h-[48px] rounded-xl btn-gradient-primary disabled:opacity-60 text-sm font-semibold text-white cursor-pointer transition-all shadow-lg shadow-violet-600/25"
            >
              {loading
                ? 'Creating Payment Request...'
                : method === 'wallet'
                  ? `Pay ${formatInrExact(amountPaise)} from Wallet`
                  : `Continue with ${formatPaymentMethodLabel(method)}`}
            </button>
          </div>
        )}

        {/* Step 2: UPI QR + App Deep Link + UTR Submission */}
        {statusState === 'awaiting_payment' && gatewaySession && (
          <div className="space-y-4">
            <div className="rounded-xl sb-surface-inner p-3.5 space-y-1.5 text-xs">
              <div className="flex justify-between gap-4">
                <span className="text-slate-400">Payment Ref</span>
                <span className="font-mono text-cyan-300">{gatewaySession.paymentCode}</span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-slate-400">Selected Method</span>
                <span className="text-white font-semibold">{formatPaymentMethodLabel(gatewaySession.method)}</span>
              </div>
            </div>

            {/* Direct UPI QR + App Intent */}
            {isUpiFamily && upiConfig.upiDirectEnabled && (upiConfig.upiQrImageUrl || upiConfig.merchantUpiId) ? (
              <div className="rounded-2xl sb-surface-inner border-cyan-400/30 p-4 space-y-4">
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  {(upiConfig.upiQrImageUrl || qrDataUrl) && (
                    <div className="p-2 bg-white rounded-xl shrink-0 shadow-lg">
                      <img
                        src={upiConfig.upiQrImageUrl || qrDataUrl}
                        alt={`UPI QR Code for ${upiConfig.merchantName || upiConfig.merchantUpiId}`}
                        referrerPolicy="no-referrer"
                        className="w-36 h-36 object-contain block"
                      />
                    </div>
                  )}

                  <div className="flex-1 space-y-2.5 text-center sm:text-left min-w-0 w-full">
                    <div>
                      <div className="text-xs font-bold text-gradient-aurora">
                        Scan &amp; Pay via Any UPI App
                      </div>
                      <div className="text-[11px] text-slate-300 mt-0.5">
                        Payee: <span className="text-amber-300 font-medium">{upiConfig.merchantName || 'SOCIAL BOOST'}</span>
                      </div>
                    </div>

                    {upiConfig.merchantUpiId && (
                      <>
                        <div className="flex items-center justify-between gap-2 rounded-lg sb-surface px-3 py-2">
                          <span className="text-xs font-mono text-cyan-300 truncate">{upiConfig.merchantUpiId}</span>
                          <button
                            type="button"
                            onClick={handleCopyUpiId}
                            className="text-xs text-slate-200 hover:text-white flex items-center gap-1 shrink-0 cursor-pointer"
                          >
                            {copiedUpi ? (
                              <Check className="h-3.5 w-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="h-3.5 w-3.5 text-cyan-300" />
                            )}
                            <span>{copiedUpi ? 'Copied' : 'Copy'}</span>
                          </button>
                        </div>

                        <a
                          href={upiUri}
                          className="w-full min-h-[42px] rounded-xl btn-gradient-primary text-xs font-semibold text-white flex items-center justify-center gap-2 shadow-md shadow-fuchsia-500/20"
                        >
                          <span>Open UPI App (GPay / PhonePe / Paytm)</span>
                          <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      </>
                    )}
                  </div>
                </div>

                {/* UTR Verification Form */}
                <form onSubmit={handleSubmitUtr} className="pt-3 border-t border-white/10 space-y-2.5">
                  <label htmlFor="upi-utr-input" className="block text-xs font-medium text-cyan-200">
                    Already paid via UPI? Enter 12-digit UTR / Reference Number:
                  </label>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      id="upi-utr-input"
                      type="text"
                      required
                      minLength={10}
                      maxLength={22}
                      value={utrInput}
                      onChange={(e) => setUtrInput(e.target.value)}
                      placeholder="e.g. 432512894510"
                      className="flex-1 min-h-[44px] rounded-xl sb-surface px-3.5 text-sm font-mono text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                    />
                    <button
                      type="submit"
                      disabled={loading}
                      className="min-h-[44px] px-4 rounded-xl bg-emerald-500/20 border border-emerald-400/40 hover:bg-emerald-500/30 text-xs font-semibold text-emerald-200 whitespace-nowrap cursor-pointer"
                    >
                      {loading ? 'Submitting...' : 'Submit UTR'}
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Admin verifies your UTR against the merchant bank statement before queuing your order.
                  </p>
                </form>
              </div>
            ) : (
              <div className="rounded-xl sb-surface-inner p-4 text-xs text-amber-200 leading-relaxed">
                Merchant UPI QR / UPI ID has not been enabled yet by the administrator, or Razorpay live webhook confirmation is pending. Please check back shortly or contact support.
              </div>
            )}

            {error && (
              <div className="rounded-lg bg-rose-500/15 border border-rose-400/40 px-3 py-2 text-xs text-rose-200">
                {error}
              </div>
            )}
          </div>
        )}

        {/* Step 3: Outcomes */}
        {statusState === 'captured' && (
          <div className="space-y-4">
            <div className="rounded-xl border border-emerald-400/40 bg-emerald-500/15 p-4 flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-emerald-300 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="text-sm font-bold text-emerald-200">Payment Verified &amp; Settled</div>
                <p className="text-xs text-slate-200">{statusMessage}</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              {settledPaymentCode && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenReceipt(settledPaymentCode);
                  }}
                  className="flex-1 min-h-[44px] rounded-xl btn-gradient-primary text-xs font-semibold text-white flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Receipt className="h-4 w-4" />
                  <span>View Payment Receipt</span>
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="min-h-[44px] px-5 rounded-xl border border-white/12 bg-white/[0.06] hover:bg-white/[0.12] text-xs font-medium text-slate-200 cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}

        {statusState === 'pending' && (
          <div className="space-y-4">
            <div className="rounded-xl border border-amber-400/40 bg-amber-500/15 p-4 flex items-start gap-3">
              <Clock className="h-5 w-5 text-amber-300 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="text-sm font-bold text-amber-200">Payment Submitted — Pending Verification</div>
                <p className="text-xs text-slate-200">{statusMessage}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="w-full min-h-[44px] rounded-xl border border-white/12 bg-white/[0.06] hover:bg-white/[0.1] text-xs font-semibold text-white cursor-pointer"
            >
              Close &amp; Track Order Status
            </button>
          </div>
        )}

        {statusState === 'failed' && (
          <div className="space-y-4">
            <div className="rounded-xl border border-rose-400/40 bg-rose-500/15 p-4 flex items-start gap-3">
              <XCircle className="h-5 w-5 text-rose-300 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="text-sm font-bold text-rose-200">Payment Failed</div>
                <p className="text-xs text-slate-200">
                  {statusMessage} No funds were captured. You can retry with another payment method.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setGatewaySession(null);
                setStatusState('select');
              }}
              className="w-full min-h-[44px] rounded-xl border border-white/12 bg-white/[0.06] hover:bg-white/[0.12] text-xs font-semibold text-white cursor-pointer"
            >
              Retry Checkout
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
