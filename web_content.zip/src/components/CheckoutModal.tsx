import React, { useState } from 'react';
import { CartItem, StoreSettings, Order, AppLanguage } from '../types';
import { formatPKR } from '../utils/storage';
import { X, User, Phone, MapPin, Home, CheckCircle2, MessageCircle, AlertCircle, Sparkles } from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  settings: StoreSettings;
  language: AppLanguage;
  customNotes: string;
  onOrderPlaced: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cart,
  settings,
  language,
  customNotes,
  onOrderPlaced
}) => {
  if (!isOpen) return null;
  const isUrdu = language === 'ur';

  // Form State
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [selectedVillage, setSelectedVillage] = useState(settings.villages[0] || 'مرکزی گاؤں');
  const [customVillage, setCustomVillage] = useState('');
  const [streetAddress, setStreetAddress] = useState('');
  const [notes, setNotes] = useState(customNotes || '');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'jazzcash_easypaisa'>('cod');
  const [error, setError] = useState('');

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const isFreeDelivery = subtotal >= settings.freeDeliveryThreshold;
  const deliveryFee = isFreeDelivery ? 0 : settings.deliveryFee;
  const total = subtotal + deliveryFee;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!customerName.trim()) {
      setError(isUrdu ? 'برائے مہربانی اپنا نام درج کریں' : 'Please enter your name');
      return;
    }

    const cleanPhone = customerPhone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setError(isUrdu ? 'درست موبائل نمبر درج کریں (مثلاً: 03017144300)' : 'Please enter a valid 11-digit mobile number');
      return;
    }

    const village = selectedVillage === 'OTHER' ? customVillage.trim() : selectedVillage;
    if (!village) {
      setError(isUrdu ? 'اپنے گاؤں یا چک کا نام درج کریں' : 'Please specify your village or chak name');
      return;
    }

    if (!streetAddress.trim()) {
      setError(isUrdu ? 'گلی، محلہ یا قریبی نشانی درج کریں' : 'Please enter street, mohallah or landmark');
      return;
    }

    // Build unique Order ID
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const orderId = `OB-${randomNum}`;

    const newOrder: Order = {
      id: orderId,
      createdAt: new Date().toISOString(),
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      villageName: village,
      streetAddress: streetAddress.trim(),
      notes: notes.trim(),
      items: cart.map(item => ({
        productId: item.product.id,
        name: item.product.name,
        urduName: item.product.urduName,
        unit: item.product.unit,
        price: item.product.price,
        quantity: item.quantity,
        total: item.product.price * item.quantity
      })),
      subtotal,
      deliveryFee,
      total,
      paymentMethod,
      status: 'pending'
    };

    onOrderPlaced(newOrder);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl my-4">
        {/* Header */}
        <div className="bg-emerald-800 text-white p-4 flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-bold flex items-center gap-1.5">
              <span>{isUrdu ? 'گاؤں ڈیلیوری و آرڈر فارم' : 'Village Delivery & Order Form'}</span>
            </h2>
            <p className="text-xs text-emerald-200">
              {isUrdu 
                ? 'محمد اویس بلال کو واٹس ایپ پر فوری آرڈر بھیجیں' 
                : `Order directly to Owais Bilal (${settings.phone})`}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-emerald-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 max-h-[78vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Customer Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {isUrdu ? 'آپ کا مکمل نام *' : 'Your Full Name *'}
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder={isUrdu ? "مثلاً: علی احمد، چوہدری اصغر، حافظ بلال" : "e.g. Ali Ahmad / Asghar"}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-medium"
              />
            </div>
          </div>

          {/* Customer Phone */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {isUrdu ? 'واٹس ایپ / موبائل نمبر *' : 'Mobile / WhatsApp Number *'}
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="tel"
                required
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="03001234567"
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-mono font-medium"
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {isUrdu ? 'اس نمبر پر آرڈر کنفرمیشن اور ڈیلیوری کی اطلاع دی جائے گی' : 'For delivery call and WhatsApp confirmation'}
            </p>
          </div>

          {/* Village / Chak Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {isUrdu ? 'اپنا گاؤں یا چک منتخب کریں *' : 'Select Village / Chak *'}
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3 z-10" />
              <select
                value={selectedVillage}
                onChange={(e) => setSelectedVillage(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs sm:text-sm font-medium bg-white"
              >
                {settings.villages.map((v, i) => (
                  <option key={i} value={v}>
                    {v}
                  </option>
                ))}
                <option value="OTHER">
                  {isUrdu ? 'کوئی دوسرا گاؤں / چک (نام لکھیں)' : 'Other Village / Chak (Type name)'}
                </option>
              </select>
            </div>
          </div>

          {/* Custom Village Name if Other */}
          {selectedVillage === 'OTHER' && (
            <div>
              <label className="block text-xs font-bold text-emerald-800 mb-1">
                {isUrdu ? 'گاؤں یا چک کا نام درج کریں:' : 'Enter Village / Chak Name:'}
              </label>
              <input
                type="text"
                required
                value={customVillage}
                onChange={(e) => setCustomVillage(e.target.value)}
                placeholder={isUrdu ? "اپنے گاؤں یا بستی کا نام لکھیں" : "Type your village or chak name"}
                className="w-full px-3 py-2.5 rounded-xl border border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
              />
            </div>
          )}

          {/* Street / Mohallah / Landmark */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {isUrdu ? 'گلی، محلہ، نزد مسجد یا ڈیرہ (نشانی) *' : 'Street / Mohallah / Landmark *'}
            </label>
            <div className="relative">
              <Home className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                required
                value={streetAddress}
                onChange={(e) => setStreetAddress(e.target.value)}
                placeholder={isUrdu ? "مثلاً: نزد جامع مسجد، ڈیرے کے سامنے، پرائمری سکول کے پاس" : "e.g. Near Jamia Masjid, opposite Dera, main bazaar"}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
              />
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              {isUrdu ? 'طریقہ ادائیگی (Payment Method) *' : 'Payment Method *'}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <label
                onClick={() => setPaymentMethod('cod')}
                className={`flex flex-col p-3 rounded-2xl border cursor-pointer transition text-center ${
                  paymentMethod === 'cod'
                    ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <span className="text-xl mb-1">💵</span>
                <span className="text-xs font-bold text-slate-800">
                  {isUrdu ? 'کیش آن ڈیلیوری' : 'Cash on Delivery'}
                </span>
                <span className="text-[10px] text-slate-500 mt-0.5">
                  {isUrdu ? 'سامان ملنے پر نقد دیں' : 'Pay when you receive'}
                </span>
              </label>

              <label
                onClick={() => setPaymentMethod('jazzcash_easypaisa')}
                className={`flex flex-col p-3 rounded-2xl border cursor-pointer transition text-center ${
                  paymentMethod === 'jazzcash_easypaisa'
                    ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <span className="text-xl mb-1">📱</span>
                <span className="text-xs font-bold text-slate-800">
                  {isUrdu ? 'جاز کیش / ایزی پیسہ' : 'JazzCash / EasyPaisa'}
                </span>
                <span className="text-[10px] text-emerald-700 font-mono font-bold mt-0.5">
                  {settings.phone}
                </span>
              </label>
            </div>
          </div>

          {/* Notes / Extra items */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {isUrdu ? 'اضافی سامان یا خصوصی ہدایات:' : 'Additional items or special notes:'}
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={isUrdu ? "کوئی خاص ہدایت، وقت، یا اضافی چیز جو لسٹ میں نہیں ملی..." : "Special instructions, preferred delivery time, etc."}
              rows={2}
              className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs resize-none"
            />
          </div>

          {/* Order Summary Box */}
          <div className="bg-slate-50 rounded-2xl p-3 border border-slate-200 text-xs space-y-1.5">
            <div className="flex justify-between text-slate-600">
              <span>{isUrdu ? 'کل سامان کی قیمت:' : 'Subtotal:'}</span>
              <span className="font-bold">{formatPKR(subtotal, isUrdu)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>{isUrdu ? 'گاؤں ڈیلیوری فیس:' : 'Village Delivery Fee:'}</span>
              <span className="font-bold text-emerald-700">
                {deliveryFee === 0 ? (isUrdu ? 'مفت (Free)' : 'FREE') : formatPKR(deliveryFee, isUrdu)}
              </span>
            </div>
            <div className="pt-1.5 border-t border-slate-200 flex justify-between font-black text-sm text-slate-900">
              <span>{isUrdu ? 'کل واجب الادا رقم:' : 'Total Amount to Pay:'}</span>
              <span className="text-emerald-800">{formatPKR(total, isUrdu)}</span>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3.5 px-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 text-sm sm:text-base transition transform active:scale-98"
          >
            <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
            <span>
              {isUrdu ? 'آرڈر مکمل کریں اور واٹس ایپ کھولیں' : 'Confirm Order & Send to WhatsApp'}
            </span>
          </button>
        </form>
      </div>
    </div>
  );
};
