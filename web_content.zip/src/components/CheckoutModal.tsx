import React, { useEffect, useState } from 'react';
import {
  X,
  CheckCircle2,
  Lock,
  Truck,
  CreditCard,
  AlertCircle,
  Loader2,
  ArrowRight,
  ArrowLeft,
  MapPin,
  Navigation,
} from 'lucide-react';
import { doc, getDoc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useStoreData } from '../context/StoreDataContext';
import { formatCurrency, getEffectivePrice } from '../lib/formatters';
import { detectBrowserLocation, LOCATION_PRESETS } from '../lib/location';
import { Product } from '../types/store';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderComplete: () => void;
}

interface PlacedOrderReceipt {
  orderId: string;
  orderNumber: string;
  totalAmount: number;
  subtotal: number;
  shippingFee: number;
  customerName: string;
  phone: string;
  location: string;
  addressSummary: string;
  itemCount: number;
}

export function CheckoutModal({ isOpen, onClose, onOrderComplete }: CheckoutModalProps) {
  const { user, userProfile, signInWithGoogle, resendVerification } = useAuth();
  const { items, clearCart } = useCart();
  const { settings, notify } = useStoreData();

  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [detectingLoc, setDetectingLoc] = useState(false);
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [pinCode, setPinCode] = useState('');
  const [paymentMethod] = useState<'Cash on Delivery'>('Cash on Delivery');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [receipt, setReceipt] = useState<PlacedOrderReceipt | null>(null);

  useEffect(() => {
    if (isOpen) {
      setErrorMsg('');
      if (userProfile) {
        setCustomerName((prev) => prev || userProfile.displayName || '');
        setPhone((prev) => prev || userProfile.phone || '');
        setLocation((prev) => prev || userProfile.location || '');
        setAddress((prev) => prev || userProfile.address || '');
        setCity((prev) => prev || userProfile.city || '');
        setPinCode((prev) => prev || userProfile.pinCode || '');
      } else if (user) {
        setCustomerName((prev) => prev || user.displayName || '');
      }
    } else {
      setReceipt(null);
    }
  }, [isOpen, userProfile, user]);

  const handleDetectLocation = async () => {
    setDetectingLoc(true);
    try {
      const detected = await detectBrowserLocation();
      setLocation(detected);
      notify('Current location detected.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Unable to detect location.', 'error');
    } finally {
      setDetectingLoc(false);
    }
  };

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, i) => sum + i.effectivePrice * i.quantity, 0);
  const freeThreshold = settings.freeShippingThreshold ?? 999;
  const standardFee = settings.standardShippingFee ?? 60;
  const shippingFee = items.length === 0 ? 0 : subtotal >= freeThreshold ? 0 : standardFee;
  const totalAmount = subtotal + shippingFee;

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!user) {
      setErrorMsg('Please sign in to place your order.');
      return;
    }
    if (!user.emailVerified) {
      setErrorMsg('Please verify your email address (or sign in with Google) before placing an order.');
      return;
    }
    if (items.length === 0) {
      setErrorMsg('Your shopping bag is empty.');
      return;
    }
    if (items.length > 6) {
      setErrorMsg('Please limit a single order to 6 distinct products.');
      return;
    }

    const cleanName = customerName.trim();
    const cleanPhone = phone.trim();
    const cleanLocation = location.trim();
    const cleanAddress = address.trim();
    const cleanCity = city.trim();
    const cleanPin = pinCode.trim();

    if (cleanName.length < 2) return setErrorMsg('Please enter your full name.');
    if (cleanPhone.length < 6) return setErrorMsg('Please enter a valid mobile number.');
    if (cleanLocation.length < 2) return setErrorMsg('Please enter or select your location.');
    if (cleanAddress.length < 5) return setErrorMsg('Please enter your complete delivery address.');
    if (cleanCity.length < 2) return setErrorMsg('Please enter your city.');
    if (cleanPin.length < 4) return setErrorMsg('Please enter a valid PIN / Postal code.');

    setSubmitting(true);

    try {
      // Server-authoritative verification: fetch latest Firestore product docs
      // so prices, discounts, and stock are verified against Firestore directly.
      const verifiedItems: {
        productId: string;
        productName: string;
        productImage: string;
        selectedSize: string;
        selectedColor: string;
        quantity: number;
        unitPrice: number;
        lineTotal: number;
      }[] = [];

      let verifiedSubtotal = 0;
      let verifiedQty = 0;

      for (const item of items) {
        const prodSnap = await getDoc(doc(db, 'products', item.productId));
        if (!prodSnap.exists()) {
          throw new Error(`"${item.name}" is no longer available.`);
        }
        const prod = { ...prodSnap.data(), id: prodSnap.id } as Product;
        if (!prod.isActive) {
          throw new Error(`"${prod.name}" is currently unavailable.`);
        }
        if (prod.stock < item.quantity) {
          throw new Error(
            `Only ${prod.stock} unit(s) of "${prod.name}" remain in stock.`
          );
        }
        const unitPrice = getEffectivePrice(prod);
        const lineTotal = Number((unitPrice * item.quantity).toFixed(2));
        verifiedSubtotal = Number((verifiedSubtotal + lineTotal).toFixed(2));
        verifiedQty += item.quantity;

        verifiedItems.push({
          productId: prod.id,
          productName: prod.name.slice(0, 120),
          productImage: prod.imageUrl.slice(0, 1000),
          selectedSize: item.selectedSize,
          selectedColor: item.selectedColor,
          quantity: item.quantity,
          unitPrice,
          lineTotal,
        });
      }

      const verifiedShipping = verifiedSubtotal >= freeThreshold ? 0 : standardFee;
      const verifiedTotal = Number((verifiedSubtotal + verifiedShipping).toFixed(2));

      const orderId = `ord-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const orderNumber = `SH-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`;

      const batch = writeBatch(db);

      verifiedItems.forEach((vItem, idx) => {
        const itemRef = doc(db, 'orders', orderId, 'items', `item_${idx}`);
        batch.set(itemRef, {
          orderId,
          userId: user.uid,
          productId: vItem.productId,
          productName: vItem.productName,
          productImage: vItem.productImage,
          selectedSize: vItem.selectedSize,
          selectedColor: vItem.selectedColor,
          quantity: vItem.quantity,
          unitPrice: vItem.unitPrice,
          lineTotal: vItem.lineTotal,
        });
      });

      const orderRef = doc(db, 'orders', orderId);
      batch.set(orderRef, {
        orderNumber,
        userId: user.uid,
        customerName: cleanName.slice(0, 100),
        customerEmail: (user.email || 'customer@fashionhub.store').slice(0, 150),
        phone: cleanPhone.slice(0, 20),
        location: cleanLocation.slice(0, 160),
        address: cleanAddress.slice(0, 300),
        city: cleanCity.slice(0, 80),
        pinCode: cleanPin.slice(0, 12),
        paymentMethod,
        paymentStatus: 'Pending',
        status: 'Pending',
        itemCount: verifiedItems.length,
        totalQuantity: verifiedQty,
        subtotal: verifiedSubtotal,
        shippingFee: verifiedShipping,
        totalAmount: verifiedTotal,
        primaryProductName: verifiedItems[0].productName,
        primaryProductImage: verifiedItems[0].productImage,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      // Also keep user profile delivery fields updated
      const userRef = doc(db, 'users', user.uid);
      batch.update(userRef, {
        displayName: cleanName.slice(0, 100),
        phone: cleanPhone.slice(0, 20),
        location: cleanLocation.slice(0, 160),
        address: cleanAddress.slice(0, 300),
        city: cleanCity.slice(0, 80),
        pinCode: cleanPin.slice(0, 12),
        updatedAt: serverTimestamp(),
      });

      try {
        await batch.commit();
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `orders/${orderId}`);
      }

      clearCart();
      setReceipt({
        orderId,
        orderNumber,
        totalAmount: verifiedTotal,
        subtotal: verifiedSubtotal,
        shippingFee: verifiedShipping,
        customerName: cleanName,
        phone: cleanPhone,
        location: cleanLocation,
        addressSummary: `${cleanAddress}, ${cleanCity} ${cleanPin}`,
        itemCount: verifiedItems.length,
      });
      notify(`Order ${orderNumber} placed successfully.`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to place order. Please try again.';
      setErrorMsg(msg);
      notify(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label="Checkout"
    >
      <div className="relative bg-white w-full max-w-3xl border border-neutral-200 shadow-2xl my-auto overflow-hidden">
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full border border-neutral-300 text-xs font-medium text-neutral-700 hover:text-[#0A0A0A] hover:border-[#0A0A0A] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-[#0A0A0A]" />
              <h2 className="text-sm font-semibold tracking-wide uppercase">
                {receipt ? 'Order Confirmed' : 'Order Now · Checkout'}
              </h2>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close checkout"
            className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-neutral-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {receipt ? (
          <div className="p-8 sm:p-10 text-center">
            <div className="w-14 h-14 mx-auto mb-5 rounded-full bg-[#0A0A0A] text-white flex items-center justify-center">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <p className="text-xs uppercase tracking-[0.2em] text-neutral-500 mb-2">
              Order Placed Successfully
            </p>
            <h3 className="font-display text-3xl font-semibold text-[#0A0A0A] mb-2">
              Thank you, {receipt.customerName}
            </h3>
            <p className="text-sm text-neutral-600 mb-6">
              Order ID:{' '}
              <span className="font-mono font-medium text-[#0A0A0A]">
                {receipt.orderNumber}
              </span>
            </p>

            <div className="max-w-md mx-auto border border-neutral-200 bg-neutral-50/70 p-5 text-left text-xs space-y-2.5 mb-8">
              <div className="flex justify-between gap-4">
                <span className="text-neutral-500 shrink-0">Customer Name</span>
                <span className="font-semibold text-[#0A0A0A] text-right">
                  {receipt.customerName}
                </span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-neutral-500 shrink-0">Phone Number</span>
                <span className="font-medium text-[#0A0A0A] text-right">
                  {receipt.phone}
                </span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-neutral-500 shrink-0">Location</span>
                <span className="font-medium text-[#0A0A0A] text-right max-w-[240px]">
                  {receipt.location}
                </span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-neutral-500 shrink-0">Delivery Address</span>
                <span className="font-medium text-[#0A0A0A] text-right max-w-[240px]">
                  {receipt.addressSummary}
                </span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-neutral-500">Payment Method</span>
                <span className="font-medium text-[#0A0A0A]">Cash on Delivery</span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-neutral-500">Status</span>
                <span className="font-semibold text-[#0A0A0A]">Pending Confirmation</span>
              </div>
              <div className="pt-2.5 border-t border-neutral-200 flex justify-between text-sm font-semibold text-[#0A0A0A]">
                <span>Total Payable</span>
                <span className="tabular-nums">{formatCurrency(receipt.totalAmount)}</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="inline-flex items-center gap-1.5 px-6 py-3 rounded-full border border-neutral-300 text-xs font-semibold hover:bg-neutral-100 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Store</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOrderComplete();
                }}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                <span>Track in My Orders</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : !user ? (
          <div className="p-8 sm:p-10 text-center max-w-md mx-auto">
            <h3 className="font-display text-2xl font-semibold mb-2">
              Sign in to complete your order
            </h3>
            <p className="text-sm text-neutral-600 mb-5">
              Enter your location and sign in so we can save your order and provide live tracking.
            </p>
            <div className="text-left mb-5 p-3.5 border border-neutral-200 bg-neutral-50/70 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <label className="text-xs font-semibold text-[#0A0A0A] flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>Your Location</span>
                </label>
                <button
                  type="button"
                  disabled={detectingLoc}
                  onClick={handleDetectLocation}
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#0A0A0A] underline cursor-pointer"
                >
                  <Navigation className="w-3 h-3" />
                  <span>{detectingLoc ? 'Detecting...' : 'Use Current Location'}</span>
                </button>
              </div>
              <input
                type="text"
                maxLength={160}
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Enter your location (e.g. Assam Badarpur)"
                className="w-full px-3 py-2 text-xs border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none"
              />
            </div>
            <button
              type="button"
              onClick={async () => {
                try {
                  await signInWithGoogle(location);
                  notify('Signed in successfully.', 'success');
                } catch (err) {
                  setErrorMsg(err instanceof Error ? err.message : 'Sign-in failed.');
                }
              }}
              className="w-full py-3.5 px-6 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              Continue with Google
            </button>
            <button
              type="button"
              onClick={onClose}
              className="mt-3 inline-flex items-center gap-1.5 text-xs text-neutral-500 hover:text-[#0A0A0A] cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Shopping</span>
            </button>
            {errorMsg && (
              <p className="mt-4 text-xs text-red-600">{errorMsg}</p>
            )}
          </div>
        ) : (
          <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 md:grid-cols-5">
            {/* Delivery Form */}
            <div className="md:col-span-3 p-6 sm:p-7 space-y-4 border-b md:border-b-0 md:border-r border-neutral-200">
              {!user.emailVerified && (
                <div className="p-3.5 border border-amber-300 bg-amber-50 text-xs text-amber-900 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">Email verification required</p>
                    <p className="mt-0.5">
                      Please verify your email link or sign in with Google to place verified orders.
                    </p>
                    <button
                      type="button"
                      onClick={async () => {
                        await resendVerification();
                        notify('Verification email sent.', 'info');
                      }}
                      className="mt-1.5 underline font-semibold cursor-pointer"
                    >
                      Resend verification email
                    </button>
                  </div>
                </div>
              )}

              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-3">
                  Delivery Information
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-neutral-700 mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={100}
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Alex Mercer"
                      className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-700 mb-1">
                      Mobile / Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      maxLength={20}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 98765 43210"
                      className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                    />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-medium text-neutral-700">
                        Customer Location *
                      </label>
                      <button
                        type="button"
                        disabled={detectingLoc}
                        onClick={handleDetectLocation}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#0A0A0A] underline hover:opacity-75 cursor-pointer"
                      >
                        <Navigation className="w-3 h-3" />
                        <span>{detectingLoc ? 'Detecting...' : 'Use Current Location'}</span>
                      </button>
                    </div>
                    <input
                      type="text"
                      required
                      maxLength={160}
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="e.g. Assam Badarpur, Station Road"
                      className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                    />
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {LOCATION_PRESETS.map((loc) => (
                        <button
                          key={loc}
                          type="button"
                          onClick={() => setLocation(loc)}
                          className={`px-2.5 py-1 rounded-full text-[11px] border transition-colors cursor-pointer ${
                            location === loc
                              ? 'bg-[#0A0A0A] text-white border-[#0A0A0A]'
                              : 'bg-white text-neutral-700 border-neutral-300 hover:border-[#0A0A0A]'
                          }`}
                        >
                          {loc}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-700 mb-1">
                      Full Delivery Address *
                    </label>
                    <textarea
                      required
                      rows={2}
                      maxLength={300}
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="House no., street address, landmark"
                      className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none resize-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-neutral-700 mb-1">
                        City
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={80}
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        placeholder="New York"
                        className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-neutral-700 mb-1">
                        PIN / Postal Code
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={12}
                        value={pinCode}
                        onChange={(e) => setPinCode(e.target.value)}
                        placeholder="10001"
                        className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Method */}
              <div className="pt-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-3">
                  Payment Method
                </h3>
                <div className="space-y-2.5">
                  <label className="flex items-start gap-3 p-3.5 border border-[#0A0A0A] bg-neutral-50 cursor-pointer">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked
                      readOnly
                      className="mt-1 accent-[#0A0A0A]"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 text-xs font-semibold text-[#0A0A0A]">
                        <Truck className="w-3.5 h-3.5" />
                        <span>Cash on Delivery</span>
                      </div>
                      <p className="text-[11px] text-neutral-600 mt-0.5">
                        Pay securely in cash or card-on-arrival when your parcel is delivered.
                      </p>
                    </div>
                  </label>

                  <div className="flex items-start gap-3 p-3.5 border border-neutral-200 bg-neutral-50/50 opacity-65">
                    <input
                      type="radio"
                      name="paymentMethod"
                      disabled
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 text-xs font-semibold text-neutral-600">
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>Online Payment</span>
                      </div>
                      <p className="text-[11px] text-neutral-500 mt-0.5">
                        Available once a live payment gateway is configured in store settings.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {errorMsg && (
                <div className="p-3 border border-red-200 bg-red-50 text-xs text-red-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}
            </div>

            {/* Order Summary */}
            <div className="md:col-span-2 p-6 sm:p-7 bg-neutral-50/80 flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-4">
                  Order Summary ({items.length})
                </h3>
                <div className="space-y-3 max-h-60 overflow-y-auto pr-1 mb-5">
                  {items.map((item) => (
                    <div
                      key={`${item.productId}-${item.selectedSize}-${item.selectedColor}`}
                      className="flex items-center gap-3 text-xs"
                    >
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-11 h-14 object-cover bg-neutral-200 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-[#0A0A0A] truncate">{item.name}</p>
                        <p className="text-neutral-500">
                          {item.selectedSize} · Qty {item.quantity}
                        </p>
                      </div>
                      <span className="font-semibold tabular-nums">
                        {formatCurrency(item.effectivePrice * item.quantity)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2 border-t border-neutral-200 pt-4 text-xs">
                <div className="flex justify-between text-neutral-600">
                  <span>Subtotal</span>
                  <span className="tabular-nums font-medium text-[#0A0A0A]">
                    {formatCurrency(subtotal)}
                  </span>
                </div>
                <div className="flex justify-between text-neutral-600">
                  <span>Delivery</span>
                  <span className="tabular-nums font-medium text-[#0A0A0A]">
                    {shippingFee === 0 ? 'Complimentary' : formatCurrency(shippingFee)}
                  </span>
                </div>
                <div className="pt-2 border-t border-neutral-200 flex justify-between text-sm font-semibold text-[#0A0A0A]">
                  <span>Total</span>
                  <span className="tabular-nums">{formatCurrency(totalAmount)}</span>
                </div>

                <div className="mt-4 space-y-2">
                  <button
                    type="submit"
                    disabled={submitting || items.length === 0}
                    className="w-full py-3.5 px-6 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 disabled:opacity-50 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                    <span>{submitting ? 'Placing Order...' : 'Order Now'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={onClose}
                    className="w-full py-2.5 px-6 rounded-full border border-neutral-300 text-xs font-medium text-neutral-700 hover:bg-white transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>
                </div>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
