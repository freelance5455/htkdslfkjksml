import React, { useState } from 'react';
import { X, CheckCircle2, Truck, CreditCard, Banknote, Building2, Printer, ArrowLeft } from 'lucide-react';
import { CartItem, CurrencyCode, CustomerProfile, Order } from '../types';
import { formatPrice } from '../utils/currency';

interface CheckoutModalProps {
  isOpen: boolean;
  cart: CartItem[];
  discountPercent: number;
  activeCurrency: CurrencyCode;
  savedProfile: CustomerProfile;
  onClose: () => void;
  onOrderCompleted: (order: Order) => void;
  onSaveProfile: (profile: CustomerProfile) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  cart,
  discountPercent,
  activeCurrency,
  savedProfile,
  onClose,
  onOrderCompleted,
  onSaveProfile
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<'shipping' | 'payment' | 'confirmation'>('shipping');
  const [profile, setProfile] = useState<CustomerProfile>(savedProfile);
  const [paymentMethod, setPaymentMethod] = useState<'Cash on Delivery (COD)' | 'Direct Bank Transfer' | 'Card Payment (Simulated)'>('Cash on Delivery (COD)');
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  const subtotalUsd = cart.reduce((sum, item) => sum + item.product.priceUsd * item.quantity, 0);
  const discountUsd = (subtotalUsd * discountPercent) / 100;
  const shippingUsd = subtotalUsd >= 75 ? 0 : 10;
  const totalUsd = subtotalUsd - discountUsd + shippingUsd;

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveProfile(profile);
    setStep('payment');
  };

  const handlePlaceOrder = () => {
    const tracking = `BUK-${Math.floor(100000 + Math.random() * 900000)}`;
    const newOrder: Order = {
      id: `ORD-${Date.now()}`,
      date: new Date().toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }),
      items: [...cart],
      subtotal: subtotalUsd,
      discount: discountUsd,
      shipping: shippingUsd,
      total: totalUsd,
      currency: activeCurrency,
      customer: profile,
      paymentMethod,
      status: 'Confirmed',
      trackingNumber: tracking
    };

    setCompletedOrder(newOrder);
    onOrderCompleted(newOrder);
    setStep('confirmation');
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs">
      <div 
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-stone-200 relative flex flex-col p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-stone-200">
          <div>
            <h2 className="font-serif text-2xl font-semibold text-stone-900">
              {step === 'confirmation' ? 'Order Confirmed' : 'Checkout & Delivery'}
            </h2>
            <p className="text-xs text-stone-500">
              {step === 'shipping' && 'Step 1 of 2: Shipping details (saved locally on your device)'}
              {step === 'payment' && 'Step 2 of 2: Select payment preference'}
              {step === 'confirmation' && 'Your order is recorded locally and ready for fulfillment'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-900 rounded-full hover:bg-stone-100 cursor-pointer"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step 1: Shipping Form */}
        {step === 'shipping' && (
          <form onSubmit={handleShippingSubmit} className="mt-6 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ukasha Khan"
                  value={profile.fullName}
                  onChange={(e) => setProfile({ ...profile, fullName: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-800"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Phone Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="+92 300 1234567 or local number"
                  value={profile.phone}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-800"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Email Address</label>
              <input
                type="email"
                placeholder="For order dispatch receipt"
                value={profile.email}
                onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-800"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Street Address *</label>
              <input
                type="text"
                required
                placeholder="House / Apartment number, Street name, Sector"
                value={profile.address}
                onChange={(e) => setProfile({ ...profile, address: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-800"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">City *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lahore / Dubai"
                  value={profile.city}
                  onChange={(e) => setProfile({ ...profile, city: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-800"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Postal Code</label>
                <input
                  type="text"
                  placeholder="e.g. 54000"
                  value={profile.postalCode}
                  onChange={(e) => setProfile({ ...profile, postalCode: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-800"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Country *</label>
                <input
                  type="text"
                  required
                  placeholder="Country"
                  value={profile.country}
                  onChange={(e) => setProfile({ ...profile, country: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-800"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Delivery Notes (Optional)</label>
              <textarea
                rows={2}
                placeholder="Special gate instructions or preferred delivery time..."
                value={profile.notes || ''}
                onChange={(e) => setProfile({ ...profile, notes: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-800"
              />
            </div>

            <div className="pt-4 flex items-center justify-between border-t border-stone-200">
              <span className="text-xs text-stone-500">
                Data saved in your local browser only.
              </span>
              <button
                type="submit"
                className="px-6 py-2.5 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 cursor-pointer"
              >
                Continue to Payment
              </button>
            </div>
          </form>
        )}

        {/* Step 2: Payment Selection */}
        {step === 'payment' && (
          <div className="mt-6 space-y-6">
            <div className="space-y-3">
              <label
                onClick={() => setPaymentMethod('Cash on Delivery (COD)')}
                className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMethod === 'Cash on Delivery (COD)'
                    ? 'border-stone-900 bg-stone-50 ring-1 ring-stone-900'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <Banknote className="w-5 h-5 text-stone-700 mt-0.5" />
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-stone-900">Cash on Delivery (COD)</span>
                    <span className="text-[11px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-medium">
                      Most Popular
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 mt-1">
                    Pay with cash directly to the courier upon delivery at your doorstep. No prepayment or credit card needed.
                  </p>
                </div>
              </label>

              <label
                onClick={() => setPaymentMethod('Direct Bank Transfer')}
                className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMethod === 'Direct Bank Transfer'
                    ? 'border-stone-900 bg-stone-50 ring-1 ring-stone-900'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <Building2 className="w-5 h-5 text-stone-700 mt-0.5" />
                <div className="flex-1">
                  <span className="text-sm font-semibold text-stone-900">Direct Bank Wire / Raast</span>
                  <p className="text-xs text-stone-500 mt-1">
                    Transfer funds directly to Bait ul Ukasha IBAN. Order will be dispatched once receipt reference is verified.
                  </p>
                </div>
              </label>

              <label
                onClick={() => setPaymentMethod('Card Payment (Simulated)')}
                className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMethod === 'Card Payment (Simulated)'
                    ? 'border-stone-900 bg-stone-50 ring-1 ring-stone-900'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <CreditCard className="w-5 h-5 text-stone-700 mt-0.5" />
                <div className="flex-1">
                  <span className="text-sm font-semibold text-stone-900">Credit / Debit Card (Offline Demo)</span>
                  <p className="text-xs text-stone-500 mt-1">
                    Client-side sandbox payment simulator. Zero real financial data charged.
                  </p>
                </div>
              </label>
            </div>

            {/* Order Review Box */}
            <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 space-y-2 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Shipping Destination:</span>
                <span className="font-medium text-stone-900">{profile.address}, {profile.city}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Items ({cart.length}):</span>
                <span className="tabular-nums font-medium text-stone-900">{formatPrice(subtotalUsd, activeCurrency)}</span>
              </div>
              {discountUsd > 0 && (
                <div className="flex justify-between text-emerald-800">
                  <span>Discount:</span>
                  <span className="tabular-nums font-medium">-{formatPrice(discountUsd, activeCurrency)}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-600">
                <span>Delivery:</span>
                <span className="tabular-nums font-medium text-stone-900">{shippingUsd === 0 ? 'FREE' : formatPrice(shippingUsd, activeCurrency)}</span>
              </div>
              <div className="pt-2 border-t border-stone-200 flex justify-between text-sm font-bold text-stone-900">
                <span>Total Due:</span>
                <span className="tabular-nums">{formatPrice(totalUsd, activeCurrency)}</span>
              </div>
            </div>

            <div className="pt-4 flex items-center justify-between border-t border-stone-200">
              <button
                type="button"
                onClick={() => setStep('shipping')}
                className="flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Shipping</span>
              </button>
              <button
                type="button"
                onClick={handlePlaceOrder}
                className="px-6 py-2.5 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 cursor-pointer shadow-sm"
              >
                Confirm & Place Order ({formatPrice(totalUsd, activeCurrency)})
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Confirmation & Receipt */}
        {step === 'confirmation' && completedOrder && (
          <div className="mt-6 text-center space-y-6">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <span className="text-xs uppercase tracking-widest text-emerald-800 font-semibold">
                Receipt # {completedOrder.trackingNumber}
              </span>
              <h3 className="font-serif text-3xl text-stone-900 mt-1">
                Thank you for your order, {completedOrder.customer.fullName}!
              </h3>
              <p className="text-xs text-stone-600 mt-2 max-w-md mx-auto">
                Your order is confirmed and has been stored in your device's local Order History. Our packaging team is preparing your artisanal essentials.
              </p>
            </div>

            {/* Printable Invoice Card */}
            <div id="printable-order-receipt" className="text-left bg-stone-50 border border-stone-200 rounded-xl p-5 space-y-4 text-xs">
              <div className="flex justify-between items-start border-b border-stone-200 pb-3">
                <div>
                  <h4 className="font-serif text-base font-bold text-stone-900">BAIT UL UKASHA</h4>
                  <p className="text-[11px] text-stone-500">Heirloom Home Essentials</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-stone-800">Date: {completedOrder.date}</p>
                  <p className="text-stone-500">Status: {completedOrder.status}</p>
                </div>
              </div>

              <div>
                <p className="font-semibold text-stone-800 mb-1">Delivering to:</p>
                <p className="text-stone-600">{completedOrder.customer.fullName}</p>
                <p className="text-stone-600">{completedOrder.customer.address}, {completedOrder.customer.city}, {completedOrder.customer.country}</p>
                <p className="text-stone-600">Contact: {completedOrder.customer.phone}</p>
                <p className="text-stone-600">Payment: {completedOrder.paymentMethod}</p>
              </div>

              <div className="border-t border-stone-200 pt-3">
                <p className="font-semibold text-stone-800 mb-2">Itemized Order:</p>
                <div className="space-y-1.5">
                  {completedOrder.items.map((item) => (
                    <div key={item.product.id} className="flex justify-between text-stone-700">
                      <span>{item.quantity}× {item.product.name}</span>
                      <span className="tabular-nums font-medium">
                        {formatPrice(item.product.priceUsd * item.quantity, activeCurrency)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-stone-200 pt-2 flex justify-between font-bold text-stone-900 text-sm">
                <span>Total Amount</span>
                <span className="tabular-nums">{formatPrice(completedOrder.total, activeCurrency)}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <button
                onClick={handlePrintReceipt}
                className="flex items-center gap-2 px-4 py-2 border border-stone-300 rounded-lg text-xs font-semibold text-stone-800 hover:bg-stone-50 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print or Save PDF Receipt</span>
              </button>
              <button
                onClick={onClose}
                className="px-6 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 cursor-pointer"
              >
                Back to Storefront
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
