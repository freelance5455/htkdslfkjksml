import React from 'react';
import { JobPosting } from '../types/job';
import { useTheme } from '../context/ThemeContext';
import {
  MapPin,
  Calendar,
  Award,
  IndianRupee,
  Users,
  ExternalLink,
  Bookmark,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Flame,
  FileCheck,
  Heart,
  Share2,
  Eye,
  Clock
} from 'lucide-react';

interface JobCardProps {
  job: JobPosting;
  isSaved: boolean;
  onToggleSave: (jobId: string) => void;
  onOpenDetail: (job: JobPosting) => void;
  onReportJob?: (job: JobPosting) => void;
  isLiked?: boolean;
  onToggleLike?: (jobId: string) => void;
  onShareJob?: (job: JobPosting) => void;
}

export const JobCard: React.FC<JobCardProps> = ({
  job,
  isSaved,
  onToggleSave,
  onOpenDetail,
  onReportJob,
  isLiked = false,
  onToggleLike,
  onShareJob
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  // Calculate days remaining
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const deadlineDate = job.closingDate || job.lastDate || job.expiryDate;
  const deadline = new Date(deadlineDate || '');
  const diffDays = Math.ceil((deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  const isExpired = job.status === 'EXPIRED' || (!isNaN(deadline.getTime()) && diffDays < 0);
  const isClosingSoon = !isExpired && !isNaN(deadline.getTime()) && diffDays >= 0 && diffDays <= 7;
  const isUrgent = job.isUrgent || isClosingSoon;

  return (
    <div
      id={`job-card-${job.id}`}
      className={`group relative rounded-2xl p-4 transition-all duration-200 border flex flex-col justify-between cursor-pointer active:scale-[0.99] select-none ${
        isDark
          ? 'bg-slate-900 hover:bg-slate-800/90 border-slate-800 hover:border-slate-700 text-slate-100 shadow-md shadow-black/25'
          : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-900 shadow-sm hover:shadow-md'
      }`}
      onClick={() => onOpenDetail(job)}
    >
      {/* Top Meta Row */}
      <div>
        <div className="flex items-start justify-between gap-2.5 mb-2.5">
          <div className="flex items-center gap-2 flex-wrap min-w-0">
            <div
              className={`w-8 h-8 rounded-xl border flex items-center justify-center text-base shrink-0 shadow-inner ${
                isDark
                  ? 'bg-slate-800 border-slate-700/60 text-white'
                  : 'bg-slate-100 border-slate-200 text-slate-900'
              }`}
            >
              {job.orgLogo || (job.sector === 'Government' ? '🏛️' : '💼')}
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              {/* Sector Tag */}
              <span
                className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded-md uppercase tracking-wider ${
                  job.sector === 'Government'
                    ? isDark
                      ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                      : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : isDark
                      ? 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
                      : 'bg-blue-50 text-blue-700 border border-blue-200'
                }`}
              >
                {job.sector}
              </span>

              {/* Status Badge */}
              {isExpired ? (
                <span
                  className={`flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-bold rounded border ${
                    isDark
                      ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                      : 'bg-rose-50 text-rose-700 border border-rose-200'
                  }`}
                >
                  <Clock className={`w-3 h-3 ${isDark ? 'text-rose-400' : 'text-rose-600'}`} />
                  EXPIRED
                </span>
              ) : isClosingSoon ? (
                <span
                  className={`flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-bold rounded border animate-pulse ${
                    isDark
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'bg-amber-50 text-amber-700 border border-amber-300'
                  }`}
                >
                  <Flame className={`w-3 h-3 ${isDark ? 'text-amber-400' : 'text-amber-600'}`} />
                  CLOSING SOON ({diffDays}d)
                </span>
              ) : job.status === 'VERIFIED' ? (
                <span
                  className={`flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-bold rounded border ${
                    isDark
                      ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                      : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                  }`}
                >
                  <ShieldCheck className={`w-3 h-3 ${isDark ? 'text-indigo-400' : 'text-indigo-600'}`} />
                  VERIFIED
                </span>
              ) : (
                <span
                  className={`flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-bold rounded border ${
                    isDark
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  }`}
                >
                  <FileCheck className={`w-3 h-3 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`} />
                  OFFICIAL
                </span>
              )}

              {job.isFeatured && (
                <span
                  className={`flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-bold rounded border ${
                    isDark
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                  }`}
                >
                  <Sparkles className={`w-3 h-3 ${isDark ? 'text-amber-400' : 'text-amber-600'}`} />
                  FEATURED
                </span>
              )}
            </div>
          </div>

          {/* Right Action Icons: Report & Bookmark */}
          <div className="flex items-center gap-1 shrink-0">
            {onReportJob && (
              <button
                id={`btn-report-${job.id}`}
                onClick={(e) => {
                  e.stopPropagation();
                  onReportJob(job);
                }}
                className={`p-1.5 rounded-full transition-colors ${
                  isDark
                    ? 'text-slate-400 hover:text-rose-400 hover:bg-slate-800'
                    : 'text-slate-400 hover:text-rose-600 hover:bg-slate-100'
                }`}
                title="Report Inaccuracy or Fake Job"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
              </button>
            )}

            <button
              id={`btn-bookmark-${job.id}`}
              onClick={(e) => {
                e.stopPropagation();
                onToggleSave(job.id);
              }}
              className={`p-1.5 rounded-full transition-colors ${
                isSaved
                  ? isDark
                    ? 'text-amber-400 bg-amber-400/15 ring-1 ring-amber-400/30'
                    : 'text-amber-600 bg-amber-50 ring-1 ring-amber-200'
                  : isDark
                    ? 'text-slate-400 hover:text-white hover:bg-slate-800'
                    : 'text-slate-400 hover:text-slate-800 hover:bg-slate-100'
              }`}
              title={isSaved ? 'Remove Bookmark' : 'Bookmark Job'}
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
            </button>
          </div>
        </div>

        {/* Job Title & Organization */}
        <h2
          className={`text-sm sm:text-base font-bold transition-colors leading-snug line-clamp-2 ${
            isDark
              ? 'text-white group-hover:text-indigo-300'
              : 'text-slate-900 group-hover:text-indigo-600'
          }`}
        >
          {job.title}
        </h2>
        <p
          className={`text-xs font-medium mt-1 line-clamp-1 ${
            isDark ? 'text-slate-300' : 'text-slate-600'
          }`}
        >
          {job.organization}
        </p>

        {/* Location Row */}
        <div
          className={`flex items-center gap-1.5 text-xs mt-2 ${
            isDark ? 'text-slate-400' : 'text-slate-500'
          }`}
        >
          <MapPin className={`w-3.5 h-3.5 shrink-0 ${isDark ? 'text-indigo-400' : 'text-indigo-600'}`} />
          <span className="truncate">
            {job.district}, <span className={`font-medium ${isDark ? 'text-slate-200' : 'text-slate-700'}`}>{job.state}</span>
          </span>
        </div>

        {/* Qualification Row */}
        <div
          className={`flex items-start gap-1.5 text-xs mt-1.5 ${
            isDark ? 'text-slate-400' : 'text-slate-500'
          }`}
        >
          <Award className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${isDark ? 'text-amber-400' : 'text-amber-500'}`} />
          <span className={`line-clamp-1 font-normal ${isDark ? 'text-slate-200' : 'text-slate-700'}`}>
            {job.qualification}
          </span>
        </div>
      </div>

      {/* Highlights Grid (Salary & Vacancies) */}
      <div
        className={`mt-3 pt-3 border-t grid grid-cols-2 gap-2 text-xs ${
          isDark ? 'border-slate-800/80' : 'border-slate-200'
        }`}
      >
        <div
          className={`p-2 rounded-xl border ${
            isDark
              ? 'bg-slate-800/60 border-slate-700/50'
              : 'bg-slate-50 border-slate-200'
          }`}
        >
          <div
            className={`flex items-center gap-1 text-[11px] ${
              isDark ? 'text-slate-400' : 'text-slate-500'
            }`}
          >
            <IndianRupee className={`w-3 h-3 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`} />
            <span>Salary / Scale</span>
          </div>
          <p
            className={`font-semibold text-xs mt-0.5 truncate ${
              isDark ? 'text-slate-100' : 'text-slate-800'
            }`}
            title={job.salary}
          >
            {job.salary}
          </p>
        </div>

        <div
          className={`p-2 rounded-xl border ${
            isDark
              ? 'bg-slate-800/60 border-slate-700/50'
              : 'bg-slate-50 border-slate-200'
          }`}
        >
          <div
            className={`flex items-center gap-1 text-[11px] ${
              isDark ? 'text-slate-400' : 'text-slate-500'
            }`}
          >
            <Users className={`w-3 h-3 ${isDark ? 'text-indigo-400' : 'text-indigo-600'}`} />
            <span>Total Posts</span>
          </div>
          <p
            className={`font-bold text-xs mt-0.5 ${
              isDark ? 'text-slate-100' : 'text-slate-900'
            }`}
          >
            {job.vacancies.toLocaleString('en-IN')} Vacancies
          </p>
        </div>
      </div>

      {/* Deadline Row */}
      <div className="mt-3 flex items-center justify-between gap-2 text-xs">
        <div
          className={`flex items-center gap-1 ${
            isDark ? 'text-slate-400' : 'text-slate-500'
          }`}
        >
          <Calendar className={`w-3.5 h-3.5 ${isDark ? 'text-rose-400' : 'text-rose-500'}`} />
          <span className="text-[11px]">Last Date:</span>
          <span
            className={`font-semibold ${
              isUrgent
                ? isDark
                  ? 'text-amber-400'
                  : 'text-amber-600'
                : isDark
                  ? 'text-slate-200'
                  : 'text-slate-800'
            }`}
          >
            {deadlineDate}
          </span>
        </div>

        {isExpired ? (
          <span
            className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md border ${
              isDark
                ? 'bg-rose-950/80 text-rose-300 border-rose-800/60'
                : 'bg-rose-50 text-rose-700 border-rose-200'
            }`}
          >
            EXPIRED
          </span>
        ) : isClosingSoon ? (
          <span
            className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md border ${
              isDark
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                : 'bg-rose-50 text-rose-700 border-rose-300'
            }`}
          >
            {diffDays}d left
          </span>
        ) : null}
      </div>

      {/* Engagement bar (Likes, Saves, Shares, Views, Apply) */}
      <div
        className={`mt-2.5 pt-2 border-t flex items-center justify-between text-[11px] ${
          isDark
            ? 'border-slate-800/70 text-slate-400'
            : 'border-slate-200 text-slate-500'
        }`}
      >
        <div className="flex items-center gap-3">
          {/* Like button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              if (onToggleLike) onToggleLike(job.id);
            }}
            className={`flex items-center gap-1 transition-colors ${
              isLiked
                ? 'text-rose-500 font-bold'
                : isDark
                  ? 'text-slate-400 hover:text-rose-400'
                  : 'text-slate-500 hover:text-rose-600'
            }`}
            title="Like this job"
          >
            <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-current' : ''}`} />
            <span>{job.likesCount || 0}</span>
          </button>

          {/* Bookmark / Save count */}
          <span
            className="flex items-center gap-1"
            title="Total saves"
          >
            <Bookmark
              className={`w-3.5 h-3.5 ${
                isSaved
                  ? isDark
                    ? 'text-amber-400 fill-current'
                    : 'text-amber-600 fill-current'
                  : isDark
                    ? 'text-slate-400'
                    : 'text-slate-500'
              }`}
            />
            <span>{job.savesCount || 0}</span>
          </span>

          {/* Share button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              if (onShareJob) onShareJob(job);
            }}
            className={`flex items-center gap-1 transition-colors ${
              isDark
                ? 'text-slate-400 hover:text-indigo-300'
                : 'text-slate-500 hover:text-indigo-600'
            }`}
            title="Share via WhatsApp, Telegram, Facebook, or Copy Link"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{job.sharesCount || 0}</span>
          </button>

          {/* Views count */}
          {job.viewsCount !== undefined && job.viewsCount > 0 && (
            <span
              className={`hidden sm:flex items-center gap-1 ${
                isDark ? 'text-slate-500' : 'text-slate-400'
              }`}
              title="Views"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{job.viewsCount}</span>
            </span>
          )}
        </div>

        {/* Apply Link */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            window.open(job.officialApplicationLink, '_blank', 'noopener,noreferrer');
          }}
          className={`flex items-center gap-1 font-semibold shrink-0 group-hover:underline ${
            isDark
              ? 'text-indigo-400 hover:text-indigo-300'
              : 'text-indigo-600 hover:text-indigo-700'
          }`}
        >
          <span>Apply</span>
          <ExternalLink className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
