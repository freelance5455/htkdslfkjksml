import { Award, Download, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { BAND_META } from '../data/constants';
import type { CefrBand } from '../types';

interface CertificateModalProps {
  open: boolean;
  band: CefrBand;
  defaultStudentName: string;
  masteredWordsCount: number;
  reasonAr: string;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export function CertificateModal({
  open,
  band,
  defaultStudentName,
  masteredWordsCount,
  reasonAr,
  onClose,
  onToast,
}: CertificateModalProps) {
  const [studentName, setStudentName] = useState(defaultStudentName || 'TMN Learner');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (defaultStudentName) setStudentName(defaultStudentName);
  }, [defaultStudentName]);

  useEffect(() => {
    if (!open || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = 1600;
    const H = 1130;
    canvas.width = W;
    canvas.height = H;

    // Deep luxury obsidian-navy background
    const bgGrad = ctx.createLinearGradient(0, 0, W, H);
    bgGrad.addColorStop(0, '#090e1a');
    bgGrad.addColorStop(0.55, '#111b33');
    bgGrad.addColorStop(1, '#0c1326');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    // Subtle radial top glow
    const glow = ctx.createRadialGradient(W / 2, 160, 40, W / 2, 220, 680);
    glow.addColorStop(0, 'rgba(99, 102, 241, 0.24)');
    glow.addColorStop(1, 'rgba(99, 102, 241, 0)');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, W, H);

    // Outer & inner precision borders
    ctx.strokeStyle = 'rgba(212, 175, 55, 0.72)';
    ctx.lineWidth = 4;
    ctx.strokeRect(48, 48, W - 96, H - 96);

    ctx.strokeStyle = 'rgba(148, 163, 184, 0.28)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(68, 68, W - 136, H - 136);

    // Top Brand Monogram
    ctx.fillStyle = '#e0e7ff';
    ctx.font = '800 38px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('TMN · ENGLISH MASTERY PLATFORM', W / 2, 155);

    ctx.fillStyle = '#d4af37';
    ctx.font = '700 26px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText('CERTIFICATE OF ACHIEVEMENT', W / 2, 210);

    // Decorative gold divider
    ctx.strokeStyle = 'rgba(212, 175, 55, 0.6)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(W / 2 - 220, 245);
    ctx.lineTo(W / 2 + 220, 245);
    ctx.stroke();

    // Subtitle
    ctx.fillStyle = '#94a3b8';
    ctx.font = '500 28px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText('This certificate is proudly presented to', W / 2, 330);

    // Student Name
    ctx.fillStyle = '#ffffff';
    ctx.font = '800 72px "Cairo", "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText((studentName.trim() || 'TMN Learner').slice(0, 40), W / 2, 435);

    // Achievement statement
    const meta = BAND_META[band];
    const bandEnLabels: Record<CefrBand, string> = {
      A0: 'Pre-Beginner',
      A1: 'Beginner',
      A2: 'Elementary',
      B1: 'Intermediate',
      B2: 'Upper-Intermediate',
      C1: 'Advanced',
      C2: 'Proficiency',
    };
    ctx.fillStyle = '#cbd5e1';
    ctx.font = '500 30px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText(
      `for achieving CEFR Level ${band} (${bandEnLabels[band]}) English proficiency`,
      W / 2,
      525
    );

    // Highlight Badge Box
    ctx.fillStyle = 'rgba(99, 102, 241, 0.16)';
    ctx.strokeStyle = 'rgba(129, 140, 248, 0.55)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(W / 2 - 230, 585, 460, 145, 24);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#a5b4fc';
    ctx.font = '800 66px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText(`CEFR ${band}`, W / 2, 665);

    ctx.fillStyle = '#e2e8f0';
    ctx.font = '600 24px "Cairo", "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText(
      `${masteredWordsCount.toLocaleString('en-US')} Mastered Words · ${meta.ar}`,
      W / 2,
      708
    );

    // Footer Columns: Date & Platform Signature
    const dateStr = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    ctx.fillStyle = '#94a3b8';
    ctx.font = '600 22px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('DATE ISSUED', 160, 915);
    ctx.fillStyle = '#f8fafc';
    ctx.font = '700 28px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText(dateStr, 160, 960);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#94a3b8';
    ctx.font = '600 22px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText('VERIFIED BY', W - 160, 915);
    ctx.fillStyle = '#d4af37';
    ctx.font = '800 30px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText('TMN Learning Academy', W - 160, 960);

    // Bottom Arabic tagline
    ctx.textAlign = 'center';
    ctx.fillStyle = '#64748b';
    ctx.font = '600 22px "Cairo", system-ui, sans-serif';
    ctx.fillText(reasonAr, W / 2, 1045);
  }, [open, band, studentName, masteredWordsCount, reasonAr]);

  if (!open) return null;

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `TMN-Certificate-${band}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    onToast(`تم تنزيل شهادة مستوى ${band} بنجاح`);
  };

  return (
    <div
      data-testid="certificate-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="شهادة الإنجاز"
    >
      <div className="tmn-card flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl">
        <div className="flex items-center justify-between border-b border-slate-200/80 px-5 py-4 dark:border-slate-800 sm:px-6">
          <div className="flex items-center gap-2.5">
            <Award className="h-5 w-5 text-amber-500" />
            <div>
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
                شهادة إنجاز CEFR {band}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">{reasonAr}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-5 sm:p-6">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <label
              htmlFor="cert-student-name"
              className="shrink-0 text-xs font-bold text-slate-600 dark:text-slate-300"
            >
              الاسم على الشهادة:
            </label>
            <input
              id="cert-student-name"
              type="text"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
              placeholder="اكتب اسمك الكامل..."
              className="h-10 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm font-bold text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200/80 bg-slate-950 dark:border-slate-800">
            <canvas
              ref={canvasRef}
              data-testid="certificate-canvas"
              className="h-auto w-full block"
            />
          </div>
        </div>

        <div className="flex items-center justify-end gap-2.5 border-t border-slate-200/80 px-5 py-3.5 dark:border-slate-800 sm:px-6">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
          >
            إغلاق
          </button>
          <button
            type="button"
            data-testid="certificate-download-btn"
            onClick={handleDownload}
            className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow-sm hover:bg-indigo-700"
          >
            <Download className="h-4 w-4" />
            <span>تنزيل الشهادة (PNG)</span>
          </button>
        </div>
      </div>
    </div>
  );
}
