import React, { useRef, useEffect, useState } from 'react';
import { X, Download, Share2, ShieldCheck, Check, Sparkles, Award } from 'lucide-react';
import confetti from 'canvas-confetti';
import { InfluencerCertificate } from '../types';
import { getCertificateById } from '../services/db';

interface CertificateModalProps {
  certificateId: string;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({
  certificateId,
  onClose,
}) => {
  const [cert, setCert] = useState<InfluencerCertificate | null>(null);
  const [downloading, setDownloading] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const certRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    async function loadCert() {
      const found = await getCertificateById(certificateId);
      if (found) {
        setCert(found);
      } else {
        setCert({
          id: certificateId,
          userId: 'user-joaovibes',
          username: 'joaovibes',
          userDisplayName: 'João Vibes',
          followerCountAtIssuance: 10,
          issuedAt: new Date().toISOString(),
          verificationCode: 'CS-INFL-88294-BR',
          title: 'CERTIFICADO DE INFLUENCIADOR CLIPSHARE',
          description:
            'Parabéns! Você conquistou seus primeiros 10 seguidores e deu um passo importante na sua jornada como criador no ClipShare.',
        });
      }
      // Fire festive celebration confetti!
      confetti({
        particleCount: 90,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FF4038', '#FF008C', '#9900FF', '#FFD700'],
      });
    }
    loadCert();
  }, [certificateId]);

  const handleDownloadPNG = () => {
    setDownloading(true);
    // Draw directly to an HTML5 canvas for crisp high-resolution PNG export
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 800;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    ctx.fillStyle = '#050505';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Elegant Outer Border Gradient
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, '#FF4038');
    grad.addColorStop(0.5, '#FF008C');
    grad.addColorStop(1, '#9900FF');

    ctx.strokeStyle = grad;
    ctx.lineWidth = 14;
    ctx.strokeRect(30, 30, canvas.width - 60, canvas.height - 60);

    // Inner gold hairline border
    ctx.strokeStyle = 'rgba(212, 175, 55, 0.4)';
    ctx.lineWidth = 2;
    ctx.strokeRect(50, 50, canvas.width - 100, canvas.height - 100);

    // Watermark circle
    ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height / 2, 280, 0, Math.PI * 2);
    ctx.fill();

    // Title: CERTIFICADO DE INFLUENCIADOR CLIPSHARE
    ctx.textAlign = 'center';
    ctx.fillStyle = '#FFD700';
    ctx.font = 'bold 22px system-ui, sans-serif';
    ctx.letterSpacing = '4px';
    ctx.fillText('• CONQUISTA OFICIAL DE CRIADOR •', canvas.width / 2, 130);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = '900 44px system-ui, sans-serif';
    ctx.letterSpacing = '2px';
    ctx.fillText('CERTIFICADO DE INFLUENCIADOR', canvas.width / 2, 190);

    ctx.fillStyle = '#FF008C';
    ctx.font = '800 32px system-ui, sans-serif';
    ctx.fillText('CLIPSHARE', canvas.width / 2, 235);

    // Divider line
    ctx.strokeStyle = grad;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(350, 260);
    ctx.lineTo(850, 260);
    ctx.stroke();

    // Recipient Info
    ctx.fillStyle = '#A1A1AA';
    ctx.font = '20px system-ui, sans-serif';
    ctx.fillText('Este certificado é outorgado solenemente a:', canvas.width / 2, 310);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 50px system-ui, sans-serif';
    ctx.fillText(cert?.userDisplayName || 'João Vibes', canvas.width / 2, 375);

    ctx.fillStyle = '#FF008C';
    ctx.font = 'bold 26px system-ui, sans-serif';
    ctx.fillText(`@${cert?.username || 'joaovibes'}`, canvas.width / 2, 415);

    // Description text
    ctx.fillStyle = '#E4E4E7';
    ctx.font = '22px system-ui, sans-serif';
    ctx.fillText(
      'Parabéns! Você conquistou seus primeiros 10 seguidores e deu um',
      canvas.width / 2,
      480
    );
    ctx.fillText(
      'passo importante na sua jornada como criador no ClipShare.',
      canvas.width / 2,
      515
    );

    // Verification Code & Authentic Seal
    ctx.fillStyle = 'rgba(212, 175, 55, 0.9)';
    ctx.font = 'bold 18px monospace';
    ctx.fillText(`CÓDIGO DE AUTENTICIDADE: ${cert?.verificationCode || 'CS-INFL-88294-BR'}`, canvas.width / 2, 600);

    ctx.fillStyle = '#A1A1AA';
    ctx.font = '16px system-ui, sans-serif';
    ctx.fillText(`Emissão: ${new Date(cert?.issuedAt || Date.now()).toLocaleDateString('pt-BR')}`, canvas.width / 2, 630);

    // Download link trigger
    const link = document.createElement('a');
    link.download = `Certificado-Influenciador-ClipShare-${cert?.username || 'criador'}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    setDownloading(false);
  };

  const handleCopyCode = () => {
    if (cert?.verificationCode) {
      navigator.clipboard.writeText(cert.verificationCode);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Certificado de Influenciador ClipShare',
          text: `Conquistei o Certificado Oficial de Influenciador no ClipShare! Código de verificação: ${cert?.verificationCode}`,
          url: window.location.href,
        });
      } catch {
        handleCopyCode();
      }
    } else {
      handleCopyCode();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-fade-in select-none">
      <div className="w-full max-w-xl bg-[#050505] border border-[#272730] rounded-3xl p-6 md:p-8 shadow-2xl relative text-center">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-full text-[#A1A1AA] hover:text-white hover:bg-[#19191F] transition-colors"
        >
          <X size={20} />
        </button>

        {/* Certificate Card Container */}
        <div
          ref={certRef}
          className="relative rounded-2xl p-6 md:p-8 bg-[#0a0a0f] border-2 border-transparent relative overflow-hidden shadow-2xl"
          style={{
            borderImage: 'linear-gradient(110deg, #FF4038 0%, #FF008C 50%, #9900FF 100%) 1',
          }}
        >
          {/* Gold subtle hairline inner border */}
          <div className="absolute inset-2 border border-amber-500/30 rounded-xl pointer-events-none" />

          {/* Header & Logo */}
          <div className="flex items-center justify-center gap-2 mb-2">
            <img src="/clipshare-bubble.svg" alt="ClipShare" className="w-7 h-7 invert" />
            <span className="text-xs font-black tracking-widest text-amber-400 uppercase">
              Certificação Oficial de Criador
            </span>
          </div>

          <h2 className="text-xl md:text-2xl font-black text-white tracking-wide">
            CERTIFICADO DE INFLUENCIADOR
          </h2>
          <span className="text-sm font-extrabold text-clipshare-gradient block mt-0.5">
            CLIPSHARE
          </span>

          <div className="w-24 h-0.5 bg-clipshare-gradient mx-auto my-4 rounded-full" />

          <p className="text-xs text-[#A1A1AA] mb-2">
            Este certificado é concedido a:
          </p>

          <h3 className="text-2xl md:text-3xl font-extrabold text-white">
            {cert?.userDisplayName || 'João Vibes'}
          </h3>
          <p className="text-xs font-bold text-[#FF008C] mt-0.5">
            @{cert?.username || 'joaovibes'}
          </p>

          <p className="text-xs text-white/90 leading-relaxed mt-4 max-w-md mx-auto">
            {cert?.description ||
              'Parabéns! Você conquistou seus primeiros 10 seguidores e deu um passo importante na sua jornada como criador no ClipShare.'}
          </p>

          {/* Golden Seal & Verification Tag */}
          <div className="mt-6 pt-4 border-t border-[#19191F] flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-xs text-amber-300 font-mono font-bold bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/30 mb-1">
              <ShieldCheck size={14} className="text-amber-400" />
              <span>{cert?.verificationCode || 'CS-INFL-88294-BR'}</span>
            </div>
            <span className="text-[10px] text-[#A1A1AA]">
              Autenticado pelo servidor ClipShare em{' '}
              {new Date(cert?.issuedAt || Date.now()).toLocaleDateString('pt-BR')}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 mt-6">
          <button
            onClick={handleDownloadPNG}
            disabled={downloading}
            className="w-full sm:flex-1 py-3 px-4 rounded-full bg-clipshare-gradient glow-clipshare-sm text-white font-bold text-xs flex items-center justify-center gap-2 hover:opacity-95 active:scale-95 transition-all cursor-pointer shadow-lg"
          >
            <Download size={16} />
            <span>{downloading ? 'Gerando...' : 'Baixar Certificado (PNG)'}</span>
          </button>

          <button
            onClick={handleCopyCode}
            className="w-full sm:w-auto py-3 px-5 rounded-full bg-[#19191F] border border-[#272730] text-white font-semibold text-xs flex items-center justify-center gap-2 hover:bg-[#22222b] active:scale-95 transition-all cursor-pointer"
          >
            {copiedCode ? <Check size={16} className="text-[#20E060]" /> : <ShieldCheck size={16} />}
            <span>{copiedCode ? 'Código copiado!' : 'Copiar Código'}</span>
          </button>

          <button
            onClick={handleShare}
            className="w-full sm:w-auto p-3 rounded-full bg-[#19191F] border border-[#272730] text-white hover:bg-[#22222b] transition-colors cursor-pointer"
            title="Compartilhar"
          >
            <Share2 size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};
