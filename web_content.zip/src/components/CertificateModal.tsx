import React from 'react';
import { X, Award, Printer, Download, Sparkles, Heart } from 'lucide-react';

interface CertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  childName: string;
  starsCount: number;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({
  isOpen,
  onClose,
  childName,
  starsCount,
}) => {
  if (!isOpen) return null;

  const trophyImage = '/src/assets/images/kid_trophy_star_1790357488422.jpg';
  const currentDate = new Date().toLocaleDateString('ur-PK', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden border-4 border-amber-300 flex flex-col">
        {/* Top bar (hidden in print) */}
        <div className="bg-amber-500 p-3 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-200" />
            <span className="font-urdu font-bold text-sm">
              شہزادہ {childName} کی شاندار سندِ اعزاز (Certificate of Excellence)
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Certificate Body (printable) */}
        <div className="p-6 sm:p-10 bg-amber-50/40 relative">
          <div className="border-8 border-double border-amber-400 p-6 sm:p-8 rounded-2xl bg-white text-center shadow-lg relative overflow-hidden">
            {/* Corner Decorative Ornaments */}
            <div className="absolute top-2 left-2 text-2xl text-amber-400">✨</div>
            <div className="absolute top-2 right-2 text-2xl text-amber-400">✨</div>
            <div className="absolute bottom-2 left-2 text-2xl text-amber-400">✨</div>
            <div className="absolute bottom-2 right-2 text-2xl text-amber-400">✨</div>

            {/* Trophy Image */}
            <div className="w-24 h-24 mx-auto mb-3 rounded-full overflow-hidden border-4 border-amber-300 shadow-md">
              <img
                src={trophyImage}
                alt="Superstar Trophy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="inline-block px-4 py-1 bg-amber-100 text-amber-900 rounded-full font-bold text-xs uppercase tracking-widest mb-2">
              Certificate of Excellence 🌟
            </div>

            <h2 className="font-urdu text-3xl sm:text-4xl font-black text-amber-950 mb-1">
              سندِ اعزاز و کامیابی
            </h2>

            <p className="text-xs text-amber-800 font-sans mb-4">
              Presented with immense pride and love to:
            </p>

            <div className="my-4 py-2 border-b-2 border-amber-300 max-w-sm mx-auto">
              <h1 className="font-urdu text-4xl sm:text-5xl font-black text-rose-600 tracking-wide">
                پیارے {childName} صاحب 👑
              </h1>
              <p className="font-fun text-lg font-extrabold text-slate-700 mt-1">
                Master {childName}
              </p>
            </div>

            <p className="font-urdu text-base sm:text-lg text-slate-800 leading-relaxed max-w-md mx-auto my-3 font-semibold">
              یہ سند پیارے {childName} کو اردو حروفِ تہجی (الف بے تے)، انگلش (ABC)، اور ریاضی گنتی (123) میں شاندار محنت، ذہانت اور لگن پر دی جاتی ہے۔
            </p>

            <div className="inline-flex items-center gap-2 bg-yellow-100 text-yellow-950 px-4 py-1.5 rounded-full font-bold text-xs my-2">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span>حاصل کردہ ستارے: {starsCount} سٹارز ⭐⭐⭐</span>
            </div>

            {/* Signatures */}
            <div className="mt-6 pt-4 border-t border-amber-200 grid grid-cols-2 gap-4 text-xs font-bold text-slate-600">
              <div className="text-center">
                <div className="font-urdu text-amber-900 text-sm font-black">
                  استاد میاں بھالو 🧸
                </div>
                <div className="text-[11px] text-slate-500">اے آئی ہیڈ ٹیچر</div>
              </div>

              <div className="text-center">
                <div className="font-urdu text-rose-700 text-sm font-black flex items-center justify-center gap-1">
                  <span>پیارے والدین</span>
                  <Heart className="w-3.5 h-3.5 fill-rose-600 text-rose-600" />
                </div>
                <div className="text-[11px] text-slate-500">{currentDate}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer (hidden in print) */}
        <div className="p-4 bg-slate-50 border-t border-amber-200 flex items-center justify-between print:hidden">
          <button
            onClick={onClose}
            className="px-4 py-2 text-slate-600 hover:text-slate-800 text-xs font-bold cursor-pointer"
          >
            بند کریں (Close)
          </button>

          <button
            onClick={handlePrint}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-md flex items-center gap-2 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>پرنٹ یا محفوظ کریں (Print / Save PDF)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
