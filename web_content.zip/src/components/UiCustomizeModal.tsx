import React from "react";
import { UiCustomizationSettings } from "../types";
import {
  X,
  Sliders,
  Check,
  Smartphone,
  Monitor,
  Eye,
  Zap,
  ArrowBigUp,
  Sparkles,
  Maximize2,
} from "lucide-react";

interface UiCustomizeModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UiCustomizationSettings;
  isLandscape?: boolean;
  onUpdateSettings: (
    updater: (prev: UiCustomizationSettings) => UiCustomizationSettings
  ) => void;
}

export const UiCustomizeModal: React.FC<UiCustomizeModalProps> = ({
  isOpen,
  onClose,
  settings,
  isLandscape = false,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  // Ultra-Slim Landscape Preset: Tiny UI so 95% of screen is open view!
  const setUltraSmallLandscapePreset = () => {
    onUpdateSettings(() => ({
      hudScale: "ultra_compact",
      hotbarScale: "compact",
      controllerSize: "extra_small",
      controllerOpacity: 0.7,
      showDpad: true,
      autoLandscapeSmall: true,
      showHandButton: true,
      showSprintButton: true,
      showJumpButton: true,
      isMinimalMode: false,
    }));
  };

  // Minimal Clean Mode Preset (Pure cinematic 60FPS landscape view)
  const setMinimalPreset = () => {
    onUpdateSettings(() => ({
      hudScale: "ultra_compact",
      hotbarScale: "compact",
      controllerSize: "extra_small",
      controllerOpacity: 0.65,
      showDpad: true,
      autoLandscapeSmall: true,
      showHandButton: true,
      showSprintButton: true,
      showJumpButton: true,
      isMinimalMode: true,
    }));
  };

  // Balanced Landscape Preset
  const setBalancedLandscapePreset = () => {
    onUpdateSettings(() => ({
      hudScale: "compact",
      hotbarScale: "compact",
      controllerSize: "small",
      controllerOpacity: 0.85,
      showDpad: true,
      autoLandscapeSmall: true,
      showHandButton: true,
      showSprintButton: true,
      showJumpButton: true,
      isMinimalMode: false,
    }));
  };

  // Standard Preset
  const setStandardPreset = () => {
    onUpdateSettings(() => ({
      hudScale: "normal",
      hotbarScale: "normal",
      controllerSize: "medium",
      controllerOpacity: 0.9,
      showDpad: true,
      autoLandscapeSmall: false,
      showHandButton: true,
      showSprintButton: true,
      showJumpButton: true,
      isMinimalMode: false,
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 select-none">
      <div className="relative w-full max-w-lg bg-stone-900 border-2 border-amber-500/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-950 via-amber-950/70 to-stone-950 p-3 border-b border-amber-600/40 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-amber-600/30 text-amber-300 rounded-lg border border-amber-500/40 shadow-inner">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-amber-200 font-['Hind_Siliguri']">
                  📐 ল্যান্ডস্কেপ মোড UI ও কন্ট্রোলার কাস্টমাইজ
                </h2>
                {isLandscape && (
                  <span className="text-[9px] bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-600 font-bold">
                    ল্যান্ডস্কেপ সক্রিয়
                  </span>
                )}
              </div>
              <p className="text-[10px] text-stone-400">
                Landscape Mode UI Scaler: Compact HUD, small controls, hand & sprint buttons
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg bg-stone-800 text-stone-400 hover:text-white cursor-pointer transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="p-3.5 overflow-y-auto space-y-3.5 text-xs text-stone-200 font-['Hind_Siliguri'] flex-1">
          {/* Quick 1-Click Presets */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider block">
              ⚡ এক-ক্লিক ল্যান্ডস্কেপ প্রিসেট (Landscape Presets):
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                onClick={setMinimalPreset}
                className={`p-2 rounded-xl border text-center font-bold cursor-pointer transition transform active:scale-95 flex flex-col items-center justify-center gap-1 ${
                  settings.isMinimalMode
                    ? "bg-amber-600/40 border-amber-400 text-amber-200 shadow-lg shadow-amber-600/20"
                    : "bg-stone-800 border-stone-700 text-stone-300 hover:bg-stone-750"
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span className="text-[11px]">মিনিমাল মোড</span>
                <span className="text-[8px] text-stone-400">সিনেমাটিক ভিউ</span>
              </button>

              <button
                onClick={setUltraSmallLandscapePreset}
                className={`p-2 rounded-xl border text-center font-bold cursor-pointer transition transform active:scale-95 flex flex-col items-center justify-center gap-1 ${
                  !settings.isMinimalMode &&
                  settings.hudScale === "ultra_compact" &&
                  settings.controllerSize === "extra_small"
                    ? "bg-amber-600/40 border-amber-400 text-amber-200 shadow-lg shadow-amber-600/20"
                    : "bg-stone-800 border-stone-700 text-stone-300 hover:bg-stone-750"
                }`}
              >
                <Smartphone className="w-4 h-4 text-amber-300" />
                <span className="text-[11px]">আল্ট্রা স্লিম</span>
                <span className="text-[8px] text-stone-400">সর্বোচ্চ ভিউ</span>
              </button>

              <button
                onClick={setBalancedLandscapePreset}
                className={`p-2 rounded-xl border text-center font-bold cursor-pointer transition transform active:scale-95 flex flex-col items-center justify-center gap-1 ${
                  !settings.isMinimalMode &&
                  settings.hudScale === "compact" &&
                  settings.controllerSize === "small"
                    ? "bg-amber-600/40 border-amber-400 text-amber-200 shadow-lg shadow-amber-600/20"
                    : "bg-stone-800 border-stone-700 text-stone-300 hover:bg-stone-750"
                }`}
              >
                <Maximize2 className="w-4 h-4 text-emerald-300" />
                <span className="text-[11px]">ব্যালেন্সড</span>
                <span className="text-[8px] text-stone-400">মাঝারি ছোট</span>
              </button>

              <button
                onClick={setStandardPreset}
                className={`p-2 rounded-xl border text-center font-bold cursor-pointer transition transform active:scale-95 flex flex-col items-center justify-center gap-1 ${
                  !settings.isMinimalMode &&
                  settings.hudScale === "normal" &&
                  settings.controllerSize === "medium"
                    ? "bg-amber-600/40 border-amber-400 text-amber-200 shadow-lg shadow-amber-600/20"
                    : "bg-stone-800 border-stone-700 text-stone-300 hover:bg-stone-750"
                }`}
              >
                <Monitor className="w-4 h-4 text-sky-300" />
                <span className="text-[11px]">স্ট্যান্ডার্ড</span>
                <span className="text-[8px] text-stone-400">স্বাভাবিক সাইজ</span>
              </button>
            </div>
          </div>

          {/* Minimal Mode Toggle Switch */}
          <div className="flex items-center justify-between p-2.5 bg-stone-950/90 rounded-xl border border-stone-800">
            <div>
              <span className="font-bold text-amber-300 text-xs block">
                ✨ মিনিমালিস্ট মোড (Minimal Clean UI Mode) [M]
              </span>
              <span className="text-[10px] text-stone-400">
                অপ্রয়োজনীয় বোতাম ও প্যানেল লুকিয়ে কেবল প্রয়োজনীয় তথ্যসহ সিনেমাটিক 60 FPS দৃশ্য প্রদর্শন
              </span>
            </div>
            <button
              onClick={() =>
                onUpdateSettings((s) => ({
                  ...s,
                  isMinimalMode: !s.isMinimalMode,
                }))
              }
              className={`w-11 h-6 rounded-full transition-colors p-0.5 cursor-pointer ${
                settings.isMinimalMode ? "bg-amber-500" : "bg-stone-700"
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.isMinimalMode ? "translate-x-5" : "translate-x-0"
                }`}
              />
            </button>
          </div>

          {/* Auto Landscape Shrink Switch */}
          <div className="flex items-center justify-between p-2.5 bg-stone-950/90 rounded-xl border border-stone-800">
            <div>
              <span className="font-bold text-amber-300 text-xs block">
                📐 ল্যান্ডস্কেপে স্বয়ংক্রিয়ভাবে UI ছোট করুন
              </span>
              <span className="text-[10px] text-stone-400">
                স্ক্রিন ল্যান্ডস্কেপ মোডে গেলে HUD, হটবার ও বাটনগুলো নিজে থেকেই ছোট হয়ে যাবে
              </span>
            </div>
            <button
              onClick={() =>
                onUpdateSettings((s) => ({
                  ...s,
                  autoLandscapeSmall: !s.autoLandscapeSmall,
                }))
              }
              className={`w-11 h-6 rounded-full transition-colors p-0.5 cursor-pointer ${
                settings.autoLandscapeSmall ? "bg-emerald-600" : "bg-stone-700"
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.autoLandscapeSmall ? "translate-x-5" : "translate-x-0"
                }`}
              />
            </button>
          </div>

          {/* 1. HUD Size in Landscape */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-stone-300 uppercase tracking-wider block">
              উপরের HUD বার আকার (Top HUD Scale):
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: "ultra_compact", label: "আল্ট্রা স্লিম", desc: "খুব ছোট" },
                { id: "compact", label: "কমপ্যাক্ট", desc: "ল্যান্ডস্কেপ সাইজ" },
                { id: "normal", label: "স্বাভাবিক", desc: "সম্পূর্ণ টেক্সট" },
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() =>
                    onUpdateSettings((s) => ({
                      ...s,
                      hudScale: opt.id as any,
                    }))
                  }
                  className={`p-2 rounded-xl border text-center font-bold cursor-pointer transition ${
                    settings.hudScale === opt.id
                      ? "bg-amber-600/30 border-amber-400 text-amber-300 shadow"
                      : "bg-stone-800 border-stone-700 text-stone-400"
                  }`}
                >
                  <span className="block text-[11px]">{opt.label}</span>
                  <span className="block text-[8px] text-stone-400 font-normal">
                    {opt.desc}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* 2. Hotbar Scale in Landscape */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-stone-300 uppercase tracking-wider block">
              নিচের হটবার আকার (Hotbar Scale):
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() =>
                  onUpdateSettings((s) => ({ ...s, hotbarScale: "compact" }))
                }
                className={`p-2 rounded-xl border text-center font-bold cursor-pointer transition ${
                  settings.hotbarScale === "compact"
                    ? "bg-amber-600/30 border-amber-400 text-amber-300 shadow"
                    : "bg-stone-800 border-stone-700 text-stone-400"
                }`}
              >
                <span>স্লিম ও কমপ্যাক্ট (Compact Small)</span>
                <span className="block text-[9px] text-stone-400 font-normal">
                  ল্যান্ডস্কেপে কম জায়গা দখল করে
                </span>
              </button>

              <button
                onClick={() =>
                  onUpdateSettings((s) => ({ ...s, hotbarScale: "normal" }))
                }
                className={`p-2 rounded-xl border text-center font-bold cursor-pointer transition ${
                  settings.hotbarScale === "normal"
                    ? "bg-amber-600/30 border-amber-400 text-amber-300 shadow"
                    : "bg-stone-800 border-stone-700 text-stone-400"
                }`}
              >
                <span>স্বাভাবিক (Standard)</span>
                <span className="block text-[9px] text-stone-400 font-normal">
                  বড় আইকন ও স্লট
                </span>
              </button>
            </div>
          </div>

          {/* 3. Virtual Controller Size */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-stone-300 uppercase tracking-wider block">
              ভার্চুয়াল D-Pad ও বাটন সাইজ (Buttons Size):
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { id: "extra_small", label: "খুব ছোট" },
                { id: "small", label: "ছোট" },
                { id: "medium", label: "মাঝারি" },
                { id: "large", label: "বড়" },
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() =>
                    onUpdateSettings((s) => ({
                      ...s,
                      controllerSize: opt.id as any,
                    }))
                  }
                  className={`py-1.5 rounded-xl border text-center font-bold cursor-pointer transition text-[11px] ${
                    settings.controllerSize === opt.id
                      ? "bg-amber-600/30 border-amber-400 text-amber-300 shadow"
                      : "bg-stone-800 border-stone-700 text-stone-400"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* 4. Controller Opacity */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-stone-300 uppercase tracking-wider flex justify-between">
              <span>বাটন স্বচ্ছতা (Opacity):</span>
              <span className="text-amber-400 font-mono">
                {Math.round(settings.controllerOpacity * 100)}%
              </span>
            </label>
            <input
              type="range"
              min="0.3"
              max="1.0"
              step="0.05"
              value={settings.controllerOpacity}
              onChange={(e) =>
                onUpdateSettings((s) => ({
                  ...s,
                  controllerOpacity: parseFloat(e.target.value),
                }))
              }
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* 5. Toggles for Specific Buttons */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-stone-300 uppercase tracking-wider block">
              অন-স্ক্রিন বোতামের উপস্থিতি (Feature Buttons):
            </label>

            {/* Hand Button Toggle */}
            <div className="flex items-center justify-between p-2 bg-stone-950 rounded-xl border border-stone-800">
              <div className="flex items-center gap-2">
                <span className="text-base">✋</span>
                <div>
                  <span className="font-bold text-stone-200 text-xs block">
                    অন-স্ক্রিন খালি হাত বোতাম (Hand Button)
                  </span>
                  <span className="text-[9px] text-stone-400">
                    কুকুরকে শান্ত করতে ও ফসল তুলতে দ্রুত হাত বাটন
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.showHandButton}
                onChange={(e) =>
                  onUpdateSettings((s) => ({
                    ...s,
                    showHandButton: e.target.checked,
                  }))
                }
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Jump Button Toggle */}
            <div className="flex items-center justify-between p-2 bg-stone-950 rounded-xl border border-stone-800">
              <div className="flex items-center gap-2">
                <ArrowBigUp className="w-4 h-4 text-sky-400" />
                <div>
                  <span className="font-bold text-stone-200 text-xs block">
                    লাফ বোতাম (Jump Button)
                  </span>
                  <span className="text-[9px] text-stone-400">
                    বাধা, নদী ও বেড়া পার হতে
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.showJumpButton}
                onChange={(e) =>
                  onUpdateSettings((s) => ({
                    ...s,
                    showJumpButton: e.target.checked,
                  }))
                }
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Sprint Button Toggle */}
            <div className="flex items-center justify-between p-2 bg-stone-950 rounded-xl border border-stone-800">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <div>
                  <span className="font-bold text-stone-200 text-xs block">
                    দৌড় বোতাম (Sprint Button)
                  </span>
                  <span className="text-[9px] text-stone-400">
                    ১.৭ গুণ দ্রুত দৌড়ানোর গতি
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.showSprintButton}
                onChange={(e) =>
                  onUpdateSettings((s) => ({
                    ...s,
                    showSprintButton: e.target.checked,
                  }))
                }
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>

            {/* D-Pad Toggle */}
            <div className="flex items-center justify-between p-2 bg-stone-950 rounded-xl border border-stone-800">
              <div>
                <span className="font-bold text-stone-200 text-xs block">
                  ভার্চুয়াল D-Pad কন্ট্রোলার (D-Pad)
                </span>
                <span className="text-[9px] text-stone-400">
                  কীবোর্ড না থাকলে স্ক্রিনে চারমুখী বাটন
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.showDpad}
                onChange={(e) =>
                  onUpdateSettings((s) => ({
                    ...s,
                    showDpad: e.target.checked,
                  }))
                }
                className="w-4 h-4 accent-amber-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-stone-950 border-t border-stone-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-lg cursor-pointer transition transform active:scale-95"
          >
            সম্পন্ন (Save & Play)
          </button>
        </div>
      </div>
    </div>
  );
};
