import React, { useState, useEffect } from 'react';
import {
  Users,
  UserPlus,
  UserCheck,
  UserX,
  Search,
  MessageSquare,
  Phone,
  Video,
  Ban,
  Trash2,
  Check,
  X,
  Loader2,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { Profile, FriendRequest, BlockedUser } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { usePresence } from '../../contexts/PresenceContext';
import { useCall } from '../../contexts/CallContext';
import {
  getFriends,
  getFriendRequests,
  searchUsers,
  sendFriendRequest,
  cancelFriendRequest,
  acceptFriendRequest,
  rejectFriendRequest,
  removeFriend,
  blockUser,
  unblockUser,
  getBlockedUsers,
} from '../../services/friendService';
import { getOrCreateDirectConversation } from '../../services/chatService';
import { ConfirmationDialog } from '../common/ConfirmationDialog';

type FriendsViewProps = {
  onStartChat: (conversationId: string, friend?: Profile) => void;
};

export const FriendsView: React.FC<FriendsViewProps> = ({ onStartChat }) => {
  const { user } = useAuth();
  const { isUserOnline } = usePresence();
  const { startCall } = useCall();

  const [activeTab, setActiveTab] = useState<'friends' | 'requests' | 'add' | 'blocked'>('friends');
  const [friends, setFriends] = useState<Profile[]>([]);
  const [requests, setRequests] = useState<{ incoming: FriendRequest[]; outgoing: FriendRequest[] }>({
    incoming: [],
    outgoing: [],
  });
  const [blockedList, setBlockedList] = useState<BlockedUser[]>([]);
  const [loading, setLoading] = useState(true);

  // Search in "Add Friend" tab
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [searching, setSearching] = useState(false);
  const [pendingSentIds, setPendingSentIds] = useState<Set<string>>(new Set());

  // Confirmations
  const [removeFriendTarget, setRemoveFriendTarget] = useState<Profile | null>(null);
  const [blockUserTarget, setBlockUserTarget] = useState<Profile | null>(null);

  const currentUserId = user?.id || '';

  const loadData = async () => {
    if (!currentUserId) return;
    setLoading(true);
    try {
      const [friendsData, requestsData, blockedData] = await Promise.all([
        getFriends(currentUserId),
        getFriendRequests(currentUserId),
        getBlockedUsers(currentUserId),
      ]);

      setFriends(friendsData);
      setRequests(requestsData);
      setBlockedList(blockedData);

      // Track outgoing pending
      const outIds = new Set(requestsData.outgoing.map((r) => r.receiver_id));
      setPendingSentIds(outIds);
    } catch (err) {
      console.error('Error loading friends data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentUserId]);

  // Search users in "Add Friend" tab
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      setSearching(true);
      try {
        const results = await searchUsers(searchQuery, currentUserId);
        setSearchResults(results);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setSearching(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery, currentUserId]);

  const handleSendRequest = async (targetId: string) => {
    try {
      await sendFriendRequest(currentUserId, targetId);
      setPendingSentIds((prev) => new Set([...prev, targetId]));
      loadData();
    } catch (err: any) {
      alert(err.message || 'Could not send friend request.');
    }
  };

  const handleStartChatWithFriend = async (friend: Profile) => {
    try {
      const convId = await getOrCreateDirectConversation(friend.id);
      onStartChat(convId, friend);
    } catch (err) {
      console.error('Start chat failed:', err);
    }
  };

  return (
    <div id="friends-view-container" className="h-full flex flex-col bg-neutral-900 text-white select-none">
      {/* Top Header */}
      <div className="p-4 border-b border-neutral-800 bg-neutral-950/40">
        <h2 className="text-lg font-bold text-white">Friends & Contacts</h2>
        <p className="text-xs text-neutral-400">Private verified messaging network</p>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-2 mt-4 overflow-x-auto pb-1 scrollbar-none">
          <button
            id="tab-friends-all"
            onClick={() => setActiveTab('friends')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'friends'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40'
                : 'bg-neutral-800/80 text-neutral-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Friends ({friends.length})</span>
          </button>

          <button
            id="tab-friends-requests"
            onClick={() => setActiveTab('requests')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'requests'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40'
                : 'bg-neutral-800/80 text-neutral-400 hover:text-white'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Requests</span>
            {requests.incoming.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                {requests.incoming.length}
              </span>
            )}
          </button>

          <button
            id="tab-friends-add"
            onClick={() => setActiveTab('add')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'add'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40'
                : 'bg-neutral-800/80 text-neutral-400 hover:text-white'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Add Friend</span>
          </button>

          <button
            id="tab-friends-blocked"
            onClick={() => setActiveTab('blocked')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors flex items-center space-x-1.5 ${
              activeTab === 'blocked'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40'
                : 'bg-neutral-800/80 text-neutral-400 hover:text-white'
            }`}
          >
            <Ban className="w-3.5 h-3.5" />
            <span>Blocked ({blockedList.length})</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4">
        {loading ? (
          <div className="py-20 flex flex-col items-center justify-center space-y-2 text-neutral-500">
            <Loader2 className="w-6 h-6 animate-spin text-emerald-500" />
            <span className="text-xs">Loading contacts...</span>
          </div>
        ) : activeTab === 'friends' ? (
          friends.length === 0 ? (
            <div className="py-20 text-center flex flex-col items-center justify-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-neutral-800 text-neutral-400 flex items-center justify-center">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-neutral-200">No friends yet</h4>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Search and add friends by their @username to start private conversations.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('add')}
                className="mt-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl flex items-center space-x-1.5"
              >
                <UserPlus className="w-4 h-4" />
                <span>Search by Username</span>
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {friends.map((friend) => {
                const online = isUserOnline(friend.id);
                return (
                  <div
                    key={friend.id}
                    id={`friend-row-${friend.id}`}
                    className="p-3.5 rounded-2xl bg-neutral-950/50 border border-neutral-800/80 hover:border-neutral-700/80 flex items-center justify-between transition-all"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="relative shrink-0">
                        <div className="w-11 h-11 rounded-full bg-neutral-800 border border-neutral-700 overflow-hidden flex items-center justify-center text-sm font-bold text-neutral-200">
                          {friend.avatar_url ? (
                            <img src={friend.avatar_url} alt={friend.display_name} className="w-full h-full object-cover" />
                          ) : (
                            friend.display_name.charAt(0).toUpperCase()
                          )}
                        </div>
                        {online && (
                          <div
                            className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-neutral-900"
                            title="Online"
                          />
                        )}
                      </div>

                      <div className="min-w-0">
                        <h4 className="text-sm font-semibold text-neutral-100 truncate">{friend.display_name}</h4>
                        <p className="text-[11px] text-neutral-500 truncate">
                          @{friend.username} {online ? '• Online' : ''}
                        </p>
                        {friend.bio && (
                          <p className="text-[11px] text-neutral-400 truncate max-w-xs mt-0.5">{friend.bio}</p>
                        )}
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center space-x-1 shrink-0">
                      <button
                        id={`btn-chat-friend-${friend.id}`}
                        onClick={() => handleStartChatWithFriend(friend)}
                        className="p-2 text-neutral-300 hover:text-emerald-400 rounded-xl hover:bg-neutral-800 transition-colors"
                        title="Chat"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>

                      <button
                        id={`btn-call-voice-friend-${friend.id}`}
                        onClick={() => startCall(friend, 'voice')}
                        className="p-2 text-neutral-300 hover:text-emerald-400 rounded-xl hover:bg-neutral-800 transition-colors"
                        title="Voice Call"
                      >
                        <Phone className="w-4 h-4" />
                      </button>

                      <button
                        id={`btn-call-video-friend-${friend.id}`}
                        onClick={() => startCall(friend, 'video')}
                        className="p-2 text-neutral-300 hover:text-emerald-400 rounded-xl hover:bg-neutral-800 transition-colors"
                        title="Video Call"
                      >
                        <Video className="w-4 h-4" />
                      </button>

                      <button
                        id={`btn-remove-friend-${friend.id}`}
                        onClick={() => setRemoveFriendTarget(friend)}
                        className="p-2 text-neutral-500 hover:text-red-400 rounded-xl hover:bg-neutral-800 transition-colors"
                        title="Remove Friend"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )
        ) : activeTab === 'requests' ? (
          <div className="space-y-6">
            {/* Incoming requests */}
            <div>
              <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">
                Incoming Requests ({requests.incoming.length})
              </h3>
              {requests.incoming.length === 0 ? (
                <p className="text-xs text-neutral-500 py-3 italic">No pending incoming requests</p>
              ) : (
                <div className="space-y-2">
                  {requests.incoming.map((req) => (
                    <div
                      key={req.id}
                      className="p-3 rounded-2xl bg-neutral-950/60 border border-neutral-800 flex items-center justify-between"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-neutral-800 overflow-hidden flex items-center justify-center font-bold text-neutral-300 text-sm">
                          {req.sender?.avatar_url ? (
                            <img src={req.sender.avatar_url} alt={req.sender.display_name} className="w-full h-full object-cover" />
                          ) : (
                            req.sender?.display_name?.charAt(0).toUpperCase() || '?'
                          )}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-neutral-200">{req.sender?.display_name}</p>
                          <p className="text-[11px] text-neutral-500">@{req.sender?.username}</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={async () => {
                            await acceptFriendRequest(req.id, req.sender_id, req.receiver_id);
                            loadData();
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center space-x-1"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Accept</span>
                        </button>

                        <button
                          onClick={async () => {
                            await rejectFriendRequest(req.id);
                            loadData();
                          }}
                          className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-xl text-xs font-semibold"
                        >
                          Decline
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Outgoing requests */}
            <div>
              <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">
                Sent Requests ({requests.outgoing.length})
              </h3>
              {requests.outgoing.length === 0 ? (
                <p className="text-xs text-neutral-500 py-3 italic">No outgoing pending requests</p>
              ) : (
                <div className="space-y-2">
                  {requests.outgoing.map((req) => (
                    <div
                      key={req.id}
                      className="p-3 rounded-2xl bg-neutral-950/60 border border-neutral-800 flex items-center justify-between"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-neutral-800 overflow-hidden flex items-center justify-center font-bold text-neutral-300 text-sm">
                          {req.receiver?.avatar_url ? (
                            <img src={req.receiver.avatar_url} alt={req.receiver.display_name} className="w-full h-full object-cover" />
                          ) : (
                            req.receiver?.display_name?.charAt(0).toUpperCase() || '?'
                          )}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-neutral-200">{req.receiver?.display_name}</p>
                          <p className="text-[11px] text-neutral-500">@{req.receiver?.username}</p>
                        </div>
                      </div>

                      <button
                        onClick={async () => {
                          await cancelFriendRequest(req.id);
                          loadData();
                        }}
                        className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white rounded-xl text-xs font-medium"
                      >
                        Cancel Request
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : activeTab === 'add' ? (
          <div className="space-y-4">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="input-search-friends-by-username"
                type="text"
                placeholder="Search by @username (e.g. sarah, alex_99)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            {/* Results */}
            {searching ? (
              <div className="py-12 flex justify-center text-neutral-500">
                <Loader2 className="w-6 h-6 animate-spin text-emerald-500" />
              </div>
            ) : searchQuery.trim() && searchResults.length === 0 ? (
              <p className="text-center py-12 text-xs text-neutral-500">
                No users found with username matching "{searchQuery}"
              </p>
            ) : (
              <div className="space-y-2">
                {searchResults.map((userItem) => {
                  const isAlreadyFriend = friends.some((f) => f.id === userItem.id);
                  const isPending = pendingSentIds.has(userItem.id);

                  return (
                    <div
                      key={userItem.id}
                      className="p-3.5 rounded-2xl bg-neutral-950/60 border border-neutral-800 flex items-center justify-between"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-neutral-800 overflow-hidden flex items-center justify-center font-bold text-neutral-300 text-sm">
                          {userItem.avatar_url ? (
                            <img src={userItem.avatar_url} alt={userItem.display_name} className="w-full h-full object-cover" />
                          ) : (
                            userItem.display_name.charAt(0).toUpperCase()
                          )}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-neutral-200">{userItem.display_name}</p>
                          <p className="text-[11px] text-neutral-500 font-mono">@{userItem.username}</p>
                          {userItem.bio && (
                            <p className="text-[11px] text-neutral-400 truncate max-w-xs">{userItem.bio}</p>
                          )}
                        </div>
                      </div>

                      {isAlreadyFriend ? (
                        <span className="text-xs text-emerald-400 font-medium flex items-center space-x-1">
                          <Check className="w-3.5 h-3.5" />
                          <span>Friends</span>
                        </span>
                      ) : isPending ? (
                        <span className="text-xs text-neutral-400 font-medium flex items-center space-x-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Pending</span>
                        </span>
                      ) : (
                        <button
                          onClick={() => handleSendRequest(userItem.id)}
                          className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-sm flex items-center space-x-1"
                        >
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>Add</span>
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          /* Blocked tab */
          blockedList.length === 0 ? (
            <div className="py-20 text-center text-xs text-neutral-500">
              No blocked users.
            </div>
          ) : (
            <div className="space-y-2">
              {blockedList.map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 rounded-2xl bg-neutral-950/60 border border-neutral-800 flex items-center justify-between"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-neutral-800 overflow-hidden flex items-center justify-center font-bold text-neutral-400 text-sm">
                      {item.blocked_profile?.display_name?.charAt(0).toUpperCase() || '?'}
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-neutral-200">
                        {item.blocked_profile?.display_name || 'User'}
                      </p>
                      <p className="text-[11px] text-neutral-500">@{item.blocked_profile?.username}</p>
                    </div>
                  </div>

                  <button
                    onClick={async () => {
                      await unblockUser(currentUserId, item.blocked_id);
                      loadData();
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium"
                  >
                    Unblock
                  </button>
                </div>
              ))}
            </div>
          )
        )}
      </div>

      {/* Confirmation Dialogs */}
      <ConfirmationDialog
        isOpen={Boolean(removeFriendTarget)}
        title={`Remove ${removeFriendTarget?.display_name}?`}
        message="Are you sure you want to remove this friend? You will need to send a new friend request to message them again."
        confirmLabel="Remove Friend"
        onConfirm={async () => {
          if (!removeFriendTarget) return;
          await removeFriend(currentUserId, removeFriendTarget.id);
          setRemoveFriendTarget(null);
          loadData();
        }}
        onCancel={() => setRemoveFriendTarget(null)}
      />

      <ConfirmationDialog
        isOpen={Boolean(blockUserTarget)}
        title={`Block ${blockUserTarget?.display_name}?`}
        message="Blocked users cannot call or message you."
        confirmLabel="Block"
        onConfirm={async () => {
          if (!blockUserTarget) return;
          await blockUser(currentUserId, blockUserTarget.id);
          setBlockUserTarget(null);
          loadData();
        }}
        onCancel={() => setBlockUserTarget(null)}
      />
    </div>
  );
};
