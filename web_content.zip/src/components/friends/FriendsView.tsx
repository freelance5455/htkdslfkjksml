import React, { useState, useEffect } from 'react';
import { User } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api, ANGOLA_PROVINCES } from '../../services/api';
import {
  Users, UserPlus, Search, MapPin, Check,
  X, ShieldCheck, UserX, MessageSquare
} from 'lucide-react';

interface FriendsViewProps {
  onStartChat: (userId: string) => void;
  onOpenProfile: (userId: string) => void;
}

export const FriendsView: React.FC<FriendsViewProps> = ({ onStartChat, onOpenProfile }) => {
  const { currentUser } = useAuth();
  const [tab, setTab] = useState<'my_friends' | 'find_people' | 'blocked'>('my_friends');
  const [users, setUsers] = useState<User[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProvince, setSelectedProvince] = useState('Todas');
  const [isLoading, setIsLoading] = useState(true);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const res = await api.searchUsers({
        q: searchQuery || undefined,
        province: selectedProvince !== 'Todas' ? selectedProvince : undefined,
        currentUserId: currentUser?.id
      });
      setUsers(res.users || []);
    } catch (err) {
      console.error('Erro ao carregar utilizadores:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [searchQuery, selectedProvince, currentUser?.id]);

  if (!currentUser) return null;

  // Filter based on tab
  const myFriends = users.filter(u => currentUser.friends.includes(u.id));
  const findPeople = users.filter(u => u.id !== currentUser.id && !currentUser.friends.includes(u.id));
  const blockedPeople = users.filter(u => currentUser.blockedUsers?.includes(u.id));

  const handleAddFriend = async (targetId: string) => {
    try {
      await api.sendFriendRequest(currentUser.id, targetId);
      alert('Pedido de amizade enviado!');
      loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleRemoveFriend = async (friendId: string) => {
    if (!window.confirm('Tem a certeza de que deseja desfazer a amizade?')) return;
    try {
      await api.removeFriend(currentUser.id, friendId);
      loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleToggleBlock = async (targetId: string) => {
    try {
      await api.toggleBlock(currentUser.id, targetId);
      loadData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const activeList = tab === 'my_friends' ? myFriends : tab === 'find_people' ? findPeople : blockedPeople;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white font-display flex items-center gap-2">
            <Users className="w-6 h-6 text-amber-500" />
            <span>Amigos & Conexões em Angola</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Encontre pessoas por província, faça amigos e comunique em tempo real.
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setTab('my_friends')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${tab === 'my_friends' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'}`}
          >
            Meus Amigos ({myFriends.length})
          </button>
          <button
            onClick={() => setTab('find_people')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${tab === 'find_people' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'}`}
          >
            Encontrar Pessoas
          </button>
          <button
            onClick={() => setTab('blocked')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${tab === 'blocked' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'}`}
          >
            Bloqueados
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Pesquisar por nome, username (@) ou biografia..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300">
          <MapPin className="w-4 h-4 text-amber-500 shrink-0" />
          <select
            value={selectedProvince}
            onChange={(e) => setSelectedProvince(e.target.value)}
            className="bg-transparent text-xs text-white focus:outline-none"
          >
            {ANGOLA_PROVINCES.map((p) => (
              <option key={p} value={p} className="bg-slate-900 text-white">
                {p === 'Todas' ? 'Todas as Províncias' : p}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Users Grid */}
      {isLoading ? (
        <div className="p-12 text-center text-slate-500 text-xs">
          A carregar pessoas...
        </div>
      ) : activeList.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
          <UserPlus className="w-8 h-8 text-amber-400/60 mx-auto mb-2" />
          <p className="text-sm font-semibold text-white">Nenhum utilizador encontrado</p>
          <p className="text-xs text-slate-500 mt-1">Tente pesquisar por outro nome ou selecione outra província.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {activeList.map((user) => (
            <div
              key={user.id}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-5 flex flex-col items-center text-center transition-all shadow-sm"
            >
              <div className="relative mb-3">
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-20 h-20 rounded-full object-cover ring-2 ring-slate-800 hover:ring-amber-500 transition-all cursor-pointer"
                  onClick={() => onOpenProfile(user.id)}
                />
                {user.verified && (
                  <ShieldCheck className="w-5 h-5 text-amber-400 fill-amber-400/20 absolute bottom-0 right-0" />
                )}
              </div>

              <h3
                onClick={() => onOpenProfile(user.id)}
                className="font-bold text-sm text-white hover:text-amber-400 cursor-pointer truncate max-w-full font-display"
              >
                {user.name}
              </h3>
              <p className="text-[11px] text-slate-400 font-mono">@{user.username}</p>
              <p className="text-xs text-amber-400 mt-1 font-medium">🇦🇴 {user.province}</p>

              <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                {user.bio}
              </p>

              <div className="w-full mt-4 pt-3 border-t border-slate-800 flex items-center justify-center gap-2">
                {tab === 'my_friends' ? (
                  <>
                    <button
                      onClick={() => onStartChat(user.id)}
                      className="flex-1 py-1.5 px-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-1 transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Mensagem</span>
                    </button>
                    <button
                      onClick={() => handleRemoveFriend(user.id)}
                      className="p-1.5 bg-slate-800 hover:bg-red-950/40 text-slate-400 hover:text-red-400 rounded-xl transition-colors"
                      title="Desfazer amizade"
                    >
                      <UserX className="w-4 h-4" />
                    </button>
                  </>
                ) : tab === 'find_people' ? (
                  <>
                    <button
                      onClick={() => handleAddFriend(user.id)}
                      className="flex-1 py-1.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-1 transition-colors"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Adicionar</span>
                    </button>
                    <button
                      onClick={() => onStartChat(user.id)}
                      className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors"
                      title="Enviar mensagem direta"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => handleToggleBlock(user.id)}
                    className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold"
                  >
                    Desbloquear
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
