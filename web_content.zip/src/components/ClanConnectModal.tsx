import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Loader2, Search, Shield, User, X } from 'lucide-react';
import { ClanDashboardState, PlayerProfile } from '../shared/cocData';
import { apiFetchJson } from '../utils/apiClient';

interface ClanSearchItem {
  tag: string;
  name: string;
  clanLevel: number;
  badgeUrl?: string;
  warLeague: string;
  locationName?: string;
  memberCount: number;
  clanPoints: number;
  warWins: number;
}

interface ClanConnectModalProps {
  isOpen: boolean;
  currentClanTag: string;
  hasApiToken: boolean;
  onClose: () => void;
  onConnected: (state: ClanDashboardState) => void;
  onOpenExternalPlayer: (player: PlayerProfile) => void;
}

export const ClanConnectModal: React.FC<ClanConnectModalProps> = ({
  isOpen,
  currentClanTag,
  hasApiToken,
  onClose,
  onConnected,
  onOpenExternalPlayer,
}) => {
  const [mode, setMode] = useState<'clan' | 'player'>('clan');
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [connectingTag, setConnectingTag] = useState<string | null>(null);
  const [clanResults, setClanResults] = useState<ClanSearchItem[]>([]);
  const [cursors, setCursors] = useState<{ after?: string; before?: string }>({});
  const [playerResult, setPlayerResult] = useState<PlayerProfile | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const searchClans = async (cursorParams?: { after?: string; before?: string }) => {
    const q = query.trim();
    if (!q) return;

    setError(null);
    setSearching(true);
    setHasSearched(true);
    setPlayerResult(null);
    try {
      const qs = new URLSearchParams({ query: q, limit: '15' });
      if (cursorParams?.after) qs.set('after', cursorParams.after);
      if (cursorParams?.before) qs.set('before', cursorParams.before);

      const data = await apiFetchJson<{
        items?: ClanSearchItem[];
        paging?: { cursors?: { after?: string; before?: string } };
      }>(`/api/coc/search?${qs.toString()}`);
      setClanResults(data.items ?? []);
      setCursors(data.paging?.cursors ?? {});
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка поиска клана');
      setClanResults([]);
      setCursors({});
    } finally {
      setSearching(false);
    }
  };

  const searchPlayer = async () => {
    const q = query.trim();
    if (!q) return;

    const cleanTag = q.toUpperCase().replace(/\s+/g, '').replace(/^#+/, '');
    const normalized = `#${cleanTag}`;
    if (!/^#[0289CGJLPQRUVY]{3,14}$/.test(normalized)) {
      setError('Введите корректный игровой тег игрока (допустимые символы: 0, 2, 8, 9, C, G, J, L, P, Q, R, U, V, Y, например #2PP).');
      setPlayerResult(null);
      setHasSearched(true);
      return;
    }

    setError(null);
    setSearching(true);
    setHasSearched(true);
    setClanResults([]);
    try {
      const data = await apiFetchJson<{ player?: PlayerProfile | null }>(
        `/api/coc/players?tag=${encodeURIComponent(normalized)}`
      );
      setPlayerResult(data.player ?? null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка поиска игрока');
      setPlayerResult(null);
    } finally {
      setSearching(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'clan') {
      searchClans();
    } else {
      searchPlayer();
    }
  };

  const handleConnectClan = async (tag: string) => {
    setError(null);
    setConnectingTag(tag);
    try {
      const data = await apiFetchJson<{ state?: ClanDashboardState }>('/api/coc/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ clanTag: tag }),
        timeoutMs: 35000,
      });
      if (data.state) {
        onConnected(data.state);
        onClose();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Не удалось загрузить данные клана');
    } finally {
      setConnectingTag(null);
    }
  };

  const handleDisconnect = async () => {
    setError(null);
    setConnectingTag('__reset__');
    try {
      const state = await apiFetchJson<ClanDashboardState>('/api/reset', { method: 'POST' });
      onConnected(state);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка при отключении клана');
    } finally {
      setConnectingTag(null);
    }
  };

  const trimmed = query.trim();
  const looksLikeTag = trimmed.startsWith('#') || /^[0289CGJLPQRUVY]{3,12}$/i.test(trimmed);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="global-search-title"
    >
      <div className="w-full max-w-2xl rounded-lg border border-slate-700/80 bg-[#121824] shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4">
          <div>
            <h2 id="global-search-title" className="font-display text-lg font-bold text-slate-100">
              Глобальный поиск Clash of Clans API
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Поиск кланов по названию и тегу или прямой просмотр профиля любого игрока
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1.5 text-slate-400 hover:bg-slate-800 hover:text-slate-100 transition-colors"
            aria-label="Закрыть"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Mode Switch */}
          <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#0B0F17] p-1 w-fit">
            <button
              type="button"
              onClick={() => {
                setMode('clan');
                setError(null);
                setHasSearched(false);
              }}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                mode === 'clan'
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Shield className="h-3.5 w-3.5" />
              <span>Клан (по названию / #тегу)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('player');
                setError(null);
                setHasSearched(false);
              }}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                mode === 'player'
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <User className="h-3.5 w-3.5" />
              <span>Игрок (по #тегу)</span>
            </button>
          </div>

          {!hasApiToken && (
            <div className="rounded-md border border-amber-500/40 bg-amber-500/10 px-3.5 py-2.5 text-xs text-amber-200 leading-relaxed">
              Серверный секрет <span className="font-mono font-semibold">SUPERCELL_API_KEY</span> не задан.
              Добавьте официальный ключ из <span className="font-mono">developer.clashofclans.com</span> в Secrets, чтобы выполнять запросы.
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-2.5 sm:flex-row">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={
                  mode === 'clan'
                    ? 'Название клана (QARACHILAR) или тег (#2UPULGJVC)...'
                    : 'Игровой тег игрока (например, #2PP)...'
                }
                autoFocus
                className="w-full rounded-md border border-slate-700 bg-[#0B0F17] py-2.5 pl-9 pr-3 text-sm text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={searching || !trimmed}
              className="inline-flex items-center justify-center gap-2 rounded-md border border-slate-700 bg-[#0B0F17] px-4 py-2.5 text-xs font-semibold text-slate-100 hover:border-amber-500/60 hover:text-amber-400 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
            >
              {searching ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
              <span>{mode === 'clan' ? 'Найти клан' : 'Найти игрока'}</span>
            </button>

            {mode === 'clan' && looksLikeTag && (
              <button
                type="button"
                disabled={Boolean(connectingTag)}
                onClick={() => handleConnectClan(trimmed)}
                className="inline-flex items-center justify-center gap-2 rounded-md bg-amber-500 px-4 py-2.5 text-xs font-semibold text-slate-950 hover:bg-amber-400 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
              >
                {connectingTag === trimmed && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                <span>Подключить тег</span>
              </button>
            )}
          </form>

          {error && (
            <div className="rounded-md border border-rose-500/40 bg-rose-500/10 px-3.5 py-2.5 text-xs text-rose-300 leading-relaxed">
              {error}
            </div>
          )}

          {connectingTag && connectingTag !== '__reset__' && (
            <div className="flex items-center gap-2.5 rounded-md border border-amber-500/30 bg-amber-500/10 px-3.5 py-2.5 text-xs text-amber-300">
              <Loader2 className="h-4 w-4 animate-spin shrink-0" />
              <span>
                Загружаем данные клана, участников, войны, CWL, рейды столицы и сохраняем снимок...
              </span>
            </div>
          )}

          {/* Results Box */}
          <div className="max-h-72 divide-y divide-slate-800/70 overflow-y-auto rounded-md border border-slate-800 bg-[#0B0F17]">
            {mode === 'clan' &&
              clanResults.map((item) => {
                const isCurrent = item.tag === currentClanTag;
                const isLoadingThis = connectingTag === item.tag;
                return (
                  <div
                    key={item.tag}
                    className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-slate-800/30 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="h-10 w-10 shrink-0 rounded bg-[#121824] border border-slate-800 flex items-center justify-center overflow-hidden">
                        {item.badgeUrl ? (
                          <img
                            src={item.badgeUrl}
                            alt={item.name}
                            referrerPolicy="no-referrer"
                            className="h-full w-full object-contain"
                          />
                        ) : (
                          <Shield className="h-5 w-5 text-amber-400" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="truncate text-sm font-semibold text-slate-100">{item.name}</div>
                        <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
                          <span className="font-mono text-slate-300">{item.tag}</span>
                          <span>·</span>
                          <span>Ур. {item.clanLevel}</span>
                          <span>·</span>
                          <span className="tabular-nums">{item.memberCount} уч.</span>
                          <span>·</span>
                          <span className="tabular-nums">{item.clanPoints.toLocaleString('ru-RU')} очк.</span>
                          <span>·</span>
                          <span>{item.warLeague}</span>
                          {item.locationName && (
                            <>
                              <span>·</span>
                              <span>{item.locationName}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={Boolean(connectingTag)}
                      onClick={() => handleConnectClan(item.tag)}
                      className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                        isCurrent
                          ? 'border border-emerald-500/40 bg-emerald-500/15 text-emerald-300'
                          : 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                      }`}
                    >
                      {isLoadingThis ? 'Загрузка...' : isCurrent ? 'Обновить' : 'Подключить'}
                    </button>
                  </div>
                );
              })}

            {mode === 'player' && playerResult && (
              <div className="flex items-center justify-between gap-3 px-4 py-3.5">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-slate-100">{playerResult.name}</span>
                    <span className="font-mono text-xs text-amber-400">TH{playerResult.townHallLevel}</span>
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
                    <span className="font-mono text-slate-300">{playerResult.tag}</span>
                    <span>·</span>
                    <span className="tabular-nums">Ур. {playerResult.expLevel}</span>
                    <span>·</span>
                    <span className="tabular-nums">{playerResult.trophies.toLocaleString('ru-RU')} кубков</span>
                    <span>·</span>
                    <span className="tabular-nums">{playerResult.warStars} звёзд КВ</span>
                    {playerResult.clanRef && (
                      <>
                        <span>·</span>
                        <span>Клан: {playerResult.clanRef.name}</span>
                      </>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onOpenExternalPlayer(playerResult);
                    onClose();
                  }}
                  className="rounded-md bg-amber-500 px-3.5 py-1.5 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors whitespace-nowrap shrink-0"
                >
                  Открыть профиль
                </button>
              </div>
            )}

            {mode === 'clan' && !searching && hasSearched && clanResults.length === 0 && !error && (
              <div className="py-8 text-center text-xs text-slate-500">
                Кланы не найдены в официальном Supercell API. Проверьте название или введите точный тег с #.
              </div>
            )}

            {mode === 'player' && !searching && hasSearched && !playerResult && !error && (
              <div className="py-8 text-center text-xs text-slate-500">
                Игрок не найден. Проверьте игровой тег.
              </div>
            )}

            {!hasSearched && (
              <div className="py-8 text-center text-xs text-slate-500">
                {mode === 'clan'
                  ? 'Введите название клана или #тег (например, QARACHILAR или #2UPULGJVC).'
                  : 'Введите точный тег игрока (например, #2PP), чтобы загрузить профиль напрямую из Supercell API.'}
              </div>
            )}
          </div>

          {/* Pagination Controls for Clan Name Search */}
          {mode === 'clan' && (cursors.before || cursors.after) && (
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={!cursors.before || searching}
                onClick={() => searchClans({ before: cursors.before })}
                className="inline-flex items-center gap-1 rounded-md border border-slate-700 bg-[#0B0F17] px-3 py-1.5 text-xs text-slate-300 hover:border-amber-500/60 disabled:opacity-40"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
                Назад
              </button>
              <button
                type="button"
                disabled={!cursors.after || searching}
                onClick={() => searchClans({ after: cursors.after })}
                className="inline-flex items-center gap-1 rounded-md border border-slate-700 bg-[#0B0F17] px-3 py-1.5 text-xs text-slate-300 hover:border-amber-500/60 disabled:opacity-40"
              >
                Вперёд
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-800 px-5 py-3 text-xs">
          <span className="text-slate-500">
            Серверный прокси: api.clashofclans.com/v1
          </span>
          {currentClanTag && (
            <button
              type="button"
              disabled={Boolean(connectingTag)}
              onClick={handleDisconnect}
              className="text-slate-400 hover:text-rose-300 transition-colors"
            >
              Отключить текущий клан
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
