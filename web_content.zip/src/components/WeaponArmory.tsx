import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Crosshair, 
  Zap, 
  Flame, 
  Layers, 
  HelpCircle, 
  Check, 
  ArrowRight,
  Shield,
  Gauge
} from 'lucide-react';
import { WEAPONS_DATA } from '../data/freeFireData';
import { Weapon } from '../types';
import { sounds } from '../utils/soundEffects';

export const WeaponArmory: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedWeapon, setSelectedWeapon] = useState<Weapon>(WEAPONS_DATA[0]);
  const [compareWeapon, setCompareWeapon] = useState<Weapon>(WEAPONS_DATA[1]);
  const [helmetLevel, setHelmetLevel] = useState<number>(2); // Level 2 default
  const [vestLevel, setVestLevel] = useState<number>(2);     // Level 2 default
  const [targetMaxHp, setTargetMaxHp] = useState<number>(200);

  const categories = ['All', 'Shotgun', 'Marksman Rifle', 'Assault Rifle', 'SMG', 'Sniper', 'Pistol'];

  const filteredWeapons = selectedCategory === 'All' 
    ? WEAPONS_DATA 
    : WEAPONS_DATA.filter(w => w.category === selectedCategory);

  const handleSelectWeapon = (weapon: Weapon) => {
    sounds.playClick();
    setSelectedWeapon(weapon);
  };

  const handleSelectCompare = (weapon: Weapon) => {
    sounds.playClick();
    setCompareWeapon(weapon);
  };

  // Free Fire Damage Formulas based on Armor Reduction and Penetration:
  // Helmet reduction: Lv0 = 0%, Lv1 = 33%, Lv2 = 45%, Lv3 = 57%, Lv4 = 70%
  // Vest reduction: Lv0 = 0%, Lv1 = 33%, Lv2 = 45%, Lv3 = 57%, Lv4 = 70%
  // Armor penetration negates a portion of the reduction.
  const calculateDamage = (weapon: Weapon, isHeadshot: boolean) => {
    const baseDamage = isHeadshot ? weapon.damage * weapon.headshotMultiplier : weapon.damage;
    const armorLevel = isHeadshot ? helmetLevel : vestLevel;
    
    const reductions: Record<number, number> = { 0: 0, 1: 0.33, 2: 0.45, 3: 0.57, 4: 0.70 };
    const baseReduction = reductions[armorLevel] || 0;
    
    // Armor penetration reduces effectiveness of armor
    const penFactor = weapon.armorPenetration / 100;
    const effectiveReduction = Math.max(0, baseReduction * (1 - penFactor));
    
    const finalDamage = Math.round(baseDamage * (1 - effectiveReduction));
    return Math.max(1, finalDamage);
  };

  const headDamage = calculateDamage(selectedWeapon, true);
  const bodyDamage = calculateDamage(selectedWeapon, false);
  const headShotsToKnock = Math.ceil(targetMaxHp / headDamage);
  const bodyShotsToKnock = Math.ceil(targetMaxHp / bodyDamage);

  // Time to kill in ms = (shots - 1) * (1000 / (fireRate * 0.15))
  const roundsPerSec = (selectedWeapon.rateOfFire * 0.14) + 2;
  const bodyTtkMs = Math.round(((bodyShotsToKnock - 1) / roundsPerSec) * 1000);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#14192b] via-[#1c223c] to-[#14192b] border border-orange-500/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-500/20 text-red-400 border border-red-500/30 font-rajdhani">
                METAGAME ARMORY
              </span>
              <span className="text-xs text-orange-400 font-bold flex items-center gap-1">
                <Flame className="w-3.5 h-3.5" /> OB44 Tournament Stats & Armor Penetration
              </span>
            </div>
            <h2 className="text-2xl font-bold font-heading text-white">
              Weapon Armory & Headshot TTK Calculator
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Compare actual in-game fire rates, bullet spread, and helmet/vest absorption. Simulate exact headshot damage against Level 1-4 gear.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Target HP:</span>
            <button
              onClick={() => setTargetMaxHp(200)}
              className={`px-3 py-1.5 rounded-lg font-bold border transition-all ${
                targetMaxHp === 200 
                  ? 'bg-orange-500 text-white border-orange-400' 
                  : 'bg-[#141828] text-slate-400 border-slate-700'
              }`}
            >
              200 HP (Standard)
            </button>
            <button
              onClick={() => setTargetMaxHp(250)}
              className={`px-3 py-1.5 rounded-lg font-bold border transition-all ${
                targetMaxHp === 250 
                  ? 'bg-amber-500 text-black border-amber-400' 
                  : 'bg-[#141828] text-slate-400 border-slate-700'
              }`}
            >
              250 HP (Luqueta / K)
            </button>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="mt-5 pt-4 border-t border-slate-700/60 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => { setSelectedCategory(cat); sounds.playClick(); }}
              className={`px-3 py-1 text-xs font-bold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                  : 'bg-[#151a2d] text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Weapons Selector Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
        {filteredWeapons.map((gun) => {
          const isPrimary = selectedWeapon.id === gun.id;
          const isCompare = compareWeapon.id === gun.id;
          return (
            <div
              key={gun.id}
              onClick={() => handleSelectWeapon(gun)}
              className={`p-3 rounded-xl border transition-all cursor-pointer relative ${
                isPrimary
                  ? 'bg-gradient-to-b from-[#1e2642] to-[#14192b] border-orange-500 shadow-lg shadow-orange-500/20'
                  : 'bg-[#101423] border-slate-800 hover:border-slate-700 hover:bg-[#14192a]'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[10px] font-black px-1.5 py-0.2 rounded uppercase ${
                  gun.tier === 'S+' ? 'bg-red-500/20 text-red-400 border border-red-500/40' :
                  gun.tier === 'S' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' :
                  'bg-blue-500/20 text-blue-400'
                }`}>
                  Tier {gun.tier}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">{gun.category}</span>
              </div>
              <div className="font-bold text-white text-xs sm:text-sm line-clamp-1 mt-1">
                {gun.name}
              </div>
              <div className="flex items-center justify-between mt-2 text-[11px] font-mono">
                <span className="text-slate-400">DMG: <strong className="text-orange-400">{gun.damage}</strong></span>
                <span className="text-slate-400">ROF: <strong className="text-cyan-400">{gun.rateOfFire}</strong></span>
              </div>
              {isPrimary && (
                <div className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-orange-400 animate-ping"></div>
              )}
            </div>
          );
        })}
      </div>

      {/* Side by Side Weapon Comparison & Live TTK Calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Comparison Stats Bars (7 cols) */}
        <div className="lg:col-span-7 bg-[#101423] border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <span className="text-xs text-slate-400">Primary Weapon</span>
              <h3 className="font-heading font-bold text-lg text-white">
                {selectedWeapon.name}
              </h3>
            </div>

            {/* Compare Selector Dropdown */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">VS:</span>
              <select
                value={compareWeapon.id}
                onChange={e => {
                  const found = WEAPONS_DATA.find(w => w.id === e.target.value);
                  if (found) handleSelectCompare(found);
                }}
                className="bg-[#090b14] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-semibold cursor-pointer"
              >
                {WEAPONS_DATA.map(w => (
                  <option key={w.id} value={w.id}>{w.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Stats Bar Comparison */}
          <div className="space-y-3.5">
            {[
              { label: 'Damage', valA: selectedWeapon.damage, valB: compareWeapon.damage, colorA: 'bg-red-500', colorB: 'bg-slate-500' },
              { label: 'Rate of Fire', valA: selectedWeapon.rateOfFire, valB: compareWeapon.rateOfFire, colorA: 'bg-orange-500', colorB: 'bg-slate-500' },
              { label: 'Range', valA: selectedWeapon.range, valB: compareWeapon.range, colorA: 'bg-amber-500', colorB: 'bg-slate-500' },
              { label: 'Armor Penetration', valA: selectedWeapon.armorPenetration, valB: compareWeapon.armorPenetration, colorA: 'bg-purple-500', colorB: 'bg-slate-500' },
              { label: 'Accuracy', valA: selectedWeapon.accuracy, valB: compareWeapon.accuracy, colorA: 'bg-emerald-500', colorB: 'bg-slate-500' },
              { label: 'Reload Speed', valA: selectedWeapon.reloadSpeed, valB: compareWeapon.reloadSpeed, colorA: 'bg-cyan-500', colorB: 'bg-slate-500' },
            ].map((stat) => (
              <div key={stat.label} className="space-y-1">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-300">{stat.label}</span>
                  <div className="flex items-center gap-3 font-mono text-xs">
                    <span className="text-orange-400 font-bold">{stat.valA}</span>
                    <span className="text-slate-500">vs</span>
                    <span className="text-slate-400">{stat.valB}</span>
                  </div>
                </div>
                {/* Visual Comparative Bars */}
                <div className="space-y-1">
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${Math.min(100, stat.valA)}%` }}
                      className={`h-full ${stat.colorA} transition-all duration-300`}
                    ></div>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800/60 rounded-full overflow-hidden opacity-50">
                    <div
                      style={{ width: `${Math.min(100, stat.valB)}%` }}
                      className="h-full bg-slate-400 transition-all duration-300"
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pro Combat Advice */}
          <div className="mt-4 p-3.5 bg-[#14192a] border border-orange-500/20 rounded-xl text-xs space-y-1">
            <div className="font-bold text-amber-300 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-yellow-400" />
              Tournament Meta Tip for {selectedWeapon.name}:
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              {selectedWeapon.proTips}
            </p>
          </div>
        </div>

        {/* Live Armor TTK Calculator (5 cols) */}
        <div className="lg:col-span-5 bg-[#101423] border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="font-heading font-bold text-base text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-cyan-400" />
              Armor & Helmet Damage Matrix
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Testing against enemy equipped with armor
            </p>
          </div>

          {/* Armor Levels Pickers */}
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1.5">
                <span>Enemy Helmet Level:</span>
                <span className="text-amber-400 font-mono font-bold">Level {helmetLevel}</span>
              </div>
              <div className="grid grid-cols-5 gap-1 text-xs">
                {[0, 1, 2, 3, 4].map(lvl => (
                  <button
                    key={lvl}
                    onClick={() => { setHelmetLevel(lvl); sounds.playClick(); }}
                    className={`py-1.5 rounded font-bold border transition-all cursor-pointer ${
                      helmetLevel === lvl
                        ? 'bg-amber-500 text-black border-amber-400 shadow-md shadow-amber-500/20'
                        : 'bg-[#151a2d] text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {lvl === 0 ? 'None' : `Lv ${lvl}`}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1.5">
                <span>Enemy Vest Level:</span>
                <span className="text-cyan-400 font-mono font-bold">Level {vestLevel}</span>
              </div>
              <div className="grid grid-cols-5 gap-1 text-xs">
                {[0, 1, 2, 3, 4].map(lvl => (
                  <button
                    key={lvl}
                    onClick={() => { setVestLevel(lvl); sounds.playClick(); }}
                    className={`py-1.5 rounded font-bold border transition-all cursor-pointer ${
                      vestLevel === lvl
                        ? 'bg-cyan-500 text-black border-cyan-400 shadow-md shadow-cyan-500/20'
                        : 'bg-[#151a2d] text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {lvl === 0 ? 'None' : `Lv ${lvl}`}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Output Damage Cards */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            {/* Headshot Damage */}
            <div className="bg-[#1c1215] border border-red-500/40 rounded-xl p-3 text-center space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-red-400">
                HEADSHOT DAMAGE
              </span>
              <div className="text-2xl sm:text-3xl font-extrabold font-mono text-red-500 flex items-center justify-center gap-1">
                ⚡ {headDamage}
              </div>
              <span className="text-[11px] font-bold text-red-300 block">
                {headShotsToKnock === 1 ? '💥 1-TAP INSTA-KNOCK' : `${headShotsToKnock} Headshots to Knock`}
              </span>
            </div>

            {/* Body Damage */}
            <div className="bg-[#181912] border border-amber-500/40 rounded-xl p-3 text-center space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                BODY SHOT DAMAGE
              </span>
              <div className="text-2xl sm:text-3xl font-extrabold font-mono text-yellow-400 flex items-center justify-center gap-1">
                {bodyDamage}
              </div>
              <span className="text-[11px] font-bold text-yellow-200 block">
                {bodyShotsToKnock} Bullets to Knock
              </span>
            </div>
          </div>

          {/* TTK Breakdown */}
          <div className="bg-[#090b14] border border-slate-800 rounded-xl p-3.5 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                Time to Kill (Body TTK):
              </span>
              <span className="font-mono font-bold text-cyan-300">{bodyTtkMs} ms</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Armor Penetration Factor:</span>
              <span className="font-mono font-bold text-purple-400">{selectedWeapon.armorPenetration}% Bypass</span>
            </div>
            <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-800">
              *Calculated against full {targetMaxHp} HP target. Headshot knocks bypass vest durability entirely.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
