import React, { useState } from 'react';
import {
  GraduationCap,
  SquarePen,
  Compass,
  Calculator,
  Code2,
  FlaskConical,
  BookOpen,
  Landmark,
  Trash2,
  HelpCircle,
  Layers,
  Crown,
  MessageSquare,
  X,
  Edit2,
  Check,
} from 'lucide-react';
import { TUTOR_PERSONAS, TutorPersonaId } from '../utils/tutor-prompts';
import { ChatSession } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  activeSessionId: string | null;
  currentPersona: TutorPersonaId;
  onSelectSession: (id: string) => void;
  onNewChat: (personaId?: TutorPersonaId) => void;
  onSelectPersona: (personaId: TutorPersonaId) => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  onClearAll: () => void;
  onOpenQuiz: () => void;
  onOpenFlashcards: () => void;
  onOpenPlans: () => void;
}

const PERSONA_ICONS: Record<TutorPersonaId, React.ComponentType<{ className?: string }>> = {
  general: Compass,
  math: Calculator,
  code: Code2,
  science: FlaskConical,
  language: BookOpen,
  history: Landmark,
};

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  sessions,
  activeSessionId,
  currentPersona,
  onSelectSession,
  onNewChat,
  onSelectPersona,
  onDeleteSession,
  onRenameSession,
  onClearAll,
  onOpenQuiz,
  onOpenFlashcards,
  onOpenPlans,
}) => {
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');

  const startEditing = (session: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(session.id);
    setEditTitle(session.title);
  };

  const saveEdit = (id: string, e?: React.FormEvent) => {
    e?.preventDefault();
    if (editTitle.trim()) {
      onRenameSession(id, editTitle.trim());
    }
    setEditingSessionId(null);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-900/30 backdrop-blur-xs z-30 md:hidden transition-opacity"
          aria-hidden="true"
        />
      )}

      <aside
        id="sidebar"
        className={`fixed md:relative top-0 bottom-0 left-0 w-72 bg-slate-50 border-r border-slate-200 flex flex-col z-40 transition-transform duration-200 ease-in-out select-none ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-white/70">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold shadow-xs">
              <GraduationCap className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 tracking-tight text-sm leading-tight">
                AI Tutor
              </div>
              <div className="text-[11px] text-slate-500 font-medium">MindSparq Study</div>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <button
              onClick={() => onNewChat()}
              aria-label="Start new conversation"
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 rounded-lg transition"
              title="New Chat"
            >
              <SquarePen className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              aria-label="Close sidebar"
              className="md:hidden p-2 text-slate-500 hover:text-slate-800 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Study Tools Quick Launch */}
        <div className="px-3 pt-3 pb-2 border-b border-slate-200">
          <div className="flex items-center justify-between mb-1.5 px-1">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Study Tools
            </span>
            <span className="text-[10px] text-indigo-600 bg-indigo-50 font-medium px-1.5 py-0.5 rounded">
              Interactive
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onOpenQuiz}
              aria-label="Open Practice Quiz Arena"
              className="flex items-center space-x-2 px-2.5 py-2 rounded-lg text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/50 hover:text-indigo-700 shadow-2xs transition group"
            >
              <HelpCircle className="w-3.5 h-3.5 text-indigo-600 group-hover:scale-110 transition-transform" />
              <span>Practice Quiz</span>
            </button>
            <button
              onClick={onOpenFlashcards}
              aria-label="Open Flashcards Study Deck"
              className="flex items-center space-x-2 px-2.5 py-2 rounded-lg text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-purple-300 hover:bg-purple-50/50 hover:text-purple-700 shadow-2xs transition group"
            >
              <Layers className="w-3.5 h-3.5 text-purple-600 group-hover:scale-110 transition-transform" />
              <span>Flashcards</span>
            </button>
          </div>
        </div>

        {/* Tutor Personas List */}
        <div className="p-3 border-b border-slate-200">
          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2 px-1">
            Tutor Persona
          </label>
          <div className="space-y-1">
            {(Object.keys(TUTOR_PERSONAS) as TutorPersonaId[]).map((key) => {
              const persona = TUTOR_PERSONAS[key];
              const Icon = PERSONA_ICONS[key] || Compass;
              const isActive = currentPersona === key;

              return (
                <button
                  key={key}
                  onClick={() => onSelectPersona(key)}
                  aria-label={`Select ${persona.name}`}
                  className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-medium transition text-left cursor-pointer ${
                    isActive
                      ? 'bg-white text-slate-900 border border-slate-200 shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-200/50 hover:text-slate-900'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-indigo-600' : 'text-slate-400'
                    }`}
                  />
                  <div className="truncate flex-1">
                    <span className="block leading-none">{persona.name}</span>
                  </div>
                  {isActive && (
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Chat History List */}
        <div className="flex-1 overflow-y-auto p-3">
          <div className="flex items-center justify-between mb-2 px-1">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Recent Chats
            </span>
            <span className="text-[11px] text-slate-400 font-mono">
              {sessions.length}
            </span>
          </div>

          {sessions.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400 px-3">
              <MessageSquare className="w-6 h-6 mx-auto mb-2 text-slate-300 stroke-[1.5]" />
              <p>No conversations yet</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Ask a question to begin</p>
            </div>
          ) : (
            <div className="space-y-1">
              {sessions.map((session) => {
                const isActive = session.id === activeSessionId;
                const isEditing = session.id === editingSessionId;

                return (
                  <div
                    key={session.id}
                    onClick={() => onSelectSession(session.id)}
                    className={`group relative flex items-center justify-between px-3 py-2 rounded-lg text-xs cursor-pointer transition ${
                      isActive
                        ? 'bg-white text-slate-900 font-medium border border-slate-200 shadow-2xs'
                        : 'text-slate-600 hover:bg-slate-200/50 hover:text-slate-900'
                    }`}
                  >
                    {isEditing ? (
                      <form
                        onSubmit={(e) => saveEdit(session.id, e)}
                        className="flex items-center w-full space-x-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <input
                          type="text"
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          onBlur={() => saveEdit(session.id)}
                          autoFocus
                          className="w-full text-xs px-1.5 py-0.5 border border-indigo-400 rounded bg-white text-slate-800 outline-none"
                        />
                        <button
                          type="submit"
                          aria-label="Confirm rename"
                          className="p-1 hover:text-indigo-600 text-slate-500"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </form>
                    ) : (
                      <>
                        <div className="flex items-center space-x-2 truncate flex-1 pr-2">
                          <MessageSquare
                            className={`w-3.5 h-3.5 shrink-0 ${
                              isActive ? 'text-indigo-600' : 'text-slate-400'
                            }`}
                          />
                          <span className="truncate">{session.title}</span>
                        </div>
                        <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={(e) => startEditing(session, e)}
                            aria-label={`Rename conversation ${session.title}`}
                            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded"
                            title="Rename"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                          <button
                            onClick={(e) => onDeleteSession(session.id, e)}
                            aria-label={`Delete conversation ${session.title}`}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded"
                            title="Delete"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Sidebar Footer: Always interactive, with in-app confirmation */}
        <div className="p-3 border-t border-slate-200 bg-white/60 space-y-2">
          <button
            onClick={() => {
              onOpenPlans();
              onClose();
            }}
            aria-label="View MindSparq subscription plans"
            className="w-full flex items-center justify-center space-x-2 text-xs font-semibold text-indigo-700 hover:bg-indigo-50 p-2.5 rounded-lg transition border border-indigo-100 bg-indigo-50/70 cursor-pointer"
          >
            <Crown className="w-3.5 h-3.5" />
            <span>Explore Plus & Pro</span>
          </button>
          <button
            onClick={onClearAll}
            aria-label="Clear all conversations"
            className="w-full flex items-center justify-center space-x-2 text-xs text-rose-600 hover:bg-rose-50 p-2 rounded-lg transition border border-transparent hover:border-rose-100 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear all conversations</span>
          </button>
        </div>
      </aside>
    </>
  );
};
