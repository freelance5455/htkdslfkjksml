import { useState } from 'react';
import { menuSections } from '../policeContent';
import PoliceIcon from './PoliceIcon';

interface SidebarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
  onSearchOpen: () => void;
}

const Sidebar = ({ activeSection, setActiveSection, onSearchOpen }: SidebarProps) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openSections, setOpenSections] = useState(() => new Set(menuSections.map((section) => section.title)));

  const navigate = (id: string) => {
    setActiveSection(id);
    setMobileOpen(false);
  };

  const toggleSection = (title: string) => {
    setOpenSections((current) => {
      const next = new Set(current);
      if (next.has(title)) next.delete(title);
      else next.add(title);
      return next;
    });
  };

  return (
    <>
      <button className="mobile-menu-button" onClick={() => setMobileOpen((value) => !value)} aria-label="Open navigation">
        <PoliceIcon name="menu" className="h-6 w-6" />
      </button>
      <aside className={`site-sidebar ${mobileOpen ? 'is-open' : ''}`}>
        <div className="sidebar-brand">
          <div className="brand-mark"><PoliceIcon name="shield" className="h-9 w-9" /></div>
          <div><strong>UK Police</strong><span>Knowledge Base</span></div>
        </div>
        <button className="sidebar-search" onClick={onSearchOpen}>
          <PoliceIcon name="search" className="h-4 w-4" /><span>Search all guidance</span><kbd>Ctrl K</kbd>
        </button>
        <nav className="sidebar-nav" aria-label="Knowledge base navigation">
          <button className={`nav-home ${activeSection === 'home' ? 'active' : ''}`} onClick={() => navigate('home')}>
            <PoliceIcon name="home" className="h-5 w-5" /><span>Home</span>
          </button>
          {menuSections.map((section) => {
            const expanded = openSections.has(section.title);
            const containsActive = section.items.some((item) => item.id === activeSection);
            return (
              <div className={`nav-section ${containsActive ? 'contains-active' : ''}`} key={section.title}>
                <button className="nav-section-toggle" onClick={() => toggleSection(section.title)} aria-expanded={expanded}>
                  <PoliceIcon name={section.icon} className="h-4 w-4" /><span>{section.title}</span>
                  <span className={`toggle-chevron ${expanded ? 'expanded' : ''}`}><PoliceIcon name="chevron" className="h-4 w-4" /></span>
                </button>
                {expanded && <div className="nav-items">{section.items.map((item) => (
                  <button key={item.id} className={activeSection === item.id ? 'active' : ''} onClick={() => navigate(item.id)}>{item.label}</button>
                ))}</div>}
              </div>
            );
          })}
        </nav>
        <div className="sidebar-footer"><span>UNITED KINGDOM</span><p>Law · Procedure · Accountability</p></div>
      </aside>
      {mobileOpen && <button className="sidebar-overlay" onClick={() => setMobileOpen(false)} aria-label="Close navigation" />}
    </>
  );
};

export default Sidebar;