import React, { useMemo, useState } from "react";
import {
  Check,
  Clock,
  Compass,
  MessageSquare,
  Pencil,
  Plus,
  Search,
  Settings,
  Shield,
  Trash2,
  X,
} from "lucide-react";
import type { AppPage, ChatSession, UserProfile } from "../types/chat";
import { BrandLogo } from "./BrandLogo";

interface SidebarProps {
  open: boolean;
  onClose: () => void;
  currentPage: AppPage;
  onNavigate: (page: AppPage) => void;
  chats: ChatSession[];
  activeChatId: string | null;
  onSelectChat: (chatId: string) => void;
  onNewChat: () => void;
  onRenameChat: (chatId: string, newTitle: string) => void;
  onRequestDeleteChat: (chat: ChatSession) => void;
  user: UserProfile;
}

function getDateBucket(timestamp: number): string {
  const now = new Date();
  const startOfToday = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate()
  ).getTime();
  const startOfYesterday = startOfToday - 24 * 60 * 60 * 1000;
  const sevenDaysAgo = startOfToday - 7 * 24 * 60 * 60 * 1000;

  if (timestamp >= startOfToday) return "Today";
  if (timestamp >= startOfYesterday) return "Yesterday";
  if (timestamp >= sevenDaysAgo) return "Previous 7 Days";
  return "Older";
}

export const Sidebar: React.FC<SidebarProps> = ({
  open,
  onClose,
  currentPage,
  onNavigate,
  chats,
  activeChatId,
  onSelectChat,
  onNewChat,
  onRenameChat,
  onRequestDeleteChat,
  user,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftTitle, setDraftTitle] = useState("");

  const filteredChats = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return chats;
    return chats.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.messages.some((m) => m.text.toLowerCase().includes(q))
    );
  }, [chats, searchQuery]);

  const groupedChats = useMemo(() => {
    const order = ["Today", "Yesterday", "Previous 7 Days", "Older"];
    const groups: Record<string, ChatSession[]> = {};
    for (const chat of filteredChats) {
      const bucket = getDateBucket(chat.updatedAt || chat.createdAt);
      if (!groups[bucket]) groups[bucket] = [];
      groups[bucket].push(chat);
    }
    return order
      .filter((label) => groups[label]?.length)
      .map((label) => ({ label, items: groups[label] }));
  }, [filteredChats]);

  const beginRename = (chat: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(chat.id);
    setDraftTitle(chat.title);
  };

  const commitRename = (chatId: string) => {
    const trimmed = draftTitle.trim();
    if (trimmed) {
      onRenameChat(chatId, trimmed);
    }
    setEditingId(null);
  };

  const navItems: Array<{ id: AppPage; label: string; icon: React.ReactNode }> = [
    { id: "chat", label: "AI Chat", icon: <MessageSquare className="w-4 h-4" /> },
    { id: "history", label: "Chat History", icon: <Clock className="w-4 h-4" /> },
    { id: "settings", label: "Settings", icon: <Settings className="w-4 h-4" /> },
    { id: "about", label: "Privacy & About", icon: <Shield className="w-4 h-4" /> },
    { id: "welcome", label: "Welcome Guide", icon: <Compass className="w-4 h-4" /> },
  ];

  const sidebarContent = (
    <aside className="flex flex-col h-full w-[280px] bg-slate-100/90 dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 select-none">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3.5 border-b border-slate-200/80 dark:border-slate-800">
        <button
          type="button"
          onClick={() => {
            onNavigate("chat");
            onClose();
          }}
          className="text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded-lg"
        >
          <BrandLogo size="sm" showSubtitle />
        </button>
        <button
          type="button"
          onClick={onClose}
          className="lg:hidden min-h-[44px] min-w-[44px] -mr-2 rounded-xl flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors"
          aria-label="Close sidebar"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* New Chat Button + Search */}
      <div className="p-3 space-y-2.5">
        <button
          type="button"
          onClick={() => {
            onNewChat();
            onClose();
          }}
          className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white text-sm font-semibold flex items-center justify-center gap-2 transition-all shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>New Chat</span>
        </button>

        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search conversations"
            aria-label="Search conversations"
            className="w-full min-h-[40px] pl-9 pr-8 py-1.5 rounded-xl text-sm bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery("")}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              aria-label="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Saved Conversations */}
      <div className="flex-1 overflow-y-auto px-3 py-1 space-y-4 mih-scroll">
        {groupedChats.length === 0 ? (
          <div className="px-2 py-6 text-center">
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              {searchQuery
                ? "No matching chats found."
                : "Your saved conversations will appear here."}
            </p>
          </div>
        ) : (
          groupedChats.map((group) => (
            <div key={group.label}>
              <div className="px-2 pb-1.5 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                {group.label}
              </div>
              <div className="space-y-0.5">
                {group.items.map((chat) => {
                  const isActive =
                    currentPage === "chat" && activeChatId === chat.id;
                  const isEditing = editingId === chat.id;

                  if (isEditing) {
                    return (
                      <div
                        key={chat.id}
                        className="flex items-center gap-1 px-2 py-1.5 rounded-xl bg-white dark:bg-slate-950 border border-blue-500"
                      >
                        <input
                          type="text"
                          value={draftTitle}
                          onChange={(e) => setDraftTitle(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") commitRename(chat.id);
                            if (e.key === "Escape") setEditingId(null);
                          }}
                          autoFocus
                          aria-label="Rename conversation"
                          className="flex-1 min-w-0 bg-transparent text-sm text-slate-900 dark:text-slate-100 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => commitRename(chat.id)}
                          className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/50"
                          aria-label="Save name"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingId(null)}
                          className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                          aria-label="Cancel rename"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={chat.id}
                      onClick={() => {
                        onSelectChat(chat.id);
                        onClose();
                      }}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          onSelectChat(chat.id);
                          onClose();
                        }
                      }}
                      className={`group flex items-center justify-between gap-2 min-h-[42px] px-2.5 py-2 rounded-xl cursor-pointer transition-colors ${
                        isActive
                          ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 shadow-2xs"
                          : "text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800/60 border border-transparent"
                      }`}
                    >
                      <span className="text-sm truncate flex-1">{chat.title}</span>
                      <div className="flex items-center gap-0.5 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 focus-within:opacity-100 transition-opacity shrink-0">
                        <button
                          type="button"
                          onClick={(e) => beginRename(chat, e)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-700"
                          aria-label={`Rename ${chat.title}`}
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onRequestDeleteChat(chat);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40"
                          aria-label={`Delete ${chat.title}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Navigation Links */}
      <div className="px-3 py-2.5 border-t border-slate-200/80 dark:border-slate-800 space-y-0.5">
        {navItems.map((item) => {
          const active = currentPage === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onNavigate(item.id);
                onClose();
              }}
              className={`w-full min-h-[40px] px-3 py-2 rounded-xl text-sm font-medium flex items-center gap-2.5 transition-colors whitespace-nowrap ${
                active
                  ? "bg-slate-200/80 dark:bg-slate-800 text-slate-900 dark:text-white"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200/50 dark:hover:bg-slate-800/50"
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* User / Mode Footer */}
      <div className="px-4 py-3 border-t border-slate-200/80 dark:border-slate-800 bg-slate-100 dark:bg-slate-900/95">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center text-xs font-semibold shrink-0">
            {user.avatarUrl ? (
              <img
                src={user.avatarUrl}
                alt={user.name}
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              user.name.slice(0, 2).toUpperCase()
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
              {user.mode === "google" ? user.name : "Demo Mode"}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
              {user.mode === "google" ? user.email : "Saved locally on device"}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );

  return (
    <>
      {/* Desktop persistent / collapsible sidebar */}
      {open && (
        <div className="hidden lg:block h-full shrink-0">{sidebarContent}</div>
      )}

      {/* Mobile & Tablet slide-over drawer */}
      {open && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div
            className="fixed inset-0 bg-slate-950/50 backdrop-blur-xs"
            onClick={onClose}
            aria-hidden="true"
          />
          <div className="relative z-50 h-full max-w-[85vw]">{sidebarContent}</div>
        </div>
      )}
    </>
  );
};
