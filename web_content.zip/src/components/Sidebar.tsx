import React from 'react';
import { MessageSquarePlus, Settings, X, HelpCircle, Zap, ShieldCheck, Trash2, Camera, Monitor, LogOut, Download } from 'lucide-react';
import { cn } from '../utils/cn';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNewChat: () => void;
  onOpenSettings: () => void;
  onOpenSubscription: () => void;
  chatHistory?: { id: string; title: string }[];
  currentSessionId?: string;
  onSelectChat?: (id: string) => void;
  onDeleteChat?: (id: string) => void;
  userName?: string | null;
  userEmail?: string | null;
  onOpenLoginModal?: () => void;
  onLogout?: () => void;
  onOpenLiveCamera?: () => void;
  onOpenScreenShare?: () => void;
}

export function Sidebar({ 
  isOpen, 
  onClose, 
  onNewChat, 
  onOpenSettings, 
  onOpenSubscription,
  chatHistory = [],
  currentSessionId = '',
  onSelectChat,
  onDeleteChat,
  userName,
  userEmail,
  onOpenLoginModal,
  onLogout,
  onOpenLiveCamera,
  onOpenScreenShare
}: SidebarProps) {
  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-slate-300 transform transition-transform duration-300 ease-in-out md:relative md:translate-x-0 flex flex-col",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-white text-xl">
            <div className="w-8 h-8 bg-gradient-to-br from-orange-500 via-white to-green-500 rounded-lg flex items-center justify-center text-slate-900 text-xs shadow-lg">
              AI
            </div>
            Indian GPT
          </div>
          <button onClick={onClose} className="md:hidden p-1 hover:text-white">
            <X size={20} />
          </button>
        </div>

        <div className="p-3 space-y-2">
          <button 
            onClick={() => {
              onNewChat();
              if (window.innerWidth < 768) onClose();
            }}
            className="w-full flex items-center gap-3 px-4 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors border border-slate-700 font-medium"
          >
            <MessageSquarePlus size={18} />
            <span>New Chat</span>
          </button>

          <div className="grid grid-cols-2 gap-2 pt-1">
            {onOpenLiveCamera && (
              <button
                onClick={() => {
                  onOpenLiveCamera();
                  if (window.innerWidth < 768) onClose();
                }}
                className="flex items-center gap-2 px-2.5 py-2 bg-orange-950/40 hover:bg-orange-900/50 border border-orange-500/30 text-orange-300 rounded-xl text-xs font-semibold transition-all"
                title="Live Camera Vision"
              >
                <Camera size={14} className="text-orange-400 flex-shrink-0" />
                <span className="truncate">Camera</span>
              </button>
            )}

            {onOpenScreenShare && (
              <button
                onClick={() => {
                  onOpenScreenShare();
                  if (window.innerWidth < 768) onClose();
                }}
                className="flex items-center gap-2 px-2.5 py-2 bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 text-cyan-300 rounded-xl text-xs font-semibold transition-all"
                title="Live Screen Share"
              >
                <Monitor size={14} className="text-cyan-400 flex-shrink-0" />
                <span className="truncate">Screen</span>
              </button>
            )}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-3 py-2">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3 px-2">
            Recent
          </div>
          {chatHistory.length > 0 ? (
            <div className="space-y-1">
              {chatHistory.map((chat) => (
                <div 
                  key={chat.id}
                  className={cn(
                    "group flex items-center justify-between w-full px-3 py-2 rounded-lg text-sm transition-colors",
                    currentSessionId === chat.id 
                      ? "bg-slate-800 text-white" 
                      : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
                  )}
                >
                  <button 
                    className="flex-1 text-left truncate mr-2 outline-none"
                    onClick={() => onSelectChat && onSelectChat(chat.id)}
                  >
                    {chat.title}
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); onDeleteChat && onDeleteChat(chat.id); }}
                    className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 hover:bg-slate-700 rounded transition-all"
                    title="Delete Chat"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="px-2 py-8 text-center text-sm text-slate-600 italic">
              No recent chats
            </div>
          )}
        </div>

        <div className="p-3 border-t border-slate-800 space-y-2 bg-slate-950/40">
          <div className="p-2.5 rounded-xl bg-slate-800/90 border border-slate-700">
            <div className="flex items-center gap-2 mb-1.5">
              <svg viewBox="0 0 24 24" width="16" height="16" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0">
                <g transform="matrix(1, 0, 0, 1, 27.009001, -39.238998)">
                  <path fill="#4285F4" d="M -3.264 51.509 C -3.264 50.719 -3.334 49.969 -3.454 49.239 L -14.754 49.239 L -14.754 52.749 L -8.284 52.749 C -8.574 53.879 -9.254 54.819 -10.204 55.449 L -10.204 57.779 L -6.324 57.779 C -4.054 55.699 -2.764 52.569 -3.264 51.509 Z"/>
                  <path fill="#34A853" d="M -14.754 63.239 C -11.514 63.239 -8.804 62.159 -6.824 60.279 L -10.204 57.949 C -11.274 58.669 -12.654 59.109 -14.754 59.109 C -18.774 59.109 -22.174 56.459 -23.384 52.889 L -27.384 52.889 L -27.384 55.989 C -25.104 60.519 -20.274 63.239 -14.754 63.239 Z"/>
                  <path fill="#FBBC05" d="M -23.384 52.889 C -23.704 51.949 -23.884 50.949 -23.884 49.919 C -23.884 48.889 -23.704 47.889 -23.384 46.949 L -23.384 43.849 L -27.384 43.849 C -28.204 45.479 -28.664 47.319 -28.664 49.239 C -28.664 51.159 -28.204 52.999 -27.384 54.629 L -23.384 52.889 Z"/>
                  <path fill="#EA4335" d="M -14.754 40.739 C -12.984 40.739 -11.404 41.349 -10.154 42.539 L -6.744 39.129 C -8.844 37.169 -11.544 36.009 -14.754 36.009 C -20.274 36.009 -25.104 38.729 -27.384 43.259 L -23.384 46.359 C -22.174 42.789 -18.774 40.739 -14.754 40.739 Z"/>
                </g>
              </svg>
              <span className="text-xs font-bold text-white truncate">
                {userName || 'Google Account'}
              </span>
            </div>
            {userEmail ? (
              <p className="text-[11px] text-slate-400 truncate mb-2">
                {userEmail}
              </p>
            ) : (
              <p className="text-[11px] text-slate-400 mb-2">
                Gmail account connected nahi hai
              </p>
            )}

            <div className="flex gap-2">
              <button
                onClick={() => {
                  if (onOpenLoginModal) onOpenLoginModal();
                  if (window.innerWidth < 768) onClose();
                }}
                className="flex-1 py-1.5 px-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-[11px] font-bold transition-colors text-center shadow-sm"
              >
                {userEmail ? 'Switch Gmail' : 'Google Login'}
              </button>
              {onLogout && (
                <button
                  onClick={() => {
                    onLogout();
                    if (window.innerWidth < 768) onClose();
                  }}
                  className="py-1.5 px-2 bg-slate-700 hover:bg-red-600/80 text-slate-300 hover:text-white rounded-lg text-[11px] font-bold transition-colors flex items-center gap-1"
                  title="Logout"
                >
                  <LogOut size={12} />
                  <span>Logout</span>
                </button>
              )}
            </div>
          </div>

          <button 
            onClick={() => {
              onOpenSubscription();
              if (window.innerWidth < 768) onClose();
            }}
            className="w-full flex items-center gap-3 px-3 py-2 bg-gradient-to-r from-orange-500/20 to-red-500/20 hover:from-orange-500/30 hover:to-red-500/30 text-orange-400 font-medium rounded-lg transition-colors text-sm border border-orange-500/20"
          >
            <Zap size={16} />
            Upgrade to Pro
          </button>
          
          <button 
            onClick={() => {
              onOpenSettings();
              if (window.innerWidth < 768) onClose();
            }}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-slate-800 rounded-lg transition-colors text-sm"
          >
            <Settings size={16} />
            Settings
          </button>

          <button 
            onClick={() => {
              const event = new CustomEvent('open-my-plan');
              window.dispatchEvent(event);
              if (window.innerWidth < 768) onClose();
            }}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-slate-800 rounded-lg transition-colors text-sm"
          >
            <ShieldCheck size={16} />
            My Plan
          </button>

          <a 
            href="/api/download-apk"
            download="IndiaGPT-release.apk"
            className="w-full flex items-center gap-3 px-3 py-2 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 font-medium rounded-lg transition-colors text-sm border border-emerald-500/30"
          >
            <Download size={16} />
            Download Release APK
          </a>
        </div>
        
        <div className="p-4 text-[10px] text-slate-600 text-center uppercase tracking-widest opacity-50">
          Indian GPT • 2026
        </div>
      </div>
    </>
  );
}
