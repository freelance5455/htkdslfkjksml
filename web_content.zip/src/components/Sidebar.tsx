import React from 'react';
import { 
  BookOpen, 
  LayoutDashboard, 
  Scan, 
  HelpCircle, 
  Award, 
  Mic, 
  Users, 
  Settings,
  Sparkles,
  Bookmark,
  Building2,
  UserCheck,
  Camera,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import LearnIcon from './LearnIcon';
import NotificationBell from './NotificationBell';
import { Language, UserProfile } from '../types';
import { INDIAN_LANGUAGES } from '../presets';
import { ALL_SUPPORTED_LANGUAGES } from '../lib/translations';
import { Globe } from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setTab: (tab: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  onOpenSearch?: () => void;
  userProfile?: UserProfile;
  unreadNotificationsCount?: number;
  onOpenNotifications?: () => void;
  onOpenLanguageModal?: () => void;
}

export default function Sidebar({ 
  currentTab, 
  setTab, 
  language, 
  setLanguage, 
  onOpenSearch, 
  userProfile,
  unreadNotificationsCount = 0,
  onOpenNotifications,
  onOpenLanguageModal
}: SidebarProps) {
  const translations: Record<string, {
    brand: string;
    slogan: string;
    dashboard: string;
    scanner: string;
    classroom: string;
    examprep: string;
    homework: string;
    govthub: string;
    saved: string;
    profile: string;
  }> = {
    en: {
      brand: 'StudySkill AI',
      slogan: 'Scan books, listen to lectures, learn naturally',
      dashboard: 'Home Dashboard',
      classroom: 'AI Learning Hub',
      scanner: 'AI Book Scanner',
      homework: 'Homework Solver',
      examprep: 'Exam Center',
      govthub: 'Govt & Job Hub',
      saved: 'My Saved Content',
      profile: 'Profile & Settings'
    },
    bn: {
      brand: 'StudySkill AI',
      slogan: 'বই দেখুন, গল্প শুনুন, সহজে শিখুন',
      dashboard: 'হোম ড্যাশবোর্ড',
      classroom: 'এআই লার্নিং হাব',
      scanner: 'বই স্ক্যানার',
      homework: 'হোমওয়ার্ক সলভার',
      examprep: 'পরীক্ষা সেন্টার',
      govthub: 'চাকরি ও গভঃ হাব',
      saved: 'সংরক্ষিত বিষয়বস্তু',
      profile: 'প্রোফাইল ও সেটিংস'
    },
    hi: {
      brand: 'StudySkill AI',
      slogan: 'किताबें देखें, कहानियां सुनें, आसानी से सीखें',
      dashboard: 'होम डैशबोर्ड',
      classroom: 'एआई लर्निंग हब',
      scanner: 'बुक स्कैनर',
      homework: 'होमवर्क सॉल्वर',
      examprep: 'परीक्षा केंद्र',
      govthub: 'सरकारी नौकरी हब',
      saved: 'सेव की गई सामग्री',
      profile: 'प्रोफ़ाइल और सेटिंग्स'
    }
  };

  const t = translations[language] || translations['en'];

  const menuItems = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard, color: 'text-sky-400 bg-sky-500/10' },
    { id: 'classroom', label: t.classroom, isLearn: true, color: 'text-violet-400 bg-violet-500/10' },
    { id: 'scanner', label: t.scanner, icon: Scan, isScanner: true, badge: 'AI Vision', color: 'text-white bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 shadow-md shadow-indigo-500/40' },
    { id: 'homework', label: t.homework, icon: HelpCircle, color: 'text-amber-400 bg-amber-500/10' },
    { id: 'examprep', label: t.examprep, icon: Award, color: 'text-purple-400 bg-purple-500/10' },
    { id: 'govthub', label: t.govthub, icon: Building2, badge: 'Jobs', color: 'text-pink-400 bg-pink-500/10' },
    { id: 'saved', label: t.saved, icon: Bookmark, color: 'text-amber-300 bg-amber-500/10' },
    { id: 'profile', label: t.profile, icon: UserCheck, color: 'text-teal-400 bg-teal-500/10' },
  ];

  return (
    <aside className="w-72 bg-slate-950 text-slate-200 flex flex-col border-r border-slate-900 h-screen sticky top-0 shrink-0 hidden md:flex shadow-xl">
      {/* Brand Header */}
      <div className="p-6 border-b border-slate-900 flex flex-col gap-2 bg-gradient-to-b from-slate-900/50 to-transparent">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-tr from-indigo-500 via-purple-600 to-pink-500 text-white rounded-xl shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold font-display tracking-tight text-white flex items-center gap-1">
                <span>Study</span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">Skill</span>
                <span className="ml-1 px-1.5 py-0.5 text-[10px] font-black rounded-md bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-xs tracking-wider">AI</span>
              </h1>
              <span className="text-[9px] font-black text-indigo-400 tracking-wider uppercase block mt-0.5">
                ALL-IN-ONE LEARNING
              </span>
            </div>
          </div>

          {onOpenNotifications && (
            <NotificationBell
              unreadCount={unreadNotificationsCount}
              onClick={onOpenNotifications}
            />
          )}
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {menuItems.map((item) => {
          const isActive = currentTab === item.id;
          const isProfileItem = item.id === 'profile';
          return (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-wide transition-all duration-200 group relative cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`p-1.5 rounded-lg transition-colors ${
                  isActive ? 'bg-white/10 text-white' : item.color
                }`}>
                  {isProfileItem && userProfile?.photoUrl ? (
                    <img 
                      src={userProfile.photoUrl} 
                      alt={userProfile.name} 
                      className="w-4.5 h-4.5 rounded-md object-cover border border-slate-700 shadow-sm"
                    />
                  ) : item.isLearn ? (
                    <LearnIcon size={18} active={isActive} />
                  ) : item.icon ? (
                    <item.icon className={`w-4 h-4 ${isActive ? 'text-white' : ''}`} />
                  ) : null}
                </div>
                <span>{item.label}</span>
              </div>
              {item.badge && !isActive && (
                <span className="text-[8px] px-2 py-0.5 font-black rounded-full bg-slate-900 border border-indigo-500/30 text-indigo-400">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User Quick Profile Dock with Photo */}
      {userProfile && (
        <div className="p-3 mx-3 mb-2 bg-slate-900/80 hover:bg-slate-900 border border-slate-800 rounded-2xl transition-all">
          <button
            onClick={() => setTab('profile')}
            className="w-full flex items-center justify-between gap-3 text-left cursor-pointer group"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              {userProfile.photoUrl ? (
                <img
                  src={userProfile.photoUrl}
                  alt={userProfile.name}
                  className="w-8 h-8 rounded-xl object-cover border border-indigo-500/40 shrink-0 shadow-sm"
                />
              ) : (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white font-black text-xs flex items-center justify-center shrink-0 shadow-sm">
                  {userProfile.name ? userProfile.name.charAt(0).toUpperCase() : 'U'}
                </div>
              )}
              <div className="min-w-0 flex-1">
                <div className="text-xs font-bold text-white truncate flex items-center gap-1">
                  <span>{userProfile.name}</span>
                  {userProfile.role === 'admin' && (
                    <ShieldCheck className="w-3 h-3 text-amber-400 shrink-0" />
                  )}
                </div>
                <div className="text-[10px] text-slate-400 truncate">
                  {userProfile.targetExam || 'Student'}
                </div>
              </div>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition-colors shrink-0" />
          </button>
        </div>
      )}

      {/* Language Selector Footer */}
      <div className="p-4 border-t border-slate-900 bg-slate-950">
        <div className="flex flex-col gap-1.5">
          <label className="text-[9px] font-black text-indigo-400 uppercase tracking-widest px-1">
            {language === 'bn' ? 'ভাষা / Language' : language === 'hi' ? 'भाषा / Language' : 'Language'}
          </label>
          <button
            type="button"
            onClick={() => {
              if (onOpenLanguageModal) {
                onOpenLanguageModal();
              }
            }}
            className="w-full bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-indigo-500/50 text-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold shadow-md flex items-center justify-between transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-2 min-w-0">
              <Globe className="w-4 h-4 text-indigo-400 shrink-0 group-hover:rotate-12 transition-transform" />
              <div className="min-w-0 text-left">
                <span className="text-xs font-bold text-white block truncate">
                  {ALL_SUPPORTED_LANGUAGES.find(l => l.code === language)?.nativeName || 'Language'}
                </span>
                <span className="text-[10px] text-slate-400 block truncate">
                  {ALL_SUPPORTED_LANGUAGES.find(l => l.code === language)?.name || 'Select'}
                </span>
              </div>
            </div>
            <div className="px-2 py-0.5 rounded-md bg-indigo-600/20 border border-indigo-500/30 text-[10px] text-indigo-300 font-bold shrink-0">
              {language.toUpperCase()}
            </div>
          </button>
        </div>
      </div>
    </aside>
  );
}
