import React, { useState } from 'react';
import {
  Files,
  Gamepad2,
  LayoutTemplate,
  History,
  Settings,
  Plus,
  Trash2,
  Copy,
  Edit2,
  Upload,
  Volume2,
  Code,
  FileText,
  RotateCcw,
  Sliders,
  Check,
  X
} from 'lucide-react';
import { Project, ProjectFile, SupportedLanguage, EditorSettings } from '../types';
import { playSound } from '../utils/audio';
import { ProjectSnapshot } from '../utils/storage';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  activeFileId: string;
  onSelectFile: (fileId: string) => void;
  onCreateFile: (name: string, language: SupportedLanguage) => void;
  onDeleteFile: (fileId: string) => void;
  onRenameFile: (fileId: string, newName: string) => void;
  onDuplicateFile: (fileId: string) => void;
  onUploadFile: (file: File) => void;
  onInsertCodeSnippet: (code: string) => void;
  onLoadTemplate: (templateId: string) => void;
  revisions: ProjectSnapshot[];
  onRevertRevision: (snapshot: ProjectSnapshot) => void;
  settings: EditorSettings;
  onUpdateSettings: (settings: Partial<EditorSettings>) => void;
}

type SidebarTab = 'files' | 'games' | 'components' | 'history' | 'settings';

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  project,
  activeFileId,
  onSelectFile,
  onCreateFile,
  onDeleteFile,
  onRenameFile,
  onDuplicateFile,
  onUploadFile,
  onInsertCodeSnippet,
  onLoadTemplate,
  revisions,
  onRevertRevision,
  settings,
  onUpdateSettings,
}) => {
  const [activeTab, setActiveTab] = useState<SidebarTab>('files');
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [editingFileId, setEditingFileId] = useState<string | null>(null);
  const [editingFileName, setEditingFileName] = useState('');

  const getLanguageFromExt = (filename: string): SupportedLanguage => {
    const ext = filename.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'html': return 'html';
      case 'css': return 'css';
      case 'js': return 'javascript';
      case 'ts': return 'typescript';
      case 'py': return 'python';
      case 'java': return 'java';
      case 'cpp':
      case 'cc':
      case 'c': return 'cpp';
      case 'json': return 'json';
      default: return 'javascript';
    }
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;
    const lang = getLanguageFromExt(newFileName.trim());
    onCreateFile(newFileName.trim(), lang);
    setNewFileName('');
    setIsCreatingFile(false);
  };

  const handleRenameSubmit = (fileId: string) => {
    if (editingFileName.trim()) {
      onRenameFile(fileId, editingFileName.trim());
    }
    setEditingFileId(null);
  };

  const getFileBadge = (filename: string) => {
    const ext = filename.split('.').pop()?.toUpperCase() || 'TXT';
    const colorMap: Record<string, string> = {
      HTML: 'text-amber-400 border-amber-500/30 bg-amber-500/10',
      CSS: 'text-sky-400 border-sky-500/30 bg-sky-500/10',
      JS: 'text-yellow-400 border-yellow-500/30 bg-yellow-500/10',
      TS: 'text-blue-400 border-blue-500/30 bg-blue-500/10',
      PY: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10',
      JSON: 'text-purple-400 border-purple-500/30 bg-purple-500/10',
    };
    const style = colorMap[ext] || 'text-slate-400 border-slate-700 bg-slate-800';
    return (
      <span className={`text-[9px] font-mono font-bold px-1 py-0.2 rounded border ${style}`}>
        {ext}
      </span>
    );
  };

  // Pre-made UI snippets for Website Builder
  const websiteSnippets = [
    {
      name: 'Hero Banner Section',
      description: 'Clean responsive hero with gradient headline and CTA buttons',
      code: `
<section class="hero-section" style="text-align: center; padding: 60px 20px; background: #0f172a; border-radius: 12px; margin: 20px 0;">
  <span style="color: #00f0ff; font-weight: bold; font-size: 12px; letter-spacing: 2px;">NEXT-GEN PLATFORM</span>
  <h1 style="color: #fff; font-size: 36px; margin: 12px 0 16px;">Supercharge Your Digital Workflow</h1>
  <p style="color: #94a3b8; max-width: 500px; margin: 0 auto 24px; font-size: 15px;">Experience blazingly fast development with integrated tools and real-time previews.</p>
  <button style="background: #00f0ff; color: #000; font-weight: bold; border: none; padding: 12px 28px; border-radius: 8px; cursor: pointer;">Get Started Free</button>
</section>`,
    },
    {
      name: 'Interactive Counter Widget',
      description: 'Stateful JS counter with increment, decrement, and reset',
      code: `
<div class="counter-widget" style="background: #1e293b; padding: 24px; border-radius: 12px; max-width: 300px; text-align: center; margin: 20px auto; border: 1px solid #334155;">
  <h3 style="color: #f8fafc; margin-bottom: 12px; font-size: 16px;">Score Counter</h3>
  <div id="counterValue" style="font-size: 48px; font-weight: 800; color: #38bdf8; margin-bottom: 16px;">0</div>
  <div style="display: flex; gap: 8px; justify-content: center;">
    <button onclick="changeCount(-1)" style="background: #334155; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer;">-1</button>
    <button onclick="changeCount(0)" style="background: #475569; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer;">Reset</button>
    <button onclick="changeCount(1)" style="background: #0284c7; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer;">+1</button>
  </div>
</div>
<script>
let count = 0;
function changeCount(delta) {
  count = delta === 0 ? 0 : count + delta;
  document.getElementById('counterValue').textContent = count;
}
</script>`,
    },
    {
      name: 'Feature Card Grid',
      description: '3-column responsive card layout with neon hover borders',
      code: `
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin: 24px 0;">
  <div style="background: #111827; border: 1px solid #1e293b; border-radius: 10px; padding: 20px;">
    <div style="font-size: 24px; margin-bottom: 8px;">⚡</div>
    <h4 style="color: #fff; margin-bottom: 6px;">Instant Deploy</h4>
    <p style="color: #64748b; font-size: 13px;">Push to global edge networks in under 2 seconds.</p>
  </div>
  <div style="background: #111827; border: 1px solid #1e293b; border-radius: 10px; padding: 20px;">
    <div style="font-size: 24px; margin-bottom: 8px;">🛡️</div>
    <h4 style="color: #fff; margin-bottom: 6px;">Zero Config</h4>
    <p style="color: #64748b; font-size: 13px;">Works straight out of the box with zero runtime hassle.</p>
  </div>
  <div style="background: #111827; border: 1px solid #1e293b; border-radius: 10px; padding: 20px;">
    <div style="font-size: 24px; margin-bottom: 8px;">📊</div>
    <h4 style="color: #fff; margin-bottom: 6px;">Live Telemetry</h4>
    <p style="color: #64748b; font-size: 13px;">Monitor real-time error logging and execution metrics.</p>
  </div>
</div>`,
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-30 md:hidden"
        />
      )}

      <aside
        className={`${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        } ${
          !isOpen && 'md:hidden'
        } fixed md:static inset-y-0 left-0 w-72 bg-[#090d18] border-r border-slate-800 flex flex-col shrink-0 select-none z-40 md:z-20 h-full transition-transform duration-200 shadow-2xl md:shadow-none`}
      >
      {/* Top Sidebar Tab Selector Strip */}
      <div className="flex border-b border-slate-800 bg-[#070a14] px-1 py-1.5 justify-around">
        <button
          onClick={() => setActiveTab('files')}
          title="File Explorer"
          aria-label="File Explorer"
          className={`p-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
            activeTab === 'files' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Files className="w-4 h-4" />
          <span className="hidden sm:inline">Files</span>
        </button>

        <button
          onClick={() => setActiveTab('games')}
          title="2D Game Studio"
          aria-label="2D Game Studio"
          className={`p-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
            activeTab === 'games' ? 'bg-purple-500/20 text-purple-300' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Gamepad2 className="w-4 h-4" />
          <span className="hidden sm:inline">Games</span>
        </button>

        <button
          onClick={() => setActiveTab('components')}
          title="Website Builder Blocks"
          aria-label="Website Builder Blocks"
          className={`p-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
            activeTab === 'components' ? 'bg-emerald-500/20 text-emerald-300' : 'text-slate-400 hover:text-white'
          }`}
        >
          <LayoutTemplate className="w-4 h-4" />
          <span className="hidden sm:inline">UI</span>
        </button>

        <button
          onClick={() => setActiveTab('history')}
          title="Project Revisions"
          aria-label="Project Revisions"
          className={`p-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
            activeTab === 'history' ? 'bg-amber-500/20 text-amber-300' : 'text-slate-400 hover:text-white'
          }`}
        >
          <History className="w-4 h-4" />
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          title="Editor Settings"
          aria-label="Editor Settings"
          className={`p-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
            activeTab === 'settings' ? 'bg-blue-500/20 text-blue-300' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>

      {/* Tab Content Area */}
      <div className="flex-1 overflow-y-auto p-3 text-xs">
        {/* TAB 1: FILES EXPLORER */}
        {activeTab === 'files' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-slate-400 px-1">
              <span className="font-bold uppercase tracking-wider text-[11px]">WORKSPACE FILES</span>
              <div className="flex items-center gap-1">
                {/* Upload File button */}
                <label
                  title="Upload local file"
                  aria-label="Upload local file"
                  className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-400 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <input
                    type="file"
                    className="hidden"
                    onChange={e => {
                      if (e.target.files && e.target.files[0]) {
                        onUploadFile(e.target.files[0]);
                      }
                    }}
                  />
                </label>
                {/* New file button */}
                <button
                  onClick={() => setIsCreatingFile(true)}
                  title="New file"
                  aria-label="Create new file"
                  className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-400"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Create file inline input */}
            {isCreatingFile && (
              <form onSubmit={handleCreateSubmit} className="flex items-center gap-1 bg-[#111827] p-1.5 rounded-lg border border-cyan-500/40">
                <input
                  type="text"
                  autoFocus
                  placeholder="filename.js, style.css..."
                  value={newFileName}
                  onChange={e => setNewFileName(e.target.value)}
                  className="bg-transparent text-white text-xs w-full outline-hidden font-mono px-1"
                />
                <button type="submit" aria-label="Confirm new file" className="text-cyan-400 hover:text-cyan-300 p-0.5">
                  <Check className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  aria-label="Cancel new file"
                  onClick={() => setIsCreatingFile(false)}
                  className="text-slate-500 hover:text-slate-400 p-0.5"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </form>
            )}

            {/* Files list */}
            <div className="space-y-1">
              {project.files.map(file => {
                const isActive = file.id === activeFileId;
                const isEditing = editingFileId === file.id;

                return (
                  <div
                    key={file.id}
                    className={`group flex items-center justify-between px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-cyan-500/15 text-cyan-200 border border-cyan-500/30 font-semibold'
                        : 'text-slate-300 hover:bg-slate-800/80'
                    }`}
                    onClick={() => onSelectFile(file.id)}
                  >
                    <div className="flex items-center gap-2 truncate flex-1 mr-2">
                      {getFileBadge(file.name)}
                      {isEditing ? (
                        <input
                          type="text"
                          value={editingFileName}
                          autoFocus
                          onClick={e => e.stopPropagation()}
                          onChange={e => setEditingFileName(e.target.value)}
                          onKeyDown={e => {
                            if (e.key === 'Enter') handleRenameSubmit(file.id);
                            if (e.key === 'Escape') setEditingFileId(null);
                          }}
                          onBlur={() => handleRenameSubmit(file.id)}
                          className="bg-slate-900 text-white font-mono text-xs px-1.5 py-0.5 rounded border border-cyan-500/50 w-full outline-hidden"
                        />
                      ) : (
                        <span className="truncate font-mono text-xs">{file.name}</span>
                      )}
                    </div>

                    {/* File Actions on hover */}
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity" onClick={e => e.stopPropagation()}>
                      <button
                        onClick={() => {
                          setEditingFileId(file.id);
                          setEditingFileName(file.name);
                        }}
                        aria-label={`Rename ${file.name}`}
                        title="Rename"
                        className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-700"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => onDuplicateFile(file.id)}
                        aria-label={`Duplicate ${file.name}`}
                        title="Duplicate"
                        className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-700"
                      >
                        <Copy className="w-3 h-3" />
                      </button>
                      {project.files.length > 1 && (
                        <button
                          onClick={() => onDeleteFile(file.id)}
                          aria-label={`Delete ${file.name}`}
                          title="Delete file"
                          className="p-1 text-rose-400 hover:text-rose-300 rounded hover:bg-rose-950/40"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: 2D GAME STUDIO & AUDIO FX */}
        {activeTab === 'games' && (
          <div className="space-y-4">
            <div>
              <div className="font-bold uppercase tracking-wider text-[11px] text-purple-300 mb-2">
                GAME TEMPLATES
              </div>
              <div className="space-y-1.5">
                {[
                  { id: 'proj-cyber-shooter', name: 'Cyber Space Shooter', icon: '🚀' },
                  { id: 'proj-platformer', name: 'Neon Platformer Odyssey', icon: '🏃' },
                  { id: 'proj-tictactoe', name: 'Tic-Tac-Toe Minimax AI', icon: '❌' },
                  { id: 'proj-clicker', name: 'Cyberpunk Clicker Studio', icon: '⚡' },
                ].map(t => (
                  <button
                    key={t.id}
                    onClick={() => onLoadTemplate(t.id)}
                    className="w-full text-left p-2 rounded-lg bg-[#111827] hover:bg-purple-950/40 border border-slate-700/80 hover:border-purple-500/50 transition-all flex items-center gap-2.5 text-slate-200"
                  >
                    <span className="text-base">{t.icon}</span>
                    <span className="font-semibold text-xs truncate">{t.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="font-bold uppercase tracking-wider text-[11px] text-cyan-300 mb-2 flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5" />
                <span>RETRO AUDIO SYNTH FX</span>
              </div>
              <p className="text-[11px] text-slate-400 mb-2 leading-relaxed">
                Test and synthesize retro 8-bit sound effects via Web Audio API:
              </p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { type: 'laser', label: 'Laser Blast' },
                  { type: 'jump', label: 'Platform Jump' },
                  { type: 'coin', label: 'Coin Collect' },
                  { type: 'explosion', label: 'Explosion' },
                  { type: 'powerup', label: 'Power-Up' },
                  { type: 'hit', label: 'Damage Hit' },
                ].map(sfx => (
                  <button
                    key={sfx.type}
                    onClick={() => playSound(sfx.type as any)}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-[11px] font-mono flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>▶</span>
                    <span>{sfx.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: WEBSITE BUILDER COMPONENTS */}
        {activeTab === 'components' && (
          <div className="space-y-3">
            <div className="font-bold uppercase tracking-wider text-[11px] text-emerald-300 mb-1">
              UI CODE SNIPPETS
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Click to insert clean, modern responsive components into the active file:
            </p>
            <div className="space-y-2 mt-2">
              {websiteSnippets.map((snippet, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-lg bg-[#111827] border border-slate-700/80 hover:border-emerald-500/50 transition-all"
                >
                  <div className="font-bold text-xs text-slate-200 mb-1">{snippet.name}</div>
                  <div className="text-[11px] text-slate-400 mb-2">{snippet.description}</div>
                  <button
                    onClick={() => onInsertCodeSnippet(snippet.code)}
                    className="w-full py-1.5 px-3 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 font-semibold text-xs border border-emerald-500/30 transition-colors flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Insert into File</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: REVISIONS & SNAPSHOTS */}
        {activeTab === 'history' && (
          <div className="space-y-3">
            <div className="font-bold uppercase tracking-wider text-[11px] text-amber-300">
              PROJECT REVISIONS ({revisions.length})
            </div>
            {revisions.length === 0 ? (
              <div className="p-4 text-center text-slate-500 text-xs">
                No revisions yet. Changes are automatically captured when editing code.
              </div>
            ) : (
              <div className="space-y-2">
                {revisions.map(rev => (
                  <div
                    key={rev.id}
                    className="p-2.5 rounded-lg bg-[#111827] border border-slate-700/80 flex flex-col gap-1.5"
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-xs text-white">{rev.label}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(rev.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {rev.files.length} files saved
                    </div>
                    <button
                      onClick={() => onRevertRevision(rev)}
                      className="mt-1 py-1 px-2.5 rounded bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 font-medium text-[11px] border border-amber-500/30 flex items-center justify-center gap-1 transition-colors"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Revert to this version</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 5: SETTINGS */}
        {activeTab === 'settings' && (
          <div className="space-y-4">
            <div className="font-bold uppercase tracking-wider text-[11px] text-blue-300">
              EDITOR PREFERENCES
            </div>

            <div className="space-y-3">
              {/* Font Size */}
              <div>
                <label className="text-slate-300 font-medium block mb-1">
                  Font Size ({settings.fontSize}px)
                </label>
                <input
                  type="range"
                  min="11"
                  max="22"
                  value={settings.fontSize}
                  onChange={e => onUpdateSettings({ fontSize: parseInt(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>

              {/* Tab Size */}
              <div>
                <label className="text-slate-300 font-medium block mb-1">Tab Spacing</label>
                <div className="flex gap-2">
                  {[2, 4].map(size => (
                    <button
                      key={size}
                      onClick={() => onUpdateSettings({ tabSize: size })}
                      className={`flex-1 py-1.5 rounded text-xs font-semibold ${
                        settings.tabSize === size
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {size} spaces
                    </button>
                  ))}
                </div>
              </div>

              {/* Line Numbers Toggle */}
              <div className="flex items-center justify-between py-1">
                <span className="text-slate-300">Line Numbers</span>
                <input
                  type="checkbox"
                  checked={settings.lineNumbers}
                  onChange={e => onUpdateSettings({ lineNumbers: e.target.checked })}
                  className="rounded accent-cyan-400 w-4 h-4"
                />
              </div>

              {/* Auto Run on Change */}
              <div className="flex items-center justify-between py-1">
                <span className="text-slate-300">Auto-Run on Change</span>
                <input
                  type="checkbox"
                  checked={settings.autoRunOnChange}
                  onChange={e => onUpdateSettings({ autoRunOnChange: e.target.checked })}
                  className="rounded accent-cyan-400 w-4 h-4"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
    </>
  );
};
