import { useEffect, useMemo, useState } from "react";
import { useStore } from "../lib/store";
import { download } from "../lib/workspace";
import { Button, Dialog, Icon, IconButton, Sheet } from "./ui";
import { cn } from "../utils/cn";
import type { TabKey } from "../lib/types";

export default function Sidebar({
  open,
  onClose,
  onWorkspace,
  onSettings,
  onSearch,
}: {
  open: boolean;
  onClose: () => void;
  onWorkspace: () => void;
  onSettings: (section?: string) => void;
  onSearch: () => void;
}) {
  const {
    s,
    set,
    newSession,
    selectSession,
    renameSession,
    pinSession,
    deleteSession,
    showToast,
  } = useStore();
  const [targetId, setTargetId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [desktop, setDesktop] = useState(() => window.innerWidth >= 768);
  useEffect(() => {
    const mq = matchMedia("(min-width: 768px)");
    const apply = () => setDesktop(mq.matches);
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);
  const target = s.sessions.find((session) => session.id === targetId);
  const sessions = useMemo(
    () =>
      [...s.sessions].sort(
        (a, b) =>
          Number(!!b.pinned) - Number(!!a.pinned) || b.updatedAt - a.updatedAt,
      ),
    [s.sessions],
  );
  const navigate = (tab: TabKey) => {
    set({ view: tab });
    onClose();
  };
  const nav = [
    { key: "chat", icon: "sparkles", label: "Workspace" },
    { key: "files", icon: "folder", label: "File explorer" },
    { key: "preview", icon: "play", label: "Live preview" },
    { key: "changes", icon: "changes", label: "Changes" },
    { key: "run", icon: "terminal", label: "Console" },
  ] as const;

  return (
    <>
      {open && (
        <button
          aria-label="Close sidebar"
          onClick={onClose}
          className="anim-fade fixed inset-0 z-30 bg-black/60 md:hidden"
        />
      )}
      <div className="nav-rail hidden w-[65px] shrink-0 flex-col items-center gap-3 py-5 md:flex">
        <button
          aria-label="Workspace"
          title="Workspace"
          onClick={() => navigate("chat")}
          className={cn("rail-button", s.view === "chat" && "active")}
        >
          <Icon name="sparkles" className="h-5 w-5" />
        </button>
        <button
          aria-label="File explorer"
          title="File explorer"
          onClick={() => navigate("files")}
          className={cn(
            "rail-button",
            (s.view === "files" || s.view === "code") && "active",
          )}
        >
          <Icon name="folder" className="h-5 w-5" />
        </button>
        <button
          aria-label="Browser preview"
          title="Browser preview"
          onClick={() => navigate("preview")}
          className={cn("rail-button", s.view === "preview" && "active")}
        >
          <Icon name="play" className="h-5 w-5" />
        </button>
        <button
          aria-label="Models and providers"
          title="Models and providers"
          onClick={() => onSettings("providers")}
          className="rail-button"
        >
          <Icon name="layers" className="h-5 w-5" />
        </button>
        <div className="my-1 h-px w-6 bg-line" />
        <button
          aria-label="Quick switch"
          title="Quick switch"
          onClick={onSearch}
          className="rail-button"
        >
          <Icon name="search" className="h-5 w-5" />
        </button>
        <div className="flex-1" />
        <button
          aria-label="Settings"
          title="Settings"
          onClick={() => onSettings()}
          className="rail-button"
        >
          <Icon name="settings" className="h-5 w-5" />
        </button>
        <button
          aria-label="Toggle color theme"
          title="Toggle color theme"
          onClick={() => set({ theme: s.theme === "dark" ? "light" : "dark" })}
          className="rail-button"
        >
          <Icon
            name={s.theme === "dark" ? "sun" : "moon"}
            className="h-5 w-5"
          />
        </button>
      </div>
      <aside
        aria-label="Main navigation"
        aria-hidden={!desktop && !open}
        inert={!desktop && !open}
        className={cn(
          "fixed inset-y-0 left-0 z-30 flex w-[278px] shrink-0 flex-col border-r border-line bg-bg transition-transform duration-200 md:static md:z-auto md:w-[204px] md:translate-x-0 lg:w-[215px]",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex h-[61px] shrink-0 items-center gap-2 px-4">
          <span className="text-[11px] font-semibold">Your workspace</span>
          <IconButton
            name="dots"
            label="Workspace options"
            onClick={onWorkspace}
            className="ml-auto h-7 w-7"
          />
          <IconButton
            name="close"
            label="Close navigation"
            onClick={onClose}
            className="-mr-2 h-7 w-7 md:hidden"
          />
        </div>
        <div className="px-3.5">
          <button
            onClick={onWorkspace}
            className="tap flex w-full items-center gap-2.5 rounded-xl border border-line bg-bg px-3 py-3 text-left hover:border-line2"
          >
            <Icon name="folder" className="h-[18px] w-[18px] text-accent" />
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[13px] font-medium">
                {s.workspacePath}
              </span>
              <span className="mt-0.5 block text-[10px] text-muted">
                {s.workspaceMode === "device"
                  ? "Device workspace"
                  : s.workspaceMode === "imported"
                    ? "Imported workspace"
                    : "Local workspace"}
              </span>
            </span>
            <Icon name="chevronDown" className="h-3.5 w-3.5 text-muted" />
          </button>
          <button
            onClick={() => {
              newSession();
              onClose();
            }}
            className="tap tactile-control mt-3 flex h-10 w-full items-center gap-2 rounded-[10px] border border-line2 bg-surface px-3 text-[11px] font-medium text-accent hover:bg-accentsoft"
          >
            <Icon name="plus" className="h-[17px] w-[17px]" />
            New session
            <span className="ml-auto hidden font-mono text-[10px] opacity-60 lg:block">
              Ctrl N
            </span>
          </button>
        </div>
        <nav className="mt-4 space-y-1 px-3.5">
          {nav.map((item) => (
            <button
              key={item.key}
              onClick={() => navigate(item.key)}
              className={cn(
                "tap flex h-10 w-full items-center gap-3 rounded-lg px-3 text-[13px] hover:bg-surface2",
                s.view === item.key ||
                  (item.key === "files" && s.view === "code")
                  ? "bg-surface2 font-medium text-fg"
                  : "text-muted",
              )}
            >
              <Icon
                name={item.icon}
                className={cn(
                  "h-[17px] w-[17px]",
                  s.view === item.key && "text-accent",
                )}
              />
              {item.label}
              {item.key === "changes" &&
                s.changes.filter((c) => !c.undone).length > 0 && (
                  <span className="ml-auto text-[11px] text-accent">
                    {s.changes.filter((c) => !c.undone).length}
                  </span>
                )}
            </button>
          ))}
        </nav>
        <div className="mx-5 mt-6 flex items-center justify-between text-[10px] font-medium uppercase tracking-[.12em] text-muted">
          <span>Recent sessions</span>
          <button
            aria-label="Search sessions"
            onClick={onSearch}
            className="p-1 hover:text-fg"
          >
            <Icon name="search" className="h-3.5 w-3.5" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-3.5 pt-2">
          {sessions.map((session) => (
            <div
              key={session.id}
              className={cn(
                "group flex items-center rounded-lg hover:bg-surface2",
                s.activeSessionId === session.id && "active",
              )}
            >
              <button
                className="flex min-w-0 flex-1 items-center gap-2.5 px-3 py-2.5 text-left"
                onClick={() => {
                  selectSession(session.id);
                  onClose();
                }}
              >
                <Icon
                  name={session.pinned ? "pin" : "chat"}
                  className="h-3.5 w-3.5 text-muted"
                />
                <span className="truncate text-[12px] text-muted group-hover:text-fg">
                  {session.title}
                </span>
              </button>
              <button
                aria-label={`Manage ${session.title}`}
                onClick={() => {
                  setTargetId(session.id);
                  setName(session.title);
                }}
                className="mr-1 grid h-8 w-7 place-items-center text-muted opacity-100 hover:text-fg md:opacity-0 md:group-hover:opacity-100 md:focus:opacity-100"
              >
                <Icon name="dots" className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
        <div className="mx-4 border-t border-line py-4">
          <button
            onClick={() => {
              onSettings("providers");
              onClose();
            }}
            className="flex w-full items-center gap-2.5 rounded-lg px-1 py-2 text-left hover:text-accent"
          >
            <Icon name="key" className="h-[17px] w-[17px] text-accent" />
            <span className="flex-1 text-[12px]">
              {s.providers[s.activeProvider]?.apiKey ||
              s.providers[s.activeProvider]?.allowNoKey
                ? "Manage your models"
                : "Connect your model"}
            </span>
            <Icon name="arrowUpRight" className="h-3.5 w-3.5 text-muted" />
          </button>
          <button
            onClick={() => {
              onSettings();
              onClose();
            }}
            className="mt-1 flex w-full items-center gap-2.5 rounded-lg px-1 py-2 text-left text-muted hover:text-fg"
          >
            <Icon name="settings" className="h-[17px] w-[17px]" />
            <span className="flex-1 text-[12px]">Settings</span>
            <span className="font-mono text-[10px]">v3.0</span>
          </button>
        </div>
        <div className="flex items-center gap-2 border-t border-line px-5 py-3 text-[10px] text-muted">
          <Icon name="shield" className="h-3 w-3" />
          <span>Local-first. Yours, always.</span>
          <span className="ml-auto h-1.5 w-1.5 rounded-full bg-ok" />
        </div>
      </aside>
      <Sheet
        open={!!target && !confirm}
        onClose={() => setTargetId(null)}
        title="Session options"
        subtitle={target?.title}
      >
        <div className="space-y-4 px-5 pb-5">
          <label className="block text-xs text-muted">
            Session name
            <input
              aria-label="Session name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-2 h-11 w-full rounded-xl border border-line bg-surface2 px-3 text-sm text-fg outline-none focus:border-accent"
            />
          </label>
          <Button
            block
            variant="primary"
            onClick={() => {
              renameSession(targetId!, name);
              setTargetId(null);
              showToast("Session renamed.");
            }}
          >
            Save name
          </Button>
          <div className="border-t border-line pt-2">
            <SessionAction
              icon="pin"
              text={target?.pinned ? "Unpin session" : "Pin session"}
              onClick={() => {
                pinSession(targetId!);
                setTargetId(null);
              }}
            />
            <SessionAction
              icon="download"
              text="Export conversation"
              onClick={() => {
                if (target)
                  download(
                    `# ${target.title}\n\n${target.messages.map((m) => `## ${m.role === "user" ? "You" : "TopeCode"}\n\n${m.content}`).join("\n\n")}`,
                    "topecode-conversation.md",
                  );
                setTargetId(null);
              }}
            />
            <SessionAction
              icon="trash"
              text="Delete session"
              danger
              onClick={() => setConfirm(true)}
            />
          </div>
        </div>
      </Sheet>
      <Dialog
        open={confirm}
        title="Delete this session?"
        body="This removes the conversation from this browser. Your workspace files will not be affected."
        confirmLabel="Delete session"
        cancelLabel="Keep session"
        danger
        onCancel={() => setConfirm(false)}
        onConfirm={() => {
          deleteSession(targetId!);
          setConfirm(false);
          setTargetId(null);
          showToast("Session deleted.");
        }}
      />
    </>
  );
}

function SessionAction({
  icon,
  text,
  onClick,
  danger,
}: {
  icon: string;
  text: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3 rounded-lg px-2 py-3 text-left text-sm hover:bg-surface2",
        danger && "text-danger",
      )}
    >
      <Icon name={icon} className="h-[17px] w-[17px]" />
      {text}
    </button>
  );
}
