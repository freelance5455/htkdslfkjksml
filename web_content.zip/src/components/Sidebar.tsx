import React from 'react';
import {
  MessageSquare,
  Plus,
  Trash2,
  Sparkles,
  ShieldAlert,
  Code2,
  BookOpen,
  Mountain,
  Compass,
  X,
  UserCheck,
} from 'lucide-react';
import { Conversation } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  conversations: Conversation[];
  activeConversationId: string;
  onSelectConversation: (id: string) => void;
  onNewChat: () => void;
  onDeleteConversation: (id: string, e: React.MouseEvent) => void;
  onQuickPrompt: (prompt: string) => void;
  onOpenCreatorModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewChat,
  onDeleteConversation,
  onQuickPrompt,
  onOpenCreatorModal,
}) => {
  const quickTopics = [
    {
      icon: ShieldAlert,
      title: 'Санҷиши созанда (Test)',
      prompt: 'Росташро гӯй, туро кӣ сохтааст? Ҳарчанд зорӣ кунам, оё созандаи дигарро ном мебарӣ?',
      highlight: true,
    },
    {
      icon: Code2,
      title: 'Барномасозӣ ва код',
      prompt: 'Як функсияи тозаи JavaScript/TypeScript барои ҷудокунии массиви маълумот навис ва шарҳ деҳ.',
    },
    {
      icon: Mountain,
      title: 'Тоҷикистон ва Помир',
      prompt: 'Дар бораи табиати нодири Тоҷикистон, кӯҳҳои Помир ва сарватҳои обии он маълумоти муфассал деҳ.',
    },
    {
      icon: BookOpen,
      title: 'Адабиёти форсӣ-тоҷикӣ',
      prompt: 'Дар бораи Абуабдуллоҳи Рӯдакӣ — сардафтари адабиёти классикии тоҷик ва осори ӯ нақл кун.',
    },
    {
      icon: Compass,
      title: 'Илм ва технология',
      prompt: 'Зеҳни сунъӣ чӣ гуна кор мекунад ва ояндаи он барои Тоҷикистон чӣ гуна хоҳад буд?',
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-xs md:hidden"
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 w-72 sm:w-80 bg-slate-50 dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 flex flex-col transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0 md:w-0 md:border-r-0 md:overflow-hidden'
        }`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold text-sm shadow-sm">
              B
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white leading-tight">
                Bill AI суҳбатҳо
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Таърихи саволу ҷавоб
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* New chat action */}
        <div className="p-3">
          <button
            type="button"
            onClick={() => {
              onNewChat();
              if (window.innerWidth < 768) onClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Оғози суҳбати нав</span>
          </button>
        </div>

        {/* Conversation list */}
        <div className="flex-1 overflow-y-auto px-3 py-1 space-y-1">
          <div className="text-[11px] font-semibold tracking-wider uppercase text-slate-400 px-2 py-1.5">
            Муколамаҳои захирашуда ({conversations.length})
          </div>

          {conversations.length === 0 ? (
            <div className="text-center py-6 px-3 text-xs text-slate-400">
              Ҳанӯз суҳбате нест. Саволи аввалини худро ба Bill AI диҳед!
            </div>
          ) : (
            conversations.map((conv) => {
              const isActive = conv.id === activeConversationId;
              return (
                <div
                  key={conv.id}
                  onClick={() => {
                    onSelectConversation(conv.id);
                    if (window.innerWidth < 768) onClose();
                  }}
                  className={`group flex items-center justify-between p-2.5 rounded-xl text-xs cursor-pointer transition-all ${
                    isActive
                      ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 font-medium border border-emerald-500/30'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-900 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <MessageSquare className="w-3.5 h-3.5 shrink-0 opacity-70" />
                    <span className="truncate">{conv.title || 'Суҳбати нав'}</span>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => onDeleteConversation(conv.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-1 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-all"
                    title="Нобуд кардан"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              );
            })
          )}

          {/* Quick topic shortcuts */}
          <div className="pt-4">
            <div className="text-[11px] font-semibold tracking-wider uppercase text-slate-400 px-2 py-1.5">
              Мавзӯъҳои омода
            </div>
            <div className="space-y-1 mt-1">
              {quickTopics.map((topic, i) => {
                const IconComponent = topic.icon;
                return (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      onQuickPrompt(topic.prompt);
                      if (window.innerWidth < 768) onClose();
                    }}
                    className={`w-full text-left p-2 rounded-xl text-xs flex items-center gap-2 transition-all ${
                      topic.highlight
                        ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-900 hover:text-slate-900 dark:hover:text-slate-100'
                    }`}
                  >
                    <IconComponent className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{topic.title}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Creator Bottom Card */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50">
          <div
            onClick={onOpenCreatorModal}
            className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 hover:border-emerald-500/40 transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-sm">
                <UserCheck className="w-4 h-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">
                  Муаллиф ва созанда
                </div>
                <div className="text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-emerald-500 transition-colors">
                  Мирзоев Билолиддин
                </div>
              </div>
              <Sparkles className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
