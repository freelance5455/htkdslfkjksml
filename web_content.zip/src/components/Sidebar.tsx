import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  MessageSquare,
  Plus,
  Trash2,
  Pin,
  PinOff,
  Edit2,
  Check,
  X,
  FileDown,
  Search,
  HardDrive,
  Settings,
  Shield,
  Sparkles,
  ChevronRight,
  MoreVertical,
  AlertTriangle,
} from 'lucide-react';
import { ChatSession, StorageStats } from '../types/index.ts';

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  storageStats: StorageStats;
  isOpen: boolean;
  onClose: () => void;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onTogglePinSession: (id: string) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  onExportSession: (session: ChatSession) => void;
  onOpenStorage: () => void;
  onOpenSettings: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  currentSessionId,
  storageStats,
  isOpen,
  onClose,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onTogglePinSession,
  onRenameSession,
  onExportSession,
  onOpenStorage,
  onOpenSettings,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [sessionToDelete, setSessionToDelete] = useState<ChatSession | null>(null);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const filteredSessions = useMemo(() => {
    if (!searchQuery.trim()) return sessions;
    const q = searchQuery.toLowerCase();
    return sessions.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.messages.some((m) => m.content.toLowerCase().includes(q))
    );
  }, [sessions, searchQuery]);

  const pinnedSessions = useMemo(
    () => filteredSessions.filter((s) => s.pinned),
    [filteredSessions]
  );
  const unpinnedSessions = useMemo(
    () => filteredSessions.filter((s) => !s.pinned),
    [filteredSessions]
  );

  const startEditing = (s: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(s.id);
    setEditTitle(s.title);
    setActiveMenuId(null);
  };

  const saveEditing = (id: string, e: React.MouseEvent | React.FormEvent) => {
    e.stopPropagation();
    if (editTitle.trim()) {
      onRenameSession(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const cancelEditing = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
  };

  const formatStorageBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-30 lg:hidden"
        />
      )}

      {/* Safety Confirmation Modal: Delete Session */}
      {sessionToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl p-5 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-950 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0 mt-0.5">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">Hapus Percakapan Ini?</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Tindakan ini tidak dapat dibatalkan.
                </p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
              <span className="text-slate-400 text-[10px] uppercase font-mono tracking-wider block">
                Judul Percakapan:
              </span>
              <p className="font-semibold text-slate-100 truncate">{sessionToDelete.title}</p>
              <p className="text-[11px] text-slate-400">
                {sessionToDelete.messages.length} pesan di dalamnya akan terhapus secara permanen dari browser lokal Anda.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setSessionToDelete(null)}
                className="px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteSession(sessionToDelete.id);
                  setSessionToDelete(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-medium bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/30 transition cursor-pointer"
              >
                Ya, Hapus Sesi
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed lg:static top-0 bottom-0 left-0 z-40 w-72 bg-slate-900 border-r border-slate-800 flex flex-col transition-transform duration-200 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Top: New Chat button */}
        <div className="p-3.5 border-b border-slate-800 flex flex-col gap-2.5">
          <button
            onClick={() => {
              onNewSession();
              if (window.innerWidth < 1024) onClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-medium text-sm shadow-md shadow-indigo-600/25 transition active:scale-[0.99] cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Percakapan Baru</span>
          </button>

          {/* Quick Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari obrolan..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700/50 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500/80 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Middle: Sessions List */}
        <div className="flex-1 overflow-y-auto px-2 py-2 space-y-4">
          {/* Pinned section */}
          {pinnedSessions.length > 0 && (
            <div>
              <div className="px-2 mb-1.5 flex items-center gap-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                <Pin className="w-3 h-3 text-amber-400" />
                <span>Disematkan</span>
              </div>
              <div className="space-y-1">
                {pinnedSessions.map((session) => (
                  <SessionItem
                    key={session.id}
                    session={session}
                    isSelected={session.id === currentSessionId}
                    isEditing={editingId === session.id}
                    editTitle={editTitle}
                    setEditTitle={setEditTitle}
                    isMenuOpen={activeMenuId === session.id}
                    onToggleMenu={(e) => {
                      e.stopPropagation();
                      setActiveMenuId((prev) => (prev === session.id ? null : session.id));
                    }}
                    onCloseMenu={() => setActiveMenuId(null)}
                    onSelect={() => {
                      onSelectSession(session.id);
                      if (window.innerWidth < 1024) onClose();
                    }}
                    onStartEdit={(e) => startEditing(session, e)}
                    onSaveEdit={(e) => saveEditing(session.id, e)}
                    onCancelEdit={cancelEditing}
                    onTogglePin={(e) => {
                      e.stopPropagation();
                      onTogglePinSession(session.id);
                      setActiveMenuId(null);
                    }}
                    onExport={(e) => {
                      e.stopPropagation();
                      onExportSession(session);
                      setActiveMenuId(null);
                    }}
                    onRequestDelete={(e) => {
                      e.stopPropagation();
                      setSessionToDelete(session);
                      setActiveMenuId(null);
                    }}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Regular sessions */}
          <div>
            {pinnedSessions.length > 0 && (
              <div className="px-2 mb-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Riwayat Percakapan
              </div>
            )}

            {unpinnedSessions.length === 0 && pinnedSessions.length === 0 ? (
              <div className="px-4 py-8 text-center text-slate-400 text-xs">
                {searchQuery ? (
                  <p>Tidak ada percakapan yang cocok dengan pencarian.</p>
                ) : (
                  <div>
                    <MessageSquare className="w-8 h-8 text-slate-400 mx-auto mb-2 opacity-50" />
                    <p className="font-medium text-slate-400">Belum ada obrolan</p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Mulai percakapan baru sekarang
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-1">
                {unpinnedSessions.map((session) => (
                  <SessionItem
                    key={session.id}
                    session={session}
                    isSelected={session.id === currentSessionId}
                    isEditing={editingId === session.id}
                    editTitle={editTitle}
                    setEditTitle={setEditTitle}
                    isMenuOpen={activeMenuId === session.id}
                    onToggleMenu={(e) => {
                      e.stopPropagation();
                      setActiveMenuId((prev) => (prev === session.id ? null : session.id));
                    }}
                    onCloseMenu={() => setActiveMenuId(null)}
                    onSelect={() => {
                      onSelectSession(session.id);
                      if (window.innerWidth < 1024) onClose();
                    }}
                    onStartEdit={(e) => startEditing(session, e)}
                    onSaveEdit={(e) => saveEditing(session.id, e)}
                    onCancelEdit={cancelEditing}
                    onTogglePin={(e) => {
                      e.stopPropagation();
                      onTogglePinSession(session.id);
                      setActiveMenuId(null);
                    }}
                    onExport={(e) => {
                      e.stopPropagation();
                      onExportSession(session);
                      setActiveMenuId(null);
                    }}
                    onRequestDelete={(e) => {
                      e.stopPropagation();
                      setSessionToDelete(session);
                      setActiveMenuId(null);
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Bottom: Storage footprint & privacy banner */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/60 flex flex-col gap-2">
          {/* Local Storage Indicator */}
          <div
            onClick={onOpenStorage}
            className="flex items-center justify-between p-2 rounded-xl bg-slate-800/40 hover:bg-slate-800 border border-slate-800/80 text-xs text-slate-300 transition cursor-pointer group"
          >
            <div className="flex items-center gap-2">
              <HardDrive className="w-3.5 h-3.5 text-sky-400 group-hover:scale-110 transition" />
              <span>Memori Browser</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-400 font-mono text-[11px]">
              <span>{formatStorageBytes(storageStats.totalBytes)}</span>
              <ChevronRight className="w-3 h-3" />
            </div>
          </div>

          {/* Quick buttons */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={onOpenSettings}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 text-xs text-slate-300 hover:text-white border border-slate-700/40 transition cursor-pointer"
            >
              <Settings className="w-3 h-3 text-indigo-400" />
              <span>Pengaturan</span>
            </button>
            <button
              onClick={onOpenStorage}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg bg-slate-800/60 hover:bg-slate-800 text-xs text-slate-300 hover:text-white border border-slate-700/40 transition cursor-pointer"
            >
              <Shield className="w-3 h-3 text-emerald-400" />
              <span>Privasi Lokal</span>
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};

interface SessionItemProps {
  session: ChatSession;
  isSelected: boolean;
  isEditing: boolean;
  editTitle: string;
  setEditTitle: (val: string) => void;
  isMenuOpen: boolean;
  onToggleMenu: (e: React.MouseEvent) => void;
  onCloseMenu: () => void;
  onSelect: () => void;
  onStartEdit: (e: React.MouseEvent) => void;
  onSaveEdit: (e: React.MouseEvent | React.FormEvent) => void;
  onCancelEdit: (e: React.MouseEvent) => void;
  onTogglePin: (e: React.MouseEvent) => void;
  onExport: (e: React.MouseEvent) => void;
  onRequestDelete: (e: React.MouseEvent) => void;
}

const SessionItem: React.FC<SessionItemProps> = ({
  session,
  isSelected,
  isEditing,
  editTitle,
  setEditTitle,
  isMenuOpen,
  onToggleMenu,
  onCloseMenu,
  onSelect,
  onStartEdit,
  onSaveEdit,
  onCancelEdit,
  onTogglePin,
  onExport,
  onRequestDelete,
}) => {
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu on click outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onCloseMenu();
      }
    };
    if (isMenuOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [isMenuOpen, onCloseMenu]);

  return (
    <div
      className={`group relative flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs transition ${
        isSelected
          ? 'bg-indigo-600/20 text-white border border-indigo-500/40 font-medium'
          : 'text-slate-300 hover:bg-slate-800/70 hover:text-white border border-transparent'
      }`}
    >
      {/* Clickable Area: Title and Message count (Guaranteed safe from delete triggers) */}
      <div
        onClick={onSelect}
        className="flex items-center gap-2.5 min-w-0 flex-1 mr-1 py-1 cursor-pointer select-none"
      >
        <MessageSquare
          className={`w-3.5 h-3.5 shrink-0 ${
            isSelected ? 'text-indigo-400' : 'text-slate-400 group-hover:text-slate-300'
          }`}
        />

        {isEditing ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onSaveEdit(e);
            }}
            className="flex items-center gap-1 w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <input
              type="text"
              autoFocus
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              className="w-full bg-slate-950 px-2 py-0.5 rounded border border-indigo-500 text-xs text-white focus:outline-none"
            />
            <button
              type="button"
              onClick={onSaveEdit}
              className="p-1 hover:text-emerald-400 text-slate-400 cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={onCancelEdit}
              className="p-1 hover:text-rose-400 text-slate-400 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </form>
        ) : (
          <div className="truncate min-w-0">
            <div className="truncate font-medium leading-snug">{session.title}</div>
            <div className="text-[10px] text-slate-400 font-normal">
              {session.messages.length} pesan
            </div>
          </div>
        )}
      </div>

      {/* Action Area: Dedicated 3-Dots Menu (Safe & Consistent across mobile and desktop) */}
      {!isEditing && (
        <div className="flex items-center gap-1 shrink-0 ml-1" ref={menuRef}>
          {/* Pinned visual indicator if pinned */}
          {session.pinned && (
            <Pin className="w-3 h-3 text-amber-400 shrink-0 opacity-80 mr-0.5" />
          )}

          {/* 3-Dots Menu Button: Safe, isolated hit area, never shifts under clicks */}
          <div className="relative">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleMenu(e);
              }}
              title="Pilihan Sesi (Pin, Edit, Simpan, Hapus)"
              aria-label="Pilihan Sesi"
              className={`p-1.5 rounded-lg transition cursor-pointer flex items-center justify-center ${
                isMenuOpen
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/80 group-hover:text-slate-300'
              }`}
            >
              <MoreVertical className="w-3.5 h-3.5" />
            </button>

            {/* Dropdown Menu Popover */}
            {isMenuOpen && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 top-full mt-1.5 w-48 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl py-1.5 z-50 text-xs font-normal animate-in fade-in zoom-in-95 duration-100"
              >
                <button
                  type="button"
                  onClick={onTogglePin}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-slate-200 hover:bg-slate-800 transition cursor-pointer"
                >
                  {session.pinned ? (
                    <>
                      <PinOff className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>Lepas Sematan</span>
                    </>
                  ) : (
                    <>
                      <Pin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Sematkan ke Atas</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={onStartEdit}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-slate-200 hover:bg-slate-800 transition cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                  <span>Ubah Nama Obrolan</span>
                </button>
                <button
                  type="button"
                  onClick={onExport}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-slate-200 hover:bg-slate-800 transition cursor-pointer"
                >
                  <FileDown className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Simpan / Ekspor (.md)</span>
                </button>
                <div className="my-1 border-t border-slate-800" />
                <button
                  type="button"
                  onClick={onRequestDelete}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 transition cursor-pointer font-medium"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                  <span>Hapus Percakapan</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
