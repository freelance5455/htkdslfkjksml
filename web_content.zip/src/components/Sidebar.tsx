import React from 'react';
import { Plus, MessageSquare, Trash2, X, Sparkles, BookOpen, Smartphone, ShieldCheck } from 'lucide-react';
import { Conversation } from '../types/chat';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  conversations: Conversation[];
  activeId: string | null;
  onSelectConversation: (id: string) => void;
  onNewChat: () => void;
  onDeleteConversation: (id: string, e: React.MouseEvent) => void;
  onClearAll: () => void;
  onOpenGuide: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  conversations,
  activeId,
  onSelectConversation,
  onNewChat,
  onDeleteConversation,
  onClearAll,
  onOpenGuide,
}) => {
  return (
    <>
      {/* Backdrop overlay for mobile */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs transition-opacity md:hidden"
        />
      )}

      {/* Drawer */}
      <aside
        className={`fixed top-0 right-0 z-50 h-full w-72 sm:w-80 bg-[#0A1126] border-l border-blue-900/40 flex flex-col transition-transform duration-300 ease-in-out shadow-2xl ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-blue-900/40 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-700 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-blue-600/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-extrabold text-white text-sm">سجل المحادثات</h2>
              <p className="text-[10px] text-blue-300/70">Mostafa AI Conversations</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-blue-900/40 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* New Chat Button */}
        <div className="p-3">
          <button
            onClick={() => {
              onNewChat();
              onClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white font-semibold text-xs shadow-md shadow-blue-600/30 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>بدء محادثة جديدة</span>
          </button>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto px-3 space-y-1 py-1">
          {conversations.length === 0 ? (
            <div className="py-12 text-center px-4">
              <MessageSquare className="w-8 h-8 mx-auto text-blue-500/40 mb-2" />
              <p className="text-xs text-slate-400">لا توجد محادثات سابقة بعد</p>
              <p className="text-[11px] text-slate-500 mt-1">ابدأ بالسؤال وسيتم حفظها هنا تلقائياً</p>
            </div>
          ) : (
            conversations.map((c) => {
              const isActive = c.id === activeId;
              return (
                <div
                  key={c.id}
                  onClick={() => {
                    onSelectConversation(c.id);
                    onClose();
                  }}
                  className={`group relative flex items-center justify-between p-2.5 rounded-xl cursor-pointer text-xs transition-all ${
                    isActive
                      ? 'bg-blue-900/50 text-white font-semibold border border-blue-600/40 shadow-sm'
                      : 'text-slate-300 hover:bg-blue-950/60 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0 pr-1">
                    <MessageSquare className={`w-3.5 h-3.5 flex-shrink-0 ${isActive ? 'text-cyan-400' : 'text-blue-400/60'}`} />
                    <span className="truncate text-right">{c.title || 'محادثة ذكية'}</span>
                  </div>

                  <button
                    onClick={(e) => onDeleteConversation(c.id, e)}
                    title="حذف المحادثة"
                    className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 rounded transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Quick Guide & Footer Actions */}
        <div className="p-3 border-t border-blue-900/40 space-y-2 bg-[#080E21]">
          {/* Step-by-Step Deploy Guide link */}
          <button
            onClick={() => {
              onOpenGuide();
              onClose();
            }}
            className="w-full flex items-center justify-between p-2.5 rounded-xl bg-blue-950/70 hover:bg-blue-900/50 text-blue-200 text-xs border border-blue-800/40 transition-all text-right"
          >
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-cyan-400 flex-shrink-0" />
              <div className="flex flex-col text-right">
                <span className="font-bold text-white">دليل التشغيل والنشر</span>
                <span className="text-[10px] text-blue-300/70">شرح خطوة بخطوة باللغة العربية</span>
              </div>
            </div>
            <span className="text-[10px] bg-blue-600/30 text-cyan-300 px-1.5 py-0.5 rounded">فتح</span>
          </button>

          {/* Android Compatibility info */}
          <div className="flex items-center gap-2 p-2 rounded-lg bg-blue-950/40 text-[11px] text-slate-300/80 border border-blue-900/30">
            <Smartphone className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>متوافق تماماً مع أندرويد ويدعم اللمس والشاشات المختلفة</span>
          </div>

          {/* Clear all conversations */}
          {conversations.length > 0 && (
            <button
              onClick={onClearAll}
              className="w-full text-center text-[11px] text-rose-400/80 hover:text-rose-300 py-1 transition-colors"
            >
              مسح جميع المحادثات السابقة
            </button>
          )}

          <div className="pt-2 text-center border-t border-blue-900/20 text-[10px] text-slate-500 flex items-center justify-center gap-1">
            <ShieldCheck className="w-3 h-3 text-cyan-400" />
            <span>أمان عالٍ: المفاتيح محمية بالخادم الخلفي</span>
          </div>
        </div>
      </aside>
    </>
  );
};
