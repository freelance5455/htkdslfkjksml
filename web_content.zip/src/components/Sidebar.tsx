import React from 'react';
import { 
  X, 
  LayoutDashboard, 
  BookOpen, 
  Megaphone, 
  Film, 
  CreditCard, 
  MessageCircle, 
  Package, 
  ReceiptText, 
  LogOut, 
  Boxes,
  Zap,
  ShoppingBag,
  Wallet
} from 'lucide-react';
import { useStore, AppView } from '../context/StoreContext';
import { ProductCategory } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const { 
    currentView, 
    setCurrentView, 
    setSelectedCategory, 
    userCredits,
    products,
    availableBalance
  } = useStore();

  const handleNavigate = (view: AppView, cat?: ProductCategory) => {
    setCurrentView(view);
    if (cat) {
      setSelectedCategory(cat);
    }
    onClose();
  };

  const lowStockCount = products.filter(p => p.stock <= p.minStockAlert).length;

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          onClick={onClose}
          className="fixed inset-0 bg-black/60 z-40 backdrop-blur-xs transition-opacity duration-200"
          aria-hidden="true"
        />
      )}

      {/* Drawer */}
      <aside 
        className={`fixed top-0 left-0 bottom-0 w-80 max-w-[85vw] bg-[#071d15] text-slate-100 z-50 flex flex-col justify-between transition-transform duration-300 ease-out border-r border-emerald-950/60 shadow-2xl ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Top Header */}
        <div className="p-5 flex items-center justify-between border-b border-emerald-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-emerald-400 flex items-center justify-center shadow-lg shadow-emerald-950/50">
              <BookOpen className="w-5 h-5 text-emerald-950 stroke-[2.5]" />
            </div>
            <div>
              <div className="font-bold text-base tracking-tight text-white leading-snug">
                EscaleBuilder
              </div>
              <div className="text-xs text-emerald-400 font-medium">
                by EscalePay
              </div>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-emerald-900/40 transition-colors"
            aria-label="Fechar menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation links */}
        <div className="flex-1 overflow-y-auto px-4 py-5 space-y-1 text-sm font-medium">
          <button
            onClick={() => handleNavigate('store', 'all')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-left transition-colors ${
              currentView === 'store' 
                ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/50 shadow-xs' 
                : 'text-slate-300 hover:bg-emerald-950/40 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">Dashboard & Loja</span>
          </button>

          <button
            onClick={() => handleNavigate('store', 'ebooks')}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-left text-slate-300 hover:bg-emerald-950/40 hover:text-white transition-colors"
          >
            <BookOpen className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">eBooks, Planilhas & Capas</span>
          </button>

          <button
            onClick={() => handleNavigate('store', 'ads_banners')}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-left text-slate-300 hover:bg-emerald-950/40 hover:text-white transition-colors"
          >
            <Megaphone className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">Anúncios, Imagem & Banner</span>
          </button>

          <button
            onClick={() => handleNavigate('store', 'courses_vsl')}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-left text-slate-300 hover:bg-emerald-950/40 hover:text-white transition-colors"
          >
            <Film className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">ADS Video & VSL</span>
          </button>

          {/* Section Divider */}
          <div className="pt-3 pb-1 px-3 text-[11px] font-semibold tracking-wider text-emerald-500 uppercase">
            Gestão & Vendas
          </div>

          <button
            onClick={() => handleNavigate('inventory')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-left transition-colors ${
              currentView === 'inventory' 
                ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/50 shadow-xs' 
                : 'text-slate-300 hover:bg-emerald-950/40 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Boxes className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="truncate">Gestão de Estoque</span>
            </div>
            {lowStockCount > 0 && (
              <span className="text-[11px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1.5 py-0.5 rounded-md font-mono">
                {lowStockCount} baixo
              </span>
            )}
          </button>

          <button
            onClick={() => handleNavigate('orders')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-left transition-colors ${
              currentView === 'orders' 
                ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/50 shadow-xs' 
                : 'text-slate-300 hover:bg-emerald-950/40 hover:text-white'
            }`}
          >
            <ReceiptText className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">Pedidos & Vendas</span>
          </button>

          <button
            onClick={() => handleNavigate('payouts')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-left transition-colors ${
              currentView === 'payouts' 
                ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/50 shadow-xs' 
                : 'text-slate-300 hover:bg-emerald-950/40 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Wallet className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="truncate">Carteira do Dono & Saques</span>
            </div>
            <span className="text-[11px] font-mono text-emerald-300 font-bold">
              {availableBalance.toLocaleString('pt-MZ')} MT
            </span>
          </button>

          <button
            onClick={() => handleNavigate('plans')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-left transition-colors ${
              currentView === 'plans' 
                ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/50 shadow-xs' 
                : 'text-slate-300 hover:bg-emerald-950/40 hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <CreditCard className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="truncate">Planos & Créditos</span>
            </div>
            <span className="text-[11px] text-emerald-300 font-medium">97 MT</span>
          </button>

          <button
            onClick={() => {
              window.open('https://wa.me/258841634528?text=Olá,%20preciso%20de%20suporte%20no%20EscaleBuilder', '_blank');
              onClose();
            }}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-left text-slate-300 hover:bg-emerald-950/40 hover:text-white transition-colors"
          >
            <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">Suporte WhatsApp</span>
          </button>
        </div>

        {/* Bottom Banner & Profile (as in screenshot) */}
        <div className="p-4 border-t border-emerald-950/80 space-y-3 bg-[#051610]">
          {/* Plan Status Box */}
          <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                {userCredits > 0 ? 'Plano Ativo' : 'Sem Plano Ativo'}
              </div>
              <span className="text-xs font-mono text-emerald-300">
                {userCredits} créditos
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              {userCredits > 0 
                ? 'Tens saldo para gerar novos produtos digitais e gerir o teu estoque.'
                : 'Escolhe um plano para criar eBooks, planilhas, capas, anúncios e gerir vendas.'}
            </p>
            <button
              onClick={() => handleNavigate('plans')}
              className="w-full py-2 px-3 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              <Zap className="w-3.5 h-3.5" />
              {userCredits > 0 ? 'Recarregar créditos' : 'Escolher plano'}
            </button>
          </div>

          {/* User profile row */}
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-xs">
                M
              </div>
              <div className="min-w-0">
                <div className="text-xs font-semibold text-white truncate">
                  Momade cassimo Sumaila
                </div>
                <div className="text-[11px] text-slate-400 truncate">
                  jucunozawayajacob@gmail.com
                </div>
              </div>
            </div>
            <button 
              onClick={() => handleNavigate('store')} 
              title="Voltar à loja"
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-emerald-900/50 transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
