import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { Conversation, PageView } from '../types.js';
import { Logo } from './Logo.js';
import {
  Plus,
  Search,
  MessageSquare,
  Trash2,
  Edit2,
  Settings,
  User,
  Sliders,
  Volume2,
  Sparkles,
  Shield,
  HelpCircle,
  LogOut,
  X,
  ChevronDown,
  Moon,
  Palette,
  Bell,
  Cpu,
  Info,
  Lock,
} from 'lucide-react';

interface SidebarProps {
  conversations: Conversation[];
  activeConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onNewChat: () => void;
  onOpenRename: (conv: Conversation) => void;
  onDeleteConversation: (id: string) => void;
  onOpenClearHistory: () => void;
  onOpenSearch: () => void;
  onOpenLogoutModal: () => void;
  isOpenMobile: boolean;
  setIsOpenMobile: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewChat,
  onOpenRename,
  onDeleteConversation,
  onOpenClearHistory,
  onOpenSearch,
  onOpenLogoutModal,
  isOpenMobile,
  setIsOpenMobile,
}) => {
  const { user, currentPage, setCurrentPage } = useAuth();
  const [settingsDropdownOpen, setSettingsDropdownOpen] = useState(false);

  // Group conversations by relative time
  const groupConversations = () => {
    const today: Conversation[] = [];
    const yesterday: Conversation[] = [];
    const lastWeek: Conversation[] = [];
    const older: Conversation[] = [];

    const now = new Date();
    const todayDate = now.toDateString();

    const yDate = new Date();
    yDate.setDate(yDate.getDate() - 1);
    const yesterdayDate = yDate.toDateString();

    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    for (const c of conversations) {
      const cDate = new Date(c.updatedAt);
      const cDateStr = cDate.toDateString();

      if (cDateStr === todayDate) {
        today.push(c);
      } else if (cDateStr === yesterdayDate) {
        yesterday.push(c);
      } else if (cDate >= sevenDaysAgo) {
        lastWeek.push(c);
      } else {
        older.push(c);
      }
    }

    return { today, yesterday, lastWeek, older };
  };

  const { today, yesterday, lastWeek, older } = groupConversations();

  const handleNav = (page: PageView) => {
    setCurrentPage(page);
    setIsOpenMobile(false);
  };

  const renderGroup = (title: string, list: Conversation[]) => {
    if (list.length === 0) return null;
    return (
      <div className="mb-4">
        <h4 className="px-3 text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
          {title}
        </h4>
        <div className="space-y-0.5">
          {list.map(conv => {
            const isActive = conv.id === activeConversationId && currentPage === 'chat';
            return (
              <div
                key={conv.id}
                className={`group relative flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition cursor-pointer ${
                  isActive
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-semibold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                }`}
                onClick={() => {
                  onSelectConversation(conv.id);
                  setIsOpenMobile(false);
                }}
              >
                <div className="flex items-center gap-2 truncate pr-2">
                  <MessageSquare
                    className={`w-3.5 h-3.5 shrink-0 ${
                      isActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'
                    }`}
                  />
                  <span className="truncate">{conv.title}</span>
                </div>

                {/* Hover actions */}
                <div className="hidden group-hover:flex items-center gap-1 shrink-0 bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded-md">
                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      onOpenRename(conv);
                    }}
                    className="p-1 rounded hover:text-indigo-600 dark:hover:text-indigo-400 text-slate-400"
                    title="Rename conversation"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      onDeleteConversation(conv.id);
                    }}
                    className="p-1 rounded hover:text-rose-600 dark:hover:text-rose-400 text-slate-400"
                    title="Delete conversation"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 select-none">
      {/* Top Brand Header */}
      <div className="p-4 flex items-center justify-between border-b border-slate-100 dark:border-slate-800/80">
        <button
          onClick={() => handleNav('chat')}
          className="flex items-center gap-2 text-left focus:outline-none"
        >
          <Logo size="sm" showTagline />
        </button>
        {/* Mobile close button */}
        <button
          onClick={() => setIsOpenMobile(false)}
          className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Action Buttons: New Chat & Search */}
      <div className="p-3 space-y-2">
        <button
          onClick={() => {
            onNewChat();
            setIsOpenMobile(false);
          }}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-sm shadow-indigo-600/20 active:scale-95 transition"
        >
          <Plus className="w-4 h-4" />
          <span>New Chat</span>
        </button>

        <button
          onClick={() => {
            onOpenSearch();
            setIsOpenMobile(false);
          }}
          className="w-full flex items-center gap-2 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-800/60 bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 text-xs transition"
        >
          <Search className="w-3.5 h-3.5" />
          <span>Search conversations...</span>
        </button>
      </div>

      {/* Chat History List */}
      <div className="flex-1 overflow-y-auto px-2 py-2 space-y-1">
        {conversations.length === 0 ? (
          <div className="text-center py-10 px-4 text-xs text-slate-400">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-30 text-indigo-500" />
            <p>No chat history yet.</p>
            <p className="text-[11px] mt-1 text-slate-400">Click "New Chat" to ask AI Pocket Chat anything!</p>
          </div>
        ) : (
          <>
            {renderGroup('Today', today)}
            {renderGroup('Yesterday', yesterday)}
            {renderGroup('Previous 7 Days', lastWeek)}
            {renderGroup('Older', older)}

            <div className="pt-2 pb-4 px-2">
              <button
                onClick={onOpenClearHistory}
                className="w-full text-center py-1.5 text-[11px] text-slate-400 hover:text-rose-500 transition"
              >
                Clear all chat history
              </button>
            </div>
          </>
        )}
      </div>

      {/* Settings Navigation Menu */}
      <div className="p-3 border-t border-slate-100 dark:border-slate-800/80 space-y-1 bg-slate-50/50 dark:bg-slate-900/50">
        {/* Settings Accordion */}
        <div>
          <button
            onClick={() => setSettingsDropdownOpen(!settingsDropdownOpen)}
            className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <div className="flex items-center gap-2">
              <Settings className="w-4 h-4 text-indigo-500" />
              <span>Preferences & AI</span>
            </div>
            <ChevronDown
              className={`w-3.5 h-3.5 text-slate-400 transition-transform ${
                settingsDropdownOpen ? 'rotate-180' : ''
              }`}
            />
          </button>

          {settingsDropdownOpen && (
            <div className="pl-6 pr-2 py-1 space-y-0.5 text-xs text-slate-600 dark:text-slate-400 animate-in fade-in">
              <button
                onClick={() => handleNav('personalization-settings')}
                className={`w-full text-left py-1.5 px-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 ${
                  currentPage === 'personalization-settings' ? 'text-indigo-600 font-semibold' : ''
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Personalization</span>
              </button>
              <button
                onClick={() => handleNav('voice-settings')}
                className={`w-full text-left py-1.5 px-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 ${
                  currentPage === 'voice-settings' ? 'text-indigo-600 font-semibold' : ''
                }`}
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Voice Settings</span>
              </button>
              <button
                onClick={() => handleNav('appearance-settings')}
                className={`w-full text-left py-1.5 px-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 ${
                  currentPage === 'appearance-settings' ? 'text-indigo-600 font-semibold' : ''
                }`}
              >
                <Palette className="w-3.5 h-3.5" />
                <span>Appearance & Theme</span>
              </button>
              <button
                onClick={() => handleNav('ai-settings')}
                className={`w-full text-left py-1.5 px-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 ${
                  currentPage === 'ai-settings' ? 'text-indigo-600 font-semibold' : ''
                }`}
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>API & Model Config</span>
              </button>
              <button
                onClick={() => handleNav('notifications-settings')}
                className={`w-full text-left py-1.5 px-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 ${
                  currentPage === 'notifications-settings' ? 'text-indigo-600 font-semibold' : ''
                }`}
              >
                <Bell className="w-3.5 h-3.5" />
                <span>Notifications</span>
              </button>
              <button
                onClick={() => handleNav('privacy-security')}
                className={`w-full text-left py-1.5 px-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 ${
                  currentPage === 'privacy-security' ? 'text-indigo-600 font-semibold' : ''
                }`}
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Privacy & Security</span>
              </button>
            </div>
          )}
        </div>

        {/* Quick Links */}
        <button
          onClick={() => handleNav('about')}
          className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition ${
            currentPage === 'about' ? 'text-indigo-600 font-semibold' : ''
          }`}
        >
          <Info className="w-4 h-4 text-slate-400" />
          <span>About AI Pocket Chat</span>
        </button>

        <button
          onClick={() => handleNav('help-support')}
          className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition ${
            currentPage === 'help-support' ? 'text-indigo-600 font-semibold' : ''
          }`}
        >
          <HelpCircle className="w-4 h-4 text-slate-400" />
          <span>Help & Support</span>
        </button>

        <button
          onClick={() => handleNav('admin')}
          className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition ${
            currentPage === 'admin' ? 'font-semibold ring-1 ring-amber-500/30' : ''
          }`}
        >
          <Lock className="w-4 h-4 text-amber-500" />
          <span>Owner Admin Panel</span>
        </button>

        {/* User Profile Bar */}
        {user && (
          <div className="pt-2 mt-2 border-t border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <button
              onClick={() => handleNav('profile')}
              className="flex items-center gap-2 text-left p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition flex-1 min-w-0 mr-1"
            >
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.name}
                  className="w-7 h-7 rounded-lg object-cover shrink-0"
                />
              ) : (
                <div className="w-7 h-7 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 font-bold text-xs flex items-center justify-center shrink-0">
                  {user.name.charAt(0).toUpperCase()}
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                  {user.name}
                </p>
                <p className="text-[10px] text-slate-400 truncate">{user.email}</p>
              </div>
            </button>

            <button
              onClick={onOpenLogoutModal}
              className="p-2 rounded-xl text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition shrink-0"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Owner signature footnote in sidebar */}
      <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800/80 text-[10px] text-slate-400 dark:text-slate-500 text-center">
        OWNER NAME: Ali ABDULLAH
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:block w-72 h-full shrink-0">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer with Backdrop */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
            onClick={() => setIsOpenMobile(false)}
          />
          <div className="relative w-80 max-w-[85vw] h-full shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
