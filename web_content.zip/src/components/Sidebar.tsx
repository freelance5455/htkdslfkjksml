import React, { useState, useRef, useMemo } from 'react';
import {
  X,
  Plus,
  Search,
  MessageSquare,
  Trash2,
  Edit2,
  Check,
  Sparkles,
  Settings,
  LogOut,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
  PanelLeftClose,
  PanelLeft,
  AlertTriangle,
  MapPin,
  FileText
} from 'lucide-react';
import { ChatSession } from '../types/chat';
import { User } from '../types/auth';

interface SidebarProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  onClearAllSessions: () => void;
  activeTab: 'chat' | 'images' | 'maps' | 'forms';
  onTabChange: (tab: 'chat' | 'images' | 'maps' | 'forms') => void;
  onOpenVoiceModal?: () => void;
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  isLight?: boolean;
  confirmBeforeDelete?: boolean;
  onOpenSettings: () => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  activeSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  onRenameSession,
  onClearAllSessions,
  activeTab,
  onTabChange,
  isOpen,
  onClose,
  user,
  isLight = false,
  confirmBeforeDelete = true,
  onOpenSettings,
  onLogout,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null);
  const [showClearAllConfirm, setShowClearAllConfirm] = useState(false);

  const editInputRef = useRef<HTMLInputElement>(null);

  // Group conversations by date (Today, Yesterday, Last 7 days, Older)
  const groupedSessions = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const filtered = sessions.filter((s) => {
      const titleMatch = (s.title || 'محادثة جديدة').toLowerCase().includes(query);
      const hasMessages = s.messages && s.messages.length > 0;
      return titleMatch && hasMessages;
    });

    const now = Date.now();
    const oneDayMs = 24 * 60 * 60 * 1000;
    const today: ChatSession[] = [];
    const yesterday: ChatSession[] = [];
    const last7Days: ChatSession[] = [];
    const older: ChatSession[] = [];

    filtered.forEach((session) => {
      const time = session.updatedAt || session.createdAt || now;
      const diffDays = Math.floor((now - time) / oneDayMs);

      if (diffDays === 0) {
        today.push(session);
      } else if (diffDays === 1) {
        yesterday.push(session);
      } else if (diffDays <= 7) {
        last7Days.push(session);
      } else {
        older.push(session);
      }
    });

    return [
      { label: 'اليوم', items: today },
      { label: 'أمس', items: yesterday },
      { label: 'آخر 7 أيام', items: last7Days },
      { label: 'المحادثات السابقة', items: older },
    ].filter((group) => group.items.length > 0);
  }, [sessions, searchQuery]);

  const startRename = (session: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(session.id);
    setEditTitle(session.title || 'محادثة جديدة');
    setMenuOpenId(null);
    setTimeout(() => {
      editInputRef.current?.focus();
      editInputRef.current?.select();
    }, 50);
  };

  const saveRename = (id: string, e?: React.FormEvent | React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (editTitle.trim()) {
      onRenameSession(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const cancelRename = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingId(null);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirmBeforeDelete) {
      if (confirmDeleteId === id) {
        onDeleteSession(id);
        setConfirmDeleteId(null);
        setMenuOpenId(null);
      } else {
        setConfirmDeleteId(id);
        setMenuOpenId(null);
        // Auto-reset confirmation after 4 seconds
        setTimeout(() => {
          setConfirmDeleteId((prev) => (prev === id ? null : prev));
        }, 4000);
      }
    } else {
      onDeleteSession(id);
      setMenuOpenId(null);
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 lg:hidden transition-opacity"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed lg:static inset-y-0 right-0 z-50 flex flex-col transition-all duration-300 ease-in-out ${
          isOpen
            ? 'w-[280px] sm:w-[290px] translate-x-0'
            : 'w-0 -translate-x-full lg:translate-x-0 lg:w-0 overflow-hidden'
        } ${
          isLight
            ? 'bg-[#F7F7F8] border-l border-[#e5e5e5] text-[#202123]'
            : 'bg-[#171717] border-l border-[#262626] text-[#ececec]'
        } select-none`}
        dir="rtl"
      >
        {/* Top Header: New Chat & Close Button */}
        <div className="p-3 pb-2 flex items-center justify-between gap-2 shrink-0">
          <button
            onClick={() => {
              onNewChat();
              if (window.innerWidth < 1024) onClose();
            }}
            className={`flex-1 flex items-center justify-between px-3 py-2 rounded-xl font-medium text-xs sm:text-sm transition-all border ${
              isLight
                ? 'bg-white hover:bg-neutral-50 border-[#e5e5e5] text-[#202123] shadow-xs'
                : 'bg-[#212121] hover:bg-[#2a2a2a] border-[#303030] text-[#ececec] shadow-sm'
            } group`}
            title="محادثة جديدة"
          >
            <div className="flex items-center gap-2">
              <Plus className="w-4 h-4 text-neutral-600 dark:text-neutral-300" />
              <span>محادثة جديدة</span>
            </div>
            <span className={`text-[10px] px-1.5 py-0.5 rounded ${isLight ? 'bg-neutral-100 text-neutral-500' : 'bg-neutral-800 text-neutral-400'}`}>
              Ctrl+N
            </span>
          </button>

          {/* Close Sidebar button */}
          <button
            onClick={onClose}
            className={`p-2 rounded-xl transition-colors ${
              isLight
                ? 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-200/60'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
            }`}
            title="إغلاق الشريط الجانبي"
          >
            <PanelLeftClose className="w-4 h-4 rotate-180" />
          </button>
        </div>

        {/* Tab switch: Chat vs Images vs Maps vs Forms */}
        <div className="px-3 py-1 shrink-0">
          <div className={`p-1 rounded-xl grid grid-cols-2 gap-1 text-xs border ${
            isLight ? 'bg-[#eeeff1] border-[#e5e5e5]' : 'bg-[#212121] border-[#2e2e2e]'
          }`}>
            <button
              onClick={() => onTabChange('chat')}
              className={`py-1.5 px-2 rounded-lg font-medium transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'chat'
                  ? isLight
                    ? 'bg-white text-[#202123] shadow-xs'
                    : 'bg-[#2f2f2f] text-white shadow-xs'
                  : isLight
                    ? 'text-neutral-500 hover:text-neutral-800'
                    : 'text-neutral-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>المحادثة</span>
            </button>
            <button
              onClick={() => onTabChange('images')}
              className={`py-1.5 px-2 rounded-lg font-medium transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'images'
                  ? isLight
                    ? 'bg-white text-[#202123] shadow-xs'
                    : 'bg-[#2f2f2f] text-white shadow-xs'
                  : isLight
                    ? 'text-neutral-500 hover:text-neutral-800'
                    : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-neutral-600 dark:text-neutral-300" />
              <span>الصور</span>
            </button>
            <button
              onClick={() => onTabChange('maps')}
              className={`py-1.5 px-2 rounded-lg font-medium transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'maps'
                  ? isLight
                    ? 'bg-white text-blue-600 font-bold shadow-xs'
                    : 'bg-[#2f2f2f] text-blue-400 font-bold shadow-xs'
                  : isLight
                    ? 'text-neutral-500 hover:text-neutral-800'
                    : 'text-neutral-400 hover:text-white'
              }`}
            >
              <MapPin className="w-3.5 h-3.5 text-blue-500" />
              <span>خرائط Google</span>
            </button>
            <button
              onClick={() => onTabChange('forms')}
              className={`py-1.5 px-2 rounded-lg font-medium transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'forms'
                  ? isLight
                    ? 'bg-white text-purple-600 font-bold shadow-xs'
                    : 'bg-[#2f2f2f] text-purple-400 font-bold shadow-xs'
                  : isLight
                    ? 'text-neutral-500 hover:text-neutral-800'
                    : 'text-neutral-400 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-purple-500" />
              <span>نماذج Google</span>
            </button>
          </div>
        </div>

        {/* Search Input */}
        <div className="px-3 py-1.5 shrink-0">
          <div className={`relative flex items-center rounded-xl border ${
            isLight
              ? 'bg-white border-[#e5e5e5] text-[#202123] focus-within:border-neutral-400'
              : 'bg-[#212121] border-[#2e2e2e] text-neutral-200 focus-within:border-neutral-500'
          } px-2.5 py-1.5 transition-colors`}>
            <Search className={`w-3.5 h-3.5 ${isLight ? 'text-neutral-400' : 'text-neutral-400'} shrink-0 ml-2`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="البحث في المحادثات..."
              className="w-full bg-transparent text-xs focus:outline-none placeholder:text-neutral-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-neutral-400 hover:text-white p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Conversation List */}
        <div className="flex-1 overflow-y-auto px-2 py-1 space-y-4">
          {groupedSessions.length === 0 ? (
            <div className="text-center py-8 px-4 text-xs text-neutral-400">
              {searchQuery ? 'لا توجد محادثات تطابق بحثك' : 'لا توجد محادثات سابقة حتى الآن'}
            </div>
          ) : (
            groupedSessions.map((group) => (
              <div key={group.label} className="space-y-1">
                {/* Date Group Header */}
                <div className={`px-2.5 py-1 text-[11px] font-semibold tracking-wider ${
                  isLight ? 'text-slate-400' : 'text-neutral-500'
                }`}>
                  {group.label}
                </div>

                {/* Items in this group */}
                {group.items.map((session) => {
                  const isActive = session.id === activeSessionId;
                  const isEditing = session.id === editingId;
                  const isConfirming = session.id === confirmDeleteId;

                  return (
                    <div
                      key={session.id}
                      onClick={() => {
                        onSelectSession(session.id);
                        if (window.innerWidth < 1024) onClose();
                      }}
                      className={`group relative flex items-center justify-between px-2.5 py-2 rounded-xl cursor-pointer text-xs transition-all ${
                        isActive
                          ? isLight
                            ? 'bg-[#ececec] text-[#202123] font-medium'
                            : 'bg-[#262626] text-white font-medium shadow-xs'
                          : isLight
                          ? 'hover:bg-neutral-200/50 text-neutral-700'
                          : 'hover:bg-[#212121] text-neutral-300'
                      }`}
                    >
                      {isEditing ? (
                        <div
                          className="flex items-center gap-1.5 w-full"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <input
                            ref={editInputRef}
                            type="text"
                            value={editTitle}
                            onChange={(e) => setEditTitle(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') saveRename(session.id, e);
                              if (e.key === 'Escape') cancelRename(e as any);
                            }}
                            className={`flex-1 px-2 py-1 text-xs rounded-lg border focus:outline-none ${
                              isLight
                                ? 'bg-white border-blue-500 text-slate-900'
                                : 'bg-[#1a1a1a] border-blue-500 text-white'
                            }`}
                          />
                          <button
                            onClick={(e) => saveRename(session.id, e)}
                            className="p-1 rounded-md text-emerald-500 hover:bg-emerald-500/10"
                            title="حفظ"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={cancelRename}
                            className="p-1 rounded-md text-rose-500 hover:bg-rose-500/10"
                            title="إلغاء"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : isConfirming ? (
                        <div
                          className="flex items-center justify-between w-full py-0.5 px-1 bg-rose-500/10 border border-rose-500/30 rounded-lg text-rose-500 animate-in fade-in"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <span className="text-[11px] font-medium">حذف المحادثة؟</span>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={(e) => handleDelete(session.id, e)}
                              className="px-2 py-0.5 text-[10px] font-bold bg-rose-600 text-white rounded hover:bg-rose-500"
                            >
                              حذف
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setConfirmDeleteId(null);
                              }}
                              className="px-1.5 py-0.5 text-[10px] text-neutral-400 hover:text-white"
                            >
                              إلغاء
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-2 truncate min-w-0 flex-1">
                            <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${
                              isActive ? (isLight ? 'text-neutral-800' : 'text-neutral-200') : (isLight ? 'text-neutral-400' : 'text-neutral-500')
                            }`} />
                            <span className="truncate" title={session.title || 'محادثة جديدة'}>
                              {session.title || 'محادثة جديدة'}
                            </span>
                          </div>

                          {/* Hover action buttons: Rename & Delete */}
                          <div className={`items-center gap-0.5 transition-opacity ${
                            isActive ? 'flex' : 'hidden group-hover:flex'
                          }`}>
                            <button
                              onClick={(e) => startRename(session, e)}
                              className={`p-1 rounded-md transition-colors ${
                                isLight
                                  ? 'hover:bg-slate-300/60 text-slate-500 hover:text-slate-900'
                                  : 'hover:bg-[#333333] text-neutral-400 hover:text-white'
                              }`}
                              title="تعديل العنوان"
                            >
                              <Edit2 className="w-3 h-3" />
                            </button>
                            <button
                              onClick={(e) => handleDelete(session.id, e)}
                              className={`p-1 rounded-md transition-colors ${
                                isLight
                                  ? 'hover:bg-rose-100 text-slate-500 hover:text-rose-600'
                                  : 'hover:bg-rose-900/40 text-neutral-400 hover:text-rose-400'
                              }`}
                              title="حذف المحادثة"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            ))
          )}
        </div>

        {/* Clear all chats button */}
        {sessions.length > 1 && (
          <div className="px-3 py-1 shrink-0">
            {showClearAllConfirm ? (
              <div className="p-2 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-500 flex items-center justify-between">
                <span>مسح كل المحادثات؟</span>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => {
                      onClearAllSessions();
                      setShowClearAllConfirm(false);
                    }}
                    className="px-2 py-0.5 bg-rose-600 text-white rounded text-[11px] font-semibold"
                  >
                    تأكيد
                  </button>
                  <button
                    onClick={() => setShowClearAllConfirm(false)}
                    className="px-1.5 py-0.5 text-neutral-400 text-[11px]"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setShowClearAllConfirm(true)}
                className={`w-full py-1.5 px-2 text-[11px] rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                  isLight
                    ? 'text-slate-400 hover:text-rose-600 hover:bg-rose-50'
                    : 'text-neutral-500 hover:text-rose-400 hover:bg-rose-950/20'
                }`}
              >
                <Trash2 className="w-3 h-3" />
                <span>مسح كافة المحادثات</span>
              </button>
            )}
          </div>
        )}

        {/* User Account & Settings Footer */}
        <div className={`p-3 border-t shrink-0 ${
          isLight ? 'border-[#e5e5e5] bg-[#F7F7F8]' : 'border-[#262626] bg-[#171717]'
        }`}>
          <div className="flex items-center justify-between gap-2">
            {/* User Profile */}
            <div
              onClick={onOpenSettings}
              className={`flex-1 flex items-center gap-2.5 p-1.5 rounded-xl cursor-pointer transition-colors ${
                isLight ? 'hover:bg-neutral-200/60' : 'hover:bg-[#262626]'
              }`}
              title="إعدادات الحساب"
            >
              {user?.avatar ? (
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-7 h-7 rounded-full object-cover border border-neutral-300 dark:border-neutral-700"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-medium text-xs flex items-center justify-center shadow-xs">
                  {user?.name ? user.name.slice(0, 1).toUpperCase() : 'U'}
                </div>
              )}
              <div className="truncate flex-1 min-w-0">
                <div className="text-xs font-semibold truncate leading-tight">
                  {user?.name || 'مستخدم Onyx'}
                </div>
                <div className={`text-[10px] truncate ${isLight ? 'text-slate-400' : 'text-neutral-500'}`}>
                  {user?.email || 'حساب مفعل'}
                </div>
              </div>
            </div>

            {/* Quick Actions: Settings & Logout */}
            <div className="flex items-center gap-0.5 shrink-0">
              <button
                onClick={onOpenSettings}
                className={`p-1.5 rounded-lg transition-colors ${
                  isLight
                    ? 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
                    : 'text-neutral-400 hover:text-white hover:bg-[#262626]'
                }`}
                title="الإعدادات"
              >
                <Settings className="w-4 h-4" />
              </button>
              <button
                onClick={onLogout}
                className={`p-1.5 rounded-lg transition-colors ${
                  isLight
                    ? 'text-slate-500 hover:text-rose-600 hover:bg-rose-50'
                    : 'text-neutral-400 hover:text-rose-400 hover:bg-rose-950/20'
                }`}
                title="تسجيل الخروج"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
