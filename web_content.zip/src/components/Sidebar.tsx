import React, { useState } from 'react';
import {
  Plus,
  MessageSquare,
  Trash2,
  X,
  Sparkles,
  Info,
  ChevronRight,
  Code,
  Lightbulb,
  BookOpen,
  Atom,
  CheckCircle2
} from 'lucide-react';
import { playSound } from '../utils/soundEffects';

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  messageCount: number;
}

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  currentSessionId: string;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onSelectPrompt: (prompt: string) => void;
  soundMuted: boolean;
  serverStatus: {
    status: string;
    version: string;
    hasApiKey: boolean;
    model: string;
  } | null;
}

const STARTER_PROMPTS = [
  {
    category: 'Sciences & IA',
    icon: <Atom className="w-4 h-4 text-cyan-400" />,
    prompts: [
      'Explique la physique quantique et l\'intrication simplement.',
      'Comment fonctionne l\'architecture d\'un transformeur comme GPT-6 ?',
      'Quelles sont les avancées majeures en fusion nucléaire ?',
    ],
  },
  {
    category: 'Code & Ingénierie',
    icon: <Code className="w-4 h-4 text-blue-400" />,
    prompts: [
      'Écris un script Python asynchrone pour analyser des données en temps réel.',
      'Comment architecturer une application React 19 avec Tailwind CSS ?',
      'Donne-moi un algorithme de recherche binaire optimisé avec tests.',
    ],
  },
  {
    category: 'Créativité & Rédaction',
    icon: <Lightbulb className="w-4 h-4 text-amber-400" />,
    prompts: [
      'Écris un court récit cyberpunk se déroulant à Néo-Paris en 2099.',
      'Rédige un pitch percutant pour une startup d\'IA spatiale.',
      'Propose 5 idées de projets innovants alliant écologie et IA.',
    ],
  },
];

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  sessions,
  currentSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onSelectPrompt,
  soundMuted,
  serverStatus,
}) => {
  const [showSpecsModal, setShowSpecsModal] = useState(false);

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer */}
      <aside className="fixed inset-y-0 left-0 z-50 flex flex-col w-80 sm:w-96 bg-[#0c1322] border-r border-cyan-500/20 shadow-2xl shadow-cyan-950/70 p-4 overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-cyan-500/15">
          <div className="flex items-center gap-2">
            <span className="text-xl">🤖</span>
            <div>
              <h2 className="font-bold text-white text-base">GPT-6 Console</h2>
              <span className="text-[10px] text-cyan-400 font-mono">v6.4 Quantum</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* New Session Button */}
        <div className="py-4">
          <button
            onClick={() => {
              playSound('click', soundMuted);
              onNewSession();
              onClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-semibold shadow-lg shadow-cyan-500/20 transition-all transform active:scale-98"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Nouvelle conversation</span>
          </button>
        </div>

        {/* Chat History List */}
        <div className="flex-1 space-y-1">
          <div className="flex items-center justify-between px-2 py-1 text-xs font-semibold text-slate-400 uppercase tracking-wider">
            <span>Conversations</span>
            <span className="text-[10px] bg-slate-800 text-cyan-300 px-1.5 py-0.5 rounded-md">
              {sessions.length}
            </span>
          </div>

          <div className="space-y-1 max-h-56 overflow-y-auto pr-1">
            {sessions.length === 0 ? (
              <div className="p-4 text-center text-xs text-slate-500">
                Aucune conversation enregistrée
              </div>
            ) : (
              sessions.map((sess) => {
                const isActive = sess.id === currentSessionId;
                return (
                  <div
                    key={sess.id}
                    className={`group flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl text-xs sm:text-sm transition-all cursor-pointer ${
                      isActive
                        ? 'bg-cyan-500/15 text-cyan-200 border border-cyan-500/30'
                        : 'text-slate-300 hover:bg-slate-850 hover:text-white hover:bg-slate-800/60'
                    }`}
                    onClick={() => {
                      playSound('click', soundMuted);
                      onSelectSession(sess.id);
                      onClose();
                    }}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                      <span className="truncate">{sess.title}</span>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        playSound('click', soundMuted);
                        onDeleteSession(sess.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-400 transition-opacity"
                      title="Supprimer la conversation"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })
            )}
          </div>

          {/* Quick Prompts Sections */}
          <div className="pt-4 mt-4 border-t border-cyan-500/15">
            <h3 className="px-2 pb-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Suggestions & Idées
            </h3>
            <div className="space-y-3">
              {STARTER_PROMPTS.map((group) => (
                <div key={group.category} className="space-y-1.5">
                  <div className="flex items-center gap-1.5 px-2 text-xs font-medium text-cyan-300/90">
                    {group.icon}
                    <span>{group.category}</span>
                  </div>
                  <div className="space-y-1">
                    {group.prompts.map((p, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          playSound('click', soundMuted);
                          onSelectPrompt(p);
                          onClose();
                        }}
                        className="w-full text-left p-2 rounded-lg text-xs text-slate-300 hover:text-cyan-200 hover:bg-slate-800/70 border border-slate-800/80 transition-colors line-clamp-1"
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer info & System specs */}
        <div className="pt-3 mt-4 border-t border-cyan-500/15">
          <button
            onClick={() => setShowSpecsModal(true)}
            className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-cyan-500/20 text-xs text-slate-300 transition-colors"
          >
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-cyan-400" />
              <span>Spécifications GPT-6</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>
        </div>
      </aside>

      {/* Specifications Modal */}
      {showSpecsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#0f182b] border border-cyan-500/30 rounded-2xl p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🤖</span>
                <h3 className="text-lg font-bold text-white">Spécifications GPT-6</h3>
              </div>
              <button
                onClick={() => setShowSpecsModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-3 text-xs sm:text-sm text-slate-300">
              <div className="flex justify-between py-1.5 border-b border-slate-800">
                <span className="text-slate-400">Architecture</span>
                <span className="font-semibold text-cyan-300">Neural Quantique 6e Génération</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800">
                <span className="text-slate-400">Moteur IA Actif</span>
                <span className="font-semibold text-cyan-300">
                  {serverStatus?.model || 'gemini-3.8-flash'}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800">
                <span className="text-slate-400">Statut du Serveur</span>
                <span className="flex items-center gap-1 font-semibold text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" /> En ligne (Streaming SSE)
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800">
                <span className="text-slate-400">Clé API Détectée</span>
                <span className="font-semibold text-slate-200">
                  {serverStatus?.hasApiKey ? 'Connectée (Cloud Secrets)' : 'Mode Simulation Local'}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-800">
                <span className="text-slate-400">Langues supportées</span>
                <span className="font-semibold text-slate-200">Français, Anglais, +80 langues</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-slate-400">Capacités</span>
                <span className="font-semibold text-cyan-300">Code, Markdown, Audio & Dictée</span>
              </div>
            </div>

            <button
              onClick={() => setShowSpecsModal(false)}
              className="w-full mt-2 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-sm transition-colors"
            >
              Fermer
            </button>
          </div>
        </div>
      )}
    </>
  );
};
