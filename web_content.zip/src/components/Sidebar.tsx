/* ============================================
   plix_ai studio — Sidebar navigation
   ============================================ */

import { useState } from 'react';
import type { PageId, NavItem } from '../types';
import { IconHome, IconDashboard, IconWrench, IconSettings, IconMenu, IconX } from './Icons';

interface SidebarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'landing', label: 'Home', icon: 'home' },
  { id: 'dashboard', label: 'Projects', icon: 'dashboard', shortcut: '1' },
  { id: 'convert', label: 'New Build', icon: 'wrench', shortcut: '2' },
  { id: 'devtools', label: 'Dev Tools', icon: 'terminal', shortcut: '3' },
  { id: 'settings', label: 'Settings', icon: 'settings', shortcut: '4' },
];

function getNavIcon(icon: string, size = 18) {
  switch (icon) {
    case 'home': return <IconHome size={size} />;
    case 'dashboard': return <IconDashboard size={size} />;
    case 'wrench': return <IconWrench size={size} />;
    case 'terminal': return <IconWrench size={size} />;
    case 'settings': return <IconSettings size={size} />;
    default: return null;
  }
}

export default function Sidebar({ currentPage, onNavigate }: SidebarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const isLanding = currentPage === 'landing';

  return (
    <>
      {/* Mobile toggle */}
      {!isLanding && (
        <button
          className="fixed top-4 left-4 z-30 btn btn-secondary btn-sm hide-desktop"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle navigation"
        >
          {mobileOpen ? <IconX size={16} /> : <IconMenu size={16} />}
        </button>
      )}

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/50 z-20 hide-desktop" onClick={() => setMobileOpen(false)} />
      )}

      {/* Sidebar */}
      {!isLanding && (
        <aside
          className={`fixed top-0 left-0 h-full w-56 surface-1 border-r border-subtle z-20 flex flex-col transition-transform duration-200 ${
            mobileOpen ? 'translate-x-0' : '-translate-x-full'
          } hide-desktop`}
          role="navigation"
          aria-label="Main navigation"
        >
          <SidebarContent
            items={NAV_ITEMS}
            current={currentPage}
            onNavigate={(id) => { onNavigate(id); setMobileOpen(false); }}
          />
        </aside>
      )}

      {/* Desktop sidebar */}
      {!isLanding && (
        <aside
          className="fixed top-0 left-0 h-full w-56 surface-1 border-r border-subtle z-20 flex-col hide-mobile flex"
          role="navigation"
          aria-label="Main navigation"
        >
          <SidebarContent
            items={NAV_ITEMS.filter(i => i.id !== 'landing')}
            current={currentPage}
            onNavigate={onNavigate}
          />
        </aside>
      )}
    </>
  );
}

function SidebarContent({ items, current, onNavigate }: { items: NavItem[]; current: PageId; onNavigate: (id: PageId) => void }) {
  return (
    <>
      {/* Logo */}
      <div className="px-4 py-5 border-b border-subtle">
        <button
          onClick={() => onNavigate('landing')}
          className="flex items-center gap-2.5 text-left w-full group"
        >
          <div className="w-8 h-8 rounded-lg bg-sky-500/15 border border-sky-500/25 flex items-center justify-center">
            <span className="font-mono text-sky-400 font-bold text-sm">P</span>
          </div>
          <div>
            <div className="text-sm font-semibold text-stone-100 leading-tight group-hover:text-sky-400 transition-colors">
              plix_ai
            </div>
            <div className="text-[10px] text-stone-500 uppercase tracking-wider">studio</div>
          </div>
        </button>
      </div>

      {/* Nav links */}
      <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
        {items.map(item => {
          const isActive = current === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-100 ${
                isActive
                  ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/50 border border-transparent'
              }`}
              aria-current={isActive ? 'page' : undefined}
            >
              <span className={isActive ? 'text-sky-400' : 'text-stone-500'}>
                {getNavIcon(item.icon)}
              </span>
              {item.label}
              {item.shortcut && (
                <span className="ml-auto">
                  <kbd className="kbd">{item.shortcut}</kbd>
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Demo badge */}
      <div className="px-4 py-3 border-t border-subtle">
        <div className="flex items-center gap-2 text-xs text-stone-500">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
          Demo Mode — All builds simulated
        </div>
      </div>
    </>
  );
}