import React from 'react';
import {
  ArchiveRestore,
  DatabaseBackup,
  FileBarChart2,
  History,
  Landmark,
  LayoutDashboard,
  Settings,
  Trash2,
  Wallet,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { ActiveNavRoute } from '../types/app';
import { DynamicIcon } from './DynamicIcon';
import { SULogo } from './Logo';

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ mobileOpen, onCloseMobile }) => {
  const { activeRoute, setActiveRoute, snapshot, setSettingsSection } = useApp();
  const { settings, modules, recycleBin } = snapshot;

  const customModules = modules
    .filter((m) => m.visible && !m.archived && m.status === 'published')
    .sort((a, b) => a.position - b.position);

  const navigate = (route: ActiveNavRoute, section?: string) => {
    setActiveRoute(route);
    if (section) setSettingsSection(section);
    onCloseMobile();
  };

  const navItemClass = (isActive: boolean) =>
    `w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors text-left cursor-pointer whitespace-nowrap ${
      isActive
        ? 'bg-emerald-600 text-white shadow-sm'
        : 'text-slate-200 hover:bg-white/10 hover:text-white'
    }`;

  const sidebarContent = (
    <div
      className="flex flex-col h-full text-white select-none"
      style={{ backgroundColor: settings.theme.sidebarColor }}
    >
      {/* Brand Lockup */}
      <div className="flex items-center justify-between gap-3 px-4 py-5 border-b border-white/10">
        <div className="flex items-center gap-3 min-w-0">
          <SULogo size="sm" />
          <div className="min-w-0">
            <div className="font-display font-bold text-base text-white truncate">
              {settings.appName}
            </div>
            <div className="text-xs text-emerald-300/90 truncate">{settings.appSubtitle}</div>
          </div>
        </div>
        <button
          type="button"
          onClick={onCloseMobile}
          aria-label="Close navigation menu"
          className="lg:hidden p-1.5 rounded-lg text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Primary Navigation */}
      <nav aria-label="Main navigation" className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <div className="px-3 pb-1.5 text-[11px] font-semibold tracking-wider text-slate-400">
          Core Workspace
        </div>
        <button
          type="button"
          onClick={() => navigate('dashboard')}
          className={navItemClass(activeRoute === 'dashboard')}
        >
          <LayoutDashboard className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>Dashboard</span>
        </button>
        <button
          type="button"
          onClick={() => navigate('loans')}
          className={navItemClass(activeRoute === 'loans')}
        >
          <Wallet className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>Loan Management</span>
        </button>
        <button
          type="button"
          onClick={() => navigate('committees')}
          className={navItemClass(activeRoute === 'committees')}
        >
          <Landmark className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>Committee Management</span>
        </button>

        {/* Dynamic Custom Modules */}
        <div className="pt-4 pb-1.5 px-3 flex items-center justify-between">
          <span className="text-[11px] font-semibold tracking-wider text-slate-400">
            Custom Modules
          </span>
          <button
            type="button"
            onClick={() => navigate('settings', 'modules')}
            className="text-[11px] font-medium text-emerald-300 hover:text-emerald-200 cursor-pointer"
          >
            + New
          </button>
        </div>
        {customModules.length === 0 ? (
          <div className="px-3.5 py-2 text-xs text-slate-400">
            No custom modules published yet
          </div>
        ) : (
          customModules.map((mod) => (
            <button
              key={mod.id}
              type="button"
              onClick={() => navigate(`module:${mod.id}`)}
              className={navItemClass(activeRoute === `module:${mod.id}`)}
            >
              <DynamicIcon name={mod.icon} className="w-4 h-4 shrink-0" />
              <span className="truncate">{mod.name}</span>
            </button>
          ))
        )}

        {/* Analytics & System */}
        <div className="pt-4 pb-1.5 px-3 text-[11px] font-semibold tracking-wider text-slate-400">
          System &amp; Tools
        </div>
        <button
          type="button"
          onClick={() => navigate('reports')}
          className={navItemClass(activeRoute === 'reports')}
        >
          <FileBarChart2 className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>Reports</span>
        </button>
        <button
          type="button"
          onClick={() => navigate('settings')}
          className={navItemClass(activeRoute === 'settings')}
        >
          <Settings className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>Settings &amp; App Builder</span>
        </button>
        <button
          type="button"
          onClick={() => navigate('backup')}
          className={navItemClass(activeRoute === 'backup')}
        >
          <DatabaseBackup className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>Backup &amp; Restore</span>
        </button>
        <button
          type="button"
          onClick={() => navigate('recycle-bin')}
          className={navItemClass(activeRoute === 'recycle-bin')}
        >
          <Trash2 className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span className="flex-1 truncate">Recycle Bin</span>
          {recycleBin.length > 0 && (
            <span className="text-xs font-mono-num text-emerald-300">{recycleBin.length}</span>
          )}
        </button>
        <button
          type="button"
          onClick={() => navigate('audit-log')}
          className={navItemClass(activeRoute === 'audit-log')}
        >
          <History className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>Audit Log</span>
        </button>
      </nav>

      {/* Bottom quick link to Preview & Test */}
      <div className="p-3 border-t border-white/10">
        <button
          type="button"
          onClick={() => navigate('settings', 'preview')}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-medium text-emerald-200 transition-colors cursor-pointer"
        >
          <ArchiveRestore className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Preview &amp; Test Sandbox</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop fixed sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 border-r border-slate-200 min-h-screen no-print">
        <div className="sticky top-0 h-screen">{sidebarContent}</div>
      </aside>

      {/* Mobile slide-over sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex no-print">
          <div
            className="fixed inset-0 bg-slate-950/60"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative w-72 max-w-[82vw] h-full z-10 shadow-2xl">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
