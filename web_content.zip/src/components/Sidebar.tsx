import React from 'react';
import {
  FileText,
  Wrench,
  Images,
  FileSpreadsheet,
  Database,
  Printer,
  ShieldCheck,
  CheckCircle2,
  Thermometer
} from 'lucide-react';
import { PaintingReport, MaintenanceReport, ProcedureReport } from '../types/domain';
import { Layers } from 'lucide-react';

import { Home } from 'lucide-react';

interface Props {
  paintingReports: PaintingReport[];
  maintenanceReports: MaintenanceReport[];
  procedureReports: ProcedureReport[];
  activeView: 'menu' | 'painting' | 'manutenzioni' | 'procedure' | 'galleria';
  onSelectView: (view: 'menu' | 'painting' | 'manutenzioni' | 'procedure' | 'galleria') => void;
  onExportCsv: () => void;
  onOpenBackup: () => void;
}

export const Sidebar: React.FC<Props> = ({
  paintingReports,
  maintenanceReports,
  procedureReports,
  activeView,
  onSelectView,
  onExportCsv,
  onOpenBackup
}) => {
  const totalPaintingPhotos = paintingReports.reduce((acc, r) => acc + (r.images ? r.images.length : 0), 0);
  const totalMaintPhotos = maintenanceReports.reduce((acc, r) => acc + (r.images ? r.images.length : 0), 0);
  const totalProcPhotos = procedureReports.reduce(
    (acc, r) => acc + (r.steps ? r.steps.reduce((sAcc, s) => sAcc + (s.images ? s.images.length : 0), 0) : 0),
    0
  );
  const totalPhotos = totalPaintingPhotos + totalMaintPhotos + totalProcPhotos;

  return (
    <aside className="w-64 bg-white border-r border-neutral-200 hidden md:flex flex-col justify-between shrink-0 no-print">
      <div className="p-4 space-y-6 overflow-y-auto">
        {/* Navigation */}
        <div>
          <div className="px-3 pb-2 text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
            Aree Operative
          </div>

          <nav className="space-y-1">
            <button
              onClick={() => onSelectView('menu')}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-lg transition-colors text-left ${
                activeView === 'menu'
                  ? 'bg-neutral-900 text-white font-semibold'
                  : 'text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Home className="w-4 h-4 text-current" />
                <span>Menù Principale</span>
              </div>
              <span
                className={`font-mono text-[10px] px-1.5 py-0.5 rounded ${
                  activeView === 'menu' ? 'bg-neutral-800 text-amber-300' : 'bg-neutral-100 text-neutral-600'
                }`}
              >
                Pixel 9
              </span>
            </button>

            <button
              onClick={() => onSelectView('painting')}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-lg transition-colors text-left ${
                activeView === 'painting'
                  ? 'bg-neutral-900 text-white font-semibold'
                  : 'text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <FileText className="w-4 h-4 text-current" />
                <span>Painting Reports</span>
              </div>
              <span
                className={`font-mono text-[11px] tabular-nums ${
                  activeView === 'painting' ? 'text-neutral-300' : 'text-neutral-400'
                }`}
              >
                {paintingReports.length}
              </span>
            </button>

            <button
              onClick={() => onSelectView('manutenzioni')}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-lg transition-colors text-left ${
                activeView === 'manutenzioni'
                  ? 'bg-neutral-900 text-white font-semibold'
                  : 'text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Wrench className="w-4 h-4 text-current" />
                <span>Manutenzioni Impianti</span>
              </div>
              <span
                className={`font-mono text-[11px] tabular-nums ${
                  activeView === 'manutenzioni' ? 'text-neutral-300' : 'text-neutral-400'
                }`}
              >
                {maintenanceReports.length}
              </span>
            </button>

            <button
              onClick={() => onSelectView('procedure')}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-lg transition-colors text-left ${
                activeView === 'procedure'
                  ? 'bg-neutral-900 text-white font-semibold'
                  : 'text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Layers className="w-4 h-4 text-current" />
                <span>Procedure & Schede Libere</span>
              </div>
              <span
                className={`font-mono text-[11px] tabular-nums ${
                  activeView === 'procedure' ? 'text-neutral-300' : 'text-neutral-400'
                }`}
              >
                {procedureReports.length}
              </span>
            </button>

            <button
              onClick={() => onSelectView('galleria')}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-lg transition-colors text-left ${
                activeView === 'galleria'
                  ? 'bg-neutral-900 text-white font-semibold'
                  : 'text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Images className="w-4 h-4 text-current" />
                <span>Archivio Foto</span>
              </div>
              <span
                className={`font-mono text-[11px] tabular-nums ${
                  activeView === 'galleria' ? 'text-neutral-300' : 'text-neutral-400'
                }`}
              >
                {totalPhotos}
              </span>
            </button>
          </nav>
        </div>

        {/* Industrial Quality Compliance Box */}
        <div className="p-3 bg-neutral-50 border border-neutral-200 rounded-lg space-y-2 text-xs">
          <div className="text-[11px] font-bold text-neutral-800 uppercase flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-neutral-700" />
            <span>Standard di Reparto</span>
          </div>
          <div className="space-y-1.5 text-[11px] text-neutral-600">
            <div className="flex items-center justify-between">
              <span>Sabbiatura:</span>
              <strong className="font-mono text-neutral-900">ISO 8501-1 SA 2.5</strong>
            </div>
            <div className="flex items-center justify-between">
              <span>Punto di Rugiada:</span>
              <strong className="font-mono text-emerald-700">ISO 8502-4 (ΔT ≥ 3°C)</strong>
            </div>
            <div className="flex items-center justify-between">
              <span>Rilievo DFT Secco:</span>
              <strong className="font-mono text-neutral-900">PosiTector 6000</strong>
            </div>
            <div className="flex items-center justify-between">
              <span>Pompe Verniciatura:</span>
              <strong className="font-mono text-neutral-900">Airless 68:1 / 70:1</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="p-3 border-t border-neutral-200 bg-neutral-50/50 space-y-1">
        <button
          onClick={onExportCsv}
          className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-neutral-700 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition-colors text-left"
        >
          <FileSpreadsheet className="w-3.5 h-3.5 text-neutral-500" />
          <span>Esporta Dati in Excel / CSV</span>
        </button>

        <button
          onClick={onOpenBackup}
          className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-neutral-700 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition-colors text-left"
        >
          <Database className="w-3.5 h-3.5 text-neutral-500" />
          <span>Backup / Ripristino JSON</span>
        </button>
      </div>
    </aside>
  );
};
