import React, { useState } from 'react';
import {
  Download,
  MessageSquare,
  Moon,
  Plus,
  Search,
  Settings,
  Sun,
  Trash2,
  X,
} from 'lucide-react';
import type { ChatSession, ThemeMode } from '../types/chat';

interface SidebarProps {
  chats: ChatSession[];
  currentId: string | null;
  theme: ThemeMode;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  onDeleteChat: (id: string) => void;
  onExportAll: () => void;
  onOpenSettings: () => void;
  onToggleTheme: () => void;
}

export function Sidebar({
  chats,
  currentId,
  theme,
  mobileOpen,
  onCloseMobile,
  onNewChat,
  onSelectChat,
  onDeleteChat,
  onExportAll,
  onOpenSettings,
  onToggleTheme,
}: SidebarProps) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');

  const filteredChats = query.trim()
    ? chats.filter(
        (c) =>
          c.title.toLowerCase().includes(query.toLowerCase()) ||
          c.messages.some((m) => m.text.toLowerCase().includes(query.toLowerCase()))
      )
    : chats;

  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-slate-950/60 backdrop-blur-[1px] md:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      <aside
        aria-label="Conversations"
        className={`fixed inset-y-0 left-0 z-40 flex w-[280px] shrink-0 flex-col border-r border-slate-200 bg-[#f8faff] p-4 transition-transform duration-200 ease-out dark:border-[#293449] dark:bg-[#101622] md:static md:translate-x-0 ${
          mobileOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        }`}
      >
        {/* Brand Lockup */}
        <div className="flex items-center justify-between pb-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-[13px] bg-gradient-to-br from-[#6678ff] to-[#42d8c6] font-display text-[15px] font-extrabold tracking-tight text-white shadow-md shadow-[#6678ff]/20">
              CB
            </div>
            <div className="min-w-0">
              <div className="font-display text-[17px] font-bold tracking-tight text-slate-950 dark:text-[#edf2ff] truncate">
                CB AI
              </div>
              <div className="text-[11px] text-slate-500 dark:text-[#9aa8c0] truncate">
                Your friendly AI buddy
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Close sidebar"
            className="grid h-9 w-9 place-items-center rounded-lg text-slate-500 hover:bg-slate-200/70 hover:text-slate-900 dark:text-[#9aa8c0] dark:hover:bg-[#1b2333] dark:hover:text-white md:hidden"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Primary Action */}
        <button
          type="button"
          onClick={onNewChat}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#6478ff] to-[#5367dd] px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-all duration-150 hover:brightness-110 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6478ff] whitespace-nowrap shrink-0"
        >
          <Plus className="h-4 w-4" />
          <span>New chat</span>
        </button>

        {/* Secondary Actions */}
        <div className="mt-2.5 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => {
              setSearchOpen((prev) => {
                if (prev) setQuery('');
                return !prev;
              });
            }}
            className={`inline-flex items-center justify-center gap-1.5 rounded-xl border px-3 py-2 text-[13px] font-medium transition-colors whitespace-nowrap shrink-0 ${
              searchOpen
                ? 'border-[#6478ff] bg-[#6478ff]/10 text-[#5367dd] dark:text-[#8ea0ff]'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#cbd5e8] dark:hover:bg-[#222c3f]'
            }`}
          >
            <Search className="h-3.5 w-3.5" />
            <span>Search</span>
          </button>

          <button
            type="button"
            onClick={onExportAll}
            disabled={chats.length === 0}
            className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-[13px] font-medium text-slate-700 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#cbd5e8] dark:hover:bg-[#222c3f] whitespace-nowrap shrink-0"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export</span>
          </button>
        </div>

        {/* Inline Live Search Field */}
        {searchOpen && (
          <div className="mt-2.5 relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filter chats by title or text..."
              autoFocus
              className="w-full rounded-xl border border-slate-200 bg-white py-2 pr-8 pl-3 text-[13px] text-slate-900 placeholder:text-slate-400 focus:border-[#6478ff] focus:outline-none dark:border-[#293449] dark:bg-[#0d1320] dark:text-[#edf2ff] dark:placeholder:text-[#6f7e99]"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                aria-label="Clear search"
                className="absolute top-1/2 right-2 -translate-y-1/2 rounded p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        )}

        {/* Section Heading */}
        <div className="mt-5 mb-2 flex items-center justify-between px-1 text-xs font-medium text-slate-500 dark:text-[#9aa8c0]">
          <span>Recent conversations</span>
          <span className="tabular-nums">{filteredChats.length}</span>
        </div>

        {/* Conversation History */}
        <div className="flex-1 space-y-1 overflow-y-auto pr-0.5">
          {filteredChats.length === 0 ? (
            <div className="rounded-xl px-3 py-4 text-center text-xs text-slate-500 dark:text-[#9aa8c0]">
              {query ? 'No matching chats found.' : 'No conversations yet.'}
            </div>
          ) : (
            filteredChats.map((chat) => {
              const isActive = chat.id === currentId;
              return (
                <div
                  key={chat.id}
                  className={`group flex items-center gap-2 rounded-xl border px-2.5 py-2 transition-colors ${
                    isActive
                      ? 'border-slate-300 bg-slate-200/75 text-slate-950 dark:border-[#354462] dark:bg-[#222e45] dark:text-white'
                      : 'border-transparent text-slate-700 hover:bg-slate-200/50 dark:text-[#cbd5e8] dark:hover:bg-[#172031]'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => onSelectChat(chat.id)}
                    className="flex min-w-0 flex-1 items-center gap-2 text-left text-[13.5px] font-medium"
                  >
                    <MessageSquare className="h-3.5 w-3.5 shrink-0 text-slate-400 dark:text-[#7f90ae]" />
                    <span className="truncate">{chat.title}</span>
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteChat(chat.id);
                    }}
                    aria-label={`Delete ${chat.title}`}
                    title="Delete chat"
                    className="rounded-lg p-1 text-slate-400 opacity-75 transition-opacity hover:bg-rose-500/10 hover:text-rose-500 group-hover:opacity-100 md:opacity-0 md:group-hover:opacity-100 focus:opacity-100"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Bottom Controls */}
        <div className="mt-3 flex items-center gap-2 border-t border-slate-200 pt-3 dark:border-[#293449]">
          <button
            type="button"
            onClick={onOpenSettings}
            className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-[13.5px] font-medium text-slate-700 transition-colors hover:bg-slate-100 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#edf2ff] dark:hover:bg-[#222c3f] whitespace-nowrap shrink-0"
          >
            <Settings className="h-4 w-4" />
            <span>Settings</span>
          </button>

          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 bg-white text-slate-700 transition-colors hover:bg-slate-100 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#edf2ff] dark:hover:bg-[#222c3f]"
          >
            {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
        </div>
      </aside>
    </>
  );
}
