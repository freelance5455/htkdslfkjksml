import { useEffect, useState, type FormEvent } from "react";
import { Youtube } from "lucide-react";
import { createProfile } from "@/lib/cutegirls/api";
import { ROLES, USER_RE, parseYoutubeChannel, type Me, type Role } from "@/lib/cutegirls/model";
import { clearDraft, readDraft, signInAccount, signUpAccount } from "@/lib/cutegirls/session";
import { fieldClass, primaryBtn, quietBtn } from "./bits";

export function Splash({ label }: { label?: string }) {
  return (
    <main className="grid min-h-dvh place-items-center px-6">
      <div className="text-center">
        <p className="text-xs tracking-widest text-mute">SALON</p>
        <h1 className="mt-2 font-display text-5xl text-ink">CUTEGIRLS</h1>
        <p className="mt-3 text-sm text-mute">{label ?? "نجهّز الصالون"}</p>
      </div>
    </main>
  );
}

export function LoginScreen() {
  const [mode, setMode] = useState<"in" | "up">("up");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [role, setRole] = useState<Role>("listener");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    const name = username.trim();
    if (!USER_RE.test(name)) {
      setError("اسم الحساب من 3 إلى 24 حرفاً إنجليزياً، ويطابق اسم يوتيوب.");
      return;
    }
    if (password.length < 8) {
      setError("كلمة المرور ثمانية أحرف على الأقل.");
      return;
    }
    if (mode === "up") {
      if (password !== confirm) {
        setError("كلمتا المرور غير متطابقتين.");
        return;
      }
      const channel = parseYoutubeChannel(youtubeUrl);
      if (!channel) {
        setError("ضع رابط القناة هكذا: youtube.com/@username");
        return;
      }
      if (channel.handle.toLowerCase() !== name.toLowerCase()) {
        setError("اسم الحساب يجب أن يكون نفس الاسم بعد @ في يوتيوب.");
        return;
      }
    }
    setPending(true);
    try {
      const result =
        mode === "up"
          ? await signUpAccount({ username: name, youtubeUrl, role }, password)
          : await signInAccount(name, password);
      if (!result.ok) setError(result.error);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر إتمام الطلب");
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="mx-auto grid min-h-dvh w-full max-w-6xl items-stretch gap-8 px-4 py-8 md:grid-cols-2 md:px-8">
      <section className="flex flex-col justify-center">
        <p className="text-xs tracking-widest text-rose">CUTEGIRLS</p>
        <h1 className="mt-3 max-w-md font-display text-4xl leading-tight text-ink md:text-5xl">
          صالون هادئ، باسم قناتك
        </h1>
        <p className="mt-3 max-w-md text-sm leading-7 text-mute">
          سجّل باسم يوتيوب نفسه. المنشورات ظاهرة للجميع، والمجموعة الشاملة مفتوحة لك منذ اللحظة الأولى.
        </p>
        <form onSubmit={onSubmit} className="mt-8 max-w-md space-y-4">
          <div className="grid grid-cols-2 gap-2 rounded-full bg-paper p-1 shadow-card">
            <button
              type="button"
              className={`min-h-11 rounded-full text-sm ${mode === "up" ? "bg-rose text-paper" : "text-mute"}`}
              onClick={() => setMode("up")}
            >
              حساب جديد
            </button>
            <button
              type="button"
              className={`min-h-11 rounded-full text-sm ${mode === "in" ? "bg-rose text-paper" : "text-mute"}`}
              onClick={() => setMode("in")}
            >
              دخول
            </button>
          </div>
          <label className="block space-y-1.5 text-sm">
            <span className="text-mute">اسم الحساب</span>
            <input
              className={`${fieldClass} h-12`}
              autoComplete="username"
              dir="ltr"
              placeholder="yourchannel"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </label>
          <label className="block space-y-1.5 text-sm">
            <span className="text-mute">كلمة المرور</span>
            <input
              className={`${fieldClass} h-12`}
              type="password"
              autoComplete={mode === "up" ? "new-password" : "current-password"}
              dir="ltr"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          {mode === "up" ? (
            <>
              <label className="block space-y-1.5 text-sm">
                <span className="text-mute">تأكيد كلمة المرور</span>
                <input
                  className={`${fieldClass} h-12`}
                  type="password"
                  autoComplete="new-password"
                  dir="ltr"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                />
              </label>
              <label className="block space-y-1.5 text-sm">
                <span className="text-mute">رابط قناة يوتيوب</span>
                <input
                  className={`${fieldClass} h-12`}
                  dir="ltr"
                  placeholder="https://youtube.com/@yourchannel"
                  value={youtubeUrl}
                  onChange={(e) => setYoutubeUrl(e.target.value)}
                />
              </label>
              <fieldset className="space-y-2">
                <legend className="text-sm text-mute">الدور</legend>
                <div className="grid grid-cols-2 gap-2">
                  {ROLES.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setRole(item.id)}
                      className={`min-h-20 rounded-3xl px-3 py-3 text-start shadow-card ${
                        role === item.id ? "bg-rose text-paper" : "bg-paper text-ink"
                      }`}
                    >
                      <span className="block font-display text-xl">{item.label}</span>
                      <span className={`mt-1 block text-xs leading-5 ${role === item.id ? "text-paper/80" : "text-mute"}`}>
                        {item.hint}
                      </span>
                    </button>
                  ))}
                </div>
              </fieldset>
            </>
          ) : null}
          {error ? <p className="text-sm text-rose">{error}</p> : null}
          <button className={`${primaryBtn} w-full`} type="submit" disabled={pending}>
            {pending ? "لحظات…" : mode === "up" ? "إنشاء الحساب" : "دخول"}
          </button>
        </form>
      </section>
      <aside className="hidden flex-col justify-end rounded-3xl bg-ink p-8 text-paper md:flex">
        <p className="text-xs tracking-widest text-paper/60">A QUIET ROOM</p>
        <h2 className="mt-4 max-w-sm font-display text-4xl leading-tight">فضفضة، مسابقة، معلومة، أو نشرة.</h2>
        <ul className="mt-8 space-y-4 text-sm leading-6 text-paper/75">
          <li>لمسات بدل الإعجاب المعتاد: بريق، تاج، ريشة، ماسة، هلال، ورد.</li>
          <li>ملصقات داخل التعليقات، وشريط للريلز، ورف للسيبلمنال.</li>
          <li>أربع غرف: الشاملة، العائلة البيولوجية، اليانديري، والخاطب.</li>
        </ul>
      </aside>
    </main>
  );
}

export function Onboard({ me, onDone }: { me: Me; onDone: () => void }) {
  const [username, setUsername] = useState(me.accountUsername ?? "");
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [role, setRole] = useState<Role>("listener");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const locked = Boolean(me.accountUsername);

  useEffect(() => {
    const draft = readDraft();
    if (!draft) return;
    if (!me.accountUsername || draft.username.toLowerCase() === me.accountUsername) {
      setUsername(draft.username);
      setYoutubeUrl(draft.youtubeUrl);
      setRole(draft.role);
    }
  }, [me.accountUsername]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setPending(true);
    setError(null);
    try {
      const result = await createProfile({ data: { username: username.trim(), youtubeUrl, role } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      clearDraft();
      onDone();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر حفظ الملف");
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-lg flex-col justify-center px-4 py-10">
      <p className="text-xs tracking-widest text-rose">الملف</p>
      <h1 className="mt-2 font-display text-4xl">أكمل بطاقتك</h1>
      <p className="mt-2 text-sm leading-6 text-mute">
        الاسم الظاهر للناس هو اسم قناتك. من يزور حسابك يجد رابط يوتيوب.
      </p>
      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <label className="block space-y-1.5 text-sm">
          <span className="text-mute">اسم الحساب</span>
          <input
            className={`${fieldClass} h-12`}
            dir="ltr"
            value={username}
            readOnly={locked}
            onChange={(e) => setUsername(e.target.value)}
          />
        </label>
        <label className="block space-y-1.5 text-sm">
          <span className="flex items-center gap-1.5 text-mute">
            <Youtube className="size-4" aria-hidden="true" />
            رابط القناة
          </span>
          <input
            className={`${fieldClass} h-12`}
            dir="ltr"
            placeholder="https://youtube.com/@name"
            value={youtubeUrl}
            onChange={(e) => setYoutubeUrl(e.target.value)}
          />
        </label>
        <div className="grid grid-cols-2 gap-2">
          {ROLES.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setRole(item.id)}
              className={`min-h-16 rounded-3xl px-3 text-start ${role === item.id ? "bg-rose text-paper" : "bg-paper text-ink shadow-card"}`}
            >
              <span className="font-display text-xl">{item.label}</span>
            </button>
          ))}
        </div>
        {error ? <p className="text-sm text-rose">{error}</p> : null}
        <button className={`${primaryBtn} w-full`} disabled={pending} type="submit">
          {pending ? "نحفظ…" : "دخول الصالون"}
        </button>
        <p className="text-center text-xs text-mute">ستنضم تلقائياً إلى الجماعة الشاملة.</p>
      </form>
      <button type="button" className={`${quietBtn} mt-4`} onClick={() => void import("@/lib/auth/client").then((m) => m.signOut("/login"))}>
        خروج
      </button>
    </main>
  );
}
