/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useNetwork } from '../context/NetworkContext';
import { SpeedometerGauge } from './SpeedometerGauge';
import { ThroughputChart } from './ThroughputChart';
import { SpeedTestModal } from './SpeedTestModal';
import { AndroidApkModal } from './AndroidApkModal';
import { 
  Wifi, 
  Gamepad2, 
  Smartphone, 
  Zap, 
  Radar, 
  HardDriveDownload, 
  HardDriveUpload, 
  Sliders, 
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Tv,
  Laptop,
  Download
} from 'lucide-react';
import { TabType } from './NavigationBottomBar';

interface DashboardTabProps {
  onNavigateTab: (tab: TabType) => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({ onNavigateTab }) => {
  const { 
    metrics, 
    history, 
    devices, 
    gamingConfig, 
    setGamingModeEnabled, 
    scanForDevices, 
    isScanningDevices,
    router,
    distributionMode
  } = useNetwork();

  const [isSpeedTestOpen, setIsSpeedTestOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  const activeOnlineDevices = devices.filter(d => d.isOnline);
  // Sort top 3 consumers by current download speed
  const topConsumers = [...devices]
    .filter(d => d.isOnline && !d.isPaused)
    .sort((a, b) => (b.currentDlMbps + b.currentUlMbps) - (a.currentDlMbps + a.currentUlMbps))
    .slice(0, 3);

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'console': return Gamepad2;
      case 'tv': return Tv;
      case 'pc': return Laptop;
      default: return Smartphone;
    }
  };

  return (
    <div className="space-y-4 pb-20 pt-1">
      {/* Network Overview Card */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-slate-800/90 p-4 shadow-md">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Wifi className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight">
                  {metrics.wifiSsid}
                </h2>
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Online
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                <span>{metrics.wifiBand}</span>
                <span>·</span>
                <span>{metrics.linkSpeedMbps} Mbps PHY</span>
                <span>·</span>
                <span>RSSI {metrics.wifiSignalDbm} dBm</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => setIsSpeedTestOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600/20 border border-cyan-500/40 hover:bg-cyan-600/30 text-cyan-300 text-xs font-medium transition active:scale-95"
          >
            <Zap className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
            <span>Speed Test</span>
          </button>
        </div>

        {/* Sub-info banner */}
        <div className="mt-3 pt-3 border-t border-slate-800/70 grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] text-slate-400">
          <div>
            <span className="text-slate-500">Gateway: </span>
            <span className="font-mono text-slate-300">{metrics.gatewayIp}</span>
          </div>
          <div>
            <span className="text-slate-500">Router: </span>
            <span className="text-slate-300 truncate">{router.brand.toUpperCase()}</span>
          </div>
          <div className="hidden sm:block">
            <span className="text-slate-500">Public IP: </span>
            <span className="font-mono text-slate-300">{metrics.publicIp}</span>
          </div>
        </div>
      </div>

      {/* APK Phone Install Banner */}
      <div 
        onClick={() => setIsApkModalOpen(true)}
        className="cursor-pointer p-3 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-cyan-950/40 border border-emerald-500/30 hover:border-emerald-500/50 flex items-center justify-between gap-3 shadow-sm transition active:scale-[0.99]"
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 shrink-0">
            <Smartphone className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-white flex items-center gap-1.5 flex-wrap">
              <span>Install NetPulse on Android Phone</span>
              <span className="text-[9px] font-mono font-bold text-emerald-300 bg-emerald-500/20 px-1.5 py-0.2 rounded">
                .APK / WebAPK
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate">
              Tap to install directly onto your phone or download standalone APK
            </p>
          </div>
        </div>

        <button
          type="button"
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shrink-0 shadow-md transition"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Get APK</span>
        </button>
      </div>

      {/* Speedometer Gauge Component */}
      <SpeedometerGauge
        downloadMbps={metrics.currentDownloadMbps}
        uploadMbps={metrics.currentUploadMbps}
        maxScaleMbps={500}
        pingMs={metrics.pingMs}
        jitterMs={metrics.jitterMs}
        bufferbloatGrade={metrics.bufferbloatGrade}
      />

      {/* Quick Action Cards Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* Gaming Mode Quick Card */}
        <div 
          onClick={() => setGamingModeEnabled(!gamingConfig.enabled)}
          className={`cursor-pointer p-3.5 rounded-2xl border transition-all active:scale-[0.98] ${
            gamingConfig.enabled
              ? 'bg-gradient-to-br from-indigo-950/60 to-purple-950/40 border-purple-500/40 shadow-md shadow-purple-950/20'
              : 'bg-slate-900/80 border-slate-800/80 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className={`p-2 rounded-xl ${gamingConfig.enabled ? 'bg-purple-500/20 text-purple-400' : 'bg-slate-800 text-slate-400'}`}>
              <Gamepad2 className="w-4 h-4" />
            </div>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
              gamingConfig.enabled 
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' 
                : 'bg-slate-800 text-slate-400'
            }`}>
              {gamingConfig.enabled ? 'ACTIVE' : 'OFF'}
            </span>
          </div>
          <div className="mt-2.5">
            <div className="text-xs font-bold text-white">Gaming Priority</div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {gamingConfig.enabled ? 'Low-latency SQM Cake active' : 'Tap to prioritize games'}
            </div>
          </div>
        </div>

        {/* Scan Network Quick Card */}
        <div 
          onClick={() => {
            if (!isScanningDevices) scanForDevices();
          }}
          className="cursor-pointer p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-slate-700 transition-all active:scale-[0.98]"
        >
          <div className="flex items-center justify-between">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Radar className={`w-4 h-4 ${isScanningDevices ? 'animate-spin' : ''}`} />
            </div>
            <span className="text-[10px] font-mono text-cyan-400">
              {activeOnlineDevices.length} Online
            </span>
          </div>
          <div className="mt-2.5">
            <div className="text-xs font-bold text-white">Device Discovery</div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {isScanningDevices ? 'Scanning 192.168.1.0/24...' : 'Tap to scan LAN'}
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Throughput Rolling Graph */}
      <ThroughputChart history={history} />

      {/* 24-Hour Usage & Quality Overview */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
            <HardDriveDownload className="w-3.5 h-3.5 text-cyan-400" />
            <span>Today's Download</span>
          </div>
          <div className="text-xl font-extrabold text-white font-mono">
            {metrics.totalDownloadedGb} <span className="text-xs font-normal text-slate-400">GB</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            Peak: {metrics.peakDownloadMbps} Mbps
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
            <HardDriveUpload className="w-3.5 h-3.5 text-purple-400" />
            <span>Today's Upload</span>
          </div>
          <div className="text-xl font-extrabold text-white font-mono">
            {metrics.totalUploadedGb} <span className="text-xs font-normal text-slate-400">GB</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            Peak: {metrics.peakUploadMbps} Mbps
          </div>
        </div>
      </div>

      {/* Top Bandwidth Consumers Section */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800/80 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Top Active Clients
            </h3>
          </div>
          <button
            onClick={() => onNavigateTab('devices')}
            className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 transition"
          >
            <span>Manage All ({devices.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {topConsumers.map(dev => {
            const Icon = getDeviceIcon(dev.type);
            const totalSpeed = dev.currentDlMbps + dev.currentUlMbps;
            const hasLimit = dev.downloadLimitMbps !== null;

            return (
              <div 
                key={dev.id}
                onClick={() => onNavigateTab('devices')}
                className="cursor-pointer flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/60 hover:border-slate-700 transition"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="p-2 rounded-lg bg-slate-800 text-slate-300">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-semibold text-white truncate max-w-[140px] sm:max-w-none">
                        {dev.customAlias || dev.name}
                      </span>
                      {dev.isGamingPriority && (
                        <span className="text-[9px] font-bold text-purple-300 bg-purple-500/20 px-1.5 py-0.2 rounded">
                          VIP
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {dev.ip} · {dev.wifiBand}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs font-bold text-cyan-300 font-mono">
                    {totalSpeed.toFixed(1)} <span className="text-[10px] text-slate-400 font-normal">Mbps</span>
                  </div>
                  <div className="text-[10px] text-slate-500">
                    {hasLimit ? `Capped ${dev.downloadLimitMbps}M` : 'Unlimited'}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Speed Test Modal */}
      <SpeedTestModal
        isOpen={isSpeedTestOpen}
        onClose={() => setIsSpeedTestOpen(false)}
      />

      {/* APK & Mobile Installation Modal */}
      <AndroidApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </div>
  );
};
