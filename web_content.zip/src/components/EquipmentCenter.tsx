import React, { useState, useRef } from 'react';
import { UserProfile, MarketItem, ItemCategory } from '../types';
import { Palette, Award, Sparkles, User, Camera, Trash2, Check, ExternalLink, LogOut } from 'lucide-react';
import { playEquipSound, playErrorSound } from '../utils/soundEffects';
import { triggerConfetti } from '../utils/confetti';

interface EquipmentCenterProps {
  user: UserProfile;
  marketItems: MarketItem[];
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onEquipItem: (category: ItemCategory, itemIdOrValue: string) => void;
  onLogout?: () => void;
  soundEnabled: boolean;
}

export const EquipmentCenter: React.FC<EquipmentCenterProps> = ({
  user,
  marketItems,
  onUpdateProfile,
  onEquipItem,
  onLogout,
  soundEnabled,
}) => {
  const [activeSection, setActiveSection] = useState<'profile' | 'themes' | 'frames' | 'titles' | 'avatars'>('profile');
  const [editName, setEditName] = useState(user.name);
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [isSavedNotice, setIsSavedNotice] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Owned items filtered
  const ownedItems = marketItems.filter((item) => user.inventory.includes(item.id));
  const ownedThemes = ownedItems.filter((i) => i.category === 'theme');
  const ownedFrames = ownedItems.filter((i) => i.category === 'frame');
  const ownedTitles = ownedItems.filter((i) => i.category === 'title');
  const ownedAvatars = ownedItems.filter((i) => i.category === 'avatar');

  // Handle local image file upload with lightweight compression
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      if (soundEnabled) playErrorSound();
      alert('يرجى اختيار ملف صورة صالح (PNG, JPG, WEBP)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (readerEvent) => {
      const img = new Image();
      img.onload = () => {
        // Resize to 256x256 max for storage efficiency
        const canvas = document.createElement('canvas');
        const maxDim = 256;
        let w = img.width;
        let h = img.height;
        if (w > h) {
          if (w > maxDim) {
            h = Math.round((h * maxDim) / w);
            w = maxDim;
          }
        } else {
          if (h > maxDim) {
            w = Math.round((w * maxDim) / h);
            h = maxDim;
          }
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, w, h);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          onUpdateProfile({ customAvatarUrl: dataUrl });
          if (soundEnabled) playEquipSound();
          triggerConfetti();
        }
      };
      img.src = readerEvent.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleApplyUrlImage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageUrlInput.trim()) return;
    onUpdateProfile({ customAvatarUrl: imageUrlInput.trim() });
    setImageUrlInput('');
    if (soundEnabled) playEquipSound();
    triggerConfetti();
  };

  const handleDeletePhoto = () => {
    onUpdateProfile({ customAvatarUrl: undefined });
    if (soundEnabled) playEquipSound();
    alert('تم حذف صورتك الشخصية والعودة للأفاتار التعبيري المجهز بنجاح 🗑️');
  };

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) return;
    onUpdateProfile({ name: editName.trim() });
    if (soundEnabled) playEquipSound();
    setIsSavedNotice(true);
    setTimeout(() => setIsSavedNotice(false), 2500);
  };

  const handleEquip = (cat: ItemCategory, val: string) => {
    onEquipItem(cat, val);
    if (soundEnabled) playEquipSound();
    triggerConfetti();
  };

  return (
    <div className="py-3 px-2 max-w-2xl mx-auto">
      
      {/* Live Profile Card Preview */}
      <div className="p-5 rounded-3xl bg-gradient-to-b from-slate-900/90 via-slate-900/80 to-indigo-950/40 border border-slate-800 mb-6 shadow-xl relative overflow-hidden">
        <div className="text-center text-xs font-bold text-indigo-400 mb-3 flex items-center justify-center gap-1.5">
          <Sparkles className="w-4 h-4" />
          <span>معاينة بطاقة حسابك الحية (Live Profile Card)</span>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-center sm:text-right">
          
          {/* Avatar with Equipped Animated Glowing Frame */}
          {(() => {
            const activeCustomFrame = marketItems.find(
              (i) => (i.id === user.frame || i.cssClass === user.frame) && i.customFrameConfig
            );
            return (
              <div className="relative shrink-0">
                <div
                  style={
                    activeCustomFrame?.customFrameConfig
                      ? {
                          borderWidth: `${activeCustomFrame.customFrameConfig.borderWidth || 3}px`,
                          borderStyle: 'solid',
                          borderColor: activeCustomFrame.customFrameConfig.borderColor1,
                          boxShadow: `0 0 25px ${activeCustomFrame.customFrameConfig.glowColor}`,
                        }
                      : undefined
                  }
                  className={`w-20 h-20 rounded-full flex items-center justify-center bg-slate-950 overflow-hidden shadow-2xl transition-all ${
                    activeCustomFrame?.customFrameConfig
                      ? activeCustomFrame.customFrameConfig.animation === 'spin'
                        ? 'animate-spin'
                        : 'animate-pulse'
                      : user.frame && user.frame !== 'none'
                      ? user.frame
                      : 'border-2 border-slate-700'
                  }`}
                >
                  {user.customAvatarUrl ? (
                    <img
                      src={user.customAvatarUrl}
                      alt={user.name}
                      className="w-full h-full object-cover"
                    />
                  ) : user.avatar && user.avatar.startsWith('data:image/') ? (
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-full h-full object-contain p-1"
                    />
                  ) : (
                    <span className="text-4xl select-none">{user.avatar || '🦅'}</span>
                  )}
                </div>

                {/* Level Pill */}
                <div className="absolute -bottom-1 -right-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-xs font-black px-2 py-0.5 rounded-full border border-slate-900 shadow">
                  مستوى {user.level}
                </div>
              </div>
            );
          })()}

          {/* User Details */}
          <div>
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <h2 className="text-xl font-black text-white">{user.name}</h2>
              {user.role === 'founder' && (
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-black">
                  👑 مؤسس وقتي
                </span>
              )}
            </div>

            <div className="flex items-center justify-center sm:justify-start gap-1.5 mt-1 text-sm font-bold text-amber-400">
              <Award className="w-4 h-4" />
              <span>{user.title || 'منجز واعد'}</span>
            </div>

            <p className="text-xs text-slate-400 mt-1 font-mono">
              {user.email} • {user.xp} XP • {user.streak} يوم متتالي 🔥
            </p>
          </div>

        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex bg-slate-950/80 p-1.5 rounded-2xl border border-slate-800 mb-5 overflow-x-auto gap-1">
        <button
          onClick={() => setActiveSection('profile')}
          className={`flex-1 min-w-[90px] py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeSection === 'profile' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          👤 البروفايل والصورة
        </button>
        <button
          onClick={() => setActiveSection('themes')}
          className={`flex-1 min-w-[70px] py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeSection === 'themes' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          🎨 الثيمات ({ownedThemes.length})
        </button>
        <button
          onClick={() => setActiveSection('frames')}
          className={`flex-1 min-w-[70px] py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeSection === 'frames' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          🖼️ الإطارات ({ownedFrames.length})
        </button>
        <button
          onClick={() => setActiveSection('titles')}
          className={`flex-1 min-w-[70px] py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeSection === 'titles' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          📜 الألقاب ({ownedTitles.length})
        </button>
        <button
          onClick={() => setActiveSection('avatars')}
          className={`flex-1 min-w-[70px] py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeSection === 'avatars' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          🎭 الأفاتارات ({ownedAvatars.length})
        </button>
      </div>

      {/* 1. Profile & Photo Customization */}
      {activeSection === 'profile' && (
        <div className="space-y-4 text-right">
          
          {/* Edit Display Name */}
          <form onSubmit={handleSaveName} className="p-4 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-slate-300">تعديل اسمك المعروض في التطبيق:</h3>
            <div className="flex gap-2">
              <input
                type="text"
                required
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 text-right"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                حفظ الاسم
              </button>
            </div>
            {isSavedNotice && (
              <span className="text-xs text-emerald-400 font-bold">✓ تم حفظ الاسم بنجاح</span>
            )}
          </form>

          {/* Photo Management */}
          <div className="p-4 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
            <h3 className="text-xs font-bold text-slate-300 flex items-center justify-between">
              <span>الصورة الشخصية للبروفايل:</span>
              {user.customAvatarUrl && (
                <button
                  type="button"
                  onClick={handleDeletePhoto}
                  className="px-3 py-1.5 rounded-xl bg-red-950/60 hover:bg-red-900/80 border border-red-500/40 text-red-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5 text-red-400" />
                  <span>حذف الصورة 🗑️</span>
                </button>
              )}
            </h3>

            {/* Option A: Upload from Device */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-850 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-right">
                <p className="text-xs font-bold text-slate-200">رفع صورة من جهازك مباشرة</p>
                <p className="text-[11px] text-slate-400">يدعم ملفات JPG, PNG بحجم خفيف وتلقائي</p>
              </div>

              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="py-2 px-4 rounded-xl bg-indigo-600/80 hover:bg-indigo-600 text-white text-xs font-bold flex items-center gap-2 cursor-pointer transition-colors"
              >
                <Camera className="w-4 h-4" />
                <span>اختيار صورة من الجهاز</span>
              </button>
            </div>

            {/* Option B: Enter URL */}
            <form onSubmit={handleApplyUrlImage} className="space-y-2">
              <label className="block text-[11px] text-slate-400">أو إضافة صورة عبر رابط مباشر (URL):</label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={imageUrlInput}
                  onChange={(e) => setImageUrlInput(e.target.value)}
                  placeholder="https://example.com/avatar.jpg"
                  dir="ltr"
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 text-left font-mono"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
                >
                  تطبيق الرابط
                </button>
              </div>
            </form>
          </div>

          {/* Prominent Account Logout Section */}
          <div className="p-4 rounded-3xl bg-red-950/25 border border-red-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 text-right">
            <div>
              <h4 className="text-xs font-black text-red-300">تسجيل الخروج من الحساب</h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                إنهاء الجلسة الحالية والعودة لشاشة الدخول (بياناتك ورصيدك ومقتنياتك محفوظة في السحابة)
              </p>
            </div>

            {onLogout && (
              <button
                type="button"
                onClick={onLogout}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 cursor-pointer transition-all"
              >
                <LogOut className="w-4 h-4" />
                <span>تسجيل الخروج 🚪</span>
              </button>
            )}
          </div>

        </div>
      )}

      {/* 2. Equipped Themes */}
      {activeSection === 'themes' && (
        <div className="space-y-3">
          <div className="text-xs text-slate-400 text-right mb-2">
            انقر على أي ثيم مملوك لتفعيله فوراً وتغيير شكل وألوان التطبيق كاملاً:
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {ownedThemes.map((theme) => {
              const isEquipped = user.theme === theme.id;
              return (
                <div
                  key={theme.id}
                  className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between ${
                    isEquipped
                      ? 'bg-indigo-950/40 border-indigo-500 shadow-md shadow-indigo-500/20'
                      : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{theme.icon || '🎨'}</span>
                    <div className="text-right">
                      <h4 className="text-xs sm:text-sm font-black text-white">{theme.name}</h4>
                      <p className="text-[11px] text-slate-400 line-clamp-1">{theme.description}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleEquip('theme', theme.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                      isEquipped
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                    }`}
                  >
                    {isEquipped ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>مفعّل الآن</span>
                      </>
                    ) : (
                      <span>تفعيل الثيم</span>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. Equipped Frames */}
      {activeSection === 'frames' && (
        <div className="space-y-3">
          <div className="text-xs text-slate-400 text-right mb-2">
            اختر الإطار المتوهج ليحيط بصورتك في كافة أقسام التطبيق:
          </div>

          {/* None frame option */}
          <div
            className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between ${
              user.frame === 'none'
                ? 'bg-indigo-950/40 border-indigo-500 shadow-md'
                : 'bg-slate-900/80 border-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full border-2 border-slate-700 flex items-center justify-center text-sm font-bold text-slate-400">
                بدون
              </div>
              <div className="text-right">
                <h4 className="text-xs font-black text-white">إطار كلاسيكي هادئ</h4>
                <p className="text-[11px] text-slate-400">بدون أي تأثيرات حركية</p>
              </div>
            </div>
            <button
              onClick={() => handleEquip('frame', 'none')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                user.frame === 'none'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              {user.frame === 'none' ? 'مفعّل' : 'تجهيز'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {ownedFrames.map((frame) => {
              const isEquipped = user.frame === frame.cssClass || user.frame === frame.id;
              return (
                <div
                  key={frame.id}
                  className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between ${
                    isEquipped
                      ? 'bg-indigo-950/40 border-indigo-500 shadow-md shadow-indigo-500/20'
                      : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      style={
                        frame.customFrameConfig
                          ? {
                              borderWidth: `${frame.customFrameConfig.borderWidth || 3}px`,
                              borderStyle: 'solid',
                              borderColor: frame.customFrameConfig.borderColor1,
                              boxShadow: `0 0 15px ${frame.customFrameConfig.glowColor}`,
                            }
                          : undefined
                      }
                      className={`w-11 h-11 rounded-full bg-slate-950 flex items-center justify-center text-xl shrink-0 ${
                        frame.customFrameConfig
                          ? frame.customFrameConfig.animation === 'spin'
                            ? 'animate-spin'
                            : 'animate-pulse'
                          : frame.cssClass || 'border border-slate-700'
                      }`}
                    >
                      {user.avatar && user.avatar.startsWith('data:image/') ? (
                        <img src={user.avatar} alt="Avatar" className="w-8 h-8 rounded-full object-contain" />
                      ) : (
                        user.avatar || '🦅'
                      )}
                    </div>
                    <div className="text-right">
                      <h4 className="text-xs font-black text-white">{frame.name}</h4>
                      <p className="text-[10px] text-slate-400 line-clamp-1">{frame.description}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleEquip('frame', frame.cssClass || frame.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                      isEquipped
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                    }`}
                  >
                    {isEquipped ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>مجهز</span>
                      </>
                    ) : (
                      <span>ارتداء</span>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. Equipped Titles */}
      {activeSection === 'titles' && (
        <div className="space-y-3">
          <div className="text-xs text-slate-400 text-right mb-2">
            ثبّت لقبك المفضل ليظهر تحت اسمك مباشرة في كل مكان:
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {ownedTitles.map((title) => {
              const isEquipped = user.title === title.name;
              return (
                <div
                  key={title.id}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between ${
                    isEquipped
                      ? 'bg-indigo-950/40 border-indigo-500 shadow-md'
                      : 'bg-slate-900/80 border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{title.icon || '📜'}</span>
                    <span className="text-xs font-black text-white">{title.name}</span>
                  </div>

                  <button
                    onClick={() => handleEquip('title', title.name)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                      isEquipped
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                    }`}
                  >
                    {isEquipped ? 'مُثبّت ✓' : 'تثبيت اللقب'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 5. Equipped Avatars */}
      {activeSection === 'avatars' && (
        <div className="space-y-3">
          <div className="text-xs text-slate-400 text-right mb-2">
            اختر الأفاتار التعبيري الفخم الذي يمثلك:
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {ownedAvatars.map((av) => {
              const avatarValue = av.customDrawing || av.icon || '🦅';
              const isEquipped = user.avatar === avatarValue;
              return (
                <div
                  key={av.id}
                  onClick={() => handleEquip('avatar', avatarValue)}
                  className={`p-3 rounded-2xl border text-center transition-all cursor-pointer ${
                    isEquipped
                      ? 'bg-indigo-950/50 border-indigo-500 shadow-lg scale-102'
                      : 'bg-slate-900/80 hover:bg-slate-800/80 border-slate-800'
                  }`}
                >
                  <div className="w-14 h-14 mx-auto mb-1.5 flex items-center justify-center">
                    {av.customDrawing ? (
                      <img src={av.customDrawing} alt={av.name} className="w-full h-full object-contain rounded-2xl border border-indigo-500/30" />
                    ) : (
                      <span className="text-4xl">{av.icon}</span>
                    )}
                  </div>
                  <div className="text-xs font-black text-slate-100 truncate">{av.name}</div>
                  <div className="mt-2">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        isEquipped ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {isEquipped ? 'مُعتمد ✓' : 'انقر للاعتماد'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

    </div>
  );
};
