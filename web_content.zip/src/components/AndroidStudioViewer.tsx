import React, { useState } from 'react';
import {
  FileCode,
  Copy,
  Check,
  Download,
  Folder,
  FolderOpen,
  Code2,
  Terminal,
  ExternalLink,
} from 'lucide-react';
import { ANDROID_PROJECT_FILES } from '../android_code/androidProjectData';
import { AndroidProjectFile } from '../types';

interface AndroidStudioViewerProps {
  onExportZip: () => void;
  isExportingZip: boolean;
}

export const AndroidStudioViewer: React.FC<AndroidStudioViewerProps> = ({
  onExportZip,
  isExportingZip,
}) => {
  const [selectedFile, setSelectedFile] = useState<AndroidProjectFile>(ANDROID_PROJECT_FILES[5]); // Default MainActivity.kt
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Top Banner */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Code2 className="w-5 h-5 text-orange-400" />
            <span>एंड्रॉइड स्टूडियो सोर्स कोड एक्सप्लोरर (Native Kotlin & Compose Files)</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            सभी {ANDROID_PROJECT_FILES.length} प्रोडक्शन-ग्रेड फ़ाइलें। आप सीधे कोड कॉपी कर सकते हैं या संपूर्ण .ZIP प्रोजेक्ट डाउनलोड कर सकते हैं।
          </p>
        </div>

        <button
          onClick={onExportZip}
          disabled={isExportingZip}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs transition-colors shadow-sm whitespace-nowrap self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>{isExportingZip ? 'ज़िप बन रहा है...' : 'एंड्रॉइड स्टूडियो ज़िप (.ZIP)'}</span>
        </button>
      </div>

      {/* Main IDE Layout: Sidebar Files + Code View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left: Project File Tree (3 cols) */}
        <div className="lg:col-span-4 rounded-2xl border border-slate-800 bg-slate-900/70 p-3 flex flex-col gap-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 px-1">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <FolderOpen className="w-4 h-4 text-orange-400" />
              <span>HindiVideoTranslator/</span>
            </span>
            <span className="text-[10px] text-slate-500 font-mono">
              {ANDROID_PROJECT_FILES.length} फ़ाइलें
            </span>
          </div>

          <div className="flex flex-col gap-1 max-h-[620px] overflow-y-auto pr-1">
            {ANDROID_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-2.5 rounded-xl text-xs transition-all flex items-start gap-2.5 ${
                    isSelected
                      ? 'bg-orange-600/15 border border-orange-500/50 text-orange-200 font-semibold'
                      : 'hover:bg-slate-800/60 text-slate-400 hover:text-slate-200 border border-transparent'
                  }`}
                >
                  <FileCode
                    className={`w-4 h-4 shrink-0 mt-0.5 ${
                      isSelected ? 'text-orange-400' : 'text-slate-500'
                    }`}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-mono text-[11px]">{file.filename}</p>
                    <p className="text-[10px] text-slate-500 truncate mt-0.5">
                      {file.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Code Viewer (8 cols) */}
        <div className="lg:col-span-8 rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden flex flex-col">
          {/* File Tab Bar */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/80">
            <div className="flex items-center gap-2 font-mono text-xs text-slate-200 truncate">
              <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-orange-400 font-bold uppercase">
                {selectedFile.language}
              </span>
              <span className="truncate">{selectedFile.path}</span>
            </div>

            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors shrink-0"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">कॉपी हो गया!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>कोड कॉपी करें</span>
                </>
              )}
            </button>
          </div>

          {/* Description banner */}
          <div className="px-4 py-2 bg-slate-900/40 border-b border-slate-800/60 text-xs text-slate-400">
            {selectedFile.description}
          </div>

          {/* Code Content */}
          <div className="p-4 max-h-[560px] overflow-auto">
            <pre className="font-mono text-xs text-slate-300 leading-relaxed whitespace-pre selection:bg-orange-500/30 selection:text-orange-200">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
