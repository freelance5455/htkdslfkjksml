import type { ReactNode } from "react";
import { lookupTokens } from "@/data/glossary";
import { useWord } from "@/components/word-context";

const WORD = /[A-Za-zÀ-ÖØ-öø-ÿ0-9’']+/;

export function ItText({ text, className }: { text: string; className?: string }) {
  const open = useWord();
  const parts = text.split(/([^A-Za-zÀ-ÖØ-öø-ÿ0-9’']+)/);
  const tokens = parts.filter((p) => WORD.test(p));
  const nodes: ReactNode[] = [];
  let ti = 0;

  for (let i = 0; i < parts.length; ) {
    const part = parts[i] ?? "";
    if (!WORD.test(part)) {
      nodes.push(part);
      i += 1;
      continue;
    }
    const rest = tokens.slice(ti);
    const hit = lookupTokens(rest);
    const len = hit?.len ?? 1;
    const raw = rebuild(parts, i, len);
    const label = rest.slice(0, len).join(" ");
    nodes.push(
      <button
        key={`${i}-${label}`}
        type="button"
        className="it-word"
        onClick={() =>
          open({
            word: label,
            meaning: hit?.entry.ar,
            note: hit?.entry.note,
            context: text,
          })
        }
      >
        {raw}
      </button>,
    );
    ti += len;
    i = advance(parts, i, len);
  }

  return (
    <p dir="ltr" lang="it" className={`text-left text-lg leading-relaxed ${className ?? ""}`}>
      {nodes}
    </p>
  );
}

function rebuild(parts: string[], start: number, words: number) {
  let left = words;
  let out = "";
  for (let i = start; i < parts.length && left > 0; i++) {
    const p = parts[i] ?? "";
    out += p;
    if (WORD.test(p)) left -= 1;
  }
  return out;
}

function advance(parts: string[], start: number, words: number) {
  let left = words;
  let i = start;
  while (i < parts.length && left > 0) {
    if (WORD.test(parts[i] ?? "")) left -= 1;
    i += 1;
  }
  return i;
}
