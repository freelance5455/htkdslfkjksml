import React, { useEffect, useRef } from 'react';
import { Volume2, SkipForward } from 'lucide-react';
import { soundEngine } from '../audio/soundEngine';

interface StartupSequenceProps {
  onComplete: () => void;
  audioUnlocked: boolean;
  onUnlockAudio: () => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  targetX: number;
  targetY: number;
  size: number;
  rotation: number;
  vRot: number;
  isIron: boolean;
  heat: number; // 1 = white/orange hot, 0 = cooled dark iron / gold
  vertices: { dx: number; dy: number }[];
  arriveDelay: number;
  trail: { x: number; y: number }[];
}

/**
 * Generates exact target points forming a detailed, sculpted gaming controller silhouette
 * normalized around (0, 0) within roughly [-180..180] x [-110..110].
 */
function sampleControllerPoints(count: number, scale: number): { x: number; y: number }[] {
  const points: { x: number; y: number }[] = [];

  const isInsideController = (nx: number, ny: number): boolean => {
    // Center bridge
    if (Math.abs(nx) <= 0.48 && ny >= -0.34 && ny <= 0.24) return true;
    // Left shoulder & upper pad
    if ((nx + 0.46) ** 2 / 0.34 ** 2 + (ny + 0.04) ** 2 / 0.34 ** 2 <= 1) return true;
    // Right shoulder & upper pad
    if ((nx - 0.46) ** 2 / 0.34 ** 2 + (ny + 0.04) ** 2 / 0.34 ** 2 <= 1) return true;
    // Left ergonomic grip angled outward-down
    const lx = nx + 0.58 - ny * 0.22;
    const ly = ny - 0.32;
    if ((lx * lx) / (0.21 * 0.21) + (ly * ly) / (0.44 * 0.44) <= 1 && ny >= -0.05) return true;
    // Right ergonomic grip angled outward-down
    const rx = nx - 0.58 + ny * 0.22;
    const ry = ny - 0.32;
    if ((rx * rx) / (0.21 * 0.21) + (ry * ry) / (0.44 * 0.44) <= 1 && ny >= -0.05) return true;
    return false;
  };

  let attempts = 0;
  while (points.length < count && attempts < count * 25) {
    attempts++;
    const nx = (Math.random() * 2 - 1) * 0.92;
    const ny = (Math.random() * 2 - 1) * 0.78;
    if (isInsideController(nx, ny)) {
      points.push({ x: nx * 195 * scale, y: ny * 155 * scale });
    }
  }
  while (points.length < count) {
    points.push({ x: (Math.random() - 0.5) * 80 * scale, y: (Math.random() - 0.5) * 40 * scale });
  }
  return points;
}

function traceRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
}

function drawGoldController(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  scale: number,
  alpha: number,
  sheenProgress: number,
  coreGlow: number,
  rotationRad = 0
) {
  if (alpha <= 0.01) return;
  ctx.save();
  ctx.translate(cx, cy);
  if (rotationRad !== 0) {
    ctx.rotate(rotationRad);
  }
  ctx.scale(scale, scale);
  ctx.globalAlpha = Math.max(0, Math.min(1, alpha));

  // Ambient golden aura behind controller
  const aura = ctx.createRadialGradient(0, 0, 20, 0, 0, 250);
  aura.addColorStop(0, `rgba(250, 204, 21, ${0.28 * coreGlow})`);
  aura.addColorStop(0.55, `rgba(180, 123, 17, ${0.12 * coreGlow})`);
  aura.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = aura;
  ctx.beginPath();
  ctx.arc(0, 0, 250, 0, Math.PI * 2);
  ctx.fill();

  // Shoulder Bumpers (L1 / R1)
  const bumperGrad = ctx.createLinearGradient(0, -76, 0, -52);
  bumperGrad.addColorStop(0, '#fef08a');
  bumperGrad.addColorStop(0.45, '#ca8a04');
  bumperGrad.addColorStop(1, '#713f12');
  ctx.fillStyle = bumperGrad;

  // Left bumper
  ctx.beginPath();
  ctx.moveTo(-124, -44);
  ctx.quadraticCurveTo(-98, -74, -56, -64);
  ctx.lineTo(-56, -44);
  ctx.closePath();
  ctx.fill();

  // Right bumper
  ctx.beginPath();
  ctx.moveTo(124, -44);
  ctx.quadraticCurveTo(98, -74, 56, -64);
  ctx.lineTo(56, -44);
  ctx.closePath();
  ctx.fill();

  // Main Controller Chassis Path
  const traceBody = () => {
    ctx.beginPath();
    ctx.moveTo(-64, -56);
    ctx.lineTo(64, -56);
    // Top-right shoulder curve
    ctx.bezierCurveTo(106, -58, 138, -36, 152, 8);
    // Right outer grip
    ctx.bezierCurveTo(168, 56, 176, 98, 152, 114);
    ctx.bezierCurveTo(132, 126, 108, 108, 92, 74);
    // Bottom-right inner arch
    ctx.bezierCurveTo(78, 46, 56, 36, 0, 36);
    // Bottom-left inner arch
    ctx.bezierCurveTo(-56, 36, -78, 46, -92, 74);
    // Left grip bottom
    ctx.bezierCurveTo(-108, 108, -132, 126, -152, 114);
    ctx.bezierCurveTo(-176, 98, -168, 56, -152, 8);
    // Top-left shoulder curve
    ctx.bezierCurveTo(-138, -36, -106, -58, -64, -56);
    ctx.closePath();
  };

  // Lightweight offset drop shadow (no expensive shadowBlur)
  ctx.save();
  ctx.translate(0, 14);
  traceBody();
  ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
  ctx.fill();
  ctx.restore();

  // Brushed 24K Gold Body Fill
  traceBody();
  const bodyGrad = ctx.createLinearGradient(-150, -70, 150, 115);
  bodyGrad.addColorStop(0, '#fef08a');
  bodyGrad.addColorStop(0.22, '#eab308');
  bodyGrad.addColorStop(0.48, '#a16207');
  bodyGrad.addColorStop(0.72, '#facc15');
  bodyGrad.addColorStop(1, '#713f12');
  ctx.fillStyle = bodyGrad;
  ctx.fill();

  // Specular metallic rim stroke
  ctx.lineWidth = 2.4;
  const rimGrad = ctx.createLinearGradient(-160, -60, 160, 100);
  rimGrad.addColorStop(0, '#fef9c3');
  rimGrad.addColorStop(0.5, '#ca8a04');
  rimGrad.addColorStop(1, '#fef08a');
  ctx.strokeStyle = rimGrad;
  ctx.stroke();

  // Sweeping metallic sheen across gold surface
  if (sheenProgress > 0 && sheenProgress < 1) {
    ctx.save();
    traceBody();
    ctx.clip();
    const sx = -260 + sheenProgress * 520;
    const sheen = ctx.createLinearGradient(sx - 55, -120, sx + 55, 120);
    sheen.addColorStop(0, 'rgba(255, 255, 255, 0)');
    sheen.addColorStop(0.5, 'rgba(255, 252, 225, 0.55)');
    sheen.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = sheen;
    ctx.fillRect(-200, -100, 400, 240);
    ctx.restore();
  }

  // Recessed central faceplate
  ctx.fillStyle = 'rgba(28, 19, 6, 0.38)';
  ctx.beginPath();
  traceRoundedRect(ctx, -52, -34, 104, 52, 10);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = 'rgba(254, 240, 138, 0.35)';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Left D-Pad (precision milled dark-gold cross)
  const drawDPad = (dx: number, dy: number) => {
    ctx.save();
    ctx.translate(dx, dy);
    // Circular well
    ctx.fillStyle = '#422006';
    ctx.beginPath();
    ctx.arc(0, 0, 24, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 1;
    ctx.stroke();

    // Cross
    const dGrad = ctx.createLinearGradient(-16, -16, 16, 16);
    dGrad.addColorStop(0, '#fef08a');
    dGrad.addColorStop(0.5, '#d97706');
    dGrad.addColorStop(1, '#78350f');
    ctx.fillStyle = dGrad;
    ctx.beginPath();
    traceRoundedRect(ctx, -6, -18, 12, 36, 2);
    traceRoundedRect(ctx, -18, -6, 36, 12, 2);
    ctx.fill();
    ctx.restore();
  };
  drawDPad(-92, -10);

  // Right ABXY Diamond Buttons
  const buttonOffsets = [
    { x: 92, y: -27, accent: '#fef08a' },
    { x: 109, y: -10, accent: '#fde047' },
    { x: 92, y: 7, accent: '#facc15' },
    { x: 75, y: -10, accent: '#fef08a' },
  ];
  buttonOffsets.forEach((b) => {
    ctx.save();
    ctx.fillStyle = '#291505';
    ctx.beginPath();
    ctx.arc(b.x, b.y, 9.5, 0, Math.PI * 2);
    ctx.fill();

    const bGrad = ctx.createRadialGradient(b.x - 2, b.y - 2, 1, b.x, b.y, 8);
    bGrad.addColorStop(0, '#fffbeb');
    bGrad.addColorStop(0.45, b.accent);
    bGrad.addColorStop(1, '#92400e');
    ctx.fillStyle = bGrad;
    ctx.beginPath();
    ctx.arc(b.x, b.y, 7.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  });

  // Dual Analog Thumbsticks
  const drawStick = (sx: number, sy: number) => {
    ctx.save();
    ctx.translate(sx, sy);
    ctx.fillStyle = '#271303';
    ctx.beginPath();
    ctx.arc(0, 0, 21, 0, Math.PI * 2);
    ctx.fill();

    const sGrad = ctx.createRadialGradient(-4, -4, 2, 0, 0, 17);
    sGrad.addColorStop(0, '#fef9c3');
    sGrad.addColorStop(0.4, '#ca8a04');
    sGrad.addColorStop(0.85, '#451a03');
    sGrad.addColorStop(1, '#1c0d02');
    ctx.fillStyle = sGrad;
    ctx.beginPath();
    ctx.arc(0, 0, 16.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = 'rgba(254, 240, 138, 0.55)';
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.arc(0, 0, 12, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  };
  drawStick(-48, 22);
  drawStick(48, 22);

  // Glowing Center Core Emblem (Zoom-through portal!)
  const portalGlow = ctx.createRadialGradient(0, -8, 1, 0, -8, 26);
  portalGlow.addColorStop(0, `rgba(255, 255, 240, ${0.95 * coreGlow})`);
  portalGlow.addColorStop(0.38, `rgba(250, 204, 21, ${0.75 * coreGlow})`);
  portalGlow.addColorStop(1, 'rgba(250, 204, 21, 0)');
  ctx.fillStyle = portalGlow;
  ctx.beginPath();
  ctx.arc(0, -8, 26, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#1f1204';
  ctx.beginPath();
  ctx.arc(0, -8, 11, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#fef08a';
  ctx.lineWidth = 1.6;
  ctx.stroke();

  // Inner power/diamond glyph
  ctx.fillStyle = '#fef9c3';
  ctx.beginPath();
  ctx.moveTo(0, -14);
  ctx.lineTo(5, -8);
  ctx.lineTo(0, -2);
  ctx.lineTo(-5, -8);
  ctx.closePath();
  ctx.fill();

  ctx.restore();
}

export const StartupSequence: React.FC<StartupSequenceProps> = ({
  onComplete,
  audioUnlocked,
  onUnlockAudio,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fadeOverlayRef = useRef<HTMLDivElement | null>(null);
  const completedRef = useRef(false);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    completedRef.current = false;
    if (fadeOverlayRef.current) {
      fadeOverlayRef.current.style.opacity = '0';
    }
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    const allowShake = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let animId = 0;
    const getLogicalSize = () => {
      const rect = canvas.getBoundingClientRect();
      const w = canvas.clientWidth || rect.width || Math.max(window.innerWidth, window.innerHeight);
      const h = canvas.clientHeight || rect.height || Math.min(window.innerWidth, window.innerHeight);
      return { w: Math.max(320, w), h: Math.max(240, h) };
    };

    let { w: width, h: height } = getLogicalSize();
    const dpr = Math.min(window.devicePixelRatio || 1, 1.35);

    const resize = () => {
      const next = getLogicalSize();
      width = next.w;
      height = next.h;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
    };
    resize();

    const controllerScale = Math.min(width / 640, height / 390, 1.45);
    const impactX = width * 0.5;
    const impactY = height * 0.58;
    const controllerCenterY = height * 0.5;

    // Pre-generate static starfield
    const stars = Array.from({ length: 65 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height * 0.72,
      r: 0.6 + Math.random() * 1.3,
      a: 0.15 + Math.random() * 0.5,
    }));

    // Pre-generate 145 physics particles (iron shards + molten sparks)
    const particleCount = 145;
    const targets = sampleControllerPoints(particleCount, controllerScale);
    const particles: Particle[] = targets.map((tgt, idx) => {
      const isIron = idx % 2 === 0;
      const angle = Math.random() * Math.PI * 2;
      const speed = isIron
        ? 180 + Math.random() * 440
        : 260 + Math.random() * 680;
      const vertCount = isIron ? 4 + (idx % 3) : 3;
      const size = isIron ? 4 + Math.random() * 7 : 1.8 + Math.random() * 2.8;
      const vertices = Array.from({ length: vertCount }, (_, v) => {
        const va = (v / vertCount) * Math.PI * 2;
        const vr = size * (0.55 + Math.random() * 0.6);
        return { dx: Math.cos(va) * vr, dy: Math.sin(va) * vr };
      });
      return {
        x: impactX,
        y: impactY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - (160 + Math.random() * 240),
        targetX: width * 0.5 + tgt.x,
        targetY: controllerCenterY + tgt.y,
        size,
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 14,
        isIron,
        heat: 1,
        vertices,
        arriveDelay: Math.random() * 0.45,
        trail: [],
      };
    });

    const meteorTrails: { x: number; y: number; r: number; life: number }[] = [];

    // Trigger initial sound effects
    soundEngine.playMeteorDescent(1.75);

    let impactPlayed = false;
    let reformPlayed = false;
    let zoomPlayed = false;

    const T_IMPACT = 1.75;
    const T_REFORM = 3.05;
    const T_ZOOM = 5.35;
    const T_END = 6.85;

    let startTime = performance.now();
    let lastTime = startTime;

    const render = (now: number) => {
      const dt = Math.min(0.035, (now - lastTime) / 1000);
      lastTime = now;
      const t = (now - startTime) / 1000;

      ctx.save();
      ctx.scale(dpr, dpr);

      // Camera Shake right after impact
      let shakeX = 0;
      let shakeY = 0;
      if (allowShake && t >= T_IMPACT && t < T_IMPACT + 0.75) {
        const decay = 1 - (t - T_IMPACT) / 0.75;
        const mag = 16 * decay * decay;
        shakeX = (Math.random() - 0.5) * mag;
        shakeY = (Math.random() - 0.5) * mag;
      }
      ctx.translate(shakeX, shakeY);

      // 1. Deep Obsidian Sky Backdrop
      const bg = ctx.createLinearGradient(0, 0, 0, height);
      bg.addColorStop(0, '#040508');
      bg.addColorStop(0.65, '#090b12');
      bg.addColorStop(1, '#12100e');
      ctx.fillStyle = bg;
      ctx.fillRect(-30, -30, width + 60, height + 60);

      // Subtle horizon floor
      ctx.strokeStyle = 'rgba(212, 175, 55, 0.14)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, impactY + 26);
      ctx.lineTo(width, impactY + 26);
      ctx.stroke();

      // Starfield
      stars.forEach((s) => {
        ctx.fillStyle = `rgba(241, 245, 249, ${s.a})`;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      });

      // ==========================================================
      // PHASE 1: METEOR DESCENT FROM LEFT TO CENTER (0.0s - 1.75s)
      // ==========================================================
      if (t < T_IMPACT) {
        const p = t / T_IMPACT;
        const eased = p * p * (0.4 + 0.6 * p); // accelerates as it falls
        const startX = -width * 0.06;
        const startY = -height * 0.1;
        const mx = startX + (impactX - startX) * eased;
        const my = startY + (impactY - startY) * eased;

        // Spawn fiery wake puffs (capped to keep trail draw calls lightweight)
        if (meteorTrails.length < 36) {
          for (let k = 0; k < 3; k++) {
            meteorTrails.push({
              x: mx + (Math.random() - 0.5) * 18,
              y: my + (Math.random() - 0.5) * 18,
              r: 8 + Math.random() * 18,
              life: 1,
            });
          }
        }

        // Draw plasma wake trail
        for (let i = meteorTrails.length - 1; i >= 0; i--) {
          const tr = meteorTrails[i];
          tr.life -= dt * 2.1;
          if (tr.life <= 0) {
            meteorTrails.splice(i, 1);
            continue;
          }
          const grad = ctx.createRadialGradient(tr.x, tr.y, 0, tr.x, tr.y, tr.r * tr.life);
          grad.addColorStop(0, `rgba(255, 237, 160, ${0.75 * tr.life})`);
          grad.addColorStop(0.45, `rgba(249, 115, 22, ${0.5 * tr.life})`);
          grad.addColorStop(1, 'rgba(124, 45, 18, 0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(tr.x, tr.y, tr.r * tr.life * 1.4, 0, Math.PI * 2);
          ctx.fill();
        }

        // Blazing Meteor Core
        const glow = ctx.createRadialGradient(mx, my, 2, mx, my, 68);
        glow.addColorStop(0, '#ffffff');
        glow.addColorStop(0.22, '#fef08a');
        glow.addColorStop(0.5, 'rgba(249, 115, 22, 0.8)');
        glow.addColorStop(1, 'rgba(234, 88, 12, 0)');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(mx, my, 68, 0, Math.PI * 2);
        ctx.fill();

        // Jagged iron-rock meteor core
        ctx.save();
        ctx.translate(mx, my);
        ctx.rotate(t * 4.5);
        ctx.fillStyle = '#3f2e21';
        ctx.strokeStyle = '#fb923c';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        for (let v = 0; v < 8; v++) {
          const a = (v / 8) * Math.PI * 2;
          const r = 15 + (v % 2 === 0 ? 5 : -2);
          if (v === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
          else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }

      // ==========================================================
      // PHASE 2: IMPACT BLAST & DEBRIS PHYSICS (1.75s - 3.05s)
      // ==========================================================
      if (t >= T_IMPACT && !impactPlayed) {
        impactPlayed = true;
        soundEngine.playMeteorImpact();
      }

      if (t >= T_IMPACT && t < T_REFORM) {
        const elapsed = t - T_IMPACT;

        // Crater Flash & Expanding Seismic Shockwave
        if (elapsed < 0.8) {
          const flashAlpha = Math.max(0, 1 - elapsed / 0.45);
          const flash = ctx.createRadialGradient(impactX, impactY, 4, impactX, impactY, 340);
          flash.addColorStop(0, `rgba(255, 250, 220, ${flashAlpha})`);
          flash.addColorStop(0.35, `rgba(251, 146, 60, ${flashAlpha * 0.7})`);
          flash.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = flash;
          ctx.beginPath();
          ctx.arc(impactX, impactY, 340, 0, Math.PI * 2);
          ctx.fill();

          const ringR = 25 + elapsed * 640;
          const ringAlpha = Math.max(0, 0.75 - elapsed);
          ctx.strokeStyle = `rgba(253, 224, 71, ${ringAlpha})`;
          ctx.lineWidth = 3 * ringAlpha;
          ctx.beginPath();
          ctx.ellipse(impactX, impactY + 12, ringR, ringR * 0.34, 0, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Update exploding iron shards & hot sparks
        const floorY = impactY + 26;
        particles.forEach((pt) => {
          pt.vy += 860 * dt; // Gravity
          pt.vx *= 0.992;
          pt.x += pt.vx * dt;
          pt.y += pt.vy * dt;
          pt.rotation += pt.vRot * dt;
          pt.heat = Math.max(0.15, pt.heat - dt * 0.55);

          if (pt.y > floorY) {
            pt.y = floorY;
            pt.vy = -Math.abs(pt.vy) * (pt.isIron ? 0.42 : 0.62);
            pt.vx *= 0.82;
          }

          pt.trail.push({ x: pt.x, y: pt.y });
          if (pt.trail.length > (pt.isIron ? 3 : 6)) pt.trail.shift();

          if (pt.isIron) {
            ctx.save();
            ctx.translate(pt.x, pt.y);
            ctx.rotate(pt.rotation);
            ctx.fillStyle = pt.heat > 0.55 ? '#9a3412' : '#475569';
            ctx.strokeStyle = pt.heat > 0.45 ? '#fb923c' : '#94a3b8';
            ctx.lineWidth = 1;
            ctx.beginPath();
            pt.vertices.forEach((v, idx) => {
              if (idx === 0) ctx.moveTo(v.dx, v.dy);
              else ctx.lineTo(v.dx, v.dy);
            });
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            ctx.restore();
          } else {
            // Molten spark streak
            if (pt.trail.length > 1) {
              ctx.strokeStyle = `rgba(253, 224, 71, ${0.4 + pt.heat * 0.55})`;
              ctx.lineWidth = pt.size;
              ctx.beginPath();
              ctx.moveTo(pt.trail[0].x, pt.trail[0].y);
              pt.trail.forEach((tr) => ctx.lineTo(tr.x, tr.y));
              ctx.stroke();
            }
            ctx.fillStyle = '#fef9c3';
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, pt.size * 0.7, 0, Math.PI * 2);
            ctx.fill();
          }
        });
      }

      // ==========================================================
      // PHASE 3: MAGNETIC REFORMATION INTO GOLD CONTROLLER (3.05s - 5.35s)
      // ==========================================================
      if (t >= T_REFORM && !reformPlayed) {
        reformPlayed = true;
        soundEngine.playGoldReformation(T_ZOOM - T_REFORM);
      }

      if (t >= T_REFORM && t < T_ZOOM) {
        const elapsed = t - T_REFORM;
        const duration = T_ZOOM - T_REFORM;
        const progress = Math.min(1, elapsed / duration);

        // Converge all particles into the gold controller silhouette
        particles.forEach((pt) => {
          const localP = Math.max(0, Math.min(1, (progress - pt.arriveDelay * 0.25) / 0.72));
          const ease = 1 - Math.pow(1 - localP, 3);

          // Magnetic spiral curl during convergence
          const dx = pt.targetX - pt.x;
          const dy = pt.targetY - pt.y;
          const swirl = (1 - ease) * 0.14;
          pt.x += dx * (0.09 + ease * 0.28) - dy * swirl;
          pt.y += dy * (0.09 + ease * 0.28) + dx * swirl;
          pt.rotation += pt.vRot * dt * (1 - ease);

          const particleAlpha = Math.max(0, 1 - Math.max(0, progress - 0.76) * 4.2);
          if (particleAlpha <= 0.02) return;

          if (pt.isIron) {
            ctx.save();
            ctx.globalAlpha = particleAlpha;
            ctx.translate(pt.x, pt.y);
            ctx.rotate(pt.rotation);
            // Iron transforms from dark iron -> molten amber -> 24K gold
            ctx.fillStyle = progress > 0.45 ? '#eab308' : '#64748b';
            ctx.strokeStyle = '#fef08a';
            ctx.lineWidth = 0.9;
            ctx.beginPath();
            pt.vertices.forEach((v, idx) => {
              if (idx === 0) ctx.moveTo(v.dx, v.dy);
              else ctx.lineTo(v.dx, v.dy);
            });
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            ctx.restore();
          } else {
            ctx.save();
            ctx.globalAlpha = particleAlpha;
            ctx.fillStyle = progress > 0.5 ? '#fde047' : '#fb923c';
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, pt.size * 0.85, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          }
        });

        // Materialize sculpted 24k Gold Gaming Controller as particles fuse
        const controllerAlpha = Math.max(0, Math.min(1, (progress - 0.54) / 0.34));
        const sheenProgress = Math.max(0, Math.min(1, (progress - 0.68) / 0.32));
        drawGoldController(
          ctx,
          width * 0.5,
          controllerCenterY,
          controllerScale * (0.94 + 0.06 * controllerAlpha),
          controllerAlpha,
          sheenProgress,
          0.6 + controllerAlpha * 0.6
        );
      }

      // ==========================================================
      // PHASE 4: ZOOM THROUGH CONTROLLER & SPIN UNTIL RIGHT SIDE UP
      // ==========================================================
      if (t >= T_ZOOM && !zoomPlayed) {
        zoomPlayed = true;
        soundEngine.playControllerZoom();
      }

      if (t >= T_ZOOM) {
        const zp = Math.min(1, (t - T_ZOOM) / (T_END - T_ZOOM));
        const zoomEase = Math.pow(zp, 2.4);
        const zoomScale = controllerScale * (1 + zoomEase * 17);
        const controllerFade = Math.max(0, 1 - Math.max(0, zp - 0.52) / 0.42);

        // Smooth full 360-degree spin-around that settles cleanly right-side up (2*PI == 0deg)
        const spinEase =
          zp < 0.5 ? 4 * zp * zp * zp : 1 - Math.pow(-2 * zp + 2, 3) / 2;
        const spinRad = spinEase * Math.PI * 2;

        // Rotating radial light-tunnel streaks during zoom-through
        if (zp > 0.18) {
          const streakAlpha = Math.sin(Math.min(1, (zp - 0.18) / 0.82) * Math.PI) * 0.48;
          ctx.save();
          ctx.translate(width * 0.5, controllerCenterY);
          ctx.rotate(spinRad);
          for (let s = 0; s < 16; s++) {
            const a = (s / 16) * Math.PI * 2;
            const innerR = 24 + zp * 140;
            const outerR = innerR + 180 + zp * 420;
            ctx.strokeStyle =
              s % 2 === 0
                ? `rgba(250, 204, 21, ${streakAlpha})`
                : `rgba(255, 255, 255, ${streakAlpha * 0.55})`;
            ctx.lineWidth = 1.6;
            ctx.beginPath();
            ctx.moveTo(Math.cos(a) * innerR, Math.sin(a) * innerR);
            ctx.lineTo(Math.cos(a) * outerR, Math.sin(a) * outerR);
            ctx.stroke();
          }
          ctx.restore();
        }

        const targetCy = controllerCenterY + 8 * zoomScale * 0.08;
        drawGoldController(
          ctx,
          width * 0.5,
          targetCy,
          zoomScale,
          controllerFade,
          0,
          1.2 + zoomEase * 2.2,
          spinRad
        );

        // Seamless dissolve into right-side-up Profile Selection (direct DOM ref, zero React re-render)
        const tunnelAlpha = Math.max(0, (zp - 0.55) / 0.45);
        if (tunnelAlpha > 0 && fadeOverlayRef.current) {
          fadeOverlayRef.current.style.opacity = String(tunnelAlpha);
        }
      }

      ctx.restore();

      if (t >= T_END) {
        if (!completedRef.current) {
          completedRef.current = true;
          onCompleteRef.current();
        }
        return;
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  const handleSkip = (e: React.MouseEvent) => {
    e.stopPropagation();
    onUnlockAudio();
    soundEngine.playSelect();
    if (!completedRef.current) {
      completedRef.current = true;
      onComplete();
    }
  };

  return (
    <div
      onClick={onUnlockAudio}
      className="relative w-full h-full bg-[#050609] overflow-hidden cursor-pointer"
    >
      <canvas ref={canvasRef} className="w-full h-full block" />

      {/* Smooth cross-dissolve during controller zoom-through */}
      <div
        ref={fadeOverlayRef}
        className="pointer-events-none absolute inset-0 bg-[#060911]"
        style={{ opacity: 0 }}
      />

      {/* Bottom utility controls during boot */}
      <div className="absolute bottom-6 inset-x-8 flex items-center justify-between pointer-events-none">
        {!audioUnlocked ? (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onUnlockAudio();
            }}
            className="pointer-events-auto flex items-center gap-2 px-4 py-2 bg-black/70 border border-sky-400/45 text-sky-200 text-xs font-medium tracking-wide hover:bg-black/90 transition-colors"
          >
            <Volume2 className="w-3.5 h-3.5 text-sky-400" />
            <span>Click anywhere to enable system audio</span>
          </button>
        ) : (
          <div />
        )}

        <button
          type="button"
          onClick={handleSkip}
          className="pointer-events-auto flex items-center gap-2 px-4 py-2 bg-white/8 hover:bg-white/15 border border-white/15 text-slate-200 text-xs font-medium transition-colors"
        >
          <span>Skip</span>
          <SkipForward className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
