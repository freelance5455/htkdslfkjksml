import { useState } from 'react';
import { CalculatedAlert } from '../utils/alerts';
import { AlertTriangle, DollarSign, Calendar, X, ChevronRight, BellRing } from 'lucide-react';
import { Student } from '../types';

interface AlertBannerProps {
  alerts: CalculatedAlert[];
  students: Student[];
  onOpenPaymentModal: (student: Student) => void;
  onNavigateToTab?: (tab: string) => void;
}

export const AlertBanner = ({
  alerts,
  students,
  onOpenPaymentModal,
  onNavigateToTab,
}: AlertBannerProps) => {
  const [dismissedIds, setDismissedIds] = useState<string[]>([]);

  const visibleAlerts = alerts.filter((a) => !dismissedIds.includes(a.id));

  if (visibleAlerts.length === 0) return null;

  const handleDismiss = (id: string) => {
    setDismissedIds((prev) => [...prev, id]);
  };

  return (
    <div className="space-y-3 mb-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BellRing className="w-4 h-4 text-amber-400 animate-bounce" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-stone-300">
            Akıllı Hatırlatma & Tahsilat Uyarıları ({visibleAlerts.length})
          </h4>
        </div>
      </div>

      <div className="grid gap-2.5">
        {visibleAlerts.map((alert) => {
          const student = students.find((s) => s.id === alert.studentId);
          const isCritical = alert.severity === 'critical';
          const isPaymentLesson = alert.type === 'payment_lesson';

          return (
            <div
              key={alert.id}
              className={`relative flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 rounded-2xl border shadow-lg transition-all gap-4 ${
                isCritical
                  ? 'bg-gradient-to-r from-rose-950/90 via-zinc-900 to-rose-950/70 border-rose-500/40 text-stone-100'
                  : isPaymentLesson
                  ? 'bg-gradient-to-r from-amber-950/90 via-zinc-900 to-amber-950/70 border-amber-500/40 text-stone-100'
                  : 'bg-zinc-900/90 border-sky-800/40 text-stone-100'
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`p-2 rounded-xl shrink-0 mt-0.5 ${
                    isCritical
                      ? 'bg-rose-900/60 text-rose-300 border border-rose-500/30'
                      : isPaymentLesson
                      ? 'bg-amber-900/60 text-amber-300 border border-amber-500/30'
                      : 'bg-sky-900/60 text-sky-300 border border-sky-500/30'
                  }`}
                >
                  {isCritical ? (
                    <AlertTriangle className="w-5 h-5 text-rose-400" />
                  ) : isPaymentLesson ? (
                    <DollarSign className="w-5 h-5 text-amber-400" />
                  ) : (
                    <Calendar className="w-5 h-5 text-sky-400" />
                  )}
                </div>

                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-sm text-white">{alert.title}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        isCritical
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : isPaymentLesson
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                      }`}
                    >
                      {alert.badge}
                    </span>
                  </div>
                  <p className="text-xs text-stone-300 mt-0.5 leading-relaxed">
                    {alert.message}
                  </p>
                </div>
              </div>

              {/* Action and Dismiss */}
              <div className="flex items-center gap-2 w-full sm:w-auto justify-end shrink-0">
                {student && alert.actionType === 'mark_paid' && (
                  <button
                    onClick={() => onOpenPaymentModal(student)}
                    className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-md shadow-rose-950/40 flex items-center gap-1 active:scale-95 transition-all cursor-pointer"
                  >
                    <span>Ödeme Alındı</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}

                {alert.actionType === 'open_schedule' && onNavigateToTab && (
                  <button
                    onClick={() => onNavigateToTab('calendar')}
                    className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 text-stone-200 border border-zinc-700 flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <span>Takvimi Aç</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  onClick={() => handleDismiss(alert.id)}
                  className="p-1 rounded-lg text-stone-400 hover:text-white hover:bg-zinc-800 transition-all cursor-pointer"
                  title="Bildirimi gizle"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
