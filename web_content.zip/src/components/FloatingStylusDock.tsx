import React, { useState, useRef } from "react";
import { motion } from "motion/react";
import {
  StylusToolType,
  StylusSettings,
} from "../types";
import {
  StylusSettingsManager,
  DigitalInkRecognitionEngine,
} from "../utils/digitalInkEngine";
import { PenPreviewBadge } from "./PenPreviewBadge";
import {
  PenTool,
  Feather,
  Pencil,
  Highlighter,
  Eraser,
  Palette,
  RotateCcw,
  RotateCw,
  Sparkles,
  Grid,
  Check,
  Move,
  Scissors,
  Sliders,
  Maximize2,
  X,
  Zap,
  Brush,
  ChevronDown,
} from "lucide-react";

interface FloatingStylusDockProps {
  activeTool: StylusToolType;
  onChangeTool: (tool: StylusToolType) => void;
  activeColor: string;
  onChangeColor: (color: string) => void;
  strokeSize: number;
  onChangeStrokeSize: (size: number) => void;
  onUndo?: () => void;
  onRedo?: () => void;
  onClearAll?: () => void;
  onRecognizeText?: () => void;
  isVisible: boolean;
  onClose?: () => void;
}

const PRESET_COLORS = [
  { name: "Kömür Siyahı", value: "#0F172A" },
  { name: "Safir Mavisi", value: "#0284C7" },
  { name: "Zümrüt Yeşili", value: "#059669" },
  { name: "Kehribar Altın", value: "#D97706" },
  { name: "Kırmızı / Gül", value: "#E11D48" },
  { name: "Mor / Asil", value: "#7C3AED" },
  { name: "Neon Fosfor", value: "#FACC15" },
  { name: "Mat Beyaz", value: "#FFFFFF" },
];

export const FloatingStylusDock: React.FC<FloatingStylusDockProps> = ({
  activeTool,
  onChangeTool,
  activeColor,
  onChangeColor,
  strokeSize,
  onChangeStrokeSize,
  onUndo,
  onRedo,
  onClearAll,
  onRecognizeText,
  isVisible,
  onClose,
}) => {
  const [showColorMenu, setShowColorMenu] = useState(false);
  const [showSizeSlider, setShowSizeSlider] = useState(false);
  const [showPenSelector, setShowPenSelector] = useState(false);
  const [settings, setSettings] = useState<StylusSettings>(
    StylusSettingsManager.getSettings()
  );

  if (!isVisible) return null;

  const toggleGridSnapping = () => {
    const updated = !settings.gridSnapping;
    StylusSettingsManager.updateSettings({ gridSnapping: updated });
    setSettings((prev) => ({ ...prev, gridSnapping: updated }));
  };

  return (
    <motion.div
      drag
      dragMomentum={false}
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 20, opacity: 0 }}
      className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 pointer-events-auto select-none"
    >
      {/* Floating Glassmorphic Container */}
      <div className="bg-slate-900/90 dark:bg-slate-950/95 text-white backdrop-blur-xl border border-slate-700/80 rounded-3xl p-2.5 shadow-2xl flex flex-wrap items-center gap-1.5 sm:gap-2 ring-1 ring-white/10">
        
        {/* Drag Handle Indicator */}
        <div className="px-1.5 py-2 cursor-grab active:cursor-grabbing text-slate-500 hover:text-slate-300 transition-colors">
          <Move className="w-4 h-4" />
        </div>

        <div className="h-6 w-[1px] bg-slate-800" />

        {/* 9 PEN TYPES SELECTOR POPUP & QUICK SWITCHER */}
        <div className="relative">
          <button
            type="button"
            onClick={() => {
              setShowPenSelector(!showPenSelector);
              setShowColorMenu(false);
              setShowSizeSlider(false);
            }}
            className="px-3 py-2 rounded-2xl bg-teal-600 hover:bg-teal-500 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-lg shadow-teal-600/30 transition-all cursor-pointer"
            title="9 Adet Kalem Çeşidi Seç"
          >
            <PenTool className="w-4 h-4 text-amber-300" />
            <span className="hidden sm:inline">
              {activeTool === "fountain" && "Dolma Kalem"}
              {activeTool === "ballpoint" && "Tükenmez Kalem"}
              {activeTool === "pencil" && "Kurşun Kalem"}
              {activeTool === "neon_glow" && "Neon Parıltı"}
              {activeTool === "calligraphy" && "Kaligrafi Fırçası"}
              {activeTool === "highlighter" && "Fosforlu Marker"}
              {activeTool === "technical" && "Teknik Rapido"}
              {activeTool === "watercolor" && "Sulu Boya"}
              {activeTool === "laser_marker" && "Lazer İşaretleyici"}
              {activeTool === "eraser" && "Silgi"}
              {activeTool === "lasso_cut" && "Çizip Kesme (Kement)"}
            </span>
            <PenPreviewBadge
              tool={activeTool}
              color={activeColor}
              size={strokeSize}
              width={48}
              height={20}
              className="hidden md:block border-teal-400/50 bg-teal-950/60"
            />
            <ChevronDown className="w-3.5 h-3.5 text-teal-200" />
          </button>

          {showPenSelector && (
            <div className="absolute bottom-14 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-700 p-3 rounded-2xl shadow-2xl z-50 flex flex-col gap-1.5 min-w-[240px] animate-in zoom-in-95 text-xs">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 px-1">
                9 Kalem Çeşidi & Çizim Araçları:
              </span>
              <div className="grid grid-cols-1 gap-1 max-h-64 overflow-y-auto pr-1">
                {[
                  { id: "fountain", name: "1. Dolma Kalem", icon: Feather, desc: "Basınç ve Açı Duyarlı Kaligrafi" },
                  { id: "ballpoint", name: "2. Tükenmez Kalem", icon: PenTool, desc: "Net, Sabit Pürüzsüz Çizgi" },
                  { id: "pencil", name: "3. Kurşun Kalem", icon: Pencil, desc: "Mat Grafik Karakalem Doku" },
                  { id: "neon_glow", name: "4. Neon Parıltı Kalemi", icon: Sparkles, desc: "Karanlıkta Parlayan Neon Işığı" },
                  { id: "calligraphy", name: "5. Kaligrafi Fırçası", icon: Brush, desc: "Sanatsal Esnek Fırça Darbeleri" },
                  { id: "highlighter", name: "6. Fosforlu Kalem", icon: Highlighter, desc: "Yarı Şeffaf Neon Vurgulayıcı" },
                  { id: "technical", name: "7. Teknik Çizim / Rapido", icon: Sliders, desc: "Milimetrik Sabit Hassas Çizgi" },
                  { id: "watercolor", name: "8. Sulu Boya Fırçası", icon: Palette, desc: "Islak Islak Yumuşak Renk Yayılımı" },
                  { id: "laser_marker", name: "9. Lazer İşaretleyici", icon: Zap, desc: "Sunum Lazer İzi & İşaretleme" },
                  { id: "lasso_cut", name: "✂️ Çizip Kesme (Kement)", icon: Scissors, desc: "Çizimi Seç, Taşı veya Kes" },
                  { id: "eraser", name: "🧹 Silgi", icon: Eraser, desc: "Obje & Piksel Silici" },
                ].map((t) => {
                  const IconComp = t.icon;
                  const isCur = activeTool === t.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => {
                        onChangeTool(t.id as StylusToolType);
                        setShowPenSelector(false);
                      }}
                      className={`w-full text-left p-2 rounded-xl flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                        isCur
                          ? "bg-teal-600 text-white font-bold"
                          : "hover:bg-slate-800 text-slate-300"
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <IconComp className="w-4 h-4 shrink-0 text-amber-400" />
                        <div>
                          <p className="font-extrabold">{t.name}</p>
                          <p className="text-[10px] text-slate-400 truncate">{t.desc}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <PenPreviewBadge
                          tool={t.id as StylusToolType}
                          color={activeColor}
                          size={strokeSize}
                          width={60}
                          height={24}
                        />
                        {isCur && <Check className="w-4 h-4 text-white shrink-0" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* QUICK ACCESS ACCESSIBLE BUTTONS */}
        <button
          type="button"
          onClick={() => onChangeTool("fountain")}
          className={`p-2 rounded-2xl flex items-center gap-1 transition-all cursor-pointer ${
            activeTool === "fountain"
              ? "bg-amber-600 text-white shadow-md ring-2 ring-amber-400/50"
              : "hover:bg-slate-800 text-slate-300"
          }`}
          title="Dolma Kalem"
        >
          <Feather className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => onChangeTool("pencil")}
          className={`p-2 rounded-2xl flex items-center gap-1 transition-all cursor-pointer ${
            activeTool === "pencil"
              ? "bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400/50"
              : "hover:bg-slate-800 text-slate-300"
          }`}
          title="Kurşun Kalem"
        >
          <Pencil className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => onChangeTool("highlighter")}
          className={`p-2 rounded-2xl flex items-center gap-1 transition-all cursor-pointer ${
            activeTool === "highlighter"
              ? "bg-yellow-500 text-slate-950 shadow-md ring-2 ring-yellow-300/50 font-black"
              : "hover:bg-slate-800 text-slate-300"
          }`}
          title="Fosforlu Kalem"
        >
          <Highlighter className="w-4 h-4" />
        </button>

        {/* LASSO CUT BUTTON */}
        <button
          type="button"
          onClick={() => onChangeTool("lasso_cut")}
          className={`p-2 rounded-2xl flex items-center gap-1 transition-all cursor-pointer ${
            activeTool === "lasso_cut"
              ? "bg-rose-600 text-white shadow-md ring-2 ring-rose-400/50"
              : "hover:bg-slate-800 text-slate-300"
          }`}
          title="Çizip Kesme / Kement Seçim Aracı"
        >
          <Scissors className="w-4 h-4" />
        </button>

        {/* ERASER BUTTON */}
        <button
          type="button"
          onClick={() => onChangeTool("eraser")}
          className={`p-2 rounded-2xl flex items-center gap-1 transition-all cursor-pointer ${
            activeTool === "eraser"
              ? "bg-rose-700 text-white shadow-md ring-2 ring-rose-500/50"
              : "hover:bg-slate-800 text-slate-300"
          }`}
          title="Silgi"
        >
          <Eraser className="w-4 h-4" />
        </button>

        <div className="h-6 w-[1px] bg-slate-800" />

        {/* COLOR PICKER PALETTE BUTTON */}
        <div className="relative">
          <button
            type="button"
            onClick={() => {
              setShowColorMenu(!showColorMenu);
              setShowSizeSlider(false);
              setShowPenSelector(false);
            }}
            className="p-2 rounded-2xl hover:bg-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Renk Paleti"
          >
            <div
              className="w-5 h-5 rounded-full border-2 border-white/80 shadow-inner"
              style={{ backgroundColor: activeColor }}
            />
            <Palette className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {/* Color Menu Dropdown */}
          {showColorMenu && (
            <div className="absolute bottom-14 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-700 p-3 rounded-2xl shadow-2xl z-50 flex flex-col gap-2.5 min-w-[200px] animate-in zoom-in-95">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                Kalem Rengi Seçin:
              </span>
              <div className="grid grid-cols-4 gap-2">
                {PRESET_COLORS.map((c) => (
                  <button
                    key={c.value}
                    type="button"
                    onClick={() => {
                      onChangeColor(c.value);
                      setShowColorMenu(false);
                    }}
                    className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-transform hover:scale-110 cursor-pointer ${
                      activeColor === c.value ? "border-teal-400 scale-110 shadow-md" : "border-transparent"
                    }`}
                    style={{ backgroundColor: c.value }}
                    title={c.name}
                  >
                    {activeColor === c.value && <Check className="w-4 h-4 text-white drop-shadow-md" />}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2 pt-1 border-t border-slate-800">
                <input
                  type="color"
                  value={activeColor}
                  onChange={(e) => onChangeColor(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                />
                <span className="text-xs font-mono text-slate-300 uppercase">{activeColor}</span>
              </div>
            </div>
          )}
        </div>

        {/* STROKE SIZE SLIDER BUTTON */}
        <div className="relative">
          <button
            type="button"
            onClick={() => {
              setShowSizeSlider(!showSizeSlider);
              setShowColorMenu(false);
              setShowPenSelector(false);
            }}
            className="p-2 rounded-2xl hover:bg-slate-800 text-slate-300 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
            title="Çizgi Kalınlığı"
          >
            <Sliders className="w-4 h-4" />
            <span className="text-[11px] font-mono font-bold px-1.5 py-0.5 rounded-md bg-slate-800 text-teal-400">
              {strokeSize}px
            </span>
          </button>

          {/* Size Slider Popover */}
          {showSizeSlider && (
            <div className="absolute bottom-14 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-700 p-3 rounded-2xl shadow-2xl z-50 flex flex-col gap-2 min-w-[180px] animate-in zoom-in-95">
              <div className="flex items-center justify-between text-xs text-slate-300 font-bold">
                <span>Kalınlık:</span>
                <span className="font-mono text-teal-400">{strokeSize} px</span>
              </div>
              <input
                type="range"
                min="1"
                max="32"
                value={strokeSize}
                onChange={(e) => onChangeStrokeSize(Number(e.target.value))}
                className="w-full accent-teal-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>1px (İnce)</span>
                <span>32px (Kalın)</span>
              </div>
            </div>
          )}
        </div>

        <div className="h-6 w-[1px] bg-slate-800" />

        {/* GRID SNAPPING TOGGLE */}
        <button
          type="button"
          onClick={toggleGridSnapping}
          className={`p-2 rounded-2xl transition-colors cursor-pointer ${
            settings.gridSnapping
              ? "bg-teal-950 text-teal-400 border border-teal-500/50"
              : "hover:bg-slate-800 text-slate-400 hover:text-slate-200"
          }`}
          title="Çizgi/Izgara Mıknatısı (Grid Snapping)"
        >
          <Grid className="w-4 h-4" />
        </button>

        {/* UNDO BUTTON */}
        {onUndo && (
          <button
            type="button"
            onClick={onUndo}
            className="p-2 rounded-2xl hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Geri Al (Undo)"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        )}

        {/* REDO BUTTON */}
        {onRedo && (
          <button
            type="button"
            onClick={onRedo}
            className="p-2 rounded-2xl hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="İleri Al (Redo)"
          >
            <RotateCw className="w-4 h-4" />
          </button>
        )}

        {/* ML KIT DIGITAL INK RECOGNITION (OCR TO TEXT) */}
        {onRecognizeText && (
          <button
            type="button"
            onClick={onRecognizeText}
            className="px-3 py-2 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-extrabold text-xs shadow-md flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer"
            title="El Yazısını Metne Dönüştür (Google / Huawei ML Kit OCR)"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden md:inline">Metne Çevir</span>
          </button>
        )}

        {/* CLOSE STYLUS DOCK */}
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-2xl hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
            title="Kalem Çubuğunu Kapat"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
    </motion.div>
  );
};
