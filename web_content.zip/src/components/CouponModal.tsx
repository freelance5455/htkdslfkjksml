import React, { useState } from 'react';
import { Ticket, Sparkles, Coins, Check, X, AlertCircle } from 'lucide-react';
import { playLevelUpSound, playCoinSound, playErrorSound } from '../utils/soundEffects';
import { triggerConfetti } from '../utils/confetti';

interface CouponModalProps {
  userId: string;
  onRedeemSuccess: (coins: number) => void;
  onClose: () => void;
  soundEnabled: boolean;
}

export const CouponModal: React.FC<CouponModalProps> = ({
  userId,
  onRedeemSuccess,
  onClose,
  soundEnabled,
}) => {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<{ text: string; success: boolean } | null>(null);

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) return;

    setLoading(true);
    setStatus(null);

    try {
      const res = await fetch('/api/coupons/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: code.trim(),
          userId,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'فشل استرداد الكوبون');
      }

      if (soundEnabled) {
        playLevelUpSound();
        setTimeout(playCoinSound, 500);
      }
      triggerConfetti();

      setStatus({ text: data.message || `تمت إضافة ${data.coinsReward} نقطة لرصيدك! 🎉`, success: true });
      onRedeemSuccess(data.coinsReward);
      setCode('');
    } catch (err: any) {
      if (soundEnabled) playErrorSound();
      setStatus({ text: err.message || 'حدث خطأ في استرداد الكوبون', success: false });
    } finally {
      setLoading(false);
    }
  };

  const handleQuickCode = (preset: string) => {
    setCode(preset);
    setStatus(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-gradient-to-b from-slate-900 to-indigo-950/40 border border-indigo-500/30 rounded-3xl p-6 shadow-2xl text-right">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="text-center mb-5">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-400 mb-2.5 shadow-md">
            <Ticket className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-black text-white">استرداد كود كوبون هدية</h3>
          <p className="text-xs text-slate-400 mt-1">
            أدخل كود الهدية أو الرمز الترويجي لتحصل على نقاط فورية بالماركت!
          </p>
        </div>

        {status && (
          <div
            className={`mb-4 p-3 rounded-2xl text-xs font-bold text-center border ${
              status.success
                ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                : 'bg-red-950/60 border-red-500/40 text-red-300'
            }`}
          >
            {status.text}
          </div>
        )}

        <form onSubmit={handleRedeem} className="space-y-3">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              رمز الكوبون (Coupon Code):
            </label>
            <input
              type="text"
              required
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="مثال: WAQTI2026"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 text-center font-mono uppercase font-bold tracking-wider"
            />
          </div>

          <button
            type="submit"
            disabled={loading || !code.trim()}
            className="w-full py-2.5 rounded-xl font-black text-xs sm:text-sm bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-lg shadow-indigo-600/30 transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? 'جاري التحقق...' : 'شحن وتفعيل الكوبون الآن 🪙'}
          </button>
        </form>

        {/* Starter Codes Helper */}
        <div className="mt-5 pt-4 border-t border-slate-800/80">
          <p className="text-[11px] text-slate-400 mb-2 font-bold">أكواد ترحيبية متاحة للمستخدمين الجدد:</p>
          <div className="flex flex-wrap gap-1.5 justify-center">
            {['WAQTI2026', 'FOUNDER_GIFT', 'SUPER_FOCUS'].map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => handleQuickCode(c)}
                className="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-amber-300 font-mono text-[11px] font-bold cursor-pointer transition-colors"
              >
                {c}
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
