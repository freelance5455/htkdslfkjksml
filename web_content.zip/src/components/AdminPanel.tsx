import React, { useState } from 'react';
import {
  ShieldCheck,
  Users,
  CheckCircle2,
  Clock,
  Activity,
  TrendingUp,
  Settings,
  Eye,
  EyeOff,
  Copy,
  Trash2,
  Search,
  Filter,
  Download,
  ArrowLeft,
  RefreshCw,
  Lock,
  Instagram,
  Mail,
  Calendar,
  AlertTriangle,
} from 'lucide-react';
import { InstagramAccount, AccountStatus, AppSettings } from '../types';

interface AdminPanelProps {
  accounts: InstagramAccount[];
  settings: AppSettings;
  onClose: () => void;
  onOpenSettings: () => void;
  onUpdateStatus: (id: string, status: AccountStatus) => Promise<void>;
  onDeleteAccount: (id: string) => Promise<void>;
  onRefresh: () => Promise<void>;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  accounts,
  settings,
  onClose,
  onOpenSettings,
  onUpdateStatus,
  onDeleteAccount,
  onRefresh,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | AccountStatus>('all');
  const [visiblePasswords, setVisiblePasswords] = useState<{ [id: string]: boolean }>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Toggle password visibility
  const togglePasswordVisibility = (id: string) => {
    setVisiblePasswords((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Copy password to clipboard
  const handleCopyPassword = (id: string, pass: string) => {
    navigator.clipboard.writeText(pass);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Filter accounts
  const filteredAccounts = accounts.filter((acc) => {
    const matchSearch =
      acc.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (acc.created_by && acc.created_by.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchStatus = statusFilter === 'all' || acc.status === statusFilter;
    return matchSearch && matchStatus;
  });

  // Calculate statistics
  const totalAccounts = accounts.length;
  const completedOrders = accounts.filter((a) => a.status === 'completed').length;
  const pendingOrders = accounts.filter((a) => a.status === 'pending').length;
  const processingOrders = accounts.filter((a) => a.status === 'processing').length;
  const totalFollowersRequested = accounts.reduce(
    (sum, a) => sum + (Number(a.followers_requested) || 0),
    0
  );

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await onRefresh();
    setTimeout(() => setIsRefreshing(false), 500);
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['ID,Username,Password,Followers_Requested,Status,Created_By,Created_At'];
    const rows = accounts.map(
      (a) =>
        `"${a.id}","${a.username}","${a.password.replace(/"/g, '""')}","${a.followers_requested}","${a.status}","${a.created_by}","${a.created_at}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `instaboost_accounts_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-purple-950 text-slate-100 pb-16">
      {/* Top Navbar */}
      <div className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-xl border-b border-purple-500/20 px-4 sm:px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors border border-purple-500/20"
              title="Return to Home Screen"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-950">
                <ShieldCheck className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-base font-extrabold text-white flex items-center gap-2">
                  Admin Control Panel
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Verified
                  </span>
                </h1>
                <p className="text-[11px] text-slate-400">
                  Manage Instagram Accounts, Orders & App Settings
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRefresh}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-purple-500/20 transition-all"
              title="Refresh Data"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-pink-400' : ''}`} />
            </button>

            <button
              onClick={onOpenSettings}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:brightness-110 active:scale-95 text-white text-xs font-bold transition-all shadow-md shadow-purple-950"
            >
              <Settings className="w-4 h-4" />
              <span>Settings</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        {/* Stats Cards Section */}
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
          {/* 1. Total Accounts */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-purple-500/25 shadow-lg backdrop-blur-md">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Total Accounts</span>
              <div className="w-8 h-8 rounded-xl bg-purple-500/15 text-purple-300 flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
              {totalAccounts}
            </div>
            <p className="text-[11px] text-purple-300/80 mt-1">Submitted submissions</p>
          </div>

          {/* 2. Completed Orders */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-emerald-500/25 shadow-lg backdrop-blur-md">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Completed Orders</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-300 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono">
              {completedOrders}
            </div>
            <p className="text-[11px] text-emerald-300/80 mt-1">Followers delivered</p>
          </div>

          {/* 3. Pending Orders */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-amber-500/25 shadow-lg backdrop-blur-md">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Pending Orders</span>
              <div className="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-300 flex items-center justify-center">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono">
              {pendingOrders}
            </div>
            <p className="text-[11px] text-amber-300/80 mt-1">Awaiting dispatch</p>
          </div>

          {/* 4. Total Followers Dispatched */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-pink-500/25 shadow-lg backdrop-blur-md">
            <div className="flex items-center justify-between text-slate-400 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Followers Volume</span>
              <div className="w-8 h-8 rounded-xl bg-pink-500/15 text-pink-300 flex items-center justify-center">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-pink-400 font-mono">
              +{totalFollowersRequested.toLocaleString()}
            </div>
            <p className="text-[11px] text-pink-300/80 mt-1">Total growth requested</p>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-purple-500/20 mb-6 flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="w-full sm:w-80 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by username or email..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-purple-500/25 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-pink-500"
            />
          </div>

          <div className="w-full sm:w-auto flex items-center gap-2 justify-between sm:justify-end">
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              <span className="text-slate-400 text-xs mr-1 hidden sm:inline">Filter:</span>
              {(['all', 'pending', 'processing', 'completed'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1.5 rounded-lg capitalize font-medium transition-all ${
                    statusFilter === st
                      ? 'bg-purple-600 text-white shadow-sm shadow-purple-900'
                      : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-purple-500/15'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-purple-500/20 transition-colors shrink-0"
              title="Download Accounts CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export CSV</span>
            </button>
          </div>
        </div>

        {/* Accounts Table / Cards */}
        {filteredAccounts.length === 0 ? (
          <div className="p-12 text-center rounded-3xl bg-slate-900/60 border border-purple-500/20">
            <Instagram className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-300">No Instagram Accounts Found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              No accounts match the current filter or search criteria.
            </p>
          </div>
        ) : (
          <div className="rounded-2xl border border-purple-500/20 overflow-hidden bg-slate-900/90 shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-purple-500/20 text-slate-400 font-semibold uppercase tracking-wider">
                    <th className="py-3 px-4">Account (Username)</th>
                    <th className="py-3 px-4">Password</th>
                    <th className="py-3 px-4">Followers</th>
                    <th className="py-3 px-4">Order Status</th>
                    <th className="py-3 px-4">Created By</th>
                    <th className="py-3 px-4">Date & Time</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-purple-500/10">
                  {filteredAccounts.map((acc) => {
                    const isVisible = visiblePasswords[acc.id];
                    const isCopied = copiedId === acc.id;

                    return (
                      <tr
                        key={acc.id}
                        className="hover:bg-purple-950/20 transition-colors group"
                      >
                        {/* Username */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center text-white font-bold text-xs shrink-0 shadow-sm">
                              {acc.username.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <span className="font-bold text-slate-100 flex items-center gap-1 font-mono">
                                @{acc.username}
                              </span>
                              <span className="text-[10px] text-slate-500 font-mono block">
                                ID: {acc.id.slice(-8)}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* Password with Show/Hide and Copy */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono bg-slate-950/80 px-2.5 py-1 rounded-md border border-purple-500/20 text-purple-200">
                              {isVisible ? acc.password : '••••••••••••'}
                            </span>
                            <button
                              type="button"
                              onClick={() => togglePasswordVisibility(acc.id)}
                              className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                              title={isVisible ? 'Hide Password' : 'Show Password'}
                            >
                              {isVisible ? (
                                <EyeOff className="w-3.5 h-3.5" />
                              ) : (
                                <Eye className="w-3.5 h-3.5" />
                              )}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleCopyPassword(acc.id, acc.password)}
                              className="p-1 rounded text-slate-400 hover:text-pink-300 hover:bg-slate-800"
                              title="Copy Password"
                            >
                              {isCopied ? (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                        </td>

                        {/* Followers Requested */}
                        <td className="py-3.5 px-4 font-mono font-bold text-pink-400 text-sm">
                          +{Number(acc.followers_requested).toLocaleString()}
                        </td>

                        {/* Status Dropdown */}
                        <td className="py-3.5 px-4">
                          <select
                            value={acc.status}
                            onChange={(e) =>
                              onUpdateStatus(acc.id, e.target.value as AccountStatus)
                            }
                            className={`px-2.5 py-1 rounded-lg text-xs font-semibold font-mono border outline-none cursor-pointer ${
                              acc.status === 'completed'
                                ? 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40'
                                : acc.status === 'processing'
                                ? 'bg-sky-950/70 text-sky-300 border-sky-500/40'
                                : acc.status === 'pending'
                                ? 'bg-amber-950/70 text-amber-300 border-amber-500/40'
                                : 'bg-rose-950/70 text-rose-300 border-rose-500/40'
                            }`}
                          >
                            <option value="pending" className="bg-slate-900 text-amber-300">
                              ⏳ Pending
                            </option>
                            <option value="processing" className="bg-slate-900 text-sky-300">
                              ⚡ Processing
                            </option>
                            <option value="completed" className="bg-slate-900 text-emerald-300">
                              ✅ Completed
                            </option>
                            <option value="cancelled" className="bg-slate-900 text-rose-300">
                              🚫 Cancelled
                            </option>
                          </select>
                        </td>

                        {/* Created By */}
                        <td className="py-3.5 px-4 text-slate-400">
                          <div className="flex items-center gap-1 font-mono text-[11px] text-slate-300">
                            <Mail className="w-3 h-3 text-purple-400 shrink-0" />
                            <span className="truncate max-w-[160px]">{acc.created_by || 'Anonymous'}</span>
                          </div>
                        </td>

                        {/* Created Date */}
                        <td className="py-3.5 px-4 text-slate-400 font-mono text-[11px]">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-slate-500" />
                            <span>
                              {new Date(acc.created_at).toLocaleString([], {
                                dateStyle: 'short',
                                timeStyle: 'short',
                              })}
                            </span>
                          </div>
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm(`Delete record for @${acc.username}?`)) {
                                onDeleteAccount(acc.id);
                              }
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                            title="Delete Record"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
