import { useMemo, useState } from "react";
import { Ban, CalendarClock, Check, Download, KeyRound, Loader2, Lock, Search, ShieldCheck, Ticket, X } from "lucide-react";
import { ACCESSORY_MAP, CATS, FURS, OUTFITS, rewardKind, rewardName } from "../data/catalog";
import {
  codeStatus, downloadTextFile, exportCodesText, generateBatch, loadCodes, revokeCode,
  type GiftCode,
} from "../lib/codes";
import { sfx } from "../lib/sound";

const ADMIN_KEY = "michilicias-admin-hash-v1";

async function sha256(text: string): Promise<string> {
  try {
    if (crypto?.subtle) {
      const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
      return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
    }
    throw new Error("no subtle");
  } catch {
    // Respaldo para contextos sin crypto.subtle (nunca guarda la contraseña en claro)
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;
    for (let i = 0; i < text.length; i++) {
      const ch = text.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    return `fb-${(h1 >>> 0).toString(16)}${(h2 >>> 0).toString(16)}-${text.length}`;
  }
}

interface RewardGroup { label: string; ids: string[] }
const REWARD_GROUPS: RewardGroup[] = [
  { label: "Sombreros exclusivos (100)", ids: [...ACCESSORY_MAP.values()].filter((i) => i.slot === "hat").map((i) => i.id) },
  { label: "Moños exclusivos (100)", ids: [...ACCESSORY_MAP.values()].filter((i) => i.slot === "bow").map((i) => i.id) },
  { label: "Collares exclusivos (100)", ids: [...ACCESSORY_MAP.values()].filter((i) => i.slot === "collar").map((i) => i.id) },
  { label: "Pelajes exclusivos (100)", ids: FURS.map((f) => f.id) },
  { label: "Gatitos exclusivos (100)", ids: CATS.map((c) => c.id) },
  { label: "Conjuntos exclusivos (200)", ids: OUTFITS.map((o) => o.id) },
];

export default function AdminPanel({ onClose }: { onClose: () => void }) {
  const [authed, setAuthed] = useState(false);
  const [hasPassword, setHasPassword] = useState(() => !!localStorage.getItem(ADMIN_KEY));
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [authError, setAuthError] = useState("");
  const [busy, setBusy] = useState(false);

  const [codes, setCodes] = useState<GiftCode[]>(() => loadCodes());
  const [count, setCount] = useState(5);
  const [length, setLength] = useState(10);
  const [maxUses, setMaxUses] = useState(1);
  const [orderId, setOrderId] = useState("");
  const [expiry, setExpiry] = useState("");
  const [isTest, setIsTest] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [group, setGroup] = useState(0);
  const [rewardQuery, setRewardQuery] = useState("");
  const [codeQuery, setCodeQuery] = useState("");
  const [lastBatch, setLastBatch] = useState<GiftCode[]>([]);
  const [tab, setTab] = useState<"gen" | "codes" | "history">("gen");

  const refresh = () => setCodes(loadCodes());

  const doAuth = async () => {
    setBusy(true);
    setAuthError("");
    try {
      const hash = await sha256(pw);
      if (!hasPassword) {
        if (pw.length < 4) { setAuthError("La contraseña debe tener al menos 4 caracteres."); return; }
        if (pw !== pw2) { setAuthError("Las contraseñas no coinciden."); return; }
        localStorage.setItem(ADMIN_KEY, hash);
        setHasPassword(true);
        setAuthed(true);
        sfx.sparkle();
      } else if (hash === localStorage.getItem(ADMIN_KEY)) {
        setAuthed(true);
        sfx.sparkle();
      } else {
        setAuthError("Contraseña incorrecta.");
        sfx.error();
      }
    } finally {
      setBusy(false);
    }
  };

  const toggleReward = (id: string) =>
    setSelected((prev) => (prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]));

  const createBatch = () => {
    if (selected.length === 0) { sfx.error(); return; }
    const batch = generateBatch({
      count: Math.max(1, Math.min(200, count)),
      length,
      rewards: selected,
      maxUses: Math.max(1, maxUses),
      expiresAt: expiry ? new Date(`${expiry}T23:59:59`).toISOString() : null,
      orderId: orderId.trim() || (isTest ? "PRUEBAS" : "SIN-PEDIDO"),
      test: isTest,
    });
    setLastBatch(batch);
    refresh();
    sfx.coin();
  };

  const redemptions = useMemo(
    () =>
      codes.flatMap((c) =>
        c.redemptions.map((r) => ({ code: c.code, at: r.at, orderId: c.orderId, rewards: c.rewards, test: c.test }))
      ).sort((a, b) => b.at.localeCompare(a.at)),
    [codes]
  );

  const filteredCodes = codes.filter(
    (c) => c.code.includes(codeQuery.toUpperCase()) || c.orderId.toLowerCase().includes(codeQuery.toLowerCase())
  );

  if (!authed) {
    return (
      <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/75 p-5 backdrop-blur-sm">
        <div className="modal-pop w-full max-w-sm rounded-[26px] border-2 border-[#caa25a] bg-[#17141f] p-5">
          <div className="mb-1 flex items-center justify-between">
            <h2 className="flex items-center gap-2 font-display text-xl font-semibold text-[#f5c451]">
              <ShieldCheck className="h-5 w-5" /> Panel MICHILICIAS
            </h2>
            <button onClick={onClose} aria-label="Cerrar" className="rounded-full bg-white/10 p-1.5 text-white active:scale-90"><X className="h-5 w-5" /></button>
          </div>
          <p className="mb-4 text-sm font-semibold text-white/55">
            {hasPassword
              ? "Escribe la contraseña de administración para continuar."
              : "Primera vez: crea la contraseña de administración. Se guarda solo su huella segura (hash) en este dispositivo, nunca en el juego."}
          </p>
          <input
            type="password"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && hasPassword && doAuth()}
            placeholder="Contraseña de administración"
            className="w-full rounded-2xl border border-white/15 bg-black/40 px-4 py-3.5 font-display text-base font-semibold text-white placeholder:text-white/30 focus:border-[#f5c451] focus:outline-none"
          />
          {!hasPassword && (
            <input
              type="password"
              value={pw2}
              onChange={(e) => setPw2(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && doAuth()}
              placeholder="Repite la contraseña"
              className="mt-2.5 w-full rounded-2xl border border-white/15 bg-black/40 px-4 py-3.5 font-display text-base font-semibold text-white placeholder:text-white/30 focus:border-[#f5c451] focus:outline-none"
            />
          )}
          {authError && <p className="mt-2.5 rounded-xl bg-rose-400/15 px-3 py-2 text-sm font-bold text-rose-200">{authError}</p>}
          <button
            onClick={doAuth}
            disabled={busy || !pw}
            className="mt-4 flex min-h-[52px] w-full items-center justify-center gap-2 rounded-2xl bg-[#f5c451] font-display text-base font-bold text-[#241a02] transition active:scale-[0.98] disabled:opacity-40"
          >
            {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <KeyRound className="h-5 w-5" />}
            {hasPassword ? "Entrar al panel" : "Crear contraseña y entrar"}
          </button>
          <p className="mt-3 flex items-start gap-1.5 text-[11px] font-semibold leading-snug text-white/40">
            <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            En producción, la administración real debe vivir en el servidor de la tienda; este panel local sirve para generar lotes en el dispositivo del equipo.
          </p>
        </div>
      </div>
    );
  }

  const inputCls = "w-full rounded-xl border border-white/12 bg-black/40 px-3 py-2.5 text-sm font-bold text-white focus:border-[#f5c451] focus:outline-none";
  const labelCls = "mb-1 block text-[11px] font-extrabold uppercase tracking-wide text-white/50";

  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-[#12101c]">
      <div className="flex items-center justify-between border-b border-[#caa25a]/50 px-4 py-3">
        <h2 className="flex items-center gap-2 font-display text-lg font-semibold text-[#f5c451]">
          <ShieldCheck className="h-5 w-5" /> Administración de códigos
        </h2>
        <button onClick={onClose} aria-label="Cerrar" className="rounded-full bg-white/10 p-2 text-white active:scale-90"><X className="h-5 w-5" /></button>
      </div>

      <div className="grid shrink-0 grid-cols-3 gap-2 px-4 pt-3">
        {([["gen", "Generar"], ["codes", `Códigos (${codes.length})`], ["history", "Historial"]] as const).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`min-h-[42px] rounded-xl font-display text-[13px] font-semibold ${tab === id ? "bg-[#f5c451] text-[#241a02]" : "border border-white/10 bg-white/8 text-white/70"}`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="no-scrollbar flex-1 overflow-y-auto p-4">
        {tab === "gen" && (
          <div>
            <div className="grid grid-cols-2 gap-2.5">
              <div><label className={labelCls}>Cantidad</label><input type="number" min={1} max={200} value={count} onChange={(e) => setCount(Number(e.target.value))} className={inputCls} /></div>
              <div>
                <label className={labelCls}>Longitud</label>
                <select value={length} onChange={(e) => setLength(Number(e.target.value))} className={inputCls}>
                  {[6, 8, 10, 12, 16, 20].map((n) => <option key={n} value={n} className="bg-[#17141f]">{n} caracteres</option>)}
                </select>
              </div>
              <div><label className={labelCls}>Usos por código</label><input type="number" min={1} max={999} value={maxUses} onChange={(e) => setMaxUses(Number(e.target.value))} className={inputCls} /></div>
              <div><label className={labelCls}>Caducidad (opcional)</label><input type="date" value={expiry} onChange={(e) => setExpiry(e.target.value)} className={inputCls} /></div>
              <div className="col-span-2"><label className={labelCls}>Identificador del pedido</label><input value={orderId} onChange={(e) => setOrderId(e.target.value)} placeholder="Ej. PEDIDO-2024-001" className={inputCls} /></div>
            </div>

            <label className="mt-3 flex items-center gap-2 rounded-xl border border-white/10 bg-black/30 px-3 py-2.5">
              <input type="checkbox" checked={isTest} onChange={(e) => setIsTest(e.target.checked)} className="h-4 w-4 accent-amber-400" />
              <span className="text-sm font-bold text-white/75">Marcar como lote de PRUEBA (separado de clientes reales)</span>
            </label>

            <p className="mb-1 mt-4 text-[11px] font-extrabold uppercase tracking-wide text-white/50">
              Recompensas de cada código ({selected.length} elegidas)
            </p>
            <div className="no-scrollbar mb-2 flex gap-1.5 overflow-x-auto">
              {REWARD_GROUPS.map((g, i) => (
                <button key={g.label} onClick={() => setGroup(i)} className={`shrink-0 rounded-full px-2.5 py-1.5 text-[11px] font-extrabold ${group === i ? "bg-[#f5c451] text-[#241a02]" : "bg-white/8 text-white/60"}`}>
                  {g.label}
                </button>
              ))}
            </div>
            <label className="mb-2 flex items-center gap-2 rounded-xl border border-white/10 bg-black/40 px-3 py-2">
              <Search className="h-4 w-4 text-white/40" />
              <input value={rewardQuery} onChange={(e) => setRewardQuery(e.target.value)} placeholder="Buscar recompensa..." className="w-full bg-transparent text-sm font-bold text-white placeholder:text-white/30 focus:outline-none" />
            </label>
            {selected.length > 0 && (
              <div className="mb-2 flex flex-wrap gap-1.5">
                {selected.map((id) => (
                  <button key={id} onClick={() => toggleReward(id)} className="flex items-center gap-1 rounded-full bg-[#f5c451] px-2.5 py-1 text-[11px] font-extrabold text-[#241a02]">
                    {rewardName(id)} <X className="h-3 w-3" />
                  </button>
                ))}
              </div>
            )}
            <div className="no-scrollbar max-h-52 overflow-y-auto rounded-2xl border border-white/10">
              {REWARD_GROUPS[group].ids
                .filter((id) => rewardName(id).toLowerCase().includes(rewardQuery.toLowerCase()))
                .slice(0, 120)
                .map((id) => {
                  const on = selected.includes(id);
                  return (
                    <button key={id} onClick={() => toggleReward(id)} className={`flex w-full items-center gap-2 px-3 py-2 text-left text-[13px] font-bold ${on ? "bg-[#2a2210] text-[#ffe9a8]" : "text-white/70"}`}>
                      <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${on ? "border-[#f5c451] bg-[#f5c451] text-[#241a02]" : "border-white/25"}`}>
                        {on && <Check className="h-3.5 w-3.5" />}
                      </span>
                      <span className="min-w-0 flex-1 truncate">{rewardName(id)}</span>
                      <span className="shrink-0 text-[10px] text-white/35">{rewardKind(id)}</span>
                    </button>
                  );
                })}
            </div>

            <button
              onClick={createBatch}
              disabled={selected.length === 0}
              className="mt-4 flex min-h-[52px] w-full items-center justify-center gap-2 rounded-2xl bg-[#f5c451] font-display text-base font-bold text-[#241a02] transition active:scale-[0.98] disabled:opacity-40"
            >
              <Ticket className="h-5 w-5" /> Generar {count} código{count === 1 ? "" : "s"} y registrarlos
            </button>

            {lastBatch.length > 0 && (
              <div className="mt-3 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-3.5">
                <p className="font-display text-sm font-semibold text-emerald-200">Lote creado y registrado: {lastBatch.length} códigos</p>
                <div className="mt-2 max-h-32 overflow-y-auto rounded-xl bg-black/40 p-2.5 font-mono text-xs leading-relaxed text-amber-100">
                  {lastBatch.map((c) => <div key={c.code}>{c.code}</div>)}
                </div>
                <button
                  onClick={() => downloadTextFile(`codigos-michilicias-${lastBatch[0].orderId}.txt`, exportCodesText(lastBatch, `Lote ${lastBatch[0].orderId}`))}
                  className="mt-2.5 flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-emerald-400 font-display text-sm font-bold text-emerald-950 active:scale-[0.98]"
                >
                  <Download className="h-4 w-4" /> Exportar códigos (.txt) para entregar
                </button>
              </div>
            )}
          </div>
        )}

        {tab === "codes" && (
          <div>
            <label className="mb-2.5 flex items-center gap-2 rounded-xl border border-white/10 bg-black/40 px-3 py-2">
              <Search className="h-4 w-4 text-white/40" />
              <input value={codeQuery} onChange={(e) => setCodeQuery(e.target.value)} placeholder="Buscar por código o pedido..." className="w-full bg-transparent text-sm font-bold text-white placeholder:text-white/30 focus:outline-none" />
            </label>
            <div className="flex flex-col gap-2">
              {filteredCodes.map((c) => (
                <div key={c.code} className="rounded-2xl border border-white/10 bg-[#1a1828] px-3.5 py-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-sm font-bold text-amber-100">{c.code}</span>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold ${c.test ? "bg-sky-400/20 text-sky-300" : "bg-white/10 text-white/60"}`}>
                      {c.test ? "PRUEBA" : "CLIENTE"} · {codeStatus(c)}
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] font-semibold leading-snug text-white/50">
                    Pedido {c.orderId} · Usos {c.maxUses - c.usesLeft}/{c.maxUses}
                    {c.expiresAt ? ` · Caduca ${new Date(c.expiresAt).toLocaleDateString("es")}` : " · Sin caducidad"}
                  </p>
                  <p className="mt-0.5 truncate text-[11px] font-semibold text-white/40">{c.rewards.map(rewardName).join(" · ")}</p>
                  {!c.revoked && (
                    <button
                      onClick={() => { revokeCode(c.code); refresh(); sfx.pop(); }}
                      className="mt-2 flex items-center gap-1 rounded-full bg-rose-400/15 px-2.5 py-1.5 text-[11px] font-extrabold text-rose-300 active:scale-95"
                    >
                      <Ban className="h-3.5 w-3.5" /> Revocar código
                    </button>
                  )}
                </div>
              ))}
              {filteredCodes.length === 0 && <p className="py-8 text-center text-sm font-bold text-white/40">No hay códigos con ese criterio.</p>}
            </div>
          </div>
        )}

        {tab === "history" && (
          <div className="flex flex-col gap-2">
            {redemptions.map((r, i) => (
              <div key={`${r.code}-${i}`} className="rounded-2xl border border-white/10 bg-[#1a1828] px-3.5 py-3">
                <p className="flex items-center gap-1.5 font-mono text-sm font-bold text-amber-100">
                  <CalendarClock className="h-4 w-4 text-white/40" /> {r.code}
                  {r.test && <span className="rounded-full bg-sky-400/20 px-2 py-0.5 font-sans text-[10px] font-extrabold text-sky-300">PRUEBA</span>}
                </p>
                <p className="mt-1 text-[11px] font-semibold text-white/50">
                  {new Date(r.at).toLocaleString("es")} · Pedido {r.orderId}
                </p>
                <p className="mt-0.5 text-[11px] font-semibold leading-snug text-white/40">
                  Entregado: {r.rewards.map(rewardName).join(" · ")}
                </p>
              </div>
            ))}
            {redemptions.length === 0 && (
              <p className="py-8 text-center text-sm font-bold text-white/40">Todavía no hay canjes registrados.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
