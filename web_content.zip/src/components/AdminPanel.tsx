import React, { useState, useEffect } from 'react';
import {
  JobPosting,
  JobCategory,
  JobSector,
  JobStatus,
  JobReport,
  getJobExpiryDate,
  isJobExpired
} from '../types/job';
import { INDIA_STATES_AND_UTS, getDistrictsByState } from '../data/indiaLocations';
import {
  addJobToFirestore,
  updateJobInFirestore,
  deleteJobFromFirestore,
  deleteExpiredJobsFromFirestore,
  seedJobsToFirestore,
  subscribeToReports,
  updateReportStatusInFirestore,
  uploadOfficialNotificationPdf,
  isUserAdmin,
  isAuthorizedAdminUid,
  signInAdminWithGoogle,
  signInAdminWithEmailPassword,
  adminSignOut,
  auth,
  testFirebaseConnection,
  FirebaseConnectionStatus,
  saveCustomFirebaseConfig,
  resetFirebaseConfig,
  getActiveFirebaseConfig,
  getFirebaseProjectDebugInfo,
  FirebaseProjectDebugInfo,
  getUserFriendlyErrorMessage
} from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import {
  ShieldCheck,
  PlusCircle,
  Database,
  Download,
  Trash2,
  CheckCircle,
  RefreshCw,
  Edit3,
  Upload,
  AlertTriangle,
  Lock,
  Mail,
  LogIn,
  LogOut,
  Sparkles,
  Flame,
  FileText,
  Search,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Layers,
  MapPin,
  Eye,
  EyeOff,
  Copy,
  Check,
  Settings,
  Sliders,
  HelpCircle,
  Clock,
  X,
  Calendar
} from 'lucide-react';

interface AdminPanelProps {
  jobs: JobPosting[];
  onRefreshJobs?: () => void;
  onOpenDetail?: (job: JobPosting) => void;
  isAdmin?: boolean;
  currentAdminEmail?: string;
}

const ALL_AVAILABLE_CATEGORIES: JobCategory[] = [
  'Government Jobs',
  'Private Jobs',
  'Latest Jobs',
  'ITI Jobs',
  'Diploma Jobs',
  'Graduate Jobs',
  'Railway Jobs',
  'Banking Jobs',
  'Defence Jobs',
  'Apprenticeship Jobs'
];

const ALL_STATUSES: JobStatus[] = [
  'PUBLISHED',
  'VERIFIED',
  'PENDING',
  'DRAFT',
  'EXPIRED',
  'REJECTED'
];

const FIRESTORE_RULES_SNIPPET = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isAuthenticated() { return request.auth != null; }
    function isAdmin() {
      return isAuthenticated() && (
        (exists(/databases/$(database)/documents/admin_users/$(request.auth.uid)) &&
         (get(/databases/$(database)/documents/admin_users/$(request.auth.uid)).data.role == 'admin' ||
          get(/databases/$(database)/documents/admin_users/$(request.auth.uid)).data.role == 'superadmin')) ||
        request.auth.token.role == 'admin'
      );
    }
    match /jobs/{jobId} {
      allow read: if resource.data.status == 'PUBLISHED' || resource.data.status == 'VERIFIED' || isAdmin();
      allow create, update, delete: if isAdmin();
    }
    match /admin_users/{userId} {
      allow read: if isAuthenticated();
      allow write: if isAdmin() || (isAuthenticated() && request.auth.uid == userId);
    }
    match /users/{userId} {
      allow read, write: if isAuthenticated() && request.auth.uid == userId;
      match /job_alerts/{alertId} {
        allow read, write: if isAuthenticated() && request.auth.uid == userId;
      }
    }
    match /saved_jobs/{saveId} {
      allow read, write: if isAuthenticated() && (
        (resource == null && request.resource.data.userId == request.auth.uid) ||
        (resource != null && resource.data.userId == request.auth.uid)
      );
    }
    match /reports/{reportId} {
      allow create: if true;
      allow read, update, delete: if isAdmin();
    }
    match /states/{stateId} { allow read: if true; allow write: if isAdmin(); }
    match /categories/{categoryId} { allow read: if true; allow write: if isAdmin(); }
  }
}`;

export const AdminPanel: React.FC<AdminPanelProps> = ({
  jobs,
  onRefreshJobs,
  onOpenDetail,
  isAdmin = false,
  currentAdminEmail
}) => {
  // Admin authentication state verified via Firebase Auth and Firestore admin_users/{UID}
  // Initialize immediately to true if admin status is already authenticated and verified to prevent flash
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    if (isAdmin) return true;
    if (sessionStorage.getItem('india_job_hub_admin_session') === 'active') return true;
    return false;
  });
  const [authenticatedAdminEmail, setAuthenticatedAdminEmail] = useState<string>(() => {
    return (
      currentAdminEmail ||
      auth.currentUser?.email ||
      sessionStorage.getItem('india_job_hub_admin_email') ||
      'Admin Officer'
    );
  });
  const [authError, setAuthError] = useState('');
  const [deniedUid, setDeniedUid] = useState<string | null>(null);
  const [copiedUid, setCopiedUid] = useState(false);
  const [isGoogleLoggingIn, setIsGoogleLoggingIn] = useState(false);
  const [adminAuthMethod, setAdminAuthMethod] = useState<'google' | 'email'>('google');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [isEmailLoggingIn, setIsEmailLoggingIn] = useState(false);

  // Keep authenticated state in sync if isAdmin prop changes
  useEffect(() => {
    if (isAdmin) {
      setIsAdminAuthenticated(true);
      const email = currentAdminEmail || auth.currentUser?.email || 'Admin Officer';
      setAuthenticatedAdminEmail(email);
      sessionStorage.setItem('india_job_hub_admin_session', 'active');
      if (currentAdminEmail || auth.currentUser?.email) {
        sessionStorage.setItem('india_job_hub_admin_email', email);
      }
    }
  }, [isAdmin, currentAdminEmail]);

  // Firebase project debug info
  const [debugInfo, setDebugInfo] = useState<FirebaseProjectDebugInfo>(() => getFirebaseProjectDebugInfo());
  const [copiedProjectId, setCopiedProjectId] = useState(false);

  const handleCopyProjectId = () => {
    const proj = debugInfo.configuredProjectId;
    if (navigator.clipboard && proj) {
      navigator.clipboard.writeText(proj);
      setCopiedProjectId(true);
      setTimeout(() => setCopiedProjectId(false), 2200);
    }
  };

  const handleCopyDeniedUid = () => {
    if (navigator.clipboard && deniedUid) {
      navigator.clipboard.writeText(deniedUid);
      setCopiedUid(true);
      setTimeout(() => setCopiedUid(false), 2200);
    }
  };

  // Maintain verified admin session via Firebase Auth state
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const isAuthorized = await isAuthorizedAdminUid(user.uid);
          if (isAuthorized) {
            setIsAdminAuthenticated(true);
            setAuthenticatedAdminEmail(user.email || 'Admin Officer');
            sessionStorage.setItem('india_job_hub_admin_session', 'active');
            if (user.email) sessionStorage.setItem('india_job_hub_admin_email', user.email);
          } else {
            if (!isAdmin) {
              setIsAdminAuthenticated(false);
              sessionStorage.removeItem('india_job_hub_admin_session');
              sessionStorage.removeItem('india_job_hub_admin_email');
            }
          }
        } catch {
          if (!isAdmin) {
            setIsAdminAuthenticated(false);
            sessionStorage.removeItem('india_job_hub_admin_session');
            sessionStorage.removeItem('india_job_hub_admin_email');
          }
        }
      } else {
        if (!isAdmin) {
          setIsAdminAuthenticated(false);
          sessionStorage.removeItem('india_job_hub_admin_session');
          sessionStorage.removeItem('india_job_hub_admin_email');
        }
      }
    });
    return () => unsub();
  }, [isAdmin]);

  // Live Firebase connection status & diagnostics
  const [connectionStatus, setConnectionStatus] = useState<FirebaseConnectionStatus | null>(null);
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [customConfigInput, setCustomConfigInput] = useState('');
  const [showCustomConfigForm, setShowCustomConfigForm] = useState(false);
  const [rulesCopied, setRulesCopied] = useState(false);
  const activeFirebaseConfig = getActiveFirebaseConfig();

  // Active panel tab
  const [activeTab, setActiveTab] = useState<'create' | 'manage' | 'expired' | 'reports' | 'locations' | 'firebase'>('create');

  // Confirmation dialog state for single and batch deletion (Requirements 4, 5, 6, 7)
  const [deleteConfirm, setDeleteConfirm] = useState<{
    isOpen: boolean;
    type: 'single' | 'all_expired';
    jobId?: string;
    jobTitle?: string;
    expiryDate?: string | null;
    isExpired?: boolean;
    count?: number;
  }>({ isOpen: false, type: 'single' });
  const [isDeleting, setIsDeleting] = useState(false);

  // Editing state
  const [editingJobId, setEditingJobId] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [organization, setOrganization] = useState('');
  const [sector, setSector] = useState<JobSector>('Government');
  const [selectedState, setSelectedState] = useState<string>('Delhi (NCT)');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('New Delhi');
  const [selectedCategories, setSelectedCategories] = useState<JobCategory[]>(['Government Jobs', 'Latest Jobs']);
  const [qualification, setQualification] = useState('');
  const [experience, setExperience] = useState('Freshers / 0-2 Years');
  const [salary, setSalary] = useState('');
  const [vacancies, setVacancies] = useState<number>(100);
  const [openingDate, setOpeningDate] = useState('2026-09-01');
  const [closingDate, setClosingDate] = useState('2026-11-30');
  const [officialApplicationLink, setOfficialApplicationLink] = useState('https://');
  const [officialSource, setOfficialSource] = useState('Official Gazette / Employment News');
  const [sourceUrl, setSourceUrl] = useState('');
  const [officialNotificationUrl, setOfficialNotificationUrl] = useState('');
  const [applicationFee, setApplicationFee] = useState('Refer to official notification');
  const [ageLimit, setAgeLimit] = useState('18 to 35 Years');
  const [description, setDescription] = useState('');
  const [selectionSteps, setSelectionSteps] = useState('Written Examination / CBT, Document Verification, Medical Test');
  const [requiredDocs, setRequiredDocs] = useState('Aadhaar Card, 10th Certificate, Degree/Diploma Marksheets, Caste Certificate, Passport Photos');
  const [status, setStatus] = useState<JobStatus>('PUBLISHED');
  const [isFeatured, setIsFeatured] = useState(false);
  const [isUrgent, setIsUrgent] = useState(false);
  const [isLatest, setIsLatest] = useState(true);

  // PDF upload state
  const [uploadingPdf, setUploadingPdf] = useState(false);
  const [pdfUploadSuccess, setPdfUploadSuccess] = useState('');

  // Status message
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Search in manage tab
  const [manageSearch, setManageSearch] = useState('');
  const [manageStatusFilter, setManageStatusFilter] = useState<string>('ALL');

  // Reports state from Firestore
  const [reports, setReports] = useState<JobReport[]>([]);

  // State & District manager additions
  const [newDistrictName, setNewDistrictName] = useState('');
  const [customDistricts, setCustomDistricts] = useState<Record<string, string[]>>({});

  const districtsForSelectedState = [
    ...getDistrictsByState(selectedState),
    ...(customDistricts[selectedState] || [])
  ];

  // Subscribe to live Firestore reports
  useEffect(() => {
    const unsub = subscribeToReports((fetchedReports) => {
      setReports(fetchedReports);
    });
    return () => unsub();
  }, []);

  // Run initial live Firebase connection test
  useEffect(() => {
    let isMounted = true;
    testFirebaseConnection().then((res) => {
      if (isMounted) setConnectionStatus(res);
    });
    return () => {
      isMounted = false;
    };
  }, []);

  const handleTestConnection = async () => {
    setIsTestingConnection(true);
    try {
      const res = await testFirebaseConnection();
      setConnectionStatus(res);
      if (res.status === 'connected') {
        setSuccessMessage('Cloud Firestore connection verified successfully!');
        setTimeout(() => setSuccessMessage(''), 3500);
      } else {
        setErrorMessage(res.message);
        setTimeout(() => setErrorMessage(''), 5000);
      }
    } catch (err: any) {
      setErrorMessage(getUserFriendlyErrorMessage(err, 'Connection test failed. Please check network.'));
    } finally {
      setIsTestingConnection(false);
    }
  };

  const handleToggleDatabaseId = () => {
    const config = getActiveFirebaseConfig();
    const nextDbId =
      config.firestoreDatabaseId === '(default)'
        ? 'ai-studio-indiajobhub-7b2e037e-6a19-4eb0-9a42-7a4ba5e8072c'
        : '(default)';
    saveCustomFirebaseConfig({ ...config, firestoreDatabaseId: nextDbId });
  };

  const handleSaveCustomJson = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const parsed = JSON.parse(customConfigInput);
      if (!parsed.apiKey || !parsed.projectId) {
        setErrorMessage('Config must have "apiKey" and "projectId".');
        return;
      }
      saveCustomFirebaseConfig(parsed);
    } catch (err: any) {
      setErrorMessage('Invalid JSON format: ' + err.message);
    }
  };

  const handleCopyRules = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(FIRESTORE_RULES_SNIPPET);
      setRulesCopied(true);
      setTimeout(() => setRulesCopied(false), 2500);
    }
  };

  const handleGoogleAdminLogin = async () => {
    setAuthError('');
    setDeniedUid(null);
    setIsGoogleLoggingIn(true);
    try {
      const { user } = await signInAdminWithGoogle();
      setIsAdminAuthenticated(true);
      setAuthenticatedAdminEmail(user.email || 'Admin Officer');
      sessionStorage.setItem('india_job_hub_admin_session', 'active');
      if (user.email) sessionStorage.setItem('india_job_hub_admin_email', user.email);
      setAuthError('');
    } catch (err: any) {
      console.warn('Admin Google authentication notice:', err?.message || err);
      const msg = err?.message || 'Google sign-in failed. Please try again.';
      setAuthError(msg);
      // Extract UID if present in error message
      const match = msg.match(/UID "([^"]+)"/);
      if (match && match[1]) {
        setDeniedUid(match[1]);
      }
      setIsAdminAuthenticated(false);
      sessionStorage.removeItem('india_job_hub_admin_session');
      sessionStorage.removeItem('india_job_hub_admin_email');
    } finally {
      setIsGoogleLoggingIn(false);
    }
  };

  const handleEmailAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminEmail.trim() || !adminPassword) {
      setAuthError('Please enter both admin email and password.');
      return;
    }

    setAuthError('');
    setDeniedUid(null);
    setIsEmailLoggingIn(true);
    try {
      const { user } = await signInAdminWithEmailPassword(adminEmail, adminPassword);
      setIsAdminAuthenticated(true);
      setAuthenticatedAdminEmail(user.email || 'Admin Officer');
      sessionStorage.setItem('india_job_hub_admin_session', 'active');
      if (user.email) sessionStorage.setItem('india_job_hub_admin_email', user.email);
      setAuthError('');
    } catch (err: any) {
      console.warn('Admin Email authentication notice:', err?.message || err);
      const msg = err?.message || 'Email sign-in failed. Please try again.';
      setAuthError(msg);
      // Extract UID if present in error message
      const match = msg.match(/UID "([^"]+)"/);
      if (match && match[1]) {
        setDeniedUid(match[1]);
      }
      setIsAdminAuthenticated(false);
      sessionStorage.removeItem('india_job_hub_admin_session');
      sessionStorage.removeItem('india_job_hub_admin_email');
    } finally {
      setIsEmailLoggingIn(false);
    }
  };

  const handleAdminLogout = async () => {
    try {
      await adminSignOut();
    } catch (err) {
      console.warn('Sign out error:', err);
    }
    sessionStorage.removeItem('india_job_hub_admin_session');
    sessionStorage.removeItem('india_job_hub_admin_email');
    setIsAdminAuthenticated(false);
    setAuthenticatedAdminEmail('Admin Officer');
  };

  const handleToggleCategory = (cat: JobCategory) => {
    if (selectedCategories.includes(cat)) {
      if (selectedCategories.length > 1) {
        setSelectedCategories(selectedCategories.filter((c) => c !== cat));
      }
    } else {
      setSelectedCategories([...selectedCategories, cat]);
    }
  };

  const handlePdfFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingPdf(true);
    setPdfUploadSuccess('');
    try {
      const downloadUrl = await uploadOfficialNotificationPdf(file);
      setOfficialNotificationUrl(downloadUrl);
      setPdfUploadSuccess(`Notification document "${file.name}" uploaded successfully!`);
      setTimeout(() => setPdfUploadSuccess(''), 4000);
    } catch (err) {
      console.error(err);
      setErrorMessage('PDF upload failed, using fallback URL.');
    } finally {
      setUploadingPdf(false);
    }
  };

  const handleSaveJob = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !organization || !qualification || !salary) {
      setErrorMessage('Please fill in required fields: Title, Organization, Qualification, Salary');
      return;
    }

    const jobData: JobPosting = {
      id: editingJobId || `job-${Date.now()}`,
      title: title.trim(),
      organization: organization.trim(),
      sector,
      category: selectedCategories,
      state: selectedState,
      district: selectedDistrict || districtsForSelectedState[0] || 'Statewide',
      qualification: qualification.trim(),
      experience: experience.trim(),
      salary: salary.trim(),
      vacancies: Number(vacancies) || 1,
      openingDate,
      closingDate,
      expiryDate: closingDate, // Application deadline / expiry date
      lastDate: closingDate,
      postDate: new Date().toISOString().split('T')[0],
      officialApplicationLink: officialApplicationLink.trim() || 'https://india.gov.in',
      officialSource: officialSource.trim() || 'Official Gazette Announcement',
      sourceUrl: sourceUrl.trim() || undefined,
      officialNotificationUrl: officialNotificationUrl.trim() || officialApplicationLink.trim(),
      applicationFee: applicationFee.trim() || 'Refer to official notification',
      ageLimit: ageLimit.trim() || '18 to 35 Years',
      selectionProcess: selectionSteps.split(',').map((s) => s.trim()).filter(Boolean),
      requiredDocuments: requiredDocs.split(',').map((d) => d.trim()).filter(Boolean),
      description: description.trim() || `Official recruitment for ${title} under ${organization}.`,
      status,
      isFeatured,
      isUrgent,
      isLatest,
      lastVerifiedDate: new Date().toISOString().split('T')[0],
      demoDataBadge: false // Real production entry
    };

    try {
      if (editingJobId) {
        await updateJobInFirestore(editingJobId, jobData);
        setSuccessMessage(`Job "${title}" successfully updated in Cloud Firestore!`);
        setEditingJobId(null);
      } else {
        await addJobToFirestore(jobData);
        setSuccessMessage(`Job "${title}" successfully published to Cloud Firestore!`);
      }

      setTimeout(() => setSuccessMessage(''), 4000);
      resetForm();
      if (onRefreshJobs) onRefreshJobs();
    } catch (err: any) {
      console.error(err);
      setErrorMessage(getUserFriendlyErrorMessage(err, 'Failed to sync job with Firestore. Please check your network.'));
    }
  };

  const handleEditJob = (job: JobPosting) => {
    setEditingJobId(job.id);
    setTitle(job.title);
    setOrganization(job.organization);
    setSector(job.sector);
    setSelectedState(job.state);
    setSelectedDistrict(job.district);
    setSelectedCategories(job.category);
    setQualification(job.qualification);
    setExperience(job.experience || 'Freshers / 0-2 Years');
    setSalary(job.salary);
    setVacancies(job.vacancies);
    setOpeningDate(job.openingDate || '2026-09-01');
    setClosingDate(job.expiryDate || job.closingDate || job.lastDate || '');
    setOfficialApplicationLink(job.officialApplicationLink);
    setOfficialSource(job.officialSource);
    setSourceUrl(job.sourceUrl || '');
    setOfficialNotificationUrl(job.officialNotificationUrl || '');
    setApplicationFee(job.applicationFee);
    setAgeLimit(job.ageLimit);
    setDescription(job.description);
    setSelectionSteps((job.selectionProcess || []).join(', '));
    setRequiredDocs((job.requiredDocuments || []).join(', '));
    setStatus(job.status || 'PUBLISHED');
    setIsFeatured(Boolean(job.isFeatured));
    setIsUrgent(Boolean(job.isUrgent));
    setIsLatest(Boolean(job.isLatest));

    setActiveTab('create');
  };

  // Open confirmation dialog for single job deletion (Requirements 4, 5, 7)
  const handlePromptDeleteJob = (job: JobPosting) => {
    const expired = isJobExpired(job);
    setDeleteConfirm({
      isOpen: true,
      type: 'single',
      jobId: job.id,
      jobTitle: job.title,
      expiryDate: getJobExpiryDate(job),
      isExpired: expired
    });
  };

  const handleDeleteJob = (jobId: string, jobTitle: string) => {
    const matchedJob = jobs.find((j) => j.id === jobId);
    if (matchedJob) {
      handlePromptDeleteJob(matchedJob);
    } else {
      setDeleteConfirm({
        isOpen: true,
        type: 'single',
        jobId,
        jobTitle,
        expiryDate: null,
        isExpired: false
      });
    }
  };

  // Open confirmation dialog for all expired jobs deletion (Requirements 5, 6, 7)
  const handlePromptDeleteAllExpired = () => {
    const expired = jobs.filter(isJobExpired);
    if (expired.length === 0) {
      setErrorMessage('No expired jobs found in the database.');
      setTimeout(() => setErrorMessage(''), 3000);
      return;
    }
    setDeleteConfirm({
      isOpen: true,
      type: 'all_expired',
      count: expired.length
    });
  };

  // Execute confirmed deletion from Cloud Firestore
  const handleConfirmDelete = async () => {
    setIsDeleting(true);
    try {
      if (deleteConfirm.type === 'single' && deleteConfirm.jobId) {
        await deleteJobFromFirestore(deleteConfirm.jobId);
        setSuccessMessage(`Job "${deleteConfirm.jobTitle || 'Selected vacancy'}" deleted permanently from Cloud Firestore.`);
      } else if (deleteConfirm.type === 'all_expired') {
        const expiredIds = jobs.filter(isJobExpired).map((j) => j.id);
        const count = await deleteExpiredJobsFromFirestore(expiredIds);
        setSuccessMessage(`Successfully deleted all ${count} expired jobs from Cloud Firestore.`);
      }
      setTimeout(() => setSuccessMessage(''), 3500);
      setDeleteConfirm({ isOpen: false, type: 'single' });
      if (onRefreshJobs) onRefreshJobs();
    } catch (err: any) {
      console.error('Delete error:', err);
      setErrorMessage(getUserFriendlyErrorMessage(err, 'Failed to delete job(s) from Firestore.'));
      setTimeout(() => setErrorMessage(''), 5000);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleTogglePublish = async (job: JobPosting) => {
    const newStatus: JobStatus = job.status === 'PUBLISHED' ? 'DRAFT' : 'PUBLISHED';
    await updateJobInFirestore(job.id, { status: newStatus });
    setSuccessMessage(`Job "${job.title}" status changed to ${newStatus}.`);
    setTimeout(() => setSuccessMessage(''), 2500);
  };

  const handleQuickVerify = async (job: JobPosting) => {
    await updateJobInFirestore(job.id, {
      status: 'VERIFIED',
      lastVerifiedDate: new Date().toISOString().split('T')[0]
    });
    setSuccessMessage(`Job "${job.title}" marked as officially VERIFIED.`);
    setTimeout(() => setSuccessMessage(''), 2500);
  };

  const handleSeedJobs = async () => {
    if (!window.confirm('Seed authentic job postings directly into your live Firestore database?')) return;
    try {
      const count = await seedJobsToFirestore(jobs);
      setSuccessMessage(`Successfully synchronized ${count} live verified jobs to Cloud Firestore!`);
      setTimeout(() => setSuccessMessage(''), 4000);
      if (onRefreshJobs) onRefreshJobs();
    } catch (err: any) {
      console.error(err);
      setErrorMessage(getUserFriendlyErrorMessage(err, 'Failed to seed jobs into Firestore.'));
    }
  };

  const handleAddCustomDistrict = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDistrictName.trim()) return;

    setCustomDistricts((prev) => ({
      ...prev,
      [selectedState]: [...(prev[selectedState] || []), newDistrictName.trim()]
    }));
    setSelectedDistrict(newDistrictName.trim());
    setNewDistrictName('');
    setSuccessMessage(`District added to ${selectedState}.`);
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  const resetForm = () => {
    setEditingJobId(null);
    setTitle('');
    setOrganization('');
    setQualification('');
    setSalary('');
    setDescription('');
    setOfficialNotificationUrl('');
    setSourceUrl('');
    setStatus('PUBLISHED');
    setIsFeatured(false);
    setIsUrgent(false);
    setOpeningDate(new Date().toISOString().split('T')[0]);
    const defaultClosing = new Date();
    defaultClosing.setDate(defaultClosing.getDate() + 30);
    setClosingDate(defaultClosing.toISOString().split('T')[0]);
  };

  // Export JSON schema for Firebase Firestore
  const handleExportFirestoreJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(jobs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', 'india_job_hub_firestore_export.json');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Automatically evaluate expired vs active jobs against current date (Requirements 2, 3, 10)
  const expiredJobs = jobs.filter(isJobExpired);
  const activeJobs = jobs.filter((j) => !isJobExpired(j));

  // Filtered jobs for manage tab
  const filteredManageJobs = jobs.filter((j) => {
    const matchQ =
      !manageSearch ||
      j.title.toLowerCase().includes(manageSearch.toLowerCase()) ||
      j.organization.toLowerCase().includes(manageSearch.toLowerCase()) ||
      j.state.toLowerCase().includes(manageSearch.toLowerCase());

    if (!matchQ) return false;
    if (manageStatusFilter === 'ALL') return true;
    if (manageStatusFilter === 'EXPIRED') return isJobExpired(j);
    if (manageStatusFilter === 'ACTIVE') return !isJobExpired(j);
    return j.status === manageStatusFilter;
  });

  // Filtered jobs for dedicated Expired tab
  const filteredExpiredJobs = expiredJobs.filter((j) => {
    return (
      !manageSearch ||
      j.title.toLowerCase().includes(manageSearch.toLowerCase()) ||
      j.organization.toLowerCase().includes(manageSearch.toLowerCase()) ||
      j.state.toLowerCase().includes(manageSearch.toLowerCase())
    );
  });

  // If not authenticated, display Admin Login Gate
  if (!isAdminAuthenticated) {
    return (
      <div className="flex-1 flex items-center justify-center bg-slate-950 p-4 py-8">
        <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl space-y-5">
          <div className="text-center space-y-2">
            <img
              src="/india-job-hub-logo.png"
              alt="India Job Hub Logo"
              width={80}
              height={80}
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-contain bg-white p-1.5 border border-slate-700/60 shadow-xl mx-auto select-none"
              referrerPolicy="no-referrer"
            />
            <h1 className="text-xl font-bold text-white">India Job Hub Admin Portal</h1>
            <p className="text-xs text-slate-400">
              Firebase Google Authentication • Role-Based Access Control • Firestore
            </p>
          </div>

          {/* CLEAR DEBUG CHECK: FIREBASE PROJECT ID & AUTH CONFIGURATION VERIFICATION */}
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-3 text-xs">
            <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-800/80 pb-2.5">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-400" />
                <span className="font-bold text-slate-200">Firebase Project Verification (Debug Check)</span>
              </div>
              <span className="text-[11px] font-medium text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> Project Connected
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <div className="p-2.5 bg-slate-900/90 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400 block font-medium">App Firebase Project ID</span>
                <div className="flex items-center justify-between gap-1">
                  <code className="text-emerald-400 font-mono font-bold text-xs truncate" title={debugInfo.configuredProjectId}>
                    {debugInfo.configuredProjectId || 'None'}
                  </code>
                  <button
                    type="button"
                    onClick={handleCopyProjectId}
                    className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors shrink-0"
                    title="Copy Project ID"
                  >
                    {copiedProjectId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="p-2.5 bg-slate-900/90 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400 block font-medium">Auth Instance Project</span>
                <div className="flex items-center justify-between gap-1">
                  <code className="text-indigo-400 font-mono font-bold text-xs truncate" title={debugInfo.authInstanceProjectId}>
                    {debugInfo.authInstanceProjectId || 'None'}
                  </code>
                  {debugInfo.isProjectMatch ? (
                    <span className="text-[10px] text-emerald-400 font-bold shrink-0 flex items-center gap-0.5">
                      <CheckCircle className="w-3 h-3" /> Bound
                    </span>
                  ) : (
                    <span className="text-[10px] text-rose-400 font-bold shrink-0">Mismatch</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Authorization Criteria Notice */}
          <div className="p-3.5 bg-indigo-500/10 border border-indigo-500/25 rounded-2xl text-xs space-y-1.5">
            <div className="flex items-center gap-2 text-indigo-300 font-semibold">
              <ShieldCheck className="w-4 h-4 text-indigo-400 shrink-0" />
              <span>Administrative Authorization Requirements</span>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              Sign in with your Google account. Access to the Admin Management Hub is authorized only when your authenticated Firebase Auth UID exists in Firestore under <code className="px-1.5 py-0.5 rounded bg-slate-900 text-indigo-300 font-mono">admin_users/{'{UID}'}</code> with role <code className="px-1.5 py-0.5 rounded bg-slate-900 text-emerald-300 font-mono">"admin"</code> or <code className="px-1.5 py-0.5 rounded bg-slate-900 text-emerald-300 font-mono">"superadmin"</code>.
            </p>
          </div>

          {/* Error Message & Rejected UID Helper */}
          {authError && (
            <div className="p-3.5 bg-rose-500/20 border border-rose-500/40 rounded-2xl text-rose-200 text-xs space-y-2">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1 flex-1 break-words">
                  <span className="font-bold text-rose-300 block">Access Authorization Notice</span>
                  <p className="leading-relaxed text-slate-200 text-[11px]">{authError}</p>
                </div>
              </div>

              {deniedUid && (
                <div className="p-2.5 bg-slate-950/80 rounded-xl border border-rose-500/30 text-[11px] space-y-1.5 mt-2">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="font-medium">Authenticated User UID:</span>
                    <button
                      type="button"
                      onClick={handleCopyDeniedUid}
                      className="inline-flex items-center gap-1 text-[10px] text-indigo-300 hover:text-white px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 transition-colors"
                    >
                      {copiedUid ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedUid ? 'Copied UID' : 'Copy UID'}</span>
                    </button>
                  </div>
                  <code className="block p-1.5 bg-slate-900 text-amber-300 font-mono text-[10px] rounded border border-slate-800 break-all select-all">
                    {deniedUid}
                  </code>
                  <p className="text-[10px] text-slate-400 leading-tight">
                    To grant access, add a document <code className="text-slate-300 font-mono">admin_users/{deniedUid}</code> in Cloud Firestore with field <code className="text-emerald-300 font-mono">role: "admin"</code>.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Auth Method Selector Tabs */}
          <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => {
                setAdminAuthMethod('google');
                setAuthError('');
              }}
              className={`py-2 px-3 rounded-lg font-medium transition-all ${
                adminAuthMethod === 'google'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-850'
              }`}
            >
              Google Account
            </button>
            <button
              type="button"
              onClick={() => {
                setAdminAuthMethod('email');
                setAuthError('');
              }}
              className={`py-2 px-3 rounded-lg font-medium transition-all ${
                adminAuthMethod === 'email'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-850'
              }`}
            >
              Email & Password
            </button>
          </div>

          {/* Action: Google Sign-in */}
          {adminAuthMethod === 'google' && (
            <div className="space-y-3 pt-1">
              <button
                type="button"
                id="btn-admin-google-login"
                onClick={handleGoogleAdminLogin}
                disabled={isGoogleLoggingIn}
                className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs sm:text-sm flex items-center justify-center gap-3 shadow-xl shadow-white/5 hover:shadow-white/10 transition-all active:scale-[0.98] disabled:opacity-60 cursor-pointer"
              >
                {isGoogleLoggingIn ? (
                  <RefreshCw className="w-5 h-5 animate-spin text-indigo-600" />
                ) : (
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path fill="#EA4335" d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.4 9 5 12 5z"/>
                    <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.7-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.9z"/>
                    <path fill="#FBBC05" d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3 0-.8.1-1.6.4-2.3L1.9 7.3C.7 9.7 0 12.4 0 15.2c0 2.8.7 5.5 1.9 7.9l3.7-2.9c-.2-.7-.4-1.5-.4-2.3z"/>
                    <path fill="#34A853" d="M12 23.5c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2-6.4-4.8L1.9 16.9C3.7 20.9 7.5 23.5 12 23.5z"/>
                  </svg>
                )}
                <span>{isGoogleLoggingIn ? 'Verifying with Google...' : 'Sign in with Google Account'}</span>
              </button>
            </div>
          )}

          {/* Action: Email & Password Sign-in */}
          {adminAuthMethod === 'email' && (
            <form onSubmit={handleEmailAdminLogin} className="space-y-3 pt-1">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Admin Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    placeholder="admin@indiajobhub.gov.in"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>
              </div>

              <button
                type="submit"
                id="btn-admin-email-login"
                disabled={isEmailLoggingIn}
                className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition-all active:scale-[0.98] disabled:opacity-60 cursor-pointer"
              >
                {isEmailLoggingIn ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <LogIn className="w-4 h-4 text-white" />
                )}
                <span>{isEmailLoggingIn ? 'Authenticating Admin...' : 'Sign in with Email & Password'}</span>
              </button>
            </form>
          )}

          <div className="pt-2 border-t border-slate-800 text-center">
            <span className="text-[11px] text-slate-500">
              Secured with Firebase Authentication & Firestore Security Rules • Project: {debugInfo.configuredProjectId}
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-slate-950 p-3 sm:p-5 space-y-4">
      {/* Top Header & Admin Session Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-3">
          <img
            src="/india-job-hub-logo.png"
            alt="India Job Hub Logo"
            width={48}
            height={48}
            className="w-12 h-12 rounded-xl object-contain bg-white p-0.5 border border-slate-700/60 shrink-0 shadow-md select-none"
            referrerPolicy="no-referrer"
          />
          <div>
            <h1 className="text-base font-bold text-white flex items-center gap-2">
              <span>Admin Management Hub</span>
              {connectionStatus?.status === 'setup_required' ? (
                <span className="px-2.5 py-0.5 text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-full flex items-center gap-1.5 animate-pulse">
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                  Firebase Setup Required
                </span>
              ) : connectionStatus?.status === 'connected' ? (
                <span className="px-2.5 py-0.5 text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Firebase Connected ({connectionStatus.projectId})
                </span>
              ) : (
                <span className="px-2.5 py-0.5 text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700 rounded-full flex items-center gap-1.5">
                  <RefreshCw className="w-3 h-3 animate-spin text-slate-400" />
                  Verifying Firebase...
                </span>
              )}
            </h1>
            <p className="text-xs text-slate-400">
              Authenticated as: <strong className="text-slate-300">{authenticatedAdminEmail}</strong>
            </p>
          </div>
        </div>

        {/* Tab switchers and Logout */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => {
                setActiveTab('create');
                if (!editingJobId) resetForm();
              }}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'create'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {editingJobId ? 'Edit Vacancy' : 'Add Vacancy'}
            </button>
            <button
              onClick={() => setActiveTab('manage')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'manage'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Jobs ({jobs.length})
            </button>
            <button
              onClick={() => setActiveTab('expired')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
                activeTab === 'expired'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Expired Jobs</span>
              {expiredJobs.length > 0 && (
                <span
                  className={`ml-0.5 px-1.5 py-0.2 text-[9px] font-bold rounded-full ${
                    activeTab === 'expired'
                      ? 'bg-white text-rose-700'
                      : 'bg-rose-500/30 text-rose-300 border border-rose-500/40'
                  }`}
                >
                  {expiredJobs.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('reports')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all relative ${
                activeTab === 'reports'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>User Reports</span>
              {reports.filter((r) => r.status === 'PENDING').length > 0 && (
                <span className="ml-1 px-1.5 py-0.2 bg-rose-500 text-white text-[9px] font-bold rounded-full">
                  {reports.filter((r) => r.status === 'PENDING').length}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('locations')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'locations'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Locations
            </button>
            <button
              onClick={() => setActiveTab('firebase')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
                activeTab === 'firebase'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>Firebase & DB</span>
              {connectionStatus?.status === 'setup_required' && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              )}
            </button>
          </div>

          <button
            onClick={handleAdminLogout}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white text-xs transition-colors"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Real-time Statistics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="text-[11px] font-medium text-slate-400">Total Postings</div>
          <div className="text-xl font-bold text-white mt-0.5">{jobs.length}</div>
        </div>
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="text-[11px] font-medium text-emerald-400">Active Vacancies</div>
          <div className="text-xl font-bold text-emerald-300 mt-0.5">{activeJobs.length}</div>
        </div>
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="text-[11px] font-medium text-rose-400">Expired Vacancies</div>
          <div className="text-xl font-bold text-rose-300 mt-0.5">{expiredJobs.length}</div>
        </div>
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="text-[11px] font-medium text-indigo-400">Applications</div>
          <div className="text-xl font-bold text-indigo-300 mt-0.5">
            {jobs.reduce((sum, j) => sum + (j.applicationsCount || 0), 0).toLocaleString()}
          </div>
        </div>
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-2xl col-span-2 sm:col-span-1">
          <div className="text-[11px] font-medium text-amber-400">Total Views</div>
          <div className="text-xl font-bold text-amber-300 mt-0.5">
            {jobs.reduce((sum, j) => sum + (j.viewsCount || 0), 0).toLocaleString()}
          </div>
        </div>
      </div>

      {/* Prominent Firebase Setup Required Banner */}
      {connectionStatus?.status === 'setup_required' && (
        <div
          id="banner-firebase-setup-required"
          className="bg-gradient-to-r from-amber-950/40 to-slate-900 border border-amber-500/40 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl"
        >
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <strong className="text-amber-300 font-bold text-sm sm:text-base">
                  Firebase Setup Required
                </strong>
                <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold rounded-full">
                  Action Needed
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                {connectionStatus.details ||
                  'Cloud Firestore database is waiting for configuration or manual project creation. The app is safely caching vacancies in memory. Follow the step-by-step setup guide to connect your live Firebase project.'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
            <button
              onClick={handleTestConnection}
              disabled={isTestingConnection}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-xs flex items-center gap-1.5 border border-slate-700 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTestingConnection ? 'animate-spin text-amber-400' : ''}`} />
              <span>{isTestingConnection ? 'Testing...' : 'Test Connection'}</span>
            </button>
            <button
              onClick={() => setActiveTab('firebase')}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md shadow-amber-500/20 active:scale-95"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Manual Setup Guide</span>
            </button>
          </div>
        </div>
      )}

      {/* Toast Messages */}
      {successMessage && (
        <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}
      {errorMessage && (
        <div className="p-3 bg-rose-500/20 border border-rose-500/40 rounded-xl text-rose-300 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* TAB 1: CREATE / EDIT VACANCY */}
      {activeTab === 'create' && (
        <form onSubmit={handleSaveJob} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-indigo-400" />
                <span>{editingJobId ? `Editing: ${title}` : 'Publish New Official Vacancy'}</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Saved directly to Cloud Firestore with live sync to all candidate devices
              </p>
            </div>

            {editingJobId && (
              <button
                type="button"
                onClick={resetForm}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
              >
                Cancel Edit
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Title */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Job Title *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Probationary Officer / Junior Engineer (Civil)"
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Organization */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Organization / Commission *
              </label>
              <input
                type="text"
                value={organization}
                onChange={(e) => setOrganization(e.target.value)}
                placeholder="e.g. State Bank of India / RRB / DRDO / BHEL"
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Sector */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Sector *
              </label>
              <select
                value={sector}
                onChange={(e) => setSector(e.target.value as JobSector)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="Government">Government Sector (Central / State / PSU)</option>
                <option value="Private">Private Sector (Corporate / MNC / Startup)</option>
              </select>
            </div>

            {/* Status */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Publication Status *
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as JobStatus)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 font-semibold"
              >
                {ALL_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s} {s === 'PUBLISHED' ? '(Visible to Citizens)' : '(Internal / Unlisted)'}
                  </option>
                ))}
              </select>
            </div>

            {/* State */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                State / UT *
              </label>
              <select
                value={selectedState}
                onChange={(e) => {
                  setSelectedState(e.target.value);
                  const firstDistrict = getDistrictsByState(e.target.value)[0] || '';
                  setSelectedDistrict(firstDistrict);
                }}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                {INDIA_STATES_AND_UTS.map((state) => (
                  <option key={state.code} value={state.name}>
                    {state.name} {state.isUT ? '(UT)' : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* District */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                District in {selectedState} *
              </label>
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                {districtsForSelectedState.map((district) => (
                  <option key={district} value={district}>
                    {district}
                  </option>
                ))}
              </select>
            </div>

            {/* Qualification */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Educational Qualification *
              </label>
              <input
                type="text"
                value={qualification}
                onChange={(e) => setQualification(e.target.value)}
                placeholder="e.g. 10th + ITI in Fitter / Diploma / Graduate in any discipline"
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Experience */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Experience Requirement
              </label>
              <input
                type="text"
                value={experience}
                onChange={(e) => setExperience(e.target.value)}
                placeholder="e.g. Freshers eligible / 0 to 2 Years / 3+ Years"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Salary */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Salary / Pay Scale *
              </label>
              <input
                type="text"
                value={salary}
                onChange={(e) => setSalary(e.target.value)}
                placeholder="e.g. ₹35,400 - ₹1,12,400 (Level 6 7th CPC) / ₹6.5 LPA"
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Vacancies */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Total Vacancies Count *
              </label>
              <input
                type="number"
                value={vacancies}
                onChange={(e) => setVacancies(Number(e.target.value))}
                min={1}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Opening Date */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Opening Date (Start Application)
              </label>
              <input
                type="date"
                value={openingDate}
                onChange={(e) => setOpeningDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Application Deadline / Expiry Date */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1 flex items-center justify-between">
                <span>Application Deadline / Expiry Date *</span>
                {closingDate && (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      closingDate < new Date().toISOString().split('T')[0]
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    }`}
                  >
                    {closingDate < new Date().toISOString().split('T')[0]
                      ? '⚠️ Past Date (Will be marked Expired)'
                      : '✓ Active Deadline'}
                  </span>
                )}
              </label>
              <input
                type="date"
                value={closingDate}
                onChange={(e) => setClosingDate(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">
                Last date to apply. Used to automatically evaluate whether the vacancy is active or expired.
              </span>
            </div>

            {/* Official Application Link */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Official Application URL *
              </label>
              <input
                type="url"
                value={officialApplicationLink}
                onChange={(e) => setOfficialApplicationLink(e.target.value)}
                placeholder="https://..."
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Official Source URL */}
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Source URL / Gazette Reference
              </label>
              <input
                type="url"
                value={sourceUrl}
                onChange={(e) => setSourceUrl(e.target.value)}
                placeholder="https://employmentnews.gov.in/..."
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* PDF Upload for Official Notification */}
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2 text-xs">
            <label className="block font-semibold text-slate-300 flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-indigo-400" />
              <span>Official Notification Document / PDF</span>
            </label>
            <div className="flex items-center gap-3">
              <input
                type="file"
                accept="application/pdf,image/*"
                onChange={handlePdfFileSelect}
                className="text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-500 cursor-pointer"
              />
              {uploadingPdf && <span className="text-amber-400 animate-pulse">Uploading to Storage...</span>}
              {pdfUploadSuccess && <span className="text-emerald-400">{pdfUploadSuccess}</span>}
            </div>
            {officialNotificationUrl && (
              <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px] truncate">
                <span>Active Doc URL:</span>
                <span className="text-indigo-300 underline truncate">{officialNotificationUrl}</span>
              </div>
            )}
          </div>

          {/* Categories Multi-Select */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Categories (Multi-Select) *
            </label>
            <div className="flex flex-wrap gap-1.5">
              {ALL_AVAILABLE_CATEGORIES.map((cat) => {
                const isSelected = selectedCategories.includes(cat);
                return (
                  <button
                    type="button"
                    key={cat}
                    onClick={() => handleToggleCategory(cat)}
                    className={`px-2.5 py-1 rounded-xl text-xs font-medium border transition-all ${
                      isSelected
                        ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {isSelected ? '✓ ' : '+ '}
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Flags: Featured, Urgent, Latest */}
          <div className="flex items-center gap-4 flex-wrap text-xs">
            <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={isFeatured}
                onChange={(e) => setIsFeatured(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 focus:ring-0 bg-slate-950 border-slate-700"
              />
              <span className="flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Featured Post
              </span>
            </label>

            <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={isUrgent}
                onChange={(e) => setIsUrgent(e.target.checked)}
                className="w-4 h-4 rounded text-rose-600 focus:ring-0 bg-slate-950 border-slate-700"
              />
              <span className="flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-rose-400" /> Mark as Urgent
              </span>
            </label>

            <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={isLatest}
                onChange={(e) => setIsLatest(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-600 focus:ring-0 bg-slate-950 border-slate-700"
              />
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Latest Notification
              </span>
            </label>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Job Description & Duties
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              placeholder="Detailed recruitment briefing, job responsibilities, post matrix..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Required Documents */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Required Documents (comma separated)
            </label>
            <input
              type="text"
              value={requiredDocs}
              onChange={(e) => setRequiredDocs(e.target.value)}
              placeholder="Aadhaar Card, 10th Board Certificate, Degree Marksheet..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Selection Process */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Selection Procedure Steps (comma separated)
            </label>
            <input
              type="text"
              value={selectionSteps}
              onChange={(e) => setSelectionSteps(e.target.value)}
              placeholder="CBT 1, CBT 2, Document Verification, Medical Test"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <button
            type="submit"
            id="btn-publish-job-admin"
            className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all active:scale-[0.99]"
          >
            {editingJobId ? 'Update Vacancy in Firestore' : 'Publish Vacancy to Cloud Firestore'}
          </button>
        </form>
      )}

      {/* TAB 2: MANAGE ALL JOBS */}
      {activeTab === 'manage' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h2 className="text-sm font-bold text-white">All Vacancy Records</h2>
              <p className="text-xs text-slate-400">
                {jobs.length} total vacancies registered • Showing {filteredManageJobs.length}
                {expiredJobs.length > 0 && (
                  <span className="ml-2 text-rose-400 font-semibold">
                    ({expiredJobs.length} expired)
                  </span>
                )}
              </p>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2 flex-wrap">
              {expiredJobs.length > 0 && (
                <button
                  onClick={handlePromptDeleteAllExpired}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all"
                  title="Permanently delete all jobs whose deadline has passed"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete All Expired ({expiredJobs.length})</span>
                </button>
              )}
              <button
                onClick={handleSeedJobs}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-sm transition-all"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Sync Verified Jobs to Firestore</span>
              </button>
            </div>
          </div>

          {/* Filters Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={manageSearch}
                onChange={(e) => setManageSearch(e.target.value)}
                placeholder="Search by title, organization, or state..."
                className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <select
              value={manageStatusFilter}
              onChange={(e) => setManageStatusFilter(e.target.value)}
              className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">All Deadlines & Statuses ({jobs.length})</option>
              <option value="ACTIVE">✓ Active Deadlines Only ({activeJobs.length})</option>
              <option value="EXPIRED">⚠️ Expired Deadlines Only ({expiredJobs.length})</option>
              {ALL_STATUSES.map((s) => (
                <option key={s} value={s}>
                  Status: {s}
                </option>
              ))}
            </select>
          </div>

          {/* Jobs Table/List */}
          <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
            {filteredManageJobs.length === 0 ? (
              <div className="p-8 text-center bg-slate-950/50 rounded-xl border border-slate-800">
                <p className="text-sm text-slate-400">No vacancy records match your search or filter.</p>
              </div>
            ) : (
              filteredManageJobs.map((job) => {
                const expired = isJobExpired(job);
                const expiry = getJobExpiryDate(job);
                return (
                  <div
                    key={job.id}
                    className={`p-3 bg-slate-950 border rounded-xl flex items-center justify-between gap-3 text-xs transition-colors ${
                      expired ? 'border-rose-900/40 hover:border-rose-700/60' : 'border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-white truncate">{job.title}</span>
                        {expired ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1">
                            <Clock className="w-3 h-3" /> Expired
                          </span>
                        ) : (
                          <span
                            className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                              job.status === 'PUBLISHED'
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                : job.status === 'VERIFIED'
                                ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                                : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            }`}
                          >
                            {job.status}
                          </span>
                        )}
                        {job.isFeatured && (
                          <span className="px-1.5 py-0.2 bg-amber-500/20 text-amber-300 text-[10px] font-bold rounded">
                            ★ Featured
                          </span>
                        )}
                        {job.isUrgent && (
                          <span className="px-1.5 py-0.2 bg-rose-500/20 text-rose-300 text-[10px] font-bold rounded">
                            Urgent
                          </span>
                        )}
                      </div>
                      <p className="text-slate-400 text-[11px] truncate mt-0.5">
                        {job.organization} • {job.district}, {job.state} • {job.vacancies} Posts •{' '}
                        <span className={expired ? 'text-rose-400 font-semibold' : 'text-slate-300'}>
                          Deadline: {expiry || 'Not specified'}{expired ? ' (Expired)' : ''}
                        </span>
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* Quick Verify */}
                      {!expired && job.status !== 'VERIFIED' && (
                        <button
                          onClick={() => handleQuickVerify(job)}
                          className="px-2 py-1 bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/30 rounded-lg text-[10px] font-bold transition-colors"
                          title="Verify Job"
                        >
                          Verify
                        </button>
                      )}

                      {/* Toggle Publish / Unpublish */}
                      {!expired && (
                        <button
                          onClick={() => handleTogglePublish(job)}
                          className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                          title={job.status === 'PUBLISHED' ? 'Unpublish (Draft)' : 'Publish Job'}
                        >
                          {job.status === 'PUBLISHED' ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      )}

                      {/* Edit */}
                      <button
                        onClick={() => handleEditJob(job)}
                        className="p-1.5 text-indigo-400 hover:bg-indigo-500/20 rounded-lg transition-colors"
                        title={expired ? 'Edit / Extend Deadline' : 'Edit Job'}
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>

                      {/* Delete Button (prominent for expired jobs) */}
                      {expired ? (
                        <button
                          onClick={() => handlePromptDeleteJob(job)}
                          className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 shadow-sm transition-colors"
                          title="Permanently delete this expired job"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handlePromptDeleteJob(job)}
                          className="p-1.5 text-rose-400 hover:bg-rose-500/20 rounded-lg transition-colors"
                          title="Delete Job"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* TAB 3: DEDICATED EXPIRED JOBS MANAGEMENT */}
      {activeTab === 'expired' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-rose-400" />
                <span>Expired Vacancy Management</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Automatically determined by comparing application deadline against today ({new Date().toISOString().split('T')[0]}). Expired jobs are not auto-deleted.
              </p>
            </div>

            {/* Delete All Expired Button (Requirement 6 & 7) */}
            <div className="flex items-center gap-2">
              <button
                onClick={handlePromptDeleteAllExpired}
                disabled={expiredJobs.length === 0}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                  expiredJobs.length > 0
                    ? 'bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white shadow-rose-600/30'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                }`}
                title="Permanently delete all expired jobs from Firestore"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete All Expired Jobs ({expiredJobs.length})</span>
              </button>
            </div>
          </div>

          {/* Search within Expired */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={manageSearch}
              onChange={(e) => setManageSearch(e.target.value)}
              placeholder="Search expired vacancies by title, organization, or state..."
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-rose-500"
            />
          </div>

          {/* Expired Jobs List */}
          <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
            {filteredExpiredJobs.length === 0 ? (
              <div className="p-8 text-center bg-slate-950/60 rounded-xl border border-slate-800/80 space-y-2">
                <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-semibold text-white">No Expired Vacancies Found</h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  {expiredJobs.length === 0
                    ? 'All registered job postings currently have active deadlines. Once a deadline passes, the job will appear here for manual review and deletion.'
                    : 'No expired jobs match your current search criteria.'}
                </p>
              </div>
            ) : (
              filteredExpiredJobs.map((job) => {
                const expiry = getJobExpiryDate(job);
                return (
                  <div
                    key={job.id}
                    className="p-3.5 bg-slate-950 border border-rose-900/40 hover:border-rose-700/60 rounded-xl flex items-center justify-between gap-3 text-xs transition-all"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-white truncate">{job.title}</span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> Expired
                        </span>
                        <span className="text-slate-400 text-[10px] bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                          {job.sector}
                        </span>
                      </div>
                      <p className="text-slate-400 text-[11px] truncate mt-1">
                        {job.organization} • {job.district}, {job.state} • {job.vacancies} Posts
                      </p>
                      <p className="text-rose-400 text-[11px] font-semibold mt-0.5 flex items-center gap-1.5">
                        <Calendar className="w-3 h-3 text-rose-400" />
                        <span>Deadline passed: {expiry || 'Date not specified'}</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {/* Edit / Extend Deadline */}
                      <button
                        onClick={() => handleEditJob(job)}
                        className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors border border-slate-700"
                        title="Edit job to extend deadline"
                      >
                        <Edit3 className="w-3.5 h-3.5 text-indigo-400" />
                        <span className="hidden sm:inline">Extend</span>
                      </button>

                      {/* Delete Single Expired Job (Requirement 4 & 5) */}
                      <button
                        onClick={() => handlePromptDeleteJob(job)}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors"
                        title="Permanently delete from Firestore"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* TAB 3: USER REPORTS */}
      {activeTab === 'reports' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <span>Citizen Reports & Verification Queue</span>
              </h2>
              <p className="text-xs text-slate-400">
                Reports submitted by users regarding fake jobs, scams, or wrong info
              </p>
            </div>
            <span className="px-2.5 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold">
              {reports.length} Reports
            </span>
          </div>

          <div className="space-y-2.5 max-h-[60vh] overflow-y-auto pr-1">
            {reports.length > 0 ? (
              reports.map((report) => (
                <div
                  key={report.id}
                  className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl text-xs space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                        {report.reason}
                      </span>
                      <h3 className="font-bold text-white mt-1">{report.jobTitle}</h3>
                      <p className="text-slate-400 text-[11px]">{report.organization}</p>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        report.status === 'PENDING'
                          ? 'bg-amber-500/20 text-amber-300'
                          : report.status === 'RESOLVED'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {report.status}
                    </span>
                  </div>

                  {report.details && (
                    <p className="p-2 bg-slate-900 rounded-lg text-slate-300 text-[11px]">
                      "{report.details}"
                    </p>
                  )}

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-900">
                    <span>Reported on: {new Date(report.createdAt).toLocaleString()}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateReportStatusInFirestore(report.id, 'RESOLVED')}
                        className="px-2 py-1 bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/30 rounded text-[10px] font-semibold"
                      >
                        Mark Resolved
                      </button>
                      <button
                        onClick={() => updateReportStatusInFirestore(report.id, 'DISMISSED')}
                        className="px-2 py-1 bg-slate-800 text-slate-400 hover:text-white rounded text-[10px]"
                      >
                        Dismiss
                      </button>
                      <button
                        onClick={() => handleDeleteJob(report.jobId, report.jobTitle)}
                        className="px-2 py-1 bg-rose-600/20 text-rose-300 hover:bg-rose-600/30 rounded text-[10px] font-semibold"
                      >
                        Delete Job
                      </button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-slate-400 text-xs">
                No active user reports filed. All postings currently clean.
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: STATE & DISTRICT MANAGEMENT */}
      {activeTab === 'locations' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-indigo-400" />
              <span>State & District Registry Management</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Easily update or expand districts across all 28 Indian States & 8 Union Territories
            </p>
          </div>

          <form onSubmit={handleAddCustomDistrict} className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 flex flex-wrap gap-2 text-xs">
            <div className="flex-1 min-w-[180px]">
              <label className="block text-slate-400 mb-1">Select State</label>
              <select
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
              >
                {INDIA_STATES_AND_UTS.map((s) => (
                  <option key={s.code} value={s.name}>
                    {s.name} {s.isUT ? '(UT)' : ''}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex-1 min-w-[180px]">
              <label className="block text-slate-400 mb-1">New District Name to Add</label>
              <input
                type="text"
                value={newDistrictName}
                onChange={(e) => setNewDistrictName(e.target.value)}
                placeholder="e.g. New Industrial Zone / District"
                className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500"
              />
            </div>

            <div className="flex items-end">
              <button
                type="submit"
                className="py-2 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl"
              >
                + Add District
              </button>
            </div>
          </form>

          {/* Current districts list */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-300">
              Registered Districts in {selectedState} ({districtsForSelectedState.length}):
            </h3>
            <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto p-2 bg-slate-950 rounded-xl border border-slate-800">
              {districtsForSelectedState.map((dist) => (
                <span key={dist} className="px-2 py-1 bg-slate-900 border border-slate-800 text-slate-300 text-xs rounded-lg">
                  {dist}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: FIREBASE SCHEMA, DIAGNOSTICS & MANUAL SETUP GUIDE */}
      {activeTab === 'firebase' && (
        <div className="space-y-4">
          {/* Main Controls Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <Database className="w-4 h-4 text-amber-400" />
                    <span>Cloud Firestore & Firebase Integration Center</span>
                  </h2>
                  {connectionStatus?.status === 'setup_required' ? (
                    <span className="px-2.5 py-0.5 text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-full flex items-center gap-1 animate-pulse">
                      <AlertTriangle className="w-3 h-3 text-amber-400" />
                      Firebase Setup Required
                    </span>
                  ) : connectionStatus?.status === 'connected' ? (
                    <span className="px-2.5 py-0.5 text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full flex items-center gap-1">
                      <CheckCircle className="w-3 h-3 text-emerald-400" />
                      Connected & Ready
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700 rounded-full flex items-center gap-1">
                      <RefreshCw className="w-3 h-3 animate-spin text-slate-400" />
                      Checking Connection...
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Cloud Firestore, Firebase Authentication, Storage, Cloud Messaging & App Check
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={handleTestConnection}
                  disabled={isTestingConnection}
                  className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 border border-slate-700"
                >
                  <RefreshCw className={`w-4 h-4 ${isTestingConnection ? 'animate-spin text-amber-400' : 'text-slate-300'}`} />
                  <span>{isTestingConnection ? 'Testing...' : 'Test Connection'}</span>
                </button>

                <button
                  onClick={handleSeedJobs}
                  className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
                >
                  <Database className="w-4 h-4" />
                  <span>Seed Jobs to Firestore</span>
                </button>

                <button
                  onClick={handleExportFirestoreJSON}
                  className="flex items-center gap-1.5 px-3 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>Export JSON</span>
                </button>
              </div>
            </div>

            {/* Connection Diagnostics Details */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-2">
              <div className="flex items-start justify-between gap-2 flex-wrap">
                <span className="font-bold text-slate-300 flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-indigo-400" />
                  Connection Diagnostic Status:
                </span>
                <span className="text-slate-500 text-[11px]">
                  Last checked: {connectionStatus?.timestamp || 'Just now'}
                </span>
              </div>

              <p className={`text-xs ${connectionStatus?.status === 'setup_required' ? 'text-amber-300' : 'text-emerald-300'}`}>
                {connectionStatus?.message || 'Analyzing project connection...'}
              </p>

              {connectionStatus?.details && (
                <p className="text-[11px] text-slate-400 bg-slate-900 p-2.5 rounded-lg border border-slate-800 leading-relaxed font-mono">
                  {connectionStatus.details}
                </p>
              )}
            </div>

            {/* Current Project Configuration Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <span className="font-bold text-slate-400 block text-[11px]">Project ID</span>
                <span className="text-indigo-400 font-mono text-xs truncate block" title={activeFirebaseConfig.projectId}>
                  {activeFirebaseConfig.projectId || 'None'}
                </span>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-400 block text-[11px]">Database ID</span>
                  <button
                    onClick={handleToggleDatabaseId}
                    className="text-[10px] text-amber-400 hover:underline"
                    title="Toggle between (default) and custom database ID"
                  >
                    Switch ID
                  </button>
                </div>
                <span className="text-indigo-400 font-mono text-xs truncate block" title={activeFirebaseConfig.firestoreDatabaseId || '(default)'}>
                  {activeFirebaseConfig.firestoreDatabaseId || '(default)'}
                </span>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <span className="font-bold text-slate-400 block text-[11px]">Auth Domain</span>
                <span className="text-indigo-400 font-mono text-xs truncate block" title={activeFirebaseConfig.authDomain}>
                  {activeFirebaseConfig.authDomain || 'None'}
                </span>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <span className="font-bold text-slate-400 block text-[11px]">Storage Bucket</span>
                <span className="text-indigo-400 font-mono text-xs truncate block" title={activeFirebaseConfig.storageBucket}>
                  {activeFirebaseConfig.storageBucket || 'None'}
                </span>
              </div>
            </div>
          </div>

          {/* MANUAL FIREBASE SETUP STEPS */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
            <div className="flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-amber-400" />
              <h3 className="text-sm font-bold text-white">
                Step-by-Step Manual Firebase Setup Guide
              </h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              If the automated provisioning button cannot connect from this sandbox, follow these 5 standard steps to connect your Firebase project directly:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
                <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-bold rounded text-[10px]">
                  Step 1: Create or Open Project
                </span>
                <h4 className="font-bold text-white">Create Firebase Project</h4>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Go to <a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" className="text-indigo-400 hover:underline inline-flex items-center gap-1">console.firebase.google.com <ExternalLink className="w-3 h-3" /></a>, click <strong>"Add project"</strong>, and name it (e.g. <code>india-job-hub</code>).
                </p>
              </div>

              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
                <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-bold rounded text-[10px]">
                  Step 2: Enable Authentication
                </span>
                <h4 className="font-bold text-white">Activate Sign-In Providers</h4>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Navigate to <strong>Build &gt; Authentication</strong>. Under <strong>Sign-in method</strong>, enable <strong>Email/Password</strong> and <strong>Google</strong>.
                </p>
              </div>

              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
                <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-bold rounded text-[10px]">
                  Step 3: Create Firestore Database
                </span>
                <h4 className="font-bold text-white">Initialize Cloud Firestore</h4>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Go to <strong>Build &gt; Firestore Database</strong>. Click <strong>"Create database"</strong>, select <strong>Production mode</strong>, and choose a region (e.g., <code>asia-south1</code> for Mumbai or <code>nam5</code>). Leave Database ID as <strong>(default)</strong>.
                </p>
              </div>

              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
                <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-bold rounded text-[10px]">
                  Step 4: Publish Security Rules
                </span>
                <h4 className="font-bold text-white">Paste Security Rules</h4>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  In Firestore, open the <strong>Rules</strong> tab, paste the rules provided below, and click <strong>Publish</strong>.
                </p>
              </div>
            </div>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs">
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-bold rounded text-[10px]">
                Step 5: Register Web App & Connect
              </span>
              <h4 className="font-bold text-white">Copy Web Credentials</h4>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                In <strong>Project Settings &gt; General &gt; Your apps</strong>, click the Web icon <code>&lt;/&gt;</code>, register your app, and copy the <code>firebaseConfig</code> object. Paste it below into the credentials editor and click <strong>"Save &amp; Apply Credentials"</strong>.
              </p>
            </div>
          </div>

          {/* PROJECT CREDENTIALS & CONFIGURATION EDITOR */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Settings className="w-4 h-4 text-indigo-400" />
                  <span>Custom Firebase Project Credentials</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Paste your Firebase web configuration JSON directly to connect your project without rebuilding
                </p>
              </div>

              <button
                onClick={() => setShowCustomConfigForm(!showCustomConfigForm)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-xl font-medium transition-colors"
              >
                {showCustomConfigForm ? 'Hide Editor' : 'Open Config Editor'}
              </button>
            </div>

            {showCustomConfigForm && (
              <form onSubmit={handleSaveCustomJson} className="space-y-3 pt-2">
                <textarea
                  rows={6}
                  value={customConfigInput}
                  onChange={(e) => setCustomConfigInput(e.target.value)}
                  placeholder={`{\n  "apiKey": "AIzaSy...",\n  "authDomain": "your-project.firebaseapp.com",\n  "projectId": "your-project-id",\n  "storageBucket": "your-project.appspot.com",\n  "messagingSenderId": "123456789",\n  "appId": "1:123456789:web:abcdef"\n}`}
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-indigo-300 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
                  >
                    Save &amp; Connect Firebase
                  </button>

                  <button
                    type="button"
                    onClick={resetFirebaseConfig}
                    className="px-3.5 py-2 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 font-semibold text-xs rounded-xl transition-colors"
                  >
                    Reset to Default Config
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* FIRESTORE RULES SNIPPET */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Production Firestore Security Rules (firestore.rules)</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Zero-trust security rules protecting jobs, reports, and administrative operations
                </p>
              </div>

              <button
                onClick={handleCopyRules}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-xl font-medium transition-colors border border-slate-700"
              >
                {rulesCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300 font-bold">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Rules</span>
                  </>
                )}
              </button>
            </div>

            <pre className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto max-h-60">
              {FIRESTORE_RULES_SNIPPET}
            </pre>
          </div>

          {/* Firestore Collections Blueprint */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Scalable Cloud Firestore Collection Schemas</span>
            </h3>
            <pre className="text-slate-300 text-xs font-mono p-3 bg-slate-950 rounded-xl border border-slate-800 whitespace-pre-wrap leading-relaxed">
{`1. /jobs/{jobId}               -> Official Vacancy documents (status: PUBLISHED | DRAFT | VERIFIED)
2. /users/{uid}                -> Citizen profiles & FCM notification tokens
3. /saved_jobs/{userId_jobId}  -> Bookmarked vacancies per user
4. /reports/{reportId}         -> User-reported fake jobs/scams for admin triage
5. /alerts/{userId}            -> Personalized alert preferences (State, District, Category)
6. /admin_users/{uid}          -> Authenticated role verification`}
            </pre>
          </div>
        </div>
      )}

      {/* CONFIRMATION DIALOG MODAL (Requirements 4, 5, 6, 7) */}
      {deleteConfirm.isOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
        >
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {deleteConfirm.type === 'all_expired'
                      ? 'Delete All Expired Vacancies?'
                      : 'Confirm Permanent Deletion'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {deleteConfirm.type === 'all_expired'
                      ? 'Bulk deletion of expired vacancies'
                      : 'Irreversible Firestore operation'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => !isDeleting && setDeleteConfirm({ isOpen: false, type: 'single' })}
                disabled={isDeleting}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
                title="Cancel and close dialog"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            {deleteConfirm.type === 'all_expired' ? (
              <div className="space-y-2 text-xs text-slate-300 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
                <p>
                  You are about to permanently delete{' '}
                  <strong className="text-rose-400 font-bold">{deleteConfirm.count} expired vacancies</strong> from the
                  Firestore <code className="text-indigo-300 font-mono">jobs</code> collection.
                </p>
                <p className="text-[11px] text-slate-400">
                  • Only jobs whose application deadline is in the past (&lt; {new Date().toISOString().split('T')[0]}) will be deleted.
                </p>
                <p className="text-[11px] text-slate-400">
                  • All active vacancies and reports will remain completely safe.
                </p>
                <p className="text-[11px] text-rose-300 font-semibold pt-1">
                  ⚠️ This action cannot be undone. Are you sure you want to proceed?
                </p>
              </div>
            ) : (
              <div className="space-y-2 text-xs text-slate-300 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
                <p>Are you sure you want to permanently delete this job from Firestore?</p>
                <div className="bg-slate-900/90 p-2.5 rounded-lg border border-slate-800 space-y-1">
                  <div className="font-bold text-white truncate">{deleteConfirm.jobTitle}</div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 flex-wrap">
                    <span>Deadline: {deleteConfirm.expiryDate || 'Not specified'}</span>
                    {deleteConfirm.isExpired && (
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                        Expired
                      </span>
                    )}
                  </div>
                </div>
                <p className="text-[11px] text-slate-400">
                  This will remove the vacancy document permanently from the live database.
                </p>
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirm({ isOpen: false, type: 'single' })}
                disabled={isDeleting}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-md shadow-rose-600/30 transition-all disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>
                      {deleteConfirm.type === 'all_expired'
                        ? `Delete All (${deleteConfirm.count}) Expired Jobs`
                        : 'Delete Permanently'}
                    </span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
