import React, { useState } from 'react';
import { Quiz, SUBJECTS_DATA } from '../types';
import {
  ShieldCheck,
  Plus,
  Trash2,
  Sparkles,
  Search,
  BookOpen,
  Calendar,
  Layers,
  HelpCircle,
  Play,
  ArrowRight,
  Database
} from 'lucide-react';

interface AdminPanelProps {
  quizzes: Quiz[];
  onOpenCreateQuiz: () => void;
  onDeleteQuiz: (id: string) => Promise<void>;
  onStartQuiz: (quiz: Quiz) => void;
  apiConnected: boolean;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  quizzes,
  onOpenCreateQuiz,
  onDeleteQuiz,
  onStartQuiz,
  apiConnected,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSubject, setFilterSubject] = useState('all');

  const totalQuestions = quizzes.reduce((acc, q) => acc + (q.questions ? q.questions.length : 0), 0);

  const filteredQuizzes = quizzes.filter((q) => {
    const matchesSearch =
      q.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (q.description && q.description.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesSubject = filterSubject === 'all' || q.subjectId === filterSubject;
    return matchesSearch && matchesSubject;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Admin Dashboard Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              प्रशासक डैशबोर्ड (Admin Dashboard)
            </h2>
          </div>
          <p className="text-slate-500 text-xs sm:text-sm">
            अपने सभी टेस्ट पेपर्स प्रबंधित करें, और Gemini AI द्वारा सेकंडों में नए टेस्ट बनाएं।
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={onOpenCreateQuiz}
            className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold text-sm rounded-xl shadow-md hover:shadow-lg transition flex items-center gap-2 transform hover:-translate-y-0.5"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>+ नया AI क्विज़ बनाएं</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xl">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold uppercase text-slate-400">कुल टेस्ट पेपर्स</span>
            <div className="text-2xl font-black text-slate-900 font-mono">{quizzes.length}</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xl">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold uppercase text-slate-400">कुल प्रश्न (MCQs)</span>
            <div className="text-2xl font-black text-slate-900 font-mono">{totalQuestions}</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xl">
            <Sparkles className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <span className="text-xs font-bold uppercase text-slate-400">AI इंजन स्थिति</span>
            <div className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full inline-block mt-0.5 border border-emerald-200">
              ⚡ Gemini API सक्रिय
            </div>
          </div>
        </div>
      </div>

      {/* Quiz Management Table Container */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <h3 className="font-bold text-slate-900 text-lg">
            टेस्ट पेपर्स सूची ({filteredQuizzes.length})
          </h3>

          <div className="flex flex-wrap items-center gap-2">
            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="शीर्षक खोजें..."
                className="pl-9 pr-3 py-1.5 text-xs sm:text-sm border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 w-44 sm:w-56"
              />
            </div>

            {/* Subject filter */}
            <select
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
              className="p-1.5 text-xs sm:text-sm border border-slate-300 rounded-xl outline-none bg-white font-medium text-slate-700"
            >
              <option value="all">सभी विषय</option>
              {SUBJECTS_DATA.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          {filteredQuizzes.length === 0 ? (
            <div className="text-center py-12 text-slate-400 space-y-2">
              <p className="text-sm">कोई टेस्ट पेपर नहीं मिला।</p>
              <button
                onClick={onOpenCreateQuiz}
                className="text-xs text-blue-600 hover:underline font-semibold"
              >
                + नया टेस्ट बनाएं
              </button>
            </div>
          ) : (
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[11px] tracking-wider border-b border-slate-100">
                <tr>
                  <th className="py-3 px-4">टेस्ट शीर्षक</th>
                  <th className="py-3 px-4">विषय व सब-ब्लॉक</th>
                  <th className="py-3 px-4 text-center">प्रश्न</th>
                  <th className="py-3 px-4">दिनांक</th>
                  <th className="py-3 px-4 text-right">कार्रवाई (Actions)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredQuizzes.map((quiz) => {
                  const subj = SUBJECTS_DATA.find((s) => s.id === quiz.subjectId);
                  const subCat = subj?.subcategories.find((sc) => sc.id === quiz.subCategoryId);

                  return (
                    <tr key={quiz.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{quiz.title}</div>
                        {quiz.description && (
                          <div className="text-[11px] text-slate-400 truncate max-w-xs">
                            {quiz.description}
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-xs">
                        <span className="font-semibold text-blue-700 block">
                          {subj ? subj.name.split('(')[0] : 'General'}
                        </span>
                        <span className="text-slate-400">
                          {subCat ? subCat.name.split('(')[0] : 'All Topics'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-100">
                          {quiz.questions ? quiz.questions.length : 0} Qs
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-400 text-xs font-mono">
                        {new Date(quiz.createdAt).toLocaleDateString('hi-IN', {
                          day: 'numeric',
                          month: 'short',
                        })}
                      </td>
                      <td className="py-3.5 px-4 text-right space-x-2">
                        <button
                          onClick={() => onStartQuiz(quiz)}
                          className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-blue-50 text-blue-700 hover:bg-blue-100 transition inline-flex items-center gap-1"
                        >
                          <Play className="w-3 h-3 fill-current" />
                          <span>प्ले</span>
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`क्या आप सचमुच "${quiz.title}" को हटाना चाहते हैं?`)) {
                              onDeleteQuiz(quiz.id);
                            }
                          }}
                          className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-red-50 text-red-600 hover:bg-red-100 transition inline-flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>हटाएं</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
