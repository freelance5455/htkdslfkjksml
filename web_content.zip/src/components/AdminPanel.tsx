import React, { useMemo, useState } from 'react';
import {
  Award,
  Bell,
  BookOpen,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  ExternalLink,
  FileText,
  FolderKanban,
  HelpCircle,
  Layers,
  LayoutDashboard,
  Loader2,
  LogOut,
  Plus,
  Search,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  TrendingUp,
  Upload,
  Users,
  Video,
  XCircle,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { getSubjectsForClass } from '../data/curriculum';
import { uploadEduToonFile } from '../services/firestoreService';
import {
  Announcement,
  AnnouncementCategory,
  ClassChangeReport,
  ClassLevel,
  CustomLesson,
  CustomSubject,
  LanguageCode,
  Quiz,
  QuizAttempt,
  QuizQuestion,
  StudentProfile,
  Subject,
} from '../types/edutoon';
import { buildDailyActivitySeries } from '../utils/adminStats';
import { Logo } from './Logo';

type AdminTab =
  | 'overview'
  | 'upload-notes'
  | 'upload-videos'
  | 'create-quiz'
  | 'classes-subjects'
  | 'manage-content'
  | 'student-progress'
  | 'announcements';

interface AdminPanelProps {
  adminUid: string;
  adminEmail: string;
  reports: ClassChangeReport[];
  announcements: Announcement[];
  customLessons: CustomLesson[];
  customSubjects: CustomSubject[];
  quizzes: Quiz[];
  quizAttempts: QuizAttempt[];
  students: StudentProfile[];
  onReviewReport: (
    report: ClassChangeReport,
    decision: 'approved' | 'rejected',
    adminNote: string
  ) => Promise<void>;
  onCreateAnnouncement: (params: {
    title: string;
    body: string;
    category: AnnouncementCategory;
    targetClass: number;
  }) => Promise<void>;
  onDeleteAnnouncement: (id: string) => Promise<void>;
  onCreateCustomLesson: (params: {
    type: 'note' | 'video';
    classLevel: ClassLevel;
    language: LanguageCode;
    subjectId: string;
    chapterNumber: number;
    title: string;
    summary: string;
    content: string;
    durationLabel: string;
    mediaUrl: string;
  }) => Promise<void>;
  onDeleteCustomLesson: (id: string) => Promise<void>;
  onCreateCustomSubject: (params: {
    slug: string;
    titleEn: string;
    titleHi: string;
    descriptionEn: string;
    descriptionHi: string;
    minClass: number;
    maxClass: number;
    accentHex: string;
    iconKey: Subject['iconKey'];
  }) => Promise<void>;
  onDeleteCustomSubject: (id: string) => Promise<void>;
  onCreateQuiz: (params: {
    classLevel: ClassLevel;
    language: LanguageCode;
    subjectId: string;
    chapterNumber: number;
    title: string;
    description: string;
    timeLimitMinutes: number;
    questions: QuizQuestion[];
  }) => Promise<void>;
  onDeleteQuiz: (id: string) => Promise<void>;
  onOpenStudentView?: () => void;
  onSignOut: () => Promise<void>;
}

const createEmptyQuestion = (index: number): QuizQuestion => ({
  id: `q_${Date.now()}_${index}`,
  prompt: '',
  options: ['', '', '', ''],
  correctIndex: 0,
  explanation: '',
});

export const AdminPanel: React.FC<AdminPanelProps> = ({
  adminUid,
  adminEmail,
  reports,
  announcements,
  customLessons,
  customSubjects,
  quizzes,
  quizAttempts,
  students,
  onReviewReport,
  onCreateAnnouncement,
  onDeleteAnnouncement,
  onCreateCustomLesson,
  onDeleteCustomLesson,
  onCreateCustomSubject,
  onDeleteCustomSubject,
  onCreateQuiz,
  onDeleteQuiz,
  onOpenStudentView,
  onSignOut,
}) => {
  const [tab, setTab] = useState<AdminTab>('overview');
  const [activityRangeDays, setActivityRangeDays] = useState<7 | 14 | 30>(14);
  const [noteByReportId, setNoteByReportId] = useState<Record<string, string>>({});
  const [busyReportId, setBusyReportId] = useState<string | null>(null);

  // Upload Notes (PDF) state
  const [noteClass, setNoteClass] = useState<ClassLevel>(6);
  const [noteLang, setNoteLang] = useState<LanguageCode>('en');
  const [noteSubject, setNoteSubject] = useState('math');
  const [noteChapter, setNoteChapter] = useState(1);
  const [noteTitle, setNoteTitle] = useState('');
  const [noteSummary, setNoteSummary] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [notePdfUrl, setNotePdfUrl] = useState('');
  const [noteFileProgress, setNoteFileProgress] = useState<number | null>(null);
  const [noteUploadError, setNoteUploadError] = useState<string | null>(null);
  const [noteSaving, setNoteSaving] = useState(false);

  // Upload Videos state
  const [vidClass, setVidClass] = useState<ClassLevel>(6);
  const [vidLang, setVidLang] = useState<LanguageCode>('en');
  const [vidSubject, setVidSubject] = useState('science');
  const [vidChapter, setVidChapter] = useState(1);
  const [vidTitle, setVidTitle] = useState('');
  const [vidSummary, setVidSummary] = useState('');
  const [vidScript, setVidScript] = useState('');
  const [vidDuration, setVidDuration] = useState('5:00 min');
  const [vidMediaUrl, setVidMediaUrl] = useState('');
  const [vidFileProgress, setVidFileProgress] = useState<number | null>(null);
  const [vidUploadError, setVidUploadError] = useState<string | null>(null);
  const [vidSaving, setVidSaving] = useState(false);

  // Create Quiz state
  const [quizClass, setQuizClass] = useState<ClassLevel>(6);
  const [quizLang, setQuizLang] = useState<LanguageCode>('en');
  const [quizSubject, setQuizSubject] = useState('math');
  const [quizChapter, setQuizChapter] = useState(1);
  const [quizTitle, setQuizTitle] = useState('');
  const [quizDesc, setQuizDesc] = useState('');
  const [quizTimeMin, setQuizTimeMin] = useState(10);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([createEmptyQuestion(1)]);
  const [quizError, setQuizError] = useState<string | null>(null);
  const [quizSaving, setQuizSaving] = useState(false);

  // Subject form
  const [subTitleEn, setSubTitleEn] = useState('');
  const [subTitleHi, setSubTitleHi] = useState('');
  const [subDescEn, setSubDescEn] = useState('');
  const [subDescHi, setSubDescHi] = useState('');
  const [subMinClass, setSubMinClass] = useState<number>(1);
  const [subMaxClass, setSubMaxClass] = useState<number>(10);
  const [subAccentHex, setSubAccentHex] = useState('#0284C7');
  const [subIconKey, setSubIconKey] = useState<Subject['iconKey']>('science');
  const [subSaving, setSubSaving] = useState(false);

  // Manage Uploaded Content filters
  const [contentTypeFilter, setContentTypeFilter] = useState<'all' | 'note' | 'video' | 'quiz'>(
    'all'
  );
  const [contentClassFilter, setContentClassFilter] = useState<number>(0);
  const [contentSearch, setContentSearch] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Student Progress filters
  const [studentSearch, setStudentSearch] = useState('');
  const [studentClassFilter, setStudentClassFilter] = useState<number>(0);

  // Announcement form
  const [annTitle, setAnnTitle] = useState('');
  const [annBody, setAnnBody] = useState('');
  const [annCategory, setAnnCategory] = useState<AnnouncementCategory>('General');
  const [annTargetClass, setAnnTargetClass] = useState<number>(0);
  const [annSaving, setAnnSaving] = useState(false);

  const pendingReports = useMemo(() => reports.filter((r) => r.status === 'pending'), [reports]);
  const customNotes = useMemo(() => customLessons.filter((l) => l.type === 'note'), [customLessons]);
  const customVideos = useMemo(
    () => customLessons.filter((l) => l.type === 'video'),
    [customLessons]
  );

  const getSubjectsForPicker = (cls: ClassLevel) => {
    const builtIn = getSubjectsForClass(cls);
    const mergedCustom: Subject[] = customSubjects
      .filter((cs) => cs.minClass <= cls && cs.maxClass >= cls)
      .map((cs) => ({
        id: cs.slug,
        classLevel: cls,
        titleEn: cs.titleEn,
        titleHi: cs.titleHi,
        descriptionEn: cs.descriptionEn,
        descriptionHi: cs.descriptionHi,
        accentHex: cs.accentHex,
        iconKey: cs.iconKey,
      }));
    return [...builtIn, ...mergedCustom];
  };

  const noteSubjects = getSubjectsForPicker(noteClass);
  const videoSubjects = getSubjectsForPicker(vidClass);
  const quizSubjects = getSubjectsForPicker(quizClass);

  // Unified Uploaded Content entries
  const unifiedContent = useMemo(() => {
    const q = contentSearch.trim().toLowerCase();
    type ContentItem =
      | { kind: 'note'; id: string; item: CustomLesson }
      | { kind: 'video'; id: string; item: CustomLesson }
      | { kind: 'quiz'; id: string; item: Quiz };

    const all: ContentItem[] = [
      ...customNotes.map((item) => ({ kind: 'note' as const, id: `lesson_${item.id}`, item })),
      ...customVideos.map((item) => ({ kind: 'video' as const, id: `lesson_${item.id}`, item })),
      ...quizzes.map((item) => ({ kind: 'quiz' as const, id: `quiz_${item.id}`, item })),
    ];

    return all.filter((entry) => {
      if (contentTypeFilter !== 'all' && entry.kind !== contentTypeFilter) return false;
      if (contentClassFilter > 0 && entry.item.classLevel !== contentClassFilter) return false;
      if (!q) return true;
      return (
        entry.item.title.toLowerCase().includes(q) ||
        entry.item.subjectId.toLowerCase().includes(q)
      );
    });
  }, [customNotes, customVideos, quizzes, contentTypeFilter, contentClassFilter, contentSearch]);

  // Quiz attempts grouped by studentId
  const attemptsByStudent = useMemo(() => {
    const map = new Map<string, QuizAttempt[]>();
    quizAttempts.forEach((att) => {
      const list = map.get(att.studentId) || [];
      list.push(att);
      map.set(att.studentId, list);
    });
    return map;
  }, [quizAttempts]);

  const filteredStudents = useMemo(() => {
    const q = studentSearch.trim().toLowerCase();
    return students.filter((s) => {
      if (studentClassFilter > 0 && s.selectedClass !== studentClassFilter) return false;
      if (!q) return true;
      return (
        s.displayName.toLowerCase().includes(q) ||
        s.uid.toLowerCase().includes(q) ||
        String(s.selectedClass).includes(q)
      );
    });
  }, [students, studentSearch, studentClassFilter]);

  const progressSummary = useMemo(() => {
    if (students.length === 0) {
      return { avgNotes: 0, avgVideos: 0, totalQuizAttempts: quizAttempts.length, avgQuizPct: 0 };
    }
    const totalNotes = students.reduce((acc, s) => acc + s.completedNoteIds.length, 0);
    const totalVideos = students.reduce((acc, s) => acc + s.completedVideoIds.length, 0);
    const totalQuizPct = quizAttempts.reduce((acc, a) => acc + a.percentage, 0);
    return {
      avgNotes: Math.round((totalNotes / students.length) * 10) / 10,
      avgVideos: Math.round((totalVideos / students.length) * 10) / 10,
      totalQuizAttempts: quizAttempts.length,
      avgQuizPct: quizAttempts.length > 0 ? Math.round(totalQuizPct / quizAttempts.length) : 0,
    };
  }, [students, quizAttempts]);

  const recentActivitySeries = useMemo(
    () =>
      buildDailyActivitySeries({
        students,
        quizAttempts,
        days: activityRangeDays,
      }),
    [students, quizAttempts, activityRangeDays]
  );

  const recentActivityTotals = useMemo(
    () =>
      recentActivitySeries.reduce(
        (acc, pt) => ({
          signups: acc.signups + pt.signups,
          quizAttempts: acc.quizAttempts + pt.quizAttempts,
        }),
        { signups: 0, quizAttempts: 0 }
      ),
    [recentActivitySeries]
  );

  const handleUploadNotePdf = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setNoteUploadError(null);
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
      setNoteUploadError('Please select a valid PDF file (.pdf).');
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      setNoteUploadError('PDF exceeds the 25 MB upload limit.');
      return;
    }
    setNoteFileProgress(0);
    try {
      const url = await uploadEduToonFile(file, 'notes', noteClass, setNoteFileProgress);
      setNotePdfUrl(url);
      if (!noteTitle.trim()) {
        setNoteTitle(file.name.replace(/\.pdf$/i, '').slice(0, 140));
      }
      setNoteFileProgress(null);
    } catch (err) {
      setNoteFileProgress(null);
      setNoteUploadError(
        err instanceof Error
          ? `PDF upload failed (${err.message}). Verify Firebase Storage & storage.rules are deployed, or paste a hosted PDF URL below.`
          : 'PDF upload failed. You can paste a hosted PDF URL directly.'
      );
    }
  };

  const handleUploadVideoFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setVidUploadError(null);
    if (!file.type.startsWith('video/')) {
      setVidUploadError('Please select a valid video file (MP4, WebM, MOV).');
      return;
    }
    if (file.size > 150 * 1024 * 1024) {
      setVidUploadError('Video exceeds the 150 MB upload limit.');
      return;
    }
    setVidFileProgress(0);
    try {
      const url = await uploadEduToonFile(file, 'videos', vidClass, setVidFileProgress);
      setVidMediaUrl(url);
      if (!vidTitle.trim()) {
        setVidTitle(file.name.replace(/\.[^.]+$/, '').slice(0, 140));
      }
      setVidFileProgress(null);
    } catch (err) {
      setVidFileProgress(null);
      setVidUploadError(
        err instanceof Error
          ? `Video upload failed (${err.message}). Verify Firebase Storage & storage.rules are deployed, or paste a hosted video URL below.`
          : 'Video upload failed. You can paste a hosted video URL directly.'
      );
    }
  };

  const handlePublishNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim() || !noteSummary.trim() || !noteContent.trim()) return;
    setNoteSaving(true);
    try {
      await onCreateCustomLesson({
        type: 'note',
        classLevel: noteClass,
        language: noteLang,
        subjectId: noteSubjects.some((s) => s.id === noteSubject)
          ? noteSubject
          : noteSubjects[0].id,
        chapterNumber: noteChapter,
        title: noteTitle,
        summary: noteSummary,
        content: noteContent,
        durationLabel: notePdfUrl ? 'Uploaded PDF' : 'Chapter Note',
        mediaUrl: notePdfUrl,
      });
      setNoteTitle('');
      setNoteSummary('');
      setNoteContent('');
      setNotePdfUrl('');
      setNoteUploadError(null);
    } finally {
      setNoteSaving(false);
    }
  };

  const handlePublishVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vidTitle.trim() || !vidSummary.trim() || !vidScript.trim()) return;
    setVidSaving(true);
    try {
      await onCreateCustomLesson({
        type: 'video',
        classLevel: vidClass,
        language: vidLang,
        subjectId: videoSubjects.some((s) => s.id === vidSubject)
          ? vidSubject
          : videoSubjects[0].id,
        chapterNumber: vidChapter,
        title: vidTitle,
        summary: vidSummary,
        content: vidScript,
        durationLabel: vidDuration || '5:00 min',
        mediaUrl: vidMediaUrl,
      });
      setVidTitle('');
      setVidSummary('');
      setVidScript('');
      setVidMediaUrl('');
      setVidUploadError(null);
    } finally {
      setVidSaving(false);
    }
  };

  const handlePublishQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    setQuizError(null);
    if (!quizTitle.trim() || !quizDesc.trim()) {
      setQuizError('Quiz title and description are required.');
      return;
    }
    const invalidQuestion = quizQuestions.find(
      (q) => !q.prompt.trim() || q.options.some((opt) => !opt.trim())
    );
    if (invalidQuestion) {
      setQuizError('Every question must have a question prompt and all 4 answer options filled.');
      return;
    }

    setQuizSaving(true);
    try {
      await onCreateQuiz({
        classLevel: quizClass,
        language: quizLang,
        subjectId: quizSubjects.some((s) => s.id === quizSubject)
          ? quizSubject
          : quizSubjects[0].id,
        chapterNumber: quizChapter,
        title: quizTitle,
        description: quizDesc,
        timeLimitMinutes: quizTimeMin,
        questions: quizQuestions,
      });
      setQuizTitle('');
      setQuizDesc('');
      setQuizQuestions([createEmptyQuestion(1)]);
    } finally {
      setQuizSaving(false);
    }
  };

  const handlePublishSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subTitleEn.trim() || !subTitleHi.trim() || !subDescEn.trim() || !subDescHi.trim()) return;
    setSubSaving(true);
    try {
      const slug = subTitleEn
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '');
      await onCreateCustomSubject({
        slug: slug || `subject_${Date.now()}`,
        titleEn: subTitleEn,
        titleHi: subTitleHi,
        descriptionEn: subDescEn,
        descriptionHi: subDescHi,
        minClass: subMinClass,
        maxClass: Math.max(subMinClass, subMaxClass),
        accentHex: subAccentHex,
        iconKey: subIconKey,
      });
      setSubTitleEn('');
      setSubTitleHi('');
      setSubDescEn('');
      setSubDescHi('');
    } finally {
      setSubSaving(false);
    }
  };

  const handlePublishAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle.trim() || !annBody.trim()) return;
    setAnnSaving(true);
    try {
      await onCreateAnnouncement({
        title: annTitle,
        body: annBody,
        category: annCategory,
        targetClass: annTargetClass,
      });
      setAnnTitle('');
      setAnnBody('');
    } finally {
      setAnnSaving(false);
    }
  };

  const navItems: { id: AdminTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'overview', label: 'Overview', icon: <LayoutDashboard className="h-4 w-4 shrink-0" /> },
    {
      id: 'upload-notes',
      label: 'Upload Notes (PDF)',
      icon: <FileText className="h-4 w-4 shrink-0" />,
      badge: customNotes.length,
    },
    {
      id: 'upload-videos',
      label: 'Upload Videos',
      icon: <Video className="h-4 w-4 shrink-0" />,
      badge: customVideos.length,
    },
    {
      id: 'create-quiz',
      label: 'Create Quiz',
      icon: <HelpCircle className="h-4 w-4 shrink-0" />,
      badge: quizzes.length,
    },
    {
      id: 'classes-subjects',
      label: 'Classes & Subjects',
      icon: <Layers className="h-4 w-4 shrink-0" />,
      badge: pendingReports.length,
    },
    {
      id: 'manage-content',
      label: 'Manage Content',
      icon: <FolderKanban className="h-4 w-4 shrink-0" />,
      badge: customLessons.length + quizzes.length,
    },
    {
      id: 'student-progress',
      label: 'Student Progress',
      icon: <Users className="h-4 w-4 shrink-0" />,
      badge: students.length,
    },
    {
      id: 'announcements',
      label: 'Announcements',
      icon: <Bell className="h-4 w-4 shrink-0" />,
      badge: announcements.length,
    },
  ];

  return (
    <div className="min-h-screen bg-[#F4F6FB] text-slate-900 flex flex-col lg:flex-row">
      {/* Admin Left Sidebar (Desktop) */}
      <aside className="hidden lg:flex lg:flex-col lg:w-72 lg:fixed lg:inset-y-0 bg-[#0B132B] text-white px-4 py-6 justify-between z-30">
        <div className="space-y-5 overflow-y-auto pr-1">
          <div className="flex items-center gap-3 px-2">
            <Logo size="sm" glow />
            <div className="min-w-0">
              <p className="font-display text-base font-bold text-white truncate">
                EduToon Admin
              </p>
              <p className="text-[11px] font-semibold text-sky-300 truncate flex items-center gap-1">
                <ShieldCheck className="h-3.5 w-3.5 shrink-0" />
                <span>Verified Admin Panel</span>
              </p>
            </div>
          </div>

          <nav className="space-y-1">
            {navItems.map((item) => {
              const active = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTab(item.id)}
                  className={`w-full min-h-[42px] px-3.5 rounded-xl flex items-center justify-between text-xs sm:text-sm font-semibold transition-colors cursor-pointer ${
                    active
                      ? 'bg-sky-600 text-white shadow-[0_0_18px_rgba(2,132,199,0.45)]'
                      : 'text-slate-300 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <span className="flex items-center gap-2.5 truncate">
                    {item.icon}
                    <span className="truncate">{item.label}</span>
                  </span>
                  {typeof item.badge === 'number' && item.badge > 0 && (
                    <span className="text-xs font-mono-num text-sky-200 ml-2">{item.badge}</span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="space-y-2.5 pt-4 border-t border-white/10">
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-xs text-slate-300">
            <p className="font-semibold text-white truncate">{adminEmail || 'Administrator'}</p>
            <p className="mt-0.5 font-mono-num text-[11px] text-slate-400 truncate">
              UID: {adminUid}
            </p>
          </div>
          {onOpenStudentView && (
            <button
              type="button"
              onClick={onOpenStudentView}
              className="w-full min-h-[42px] px-3.5 rounded-xl border border-sky-400/35 bg-sky-500/15 hover:bg-sky-500/25 text-sky-100 text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
            >
              <BookOpen className="h-4 w-4" />
              <span>Student Dashboard</span>
            </button>
          )}
          <button
            type="button"
            onClick={onSignOut}
            className="w-full min-h-[44px] px-3.5 rounded-xl bg-red-500/15 border border-red-400/40 hover:bg-red-500/25 text-red-100 text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogOut className="h-4 w-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Mobile Top Admin Header */}
      <header className="lg:hidden sticky top-0 z-30 bg-[#0B132B] text-white border-b border-slate-800 px-4 py-2.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <Logo size="xs" />
          <div className="min-w-0">
            <p className="font-display text-sm font-bold truncate">EduToon Admin Dashboard</p>
            <p className="text-[11px] text-sky-300 truncate">{adminEmail || adminUid}</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {onOpenStudentView && (
            <button
              type="button"
              onClick={onOpenStudentView}
              className="min-h-[38px] px-2.5 rounded-xl border border-sky-400/40 bg-sky-500/15 text-[11px] font-semibold text-sky-100 inline-flex items-center gap-1 cursor-pointer"
            >
              <BookOpen className="h-3.5 w-3.5" />
              <span>Student</span>
            </button>
          )}
          <button
            type="button"
            onClick={onSignOut}
            className="min-h-[38px] px-3 rounded-xl bg-red-500/15 border border-red-400/40 text-xs font-semibold text-red-100 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </header>

      {/* Mobile Admin Navigation Strip */}
      <div className="lg:hidden bg-white border-b border-slate-200 px-3 py-2 overflow-x-auto">
        <div className="flex items-center gap-1.5 min-w-max">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={`min-h-[38px] px-3 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                tab === item.id
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
              {typeof item.badge === 'number' && item.badge > 0 && (
                <span className="font-mono-num opacity-80">({item.badge})</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Main Admin Workspace */}
      <main className="flex-1 lg:pl-72 p-4 sm:p-6 lg:p-8">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Top Dashboard Statistics */}
          <section
            aria-label="Dashboard Statistics"
            className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <Logo size="xs" />
                <div>
                  <h2 className="font-display text-base sm:text-lg font-bold text-slate-900">
                    Dashboard Statistics
                  </h2>
                  <p className="text-xs text-slate-500">
                    Live overview of students, pending class-change requests, and quizzes.
                  </p>
                </div>
              </div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-sky-700">
                Real-Time Totals
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <button
                type="button"
                onClick={() => setTab('student-progress')}
                className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-sky-400 hover:bg-sky-50/40 text-left transition-colors cursor-pointer flex items-center justify-between gap-3"
              >
                <div>
                  <p className="text-xs font-semibold text-slate-500">Total Students</p>
                  <p className="mt-1.5 font-display text-3xl font-bold text-slate-900 font-mono-num">
                    {students.length}
                  </p>
                </div>
                <div className="h-11 w-11 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center shrink-0">
                  <Users className="h-5 w-5" />
                </div>
              </button>

              <button
                type="button"
                onClick={() => setTab('classes-subjects')}
                className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-amber-400 hover:bg-amber-50/40 text-left transition-colors cursor-pointer flex items-center justify-between gap-3"
              >
                <div>
                  <p className="text-xs font-semibold text-slate-500">
                    Pending Class-Change Reports
                  </p>
                  <p className="mt-1.5 font-display text-3xl font-bold text-amber-600 font-mono-num">
                    {pendingReports.length}
                  </p>
                </div>
                <div className="h-11 w-11 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                  <Clock className="h-5 w-5" />
                </div>
              </button>

              <button
                type="button"
                onClick={() => setTab('create-quiz')}
                className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/40 text-left transition-colors cursor-pointer flex items-center justify-between gap-3"
              >
                <div>
                  <p className="text-xs font-semibold text-slate-500">Total Quizzes Created</p>
                  <p className="mt-1.5 font-display text-3xl font-bold text-emerald-700 font-mono-num">
                    {quizzes.length}
                  </p>
                </div>
                <div className="h-11 w-11 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <HelpCircle className="h-5 w-5" />
                </div>
              </button>
            </div>

            {/* Recent Activity Chart (Recharts) */}
            <div className="pt-4 border-t border-slate-100 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="h-9 w-9 rounded-xl bg-sky-50 border border-sky-100 text-sky-700 flex items-center justify-center shrink-0">
                    <TrendingUp className="h-4 w-4" />
                  </div>
                  <div>
                    <h3 className="font-display text-sm sm:text-base font-bold text-slate-900">
                      Recent Activity
                    </h3>
                    <p className="text-xs text-slate-500">
                      Daily student signups &amp; quiz participation ({recentActivityTotals.signups}{' '}
                      signups · {recentActivityTotals.quizAttempts} quiz attempts in last{' '}
                      {activityRangeDays}d)
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between sm:justify-end gap-3">
                  <div className="flex items-center gap-3 text-xs font-semibold text-slate-600">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="h-2.5 w-2.5 rounded-full bg-sky-600" />
                      <span>Student Signups</span>
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                      <span>Quiz Participation</span>
                    </span>
                  </div>

                  <div
                    role="group"
                    aria-label="Recent activity timeframe"
                    className="inline-flex rounded-xl bg-slate-100 p-1 gap-1"
                  >
                    {([7, 14, 30] as const).map((days) => (
                      <button
                        key={days}
                        type="button"
                        onClick={() => setActivityRangeDays(days)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold font-mono-num transition-colors cursor-pointer ${
                          activityRangeDays === days
                            ? 'bg-white text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {days}D
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="h-[240px] w-full min-w-0">
                <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                  <AreaChart
                    data={recentActivitySeries}
                    margin={{ top: 10, right: 12, left: -16, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="edutoonSignupsGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0284C7" stopOpacity={0.28} />
                        <stop offset="95%" stopColor="#0284C7" stopOpacity={0.02} />
                      </linearGradient>
                      <linearGradient id="edutoonQuizzesGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10B981" stopOpacity={0.28} />
                        <stop offset="95%" stopColor="#10B981" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                    <XAxis
                      dataKey="label"
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      axisLine={false}
                      tickLine={false}
                      minTickGap={18}
                    />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0B132B',
                        borderColor: '#1E293B',
                        borderRadius: '14px',
                        color: '#F8FAFC',
                        fontSize: '12px',
                        padding: '10px 12px',
                      }}
                      labelStyle={{ color: '#94A3B8', fontWeight: 600, marginBottom: '4px' }}
                    />
                    <Area
                      type="monotone"
                      dataKey="signups"
                      name="Student Signups"
                      stroke="#0284C7"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#edutoonSignupsGrad)"
                      activeDot={{ r: 5 }}
                    />
                    <Area
                      type="monotone"
                      dataKey="quizAttempts"
                      name="Quiz Participation"
                      stroke="#10B981"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#edutoonQuizzesGrad)"
                      activeDot={{ r: 5 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </section>

          {/* 0. Overview */}
          {tab === 'overview' && (
            <div className="space-y-6">
              <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <Logo size="sm" />
                  <div>
                    <p className="text-xs font-semibold text-sky-700">
                      EduToon Education · Authorized Admin Console
                    </p>
                    <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
                      Admin Dashboard
                    </h1>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setTab('upload-notes')}
                    className="min-h-[42px] px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-semibold cursor-pointer"
                  >
                    + Upload Notes (PDF)
                  </button>
                  <button
                    type="button"
                    onClick={() => setTab('create-quiz')}
                    className="min-h-[42px] px-4 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 text-xs sm:text-sm font-semibold cursor-pointer"
                  >
                    + Create Quiz
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <button
                  type="button"
                  onClick={() => setTab('upload-notes')}
                  className="bg-white rounded-2xl border border-slate-200 hover:border-sky-400 p-5 text-left cursor-pointer"
                >
                  <p className="text-xs font-semibold text-slate-500">Notes (PDF) Uploaded</p>
                  <p className="mt-2 font-display text-3xl font-bold text-sky-700 font-mono-num">
                    {customNotes.length}
                  </p>
                </button>
                <button
                  type="button"
                  onClick={() => setTab('upload-videos')}
                  className="bg-white rounded-2xl border border-slate-200 hover:border-sky-400 p-5 text-left cursor-pointer"
                >
                  <p className="text-xs font-semibold text-slate-500">Video Lessons Uploaded</p>
                  <p className="mt-2 font-display text-3xl font-bold text-purple-700 font-mono-num">
                    {customVideos.length}
                  </p>
                </button>
                <button
                  type="button"
                  onClick={() => setTab('student-progress')}
                  className="bg-white rounded-2xl border border-slate-200 hover:border-sky-400 p-5 text-left cursor-pointer"
                >
                  <p className="text-xs font-semibold text-slate-500">Quiz Attempts Recorded</p>
                  <p className="mt-2 font-display text-3xl font-bold text-emerald-700 font-mono-num">
                    {quizAttempts.length}
                  </p>
                </button>
                <button
                  type="button"
                  onClick={() => setTab('announcements')}
                  className="bg-white rounded-2xl border border-slate-200 hover:border-sky-400 p-5 text-left cursor-pointer"
                >
                  <p className="text-xs font-semibold text-slate-500">Published Announcements</p>
                  <p className="mt-2 font-display text-3xl font-bold text-slate-900 font-mono-num">
                    {announcements.length}
                  </p>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      Quick Admin Actions
                    </h2>
                    <Logo size="xs" />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setTab('upload-notes')}
                      className="p-4 rounded-2xl border border-slate-200 hover:border-sky-400 hover:bg-sky-50/40 text-left cursor-pointer"
                    >
                      <FileText className="h-5 w-5 text-sky-600 mb-2" />
                      <p className="font-semibold text-sm text-slate-900">Upload Notes (PDF)</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Upload PDFs to Storage &amp; publish notes
                      </p>
                    </button>
                    <button
                      type="button"
                      onClick={() => setTab('upload-videos')}
                      className="p-4 rounded-2xl border border-slate-200 hover:border-sky-400 hover:bg-sky-50/40 text-left cursor-pointer"
                    >
                      <Video className="h-5 w-5 text-purple-600 mb-2" />
                      <p className="font-semibold text-sm text-slate-900">Upload Videos</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Upload MP4/WebM animated video lessons
                      </p>
                    </button>
                    <button
                      type="button"
                      onClick={() => setTab('create-quiz')}
                      className="p-4 rounded-2xl border border-slate-200 hover:border-sky-400 hover:bg-sky-50/40 text-left cursor-pointer"
                    >
                      <HelpCircle className="h-5 w-5 text-emerald-600 mb-2" />
                      <p className="font-semibold text-sm text-slate-900">Create Quiz</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Build chapter MCQs &amp; track scores
                      </p>
                    </button>
                    <button
                      type="button"
                      onClick={() => setTab('announcements')}
                      className="p-4 rounded-2xl border border-slate-200 hover:border-sky-400 hover:bg-sky-50/40 text-left cursor-pointer"
                    >
                      <Bell className="h-5 w-5 text-amber-600 mb-2" />
                      <p className="font-semibold text-sm text-slate-900">Announcements</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Broadcast alerts to Classes 1–10
                      </p>
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      Pending Class Change Requests
                    </h2>
                    <button
                      type="button"
                      onClick={() => setTab('classes-subjects')}
                      className="text-xs font-semibold text-sky-700 hover:underline cursor-pointer"
                    >
                      Manage Classes →
                    </button>
                  </div>
                  {pendingReports.length === 0 ? (
                    <p className="text-sm text-slate-500">
                      All student class change requests have been reviewed.
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {pendingReports.slice(0, 3).map((rep) => (
                        <div
                          key={rep.id}
                          className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div>
                            <p className="font-semibold text-slate-900 text-sm">
                              {rep.studentName} · Class {rep.currentClass} → Class{' '}
                              {rep.requestedClass}
                            </p>
                            <p className="text-xs text-slate-600 mt-0.5">{rep.reason}</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => setTab('classes-subjects')}
                            className="min-h-[38px] px-3.5 rounded-xl bg-slate-900 text-white text-xs font-semibold cursor-pointer self-start sm:self-auto"
                          >
                            Review
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 1. Upload Notes (PDF) */}
          {tab === 'upload-notes' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              <form
                onSubmit={handlePublishNote}
                className="lg:col-span-6 bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4 self-start"
              >
                <div className="flex items-center gap-2.5">
                  <Logo size="xs" />
                  <div>
                    <h1 className="font-display text-lg font-bold text-slate-900">
                      Upload Notes (PDF)
                    </h1>
                    <p className="text-xs text-slate-500">
                      Upload a PDF file to Firebase Storage or link an external PDF.
                    </p>
                  </div>
                </div>

                {/* Real PDF File Picker */}
                <div className="p-4 rounded-2xl border-2 border-dashed border-sky-300 bg-sky-50/50 space-y-2.5">
                  <label className="flex items-center justify-between gap-2 text-xs font-semibold text-sky-900">
                    <span className="inline-flex items-center gap-1.5">
                      <Upload className="h-4 w-4 text-sky-600" />
                      <span>Select PDF Document (Max 25 MB)</span>
                    </span>
                    {noteFileProgress !== null && (
                      <span className="font-mono-num text-sky-700">{noteFileProgress}%</span>
                    )}
                  </label>
                  <input
                    type="file"
                    accept=".pdf,application/pdf"
                    onChange={handleUploadNotePdf}
                    className="block w-full text-xs text-slate-700 file:mr-3 file:py-2 file:px-3.5 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-sky-600 file:text-white hover:file:bg-sky-700 cursor-pointer"
                  />
                  {noteFileProgress !== null && (
                    <div className="h-2 rounded-full bg-sky-100 overflow-hidden">
                      <div
                        className="h-full bg-sky-600 transition-all"
                        style={{ width: `${noteFileProgress}%` }}
                      />
                    </div>
                  )}
                  {noteUploadError && (
                    <p className="text-xs text-red-700 flex items-start gap-1.5">
                      <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5" />
                      <span>{noteUploadError}</span>
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Class</label>
                    <select
                      value={noteClass}
                      onChange={(e) => setNoteClass(Number(e.target.value) as ClassLevel)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((c) => (
                        <option key={c} value={c}>
                          Class {c}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Medium</label>
                    <select
                      value={noteLang}
                      onChange={(e) => setNoteLang(e.target.value as LanguageCode)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      <option value="en">English</option>
                      <option value="hi">हिंदी</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Subject</label>
                    <select
                      value={noteSubject}
                      onChange={(e) => setNoteSubject(e.target.value)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      {noteSubjects.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.titleEn}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Chapter #
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={50}
                      value={noteChapter}
                      onChange={(e) => setNoteChapter(Number(e.target.value))}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm font-mono-num"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Note / PDF Title
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={160}
                    value={noteTitle}
                    onChange={(e) => setNoteTitle(e.target.value)}
                    placeholder="e.g. Chapter 1: Fractions Revision PDF"
                    className="w-full h-11 px-3.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Summary</label>
                  <input
                    type="text"
                    required
                    maxLength={400}
                    value={noteSummary}
                    onChange={(e) => setNoteSummary(e.target.value)}
                    placeholder="Key formulas and topic highlights"
                    className="w-full h-11 px-3.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Chapter Study Notes Text
                  </label>
                  <textarea
                    rows={4}
                    required
                    maxLength={6000}
                    value={noteContent}
                    onChange={(e) => setNoteContent(e.target.value)}
                    placeholder="Write detailed study notes, definitions, or PDF overview..."
                    className="w-full p-3.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Uploaded / External PDF URL
                  </label>
                  <input
                    type="url"
                    maxLength={500}
                    value={notePdfUrl}
                    onChange={(e) => setNotePdfUrl(e.target.value)}
                    placeholder="Auto-filled after PDF upload, or paste https://..."
                    className="w-full h-11 px-3.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>

                <button
                  type="submit"
                  disabled={noteSaving || noteFileProgress !== null}
                  className="w-full min-h-[46px] rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
                >
                  {noteSaving && <Loader2 className="h-4 w-4 animate-spin" />}
                  <span>{noteSaving ? 'Publishing PDF Note...' : 'Publish Note (PDF)'}</span>
                </button>
              </form>

              <div className="lg:col-span-6 space-y-3">
                <div className="bg-white rounded-2xl border border-slate-200 px-5 py-3.5 flex items-center justify-between">
                  <span className="font-display font-bold text-slate-900">
                    Uploaded Notes &amp; PDFs ({customNotes.length})
                  </span>
                  <button
                    type="button"
                    onClick={() => setTab('manage-content')}
                    className="text-xs font-semibold text-sky-700 hover:underline cursor-pointer"
                  >
                    Open Content Manager →
                  </button>
                </div>
                {customNotes.length === 0 ? (
                  <div className="bg-white rounded-3xl border border-slate-200 p-8 text-center text-sm text-slate-500">
                    No custom notes or PDFs uploaded yet.
                  </div>
                ) : (
                  customNotes.map((lesson) => (
                    <div
                      key={lesson.id}
                      className="bg-white rounded-2xl border border-slate-200 p-4 flex items-start justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <p className="text-xs text-slate-500">
                          Class {lesson.classLevel} · {lesson.subjectId} · Ch{' '}
                          {lesson.chapterNumber} · {lesson.language === 'hi' ? 'हिंदी' : 'English'}
                        </p>
                        <h3 className="font-display text-base font-bold text-slate-900 mt-0.5 truncate">
                          {lesson.title}
                        </h3>
                        <p className="text-sm text-slate-600 mt-1">{lesson.summary}</p>
                        {lesson.mediaUrl && (
                          <a
                            href={lesson.mediaUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-sky-700 hover:underline"
                          >
                            <ExternalLink className="h-3.5 w-3.5" />
                            <span>View Uploaded PDF</span>
                          </a>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => onDeleteCustomLesson(lesson.id)}
                        aria-label="Delete note"
                        className="min-h-[40px] min-w-[40px] rounded-xl text-slate-500 hover:bg-red-50 hover:text-red-700 flex items-center justify-center cursor-pointer shrink-0"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* 2. Upload Videos */}
          {tab === 'upload-videos' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              <form
                onSubmit={handlePublishVideo}
                className="lg:col-span-6 bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4 self-start"
              >
                <div className="flex items-center gap-2.5">
                  <Logo size="xs" />
                  <div>
                    <h1 className="font-display text-lg font-bold text-slate-900">
                      Upload Videos
                    </h1>
                    <p className="text-xs text-slate-500">
                      Upload MP4/WebM lessons to Firebase Storage or enter a hosted video stream URL.
                    </p>
                  </div>
                </div>

                {/* Real Video File Picker */}
                <div className="p-4 rounded-2xl border-2 border-dashed border-purple-300 bg-purple-50/50 space-y-2.5">
                  <label className="flex items-center justify-between gap-2 text-xs font-semibold text-purple-950">
                    <span className="inline-flex items-center gap-1.5">
                      <Upload className="h-4 w-4 text-purple-600" />
                      <span>Select Video File (MP4/WebM, Max 150 MB)</span>
                    </span>
                    {vidFileProgress !== null && (
                      <span className="font-mono-num text-purple-700">{vidFileProgress}%</span>
                    )}
                  </label>
                  <input
                    type="file"
                    accept="video/mp4,video/webm,video/quicktime,video/*"
                    onChange={handleUploadVideoFile}
                    className="block w-full text-xs text-slate-700 file:mr-3 file:py-2 file:px-3.5 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700 cursor-pointer"
                  />
                  {vidFileProgress !== null && (
                    <div className="h-2 rounded-full bg-purple-100 overflow-hidden">
                      <div
                        className="h-full bg-purple-600 transition-all"
                        style={{ width: `${vidFileProgress}%` }}
                      />
                    </div>
                  )}
                  {vidUploadError && (
                    <p className="text-xs text-red-700 flex items-start gap-1.5">
                      <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5" />
                      <span>{vidUploadError}</span>
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Class</label>
                    <select
                      value={vidClass}
                      onChange={(e) => setVidClass(Number(e.target.value) as ClassLevel)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((c) => (
                        <option key={c} value={c}>
                          Class {c}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Medium</label>
                    <select
                      value={vidLang}
                      onChange={(e) => setVidLang(e.target.value as LanguageCode)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      <option value="en">English</option>
                      <option value="hi">हिंदी</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Subject</label>
                    <select
                      value={vidSubject}
                      onChange={(e) => setVidSubject(e.target.value)}
                      className="w-full h-11 px-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      {videoSubjects.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.titleEn}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Chapter #
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={50}
                      value={vidChapter}
                      onChange={(e) => setVidChapter(Number(e.target.value))}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm font-mono-num"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Duration
                    </label>
                    <input
                      type="text"
                      maxLength={40}
                      value={vidDuration}
                      onChange={(e) => setVidDuration(e.target.value)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Video Title
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={160}
                    value={vidTitle}
                    onChange={(e) => setVidTitle(e.target.value)}
                    placeholder="Animated Lesson Title"
                    className="w-full h-11 px-3.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Summary</label>
                  <input
                    type="text"
                    required
                    maxLength={400}
                    value={vidSummary}
                    onChange={(e) => setVidSummary(e.target.value)}
                    placeholder="What students learn in this video"
                    className="w-full h-11 px-3.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Lesson Script / Key Explanation
                  </label>
                  <textarea
                    rows={3}
                    required
                    maxLength={6000}
                    value={vidScript}
                    onChange={(e) => setVidScript(e.target.value)}
                    placeholder="Scene explanation and key concept..."
                    className="w-full p-3.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Uploaded / External Video URL (MP4 / WebM)
                  </label>
                  <input
                    type="url"
                    maxLength={500}
                    value={vidMediaUrl}
                    onChange={(e) => setVidMediaUrl(e.target.value)}
                    placeholder="Auto-filled after video upload, or paste https://..."
                    className="w-full h-11 px-3.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>

                <button
                  type="submit"
                  disabled={vidSaving || vidFileProgress !== null}
                  className="w-full min-h-[46px] rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
                >
                  {vidSaving && <Loader2 className="h-4 w-4 animate-spin" />}
                  <span>{vidSaving ? 'Publishing Video...' : 'Publish Video Lesson'}</span>
                </button>
              </form>

              <div className="lg:col-span-6 space-y-3">
                <div className="bg-white rounded-2xl border border-slate-200 px-5 py-3.5 flex items-center justify-between">
                  <span className="font-display font-bold text-slate-900">
                    Uploaded Videos ({customVideos.length})
                  </span>
                  <span className="text-xs text-slate-500">Plays inside Student Video Player</span>
                </div>
                {customVideos.length === 0 ? (
                  <div className="bg-white rounded-3xl border border-slate-200 p-8 text-center text-sm text-slate-500">
                    No custom video lessons uploaded yet.
                  </div>
                ) : (
                  customVideos.map((lesson) => (
                    <div
                      key={lesson.id}
                      className="bg-white rounded-2xl border border-slate-200 p-4 flex items-start justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <p className="text-xs text-slate-500">
                          Class {lesson.classLevel} · {lesson.subjectId} · Ch{' '}
                          {lesson.chapterNumber} · {lesson.durationLabel} ·{' '}
                          {lesson.language === 'hi' ? 'हिंदी' : 'English'}
                        </p>
                        <h3 className="font-display text-base font-bold text-slate-900 mt-0.5 truncate">
                          {lesson.title}
                        </h3>
                        <p className="text-sm text-slate-600 mt-1">{lesson.summary}</p>
                        {lesson.mediaUrl && (
                          <a
                            href={lesson.mediaUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-purple-700 hover:underline"
                          >
                            <ExternalLink className="h-3.5 w-3.5" />
                            <span>Open Video File</span>
                          </a>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => onDeleteCustomLesson(lesson.id)}
                        aria-label="Delete video"
                        className="min-h-[40px] min-w-[40px] rounded-xl text-slate-500 hover:bg-red-50 hover:text-red-700 flex items-center justify-center cursor-pointer shrink-0"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* 3. Create Quiz */}
          {tab === 'create-quiz' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              <form
                onSubmit={handlePublishQuiz}
                className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4 self-start"
              >
                <div className="flex items-center gap-2.5">
                  <Logo size="xs" />
                  <div>
                    <h1 className="font-display text-lg font-bold text-slate-900">Create Quiz</h1>
                    <p className="text-xs text-slate-500">
                      Build chapter MCQ quizzes published directly to students.
                    </p>
                  </div>
                </div>

                {quizError && (
                  <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
                    <ShieldAlert className="h-4 w-4 shrink-0" />
                    <span>{quizError}</span>
                  </div>
                )}

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Class</label>
                    <select
                      value={quizClass}
                      onChange={(e) => setQuizClass(Number(e.target.value) as ClassLevel)}
                      className="w-full h-11 px-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((c) => (
                        <option key={c} value={c}>
                          Class {c}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Medium</label>
                    <select
                      value={quizLang}
                      onChange={(e) => setQuizLang(e.target.value as LanguageCode)}
                      className="w-full h-11 px-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      <option value="en">English</option>
                      <option value="hi">हिंदी</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Subject</label>
                    <select
                      value={quizSubject}
                      onChange={(e) => setQuizSubject(e.target.value)}
                      className="w-full h-11 px-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      {quizSubjects.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.titleEn}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Ch # / Mins
                    </label>
                    <div className="grid grid-cols-2 gap-1.5">
                      <input
                        type="number"
                        min={1}
                        max={50}
                        value={quizChapter}
                        onChange={(e) => setQuizChapter(Number(e.target.value))}
                        title="Chapter Number"
                        className="w-full h-11 px-2 rounded-xl border border-slate-300 text-sm font-mono-num"
                      />
                      <input
                        type="number"
                        min={1}
                        max={120}
                        value={quizTimeMin}
                        onChange={(e) => setQuizTimeMin(Number(e.target.value))}
                        title="Time Limit (minutes)"
                        className="w-full h-11 px-2 rounded-xl border border-slate-300 text-sm font-mono-num"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Quiz Title
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={160}
                      value={quizTitle}
                      onChange={(e) => setQuizTitle(e.target.value)}
                      placeholder="e.g. Chapter 1 Quick Check"
                      className="w-full h-11 px-3.5 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Short Instructions
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={400}
                      value={quizDesc}
                      onChange={(e) => setQuizDesc(e.target.value)}
                      placeholder="Test your understanding of chapter concepts"
                      className="w-full h-11 px-3.5 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>
                </div>

                {/* Questions Builder */}
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Questions ({quizQuestions.length} / 20)
                    </span>
                    {quizQuestions.length < 20 && (
                      <button
                        type="button"
                        onClick={() =>
                          setQuizQuestions((prev) => [
                            ...prev,
                            createEmptyQuestion(prev.length + 1),
                          ])
                        }
                        className="min-h-[36px] px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="h-3.5 w-3.5" />
                        <span>Add Question</span>
                      </button>
                    )}
                  </div>

                  {quizQuestions.map((q, qIdx) => (
                    <div
                      key={q.id}
                      className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-sky-700 font-mono-num">
                          Question {qIdx + 1}
                        </span>
                        {quizQuestions.length > 1 && (
                          <button
                            type="button"
                            onClick={() =>
                              setQuizQuestions((prev) => prev.filter((_, i) => i !== qIdx))
                            }
                            className="text-xs font-semibold text-red-600 hover:underline cursor-pointer"
                          >
                            Remove
                          </button>
                        )}
                      </div>

                      <input
                        type="text"
                        required
                        maxLength={300}
                        value={q.prompt}
                        onChange={(e) => {
                          const val = e.target.value;
                          setQuizQuestions((prev) =>
                            prev.map((item, i) => (i === qIdx ? { ...item, prompt: val } : item))
                          );
                        }}
                        placeholder="Enter question prompt..."
                        className="w-full h-10 px-3 rounded-xl border border-slate-300 bg-white text-sm"
                      />

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {([0, 1, 2, 3] as const).map((optIdx) => (
                          <div key={optIdx} className="flex items-center gap-2">
                            <input
                              type="radio"
                              name={`correct-${q.id}`}
                              checked={q.correctIndex === optIdx}
                              onChange={() =>
                                setQuizQuestions((prev) =>
                                  prev.map((item, i) =>
                                    i === qIdx ? { ...item, correctIndex: optIdx } : item
                                  )
                                )
                              }
                              title="Mark as correct option"
                              className="accent-emerald-600 h-4 w-4 cursor-pointer shrink-0"
                            />
                            <input
                              type="text"
                              required
                              maxLength={160}
                              value={q.options[optIdx]}
                              onChange={(e) => {
                                const val = e.target.value;
                                setQuizQuestions((prev) =>
                                  prev.map((item, i) => {
                                    if (i !== qIdx) return item;
                                    const nextOpts = [...item.options] as [
                                      string,
                                      string,
                                      string,
                                      string,
                                    ];
                                    nextOpts[optIdx] = val;
                                    return { ...item, options: nextOpts };
                                  })
                                );
                              }}
                              placeholder={`Option ${String.fromCharCode(65 + optIdx)}`}
                              className={`flex-1 h-10 px-3 rounded-xl border text-xs sm:text-sm bg-white ${
                                q.correctIndex === optIdx
                                  ? 'border-emerald-400 ring-1 ring-emerald-200'
                                  : 'border-slate-300'
                              }`}
                            />
                          </div>
                        ))}
                      </div>

                      <input
                        type="text"
                        maxLength={400}
                        value={q.explanation}
                        onChange={(e) => {
                          const val = e.target.value;
                          setQuizQuestions((prev) =>
                            prev.map((item, i) =>
                              i === qIdx ? { ...item, explanation: val } : item
                            )
                          );
                        }}
                        placeholder="Optional answer explanation shown after submission..."
                        className="w-full h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs"
                      />
                    </div>
                  ))}
                </div>

                <button
                  type="submit"
                  disabled={quizSaving}
                  className="w-full min-h-[46px] rounded-xl bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-sm font-semibold cursor-pointer"
                >
                  {quizSaving ? 'Publishing Quiz...' : 'Publish Chapter Quiz'}
                </button>
              </form>

              <div className="lg:col-span-5 space-y-3">
                <div className="bg-white rounded-2xl border border-slate-200 px-5 py-3.5 flex items-center justify-between">
                  <span className="font-display font-bold text-slate-900">
                    Published Quizzes ({quizzes.length})
                  </span>
                  <span className="text-xs text-slate-500">Interactive MCQs</span>
                </div>
                {quizzes.length === 0 ? (
                  <div className="bg-white rounded-3xl border border-slate-200 p-8 text-center text-sm text-slate-500">
                    No quizzes created yet. Use the builder to publish a chapter quiz.
                  </div>
                ) : (
                  quizzes.map((qz) => (
                    <div
                      key={qz.id}
                      className="bg-white rounded-2xl border border-slate-200 p-4 flex items-start justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <p className="text-xs text-slate-500">
                          Class {qz.classLevel} · {qz.subjectId} · Ch {qz.chapterNumber} ·{' '}
                          <span className="font-mono-num">{qz.questions.length} Qs</span> ·{' '}
                          {qz.language === 'hi' ? 'हिंदी' : 'English'}
                        </p>
                        <h3 className="font-display text-base font-bold text-slate-900 mt-0.5 truncate">
                          {qz.title}
                        </h3>
                        <p className="text-xs text-slate-600 mt-1">{qz.description}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onDeleteQuiz(qz.id)}
                        aria-label="Delete quiz"
                        className="min-h-[40px] min-w-[40px] rounded-xl text-slate-500 hover:bg-red-50 hover:text-red-700 flex items-center justify-center cursor-pointer shrink-0"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* 4. Manage Classes and Subjects (+ Class Change Reports) */}
          {tab === 'classes-subjects' && (
            <div className="space-y-6">
              {/* Classes 1–10 Summary */}
              <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <Logo size="xs" />
                  <div>
                    <h1 className="font-display text-xl font-bold text-slate-900">
                      Manage Classes &amp; Subjects (Classes 1–10)
                    </h1>
                    <p className="text-xs text-slate-500">
                      Active student enrollment, subjects, and custom content across Classes 1 to 10.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  {([1, 2, 3, 4, 5, 6, 7, 8, 9, 10] as ClassLevel[]).map((cls) => {
                    const enrolled = students.filter((s) => s.selectedClass === cls).length;
                    const subjCount = getSubjectsForPicker(cls).length;
                    const lessonCount =
                      customLessons.filter((l) => l.classLevel === cls).length +
                      quizzes.filter((q) => q.classLevel === cls).length;
                    return (
                      <div
                        key={cls}
                        className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1"
                      >
                        <p className="font-display text-base font-bold text-slate-900">
                          Class {cls}
                        </p>
                        <p className="text-xs text-slate-600 font-mono-num">
                          {enrolled} students
                        </p>
                        <p className="text-[11px] text-slate-500 font-mono-num">
                          {subjCount} subjects · {lessonCount} custom items
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Add & Manage Subjects */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                <form
                  onSubmit={handlePublishSubject}
                  className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-5 space-y-3.5 self-start"
                >
                  <div className="flex items-center gap-2.5">
                    <BookOpen className="h-5 w-5 text-sky-600" />
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      Add Custom Subject
                    </h2>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Title (English)
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={80}
                        value={subTitleEn}
                        onChange={(e) => setSubTitleEn(e.target.value)}
                        placeholder="e.g. Computer Science"
                        className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Title (हिंदी)
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={80}
                        value={subTitleHi}
                        onChange={(e) => setSubTitleHi(e.target.value)}
                        placeholder="e.g. कंप्यूटर विज्ञान"
                        className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Description (English)
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={200}
                      value={subDescEn}
                      onChange={(e) => setSubDescEn(e.target.value)}
                      placeholder="Coding basics, digital literacy, and logic"
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Description (हिंदी)
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={200}
                      value={subDescHi}
                      onChange={(e) => setSubDescHi(e.target.value)}
                      placeholder="कंप्यूटर मूल बातें और कोडिंग अभ्यास"
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Min Class
                      </label>
                      <select
                        value={subMinClass}
                        onChange={(e) => setSubMinClass(Number(e.target.value))}
                        className="w-full h-11 px-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((c) => (
                          <option key={c} value={c}>
                            Class {c}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Max Class
                      </label>
                      <select
                        value={subMaxClass}
                        onChange={(e) => setSubMaxClass(Number(e.target.value))}
                        className="w-full h-11 px-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((c) => (
                          <option key={c} value={c}>
                            Class {c}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Icon</label>
                      <select
                        value={subIconKey}
                        onChange={(e) => setSubIconKey(e.target.value as Subject['iconKey'])}
                        className="w-full h-11 px-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="science">Science</option>
                        <option value="math">Math</option>
                        <option value="evs">EVS</option>
                        <option value="social">Social</option>
                        <option value="english">English</option>
                        <option value="hindi">Hindi</option>
                        <option value="gk">GK</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Accent Color
                    </label>
                    <input
                      type="color"
                      value={subAccentHex}
                      onChange={(e) => setSubAccentHex(e.target.value)}
                      className="h-10 w-20 rounded-lg border border-slate-300 cursor-pointer"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={subSaving}
                    className="w-full min-h-[44px] rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold cursor-pointer"
                  >
                    {subSaving ? 'Saving Subject...' : 'Create Subject'}
                  </button>
                </form>

                <div className="lg:col-span-7 space-y-4">
                  <div className="bg-white rounded-3xl border border-slate-200 p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-display text-base font-bold text-slate-900">
                        Custom Subjects ({customSubjects.length})
                      </h3>
                      <Layers className="h-4 w-4 text-sky-600" />
                    </div>
                    {customSubjects.length === 0 ? (
                      <p className="text-sm text-slate-500">
                        No custom subjects added yet. Built-in curriculum for Classes 1–10 is active.
                      </p>
                    ) : (
                      <div className="space-y-2.5">
                        {customSubjects.map((cs) => (
                          <div
                            key={cs.id}
                            className="p-3.5 rounded-2xl border border-slate-200 flex items-center justify-between gap-3"
                          >
                            <div>
                              <p className="font-semibold text-slate-900 text-sm">
                                {cs.titleEn} / {cs.titleHi}
                              </p>
                              <p className="text-xs text-slate-500">
                                Classes {cs.minClass}–{cs.maxClass} · Slug: {cs.slug}
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => onDeleteCustomSubject(cs.id)}
                              aria-label="Delete custom subject"
                              className="min-h-[38px] min-w-[38px] rounded-xl text-slate-500 hover:bg-red-50 hover:text-red-700 flex items-center justify-center cursor-pointer"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Student Class Change Reports Queue */}
                  <div className="bg-white rounded-3xl border border-slate-200 p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-display text-base font-bold text-slate-900">
                        Student Class Change Requests ({reports.length})
                      </h3>
                      <span className="text-xs font-semibold text-amber-700 font-mono-num">
                        {pendingReports.length} pending
                      </span>
                    </div>
                    {reports.length === 0 ? (
                      <p className="text-sm text-slate-500">No class change requests submitted.</p>
                    ) : (
                      <div className="space-y-3">
                        {reports.map((rep) => (
                          <div
                            key={rep.id}
                            className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5"
                          >
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <div>
                                <p className="font-semibold text-sm text-slate-900">
                                  {rep.studentName} ·{' '}
                                  <span className="font-mono-num text-sky-700">
                                    Class {rep.currentClass} → Class {rep.requestedClass}
                                  </span>
                                </p>
                                <p className="text-[11px] text-slate-400 font-mono-num">
                                  UID: {rep.studentId}
                                </p>
                              </div>
                              <span
                                className={`inline-flex items-center gap-1 text-xs font-semibold ${
                                  rep.status === 'approved'
                                    ? 'text-emerald-700'
                                    : rep.status === 'rejected'
                                      ? 'text-red-700'
                                      : 'text-amber-700'
                                }`}
                              >
                                {rep.status === 'approved' && <CheckCircle2 className="h-4 w-4" />}
                                {rep.status === 'rejected' && <XCircle className="h-4 w-4" />}
                                {rep.status === 'pending' && <Clock className="h-4 w-4" />}
                                <span className="capitalize">{rep.status}</span>
                              </span>
                            </div>
                            <p className="text-xs text-slate-700">{rep.reason}</p>
                            {rep.status === 'pending' && (
                              <div className="flex flex-col sm:flex-row gap-2">
                                <input
                                  type="text"
                                  placeholder="Optional admin remark..."
                                  value={noteByReportId[rep.id] || ''}
                                  onChange={(e) =>
                                    setNoteByReportId((prev) => ({
                                      ...prev,
                                      [rep.id]: e.target.value,
                                    }))
                                  }
                                  maxLength={300}
                                  className="flex-1 h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm"
                                />
                                <button
                                  type="button"
                                  disabled={busyReportId === rep.id}
                                  onClick={async () => {
                                    setBusyReportId(rep.id);
                                    try {
                                      await onReviewReport(
                                        rep,
                                        'approved',
                                        noteByReportId[rep.id] || ''
                                      );
                                    } finally {
                                      setBusyReportId(null);
                                    }
                                  }}
                                  className="min-h-[40px] px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                                >
                                  Approve &amp; Update Class
                                </button>
                                <button
                                  type="button"
                                  disabled={busyReportId === rep.id}
                                  onClick={async () => {
                                    setBusyReportId(rep.id);
                                    try {
                                      await onReviewReport(
                                        rep,
                                        'rejected',
                                        noteByReportId[rep.id] || ''
                                      );
                                    } finally {
                                      setBusyReportId(null);
                                    }
                                  }}
                                  className="min-h-[40px] px-3.5 rounded-xl border border-red-300 text-red-700 hover:bg-red-50 text-xs font-semibold cursor-pointer"
                                >
                                  Reject
                                </button>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 5. Manage Uploaded Content */}
          {tab === 'manage-content' && (
            <div className="space-y-4">
              <div className="bg-white rounded-3xl border border-slate-200 p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <Logo size="xs" />
                  <div>
                    <h1 className="font-display text-xl font-bold text-slate-900">
                      Manage Uploaded Content ({unifiedContent.length})
                    </h1>
                    <p className="text-xs text-slate-500">
                      Inspect, filter, and remove uploaded PDFs, Videos, and Quizzes.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <select
                    value={contentTypeFilter}
                    onChange={(e) =>
                      setContentTypeFilter(e.target.value as 'all' | 'note' | 'video' | 'quiz')
                    }
                    className="h-10 px-3 rounded-xl border border-slate-300 text-xs sm:text-sm bg-white"
                  >
                    <option value="all">All Types</option>
                    <option value="note">Notes (PDF)</option>
                    <option value="video">Videos</option>
                    <option value="quiz">Quizzes</option>
                  </select>
                  <select
                    value={contentClassFilter}
                    onChange={(e) => setContentClassFilter(Number(e.target.value))}
                    className="h-10 px-3 rounded-xl border border-slate-300 text-xs sm:text-sm bg-white"
                  >
                    <option value={0}>All Classes</option>
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((c) => (
                      <option key={c} value={c}>
                        Class {c}
                      </option>
                    ))}
                  </select>
                  <div className="relative w-full sm:w-56">
                    <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={contentSearch}
                      onChange={(e) => setContentSearch(e.target.value)}
                      placeholder="Search title or subject..."
                      className="w-full h-10 pl-9 pr-3 rounded-xl border border-slate-300 text-xs sm:text-sm"
                    />
                  </div>
                </div>
              </div>

              {unifiedContent.length === 0 ? (
                <div className="bg-white rounded-3xl border border-slate-200 p-10 text-center space-y-3">
                  <p className="text-sm text-slate-500">
                    No uploaded content matches the selected filters.
                  </p>
                  <div className="flex flex-wrap justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => setTab('upload-notes')}
                      className="min-h-[40px] px-4 rounded-xl bg-sky-600 text-white text-xs font-semibold cursor-pointer"
                    >
                      Upload Notes (PDF)
                    </button>
                    <button
                      type="button"
                      onClick={() => setTab('upload-videos')}
                      className="min-h-[40px] px-4 rounded-xl border border-slate-300 text-slate-800 text-xs font-semibold cursor-pointer"
                    >
                      Upload Videos
                    </button>
                    <button
                      type="button"
                      onClick={() => setTab('create-quiz')}
                      className="min-h-[40px] px-4 rounded-xl border border-slate-300 text-slate-800 text-xs font-semibold cursor-pointer"
                    >
                      Create Quiz
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {unifiedContent.map((entry) => {
                    const isConfirming = confirmDeleteId === entry.id;
                    return (
                      <div
                        key={entry.id}
                        className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col justify-between gap-3"
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                            <span className="font-semibold text-sky-700 uppercase">
                              {entry.kind === 'note'
                                ? 'Note / PDF'
                                : entry.kind === 'video'
                                  ? 'Video Lesson'
                                  : 'Chapter Quiz'}
                            </span>
                            <span className="font-mono-num">
                              Class {entry.item.classLevel} · {entry.item.subjectId} · Ch{' '}
                              {entry.item.chapterNumber}
                            </span>
                          </div>
                          <h3 className="mt-1 font-display text-base font-bold text-slate-900">
                            {entry.item.title}
                          </h3>
                          <p className="mt-1 text-xs text-slate-600">
                            {entry.kind === 'quiz'
                              ? `${entry.item.questions.length} Questions · ${entry.item.timeLimitMinutes} min · ${entry.item.description}`
                              : entry.item.summary}
                          </p>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                          {entry.kind !== 'quiz' && entry.item.mediaUrl ? (
                            <a
                              href={entry.item.mediaUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1.5 text-xs font-semibold text-sky-700 hover:underline"
                            >
                              <ExternalLink className="h-3.5 w-3.5" />
                              <span>Open Uploaded Media</span>
                            </a>
                          ) : (
                            <span className="text-[11px] text-slate-400">
                              {entry.item.language === 'hi' ? 'हिंदी माध्यम' : 'English Medium'}
                            </span>
                          )}

                          {!isConfirming ? (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(entry.id)}
                              className="min-h-[36px] px-3 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-50 inline-flex items-center gap-1.5 cursor-pointer"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                              <span>Delete</span>
                            </button>
                          ) : (
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={async () => {
                                  if (entry.kind === 'quiz') {
                                    await onDeleteQuiz(entry.item.id);
                                  } else {
                                    await onDeleteCustomLesson(entry.item.id);
                                  }
                                  setConfirmDeleteId(null);
                                }}
                                className="min-h-[34px] px-3 rounded-lg bg-red-600 text-white text-xs font-semibold cursor-pointer"
                              >
                                Confirm Delete
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(null)}
                                className="min-h-[34px] px-2.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* 6. Student Progress */}
          {tab === 'student-progress' && (
            <div className="space-y-5">
              <div className="bg-white rounded-3xl border border-slate-200 p-5 flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <Logo size="xs" />
                  <div>
                    <h1 className="font-display text-xl font-bold text-slate-900">
                      Student Progress ({filteredStudents.length})
                    </h1>
                    <p className="text-xs text-slate-500">
                      Real-time completion metrics across Notes, Videos, and Quizzes.
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    value={studentClassFilter}
                    onChange={(e) => setStudentClassFilter(Number(e.target.value))}
                    className="h-10 px-3 rounded-xl border border-slate-300 text-xs sm:text-sm bg-white"
                  >
                    <option value={0}>All Classes</option>
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((c) => (
                      <option key={c} value={c}>
                        Class {c}
                      </option>
                    ))}
                  </select>
                  <div className="relative w-full sm:w-64">
                    <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={studentSearch}
                      onChange={(e) => setStudentSearch(e.target.value)}
                      placeholder="Search student name or UID..."
                      className="w-full h-10 pl-10 pr-3.5 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white rounded-2xl border border-slate-200 p-4">
                  <p className="text-xs font-semibold text-slate-500">Total Students</p>
                  <p className="mt-1 font-display text-2xl font-bold text-slate-900 font-mono-num">
                    {students.length}
                  </p>
                </div>
                <div className="bg-white rounded-2xl border border-slate-200 p-4">
                  <p className="text-xs font-semibold text-slate-500">Avg Notes Done</p>
                  <p className="mt-1 font-display text-2xl font-bold text-sky-700 font-mono-num">
                    {progressSummary.avgNotes}
                  </p>
                </div>
                <div className="bg-white rounded-2xl border border-slate-200 p-4">
                  <p className="text-xs font-semibold text-slate-500">Avg Videos Done</p>
                  <p className="mt-1 font-display text-2xl font-bold text-purple-700 font-mono-num">
                    {progressSummary.avgVideos}
                  </p>
                </div>
                <div className="bg-white rounded-2xl border border-slate-200 p-4">
                  <p className="text-xs font-semibold text-slate-500">Avg Quiz Score</p>
                  <p className="mt-1 font-display text-2xl font-bold text-emerald-700 font-mono-num">
                    {progressSummary.avgQuizPct}%
                  </p>
                </div>
              </div>

              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                        <th className="py-3.5 px-5">Student</th>
                        <th className="py-3.5 px-4">Class</th>
                        <th className="py-3.5 px-4">Medium</th>
                        <th className="py-3.5 px-4">Notes Done</th>
                        <th className="py-3.5 px-4">Videos Done</th>
                        <th className="py-3.5 px-4">Quizzes / Avg</th>
                        <th className="py-3.5 px-4">Auth</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-sm">
                      {filteredStudents.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-8 text-center text-slate-500 text-sm">
                            No student progress records match your filter.
                          </td>
                        </tr>
                      ) : (
                        filteredStudents.map((st) => {
                          const stAttempts = attemptsByStudent.get(st.uid) || [];
                          const stQuizAvg =
                            stAttempts.length > 0
                              ? Math.round(
                                  stAttempts.reduce((acc, a) => acc + a.percentage, 0) /
                                    stAttempts.length
                                )
                              : null;

                          return (
                            <tr key={st.uid} className="hover:bg-slate-50/70">
                              <td className="py-3.5 px-5">
                                <p className="font-semibold text-slate-900">{st.displayName}</p>
                                <p className="text-[11px] text-slate-400 font-mono-num">{st.uid}</p>
                              </td>
                              <td className="py-3.5 px-4 font-mono-num">
                                {st.selectedClass > 0 ? `Class ${st.selectedClass}` : 'Onboarding'}
                              </td>
                              <td className="py-3.5 px-4">
                                {st.language === 'hi'
                                  ? 'हिंदी'
                                  : st.language === 'en'
                                    ? 'English'
                                    : '—'}
                              </td>
                              <td className="py-3.5 px-4 font-mono-num">
                                {st.completedNoteIds.length}
                              </td>
                              <td className="py-3.5 px-4 font-mono-num">
                                {st.completedVideoIds.length}
                              </td>
                              <td className="py-3.5 px-4 font-mono-num">
                                {stAttempts.length > 0 ? (
                                  <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
                                    <Award className="h-3.5 w-3.5" />
                                    {stAttempts.length} ({stQuizAvg}%)
                                  </span>
                                ) : (
                                  <span className="text-slate-400">0</span>
                                )}
                              </td>
                              <td className="py-3.5 px-4 capitalize text-slate-600">
                                {st.authProvider}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* 7. Announcements */}
          {tab === 'announcements' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              <form
                onSubmit={handlePublishAnnouncement}
                className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-5 space-y-4 self-start"
              >
                <div className="flex items-center gap-2.5">
                  <Logo size="xs" />
                  <h1 className="font-display text-lg font-bold text-slate-900">
                    Publish Announcement
                  </h1>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Title</label>
                  <input
                    type="text"
                    required
                    maxLength={140}
                    value={annTitle}
                    onChange={(e) => setAnnTitle(e.target.value)}
                    placeholder="e.g. Unit Test Schedule Released"
                    className="w-full h-11 px-3.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Category
                    </label>
                    <select
                      value={annCategory}
                      onChange={(e) => setAnnCategory(e.target.value as AnnouncementCategory)}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      <option value="General">General</option>
                      <option value="Exam">Exam</option>
                      <option value="Content">Content</option>
                      <option value="Schedule">Schedule</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Target Class
                    </label>
                    <select
                      value={annTargetClass}
                      onChange={(e) => setAnnTargetClass(Number(e.target.value))}
                      className="w-full h-11 px-3 rounded-xl border border-slate-300 text-sm bg-white"
                    >
                      <option value={0}>All Classes (1–10)</option>
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((c) => (
                        <option key={c} value={c}>
                          Class {c}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Message</label>
                  <textarea
                    rows={4}
                    required
                    maxLength={1500}
                    value={annBody}
                    onChange={(e) => setAnnBody(e.target.value)}
                    placeholder="Write announcement details for students..."
                    className="w-full p-3.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
                <button
                  type="submit"
                  disabled={annSaving}
                  className="w-full min-h-[44px] rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold cursor-pointer"
                >
                  {annSaving ? 'Publishing...' : 'Publish Announcement'}
                </button>
              </form>

              <div className="lg:col-span-7 space-y-3">
                {announcements.length === 0 ? (
                  <div className="bg-white rounded-3xl border border-slate-200 p-8 text-center text-sm text-slate-500">
                    No announcements published yet.
                  </div>
                ) : (
                  announcements.map((ann) => (
                    <div
                      key={ann.id}
                      className="bg-white rounded-2xl border border-slate-200 p-4 flex items-start justify-between gap-3"
                    >
                      <div>
                        <p className="text-xs text-slate-500">
                          {ann.category} ·{' '}
                          {ann.targetClass === 0 ? 'All Classes' : `Class ${ann.targetClass}`}
                        </p>
                        <h3 className="font-display text-base font-bold text-slate-900 mt-0.5">
                          {ann.title}
                        </h3>
                        <p className="text-sm text-slate-600 mt-1">{ann.body}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onDeleteAnnouncement(ann.id)}
                        aria-label="Delete announcement"
                        className="min-h-[40px] min-w-[40px] rounded-xl text-slate-500 hover:bg-red-50 hover:text-red-700 flex items-center justify-center cursor-pointer"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
