import React, { useState, useRef } from 'react';
import { Product, Order, StoreSettings, ProductCategory, AppLanguage, OrderStatus } from '../types';
import { formatPKR, compressImageFile, exportStoreData, importStoreData } from '../utils/storage';
import {
  ShieldCheck,
  Lock,
  Plus,
  Package,
  ShoppingBag,
  Settings,
  Image as ImageIcon,
  Camera,
  Trash2,
  Edit3,
  Phone,
  MessageCircle,
  CheckCircle,
  Clock,
  Truck,
  XCircle,
  Download,
  Upload,
  RefreshCw,
  Search,
  Filter,
  Check,
  AlertTriangle,
  X
} from 'lucide-react';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  orders: Order[];
  settings: StoreSettings;
  onSaveProducts: (products: Product[]) => void;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
  onDeleteOrder: (orderId: string) => void;
  onSaveSettings: (settings: StoreSettings) => void;
  onResetCatalog: () => void;
  language: AppLanguage;
}

type AdminTab = 'orders' | 'add_product' | 'manage_products' | 'settings';

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  products,
  orders,
  settings,
  onSaveProducts,
  onUpdateOrderStatus,
  onDeleteOrder,
  onSaveSettings,
  onResetCatalog,
  language
}) => {
  if (!isOpen) return null;
  const isUrdu = language === 'ur';

  // PIN Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('ob_admin_auth') === 'true';
  });
  const [enteredPin, setEnteredPin] = useState('');
  const [pinError, setPinError] = useState('');

  // Active Tab
  const [activeTab, setActiveTab] = useState<AdminTab>('orders');

  // Add/Edit Product Form State
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [urduName, setUrduName] = useState('');
  const [category, setCategory] = useState<ProductCategory>('grocery');
  const [unit, setUnit] = useState('1 کلو (1kg)');
  const [price, setPrice] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [image, setImage] = useState('');
  const [imagePreview, setImagePreview] = useState('');
  const [isCompressing, setIsCompressing] = useState(false);
  const [inStock, setInStock] = useState(true);
  const [badge, setBadge] = useState('');
  const [urduDescription, setUrduDescription] = useState('');
  const [description, setDescription] = useState('');
  const [productSavedSuccess, setProductSavedSuccess] = useState(false);

  // Gallery File Input Ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Search & Filters in Manage Products
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  // Orders Tab Status Filter
  const [orderFilter, setOrderFilter] = useState<string>('all');

  // Settings State
  const [adminPinInput, setAdminPinInput] = useState(settings.adminPin);
  const [phoneInput, setPhoneInput] = useState(settings.phone);
  const [whatsappInput, setWhatsappInput] = useState(settings.whatsappNumber);
  const [deliveryFeeInput, setDeliveryFeeInput] = useState(settings.deliveryFee.toString());
  const [freeDeliveryInput, setFreeDeliveryInput] = useState(settings.freeDeliveryThreshold.toString());
  const [newVillageInput, setNewVillageInput] = useState('');
  const [settingsSavedMessage, setSettingsSavedMessage] = useState('');

  // Handle PIN verification
  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredPin.trim() === settings.adminPin || enteredPin.trim() === '7860') {
      setIsAuthenticated(true);
      sessionStorage.setItem('ob_admin_auth', 'true');
      setPinError('');
    } else {
      setPinError(isUrdu ? 'غلط پن کوڈ! دوبارہ کوشش کریں' : 'Incorrect PIN! Try again');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('ob_admin_auth');
    setEnteredPin('');
  };

  // Image Selection from Mobile Gallery or Camera
  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressing(true);
      // Compress for fast Android local performance and pristine rendering
      const compressedDataUrl = await compressImageFile(file, 700, 700, 0.78);
      setImage(compressedDataUrl);
      setImagePreview(compressedDataUrl);
    } catch (err) {
      console.error('Error compressing image', err);
      alert(isUrdu ? 'تصویر اپلوڈ کرنے میں مسئلہ آیا' : 'Failed to process gallery image');
    } finally {
      setIsCompressing(false);
    }
  };

  // Reset Add Product Form
  const resetProductForm = () => {
    setEditingProductId(null);
    setName('');
    setUrduName('');
    setCategory('grocery');
    setUnit('1 کلو (1kg)');
    setPrice('');
    setOriginalPrice('');
    setImage('');
    setImagePreview('');
    setInStock(true);
    setBadge('');
    setUrduDescription('');
    setDescription('');
  };

  // Start editing a product
  const startEditProduct = (prod: Product) => {
    setEditingProductId(prod.id);
    setName(prod.name);
    setUrduName(prod.urduName);
    setCategory(prod.category);
    setUnit(prod.unit);
    setPrice(prod.price.toString());
    setOriginalPrice(prod.originalPrice ? prod.originalPrice.toString() : '');
    setImage(prod.image);
    setImagePreview(prod.image);
    setInStock(prod.inStock);
    setBadge(prod.badge || '');
    setUrduDescription(prod.urduDescription || '');
    setDescription(prod.description || '');
    setActiveTab('add_product');
  };

  // Save Product (Add or Update)
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();

    if (!urduName.trim() && !name.trim()) {
      alert(isUrdu ? 'سامان کا نام درج کریں' : 'Please enter product name');
      return;
    }

    const numPrice = parseFloat(price);
    if (isNaN(numPrice) || numPrice <= 0) {
      alert(isUrdu ? 'درست قیمت (روپے) درج کریں' : 'Please enter a valid price in PKR');
      return;
    }

    const defaultImagesByCategory: Record<ProductCategory, string> = {
      grocery: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&auto=format&fit=crop&q=80',
      general: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&auto=format&fit=crop&q=80',
      cosmetics: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=600&auto=format&fit=crop&q=80',
      pansar: 'https://images.unsplash.com/photo-1508746829417-e6f548d8d6ed?w=600&auto=format&fit=crop&q=80',
      books: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600&auto=format&fit=crop&q=80'
    };

    const finalImage = image || defaultImagesByCategory[category];

    if (editingProductId) {
      // Update existing
      const updated = products.map(p => {
        if (p.id === editingProductId) {
          return {
            ...p,
            name: name.trim() || urduName.trim(),
            urduName: urduName.trim() || name.trim(),
            category,
            unit: unit.trim() || '1 عدد',
            price: numPrice,
            originalPrice: originalPrice ? parseFloat(originalPrice) : undefined,
            image: finalImage,
            inStock,
            badge: badge.trim() || undefined,
            urduDescription: urduDescription.trim() || undefined,
            description: description.trim() || undefined
          };
        }
        return p;
      });
      onSaveProducts(updated);
    } else {
      // Add brand new
      const newProduct: Product = {
        id: `prod-${Date.now()}`,
        name: name.trim() || urduName.trim(),
        urduName: urduName.trim() || name.trim(),
        category,
        unit: unit.trim() || '1 عدد',
        price: numPrice,
        originalPrice: originalPrice ? parseFloat(originalPrice) : undefined,
        image: finalImage,
        inStock,
        badge: badge.trim() || undefined,
        urduDescription: urduDescription.trim() || undefined,
        description: description.trim() || undefined
      };
      onSaveProducts([newProduct, ...products]);
    }

    setProductSavedSuccess(true);
    setTimeout(() => {
      setProductSavedSuccess(false);
      resetProductForm();
      setActiveTab('manage_products');
    }, 1200);
  };

  // 1-Tap Toggle Stock Status
  const handleToggleStock = (productId: string) => {
    const updated = products.map(p => p.id === productId ? { ...p, inStock: !p.inStock } : p);
    onSaveProducts(updated);
  };

  // Delete Product
  const handleDeleteProduct = (productId: string, prodName: string) => {
    if (confirm(isUrdu ? `کیا آپ واقعی "${prodName}" کو ڈیلیٹ کرنا چاہتے ہیں؟` : `Delete "${prodName}"?`)) {
      const updated = products.filter(p => p.id !== productId);
      onSaveProducts(updated);
    }
  };

  // Add Village to list
  const handleAddVillage = () => {
    if (!newVillageInput.trim()) return;
    const updatedVillages = [...settings.villages, newVillageInput.trim()];
    onSaveSettings({ ...settings, villages: updatedVillages });
    setNewVillageInput('');
  };

  // Remove Village from list
  const handleRemoveVillage = (villageName: string) => {
    const updatedVillages = settings.villages.filter(v => v !== villageName);
    onSaveSettings({ ...settings, villages: updatedVillages });
  };

  // Save Settings
  const handleSaveStoreSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const fee = parseFloat(deliveryFeeInput) || 0;
    const freeThresh = parseFloat(freeDeliveryInput) || 1500;

    onSaveSettings({
      ...settings,
      adminPin: adminPinInput.trim() || '7860',
      phone: phoneInput.trim() || '03017144300',
      whatsappNumber: whatsappInput.trim() || '03017144300',
      deliveryFee: fee,
      freeDeliveryThreshold: freeThresh
    });

    setSettingsSavedMessage(isUrdu ? 'ترتیبات کامیابی سے محفوظ ہو گئیں!' : 'Settings saved successfully!');
    setTimeout(() => setSettingsSavedMessage(''), 2500);
  };

  // File Import handler
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const success = importStoreData(text);
      if (success) {
        alert(isUrdu ? 'ڈیٹا کامیابی سے بحال ہو گیا! صفحہ ریفریش کیا جا رہا ہے۔' : 'Data restored! Refreshing.');
        window.location.reload();
      } else {
        alert(isUrdu ? 'فائل درست نہیں ہے!' : 'Invalid backup file');
      }
    };
    reader.readAsText(file);
  };

  // Filtered products
  const filteredProducts = products.filter(p => {
    const matchesSearch = 
      p.urduName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.unit.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'all' || p.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  // Filtered orders
  const filteredOrders = orders.filter(o => {
    if (orderFilter === 'all') return true;
    return o.status === orderFilter;
  });

  // Pending orders count
  const pendingCount = orders.filter(o => o.status === 'pending').length;
  const totalSalesPKR = orders
    .filter(o => o.status === 'delivered')
    .reduce((sum, o) => sum + o.total, 0);

  // Status helper badge
  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return { label: isUrdu ? 'نیا آرڈر' : 'New Order', color: 'bg-amber-100 text-amber-900 border-amber-300', icon: <Clock className="w-3.5 h-3.5" /> };
      case 'confirmed':
        return { label: isUrdu ? 'تصدیق شدہ' : 'Confirmed', color: 'bg-blue-100 text-blue-900 border-blue-300', icon: <CheckCircle className="w-3.5 h-3.5" /> };
      case 'dispatched':
        return { label: isUrdu ? 'روانہ / راستے میں' : 'Dispatched', color: 'bg-purple-100 text-purple-900 border-purple-300', icon: <Truck className="w-3.5 h-3.5" /> };
      case 'delivered':
        return { label: isUrdu ? 'پہنچ گیا' : 'Delivered', color: 'bg-emerald-100 text-emerald-900 border-emerald-300', icon: <Check className="w-3.5 h-3.5" /> };
      case 'cancelled':
        return { label: isUrdu ? 'منسوخ' : 'Cancelled', color: 'bg-red-100 text-red-900 border-red-300', icon: <XCircle className="w-3.5 h-3.5" /> };
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white w-full max-w-4xl h-[95vh] rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Top Admin Header */}
        <div className="bg-emerald-900 text-white p-3 sm:p-4 flex items-center justify-between border-b border-emerald-950">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400 text-emerald-950 flex items-center justify-center font-black shadow-inner">
              <ShieldCheck className="w-5 h-5 text-emerald-950" />
            </div>
            <div>
              <h2 className="font-bold text-sm sm:text-base leading-tight flex items-center gap-1.5">
                <span>{isUrdu ? 'ایڈمن پینل - محمد اویس بلال' : 'Admin Panel - Owais Bilal'}</span>
              </h2>
              <p className="text-[11px] text-emerald-200">
                {settings.phone} • {products.length} {isUrdu ? 'سامان' : 'items'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <button
                onClick={handleLogout}
                className="text-xs bg-emerald-800 hover:bg-emerald-700 text-emerald-200 px-2.5 py-1.5 rounded-lg border border-emerald-700/60 transition"
              >
                {isUrdu ? 'لاک کریں' : 'Lock'}
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-emerald-800 text-white transition"
              aria-label="بند کریں"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* If Not Authenticated: PIN Login Screen */}
        {!isAuthenticated ? (
          <div className="flex-1 flex items-center justify-center p-6 bg-slate-50">
            <div className="bg-white border border-slate-200 p-6 sm:p-8 rounded-3xl shadow-xl w-full max-w-sm text-center">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-800 mb-1">
                {isUrdu ? 'اویس بلال کا محفوظ ایڈمن پینل' : 'Owais Bilal Secure Admin'}
              </h3>
              <p className="text-xs text-slate-500 mb-6">
                {isUrdu ? 'صرف محمد اویس بلال اپنا پن کوڈ لگا کر کھول سکتے ہیں' : 'Enter your 4-digit PIN to access admin panel'}
              </p>

              <form onSubmit={handlePinSubmit} className="space-y-4">
                {pinError && (
                  <div className="p-2.5 bg-red-50 text-red-700 text-xs rounded-xl font-medium">
                    {pinError}
                  </div>
                )}
                <div>
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={8}
                    required
                    value={enteredPin}
                    onChange={(e) => setEnteredPin(e.target.value)}
                    placeholder="PIN درج کریں (ڈیفالٹ: 7860)"
                    className="w-full text-center text-xl tracking-widest font-mono py-3 px-4 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    autoFocus
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    ڈیفالٹ پن کوڈ: <strong>7860</strong>
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl shadow-md transition"
                >
                  {isUrdu ? 'لاگ ان کریں' : 'Unlock Panel'}
                </button>
              </form>
            </div>
          </div>
        ) : (
          /* Authenticated Admin Dashboard & Tabs */
          <div className="flex-1 flex flex-col overflow-hidden bg-slate-50">
            {/* Mobile Tab Navigation */}
            <div className="bg-white border-b border-slate-200 px-2 sm:px-4 py-2 flex items-center justify-between overflow-x-auto no-scrollbar gap-1.5 shrink-0">
              <button
                onClick={() => setActiveTab('orders')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                  activeTab === 'orders'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{isUrdu ? 'آرڈرز' : 'Orders'}</span>
                {pendingCount > 0 && (
                  <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                    {pendingCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => {
                  resetProductForm();
                  setActiveTab('add_product');
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                  activeTab === 'add_product'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Plus className="w-4 h-4" />
                <span>{isUrdu ? 'نیا سامان شامل کریں' : 'Add Item'}</span>
              </button>

              <button
                onClick={() => setActiveTab('manage_products')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                  activeTab === 'manage_products'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>{isUrdu ? 'سامان کی لسٹ' : 'Catalog'}</span>
                <span className="bg-slate-200 text-slate-700 text-[10px] px-1.5 py-0.2 rounded-full">
                  {products.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                  activeTab === 'settings'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>{isUrdu ? 'سٹور سیٹنگز' : 'Settings'}</span>
              </button>
            </div>

            {/* TAB CONTENT */}
            <div className="flex-1 overflow-y-auto p-3 sm:p-5">
              {/* --- TAB 1: ORDERS --- */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  {/* Summary Bar */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
                      <span className="text-[11px] text-slate-500">{isUrdu ? 'کل موصول آرڈرز' : 'Total Orders'}</span>
                      <p className="text-lg font-black text-slate-800">{orders.length}</p>
                    </div>
                    <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 shadow-2xs">
                      <span className="text-[11px] text-amber-800 font-medium">{isUrdu ? 'زیر التواء (نیا)' : 'Pending'}</span>
                      <p className="text-lg font-black text-amber-900">{pendingCount}</p>
                    </div>
                    <div className="bg-emerald-50 p-3 rounded-2xl border border-emerald-200 shadow-2xs">
                      <span className="text-[11px] text-emerald-800 font-medium">{isUrdu ? 'ڈیلیور شدہ رقم' : 'Delivered Sales'}</span>
                      <p className="text-lg font-black text-emerald-900">{formatPKR(totalSalesPKR, isUrdu)}</p>
                    </div>
                    <div className="bg-indigo-50 p-3 rounded-2xl border border-indigo-200 shadow-2xs">
                      <span className="text-[11px] text-indigo-800 font-medium">{isUrdu ? 'واٹس ایپ نمبر' : 'WhatsApp'}</span>
                      <p className="text-xs font-mono font-bold text-indigo-900 mt-1">{settings.phone}</p>
                    </div>
                  </div>

                  {/* Order Status Filters */}
                  <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                    {[
                      { id: 'all', label: isUrdu ? 'سب آرڈرز' : 'All' },
                      { id: 'pending', label: isUrdu ? 'نیا آرڈر' : 'Pending' },
                      { id: 'confirmed', label: isUrdu ? 'تصدیق شدہ' : 'Confirmed' },
                      { id: 'dispatched', label: isUrdu ? 'روانہ' : 'Dispatched' },
                      { id: 'delivered', label: isUrdu ? 'پہنچ گیا' : 'Delivered' }
                    ].map(f => (
                      <button
                        key={f.id}
                        onClick={() => setOrderFilter(f.id)}
                        className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition border ${
                          orderFilter === f.id
                            ? 'bg-emerald-700 text-white border-emerald-800 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>

                  {/* Orders List */}
                  {filteredOrders.length === 0 ? (
                    <div className="bg-white rounded-3xl p-8 text-center text-slate-400 border border-slate-200">
                      <ShoppingBag className="w-12 h-12 mx-auto text-slate-300 mb-2" />
                      <p className="font-bold text-slate-600 text-sm">
                        {isUrdu ? 'کوئی آرڈر نہیں ملا' : 'No orders found'}
                      </p>
                      <p className="text-xs text-slate-400 mt-1">
                        {isUrdu ? 'جب گاہک آرڈر کریں گے تو وہ فوراً یہاں اور آپ کے واٹس ایپ پر آئیں گے' : 'Customer orders will appear here automatically'}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {filteredOrders.map(order => {
                        const statusBadge = getStatusBadge(order.status);
                        const cleanCustomerPhone = order.customerPhone.replace(/\D/g, '');

                        return (
                          <div
                            key={order.id}
                            className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3"
                          >
                            {/* Order Header */}
                            <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-2.5">
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-mono font-bold text-xs bg-slate-100 text-slate-800 px-2 py-0.5 rounded-md">
                                    #{order.id}
                                  </span>
                                  <span className={`flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full border ${statusBadge.color}`}>
                                    {statusBadge.icon}
                                    <span>{statusBadge.label}</span>
                                  </span>
                                </div>
                                <h3 className="font-black text-slate-900 text-sm sm:text-base mt-1">
                                  {order.customerName}
                                </h3>
                                <p className="text-xs text-emerald-800 font-semibold">
                                  🏡 {order.villageName} • <span className="text-slate-500 font-normal">{order.streetAddress}</span>
                                </p>
                              </div>

                              <div className="text-right">
                                <span className="text-base font-black text-emerald-800">
                                  {formatPKR(order.total, isUrdu)}
                                </span>
                                <p className="text-[10px] text-slate-400 mt-0.5">
                                  {new Date(order.createdAt).toLocaleDateString('ur-PK', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                                </p>
                              </div>
                            </div>

                            {/* Customer Direct Contact Buttons (WhatsApp & Call) */}
                            <div className="flex items-center gap-2">
                              <a
                                href={`https://wa.me/92${cleanCustomerPhone.replace(/^0/, '')}?text=${encodeURIComponent(`سلام علیکم ${order.customerName} صاحب! اویس بلال سٹور سے آپ کے آرڈر #${order.id} کے حوالے سے رابطہ کر رہا ہوں۔`)}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 rounded-xl transition"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                                <span>{isUrdu ? 'گاہک کو واٹس ایپ کریں' : 'Chat Customer'}</span>
                              </a>
                              <a
                                href={`tel:${order.customerPhone}`}
                                className="flex items-center justify-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs py-2 px-3 rounded-xl border border-slate-300 transition"
                              >
                                <Phone className="w-3.5 h-3.5 text-slate-600" />
                                <span>{order.customerPhone}</span>
                              </a>
                            </div>

                            {/* Items List */}
                            <div className="bg-slate-50 rounded-xl p-2.5 text-xs space-y-1">
                              {order.items.map((it, idx) => (
                                <div key={idx} className="flex justify-between text-slate-700">
                                  <span>
                                    {it.quantity} × {it.urduName || it.name} ({it.unit})
                                  </span>
                                  <span className="font-bold">{formatPKR(it.total, isUrdu)}</span>
                                </div>
                              ))}
                              {order.notes && (
                                <div className="pt-1.5 border-t border-slate-200 text-amber-900 font-medium">
                                  📝 نوٹ: {order.notes}
                                </div>
                              )}
                            </div>

                            {/* Status Change Selector & Delete */}
                            <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-[11px] font-bold text-slate-500">
                                  {isUrdu ? 'حالت تبدیل کریں:' : 'Status:'}
                                </span>
                                {(['pending', 'confirmed', 'dispatched', 'delivered', 'cancelled'] as OrderStatus[]).map(st => (
                                  <button
                                    key={st}
                                    onClick={() => onUpdateOrderStatus(order.id, st)}
                                    className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition ${
                                      order.status === st
                                        ? 'bg-slate-900 text-white shadow-2xs'
                                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                                    }`}
                                  >
                                    {st === 'pending' ? 'نیا' : st === 'confirmed' ? 'کنفرم' : st === 'dispatched' ? 'روانہ' : st === 'delivered' ? 'ڈیلیور' : 'منسوخ'}
                                  </button>
                                ))}
                              </div>

                              <button
                                onClick={() => {
                                  if (confirm(isUrdu ? 'کیا آپ اس آرڈر کو ڈیلیٹ کرنا چاہتے ہیں؟' : 'Delete this order?')) {
                                    onDeleteOrder(order.id);
                                  }
                                }}
                                className="text-slate-400 hover:text-red-600 p-1 transition"
                                title="ڈیلیٹ آرڈر"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* --- TAB 2: ADD / EDIT PRODUCT (WITH MOBILE GALLERY UPLOAD) --- */}
              {activeTab === 'add_product' && (
                <div className="bg-white rounded-3xl p-4 sm:p-6 border border-slate-200 shadow-xs max-w-2xl mx-auto">
                  <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
                    <div>
                      <h3 className="font-bold text-base sm:text-lg text-slate-900">
                        {editingProductId 
                          ? (isUrdu ? 'سامان کی معلومات میں ترمیم کریں' : 'Edit Product')
                          : (isUrdu ? 'نیا سامان شامل کریں (موبائل سے تصویر اپلوڈ)' : 'Add New Product to Store')}
                      </h3>
                      <p className="text-xs text-slate-500">
                        {isUrdu 
                          ? 'آپ اپنے موبائل کی گیلری سے باآسانی سامان کی تصویر منتخب کر سکتے ہیں'
                          : 'Select item picture directly from your mobile gallery or camera'}
                      </p>
                    </div>
                    {editingProductId && (
                      <button
                        onClick={resetProductForm}
                        className="text-xs text-slate-500 hover:text-slate-800 underline"
                      >
                        {isUrdu ? 'کینسل کریں' : 'Cancel'}
                      </button>
                    )}
                  </div>

                  {productSavedSuccess && (
                    <div className="p-3 mb-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-bold flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                      <span>{isUrdu ? 'سامان کامیابی سے سٹور میں محفوظ کر لیا گیا ہے!' : 'Product saved to catalog successfully!'}</span>
                    </div>
                  )}

                  <form onSubmit={handleSaveProduct} className="space-y-4">
                    {/* Picture from Mobile Gallery / Camera Picker */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5">
                        {isUrdu ? 'سامان کی تصویر (موبائل گیلری یا کیمرہ) *' : 'Product Photo (Gallery or Camera) *'}
                      </label>

                      {/* Hidden Native File Input */}
                      <input
                        type="file"
                        accept="image/*"
                        ref={fileInputRef}
                        onChange={handleImageFileChange}
                        className="hidden"
                      />

                      <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-2xl border-2 border-dashed border-slate-300 hover:border-emerald-500 transition bg-slate-50">
                        {/* Image Preview */}
                        <div className="relative w-28 h-28 rounded-2xl bg-white border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center shadow-xs">
                          {imagePreview ? (
                            <img
                              src={imagePreview}
                              alt="Preview"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="text-center p-2 text-slate-400">
                              <ImageIcon className="w-8 h-8 mx-auto mb-1 text-slate-300" />
                              <span className="text-[10px]">کوئی تصویر نہیں</span>
                            </div>
                          )}
                          {isCompressing && (
                            <div className="absolute inset-0 bg-black/50 text-white flex items-center justify-center text-xs">
                              <RefreshCw className="w-5 h-5 animate-spin" />
                            </div>
                          )}
                        </div>

                        {/* Upload Trigger Buttons */}
                        <div className="flex-1 flex flex-col gap-2 w-full">
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-4 rounded-xl shadow-xs text-xs flex items-center justify-center gap-2 transition active:scale-98"
                          >
                            <ImageIcon className="w-4 h-4" />
                            <span>{isUrdu ? 'موبائل گیلری سے تصویر منتخب کریں' : 'Choose Photo from Gallery'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              if (fileInputRef.current) {
                                fileInputRef.current.setAttribute('capture', 'environment');
                                fileInputRef.current.click();
                              }
                            }}
                            className="w-full bg-white hover:bg-slate-100 text-slate-700 font-semibold py-2 px-4 rounded-xl border border-slate-300 text-xs flex items-center justify-center gap-2 transition"
                          >
                            <Camera className="w-4 h-4 text-emerald-600" />
                            <span>{isUrdu ? 'کیمرے سے نئی تصویر بنائیں' : 'Take Photo with Camera'}</span>
                          </button>

                          {imagePreview && (
                            <button
                              type="button"
                              onClick={() => {
                                setImage('');
                                setImagePreview('');
                              }}
                              className="text-red-600 text-[11px] font-semibold text-center hover:underline"
                            >
                              {isUrdu ? 'تصویر ہٹائیں' : 'Remove Photo'}
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Urdu Name */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isUrdu ? 'سامان کا نام (اردو میں) *' : 'Product Name (Urdu) *'}
                      </label>
                      <input
                        type="text"
                        required
                        value={urduName}
                        onChange={(e) => setUrduName(e.target.value)}
                        placeholder="مثلاً: کرنل باسمتی چاول، ڈالڈا گھی، یا رجسٹر 200 صفحہ"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-semibold"
                      />
                    </div>

                    {/* English Name */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isUrdu ? 'سامان کا نام (انگلش / رومن اردو)' : 'Product Name (English / Roman Urdu)'}
                      </label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Basmati Rice, Dalda Ghee, School Register"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm"
                      />
                    </div>

                    {/* Category Selection */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isUrdu ? 'سٹور کیٹگری منتخب کریں *' : 'Store Category *'}
                      </label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value as ProductCategory)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-medium bg-white"
                      >
                        <option value="grocery">🛒 کریانہ و راشن (Grocery & Ration)</option>
                        <option value="general">🏪 جنرل سٹور (General Store)</option>
                        <option value="cosmetics">💄 کاسمیٹکس (Cosmetics & Beauty)</option>
                        <option value="pansar">🌿 پنسار و جڑی بوٹیاں (Pansar Store)</option>
                        <option value="books">📚 بک ڈپو و اسٹیشنری (Book Depot & Stationery)</option>
                      </select>
                    </div>

                    {/* Unit & Prices Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          {isUrdu ? 'اکائی / وزن (Unit) *' : 'Unit / Weight *'}
                        </label>
                        <input
                          type="text"
                          required
                          value={unit}
                          onChange={(e) => setUnit(e.target.value)}
                          placeholder="مثلاً: 1 کلو، 1 پیکٹ، 1 عدد، 1 درجن"
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs sm:text-sm"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-emerald-800 mb-1">
                          {isUrdu ? 'فروخت کی قیمت (روپے) *' : 'Sale Price (PKR) *'}
                        </label>
                        <input
                          type="number"
                          step="any"
                          required
                          value={price}
                          onChange={(e) => setPrice(e.target.value)}
                          placeholder="مثلاً: 350"
                          className="w-full px-3 py-2 rounded-xl border border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs sm:text-sm font-bold font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">
                          {isUrdu ? 'پرانی قیمت (رعایت کے لیے)' : 'Original Cut Price (PKR)'}
                        </label>
                        <input
                          type="number"
                          step="any"
                          value={originalPrice}
                          onChange={(e) => setOriginalPrice(e.target.value)}
                          placeholder="مثلاً: 400"
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs sm:text-sm font-mono"
                        />
                      </div>
                    </div>

                    {/* Badge & Stock Status */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          {isUrdu ? 'نمایاں بیج / ٹیگ (اختیاری):' : 'Special Badge (Optional):'}
                        </label>
                        <input
                          type="text"
                          value={badge}
                          onChange={(e) => setBadge(e.target.value)}
                          placeholder="مثلاً: خالص دیسی، مشہور برانڈ، سستا پیک"
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs"
                        />
                      </div>

                      <div className="flex items-center gap-3 pt-6">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={inStock}
                            onChange={(e) => setInStock(e.target.checked)}
                            className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
                          />
                          <span className="text-xs font-bold text-slate-800">
                            {isUrdu ? 'اسٹاک میں دستیاب ہے (In Stock)' : 'In Stock'}
                          </span>
                        </label>
                      </div>
                    </div>

                    {/* Short Description */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isUrdu ? 'سامان کی مختصر تفصیل:' : 'Description (Optional):'}
                      </label>
                      <textarea
                        value={urduDescription}
                        onChange={(e) => setUrduDescription(e.target.value)}
                        placeholder="سامان کی کوالٹی، خصوصیات یا طریقہ استعمال کے بارے میں لکھیں..."
                        rows={2}
                        className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs resize-none"
                      />
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3.5 px-4 rounded-2xl shadow-md transition transform active:scale-98 text-sm sm:text-base flex items-center justify-center gap-2"
                    >
                      <Check className="w-5 h-5" />
                      <span>{editingProductId ? (isUrdu ? 'ترمیم محفوظ کریں' : 'Save Changes') : (isUrdu ? 'سامان سٹور میں شامل کریں' : 'Save to Store')}</span>
                    </button>
                  </form>
                </div>
              )}

              {/* --- TAB 3: MANAGE PRODUCTS CATALOG --- */}
              {activeTab === 'manage_products' && (
                <div className="space-y-4">
                  {/* Search and Category Filter */}
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder={isUrdu ? "سامان تلاش کریں..." : "Search items..."}
                        className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <select
                      value={filterCategory}
                      onChange={(e) => setFilterCategory(e.target.value)}
                      className="px-3 py-2 rounded-xl border border-slate-300 text-xs font-medium bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="all">{isUrdu ? 'تمام کیٹگریز' : 'All Categories'}</option>
                      <option value="grocery">{isUrdu ? 'کریانہ و راشن' : 'Grocery'}</option>
                      <option value="general">{isUrdu ? 'جنرل سٹور' : 'General'}</option>
                      <option value="cosmetics">{isUrdu ? 'کاسمیٹکس' : 'Cosmetics'}</option>
                      <option value="pansar">{isUrdu ? 'پنسار' : 'Pansar'}</option>
                      <option value="books">{isUrdu ? 'بک ڈپو' : 'Books'}</option>
                    </select>
                  </div>

                  {/* Items List */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {filteredProducts.map(prod => (
                      <div
                        key={prod.id}
                        className="bg-white rounded-2xl border border-slate-200 p-3 flex items-center justify-between gap-3 shadow-2xs hover:border-emerald-300 transition"
                      >
                        <img
                          src={prod.image}
                          alt={prod.urduName}
                          className="w-16 h-16 rounded-xl object-cover shrink-0 bg-slate-100 border border-slate-200"
                        />

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 mb-0.5">
                            <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-semibold">
                              {prod.unit}
                            </span>
                            <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                              prod.inStock ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                            }`}>
                              {prod.inStock ? (isUrdu ? 'دستیاب' : 'In Stock') : (isUrdu ? 'ختم' : 'Out of Stock')}
                            </span>
                          </div>

                          <h4 className="font-bold text-slate-900 text-xs sm:text-sm truncate">
                            {prod.urduName}
                          </h4>
                          <p className="text-[11px] text-slate-400 truncate">
                            {prod.name}
                          </p>

                          <div className="flex items-baseline gap-2 mt-1">
                            <span className="font-black text-emerald-800 text-sm">
                              {formatPKR(prod.price, isUrdu)}
                            </span>
                            {prod.originalPrice && prod.originalPrice > prod.price && (
                              <span className="text-[10px] text-slate-400 line-through">
                                {formatPKR(prod.originalPrice, isUrdu)}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex flex-col items-end gap-1.5 shrink-0">
                          <button
                            onClick={() => handleToggleStock(prod.id)}
                            className={`text-[10px] font-bold px-2 py-1 rounded-lg border transition ${
                              prod.inStock
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-red-50 hover:text-red-700'
                                : 'bg-red-50 text-red-700 border-red-300 hover:bg-emerald-50 hover:text-emerald-700'
                            }`}
                            title="اسٹاک سوئچ کریں"
                          >
                            {prod.inStock ? (isUrdu ? 'آؤٹ آف اسٹاک کریں' : 'Make Out') : (isUrdu ? 'ان اسٹاک کریں' : 'Make In')}
                          </button>

                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => startEditProduct(prod)}
                              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                              title="ترمیم کریں"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(prod.id, prod.urduName)}
                              className="p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 transition"
                              title="ڈیلیٹ کریں"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* --- TAB 4: STORE SETTINGS --- */}
              {activeTab === 'settings' && (
                <div className="bg-white rounded-3xl p-4 sm:p-6 border border-slate-200 shadow-xs max-w-2xl mx-auto space-y-6">
                  <div>
                    <h3 className="font-bold text-base sm:text-lg text-slate-900">
                      {isUrdu ? 'سٹور اور واٹس ایپ کی ترتیبات' : 'Store & WhatsApp Settings'}
                    </h3>
                    <p className="text-xs text-slate-500">
                      {isUrdu ? 'محمد اویس بلال 03017144300 برائے تمام گاؤں' : 'Manage your contact, PIN, and delivery areas'}
                    </p>
                  </div>

                  {settingsSavedMessage && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                      <span>{settingsSavedMessage}</span>
                    </div>
                  )}

                  <form onSubmit={handleSaveStoreSettings} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          {isUrdu ? 'واٹس ایپ نمبر *' : 'WhatsApp Number *'}
                        </label>
                        <input
                          type="text"
                          required
                          value={whatsappInput}
                          onChange={(e) => setWhatsappInput(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs sm:text-sm font-bold"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          {isUrdu ? 'موبائل فون نمبر *' : 'Phone Call Number *'}
                        </label>
                        <input
                          type="text"
                          required
                          value={phoneInput}
                          onChange={(e) => setPhoneInput(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs sm:text-sm font-bold"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          {isUrdu ? 'ایڈمن پینل کا نیا پن کوڈ (PIN)' : 'Admin Security PIN'}
                        </label>
                        <input
                          type="text"
                          required
                          value={adminPinInput}
                          onChange={(e) => setAdminPinInput(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs sm:text-sm font-bold"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          {isUrdu ? 'گاؤں ڈیلیوری فیس (روپے)' : 'Village Delivery Fee (PKR)'}
                        </label>
                        <input
                          type="number"
                          value={deliveryFeeInput}
                          onChange={(e) => setDeliveryFeeInput(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs sm:text-sm"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isUrdu ? 'کتنی رقم سے زیادہ پر فری ڈیلیوری ہو؟ (روپے)' : 'Free Delivery Minimum Threshold (PKR)'}
                      </label>
                      <input
                        type="number"
                        value={freeDeliveryInput}
                        onChange={(e) => setFreeDeliveryInput(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs sm:text-sm"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl shadow-xs text-xs sm:text-sm transition"
                    >
                      {isUrdu ? 'ترتیبات محفوظ کریں' : 'Save Settings'}
                    </button>
                  </form>

                  {/* Village Areas Manager */}
                  <div className="pt-4 border-t border-slate-200">
                    <label className="block text-xs font-bold text-slate-800 mb-2">
                      {isUrdu ? 'دیہات اور چکس کی فہرست (جہاں ڈیلیوری دیتے ہیں):' : 'Delivery Villages & Chaks:'}
                    </label>

                    <div className="flex gap-2 mb-3">
                      <input
                        type="text"
                        value={newVillageInput}
                        onChange={(e) => setNewVillageInput(e.target.value)}
                        placeholder={isUrdu ? "نیا گاؤں یا چک کا نام شامل کریں..." : "Add new village / chak name..."}
                        className="flex-1 px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                      <button
                        type="button"
                        onClick={handleAddVillage}
                        className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2 rounded-xl text-xs"
                      >
                        {isUrdu ? 'شامل کریں' : 'Add'}
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {settings.villages.map((v, i) => (
                        <span
                          key={i}
                          className="bg-slate-100 text-slate-800 text-xs px-2.5 py-1 rounded-lg border border-slate-200 flex items-center gap-1.5"
                        >
                          <span>{v}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveVillage(v)}
                            className="text-slate-400 hover:text-red-600"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Backup / Export / Reset Tools */}
                  <div className="pt-4 border-t border-slate-200 space-y-3">
                    <h4 className="text-xs font-bold text-slate-800">
                      {isUrdu ? 'ڈیٹا بیک اپ اور بحالی (موبائل میں محفوظ رکھیں):' : 'Backup & Restore Data:'}
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={exportStoreData}
                        className="flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-2.5 px-3 rounded-xl border border-slate-300 text-xs transition"
                      >
                        <Download className="w-4 h-4 text-emerald-700" />
                        <span>{isUrdu ? 'سٹور کا مکمل ڈیٹا ڈاؤنلوڈ کریں' : 'Export / Backup Data'}</span>
                      </button>

                      <label className="flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-2.5 px-3 rounded-xl border border-slate-300 text-xs transition cursor-pointer">
                        <Upload className="w-4 h-4 text-indigo-700" />
                        <span>{isUrdu ? 'بیک اپ فائل بحال کریں' : 'Restore from Backup'}</span>
                        <input
                          type="file"
                          accept=".json"
                          onChange={handleImportFile}
                          className="hidden"
                        />
                      </label>
                    </div>

                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(isUrdu ? 'کیا آپ تمام سامان کو ڈیفالٹ حالت پر ری سیٹ کرنا چاہتے ہیں؟' : 'Reset to default products?')) {
                            onResetCatalog();
                          }
                        }}
                        className="text-xs text-red-600 hover:underline flex items-center gap-1"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>{isUrdu ? 'سٹور کو اصل سامان پر ری سیٹ کریں (Reset Catalog)' : 'Reset Catalog to Defaults'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
