import React, { useState } from 'react';
import { PurchasedTicket } from '../types';
import { useApp } from '../context/AppContext';
import {
  X,
  Calendar,
  Check,
  Download,
  Trash2,
  Copy,
  AlertTriangle,
  ShieldCheck,
  UserCheck,
  RotateCcw,
  Mail,
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { downloadTicketPass } from '../utils/downloadTicket';
import { emailTicketService } from '../services/emailTicketService';
import { triggerHaptic } from '../utils/haptics';

interface VirtualTicketPassProps {
  ticket: PurchasedTicket;
  onClose: () => void;
}

export const VirtualTicketPass: React.FC<VirtualTicketPassProps> = ({ ticket, onClose }) => {
  const { showToast, formatKsh, setCurrentPage, deleteTicket } = useApp();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const handleCopyCode = () => {
    triggerHaptic('light');
    navigator.clipboard.writeText(ticket.ticketCode);
    setCopiedCode(true);
    showToast(`Pass code ${ticket.ticketCode} copied to clipboard!`);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handleDownload = () => {
    triggerHaptic('medium');
    downloadTicketPass(ticket);
    showToast(`Pass downloaded (Eventra-Pass-${ticket.ticketCode || ticket.orderNumber}.png)`);
  };

  const handleSyncToAppCalendar = () => {
    triggerHaptic('success');
    showToast(`Added to in-app schedule on ${ticket.date.split(',')[1] || ticket.date}!`);
    onClose();
    setCurrentPage('tickets');
  };

  const handleDelete = () => {
    triggerHaptic('medium');
    deleteTicket(ticket.ticketId);
    onClose();
  };

  const isAdmitted = ticket.status === 'used';
  const isRefunded = ticket.status === 'refunded';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-sm sm:max-w-md my-auto bg-[#111317] rounded-[32px] shadow-2xl border border-[#1f2229] overflow-hidden text-[#f4f4f6]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Dismiss Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-black/60 hover:bg-black/85 text-white flex items-center justify-center transition-colors cursor-pointer border border-white/15"
          aria-label="Close pass"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header / Event Image Banner */}
        <div className="relative h-44 w-full bg-[#090a0d] overflow-hidden">
          <img
            src={ticket.eventImage}
            alt={ticket.eventTitle}
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#111317] via-[#111317]/50 to-transparent" />

          {/* Pass Status Badge */}
          <div className="absolute top-4 left-4">
            {isRefunded ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold tracking-wide uppercase shadow-sm bg-rose-500/90 text-white">
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Refunded ({formatKsh(ticket.refundAmount || ticket.totalPaid)})</span>
              </span>
            ) : isAdmitted ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold tracking-wide uppercase shadow-sm bg-[#1c1f28] text-[#9496a1] border border-[#262a36]">
                <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Admitted ({ticket.checkedInAt || 'Verified'})</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold tracking-wide uppercase shadow-sm bg-emerald-500 text-white">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Verified Admission Pass</span>
              </span>
            )}
          </div>

          <div className="absolute bottom-3 left-4 right-4 text-white">
            <span className="text-[11px] font-semibold text-[#9496a1] uppercase tracking-wider block">
              {ticket.city}, Kenya
            </span>
            <h3 className="text-base sm:text-lg font-bold leading-tight truncate">
              {ticket.eventTitle}
            </h3>
          </div>
        </div>

        {/* Ticket Body with Details */}
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3 text-xs bg-[#17191f] rounded-2xl p-4 border border-[#1f2229]">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#646875] block">
                Date & Time
              </span>
              <span className="font-semibold text-[#f4f4f6]">
                {ticket.date.split(',')[1] || ticket.date} · {ticket.time}
              </span>
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-[#646875] block">
                Admission Tier
              </span>
              <span className="font-semibold text-[#f4f4f6]">
                {ticket.groupTierName || (ticket.ticketType === 'group' ? 'Group Pass' : 'Personal Pass')} ({ticket.quantity} Guest{ticket.quantity > 1 ? 's' : ''})
              </span>
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-[#646875] block">
                Passholder
              </span>
              <span className="font-medium text-[#f4f4f6] truncate block">
                {ticket.holderName}
              </span>
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-[#646875] block">
                Status
              </span>
              <span className="font-medium text-emerald-400 truncate block">
                Active & Synced
              </span>
            </div>

            <div className="col-span-2 pt-2 border-t border-[#1f2229]">
              <span className="text-[10px] uppercase font-bold text-[#646875] block">
                Venue Location
              </span>
              <span className="font-medium text-[#9496a1] truncate block">
                {ticket.venue} ({ticket.address})
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs px-1 text-[#9496a1]">
            <span>Method: <strong className="text-[#f4f4f6] uppercase">{ticket.paymentMethod}</strong></span>
            <span className="font-mono text-[11px] uppercase bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20 text-emerald-400 font-bold">
              {isRefunded ? 'Refunded' : `Paid: ${formatKsh(ticket.totalPaid)}`}
            </span>
          </div>

          {/* Perforated Divider */}
          <div className="relative py-2 flex items-center">
            <div className="w-5 h-5 -ml-8.5 rounded-full bg-[#090a0d] border-r border-[#1f2229]" />
            <div className="flex-1 border-t-2 border-dashed border-[#1f2229] mx-2" />
            <div className="w-5 h-5 -mr-8.5 rounded-full bg-[#090a0d] border-l border-[#1f2229]" />
          </div>

          {/* Apple Pass Style QR Code & Verification Block */}
          <div className="bg-[#17191f] p-5 rounded-2xl border border-[#1f2229] flex flex-col items-center text-center space-y-3.5">
            {/* Crisp Digital Pass QR Code with clean high contrast dark frame */}
            <div className="p-3 bg-white rounded-2xl shadow-sm border border-neutral-200 inline-block">
              <QRCodeSVG
                value={`EVENTRA:PASS:${ticket.ticketCode}:${ticket.ticketId}`}
                size={148}
                level="H"
                includeMargin={false}
              />
            </div>

            {/* Distinct Monospace Code Display */}
            <div className="w-full p-3.5 rounded-xl bg-[#090a0d] border border-[#1f2229] flex items-center justify-between gap-3 shadow-2xs">
              <div className="text-left">
                <span className="text-[10px] uppercase tracking-wider font-bold text-[#646875] block">
                  Distinct Ticket Code
                </span>
                <span className="text-base sm:text-lg font-mono font-black tracking-wider text-emerald-400">
                  {ticket.ticketCode}
                </span>
              </div>

              <button
                type="button"
                onClick={handleCopyCode}
                className="py-1.5 px-3 rounded-lg bg-[#17191f] hover:bg-emerald-500 hover:text-white border border-[#1f2229] text-xs font-semibold text-[#f4f4f6] transition-all flex items-center gap-1.5 cursor-pointer"
                title="Copy Code"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCode ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="w-full flex items-center justify-between text-[11px] font-mono text-[#646875]">
              <span>Order: {ticket.orderNumber}</span>
              <span>Ref: {ticket.transactionRef}</span>
            </div>
          </div>

          {/* Automated Email Pass Delivery Card */}
          <div className="p-3 rounded-2xl bg-[#16181f] border border-[#232733] flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0">
                <Mail className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block">
                  Delivered to Email
                </span>
                <span className="text-white font-medium truncate block text-xs">
                  {ticket.holderEmail || 'buyer@eventra.com'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                emailTicketService.openMailClientVoucher(ticket);
                showToast(`Opened email voucher for ${ticket.holderEmail || 'registered buyer'}`);
              }}
              className="px-2.5 py-1.5 rounded-lg border border-[#262934] bg-[#1a1d26] hover:bg-emerald-500 hover:text-white text-[11px] font-semibold text-emerald-400 transition-colors cursor-pointer shrink-0"
              title="Resend / View Email Pass Voucher"
            >
              Resend
            </button>
          </div>

          {/* Delete Confirmation Warning */}
          {showDeleteConfirm ? (
            <div className="p-4 rounded-2xl bg-red-950/40 border border-red-800/80 space-y-3">
              <div className="flex items-start gap-2.5 text-red-300">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
                <div className="text-xs">
                  <p className="font-bold">Delete this digital pass?</p>
                  <p className="text-red-300/80 mt-0.5">
                    This will remove the ticket from your digital wallet and cloud passbook.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleDelete}
                  className="py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  Confirm Delete
                </button>
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="py-2.5 rounded-xl border border-[#1f2229] bg-[#17191f] text-[#f4f4f6] text-xs font-medium hover:bg-[#1f2229] cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            /* Remade Pass Actions: Print and Share Removed As Requested */
            <div className="space-y-2 pt-1">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleDownload}
                  className="h-11 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm active:scale-98"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Pass</span>
                </button>

                <button
                  onClick={handleSyncToAppCalendar}
                  className="h-11 rounded-xl border border-[#1f2229] bg-[#17191f] hover:bg-[#1f2229] text-xs font-semibold text-[#f4f4f6] transition-colors flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                >
                  <Calendar className="w-4 h-4 text-emerald-400" />
                  <span>Add to Calendar</span>
                </button>
              </div>

              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="w-full h-10 rounded-xl border border-red-500/20 bg-red-950/20 hover:bg-red-900/30 text-xs font-medium text-red-400 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Digital Ticket</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
