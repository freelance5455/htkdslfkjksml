import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  CheckCircle2, 
  RefreshCw, 
  Zap, 
  ShieldCheck, 
  Layers, 
  Server, 
  Globe, 
  Cpu, 
  Radio, 
  ArrowUpRight, 
  Clock, 
  AlertCircle,
  Database,
  ExternalLink
} from 'lucide-react';

export interface BlockchainNodeStatus {
  id: string;
  name: string;
  chain: 'Bitcoin' | 'Ethereum' | 'Solana' | 'Base' | 'Polygon' | 'IMSI Telecom';
  networkType: 'Mainnet' | 'Cluster' | 'Carrier BTS';
  blockHeight: number;
  latestBlockHash: string;
  latencyMs: number;
  syncStatus: 'Synced' | 'Syncing';
  syncProgressPercent: number;
  gasOrFee: string;
  peersConnected: number;
  rpcEndpoint: string;
  lastUpdated: string;
}

const INITIAL_NODES: BlockchainNodeStatus[] = [
  {
    id: 'node-btc',
    name: 'Bitcoin Taproot Core Full Node',
    chain: 'Bitcoin',
    networkType: 'Mainnet',
    blockHeight: 892415,
    latestBlockHash: '00000000000000000002ab4c19...8f2a',
    latencyMs: 14,
    syncStatus: 'Synced',
    syncProgressPercent: 100,
    gasOrFee: '12 sat/vB',
    peersConnected: 38,
    rpcEndpoint: 'https://btc.juhnkrixmusika.pages.dev/rpc',
    lastUpdated: 'Just now'
  },
  {
    id: 'node-eth',
    name: 'Ethereum Execution Client (Geth + Lighthouse)',
    chain: 'Ethereum',
    networkType: 'Mainnet',
    blockHeight: 21849102,
    latestBlockHash: '0x8f3c7e...b941',
    latencyMs: 18,
    syncStatus: 'Synced',
    syncProgressPercent: 100,
    gasOrFee: '16.4 Gwei',
    peersConnected: 54,
    rpcEndpoint: 'https://mainnet.infura.io/v3/juhnkrix-sovereign',
    lastUpdated: '1s ago'
  },
  {
    id: 'node-sol',
    name: 'Solana High-Throughput RPC Validator',
    chain: 'Solana',
    networkType: 'Cluster',
    blockHeight: 298104882,
    latestBlockHash: '5YghK...9x2A',
    latencyMs: 24,
    syncStatus: 'Synced',
    syncProgressPercent: 100,
    gasOrFee: '0.000005 SOL',
    peersConnected: 1820,
    rpcEndpoint: 'https://api.mainnet-beta.solana.com',
    lastUpdated: '400ms ago'
  },
  {
    id: 'node-base',
    name: 'Base L2 Rollup Sequencer',
    chain: 'Base',
    networkType: 'Mainnet',
    blockHeight: 25194012,
    latestBlockHash: '0x3a91...4e88',
    latencyMs: 9,
    syncStatus: 'Synced',
    syncProgressPercent: 100,
    gasOrFee: '0.008 Gwei',
    peersConnected: 42,
    rpcEndpoint: 'https://mainnet.base.org',
    lastUpdated: 'Just now'
  },
  {
    id: 'node-poly',
    name: 'Polygon PoS Bor Client',
    chain: 'Polygon',
    networkType: 'Mainnet',
    blockHeight: 67182930,
    latestBlockHash: '0xbb21...7710',
    latencyMs: 22,
    syncStatus: 'Synced',
    syncProgressPercent: 100,
    gasOrFee: '31 Gwei',
    peersConnected: 65,
    rpcEndpoint: 'https://polygon-rpc.com',
    lastUpdated: '2s ago'
  },
  {
    id: 'node-imsi',
    name: 'IMSI 62130 Carrier Settlement Gateway',
    chain: 'IMSI Telecom',
    networkType: 'Carrier BTS',
    blockHeight: 148209,
    latestBlockHash: 'IMSI-TX-7071918280-99',
    latencyMs: 5,
    syncStatus: 'Synced',
    syncProgressPercent: 100,
    gasOrFee: '₦0.00 Tariff',
    peersConnected: 120,
    rpcEndpoint: 'http://142.250.190.46:3000/api/imsi-sync',
    lastUpdated: 'Real-time'
  }
];

interface CrossChainSyncMonitorProps {
  onShowToast?: (msg: string) => void;
}

export const CrossChainSyncMonitor: React.FC<CrossChainSyncMonitorProps> = ({ onShowToast }) => {
  const [nodes, setNodes] = useState<BlockchainNodeStatus[]>(INITIAL_NODES);
  const [isResyncing, setIsResyncing] = useState<boolean>(false);
  const [autoSync, setAutoSync] = useState<boolean>(true);
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<string>(new Date().toLocaleTimeString());

  // Periodically simulate live block increments and node health
  useEffect(() => {
    if (!autoSync) return;

    const interval = setInterval(() => {
      setNodes(prev => prev.map(node => {
        const blockInc = Math.random() > 0.4 ? 1 : 0;
        const newLatency = Math.max(4, Math.floor(node.latencyMs + (Math.random() * 6 - 3)));
        return {
          ...node,
          blockHeight: node.blockHeight + blockInc,
          latencyMs: newLatency,
          lastUpdated: 'Just now'
        };
      }));
      setLastSyncTimestamp(new Date().toLocaleTimeString());
    }, 4000);

    return () => clearInterval(interval);
  }, [autoSync]);

  const handleForceResync = async () => {
    setIsResyncing(true);
    onShowToast?.('🔄 Re-syncing all cross-chain blockchain nodes & carrier RPC gateways...');

    // Put all nodes into 'Syncing' state
    setNodes(prev => prev.map(n => ({
      ...n,
      syncStatus: 'Syncing',
      syncProgressPercent: 92 + Math.floor(Math.random() * 6)
    })));

    // Reconcile and set back to Synced
    setTimeout(() => {
      setNodes(prev => prev.map(n => ({
        ...n,
        syncStatus: 'Synced',
        syncProgressPercent: 100,
        blockHeight: n.blockHeight + 2,
        latencyMs: Math.max(4, Math.floor(n.latencyMs * 0.85)),
        lastUpdated: 'Just now'
      })));
      setIsResyncing(false);
      setLastSyncTimestamp(new Date().toLocaleTimeString());
      onShowToast?.('✓ All 6 cross-chain blockchain nodes are 100% Synced & healthy!');
    }, 1800);
  };

  const allSynced = nodes.every(n => n.syncStatus === 'Synced');
  const avgLatency = Math.round(nodes.reduce((acc, curr) => acc + curr.latencyMs, 0) / nodes.length);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="bg-slate-950 border-2 border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden space-y-6"
    >
      <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-black uppercase tracking-wider">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>CROSS-CHAIN BLOCKCHAIN NODE SYNC STATUS & RPC HEALTH</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-100 flex items-center space-x-2">
            <span>Multi-Chain Decentralized Node Monitor</span>
          </h3>
          <p className="text-xs text-slate-400 max-w-xl">
            Live synchronization telemetry tracking Bitcoin, Ethereum, Solana, Base, Polygon, and IMSI telecommunication RPC nodes in real-time.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 flex items-center space-x-2">
            <span className={`w-2.5 h-2.5 rounded-full ${allSynced ? 'bg-emerald-400 animate-ping' : 'bg-amber-400 animate-spin'}`} />
            <span className="font-bold">{allSynced ? 'ALL NODES SYNCED' : 'SYNCING IN PROGRESS'}</span>
          </div>

          <button
            onClick={handleForceResync}
            disabled={isResyncing}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-lg shadow-emerald-500/20 transition-all hover:scale-105 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 text-slate-950 ${isResyncing ? 'animate-spin' : ''}`} />
            <span>{isResyncing ? 'SYNCING NODES...' : 'FORCE RESYNC ALL'}</span>
          </button>
        </div>
      </div>

      {/* Global Telemetry Summary Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 relative z-10">
        <div className="bg-slate-900/90 border border-emerald-500/20 rounded-2xl p-3.5 flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-slate-400 font-bold uppercase">Average Latency</div>
            <div className="text-base font-black text-emerald-300">{avgLatency} ms</div>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-blue-500/20 rounded-2xl p-3.5 flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-slate-400 font-bold uppercase">Active RPC Nodes</div>
            <div className="text-base font-black text-blue-300">{nodes.length} / {nodes.length} Active</div>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-amber-500/20 rounded-2xl p-3.5 flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-slate-400 font-bold uppercase">Consensus Status</div>
            <div className="text-base font-black text-amber-300">100% Finalized</div>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-purple-500/20 rounded-2xl p-3.5 flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-slate-400 font-bold uppercase">Last Heartbeat</div>
            <div className="text-base font-mono font-bold text-purple-300">{lastSyncTimestamp}</div>
          </div>
        </div>
      </div>

      {/* Nodes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 relative z-10">
        {nodes.map(node => {
          const isSynced = node.syncStatus === 'Synced';
          return (
            <motion.div
              key={node.id}
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2 }}
              className={`bg-slate-900/90 border-2 rounded-2xl p-4.5 space-y-3 transition-all ${
                isSynced 
                  ? 'border-emerald-500/30 hover:border-emerald-400' 
                  : 'border-amber-500/50 hover:border-amber-400 bg-amber-950/20'
              }`}
            >
              {/* Top Row: Name and Status Badge */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center space-x-1.5">
                    <span className="font-extrabold text-sm text-slate-100">{node.chain}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                      {node.networkType}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 truncate max-w-[200px]">
                    {node.name}
                  </div>
                </div>

                {/* Status Indicator Badge */}
                <div className={`px-2.5 py-1 rounded-full text-[10px] font-black tracking-wide flex items-center space-x-1 border ${
                  isSynced
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-400/40 shadow-sm shadow-emerald-500/20'
                    : 'bg-amber-500/20 text-amber-300 border-amber-400/40 animate-pulse'
                }`}>
                  {isSynced ? (
                    <>
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      <span>SYNCED</span>
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-3 h-3 text-amber-400 animate-spin" />
                      <span>SYNCING ({node.syncProgressPercent}%)</span>
                    </>
                  )}
                </div>
              </div>

              {/* Middle Row: Block Height & Latency */}
              <div className="grid grid-cols-2 gap-2 bg-slate-950/80 rounded-xl p-2.5 border border-slate-800 text-xs">
                <div>
                  <div className="text-[10px] text-slate-500 font-bold uppercase">Block Height</div>
                  <div className="font-mono font-bold text-amber-200 truncate">
                    #{node.blockHeight.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 font-bold uppercase">Node Latency</div>
                  <div className={`font-bold flex items-center space-x-1 ${
                    node.latencyMs < 20 ? 'text-emerald-400' : 'text-amber-300'
                  }`}>
                    <span>{node.latencyMs} ms</span>
                    <span className="text-[10px] text-slate-500">({node.peersConnected} peers)</span>
                  </div>
                </div>
              </div>

              {/* Bottom Row: Gas / Fees and Endpoint */}
              <div className="space-y-1.5 text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                <div className="flex justify-between items-center">
                  <span>Network Gas / Fee:</span>
                  <span className="font-bold text-slate-200">{node.gasOrFee}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Latest Hash:</span>
                  <span className="font-mono text-[10px] text-slate-300 truncate max-w-[140px]">
                    {node.latestBlockHash}
                  </span>
                </div>
              </div>

              {/* Progress bar if syncing */}
              {!isSynced && (
                <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full transition-all duration-300"
                    style={{ width: `${node.syncProgressPercent}%` }}
                  />
                </div>
              )}
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
};
