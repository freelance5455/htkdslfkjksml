import React, { useState } from 'react';
import { Download, Smartphone, Apple, Monitor, Share2, Copy, Check, X, Sparkles, ExternalLink } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ isOpen, onClose, onToast }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [activeDeviceTab, setActiveDeviceTab] = useState<'android' | 'ios' | 'pc'>('android');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = window.location.href;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentUrl).then(() => {
      setCopied(true);
      onToast('تم نسخ رابط التطبيق بنجاح! افتحه في متصفح الهاتف لتثبيته 📲');
      setTimeout(() => setCopied(false), 2500);
    }).catch(() => {
      onToast('تعذر نسخ الرابط تلقائياً');
    });
  };

  const handleNativeInstall = async () => {
    const success = await install();
    if (success) {
      onToast('تهانينا! جاري تثبيت تطبيق عالم عاصف على جهازك 🎉');
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#111b21] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#0b141a] via-[#1f2c34] to-[#0b141a] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#00a884] to-[#25d366] p-0.5 shadow-lg shadow-[#25d366]/20">
              <div className="w-full h-full bg-[#111b21] rounded-[14px] flex items-center justify-center">
                <Download className="w-6 h-6 text-[#25d366] animate-bounce" />
              </div>
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>تنزيل تطبيق عالم عاصف</span>
                <span className="text-[10px] bg-[#25d366]/20 text-[#25d366] px-2 py-0.5 rounded-full font-bold">
                  PWA أصلي 100%
                </span>
              </h2>
              <p className="text-xs text-gray-400 mt-0.5">
                تثبيت فوري ومجاني على شاشة هاتفك كأي تطبيق رسمي
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto custom-scrollbar flex-1 text-right">
          {/* Status or 1-Click Install Button if supported */}
          {isInstalled ? (
            <div className="p-3.5 rounded-xl bg-[#25d366]/15 border border-[#25d366]/30 flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-[#25d366] shrink-0" />
              <div className="text-xs text-gray-200">
                <strong className="text-white block font-black">التطبيق مثبت بالفعل على هذا الجهاز!</strong>
                يمكنك فتحه مباشرة من الشاشة الرئيسية لهاتفك أو جهازك بدون متصفح.
              </div>
            </div>
          ) : isInstallable ? (
            <div className="p-3.5 rounded-xl bg-gradient-to-r from-[#25d366]/20 to-[#00a884]/20 border border-[#25d366]/40 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
              <div className="text-xs text-gray-200 text-right w-full">
                <strong className="text-[#25d366] font-black text-sm block">جاهز للتثبيت الفوري بنقرة واحدة! ⚡</strong>
                متصفحك يدعم التثبيت المباشر دون أي خطوات إضافية.
              </div>
              <button
                onClick={handleNativeInstall}
                className="w-full sm:w-auto shrink-0 px-5 py-2.5 rounded-xl bg-[#25d366] hover:bg-[#20ba59] active:scale-95 text-black font-black text-xs transition duration-200 shadow-md shadow-[#25d366]/30 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>تثبيت الآن على الجهاز</span>
              </button>
            </div>
          ) : null}

          {/* Quick Share / Direct Open Link Box */}
          <div className="p-3 rounded-xl bg-[#1f2c34]/70 border border-white/5 space-y-2">
            <div className="flex items-center justify-between text-xs text-gray-300">
              <span className="font-bold flex items-center gap-1.5 text-gray-200">
                <Share2 className="w-3.5 h-3.5 text-[#25d366]" />
                <span>رابط التطبيق المباشر للتثبيت:</span>
              </span>
              <span className="text-[10px] text-gray-400">افتحه في متصفح هاتفك</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={currentUrl}
                className="w-full px-3 py-2 rounded-lg bg-[#0b141a] border border-white/10 text-xs text-gray-300 font-mono truncate focus:outline-none"
              />
              <button
                onClick={handleCopyLink}
                className="shrink-0 px-3.5 py-2 rounded-lg bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-[#25d366]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'تم النسخ' : 'نسخ'}</span>
              </button>
            </div>
          </div>

          {/* Device Tabs */}
          <div className="space-y-2.5">
            <label className="text-xs font-bold text-gray-300 block">
              اختر نوع جهازك للاطلاع على خطوات التنزيل:
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setActiveDeviceTab('android')}
                className={`py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 border cursor-pointer ${
                  activeDeviceTab === 'android'
                    ? 'bg-[#25d366]/20 border-[#25d366] text-[#25d366] shadow-sm'
                    : 'bg-[#1f2c34] border-white/5 text-gray-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>أندرويد (Android)</span>
              </button>

              <button
                onClick={() => setActiveDeviceTab('ios')}
                className={`py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 border cursor-pointer ${
                  activeDeviceTab === 'ios'
                    ? 'bg-[#25d366]/20 border-[#25d366] text-[#25d366] shadow-sm'
                    : 'bg-[#1f2c34] border-white/5 text-gray-400 hover:text-white'
                }`}
              >
                <Apple className="w-3.5 h-3.5" />
                <span>آيفون (iPhone)</span>
              </button>

              <button
                onClick={() => setActiveDeviceTab('pc')}
                className={`py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 border cursor-pointer ${
                  activeDeviceTab === 'pc'
                    ? 'bg-[#25d366]/20 border-[#25d366] text-[#25d366] shadow-sm'
                    : 'bg-[#1f2c34] border-white/5 text-gray-400 hover:text-white'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>الكمبيوتر (PC)</span>
              </button>
            </div>
          </div>

          {/* Step-by-Step Instructions per Tab */}
          <div className="p-4 rounded-xl bg-[#0b141a] border border-white/5 space-y-3">
            {activeDeviceTab === 'android' && (
              <div className="space-y-3 animate-in fade-in duration-200">
                <div className="flex items-center gap-2 text-xs font-black text-white">
                  <span className="w-5 h-5 rounded-full bg-[#25d366] text-black flex items-center justify-center text-[11px] font-black">
                    1
                  </span>
                  <span>خطوات التنزيل على هواتف أندرويد (Chrome أو Samsung Internet):</span>
                </div>
                <ol className="space-y-2.5 text-xs text-gray-300 list-decimal pr-5 leading-relaxed">
                  <li>
                    افتح رابط التطبيق في متصفح <strong>Google Chrome</strong> على هاتفك.
                  </li>
                  <li>
                    اضغط على زر <strong>خيارات المتصفح</strong> (أيقونة النقاط الثلاث <code className="text-[#25d366]">⋮</code> في الزاوية العلوية).
                  </li>
                  <li>
                    اختر خيار <strong>«تثبيت التطبيق» (Install app)</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.
                  </li>
                  <li>
                    اضغط على <strong>تثبيت (Install)</strong> لتأكيد التنزيل.
                  </li>
                  <li className="text-[#25d366] font-bold">
                    سيظهر تطبيق «عالم عاصف» فوراً كأيقونة تطبيق كاملة على شاشتك الرئيسية ويعمل بدون شريط متصفح وبكامل السرعة!
                  </li>
                </ol>
              </div>
            )}

            {activeDeviceTab === 'ios' && (
              <div className="space-y-3 animate-in fade-in duration-200">
                <div className="flex items-center gap-2 text-xs font-black text-white">
                  <span className="w-5 h-5 rounded-full bg-[#25d366] text-black flex items-center justify-center text-[11px] font-black">
                    2
                  </span>
                  <span>خطوات التنزيل على آيفون وآيباد (iPhone / iPad - Safari):</span>
                </div>
                <ol className="space-y-2.5 text-xs text-gray-300 list-decimal pr-5 leading-relaxed">
                  <li>
                    افتح رابط التطبيق حصراً في متصفح <strong>سفاري (Safari)</strong>.
                  </li>
                  <li>
                    اضغط على زر <strong>المشاركة</strong> بالأسفل (المربع الذي ينبثق منه سهم للأعلى <code className="text-white">⎋</code>).
                  </li>
                  <li>
                    مرر للأسفل بين الخيارات واضغط على <strong>«إضافة إلى الشاشة الرئيسية» ➕</strong> (Add to Home Screen).
                  </li>
                  <li>
                    اضغط على <strong>«إضافة» (Add)</strong> في أعلى الزاوية.
                  </li>
                  <li className="text-[#25d366] font-bold">
                    سيتم تنزيل الأيقونة الفاخرة لتطبيق «عالم عاصف» على شاشة الآيفون، لتفتحه بملء الشاشة كأي تطبيق تم تنزيله من الآب ستور!
                  </li>
                </ol>
              </div>
            )}

            {activeDeviceTab === 'pc' && (
              <div className="space-y-3 animate-in fade-in duration-200">
                <div className="flex items-center gap-2 text-xs font-black text-white">
                  <span className="w-5 h-5 rounded-full bg-[#25d366] text-black flex items-center justify-center text-[11px] font-black">
                    3
                  </span>
                  <span>خطوات التنزيل على الكمبيوتر واللابتوب (Windows / Mac / Chrome):</span>
                </div>
                <ol className="space-y-2.5 text-xs text-gray-300 list-decimal pr-5 leading-relaxed">
                  <li>
                    افتح الرابط في متصفح <strong>Google Chrome</strong> أو <strong>Microsoft Edge</strong>.
                  </li>
                  <li>
                    ستلاحظ ظهور أيقونة كمبيوتر صغيرة بجانب شريط الرابط بالأعلى مكتوب عليها <strong>«تثبيت عالم عاصف»</strong>، اضغط عليها.
                  </li>
                  <li>
                    أو اضغط على زر الخيارات (<code className="text-[#25d366]">⋮</code>) ثم اختر <strong>«تثبيت التطبيق كبرنامج مستقل»</strong>.
                  </li>
                  <li className="text-[#25d366] font-bold">
                    سيفتح التطبيق في نافذة مستقلة أنيقة على سطح المكتب مع إشعارات فورية وسرعة فائقة.
                  </li>
                </ol>
              </div>
            )}
          </div>

          {/* Advantages Card */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-500/10 via-[#1f2c34] to-emerald-500/10 border border-white/5 space-y-2">
            <h4 className="text-xs font-black text-white flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>مميزات تنزيل التطبيق على الهاتف:</span>
            </h4>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-gray-300">
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#25d366]" />
                <span>مجاني 100% بدون أي رسوم</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#25d366]" />
                <span>شاشة كاملة وتجربة أصلية</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#25d366]" />
                <span>إشعارات وصوت عند الرسائل</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#25d366]" />
                <span>مزامنة فورية لكافة المحادثات</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#0b141a] border-t border-white/10 flex items-center justify-between gap-3">
          <button
            onClick={handleCopyLink}
            className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Copy className="w-4 h-4 text-[#25d366]" />
            <span>نسخ رابط التنزيل</span>
          </button>
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-[#25d366] hover:bg-[#20ba59] active:scale-95 text-black font-black text-xs transition duration-200 cursor-pointer text-center"
          >
            حسناً، فهمت
          </button>
        </div>
      </div>
    </div>
  );
};
