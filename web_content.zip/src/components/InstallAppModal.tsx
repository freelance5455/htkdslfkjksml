import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Download, 
  Share2, 
  CheckCircle2, 
  ExternalLink, 
  X, 
  Sparkles, 
  QrCode, 
  ShieldCheck, 
  ArrowRight,
  Layers,
  Copy,
  Check
} from 'lucide-react';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const appUrl = 'https://ais-pre-xlprxg2hojfk27qltbjfyi-120181986202.asia-southeast1.run.app';

  useEffect(() => {
    // Listen for beforeinstallprompt event on Android Chrome
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    // Check if running in standalone mode (already installed)
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      // Guide user on Chrome Android
      alert('To install directly: In Chrome, tap the 3 dots (⋮) in the top-right corner and select "Install app" or "Add to Home screen"!');
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0c0f1d] border border-cyan-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-100 space-y-4 max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-purple-600 p-0.5 shadow-lg shadow-cyan-500/25">
              <img 
                src="/pwa-192x192.png" 
                alt="Secret Gossip" 
                className="w-full h-full object-cover rounded-[14px]"
              />
            </div>
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <span>Install Secret Gossip</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono">
                  APK / Android
                </span>
              </h3>
              <p className="text-xs text-slate-400">Install as native app on your phone</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status if already installed */}
        {isInstalled && (
          <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Secret Gossip is installed and active on this device!</span>
          </div>
        )}

        {/* PRIMARY METHOD: 1-Click Install to Phone */}
        <div className="p-4 rounded-2xl bg-gradient-to-b from-cyan-950/40 to-slate-900 border border-cyan-500/30 space-y-3">
          <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs uppercase tracking-wider">
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <span>Method 1: Direct 1-Click Phone Install (Recommended)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Android creates an official <strong>native app package (.apk)</strong> directly on your home screen. No unknown sources permissions or APK download errors!
          </p>

          <button
            type="button"
            onClick={handleInstallClick}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-500 hover:from-cyan-400 hover:to-pink-400 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/25 transition-all flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>Install Native App onto Phone</span>
          </button>
        </div>

        {/* METHOD 2: Open On Phone via Link / QR */}
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs font-bold text-slate-300">
            <span className="flex items-center gap-1.5">
              <Share2 className="w-4 h-4 text-purple-400" />
              <span>Method 2: Open directly on your Phone Chrome</span>
            </span>
          </div>

          <p className="text-[11px] text-slate-400">
            Open this URL on your phone's Chrome browser, tap the <strong>3 dots (⋮)</strong> and select <strong>"Install app"</strong>:
          </p>

          <div className="flex items-center gap-2 p-2 rounded-xl bg-slate-950 border border-slate-800">
            <input
              type="text"
              readOnly
              value={appUrl}
              className="bg-transparent text-[11px] text-cyan-300 font-mono flex-1 outline-none truncate"
            />
            <button
              onClick={handleCopyLink}
              className="px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center gap-1 transition-colors shrink-0"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
            </button>
          </div>
        </div>

        {/* METHOD 3: Download Standalone .APK File (PWABuilder) */}
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2.5">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
            <Layers className="w-4 h-4 text-amber-400" />
            <span>Method 3: Download Standalone .APK Package</span>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            You can generate a signed standalone <strong>.apk file</strong> using Google's official PWABuilder tool:
          </p>

          <a
            href={`https://www.pwabuilder.com?url=${encodeURIComponent(appUrl)}`}
            target="_blank"
            rel="noreferrer"
            className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
          >
            <span>Generate & Download .APK via PWABuilder</span>
            <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
          </a>
        </div>

        {/* Safety Note */}
        <div className="flex items-center gap-2 text-[10px] text-slate-500 justify-center pt-1">
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span>100% Virus-Free • Verified Google Progressive Web Application</span>
        </div>
      </div>
    </div>
  );
};
