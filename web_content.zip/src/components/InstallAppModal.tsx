import React from 'react';
import { Download, Smartphone, CheckCircle, X, Share2, Sparkles } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useAudioFeedback } from '../hooks/useAudioFeedback';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const { playButtonClick, playCoinCollect } = useAudioFeedback();

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    playButtonClick();
    if (isInstallable) {
      const success = await install();
      if (success) {
        playCoinCollect(3);
        onClose();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Smartphone className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-white font-display">
                Download & Install App
              </h3>
              <p className="text-[11px] text-slate-400">Mobile Home Screen Par Install Karein</p>
            </div>
          </div>

          <button
            onClick={() => {
              playButtonClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status / Instructions */}
        {isInstalled ? (
          <div className="p-3.5 bg-emerald-950/60 border border-emerald-800 rounded-2xl flex items-center gap-2.5 text-xs text-emerald-300">
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-400" />
            <span>Yeh app pehle se aapke mobile par installed hai!</span>
          </div>
        ) : (
          <div className="space-y-3">
            {/* 1-Click Install Button if supported by Chrome */}
            {isInstallable && (
              <button
                onClick={handleInstallClick}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-xs hover:brightness-105 transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>1-Click Install Tap Tap Cash</span>
              </button>
            )}

            {/* Android Chrome Guided Steps */}
            <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-2 text-xs">
              <div className="flex items-center gap-1.5 text-amber-400 font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Android Mobile me Install karne ka tareeqa:</span>
              </div>
              <ol className="text-slate-300 space-y-1.5 list-decimal list-inside text-[11px] leading-relaxed">
                <li>
                  Chrome browser ke upar right side par <strong className="text-white">3 Dots (⋮)</strong> par tap karein.
                </li>
                <li>
                  Menu me se <strong className="text-emerald-400">"Install app"</strong> ya <strong className="text-emerald-400">"Add to Home screen"</strong> select karein.
                </li>
                <li>
                  Game direct aapke phone ki home screen par ek real app icon ke sath save ho jayegi!
                </li>
              </ol>
            </div>

            {/* iOS Safari Guided Steps */}
            {isIOS && (
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-1.5 text-xs">
                <span className="text-cyan-400 font-bold block">iPhone / iPad Users:</span>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Safari ke niche <Share2 className="w-3 h-3 inline text-white" /> <strong>Share</strong> icon dabayein aur <strong>"Add to Home Screen"</strong> par tap karein.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Direct ZIP File Download Link */}
        <div className="pt-2 border-t border-slate-800">
          <a
            href="/tap-tap-cash.zip"
            download="tap-tap-cash.zip"
            onClick={() => {
              playButtonClick();
              playCoinCollect(2);
            }}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Download Game ZIP File (.zip)</span>
          </a>
        </div>

        {/* Benefits badge */}
        <div className="pt-1 text-center">
          <p className="text-[11px] text-slate-500">
            ⚡ Fullscreen mode · Fast loading · Har waqt 1-tap se accessible
          </p>
        </div>

        <button
          onClick={() => {
            playButtonClick();
            onClose();
          }}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  );
};
