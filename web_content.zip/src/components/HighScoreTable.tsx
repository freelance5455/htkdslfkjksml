import type { HighScoreEntry } from '@/game/types';
import { cn } from '@/utils/cn';

interface Props {
  scores: HighScoreEntry[];
  highlight?: number;
  limit?: number;
  className?: string;
  dark?: boolean;
}

const medal = (i: number) => (i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}`);

export default function HighScoreTable({ scores, highlight = -1, limit = 10, className, dark = false }: Props) {
  const rows = scores.slice(0, limit);
  if (rows.length === 0) {
    return (
      <div className={cn('rounded-xl border border-dashed px-4 py-6 text-center text-sm font-bold', dark ? 'border-gold/40 text-parchment/70' : 'border-gold-dark/50 text-ink-soft', className)}>
        No runs recorded yet — be the first on the board!
      </div>
    );
  }
  return (
    <div className={cn('overflow-hidden rounded-xl border', dark ? 'border-gold/30 bg-ink/40' : 'border-gold-dark/40 bg-white/40', className)}>
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className={cn('text-[10px] font-black uppercase tracking-[0.2em]', dark ? 'bg-gold/15 text-gold-light' : 'bg-gold-dark/15 text-ink-soft')}>
            <th className="px-3 py-2 text-left">#</th>
            <th className="px-2 py-2 text-left">Runner</th>
            <th className="px-2 py-2 text-right">Score</th>
            <th className="hidden px-2 py-2 text-right sm:table-cell">Answers</th>
            <th className="px-3 py-2 text-right">Combo</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => {
            const hl = i === highlight;
            return (
              <tr
                key={r.date + '-' + i}
                className={cn(
                  'border-t font-bold',
                  dark ? 'border-gold/15 text-parchment' : 'border-gold-dark/20 text-ink',
                  hl && (dark ? 'bg-gold/25 text-gold-light' : 'bg-gold/40'),
                  hl && 'animate-pop-in',
                )}
              >
                <td className="px-3 py-1.5 text-left font-display">{medal(i)}</td>
                <td className="max-w-[9rem] truncate px-2 py-1.5 text-left">
                  {r.name}
                  {hl && <span className="ml-2 rounded bg-wrong px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wider text-white">New</span>}
                </td>
                <td className="px-2 py-1.5 text-right font-display tabular-nums">{r.score.toLocaleString('en-US')}</td>
                <td className="hidden px-2 py-1.5 text-right tabular-nums sm:table-cell">
                  {r.correct}/{r.answered}
                </td>
                <td className="px-3 py-1.5 text-right tabular-nums">×{r.maxCombo}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
