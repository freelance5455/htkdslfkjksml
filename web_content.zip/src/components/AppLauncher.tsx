import React, { useState } from 'react';
import { AndroidApp } from '../types/jarvis';
import { hardwareBridge } from '../utils/hardwareBridge';
import {
  Search,
  ExternalLink,
  MessageCircle,
  Phone,
  MessageSquare,
  Youtube,
  Music,
  MapPin,
  Globe,
  Camera,
  Mail,
  Send,
  Settings,
  Clock,
  LayoutGrid,
  Plus,
  X,
} from 'lucide-react';

interface AppLauncherProps {
  apps: AndroidApp[];
  onOpenApp: (app: AndroidApp) => void;
  onAddCustomApp: (app: AndroidApp) => void;
}

export const AppLauncher: React.FC<AppLauncherProps> = ({
  apps,
  onOpenApp,
  onAddCustomApp,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showAddModal, setShowAddModal] = useState(false);

  // New App Form
  const [newAppName, setNewAppName] = useState('');
  const [newAppCategory, setNewAppCategory] = useState<'Comms' | 'Tools' | 'Media' | 'Social' | 'Google'>('Tools');
  const [newAppScheme, setNewAppScheme] = useState('');

  const categories = ['All', 'Comms', 'Tools', 'Media', 'Google'];

  const filteredApps = apps.filter((app) => {
    const matchesSearch = app.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || app.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const renderIcon = (name: string, color: string) => {
    const props = { className: 'w-6 h-6', style: { color } };
    switch (name) {
      case 'MessageCircle':
        return <MessageCircle {...props} />;
      case 'Phone':
        return <Phone {...props} />;
      case 'MessageSquare':
        return <MessageSquare {...props} />;
      case 'Youtube':
        return <Youtube {...props} />;
      case 'Music':
        return <Music {...props} />;
      case 'MapPin':
        return <MapPin {...props} />;
      case 'Globe':
        return <Globe {...props} />;
      case 'Camera':
        return <Camera {...props} />;
      case 'Mail':
        return <Mail {...props} />;
      case 'Send':
        return <Send {...props} />;
      case 'Settings':
        return <Settings {...props} />;
      case 'Clock':
        return <Clock {...props} />;
      default:
        return <ExternalLink {...props} />;
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAppName.trim() || !newAppScheme.trim()) return;

    const newApp: AndroidApp = {
      id: `app-${Date.now()}`,
      name: newAppName.trim(),
      category: newAppCategory,
      intentUrl: newAppScheme.trim(),
      webFallback: `https://www.google.com/search?q=${encodeURIComponent(newAppName)}`,
      iconName: 'ExternalLink',
      color: '#38bdf8',
    };

    onAddCustomApp(newApp);
    setNewAppName('');
    setNewAppScheme('');
    setShowAddModal(false);
  };

  return (
    <div className="bg-gray-900/90 border border-cyan-500/30 rounded-2xl p-4 sm:p-6 backdrop-blur-md shadow-2xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <LayoutGrid className="w-5 h-5" />
            </span>
            <h2 className="font-orbitron text-lg font-bold tracking-wider text-slate-100 uppercase">
              Android App Matrix
            </h2>
          </div>
          <p className="text-xs text-slate-400 font-rajdhani mt-0.5">
            Direct intent launch to Android native applications via Jarvis voice & touch
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-900 border border-cyan-500/40 hover:bg-cyan-950 text-cyan-300 font-orbitron text-xs font-bold uppercase tracking-wider transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add Custom App
        </button>
      </div>

      {/* Search & Categories */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search installed Android apps..."
            className="w-full bg-gray-950 border border-gray-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono-code transition shrink-0 ${
                selectedCategory === cat
                  ? 'bg-cyan-500 text-gray-950 font-bold'
                  : 'bg-gray-950 border border-gray-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* App Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
        {filteredApps.map((app) => (
          <button
            key={app.id}
            onClick={() => onOpenApp(app)}
            className="group p-3 rounded-2xl bg-gray-950/80 border border-gray-800 hover:border-cyan-500/50 hover:bg-gray-950 transition-all flex flex-col items-center text-center shadow-sm hover:shadow-cyan-950/30 active:scale-95"
          >
            <div className="w-12 h-12 rounded-2xl bg-gray-900 border border-gray-800 group-hover:border-cyan-500/40 flex items-center justify-center transition-all shadow-inner group-hover:shadow-[0_0_12px_rgba(6,182,212,0.3)]">
              {renderIcon(app.iconName, app.color)}
            </div>
            <span className="mt-2 text-xs font-medium text-slate-200 group-hover:text-cyan-200 truncate w-full">
              {app.name}
            </span>
            <span className="text-[10px] font-mono-code text-slate-500 uppercase mt-0.5">
              {app.category}
            </span>
          </button>
        ))}
      </div>

      {/* Add Custom App Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-gray-900 border border-cyan-500/40 rounded-2xl p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-gray-800">
              <h3 className="font-orbitron text-sm font-bold text-cyan-300 uppercase tracking-wider">
                Register Android App Intent
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">
                  Application Name
                </label>
                <input
                  type="text"
                  required
                  value={newAppName}
                  onChange={(e) => setNewAppName(e.target.value)}
                  placeholder="e.g. Netflix / Discord / Spotify"
                  className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">
                  Android URI Scheme or Package
                </label>
                <input
                  type="text"
                  required
                  value={newAppScheme}
                  onChange={(e) => setNewAppScheme(e.target.value)}
                  placeholder="e.g. netflix:// or discord:// or https://"
                  className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">
                  Category
                </label>
                <select
                  value={newAppCategory}
                  onChange={(e) => setNewAppCategory(e.target.value as any)}
                  className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                >
                  <option value="Comms">Comms</option>
                  <option value="Tools">Tools</option>
                  <option value="Media">Media</option>
                  <option value="Social">Social</option>
                  <option value="Google">Google</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold font-orbitron text-xs uppercase tracking-wider transition shadow-lg shadow-cyan-600/30"
                >
                  Save App
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
