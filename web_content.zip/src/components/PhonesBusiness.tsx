import React, { useState } from 'react';
import { Smartphone, MapPin, Send, CheckCircle2, ShieldCheck, ArrowRight } from 'lucide-react';

export const PhonesBusiness: React.FC = () => {
  const [phoneModel, setPhoneModel] = useState('');
  const [phonePlace, setPhonePlace] = useState('Kyebando, Kawempe, Kampala');

  const handlePhoneSell = (e: React.FormEvent) => {
    e.preventDefault();
    const model = phoneModel.trim() || 'Used/New Smartphone';
    const place = phonePlace.trim() || 'Kyebando, Kawempe, Kampala';
    const msg = `Hello Cue King, I have phone to sell/buy%0APhone: ${encodeURIComponent(model)}%0ALocation: ${encodeURIComponent(place)} - Kampala%0A%0AWhat is price?`;
    window.open(`https://wa.me/256742094651?text=${msg}`, '_blank');
  };

  return (
    <section id="phones" className="py-8 px-4 max-w-5xl mx-auto">
      <div className="bg-gradient-to-br from-yellow-400 via-amber-400 to-orange-500 text-black rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/20 rounded-full blur-2xl pointer-events-none" />

        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black text-yellow-300 text-xs font-black uppercase tracking-wider mb-2">
            <Smartphone className="w-3.5 h-3.5" />
            Instant Cash &amp; Swap In Kampala
          </div>

          <h2 className="text-2xl sm:text-3xl font-black uppercase tracking-tight text-black">
            📱 USED &amp; NEW PHONES — Kyebando, Kawempe, Kampala
          </h2>

          <p className="text-sm sm:text-base font-bold mt-1 text-zinc-900 leading-snug">
            We deal in used and unused phones. Tell us what you have and where you are, we come to you.
          </p>

          <p className="text-xs text-zinc-800 mt-1 font-medium">
            Tecno, Infinix, iPhone, Samsung, Redmi, Itel — Buy, sell, or swap with quick cash on the spot!
          </p>
        </div>

        {/* Form Container */}
        <form onSubmit={handlePhoneSell} className="mt-5 bg-black p-4 sm:p-6 rounded-2xl border border-black/40 text-white shadow-xl">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1.5">
                What phone do you have?
              </label>
              <input
                type="text"
                required
                value={phoneModel}
                onChange={(e) => setPhoneModel(e.target.value)}
                placeholder="e.g Tecno Spark 20, iPhone 12, Samsung A15"
                className="w-full p-3 rounded-xl bg-zinc-800 text-white border border-zinc-700 text-sm focus:outline-none focus:border-yellow-400 transition-colors"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1.5">
                Where are you located?
              </label>
              <input
                type="text"
                required
                value={phonePlace}
                onChange={(e) => setPhonePlace(e.target.value)}
                placeholder="Where are you? e.g Kyebando, Bwaise, Kampala"
                className="w-full p-3 rounded-xl bg-zinc-800 text-white border border-zinc-700 text-sm focus:outline-none focus:border-yellow-400 transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-yellow-400 hover:bg-yellow-300 text-black py-3.5 rounded-full font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all cursor-pointer"
          >
            <span>SEND TO WHATSAPP (0742094651)</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[11px] text-zinc-400 pt-2 border-t border-zinc-800">
            <span className="flex items-center gap-1 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" /> Fair Market Valuation Guaranteed
            </span>
            <span>Kyebando Base · We move across all Kampala</span>
          </div>
        </form>
      </div>
    </section>
  );
};
