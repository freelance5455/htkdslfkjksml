import React from 'react';
import {
  ArrowRight,
  Brain,
  CheckCircle2,
  Cpu,
  Database,
  Eye,
  MessageSquare,
  Play,
  RefreshCw,
  Search,
  ShieldCheck,
  Wrench,
} from 'lucide-react';
import { CoreLoopStage } from '../types.ts';

interface CoreLoopVisualizerProps {
  currentStage: CoreLoopStage | null;
  isExecuting: boolean;
}

const STAGES: { stage: CoreLoopStage; label: string; icon: React.ReactNode }[] = [
  { stage: 'PERCEIVE', label: 'PERCEIVE', icon: <Eye className="w-3.5 h-3.5" /> },
  { stage: 'UNDERSTAND', label: 'UNDERSTAND', icon: <Brain className="w-3.5 h-3.5" /> },
  { stage: 'REMEMBER', label: 'REMEMBER', icon: <Database className="w-3.5 h-3.5" /> },
  { stage: 'PLAN', label: 'PLAN', icon: <Search className="w-3.5 h-3.5" /> },
  { stage: 'SELECT_MODEL', label: 'MODEL', icon: <Cpu className="w-3.5 h-3.5" /> },
  { stage: 'SELECT_TOOLS', label: 'TOOLS', icon: <Wrench className="w-3.5 h-3.5" /> },
  { stage: 'EXECUTE', label: 'EXECUTE', icon: <Play className="w-3.5 h-3.5" /> },
  { stage: 'OBSERVE', label: 'OBSERVE', icon: <Eye className="w-3.5 h-3.5" /> },
  { stage: 'VERIFY', label: 'VERIFY', icon: <ShieldCheck className="w-3.5 h-3.5" /> },
  { stage: 'REPLAN', label: 'REPLAN', icon: <RefreshCw className="w-3.5 h-3.5" /> },
  { stage: 'RESPOND', label: 'RESPOND', icon: <MessageSquare className="w-3.5 h-3.5" /> },
];

export const CoreLoopVisualizer: React.FC<CoreLoopVisualizerProps> = ({
  currentStage,
  isExecuting,
}) => {
  const currentIndex = STAGES.findIndex((s) => s.stage === currentStage);

  return (
    <div
      id="core-loop-visualizer"
      className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs transition-colors"
    >
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-800 font-bold">
            Autonomous 11-Stage Pipeline
          </span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-50 text-sky-800 border border-sky-200 font-mono font-medium">
            11 STAGES
          </span>
          {currentIndex >= 0 && (
            <span className="text-[11px] font-mono text-slate-500">
              Stage {currentIndex + 1} of 11: <strong className="text-slate-900">{STAGES[currentIndex].label}</strong>
            </span>
          )}
        </div>
        {isExecuting ? (
          <span className="text-xs font-mono text-sky-700 flex items-center gap-1.5 font-semibold bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
            <span className="w-2 h-2 rounded-full bg-sky-600 animate-ping" />
            CYCLE ACTIVE
          </span>
        ) : (
          <span className="text-xs font-mono text-slate-500 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-slate-300" />
            STANDBY / READY
          </span>
        )}
      </div>

      {/* Horizontal Stage Chain Flow */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
        {STAGES.map((item, idx) => {
          const isActive = currentStage === item.stage;
          const isPassed = currentIndex > idx;
          const isReplan = item.stage === 'REPLAN' && isActive;

          let statusClass = 'bg-slate-50 border-slate-200 text-slate-500 hover:border-slate-300';
          if (isActive) {
            statusClass = isReplan
              ? 'bg-amber-50 border-amber-400 text-amber-900 ring-2 ring-amber-300/60 animate-pulse font-semibold shadow-xs'
              : 'bg-sky-50 border-sky-500 text-sky-900 ring-2 ring-sky-300/60 shadow-xs font-semibold';
          } else if (isPassed) {
            statusClass = 'bg-emerald-50 border-emerald-300 text-emerald-800 font-medium';
          }

          return (
            <React.Fragment key={item.stage}>
              <div
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-mono whitespace-nowrap transition-all duration-200 ${statusClass}`}
              >
                {isPassed ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                ) : (
                  <span className={`flex-shrink-0 ${isActive ? 'text-sky-600' : 'text-slate-400'}`}>
                    {item.icon}
                  </span>
                )}
                <span className="text-[11px] tracking-tight">{item.label}</span>
              </div>
              {idx < STAGES.length - 1 && (
                <ArrowRight
                  className={`w-3 h-3 flex-shrink-0 ${
                    isPassed ? 'text-emerald-500' : 'text-slate-300'
                  }`}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};
