import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  History,
  BellRing,
  Clock,
  Search,
  CheckCircle2,
  TrendingUp,
  TrendingDown,
  MapPin,
  Trash2,
  CheckCheck,
  ArrowUpRight,
  Filter,
  X,
  Target,
  Sparkles,
  ShoppingBag,
  RotateCcw,
  Award,
} from 'lucide-react';
import { Language, MarketAlertHistoryItem } from '../types';
import { playKeyTap, playSuccessChime } from '../utils/audio';

interface NotificationHistoryTabProps {
  language: Language;
  history: MarketAlertHistoryItem[];
  onMarkStatus: (id: string, status: 'new' | 'reviewed' | 'action_taken') => void;
  onDeleteHistoryItem: (id: string) => void;
  onMarkAllReviewed: () => void;
  onClearHistory: () => void;
  onRetarget: (cropId: string, currentTarget: number) => void;
  onNavigateToBuyers?: () => void;
}

export default function NotificationHistoryTab({
  language,
  history,
  onMarkStatus,
  onDeleteHistoryItem,
  onMarkAllReviewed,
  onClearHistory,
  onRetarget,
  onNavigateToBuyers,
}: NotificationHistoryTabProps) {
  const isSw = language === 'sw';
  const [statusFilter, setStatusFilter] = useState<'all' | 'new' | 'reviewed' | 'action_taken'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Filtered history
  const filteredHistory = useMemo(() => {
    return history.filter((item) => {
      // Status filter
      if (statusFilter !== 'all' && item.status !== statusFilter) {
        return false;
      }
      // Search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesCrop =
          item.cropNameSw.toLowerCase().includes(query) ||
          item.cropNameEn.toLowerCase().includes(query);
        const matchesMarket = item.marketName.toLowerCase().includes(query);
        const matchesNote = item.note ? item.note.toLowerCase().includes(query) : false;
        return matchesCrop || matchesMarket || matchesNote;
      }
      return true;
    });
  }, [history, statusFilter, searchQuery]);

  // Summary analytics
  const totalCount = history.length;
  const newCount = history.filter((h) => h.status === 'new').length;
  const reviewedCount = history.filter((h) => h.status === 'reviewed').length;
  const actionTakenCount = history.filter((h) => h.status === 'action_taken').length;

  const averageGainTsh = useMemo(() => {
    const positiveGains = history.filter((h) => h.profitDeltaTsh > 0);
    if (positiveGains.length === 0) return 0;
    const sum = positiveGains.reduce((acc, h) => acc + h.profitDeltaTsh, 0);
    return Math.round(sum / positiveGains.length);
  }, [history]);

  const getCropEmoji = (cropId: string) => {
    if (cropId.includes('coffee')) return '☕';
    if (cropId.includes('cashew')) return '🥜';
    if (cropId.includes('clove')) return '🌿';
    if (cropId.includes('cocoa')) return '🍫';
    if (cropId.includes('tea')) return '🍵';
    if (cropId === 'mp-1' || cropId.includes('maize')) return '🌽';
    if (cropId === 'mp-2' || cropId.includes('rice')) return '🍚';
    if (cropId === 'mp-4' || cropId.includes('bean')) return '🫘';
    return '🌱';
  };

  return (
    <div id="market-notification-history-container" className="space-y-4">
      {/* 1. SUMMARY STATS BANNER */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {/* Total Triggered */}
        <div className="p-3 rounded-2xl bg-[var(--paper)] border border-[var(--line)] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-[var(--ink-soft)]">
            <span className="text-[10px] font-bold uppercase tracking-wider">
              {isSw ? 'Jumla ya Arifa' : 'Total Triggered'}
            </span>
            <BellRing className="w-3.5 h-3.5 text-[var(--forest)]" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="font-display text-2xl font-bold text-[var(--ink)]">
              {totalCount}
            </span>
            <span className="text-[10px] text-[var(--ink-soft)]">
              {isSw ? 'zilizorekodiwa' : 'logged'}
            </span>
          </div>
        </div>

        {/* New / Actionable */}
        <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-emerald-800 dark:text-emerald-300">
            <span className="text-[10px] font-bold uppercase tracking-wider">
              {isSw ? 'Zinazosubiri Hatua' : 'Pending Action'}
            </span>
            <Sparkles className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="font-display text-2xl font-bold text-emerald-700 dark:text-emerald-300">
              {newCount}
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
              {isSw ? 'mpya' : 'new alerts'}
            </span>
          </div>
        </div>

        {/* Average Gain Above Target */}
        <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-amber-800 dark:text-amber-300">
            <span className="text-[10px] font-bold uppercase tracking-wider">
              {isSw ? 'Wastani Juu ya Lengo' : 'Avg. Above Target'}
            </span>
            <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1">
            <span className="font-display text-xl font-bold text-amber-900 dark:text-amber-200">
              +{averageGainTsh > 0 ? averageGainTsh.toLocaleString() : 0}
            </span>
            <span className="text-[10px] text-amber-700 dark:text-amber-300 font-bold">
              Tsh/kg
            </span>
          </div>
        </div>

        {/* Action Taken / Sold */}
        <div className="p-3 rounded-2xl bg-[var(--paper)] border border-[var(--line)] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-[var(--ink-soft)]">
            <span className="text-[10px] font-bold uppercase tracking-wider">
              {isSw ? 'Uuzaji Umefanyika' : 'Action Taken'}
            </span>
            <Award className="w-3.5 h-3.5 text-[var(--soil)]" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="font-display text-2xl font-bold text-[var(--ink)]">
              {actionTakenCount}
            </span>
            <span className="text-[10px] text-[var(--ink-soft)]">
              {isSw ? 'zimekamilika' : 'completed'}
            </span>
          </div>
        </div>
      </div>

      {/* 2. SEARCH & STATUS FILTER CONTROLS */}
      <div className="p-3 rounded-2xl bg-[var(--paper)] border border-[var(--line)] space-y-2.5">
        {/* Search Input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[var(--ink-soft)]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isSw
                ? 'Tafuta arifa kwa zao (mf. Mahindi, Kahawa), soko, au dokezo...'
                : 'Search alert history by crop, market, or action note...'
            }
            className="w-full pl-9 pr-8 py-2 text-xs rounded-xl bg-[var(--bg)] border border-[var(--line)] text-[var(--ink)] placeholder:text-[var(--ink-soft)] focus:outline-none focus:border-[var(--forest)]"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-2.5 text-[var(--ink-soft)] hover:text-[var(--ink)] cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Pills & Batch Action Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 border-t border-[var(--line)]">
          {/* Status Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            <button
              onClick={() => {
                playKeyTap();
                setStatusFilter('all');
              }}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer whitespace-nowrap ${
                statusFilter === 'all'
                  ? 'bg-[var(--forest)] text-[#F7F4E9] shadow-xs'
                  : 'bg-[var(--bg)] text-[var(--ink-soft)] hover:text-[var(--ink)] border border-[var(--line)]'
              }`}
            >
              {isSw ? 'Zote' : 'All'} ({totalCount})
            </button>

            <button
              onClick={() => {
                playKeyTap();
                setStatusFilter('new');
              }}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                statusFilter === 'new'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 border border-emerald-500/20'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>{isSw ? 'Mpya / Zinazosubiri' : 'Pending'}</span>
              <span className="text-[10px] opacity-80">({newCount})</span>
            </button>

            <button
              onClick={() => {
                playKeyTap();
                setStatusFilter('reviewed');
              }}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer whitespace-nowrap ${
                statusFilter === 'reviewed'
                  ? 'bg-[var(--forest)] text-[#F7F4E9] shadow-xs'
                  : 'bg-[var(--bg)] text-[var(--ink-soft)] hover:text-[var(--ink)] border border-[var(--line)]'
              }`}
            >
              {isSw ? 'Zilizohakikiwa' : 'Reviewed'} ({reviewedCount})
            </button>

            <button
              onClick={() => {
                playKeyTap();
                setStatusFilter('action_taken');
              }}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer whitespace-nowrap ${
                statusFilter === 'action_taken'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-[var(--bg)] text-[var(--ink-soft)] hover:text-[var(--ink)] border border-[var(--line)]'
              }`}
            >
              {isSw ? 'Zilizouzwa' : 'Action Taken'} ({actionTakenCount})
            </button>
          </div>

          {/* Batch Tools */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {newCount > 0 && (
              <button
                onClick={() => {
                  playSuccessChime();
                  onMarkAllReviewed();
                }}
                className="py-1 px-2.5 rounded-lg bg-[var(--bg)] border border-[var(--line)] hover:border-[var(--forest)] text-[11px] font-semibold text-[var(--forest)] flex items-center gap-1 cursor-pointer transition-colors"
                title={isSw ? 'Weka arifa zote mpya kuwa zimehakikiwa' : 'Mark all new alerts as reviewed'}
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>{isSw ? 'Hakiki Zote' : 'Mark All Reviewed'}</span>
              </button>
            )}

            {history.length > 0 && (
              <div className="relative">
                {!showClearConfirm ? (
                  <button
                    onClick={() => {
                      playKeyTap();
                      setShowClearConfirm(true);
                    }}
                    className="p-1 rounded-lg text-neutral-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer transition-colors"
                    title={isSw ? 'Futa kumbukumbu zote' : 'Clear history'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <div className="flex items-center gap-1 bg-red-50 dark:bg-red-950/40 p-1 rounded-lg border border-red-300 dark:border-red-900">
                    <span className="text-[10px] font-bold text-red-700 dark:text-red-300">
                      {isSw ? 'Futa yote?' : 'Clear all?'}
                    </span>
                    <button
                      onClick={() => {
                        playKeyTap();
                        onClearHistory();
                        setShowClearConfirm(false);
                      }}
                      className="px-1.5 py-0.5 rounded bg-red-600 text-white text-[9px] font-bold hover:bg-red-700 cursor-pointer"
                    >
                      {isSw ? 'Ndio' : 'Yes'}
                    </button>
                    <button
                      onClick={() => setShowClearConfirm(false)}
                      className="px-1.5 py-0.5 rounded bg-neutral-200 dark:bg-neutral-800 text-[9px] font-bold cursor-pointer"
                    >
                      {isSw ? 'Hapana' : 'No'}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 3. NOTIFICATION HISTORY LIST */}
      <div className="space-y-3">
        <AnimatePresence mode="popLayout">
          {filteredHistory.length > 0 ? (
            filteredHistory.map((item) => {
              const isProfit = item.profitDeltaTsh >= 0;
              const emoji = getCropEmoji(item.cropId);

              return (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className={`p-4 rounded-2xl border transition-all space-y-3 ${
                    item.status === 'new'
                      ? 'bg-[var(--paper)] border-emerald-500/40 shadow-sm ring-1 ring-emerald-500/20'
                      : item.status === 'action_taken'
                      ? 'bg-[var(--paper)] border-amber-500/30'
                      : 'bg-[var(--paper)] border-[var(--line)] opacity-90'
                  }`}
                >
                  {/* Top Header: Crop Name, Timestamp & Status Badge */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-xl bg-[var(--bg)] border border-[var(--line)] flex items-center justify-center text-lg flex-shrink-0 shadow-xs">
                        <span>{emoji}</span>
                      </div>
                      <div>
                        <div className="font-bold text-sm text-[var(--ink)] flex items-center gap-1.5 flex-wrap">
                          <span>{isSw ? item.cropNameSw : item.cropNameEn}</span>
                        </div>
                        <div className="text-[10px] text-[var(--ink-soft)] flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3 text-[var(--ink-soft)]" />
                          <span>{item.triggeredAt}</span>
                          <span>•</span>
                          <MapPin className="w-3 h-3 text-[var(--soil)]" />
                          <span className="truncate max-w-[180px]">{item.marketName}</span>
                        </div>
                      </div>
                    </div>

                    {/* Status Badge */}
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {item.status === 'new' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-600 text-white flex items-center gap-1 shadow-xs animate-pulse">
                          <BellRing className="w-2.5 h-2.5" />
                          <span>{isSw ? 'IMEFIKIWA (MPYA)' : 'TRIGGERED'}</span>
                        </span>
                      )}
                      {item.status === 'reviewed' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-[var(--bg)] border border-[var(--line)] text-[var(--ink-soft)] flex items-center gap-1">
                          <CheckCircle2 className="w-2.5 h-2.5 text-neutral-400" />
                          <span>{isSw ? 'Imehakikiwa' : 'Reviewed'}</span>
                        </span>
                      )}
                      {item.status === 'action_taken' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-500/40 flex items-center gap-1">
                          <Award className="w-2.5 h-2.5 text-amber-600" />
                          <span>{isSw ? 'Uuzaji Umefanyika' : 'Action Taken'}</span>
                        </span>
                      )}

                      <button
                        onClick={() => onDeleteHistoryItem(item.id)}
                        className="p-1 text-neutral-400 hover:text-red-500 rounded-lg cursor-pointer transition-colors"
                        title={isSw ? 'Futa kumbukumbu hii' : 'Delete this record'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Core Metrics: Target vs Actual Price & Profit Margin */}
                  <div className="p-3 rounded-xl bg-[var(--bg)] border border-[var(--line)] grid grid-cols-3 gap-2 text-center">
                    {/* Target */}
                    <div className="text-left border-r border-[var(--line)] pr-2">
                      <span className="text-[10px] text-[var(--ink-soft)] block">
                        {isSw ? 'Lengo Lako:' : 'Target Set:'}
                      </span>
                      <span className="font-bold text-xs text-[var(--ink)] mt-0.5 block">
                        {item.condition === 'gte' ? '≥' : '≤'} Tsh {item.targetPriceTsh.toLocaleString()}/{item.unit}
                      </span>
                    </div>

                    {/* Triggered Price */}
                    <div className="border-r border-[var(--line)] px-2">
                      <span className="text-[10px] text-[var(--ink-soft)] block">
                        {isSw ? 'Soko Lilipofikia:' : 'Triggered Price:'}
                      </span>
                      <span className="font-display font-bold text-xs text-[var(--forest)] mt-0.5 block">
                        Tsh {item.triggeredPriceTsh.toLocaleString()}/{item.unit}
                      </span>
                    </div>

                    {/* Delta / Profit */}
                    <div className="text-right pl-2">
                      <span className="text-[10px] text-[var(--ink-soft)] block">
                        {isProfit ? (isSw ? 'Ziada Juu ya Lengo:' : 'Surplus Margin:') : (isSw ? 'Tofauti:' : 'Difference:')}
                      </span>
                      <span
                        className={`font-bold text-xs flex items-center justify-end gap-0.5 mt-0.5 ${
                          isProfit ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600'
                        }`}
                      >
                        {isProfit ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        <span>
                          {isProfit ? '+' : ''}
                          {item.profitDeltaTsh.toLocaleString()} Tsh ({item.profitDeltaPercent}%)
                        </span>
                      </span>
                    </div>
                  </div>

                  {/* Farmer's Action Note (if provided) */}
                  {item.note && (
                    <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-[var(--ink)] flex items-start gap-2">
                      <span className="text-amber-600 font-bold flex-shrink-0">💡</span>
                      <div className="italic text-[11px] leading-relaxed">
                        <strong className="not-italic text-[var(--soil)] font-semibold">
                          {isSw ? 'Dokezo lako la shambani:' : 'Farmer Note:'}{' '}
                        </strong>
                        "{item.note}"
                      </div>
                    </div>
                  )}

                  {/* Action Bar */}
                  <div className="pt-1 flex items-center justify-between gap-2 flex-wrap text-xs">
                    {/* Status Toggles */}
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {item.status === 'new' && (
                        <button
                          onClick={() => onMarkStatus(item.id, 'reviewed')}
                          className="py-1 px-2.5 rounded-lg bg-[var(--bg)] border border-[var(--line)] hover:border-[var(--forest)] text-[var(--ink)] font-semibold text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>{isSw ? 'Weka Imehakikiwa' : 'Mark Reviewed'}</span>
                        </button>
                      )}

                      {item.status !== 'action_taken' && (
                        <button
                          onClick={() => onMarkStatus(item.id, 'action_taken')}
                          className="py-1 px-2.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-900 dark:text-amber-200 font-bold text-[11px] flex items-center gap-1 cursor-pointer hover:bg-amber-500/25 transition-colors"
                        >
                          <Award className="w-3 h-3 text-amber-600" />
                          <span>{isSw ? 'Weka Imeuzwa / Tayari' : 'Mark as Sold'}</span>
                        </button>
                      )}

                      {item.status !== 'new' && (
                        <button
                          onClick={() => onMarkStatus(item.id, 'new')}
                          className="py-1 px-2 rounded-lg text-[var(--ink-soft)] hover:text-[var(--ink)] text-[10px] font-medium cursor-pointer"
                        >
                          <RotateCcw className="w-3 h-3 inline mr-0.5" />
                          <span>{isSw ? 'Rejesha Mpya' : 'Mark as New'}</span>
                        </button>
                      )}
                    </div>

                    {/* Proactive Next Steps: Re-target & Connect with Buyers */}
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {onNavigateToBuyers && (
                        <button
                          onClick={onNavigateToBuyers}
                          className="py-1 px-2.5 rounded-lg bg-[var(--bg)] border border-[var(--line)] hover:border-[var(--forest)] text-[var(--forest)] font-semibold text-[11px] flex items-center gap-1 cursor-pointer"
                          title={isSw ? 'Tafuta wanunuzi wa zao hili' : 'Connect to verified buyers'}
                        >
                          <ShoppingBag className="w-3 h-3" />
                          <span className="hidden xs:inline">{isSw ? 'Wanunuzi' : 'Buyers'}</span>
                        </button>
                      )}

                      <button
                        onClick={() => onRetarget(item.cropId, item.targetPriceTsh)}
                        className="py-1 px-2.5 rounded-lg bg-[var(--forest)] text-[#F7F4E9] font-bold text-[11px] flex items-center gap-1 shadow-xs hover:bg-[var(--forest-dark)] active:scale-95 transition-all cursor-pointer"
                        title={isSw ? 'Weka lengo jipya la juu zaidi' : 'Set a higher price target'}
                      >
                        <Target className="w-3 h-3" />
                        <span>{isSw ? 'Pandisha Lengo' : 'Retarget Higher'}</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })
          ) : (
            /* EMPTY STATE */
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="py-12 px-4 rounded-2xl bg-[var(--paper)] border border-dashed border-[var(--line)] text-center space-y-3"
            >
              <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
                <History className="w-6 h-6" />
              </div>
              <div className="max-w-xs mx-auto space-y-1">
                <h4 className="font-bold text-sm text-[var(--ink)]">
                  {searchQuery || statusFilter !== 'all'
                    ? (isSw ? 'Hakuna arifa zilizopatikana' : 'No matching alerts found')
                    : (isSw ? 'Bado hakuna historia ya arifa za bei' : 'No triggered alerts in history yet')}
                </h4>
                <p className="text-xs text-[var(--ink-soft)] leading-relaxed">
                  {searchQuery || statusFilter !== 'all'
                    ? (isSw
                        ? 'Jaribu kubadilisha maneno ya utafutaji au weka kichujio cha "Zote".'
                        : 'Try adjusting your search query or reset the filter to "All".')
                    : (isSw
                        ? 'Mfumo utarekodi hapa kiotomatiki kila bei za soko zinapofikia malengo yako ya uuzaji.'
                        : 'The system will automatically track every time live market prices reach or exceed your target selling thresholds.')}
                </p>
              </div>

              {(searchQuery || statusFilter !== 'all') && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setStatusFilter('all');
                  }}
                  className="py-1.5 px-3 rounded-xl bg-[var(--forest)] text-[#F7F4E9] text-xs font-bold cursor-pointer hover:bg-[var(--forest-dark)]"
                >
                  {isSw ? 'Rejesha Vichujio Vyote' : 'Reset All Filters'}
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 4. EDUCATIONAL TIP FOR FARMERS */}
      <div className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] flex items-start gap-3 text-xs text-[var(--ink-soft)]">
        <div className="w-7 h-7 rounded-xl bg-amber-500/15 text-amber-700 dark:text-amber-300 flex items-center justify-center flex-shrink-0 mt-0.5">
          <Sparkles className="w-4 h-4" />
        </div>
        <div className="space-y-1">
          <div className="font-bold text-[var(--ink)]">
            {isSw ? 'Jinsi Arifa za Malengo Zinavyofanya Kazi' : 'How Price Threshold Alerts Work'}
          </div>
          <p className="leading-relaxed text-[11px]">
            {isSw
              ? 'Wakati wowote bei ya Kariakoo, Kibaigwa, au Soko la Dunia inapofikia kiwango ulichopanga, mfumo hutoa arifa na kuihifadhi kwenye historia hii ili uweze kupanga muda muafaka wa kutoa mazao ghalani na kuuza kwa faida ya juu.'
              : 'Whenever commodity prices at Kariakoo, Kibaigwa, or Global exchanges hit your designated threshold, Ardhi flags it and preserves it in this history tab so you can execute sales at peak profit windows.'}
          </p>
        </div>
      </div>
    </div>
  );
}
