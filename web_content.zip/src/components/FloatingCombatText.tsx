import React, { useEffect, useState } from 'react';
import { GameEngine } from '../game/GameEngine';
import { FloatingDamage } from '../types/game';

interface ActiveFloatingItem extends FloatingDamage {
  curY: number;
  screenPos: { x: number; y: number; visible: boolean };
}

interface FloatingCombatTextProps {
  engine: GameEngine | null;
  items: FloatingDamage[];
}

export const FloatingCombatText: React.FC<FloatingCombatTextProps> = ({ engine, items }) => {
  const [renderedItems, setRenderedItems] = useState<ActiveFloatingItem[]>([]);

  // Add new items as they arrive
  useEffect(() => {
    if (items.length === 0) return;

    const newItems: ActiveFloatingItem[] = items.map((item) => ({
      ...item,
      curY: item.y,
      screenPos: engine ? engine.projectToScreen(item.x, item.y, item.z) : { x: 0, y: 0, visible: false },
    }));

    setRenderedItems((prev) => [...prev, ...newItems]);
  }, [items, engine]);

  // Animation frame loop to update Y rise, fade opacity, and re-project with 3D camera
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const loop = (now: number) => {
      const dt = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      setRenderedItems((prev) => {
        if (prev.length === 0) return prev;

        const updated: ActiveFloatingItem[] = [];

        for (const item of prev) {
          const nextY = item.curY + item.vy * dt;
          const nextOpacity = item.opacity - dt * 0.85;

          if (nextOpacity > 0.05) {
            const screenPos = engine
              ? engine.projectToScreen(item.x, nextY, item.z)
              : { x: 0, y: 0, visible: false };

            updated.push({
              ...item,
              curY: nextY,
              opacity: nextOpacity,
              screenPos,
            });
          }
        }

        return updated;
      });

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [engine]);

  return (
    <div className="fixed inset-0 pointer-events-none select-none z-25 overflow-hidden">
      {renderedItems.map((item) => {
        if (!item.screenPos.visible) return null;

        const isCrit = item.isCrit;
        const isIncoming = item.type === 'incoming';
        const isDodge = item.type === 'dodge';

        return (
          <div
            key={item.id}
            className={`absolute font-mono font-black -translate-x-1/2 -translate-y-1/2 transition-transform duration-75 ${
              isCrit ? 'text-lg md:text-2xl scale-125' : isDodge ? 'text-sm md:text-base' : 'text-sm md:text-lg'
            }`}
            style={{
              left: `${item.screenPos.x}px`,
              top: `${item.screenPos.y}px`,
              opacity: item.opacity,
              color: item.color,
              textShadow: isCrit
                ? '0 0 10px rgba(239,68,68,0.9), 0 2px 4px #000000'
                : isDodge
                ? '0 0 8px rgba(56,189,248,0.9), 0 1px 3px #000000'
                : isIncoming
                ? '0 0 8px rgba(248,113,113,0.8), 0 1px 3px #000000'
                : '0 0 6px rgba(0,0,0,0.9), 0 1px 3px #000000',
            }}
          >
            {item.text}
          </div>
        );
      })}
    </div>
  );
};
