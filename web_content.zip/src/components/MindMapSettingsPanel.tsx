import React, { useState } from "react";
import {
  Network,
  GitBranch,
  Layers,
  Sparkles,
  Sliders,
  Check,
  RotateCcw,
  Maximize2,
  Compass,
  Cpu,
  CheckCircle2,
  Spline
} from "lucide-react";
import {
  MindMapSettings,
  MindMapLayoutType,
  MindMapLineStyle,
  MindMapSummaryDepth,
  DEFAULT_MIND_MAP_SETTINGS,
  getStoredMindMapSettings,
  saveStoredMindMapSettings,
} from "../utils/AudioVideoMindMapExtractor";

interface MindMapSettingsPanelProps {
  onNotify?: (msg: string) => void;
  onSettingsChanged?: (settings: MindMapSettings) => void;
}

export const MindMapSettingsPanel: React.FC<MindMapSettingsPanelProps> = ({
  onNotify,
  onSettingsChanged,
}) => {
  const [settings, setSettings] = useState<MindMapSettings>(getStoredMindMapSettings);

  const updateSettings = (patch: Partial<MindMapSettings>) => {
    const updated = { ...settings, ...patch };
    setSettings(updated);
    saveStoredMindMapSettings(updated);
    if (onSettingsChanged) onSettingsChanged(updated);
    if (onNotify) onNotify("✓ Zihin Haritası ve İlişki Ağı ayarları güncellendi.");
  };

  const handleReset = () => {
    setSettings(DEFAULT_MIND_MAP_SETTINGS);
    saveStoredMindMapSettings(DEFAULT_MIND_MAP_SETTINGS);
    if (onSettingsChanged) onSettingsChanged(DEFAULT_MIND_MAP_SETTINGS);
    if (onNotify) onNotify("Zihin Haritası ayarları varsayılana sıfırlandı.");
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-start gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center shrink-0 shadow-md">
            <Network className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-black text-slate-900 dark:text-white">
                Zihin Haritası & İlişki Ağı Ayarları
              </h2>
              <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                PKM & AI Graph Engine
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Notlarınızdan ve ses/video kayıtlarınızdan otomatik üretilen zihin haritalarının görsel düzenini ve AI analiz derinliğini yapılandırın.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleReset}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold transition-all shrink-0 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
          <span>Varsayılana Sıfırla</span>
        </button>
      </div>

      {/* 1. HARİTA LAYOUT TİPİ SEÇİCİSİ */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center gap-2">
          <GitBranch className="w-4 h-4 text-purple-500" />
          <span>1. Harita Düzen Tipi (Layout Concept)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {/* Radyal */}
          <div
            onClick={() => updateSettings({ layoutType: "radial" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
              settings.layoutType === "radial"
                ? "bg-purple-50/70 dark:bg-purple-950/50 border-purple-500 text-purple-950 dark:text-purple-100 shadow-sm ring-2 ring-purple-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black">Radyal (Radial)</span>
              {settings.layoutType === "radial" && <CheckCircle2 className="w-4 h-4 text-purple-600 dark:text-purple-400" />}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Ana kavram merkezde, alt fikirler dairesel kollar halinde etrafında.
            </p>
          </div>

          {/* Dikey Ağaç */}
          <div
            onClick={() => updateSettings({ layoutType: "vertical_tree" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
              settings.layoutType === "vertical_tree"
                ? "bg-purple-50/70 dark:bg-purple-950/50 border-purple-500 text-purple-950 dark:text-purple-100 shadow-sm ring-2 ring-purple-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black">Dikey Ağaç (Vertical)</span>
              {settings.layoutType === "vertical_tree" && <CheckCircle2 className="w-4 h-4 text-purple-600 dark:text-purple-400" />}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Yukarıdan aşağıya hiyerarşik organizasyon şeması düzeni.
            </p>
          </div>

          {/* Balık Kılçığı */}
          <div
            onClick={() => updateSettings({ layoutType: "fishbone" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
              settings.layoutType === "fishbone"
                ? "bg-purple-50/70 dark:bg-purple-950/50 border-purple-500 text-purple-950 dark:text-purple-100 shadow-sm ring-2 ring-purple-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black">Balık Kılçığı (Ishikawa)</span>
              {settings.layoutType === "fishbone" && <CheckCircle2 className="w-4 h-4 text-purple-600 dark:text-purple-400" />}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Neden-sonuç analizi ve kronolojik süreç haritalandırması.
            </p>
          </div>

          {/* Serbest Düğümler */}
          <div
            onClick={() => updateSettings({ layoutType: "freeform" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
              settings.layoutType === "freeform"
                ? "bg-purple-50/70 dark:bg-purple-950/50 border-purple-500 text-purple-950 dark:text-purple-100 shadow-sm ring-2 ring-purple-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black">Serbest Düğümler (Force)</span>
              {settings.layoutType === "freeform" && <CheckCircle2 className="w-4 h-4 text-purple-600 dark:text-purple-400" />}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Fiziksel kütle simülasyonlu, sürüklenebilir serbest kavram ağı.
            </p>
          </div>
        </div>
      </div>

      {/* 2. ÇİZGİ VE BAĞLANTI STİLLERİ */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center gap-2">
          <Spline className="w-4 h-4 text-indigo-500" />
          <span>2. Çizgi ve Bağlantı Stilleri (Connection Lines)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          {/* Kavisli */}
          <div
            onClick={() => updateSettings({ lineStyle: "curved" })}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2 ${
              settings.lineStyle === "curved"
                ? "bg-indigo-50/70 dark:bg-indigo-950/50 border-indigo-500 text-indigo-950 dark:text-indigo-100 shadow-sm ring-1 ring-indigo-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            }`}
          >
            <div>
              <h4 className="text-xs font-bold">Kavisli (Curved Bezier)</h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">Yumuşak kavisli bağlantılar</p>
            </div>
            {settings.lineStyle === "curved" && <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />}
          </div>

          {/* Düz */}
          <div
            onClick={() => updateSettings({ lineStyle: "straight" })}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2 ${
              settings.lineStyle === "straight"
                ? "bg-indigo-50/70 dark:bg-indigo-950/50 border-indigo-500 text-indigo-950 dark:text-indigo-100 shadow-sm ring-1 ring-indigo-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            }`}
          >
            <div>
              <h4 className="text-xs font-bold">Düz (Straight)</h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">Köşeli direkt çizgiler</p>
            </div>
            {settings.lineStyle === "straight" && <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />}
          </div>

          {/* Kesikli */}
          <div
            onClick={() => updateSettings({ lineStyle: "dashed" })}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2 ${
              settings.lineStyle === "dashed"
                ? "bg-indigo-50/70 dark:bg-indigo-950/50 border-indigo-500 text-indigo-950 dark:text-indigo-100 shadow-sm ring-1 ring-indigo-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            }`}
          >
            <div>
              <h4 className="text-xs font-bold">Kesikli (Dashed Line)</h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">Noktalı dinamik hatlar</p>
            </div>
            {settings.lineStyle === "dashed" && <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />}
          </div>

          {/* Neon Parıltılı */}
          <div
            onClick={() => updateSettings({ lineStyle: "neon" })}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2 ${
              settings.lineStyle === "neon"
                ? "bg-indigo-50/70 dark:bg-indigo-950/50 border-indigo-500 text-indigo-950 dark:text-indigo-100 shadow-sm ring-1 ring-indigo-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            }`}
          >
            <div>
              <h4 className="text-xs font-bold flex items-center gap-1">
                <span>Neon Parıltılı</span>
                <Sparkles className="w-3 h-3 text-indigo-500 animate-pulse" />
              </h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">Işıltılı siber bağlantılar</p>
            </div>
            {settings.lineStyle === "neon" && <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />}
          </div>
        </div>
      </div>

      {/* 3. OTOMATİK AI DERİNLİĞİ (ÖZET SEVİYESİ) */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center gap-2">
          <Cpu className="w-4 h-4 text-emerald-500" />
          <span>3. Otomatik AI Analiz Derinliği (Summary Depth)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Yüzeyel */}
          <div
            onClick={() => updateSettings({ summaryDepth: "surface" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
              settings.summaryDepth === "surface"
                ? "bg-emerald-50/70 dark:bg-emerald-950/50 border-emerald-500 text-emerald-950 dark:text-emerald-100 shadow-sm ring-1 ring-emerald-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black">Yüzeyel (Surface / Hızlı)</span>
              {settings.summaryDepth === "surface" && <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Sadece ana başlıklar ve 2-3 temel kavram. Hızlı gözden geçirme için ideal.
            </p>
          </div>

          {/* Detaylı */}
          <div
            onClick={() => updateSettings({ summaryDepth: "detailed" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
              settings.summaryDepth === "detailed"
                ? "bg-emerald-50/70 dark:bg-emerald-950/50 border-emerald-500 text-emerald-950 dark:text-emerald-100 shadow-sm ring-1 ring-emerald-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black">Detaylı (Detailed / Standart)</span>
              {settings.summaryDepth === "detailed" && <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Dengeli dal yapısı, ana fikirler ve ilişkili alt detaylar.
            </p>
          </div>

          {/* Akademik */}
          <div
            onClick={() => updateSettings({ summaryDepth: "academic" })}
            className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
              settings.summaryDepth === "academic"
                ? "bg-emerald-50/70 dark:bg-emerald-950/50 border-emerald-500 text-emerald-950 dark:text-emerald-100 shadow-sm ring-1 ring-emerald-500/30"
                : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black">Akademik (Academic / Derin)</span>
              {settings.summaryDepth === "academic" && <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Maksimum düğüm yoğunluğu, kavramsal ilişkiler, deşifre ayrıntıları ve zaman damgaları.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
