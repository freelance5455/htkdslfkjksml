import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Bell,
  X,
  Calendar,
  Clock,
  Repeat,
  Music,
  Play,
  Square,
  Upload,
  Check,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
} from 'lucide-react';
import type { AlarmRepeatMode, BuiltinRingtoneId, StudyAlarm } from '../types';
import {
  BUILTIN_RINGTONES,
  startAlarmPlayback,
  stopAlarmAudio,
} from '../lib/sound';
import {
  formatFileSize,
  uploadFileToIndexedDb,
  validateAdminFile,
} from '../lib/fileDb';
import { TactileButton } from './InteractiveButton';

interface AlarmModalProps {
  open: boolean;
  onClose: () => void;
  editingAlarm: StudyAlarm | null;
  defaultTitle: string;
  taskId?: string;
  onSave: (alarmData: Omit<StudyAlarm, 'id' | 'createdAt'>) => void;
}

function getTodayDateString(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getDefaultTimeString(): string {
  const soon = new Date(Date.now() + 15 * 60 * 1000);
  const h = String(soon.getHours()).padStart(2, '0');
  const m = String(soon.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

export function AlarmModal({
  open,
  onClose,
  editingAlarm,
  defaultTitle,
  taskId,
  onSave,
}: AlarmModalProps) {
  const audioPickerRef = useRef<HTMLInputElement | null>(null);

  const [title, setTitle] = useState(defaultTitle);
  const [date, setDate] = useState(getTodayDateString);
  const [time, setTime] = useState(getDefaultTimeString);
  const [repeat, setRepeat] = useState<AlarmRepeatMode>('once');
  const [ringtoneType, setRingtoneType] = useState<'builtin' | 'custom'>('builtin');
  const [builtinRingtoneId, setBuiltinRingtoneId] =
    useState<BuiltinRingtoneId>('calm_study');
  const [customAudioUrl, setCustomAudioUrl] = useState<string | undefined>(undefined);
  const [customAudioName, setCustomAudioName] = useState<string | undefined>(undefined);

  // Custom phone ringtone upload state (90MB max + IndexedDB + FileReader)
  const [previewPlayingKey, setPreviewPlayingKey] = useState<string | null>(null);
  const [audioUploading, setAudioUploading] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const [audioSize, setAudioSize] = useState(0);
  const [audioUploadDone, setAudioUploadDone] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) {
      stopAlarmAudio();
      setPreviewPlayingKey(null);
      return;
    }

    if (editingAlarm) {
      setTitle(editingAlarm.title);
      setDate(editingAlarm.date);
      setTime(editingAlarm.time);
      setRepeat(editingAlarm.repeat);
      setRingtoneType(editingAlarm.ringtoneType);
      setBuiltinRingtoneId(editingAlarm.builtinRingtoneId);
      setCustomAudioUrl(editingAlarm.customAudioUrl);
      setCustomAudioName(editingAlarm.customAudioName);
    } else {
      setTitle(defaultTitle);
      setDate(getTodayDateString());
      setTime(getDefaultTimeString());
      setRepeat('once');
      setRingtoneType('builtin');
      setBuiltinRingtoneId('calm_study');
      setCustomAudioUrl(undefined);
      setCustomAudioName(undefined);
    }
    setAudioUploading(false);
    setAudioProgress(0);
    setAudioSize(0);
    setAudioUploadDone(false);
    setAudioError(null);
    setPreviewPlayingKey(null);
  }, [open, editingAlarm, defaultTitle]);

  useEffect(() => {
    return () => {
      stopAlarmAudio();
    };
  }, []);

  const handleTogglePreview = async (
    key: string,
    opts: {
      ringtoneType: 'builtin' | 'custom';
      builtinRingtoneId: BuiltinRingtoneId;
      customAudioUrl?: string;
    }
  ) => {
    if (previewPlayingKey === key) {
      stopAlarmAudio();
      setPreviewPlayingKey(null);
      return;
    }
    setPreviewPlayingKey(key);
    await startAlarmPlayback({ ...opts, loop: false });
  };

  const handlePickCustomAudio = async (file: File | null) => {
    setAudioError(null);
    setAudioUploadDone(false);
    setAudioProgress(0);
    if (!file) return;

    const validation = validateAdminFile(file);
    if (!validation.valid) {
      if (audioPickerRef.current) audioPickerRef.current.value = '';
      setAudioError(validation.error);
      return;
    }
    if (validation.mediaType !== 'audio') {
      if (audioPickerRef.current) audioPickerRef.current.value = '';
      setAudioError('الصيغة دي مش مدعومة');
      return;
    }

    setAudioUploading(true);
    setAudioSize(file.size);
    try {
      const audioId = `alarm_audio_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const saved = await uploadFileToIndexedDb(file, audioId, setAudioProgress);
      setCustomAudioUrl(saved.fileUrl);
      setCustomAudioName(file.name);
      setRingtoneType('custom');
      setAudioProgress(100);
      setAudioUploadDone(true);
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'تعذر حفظ النغمة';
      setAudioError(`حصل خطأ أثناء الرفع: ${reason}`);
    } finally {
      setAudioUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (audioUploading) return;
    stopAlarmAudio();
    setPreviewPlayingKey(null);

    // Ask notification permission once if supported; if denied, alarm continues inside app
    if (
      typeof window !== 'undefined' &&
      'Notification' in window &&
      Notification.permission === 'default'
    ) {
      try {
        await Notification.requestPermission();
      } catch {
        // Ignore if browser rejects permission prompt
      }
    }

    onSave({
      title: title.trim() || defaultTitle || 'منبه المذاكرة',
      taskId: editingAlarm?.taskId ?? taskId,
      date,
      time,
      repeat,
      ringtoneType,
      builtinRingtoneId,
      customAudioUrl,
      customAudioName,
      enabled: true,
      lastTriggeredKey: undefined,
      snoozeUntilMs: undefined,
    });
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-slate-900/55 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4"
          role="dialog"
          aria-modal="true"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 12 }}
            className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 sm:p-6 shadow-2xl max-h-[92vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between gap-2 pb-3 mb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
                    {editingAlarm ? 'تعديل المنبه' : 'ضبط منبه المذاكرة'}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    حدد الوقت والتكرار والنغمة المناسبة لك
                  </p>
                </div>
              </div>

              <motion.button
                type="button"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  stopAlarmAudio();
                  onClose();
                }}
                aria-label="إغلاق"
                className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer active:shadow-none"
              >
                <X className="w-5 h-5" />
              </motion.button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Alarm Label */}
              <div>
                <label className="block text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                  اسم التنبيه
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثال: مراجعة الفيزياء"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-violet-500 outline-none text-sm"
                />
              </div>

              {/* Manual Date & Time */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                    <Calendar className="w-3.5 h-3.5 text-violet-600 dark:text-violet-400" />
                    <span>التاريخ</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono-num text-xs sm:text-sm focus:border-violet-500 outline-none"
                  />
                </div>

                <div>
                  <label className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                    <Clock className="w-3.5 h-3.5 text-violet-600 dark:text-violet-400" />
                    <span>الوقت</span>
                  </label>
                  <input
                    type="time"
                    required
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono-num text-xs sm:text-sm focus:border-violet-500 outline-none"
                  />
                </div>
              </div>

              {/* Repeat Mode */}
              <div>
                <span className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                  <Repeat className="w-3.5 h-3.5 text-violet-600 dark:text-violet-400" />
                  <span>التكرار</span>
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'once' as const, label: 'مرة واحدة' },
                    { id: 'daily' as const, label: 'كل يوم' },
                    { id: 'study_days' as const, label: 'أيام الدراسة بس' },
                  ].map((opt) => (
                    <TactileButton
                      key={opt.id}
                      type="button"
                      onClick={() => setRepeat(opt.id)}
                      className={`py-2 px-2 rounded-xl text-xs font-bold min-h-[40px] whitespace-nowrap ${
                        repeat === opt.id
                          ? 'bg-violet-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 shadow-none'
                      }`}
                    >
                      {opt.label}
                    </TactileButton>
                  ))}
                </div>
              </div>

              {/* Custom Phone Ringtone */}
              <div className="space-y-2.5 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200">
                    <Music className="w-4 h-4 text-orange-500" />
                    <span>النغمة</span>
                  </span>

                  <input
                    ref={audioPickerRef}
                    type="file"
                    accept="audio/*"
                    onChange={(e) => handlePickCustomAudio(e.target.files?.[0] || null)}
                    className="hidden"
                  />

                  <TactileButton
                    type="button"
                    disabled={audioUploading}
                    onClick={() => audioPickerRef.current?.click()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-orange-50 dark:bg-orange-950/60 hover:bg-orange-100 dark:hover:bg-orange-900 text-orange-700 dark:text-orange-300 text-xs font-bold min-h-[38px]"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>اختار نغمة من الهاتف</span>
                  </TactileButton>
                </div>

                {/* Custom audio progress or selected card */}
                {(audioUploading || audioUploadDone || customAudioUrl) && (
                  <div
                    onClick={() => {
                      if (customAudioUrl) setRingtoneType('custom');
                    }}
                    className={`p-3 rounded-xl border space-y-2 cursor-pointer transition-colors ${
                      ringtoneType === 'custom'
                        ? 'bg-orange-50/70 dark:bg-orange-950/40 border-orange-400 dark:border-orange-700'
                        : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0 flex items-center gap-2">
                        <div
                          className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 ${
                            ringtoneType === 'custom'
                              ? 'bg-orange-500 text-white'
                              : 'bg-slate-200 dark:bg-slate-700 text-transparent'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {customAudioName || 'نغمة من الهاتف'}
                          </p>
                          {audioSize > 0 && (
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono-num">
                              {formatFileSize(audioSize)}
                            </p>
                          )}
                        </div>
                      </div>

                      {customAudioUrl && (
                        <TactileButton
                          type="button"
                          onClick={(ev) => {
                            ev.stopPropagation();
                            void handleTogglePreview('custom', {
                              ringtoneType: 'custom',
                              builtinRingtoneId,
                              customAudioUrl,
                            });
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-bold min-h-[34px] shrink-0"
                        >
                          {previewPlayingKey === 'custom' ? (
                            <>
                              <Square className="w-3 h-3 text-rose-500" />
                              <span>إيقاف</span>
                            </>
                          ) : (
                            <>
                              <Play className="w-3 h-3 text-orange-500" />
                              <span>تشغيل تجريبي</span>
                            </>
                          )}
                        </TactileButton>
                      )}
                    </div>

                    {(audioUploading || audioUploadDone) && (
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[11px] font-bold">
                          <span className="flex items-center gap-1 text-emerald-700 dark:text-emerald-300">
                            {audioUploadDone ? (
                              <>
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>تم رفع الملف بنجاح</span>
                              </>
                            ) : (
                              <span>جاري حفظ النغمة...</span>
                            )}
                          </span>
                          <span className="font-mono-num">{audioProgress}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all duration-200 ${
                              audioUploadDone ? 'bg-emerald-500' : 'bg-orange-500'
                            }`}
                            style={{ width: `${audioProgress}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {audioError && (
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs font-bold space-y-2">
                    <div className="flex items-center gap-1.5">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{audioError}</span>
                    </div>
                    <TactileButton
                      type="button"
                      onClick={() => {
                        setAudioError(null);
                        audioPickerRef.current?.click();
                      }}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold min-h-[34px]"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>اختار ملف تاني</span>
                    </TactileButton>
                  </div>
                )}

                {/* 5 Built-in Ringtones */}
                <div className="space-y-2">
                  {BUILTIN_RINGTONES.map((tone) => {
                    const selected =
                      ringtoneType === 'builtin' && builtinRingtoneId === tone.id;
                    const playing = previewPlayingKey === tone.id;
                    return (
                      <div
                        key={tone.id}
                        onClick={() => {
                          setRingtoneType('builtin');
                          setBuiltinRingtoneId(tone.id);
                        }}
                        className={`p-2.5 sm:p-3 rounded-xl border flex items-center justify-between gap-2 cursor-pointer transition-colors ${
                          selected
                            ? 'bg-violet-50/80 dark:bg-violet-950/50 border-violet-400 dark:border-violet-700'
                            : 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-700/80 hover:border-slate-300 dark:hover:border-slate-600'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div
                            className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 ${
                              selected
                                ? 'bg-violet-600 text-white'
                                : 'bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-transparent'
                            }`}
                          >
                            <Check className="w-3.5 h-3.5" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                              {tone.name}
                            </p>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                              {tone.description}
                            </p>
                          </div>
                        </div>

                        <TactileButton
                          type="button"
                          onClick={(ev) => {
                            ev.stopPropagation();
                            void handleTogglePreview(tone.id, {
                              ringtoneType: 'builtin',
                              builtinRingtoneId: tone.id,
                            });
                          }}
                          className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-bold min-h-[34px] whitespace-nowrap shrink-0 ${
                            playing
                              ? 'bg-rose-500 text-white'
                              : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:text-violet-700 dark:hover:text-violet-300'
                          }`}
                        >
                          {playing ? (
                            <>
                              <Square className="w-3 h-3" />
                              <span>إيقاف</span>
                            </>
                          ) : (
                            <>
                              <Play className="w-3 h-3" />
                              <span>تجربة النغمة</span>
                            </>
                          )}
                        </TactileButton>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <TactileButton
                  type="button"
                  onClick={() => {
                    stopAlarmAudio();
                    onClose();
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-sm font-bold min-h-[42px]"
                >
                  إلغاء
                </TactileButton>
                <TactileButton
                  type="submit"
                  disabled={audioUploading}
                  className="px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 disabled:opacity-60 text-white text-sm font-bold min-h-[42px]"
                >
                  حفظ المنبه
                </TactileButton>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
