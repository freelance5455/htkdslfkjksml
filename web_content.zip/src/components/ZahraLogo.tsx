import React from 'react';

interface ZahraLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  pulse?: boolean;
}

export const ZahraLogo: React.FC<ZahraLogoProps> = ({ 
  size = 'lg', 
  showText = false,
  pulse = true 
}) => {
  const dimensions = {
    sm: 'w-10 h-10',
    md: 'w-20 h-20',
    lg: 'w-32 h-32',
    xl: 'w-44 h-44 sm:w-48 sm:h-48'
  }[size];

  return (
    <div className="flex flex-col items-center justify-center select-none">
      <div className={`relative ${dimensions} flex items-center justify-center`}>
        {/* Luminous Glow */}
        <div 
          className={`absolute inset-0 rounded-full bg-gradient-to-tr from-pink-600/30 via-rose-500/25 to-amber-400/20 blur-xl ${pulse ? 'animate-pulse' : ''}`}
        />

        {/* Outer Circular Gradient Rim */}
        <div className="relative w-full h-full rounded-full p-[2.5px] bg-gradient-to-tr from-amber-300 via-rose-500 to-fuchsia-600 shadow-xl shadow-rose-950/40">
          {/* Inner Badge Background */}
          <div className="w-full h-full rounded-full bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 p-2 flex items-center justify-center border border-white/10">
            
            {/* Ultra-clean Luxury Zahra Blossom Vector SVG */}
            <svg 
              viewBox="0 0 100 100" 
              className="w-full h-full filter drop-shadow-[0_2px_8px_rgba(244,63,94,0.4)]"
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="roseLuxuryGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FB7185" />
                  <stop offset="50%" stopColor="#E11D48" />
                  <stop offset="100%" stopColor="#9F1239" />
                </linearGradient>
                <linearGradient id="goldLuxuryGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FEF08A" />
                  <stop offset="50%" stopColor="#F59E0B" />
                  <stop offset="100%" stopColor="#D97706" />
                </linearGradient>
                <linearGradient id="petalLight" x1="50%" y1="0%" x2="50%" y2="100%">
                  <stop offset="0%" stopColor="#FDA4AF" />
                  <stop offset="100%" stopColor="#F43F5E" />
                </linearGradient>
              </defs>

              {/* Geometric Blooming Petals (Outer Ring) */}
              <g opacity="0.95">
                {[0, 60, 120, 180, 240, 300].map((angle, i) => (
                  <path
                    key={`outer-${i}`}
                    d="M50 50 C44 28 32 12 50 4 C68 12 56 28 50 50Z"
                    fill="url(#roseLuxuryGrad)"
                    transform={`rotate(${angle} 50 50)`}
                  />
                ))}
              </g>

              {/* Interlaced Inner Gold Petals */}
              <g opacity="0.9">
                {[30, 90, 150, 210, 270, 330].map((angle, i) => (
                  <path
                    key={`inner-${i}`}
                    d="M50 50 C46 34 38 22 50 16 C62 22 54 34 50 50Z"
                    fill="url(#goldLuxuryGrad)"
                    transform={`rotate(${angle} 50 50)`}
                  />
                ))}
              </g>

              {/* Central Floral Blossom Core */}
              <circle cx="50" cy="50" r="14" fill="url(#petalLight)" />
              <circle cx="50" cy="50" r="9" fill="url(#goldLuxuryGrad)" />
              <circle cx="50" cy="50" r="4.5" fill="#FFFFFF" />

              {/* Top Miniature Royal Crown */}
              <path 
                d="M44 32 L47 28 L50 31 L53 28 L56 32 L54 34 L46 34 Z" 
                fill="#FEF08A" 
                stroke="#D97706" 
                strokeWidth="0.5"
              />
            </svg>

          </div>
        </div>
      </div>

      {showText && (
        <div className="mt-4 text-center">
          <h1 className="text-3xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-purple-700 via-pink-600 to-rose-600 font-['Cairo']">
            زهرة شات
          </h1>
          <p className="text-xs text-rose-600 font-medium tracking-wide mt-1">
            Zahra Chat • ملتقى الأصدقاء والتواصل الراقي
          </p>
        </div>
      )}
    </div>
  );
};
