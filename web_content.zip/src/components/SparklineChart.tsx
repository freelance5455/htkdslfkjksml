import React from 'react';

interface SparklineChartProps {
  data: number[];
  maxValue?: number;
  minValue?: number;
  color?: string;
  height?: number;
  unit?: string;
  label?: string;
}

export const SparklineChart: React.FC<SparklineChartProps> = ({
  data,
  maxValue,
  minValue = 0,
  color = '#39E52D',
  height = 110,
  unit = '',
  label,
}) => {
  const width = 420;
  const safeData = data.length >= 2 ? data : [data[0] ?? 0, data[0] ?? 0];
  const computedMax =
    maxValue ?? Math.max(...safeData, minValue + 10);
  const range = Math.max(computedMax - minValue, 1);

  const points = safeData.map((val, index) => {
    const x = (index / (safeData.length - 1)) * width;
    const normalized = Math.min(Math.max((val - minValue) / range, 0), 1);
    const y = height - 8 - normalized * (height - 16);
    return { x, y };
  });

  const linePath = points
    .map((pt, i) => `${i === 0 ? 'M' : 'L'} ${pt.x.toFixed(1)} ${pt.y.toFixed(1)}`)
    .join(' ');

  const areaPath = `${linePath} L ${width} ${height} L 0 ${height} Z`;
  const gradId = `spark-grad-${(label || 'chart').replace(/[^a-zA-Z0-9]/g, '')}`;
  const latest = safeData[safeData.length - 1];

  return (
    <div className="w-full">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full overflow-visible"
        style={{ height }}
        aria-label={label || 'Telemetry chart'}
      >
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.28" />
            <stop offset="100%" stopColor={color} stopOpacity="0.01" />
          </linearGradient>
        </defs>

        {/* Subtle reference lines */}
        <line
          x1="0"
          y1={height * 0.25}
          x2={width}
          y2={height * 0.25}
          stroke="currentColor"
          strokeOpacity="0.08"
          strokeDasharray="4 4"
        />
        <line
          x1="0"
          y1={height * 0.65}
          x2={width}
          y2={height * 0.65}
          stroke="currentColor"
          strokeOpacity="0.08"
          strokeDasharray="4 4"
        />

        <path d={areaPath} fill={`url(#${gradId})`} />
        <path
          d={linePath}
          fill="none"
          stroke={color}
          strokeWidth="2.25"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {points.length > 0 && (
          <circle
            cx={points[points.length - 1].x}
            cy={points[points.length - 1].y}
            r="4"
            fill={color}
          />
        )}
      </svg>
      <div className="mt-1.5 flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 font-mono tabular-nums">
        <span>Min {Math.min(...safeData).toFixed(1)}{unit}</span>
        <span className="font-semibold text-neutral-900 dark:text-neutral-100">
          Now {latest.toFixed(1)}{unit}
        </span>
        <span>Max {Math.max(...safeData).toFixed(1)}{unit}</span>
      </div>
    </div>
  );
};
