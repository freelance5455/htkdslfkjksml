import React, { useState } from 'react';
import {
  User as UserIcon, ShieldCheck, KeyRound, Bell, Lock, LogOut,
  Edit3, Check, X, ShieldAlert, Phone, Moon, Smartphone
} from 'lucide-react';
import type { User } from '../types/index.ts';
import { api } from '../services/api.ts';
import { BlueTick } from './BlueTick.tsx';
import { WHATSAPP_SERVICE_NUMBER } from '../constants.ts';

interface ProfileTabProps {
  currentUser: User;
  onLogout: () => void;
  onOpenWhatsApp: () => void;
  onUserUpdated: (updatedUser: User) => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  currentUser,
  onLogout,
  onOpenWhatsApp,
  onUserUpdated,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [fullName, setFullName] = useState(currentUser.fullName);
  const [bio, setBio] = useState(currentUser.bio);
  const [customStatus, setCustomStatus] = useState(currentUser.customStatus || '');

  // Password change modal state
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  // Settings Toggles
  const [readReceipts, setReadReceipts] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [previewNotifications, setPreviewNotifications] = useState(true);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.updateUserProfile(currentUser.id, {
        fullName: fullName.trim(),
        bio: bio.trim(),
        customStatus: customStatus.trim(),
      });
      if (res.success && res.user) {
        onUserUpdated(res.user);
        setIsEditing(false);
      }
    } catch {
      alert('Failed to update profile');
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);
    if (!oldPassword || !newPassword) {
      setPasswordError('Please fill all fields');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match');
      return;
    }
    if (newPassword.length < 4) {
      setPasswordError('Password must be at least 4 characters');
      return;
    }

    try {
      const res = await api.changePassword(currentUser.id, oldPassword, newPassword);
      if (res.success) {
        setPasswordSuccess(true);
        setTimeout(() => {
          setShowPasswordModal(false);
          setPasswordSuccess(false);
          setOldPassword('');
          setNewPassword('');
          setConfirmPassword('');
        }, 1500);
      } else {
        setPasswordError(res.error || 'Failed to update password');
      }
    } catch {
      setPasswordError('Server connection error');
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#080a0f] overflow-y-auto text-slate-100 p-4 md:p-6 space-y-6">
      {/* Profile Header Card */}
      <div className="rounded-2xl bg-[#0c121e] border border-cyan-500/30 p-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-600/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 relative z-10">
          <div className="relative">
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.username}
              className="w-20 h-20 rounded-2xl bg-slate-900 border-2 border-cyan-400 object-cover shadow-[0_0_15px_rgba(0,210,255,0.3)]"
            />
            {currentUser.online && (
              <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-[#0c121e]" />
            )}
          </div>

          <div className="flex-1 text-center sm:text-left min-w-0">
            <div className="flex items-center justify-center sm:justify-start gap-2 font-bold text-lg text-white font-display">
              <span>{currentUser.fullName}</span>
              {currentUser.verifiedBlueTick && <BlueTick size="md" />}
            </div>
            <div className="text-xs text-cyan-400 font-mono mt-0.5">@{currentUser.username}</div>
            <div className="text-xs text-slate-300 mt-2 italic bg-slate-900/60 p-2 rounded-xl border border-slate-800">
              "{currentUser.bio || 'Unknown Gamer Clan Member'}"
            </div>
            {currentUser.customStatus && (
              <div className="text-[11px] text-amber-300 mt-1.5 flex items-center justify-center sm:justify-start gap-1">
                <span>{currentUser.customStatus}</span>
              </div>
            )}
          </div>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-cyan-300 transition-colors self-center sm:self-start"
          >
            <Edit3 size={14} />
            <span>{isEditing ? 'Cancel' : 'Edit Profile'}</span>
          </button>
        </div>

        {/* EDIT PROFILE FORM */}
        {isEditing && (
          <form onSubmit={handleSaveProfile} className="mt-5 pt-4 border-t border-slate-800 space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">Display Name</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#090d16] border border-slate-700 text-white outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Gaming Bio / Clan Role</label>
              <input
                type="text"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#090d16] border border-slate-700 text-white outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Custom Status Message</label>
              <input
                type="text"
                value={customStatus}
                onChange={(e) => setCustomStatus(e.target.value)}
                placeholder="e.g. ⚡ In Scrims Tournament"
                className="w-full px-3 py-2 rounded-xl bg-[#090d16] border border-slate-700 text-white outline-none focus:border-cyan-400"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-colors cursor-pointer"
            >
              Save Profile Changes
            </button>
          </form>
        )}
      </div>

      {/* Account & Security Settings */}
      <div className="rounded-2xl bg-[#0c121e] border border-slate-800 p-4 space-y-3 text-xs">
        <div className="font-bold text-white text-xs uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-800">
          Security & Account
        </div>

        <button
          onClick={() => setShowPasswordModal(true)}
          className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-900/60 hover:bg-slate-850 text-slate-200 transition-colors"
        >
          <div className="flex items-center gap-3">
            <KeyRound size={16} className="text-cyan-400" />
            <div className="text-left">
              <div className="font-semibold text-white">Change Account Password</div>
              <div className="text-[10px] text-slate-400">Update your gamer credentials</div>
            </div>
          </div>
          <span className="text-[11px] text-cyan-400 font-semibold">Change</span>
        </button>

        <button
          onClick={onOpenWhatsApp}
          className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-900/60 hover:bg-slate-850 text-slate-200 transition-colors"
        >
          <div className="flex items-center gap-3">
            <Phone size={16} className="text-emerald-400" />
            <div className="text-left">
              <div className="font-semibold text-white">WhatsApp Service & Helpdesk</div>
              <div className="text-[10px] text-slate-400">{WHATSAPP_SERVICE_NUMBER}</div>
            </div>
          </div>
          <span className="text-[11px] text-emerald-400 font-semibold">Connect</span>
        </button>
      </div>

      {/* Preferences & Privacy Settings */}
      <div className="rounded-2xl bg-[#0c121e] border border-slate-800 p-4 space-y-3 text-xs">
        <div className="font-bold text-white text-xs uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-800">
          Preferences & Notifications
        </div>

        <div className="flex items-center justify-between p-2.5">
          <div className="flex items-center gap-2.5">
            <ShieldCheck size={16} className="text-cyan-400" />
            <div>
              <div className="font-semibold text-white">Read Receipts</div>
              <div className="text-[10px] text-slate-400">Show double blue checkmarks when messages are read</div>
            </div>
          </div>
          <input
            type="checkbox"
            checked={readReceipts}
            onChange={(e) => setReadReceipts(e.target.checked)}
            className="w-4 h-4 accent-cyan-500 cursor-pointer"
          />
        </div>

        <div className="flex items-center justify-between p-2.5">
          <div className="flex items-center gap-2.5">
            <Bell size={16} className="text-cyan-400" />
            <div>
              <div className="font-semibold text-white">In-App Notification Sounds</div>
              <div className="text-[10px] text-slate-400">Tactile audio alerts on clan message receipt</div>
            </div>
          </div>
          <input
            type="checkbox"
            checked={soundEnabled}
            onChange={(e) => setSoundEnabled(e.target.checked)}
            className="w-4 h-4 accent-cyan-500 cursor-pointer"
          />
        </div>
      </div>

      {/* Logout Button */}
      <div className="pt-2">
        <button
          onClick={onLogout}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-red-950/50 hover:bg-red-900/60 border border-red-500/30 text-red-300 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
        >
          <LogOut size={16} />
          <span>Exit Arena (Logout)</span>
        </button>
      </div>

      {/* CHANGE PASSWORD MODAL */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-[#0a0f18] border border-cyan-500/40 p-5 space-y-4 text-xs text-slate-200">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-white text-sm">Change Password</h3>
              <button onClick={() => setShowPasswordModal(false)}>
                <X size={16} />
              </button>
            </div>

            {passwordError && (
              <div className="p-2.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300">
                {passwordError}
              </div>
            )}

            {passwordSuccess && (
              <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 flex items-center gap-1.5">
                <Check size={14} />
                <span>Password updated successfully!</span>
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-3">
              <div>
                <label className="block text-slate-300 mb-1">Current Password</label>
                <input
                  type="password"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  placeholder="Enter current password"
                  className="w-full px-3 py-2 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">New Password</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password"
                  className="w-full px-3 py-2 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Confirm New Password</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm new password"
                  className="w-full px-3 py-2 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold"
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
