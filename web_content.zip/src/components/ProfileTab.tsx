import React, { useState } from 'react';
import {
  Crown,
  Settings,
  Edit,
  Sparkles,
  Lock,
  MessageSquare,
  Plus,
  Zap,
  Image as ImageIcon
} from 'lucide-react';
import { Character, UserProfile } from '../types';

interface ProfileTabProps {
  userProfile: UserProfile;
  characters: Character[];
  onSelectCharacter: (char: Character) => void;
  onOpenSettings: () => void;
  onOpenCreate: () => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  userProfile,
  characters,
  onSelectCharacter,
  onOpenSettings,
  onOpenCreate,
}) => {
  const [activeProfileTab, setActiveProfileTab] = useState<
    'الشخصيات' | 'المجموعات' | 'المجموعة' | 'معرض الصور'
  >('الشخصيات');

  const myCharacters = characters.filter(
    (char) => char.creatorName === 'samrae bounadar' || char.isPrivate
  );

  return (
    <div className="pb-24 pt-2 px-4 max-w-lg mx-auto dir-rtl">
      {/* Top Header Controls */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2 space-x-reverse">
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-xl bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-white"
            title="الإعدادات"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-pink-500/10 border border-pink-500/30 text-pink-300 text-xs font-semibold px-3 py-1 rounded-full">
          {userProfile.freeMessages} رسالة مجانية
        </div>
      </div>

      {/* User Info Header matching Screenshot 3 & 4 */}
      <div className="flex flex-col items-center text-center mb-6">
        <div className="relative mb-2">
          <img
            src={userProfile.avatar}
            alt={userProfile.name}
            className="w-20 h-20 rounded-full object-cover border-2 border-pink-500/50 shadow-lg shadow-pink-500/20"
          />
          <button
            onClick={() => alert('يمكنك تغيير الصورة الشخصية في إعدادات الحساب.')}
            className="absolute bottom-0 left-0 bg-slate-800 border border-slate-700 text-white p-1.5 rounded-full shadow-md hover:bg-pink-600 transition-colors"
          >
            <Edit className="w-3.5 h-3.5" />
          </button>
        </div>

        <h2 className="text-lg font-bold text-white mb-0.5">
          {userProfile.name}
        </h2>
        <span className="text-xs text-slate-400 font-mono">
          UID:{userProfile.uid}
        </span>
      </div>

      {/* Premium Subscription Banner matching Screenshots */}
      <div className="bg-gradient-to-r from-pink-950/40 via-purple-900/30 to-slate-900 border border-pink-500/30 rounded-2xl p-4 mb-6 shadow-xl relative overflow-hidden">
        <div className="flex items-start justify-between relative z-10">
          <div>
            <div className="flex items-center space-x-1.5 space-x-reverse mb-1">
              <Crown className="w-5 h-5 text-pink-400 fill-pink-400" />
              <h3 className="font-bold text-pink-200 text-base">مميز</h3>
            </div>
            <p className="text-xs text-slate-300 mb-2">
              نماذج مميزة ومزايا احترافية لا محدودة
            </p>
            <div className="inline-flex items-center space-x-2 space-x-reverse bg-pink-500/20 border border-pink-500/30 px-2.5 py-1 rounded-lg text-pink-300 text-xs font-bold">
              <span>20% من السعر الأصلي</span>
              <span className="text-[11px] opacity-80 dir-ltr font-mono">
                00:19:43
              </span>
            </div>
          </div>

          <button
            onClick={() => alert('اشتراك مميز: رسائل غير محدودة ووصول لكافة النماذج المتقدمة!')}
            className="bg-pink-600 hover:bg-pink-500 text-white font-bold px-4 py-2 rounded-xl text-xs shadow-lg shadow-pink-600/30 transition-all self-center"
          >
            اشترك
          </button>
        </div>
      </div>

      {/* Profile Sub Tabs matching Screenshot 3 & 4 */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-4 text-xs font-bold">
        {[
          'الشخصيات',
          'المجموعات',
          'المجموعة',
          'معرض الصور',
        ].map((tab) => {
          const isActive = activeProfileTab === tab;
          return (
            <button
              key={tab}
              onClick={() => setActiveProfileTab(tab as any)}
              className={`pb-2 px-1 transition-all border-b-2 ${
                isActive
                  ? 'border-pink-500 text-white font-bold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab}
            </button>
          );
        })}
      </div>

      {/* Tab Contents: My Characters List */}
      {activeProfileTab === 'الشخصيات' ? (
        <div className="space-y-3">
          {myCharacters.map((char) => (
            <div
              key={char.id}
              onClick={() => onSelectCharacter(char)}
              className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 hover:border-pink-500/40 rounded-2xl p-3 flex items-center justify-between transition-all cursor-pointer shadow-sm"
            >
              <div className="flex items-center space-x-3 space-x-reverse flex-1 min-w-0">
                <img
                  src={char.avatar}
                  alt={char.name}
                  className="w-12 h-12 rounded-full object-cover border border-pink-500/30 flex-shrink-0"
                />
                <div className="flex-1 min-w-0 pr-1">
                  <div className="flex items-center justify-between mb-0.5">
                    <h4 className="text-sm font-bold text-white truncate">
                      {char.nameAr || char.name}
                    </h4>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {char.createdAt || '2026-07-25'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 truncate mb-1">
                    {char.description}
                  </p>
                  <span className="inline-flex items-center gap-1 bg-purple-500/20 text-purple-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-purple-500/30">
                    <Lock className="w-2.5 h-2.5" />
                    خاص
                  </span>
                </div>
              </div>
            </div>
          ))}

          {/* Quick Create Button */}
          <button
            onClick={onOpenCreate}
            className="w-full mt-4 bg-slate-800/60 hover:bg-slate-800 border-2 border-dashed border-pink-500/30 hover:border-pink-500/60 rounded-2xl p-4 flex items-center justify-center space-x-2 space-x-reverse text-pink-300 text-xs font-bold transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>إنشاء شخصية جديدة</span>
          </button>
        </div>
      ) : (
        <div className="text-center py-12 px-4 bg-slate-800/40 rounded-2xl border border-slate-800">
          <Sparkles className="w-10 h-10 text-pink-400/40 mx-auto mb-2" />
          <p className="text-slate-300 text-xs font-semibold">
            لا توجد عناصر في قسم {activeProfileTab} حالياً
          </p>
        </div>
      )}
    </div>
  );
};
