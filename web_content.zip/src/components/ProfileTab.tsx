import React, { useState } from 'react';
import {
  User,
  Users,
  Flame,
  Zap,
  Settings,
  Bot,
  Copy,
  Sparkles,
  MessageSquare,
  History,
  Download,
  Upload,
  Award,
  Mail,
  X,
  Check,
  Shield,
  PlusCircle,
  LogIn
} from 'lucide-react';
import { UserProfile, UserProgressData, ActivityLogItem } from '../types';
import { sound } from '../services/sound';

interface ProfileTabProps {
  profile: UserProfile;
  progress: UserProgressData;
  allAccounts: UserProfile[];
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onCreateAccount: (name: string, email?: string, pin?: string, targetExam?: string, dailyGoal?: number) => void;
  onSwitchAccount: (userId: string, pin?: string) => boolean;
  onDeleteAccount: (userId: string) => void;
  onExportBackup: () => void;
  onImportBackup: (jsonStr: string) => boolean;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  profile,
  progress,
  allAccounts,
  onUpdateProfile,
  onCreateAccount,
  onSwitchAccount,
  onDeleteAccount,
  onExportBackup,
  onImportBackup,
}) => {
  // Modals
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAccountsModal, setShowAccountsModal] = useState(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);

  // Edit Goal Form
  const [editName, setEditName] = useState(profile.name);
  const [editExam, setEditExam] = useState(profile.targetExam);
  const [editGoal, setEditGoal] = useState(profile.dailyGoal || 15);
  const [editPin, setEditPin] = useState(profile.pin || '');
  const [editVoice, setEditVoice] = useState(profile.voiceLang || 'en-US');

  // Create Account Form
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newName, setNewName] = useState('');
  const [newExam, setNewExam] = useState('Bangladesh Civil Service (BCS)');
  const [newGoal, setNewGoal] = useState(15);
  const [newPin, setNewPin] = useState('');

  // Switch Account PIN prompt
  const [selectedSwitchUser, setSelectedSwitchUser] = useState<UserProfile | null>(null);
  const [enteredPin, setEnteredPin] = useState('');
  const [pinError, setPinError] = useState('');

  // AI Prompt Studio
  const [promptMode, setPromptMode] = useState<'dossier' | 'quiz' | 'essay' | 'vault'>('dossier');
  const [copyFeedback, setCopyFeedback] = useState(false);

  // Feedback Form
  const [feedbackText, setFeedbackText] = useState('');

  const targetWord = progress.todayLearned[0] || 'Callous';
  const weakWordsList = progress.mistakesVault.map(m => m.word).slice(0, 8).join(', ') || 'Abase, Abash, Abate, Callous';

  const generatePrompt = () => {
    if (promptMode === 'dossier') {
      return `Master Prompt: English Word Meaning in Comprehensive Detail\nAct as an expert English lexicographer, linguist, and senior Bangladesh Civil Service (BCS) vocabulary instructor.\nExplain the following English word in exhaustive detail for an advanced candidate preparing for ${profile.targetExam}.\nTarget Word: [${targetWord}]\n\nFollow this 17-section structure:\n1. Word Identification & Exact Pronunciation\n2. Core Meaning & Connotation\n3. Parts of Speech Matrix & Derived Forms\n4. Definitions by Register and Context\n5. 10 Examination Example Sentences (with Bengali translation)\n6. Synonyms and Antonyms by Nuance\n7. Nuance Differences & Lookalike Confusions\n8. Etymology & Roots\n9. Common Collocations & Natural Expressions\n10. Grammar Patterns & Prepositions\n11. Register & Pragmatic Tone\n12. Common Examination Traps & Errors\n13. Bengali Mnemonic Hook (মনে রাখার টেকনিক)\n14. Literary & Academic Usage\n15. 5-Question BCS/Bank Exam MCQ Battery\n16. Quick Revision Summary\n17. Final Written Essay Anchor Quote`;
    } else if (promptMode === 'quiz') {
      return `Act as a Senior Question Setter for the ${profile.targetExam}.\nGenerate a rigorous 5-Question Diagnostic Lexical Battery specifically focused on the target word: "${targetWord}".\n\nInclude:\nQuestion 1: Lexical Meaning & Near-Synonym Trap\nQuestion 2: Direct High-Yield Polar Antonym\nQuestion 3: Prepositional Complementation & Collocation Fill-in-the-blank\nQuestion 4: Complex Sentence Completion\nQuestion 5: Error Detection / Sentence Correction\n\nProvide exhaustive answers with bilingual Bengali explanations.`;
    } else if (promptMode === 'essay') {
      return `Act as an expert English Stylist and Written English Examiner for ${profile.targetExam}.\nShow how to masterfully incorporate the word "${targetWord}" into high-scoring competitive essays and précis writing.\n\nProvide:\n1. 3 Sophisticated Topic Sentences incorporating "${targetWord}".\n2. A cohesive 120-word model editorial paragraph demonstrating natural collocations.\n3. 2 Critical stylistic caveats to prevent awkward overuse.`;
    } else {
      return `Act as a cognitive vocabulary remediator and lexicographer for ${profile.targetExam}.\nHere is my current list of weak / missed vocabulary words from my Mistakes Vault:\n[${weakWordsList}]\n\nPlease conduct a Diagnostic Lookalike & Trap Remediation Clinic:\n1. Group these words by root confusion or semantic traps.\n2. Create a clean comparative distinction table.\n3. Provide a memorable Bengali mnemonic hook for each weak word.`;
    }
  };

  const handleCopyPrompt = async () => {
    const text = generatePrompt();
    try {
      await navigator.clipboard.writeText(text);
      setCopyFeedback(true);
      sound.triggerFloatingXp(10);
      sound.triggerCelebration(40, 30);
      setTimeout(() => setCopyFeedback(false), 2500);
    } catch {
      // Fallback
      alert('Prompt selected. Please use Ctrl+C / Cmd+C.');
    }
  };

  const handleLaunchAI = (platform: 'gemini' | 'chatgpt') => {
    handleCopyPrompt();
    const url = platform === 'gemini' ? 'https://gemini.google.com/app' : 'https://chatgpt.com';
    window.open(url, '_blank');
  };

  const handleSaveProfile = () => {
    onUpdateProfile({
      name: editName.trim() || 'Aspirant',
      targetExam: editExam,
      dailyGoal: Number(editGoal) || 15,
      pin: editPin.trim(),
      voiceLang: editVoice as 'en-US' | 'en-GB'
    });
    setShowEditModal(false);
    sound.triggerFloatingXp(10);
  };

  const handleCreateNewAccount = () => {
    if (!newName.trim()) {
      alert('Please enter a name for the new account.');
      return;
    }
    onCreateAccount(newName, undefined, newPin, newExam, Number(newGoal));
    setIsCreatingNew(false);
    setShowAccountsModal(false);
    setNewName('');
    setNewPin('');
    sound.triggerCelebration();
  };

  const handleSwitchAccountSubmit = () => {
    if (!selectedSwitchUser) return;
    const res = onSwitchAccount(selectedSwitchUser.id, enteredPin);
    if (res) {
      setShowAccountsModal(false);
      setSelectedSwitchUser(null);
      setEnteredPin('');
      setPinError('');
    } else {
      setPinError('Incorrect 4-digit PIN');
    }
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content && onImportBackup(content)) {
        alert('Data successfully restored!');
      } else {
        alert('Invalid JSON file format.');
      }
    };
    reader.readAsText(file);
  };

  const handleSendFeedback = () => {
    if (!feedbackText.trim()) return;
    const subject = encodeURIComponent('VocabMuse App Feedback - Competitive Aspirant');
    const body = encodeURIComponent(`Feedback:\n\n${feedbackText}\n\nProfile: ${profile.name} (${profile.targetExam})`);
    window.location.href = `mailto:jahidhasan.eng.sust@gmail.com?subject=${subject}&body=${body}`;
    setShowFeedbackModal(false);
    setFeedbackText('');
  };

  const avatarLetter = (profile.name?.charAt(0) || 'A').toUpperCase();

  return (
    <div className="flex-1 smooth-scroll p-4 space-y-4 pb-28 max-w-md mx-auto w-full">
      
      {/* Profile Card */}
      <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
        <div className="flex items-center gap-3.5">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 text-white flex items-center justify-center font-black text-2xl shadow-[0_3px_0_0_#059669]">
            {avatarLetter}
          </div>

          <div className="flex-1 min-w-0">
            <h3 className="font-black text-lg text-slate-900 dark:text-white truncate">
              {profile.name}
            </h3>
            <p className="text-xs text-slate-500 font-semibold truncate">
              Target: {profile.targetExam}
            </p>
            <div className="flex items-center gap-2 mt-1 text-[11px] font-bold">
              <span className="text-amber-500 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 fill-current" /> {profile.streak} Days
              </span>
              <span className="text-slate-300">&bull;</span>
              <span className="text-blue-500 flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 fill-current" /> {profile.xp} XP
              </span>
              <span className="text-slate-300">&bull;</span>
              <span className="text-emerald-600 dark:text-emerald-400">
                Goal: {profile.dailyGoal}/day
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setEditName(profile.name);
              setEditExam(profile.targetExam);
              setEditGoal(profile.dailyGoal);
              setEditPin(profile.pin || '');
              setEditVoice(profile.voiceLang || 'en-US');
              setShowEditModal(true);
            }}
            className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-extrabold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5"
          >
            <Settings className="w-3.5 h-3.5" /> Edit Goals
          </button>

          <button
            onClick={() => setShowAccountsModal(true)}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-[0_3px_0_0_#059669] transition-all flex items-center gap-1.5"
          >
            <Users className="w-3.5 h-3.5" /> Accounts ({allAccounts.length})
          </button>
        </div>
      </div>

      {/* AI Companion Studio */}
      <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 text-white rounded-3xl p-5 border-2 border-indigo-800/60 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 flex items-center justify-center text-amber-300">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-sm tracking-tight">AI Companion Studio</h3>
              <p className="text-[10px] text-indigo-300 font-medium">Precision Prompts for Gemini & ChatGPT</p>
            </div>
          </div>
          <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold border border-emerald-500/30">
            Exam Caliber
          </span>
        </div>

        <p className="text-xs text-slate-300 font-bengali leading-relaxed">
          আপনার বর্তমান নির্বাচিত শব্দ, দুর্বল শব্দ ব্যাংক ও পরীক্ষার টার্গেট অনুযায়ী পূর্ণাঙ্গ মাস্টার প্রম্পট তৈরি করে সরাসরি AI তে পাঠান।
        </p>

        {/* Prompt Modes */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          {[
            { id: 'dossier', label: '1. 17-Section Master' },
            { id: 'quiz', label: '2. 5-Question Drill' },
            { id: 'essay', label: '3. Essay Writing Anchor' },
            { id: 'vault', label: '4. Weakness Clinic' },
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => setPromptMode(m.id as any)}
              className={`p-2 rounded-xl text-left font-bold transition-all ${
                promptMode === m.id
                  ? 'bg-indigo-600 text-white border border-indigo-400 shadow-sm'
                  : 'bg-slate-800/80 text-slate-300 border border-slate-700 hover:bg-slate-700'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>

        {/* Prompt Preview */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-300">
            <span>Generated Master Prompt:</span>
            <span className="text-emerald-400 font-mono text-[10px]">
              Word: {targetWord}
            </span>
          </div>

          <textarea
            readOnly
            rows={4}
            value={generatePrompt()}
            className="w-full p-3 rounded-2xl bg-black/40 border border-slate-700 text-[11px] text-slate-200 font-mono select-all focus:outline-none focus:ring-1 focus:ring-indigo-400 leading-relaxed"
          />
        </div>

        {/* Action Buttons */}
        <div className="space-y-2">
          <button
            onClick={handleCopyPrompt}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-extrabold text-xs rounded-2xl shadow-[0_4px_0_0_#059669] transition-all flex items-center justify-center gap-1.5"
          >
            {copyFeedback ? (
              <>
                <Check className="w-4 h-4 text-emerald-200" />
                <span>Copied to Clipboard!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy Prompt to Clipboard</span>
              </>
            )}
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleLaunchAI('gemini')}
              className="py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-[0_3px_0_0_#0369a1] transition-all flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" /> Launch Gemini
            </button>
            <button
              onClick={() => handleLaunchAI('chatgpt')}
              className="py-2.5 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-[0_3px_0_0_#0d9488] transition-all flex items-center justify-center gap-1.5"
            >
              <MessageSquare className="w-3.5 h-3.5" /> Launch ChatGPT
            </button>
          </div>
        </div>
      </div>

      {/* Offline Activity Log */}
      <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wide flex items-center gap-1.5">
            <History className="w-4 h-4 text-emerald-500" /> Offline Activity Log
          </span>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
            Device LocalStorage
          </span>
        </div>

        <p className="text-xs text-slate-500 font-bengali leading-relaxed">
          আপনার লগইন সেশন ও পড়াশোনার প্রতিটি কার্যক্রম এই ডিভাইসের লোকাল স্টোরেজে সংরক্ষিত।
        </p>

        <div className="space-y-1.5 max-h-48 smooth-scroll pr-1 text-xs">
          {progress.activityLog.map((log: ActivityLogItem) => (
            <div
              key={log.id}
              className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60"
            >
              <div className="flex items-center gap-2 min-w-0 pr-2">
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 shrink-0">
                  {log.type}
                </span>
                <span className="text-xs text-slate-700 dark:text-slate-200 truncate">
                  {log.text}
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono shrink-0">
                {log.time}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Portable Data Backup & Restore */}
      <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-slate-400">
          <span>PORTABLE DATA SYNC</span>
          <span className="text-emerald-500">JSON Archive</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onExportBackup}
            className="flex-1 py-2.5 border-2 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all"
          >
            <Download className="w-3.5 h-3.5" /> Backup JSON
          </button>

          <label className="flex-1 py-2.5 border-2 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-all">
            <Upload className="w-3.5 h-3.5" /> Restore JSON
            <input
              type="file"
              accept=".json"
              onChange={handleFileImport}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Creator & Academic Attribution */}
      <div className="bg-gradient-to-br from-slate-100 to-slate-200 dark:from-[#111827] dark:to-slate-900 rounded-3xl p-4 border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
        <div className="font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
          <Award className="w-4 h-4 text-emerald-600" /> Designed by Md. Jahid Hasan
        </div>
        <p className="text-slate-600 dark:text-slate-300 font-medium leading-relaxed font-bengali">
          ইংরেজি গ্র্যাজুয়েট, শাহজালাল বিজ্ঞান ও প্রযুক্তি বিশ্ববিদ্যালয় (SUST)। বিসিএস, ব্যাংক ও বিশ্ববিদ্যালয় ভর্তি পরীক্ষার প্রস্তুতি সহায়ক প্ল্যাটফর্ম।
        </p>
        <div className="pt-1 flex items-center justify-between">
          <div className="flex items-center gap-1 text-[11px] text-slate-500 font-mono truncate max-w-[200px]">
            <Mail className="w-3.5 h-3.5 shrink-0" />
            <a
              href="mailto:jahidhasan.eng.sust@gmail.com"
              className="text-blue-500 underline font-bold truncate"
            >
              jahidhasan.eng.sust@gmail.com
            </a>
          </div>
          <button
            onClick={() => setShowFeedbackModal(true)}
            className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-[10px] font-bold shadow-sm hover:bg-emerald-700"
          >
            Feedback
          </button>
        </div>
      </div>

      {/* Edit Profile Modal */}
      {showEditModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-[#111827] max-w-sm w-full rounded-3xl p-5 border-2 border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-black text-sm text-slate-900 dark:text-white">
                Edit Learning Target
              </h3>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white font-semibold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Target Examination
                </label>
                <select
                  value={editExam}
                  onChange={(e) => setEditExam(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white font-semibold"
                >
                  <option value="Bangladesh Civil Service (BCS)">Bangladesh Civil Service (BCS)</option>
                  <option value="Combined Bank Officer">Combined Bank Officer (Cash/General)</option>
                  <option value="UPSC Civil Services">UPSC Civil Services (IAS/IPS)</option>
                  <option value="IBA / MBA University Admission">IBA / MBA Admission</option>
                  <option value="GRE / Higher Studies">GRE / SAT / Higher Academic</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Daily Word Goal
                </label>
                <input
                  type="number"
                  min="5"
                  max="50"
                  value={editGoal}
                  onChange={(e) => setEditGoal(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Voice Accent
                </label>
                <select
                  value={editVoice}
                  onChange={(e) => setEditVoice(e.target.value as 'en-US' | 'en-GB')}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white font-semibold"
                >
                  <option value="en-US">US American English</option>
                  <option value="en-GB">UK British English</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Offline PIN (Optional 4 digits)
                </label>
                <input
                  type="password"
                  maxLength={4}
                  value={editPin}
                  onChange={(e) => setEditPin(e.target.value)}
                  placeholder="e.g. 1234"
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white font-mono"
                />
              </div>
            </div>

            <button
              onClick={handleSaveProfile}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl shadow-[0_4px_0_0_#059669] transition-all"
            >
              Save Changes
            </button>
          </div>
        </div>
      )}

      {/* Switch / Create Account Modal */}
      {showAccountsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-[#111827] max-w-sm w-full rounded-3xl p-5 border-2 border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-500" /> Device User Accounts
              </h3>
              <button
                onClick={() => {
                  setShowAccountsModal(false);
                  setIsCreatingNew(false);
                  setSelectedSwitchUser(null);
                  setEnteredPin('');
                  setPinError('');
                }}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {!isCreatingNew && !selectedSwitchUser && (
              <div className="space-y-3">
                <p className="text-xs text-slate-500 font-bengali">
                  এই ডিভাইসে সংরক্ষিত যেকোনো অ্যাকাউন্টে প্রবেশ করুন অথবা নতুন প্রোফাইল তৈরি করুন:
                </p>

                <div className="space-y-2 max-h-52 smooth-scroll">
                  {allAccounts.map((acc) => {
                    const isCurrent = acc.id === profile.id;
                    return (
                      <div
                        key={acc.id}
                        className={`p-3 rounded-2xl border flex items-center justify-between transition-all ${
                          isCurrent
                            ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30'
                            : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0 pr-2">
                          <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                            {(acc.name.charAt(0) || 'A').toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <div className="font-extrabold text-xs text-slate-900 dark:text-white truncate">
                              {acc.name} {isCurrent && '(Active)'}
                            </div>
                            <div className="text-[10px] text-slate-400 truncate">
                              {acc.targetExam.split('(')[0]} &bull; {acc.xp} XP
                            </div>
                          </div>
                        </div>

                        {!isCurrent && (
                          <button
                            onClick={() => {
                              if (acc.pin) {
                                setSelectedSwitchUser(acc);
                              } else {
                                onSwitchAccount(acc.id);
                                setShowAccountsModal(false);
                              }
                            }}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl active:scale-95"
                          >
                            Switch
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>

                <button
                  onClick={() => setIsCreatingNew(true)}
                  className="w-full py-2.5 border-2 border-dashed border-emerald-500 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-2xl font-extrabold text-xs flex items-center justify-center gap-1.5 transition-all"
                >
                  <PlusCircle className="w-4 h-4" /> Create Another Account
                </button>
              </div>
            )}

            {/* PIN prompt */}
            {selectedSwitchUser && (
              <div className="space-y-3">
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  Account <strong>{selectedSwitchUser.name}</strong> is protected with a PIN.
                </p>

                <input
                  type="password"
                  maxLength={4}
                  placeholder="Enter 4-digit PIN"
                  value={enteredPin}
                  onChange={(e) => {
                    setEnteredPin(e.target.value);
                    setPinError('');
                  }}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-center font-mono text-base font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                />

                {pinError && (
                  <p className="text-xs text-rose-500 font-bold">{pinError}</p>
                )}

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedSwitchUser(null)}
                    className="flex-1 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleSwitchAccountSubmit}
                    className="flex-1 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-sm"
                  >
                    Login
                  </button>
                </div>
              </div>
            )}

            {/* Create Account Form */}
            {isCreatingNew && (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Aspirant Name
                  </label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g. Mahfuz Rahman"
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Target Exam
                  </label>
                  <select
                    value={newExam}
                    onChange={(e) => setNewExam(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Bangladesh Civil Service (BCS)">Bangladesh Civil Service (BCS)</option>
                    <option value="Combined Bank Officer">Combined Bank Officer (Cash/General)</option>
                    <option value="UPSC Civil Services">UPSC Civil Services</option>
                    <option value="IBA / MBA Admission">IBA / MBA Admission</option>
                    <option value="GRE / Higher Studies">GRE / SAT / Higher Academic</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Daily Goal (Words)
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="50"
                    value={newGoal}
                    onChange={(e) => setNewGoal(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Offline PIN (Optional 4 digits)
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="e.g. 1234"
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                  />
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    onClick={() => setIsCreatingNew(false)}
                    className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleCreateNewAccount}
                    className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm"
                  >
                    Create Account
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Feedback Modal */}
      {showFeedbackModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-[#111827] max-w-sm w-full rounded-3xl p-5 border-2 border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-black text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-emerald-500" /> Send Feedback to Contributor
              </h3>
              <button
                onClick={() => setShowFeedbackModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 font-bengali leading-relaxed">
              VocabMuse অ্যাপটিকে আরও উন্নত করার জন্য আপনার মতামত সরাসরি পাঠিয়ে দিন <strong>Md. Jahid Hasan</strong> (SUST)-এর নিকট।
            </p>

            <textarea
              rows={4}
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              placeholder="আপনার পরামর্শ, নতুন ফিচারের অনুরোধ বা মতামত লিখুন..."
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white font-medium"
            />

            <button
              onClick={handleSendFeedback}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl shadow-[0_4px_0_0_#059669] transition-all flex items-center justify-center gap-1.5"
            >
              <Mail className="w-4 h-4" /> Send via Email
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
