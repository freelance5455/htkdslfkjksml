import React, { useEffect, useState } from 'react';
import { deleteUser, signOut } from 'firebase/auth';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  Building2,
  Camera,
  CreditCard,
  Download,
  Globe,
  LogOut,
  Moon,
  Shield,
  Smartphone,
  Sun,
  Trash2,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import { compressImageFile, formatRelativeTime } from '../lib/mediaUtils';
import { BUILTIN_COURSES, TEVETA_COLLEGES } from '../lib/tevetaCatalog';
import type {
  LanguageCode,
  PaymentRecord,
  ThemeMode,
  UserPrivateInfo,
  UserProfile,
} from '../types';

interface ProfileTabProps {
  profile: UserProfile;
  privateInfo: UserPrivateInfo | null;
  isAdmin: boolean;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  onOpenAdmin: () => void;
  onOpenDownloadModal: () => void;
  onOpenCollegeNotice: () => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  profile,
  privateInfo,
  isAdmin,
  language,
  setLanguage,
  theme,
  setTheme,
  onOpenAdmin,
  onOpenDownloadModal,
  onOpenCollegeNotice,
}) => {
  const t = TRANSLATIONS[language];
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState(profile.fullName);
  const [bio, setBio] = useState(profile.bio || '');
  const [location, setLocation] = useState(profile.location || 'Lilongwe, Malawi');
  const [college, setCollege] = useState(profile.college || TEVETA_COLLEGES[0]);
  const [course, setCourse] = useState(profile.course || BUILTIN_COURSES[0].name);
  const [level, setLevel] = useState(profile.level || 'Level 1');
  const [profileVisibility, setProfileVisibility] = useState<'public' | 'friends' | 'private'>(
    privateInfo?.profileVisibility || 'public'
  );
  const [saving, setSaving] = useState(false);

  // Membership & Mobile Money Checkout
  const [provider, setProvider] = useState<'airtel_money' | 'tnm_mpamba'>('airtel_money');
  const [phoneNumber, setPhoneNumber] = useState(privateInfo?.phone || '');
  const [gatewayConfig, setGatewayConfig] = useState<{
    priceMwk: number;
    durationDays: number;
    providers: {
      airtel_money: { configured: boolean };
      tnm_mpamba: { configured: boolean };
    };
  } | null>(null);
  const [paymentStatusMsg, setPaymentStatusMsg] = useState<string | null>(null);
  const [paymentBusy, setPaymentBusy] = useState(false);
  const [paymentHistory, setPaymentHistory] = useState<PaymentRecord[]>([]);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  useEffect(() => {
    fetch('/api/payments/config')
      .then((r) => r.json())
      .then((data) => setGatewayConfig(data))
      .catch(() => setGatewayConfig(null));
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'payments'), where('uid', '==', profile.uid));
    const unsub = onSnapshot(
      q,
      (snap) => {
        setPaymentHistory(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<PaymentRecord, 'id'>) }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'payments')
    );
    return () => unsub();
  }, [profile.uid]);

  const handlePhotoUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    field: 'photoUrl' | 'coverUrl'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const compressed = await compressImageFile(file, field === 'coverUrl' ? 1080 : 480, 0.72);
    try {
      await updateDoc(doc(db, 'users', profile.uid), {
        [field]: compressed,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}`);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateDoc(doc(db, 'users', profile.uid), {
        fullName: fullName.trim() || profile.fullName,
        bio: bio.trim(),
        location: location.trim(),
        college,
        course,
        level,
        updatedAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'users', profile.uid, 'private', 'info'), {
        profileVisibility,
        language,
        theme,
        updatedAt: serverTimestamp(),
      });
      setEditing(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}`);
    } finally {
      setSaving(false);
    }
  };

  const handleInitiatePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentBusy(true);
    setPaymentStatusMsg(null);
    try {
      const resp = await fetch('/api/payments/initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: profile.uid,
          provider,
          phoneNumber,
        }),
      });
      const result = (await resp.json()) as {
        ok?: boolean;
        status?: 'pending' | 'failed' | 'unconfigured';
        reference?: string;
        phoneMasked?: string;
        amountMwk?: number;
        message?: string;
        error?: string;
      };

      const recordStatus = result.status || 'failed';
      await addDoc(collection(db, 'payments'), {
        uid: profile.uid,
        provider,
        phoneMasked: result.phoneMasked || '****',
        amountMwk: result.amountMwk || 1000,
        reference: result.reference || `TPW-${Date.now()}`,
        status: recordStatus,
        gatewayMessage: result.message || result.error || 'Payment request logged',
        createdAt: serverTimestamp(),
      });

      setPaymentStatusMsg(result.message || result.error || 'Payment status recorded.');
    } catch (err) {
      setPaymentStatusMsg(err instanceof Error ? err.message : 'Payment request failed.');
    } finally {
      setPaymentBusy(false);
    }
  };

  const handleDeleteAccount = async () => {
    try {
      await deleteDoc(doc(db, 'users', profile.uid, 'private', 'info'));
      await deleteDoc(doc(db, 'users', profile.uid));
      if (auth.currentUser) {
        await deleteUser(auth.currentUser);
      }
    } catch (err) {
      setPaymentStatusMsg(
        err instanceof Error
          ? `${err.message}. For security, please sign out and sign back in right before deleting your account.`
          : 'Account deletion requires a recent login.'
      );
      setConfirmDelete(false);
    }
  };

  const subStatus = privateInfo?.subscriptionStatus || 'free';

  return (
    <div className="space-y-6">
      {/* Profile Cover & Identity Card */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
        <div className="relative h-44 sm:h-52 bg-blue-900">
          <img
            src={profile.coverUrl || '/src/assets/images/cover_solar_campus_1794522898351.jpg'}
            alt="Profile cover"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <label className="absolute bottom-3 right-3 px-3 py-1.5 rounded-xl bg-slate-950/75 text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer hover:bg-slate-950">
            <Camera className="w-3.5 h-3.5" />
            <span>Change Cover</span>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => void handlePhotoUpload(e, 'coverUrl')}
              className="hidden"
            />
          </label>
        </div>

        <div className="px-5 pb-6">
          <div className="relative -mt-12 mb-3 flex flex-wrap items-end justify-between gap-4">
            <div className="relative w-24 h-24 rounded-full ring-4 ring-white dark:ring-slate-900 bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 flex items-center justify-center font-display font-bold text-2xl overflow-hidden">
              {profile.photoUrl ? (
                <img
                  src={profile.photoUrl}
                  alt={profile.fullName}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                profile.fullName.slice(0, 2).toUpperCase()
              )}
              <label className="absolute inset-x-0 bottom-0 bg-slate-950/70 text-white text-[10px] py-1 text-center cursor-pointer">
                Edit
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => void handlePhotoUpload(e, 'photoUrl')}
                  className="hidden"
                />
              </label>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {isAdmin && (
                <button
                  type="button"
                  onClick={onOpenAdmin}
                  className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Shield className="w-4 h-4" />
                  <span>{t.actions.adminPanel}</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => setEditing(!editing)}
                className="min-h-[40px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
              >
                {editing ? 'Cancel' : t.profile.editProfile}
              </button>
            </div>
          </div>

          <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white">
            {profile.fullName}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            @{profile.username} · {profile.role} · {profile.college || 'Malawi TEVETA'} · {profile.course || 'Technical Studies'} ({profile.level || 'Level 1'})
          </p>
          {profile.bio && (
            <p className="text-sm text-slate-700 dark:text-slate-300 mt-3 leading-relaxed">
              {profile.bio}
            </p>
          )}
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Location: {profile.location || 'Malawi'} · Visibility: {privateInfo?.profileVisibility || 'public'}
          </p>

          {editing && (
            <form onSubmit={handleSaveProfile} className="mt-5 pt-5 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <div className="grid sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Full Name"
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
                />
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="City / District"
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
                />
              </div>
              <textarea
                rows={2}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Write a short biography..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
              />
              <div className="grid sm:grid-cols-3 gap-3">
                <select
                  value={college}
                  onChange={(e) => setCollege(e.target.value)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  {TEVETA_COLLEGES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                <select
                  value={course}
                  onChange={(e) => setCourse(e.target.value)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  {BUILTIN_COURSES.map((c) => (
                    <option key={c.id} value={c.name}>{c.trade}</option>
                  ))}
                </select>
                <select
                  value={level}
                  onChange={(e) => setLevel(e.target.value)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  <option value="Level 1">Level 1</option>
                  <option value="Level 2">Level 2</option>
                  <option value="Level 3">Level 3</option>
                </select>
              </div>
              <div className="flex items-center justify-between gap-3">
                <select
                  value={profileVisibility}
                  onChange={(e) => setProfileVisibility(e.target.value as typeof profileVisibility)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                >
                  <option value="public">Profile: Public</option>
                  <option value="friends">Profile: Friends Only</option>
                  <option value="private">Profile: Private</option>
                </select>
                <button
                  type="submit"
                  disabled={saving}
                  className="min-h-[40px] px-5 py-2 rounded-xl bg-blue-700 text-white text-xs font-semibold"
                >
                  {saving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          )}
        </div>
      </section>

      {/* Monthly Membership & Malawi Mobile Money Checkout */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-display font-bold text-base flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-blue-600" />
              <span>{t.profile.membership} — {t.profile.membershipPrice}</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Status: <strong className="uppercase">{subStatus}</strong> · 30-day automatic renewal via Airtel Money or TNM Mpamba
            </p>
          </div>
        </div>

        <form onSubmit={handleInitiatePayment} className="space-y-3">
          <div className="grid sm:grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setProvider('airtel_money')}
              className={`p-3 rounded-xl border text-left text-xs font-semibold transition-colors cursor-pointer ${
                provider === 'airtel_money'
                  ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300'
                  : 'border-slate-200 dark:border-slate-700'
              }`}
            >
              <div>Airtel Money (Malawi)</div>
              <div className="text-[11px] font-normal text-slate-500 mt-0.5">
                {gatewayConfig?.providers.airtel_money.configured ? 'Merchant API Connected' : 'Awaiting server merchant key'}
              </div>
            </button>
            <button
              type="button"
              onClick={() => setProvider('tnm_mpamba')}
              className={`p-3 rounded-xl border text-left text-xs font-semibold transition-colors cursor-pointer ${
                provider === 'tnm_mpamba'
                  ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300'
                  : 'border-slate-200 dark:border-slate-700'
              }`}
            >
              <div>TNM Mpamba (Malawi)</div>
              <div className="text-[11px] font-normal text-slate-500 mt-0.5">
                {gatewayConfig?.providers.tnm_mpamba.configured ? 'Merchant API Connected' : 'Awaiting server merchant key'}
              </div>
            </button>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="tel"
              required
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder={provider === 'airtel_money' ? 'Enter your 099xxxxxxx number' : 'Enter your 088xxxxxxx number'}
              className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm"
            />
            <button
              type="submit"
              disabled={paymentBusy}
              className="min-h-[44px] px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
            >
              {paymentBusy ? 'Requesting...' : 'Pay MWK 1,000'}
            </button>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            Security notice: Never enter your mobile money PIN inside the app. Approve payment only on your phone&apos;s official Airtel/TNM USSD prompt. Subscriptions activate strictly upon verified gateway confirmation.
          </p>
        </form>

        {paymentStatusMsg && (
          <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs text-slate-700 dark:text-slate-300">
            {paymentStatusMsg}
          </div>
        )}

        {paymentHistory.length > 0 && (
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300">Payment History</h3>
            {paymentHistory.map((p) => (
              <div key={p.id} className="flex items-center justify-between text-xs py-1">
                <span>
                  {p.reference} · {p.provider.replace('_', ' ')} · MWK {p.amountMwk}
                </span>
                <span className="font-mono uppercase">{p.status}</span>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Preferences, PWA Install & Account Controls */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <h2 className="font-display font-bold text-base">App Settings & Device Installation</h2>

        <div className="grid sm:grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setLanguage(language === 'en' ? 'ny' : 'en')}
            className="min-h-[46px] px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-semibold cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-600" />
              <span>{t.profile.language}</span>
            </span>
            <span>{language === 'en' ? 'English' : 'Chichewa'}</span>
          </button>

          <button
            type="button"
            onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
            className="min-h-[46px] px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-semibold cursor-pointer"
          >
            <span className="flex items-center gap-2">
              {theme === 'light' ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-blue-400" />}
              <span>{t.profile.theme}</span>
            </span>
            <span className="capitalize">{theme} Mode</span>
          </button>
        </div>

        {/* Always-Available App Download / Install Card */}
        <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Smartphone className="w-5 h-5 text-blue-700 dark:text-blue-400 shrink-0" />
            <div>
              <p className="text-xs font-semibold text-slate-900 dark:text-white">
                {isInstalled
                  ? 'TEVET POWER APP Installed on This Device'
                  : 'Download / Install TEVET POWER APP on Your Phone'}
              </p>
              <p className="text-[11px] text-slate-600 dark:text-slate-400">
                Works offline with saved TEVETA notes, Android home-screen launch, and Capacitor APK build options.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {!isInstalled && isInstallable && (
              <button
                type="button"
                onClick={install}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>{t.actions.installApp}</span>
              </button>
            )}
            <button
              type="button"
              onClick={onOpenDownloadModal}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Options</span>
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenCollegeNotice}
          className="w-full min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
        >
          <span className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>{t.studentNotice.modalTitle}</span>
          </span>
          <span className="text-blue-700 dark:text-blue-400">{t.studentNotice.viewCollegesBtn}</span>
        </button>

        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => void signOut(auth)}
            className="min-h-[42px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>{t.actions.signOut}</span>
          </button>

          {!confirmDelete ? (
            <button
              type="button"
              onClick={() => setConfirmDelete(true)}
              className="min-h-[42px] px-4 py-2 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 flex items-center gap-2 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>{t.profile.deleteAccount}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDeleteAccount}
                className="px-3.5 py-2 rounded-xl bg-red-600 text-white text-xs font-semibold"
              >
                Confirm Permanent Delete
              </button>
              <button
                type="button"
                onClick={() => setConfirmDelete(false)}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </section>

      {showIOSGuide && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 max-w-sm w-full space-y-3">
            <h3 className="font-display font-bold text-base">Install on iPhone / iPad</h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              1. Tap the <strong>Share</strong> icon in Safari.<br />
              2. Scroll down and select <strong>Add to Home Screen</strong>.
            </p>
            <button
              type="button"
              onClick={() => setShowIOSGuide(false)}
              className="w-full py-2.5 rounded-xl bg-blue-700 text-white text-xs font-semibold"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
