import React, { useState } from 'react';
import {
  Calendar,
  Filter,
  Search,
  FileText,
  Share2,
  Trash2,
  ChevronRight,
  ArrowDownLeft,
  ArrowUpRight,
  RefreshCw,
  Plus,
} from 'lucide-react';
import { Voucher, VoucherType } from '../types/tally';
import { formatCurrency, formatINR, formatDateDisplay } from '../utils/tallyEngine';
import { triggerHaptic, soundManager } from '../utils/haptics';

interface DayBookViewProps {
  vouchers: Voucher[];
  onOpenVoucherInvoice: (voucher: Voucher) => void;
  onOpenNewVoucher: () => void;
  onDeleteVoucher: (id: string) => void;
}

export const DayBookView: React.FC<DayBookViewProps> = ({
  vouchers,
  onOpenVoucherInvoice,
  onOpenNewVoucher,
  onDeleteVoucher,
}) => {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dateFilter, setDateFilter] = useState<string>('');

  const filteredVouchers = vouchers.filter((vch) => {
    if (selectedType !== 'all' && vch.voucherType !== selectedType) return false;
    if (dateFilter && vch.date !== dateFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchNo = vch.voucherNumber.toLowerCase().includes(q);
      const matchParty = vch.partyLedgerName?.toLowerCase().includes(q);
      const matchNarr = vch.narration.toLowerCase().includes(q);
      const matchRows = vch.rows?.some((r) => r.ledgerName.toLowerCase().includes(q));
      if (!matchNo && !matchParty && !matchNarr && !matchRows) return false;
    }
    return true;
  });

  const totalAmount = filteredVouchers.reduce((sum, v) => sum + v.totalAmount, 0);

  const getTypeBadge = (type: VoucherType) => {
    switch (type) {
      case 'sales':
        return { label: 'SALES', bg: 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300' };
      case 'purchase':
        return { label: 'PURCHASE', bg: 'bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300' };
      case 'payment':
        return { label: 'PAYMENT', bg: 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300' };
      case 'receipt':
        return { label: 'RECEIPT', bg: 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300' };
      case 'contra':
        return { label: 'CONTRA', bg: 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300' };
      default:
        return { label: 'JOURNAL', bg: 'bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300' };
    }
  };

  return (
    <div className="flex-1 flex flex-col pb-8 text-slate-800 dark:text-slate-100">
      {/* Header bar */}
      <div className="bg-emerald-900 text-white px-4 py-3 flex items-center justify-between shadow-xs">
        <div>
          <div className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">
            Reports & Registers
          </div>
          <h2 className="text-base font-bold">Day Book (Journal Register)</h2>
        </div>
        <button
          onClick={() => {
            triggerHaptic('medium');
            onOpenNewVoucher();
          }}
          className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1.5 rounded-lg text-xs font-semibold shadow-xs touch-press"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Voucher</span>
        </button>
      </div>

      {/* Filters Strip */}
      <div className="p-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 space-y-2">
        {/* Search & Date */}
        <div className="flex items-center gap-2">
          <div className="flex-1 relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search voucher, party, narration..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="relative">
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="px-2 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono"
            />
          </div>

          {dateFilter && (
            <button
              onClick={() => setDateFilter('')}
              className="text-[10px] text-slate-400 hover:text-slate-600 underline"
            >
              Clear
            </button>
          )}
        </div>

        {/* Voucher Type Horizontal Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {['all', 'sales', 'purchase', 'payment', 'receipt', 'contra', 'journal'].map((type) => {
            const active = selectedType === type;
            return (
              <button
                key={type}
                onClick={() => {
                  triggerHaptic('light');
                  setSelectedType(type);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors touch-press ${
                  active
                    ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {type.toUpperCase()}
              </button>
            );
          })}
        </div>

        {/* Aggregate Summary */}
        <div className="flex items-center justify-between text-xs pt-1 px-1 text-slate-500 dark:text-slate-400 font-mono">
          <span>Found {filteredVouchers.length} Vouchers</span>
          <span className="font-bold text-slate-900 dark:text-white tabular-nums">
            Total: {formatCurrency(totalAmount)}
          </span>
        </div>
      </div>

      {/* Voucher List */}
      <div className="p-3 space-y-2.5">
        {filteredVouchers.length === 0 ? (
          <div className="p-8 text-center bg-white dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-slate-400">
            <Calendar className="w-8 h-8 mx-auto mb-2 opacity-40 text-emerald-600" />
            <p className="text-xs font-medium">No vouchers found for selected filters</p>
            <button
              onClick={() => {
                setSelectedType('all');
                setDateFilter('');
                setSearchQuery('');
              }}
              className="text-[11px] text-emerald-600 dark:text-emerald-400 underline mt-2 inline-block"
            >
              Reset all filters
            </button>
          </div>
        ) : (
          filteredVouchers.map((vch) => {
            const badge = getTypeBadge(vch.voucherType);
            const particulars =
              vch.partyLedgerName ||
              (vch.rows && vch.rows[0]?.ledgerName) ||
              'Multiple Ledgers';

            return (
              <div
                key={vch.id}
                className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 p-3 shadow-xs hover:border-emerald-500/60 transition-all space-y-2"
              >
                {/* Row 1: Date & Voucher Type */}
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded-md ${badge.bg}`}>
                      {badge.label}
                    </span>
                    <span className="font-mono text-slate-500 dark:text-slate-400 text-[11px]">
                      {vch.voucherNumber}
                    </span>
                  </div>
                  <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                    {formatDateDisplay(vch.date)}
                  </span>
                </div>

                {/* Row 2: Particulars & Amount */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                      {particulars}
                    </div>
                    {vch.items && vch.items.length > 0 && (
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
                        {vch.items.map((i) => `${i.itemName} (x${i.qty})`).join(', ')}
                      </div>
                    )}
                    {vch.rows && vch.rows.length > 0 && (
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5 line-clamp-1">
                        {vch.rows.map((r) => `${r.type}: ${r.ledgerName} (${formatINR(r.amount, false)})`).join(' · ')}
                      </div>
                    )}
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-sm font-bold font-mono text-slate-900 dark:text-white tabular-nums">
                      {formatCurrency(vch.totalAmount)}
                    </div>
                    {vch.cgstAmount + vch.sgstAmount + vch.igstAmount > 0 && (
                      <div className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400">
                        GST: {formatINR(vch.cgstAmount + vch.sgstAmount + vch.igstAmount)}
                      </div>
                    )}
                  </div>
                </div>

                {/* Row 3: Narration */}
                {vch.narration && (
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 italic bg-slate-50 dark:bg-slate-900/40 px-2 py-1 rounded-lg line-clamp-1">
                    "{vch.narration}"
                  </div>
                )}

                {/* Row 4: Action Bar */}
                <div className="pt-1.5 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        triggerHaptic('light');
                        onOpenVoucherInvoice(vch);
                      }}
                      className="flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold hover:underline"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Tax Bill / Details</span>
                    </button>
                  </div>

                  <button
                    onClick={() => {
                      if (confirm(`Delete voucher ${vch.voucherNumber}?`)) {
                        triggerHaptic('warning');
                        onDeleteVoucher(vch.id);
                      }
                    }}
                    className="p-1 text-slate-400 hover:text-rose-500 transition-colors"
                    title="Delete Voucher"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
