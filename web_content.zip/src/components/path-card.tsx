"use client";

import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import type { LearningPath } from "@/data/paths";
import { useLessonProgress } from "@/components/lesson-list";
import { toArabicDigits } from "@/lib/site";

export function PathCard({ path, index }: { path: LearningPath; index: number }) {
  const [completed] = useLessonProgress(path.slug);
  const total = path.lessons.length;
  const done = path.lessons.filter((l) => completed[l.id]).length;
  const percent = total ? (done / total) * 100 : 0;

  return (
    <Link
      href={`/paths/${path.slug}`}
      className="group relative flex h-full flex-col overflow-hidden rounded-[2rem] border border-border bg-card p-8 shadow-[0_30px_70px_-40px_rgba(23,36,58,0.55)] transition-all duration-500 hover:-translate-y-1 hover:border-gold/60 hover:shadow-[0_45px_90px_-40px_rgba(23,36,58,0.75)]"
    >
      <div className="pattern-lattice absolute inset-0 opacity-[0.04]" aria-hidden="true" />
      <div className="relative flex items-center justify-between gap-4">
        <span className="grid size-14 place-items-center rounded-2xl bg-navy font-serif text-2xl font-bold text-gold-light">
          {toArabicDigits(index + 1)}
        </span>
        <span className="text-xs text-gold">{path.stageLabel}</span>
      </div>
      <h2 className="relative mt-6 font-serif text-3xl font-bold text-navy">{path.title}</h2>
      <p className="relative mt-3 leading-7 text-navy/65">{path.description}</p>

      <div className="relative mt-8">
        <div className="mb-2 flex items-center justify-between text-xs text-navy/60 tabular-nums">
          <span>
            {toArabicDigits(done)} / {toArabicDigits(total)} دروس مكتملة
          </span>
          <span>{toArabicDigits(Math.round(percent))}٪</span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-stone">
          <div className="h-full rounded-full bg-gradient-to-l from-gold to-royal transition-all duration-700" style={{ width: `${percent}%` }} />
        </div>
      </div>

      <span className="relative mt-8 inline-flex items-center gap-2 text-sm font-medium text-royal transition-all group-hover:gap-3 group-hover:text-gold">
        ادخل المسار <ArrowLeft className="size-4" aria-hidden="true" />
      </span>
    </Link>
  );
}
