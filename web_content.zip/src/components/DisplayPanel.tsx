import { useEffect, useRef, useState } from 'react';
import { AlertCircle, Check, Copy } from 'lucide-react';
import type { AngleMode, CalculatorMode } from '../types/calculator';
import { formatDisplayNumber, toFractionString } from '../utils/mathEngine';

interface DisplayPanelProps {
  mode: CalculatorMode;
  angleMode: AngleMode;
  expression: string;
  historyExpression: string;
  evaluatedRaw: string | null;
  previewRaw: string | null;
  error: string | null;
  memoryValue: string;
  forceScientific: boolean;
  showFraction: boolean;
  onToggleFraction: () => void;
  onToggleAngleMode: () => void;
}

export function DisplayPanel({
  mode,
  angleMode,
  expression,
  historyExpression,
  evaluatedRaw,
  previewRaw,
  error,
  memoryValue,
  forceScientific,
  showFraction,
  onToggleFraction,
  onToggleAngleMode,
}: DisplayPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);

  const hasMemory = memoryValue !== '0' && memoryValue !== '';
  const activeRaw = evaluatedRaw ?? previewRaw;
  const fractionText = activeRaw ? toFractionString(activeRaw) : null;

  // Determine main primary display text
  let primaryText = '0';
  if (error) {
    primaryText = error;
  } else if (evaluatedRaw !== null) {
    if (showFraction && fractionText) {
      primaryText = fractionText;
    } else {
      primaryText = formatDisplayNumber(evaluatedRaw, forceScientific);
    }
  } else if (expression) {
    primaryText = expression;
  }

  // Secondary preview text while typing
  let secondaryPreview: string | null = null;
  if (!error && evaluatedRaw === null && previewRaw !== null && expression) {
    if (showFraction && fractionText) {
      secondaryPreview = `= ${fractionText}`;
    } else {
      const formattedPreview = formatDisplayNumber(previewRaw, forceScientific);
      // Only show live preview when it differs meaningfully from raw typed digits
      if (formattedPreview.replace(/,/g, '') !== expression.replace(/−/g, '-')) {
        secondaryPreview = `= ${formattedPreview}`;
      }
    }
  } else if (!error && evaluatedRaw !== null && fractionText && !showFraction && mode === 'scientific') {
    secondaryPreview = `Fraction: ${fractionText}`;
  } else if (!error && evaluatedRaw !== null && showFraction && fractionText) {
    secondaryPreview = `Decimal: ${formatDisplayNumber(evaluatedRaw, forceScientific)}`;
  }

  // Auto-scroll expression horizontally to the latest input
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollLeft = scrollRef.current.scrollWidth;
    }
  }, [primaryText, expression]);

  // Dynamic font sizing so large numbers or expressions stay crisp and legible
  const textLen = primaryText.length;
  let sizeClass = 'text-4xl sm:text-5xl';
  if (error) {
    sizeClass = 'text-xl sm:text-2xl';
  } else if (textLen > 18) {
    sizeClass = 'text-2xl sm:text-3xl';
  } else if (textLen > 12) {
    sizeClass = 'text-3xl sm:text-4xl';
  }

  const handleCopy = async () => {
    const textToCopy = error
      ? ''
      : evaluatedRaw !== null
        ? (showFraction && fractionText ? fractionText : evaluatedRaw.replace(/E/g, 'e'))
        : previewRaw
          ? previewRaw.replace(/E/g, 'e')
          : expression;
    if (!textToCopy) return;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Clipboard unavailable in restricted contexts
    }
  };

  return (
    <div
      className={`rounded-2xl bg-zinc-50 dark:bg-[#0D1117] border border-zinc-200/80 dark:border-zinc-800/80 px-4 sm:px-5 ${
        mode === 'scientific' ? 'py-3 sm:py-4' : 'py-4 sm:py-6'
      } flex flex-col justify-between transition-colors`}
    >
      {/* Top metadata row: clean unboxed indicators + functional controls */}
      <div className="flex items-center justify-between gap-2 min-h-[28px] text-xs text-zinc-500 dark:text-zinc-400">
        <div className="flex items-center gap-2 min-w-0 truncate">
          {mode === 'scientific' ? (
            <button
              type="button"
              onClick={onToggleAngleMode}
              className="font-mono font-semibold text-blue-600 dark:text-blue-400 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded px-1 -ml-1 whitespace-nowrap shrink-0"
              title="Toggle Degrees / Radians"
            >
              {angleMode}
            </button>
          ) : (
            <span className="font-medium text-zinc-500 dark:text-zinc-400 whitespace-nowrap shrink-0">
              Standard
            </span>
          )}

          {forceScientific && (
            <>
              <span aria-hidden="true">·</span>
              <span className="font-mono font-medium text-zinc-700 dark:text-zinc-300 whitespace-nowrap shrink-0">
                SCI
              </span>
            </>
          )}

          {hasMemory && (
            <>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums text-zinc-700 dark:text-zinc-300 truncate">
                M = {formatDisplayNumber(memoryValue, forceScientific)}
              </span>
            </>
          )}
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {fractionText && !error && (
            <button
              type="button"
              onClick={onToggleFraction}
              className={`px-2 py-1 rounded-lg text-xs font-mono font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                showFraction
                  ? 'bg-blue-600 text-white'
                  : 'bg-zinc-200/80 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-300/80 dark:hover:bg-zinc-700'
              }`}
              title="Toggle Decimal / Fraction display"
            >
              {showFraction ? 'Dec' : 'a/b'}
            </button>
          )}

          {(expression || evaluatedRaw !== null) && !error && (
            <button
              type="button"
              onClick={handleCopy}
              aria-label="Copy value"
              className="p-1.5 rounded-lg text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 hover:bg-zinc-200/70 dark:hover:bg-zinc-800 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
              title="Copy result"
            >
              {copied ? (
                <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
            </button>
          )}
        </div>
      </div>

      {/* Evaluated Expression Subline */}
      <div className="mt-1.5 min-h-[22px] text-right font-mono tabular-nums text-sm text-zinc-500 dark:text-zinc-400 overflow-x-auto no-scrollbar whitespace-nowrap">
        {historyExpression ? `${historyExpression} =` : ''}
      </div>

      {/* Primary Numeric / Expression Readout */}
      <div
        ref={scrollRef}
        role="status"
        aria-live="polite"
        className={`mt-1 min-h-[52px] sm:min-h-[60px] flex items-center justify-end overflow-x-auto no-scrollbar font-mono tabular-nums font-semibold tracking-tight whitespace-nowrap ${sizeClass} ${
          error
            ? 'text-rose-600 dark:text-rose-400 gap-2'
            : 'text-zinc-900 dark:text-zinc-50'
        }`}
      >
        {error && <AlertCircle className="w-5 h-5 shrink-0" aria-hidden="true" />}
        <span>{primaryText}</span>
      </div>

      {/* Live Preview / Fraction Subline */}
      <div className="mt-1 min-h-[22px] text-right font-mono tabular-nums text-sm sm:text-base font-medium text-zinc-500 dark:text-zinc-400 overflow-x-auto no-scrollbar whitespace-nowrap">
        {secondaryPreview ?? ''}
      </div>
    </div>
  );
}
