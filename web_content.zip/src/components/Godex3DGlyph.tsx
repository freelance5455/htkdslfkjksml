import React from 'react';

export interface Godex3DGlyphProps {
  size?: number;
  className?: string;
  withOrbitalRing?: boolean;
  withGlow?: boolean;
  interactive?: boolean;
}

/**
 * GODEX 3D Geometric Engineering Core Glyph
 * High-precision faceted isometric 'G' symbol matching the official GODEX identity.
 */
export const Godex3DGlyph: React.FC<Godex3DGlyphProps> = ({
  size = 120,
  className = '',
  withOrbitalRing = true,
  withGlow = true,
  interactive = false
}) => {
  return (
    <div 
      className={`relative flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Outer Glow Field */}
      {withGlow && (
        <div 
          className="absolute inset-0 rounded-full blur-2xl opacity-60 pointer-events-none transition-opacity duration-700"
          style={{
            background: 'radial-gradient(circle, rgba(124, 58, 237, 0.45) 0%, rgba(34, 211, 238, 0.25) 45%, transparent 70%)'
          }}
        />
      )}

      {/* Orbital Particle & Guide Rings */}
      {withOrbitalRing && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          {/* Outer Ring */}
          <div 
            className="absolute rounded-full border border-indigo-500/20 animate-orbit-slow"
            style={{ width: size * 1.35, height: size * 1.35 }}
          >
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]" />
            <div className="absolute -bottom-1 left-1/4 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-violet-400 shadow-[0_0_6px_#a855f7]" />
          </div>

          {/* Inner Tilted Coordinate Ring */}
          <div 
            className="absolute rounded-full border border-cyan-500/15"
            style={{
              width: size * 1.15,
              height: size * 1.15,
              transform: 'rotateX(60deg) rotateZ(30deg)'
            }}
          />
        </div>
      )}

      {/* Primary 3D Faceted G Vector */}
      <svg
        viewBox="0 0 160 160"
        width={size}
        height={size}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`relative z-10 drop-shadow-[0_12px_24px_rgba(0,0,0,0.6)] ${
          interactive ? 'hover:scale-105 transition-transform duration-300' : ''
        }`}
      >
        <defs>
          {/* Linear & Radial Gradients for 3D Isometric Shading */}
          <linearGradient id="facet-top" x1="40" y1="20" x2="120" y2="45" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#A78BFA" />
            <stop offset="60%" stopColor="#7C3AED" />
            <stop offset="100%" stopColor="#4C1D95" />
          </linearGradient>

          <linearGradient id="facet-left" x1="20" y1="40" x2="60" y2="120" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#818CF8" />
            <stop offset="50%" stopColor="#4F46E5" />
            <stop offset="100%" stopColor="#1E1B4B" />
          </linearGradient>

          <linearGradient id="facet-right" x1="120" y1="40" x2="145" y2="120" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#38BDF8" />
            <stop offset="60%" stopColor="#0284C7" />
            <stop offset="100%" stopColor="#082F49" />
          </linearGradient>

          <linearGradient id="facet-inner-core" x1="60" y1="60" x2="110" y2="105" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#22D3EE" />
            <stop offset="100%" stopColor="#6366F1" />
          </linearGradient>

          <linearGradient id="facet-bottom" x1="40" y1="130" x2="120" y2="150" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#3B82F6" />
            <stop offset="100%" stopColor="#1D4ED8" />
          </linearGradient>

          <filter id="core-glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* --- 3D Geometric Faceted 'G' Structure --- */}

        {/* Top Outer Crown Bar */}
        <polygon
          points="40,24 120,24 136,44 56,44"
          fill="url(#facet-top)"
          stroke="#C4B5FD"
          strokeWidth="0.75"
          strokeOpacity="0.6"
        />

        {/* Left Vertical Spine Front */}
        <polygon
          points="40,24 56,44 56,120 40,140"
          fill="url(#facet-left)"
          stroke="#A5B4FC"
          strokeWidth="0.75"
          strokeOpacity="0.5"
        />

        {/* Left Vertical Outer Side Thickness */}
        <polygon
          points="24,38 40,24 40,140 24,124"
          fill="#312E81"
          stroke="#4338CA"
          strokeWidth="0.5"
        />

        {/* Bottom Horizontal Base Bar */}
        <polygon
          points="40,140 56,120 120,120 136,140"
          fill="url(#facet-bottom)"
          stroke="#60A5FA"
          strokeWidth="0.75"
          strokeOpacity="0.6"
        />

        {/* Bottom Outer Underside Thickness */}
        <polygon
          points="24,124 40,140 136,140 120,154"
          fill="#1E3A8A"
          stroke="#1D4ED8"
          strokeWidth="0.5"
        />

        {/* Right Lower Vertical Upright */}
        <polygon
          points="120,80 136,70 136,140 120,120"
          fill="url(#facet-right)"
          stroke="#38BDF8"
          strokeWidth="0.75"
          strokeOpacity="0.6"
        />

        {/* Right Lower Outer Thickness */}
        <polygon
          points="136,70 148,82 148,146 136,140"
          fill="#0C4A6E"
          stroke="#0284C7"
          strokeWidth="0.5"
        />

        {/* Center Crossbar / Inset Shelf */}
        <polygon
          points="84,80 136,70 120,88 84,88"
          fill="url(#facet-inner-core)"
          filter="url(#core-glow)"
          stroke="#67E8F9"
          strokeWidth="0.75"
        />

        {/* Inner Geometric Lattice Lines */}
        <line x1="56" y1="44" x2="84" y2="80" stroke="#818CF8" strokeWidth="1" strokeDasharray="2 2" strokeOpacity="0.7" />
        <line x1="84" y1="88" x2="56" y2="120" stroke="#38BDF8" strokeWidth="1" strokeDasharray="2 2" strokeOpacity="0.7" />

        {/* Center Glowing Energy Node */}
        <circle cx="84" cy="84" r="5" fill="#22D3EE" filter="url(#core-glow)" />
        <circle cx="84" cy="84" r="2.5" fill="#FFFFFF" />

        {/* Top-right corner highlight node */}
        <circle cx="120" cy="24" r="2" fill="#E0E7FF" />
        <circle cx="136" cy="70" r="2" fill="#38BDF8" />
      </svg>
    </div>
  );
};
