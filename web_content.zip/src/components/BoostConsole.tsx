import React from 'react';
import { Terminal, Shield, CheckCircle2, Loader2, ArrowRight } from 'lucide-react';
import { BoostStep } from '../types';

interface BoostConsoleProps {
  steps: BoostStep[];
  isBoosting: boolean;
  isBoosted: boolean;
  onClear?: () => void;
  language: 'en' | 'ur';
}

export const BoostConsole: React.FC<BoostConsoleProps> = ({
  steps,
  isBoosting,
  isBoosted,
  language,
}) => {
  return (
    <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 font-mono text-xs">
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-amber-400" />
          <span className="font-semibold text-slate-200">
            {language === 'ur' ? 'او پی کنگ ۴۷ بوسٹر انجن لاگز' : 'OPKING47 Android Execution Console'}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {isBoosting && (
            <span className="text-amber-400 flex items-center gap-1">
              <Loader2 className="w-3 h-3 animate-spin" />
              <span>OPTIMIZING</span>
            </span>
          )}
          {isBoosted && !isBoosting && (
            <span className="text-emerald-400 flex items-center gap-1 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>FF PING: LOW (18ms)</span>
            </span>
          )}
        </div>
      </div>

      {/* Terminal log lines */}
      <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
        {steps.map((step, idx) => {
          return (
            <div
              key={step.id || idx}
              className={`p-2.5 rounded-lg border transition-all ${
                step.status === 'completed'
                  ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
                  : step.status === 'in_progress'
                  ? 'bg-amber-950/20 border-amber-500/40 text-amber-300 animate-pulse'
                  : 'bg-slate-950/50 border-slate-800/80 text-slate-400'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-semibold flex items-center gap-1.5">
                  {step.status === 'completed' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                  {step.status === 'in_progress' && <Loader2 className="w-3.5 h-3.5 text-amber-400 animate-spin shrink-0" />}
                  {step.status === 'pending' && <span className="w-3.5 h-3.5 text-slate-600 font-bold">·</span>}
                  <span>{step.text}</span>
                </span>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider">{step.status}</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-1 pl-5 font-sans">
                {step.detail}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
        <span>Target: com.opking47.networkbooster</span>
        <span className="text-amber-400 font-semibold">Kernel: Linux / Android WifiManager</span>
      </div>
    </div>
  );
};
