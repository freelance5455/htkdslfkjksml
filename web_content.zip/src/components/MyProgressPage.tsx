import React, { useState, useEffect } from 'react';
import {
  Globe,
  Plus,
  ArrowLeft,
  Calendar,
  Activity,
  UserCheck,
  Building2,
  Pill,
  Thermometer,
  Heart,
  Edit3,
  Trash2,
  AlertTriangle,
  ChevronRight,
  Stethoscope,
  ShieldCheck,
  Clock,
  Info
} from 'lucide-react';
import { TopAppBar } from './TopAppBar';
import { AddDiseasePage, TrackerLanguage } from './AddDiseasePage';
import { ReadAloudButton } from './ReadAloudButton';
import { PreferredLanguage } from '../types';

interface SavedDiseaseRecord {
  id: string;
  diseaseName: string;
  diagnosisDate: string;
  currentStage?: string;
  treatingDoctor?: string;
  hospitalClinic?: string;
  medicines?: Array<{
    id: string;
    name: string;
    strength: string;
    dose: string;
    frequency: string;
    notes?: string;
  }>;
  healthParameters?: {
    heightCm?: number;
    weightKg?: number;
    bmi?: number;
    bloodPressure?: string;
    bloodSugar?: string;
    heartRate?: string;
    bodyTemp?: string;
    oxygenSpo2?: string;
  };
  symptoms?: string[];
  symptomKeys?: string[];
  createdAt: string;
  updatedAt?: string;
}

interface MyProgressPageProps {
  onBack: () => void;
  onNavigateToAddDisease: () => void;
}

const translations: Record<TrackerLanguage, Record<string, string>> = {
  English: {
    languageLabel: 'Language',
    myProgressTitle: 'My Progress',
    myProgressSubtitle: 'View & manage your tracked health conditions',
    backToTracker: 'Back to Tracker',
    noDiseasesTitle: 'No diseases added yet.',
    noDiseasesSubtitle: 'Start tracking your health condition by registering your first disease.',
    addDiseaseBtn: '+ Add Disease',

    // Card labels
    diagnosisDateLabel: 'Diagnosis Date',
    currentStatusLabel: 'Current Status',
    lastUpdatedLabel: 'Last Updated',
    activeStatus: 'Active Condition',

    // Details page
    diseaseDetailsTitle: 'Disease Details',
    stageLabel: 'Current Stage',
    doctorLabel: 'Treating Doctor',
    hospitalLabel: 'Hospital / Clinic',
    currentMedicinesTitle: 'Current Medicines',
    noMedicines: 'No medicines recorded.',
    currentSymptomsTitle: 'Current Symptoms',
    noSymptoms: 'No symptoms recorded.',
    latestVitalsTitle: 'Latest Health Parameters',
    height: 'Height',
    weight: 'Weight',
    bmi: 'BMI',
    bp: 'Blood Pressure',
    sugar: 'Blood Sugar',
    heartRate: 'Heart Rate',
    temp: 'Body Temperature',
    spo2: 'SpO₂ Oxygen',
    notSpecified: 'Not specified',

    // Actions
    editDiseaseBtn: 'Edit Disease',
    deleteDiseaseBtn: 'Delete Disease',

    // Delete Modal
    confirmDeleteTitle: 'Delete Disease Record?',
    confirmDeleteMessage: 'Are you sure you want to delete this disease record? This action cannot be undone.',
    cancelBtn: 'Cancel',
    confirmDeleteAction: 'Yes, Delete Record'
  },
  Hindi: {
    languageLabel: 'भाषा',
    myProgressTitle: 'मेरी प्रगति (My Progress)',
    myProgressSubtitle: 'दर्ज किए गए आजारों की स्थिति देखें और प्रबंधित करें',
    backToTracker: 'ट्रैकर पर वापस जाएं',
    noDiseasesTitle: 'अभी तक कोई बीमारी नहीं जोड़ी गई।',
    noDiseasesSubtitle: 'अपनी पहली बीमारी दर्ज करके अपनी स्वास्थ्य स्थिति को ट्रैक करना शुरू करें।',
    addDiseaseBtn: '+ बीमारी जोड़ें (Add Disease)',

    // Card labels
    diagnosisDateLabel: 'निदान की तारीख',
    currentStatusLabel: 'वर्तमान स्थिति',
    lastUpdatedLabel: 'अंतिम अपडेट',
    activeStatus: 'सक्रिय स्थिति',

    // Details page
    diseaseDetailsTitle: 'बीमारी का विवरण',
    stageLabel: 'वर्तमान चरण (Current Stage)',
    doctorLabel: 'इलाज करने वाले डॉक्टर',
    hospitalLabel: 'अस्पताल / क्लिनिक',
    currentMedicinesTitle: 'वर्तमान दवाइयां',
    noMedicines: 'कोई दवाई दर्ज नहीं है।',
    currentSymptomsTitle: 'वर्तमान लक्षण',
    noSymptoms: 'कोई लक्षण दर्ज नहीं है।',
    latestVitalsTitle: 'नवीनतम स्वास्थ्य पैरामीटर',
    height: 'ऊंचाई',
    weight: 'वजन',
    bmi: 'बीएमआई (BMI)',
    bp: 'रक्तचाप (Blood Pressure)',
    sugar: 'ब्लड शुगर (Blood Sugar)',
    heartRate: 'हृदय गति (Heart Rate)',
    temp: 'शरीर का तापमान',
    spo2: 'ऑक्सीजन स्तर SpO₂',
    notSpecified: 'निर्दिष्ट नहीं है',

    // Actions
    editDiseaseBtn: 'बीमारी संपादित करें (Edit)',
    deleteDiseaseBtn: 'बीमारी हटाएं (Delete)',

    // Delete Modal
    confirmDeleteTitle: 'बीमारी का रिकॉर्ड हटाएं?',
    confirmDeleteMessage: 'क्या आप वाकई इस बीमारी का रिकॉर्ड हटाना चाहते हैं? यह कार्रवाई पूर्ववत नहीं की जा सकती।',
    cancelBtn: 'रद्द करें',
    confirmDeleteAction: 'हां, रिकॉर्ड हटाएं'
  },
  Marathi: {
    languageLabel: 'भाषा',
    myProgressTitle: 'माझी प्रगती (My Progress)',
    myProgressSubtitle: 'नोंदणीकृत आजारांची स्थिती पहा आणि व्यवस्थापित करा',
    backToTracker: 'ट्रॅकरवर परत जा',
    noDiseasesTitle: 'अद्याप कोणताही आजार जोडलेला नाही.',
    noDiseasesSubtitle: 'तुमचा पहिला आजार नोंदवून तुमच्या आरोग्याची स्थिती ट्रॅक करण्यास सुरुवात करा.',
    addDiseaseBtn: '+ आजार जोडा (Add Disease)',

    // Card labels
    diagnosisDateLabel: 'निदानाची तारीख',
    currentStatusLabel: 'सध्याची स्थिती',
    lastUpdatedLabel: 'शेवटचे अपडेट',
    activeStatus: 'सक्रिय स्थिती',

    // Details page
    diseaseDetailsTitle: 'आजाराचा तपशील',
    stageLabel: 'सध्याचा टप्पा (Current Stage)',
    doctorLabel: 'उपचार करणारे डॉक्टर',
    hospitalLabel: 'रुग्णालय / क्लिनिक',
    currentMedicinesTitle: 'सध्याची औषधे',
    noMedicines: 'कोणतेही औषध नोंदवलेले नाही.',
    currentSymptomsTitle: 'सध्याची लक्षणे',
    noSymptoms: 'कोणतीही लक्षणे नोंदवलेली नाहीत.',
    latestVitalsTitle: 'नवीनतम आरोग्य घटक',
    height: 'उंची',
    weight: 'वजन',
    bmi: 'बीएमआई (BMI)',
    bp: 'रक्तदाब (Blood Pressure)',
    sugar: 'ब्लड शुगर (Blood Sugar)',
    heartRate: 'हृदयाचे ठोके (Heart Rate)',
    temp: 'शरीराचे तापमान',
    spo2: 'ऑक्सिजन पातळी SpO₂',
    notSpecified: 'नमुद केलेले नाही',

    // Actions
    editDiseaseBtn: 'आजार संपादित करा (Edit)',
    deleteDiseaseBtn: 'आजार काढून टाका (Delete)',

    // Delete Modal
    confirmDeleteTitle: 'आजाराची नोंद काढून टाकायची?',
    confirmDeleteMessage: 'तुम्हाला खरंच या आजाराची नोंद काढून टाकायची आहे का? ही क्रिया मागे घेतली जाऊ शकत नाही.',
    cancelBtn: 'रद्द करा',
    confirmDeleteAction: 'होय, नोंद काढून टाका'
  }
};

export const MyProgressPage: React.FC<MyProgressPageProps> = ({
  onBack,
  onNavigateToAddDisease
}) => {
  const [language, setLanguage] = useState<TrackerLanguage>('English');
  const t = translations[language];

  const [diseases, setDiseases] = useState<SavedDiseaseRecord[]>([]);
  const [selectedDisease, setSelectedDisease] = useState<SavedDiseaseRecord | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Load saved diseases strictly from localStorage
  const loadSavedDiseases = () => {
    try {
      const dataStr = localStorage.getItem('saved_disease_records');
      if (dataStr) {
        const parsed = JSON.parse(dataStr);
        if (Array.isArray(parsed)) {
          setDiseases(parsed);
          return;
        }
      }
      setDiseases([]);
    } catch (err) {
      console.error('Failed to parse saved_disease_records', err);
      setDiseases([]);
    }
  };

  useEffect(() => {
    loadSavedDiseases();
  }, []);

  // Format Date String nicely
  const formatDate = (dateStr?: string) => {
    if (!dateStr) return t.notSpecified;
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return dateStr;
    }
  };

  // Format DateTime string
  const formatDateTime = (dateStr?: string) => {
    if (!dateStr) return t.notSpecified;
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      }) + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return dateStr;
    }
  };

  // Delete disease handler
  const handleDeleteConfirm = () => {
    if (!selectedDisease) return;

    try {
      const updatedList = diseases.filter((d) => d.id !== selectedDisease.id);
      localStorage.setItem('saved_disease_records', JSON.stringify(updatedList));
      setDiseases(updatedList);
      setSelectedDisease(null);
      setShowDeleteConfirm(false);
    } catch (err) {
      console.error('Failed to delete disease record', err);
    }
  };

  // If currently editing a selected disease, render AddDiseasePage with initialDisease prop
  if (isEditing && selectedDisease) {
    return (
      <AddDiseasePage
        initialDisease={selectedDisease}
        onBack={() => {
          setIsEditing(false);
          loadSavedDiseases();
        }}
        onSaveSuccess={() => {
          setIsEditing(false);
          loadSavedDiseases();
          // Update selected disease view with latest
          const updatedStr = localStorage.getItem('saved_disease_records');
          if (updatedStr) {
            const list = JSON.parse(updatedStr);
            const updated = list.find((item: any) => item.id === selectedDisease.id);
            if (updated) setSelectedDisease(updated);
          }
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      {/* Top AppBar */}
      <TopAppBar
        title={t.myProgressTitle}
        subtitle={t.myProgressSubtitle}
        onBack={() => {
          if (selectedDisease) {
            setSelectedDisease(null);
          } else {
            onBack();
          }
        }}
      />

      <div className="p-4 sm:p-6 max-w-3xl mx-auto w-full space-y-6">
        
        {/* Language Selection Header Bar */}
        <div className="bg-white rounded-2xl p-3 border border-slate-200/90 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-700 font-extrabold text-xs sm:text-sm">
            <Globe className="w-4 h-4 text-teal-700" />
            <span>{t.languageLabel}:</span>
          </div>
          <div className="flex items-center bg-slate-100 p-1 rounded-xl gap-1">
            {(['English', 'Hindi', 'Marathi'] as TrackerLanguage[]).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => setLanguage(lang)}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all ${
                  language === lang
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
              </button>
            ))}
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* DETAIL VIEW WHEN A DISEASE CARD IS TAPPED */}
        {/* ------------------------------------------------------------- */}
        {selectedDisease ? (
          <div className="space-y-6 animate-in fade-in">
            {/* Header Title Bar */}
            <div className="bg-gradient-to-r from-teal-800 to-teal-900 text-white p-6 rounded-3xl shadow-md flex items-start justify-between">
              <div>
                <span className="px-3 py-1 bg-teal-700/80 border border-teal-600 rounded-full text-xs font-black uppercase tracking-wider text-teal-100">
                  {selectedDisease.currentStage || t.activeStatus}
                </span>
                <h2 className="text-2xl font-black mt-2 tracking-tight">
                  {selectedDisease.diseaseName}
                </h2>
                <div className="flex items-center gap-4 text-xs text-teal-100 font-medium mt-1">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {t.diagnosisDateLabel}: {formatDate(selectedDisease.diagnosisDate)}
                  </span>
                </div>
              </div>

              {/* Action Buttons: Read Aloud, Edit & Delete */}
              <div className="flex items-center gap-2">
                <ReadAloudButton
                  id={`disease-progress-${selectedDisease.id}`}
                  text={(() => {
                    const parts: string[] = [];
                    parts.push(`${selectedDisease.diseaseName}`);
                    if (selectedDisease.currentStage) parts.push(`${t.stageLabel}: ${selectedDisease.currentStage}`);
                    if (selectedDisease.diagnosisDate) parts.push(`${t.diagnosisDateLabel}: ${formatDate(selectedDisease.diagnosisDate)}`);
                    if (selectedDisease.treatingDoctor) parts.push(`${t.doctorLabel}: ${selectedDisease.treatingDoctor}`);
                    if (selectedDisease.hospitalClinic) parts.push(`${t.hospitalLabel}: ${selectedDisease.hospitalClinic}`);
                    if (selectedDisease.symptoms && selectedDisease.symptoms.length > 0) {
                      parts.push(`${t.currentSymptomsTitle}: ${selectedDisease.symptoms.join(', ')}`);
                    }
                    if (selectedDisease.healthParameters) {
                      const hp = selectedDisease.healthParameters;
                      const vitals: string[] = [];
                      if (hp.bloodPressure) vitals.push(`${t.bp} ${hp.bloodPressure}`);
                      if (hp.bloodSugar) vitals.push(`${t.bloodSugar} ${hp.bloodSugar}`);
                      if (hp.heartRate) vitals.push(`${t.heartRate} ${hp.heartRate}`);
                      if (hp.oxygenSpo2) vitals.push(`${t.spo2} ${hp.oxygenSpo2}%`);
                      if (hp.bodyTemp) vitals.push(`${t.temp} ${hp.bodyTemp}`);
                      if (hp.weightKg) vitals.push(`${t.weight} ${hp.weightKg} kg`);
                      if (vitals.length > 0) parts.push(`${t.latestVitalsTitle}: ${vitals.join(', ')}`);
                    }
                    if (selectedDisease.medicines && selectedDisease.medicines.length > 0) {
                      const meds = selectedDisease.medicines.map(m => `${m.name} ${m.dose} ${m.frequency}`).join(', ');
                      parts.push(`${t.currentMedicinesTitle}: ${meds}`);
                    }
                    return parts.join('. ');
                  })()}
                  language={language as PreferredLanguage}
                  variant="pill"
                  className="bg-white/20 hover:bg-white/30 text-white border border-white/20 rounded-2xl"
                />

                <button
                  type="button"
                  onClick={() => setIsEditing(true)}
                  className="px-3 py-2 bg-white/10 hover:bg-white/20 border border-white/20 rounded-2xl text-xs font-extrabold text-white transition-all flex items-center gap-1.5 shadow-2xs"
                >
                  <Edit3 className="w-4 h-4" />
                  <span className="hidden sm:inline">{t.editDiseaseBtn}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(true)}
                  className="px-3 py-2 bg-rose-600/80 hover:bg-rose-600 border border-rose-500 rounded-2xl text-xs font-extrabold text-white transition-all flex items-center gap-1.5 shadow-2xs"
                >
                  <Trash2 className="w-4 h-4" />
                  <span className="hidden sm:inline">{t.deleteDiseaseBtn}</span>
                </button>
              </div>
            </div>

            {/* Disease Key Details Card */}
            <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
              <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
                <div className="p-2 bg-teal-50 text-teal-700 rounded-xl">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <h3 className="font-extrabold text-base text-slate-900">
                  {t.diseaseDetailsTitle}
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                  <span className="text-slate-500 font-bold block text-xs">{t.stageLabel}</span>
                  <span className="font-extrabold text-slate-900 mt-0.5 block">
                    {selectedDisease.currentStage || t.notSpecified}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                  <span className="text-slate-500 font-bold block text-xs">{t.doctorLabel}</span>
                  <span className="font-extrabold text-slate-900 mt-0.5 block">
                    {selectedDisease.treatingDoctor || t.notSpecified}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 sm:col-span-2">
                  <span className="text-slate-500 font-bold block text-xs">{t.hospitalLabel}</span>
                  <span className="font-extrabold text-slate-900 mt-0.5 block">
                    {selectedDisease.hospitalClinic || t.notSpecified}
                  </span>
                </div>
              </div>
            </div>

            {/* Current Medicines Card */}
            <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
              <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
                <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                  <Pill className="w-5 h-5" />
                </div>
                <h3 className="font-extrabold text-base text-slate-900">
                  {t.currentMedicinesTitle}
                </h3>
              </div>

              {!selectedDisease.medicines || selectedDisease.medicines.length === 0 ? (
                <p className="text-xs text-slate-400 italic bg-slate-50 p-3 rounded-2xl text-center border border-dashed border-slate-200">
                  {t.noMedicines}
                </p>
              ) : (
                <div className="space-y-2.5">
                  {selectedDisease.medicines.map((med) => (
                    <div
                      key={med.id}
                      className="p-3.5 bg-emerald-50/50 border border-emerald-200/80 rounded-2xl text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-slate-900 text-sm">
                          {med.name} {med.strength && `(${med.strength})`}
                        </span>
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-extrabold rounded-lg text-[11px]">
                          {med.frequency}
                        </span>
                      </div>
                      {med.dose && (
                        <p className="text-slate-700 font-medium">
                          <strong>Dose:</strong> {med.dose}
                        </p>
                      )}
                      {med.notes && (
                        <p className="text-slate-600 italic">
                          <strong>Note:</strong> {med.notes}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Current Symptoms Card */}
            <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
              <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
                <div className="p-2 bg-amber-50 text-amber-700 rounded-xl">
                  <Thermometer className="w-5 h-5" />
                </div>
                <h3 className="font-extrabold text-base text-slate-900">
                  {t.currentSymptomsTitle}
                </h3>
              </div>

              {!selectedDisease.symptoms || selectedDisease.symptoms.length === 0 ? (
                <p className="text-xs text-slate-400 italic bg-slate-50 p-3 rounded-2xl text-center border border-dashed border-slate-200">
                  {t.noSymptoms}
                </p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {selectedDisease.symptoms.map((sym, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1.5 bg-amber-50 border border-amber-200 text-amber-900 font-extrabold text-xs rounded-xl shadow-2xs"
                    >
                      • {sym}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Latest Health Parameters / Vitals Card */}
            <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
              <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
                <div className="p-2 bg-purple-50 text-purple-700 rounded-xl">
                  <Heart className="w-5 h-5" />
                </div>
                <h3 className="font-extrabold text-base text-slate-900">
                  {t.latestVitalsTitle}
                </h3>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                {/* Height */}
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-2xl">
                  <span className="text-slate-500 font-bold block">{t.height}</span>
                  <span className="font-black text-slate-900 text-sm mt-0.5 block">
                    {selectedDisease.healthParameters?.heightCm
                      ? `${selectedDisease.healthParameters.heightCm} cm`
                      : t.notSpecified}
                  </span>
                </div>

                {/* Weight */}
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-2xl">
                  <span className="text-slate-500 font-bold block">{t.weight}</span>
                  <span className="font-black text-slate-900 text-sm mt-0.5 block">
                    {selectedDisease.healthParameters?.weightKg
                      ? `${selectedDisease.healthParameters.weightKg} kg`
                      : t.notSpecified}
                  </span>
                </div>

                {/* BMI */}
                <div className="p-3 bg-purple-50/70 border border-purple-100 rounded-2xl">
                  <span className="text-purple-800 font-bold block">{t.bmi}</span>
                  <span className="font-black text-purple-950 text-sm mt-0.5 block">
                    {selectedDisease.healthParameters?.bmi
                      ? `${selectedDisease.healthParameters.bmi} kg/m²`
                      : t.notSpecified}
                  </span>
                </div>

                {/* Blood Pressure */}
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-2xl">
                  <span className="text-slate-500 font-bold block">{t.bp}</span>
                  <span className="font-black text-slate-900 text-sm mt-0.5 block">
                    {selectedDisease.healthParameters?.bloodPressure || t.notSpecified}
                  </span>
                </div>

                {/* Blood Sugar */}
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-2xl">
                  <span className="text-slate-500 font-bold block">{t.sugar}</span>
                  <span className="font-black text-slate-900 text-sm mt-0.5 block">
                    {selectedDisease.healthParameters?.bloodSugar || t.notSpecified}
                  </span>
                </div>

                {/* Heart Rate */}
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-2xl">
                  <span className="text-slate-500 font-bold block">{t.heartRate}</span>
                  <span className="font-black text-slate-900 text-sm mt-0.5 block">
                    {selectedDisease.healthParameters?.heartRate || t.notSpecified}
                  </span>
                </div>

                {/* Body Temperature */}
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-2xl">
                  <span className="text-slate-500 font-bold block">{t.temp}</span>
                  <span className="font-black text-slate-900 text-sm mt-0.5 block">
                    {selectedDisease.healthParameters?.bodyTemp || t.notSpecified}
                  </span>
                </div>

                {/* SpO2 */}
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-2xl col-span-2 sm:col-span-1">
                  <span className="text-slate-500 font-bold block">{t.spo2}</span>
                  <span className="font-black text-slate-900 text-sm mt-0.5 block">
                    {selectedDisease.healthParameters?.oxygenSpo2 || t.notSpecified}
                  </span>
                </div>
              </div>
            </div>

            {/* Back Button */}
            <button
              type="button"
              onClick={() => setSelectedDisease(null)}
              className="w-full py-3.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-extrabold text-xs sm:text-sm rounded-2xl transition-all flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{t.backToTracker}</span>
            </button>
          </div>
        ) : (
          /* ------------------------------------------------------------- */
          /* LIST VIEW OF ALL USER-ADDED DISEASES */
          /* ------------------------------------------------------------- */
          <div className="space-y-4">
            {diseases.length === 0 ? (
              /* EMPTY STATE: "No diseases added yet." */
              <div className="bg-white rounded-3xl p-8 border border-slate-200/90 shadow-2xs text-center space-y-4 my-8">
                <div className="w-16 h-16 bg-teal-50 text-teal-700 rounded-2xl border border-teal-100 flex items-center justify-center mx-auto">
                  <Stethoscope className="w-8 h-8" />
                </div>

                <div className="space-y-1">
                  <h3 className="font-extrabold text-lg text-slate-900">
                    {t.noDiseasesTitle}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium max-w-sm mx-auto">
                    {t.noDiseasesSubtitle}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={onNavigateToAddDisease}
                  className="px-6 py-3 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-xs sm:text-sm rounded-2xl shadow-md shadow-teal-700/20 active:scale-98 transition-all inline-flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t.addDiseaseBtn}</span>
                </button>
              </div>
            ) : (
              /* SAVED DISEASE CARDS LIST */
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-1">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Registered Conditions ({diseases.length})
                  </h3>
                  <button
                    type="button"
                    onClick={onNavigateToAddDisease}
                    className="text-xs font-extrabold text-teal-700 hover:text-teal-800 flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{t.addDiseaseBtn}</span>
                  </button>
                </div>

                {diseases.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedDisease(item)}
                    className="w-full bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs hover:shadow-md transition-all text-left flex items-center justify-between group active:scale-98"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <h4 className="font-extrabold text-base text-slate-900 group-hover:text-teal-800 transition-colors">
                          {item.diseaseName}
                        </h4>
                        <span className="px-2.5 py-0.5 bg-teal-50 text-teal-800 border border-teal-200 rounded-full text-[11px] font-extrabold">
                          {item.currentStage || t.activeStatus}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 text-xs text-slate-500 font-medium">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          <span>
                            {t.diagnosisDateLabel}: <strong>{formatDate(item.diagnosisDate)}</strong>
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>
                            {t.lastUpdatedLabel}: <strong>{formatDateTime(item.updatedAt || item.createdAt)}</strong>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="p-2 bg-slate-50 text-slate-400 group-hover:text-teal-700 group-hover:bg-teal-50 rounded-xl transition-all">
                      <ChevronRight className="w-5 h-5" />
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

      </div>

      {/* DELETE CONFIRMATION MODAL */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl space-y-4 border border-slate-200">
            <div className="w-12 h-12 bg-rose-100 text-rose-700 rounded-2xl flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-extrabold text-base text-slate-900">
                {t.confirmDeleteTitle}
              </h3>
              <p className="text-xs text-slate-600 font-medium leading-relaxed">
                {t.confirmDeleteMessage}
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs rounded-xl transition-colors"
              >
                {t.cancelBtn}
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors"
              >
                {t.confirmDeleteAction}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
