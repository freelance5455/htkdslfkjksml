import React, { useState, useEffect } from 'react';
import { FinancialTransaction } from '../types/business';
import { StorageService } from '../db/storage';
import { ArrowLeft, Search, CreditCard, DollarSign, RotateCcw, Receipt, PlusCircle } from 'lucide-react';

interface TransactionsViewProps {
  lang: 'bn' | 'en';
  onBack: () => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  lang,
  onBack,
}) => {
  const [transactions, setTransactions] = useState<FinancialTransaction[]>(StorageService.getTransactions());
  const [filterType, setFilterType] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    setTransactions(StorageService.getTransactions());
  }, []);

  const filtered = transactions.filter((t) => {
    const q = searchQuery.toLowerCase();
    const matchSearch =
      t.description.toLowerCase().includes(q) ||
      (t.invoiceNumber && t.invoiceNumber.toLowerCase().includes(q)) ||
      (t.customerName && t.customerName.toLowerCase().includes(q));
    const matchType = filterType === 'All' || t.type === filterType;
    return matchSearch && matchType;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-violet-600" />
                <span>{lang === 'bn' ? 'সম্পত্তিক আর্থিক লেনদেন খতিয়ান' : 'Financial Transactions'}</span>
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn' ? `সর্বমোট ${transactions.length} টি লেনদেন রেকর্ড রয়েছে` : `Total ${transactions.length} transactions logged`}
              </p>
            </div>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 border-t border-slate-100 flex flex-col md:flex-row items-stretch md:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="বিবরণ, চালান নম্বর বা কাস্টমার খুঁজুন..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-violet-500/20"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
            {['All', 'Sale', 'Due Collection', 'Return', 'Expense'].map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-all ${
                  filterType === type
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {type === 'All' ? 'সব' : type === 'Sale' ? 'বিক্রয়' : type === 'Due Collection' ? 'বাকি আদায়' : type === 'Return' ? 'রিটার্ন' : 'খরচ'}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-3">
        {filtered.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 text-slate-400 text-xs">
            কোন লেনদেন পাওয়া যায়নি
          </div>
        ) : (
          filtered.map((t) => {
            const isSale = t.type === 'Sale';
            const isDuePay = t.type === 'Due Collection';
            const isReturn = t.type === 'Return';
            const isExpense = t.type === 'Expense';

            return (
              <div
                key={t.id}
                className="p-4 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold shrink-0 ${
                      isSale
                        ? 'bg-emerald-50 text-emerald-600'
                        : isDuePay
                        ? 'bg-blue-50 text-blue-600'
                        : isReturn
                        ? 'bg-rose-50 text-rose-600'
                        : 'bg-amber-50 text-amber-600'
                    }`}
                  >
                    {isSale ? (
                      <DollarSign className="w-5 h-5" />
                    ) : isDuePay ? (
                      <CreditCard className="w-5 h-5" />
                    ) : isReturn ? (
                      <RotateCcw className="w-5 h-5" />
                    ) : (
                      <Receipt className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isSale
                            ? 'bg-emerald-100 text-emerald-800'
                            : isDuePay
                            ? 'bg-blue-100 text-blue-800'
                            : isReturn
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-slate-100 text-slate-800'
                        }`}
                      >
                        {t.type}
                      </span>
                      <span className="text-slate-400 text-[11px] font-mono">
                        {t.date} • {t.time}
                      </span>
                    </div>
                    <p className="font-bold text-slate-900 text-sm mt-0.5">{t.description}</p>
                    {t.customerName && (
                      <p className="text-[11px] text-slate-500">কাস্টমার: {t.customerName}</p>
                    )}
                  </div>
                </div>

                <div className="text-right sm:border-l sm:border-slate-100 sm:pl-4">
                  <span className="text-[10px] text-slate-400 block font-medium">লেনদেন পরিমাণ</span>
                  <span
                    className={`text-base font-black ${
                      isReturn || isExpense ? 'text-rose-600' : 'text-emerald-700'
                    }`}
                  >
                    {isReturn || isExpense ? '-' : '+'}৳{t.amount.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-500 block font-semibold">
                    মাধ্যম: {t.paymentMethod}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
