import React, { useState } from 'react';
import { StudyModule, ModuleProgress } from '../types/index.ts';
import {
  ArrowLeft,
  Volume2,
  VolumeX,
  Printer,
  HelpCircle,
  Lightbulb,
  CheckCircle,
  CheckCircle2,
  Share2,
  Layers,
  Globe,
} from 'lucide-react';
import { speakText, stopSpeaking } from '../utils/audio.ts';
import { CircularProgressRing } from './CircularProgressRing.tsx';

interface StudyNotesReaderProps {
  module: StudyModule;
  progress?: ModuleProgress;
  language: 'om' | 'en';
  onBack: () => void;
  onTakeQuiz: (module: StudyModule) => void;
  onOpenFlashcards: (module: StudyModule) => void;
}

export const StudyNotesReader: React.FC<StudyNotesReaderProps> = ({
  module,
  progress,
  language: appLanguage,
  onBack,
  onTakeQuiz,
  onOpenFlashcards,
}) => {
  const [contentLang, setContentLang] = useState<'om' | 'en'>(appLanguage);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [copied, setCopied] = useState(false);

  const toggleSpeech = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
    } else {
      // Gather text to speak
      const intro = contentLang === 'om' ? module.title : module.titleEn;
      const bodyText = module.sections
        .map((s) => {
          const heading = contentLang === 'om' ? s.heading : (s.headingEn || s.heading);
          const summary = contentLang === 'om' ? s.summary : (s.summaryEn || s.summary);
          const bullets = (contentLang === 'om' ? s.bulletPoints : (s.bulletPointsEn || s.bulletPoints)).join('. ');
          return `${heading}. ${summary}. ${bullets}`;
        })
        .join('. ');

      const fullText = `${intro}. ${bodyText}`;
      speakText(fullText, contentLang === 'om' ? 'it-IT' : 'en-US'); // it-IT or en-US
      setIsSpeaking(true);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleShare = async () => {
    const text = `${module.title} - Ethiopian Grade 9 Study Notes & 5 MCQs`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: module.title,
          text,
          url: window.location.href,
        });
      } catch (err) {
        // user dismissed
      }
    } else {
      navigator.clipboard.writeText(`${text}\n${window.location.href}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <article className="max-w-4xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Top action row */}
      <div className="flex items-center justify-between gap-3 flex-wrap border-b border-slate-200 pb-4">
        <button
          onClick={onBack}
          className="min-h-[44px] inline-flex items-center gap-2 text-xs font-semibold text-slate-700 hover:text-slate-950 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{appLanguage === 'om' ? 'Gara Tarree Qabxiilee' : 'Back to Notes'}</span>
        </button>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Language toggle for notes */}
          <button
            onClick={() => setContentLang((prev) => (prev === 'om' ? 'en' : 'om'))}
            className="min-h-[38px] px-3 py-1.5 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-amber-600" />
            <span>{contentLang === 'om' ? 'English Translate' : 'Afaan Oromoo'}</span>
          </button>

          {/* Audio reader */}
          <button
            onClick={toggleSpeech}
            className={`min-h-[38px] px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors inline-flex items-center gap-1.5 cursor-pointer ${
              isSpeaking
                ? 'bg-amber-100 text-amber-900 border-amber-300'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {isSpeaking ? (
              <>
                <VolumeX className="w-3.5 h-3.5 text-amber-700" />
                <span>{appLanguage === 'om' ? 'Dhaabi' : 'Stop Audio'}</span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5 text-slate-600" />
                <span>{appLanguage === 'om' ? 'Dhaggeeffadhu' : 'Listen'}</span>
              </>
            )}
          </button>

          {/* Print button */}
          <button
            onClick={handlePrint}
            title="Waraqaa qorannoo maxxansi / Print Study Sheet"
            className="min-h-[38px] px-3 py-1.5 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span className="hidden sm:inline">{appLanguage === 'om' ? 'Maxxansi' : 'Print'}</span>
          </button>

          {/* Share */}
          <button
            onClick={handleShare}
            className="min-h-[38px] px-3 py-1.5 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5 text-slate-600" />
            <span>{copied ? 'Copied!' : appLanguage === 'om' ? 'Qoodi' : 'Share'}</span>
          </button>
        </div>
      </div>

      {/* Module Header with Progress */}
      <header className="space-y-3 bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs text-slate-500 flex-wrap">
              <span className="font-semibold text-amber-700">{module.subject}</span>
              <span aria-hidden="true">·</span>
              <span>{module.grade}</span>
              <span aria-hidden="true">·</span>
              <span>{module.estimatedMinutes} Daqiiqaa</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
              {contentLang === 'om' ? module.title : module.titleEn}
            </h1>
          </div>

          {/* Progress Ring in Reader Header */}
          <div className="flex flex-col items-center gap-1 shrink-0 p-2 bg-slate-50 rounded-xl border border-slate-100">
            <CircularProgressRing
              score={progress?.bestScore || 0}
              total={module.questions?.length || 5}
              size={48}
              strokeWidth={4}
            />
            <span className="text-[10px] font-semibold text-slate-500 whitespace-nowrap">
              {progress?.completed
                ? appLanguage === 'om'
                  ? 'Guutuu (100%)'
                  : 'Mastered'
                : (progress?.bestScore || 0) > 0
                ? appLanguage === 'om'
                  ? 'Adeemsarra'
                  : 'In Progress'
                : appLanguage === 'om'
                ? 'Hin jalqabamne'
                : 'Not Started'}
            </span>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed bg-amber-50/60 p-3.5 rounded-xl border border-amber-200/50">
          {contentLang === 'om'
            ? module.topicSummary
            : (module.topicSummaryEn || module.topicSummary)}
        </p>
      </header>

      {/* Primary Action Banner: Take 5 MCQs Quiz */}
      <div className="bg-slate-900 text-white p-4 sm:p-5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-amber-400" />
            <span>{appLanguage === 'om' ? 'Qormaata Mirkaneeffannaa (Gaaffilee 5)' : '5 Multiple-Choice Review Questions'}</span>
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            {appLanguage === 'om'
              ? 'Erga qabxii kana dubbistee booda beekumsa kee mirkaneeffadhu.'
              : 'Test your understanding immediately with answer keys and detailed explanations.'}
          </p>
        </div>

        <button
          onClick={() => onTakeQuiz(module)}
          className="min-h-[44px] px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all whitespace-nowrap cursor-pointer active:scale-[0.98] shadow-sm shrink-0"
        >
          {appLanguage === 'om' ? 'Gaaffilee 5 Qori' : 'Take 5 Review MCQs'}
        </button>
      </div>

      {/* Sections Content */}
      <div className="space-y-6 pt-2">
        {module.sections.map((section, idx) => {
          const heading = contentLang === 'om' ? section.heading : (section.headingEn || section.heading);
          const summary = contentLang === 'om' ? section.summary : (section.summaryEn || section.summary);
          const bullets = contentLang === 'om' ? section.bulletPoints : (section.bulletPointsEn || section.bulletPoints);

          return (
            <section
              key={idx}
              className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 space-y-4 shadow-sm"
            >
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 border-b border-slate-100 pb-2">
                {heading}
              </h2>

              <p className="text-sm text-slate-700 leading-relaxed font-medium">
                {summary}
              </p>

              {/* High-yield bullet points */}
              <div className="space-y-2">
                <p className="text-xs font-bold text-slate-500">
                  {contentLang === 'om' ? 'Qabxiilee Ijoo (Key Points):' : 'Key Concept Takeaways:'}
                </p>
                <ul className="space-y-2 text-xs sm:text-sm text-slate-700">
                  {bullets.map((point, bIdx) => (
                    <li key={bIdx} className="flex items-start gap-2.5">
                      <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{point}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Examples section if available */}
              {section.examples && section.examples.length > 0 && (
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 space-y-1.5 text-xs sm:text-sm">
                  <p className="font-bold text-slate-700 text-xs">
                    {contentLang === 'om' ? 'Fakkeenyota Hojiirraa (Practical Examples):' : 'Real-world Examples:'}
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-slate-600 pl-1">
                    {section.examples.map((ex, exIdx) => (
                      <li key={exIdx} className="leading-relaxed">{ex}</li>
                    ))}
                  </ul>
                </div>
              )}
            </section>
          );
        })}
      </div>

      {/* High-Yield Exam Tip */}
      {module.examTip && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 space-y-2">
          <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
            <Lightbulb className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              {contentLang === 'om' ? 'Gorsa Qormaata Kutaa 9ffaa (Exam Tip)' : 'Grade 9 National Exam Strategy Tip'}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-amber-950 leading-relaxed">
            {contentLang === 'om' ? module.examTip : (module.examTipEn || module.examTip)}
          </p>
        </div>
      )}

      {/* Key Terms / Glossary */}
      {module.keyTerms && module.keyTerms.length > 0 && (
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-600" />
              <span>{appLanguage === 'om' ? 'Jechoota Qorannoo (Key Vocabulary Terms)' : 'Key Vocabulary & Flashcards'}</span>
            </h2>

            <button
              onClick={() => onOpenFlashcards(module)}
              className="text-xs font-semibold text-amber-700 hover:text-amber-800 underline cursor-pointer"
            >
              {appLanguage === 'om' ? 'Kaardiidhaan Shaakali' : 'Practice Flashcards'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {module.keyTerms.map((term, tIdx) => (
              <div
                key={tIdx}
                className="p-3.5 rounded-xl border border-slate-100 bg-slate-50 space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">{term.term}</span>
                  <span className="text-[11px] text-slate-500 italic">{term.translation}</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{term.definition}</p>
                {term.example && (
                  <p className="text-[11px] text-amber-700 font-medium">Fkn: {term.example}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sticky or Bottom Action to take quiz */}
      <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-200">
        <button
          onClick={onBack}
          className="w-full sm:w-auto min-h-[44px] px-5 py-2.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer"
        >
          {appLanguage === 'om' ? 'Tarree Qabxiileetti Deebi\'i' : 'Back to All Modules'}
        </button>

        <button
          onClick={() => onTakeQuiz(module)}
          className="w-full sm:w-auto min-h-[44px] px-6 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-sm cursor-pointer active:scale-[0.98] inline-flex items-center justify-center gap-2"
        >
          <HelpCircle className="w-4 h-4" />
          <span>{appLanguage === 'om' ? 'Qormaata Gaaffilee 5 Jalqabi' : 'Start 5-Question Review Quiz'}</span>
        </button>
      </div>
    </article>
  );
};
