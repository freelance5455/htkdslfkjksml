import { Link } from "react-router-dom";
import { format } from "date-fns";
import { ArrowUpRight, MapPin, ThumbsUp } from "lucide-react";
import { Image } from "@/components/ui/image";
import StatusPill from "@/components/StatusPill";
import CategoryChip from "@/components/CategoryChip";
import { categoryMeta, reportDate } from "@/lib/reportStats";

export default function ReportCard({ report }) {
  const meta = categoryMeta(report.category);

  return (
    <Link
      to={`/issues/${report.id}`}
      className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/25 hover:shadow-[0_18px_40px_-28px_hsl(var(--foreground)/0.45)]"
    >
      <div className="relative h-40 overflow-hidden">
        {report.photo_url ? (
          <Image
            src={report.photo_url}
            alt={report.title}
            fittingType="fill"
            className="h-full w-full transition-transform duration-500 group-hover:scale-[1.03]"
          />
        ) : (
          <div
            className="flex h-full w-full items-center justify-center"
            style={{ background: `linear-gradient(135deg, ${meta.color}1f, ${meta.color}0a)` }}
          >
            <span
              className="font-display text-3xl font-semibold opacity-40"
              style={{ color: meta.color }}
            >
              {meta.short.split(" ")[0]}
            </span>
          </div>
        )}
        <div className="absolute left-3 top-3">
          <StatusPill status={report.status} className="bg-white/95 backdrop-blur" />
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <CategoryChip category={report.category} />
        <h3 className="font-display text-[17px] font-semibold leading-snug tracking-tight text-foreground">
          {report.title}
        </h3>
        <p className="line-clamp-2 text-[13px] leading-relaxed text-muted-foreground">
          {report.description}
        </p>
        <div className="mt-auto flex items-center justify-between gap-2 pt-2 text-[11px] text-muted-foreground">
          <span className="inline-flex items-center gap-1 truncate">
            <MapPin className="h-3 w-3 shrink-0" />
            <span className="truncate">{report.area}</span>
          </span>
          <span className="inline-flex items-center gap-3">
            <span className="inline-flex items-center gap-1">
              <ThumbsUp className="h-3 w-3" />
              {report.supports || 0}
            </span>
            <span className="hidden sm:inline">
              {reportDate(report) ? format(new Date(reportDate(report)), "d MMM") : ""}
            </span>
            <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </span>
        </div>
      </div>
    </Link>
  );
}