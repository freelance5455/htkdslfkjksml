import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Clock, 
  Sparkles, 
  X, 
  ExternalLink, 
  Play, 
  Zap, 
  Award,
  Volume2
} from 'lucide-react';
import { QuizNotificationAlert, WeeklyQuiz } from '../types';

interface QuizNotificationAlertBannerProps {
  language: string;
  onOpenQuiz: (quizId?: string) => void;
}

export default function QuizNotificationAlertBanner({
  language,
  onOpenQuiz
}: QuizNotificationAlertBannerProps) {
  const [activeAlert, setActiveAlert] = useState<QuizNotificationAlert | null>(null);
  const [dismissedIds, setDismissedIds] = useState<string[]>(() => {
    try {
      return JSON.parse(sessionStorage.getItem('edumind_dismissed_alerts') || '[]');
    } catch (e) {
      return [];
    }
  });

  const pollAlerts = async () => {
    try {
      const res = await fetch('/api/weekly-quiz/alerts/recent');
      if (!res.ok) return;
      const data = await res.json();
      if (data.success && Array.isArray(data.alerts) && data.alerts.length > 0) {
        // Find latest un-dismissed alert
        const unread = data.alerts.find((a: QuizNotificationAlert) => !dismissedIds.includes(a.id));
        if (unread) {
          setActiveAlert(unread);
          // Play short subtle alert tone if audio API available
          try {
            const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
            osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.3); // A5
            gain.gain.setValueAtTime(0.15, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.4);
          } catch (e) {}
        }
      }
    } catch (e) {
      // ignore network blips
    }
  };

  useEffect(() => {
    pollAlerts();
    const interval = setInterval(pollAlerts, 20000); // Check every 20s
    return () => clearInterval(interval);
  }, [dismissedIds]);

  const handleDismiss = (id: string) => {
    const updated = [...dismissedIds, id];
    setDismissedIds(updated);
    try {
      sessionStorage.setItem('edumind_dismissed_alerts', JSON.stringify(updated));
    } catch (e) {}
    setActiveAlert(null);
  };

  const handleAction = () => {
    if (activeAlert) {
      handleDismiss(activeAlert.id);
      onOpenQuiz(activeAlert.quizId);
    }
  };

  if (!activeAlert) return null;

  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 w-11/12 max-w-2xl animate-in slide-in-from-top-4 duration-300">
      <div className="bg-gradient-to-r from-amber-950/95 via-slate-900/95 to-indigo-950/95 border-2 border-amber-500/70 text-white rounded-2xl p-3.5 sm:p-4 shadow-2xl shadow-amber-500/20 backdrop-blur-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        
        {/* Left Icon & Message */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/40 shrink-0">
            <Bell className="w-5 h-5 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] bg-amber-500 text-slate-950 font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                {language === 'bn' ? '⏰ ১০ মিনিট সতর্কতা' : language === 'hi' ? '⏰ 10 मिनट अलर्ट' : '⏰ 10 MIN ALERT'}
              </span>
              <span className="text-xs font-mono text-amber-300 font-bold">
                {activeAlert.startTime}
              </span>
            </div>
            <p className="text-xs font-bold text-slate-100 mt-1 leading-snug">
              {activeAlert.message}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 justify-end">
          <button
            onClick={handleAction}
            className="flex-1 sm:flex-none py-1.5 px-3.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-1.5 transition-all"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{language === 'bn' ? 'কুইজে যান' : 'Go to Quiz'}</span>
          </button>

          <button
            onClick={() => handleDismiss(activeAlert.id)}
            className="p-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition-all cursor-pointer"
            title="Dismiss"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
}
