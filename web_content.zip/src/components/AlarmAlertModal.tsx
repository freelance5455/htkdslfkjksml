import React from 'react';
import { Bell, Phone, MessageCircle, RefreshCw, X, ChevronRight } from 'lucide-react';
import { CustomerReminderInfo } from '../types';

interface AlarmAlertBannerProps {
  dueCustomers: CustomerReminderInfo[];
  onRenewDealDate: (customerInfo: CustomerReminderInfo) => void;
  onSelectCustomer: (customerId: string) => void;
}

export const AlarmAlertBanner: React.FC<AlarmAlertBannerProps> = ({
  dueCustomers,
  onRenewDealDate,
  onSelectCustomer,
}) => {
  const [isDismissed, setIsDismissed] = React.useState(false);

  if (dueCustomers.length === 0 || isDismissed) {
    return null;
  }

  return (
    <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 rounded-2xl p-3.5 sm:p-4 text-white shadow-lg border-2 border-yellow-300/60 relative overflow-hidden">
      {/* Background glowing bell watermark */}
      <Bell className="absolute -right-4 -bottom-4 w-32 h-32 text-white/10 pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-2">
          <span className="flex h-3 w-3 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-600"></span>
          </span>
          <h3 className="text-sm sm:text-base font-extrabold tracking-tight flex items-center gap-1.5">
            <Bell className="w-4 h-4 text-yellow-200 animate-bounce" />
            <span>26वें दिन का अलार्म: {dueCustomers.length} ग्राहकों का समय आज पूरा हुआ!</span>
          </h3>
        </div>
        <button
          onClick={() => setIsDismissed(true)}
          className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition cursor-pointer"
          title="छिपाएं"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <p className="text-xs text-orange-100 mb-3 font-medium">
        इन ग्राहकों की डील तारीख को 25 दिन बीत चुके हैं (आज सुबह 9:00 बजे का अलार्म)। कृपया तुरंत कॉल या WhatsApp करें:
      </p>

      {/* Quick customer contact cards */}
      <div className="space-y-2">
        {dueCustomers.slice(0, 3).map((info) => {
          const { customer } = info;
          const cleanPhone = customer.phone ? customer.phone.replace(/[^0-9+]/g, '') : '';
          const waPhone = cleanPhone.startsWith('91') || cleanPhone.startsWith('+91')
            ? cleanPhone.replace('+', '')
            : `91${cleanPhone}`;
          const waMsg = encodeURIComponent(
            `नमस्ते ${customer.name} जी! आपकी गैस सिलेंडर की डिलीवरी को 25 दिन हो चुके हैं। क्या आज आपको नए गैस सिलेंडर की आवश्यकता है?`
          );

          return (
            <div
              key={customer.id}
              className="bg-white text-slate-900 rounded-xl p-2.5 sm:p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-sm"
            >
              <div
                onClick={() => onSelectCustomer(customer.id)}
                className="cursor-pointer hover:opacity-80 transition min-w-0"
              >
                <div className="font-extrabold text-sm text-slate-900 truncate">
                  {customer.name}
                </div>
                <div className="text-xs text-slate-600 flex items-center gap-1 mt-0.5">
                  <span className="font-bold text-orange-600">{customer.phone || 'मोबाइल उपलब्ध नहीं'}</span>
                  <span>•</span>
                  <span className="truncate text-slate-500 max-w-[150px]">{customer.address}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
                {cleanPhone && (
                  <>
                    <a
                      href={`tel:${cleanPhone}`}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs active:scale-95"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>कॉल</span>
                    </a>
                    <a
                      href={`https://wa.me/${waPhone}?text=${waMsg}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-green-500 hover:bg-green-600 text-white text-xs font-bold shadow-xs active:scale-95"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                  </>
                )}
                <button
                  onClick={() => onRenewDealDate(info)}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold shadow-xs active:scale-95 cursor-pointer"
                  title="आज नया सिलेंडर दिया"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>आज दिया</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {dueCustomers.length > 3 && (
        <div className="mt-2 text-right">
          <span className="text-xs text-yellow-200 font-bold inline-flex items-center gap-1">
            <span>+{dueCustomers.length - 3} अन्य ग्राहक नीचे सूची में देखें</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </span>
        </div>
      )}
    </div>
  );
};
