import { useMemo, useState } from "react";
import { Donut } from "@/components/charts";
import { Field, PnlText, Sheet } from "@/components/ui";
import { allocation, futureValue, portfolioCost, portfolioValue, resolveRates, weightedExpectedReturn } from "@/lib/calc";
import { formatKrw, formatMan, formatPct, parseNum } from "@/lib/format";
import { usePortfolio } from "@/lib/store";
import type { TabId, TxKind } from "@/lib/types";

export function HomeView({
  onNavigate,
  onTrade,
}: {
  onNavigate: (tab: TabId) => void;
  onTrade: (kind: TxKind) => void;
}) {
  const data = usePortfolio();
  const [targetsOpen, setTargetsOpen] = useState(false);
  const [resetAsk, setResetAsk] = useState(false);
  const fx = data.market.fx;
  const total = portfolioValue(data.holdings, fx);
  const cost = portfolioCost(data.holdings, fx);
  const pnl = total - cost;
  const pnlPct = cost > 0 ? (pnl / cost) * 100 : 0;
  const rows = useMemo(() => allocation(data.holdings, data.classes, fx), [data.holdings, data.classes, fx]);
  const slices = rows.filter((row) => row.value > 0);
  const computed = weightedExpectedReturn(rows);
  const rates = resolveRates(computed, data.settings);
  const years = data.settings.years;
  const monthly = data.settings.contribution;
  const targetSum = data.classes.reduce((sum, item) => sum + item.target, 0);

  return (
    <div className="space-y-4">
      {data.isSample ? (
        <div className="rounded-xl bg-surface-2 px-3 py-3 text-sm text-muted">
          예시 포트폴리오입니다. 종목을 고치거나 비우고 내 계좌로 바꾸세요.
          <div className="mt-2 flex gap-2">
            <button type="button" className="h-11 rounded-md bg-surface px-3 text-sm font-medium text-fg" onClick={() => onNavigate("assets")}>
              자산 고치기
            </button>
            <button type="button" className="h-11 rounded-md px-3 text-sm text-fg" onClick={() => data.startFresh()}>
              비우고 시작
            </button>
          </div>
        </div>
      ) : null}

      <section className="card p-4">
        <p className="text-sm text-muted">총 평가액</p>
        <p className="mt-1 text-3xl font-semibold tracking-tight tabular-nums">{formatKrw(total)}</p>
        <p className="mt-1 text-sm">
          <PnlText value={pnl}>
            {pnl >= 0 ? "평가이익" : "평가손실"} {formatKrw(Math.abs(pnl))} ({formatPct(pnlPct)})
          </PnlText>
        </p>
        <p className="mt-1 text-xs text-muted">달러 자산은 현재 환율 {formatKrw(fx).replace("원", "")}원으로 환산</p>
        <div className="mt-4 grid grid-cols-3 gap-2">
          {(["buy", "sell", "dividend"] as const).map((kind) => (
            <button key={kind} type="button" className="h-11 rounded-lg bg-surface-2 text-sm font-medium" onClick={() => onTrade(kind)}>
              {kind === "buy" ? "매수" : kind === "sell" ? "매도" : "배당"}
            </button>
          ))}
        </div>
      </section>

      <section className="card p-4">
        <div className="mb-2 flex items-baseline justify-between">
          <h2 className="text-base font-semibold">자산군 비중</h2>
          <button type="button" className="h-11 px-2 text-sm text-primary" onClick={() => setTargetsOpen(true)}>
            목표 조정
          </button>
        </div>
        <div className="grid items-center gap-3 md:grid-cols-[16rem_1fr]">
          <Donut data={slices.map((row) => ({ id: row.id, name: row.name, value: row.value, color: row.color }))} />
          <ul className="space-y-1.5">
            {rows
              .filter((row) => row.value > 0)
              .map((row) => (
                <li key={row.id} className="flex min-w-0 items-center gap-2">
                  <span className="size-2 shrink-0 rounded-full" style={{ background: row.color }} />
                  <span className="min-w-0 flex-1 truncate text-sm">{row.name}</span>
                  <span className="shrink-0 text-sm tabular-nums">{formatMan(row.value)}</span>
                  <span className="w-12 shrink-0 text-right text-xs tabular-nums text-muted">{row.pct.toFixed(1)}%</span>
                </li>
              ))}
          </ul>
        </div>
      </section>

      <section className="card p-4">
        <div className="mb-1 flex items-baseline justify-between gap-3">
          <h2 className="text-base font-semibold">목표보다 어디가 부족한지</h2>
          <span className={targetSum === 100 ? "text-xs text-muted" : "text-xs text-down"}>목표 합계 {targetSum.toFixed(0)}%</span>
        </div>
        <p className="mb-3 text-xs text-muted">막대는 현재 비중, 눈금은 목표입니다. 부족 금액은 지금 평가액 기준입니다.</p>
        <ul className="space-y-3">
          {rows.map((row) => {
            const short = row.gapPct > 0.2;
            const over = row.gapPct < -0.2;
            return (
              <li key={row.id}>
                <div className="flex items-baseline justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{row.name}</p>
                    <p className="text-xs tabular-nums text-muted">
                      {row.pct.toFixed(1)}% / 목표 {row.target.toFixed(1)}%
                    </p>
                  </div>
                  <p className={`shrink-0 text-right text-sm tabular-nums ${short ? "text-down" : "text-muted"}`}>
                    {short ? `부족 ${formatKrw(row.gapKrw)}` : over ? `초과 ${formatKrw(-row.gapKrw)}` : "거의 일치"}
                  </p>
                </div>
                <div className="relative mt-2 h-2 rounded-full bg-surface-2">
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${Math.min(100, Math.max(0, row.pct))}%`, background: row.color }}
                  />
                  <span
                    className="absolute top-1/2 h-3.5 w-0.5 -translate-y-1/2 bg-fg"
                    style={{ left: `${Math.min(100, Math.max(0, row.target))}%` }}
                  />
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      <button type="button" className="card w-full p-4 text-left" onClick={() => onNavigate("outlook")}>
        <p className="text-base font-semibold">이대로 {years}년</p>
        <p className="mt-1 text-xs text-muted">
          매달 {formatMan(monthly)} 추가 · 평균 {rates.average.toFixed(1)}%는 보유 자산 기대수익의 가중평균
        </p>
        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          <Mini label="비관" value={futureValue(total, rates.pessimistic, monthly, years)} />
          <Mini label="평균" value={futureValue(total, rates.average, monthly, years)} />
          <Mini label="낙관" value={futureValue(total, rates.optimistic, monthly, years)} />
        </div>
      </button>

      <div className="flex flex-wrap gap-2 pb-2">
        {resetAsk ? (
          <>
            <p className="w-full text-xs text-muted">예시로 되돌리면 지금 입력한 자산과 기록이 지워집니다.</p>
            <button type="button" className="h-11 rounded-lg bg-fg px-3 text-sm text-bg" onClick={() => { data.resetSample(); setResetAsk(false); }}>
              예시로 되돌리기
            </button>
            <button type="button" className="h-11 px-3 text-sm" onClick={() => setResetAsk(false)}>
              취소
            </button>
          </>
        ) : (
          <button type="button" className="h-11 px-1 text-sm text-muted" onClick={() => setResetAsk(true)}>
            예시 포트폴리오로 되돌리기
          </button>
        )}
      </div>

      <TargetSheet open={targetsOpen} onClose={() => setTargetsOpen(false)} />
    </div>
  );
}

function Mini({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg bg-surface-2 px-2 py-2">
      <p className="text-xs text-muted">{label}</p>
      <p className="text-sm font-semibold tabular-nums">{formatMan(value)}</p>
    </div>
  );
}

function TargetSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const classes = usePortfolio((state) => state.classes);
  const updateClass = usePortfolio((state) => state.updateClass);
  const addClass = usePortfolio((state) => state.addClass);
  const removeClass = usePortfolio((state) => state.removeClass);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState("");
  const sum = classes.reduce((total, item) => total + item.target, 0);

  return (
    <Sheet open={open} title="목표 비중" onClose={onClose}>
      <p className="mb-3 text-sm text-muted">기본 9개 자산군입니다. 이름을 바꾸고, 목표를 맞추고, 없는 자산군은 추가하세요.</p>
      <p className={`mb-3 text-sm tabular-nums ${Math.abs(sum - 100) < 0.05 ? "text-muted" : "text-down"}`}>합계 {sum.toFixed(1)}%</p>
      <ul className="space-y-3">
        {classes.map((item) => (
          <li key={item.id} className="grid grid-cols-[auto_minmax(0,1fr)_4.5rem_auto] items-center gap-2">
            <span className="size-2.5 rounded-full" style={{ background: item.color }} />
            <input
              className="field min-w-0"
              value={item.name}
              aria-label={`${item.name} 이름`}
              onChange={(event) => updateClass(item.id, { name: event.target.value })}
            />
            <input
              className="field text-right tabular-nums"
              inputMode="decimal"
              aria-label={`${item.name} 목표 비중`}
              value={String(item.target)}
              onChange={(event) => {
                const next = parseNum(event.target.value);
                updateClass(item.id, { target: next == null ? 0 : Math.max(0, next) });
              }}
            />
            <button
              type="button"
              className="h-11 px-2 text-sm text-down"
              onClick={() => {
                const message = removeClass(item.id);
                setError(message);
              }}
            >
              삭제
            </button>
          </li>
        ))}
      </ul>
      {error ? <p className="mt-2 text-sm text-down">{error}</p> : null}
      <form
        className="mt-4 space-y-2"
        onSubmit={(event) => {
          event.preventDefault();
          addClass(name);
          setName("");
          setError(null);
        }}
      >
        <Field label="자산군 추가">
          <input className="field" value={name} placeholder="예: 원자재" onChange={(event) => setName(event.target.value)} />
        </Field>
        <button type="submit" className="h-11 w-full rounded-lg bg-primary text-sm font-medium text-primary-fg">
          추가
        </button>
      </form>
    </Sheet>
  );
}
