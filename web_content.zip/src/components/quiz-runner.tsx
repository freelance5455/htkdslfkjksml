import { useState } from "react";
import type { Question } from "@/content/catalog";
import { t } from "@/content/copy";
import { Button } from "@/components/ui/button";
import { fill, tx, type Locale } from "@/lib/locale";
import { cn } from "@/lib/cn";

export function QuizRunner({
  questions,
  locale,
  mode,
  submitLabel,
  onSubmit,
}: {
  questions: Question[];
  locale: Locale;
  mode: "all" | "step";
  submitLabel: string;
  onSubmit: (answers: number[]) => Promise<{ score: number; total: number; marks: boolean[]; synced: boolean }>;
}) {
  const [answers, setAnswers] = useState<number[]>(() => questions.map(() => -1));
  const [step, setStep] = useState(0);
  const [result, setResult] = useState<{ score: number; total: number; marks: boolean[]; synced: boolean } | null>(
    null,
  );
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function choose(index: number, choice: number) {
    if (result) return;
    setAnswers((current) => current.map((value, item) => (item === index ? choice : value)));
  }

  async function submit() {
    if (answers.some((answer) => answer < 0)) {
      setError(t(locale, "choose"));
      return;
    }
    setPending(true);
    setError(null);
    try {
      const graded = await onSubmit(answers);
      setResult(graded);
    } finally {
      setPending(false);
    }
  }

  if (result) {
    const ratio = result.total ? result.score / result.total : 0;
    return (
      <section className="rounded-2xl border border-line bg-card p-4">
        <p className="text-sm font-semibold text-muted">{t(locale, "yourScore")}</p>
        <p className="mt-1 text-3xl font-semibold tabular-nums text-ink">
          {fill(t(locale, "outOf"), { score: result.score, total: result.total })}
        </p>
        <p className="mt-1 text-sm font-semibold text-teal-deep">
          {ratio >= 0.6 ? t(locale, "strong") : t(locale, "keepGoing")}
        </p>
        {!result.synced ? <p className="mt-2 text-sm text-muted">{t(locale, "syncLater")}</p> : null}
        <ol className="mt-5 space-y-4">
          {questions.map((question, index) => {
            const mark = result.marks[index];
            return (
              <li key={question.id} className="border-t border-line pt-4">
                <p className="font-semibold">{tx(locale, question.prompt)}</p>
                <p className={cn("mt-1 text-sm font-semibold", mark ? "text-teal-deep" : "text-danger")}>
                  {mark ? t(locale, "correct") : t(locale, "incorrect")}
                </p>
                <p className="mt-1 text-sm text-muted">
                  <span className="font-semibold text-ink">{t(locale, "explanation")}. </span>
                  {tx(locale, question.explain)}
                </p>
              </li>
            );
          })}
        </ol>
        <Button
          className="mt-5"
          variant="secondary"
          onClick={() => {
            setResult(null);
            setAnswers(questions.map(() => -1));
            setStep(0);
          }}
        >
          {t(locale, "retake")}
        </Button>
      </section>
    );
  }

  const visible = mode === "all" ? questions.map((question, index) => ({ question, index })) : [{ question: questions[step], index: step }];

  return (
    <section className="space-y-4">
      {mode === "step" ? (
        <p className="text-sm font-semibold tabular-nums text-muted">
          {fill(t(locale, "questionOf"), { n: step + 1, total: questions.length })}
        </p>
      ) : null}
      {visible.map(({ question, index }) => (
        <fieldset key={question.id} className="rounded-2xl border border-line bg-card p-4">
          <legend className="px-1 font-semibold">{tx(locale, question.prompt)}</legend>
          <div className="mt-3 grid gap-2">
            {question.choices.map((choice, choiceIndex) => {
              const selected = answers[index] === choiceIndex;
              return (
                <button
                  key={choice.en}
                  type="button"
                  aria-pressed={selected}
                  onClick={() => choose(index, choiceIndex)}
                  className={cn(
                    "min-h-11 rounded-md border px-3 py-2 text-left text-sm font-semibold transition-[background-color,border-color] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]",
                    selected ? "border-teal bg-foam text-teal-deep" : "border-line bg-card text-ink",
                  )}
                >
                  {tx(locale, choice)}
                </button>
              );
            })}
          </div>
        </fieldset>
      ))}
      {error ? <p className="text-sm font-semibold text-danger">{error}</p> : null}
      <div className="flex gap-2">
        {mode === "step" && step > 0 ? (
          <Button variant="secondary" onClick={() => setStep((value) => value - 1)}>
            {t(locale, "back")}
          </Button>
        ) : null}
        {mode === "step" && step < questions.length - 1 ? (
          <Button
            onClick={() => {
              if (answers[step] < 0) {
                setError(t(locale, "choose"));
                return;
              }
              setError(null);
              setStep((value) => value + 1);
            }}
          >
            {t(locale, "next")}
          </Button>
        ) : (
          <Button disabled={pending} onClick={() => void submit()}>
            {pending ? t(locale, "working") : submitLabel}
          </Button>
        )}
      </div>
    </section>
  );
}
