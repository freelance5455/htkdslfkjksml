import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CloudSun,
  TrendingUp,
  TrendingDown,
  Calendar,
  CheckCircle,
  ExternalLink,
  PhoneCall,
  MessageSquare,
  Heart,
  Plus,
  ArrowUpDown,
  Calculator,
  ShieldCheck,
  MapPin,
  Sparkles,
  Wallet,
  Send,
  ShoppingCart,
  ChevronRight,
  Globe2,
  Sprout,
  Award,
  Layers,
  Flame,
  Info,
  Download,
  FileText,
  FileSpreadsheet,
  Printer,
  X,
  Check,
  Bell,
  BellRing,
  Target,
  Trash2,
  CheckCircle2,
  Sliders,
  History,
  Clock,
  Search,
  Filter,
  ArrowUpRight,
  CheckCheck,
  Bug,
  Ship,
  Camera,
} from 'lucide-react';
import {
  Language,
  UserProfile,
  CropRecord,
  MarketPrice,
  BuyerListing,
  CommunityPost,
  WorldCashCrop,
  PriceAlert,
  MarketAlertHistoryItem,
} from '../types';
import {
  INITIAL_CROPS,
  MARKET_PRICES,
  BUYERS_LIST,
  COMMUNITY_POSTS,
  WORLD_CASH_CROPS,
  INITIAL_PRICE_ALERTS,
  INITIAL_MARKET_ALERT_HISTORY,
} from '../data/mockData';
import { playKeyTap, playSuccessChime } from '../utils/audio';
import WeatherWidget from './WeatherWidget';
import CropPriceTrendChart from './CropPriceTrendChart';
import GrandPromotionBanner from './GrandPromotionBanner';
import ExpertAdviceCarousel from './ExpertAdviceCarousel';
import NotificationHistoryTab from './NotificationHistoryTab';
import ExportMarketsTab from './ExportMarketsTab';

// Real Farm Photographic Image
import realFarmImg from '../assets/images/real_farm_landscape_1789732053942.jpg';

interface ViewsProps {
  language: Language;
  user: UserProfile;
  onNavigateToWallet?: () => void;
  onNavigateToBuyers?: () => void;
  onNavigateToPestDoctor?: () => void;
  onNavigateToAggregationPools?: () => void;
}

// 1. HOME VIEW
export function HomeView({
  language,
  user,
  onNavigateToWallet,
  onNavigateToPestDoctor,
  onNavigateToAggregationPools,
}: ViewsProps) {
  const isSw = language === 'sw';
  const [crops, setCrops] = useState<CropRecord[]>(INITIAL_CROPS);
  const [selectedCrop, setSelectedCrop] = useState<CropRecord | null>(null);

  return (
    <div id="dashboard-home-view" className="space-y-4 pb-6">
      {/* Greeting Header */}
      <div className="pt-2 flex items-center justify-between">
        <div>
          <div className="text-xs text-[var(--ink-soft)] font-medium">
            {isSw ? 'Habari za asubuhi,' : 'Good morning,'}
          </div>
          <h2 className="font-display text-2xl font-bold text-[var(--ink)]">
            {user.name}
          </h2>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[var(--forest)]/10 text-[var(--forest)]">
          {user.region}
        </span>
      </div>

      {/* REAL FARM PHOTOGRAPHIC HERO CARD */}
      <div
        id="real-farm-hero-card"
        className="relative w-full h-44 sm:h-48 rounded-3xl overflow-hidden shadow-lg border border-[var(--line)] group"
      >
        <img
          src={realFarmImg}
          alt="Ardhi Real Farm"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent flex flex-col justify-end p-4 text-[#F7F4E9]">
          <div className="flex items-center justify-between mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-600/90 backdrop-blur-md text-[#F7F4E9] text-[10px] font-bold tracking-wider uppercase flex items-center gap-1 shadow-sm">
              <Sprout className="w-3 h-3" />
              <span>{isSw ? 'Shamba Lako Halisi' : 'Your Real Farmland'}</span>
            </span>
            <span className="text-[11px] font-semibold text-amber-300 flex items-center gap-1 drop-shadow">
              <MapPin className="w-3 h-3" />
              <span>{user.region}, Tanzania</span>
            </span>
          </div>

          <h3 className="font-display text-lg sm:text-xl font-bold leading-tight drop-shadow text-white">
            {isSw ? `Mashamba ya Mazao ya ${user.name}` : `${user.name}'s Cultivated Acreage`}
          </h3>

          <div className="flex items-center gap-3 text-xs text-white/90 mt-1 drop-shadow">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{isSw ? 'Udongo wenye Rutuba Bora' : 'Fertile Loam Soil'}</span>
            </div>
            <span>•</span>
            <span>{isSw ? 'Hatua ya Mimea: Siku 58' : 'Crop Stage: Day 58'}</span>
          </div>
        </div>
      </div>

      {/* GRAND PROMOTION OFFER: RANGE ROVER & DUBAI TRIP */}
      <GrandPromotionBanner
        language={language}
        user={user}
        onNavigateToWalletBuy={onNavigateToWallet}
        onNavigateToSendMoney={onNavigateToWallet}
      />

      {/* WeatherWidget with 5-Day Forecast & Agro Planning */}
      <WeatherWidget language={language} region={user.region} />

      {/* Farmer Wallet Quick Card */}
      <div
        className="rounded-2xl p-4 bg-[var(--paper)] border border-[var(--line)] shadow-sm flex flex-col gap-3"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[var(--forest)] text-[#F7F4E9] flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-xs text-[var(--ink)]">
                {isSw ? 'Pochi ya Mkulima' : 'Farmer Wallet'}
              </div>
              <div className="text-[10px] text-[var(--ink-soft)] font-mono">
                ID: ARD-{user.phone.slice(-6)}
              </div>
            </div>
          </div>
          {onNavigateToWallet && (
            <button
              onClick={onNavigateToWallet}
              className="text-xs font-semibold text-[var(--forest)] hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              <span>{isSw ? 'Fungua Pochi' : 'Open Wallet'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex items-center justify-between pt-1">
          <div>
            <span className="text-[10px] text-[var(--ink-soft)] block uppercase tracking-wider">
              {isSw ? 'Salio Linalopatikana' : 'Available Balance'}
            </span>
            <span className="font-display text-xl font-bold text-[var(--forest)]">
              Tsh 345,000
            </span>
          </div>
          <div className="flex gap-2">
            {onNavigateToWallet && (
              <>
                <button
                  onClick={onNavigateToWallet}
                  className="py-1.5 px-3 rounded-xl bg-[var(--forest)] text-[#F7F4E9] text-[11px] font-semibold flex items-center gap-1 shadow-sm active:scale-95 transition-all cursor-pointer"
                >
                  <Send className="w-3 h-3" />
                  <span>{isSw ? 'Tuma Pesa' : 'Send'}</span>
                </button>
                <button
                  onClick={onNavigateToWallet}
                  className="py-1.5 px-3 rounded-xl bg-[var(--bg)] border border-[var(--line)] hover:border-[var(--forest)] text-[var(--ink)] text-[11px] font-semibold flex items-center gap-1 active:scale-95 transition-all cursor-pointer"
                >
                  <ShoppingCart className="w-3 h-3 text-[var(--forest)]" />
                  <span>{isSw ? 'Pembejeo' : 'Inputs'}</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Farm Growth Wallet Progress Sub-strip */}
        <div className="pt-2.5 border-t border-[var(--line)] flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs bg-[var(--bg)] p-2.5 rounded-xl border">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
              <Sprout className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="font-bold text-[11px] text-[var(--ink)] flex items-center gap-1.5">
                <span>{isSw ? 'Mfuko wa Kukuza Shamba (Reinvestment Vault)' : 'Farm Growth Wallet'}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 font-bold">
                  72%
                </span>
              </div>
              <div className="text-[10px] text-[var(--ink-soft)]">
                {isSw
                  ? 'Umehifadhi Tsh 180,000 / Tsh 250,000 kwa pembejeo za Masika'
                  : 'Saved Tsh 180k of Tsh 250k goal for Masika season inputs'}
              </div>
            </div>
          </div>
          {onNavigateToWallet && (
            <button
              onClick={onNavigateToWallet}
              className="text-[10px] font-bold text-[var(--forest)] hover:underline flex items-center gap-0.5 self-end sm:self-auto cursor-pointer"
            >
              <span>{isSw ? 'Tenga Salio' : 'Allocate Stash'}</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* EXPERT ADVICE CAROUSEL WITH SEASON & CROP-DRIVEN TIPS */}
      <ExpertAdviceCarousel
        language={language}
        user={user}
        onNavigateToWallet={onNavigateToWallet}
      />

      {/* NEW SMART AGRI-FEATURES QUICK LAUNCHER */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* 1. Pest & Disease Diagnostic Doctor Card */}
        <div
          onClick={() => {
            playKeyTap();
            if (onNavigateToPestDoctor) onNavigateToPestDoctor();
          }}
          className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500/15 via-teal-500/10 to-[var(--bg)] border border-emerald-500/30 hover:border-emerald-500 shadow-xs cursor-pointer transition-all flex flex-col justify-between group"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                <Camera className="w-3 h-3 text-emerald-600" />
                <span>{isSw ? 'Kipiga Picha & Uchunguzi' : 'Pest Scanner'}</span>
              </span>
              <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-bold font-mono">
                TPRI / TFRA
              </span>
            </div>

            <h4 className="font-display font-bold text-sm text-[var(--ink)] group-hover:text-emerald-700 dark:group-hover:text-emerald-300 transition-colors flex items-center gap-1.5">
              <span>{isSw ? 'Daktari wa Mimea & Wadudu' : 'Field Crop Doctor & Pests'}</span>
            </h4>
            <p className="text-[11px] text-[var(--ink-soft)] mt-1 line-clamp-2 leading-relaxed">
              {isSw
                ? 'Tambua Funza wa Mahindi, Ukungu wa Nyanya na Kutu ya Kahawa kwa picha na upate tiba sahihi.'
                : 'Diagnose Armyworm, Blight, and Rust with visual analysis and registered chemical dosages.'}
            </p>
          </div>

          <div className="pt-3 border-t border-emerald-500/20 mt-3 flex items-center justify-between text-xs font-bold text-emerald-700 dark:text-emerald-300">
            <span>{isSw ? 'Fungua Kichunguzi' : 'Open Diagnostic Lab'}</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* 2. Cooperative Aggregation & AMCOS Export Pools Card */}
        <div
          onClick={() => {
            playKeyTap();
            if (onNavigateToAggregationPools) onNavigateToAggregationPools();
          }}
          className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/15 via-indigo-500/10 to-[var(--bg)] border border-blue-500/30 hover:border-blue-500 shadow-xs cursor-pointer transition-all flex flex-col justify-between group"
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-800 dark:text-blue-300 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                <Ship className="w-3 h-3 text-blue-600" />
                <span>{isSw ? 'Makontena ya Nje' : 'Export Pools'}</span>
              </span>
              <span className="text-[10px] text-amber-700 dark:text-amber-300 font-bold">
                +43% {isSw ? 'Faida Zaidi' : 'Gain'}
              </span>
            </div>

            <h4 className="font-display font-bold text-sm text-[var(--ink)] group-hover:text-blue-700 dark:group-hover:text-blue-300 transition-colors flex items-center gap-1.5">
              <span>{isSw ? 'Uuzaji wa Pamoja (AMCOS Pools)' : 'Harvest Aggregation Pools'}</span>
            </h4>
            <p className="text-[11px] text-[var(--ink-soft)] mt-1 line-clamp-2 leading-relaxed">
              {isSw
                ? 'Ungana na wakulima wenzako kujaza makontena ya FCL ya Ufuta, Parachichi na Soya kuelekea China na Ulaya.'
                : 'Pool harvests into 20ft/40ft containers directly to overseas buyers at top port FOB prices.'}
            </p>
          </div>

          <div className="pt-3 border-t border-blue-500/20 mt-3 flex items-center justify-between text-xs font-bold text-blue-700 dark:text-blue-300">
            <span>{isSw ? 'Tazama Makontena Wazi' : 'View Open Pools'}</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>

      {/* Price Ticker Strip */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar py-1">
        {MARKET_PRICES.slice(0, 4).map((item) => (
          <div
            key={item.id}
            className="flex-shrink-0 px-3 py-2 rounded-xl bg-[var(--paper)] border border-[var(--line)] flex items-center gap-2 text-xs shadow-sm"
          >
            <span className="font-semibold text-[var(--ink)]">
              {isSw ? item.cropNameSw : item.cropNameEn}
            </span>
            <span className="font-display font-bold text-[var(--forest)]">{item.priceDisplay}</span>
            <span
              className={`flex items-center text-[10px] font-bold ${
                item.isUp ? 'text-[var(--up)]' : 'text-[var(--down)]'
              }`}
            >
              {item.isUp ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
              {item.deltaPercent}%
            </span>
          </div>
        ))}
      </div>

      {/* Your Crops Section */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--ink-soft)]">
            {isSw ? 'Mazao Yako Shambani' : 'Your Farmed Crops'}
          </h3>
          <span className="text-[11px] text-[var(--forest)] font-semibold">
            {crops.length} {isSw ? 'Mashamba' : 'Plots'}
          </span>
        </div>

        <div className="space-y-2.5">
          {crops.map((crop) => (
            <div
              key={crop.id}
              onClick={() => {
                playKeyTap();
                setSelectedCrop(selectedCrop?.id === crop.id ? null : crop);
              }}
              className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] shadow-sm hover:border-[var(--forest)] transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-[var(--gold-soft)] flex items-center justify-center text-2xl flex-shrink-0">
                  {crop.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-[var(--ink)]">
                      {isSw ? crop.nameSw : crop.nameEn} — {isSw ? crop.plotNameSw : crop.plotNameEn}
                    </span>
                    <span className="text-xs font-bold font-display text-[var(--forest)]">
                      {crop.progressPercent}%
                    </span>
                  </div>
                  <div className="text-[11px] text-[var(--ink-soft)] mt-0.5 truncate">
                    {isSw ? crop.stageNoteSw : crop.stageNoteEn}
                  </div>
                  {/* Progress Bar */}
                  <div className="w-full h-1.5 bg-[var(--line)] rounded-full mt-2 overflow-hidden">
                    <div
                      className="h-full bg-[var(--forest)] rounded-full transition-all duration-500"
                      style={{ width: `${crop.progressPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Expanded Advice Accordion */}
              {selectedCrop?.id === crop.id && (
                <div className="mt-3 pt-3 border-t border-[var(--line)] text-xs text-[var(--ink)] bg-[var(--bg)] p-2.5 rounded-xl">
                  <div className="font-semibold text-[var(--soil)] flex items-center gap-1 mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isSw ? 'Ushauri wa Kitaalamu:' : 'Agronomist Recommendation:'}</span>
                  </div>
                  <p className="text-[11px] text-[var(--ink-soft)] leading-relaxed">
                    {isSw ? crop.adviceSw : crop.adviceEn}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Daily Agricultural Tip */}
      <div className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] shadow-sm flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-700 dark:text-amber-300 flex items-center justify-center text-lg flex-shrink-0">
          💡
        </div>
        <div>
          <div className="font-bold text-xs text-[var(--ink)]">
            {isSw ? 'Muda mzuri wa kupanda mtama' : 'Best window for sorghum planting'}
          </div>
          <div className="text-[11px] text-[var(--ink-soft)] mt-0.5 leading-relaxed">
            {isSw
              ? 'Wiki 2 zijazo zinatoa unyevu mzuri zaidi wa udongo kabla ya msimu wa kiangazi.'
              : 'The upcoming two weeks provide peak soil moisture ahead of the dry spell.'}
          </div>
        </div>
      </div>
    </div>
  );
}

// 2. CALENDAR VIEW
export function CalendarView({ language, user }: ViewsProps) {
  const isSw = language === 'sw';

  // State
  const [selectedSeason, setSelectedSeason] = useState<'all' | 'masika' | 'vuli'>('all');
  const [showPdfModal, setShowPdfModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const events = [
    {
      id: 'sched-1',
      crop: 'Mahindi',
      cropEn: 'Maize',
      variety: 'SC627 Dawa Bora (Chotara)',
      plotSw: 'Shamba Kuu (2.5 Ekari)',
      plotEn: 'Main Field (2.5 Acres)',
      icon: '🌽',
      season: 'masika',
      seasonSw: 'Msimu wa Masika',
      seasonEn: 'Masika Season',
      plantSw: 'Okt 15 – Nov 10',
      plantEn: 'Oct 15 – Nov 10',
      harvestSw: 'Feb 20 – Mac 10',
      harvestEn: 'Feb 20 – Mar 10',
      statusSw: 'Katikati ya Ukuaji',
      statusEn: 'Mid Vegetative',
      progressPercent: 65,
      estYield: '35 Magunia / Ekari',
      estYieldEn: '35 Bags / Acre',
      keyAdviceSw: 'Weka mbolea ya kukuzia (Urea/CAN) sasa kabla udongo haujakauka.',
      keyAdviceEn: 'Apply top-dressing fertilizer (Urea/CAN) while soil retains moisture.',
    },
    {
      id: 'sched-2',
      crop: 'Mpunga Super',
      cropEn: 'Super Rice',
      variety: 'SARO 5 (TXD 306)',
      plotSw: 'Bonde la Kilombero (1.8 Ekari)',
      plotEn: 'Kilombero Basin (1.8 Acres)',
      icon: '🍚',
      season: 'masika',
      seasonSw: 'Msimu wa Masika',
      seasonEn: 'Masika Season',
      plantSw: 'Des 1 – Des 20',
      plantEn: 'Dec 1 – Dec 20',
      harvestSw: 'Apr 15 – Mei 5',
      harvestEn: 'Apr 15 – May 5',
      statusSw: 'Ujazaji wa Nafaka',
      statusEn: 'Grain Filling',
      progressPercent: 82,
      estYield: '42 Magunia / Ekari',
      estYieldEn: '42 Bags / Acre',
      keyAdviceSw: 'Dumisha kina cha maji cha inchi 2–3 ili kuzuia magugu.',
      keyAdviceEn: 'Maintain 2–3 inch water depth to suppress weed emergence.',
    },
    {
      id: 'sched-3',
      crop: 'Maharage ya Njano',
      cropEn: 'Yellow Beans',
      variety: 'Njano ya Kilosa (Uyole)',
      plotSw: 'Kitalu B (1.0 Ekari)',
      plotEn: 'Plot B (1.0 Acre)',
      icon: '🫘',
      season: 'vuli',
      seasonSw: 'Msimu wa Vuli',
      seasonEn: 'Vuli Season',
      plantSw: 'Nov 1 – Nov 25',
      plantEn: 'Nov 1 – Nov 25',
      harvestSw: 'Jan 20 – Feb 10',
      harvestEn: 'Jan 20 – Feb 10',
      statusSw: 'Karibu Kuvunwa',
      statusEn: 'Near Harvest',
      progressPercent: 94,
      estYield: '16 Magunia / Ekari',
      estYieldEn: '16 Bags / Acre',
      keyAdviceSw: 'Punguza umwagiliaji na uandae kichanja safi cha kukaushia.',
      keyAdviceEn: 'Taper irrigation and prepare raised clean drying racks.',
    },
    {
      id: 'sched-4',
      crop: 'Karanga',
      cropEn: 'Groundnuts',
      variety: 'Red Mwitunde / Pendo',
      plotSw: 'Shamba la Mlimani (1.2 Ekari)',
      plotEn: 'Hillside Plot (1.2 Acres)',
      icon: '🥜',
      season: 'vuli',
      seasonSw: 'Msimu wa Vuli',
      seasonEn: 'Vuli Season',
      plantSw: 'Nov 10 – Des 5',
      plantEn: 'Nov 10 – Dec 5',
      harvestSw: 'Mac 1 – Mac 20',
      harvestEn: 'Mar 1 – Mar 20',
      statusSw: 'Kutengeneza Vifuko',
      statusEn: 'Pod Formation',
      progressPercent: 55,
      estYield: '18 Magunia / Ekari',
      estYieldEn: '18 Bags / Acre',
      keyAdviceSw: 'Epuka kupalilia kwa kina kirefu ili usikate vifuko vinavyozama ardhini.',
      keyAdviceEn: 'Avoid deep hoeing to protect subterranean pegging pods.',
    },
  ];

  const filteredEvents = events.filter((ev) => {
    if (selectedSeason === 'all') return true;
    return ev.season === selectedSeason;
  });

  // Handler: Export CSV
  const handleExportCsv = () => {
    playKeyTap();
    const headers = [
      'Crop',
      'Variety',
      'Plot / Acreage',
      'Season',
      'Planting Window',
      'Harvesting Window',
      'Growth Stage',
      'Progress Percent',
      'Estimated Yield',
      'Agronomic Recommendation',
      'Region',
      'Farmer Name',
      'Contact',
    ];

    const rows = filteredEvents.map((ev) => [
      `"${ev.crop}"`,
      `"${ev.variety}"`,
      `"${isSw ? ev.plotSw : ev.plotEn}"`,
      `"${isSw ? ev.seasonSw : ev.seasonEn}"`,
      `"${isSw ? ev.plantSw : ev.plantEn}"`,
      `"${isSw ? ev.harvestSw : ev.harvestEn}"`,
      `"${isSw ? ev.statusSw : ev.statusEn}"`,
      `"${ev.progressPercent}%"`,
      `"${isSw ? ev.estYield : ev.estYieldEn}"`,
      `"${(isSw ? ev.keyAdviceSw : ev.keyAdviceEn).replace(/"/g, '""')}"`,
      `"${user.region}"`,
      `"${user.name}"`,
      `"${user.phone}"`,
    ]);

    const csvString = [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const sanitizedRegion = user.region.toLowerCase().replace(/[^a-z0-9]/g, '_');
    link.setAttribute('download', `ardhi_ratiba_ya_mazao_${sanitizedRegion}_2026.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    playSuccessChime();
    setToastMessage(
      isSw
        ? 'Faili la CSV limepakuliwa kikamilifu!'
        : 'Crop schedule CSV file downloaded successfully!'
    );
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Handler: Direct Download Simulated PDF File
  const handleDownloadPdfFile = () => {
    playKeyTap();
    // Generate a formatted printable HTML document with .pdf extension or print wrapper
    const printContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ratiba ya Mazao 2026 - ${user.name}</title>
  <style>
    body { font-family: 'Helvetica Neue', Arial, sans-serif; padding: 32px; color: #1e2b21; background: #fff; }
    .header { text-align: center; border-bottom: 2px solid #2c4a3b; padding-bottom: 16px; margin-bottom: 20px; }
    .title { font-size: 20px; font-weight: bold; color: #2c4a3b; text-transform: uppercase; margin: 4px 0; }
    .meta-box { background: #f7f5ed; border: 1px solid #d9d3c1; border-radius: 8px; padding: 12px; margin-bottom: 20px; font-size: 12px; }
    .meta-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
    table { width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 24px; }
    th { background: #2c4a3b; color: #fff; text-align: left; padding: 8px; }
    td { border-bottom: 1px solid #e2ded0; padding: 8px; vertical-align: top; }
    .badge { display: inline-block; padding: 2px 6px; border-radius: 4px; font-weight: bold; font-size: 10px; background: #e8f3ec; color: #2c4a3b; }
    .footer { text-align: center; font-size: 10px; color: #6b776a; margin-top: 30px; border-top: 1px solid #e2ded0; padding-top: 10px; }
  </style>
</head>
<body>
  <div class="header">
    <div style="font-size: 12px; letter-spacing: 1px; color: #6b776a; font-weight: bold;">JAMHURI YA MUUNGANO WA TANZANIA · WIZARA YA KILIMO</div>
    <div class="title">RATIBA RASMI YA MSIMU WA KILIMO 2026</div>
    <div style="font-size: 11px; color: #2c4a3b;">ARDHI SMART FARMER COMPANION · OFFICIAL FIELD TIMETABLE</div>
  </div>
  <div class="meta-box">
    <div class="meta-grid">
      <div><strong>Mkulima / Farmer:</strong> ${user.name}</div>
      <div><strong>Mkoa / Region:</strong> ${user.region}</div>
      <div><strong>Simu / Phone:</strong> ${user.phone}</div>
      <div><strong>Namba ya Kumbukumbu:</strong> ARD-SCHED-2026-${Math.floor(1000 + Math.random() * 9000)}</div>
    </div>
  </div>
  <table>
    <thead>
      <tr>
        <th>Zao (Crop)</th>
        <th>Aina / Plot</th>
        <th>Kupanda (Planting)</th>
        <th>Kuvuna (Harvest)</th>
        <th>Hatua (Stage)</th>
        <th>Makadirio ya Mavuno</th>
      </tr>
    </thead>
    <tbody>
      ${filteredEvents
        .map(
          (ev) => `
        <tr>
          <td><strong>${ev.crop}</strong></td>
          <td>${ev.variety}<br><small style="color:#666">${isSw ? ev.plotSw : ev.plotEn}</small></td>
          <td>${isSw ? ev.plantSw : ev.plantEn}</td>
          <td>${isSw ? ev.harvestSw : ev.harvestEn}</td>
          <td><span class="badge">${isSw ? ev.statusSw : ev.statusEn} (${ev.progressPercent}%)</span></td>
          <td><strong>${isSw ? ev.estYield : ev.estYieldEn}</strong></td>
        </tr>
      `
        )
        .join('')}
    </tbody>
  </table>
  <div class="footer">
    Hati hii imetolewa kidijitali na mfumo wa Ardhi Farmer Companion kwa ushirikiano na Afisa Kilimo wa Wilaya.<br>
    Tarehe ya Kutolewa: ${new Date().toLocaleDateString('sw-TZ', { day: 'numeric', month: 'long', year: 'numeric' })}
  </div>
</body>
</html>
    `;

    const blob = new Blob([printContent], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const sanitizedRegion = user.region.toLowerCase().replace(/[^a-z0-9]/g, '_');
    link.setAttribute('download', `ardhi_ratiba_ya_mazao_${sanitizedRegion}_2026.pdf`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    playSuccessChime();
    setToastMessage(
      isSw
        ? 'Faili la PDF limepakuliwa kikamilifu!'
        : 'Crop schedule PDF downloaded successfully!'
    );
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Handler: Print / Native Save to PDF
  const handlePrintPdf = () => {
    playKeyTap();
    window.print();
  };

  return (
    <div id="dashboard-calendar-view" className="space-y-4 pb-6">
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-3 rounded-2xl bg-emerald-600 text-white text-xs font-semibold flex items-center justify-between shadow-lg"
          >
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-200" />
              <span>{toastMessage}</span>
            </div>
            <button
              onClick={() => setToastMessage(null)}
              className="p-1 hover:bg-emerald-700 rounded-full"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header & Export Actions Bar */}
      <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl font-bold text-[var(--ink)]">
            {isSw ? 'Kalenda ya Mazao' : 'Crop Calendar'}
          </h2>
          <p className="text-xs text-[var(--ink-soft)] mt-0.5">
            {isSw
              ? `Ratiba ya msimu wa kilimo — ${user.region}`
              : `Seasonal agricultural timetable — ${user.region}`}
          </p>
        </div>

        {/* Dual Export Buttons */}
        <div className="flex items-center gap-2">
          {/* Export CSV Button */}
          <button
            id="calendar-export-csv-btn"
            onClick={handleExportCsv}
            className="flex-1 sm:flex-initial py-2 px-3 rounded-xl bg-[var(--paper)] hover:bg-[var(--forest)] hover:text-[#F7F4E9] text-[var(--forest)] border border-[var(--line)] text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all cursor-pointer"
            title={isSw ? 'Pakua nakala ya CSV kwenye kifaa chako' : 'Download CSV spreadsheet'}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>{isSw ? 'Pakua CSV' : 'Export CSV'}</span>
          </button>

          {/* Export / Preview PDF Button */}
          <button
            id="calendar-export-pdf-btn"
            onClick={() => {
              playKeyTap();
              setShowPdfModal(true);
            }}
            className="flex-1 sm:flex-initial py-2 px-3 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all cursor-pointer"
            title={isSw ? 'Tazama na pakua PDF ya ratiba' : 'View and export schedule PDF'}
          >
            <FileText className="w-4 h-4 text-amber-300" />
            <span>{isSw ? 'Pakua PDF' : 'Export PDF'}</span>
          </button>
        </div>
      </div>

      {/* Season Filter Switcher */}
      <div className="flex bg-[var(--paper)] p-1 rounded-2xl border border-[var(--line)] text-xs font-semibold">
        {[
          { id: 'all', labelSw: 'Mazao Yote', labelEn: 'All Crops' },
          { id: 'masika', labelSw: 'Msimu wa Masika', labelEn: 'Masika Season' },
          { id: 'vuli', labelSw: 'Msimu wa Vuli', labelEn: 'Vuli Season' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              playKeyTap();
              setSelectedSeason(tab.id as any);
            }}
            className={`flex-1 py-1.5 rounded-xl transition-all ${
              selectedSeason === tab.id
                ? 'bg-[var(--forest)] text-[#F7F4E9] shadow-sm font-bold'
                : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
            }`}
          >
            {isSw ? tab.labelSw : tab.labelEn}
          </button>
        ))}
      </div>

      {/* Schedule Items List */}
      <div className="space-y-2.5">
        {filteredEvents.map((ev) => (
          <div
            key={ev.id}
            className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] shadow-sm hover:border-[var(--forest)] transition-all"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl flex-shrink-0">{ev.icon}</span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-[var(--ink)]">{ev.crop}</span>
                    <span className="text-[10px] text-[var(--ink-soft)] font-mono">
                      {ev.variety}
                    </span>
                  </div>
                  <div className="text-[11px] text-[var(--forest)] font-medium">
                    {isSw ? ev.plotSw : ev.plotEn} · {isSw ? ev.seasonSw : ev.seasonEn}
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[var(--forest)]/15 text-[var(--forest)]">
                {isSw ? ev.statusSw : ev.statusEn}
              </span>
            </div>

            {/* Progress Bar */}
            <div className="mb-2.5">
              <div className="flex justify-between text-[10px] text-[var(--ink-soft)] mb-1">
                <span>{isSw ? 'Maendeleo ya Ukuaji:' : 'Growth Progress:'}</span>
                <span className="font-bold font-display text-[var(--forest)]">
                  {ev.progressPercent}%
                </span>
              </div>
              <div className="w-full h-1.5 bg-[var(--line)] rounded-full overflow-hidden">
                <div
                  className="h-full bg-[var(--forest)] rounded-full transition-all duration-500"
                  style={{ width: `${ev.progressPercent}%` }}
                />
              </div>
            </div>

            {/* Timetable details grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] bg-[var(--bg)] p-2.5 rounded-xl">
              <div>
                <span className="text-[var(--ink-soft)] block text-[10px] uppercase font-bold">
                  {isSw ? 'Kupanda:' : 'Planting:'}
                </span>
                <span className="font-semibold text-[var(--ink)]">
                  {isSw ? ev.plantSw : ev.plantEn}
                </span>
              </div>
              <div>
                <span className="text-[var(--ink-soft)] block text-[10px] uppercase font-bold">
                  {isSw ? 'Kuvuna:' : 'Harvesting:'}
                </span>
                <span className="font-semibold text-[var(--soil)]">
                  {isSw ? ev.harvestSw : ev.harvestEn}
                </span>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <span className="text-[var(--ink-soft)] block text-[10px] uppercase font-bold">
                  {isSw ? 'Mavuno Yaliyotarajiwa:' : 'Est. Yield:'}
                </span>
                <span className="font-semibold text-emerald-700 dark:text-emerald-300">
                  {isSw ? ev.estYield : ev.estYieldEn}
                </span>
              </div>
            </div>

            {/* Agronomic recommendation footnote */}
            <div className="mt-2 text-[11px] text-[var(--ink-soft)] flex items-start gap-1.5 pt-1 border-t border-[var(--line)]">
              <Sparkles className="w-3.5 h-3.5 text-amber-600 flex-shrink-0 mt-0.5" />
              <span>{isSw ? ev.keyAdviceSw : ev.keyAdviceEn}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Task Reminders List */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--ink-soft)] mb-2">
          {isSw ? 'Kumbukumbu za Kazi za Wiki Hii' : 'Task Reminders This Week'}
        </h3>
        <div className="space-y-2">
          <div className="p-3 rounded-xl bg-[var(--paper)] border border-[var(--line)] flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
            <div className="text-xs">
              <div className="font-bold text-[var(--ink)]">
                {isSw ? 'Kupulizia dawa — Shamba A la Mahindi' : 'Spraying — Maize Field A'}
              </div>
              <div className="text-[11px] text-[var(--ink-soft)] mt-0.5">
                {isSw ? 'Kesho saa 12 asubuhi (kabla ya upepo kuanza)' : 'Tomorrow 6:00 AM (before morning wind)'}
              </div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[var(--paper)] border border-[var(--line)] flex items-center gap-3">
            <Calendar className="w-5 h-5 text-amber-600 flex-shrink-0" />
            <div className="text-xs">
              <div className="font-bold text-[var(--ink)]">
                {isSw ? 'Kukagua unyevu wa udongo — Kitalu B cha Maharage' : 'Soil moisture inspection — Beans Plot B'}
              </div>
              <div className="text-[11px] text-[var(--ink-soft)] mt-0.5">
                {isSw ? 'Ijumaa saa 10 jioni kujiandaa na uvunaji' : 'Friday 4:00 PM in preparation for harvest'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SIMULATED PDF PREVIEW & EXPORT MODAL */}
      {/* ========================================================================= */}
      <AnimatePresence>
        {showPdfModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-xl bg-[var(--paper)] rounded-3xl border border-[var(--line)] shadow-2xl relative my-6 max-h-[92vh] flex flex-col overflow-hidden"
            >
              {/* Modal Top Control Bar */}
              <div className="p-4 border-b border-[var(--line)] flex items-center justify-between bg-[var(--bg)] no-print">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[var(--forest)] text-[#F7F4E9] flex items-center justify-center">
                    <FileText className="w-4 h-4 text-amber-300" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-sm text-[var(--ink)]">
                      {isSw ? 'Hati Rasmi ya PDF ya Ratiba' : 'Official Crop Schedule PDF'}
                    </h3>
                    <p className="text-[10px] text-[var(--ink-soft)]">
                      {isSw ? 'Mwonekano na usafirishaji wa faili' : 'Simulated document preview & export'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setShowPdfModal(false)}
                  className="p-1.5 rounded-full text-[var(--ink-soft)] hover:bg-[var(--line)] transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Scrollable Printable PDF Sheet Container */}
              <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-neutral-200/50 dark:bg-neutral-900/50">
                {/* Authentic Document Card (targets print styling) */}
                <div
                  id="printable-crop-schedule"
                  className="bg-white text-[#1E2B21] rounded-2xl p-5 sm:p-7 shadow-lg border border-neutral-300 space-y-4 max-w-lg mx-auto"
                  style={{ fontFamily: "'Work Sans', sans-serif" }}
                >
                  {/* Official Header */}
                  <div className="text-center border-b-2 border-[#2C4A3B] pb-3 space-y-1">
                    <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#2C4A3B] text-amber-300 font-bold mb-1 shadow-sm">
                      <Sprout className="w-5 h-5" />
                    </div>
                    <div className="text-[10px] uppercase tracking-widest font-bold text-[#4E5A4A]">
                      JAMHURI YA MUUNGANO WA TANZANIA
                    </div>
                    <h2 className="font-serif text-lg font-bold text-[#2C4A3B] leading-tight">
                      {isSw ? 'RATIBA RASMI YA MSIMU WA KILIMO 2026' : 'OFFICIAL SEASONAL CROP SCHEDULE 2026'}
                    </h2>
                    <div className="text-[10px] text-[#2C4A3B] font-semibold">
                      ARDHI SMART FARMER COMPANION · WIZARA YA KILIMO & TARI
                    </div>
                  </div>

                  {/* Metadata Box */}
                  <div className="bg-[#F7F5ED] border border-[#D9D3C1] rounded-xl p-3 text-xs grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[#6B776A] block text-[10px]">
                        {isSw ? 'Jina la Mkulima:' : 'Farmer Name:'}
                      </span>
                      <strong className="text-[#1E2B21] font-semibold">{user.name}</strong>
                    </div>
                    <div>
                      <span className="text-[#6B776A] block text-[10px]">
                        {isSw ? 'Mkoa / Wilaya:' : 'Region / District:'}
                      </span>
                      <strong className="text-[#1E2B21] font-semibold">{user.region}</strong>
                    </div>
                    <div>
                      <span className="text-[#6B776A] block text-[10px]">
                        {isSw ? 'Namba ya Simu:' : 'Contact Phone:'}
                      </span>
                      <span className="font-mono text-[#1E2B21]">{user.phone}</span>
                    </div>
                    <div>
                      <span className="text-[#6B776A] block text-[10px]">
                        {isSw ? 'Namba ya Kumbukumbu:' : 'Document Ref:'}
                      </span>
                      <span className="font-mono text-[10px] font-bold text-[#2C4A3B]">
                        ARD-SCHED-2026-7842
                      </span>
                    </div>
                  </div>

                  {/* Schedule Table */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#2C4A3B] text-white text-[10px] uppercase">
                          <th className="p-2 rounded-l-lg">{isSw ? 'Zao' : 'Crop'}</th>
                          <th className="p-2">{isSw ? 'Kupanda' : 'Planting'}</th>
                          <th className="p-2">{isSw ? 'Kuvuna' : 'Harvest'}</th>
                          <th className="p-2 rounded-r-lg">{isSw ? 'Makadirio' : 'Est. Yield'}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-200">
                        {filteredEvents.map((ev) => (
                          <tr key={ev.id} className="hover:bg-neutral-50">
                            <td className="p-2">
                              <div className="font-bold flex items-center gap-1">
                                <span>{ev.icon}</span>
                                <span>{ev.crop}</span>
                              </div>
                              <div className="text-[10px] text-neutral-500">{ev.variety}</div>
                            </td>
                            <td className="p-2 text-[11px]">{isSw ? ev.plantSw : ev.plantEn}</td>
                            <td className="p-2 text-[11px] font-semibold text-[#A15C3E]">
                              {isSw ? ev.harvestSw : ev.harvestEn}
                            </td>
                            <td className="p-2 text-[11px] font-bold text-emerald-800">
                              {isSw ? ev.estYield : ev.estYieldEn}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Verification Seal & Extension Signature */}
                  <div className="pt-3 border-t border-neutral-200 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 rounded-full border-2 border-emerald-700 bg-emerald-50 text-emerald-800 flex flex-col items-center justify-center text-[7px] font-extrabold uppercase text-center leading-tight">
                        <span>TARI</span>
                        <span>CERTIFIED</span>
                      </div>
                      <div className="text-[10px] text-neutral-600">
                        <div className="font-bold text-[#1E2B21]">
                          {isSw ? 'Imethibitishwa Kidijitali' : 'Digitally Certified'}
                        </div>
                        <div>Afisa Kilimo wa Wilaya · ARDHI</div>
                      </div>
                    </div>

                    <div className="text-right text-[10px] text-neutral-500 font-mono">
                      Tarehe: {new Date().toLocaleDateString('sw-TZ', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Modal Bottom Action Bar */}
              <div className="p-4 border-t border-[var(--line)] bg-[var(--paper)] flex flex-col sm:flex-row gap-2 no-print">
                {/* Download PDF file button */}
                <button
                  id="calendar-download-pdf-file-btn"
                  onClick={handleDownloadPdfFile}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>{isSw ? 'Pakua Faili la PDF (.pdf)' : 'Download PDF File (.pdf)'}</span>
                </button>

                {/* Native Print / Save to PDF */}
                <button
                  id="calendar-print-pdf-btn"
                  onClick={handlePrintPdf}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-[var(--bg)] hover:bg-[var(--line)] text-[var(--ink)] border border-[var(--line)] font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4 text-[var(--forest)]" />
                  <span>{isSw ? 'Chapisha / Hifadhi (Print)' : 'Print / Save as PDF'}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// 3. MARKET PRICES VIEW
export function MarketView({
  language,
  user,
  onNavigateToWallet,
  onNavigateToBuyers,
  onNavigateToAggregationPools,
}: ViewsProps) {
  const isSw = language === 'sw';
  const [calculatorKgs, setCalculatorKgs] = useState('1000');
  const [selectedCropPrice, setSelectedCropPrice] = useState(720);
  const [worldCropFilter, setWorldCropFilter] = useState<'all' | 'beverages' | 'spices_nuts' | 'fibers'>('all');
  const [currencyMode, setCurrencyMode] = useState<'both' | 'tsh' | 'usd'>('both');

  // MARKET VIEW PRIMARY SUB-TABS: PRICES & TRENDS vs CHINA & EXPORT MARKETS vs NOTIFICATION HISTORY
  const [marketMainTab, setMarketMainTab] = useState<'prices' | 'export_markets' | 'history'>('prices');

  // NOTIFICATION HISTORY STATE (Previously triggered price thresholds)
  const [alertHistory, setAlertHistory] = useState<MarketAlertHistoryItem[]>(INITIAL_MARKET_ALERT_HISTORY);

  // TARGET PRICE THRESHOLDS STATE
  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>(INITIAL_PRICE_ALERTS);
  const [showThresholdModal, setShowThresholdModal] = useState(false);
  const [showThresholdsPanel, setShowThresholdsPanel] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form states for adding/editing threshold
  const [formCropId, setFormCropId] = useState<string>('mp-1');
  const [formTargetPrice, setFormTargetPrice] = useState<string>('750');
  const [formCondition, setFormCondition] = useState<'gte' | 'lte'>('gte');
  const [formNote, setFormNote] = useState<string>('');

  // Live market price simulation overrides (to test live badge notifications)
  const [priceSimulations, setPriceSimulations] = useState<Record<string, number>>({});

  // List of all crops eligible for target threshold alerts
  const allAlertableCrops = [
    ...MARKET_PRICES.map((mp) => ({
      id: mp.id,
      nameSw: mp.cropNameSw,
      nameEn: mp.cropNameEn,
      unit: mp.unit,
      basePrice: mp.priceValue,
      marketName: mp.marketName,
      isGlobal: false,
    })),
    ...WORLD_CASH_CROPS.map((w) => ({
      id: w.id,
      nameSw: `${w.nameSw} (${w.symbol})`,
      nameEn: `${w.nameEn} (${w.symbol})`,
      unit: w.localUnit,
      basePrice: w.localPriceTsh,
      marketName: w.exchange,
      isGlobal: true,
    })),
  ];

  // Helper: Retrieve effective price considering any user-triggered live simulation
  const getEffectivePrice = (cropId: string, fallbackPrice: number) => {
    if (priceSimulations[cropId] !== undefined) {
      return priceSimulations[cropId];
    }
    return fallbackPrice;
  };

  // Evaluate alerts dynamically against current/simulated prices
  const evaluatedAlerts = priceAlerts.map((alert) => {
    const cropInfo = allAlertableCrops.find((c) => c.id === alert.cropId);
    const currentPrice = cropInfo ? getEffectivePrice(alert.cropId, cropInfo.basePrice) : alert.currentPriceTsh;
    const isHit =
      alert.condition === 'gte'
        ? currentPrice >= alert.targetPriceTsh
        : currentPrice <= alert.targetPriceTsh;
    return {
      ...alert,
      currentPriceTsh: currentPrice,
      isTriggered: isHit,
    };
  });

  const triggeredAlerts = evaluatedAlerts.filter((a) => a.isTriggered);
  const triggeredCount = triggeredAlerts.length;
  const newHistoryCount = alertHistory.filter((h) => h.status === 'new').length;

  const estimatedTotal = (Number(calculatorKgs) || 0) * selectedCropPrice;

  const filteredWorldCrops = WORLD_CASH_CROPS.filter((c) => {
    if (worldCropFilter === 'all') return true;
    if (worldCropFilter === 'beverages') return c.id.includes('coffee') || c.id.includes('tea');
    if (worldCropFilter === 'spices_nuts') return c.id.includes('cloves') || c.id.includes('cashew') || c.id.includes('cocoa');
    if (worldCropFilter === 'fibers') return c.id.includes('cotton') || c.id.includes('tobacco');
    return true;
  });

  // Open modal with preselected crop
  const handleOpenSetAlert = (cropId?: string) => {
    playKeyTap();
    const targetCropId = cropId || 'mp-1';
    const foundCrop = allAlertableCrops.find((c) => c.id === targetCropId);
    setFormCropId(targetCropId);
    if (foundCrop) {
      const effPrice = getEffectivePrice(foundCrop.id, foundCrop.basePrice);
      // Default to suggested target (5% above current price rounded to nearest 10)
      const suggestedTarget = Math.max(10, Math.round((effPrice * 1.05) / 10) * 10);
      setFormTargetPrice(suggestedTarget.toString());
    } else {
      setFormTargetPrice('750');
    }
    setFormCondition('gte');
    setFormNote('');
    setShowThresholdModal(true);
  };

  // Save or update a threshold alert
  const handleSaveThreshold = (e: React.FormEvent) => {
    e.preventDefault();
    const targetNum = Number(formTargetPrice);
    if (!targetNum || targetNum <= 0) return;

    const cropInfo = allAlertableCrops.find((c) => c.id === formCropId);
    if (!cropInfo) return;

    const effPrice = getEffectivePrice(cropInfo.id, cropInfo.basePrice);
    const isHit = formCondition === 'gte' ? effPrice >= targetNum : effPrice <= targetNum;

    const existingIndex = priceAlerts.findIndex((a) => a.cropId === formCropId);
    const newAlert: PriceAlert = {
      id: existingIndex >= 0 ? priceAlerts[existingIndex].id : `alert-${Date.now()}`,
      cropId: cropInfo.id,
      cropNameSw: cropInfo.nameSw,
      cropNameEn: cropInfo.nameEn,
      unit: cropInfo.unit,
      targetPriceTsh: targetNum,
      currentPriceTsh: effPrice,
      condition: formCondition,
      isTriggered: isHit,
      note: formNote.trim() || undefined,
      createdAt: new Date().toLocaleDateString('sw-TZ', { day: 'numeric', month: 'short', year: 'numeric' }),
      triggeredAt: isHit ? (isSw ? 'Leo, Muda Huu' : 'Today, Just Now') : undefined,
    };

    if (existingIndex >= 0) {
      const updated = [...priceAlerts];
      updated[existingIndex] = newAlert;
      setPriceAlerts(updated);
    } else {
      setPriceAlerts([newAlert, ...priceAlerts]);
    }

    // If threshold is already hit at creation, automatically record in Notification History
    if (isHit) {
      const newHistItem: MarketAlertHistoryItem = {
        id: `hist-${Date.now()}`,
        alertId: newAlert.id,
        cropId: cropInfo.id,
        cropNameSw: cropInfo.nameSw,
        cropNameEn: cropInfo.nameEn,
        unit: cropInfo.unit,
        targetPriceTsh: targetNum,
        triggeredPriceTsh: effPrice,
        condition: formCondition,
        marketName: cropInfo.marketName,
        note: formNote.trim() || undefined,
        triggeredAt: isSw ? 'Leo, Muda Huu' : 'Today, Just Now',
        timestamp: Date.now(),
        status: 'new',
        profitDeltaTsh: effPrice - targetNum,
        profitDeltaPercent: Number((((effPrice - targetNum) / targetNum) * 100).toFixed(1)),
      };
      setAlertHistory((prev) => [newHistItem, ...prev]);
    }

    playSuccessChime();
    setShowThresholdModal(false);
    setToastMessage(
      isHit
        ? (isSw
            ? `🎯 Lengo la ${cropInfo.nameSw} (Tsh ${targetNum.toLocaleString()}) limewekwa na tayari soko limefikia Tsh ${effPrice.toLocaleString()}!`
            : `🎯 Target for ${cropInfo.nameEn} (Tsh ${targetNum.toLocaleString()}) set and market already hit Tsh ${effPrice.toLocaleString()}!`)
        : (isSw
            ? `✅ Lengo la Tsh ${targetNum.toLocaleString()}/${cropInfo.unit} kwa ${cropInfo.nameSw} limewekwa kikamilifu.`
            : `✅ Target threshold of Tsh ${targetNum.toLocaleString()}/${cropInfo.unit} set for ${cropInfo.nameEn}.`)
    );
    setTimeout(() => setToastMessage(null), 5000);
  };

  const handleDeleteAlert = (alertId: string) => {
    playKeyTap();
    setPriceAlerts(priceAlerts.filter((a) => a.id !== alertId));
    setToastMessage(isSw ? 'Lengo la bei limefutwa.' : 'Price threshold alert deleted.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSimulatePriceChange = (cropId: string, deltaTsh: number) => {
    playKeyTap();
    const cropInfo = allAlertableCrops.find((c) => c.id === cropId);
    if (!cropInfo) return;
    const currentEff = getEffectivePrice(cropId, cropInfo.basePrice);
    const newPrice = Math.max(50, currentEff + deltaTsh);
    setPriceSimulations((prev) => ({ ...prev, [cropId]: newPrice }));

    const affectedAlert = priceAlerts.find((a) => a.cropId === cropId);
    if (affectedAlert) {
      const willHit = affectedAlert.condition === 'gte' ? newPrice >= affectedAlert.targetPriceTsh : newPrice <= affectedAlert.targetPriceTsh;
      if (willHit) {
        // Automatically append to Notification History
        const newHistItem: MarketAlertHistoryItem = {
          id: `hist-${Date.now()}`,
          alertId: affectedAlert.id,
          cropId: affectedAlert.cropId,
          cropNameSw: affectedAlert.cropNameSw,
          cropNameEn: affectedAlert.cropNameEn,
          unit: affectedAlert.unit,
          targetPriceTsh: affectedAlert.targetPriceTsh,
          triggeredPriceTsh: newPrice,
          condition: affectedAlert.condition,
          marketName: cropInfo.marketName,
          note: affectedAlert.note,
          triggeredAt: isSw ? 'Leo, Muda Huu' : 'Today, Just Now',
          timestamp: Date.now(),
          status: 'new',
          profitDeltaTsh: newPrice - affectedAlert.targetPriceTsh,
          profitDeltaPercent: Number((((newPrice - affectedAlert.targetPriceTsh) / affectedAlert.targetPriceTsh) * 100).toFixed(1)),
        };
        setAlertHistory((prev) => [newHistItem, ...prev]);

        playSuccessChime();
        setToastMessage(
          isSw
            ? `🚨 ARIFA MPYA YA SOKO: Bei ya ${affectedAlert.cropNameSw} imefikia Tsh ${newPrice.toLocaleString()} (Lengo: Tsh ${affectedAlert.targetPriceTsh.toLocaleString()})!`
            : `🚨 MARKET ALERT TRIGGERED: ${affectedAlert.cropNameEn} price reached Tsh ${newPrice.toLocaleString()} (Target: Tsh ${affectedAlert.targetPriceTsh.toLocaleString()})!`
        );
        setTimeout(() => setToastMessage(null), 5000);
      }
    }
  };

  // NOTIFICATION HISTORY HANDLERS
  const handleMarkHistoryStatus = (id: string, newStatus: 'new' | 'reviewed' | 'action_taken') => {
    playKeyTap();
    setAlertHistory((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: newStatus } : item))
    );
    setToastMessage(
      newStatus === 'action_taken'
        ? (isSw ? '✅ Imewekwa alama: Uuzaji umefanyika.' : '✅ Marked as action taken.')
        : newStatus === 'reviewed'
        ? (isSw ? 'Arifa imewekwa kama imehakikiwa.' : 'Alert marked as reviewed.')
        : (isSw ? 'Imerejeshwa kama arifa mpya.' : 'Reverted to new alert.')
    );
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDeleteHistoryItem = (id: string) => {
    playKeyTap();
    setAlertHistory((prev) => prev.filter((item) => item.id !== id));
    setToastMessage(isSw ? 'Arifa imefutwa kwenye historia.' : 'Alert removed from history.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleMarkAllHistoryReviewed = () => {
    playSuccessChime();
    setAlertHistory((prev) => prev.map((item) => ({ ...item, status: 'reviewed' })));
    setToastMessage(isSw ? 'Arifa zote zimewekwa kama zimehakikiwa.' : 'All alerts marked as reviewed.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleClearHistory = () => {
    playKeyTap();
    setAlertHistory([]);
    setToastMessage(isSw ? 'Kumbukumbu zote za arifa zimefutwa.' : 'All notification history cleared.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleRetargetFromHistory = (cropId: string, currentTarget: number) => {
    playKeyTap();
    handleOpenSetAlert(cropId);
    // Suggest 8% higher target price
    const bumped = Math.max(currentTarget + 50, Math.round((currentTarget * 1.08) / 10) * 10);
    setFormTargetPrice(bumped.toString());
  };

  return (
    <div id="dashboard-market-view" className="space-y-4 pb-6">
      {/* Header with Title & Price Alerts Threshold Actions */}
      <div className="pt-2 flex items-start justify-between gap-2">
        <div>
          <h2 className="font-display text-2xl font-bold text-[var(--ink)]">
            {isSw ? 'Bei za Soko & Mwenendo' : 'Market Prices & Trends'}
          </h2>
          <p className="text-xs text-[var(--ink-soft)] mt-0.5">
            {isSw
              ? 'Uchambuzi wa bei za siku 30, malengo ya bei, na historia ya arifa za soko'
              : '30-day price trends, target price thresholds, and market alert history'}
          </p>
        </div>

        {/* Price Alerts Badges & Target Setup Actions */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <button
            id="market-alerts-badge-toggle-btn"
            onClick={() => {
              playKeyTap();
              setShowThresholdsPanel(!showThresholdsPanel);
            }}
            className={`py-1.5 px-2.5 sm:px-3 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
              triggeredCount > 0
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-800 dark:text-emerald-300'
                : 'bg-[var(--paper)] border-[var(--line)] text-[var(--ink)] hover:border-[var(--forest)]'
            }`}
            title={isSw ? 'Arifa za Malengo ya Bei' : 'Price Threshold Alerts'}
          >
            {triggeredCount > 0 ? (
              <BellRing className="w-4 h-4 text-emerald-600 animate-bounce" />
            ) : (
              <Bell className="w-4 h-4 text-[var(--ink-soft)]" />
            )}
            <span className="hidden sm:inline">{isSw ? 'Malengo ya Bei' : 'Price Alerts'}</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                triggeredCount > 0
                  ? 'bg-emerald-600 text-white animate-pulse'
                  : 'bg-[var(--line)] text-[var(--ink-soft)]'
              }`}
            >
              {triggeredCount > 0 ? `${triggeredCount} ${isSw ? 'Zimefikiwa' : 'Hit'}` : evaluatedAlerts.length}
            </span>
          </button>

          <button
            id="market-add-threshold-btn"
            onClick={() => handleOpenSetAlert()}
            className="py-1.5 px-2.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] text-xs font-bold flex items-center gap-1 shadow-sm hover:bg-[var(--forest-dark)] active:scale-95 transition-all cursor-pointer"
            title={isSw ? 'Weka Lengo Jipya la Bei' : 'Set New Price Threshold'}
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">{isSw ? 'Weka Lengo' : 'Set Target'}</span>
          </button>
        </div>
      </div>

      {/* FLOATING TOAST NOTIFICATION */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="p-3 rounded-xl bg-[var(--forest)] text-[#F7F4E9] text-xs font-medium shadow-lg flex items-center justify-between gap-2 border border-emerald-400/30"
          >
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-300 flex-shrink-0" />
              <span>{toastMessage}</span>
            </div>
            <button
              onClick={() => setToastMessage(null)}
              className="p-1 hover:bg-white/10 rounded-lg cursor-pointer flex-shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* UI BADGE NOTIFICATION BANNER: WHEN THRESHOLDS ARE HIT */}
      {triggeredCount > 0 && (
        <div
          id="market-target-hit-banner"
          className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-500/20 via-emerald-600/10 to-amber-500/20 border border-emerald-500/40 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3"
        >
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center flex-shrink-0 shadow-md">
              <Target className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-xs text-[var(--ink)]">
                  {isSw ? '🎯 Hongera! Lengo la Bei Limefikiwa' : '🎯 Target Price Threshold Reached!'}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-600 text-white shadow-xs animate-pulse">
                  {triggeredCount} {isSw ? 'Mazao Yamefikia Lengo' : 'Crops Hit Target'}
                </span>
              </div>
              <p className="text-[11px] text-[var(--ink-soft)] mt-0.5 leading-relaxed">
                {isSw
                  ? `Bei za soko za ${triggeredAlerts.map((a) => a.cropNameSw).join(' na ')} zimefikia au kuvuka viwango ulivyopanga. Ni wakati mzuri wa kuuza!`
                  : `Market prices for ${triggeredAlerts.map((a) => a.cropNameEn).join(' & ')} have reached or exceeded your target threshold. Prime selling window!`
                }
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              id="banner-open-history-btn"
              onClick={() => {
                playKeyTap();
                setMarketMainTab('history');
              }}
              className="py-1.5 px-3 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow-xs hover:bg-emerald-700 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <History className="w-3.5 h-3.5" />
              <span>{isSw ? 'Kagua Historia' : 'Review History'}</span>
            </button>

            <button
              onClick={() => {
                playKeyTap();
                setShowThresholdsPanel(!showThresholdsPanel);
              }}
              className="py-1.5 px-3 rounded-xl bg-[var(--paper)] text-[var(--forest)] border border-[var(--forest)]/30 hover:border-[var(--forest)] text-xs font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>{showThresholdsPanel ? (isSw ? 'Funga Malengo' : 'Close Panel') : (isSw ? 'Tazama Malengo' : 'Manage Targets')}</span>
            </button>
          </div>
        </div>
      )}

      {/* AMCOS EXPORT POOLS QUICK CALLOUT */}
      {onNavigateToAggregationPools && (
        <div
          onClick={() => {
            playKeyTap();
            onNavigateToAggregationPools();
          }}
          className="p-3 rounded-2xl bg-gradient-to-r from-blue-600/15 via-indigo-600/10 to-emerald-600/15 border border-blue-500/30 hover:border-blue-500 flex items-center justify-between gap-2.5 cursor-pointer shadow-xs transition-all group"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center flex-shrink-0">
              <Ship className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-[var(--ink)] flex items-center gap-1.5">
                <span>{isSw ? 'Uuzaji wa Pamoja: Makontena ya Nje (AMCOS Pools)' : 'Collective Export Shipping Pools (AMCOS)'}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 font-bold">
                  {isSw ? '+43% Faida' : '+43% Premium'}
                </span>
              </div>
              <p className="text-[10.5px] text-[var(--ink-soft)]">
                {isSw ? 'Jiunge na kontena la Ufuta au Parachichi na upokee 70% malipo ya papo hapo ghalani.' : 'Pledge crop volume into 20ft/40ft containers for 70% instant depot payment.'}
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-blue-600 group-hover:translate-x-1 transition-transform flex-shrink-0" />
        </div>
      )}

      {/* PRIMARY MARKET VIEW SUB-TABS: LIVE PRICES vs CHINA & EXPORT MARKETS vs NOTIFICATION HISTORY */}
      <div className="flex p-1 bg-[var(--bg)] rounded-2xl border border-[var(--line)] gap-1 shadow-xs">
        <button
          id="market-tab-prices-btn"
          onClick={() => {
            playKeyTap();
            setMarketMainTab('prices');
          }}
          className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            marketMainTab === 'prices'
              ? 'bg-[var(--paper)] text-[var(--forest)] shadow-sm border border-[var(--line)]'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <TrendingUp className="w-4 h-4 flex-shrink-0" />
          <span className="truncate">{isSw ? 'Mwenendo & Bei' : 'Live Prices & Trends'}</span>
        </button>

        <button
          id="market-tab-export-btn"
          onClick={() => {
            playKeyTap();
            setMarketMainTab('export_markets');
          }}
          className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer relative ${
            marketMainTab === 'export_markets'
              ? 'bg-[var(--paper)] text-red-700 dark:text-red-300 shadow-sm border border-red-500/30'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <Globe2 className="w-4 h-4 text-red-600 flex-shrink-0" />
          <span className="truncate">{isSw ? 'Masoko ya China & Nje' : 'China & Global Demand'}</span>
          <span className="hidden xs:inline px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-red-600 text-white shadow-xs">
            🇨🇳 250k T
          </span>
        </button>

        <button
          id="market-tab-history-btn"
          onClick={() => {
            playKeyTap();
            setMarketMainTab('history');
          }}
          className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer relative ${
            marketMainTab === 'history'
              ? 'bg-[var(--paper)] text-[var(--forest)] shadow-sm border border-[var(--line)]'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <History className="w-4 h-4 flex-shrink-0" />
          <span className="truncate">{isSw ? 'Historia' : 'History'}</span>
          {newHistoryCount > 0 ? (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-emerald-600 text-white animate-pulse">
              {newHistoryCount}
            </span>
          ) : (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-semibold bg-[var(--line)] text-[var(--ink-soft)]">
              {alertHistory.length}
            </span>
          )}
        </button>
      </div>

      {/* EXPANDABLE TARGET PRICE THRESHOLDS MANAGER & LIVE SIMULATOR */}
      <AnimatePresence>
        {showThresholdsPanel && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden space-y-3"
          >
            <div className="p-4 rounded-2xl bg-[var(--paper)] border-2 border-[var(--forest)]/30 shadow-md space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[var(--line)]">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-[var(--forest)] text-[#F7F4E9] flex items-center justify-center">
                    <Target className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-xs text-[var(--ink)]">
                      {isSw ? 'Malengo Yako ya Bei za Mazao' : 'Your Target Price Thresholds'}
                    </h3>
                    <p className="text-[10px] text-[var(--ink-soft)]">
                      {isSw
                        ? 'Mfumo hukupa beji na arifa pindi bei inapofikia viwango hivi'
                        : 'Badges and notifications update automatically when market hits your targets'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleOpenSetAlert()}
                    className="py-1 px-2.5 rounded-lg bg-[var(--forest)] text-[#F7F4E9] text-[11px] font-bold flex items-center gap-1 cursor-pointer hover:bg-[var(--forest-dark)]"
                  >
                    <Plus className="w-3 h-3" />
                    <span>{isSw ? 'Weka Lengo' : 'New Target'}</span>
                  </button>
                  <button
                    onClick={() => setShowThresholdsPanel(false)}
                    className="p-1 rounded-lg text-[var(--ink-soft)] hover:bg-[var(--line)] cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Threshold Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {evaluatedAlerts.map((alert) => {
                  const diff = alert.targetPriceTsh - alert.currentPriceTsh;
                  const progress = Math.min(100, Math.round((alert.currentPriceTsh / alert.targetPriceTsh) * 100));

                  return (
                    <div
                      key={alert.id}
                      className={`p-3 rounded-xl border transition-all ${
                        alert.isTriggered
                          ? 'bg-emerald-500/10 border-emerald-500/50 shadow-xs'
                          : 'bg-[var(--bg)] border-[var(--line)]'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-1">
                        <div>
                          <div className="font-bold text-xs text-[var(--ink)]">
                            {isSw ? alert.cropNameSw : alert.cropNameEn}
                          </div>
                          <div className="text-[10px] text-[var(--ink-soft)] mt-0.5">
                            {isSw ? 'Lengo:' : 'Target:'}{' '}
                            <strong className="text-[var(--forest)]">
                              {alert.condition === 'gte' ? '≥' : '≤'} Tsh {alert.targetPriceTsh.toLocaleString()}/{alert.unit}
                            </strong>
                          </div>
                        </div>

                        {/* Badge notification status */}
                        <div className="flex flex-col items-end gap-1">
                          {alert.isTriggered ? (
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-600 text-white flex items-center gap-1 animate-pulse">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>{isSw ? 'LIMEFIKIWA' : 'TARGET HIT'}</span>
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-medium bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-500/30 flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
                              <span>{isSw ? 'INAFUATILIWA' : 'MONITORING'}</span>
                            </span>
                          )}

                          <button
                            onClick={() => handleDeleteAlert(alert.id)}
                            className="text-neutral-400 hover:text-red-500 p-0.5 rounded cursor-pointer transition-colors"
                            title={isSw ? 'Futa lengo hili' : 'Delete threshold'}
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Current Price vs Target Bar */}
                      <div className="mt-2 pt-2 border-t border-[var(--line)] text-[10px]">
                        <div className="flex items-center justify-between text-[10px] mb-1">
                          <span className="text-[var(--ink-soft)]">
                            {isSw ? 'Bei ya Sasa:' : 'Current Price:'}{' '}
                            <strong className={alert.isTriggered ? 'text-emerald-700 dark:text-emerald-300 font-bold' : 'text-[var(--ink)]'}>
                              Tsh {alert.currentPriceTsh.toLocaleString()}/{alert.unit}
                            </strong>
                          </span>
                          <span className="font-semibold text-[var(--forest)]">{progress}%</span>
                        </div>

                        {/* Visual Progress Bar */}
                        <div className="w-full h-1.5 rounded-full bg-neutral-200 dark:bg-neutral-800 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              alert.isTriggered ? 'bg-emerald-500' : 'bg-amber-500'
                            }`}
                            style={{ width: `${progress}%` }}
                          />
                        </div>

                        {/* Note & Timing */}
                        <div className="mt-1.5 flex items-center justify-between text-[9px] text-[var(--ink-soft)]">
                          <span>
                            {alert.isTriggered
                              ? (isSw ? `🎉 Limefikiwa (${alert.triggeredAt || 'Leo'})` : `🎉 Reached (${alert.triggeredAt || 'Today'})`)
                              : (isSw ? `Bado Tsh ${Math.max(0, diff).toLocaleString()} kufikia lengo` : `Tsh ${Math.max(0, diff).toLocaleString()} to target`)
                            }
                          </span>
                          {alert.note && <span className="italic truncate max-w-[130px]">"{alert.note}"</span>}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* LIVE MARKET PRICE SIMULATOR (Tactile test for farmers) */}
              <div className="mt-2 p-3 rounded-xl bg-[var(--bg)] border border-[var(--line)] space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[var(--ink)]">
                    <Sliders className="w-3.5 h-3.5 text-[var(--soil)]" />
                    <span>{isSw ? 'Jaribu Mabadiliko ya Bei (Live Simulator)' : 'Test Market Price Fluctuation (Simulator)'}</span>
                  </div>
                  <span className="text-[10px] text-[var(--ink-soft)]">
                    {isSw ? 'Jaribu kubadilisha bei kuona beji ikijitokeza live' : 'Simulate price moves to trigger badge alerts'}
                  </span>
                </div>

                <div className="flex flex-wrap gap-2 text-xs">
                  {/* Mahindi simulation quick buttons */}
                  <div className="flex items-center gap-1 bg-[var(--paper)] p-1.5 rounded-lg border border-[var(--line)]">
                    <span className="text-[10px] font-semibold text-[var(--ink)]">🌽 Mahindi:</span>
                    <button
                      onClick={() => handleSimulatePriceChange('mp-1', -40)}
                      className="px-2 py-0.5 rounded bg-red-100 dark:bg-red-950/40 text-red-700 dark:text-red-300 text-[10px] font-bold hover:bg-red-200 cursor-pointer"
                    >
                      -40 Tsh
                    </button>
                    <button
                      onClick={() => handleSimulatePriceChange('mp-1', 40)}
                      className="px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold hover:bg-emerald-200 cursor-pointer"
                    >
                      +40 Tsh
                    </button>
                  </div>

                  {/* Cashew simulation quick buttons */}
                  <div className="flex items-center gap-1 bg-[var(--paper)] p-1.5 rounded-lg border border-[var(--line)]">
                    <span className="text-[10px] font-semibold text-[var(--ink)]">🥜 Korosho:</span>
                    <button
                      onClick={() => handleSimulatePriceChange('mp-3', -150)}
                      className="px-2 py-0.5 rounded bg-red-100 dark:bg-red-950/40 text-red-700 dark:text-red-300 text-[10px] font-bold hover:bg-red-200 cursor-pointer"
                    >
                      -150 Tsh
                    </button>
                    <button
                      onClick={() => handleSimulatePriceChange('mp-3', 200)}
                      className="px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold hover:bg-emerald-200 cursor-pointer"
                    >
                      +200 Tsh (Trigger)
                    </button>
                  </div>

                  {/* Rice simulation quick buttons */}
                  <div className="flex items-center gap-1 bg-[var(--paper)] p-1.5 rounded-lg border border-[var(--line)]">
                    <span className="text-[10px] font-semibold text-[var(--ink)]">🍚 Mpunga:</span>
                    <button
                      onClick={() => handleSimulatePriceChange('mp-2', 150)}
                      className="px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold hover:bg-emerald-200 cursor-pointer"
                    >
                      +150 Tsh (Hit 1,300)
                    </button>
                  </div>

                  {/* Reset all simulations */}
                  {Object.keys(priceSimulations).length > 0 && (
                    <button
                      onClick={() => {
                        playKeyTap();
                        setPriceSimulations({});
                      }}
                      className="px-2 py-1 rounded-lg text-[10px] text-[var(--ink-soft)] hover:text-[var(--ink)] border border-dashed border-[var(--line)] cursor-pointer"
                    >
                      {isSw ? 'Rejesha Bei Asilia' : 'Reset Original'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {marketMainTab === 'prices' ? (
        <div className="space-y-4">
          {/* PROMOTION TEASER PILL */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/15 via-[var(--forest)]/15 to-amber-500/15 border border-amber-500/30 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <span className="text-xl">🚗</span>
          <div>
            <div className="font-bold text-[var(--ink)] flex items-center gap-1">
              <span>{isSw ? 'Ofa ya Range Rover & Dubai 2026' : 'Win Range Rover & Dubai Trip'}</span>
              <span className="text-[10px] bg-amber-400 text-black px-1.5 py-0.2 rounded font-bold">HOT</span>
            </div>
            <div className="text-[11px] text-[var(--ink-soft)]">
              {isSw
                ? 'Agiza pembejeo au fanya miamala ya pochi ujishindie!'
                : 'Order farm inputs or transfer via wallet to enter!'}
            </div>
          </div>
        </div>
        {onNavigateToWallet && (
          <button
            onClick={onNavigateToWallet}
            className="py-1 px-2.5 rounded-lg bg-[var(--forest)] text-[#F7F4E9] font-bold text-[10px] flex-shrink-0 cursor-pointer shadow-sm hover:opacity-95"
          >
            {isSw ? 'Shiriki Sasa' : 'Enter Now'}
          </button>
        )}
      </div>

      {/* FX Exchange Rates Bar */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { pair: 'USD/TZS', rate: '2,570', delta: '+0.4%' },
          { pair: 'EUR/TZS', rate: '2,795', delta: '+0.2%' },
          { pair: 'KES/TZS', rate: '19.85', delta: '-0.1%' },
        ].map((fx) => (
          <div
            key={fx.pair}
            className="p-2.5 rounded-xl bg-[var(--forest-dark)] text-[#F7F4E9] text-center shadow-sm"
          >
            <div className="text-[10px] opacity-75">{fx.pair}</div>
            <div className="font-display font-bold text-sm text-amber-200 mt-0.5">{fx.rate}</div>
          </div>
        ))}
      </div>

      {/* 1. RECHARTS 30-DAY PRICE TREND COMPONENT */}
      <CropPriceTrendChart language={language} />

      {/* 2. WORLD MARKET CASH CROPS SECTION */}
      <div className="space-y-3">
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-700 dark:text-amber-300 flex items-center justify-center">
                <Globe2 className="w-4 h-4" />
              </div>
              <h3 className="font-bold text-xs uppercase tracking-wider text-[var(--ink)]">
                {isSw ? 'Mazao ya Biashara Soko la Dunia' : 'World Market Cash Crops'}
              </h3>
            </div>

            {/* Currency Mode Toggle */}
            <div className="flex bg-[var(--bg)] p-0.5 rounded-lg border border-[var(--line)] text-[10px]">
              <button
                onClick={() => setCurrencyMode('both')}
                className={`px-2 py-0.5 rounded font-semibold ${
                  currencyMode === 'both'
                    ? 'bg-[var(--paper)] text-[var(--forest)] shadow-xs'
                    : 'text-[var(--ink-soft)]'
                }`}
              >
                TZS / USD
              </button>
              <button
                onClick={() => setCurrencyMode('tsh')}
                className={`px-2 py-0.5 rounded font-semibold ${
                  currencyMode === 'tsh'
                    ? 'bg-[var(--paper)] text-[var(--forest)] shadow-xs'
                    : 'text-[var(--ink-soft)]'
                }`}
              >
                TZS
              </button>
            </div>
          </div>

          <p className="text-[11px] text-[var(--ink-soft)]">
            {isSw
              ? 'Bei rasmi za soko la hisa na minada ya kimataifa (ICE New York, London LIFFE, Mombasa, Zanzibar)'
              : 'Live international benchmark commodity exchanges and export auctions'}
          </p>

          {/* Category Filter Pills */}
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            {[
              { id: 'all', sw: 'Yote (All)', en: 'All' },
              { id: 'beverages', sw: 'Kahawa & Chai', en: 'Coffee & Tea' },
              { id: 'spices_nuts', sw: 'Kakao, Korosho & Karafuu', en: 'Cocoa, Cashew & Cloves' },
              { id: 'fibers', sw: 'Pamba & Tumbaku', en: 'Cotton & Tobacco' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  playKeyTap();
                  setWorldCropFilter(tab.id as any);
                }}
                className={`px-2.5 py-1 rounded-xl text-[10px] font-semibold flex-shrink-0 transition-all cursor-pointer border ${
                  worldCropFilter === tab.id
                    ? 'bg-[var(--forest)] text-[#F7F4E9] border-[var(--forest)] shadow-xs'
                    : 'bg-[var(--bg)] text-[var(--ink-soft)] border-[var(--line)] hover:text-[var(--ink)]'
                }`}
              >
                {isSw ? tab.sw : tab.en}
              </button>
            ))}
          </div>
        </div>

        {/* Global Cash Crops Grid */}
        <div className="space-y-2.5">
          {filteredWorldCrops.map((crop) => {
            const cropAlert = evaluatedAlerts.find((a) => a.cropId === crop.id);
            const currentEffectivePrice = getEffectivePrice(crop.id, crop.localPriceTsh);

            return (
              <div
                key={crop.id}
                className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] shadow-sm hover:border-[var(--forest)]/40 transition-all space-y-2"
              >
                {/* Top Row: Crop Name, Badges & Delta */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-xs text-[var(--ink)]">
                        {isSw ? crop.nameSw : crop.nameEn}
                      </span>

                      {/* TARGET PRICE BADGE ON WORLD CROP */}
                      {cropAlert && (
                        cropAlert.isTriggered ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-600 text-white shadow-xs animate-pulse">
                            <Target className="w-2.5 h-2.5" />
                            <span>{isSw ? `Lengo Limefikiwa (≥ Tsh ${cropAlert.targetPriceTsh.toLocaleString()})` : `Target Hit (≥ Tsh ${cropAlert.targetPriceTsh.toLocaleString()})`}</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-medium bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-500/30">
                            <Target className="w-2.5 h-2.5 text-amber-600" />
                            <span>{isSw ? `Lengo: Tsh ${cropAlert.targetPriceTsh.toLocaleString()}` : `Target: Tsh ${cropAlert.targetPriceTsh.toLocaleString()}`}</span>
                          </span>
                        )
                      )}
                    </div>
                    <div className="text-[10px] text-[var(--ink-soft)] flex items-center gap-1 mt-0.5">
                      <span className="font-mono font-semibold text-amber-600 dark:text-amber-400">
                        {crop.symbol}
                      </span>
                      <span>•</span>
                      <span className="truncate">{crop.exchange}</span>
                    </div>
                  </div>

                  {/* Price Display & Quick Target Action */}
                  <div className="text-right flex-shrink-0">
                    <div className="flex items-center justify-end gap-1.5">
                      <div className="font-display font-bold text-sm text-[var(--forest)]">
                        {currencyMode !== 'usd' && (
                          <span>Tsh {currentEffectivePrice.toLocaleString()}/{crop.localUnit}</span>
                        )}
                        {currencyMode === 'usd' && (
                          <span>${crop.globalPriceUsd} USD/{crop.globalUnit.split(' ')[0]}</span>
                        )}
                      </div>
                      <button
                        onClick={() => handleOpenSetAlert(crop.id)}
                        className="p-1 rounded-lg hover:bg-[var(--line)] text-[var(--ink-soft)] hover:text-[var(--forest)] transition-colors cursor-pointer"
                        title={isSw ? 'Weka lengo la bei' : 'Set target price'}
                      >
                        <Target className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {currencyMode === 'both' && (
                      <div className="text-[10px] text-amber-600 dark:text-amber-400 font-mono font-medium">
                        ≈ ${crop.globalPriceUsd} USD ({crop.globalUnit})
                      </div>
                    )}
                    <div
                      className={`text-[10px] font-bold flex items-center justify-end gap-0.5 mt-0.5 ${
                        crop.isUp ? 'text-[var(--up)]' : 'text-[var(--down)]'
                      }`}
                    >
                      {crop.isUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                      <span>
                        {crop.isUp ? '+' : ''}
                        {crop.changePercent}% {isSw ? '(Mwezi 1)' : '(30d)'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Bottom Tags: Demand Barometer & Producing Regions */}
                <div className="pt-2 border-t border-[var(--line)] flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[10px]">
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    <span className="font-medium text-emerald-700 dark:text-emerald-300">
                      {isSw ? crop.demandStatusSw : crop.demandStatusEn}
                    </span>
                  </div>
                  <div className="text-[var(--ink-soft)] truncate">
                    📍 {isSw ? crop.producingRegionsSw : crop.producingRegionsEn}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. MAJOR DOMESTIC MARKETS LIST WITH THRESHOLD BADGES */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--ink-soft)]">
            {isSw ? 'Masoko ya Ndani (Tanzania)' : 'Domestic Grain & Produce Markets'}
          </h3>
          <span className="text-[10px] text-[var(--ink-soft)]">
            {isSw ? 'Gusa lengo kuweka arifa' : 'Tap target to set alert'}
          </span>
        </div>

        <div className="space-y-2 bg-[var(--paper)] rounded-2xl border border-[var(--line)] p-3 divide-y divide-[var(--line)]">
          {MARKET_PRICES.map((p) => {
            const cropAlert = evaluatedAlerts.find((a) => a.cropId === p.id);
            const currentEffectivePrice = getEffectivePrice(p.id, p.priceValue);

            return (
              <div key={p.id} className="pt-2.5 first:pt-0 pb-2.5 last:pb-0 flex items-center justify-between gap-2">
                <div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-bold text-xs text-[var(--ink)]">
                      {isSw ? p.cropNameSw : p.cropNameEn}
                    </span>

                    {/* UI BADGE NOTIFICATION FOR SPECIFIC CROP */}
                    {cropAlert && (
                      cropAlert.isTriggered ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-600 text-white shadow-xs animate-pulse">
                          <Target className="w-2.5 h-2.5" />
                          <span>{isSw ? `Lengo Limefikiwa (≥ Tsh ${cropAlert.targetPriceTsh.toLocaleString()})` : `Target Hit (≥ Tsh ${cropAlert.targetPriceTsh.toLocaleString()})`}</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-medium bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-500/30">
                          <Target className="w-2.5 h-2.5 text-amber-600" />
                          <span>{isSw ? `Lengo: Tsh ${cropAlert.targetPriceTsh.toLocaleString()}` : `Target: Tsh ${cropAlert.targetPriceTsh.toLocaleString()}`}</span>
                        </span>
                      )
                    )}
                  </div>
                  <div className="text-[10px] text-[var(--ink-soft)] flex items-center gap-1 mt-0.5">
                    <MapPin className="w-2.5 h-2.5" />
                    <span>{p.marketName}</span>
                  </div>
                </div>

                <div className="text-right flex items-center gap-2 flex-shrink-0">
                  <div>
                    <div className="font-display font-bold text-sm text-[var(--forest)]">
                      {p.isGlobal
                        ? p.priceDisplay
                        : `Tsh ${currentEffectivePrice.toLocaleString()}/${p.unit}`}
                    </div>
                    <div
                      className={`text-[10px] font-semibold flex items-center justify-end gap-0.5 ${
                        p.isUp ? 'text-[var(--up)]' : 'text-[var(--down)]'
                      }`}
                    >
                      {p.isUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                      <span>
                        {p.isUp ? '+' : '-'}
                        {p.deltaPercent}% {isSw ? p.timeframeSw : p.timeframeEn}
                      </span>
                    </div>
                  </div>

                  {/* Quick button to set or update target price */}
                  <button
                    onClick={() => handleOpenSetAlert(p.id)}
                    className="p-1.5 rounded-lg border border-[var(--line)] hover:border-[var(--forest)] text-[var(--ink-soft)] hover:text-[var(--forest)] hover:bg-[var(--bg)] transition-colors cursor-pointer"
                    title={isSw ? 'Weka au badili lengo la bei' : 'Set or edit price target threshold'}
                  >
                    <Target className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. HARVEST REVENUE CALCULATOR */}
      <div className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] shadow-sm">
        <div className="flex items-center gap-2 mb-2 font-bold text-xs text-[var(--ink)]">
          <Calculator className="w-4 h-4 text-[var(--soil)]" />
          <span>{isSw ? 'Kikokotoo cha Mapato ya Shambani' : 'Harvest Revenue Calculator'}</span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <label className="text-[10px] text-[var(--ink-soft)] block mb-1">
              {isSw ? 'Chagua Zao' : 'Select Crop'}
            </label>
            <select
              value={selectedCropPrice}
              onChange={(e) => setSelectedCropPrice(Number(e.target.value))}
              className="w-full p-2 text-xs rounded-xl bg-[var(--bg)] border border-[var(--line)]"
            >
              <option value={780}>{isSw ? 'Mahindi (Tsh 780/kg)' : 'Maize (Tsh 780/kg)'}</option>
              <option value={1250}>{isSw ? 'Mpunga Saro (Tsh 1,250/kg)' : 'Rice (Tsh 1,250/kg)'}</option>
              <option value={3650}>{isSw ? 'Korosho Ghafi (Tsh 3,650/kg)' : 'Cashew (Tsh 3,650/kg)'}</option>
              <option value={13820}>{isSw ? 'Kahawa Arabica (Tsh 13,820/kg)' : 'Arabica Coffee (Tsh 13,820/kg)'}</option>
              <option value={20200}>{isSw ? 'Kakao Bora (Tsh 20,200/kg)' : 'Cocoa (Tsh 20,200/kg)'}</option>
            </select>
          </div>
          <div>
            <label className="text-[10px] text-[var(--ink-soft)] block mb-1">
              {isSw ? 'Kiasi (Kilo)' : 'Volume (Kg)'}
            </label>
            <input
              type="number"
              value={calculatorKgs}
              onChange={(e) => setCalculatorKgs(e.target.value)}
              className="w-full p-2 text-xs rounded-xl bg-[var(--bg)] border border-[var(--line)] font-semibold"
            />
          </div>
        </div>
        <div className="mt-3 p-2.5 rounded-xl bg-[var(--bg)] flex items-center justify-between">
          <span className="text-[11px] text-[var(--ink-soft)]">{isSw ? 'Makadirio ya Mauzo:' : 'Estimated Total:'}</span>
          <span className="font-display text-base font-bold text-[var(--forest)]">
            Tsh {estimatedTotal.toLocaleString()}
          </span>
        </div>
      </div>
        </div>
      ) : marketMainTab === 'export_markets' ? (
        <ExportMarketsTab
          language={language}
          onNavigateToBuyers={onNavigateToBuyers}
          onSetAlertForCrop={handleOpenSetAlert}
        />
      ) : (
        <NotificationHistoryTab
          language={language}
          history={alertHistory}
          onMarkStatus={handleMarkHistoryStatus}
          onDeleteHistoryItem={handleDeleteHistoryItem}
          onMarkAllReviewed={handleMarkAllHistoryReviewed}
          onClearHistory={handleClearHistory}
          onRetarget={handleRetargetFromHistory}
          onNavigateToBuyers={onNavigateToBuyers}
        />
      )}

      {/* MODAL: SET TARGET PRICE THRESHOLD */}
      <AnimatePresence>
        {showThresholdModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-[var(--paper)] border border-[var(--line)] rounded-2xl w-full max-w-md shadow-2xl overflow-hidden"
            >
              {/* Modal Header */}
              <div className="p-4 border-b border-[var(--line)] flex items-center justify-between bg-gradient-to-r from-[var(--forest)]/10 to-transparent">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[var(--forest)] text-[#F7F4E9] flex items-center justify-center">
                    <Target className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-sm text-[var(--ink)]">
                      {isSw ? 'Weka Lengo la Bei ya Soko' : 'Set Target Price Threshold'}
                    </h3>
                    <p className="text-[10px] text-[var(--ink-soft)]">
                      {isSw ? 'Pata arifa na beji bei ikifikia kiwango unachotaka' : 'Get notified with badges when market reaches your target'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowThresholdModal(false)}
                  className="p-1 rounded-lg text-[var(--ink-soft)] hover:bg-[var(--line)] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Form */}
              <form onSubmit={handleSaveThreshold} className="p-4 space-y-3.5 text-xs">
                {/* Crop Selection */}
                <div>
                  <label className="text-[11px] font-bold text-[var(--ink)] block mb-1">
                    {isSw ? 'Chagua Zao & Soko' : 'Select Crop & Market'}
                  </label>
                  <select
                    value={formCropId}
                    onChange={(e) => {
                      const selectedId = e.target.value;
                      setFormCropId(selectedId);
                      const crop = allAlertableCrops.find((c) => c.id === selectedId);
                      if (crop) {
                        const eff = getEffectivePrice(crop.id, crop.basePrice);
                        setFormTargetPrice(Math.round((eff * 1.05) / 10 * 10).toString());
                      }
                    }}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink)] font-semibold"
                  >
                    {allAlertableCrops.map((c) => {
                      const eff = getEffectivePrice(c.id, c.basePrice);
                      return (
                        <option key={c.id} value={c.id}>
                          {isSw ? c.nameSw : c.nameEn} — Tsh {eff.toLocaleString()}/{c.unit} ({c.marketName})
                        </option>
                      );
                    })}
                  </select>
                </div>

                {/* Condition Selection */}
                <div>
                  <label className="text-[11px] font-bold text-[var(--ink)] block mb-1">
                    {isSw ? 'Masharti ya Arifa' : 'Alert Condition'}
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setFormCondition('gte')}
                      className={`p-2 rounded-xl border text-left flex items-center gap-2 cursor-pointer transition-all ${
                        formCondition === 'gte'
                          ? 'bg-[var(--forest)] text-[#F7F4E9] border-[var(--forest)] font-bold shadow-xs'
                          : 'bg-[var(--bg)] text-[var(--ink-soft)] border-[var(--line)] hover:text-[var(--ink)]'
                      }`}
                    >
                      <TrendingUp className="w-4 h-4" />
                      <div>
                        <div className="text-[11px] leading-tight">{isSw ? '≥ Ikifikia au Kuzidi' : '≥ Reaches or Exceeds'}</div>
                        <div className="text-[9px] opacity-80">{isSw ? '(Wakati wa Kuuza)' : '(Best to Sell)'}</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setFormCondition('lte')}
                      className={`p-2 rounded-xl border text-left flex items-center gap-2 cursor-pointer transition-all ${
                        formCondition === 'lte'
                          ? 'bg-[var(--forest)] text-[#F7F4E9] border-[var(--forest)] font-bold shadow-xs'
                          : 'bg-[var(--bg)] text-[var(--ink-soft)] border-[var(--line)] hover:text-[var(--ink)]'
                      }`}
                    >
                      <TrendingDown className="w-4 h-4" />
                      <div>
                        <div className="text-[11px] leading-tight">{isSw ? '≤ Ikishuka Hadi' : '≤ Drops Below'}</div>
                        <div className="text-[9px] opacity-80">{isSw ? '(Wakati wa Kununua)' : '(Best to Buy)'}</div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Target Price Input with Quick Percent Helpers */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-bold text-[var(--ink)]">
                      {isSw ? 'Kiwango cha Bei (Tsh)' : 'Target Threshold Price (Tsh)'}
                    </label>
                    {(() => {
                      const c = allAlertableCrops.find((cr) => cr.id === formCropId);
                      const currentEff = c ? getEffectivePrice(c.id, c.basePrice) : 0;
                      return (
                        <span className="text-[10px] text-[var(--ink-soft)]">
                          {isSw ? 'Bei ya sasa:' : 'Current:'}{' '}
                          <strong className="text-[var(--forest)]">Tsh {currentEff.toLocaleString()}</strong>
                        </span>
                      );
                    })()}
                  </div>

                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-[var(--ink-soft)] font-bold text-xs">Tsh</span>
                    <input
                      type="number"
                      required
                      min="1"
                      value={formTargetPrice}
                      onChange={(e) => setFormTargetPrice(e.target.value)}
                      className="w-full pl-12 pr-14 py-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] font-bold text-sm text-[var(--ink)]"
                      placeholder="e.g. 750"
                    />
                    <span className="absolute right-3 top-2.5 text-[var(--ink-soft)] text-xs font-semibold">
                      /{allAlertableCrops.find((c) => c.id === formCropId)?.unit || 'kg'}
                    </span>
                  </div>

                  {/* Quick Helper Increment Pills */}
                  <div className="flex gap-1.5 mt-2 flex-wrap">
                    {[
                      { label: '+5%', mult: 1.05 },
                      { label: '+10%', mult: 1.10 },
                      { label: '+15%', mult: 1.15 },
                      { label: '+20%', mult: 1.20 },
                      { label: '+50 Tsh', add: 50 },
                      { label: '+100 Tsh', add: 100 },
                    ].map((helper, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          playKeyTap();
                          const c = allAlertableCrops.find((cr) => cr.id === formCropId);
                          const base = c ? getEffectivePrice(c.id, c.basePrice) : 700;
                          const calculated = helper.mult ? Math.round((base * helper.mult) / 10) * 10 : base + (helper.add || 0);
                          setFormTargetPrice(calculated.toString());
                        }}
                        className="px-2 py-0.5 rounded-lg bg-[var(--bg)] hover:bg-[var(--line)] text-[10px] font-semibold text-[var(--forest)] border border-[var(--line)] cursor-pointer"
                      >
                        {helper.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Optional Note */}
                <div>
                  <label className="text-[11px] font-bold text-[var(--ink)] block mb-1">
                    {isSw ? 'Kumbukumbu / Dokezo (Hiari)' : 'Action Note (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={formNote}
                    onChange={(e) => setFormNote(e.target.value)}
                    placeholder={isSw ? 'mf. Uza magunia 40 ya shamba la kaskazini' : 'e.g. Sell 40 bags from north plot'}
                    className="w-full p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink)]"
                  />
                </div>

                {/* Actions */}
                <div className="pt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowThresholdModal(false)}
                    className="flex-1 py-2.5 rounded-xl border border-[var(--line)] text-[var(--ink)] font-bold text-xs hover:bg-[var(--bg)] cursor-pointer"
                  >
                    {isSw ? 'Ghairi' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] font-bold text-xs hover:bg-[var(--forest-dark)] shadow-md active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    <span>{isSw ? 'Thibitisha Lengo' : 'Save Threshold'}</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// 4. BUYERS VIEW
export function BuyersView({ language }: ViewsProps) {
  const isSw = language === 'sw';
  const [contactedBuyer, setContactedBuyer] = useState<string | null>(null);
  const [buyerFilter, setBuyerFilter] = useState<'all' | 'china' | 'domestic'>('all');
  const [searchBuyerQuery, setSearchBuyerQuery] = useState('');

  const filteredBuyers = BUYERS_LIST.filter((buyer) => {
    if (buyerFilter === 'china' && !buyer.id.startsWith('b-cn')) return false;
    if (buyerFilter === 'domestic' && buyer.id.startsWith('b-cn')) return false;

    if (searchBuyerQuery.trim()) {
      const q = searchBuyerQuery.toLowerCase();
      const matchName = buyer.name.toLowerCase().includes(q);
      const matchCrop = buyer.cropSw.toLowerCase().includes(q) || buyer.cropEn.toLowerCase().includes(q);
      const matchLoc = buyer.location.toLowerCase().includes(q);
      if (!matchName && !matchCrop && !matchLoc) return false;
    }
    return true;
  });

  return (
    <div id="dashboard-buyers-view" className="space-y-4 pb-6">
      <div className="pt-2 flex items-start justify-between flex-wrap gap-2">
        <div>
          <h2 className="font-display text-2xl font-bold text-[var(--ink)]">
            {isSw ? 'Wanunuzi & Masoko ya Nje' : 'Buyers & Export Markets'}
          </h2>
          <p className="text-xs text-[var(--ink-soft)] mt-0.5">
            {isSw
              ? 'Ungana na wanunuzi wa China, masoko ya kimataifa, na viwanda vya ndani'
              : 'Connect with verified Chinese importers, international markets, and domestic plants'}
          </p>
        </div>

        {/* Total stats pill */}
        <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-500/30">
          {filteredBuyers.length} {isSw ? 'Wanunuzi Walioidhinishwa' : 'Verified Buyers'}
        </span>
      </div>

      {/* Search & Category Tabs */}
      <div className="space-y-2">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-[var(--ink-soft)] absolute left-3 top-3 pointer-events-none" />
          <input
            type="text"
            value={searchBuyerQuery}
            onChange={(e) => setSearchBuyerQuery(e.target.value)}
            placeholder={
              isSw
                ? 'Tafuta mnunuzi, zao (mf. Ufuta, Soya, Muhogo, Parachichi, Korosho)...'
                : 'Search buyer, crop (e.g. Sesame, Soybeans, Cassava, Avocado)...'
            }
            className="w-full pl-9 pr-8 py-2 rounded-xl bg-[var(--paper)] border border-[var(--line)] text-xs text-[var(--ink)] placeholder:text-[var(--ink-soft)] focus:outline-none focus:border-[var(--forest)] shadow-xs"
          />
          {searchBuyerQuery && (
            <button
              onClick={() => setSearchBuyerQuery('')}
              className="absolute right-2.5 top-2.5 text-[var(--ink-soft)] hover:text-[var(--ink)] p-0.5 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Pills */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {[
            { id: 'all', sw: 'Wanunuzi Wote', en: 'All Buyers' },
            { id: 'china', sw: '🇨🇳 Masoko ya China & Nje (Bilateral)', en: '🇨🇳 China & Global Importers' },
            { id: 'domestic', sw: '🇹🇿 Viwanda vya Ndani (Tanzania)', en: '🇹🇿 Domestic Processors' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                playKeyTap();
                setBuyerFilter(tab.id as 'all' | 'china' | 'domestic');
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex-shrink-0 transition-all cursor-pointer border ${
                buyerFilter === tab.id
                  ? 'bg-[var(--forest)] text-[#F7F4E9] border-[var(--forest)] shadow-xs'
                  : 'bg-[var(--paper)] text-[var(--ink-soft)] border-[var(--line)] hover:text-[var(--ink)]'
              }`}
            >
              {isSw ? tab.sw : tab.en}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {filteredBuyers.length === 0 ? (
          <div className="p-8 text-center bg-[var(--paper)] rounded-2xl border border-[var(--line)] text-xs text-[var(--ink-soft)]">
            {isSw ? 'Hakuna mnunuzi aliyelingana na utafutaji wako.' : 'No buyers found for this search.'}
          </div>
        ) : (
          filteredBuyers.map((buyer) => {
            const isChinaMarket = buyer.id.startsWith('b-cn');

            return (
              <div
                key={buyer.id}
                className={`p-4 rounded-2xl bg-[var(--paper)] border shadow-sm space-y-3 transition-all ${
                  isChinaMarket
                    ? 'border-red-500/40 hover:border-red-500'
                    : 'border-[var(--line)] hover:border-[var(--forest)]/50'
                }`}
              >
                <div className="flex items-start justify-between flex-wrap gap-2">
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {isChinaMarket && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-600/15 text-red-700 dark:text-red-300 border border-red-500/20">
                          🇨🇳 Soko la China
                        </span>
                      )}
                      <h4 className="font-bold text-sm text-[var(--ink)]">{buyer.name}</h4>
                    </div>
                    <div className="text-[11px] text-[var(--ink-soft)] mt-0.5">
                      {isSw ? buyer.typeSw : buyer.typeEn} · 📍 {buyer.location}
                    </div>
                  </div>

                  <span className="flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[var(--gold-soft)] text-[var(--forest)] border border-[var(--forest)]/20">
                    <ShieldCheck className="w-3 h-3 text-[var(--forest)]" />
                    <span>{isSw ? 'Malipo Salama ya Escrow/LC' : 'Secure Escrow/LC'}</span>
                  </span>
                </div>

                <div className="p-2.5 rounded-xl bg-[var(--bg)] text-xs space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-[var(--ink-soft)]">{isSw ? 'Zao Linalohitajika:' : 'Required Crop:'}</span>
                    <span className="font-bold text-[var(--ink)]">{isSw ? buyer.cropSw : buyer.cropEn}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[var(--ink-soft)]">{isSw ? 'Bei ya Ofa:' : 'Offer Price:'}</span>
                    <span className="font-display font-bold text-base text-[var(--forest)]">{buyer.offerPrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[var(--ink-soft)]">{isSw ? 'Kiwango cha Chini:' : 'Minimum Volume:'}</span>
                    <span className="font-semibold text-amber-700 dark:text-amber-300">{buyer.minVolume}</span>
                  </div>
                  {buyer.requirements && (
                    <div className="pt-1 border-t border-[var(--line)] text-[10px] text-[var(--ink-soft)]">
                      <span className="font-semibold text-[var(--ink)]">{isSw ? 'Vigezo:' : 'Specs:'} </span>
                      {buyer.requirements}
                    </div>
                  )}
                </div>

                <button
                  onClick={() => {
                    playSuccessChime();
                    setContactedBuyer(buyer.name);
                    setTimeout(() => setContactedBuyer(null), 5000);
                  }}
                  className={`w-full py-2.5 rounded-xl font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs ${
                    isChinaMarket
                      ? 'bg-red-700 hover:bg-red-800 text-white'
                      : 'bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9]'
                  }`}
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>
                    {contactedBuyer === buyer.name
                      ? (isSw ? `Simu imefunguliwa: ${buyer.contactPhone}` : `Dialing: ${buyer.contactPhone}`)
                      : (isSw ? 'Wasiliana na Mnunuzi / Dawati la Mauzo' : 'Contact Buyer / Trade Desk')}
                  </span>
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

// 5. COMMUNITY VIEW
export function CommunityView({ language, user }: ViewsProps) {
  const isSw = language === 'sw';
  const [posts, setPosts] = useState<CommunityPost[]>(COMMUNITY_POSTS);
  const [newPostText, setNewPostText] = useState('');
  const [showNewPostModal, setShowNewPostModal] = useState(false);

  const toggleLike = (postId: string) => {
    playKeyTap();
    setPosts(
      posts.map((p) => {
        if (p.id === postId) {
          const liked = !p.liked;
          return {
            ...p,
            liked,
            likesCount: liked ? p.likesCount + 1 : p.likesCount - 1,
          };
        }
        return p;
      })
    );
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim()) return;

    const newPost: CommunityPost = {
      id: `post-${Date.now()}`,
      authorName: user.name,
      location: `${user.region}, Tanzania`,
      avatarInitials: user.avatar,
      timeAgoSw: 'Sasa hivi',
      timeAgoEn: 'Just now',
      contentSw: newPostText,
      contentEn: newPostText,
      repliesCount: 0,
      likesCount: 1,
      liked: true,
      tagSw: 'Mazungumzo ya Wakulima',
      tagEn: 'Farmer Discussion',
    };

    setPosts([newPost, ...posts]);
    setNewPostText('');
    setShowNewPostModal(false);
    playSuccessChime();
  };

  return (
    <div id="dashboard-community-view" className="space-y-4 pb-6">
      <div className="pt-2 flex items-center justify-between">
        <div>
          <h2 className="font-display text-2xl font-bold text-[var(--ink)]">
            {isSw ? 'Jumuiya ya Wakulima' : 'Farmer Community'}
          </h2>
          <p className="text-xs text-[var(--ink-soft)] mt-0.5">
            {isSw ? 'Ushauri, uzoefu, na maswali ya kilimo' : 'Knowledge exchange, crop questions, and advice'}
          </p>
        </div>
        <button
          onClick={() => setShowNewPostModal(true)}
          className="p-2.5 rounded-full bg-[var(--forest)] text-[#F7F4E9] shadow-md hover:bg-[var(--forest-dark)]"
          title={isSw ? 'Andika Swali' : 'Post Question'}
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-3">
        {posts.map((post) => (
          <div
            key={post.id}
            className="p-4 rounded-2xl bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-2.5"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[var(--soil)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center">
                  {post.avatarInitials}
                </div>
                <div>
                  <div className="font-bold text-xs text-[var(--ink)]">{post.authorName}</div>
                  <div className="text-[10px] text-[var(--ink-soft)]">
                    {post.location} · {isSw ? post.timeAgoSw : post.timeAgoEn}
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[var(--bg)] text-[var(--forest)]">
                {isSw ? post.tagSw : post.tagEn}
              </span>
            </div>

            <p className="text-xs text-[var(--ink)] leading-relaxed">
              {isSw ? post.contentSw : post.contentEn}
            </p>

            <div className="pt-2 border-t border-[var(--line)] flex items-center justify-between text-xs text-[var(--ink-soft)]">
              <button
                onClick={() => toggleLike(post.id)}
                className={`flex items-center gap-1 transition-colors ${
                  post.liked ? 'text-red-500 font-semibold' : 'hover:text-[var(--ink)]'
                }`}
              >
                <Heart className={`w-3.5 h-3.5 ${post.liked ? 'fill-current' : ''}`} />
                <span>{post.likesCount}</span>
              </button>
              <div className="flex items-center gap-1">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>{post.repliesCount} {isSw ? 'majibu' : 'replies'}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* New Post Modal */}
      {showNewPostModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-[var(--paper)] rounded-2xl p-5 border border-[var(--line)] shadow-2xl">
            <h3 className="font-display text-lg font-bold text-[var(--ink)] mb-2">
              {isSw ? 'Uliza Swali au Shiriki Ushauri' : 'Ask Question or Share Tip'}
            </h3>
            <form onSubmit={handleCreatePost} className="space-y-3">
              <textarea
                rows={4}
                required
                value={newPostText}
                onChange={(e) => setNewPostText(e.target.value)}
                placeholder={
                  isSw
                    ? 'Eleza zao lako, changamoto unayokutana nayo, au mbinu iliyokusaidia...'
                    : 'Describe your crop, pest issue, or successful farming method...'
                }
                className="w-full p-3 text-xs rounded-xl bg-[var(--bg)] border border-[var(--line)] outline-none"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewPostModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-[var(--line)] text-xs font-semibold"
                >
                  {isSw ? 'Ghairi' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[var(--forest)] text-[#F7F4E9] text-xs font-semibold"
                >
                  {isSw ? 'Chapisha' : 'Post'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
