import { cn } from "@/lib/utils";

export function ShieldMark({
  className,
  pulse = false,
}: {
  className?: string;
  pulse?: boolean;
}) {
  return (
    <svg
      viewBox="0 0 64 64"
      className={cn("text-primary", className)}
      aria-hidden="true"
    >
      {pulse ? (
        <circle cx="32" cy="34" r="22" fill="currentColor" opacity="0.08">
          <animate
            attributeName="r"
            values="20;26;20"
            dur="2.8s"
            repeatCount="indefinite"
          />
          <animate
            attributeName="opacity"
            values="0.12;0.02;0.12"
            dur="2.8s"
            repeatCount="indefinite"
          />
        </circle>
      ) : null}
      <path
        d="M32 6 L54 14 V32 C54 46 44 56 32 60 C20 56 10 46 10 32 V14 Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.4"
        strokeLinejoin="round"
      />
      <path
        d="M32 14 L46 19 V32 C46 42 39 50 32 53 C25 50 18 42 18 32 V19 Z"
        fill="currentColor"
        opacity="0.16"
      />
      <path
        d="M32 18 V46"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <path
        d="M24 31 H40"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
    </svg>
  );
}
