import * as Dialog from "@radix-ui/react-dialog";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { explainWord } from "@/lib/explain.functions";
import { useStudy } from "@/lib/study-store";

export type WordPayload = {
  word: string;
  meaning?: string;
  note?: string;
  context: string;
};

const mem = new Map<string, string>();

export function WordSheet({ payload, onClose }: { payload: WordPayload | null; onClose: () => void }) {
  const ask = useServerFn(explainWord);
  const saveAsk = useStudy((s) => s.saveAsk);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);

  function reset(next: boolean) {
    if (!next) {
      setQuestion("");
      setAnswer("");
      setError("");
      setBusy(false);
      setSaved(false);
      onClose();
    }
  }

  async function explain() {
    if (!payload) return;
    const cacheKey = `${payload.word}|${question}|${payload.context}`;
    const hit = mem.get(cacheKey);
    if (hit) {
      setAnswer(hit);
      setError("");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const res = await ask({
        data: { word: payload.word, question, context: payload.context },
      });
      if (!res.ok) {
        setError(res.error);
        return;
      }
      mem.set(cacheKey, res.text);
      setAnswer(res.text);
    } catch {
      setError("ما قدرتش أوصل للشرح. المعنى من القاموس لسه ظاهر فوق.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog.Root open={payload !== null} onOpenChange={reset}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-ink/40" />
        <Dialog.Content className="fixed inset-x-0 bottom-0 z-50 max-h-[85vh] overflow-y-auto rounded-t-2xl border border-line bg-surface p-5 shadow-lg md:inset-x-auto md:top-1/2 md:bottom-auto md:w-full md:max-w-lg md:-translate-y-1/2 md:rounded-2xl md:left-1/2 md:-translate-x-1/2">
          {payload ? (
            <>
              <Dialog.Title dir="ltr" lang="it" className="text-left text-3xl font-semibold text-primary">
                {payload.word}
              </Dialog.Title>
              <Dialog.Description className="mt-2 text-base text-ink">
                {payload.meaning ? payload.meaning : "الكلمة دي مش في القاموس الثابت. اطلب شرحها تحت."}
              </Dialog.Description>
              {payload.note ? <p className="mt-3 rounded-xl bg-soft px-3 py-2 text-sm leading-relaxed">{payload.note}</p> : null}
              <label className="mt-4 block text-sm text-muted" htmlFor="ask">
                اسأل عن الكلمة أو عن الجملة
              </label>
              <textarea
                id="ask"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                rows={3}
                placeholder="مثال: ليه الإجابة خطأ لو السرعة 130 في المطر؟"
                className="mt-1 w-full rounded-xl border border-line bg-bg px-3 py-2 text-base outline-none focus:border-primary"
              />
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void explain()}
                  className="min-h-11 rounded-full bg-primary px-4 text-primary-fg disabled:opacity-60"
                >
                  {busy ? "بيشرح…" : "اشرح لي"}
                </button>
                <Dialog.Close className="min-h-11 rounded-full border border-line px-4">إغلاق</Dialog.Close>
              </div>
              {error ? <p className="mt-3 text-sm text-accent">{error}</p> : null}
              {answer ? (
                <div className="mt-4 rounded-xl bg-warn px-3 py-3 text-sm leading-relaxed text-warn-ink">
                  <p>{answer}</p>
                  <button
                    type="button"
                    className="mt-3 min-h-11 rounded-full bg-ink px-4 text-surface"
                    onClick={() => {
                      saveAsk({
                        id: `${Date.now()}`,
                        word: payload.word,
                        question: question || "شرح الكلمة",
                        answer,
                        at: Date.now(),
                      });
                      setSaved(true);
                    }}
                  >
                    {saved ? "اتحفظ في أسئلتي" : "احفظ الشرح"}
                  </button>
                </div>
              ) : null}
            </>
          ) : null}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
