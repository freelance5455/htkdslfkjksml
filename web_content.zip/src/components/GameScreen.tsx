import {
  CSSProperties,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  ArrowRight,
  Lightbulb,
  Map as MapIcon,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Settings,
  Star,
  Trophy,
  Undo2,
  Volume2,
  VolumeX,
  Waves,
} from "lucide-react";
import {
  applyMove,
  calculateResult,
  findHint,
  formatTime,
  getLevel,
  getPourAmount,
  getValidMoves,
  isSolved,
  isTubeComplete,
  LevelResult,
  LIQUID_COLORS,
  Move,
  previewScore,
  SkinId,
  topGroup,
  TOTAL_LEVELS,
  TubeState,
} from "../game";
import { LevelRecord } from "../storage";
import { audio } from "../audio";
import TubeGraphic, { makeLayers, VisualLayer } from "./Tube";
import PourStream from "./PourStream";
import { LIP_LEFT, LIP_RIGHT, pourTilt, rotate, TUBE_CENTER } from "../liquidPhysics";

interface GameScreenProps {
  levelNumber: number;
  best?: LevelRecord;
  skin: SkinId;
  soundOn: boolean;
  onToggleSound: () => void;
  onOpenSettings: () => void;
  onExit: () => void;
  onStartLevel: (level: number) => void;
  onComplete: (result: LevelResult) => void;
  onMove: () => void;
}

interface Point { x: number; y: number }

interface PourGeometry {
  fromCenter: Point;
  /** Fixed world point where the source lip sits during the pour. */
  mouth: Point;
  targetCenter: Point;
  targetTop: number;
  targetHeight: number;
  targetWidth: number;
  sourceHeight: number;
  /** +1 tilts clockwise (pouring right), -1 counter-clockwise. */
  dir: number;
  width: number;
  height: number;
}

interface PourAnimation extends Move {
  start: number;
  duration: number;
  geometry: PourGeometry;
  /** Target fill (0..4 units) before the pour — for synced fill-pitch audio. */
  initialTarget: number;
  /** Source fill before the pour — drives the physically required tilt. */
  sourceTotal: number;
}

interface HistoryEntry {
  tubes: TubeState;
  moves: number;
}

const STREAM_START = 0.26;
const STREAM_END = 0.84;
/** Final drops that fall from the lip after the stream breaks (in progress units). */
const DRIPS = [
  { at: 0.0, fall: 0.05, r: 2.2 },
  { at: 0.035, fall: 0.05, r: 1.6 },
  { at: 0.075, fall: 0.045, r: 1.1 },
];
const clamp = (value: number, min = 0, max = 1) => Math.max(min, Math.min(max, value));
const ease = (value: number) => {
  const t = clamp(value);
  return t * t * (3 - 2 * t);
};
const mix = (a: number, b: number, t: number) => a + (b - a) * t;

function addVisualLiquid(layers: VisualLayer[], color: number, amount: number): VisualLayer[] {
  const next = layers.map((layer) => ({ ...layer }));
  if (amount <= 0) return next;
  const last = next[next.length - 1];
  if (last?.color === color) last.units += amount;
  else next.push({ color, units: amount });
  return next;
}

function removeVisualLiquid(layers: VisualLayer[], amount: number): VisualLayer[] {
  const next = layers.map((layer) => ({ ...layer }));
  let remaining = amount;
  while (remaining > 0.0001 && next.length) {
    const last = next[next.length - 1];
    const removed = Math.min(last.units, remaining);
    last.units -= removed;
    remaining -= removed;
    if (last.units <= 0.005) next.pop();
  }
  return next;
}

export default function GameScreen({
  levelNumber,
  best,
  skin,
  soundOn,
  onToggleSound,
  onOpenSettings,
  onExit,
  onStartLevel,
  onComplete,
  onMove,
}: GameScreenProps) {
  const definition = useMemo(() => getLevel(levelNumber), [levelNumber]);
  const [tubes, setTubes] = useState<TubeState>(() => definition.tubes.map((tube) => [...tube]));
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [moves, setMoves] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [undosUsed, setUndosUsed] = useState(0);
  const [extraTubes, setExtraTubes] = useState(0);
  const [paused, setPaused] = useState(false);
  const [victory, setVictory] = useState<LevelResult | null>(null);
  const [deadlocked, setDeadlocked] = useState(false);
  const [pour, setPour] = useState<PourAnimation | null>(null);
  const [pourProgress, setPourProgress] = useState(0);
  const [notice, setNotice] = useState("Tap a tube, then choose a matching or empty tube.");
  const [invalidTube, setInvalidTube] = useState<number | null>(null);
  const [hint, setHint] = useState<Move | null>(null);
  const [hintThinking, setHintThinking] = useState(false);
  const [shake, setShake] = useState(false);
  const [newBest, setNewBest] = useState(false);
  const boardRef = useRef<HTMLDivElement>(null);
  const tubeRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const hintTimer = useRef<number | null>(null);
  const bestRef = useRef<LevelRecord | undefined>(best);
  const elapsedRef = useRef(elapsed);
  bestRef.current = best;
  elapsedRef.current = elapsed;

  const columns = Math.min(6, tubes.length <= 6 ? tubes.length : Math.ceil(tubes.length / 2));
  // Shrink tubes as the count grows so 13–16 tube Hard boards still fit.
  const tubeWidth =
    tubes.length <= 8
      ? "clamp(42px, 12.2vw, 67px)"
      : tubes.length <= 12
        ? "clamp(38px, 11vw, 58px)"
        : "clamp(31px, 9.4vw, 50px)";
  const liveScore = previewScore(levelNumber, moves, elapsed, hintsUsed, undosUsed, extraTubes);

  const pulseShake = useCallback(() => {
    setShake(false);
    window.requestAnimationFrame(() => setShake(true));
    window.setTimeout(() => setShake(false), 380);
  }, []);

  const resetGame = useCallback(() => {
    if (hintTimer.current !== null) window.clearTimeout(hintTimer.current);
    audio.stopPour(true);
    setTubes(definition.tubes.map((tube) => [...tube]));
    setHistory([]);
    setSelected(null);
    setMoves(0);
    setElapsed(0);
    setHintsUsed(0);
    setUndosUsed(0);
    setExtraTubes(0);
    setPaused(false);
    setVictory(null);
    setDeadlocked(false);
    setPour(null);
    setPourProgress(0);
    setHint(null);
    setHintThinking(false);
    setNewBest(false);
    setNotice("Fresh water. Tap a tube to begin.");
    audio.clink();
  }, [definition]);

  useEffect(() => {
    if (paused || victory || deadlocked) return;
    const timer = window.setInterval(() => setElapsed((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [paused, victory, deadlocked]);

  useEffect(() => () => {
    if (hintTimer.current !== null) window.clearTimeout(hintTimer.current);
    audio.stopPour(true);
  }, []);

  const finishPour = (finished: PourAnimation) => {
    const next = applyMove(tubes, finished);
    const nextMoves = moves + 1;
    setTubes(next);
    setMoves(nextMoves);
    onMove();
    setNotice("Liquid settled. Keep the colors flowing.");
    if (isTubeComplete(next[finished.to]) && !isTubeComplete(tubes[finished.to])) {
      setNotice(`${LIQUID_COLORS[finished.color].name} sorted — glass sealed!`);
      // Sound lands with the lid's impact in the drop animation.
      window.setTimeout(() => {
        audio.cap();
        try { navigator.vibrate?.(15); } catch { /* no haptics */ }
      }, 300);
    }

    if (isSolved(next)) {
      const result = calculateResult(levelNumber, nextMoves, elapsedRef.current, hintsUsed, undosUsed, extraTubes);
      const previous = bestRef.current;
      setNewBest(!previous || nextMoves < previous.bestMoves || result.score > previous.bestScore);
      setVictory(result);
      onComplete(result);
      audio.victory();
      pulseShake();
    } else if (getValidMoves(next).length === 0) {
      setDeadlocked(true);
      setNotice("No legal pours remain. Undo or add a tube to continue.");
    }
  };
  const finishPourRef = useRef(finishPour);
  finishPourRef.current = finishPour;

  useEffect(() => {
    if (!pour) return;
    let frame = 0;
    let streamPlaying = false;
    let landed = false;
    const dripPlayed = [false, false, false];
    const initialFill = pour.initialTarget / 4;

    const animate = (now: number) => {
      const progress = clamp((now - pour.start) / pour.duration);
      setPourProgress(progress);
      // Live flow 0→1→0 across the stream window — one value drives
      // stream width, splash energy AND pour volume/pitch. Always in sync.
      const streamT = clamp((progress - STREAM_START) / (STREAM_END - STREAM_START));
      const flow = Math.pow(Math.sin(streamT * Math.PI), 1.4);
      const transferNow = pour.amount * (streamT - Math.sin(2 * Math.PI * streamT) / (2 * Math.PI));
      const fillNow = (pour.initialTarget + transferNow) / 4;

      if (progress >= STREAM_START && progress < STREAM_END && !streamPlaying) {
        audio.startPour(pour.amount, initialFill);
        try {
          navigator.vibrate?.(8);
        } catch {
          /* haptics unavailable */
        }
        streamPlaying = true;
      }
      if (streamPlaying) {
        audio.updatePour(progress < STREAM_END ? flow : 0, fillNow);
      }
      if (progress >= STREAM_END && streamPlaying) {
        audio.stopPour();
        audio.splash(0.7 + pour.amount * 0.1, Math.min(1, fillNow));
        streamPlaying = false;
      }
      // Each final drip plinks as it lands on the target surface.
      DRIPS.forEach((drip, i) => {
        if (!dripPlayed[i] && progress >= STREAM_END + drip.at + drip.fall) {
          dripPlayed[i] = true;
          audio.plink(Math.min(1, (pour.initialTarget + pour.amount) / 4), 0.5 - i * 0.12);
        }
      });
      // Tube touches back down near the end of the return leg.
      if (progress > 0.93 && !landed) {
        landed = true;
        audio.land();
        try {
          navigator.vibrate?.(12);
        } catch {
          /* haptics unavailable */
        }
      }
      if (progress < 1) {
        frame = window.requestAnimationFrame(animate);
      } else {
        setPour(null);
        setPourProgress(0);
        finishPourRef.current(pour);
      }
    };
    frame = window.requestAnimationFrame(animate);
    return () => {
      window.cancelAnimationFrame(frame);
      if (streamPlaying) audio.stopPour(true);
    };
  }, [pour]);

  const measurePour = (from: number, to: number): PourGeometry | null => {
    const board = boardRef.current?.getBoundingClientRect();
    const source = tubeRefs.current[from]?.getBoundingClientRect();
    const target = tubeRefs.current[to]?.getBoundingClientRect();
    if (!board || !source || !target) return null;
    const fromCenter = { x: source.left - board.left + source.width / 2, y: source.top - board.top + source.height / 2 };
    const targetCenter = { x: target.left - board.left + target.width / 2, y: target.top - board.top + target.height / 2 };
    const dir = Math.abs(targetCenter.x - fromCenter.x) > 4
      ? (targetCenter.x > fromCenter.x ? 1 : -1)
      : (to > from ? 1 : -1);
    const targetTop = target.top - board.top;
    // Lip hangs just over the target rim, slightly to the source side.
    const mouth = {
      x: targetCenter.x - dir * target.width * 0.22,
      y: targetTop - Math.max(10, source.height * 0.05),
    };
    return {
      fromCenter,
      mouth,
      targetCenter,
      targetTop,
      targetHeight: target.height,
      targetWidth: target.width,
      sourceHeight: source.height,
      dir,
      width: board.width,
      height: board.height,
    };
  };

  const beginPour = (from: number, to: number) => {
    const amount = getPourAmount(tubes, from, to);
    const geometry = measurePour(from, to);
    if (!amount || !geometry) return;
    const { color } = topGroup(tubes[from]);
    setHistory((items) => [...items, { tubes: tubes.map((tube) => [...tube]), moves }]);
    setSelected(null);
    setHint(null);
    setNotice(`Pouring ${LIQUID_COLORS[color].name.toLowerCase()} water…`);
    setPourProgress(0);
    audio.lift();
    setPour({
      from,
      to,
      amount,
      color,
      geometry,
      initialTarget: tubes[to].length,
      sourceTotal: tubes[from].length,
      start: performance.now(),
      duration: 2100 + amount * 420,
    });
  };

  const rejectPour = (index: number, message: string) => {
    setInvalidTube(index);
    setNotice(message);
    audio.invalid();
    pulseShake();
    window.setTimeout(() => setInvalidTube(null), 420);
  };

  const handleTube = (index: number) => {
    if (pour || paused || victory || deadlocked || hintThinking) return;
    setHint(null);
    if (selected === null) {
      if (!tubes[index].length) {
        rejectPour(index, "That tube is empty. Choose a tube with liquid first.");
        return;
      }
      if (isTubeComplete(tubes[index])) {
        rejectPour(index, "That glass is sealed — it's already sorted.");
        return;
      }
      setSelected(index);
      const { color, count } = topGroup(tubes[index]);
      setNotice(`${LIQUID_COLORS[color].name} selected · ${count} unit${count > 1 ? "s" : ""} ready to pour.`);
      audio.tap(0.7);
      return;
    }
    if (selected === index) {
      setSelected(null);
      setNotice("Selection cleared. Choose any non-empty tube.");
      audio.tap(0.45);
      return;
    }
    const amount = getPourAmount(tubes, selected, index);
    if (!amount) {
      const target = tubes[index];
      const sourceColor = topGroup(tubes[selected]).color;
      const message = target.length >= 4
        ? "That tube is full. Choose another destination."
        : target.length > 0 && target[target.length - 1] !== sourceColor
          ? "Only matching colors can touch. Try an empty or matching tube."
          : "That pour is not possible.";
      rejectPour(index, message);
      return;
    }
    beginPour(selected, index);
  };

  const undo = useCallback(() => {
    if (pour || hintThinking) return;
    const last = history[history.length - 1];
    if (!last) {
      setNotice("No pours to undo yet.");
      audio.invalid();
      return;
    }
    const restored = last.tubes.map((tube) => [...tube]);
    // Adding a tube is a separate action, not part of the pour being undone.
    if (extraTubes > 0 && restored.length === definition.tubes.length) restored.push([]);
    setTubes(restored);
    setMoves(last.moves);
    setHistory((items) => items.slice(0, -1));
    setUndosUsed((value) => value + 1);
    setSelected(null);
    setHint(null);
    setVictory(null);
    setDeadlocked(false);
    setNotice("Last pour restored. Your lifetime move total is unchanged.");
    audio.clink();
  }, [history, pour, hintThinking, extraTubes, definition.tubes.length]);

  const requestHint = useCallback(() => {
    if (pour || paused || victory || deadlocked || hintThinking) return;
    setHintThinking(true);
    setHint(null);
    setNotice("Reading the currents…");
    hintTimer.current = window.setTimeout(() => {
      const result = findHint(tubes);
      setHintThinking(false);
      if (!result.move) {
        setDeadlocked(true);
        setNotice("No legal pours remain. Undo or add a tube.");
        return;
      }
      setHint(result.move);
      setHintsUsed((value) => value + 1);
      setNotice(`Hint: pour tube ${result.move.from + 1} into tube ${result.move.to + 1}.`);
      audio.bubble(false, 1.2);
    }, 90);
  }, [pour, paused, victory, deadlocked, hintThinking, tubes]);

  const addTube = useCallback(() => {
    if (pour || hintThinking || extraTubes >= 1 || victory) return;
    setTubes((items) => [...items, []]);
    setExtraTubes((value) => value + 1);
    setSelected(null);
    setHint(null);
    setDeadlocked(false);
    setNotice("Bonus tube added. It costs 250 points, but the puzzle is now more open.");
    audio.clink();
  }, [pour, hintThinking, extraTubes, victory]);

  const togglePause = useCallback(() => {
    if (pour || victory || deadlocked) return;
    setPaused((value) => !value);
    setSelected(null);
    audio.clink();
  }, [pour, victory, deadlocked]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.target as HTMLElement)?.matches("input, textarea")) return;
      const key = event.key.toLowerCase();
      if (key === "m") { onToggleSound(); return; }
      if (key === "r") { event.preventDefault(); resetGame(); return; }
      if (key === "escape" || key === "p") { event.preventDefault(); togglePause(); return; }
      if (paused || victory) return;
      if (key === "u") { event.preventDefault(); undo(); return; }
      if (key === "h") { event.preventDefault(); requestHint(); return; }
      if (key === "a") { event.preventDefault(); addTube(); return; }
      if (deadlocked) return;
      if (/^[0-9]$/.test(key)) {
        const index = key === "0" ? 9 : Number(key) - 1;
        if (index < tubes.length) handleTube(index);
        return;
      }
      if (["arrowleft", "arrowright", "arrowup", "arrowdown"].includes(key)) {
        event.preventDefault();
        const active = tubeRefs.current.findIndex((element) => element === document.activeElement);
        const delta = key === "arrowleft" || key === "arrowup" ? -1 : 1;
        const next = ((active < 0 ? 0 : active + delta) + tubes.length) % tubes.length;
        tubeRefs.current[next]?.focus();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  });

  // Drain curve whose rate is sin² — exactly the stream's flow envelope.
  // Liquid leaves the source slowly, peaks mid-pour, and tapers off.
  const drainCurve = (t: number) => {
    const c = clamp(t);
    return c - Math.sin(2 * Math.PI * c) / (2 * Math.PI);
  };
  const transfer = pour
    ? pour.amount * drainCurve((pourProgress - STREAM_START) / (STREAM_END - STREAM_START))
    : 0;

  // Target fills only once the stream head has actually reached it.
  const streamTNow = pour ? clamp((pourProgress - STREAM_START) / (STREAM_END - STREAM_START)) : 0;
  // Target receives the same curve, delayed by the stream's fall time.
  const targetTransfer = pour ? pour.amount * drainCurve((streamTNow - 0.08) / 0.92) : 0;
  const headT = clamp(streamTNow / 0.09);
  const tailT = clamp((streamTNow - 0.9) / 0.1);

  const layersFor = (index: number): VisualLayer[] | undefined => {
    // Static tubes keep their identity so the memoized SVG does not rerender at 60fps.
    if (!pour || (index !== pour.from && index !== pour.to)) return undefined;
    let layers = makeLayers(tubes[index]);
    if (index === pour.from) layers = removeVisualLiquid(layers, transfer);
    if (index === pour.to) layers = addVisualLiquid(layers, pour.color, targetTransfer);
    return layers;
  };

  // Shared flow envelope 0→1→0 — visuals and audio read the same value.
  const streamT = pour ? clamp((pourProgress - STREAM_START) / (STREAM_END - STREAM_START)) : 0;
  const flow = pour ? Math.pow(Math.sin(streamT * Math.PI), 1.4) : 0;

  let sourcePose: { center: Point; angle: number } | null = null;
  if (pour) {
    const { geometry } = pour;
    const scale = geometry.sourceHeight / 220;
    const lip = geometry.dir > 0 ? LIP_RIGHT : LIP_LEFT;
    const lipOffset = { x: (lip.x - TUBE_CENTER.x) * scale, y: (lip.y - TUBE_CENTER.y) * scale };
    // Center that puts the lip exactly on the fixed mouth point at angle θ.
    const centerFor = (theta: number) => {
      const r = rotate(lipOffset, theta);
      return { x: geometry.mouth.x - r.x, y: geometry.mouth.y - r.y };
    };
    // Physically required tilt: liquid surface just reaches the lip.
    // Slight over-tilt so the surface visibly spills over the lip.
    const tiltAt = (units: number) => geometry.dir * (pourTilt(units) + 0.07);
    const startAngle = tiltAt(pour.sourceTotal);
    const endAngle = tiltAt(pour.sourceTotal - pour.amount);
    if (pourProgress < STREAM_START) {
      const t = ease(pourProgress / STREAM_START);
      const target = centerFor(startAngle);
      sourcePose = {
        center: {
          x: mix(geometry.fromCenter.x, target.x, t),
          y: mix(geometry.fromCenter.y, target.y, t) - Math.sin(t * Math.PI) * 26,
        },
        angle: startAngle * ease(Math.min(1, (pourProgress / STREAM_START) * 1.15)),
      };
    } else if (pourProgress <= STREAM_END) {
      // Tips further as it empties so the liquid keeps reaching the lip.
      const angle = tiltAt(pour.sourceTotal - transfer);
      sourcePose = { center: centerFor(angle), angle };
    } else {
      const t = ease((pourProgress - STREAM_END) / (1 - STREAM_END));
      const from = centerFor(endAngle);
      sourcePose = {
        center: {
          x: mix(from.x, geometry.fromCenter.x, t),
          y: mix(from.y, geometry.fromCenter.y, t) - Math.sin(t * Math.PI) * 20,
        },
        angle: endAngle * (1 - t),
      };
    }
  }

  let stream: { start: Point; control: Point; end: Point; opacity: number; flow: number } | null = null;
  if (pour && sourcePose && pourProgress >= STREAM_START && pourProgress <= STREAM_END) {
    const { geometry } = pour;
    const start = geometry.mouth;
    const targetUnits = tubes[pour.to].length + targetTransfer;
    const surfaceInViewBox = 196 - targetUnits * 43.5;
    const end = {
      x: geometry.targetCenter.x + geometry.dir * geometry.targetWidth * 0.04,
      y: geometry.targetTop + (surfaceInViewBox / 220) * geometry.targetHeight,
    };
    // Liquid spills over the lip, arcs outward briefly, then falls straight.
    const control = {
      x: start.x + geometry.dir * geometry.targetWidth * 0.34,
      y: start.y + 2,
    };
    // Fade in only — the end is handled by the tail actually falling.
    const opacity = clamp((pourProgress - STREAM_START) / 0.03);
    stream = { start, control, end, opacity, flow };
  }

  return (
    <main className={`play-screen screen ${shake ? "screen-shake" : ""}`}>
      <header className="play-header">
        <button className="icon-button glass-button" onClick={togglePause} disabled={Boolean(pour) || Boolean(victory)} aria-label="Pause game">
          <Pause size={20} />
        </button>
        <div className="level-heading">
          <span>{definition.difficulty} current</span>
          <strong>Level {levelNumber}</strong>
        </div>
        <button className="icon-button glass-button" onClick={onToggleSound} aria-label={soundOn ? "Mute all sound" : "Turn sound on"}>
          {soundOn ? <Volume2 size={20} /> : <VolumeX size={20} />}
        </button>
      </header>

      <section className="game-stats glass-panel" aria-label="Level statistics">
        <div><span>Moves</span><strong>{moves}</strong><small>Par {definition.par}</small></div>
        <div><span>Best</span><strong>{best?.bestMoves ?? "—"}</strong><small>{best ? `${best.stars} stars` : "No record"}</small></div>
        <div className="score-stat"><span>Score</span><strong>{liveScore.toLocaleString()}</strong><small>{formatTime(elapsed)}</small></div>
      </section>

      <div className={`notice ${invalidTube !== null ? "notice-error" : ""}`} role="status" aria-live="polite">
        {hintThinking ? <span className="tiny-spinner" /> : <Waves size={15} />}
        <span>{notice}</span>
      </div>

      <section
        className={`tube-board ${pour ? "board-is-pouring" : ""} ${tubes.length > 12 ? "tubes-many" : ""}`}
        ref={boardRef}
        style={{ "--columns": columns, "--tube-w": tubeWidth } as CSSProperties}
        aria-label={`Puzzle board with ${tubes.length} tubes`}
      >
        <div className="tube-grid" style={{ gridTemplateColumns: `repeat(${columns}, var(--tube-w))` }}>
          {tubes.map((tube, index) => {
            const isSource = pour?.from === index;
            const isTarget = pour?.to === index;
            const motionStyle: CSSProperties = {};
            if (isSource && sourcePose && pour) {
              motionStyle.transform = `translate(${sourcePose.center.x - pour.geometry.fromCenter.x}px, ${sourcePose.center.y - pour.geometry.fromCenter.y}px) rotate(${sourcePose.angle}rad)`;
              motionStyle.zIndex = 24;
            } else if (isTarget && stream && pour) {
              // Impact tremor scaled by live flow — the glass shudders as water lands.
              const tremor = Math.sin(pourProgress * 43) * 1.1 * stream.flow;
              const bob = Math.abs(Math.sin(pourProgress * 31)) * 1.4 * stream.flow;
              motionStyle.transform = `translate(${tremor}px, ${bob}px)`;
            }
            const colorNames = tube.length ? tube.map((color) => LIQUID_COLORS[color].name).join(", ") : "empty";
            return (
              <button
                key={index}
                ref={(element) => { tubeRefs.current[index] = element; }}
                className={`tube-slot ${selected === index ? "selected" : ""} ${invalidTube === index ? "invalid" : ""} ${hint?.from === index ? "hint-source" : ""} ${hint?.to === index ? "hint-target" : ""} ${isTarget && stream ? "receiving" : ""}`}
                onClick={() => handleTube(index)}
                aria-label={`Tube ${index + 1}, ${colorNames}. ${selected === index ? "Selected" : ""}`}
                aria-pressed={selected === index}
                disabled={Boolean(victory || paused || deadlocked)}
              >
                <span className="tube-motion" style={motionStyle}>
                  <TubeGraphic
                    tube={tube}
                    layers={layersFor(index)}
                    skin={skin}
                    active={Boolean((isSource || isTarget) && stream)}
                    tilt={isSource && sourcePose ? sourcePose.angle : 0}
                    lifted={selected === index}
                    complete={isTubeComplete(tube)}
                  />
                </span>
                <span className="tube-number">{index + 1}</span>
                {hint?.from === index && <span className="hint-tag">FROM</span>}
                {hint?.to === index && <span className="hint-tag">POUR HERE</span>}
              </button>
            );
          })}
        </div>

        {pour && (
          <svg
            className="pour-overlay"
            width={pour.geometry.width}
            height={pour.geometry.height}
            viewBox={`0 0 ${pour.geometry.width} ${pour.geometry.height}`}
            aria-hidden="true"
          >
            {stream && (
              <PourStream
                color={pour.color}
                amount={pour.amount}
                progress={pourProgress}
                flow={stream.flow}
                headT={headT}
                tailT={tailT}
                start={stream.start}
                control={stream.control}
                end={stream.end}
                opacity={stream.opacity}
                impactRadius={pour.geometry.targetHeight * 0.075}
              />
            )}
            {pour && pourProgress > STREAM_END && (() => {
              const g = pour.geometry;
              const finalUnits = tubes[pour.to].length + pour.amount;
              const surfaceY = g.targetTop + ((196 - finalUnits * 43.5) / 220) * g.targetHeight;
              const palette = LIQUID_COLORS[pour.color];
              return DRIPS.map((drip, i) => {
                const t = (pourProgress - STREAM_END - drip.at) / drip.fall;
                if (t < 0 || t > 1) return null;
                const y = g.mouth.y + (surfaceY - g.mouth.y) * t * t;
                const x = g.mouth.x + g.dir * g.targetWidth * 0.18 * Math.min(1, t * 2);
                const r = drip.r * (g.targetWidth / 60);
                return (
                  <g key={i}>
                    <ellipse cx={x} cy={y} rx={r * 0.8} ry={r * (1 + t * 0.6)} fill={palette.base} />
                    <circle cx={x - r * 0.25} cy={y - r * 0.35} r={r * 0.3} fill="#ffffff" opacity=".85" />
                  </g>
                );
              });
            })()}
          </svg>
        )}
      </section>

      <nav className="game-controls glass-panel" aria-label="Puzzle actions">
        <button onClick={undo} disabled={!history.length || Boolean(pour)}><Undo2 /><span>Undo</span><kbd>U</kbd></button>
        <button onClick={resetGame}><RotateCcw /><span>Restart</span><kbd>R</kbd></button>
        <button onClick={requestHint} disabled={Boolean(pour) || hintThinking}><Lightbulb /><span>{hintThinking ? "Thinking" : "Hint"}</span><kbd>H</kbd></button>
        <button onClick={addTube} disabled={extraTubes >= 1 || Boolean(pour) || hintThinking}><Plus /><span>{extraTubes ? "Tube Added" : "Add Tube"}</span><kbd>A</kbd></button>
      </nav>
      <div className="keyboard-tip">Arrow keys + Enter to pour <span>·</span> P to pause <span>·</span> M for sound</div>

      {paused && !victory && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Game paused">
          <section className="modal-card pause-card">
            <div className="modal-icon"><Pause /></div>
            <span className="eyebrow">Take a breath</span>
            <h2>Ocean Paused</h2>
            <p>Your puzzle and timer are waiting right here.</p>
            <button className="primary-button wide" onClick={togglePause}><Play size={19} /> Resume Dive</button>
            <div className="modal-button-row">
              <button className="secondary-button" onClick={resetGame}><RotateCcw size={17} /> Restart</button>
              <button className="secondary-button" onClick={onOpenSettings}><Settings size={17} /> Settings</button>
            </div>
            <button className="text-button" onClick={onExit}><MapIcon size={16} /> All levels</button>
          </section>
        </div>
      )}

      {deadlocked && !victory && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="No moves remain">
          <section className="modal-card deadlock-card">
            <div className="modal-icon warning"><Waves /></div>
            <span className="eyebrow">Current stalled</span>
            <h2>No Pours Left</h2>
            <p>This arrangement has no legal moves. Recover instantly—your progress is safe.</p>
            {history.length > 0 && <button className="primary-button wide" onClick={undo}><Undo2 size={18} /> Undo Last Pour</button>}
            {!extraTubes && <button className="secondary-button wide" onClick={addTube}><Plus size={18} /> Add a Tube</button>}
            <button className="secondary-button wide" onClick={resetGame}><RotateCcw size={18} /> Restart Level</button>
            <button className="text-button" onClick={onExit}><MapIcon size={16} /> All levels</button>
          </section>
        </div>
      )}

      {victory && (
        <div className="modal-backdrop victory-backdrop" role="dialog" aria-modal="true" aria-label="Level complete">
          <div className="victory-particles" aria-hidden="true">
            {Array.from({ length: 26 }, (_, index) => (
              <i
                key={index}
                style={{
                  left: `${4 + (index * 37) % 92}%`,
                  top: `${67 + (index * 13) % 25}%`,
                  background: `hsl(${165 + (index * 9) % 190} 85% 70%)`,
                  animationDelay: `${-index * 0.07}s`,
                }}
              />
            ))}
          </div>
          <section className="modal-card victory-card">
            <div className="victory-splash" aria-hidden="true"><i /><i /><i /><Waves /></div>
            <span className="eyebrow">Level {levelNumber} complete</span>
            <h2>Crystal Clear!</h2>
            <div className="victory-stars" aria-label={`${victory.stars} out of 3 stars`}>
              {[0, 1, 2].map((index) => (
                <Star key={index} className={index < victory.stars ? "earned" : ""} fill={index < victory.stars ? "currentColor" : "none"} style={{ animationDelay: `${0.18 + index * 0.15}s` }} />
              ))}
            </div>
            {newBest && <div className="new-best"><Trophy size={15} /> New personal best</div>}
            <div className="victory-score"><span>Score</span><strong>{victory.score.toLocaleString()}</strong></div>
            <div className="victory-details">
              <div><span>Moves</span><strong>{victory.moves}</strong><small>Par {definition.par}</small></div>
              <div><span>Time</span><strong>{formatTime(victory.seconds)}</strong><small>Active play</small></div>
              <div><span>Best</span><strong>{best?.bestMoves ?? victory.moves}</strong><small>{best?.bestScore.toLocaleString() ?? victory.score} pts</small></div>
            </div>
            <button
              className="primary-button wide"
              onClick={() => levelNumber < TOTAL_LEVELS ? onStartLevel(levelNumber + 1) : onExit()}
            >
              {levelNumber < TOTAL_LEVELS ? <>Next Level <ArrowRight size={19} /></> : <>All Levels <MapIcon size={18} /></>}
            </button>
            <div className="modal-button-row">
              <button className="secondary-button" onClick={resetGame}><RotateCcw size={17} /> Replay</button>
              <button className="secondary-button" onClick={onExit}><MapIcon size={17} /> All Levels</button>
            </div>
          </section>
        </div>
      )}
    </main>
  );
}
