import { useEffect, useRef, useState } from 'react';
import { Match } from '../game/match';
import type { Mode } from '../game/match';
import type { Difficulty } from '../game/bot';
import type { Settings } from '../game/settings';
import { draw, newView, pickJoint, updateView } from '../game/render';
import type { View } from '../game/render';
import { PARTS, STATE_COLORS, STATE_NAMES, HOLD, CONTRACT, EXTEND, RELAX, MAX_HP } from '../game/physics';
import { PRESETS } from '../game/presets';
import { initAudio, playBlip } from '../game/audio';
import { cn } from '../utils/cn';

interface Props {
  mode: Mode;
  difficulty: Difficulty;
  settings: Settings;
  onExit: () => void;
  onRematch: () => void;
  onResult: (winner: number, damageDealt: number) => void;
}

const STATE_BTN: { s: number; label: string; icon: string; cls: string; active: string }[] = [
  { s: CONTRACT, label: 'Contract', icon: '⇲', cls: 'border-red-500/60 text-red-300', active: 'bg-red-500 text-white border-red-300' },
  { s: EXTEND, label: 'Extend', icon: '⇱', cls: 'border-green-500/60 text-green-300', active: 'bg-green-500 text-white border-green-300' },
  { s: HOLD, label: 'Hold', icon: '⏸', cls: 'border-yellow-400/60 text-yellow-200', active: 'bg-yellow-400 text-black border-yellow-200' },
  { s: RELAX, label: 'Relax', icon: '≋', cls: 'border-sky-400/60 text-sky-300', active: 'bg-sky-400 text-black border-sky-200' },
];

export default function GameScreen({ mode, difficulty, settings, onExit, onRematch, onResult }: Props) {
  const matchRef = useRef<Match | null>(null);
  if (!matchRef.current) matchRef.current = new Match(mode, difficulty, settings);
  const match = matchRef.current;

  const [, force] = useState(0);
  const [paused, setPaused] = useState(false);
  const [showHelp, setShowHelp] = useState(true);
  const pausedRef = useRef(false);
  pausedRef.current = paused;

  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const viewRef = useRef<View>(newView());
  const resultRef = useRef(onResult);
  resultRef.current = onResult;

  // ---------------------------------------------------------------- loop
  useEffect(() => {
    match.disposed = false;
    match.changed = () => force((n) => n + 1);
    match.finished = (winner) => {
      const dealt = Math.round(match.sim.fighters[1].damage);
      resultRef.current(winner, dealt);
    };
    const canvas = canvasRef.current!;
    const wrap = wrapRef.current!;
    const ctx = canvas.getContext('2d')!;
    const view = viewRef.current;
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    let t = 0;

    const resize = () => {
      const r = wrap.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      canvas.width = Math.max(1, Math.floor(r.width * dpr));
      canvas.height = Math.max(1, Math.floor(r.height * dpr));
      canvas.style.width = r.width + 'px';
      canvas.style.height = r.height + 'px';
      view.w = r.width;
      view.h = r.height;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      t += dt;
      if (!pausedRef.current) match.update(dt);
      updateView(view, match.sim, dt);

      const ph = match.phase;
      let markers: [number, number] = [0, 0];
      if (ph === 'plan') {
        if (match.mode === 'local') markers = match.planner === 0 ? [1, 0] : [0, 1];
        else markers = [1, match.mode === 'practice' ? 0.35 : 0];
      } else if (ph === 'sim' || ph === 'thinking') {
        markers = [0.45, match.mode === 'local' ? 0.45 : match.mode === 'practice' ? 0.25 : 0];
      }
      draw(ctx, {
        sim: match.sim,
        view,
        particles: match.particles,
        popups: match.popups,
        selected: match.selected,
        selectedFighter: match.mode === 'local' ? match.planner : 0,
        markers,
        shake: match.shake,
        time: t,
        dismemberOn: match.settings.dismember,
      });

      acc += dt;
      if (acc > 0.1) {
        acc = 0;
        force((n) => n + 1);
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      match.disposed = true;
    };
  }, [match]);

  // --------------------------------------------------------------- input
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const gesture = useRef({ sx: 0, sy: 0, moved: false, dist: 0, zoom: 1 });

  const local = (e: React.PointerEvent) => {
    const r = canvasRef.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  const onDown = (e: React.PointerEvent) => {
    initAudio();
    (e.target as Element).setPointerCapture?.(e.pointerId);
    const p = local(e);
    pointers.current.set(e.pointerId, p);
    const g = gesture.current;
    if (pointers.current.size === 1) {
      g.sx = p.x;
      g.sy = p.y;
      g.moved = false;
    } else if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      g.dist = Math.hypot(a.x - b.x, a.y - b.y);
      g.zoom = viewRef.current.zoom;
      g.moved = true;
    }
  };

  const onMove = (e: React.PointerEvent) => {
    const prev = pointers.current.get(e.pointerId);
    if (!prev) return;
    const p = local(e);
    pointers.current.set(e.pointerId, p);
    const g = gesture.current;
    const view = viewRef.current;
    if (pointers.current.size >= 2) {
      const [a, b] = [...pointers.current.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      if (g.dist > 0) view.zoom = Math.max(0.5, Math.min(3, (g.zoom * d) / g.dist));
    } else {
      if (!g.moved && Math.hypot(p.x - g.sx, p.y - g.sy) > 10) g.moved = true;
      if (g.moved) {
        view.panX += p.x - prev.x;
        view.panY += p.y - prev.y;
      }
    }
  };

  const onUp = (e: React.PointerEvent) => {
    const wasOnly = pointers.current.size === 1;
    const p = pointers.current.get(e.pointerId);
    pointers.current.delete(e.pointerId);
    if (!p || !wasOnly) return;
    const g = gesture.current;
    if (g.moved) return;
    if (match.phase !== 'plan' || paused) return;
    const fi = match.mode === 'local' ? match.planner : 0;
    const j = pickJoint(match.sim, fi, viewRef.current, p.x, p.y, 30);
    if (j !== null) {
      setShowHelp(false);
      playBlip(440, match.settings.sound, 0.03, 'sine');
      match.select(j === match.selected ? null : j);
    } else {
      match.select(null);
    }
  };

  const onWheel = (e: React.WheelEvent) => {
    const v = viewRef.current;
    v.zoom = Math.max(0.5, Math.min(3, v.zoom * (e.deltaY < 0 ? 1.1 : 0.9)));
  };

  const recenter = () => {
    const v = viewRef.current;
    v.zoom = 1;
    v.panX = 0;
    v.panY = 0;
  };

  // ----------------------------------------------------------------- UI
  const plan = match.phase === 'plan';
  const f = match.activeFighter;
  const sel = match.selected;
  const selPart = sel !== null ? PARTS[sel] : null;
  const isHand = selPart?.kind === 'hand';
  const gripOn = isHand && sel !== null ? f.grip[selPart!.side - 1] : false;

  const names =
    mode === 'bot'
      ? ['You', `Bot · ${difficulty[0].toUpperCase() + difficulty.slice(1)}`]
      : mode === 'local'
        ? ['Player 1', 'Player 2']
        : ['You', 'Dummy'];

  const hp0 = match.hp(0);
  const hp1 = match.hp(1);
  const d0 = Math.round(match.sim.fighters[0].damage);
  const d1 = Math.round(match.sim.fighters[1].damage);

  const timerPct = match.timed ? match.timeLeft / match.settings.turnTime : 1;

  return (
    <div className="fixed inset-0 flex touch-none select-none flex-col bg-black text-white landscape:flex-row">
      {/* ---------------- arena ---------------- */}
      <div ref={wrapRef} className="relative min-h-0 min-w-0 flex-1 overflow-hidden">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 touch-none"
          onPointerDown={onDown}
          onPointerMove={onMove}
          onPointerUp={onUp}
          onPointerCancel={onUp}
          onWheel={onWheel}
        />

        {/* HUD */}
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start gap-2 p-2">
          <HpBar name={names[0]} hp={hp0} dmg={d1} color="from-blue-500 to-sky-300" active={plan && (mode !== 'local' || match.planner === 0)} />
          <div className="flex w-20 shrink-0 flex-col items-center">
            <div className="rounded-md bg-black/60 px-2 py-0.5 text-[11px] font-bold tracking-widest text-white/80">
              {mode === 'practice' ? `TURN ${match.turn}` : `TURN ${match.turn}/${match.totalTurns}`}
            </div>
            {match.timed && plan && (
              <div
                className={cn(
                  'mt-1 flex h-9 w-9 items-center justify-center rounded-full border-2 text-sm font-black',
                  match.timeLeft <= 5 ? 'animate-pulse border-red-500 bg-red-900/70 text-red-300' : 'border-white/40 bg-black/60'
                )}
                style={{ background: `conic-gradient(rgba(250,204,21,0.55) ${timerPct * 360}deg, rgba(0,0,0,0.6) 0deg)` }}
              >
                <span className="rounded-full bg-black/70 px-1">{Math.ceil(match.timeLeft)}</span>
              </div>
            )}
          </div>
          <HpBar name={names[1]} hp={hp1} dmg={d0} color="from-red-500 to-orange-300" right active={plan && mode === 'local' && match.planner === 1} />
        </div>

        {/* side buttons */}
        <div className="absolute left-2 top-14 flex flex-col gap-2">
          <IconBtn onClick={() => setPaused(true)} label="Pause">
            ❚❚
          </IconBtn>
          <IconBtn onClick={recenter} label="Recenter camera">
            ⌖
          </IconBtn>
        </div>

        {mode === 'practice' && (
          <div className="absolute right-2 top-14 flex flex-col gap-2">
            <IconBtn onClick={() => match.resetPractice()} label="Reset">
              ↺
            </IconBtn>
            <IconBtn onClick={() => match.setDummyRelaxed(!(match.sim.fighters[1].state[1] === RELAX))} label="Toggle dummy ragdoll">
              🎭
            </IconBtn>
          </div>
        )}

        {/* hint */}
        {plan && sel === null && showHelp && (
          <div className="pointer-events-none absolute inset-x-0 bottom-3 flex justify-center px-6">
            <div className="animate-pulse rounded-full bg-black/70 px-4 py-2 text-center text-xs font-semibold text-yellow-200 ring-1 ring-yellow-300/40">
              Tap a glowing joint ● on your fighter · drag to pan · pinch to zoom
            </div>
          </div>
        )}

        {match.phase === 'sim' && (
          <div className="pointer-events-none absolute inset-x-0 bottom-2 flex justify-center">
            <div className="rounded-full bg-black/55 px-3 py-1 text-[11px] font-bold tracking-[0.25em] text-white/80">
              {match.slowTimer > 0 ? 'IMPACT' : 'FIGHT'}
            </div>
          </div>
        )}

        {/* thinking */}
        {match.phase === 'thinking' && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/30">
            <div className="flex items-center gap-3 rounded-xl bg-black/70 px-5 py-3 text-sm font-semibold ring-1 ring-white/20">
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-red-400" />
              Opponent is planning…
            </div>
          </div>
        )}

        {/* hot-seat handoff */}
        {match.phase === 'handoff' && (
          <button
            onClick={() => match.continueHandoff()}
            className={cn(
              'absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/85 backdrop-blur-sm',
              match.handoffTo === 0 ? 'text-sky-300' : 'text-red-300'
            )}
          >
            <div className="text-xs font-bold tracking-[0.4em] text-white/60">PASS THE PHONE</div>
            <div className="text-4xl font-black">PLAYER {match.handoffTo + 1}</div>
            <div className="rounded-full border border-white/30 px-5 py-2 text-sm font-semibold text-white">Tap when ready</div>
          </button>
        )}

        {/* result */}
        {match.phase === 'over' && (
          <Result match={match} names={names} mode={mode} onRematch={onRematch} onExit={onExit} />
        )}

        {/* pause */}
        {paused && (
          <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/80 p-6 backdrop-blur-sm">
            <div className="w-full max-w-xs space-y-3 rounded-2xl bg-slate-900 p-5 ring-1 ring-white/10">
              <div className="text-center text-xl font-black tracking-widest">PAUSED</div>
              <BigBtn onClick={() => setPaused(false)} cls="bg-green-500 text-black">
                Resume
              </BigBtn>
              <BigBtn
                onClick={() => {
                  setPaused(false);
                  onRematch();
                }}
                cls="bg-slate-700"
              >
                Restart
              </BigBtn>
              <BigBtn onClick={onExit} cls="bg-red-600">
                Quit to menu
              </BigBtn>
            </div>
          </div>
        )}
      </div>

      {/* ---------------- control panel ---------------- */}
      <div className="flex shrink-0 flex-col gap-2 border-white/10 bg-slate-950 p-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] border-t landscape:w-60 landscape:justify-center landscape:overflow-y-auto landscape:border-l landscape:border-t-0 landscape:pr-[max(0.5rem,env(safe-area-inset-right))]">
        {plan ? (
          <>
            {/* joint header */}
            <div className="flex h-6 items-center justify-between px-1 text-xs">
              {selPart && sel !== null ? (
                <>
                  <span className="font-bold text-white">{selPart.joint!.name}</span>
                  <span className="font-semibold" style={{ color: STATE_COLORS[f.state[sel]] }}>
                    {STATE_NAMES[f.state[sel]]}
                  </span>
                </>
              ) : (
                <span className="text-white/50">
                  {mode === 'local' ? `Player ${match.planner + 1}: ` : ''}Select a joint, or pick a move
                </span>
              )}
            </div>

            {/* state buttons */}
            <div className="grid grid-cols-4 gap-1.5 landscape:grid-cols-2">
              {STATE_BTN.map((b) => (
                <button
                  key={b.s}
                  disabled={sel === null}
                  onClick={() => sel !== null && match.setState(sel, b.s)}
                  className={cn(
                    'flex h-11 items-center justify-center gap-1 rounded-lg border text-[13px] font-bold transition active:scale-95 disabled:opacity-30',
                    sel !== null && f.state[sel] === b.s ? b.active : 'bg-slate-900 ' + b.cls
                  )}
                >
                  <span className="text-base leading-none">{b.icon}</span>
                  {b.label}
                </button>
              ))}
            </div>

            {isHand && sel !== null && (
              <button
                onClick={() => match.toggleGrip(sel)}
                className={cn(
                  'h-10 rounded-lg border text-[13px] font-bold active:scale-95',
                  gripOn ? 'border-amber-200 bg-amber-400 text-black' : 'border-amber-400/60 bg-slate-900 text-amber-300'
                )}
              >
                ✊ Grip: {gripOn ? 'ON' : 'OFF'}
              </button>
            )}

            {/* presets */}
            <div className="-mx-0.5 flex gap-1.5 overflow-x-auto px-0.5 pb-0.5 [scrollbar-width:none]">
              {PRESETS.map((p) => (
                <button
                  key={p.id}
                  onClick={() => match.applyPreset(p)}
                  title={p.desc}
                  className="flex h-12 min-w-[54px] shrink-0 flex-col items-center justify-center rounded-lg bg-slate-800 px-1 text-[10px] font-semibold text-white/85 ring-1 ring-white/10 active:scale-95 active:bg-slate-700"
                >
                  <span className="text-lg leading-none">{p.icon}</span>
                  {p.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => {
                initAudio();
                match.commit();
              }}
              className="h-12 rounded-xl bg-gradient-to-b from-green-400 to-green-600 text-base font-black tracking-widest text-black shadow-lg shadow-green-900/50 active:scale-[0.98]"
            >
              READY ▶
            </button>
          </>
        ) : (
          <div className="flex flex-col gap-2">
            <div className="px-1 text-center text-xs font-semibold text-white/60">
              {match.phase === 'sim' ? 'Turn in progress…' : match.phase === 'thinking' ? 'Bot is thinking…' : ''}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                disabled={match.phase !== 'sim'}
                onClick={() => match.cycleSpeed()}
                className="h-11 rounded-lg bg-slate-800 text-sm font-bold ring-1 ring-white/10 active:scale-95 disabled:opacity-40"
              >
                Speed {match.speed}×
              </button>
              <button
                disabled={match.phase !== 'sim'}
                onClick={() => match.skipTurn()}
                className="h-11 rounded-lg bg-slate-800 text-sm font-bold ring-1 ring-white/10 active:scale-95 disabled:opacity-40"
              >
                Skip ⏭
              </button>
            </div>
            <div className="hidden text-[11px] leading-snug text-white/40 landscape:block">
              Joints: <b className="text-red-300">contract</b>, <b className="text-green-300">extend</b>, <b className="text-yellow-200">hold</b>,{' '}
              <b className="text-sky-300">relax</b>. Hit the opponent's head, torso and groin for damage.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ pieces
function HpBar({ name, hp, dmg, color, right, active }: { name: string; hp: number; dmg: number; color: string; right?: boolean; active?: boolean }) {
  return (
    <div className={cn('min-w-0 flex-1', right && 'text-right')}>
      <div className={cn('flex items-baseline gap-2 text-[11px] font-bold', right ? 'flex-row-reverse' : '')}>
        <span className={cn('truncate drop-shadow', active ? 'text-white' : 'text-white/70')}>{name}</span>
        <span className="text-[10px] font-semibold text-amber-300/90">{dmg > 0 ? `${dmg} pts` : ''}</span>
      </div>
      <div className={cn('mt-0.5 h-3 overflow-hidden rounded-full bg-black/60 ring-1 ring-white/25', active && 'ring-yellow-300')}>
        <div
          className={cn('h-full rounded-full bg-gradient-to-r transition-all duration-300', color, right && 'ml-auto')}
          style={{ width: `${Math.max(0, hp * 100)}%` }}
        />
      </div>
    </div>
  );
}

function IconBtn({ onClick, children, label }: { onClick: () => void; children: React.ReactNode; label: string }) {
  return (
    <button
      aria-label={label}
      onClick={onClick}
      onPointerDown={(e) => e.stopPropagation()}
      className="flex h-10 w-10 items-center justify-center rounded-full bg-black/55 text-base font-bold text-white ring-1 ring-white/25 active:scale-90"
    >
      {children}
    </button>
  );
}

function BigBtn({ onClick, children, cls }: { onClick: () => void; children: React.ReactNode; cls: string }) {
  return (
    <button onClick={onClick} className={cn('h-12 w-full rounded-xl text-base font-bold active:scale-[0.98]', cls)}>
      {children}
    </button>
  );
}

function Result({ match, names, mode, onRematch, onExit }: { match: Match; names: string[]; mode: Mode; onRematch: () => void; onExit: () => void }) {
  const w = match.winner;
  let title = 'DRAW';
  let color = 'text-white';
  if (w === 0) {
    title = mode === 'local' ? 'PLAYER 1 WINS' : 'VICTORY';
    color = 'text-sky-300';
  } else if (w === 1) {
    title = mode === 'local' ? 'PLAYER 2 WINS' : 'DEFEAT';
    color = 'text-red-400';
  }
  const fs = match.sim.fighters;
  return (
    <div className="absolute inset-0 z-10 flex items-center justify-center overflow-y-auto bg-black/80 p-4 backdrop-blur-sm">
      <div className="w-full max-w-sm space-y-3 rounded-2xl bg-slate-900/95 p-5 text-center ring-1 ring-white/10">
        <div className="text-[11px] font-bold tracking-[0.4em] text-white/50">{match.endReason.toUpperCase()}</div>
        <div className={cn('text-4xl font-black tracking-wide', color)}>{title}</div>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="rounded-lg bg-blue-500/15 p-2 ring-1 ring-blue-400/30">
            <div className="text-xs text-blue-200">{names[0]}</div>
            <div className="text-2xl font-black">{Math.round(fs[1].damage)}</div>
            <div className="text-[10px] uppercase tracking-wider text-white/40">damage dealt</div>
          </div>
          <div className="rounded-lg bg-red-500/15 p-2 ring-1 ring-red-400/30">
            <div className="text-xs text-red-200">{names[1]}</div>
            <div className="text-2xl font-black">{Math.round(fs[0].damage)}</div>
            <div className="text-[10px] uppercase tracking-wider text-white/40">damage dealt</div>
          </div>
        </div>
        <div className="text-[11px] text-white/40">Knock-out at {MAX_HP} damage</div>
        <BigBtn onClick={onRematch} cls="bg-green-500 text-black">
          Rematch
        </BigBtn>
        <BigBtn onClick={onExit} cls="bg-slate-700">
          Main menu
        </BigBtn>
      </div>
    </div>
  );
}
