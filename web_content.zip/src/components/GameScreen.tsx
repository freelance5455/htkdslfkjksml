import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowRight,
  RotateCcw,
  CheckCheck,
  Trophy,
  ArrowLeftRight,
  ListFilter,
  ZoomIn,
  ZoomOut,
  Eye,
  Play,
  Sparkles,
  Star,
  Lightbulb,
} from 'lucide-react';
import { Stage, Direction, GridCell, GridPosition } from '../types/crossword';
import { CrosswordEngine } from '../engine/CrosswordEngine';
import { CrosswordGrid } from './CrosswordGrid';
import { InAppKeyboard } from './InAppKeyboard';
import { convertToArabicNumerals } from '../data/sampleStages';
import { soundManager } from '../utils/audio';

interface GameScreenProps {
  stage: Stage;
  savedAnswers: { [cellKey: string]: string };
  savedHintsUsed?: number;
  bestStars?: number;
  onBack: () => void;
  onSaveProgress: (
    stageId: number,
    answers: { [cellKey: string]: string },
    completedQuestionIds: string[],
    isCompleted: boolean,
    hintsUsed: number
  ) => void;
  onNextStage?: () => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({
  stage,
  savedAnswers,
  savedHintsUsed = 0,
  bestStars,
  onBack,
  onSaveProgress,
  onNextStage,
}) => {
  const engineRef = useRef<CrosswordEngine>(new CrosswordEngine());

  const [grid, setGrid] = useState<GridCell[][]>([]);
  const [selectedPos, setSelectedPos] = useState<GridPosition | null>(null);
  const [selectedWordId, setSelectedWordId] = useState<string | null>(null);
  const [activeDirection, setActiveDirection] = useState<Direction>('horizontal');
  const [showQuestionsList, setShowQuestionsList] = useState<boolean>(false);
  const [checkResult, setCheckResult] = useState<{
    wordNumber?: number;
    wordDirection?: Direction;
    isWordCorrect: boolean;
    correctCount: number;
    incorrectCount: number;
    emptyCount: number;
    totalLetters: number;
  } | null>(null);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [showVictoryModal, setShowVictoryModal] = useState<boolean>(false);
  const [isZoomEnabled, setIsZoomEnabled] = useState<boolean>(false);

  // Hints & Stars State
  const [hintsUsed, setHintsUsed] = useState<number>(savedHintsUsed);
  const [hintConfirmQuestionId, setHintConfirmQuestionId] = useState<string | null>(null);
  const [hintNotification, setHintNotification] = useState<string | null>(null);

  // Initialize engine state
  useEffect(() => {
    engineRef.current = new CrosswordEngine();
    engineRef.current.loadStage(stage, savedAnswers);
    updateEngineState();
    const completed = engineRef.current.isStageCompleted();
    setIsCompleted(completed);
    setShowVictoryModal(completed);
    setHintsUsed(savedHintsUsed);
  }, [stage.id]);

  const updateEngineState = () => {
    const engine = engineRef.current;
    setGrid([...engine.getGrid().map((row) => [...row])]);
    setSelectedPos(engine.getSelectedPos());
    setSelectedWordId(engine.getSelectedWordId());
    setActiveDirection(engine.getActiveDirection());
  };

  const persistCurrentProgress = (overrideHintsUsed?: number) => {
    const engine = engineRef.current;
    const currentAnswers = engine.getUserAnswers();
    const completedQuestionIds = engine.getCompletedQuestionIds();
    const completed = engine.isStageCompleted();
    const currentHintsUsed = overrideHintsUsed !== undefined ? overrideHintsUsed : hintsUsed;

    // Check if whole stage was just finished
    if (completed && !isCompleted) {
      soundManager.playVictory();
      setShowVictoryModal(true);
    }

    setIsCompleted(completed);
    onSaveProgress(stage.id, currentAnswers, completedQuestionIds, completed, currentHintsUsed);
  };

  // Interactions
  const handleCellClick = (row: number, col: number) => {
    const engine = engineRef.current;
    engine.selectCell(row, col);
    updateEngineState();
    setCheckResult(null);
  };

  const handleKeyPress = (char: string) => {
    const engine = engineRef.current;
    engine.typeChar(char);
    updateEngineState();
    setCheckResult(null);
    persistCurrentProgress();
  };

  const handleDelete = () => {
    const engine = engineRef.current;
    engine.deleteChar();
    updateEngineState();
    setCheckResult(null);
    persistCurrentProgress();
  };

  const handleSetDirection = (dir: Direction) => {
    soundManager.playSelectCell();
    const engine = engineRef.current;
    engine.setDirection(dir);
    updateEngineState();
  };

  const handleToggleDirection = () => {
    soundManager.playSelectCell();
    const engine = engineRef.current;
    engine.toggleDirection();
    updateEngineState();
  };

  const handleSelectQuestion = (questionId: string) => {
    soundManager.playSelectCell();
    const engine = engineRef.current;
    engine.selectQuestion(questionId);
    updateEngineState();
    setShowQuestionsList(false);
    setCheckResult(null);
  };

  const handleCheckWord = () => {
    const engine = engineRef.current;
    const result = engine.checkCurrentWord();
    if (!result) return;
    setGrid([...engine.getGrid().map((row) => [...row])]);
    setCheckResult(result);
    if (result.isWordCorrect) {
      soundManager.playWordComplete();
    } else {
      soundManager.vibrate([40, 50, 40]);
    }
    persistCurrentProgress();
  };

  // Request Hint for a chosen word
  const handleRequestHint = (questionId?: string) => {
    soundManager.playButtonClick();
    const targetQId = questionId || selectedWordId;
    if (!targetQId) {
      setHintNotification('الرجاء اختيار سؤال أو كلمة أولاً لاستخدام المساعدة عليها.');
      return;
    }

    const engine = engineRef.current;
    if (engine.isQuestionCompleted(targetQId)) {
      setHintNotification('هذه الكلمة محلولة بالكامل بالفعل، لا حاجة للمساعدة!');
      return;
    }

    if (hintsUsed >= 3) {
      setHintNotification('لقد استنفدت جميع المساعدات الثلاث المتاحة لهذه المرحلة.');
      return;
    }

    // Open confirmation dialog
    setHintConfirmQuestionId(targetQId);
  };

  // Confirm Hint Execution: reveal word & deduct 1 star permanently for this run
  const handleConfirmHint = () => {
    if (!hintConfirmQuestionId) return;
    const targetQId = hintConfirmQuestionId;
    setHintConfirmQuestionId(null);

    const engine = engineRef.current;
    const success = engine.revealWord(targetQId);
    if (success) {
      const newHintsUsed = hintsUsed + 1;
      setHintsUsed(newHintsUsed);
      soundManager.playHint();
      updateEngineState();
      persistCurrentProgress(newHintsUsed);

      const targetQ = stage.questions.find((q) => q.id === targetQId);
      const remainingStars = Math.max(0, 3 - newHintsUsed);
      setHintNotification(
        `تم كشف الكلمة "${targetQ?.answer || ''}" بالكامل! المتبقي: ${convertToArabicNumerals(remainingStars)} نجوم و${convertToArabicNumerals(3 - newHintsUsed)} مساعدات.`
      );
    }
  };

  const handleCancelHint = () => {
    soundManager.playButtonClick();
    setHintConfirmQuestionId(null);
  };

  const handleResetStage = () => {
    soundManager.playButtonClick();
    const engine = engineRef.current;
    engine.resetStage();
    updateEngineState();
    setCheckResult(null);
    setIsCompleted(false);
    setShowVictoryModal(false);
    setHintsUsed(0);
    persistCurrentProgress(0);
  };

  const handleViewSolvedGrid = () => {
    soundManager.playButtonClick();
    const engine = engineRef.current;
    engine.fillSolution();
    updateEngineState();
    setShowVictoryModal(false);
  };

  const handleReplayStage = () => {
    soundManager.playButtonClick();
    const engine = engineRef.current;
    engine.resetStage();
    updateEngineState();
    setCheckResult(null);
    setIsCompleted(false);
    setShowVictoryModal(false);
    setHintsUsed(0);
    persistCurrentProgress(0);
  };

  const handleToggleZoom = () => {
    setIsZoomEnabled((prev) => !prev);
  };

  // Get currently selected question
  const engine = engineRef.current;
  const currentQuestion = engine.getSelectedQuestion();
  const completedQuestionsCount = engine.getCompletedQuestionIds().length;

  // Live star calculation: 3 - hintsUsed (minimum 0)
  const currentStars = Math.max(0, 3 - Math.min(3, hintsUsed));
  const remainingHints = Math.max(0, 3 - hintsUsed);

  // Questions for direction tabs
  const horizontalQuestions = stage.questions.filter((q) => q.direction === 'horizontal');
  const verticalQuestions = stage.questions.filter((q) => q.direction === 'vertical');
  const activeQuestionsList = activeDirection === 'horizontal' ? horizontalQuestions : verticalQuestions;

  // Selected question completion status
  const isCurrentQuestionCompleted = currentQuestion ? engine.isQuestionCompleted(currentQuestion.id) : false;

  // Confirmation question object
  const confirmQuestionObj = hintConfirmQuestionId
    ? stage.questions.find((q) => q.id === hintConfirmQuestionId)
    : null;

  return (
    <div className="flex-1 flex flex-col justify-between w-full max-w-lg mx-auto h-full overflow-hidden select-none bg-[#fdfbf7]">
      {/* 1. TOP BAR */}
      <header className="w-full bg-[#ede9e1] border-b-2 border-[#2c2c2c] newspaper-border-double px-2 py-1 flex items-center justify-between gap-1 shadow-xs z-10 shrink-0">
        <button
          type="button"
          onClick={onBack}
          className="p-1 sm:p-1.5 rounded-xs hover:bg-[#e6d5b8] active:bg-[#2c2c2c] active:text-[#fdfbf7] text-[#1a1a1a] flex items-center gap-1 font-bold text-xs sm:text-sm transition-colors border border-transparent hover:border-[#2c2c2c]"
          aria-label="رجوع"
        >
          <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
          <span className="hidden xs:inline">الرئيسية</span>
        </button>

        {/* Stage Title, Stars, and Question Counter */}
        <div className="text-center flex flex-col items-center">
          <h2 className="newspaper-font text-base sm:text-lg font-bold text-[#1a1a1a] leading-tight">
            {stage.title}
          </h2>
          <div className="flex items-center gap-2">
            {/* Live 3 Stars Display */}
            <div className="flex items-center gap-0.5" style={{ direction: 'ltr' }}>
              {[1, 2, 3].map((starIdx) => (
                <Star
                  key={starIdx}
                  className={`w-3.5 h-3.5 transition-all ${
                    starIdx <= currentStars
                      ? 'fill-[#d97706] text-[#b45309]'
                      : 'text-[#2c2c2c]/30 fill-transparent'
                  }`}
                />
              ))}
            </div>
            <span className="text-[10px] text-[#2c2c2c]/40 font-mono">•</span>
            <div className="text-[10px] sm:text-xs font-semibold text-[#2c2c2c]">
              الإنجاز: {convertToArabicNumerals(completedQuestionsCount)} / {convertToArabicNumerals(25)}
            </div>
          </div>
        </div>

        {/* Action Controls: Hint, Check, Zoom Toggle, Reset */}
        <div className="flex items-center gap-1">
          {/* Main Hint Button with Remaining Count */}
          <button
            type="button"
            onClick={() => handleRequestHint()}
            disabled={remainingHints === 0 || isCurrentQuestionCompleted}
            title={
              remainingHints === 0
                ? 'استنفدت جميع المساعدات (٠ مساعدات متبقية)'
                : isCurrentQuestionCompleted
                ? 'الكلمة الحالية محلولة بالفعل'
                : `استخدام مساعدة لكشف الكلمة (${convertToArabicNumerals(remainingHints)} متبقية)`
            }
            className={`py-1 px-1.5 sm:px-2 rounded-xs border font-bold text-xs flex items-center gap-1 touch-manipulation transition-all ${
              remainingHints === 0 || isCurrentQuestionCompleted
                ? 'opacity-40 bg-[#ede9e1] border-[#8a8578] text-[#8a8578] cursor-not-allowed'
                : 'bg-[#d8d3c5] hover:bg-[#e6d5b8] active:bg-[#2c2c2c] active:text-[#fdfbf7] text-[#1a1a1a] border-[#2c2c2c] shadow-2xs'
            }`}
          >
            <Lightbulb className={`w-3.5 h-3.5 ${remainingHints > 0 ? 'text-[#b45309] fill-[#d97706]' : ''}`} />
            <span className="text-[11px] font-bold">مساعدة</span>
            <span className="bg-[#2c2c2c] text-[#fdfbf7] text-[9px] px-1 py-0.2 rounded-full min-w-[14px] text-center font-mono">
              {convertToArabicNumerals(remainingHints)}
            </span>
          </button>

          {/* Zoom Toggle Lock Button */}
          <button
            type="button"
            onClick={handleToggleZoom}
            title={isZoomEnabled ? 'إلغاء التكبير والعودة للحجم الطبيعي' : 'تفعيل تكبير الشبكة'}
            className={`py-1 px-1.5 rounded-xs border font-bold text-xs flex items-center gap-1 touch-manipulation transition-colors ${
              isZoomEnabled
                ? 'bg-[#1a1a1a] text-[#fdfbf7] border-[#1a1a1a] ring-1 ring-[#1a1a1a]'
                : 'bg-[#fdfbf7] hover:bg-[#e6d5b8] text-[#1a1a1a] border-[#2c2c2c]'
            }`}
          >
            {isZoomEnabled ? (
              <>
                <ZoomOut className="w-3.5 h-3.5 text-[#e6d5b8]" />
                <span className="text-[10px] hidden sm:inline">الحجم الأصلي</span>
              </>
            ) : (
              <>
                <ZoomIn className="w-3.5 h-3.5" />
                <span className="text-[10px] hidden sm:inline">تكبير</span>
              </>
            )}
          </button>

          {/* Check Current Word Button */}
          <button
            type="button"
            onClick={handleCheckWord}
            title="تحقق من الكلمة المحددة حالياً"
            className="py-1 px-2 bg-[#fdfbf7] hover:bg-[#e6d5b8] active:bg-[#2c2c2c] active:text-[#fdfbf7] text-[#1a1a1a] rounded-xs border border-[#2c2c2c] font-bold text-xs flex items-center gap-1 touch-manipulation transition-colors"
          >
            <CheckCheck className="w-3.5 h-3.5 text-[#1c4d1f]" />
            <span className="hidden sm:inline">تحقق</span>
          </button>

          {/* Reset / Replay Stage Button */}
          <button
            type="button"
            onClick={handleResetStage}
            title="إعادة لعب المرحلة من البداية (استعادة النجوم والمساعدات)"
            className="p-1.5 bg-[#fce8e8] hover:bg-[#f8d0d0] text-[#7a1c1c] rounded-xs border border-[#7a1c1c] transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Check Word Result Banner if triggered */}
      {checkResult && (
        <div
          className={`py-1.5 px-3 text-center text-xs font-bold flex items-center justify-between shrink-0 border-b ${
            checkResult.isWordCorrect
              ? 'bg-[#dfebd9] text-[#1c4d1f] border-[#2d6130]'
              : checkResult.emptyCount === checkResult.totalLetters
              ? 'bg-[#ede9e1] text-[#2c2c2c] border-[#2c2c2c]'
              : 'bg-[#fce8e8] text-[#7a1c1c] border-[#7a1c1c]'
          }`}
        >
          <span className="newspaper-font text-xs">
            {checkResult.isWordCorrect ? (
              <>
                ✓ الكلمة رقم {convertToArabicNumerals(checkResult.wordNumber || 0)} ({checkResult.wordDirection === 'horizontal' ? 'أفقي' : 'عمودي'}) صحيحة بالكامل!
              </>
            ) : checkResult.emptyCount === checkResult.totalLetters ? (
              <>
                الرجاء إدخال أحرف الكلمة رقم {convertToArabicNumerals(checkResult.wordNumber || 0)} أولاً للتحقق منها.
              </>
            ) : (
              <>
                الكلمة رقم {convertToArabicNumerals(checkResult.wordNumber || 0)}: {convertToArabicNumerals(checkResult.correctCount)} حرف صحيح من أصل {convertToArabicNumerals(checkResult.totalLetters)}
              </>
            )}
          </span>
          <button
            type="button"
            onClick={() => setCheckResult(null)}
            className="text-[10px] underline font-sans mr-2 hover:opacity-80"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* Hint Alert/Notification Banner if triggered */}
      {hintNotification && (
        <div className="py-1.5 px-3 text-center text-xs font-bold flex items-center justify-between shrink-0 border-b bg-[#fffbeb] text-[#92400e] border-[#b45309]/30">
          <span className="newspaper-font text-xs flex items-center gap-1.5">
            <Lightbulb className="w-3.5 h-3.5 fill-[#d97706] text-[#b45309] shrink-0" />
            <span>{hintNotification}</span>
          </span>
          <button
            type="button"
            onClick={() => setHintNotification(null)}
            className="text-[10px] underline font-sans mr-2 hover:opacity-80"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* 2. MAIN CROSSWORD GRID (Centered, complete, responsive 15x15) */}
      <div className="flex-1 flex flex-col justify-center items-center px-2 py-1 min-h-0 overflow-hidden w-full">
        <CrosswordGrid
          grid={grid}
          selectedPos={selectedPos}
          selectedWordId={selectedWordId}
          activeDirection={activeDirection}
          isZoomEnabled={isZoomEnabled}
          onCellClick={handleCellClick}
        />
      </div>

      {/* 3 & 4. BOTTOM INTERACTIVE AREA: (Clue Bar + Keyboard) OR (Full Questions List replacing both) */}
      <div className="w-full shrink-0 relative bg-[#ede9e1] border-t-2 border-[#2c2c2c] newspaper-border-double">
        {showQuestionsList ? (
          /* Full Questions List Drawer replacing both the Clue Banner & Keyboard */
          <div className="w-full h-[285px] sm:h-[310px] p-2.5 flex flex-col bg-[#fdfbf7] shadow-inner select-none animate-fade-in">
            {/* Header of Questions Drawer with Tabs and Close button */}
            <div className="flex items-center justify-between border-b-2 border-[#2c2c2c] pb-2 mb-2 px-1">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xs sm:text-sm text-[#1a1a1a]">قائمة الأسئلة:</span>
                <button
                  type="button"
                  onClick={() => handleSetDirection('horizontal')}
                  className={`py-1 px-3 text-xs font-bold rounded-xs border transition-all touch-manipulation ${
                    activeDirection === 'horizontal'
                      ? 'bg-[#1a1a1a] text-[#fdfbf7] border-[#1a1a1a]'
                      : 'bg-[#ede9e1] text-[#2c2c2c] border-[#2c2c2c] hover:bg-[#e6d5b8]'
                  }`}
                >
                  أفقي ({convertToArabicNumerals(horizontalQuestions.length)})
                </button>
                <button
                  type="button"
                  onClick={() => handleSetDirection('vertical')}
                  className={`py-1 px-3 text-xs font-bold rounded-xs border transition-all touch-manipulation ${
                    activeDirection === 'vertical'
                      ? 'bg-[#1a1a1a] text-[#fdfbf7] border-[#1a1a1a]'
                      : 'bg-[#ede9e1] text-[#2c2c2c] border-[#2c2c2c] hover:bg-[#e6d5b8]'
                  }`}
                >
                  عمودي ({convertToArabicNumerals(verticalQuestions.length)})
                </button>
              </div>

              <button
                type="button"
                onClick={() => setShowQuestionsList(false)}
                className="py-1 px-3 bg-[#2c2c2c] hover:bg-[#1a1a1a] active:bg-[#000] text-[#fdfbf7] rounded-xs font-bold text-xs flex items-center gap-1 transition-colors shadow-2xs touch-manipulation"
              >
                <span>لوحة المفاتيح</span>
                <span className="text-[10px] opacity-80">✕</span>
              </button>
            </div>

            {/* Scrollable Questions list */}
            <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-1.5 divide-y divide-[#2c2c2c]/15">
              {activeQuestionsList.map((q) => {
                const isSelected = selectedWordId === q.id;
                const isWordDone = engine.isQuestionCompleted(q.id);

                return (
                  <button
                    key={q.id}
                    type="button"
                    onClick={() => {
                      handleSelectQuestion(q.id);
                      setShowQuestionsList(false);
                    }}
                    className={`p-2.5 text-right w-full flex items-start justify-between gap-2.5 rounded-xs transition-colors touch-manipulation ${
                      isSelected
                        ? 'bg-[#e6d5b8] text-[#1a1a1a] border-2 border-[#2c2c2c] font-bold shadow-xs'
                        : 'bg-[#ede9e1]/50 hover:bg-[#e6d5b8]/70 text-[#1a1a1a] border border-transparent'
                    }`}
                  >
                    <div className="flex items-start gap-2.5 flex-1 min-w-0">
                      <span className={`font-bold text-xs min-w-[24px] h-[24px] rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                        isWordDone ? 'bg-[#1c4d1f] text-white border-[#1c4d1f]' : 'border-current'
                      }`}>
                        {convertToArabicNumerals(q.number)}
                      </span>
                      <span className="newspaper-font text-xs sm:text-sm font-bold pb-0.5 leading-relaxed text-right break-words">
                        {q.clue}
                      </span>
                    </div>
                    <div className="text-[10px] sm:text-xs opacity-85 shrink-0 flex flex-col items-end gap-1 mt-0.5">
                      <div className="flex items-center gap-1">
                        {isWordDone && (
                          <span className="text-[#1c4d1f] font-bold bg-[#dfebd9] px-1.5 py-0.2 rounded-xs">
                            محلولة ✓
                          </span>
                        )}
                        <span>({convertToArabicNumerals(q.length)} حروف)</span>
                      </div>
                      {q.reversed && (
                        <span className="text-[#8c2d19] font-bold bg-[#f6dcd6] px-1.5 py-0.5 rounded-xs">
                          معكوس
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          /* Normal View: Clue Bar + Keyboard */
          <>
            {/* Clue and Direction Bar */}
            <div className="w-full bg-[#f8f4ed] px-2.5 py-1.5 shadow-xs border-b border-[#2c2c2c]/30">
              <div className="flex items-center justify-between mb-1 gap-2 border-b border-[#2c2c2c]/20 pb-1">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleSetDirection('horizontal')}
                    className={`py-0.5 px-2.5 text-xs sm:text-sm font-bold rounded-xs border transition-all touch-manipulation ${
                      activeDirection === 'horizontal'
                        ? 'bg-[#1a1a1a] text-[#fdfbf7] border-[#1a1a1a] shadow-2xs'
                        : 'bg-[#ede9e1] text-[#2c2c2c] border-[#2c2c2c] hover:bg-[#e6d5b8]'
                    }`}
                  >
                    أفقي ({convertToArabicNumerals(horizontalQuestions.length)})
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetDirection('vertical')}
                    className={`py-0.5 px-2.5 text-xs sm:text-sm font-bold rounded-xs border transition-all touch-manipulation ${
                      activeDirection === 'vertical'
                        ? 'bg-[#1a1a1a] text-[#fdfbf7] border-[#1a1a1a] shadow-2xs'
                        : 'bg-[#ede9e1] text-[#2c2c2c] border-[#2c2c2c] hover:bg-[#e6d5b8]'
                    }`}
                  >
                    عمودي ({convertToArabicNumerals(verticalQuestions.length)})
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleToggleDirection()}
                    title="تغيير الاتجاه"
                    className="p-1 bg-[#ede9e1] border border-[#2c2c2c] rounded-xs hover:bg-[#e6d5b8] text-[#1a1a1a]"
                  >
                    <ArrowLeftRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowQuestionsList(true)}
                    className="py-0.5 px-2 bg-[#ede9e1] hover:bg-[#e6d5b8] active:bg-[#2c2c2c] active:text-[#fdfbf7] border border-[#2c2c2c] rounded-xs font-bold text-xs text-[#1a1a1a] flex items-center gap-1 transition-colors"
                  >
                    <ListFilter className="w-3.5 h-3.5" />
                    <span>الأسئلة</span>
                  </button>
                </div>
              </div>

              {/* Current Active Clue Banner with dynamic font sizing based on length */}
              {currentQuestion ? (() => {
                const clueLen = currentQuestion.clue.length;
                let clueFontClass = 'text-xs sm:text-sm leading-normal';
                if (clueLen > 120) {
                  clueFontClass = 'text-[10px] sm:text-xs leading-snug';
                }

                return (
                  <div className="bg-[#e6d5b8] border border-[#2c2c2c] px-2.5 py-1 rounded-xs text-right min-h-[46px] flex flex-col justify-center shadow-2xs">
                    <div className="flex items-center justify-between text-[10px] font-bold text-[#2c2c2c] leading-none shrink-0 mb-0.5">
                      <span>
                        سؤال رقم {convertToArabicNumerals(currentQuestion.number)} ({currentQuestion.direction === 'horizontal' ? 'أفقي' : 'عمودي'})
                        {isCurrentQuestionCompleted && (
                          <span className="mr-1.5 text-[#1c4d1f] bg-[#dfebd9] px-1 py-0.2 rounded-xs font-bold">
                            ✓ محلولة
                          </span>
                        )}
                      </span>
                      <span>
                        {convertToArabicNumerals(currentQuestion.length)} حروف {currentQuestion.reversed ? '• (معكوسة)' : ''}
                      </span>
                    </div>
                    <p className={`newspaper-font font-bold text-[#1a1a1a] ${clueFontClass} select-text`}>
                      {currentQuestion.clue}
                    </p>
                  </div>
                );
              })() : (
                <div className="bg-[#ede9e1] py-1.5 px-2.5 rounded-xs text-center text-xs text-[#2c2c2c] border border-[#2c2c2c]/30">
                  اضغط على أي خانة لعرض السؤال المتقاطع
                </div>
              )}
            </div>

            {/* In-App Keyboard */}
            <InAppKeyboard
              onKeyPress={handleKeyPress}
              onDelete={handleDelete}
              onSpace={() => {
                const engine = engineRef.current;
                engine.skipToNextCell();
                updateEngineState();
              }}
            />
          </>
        )}
      </div>

      {/* 5. HINT CONFIRMATION MODAL */}
      {hintConfirmQuestionId && confirmQuestionObj && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-[#f8f4ed] border-2 border-[#2c2c2c] newspaper-border-double p-5 rounded-xs max-w-sm w-full text-center shadow-2xl animate-fade-in">
            <div className="w-10 h-10 rounded-full bg-[#d8d3c5] border border-[#2c2c2c] flex items-center justify-center mx-auto mb-2 text-[#b45309]">
              <Lightbulb className="w-6 h-6 fill-[#d97706] text-[#b45309]" />
            </div>
            
            <h3 className="newspaper-font text-xl sm:text-2xl font-black text-[#1a1a1a] my-1">
              تأكيد استخدام المساعدة
            </h3>
            
            <div className="bg-[#ede9e1] border border-[#2c2c2c]/30 p-2.5 my-2.5 rounded-xs text-right text-xs">
              <div className="font-bold text-[#1a1a1a] mb-1">
                سؤال رقم {convertToArabicNumerals(confirmQuestionObj.number)} ({confirmQuestionObj.direction === 'horizontal' ? 'أفقي' : 'عمودي'}):
              </div>
              <p className="newspaper-font text-[#2c2c2c] leading-relaxed">
                {confirmQuestionObj.clue}
              </p>
            </div>

            <p className="text-xs text-[#7a1c1c] font-bold bg-[#fce8e8] border border-[#7a1c1c]/40 p-2 rounded-xs mb-4 leading-relaxed">
              ⚠️ تنبيه: سيتم كشف حروف هذه الكلمة بالكامل في الشبكة فوراً، و<span className="underline">سيتم خصم نجمة واحدة (⭐)</span> من تقييم هذه المرحلة ولا يمكن التراجع عن هذا الإجراء!
            </p>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleConfirmHint}
                className="flex-1 py-2.5 bg-[#1a1a1a] hover:bg-[#2c2c2c] active:bg-[#000] text-[#fdfbf7] font-bold text-sm rounded-xs border border-[#1a1a1a] shadow-xs transition-colors"
              >
                تأكيد وكشف الكلمة
              </button>
              <button
                type="button"
                onClick={handleCancelHint}
                className="py-2.5 px-4 bg-[#ede9e1] hover:bg-[#e6d5b8] text-[#1a1a1a] font-bold text-sm rounded-xs border border-[#2c2c2c] shadow-2xs transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. STAGE COMPLETED NEWSPAPER OVERLAY */}
      {showVictoryModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-[#f8f4ed] border-2 border-[#2c2c2c] newspaper-border-double p-5 sm:p-6 rounded-xs max-w-sm w-full text-center shadow-2xl animate-fade-in">
            <Trophy className="w-12 h-12 text-[#1a1a1a] mx-auto mb-1" />
            <div className="text-[10px] font-bold tracking-widest text-[#2c2c2c] uppercase border-t border-b border-[#2c2c2c]/30 py-0.5 my-1">
              خبر عاجل - طبعة ممتازة
            </div>
            <h3 className="newspaper-font text-2xl sm:text-3xl font-black text-[#1a1a1a] my-1">
              اكتملت المرحلة بنجاح!
            </h3>

            {/* Stars Earned in Victory Modal */}
            <div className="my-3 py-2 bg-[#ede9e1] border border-[#2c2c2c]/30 rounded-xs flex flex-col items-center">
              <div className="text-xs font-bold text-[#2c2c2c] mb-1">
                تقييم إنجازك في هذه المرحلة:
              </div>
              <div className="flex items-center justify-center gap-1.5 my-1" style={{ direction: 'ltr' }}>
                {[1, 2, 3].map((starIdx) => (
                  <Star
                    key={starIdx}
                    className={`w-7 h-7 drop-shadow-xs transition-all ${
                      starIdx <= currentStars
                        ? 'fill-[#d97706] text-[#b45309] scale-110'
                        : 'text-[#2c2c2c]/25 fill-transparent'
                    }`}
                  />
                ))}
              </div>
              <div className="text-[11px] font-semibold text-[#1a1a1a] mt-1">
                {currentStars === 3 && 'ممتاز جداً! أكملت المرحلة دون استخدام أي مساعدة ⭐⭐⭐'}
                {currentStars === 2 && 'رائع! أكملت المرحلة باستخدام مساعدة واحدة فقط ⭐⭐'}
                {currentStars === 1 && 'جيد! أكملت المرحلة باستخدام مساعدتين ⭐'}
                {currentStars === 0 && 'أكملت المرحلة باستخدام ٣ مساعدات (٠ نجوم)'}
              </div>
              {bestStars !== undefined && bestStars > currentStars && (
                <div className="text-[10px] text-[#2c2c2c]/70 mt-1">
                  (أفضل تقييم مسجل لك سابقاً: {convertToArabicNumerals(bestStars)} نجوم)
                </div>
              )}
            </div>

            <p className="text-xs text-[#2c2c2c] mb-3 font-serif leading-relaxed">
              {stage.id >= 50
                ? `تهانينا البالغة! لقد أتممت حل جميع أسئلة ${stage.title} وبذلك تكون قد أكملت اللعبة بجميع مراحلها الخمسين بنجاح باهر وإتقان تام!`
                : `تهانينا! لقد قمت بحل جميع أسئلة ${stage.title} بالكامل. تم فتح المرحلة التالية!`}
            </p>

            <div className="flex flex-col gap-2">
              {onNextStage && stage.id < 50 && (
                <button
                  type="button"
                  onClick={onNextStage}
                  className="w-full py-3 bg-[#1a1a1a] hover:bg-[#2c2c2c] active:bg-[#000] text-[#fdfbf7] font-bold text-base rounded-xs border border-[#1a1a1a] shadow-xs transition-colors flex items-center justify-center gap-2"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>المرحلة التالية ({convertToArabicNumerals(stage.id + 1)})</span>
                </button>
              )}

              {/* View Solved Grid Option */}
              <button
                type="button"
                onClick={handleViewSolvedGrid}
                className="w-full py-2 bg-[#fdfbf7] hover:bg-[#e6d5b8] text-[#1a1a1a] font-bold text-sm rounded-xs border border-[#2c2c2c] shadow-2xs transition-colors flex items-center justify-center gap-2"
              >
                <Eye className="w-4 h-4 text-[#1a1a1a]" />
                <span>عرض المرحلة وهي محلولة</span>
              </button>

              {/* Replay Stage Option - Only show 'تحسين النجوم' if currentStars < 3 */}
              {currentStars < 3 ? (
                <button
                  type="button"
                  onClick={handleReplayStage}
                  className="w-full py-2 bg-[#ede9e1] hover:bg-[#e6d5b8] text-[#1a1a1a] font-bold text-sm rounded-xs border border-[#2c2c2c] shadow-2xs transition-colors flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-4 h-4 text-[#1a1a1a]" />
                  <span>إعادة المرحلة من جديد لتحسين النجوم</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleReplayStage}
                  className="w-full py-2 bg-[#ede9e1] hover:bg-[#e6d5b8] text-[#1a1a1a] font-bold text-sm rounded-xs border border-[#2c2c2c] shadow-2xs transition-colors flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-4 h-4 text-[#1a1a1a]" />
                  <span>إعادة لعب المرحلة من جديد</span>
                </button>
              )}

              <button
                type="button"
                onClick={onBack}
                className="w-full py-2 bg-transparent hover:bg-[#ede9e1] text-[#2c2c2c] font-bold text-sm rounded-xs border border-[#2c2c2c]/40 transition-colors mt-0.5"
              >
                قائمة المراحل
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

