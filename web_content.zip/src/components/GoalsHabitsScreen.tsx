import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Goal, Habit } from '../types';
import {
  Target,
  Flame,
  CheckCircle2,
  Circle,
  Plus,
  Sparkles,
  Sun,
  Compass,
  BookOpen,
  Moon,
  TrendingUp,
  Award,
  ChevronRight,
  Heart,
} from 'lucide-react';
import { sound } from '../utils/sound';

export const GoalsHabitsScreen: React.FC = () => {
  const { goals, addGoal, updateGoalProgress, habits, addHabit, toggleHabit } = useApp();

  const [activeTab, setActiveTab] = useState<'habits' | 'goals'>('habits');
  const [isAddingGoal, setIsAddingGoal] = useState(false);
  const [isAddingHabit, setIsAddingHabit] = useState(false);

  // New goal form
  const [goalTitle, setGoalTitle] = useState('');
  const [goalTargetDate, setGoalTargetDate] = useState('');
  const [goalCategory, setGoalCategory] = useState('Personal');

  // New habit form
  const [habitTitle, setHabitTitle] = useState('');
  const [habitCategory, setHabitCategory] = useState<'health' | 'productivity' | 'mindfulness' | 'learning'>('health');

  const habitIcons: Record<string, any> = {
    Sun,
    Compass,
    BookOpen,
    Moon,
  };

  const completedHabits = habits.filter((h) => h.completedToday).length;
  const habitCompletionRate = Math.round((completedHabits / (habits.length || 1)) * 100);

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalTitle.trim()) return;
    addGoal({
      title: goalTitle.trim(),
      targetDate: goalTargetDate || 'Dec 2026',
      category: goalCategory,
      progressPercentage: 10,
      currentMilestone: 'Starting milestone #1',
      totalMilestones: 5,
      completedMilestones: 1,
      color: 'from-indigo-500 to-violet-600',
    });
    setGoalTitle('');
    setGoalTargetDate('');
    setIsAddingGoal(false);
  };

  const handleCreateHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!habitTitle.trim()) return;
    addHabit({
      title: habitTitle.trim(),
      frequency: 'Daily',
      targetDaysPerWeek: 7,
      category: habitCategory,
      icon: habitCategory === 'mindfulness' ? 'Compass' : habitCategory === 'learning' ? 'BookOpen' : 'Sun',
    });
    setHabitTitle('');
    setIsAddingHabit(false);
  };

  return (
    <div className="pb-24 pt-3 px-4 max-w-md mx-auto space-y-4">
      {/* 1. Header with Tab Switcher */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Goals & Habits
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Micro-habits lead to monumental achievements
          </p>
        </div>

        {/* Tab Toggle */}
        <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('habits');
            }}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'habits'
                ? 'bg-white dark:bg-slate-750 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-500'
            }`}
          >
            Habits
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('goals');
            }}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'goals'
                ? 'bg-white dark:bg-slate-750 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-500'
            }`}
          >
            Goals
          </button>
        </div>
      </div>

      {/* 2. Top Metric Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-violet-600 via-indigo-600 to-sky-600 text-white shadow-lg shadow-indigo-600/20 flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-xs text-indigo-100 font-semibold uppercase tracking-wider">
            <Flame className="w-4 h-4 text-amber-300" />
            <span>Habit Momentum</span>
          </div>
          <p className="text-2xl font-black font-mono tabular-nums">
            {completedHabits} of {habits.length} checked
          </p>
          <p className="text-xs text-indigo-100">
            {habitCompletionRate >= 75
              ? 'Outstanding focus today! Keep the flame alive.'
              : 'You have a few moments left to complete your rituals.'}
          </p>
        </div>

        <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md flex flex-col items-center justify-center border border-white/20 shrink-0">
          <span className="text-lg font-bold font-mono">{habitCompletionRate}%</span>
          <span className="text-[9px] uppercase tracking-wider text-indigo-100">Rate</span>
        </div>
      </div>

      {/* 3. AI Habit Coach Card */}
      <div className="p-3.5 rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200/70 dark:border-indigo-800/60 flex items-start gap-3">
        <div className="p-2 rounded-xl bg-indigo-600 text-white shrink-0 mt-0.5">
          <Sparkles className="w-3.5 h-3.5" />
        </div>
        <div className="text-xs">
          <p className="font-bold text-indigo-950 dark:text-indigo-200">
            HiBuddy Habit Coach
          </p>
          <p className="text-indigo-800/80 dark:text-indigo-300 mt-0.5 leading-relaxed">
            Pair your <span className="font-semibold">Morning Sunlight & Hydration</span> habit directly with your morning coffee ritual. Habit stacking boosts retention by 64%!
          </p>
        </div>
      </div>

      {/* 4. Active Tab Content */}
      {activeTab === 'habits' ? (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Daily Rituals
            </h3>
            <button
              onClick={() => {
                sound.playClick();
                setIsAddingHabit(true);
              }}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Habit</span>
            </button>
          </div>

          {/* Add Habit Form Modal */}
          {isAddingHabit && (
            <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-800 shadow-md space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  New Daily Habit
                </h4>
                <button
                  onClick={() => setIsAddingHabit(false)}
                  className="text-xs text-slate-400"
                >
                  Cancel
                </button>
              </div>

              <form onSubmit={handleCreateHabit} className="space-y-3">
                <input
                  type="text"
                  required
                  placeholder="e.g. 20-min daily reading"
                  value={habitTitle}
                  onChange={(e) => setHabitTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none"
                />

                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    Category
                  </label>
                  <select
                    value={habitCategory}
                    onChange={(e) => setHabitCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                  >
                    <option value="health">Health & Energy</option>
                    <option value="mindfulness">Mindfulness & Rest</option>
                    <option value="learning">Continuous Learning</option>
                    <option value="productivity">Work Productivity</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition-colors"
                >
                  Create Habit
                </button>
              </form>
            </div>
          )}

          {/* Habits list */}
          <div className="space-y-2">
            {habits.map((h) => {
              const IconComp = habitIcons[h.icon] || Heart;
              return (
                <div
                  key={h.id}
                  className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    h.completedToday
                      ? 'bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60'
                      : 'bg-white dark:bg-slate-800/90 border-slate-200/80 dark:border-slate-700/80 shadow-xs'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      onClick={() => toggleHabit(h.id)}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                        h.completedToday
                          ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-indigo-50'
                      }`}
                    >
                      <IconComp className="w-4 h-4" />
                    </button>
                    <div className="min-w-0">
                      <p
                        className={`text-xs sm:text-sm font-bold truncate ${
                          h.completedToday
                            ? 'text-emerald-900 dark:text-emerald-200'
                            : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {h.title}
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 capitalize">
                        {h.category} · {h.frequency}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-900/60 text-amber-700 dark:text-amber-300 text-xs font-bold font-mono">
                      <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                      <span>{h.streakDays}d</span>
                    </div>

                    <button
                      onClick={() => toggleHabit(h.id)}
                      className={`w-6 h-6 rounded-full border flex items-center justify-center transition-colors ${
                        h.completedToday
                          ? 'bg-emerald-600 border-emerald-600 text-white'
                          : 'border-slate-300 dark:border-slate-600 hover:border-emerald-500'
                      }`}
                    >
                      {h.completedToday && <CheckCircle2 className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* Goals Section */
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Long-Term Milestones
            </h3>
            <button
              onClick={() => {
                sound.playClick();
                setIsAddingGoal(true);
              }}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Goal</span>
            </button>
          </div>

          {/* Add Goal Modal */}
          {isAddingGoal && (
            <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-800 shadow-md space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  New Major Goal
                </h4>
                <button
                  onClick={() => setIsAddingGoal(false)}
                  className="text-xs text-slate-400"
                >
                  Cancel
                </button>
              </div>

              <form onSubmit={handleCreateGoal} className="space-y-3">
                <input
                  type="text"
                  required
                  placeholder="e.g. Save $10,000 for travel fund"
                  value={goalTitle}
                  onChange={(e) => setGoalTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none"
                />

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">
                      Target Date
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Dec 2026"
                      value={goalTargetDate}
                      onChange={(e) => setGoalTargetDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">
                      Category
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Finance"
                      value={goalCategory}
                      onChange={(e) => setGoalCategory(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition-colors"
                >
                  Create Goal
                </button>
              </form>
            </div>
          )}

          {/* Goals list */}
          <div className="space-y-3">
            {goals.map((g) => (
              <div
                key={g.id}
                className="p-4 rounded-3xl bg-white dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                      {g.category} · Due {g.targetDate}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                      {g.title}
                    </h4>
                  </div>
                  <span className="text-base font-black font-mono text-indigo-600 dark:text-indigo-400 tabular-nums">
                    {g.progressPercentage}%
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-100 dark:bg-slate-700 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-indigo-500 to-violet-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${g.progressPercentage}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="text-[11px] truncate">{g.currentMilestone}</span>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => updateGoalProgress(g.id, -5)}
                      className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-[11px]"
                      title="-5%"
                    >
                      -5%
                    </button>
                    <button
                      onClick={() => updateGoalProgress(g.id, 5)}
                      className="px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-600 dark:text-indigo-400 text-[11px] font-semibold"
                      title="+5%"
                    >
                      +5%
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
