import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, Bell, AlertCircle, CheckCircle2, Lock, Volume2, VolumeX, Play, Square } from 'lucide-react';
import { Task, Priority, TaskCategory } from '../../types';
import { useApp, getTodayString } from '../../context/AppContext';
import {
  stopAlarmSound,
  ALARM_TONE_OPTIONS,
  getSelectedTone,
  previewRingtone,
  stopRingtonePreview,
  isRingtonePreviewing,
} from '../../utils/alarmAudio';

interface TaskModalProps {
  isOpen: boolean;
  taskToEdit?: Task | null;
  onClose: () => void;
}

export const TaskModal: React.FC<TaskModalProps> = ({ isOpen, taskToEdit, onClose }) => {
  const { addTask, updateTask, t, language, notificationStatus, requestNotificationPermission } = useApp();

  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [dueDate, setDueDate] = useState(getTodayString());
  const [dueTime, setDueTime] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [category, setCategory] = useState<TaskCategory>('work');
  const [isRoutine, setIsRoutine] = useState(false);
  const [reminderSet, setReminderSet] = useState(false);
  const [alarmMinutesBefore, setAlarmMinutesBefore] = useState<number>(5);
  const [ringtone, setRingtone] = useState<string>(() => getSelectedTone());
  const [permissionNotice, setPermissionNotice] = useState<string | null>(null);
  const [previewingTone, setPreviewingTone] = useState<string | null>(null);

  useEffect(() => {
    if (taskToEdit) {
      setTitle(taskToEdit.title);
      setNotes(taskToEdit.notes || '');
      setDueDate(taskToEdit.dueDate || getTodayString());
      setDueTime(taskToEdit.dueTime || '');
      setPriority(taskToEdit.priority);
      setCategory(taskToEdit.category);
      setIsRoutine(Boolean(taskToEdit.isRoutine));
      setReminderSet(Boolean(taskToEdit.reminderSet || taskToEdit.alarmEnabled));
      setAlarmMinutesBefore(taskToEdit.alarmMinutesBefore ?? 5);
      setRingtone(taskToEdit.ringtone || getSelectedTone());
    } else {
      setTitle('');
      setNotes('');
      setDueDate(getTodayString());
      setDueTime('');
      setPriority('medium');
      setCategory('work');
      setIsRoutine(false);
      setReminderSet(false);
      setAlarmMinutesBefore(5);
      setRingtone(getSelectedTone());
    }
    setPermissionNotice(null);
    setPreviewingTone(null);
    stopRingtonePreview();
  }, [taskToEdit, isOpen]);

  useEffect(() => {
    const handlePreviewStopped = () => {
      setPreviewingTone(null);
    };
    window.addEventListener('habivio:preview-stopped', handlePreviewStopped);
    return () => {
      window.removeEventListener('habivio:preview-stopped', handlePreviewStopped);
      stopAlarmSound();
      stopRingtonePreview();
    };
  }, []);

  if (!isOpen) return null;

  const handleReminderToggle = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const checked = e.target.checked;
    if (!checked) {
      setReminderSet(false);
      setPermissionNotice(null);
      return;
    }

    if (notificationStatus === 'unsupported') {
      setReminderSet(true);
      setPermissionNotice(t.reminderNoticeUnsupported);
      return;
    }

    if (notificationStatus === 'granted') {
      setReminderSet(true);
      setPermissionNotice(t.reminderNoticeAllowed);
    } else {
      const granted = await requestNotificationPermission();
      if (granted) {
        setReminderSet(true);
        setPermissionNotice(t.reminderNoticeAllowed);
      } else {
        setReminderSet(true);
        setPermissionNotice(t.reminderNoticeDenied);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    stopAlarmSound();

    if (taskToEdit) {
      updateTask({
        ...taskToEdit,
        title: title.trim(),
        notes: notes.trim(),
        dueDate,
        dueTime: dueTime || undefined,
        priority,
        category,
        isRoutine,
        routineFrequency: isRoutine ? 'daily' : undefined,
        reminderSet,
        alarmEnabled: reminderSet,
        alarmMinutesBefore: reminderSet ? alarmMinutesBefore : undefined,
        ringtone: reminderSet ? ringtone : undefined,
        hasAlarmRung: false,
      });
    } else {
      addTask({
        title: title.trim(),
        notes: notes.trim(),
        dueDate,
        dueTime: dueTime || undefined,
        priority,
        category,
        completed: false,
        isRoutine,
        routineFrequency: isRoutine ? 'daily' : undefined,
        reminderSet,
        alarmEnabled: reminderSet,
        alarmMinutesBefore: reminderSet ? alarmMinutesBefore : undefined,
        ringtone: reminderSet ? ringtone : undefined,
        hasAlarmRung: false,
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-6 shadow-2xl transition-all max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Close"
        >
          <X size={18} />
        </button>

        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-5">
          {taskToEdit ? t.editTask : t.addTask}
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t.taskTitle} *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={t.taskTitlePlaceholder}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-violet-500 transition-all"
            />
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t.taskNotes}
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={t.taskNotesPlaceholder}
              className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-violet-500 transition-all"
            />
          </div>

          {/* Due Date & Due Time */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Calendar size={14} />
                <span>{t.dueDate}</span>
              </label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-violet-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Clock size={14} />
                <span>{t.dueTime}</span>
              </label>
              <input
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-violet-500"
              />
            </div>
          </div>

          {/* Priority */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t.priority}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['low', 'medium', 'high'] as Priority[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPriority(p)}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold capitalize transition-all ${
                    priority === p
                      ? p === 'high'
                        ? 'bg-rose-500 text-white border-rose-500 shadow-xs'
                        : p === 'medium'
                        ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                        : 'bg-sky-500 text-white border-sky-500 shadow-xs'
                      : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {p === 'high' ? t.priorityHigh : p === 'medium' ? t.priorityMedium : t.priorityLow}
                </button>
              ))}
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t.category}
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as TaskCategory)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-violet-500 capitalize"
            >
              <option value="work">{t.catWork}</option>
              <option value="personal">{t.catPersonal}</option>
              <option value="study">{t.catStudy}</option>
              <option value="health">{t.catHealth}</option>
              <option value="worship">{t.catWorship}</option>
              <option value="routine">{t.catRoutine}</option>
              <option value="other">{t.catOther}</option>
            </select>
          </div>

          {/* Routine Switch */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-200 block">
                {t.isDailyRoutine}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 block mt-0.5">
                {t.isDailyRoutineDesc}
              </span>
            </div>
            <input
              type="checkbox"
              checked={isRoutine}
              onChange={(e) => setIsRoutine(e.target.checked)}
              className="w-5 h-5 rounded-md text-violet-600 focus:ring-violet-500 border-slate-300 dark:border-slate-600"
            />
          </div>

          {/* Alarm & Reminder System */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl ${reminderSet ? 'bg-rose-500 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-500'}`}>
                  <Bell size={16} />
                </div>
                <div>
                  <span className="text-sm font-bold text-slate-800 dark:text-slate-200 block">
                    {language === 'bn' ? 'অ্যালার্ম ও রিমাইন্ডার চালু করুন' : 'Enable Alarm & Sound Reminder'}
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                    {language === 'bn' ? 'কাজের সময় অ্যালার্ম সাউন্ড ও ভাইব্রেশন বাজবে' : 'Rings alarm buzzer, vibration & browser alert'}
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={reminderSet}
                onChange={handleReminderToggle}
                className="w-5 h-5 rounded-md text-violet-600 focus:ring-violet-500 border-slate-300 dark:border-slate-600 cursor-pointer"
              />
            </div>

            {/* If Alarm Enabled: Options */}
            {reminderSet && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700/80 space-y-2">
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  {language === 'bn' ? 'রিমাইন্ডারের সময়' : 'Reminder Trigger'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs">
                  {[
                    { val: 0, label: language === 'bn' ? 'নির্দিষ্ট সময়ে' : 'At time' },
                    { val: 5, label: language === 'bn' ? '৫ মিনিট আগে' : '5m before' },
                    { val: 10, label: language === 'bn' ? '১০ মিনিট আগে' : '10m before' },
                    { val: 15, label: language === 'bn' ? '১৫ মিনিট আগে' : '15m before' },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      type="button"
                      onClick={() => setAlarmMinutesBefore(opt.val)}
                      className={`py-1.5 px-2 rounded-xl border text-center font-bold text-[11px] transition-all ${
                        alarmMinutesBefore === opt.val
                          ? 'bg-violet-600 border-violet-600 text-white shadow-xs'
                          : 'bg-white dark:bg-slate-700 border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>

                {/* Alarm Ringtone Picker with Preview */}
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700/80 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Volume2 size={13} className="text-violet-500" />
                      <span>{language === 'bn' ? 'অ্যালার্মের সুর (রিংটোন)' : 'Alarm Sound (Ringtone)'}</span>
                    </label>
                    {ringtone === 'silent' ? (
                      <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center gap-1">
                        <VolumeX size={10} />
                        <span>{language === 'bn' ? 'শব্দ বন্ধ' : 'Muted'}</span>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          if (previewingTone && isRingtonePreviewing()) {
                            stopRingtonePreview();
                            setPreviewingTone(null);
                          } else {
                            previewRingtone(ringtone);
                            setPreviewingTone(ringtone);
                          }
                        }}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all ${
                          previewingTone && isRingtonePreviewing()
                            ? 'bg-rose-500 text-white animate-pulse'
                            : 'bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300 hover:bg-violet-200'
                        }`}
                      >
                        {previewingTone && isRingtonePreviewing() ? (
                          <>
                            <Square size={10} className="fill-current" />
                            <span>{language === 'bn' ? 'থামান' : 'Stop'}</span>
                          </>
                        ) : (
                          <>
                            <Play size={10} className="fill-current" />
                            <span>{language === 'bn' ? 'টেস্ট শুনুন' : 'Test Sound'}</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>

                  <select
                    value={ringtone}
                    onChange={(e) => {
                      setRingtone(e.target.value);
                      stopRingtonePreview();
                      setPreviewingTone(null);
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-hidden focus:ring-2 focus:ring-violet-500 font-bold"
                  >
                    {ALARM_TONE_OPTIONS.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.icon} {language === 'bn' ? t.nameBn : t.nameEn}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {permissionNotice && (
              <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 pt-1">
                {reminderSet ? (
                  <CheckCircle2 size={13} className="text-emerald-500 shrink-0" />
                ) : (
                  <AlertCircle size={13} className="text-amber-500 shrink-0" />
                )}
                <span>{permissionNotice}</span>
              </div>
            )}

            {reminderSet && (
              <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200/80 dark:border-indigo-800/50 text-[11px] text-indigo-900 dark:text-indigo-300">
                <Lock size={13} className="text-indigo-600 dark:text-indigo-400 shrink-0" />
                <span>
                  {language === 'bn'
                    ? '🔒 ফোন লক বা স্ক্রিন বন্ধ থাকলেও অ্যালার্ম ও ভাইব্রেশন বাজবে।'
                    : '🔒 Alarm and vibration will ring even if phone screen is locked.'}
                </span>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-sm font-semibold text-white shadow-xs active:scale-95 transition-all"
            >
              {t.saveTask}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
