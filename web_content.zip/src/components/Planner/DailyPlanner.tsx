import React, { useState, useMemo } from 'react';
import {
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Circle,
  Clock,
  Calendar,
  Trash2,
  Edit3,
  Repeat,
  Bell,
} from 'lucide-react';
import { useApp, getTodayString } from '../../context/AppContext';
import { Task, Priority, TaskCategory } from '../../types';
import { ConfirmationModal } from '../ConfirmationModal';

interface DailyPlannerProps {
  onOpenTaskModal: (task?: Task) => void;
}

type TabFilter = 'today' | 'upcoming' | 'completed' | 'routines' | 'all';

export const DailyPlanner: React.FC<DailyPlannerProps> = ({ onOpenTaskModal }) => {
  const { tasks, toggleTaskCompleted, deleteTask, t } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<TabFilter>('today');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [taskToDelete, setTaskToDelete] = useState<Task | null>(null);

  const todayStr = getTodayString();

  // Filter and sort tasks
  const filteredTasks = useMemo(() => {
    return tasks
      .filter((task) => {
        // Sub-tab filter
        if (activeSubTab === 'today') {
          return (task.dueDate === todayStr || task.isRoutine) && !task.completed;
        }
        if (activeSubTab === 'upcoming') {
          return task.dueDate > todayStr && !task.completed && !task.isRoutine;
        }
        if (activeSubTab === 'completed') {
          return task.completed;
        }
        if (activeSubTab === 'routines') {
          return task.isRoutine;
        }
        // 'all' tab
        return true;
      })
      .filter((task) => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = task.title.toLowerCase().includes(q);
          const matchNotes = task.notes?.toLowerCase().includes(q);
          return matchTitle || matchNotes;
        }
        return true;
      })
      .filter((task) => {
        // Category filter
        if (selectedCategory !== 'all' && task.category !== selectedCategory) {
          return false;
        }
        // Priority filter
        if (selectedPriority !== 'all' && task.priority !== selectedPriority) {
          return false;
        }
        return true;
      })
      .sort((a, b) => {
        // Chronological order by due date and time
        if (a.dueDate !== b.dueDate) {
          return a.dueDate.localeCompare(b.dueDate);
        }
        const timeA = a.dueTime || '99:99';
        const timeB = b.dueTime || '99:99';
        return timeA.localeCompare(timeB);
      });
  }, [tasks, activeSubTab, searchQuery, selectedCategory, selectedPriority, todayStr]);

  const categories: Array<{ id: string; label: string }> = [
    { id: 'all', label: t.filterAll },
    { id: 'work', label: t.catWork },
    { id: 'personal', label: t.catPersonal },
    { id: 'study', label: t.catStudy },
    { id: 'health', label: t.catHealth },
    { id: 'worship', label: t.catWorship },
    { id: 'routine', label: t.catRoutine },
  ];

  return (
    <div className="space-y-5 pb-8">
      {/* Header bar */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
            {t.navPlanner}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {t.motto}
          </p>
        </div>
        <button
          onClick={() => onOpenTaskModal()}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold shadow-xs active:scale-95 transition-all"
        >
          <Plus size={16} />
          <span>{t.addTask}</span>
        </button>
      </div>

      {/* Main Sub-Tabs (Today, Upcoming, Completed, Routines, All) */}
      <div className="flex gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 overflow-x-auto scrollbar-none">
        {(
          [
            { id: 'today', label: t.today },
            { id: 'upcoming', label: t.upcoming },
            { id: 'completed', label: t.completed },
            { id: 'routines', label: t.routines },
            { id: 'all', label: t.all },
          ] as Array<{ id: TabFilter; label: string }>
        ).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id)}
            className={`flex-1 min-w-[70px] py-2 px-3 rounded-xl text-xs font-bold transition-all whitespace-nowrap text-center ${
              activeSubTab === tab.id
                ? 'bg-white dark:bg-slate-700 text-violet-600 dark:text-violet-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Search and Filters Bar */}
      <div className="space-y-2.5">
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.search}
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs focus:outline-hidden focus:ring-2 focus:ring-violet-500 shadow-xs"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none items-center text-xs">
          <div className="flex items-center gap-1 text-slate-400 pl-1 shrink-0">
            <Filter size={13} />
          </div>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`shrink-0 px-3 py-1.5 rounded-xl border font-semibold transition-all ${
                selectedCategory === c.id
                  ? 'bg-violet-50 dark:bg-violet-950/50 border-violet-300 dark:border-violet-700 text-violet-700 dark:text-violet-300'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
              }`}
            >
              {c.label}
            </button>
          ))}

          {/* Priority filter */}
          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="shrink-0 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 font-semibold text-xs focus:outline-hidden"
          >
            <option value="all">{t.filterAll}</option>
            <option value="high">{t.priorityHigh}</option>
            <option value="medium">{t.priorityMedium}</option>
            <option value="low">{t.priorityLow}</option>
          </select>
        </div>
      </div>

      {/* Task List */}
      {filteredTasks.length === 0 ? (
        <div className="text-center py-12 px-6 rounded-3xl bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 shadow-xs">
          <Calendar size={36} className="mx-auto text-slate-300 dark:text-slate-600 mb-2" />
          <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
            {t.noTasksFound}
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
            {t.noTasksFoundSub}
          </p>
          <button
            onClick={() => onOpenTaskModal()}
            className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700 transition-colors"
          >
            <Plus size={14} />
            <span>{t.addTask}</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTasks.map((task) => (
            <div
              key={task.id}
              className={`p-4 rounded-3xl border transition-all ${
                task.completed
                  ? 'bg-slate-50/70 dark:bg-slate-900/50 border-slate-200/60 dark:border-slate-800/60 opacity-80'
                  : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:shadow-sm'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <button
                    onClick={() => toggleTaskCompleted(task.id)}
                    className={`mt-0.5 shrink-0 transition-colors ${
                      task.completed
                        ? 'text-emerald-500 dark:text-emerald-400'
                        : 'text-slate-400 hover:text-violet-600'
                    }`}
                    aria-label={task.completed ? 'Mark incomplete' : 'Mark complete'}
                  >
                    {task.completed ? (
                      <CheckCircle2 size={22} className="fill-emerald-100 dark:fill-emerald-950" />
                    ) : (
                      <Circle size={22} />
                    )}
                  </button>

                  <div className="min-w-0 flex-1">
                    <h4
                      className={`text-sm font-bold tracking-tight truncate ${
                        task.completed
                          ? 'line-through text-slate-400 dark:text-slate-500'
                          : 'text-slate-900 dark:text-white'
                      }`}
                    >
                      {task.title}
                    </h4>

                    {task.notes && (
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                        {task.notes}
                      </p>
                    )}

                    <div className="flex flex-wrap items-center gap-2 mt-2 text-[11px] text-slate-500 dark:text-slate-400">
                      <span className="flex items-center gap-1 font-medium">
                        <Calendar size={12} />
                        {task.dueDate === todayStr ? t.today : task.dueDate}
                      </span>

                      {task.dueTime && (
                        <span className="flex items-center gap-1 font-mono font-medium">
                          <Clock size={12} />
                          {task.dueTime}
                        </span>
                      )}

                      <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold capitalize">
                        {task.category}
                      </span>

                      {task.isRoutine && (
                        <span className="flex items-center gap-1 text-violet-600 dark:text-violet-400 font-semibold text-[10px]">
                          <Repeat size={11} />
                          <span>Routine</span>
                        </span>
                      )}

                      {task.reminderSet && (
                        <span className="flex items-center gap-1 text-sky-600 dark:text-sky-400 font-semibold text-[10px]">
                          <Bell size={11} />
                          <span>Reminder</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right actions: Priority badge + Edit + Delete */}
                <div className="flex flex-col items-end gap-2 shrink-0">
                  <span
                    className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                      task.priority === 'high'
                        ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
                        : task.priority === 'medium'
                        ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400'
                        : 'bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400'
                    }`}
                  >
                    {task.priority === 'high' ? 'High' : task.priority === 'medium' ? 'Med' : 'Low'}
                  </span>

                  <div className="flex items-center gap-1 pt-1 opacity-70 hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => onOpenTaskModal(task)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      title={t.edit}
                      aria-label="Edit Task"
                    >
                      <Edit3 size={15} />
                    </button>
                    <button
                      onClick={() => setTaskToDelete(task)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                      title={t.delete}
                      aria-label="Delete Task"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={Boolean(taskToDelete)}
        title={t.deleteConfirmTitle}
        message={t.deleteConfirmTask}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        isDestructive={true}
        onConfirm={() => {
          if (taskToDelete) {
            deleteTask(taskToDelete.id);
            setTaskToDelete(null);
          }
        }}
        onClose={() => setTaskToDelete(null)}
      />
    </div>
  );
};
