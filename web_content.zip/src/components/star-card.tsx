import { Link } from "@tanstack/react-router";
import { StarPhoto } from "@/components/star-photo";
import type { VaultStar } from "@/store/vault";
import { cn } from "@/lib/utils";

export function StarCard({ star }: { star: VaultStar }) {
  return (
    <Link
      to="/star/$slug"
      params={{ slug: star.slug }}
      className={cn(
        "star-card group block rounded-lg outline-none",
        "focus-visible:ring-2 focus-visible:ring-ring",
      )}
    >
      <div className="relative aspect-portrait overflow-hidden rounded-lg bg-card shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 group-hover:shadow-[var(--shadow-border-hover)]">
        <StarPhoto
          star={star}
          className="transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.03]"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/10 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-2.5">
          <h3 className="font-display text-lg font-medium leading-tight tracking-tight text-paper">
            {star.name}
          </h3>
          {star.counts.total > 0 ? (
            <p className="mt-0.5 text-xs tabular-nums text-ivory/80">
              {star.counts.total} {star.counts.total === 1 ? "file" : "files"}
            </p>
          ) : null}
        </div>
        {star.favorite ? (
          <span className="absolute right-2 top-2 size-1.5 rounded-full bg-ivory" />
        ) : null}
      </div>
    </Link>
  );
}
