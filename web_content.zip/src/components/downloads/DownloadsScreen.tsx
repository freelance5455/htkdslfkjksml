import React, { useState, useMemo } from 'react';
import { useMusic } from '../../context/MusicContext';
import { SongCard } from '../cards/SongCard';
import { MusicListItem } from '../cards/MusicListItem';
import {
  ArrowDownToLine,
  HardDrive,
  WifiOff,
  Wifi,
  Trash2,
  Play,
  Pause,
  CheckCircle2,
  AlertCircle,
  Sparkles
} from 'lucide-react';

export const DownloadsScreen: React.FC = () => {
  const {
    songs,
    albums,
    playlists,
    downloadedSongIds,
    toggleDownloadSong,
    offlineMode,
    setOfflineMode,
    playSong,
    setActiveTab
  } = useMusic();

  const [downloadTab, setDownloadTab] = useState<'songs' | 'albums' | 'playlists'>('songs');

  // Filter downloaded songs
  const downloadedSongs = useMemo(() => {
    return songs.filter((s) => downloadedSongIds.includes(s.id));
  }, [songs, downloadedSongIds]);

  // Downloaded albums
  const downloadedAlbums = useMemo(() => {
    return albums.filter((a) => a.songIds.some((id) => downloadedSongIds.includes(id)));
  }, [albums, downloadedSongIds]);

  // Downloaded playlists
  const downloadedPlaylists = useMemo(() => {
    return playlists.filter((p) => p.songIds.some((id) => downloadedSongIds.includes(id)));
  }, [playlists, downloadedSongIds]);

  // Calculate simulated storage
  const totalStorageMb = downloadedSongs.reduce((acc, curr) => acc + (curr.downloadSizeMb || 8.2), 0);
  const totalStorageGb = (totalStorageMb / 1024).toFixed(2);
  const storagePercentage = Math.min(100, Math.round((totalStorageMb / (32 * 1024)) * 100));

  return (
    <div className="space-y-6 pb-24 pt-2 max-w-4xl mx-auto px-1">
      {/* Offline Mode Banner */}
      <div className={`p-4 rounded-3xl border transition-all ${
        offlineMode
          ? 'bg-amber-950/30 border-amber-500/40'
          : 'bg-white/[0.03] border-white/[0.08]'
      }`}>
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
              offlineMode ? 'bg-amber-500/20 text-amber-400' : 'bg-purple-500/20 text-purple-400'
            }`}>
              {offlineMode ? <WifiOff className="w-5 h-5" /> : <Wifi className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-sm sm:text-base text-white">
                  Offline Mode
                </h3>
                {offlineMode && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-semibold">
                    ACTIVE
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {offlineMode
                  ? 'Only downloaded music will play. Zero cellular data used.'
                  : 'Toggle to test playback without active internet access.'}
              </p>
            </div>
          </div>

          {/* Toggle Switch */}
          <button
            onClick={() => setOfflineMode(!offlineMode)}
            className={`w-12 h-6 rounded-full transition-colors relative p-0.5 shrink-0 ${
              offlineMode ? 'bg-amber-500' : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                offlineMode ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Storage Usage Card */}
      <div className="p-4 rounded-3xl bg-white/[0.02] border border-white/[0.06] space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-slate-300 flex items-center gap-1.5">
            <HardDrive className="w-4 h-4 text-purple-400" />
            <span>Storage Usage</span>
          </span>
          <span className="font-mono text-slate-400">
            {totalStorageGb} GB of 32 GB Used
          </span>
        </div>

        {/* Progress meter */}
        <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-emerald-400 rounded-full transition-all duration-500"
            style={{ width: `${Math.max(5, storagePercentage)}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-400">
          <span>{downloadedSongs.length} songs cached on this device</span>
          <span className="text-emerald-400 font-medium">320kbps High Fidelity</span>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setDownloadTab('songs')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
              downloadTab === 'songs'
                ? 'bg-purple-600 text-white'
                : 'bg-white/[0.04] text-slate-400 hover:text-white'
            }`}
          >
            Songs ({downloadedSongs.length})
          </button>
          <button
            onClick={() => setDownloadTab('albums')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
              downloadTab === 'albums'
                ? 'bg-purple-600 text-white'
                : 'bg-white/[0.04] text-slate-400 hover:text-white'
            }`}
          >
            Albums ({downloadedAlbums.length})
          </button>
          <button
            onClick={() => setDownloadTab('playlists')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
              downloadTab === 'playlists'
                ? 'bg-purple-600 text-white'
                : 'bg-white/[0.04] text-slate-400 hover:text-white'
            }`}
          >
            Playlists ({downloadedPlaylists.length})
          </button>
        </div>

        {downloadedSongs.length > 0 && downloadTab === 'songs' && (
          <button
            onClick={() => playSong(downloadedSongs[0], downloadedSongs)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-md transition-all"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            <span>Play All</span>
          </button>
        )}
      </div>

      {/* Content */}
      {downloadTab === 'songs' && (
        downloadedSongs.length === 0 ? (
          <div className="text-center py-16 px-4">
            <ArrowDownToLine className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <p className="text-sm font-semibold text-slate-200">No offline songs downloaded</p>
            <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
              Download your favorite tracks to listen anywhere on the road without using cellular data.
            </p>
            <button
              onClick={() => setActiveTab('home')}
              className="mt-4 px-4 py-2 rounded-full bg-purple-600 text-white font-semibold text-xs hover:bg-purple-500 transition-colors"
            >
              Explore Music
            </button>
          </div>
        ) : (
          <div className="space-y-1.5 bg-white/[0.02] p-2 rounded-3xl border border-white/[0.04]">
            {downloadedSongs.map((song) => (
              <div key={song.id} className="relative group">
                <MusicListItem song={song} contextQueue={downloadedSongs} />
                <button
                  onClick={() => toggleDownloadSong(song.id)}
                  title="Remove download"
                  className="absolute right-12 top-1/2 -translate-y-1/2 p-2 rounded-lg text-slate-500 hover:text-red-400 hover:bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )
      )}

      {downloadTab === 'albums' && (
        <div className="space-y-2">
          {downloadedAlbums.map((album) => (
            <div
              key={album.id}
              className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.03] border border-white/[0.05]"
            >
              <div>
                <p className="font-semibold text-sm text-white">{album.title}</p>
                <p className="text-xs text-slate-400">{album.artist} · {album.year}</p>
              </div>
              <span className="text-xs text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Downloaded</span>
              </span>
            </div>
          ))}
        </div>
      )}

      {downloadTab === 'playlists' && (
        <div className="space-y-2">
          {downloadedPlaylists.map((pl) => (
            <div
              key={pl.id}
              className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.03] border border-white/[0.05]"
            >
              <div>
                <p className="font-semibold text-sm text-white">{pl.title}</p>
                <p className="text-xs text-slate-400">{pl.songIds.length} tracks · {pl.creator}</p>
              </div>
              <span className="text-xs text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Downloaded</span>
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
