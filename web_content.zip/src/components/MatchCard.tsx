import React from 'react';
import { Match } from '../types';
import { Play, Mic, Tv, MapPin, Radio, Clock, ShieldCheck, Flame } from 'lucide-react';

interface MatchCardProps {
  match: Match;
  onSelectMatch: (match: Match) => void;
}

export const MatchCard: React.FC<MatchCardProps> = ({ match, onSelectMatch }) => {
  const isLive = match.status === 'live';
  const isFinished = match.status === 'finished';
  const isUpcoming = match.status === 'upcoming';

  return (
    <div
      id={`match-card-${match.id}`}
      className="group relative bg-white dark:bg-[#111624] hover:bg-slate-50/90 dark:hover:bg-[#151c2e] border border-slate-200/90 dark:border-slate-800/90 hover:border-rose-400 dark:hover:border-rose-500/50 rounded-2xl overflow-hidden shadow-sm dark:shadow-xl transition-all duration-300 hover:shadow-md dark:hover:shadow-2xl hover:shadow-rose-950/10 flex flex-col justify-between"
    >
      {/* Top Tournament Header */}
      <div className="bg-slate-50 dark:bg-[#0c101a]/90 px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs transition-colors">
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
          <span className="font-bold text-slate-800 dark:text-slate-200 truncate">{match.tournament.name}</span>
        </div>

        {/* Status Badge */}
        {isLive && (
          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-600/15 dark:bg-rose-600/25 border border-rose-500/40 dark:border-rose-500/60 text-rose-600 dark:text-rose-400 font-extrabold text-[11px] animate-pulse">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <span>مباشر {match.minute ? `(${match.minute}')` : ''}</span>
          </div>
        )}

        {isFinished && (
          <span className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold text-[11px] border border-slate-300 dark:border-slate-700/60">
            انتهت
          </span>
        )}

        {isUpcoming && (
          <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400 text-[11px] font-semibold">
            <Clock className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
            <span className="font-mono">{match.time} بتوقيت مكة</span>
          </div>
        )}
      </div>

      {/* Center Match Action (Teams + Score) */}
      <div className="p-5">
        <div className="grid grid-cols-7 items-center gap-2">
          {/* Home Team */}
          <div className="col-span-3 flex flex-col items-center text-center gap-2">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-100 dark:bg-[#192236] p-2.5 flex items-center justify-center border border-slate-200 dark:border-slate-700/60 group-hover:border-rose-400 dark:group-hover:border-rose-500/30 shadow-xs group-hover:scale-105 transition-transform">
              <img
                src={match.homeTeam.logo}
                alt={match.homeTeam.name}
                referrerPolicy="no-referrer"
                className="max-h-full max-w-full object-contain filter drop-shadow"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://upload.wikimedia.org/wikipedia/commons/d/d3/Soccerball.svg';
                }}
              />
            </div>
            <span className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100 line-clamp-1">
              {match.homeTeam.name}
            </span>
          </div>

          {/* Score or VS in Center */}
          <div className="col-span-1 flex flex-col items-center justify-center">
            {isLive || isFinished ? (
              <div className="flex items-center justify-center gap-1.5 bg-slate-100 dark:bg-[#090d16] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                <span className={`text-xl sm:text-2xl font-black font-['Changa',sans-serif] ${isLive ? 'text-rose-600 dark:text-rose-400' : 'text-slate-900 dark:text-white'}`}>
                  {match.homeScore ?? 0}
                </span>
                <span className="text-slate-400 dark:text-slate-500 text-sm font-bold">:</span>
                <span className={`text-xl sm:text-2xl font-black font-['Changa',sans-serif] ${isLive ? 'text-rose-600 dark:text-rose-400' : 'text-slate-900 dark:text-white'}`}>
                  {match.awayScore ?? 0}
                </span>
              </div>
            ) : (
              <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-[#192236] border border-slate-200 dark:border-slate-700 flex items-center justify-center text-xs font-black text-rose-600 dark:text-rose-400 font-['Changa']">
                VS
              </div>
            )}
            <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 font-mono font-medium">
              {isLive ? 'جارية الآن' : isFinished ? 'النتيجة النهائية' : match.time}
            </span>
          </div>

          {/* Away Team */}
          <div className="col-span-3 flex flex-col items-center text-center gap-2">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-100 dark:bg-[#192236] p-2.5 flex items-center justify-center border border-slate-200 dark:border-slate-700/60 group-hover:border-rose-400 dark:group-hover:border-rose-500/30 shadow-xs group-hover:scale-105 transition-transform">
              <img
                src={match.awayTeam.logo}
                alt={match.awayTeam.name}
                referrerPolicy="no-referrer"
                className="max-h-full max-w-full object-contain filter drop-shadow"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://upload.wikimedia.org/wikipedia/commons/d/d3/Soccerball.svg';
                }}
              />
            </div>
            <span className="font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100 line-clamp-1">
              {match.awayTeam.name}
            </span>
          </div>
        </div>

        {/* Live Goal highlight if any */}
        {match.events.length > 0 && isLive && (
          <div className="mt-3.5 px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/40 text-[11px] text-rose-700 dark:text-rose-300 flex items-center justify-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-rose-500 dark:text-rose-400 shrink-0" />
            <span className="truncate">
              آخر هدف: {match.events[match.events.length - 1].player} ({match.events[match.events.length - 1].minute}')
            </span>
          </div>
        )}
      </div>

      {/* Match Meta Footer: Channel, Commentator, Watch Button */}
      <div className="bg-slate-50 dark:bg-[#0d121e] px-4 py-3 border-t border-slate-200 dark:border-slate-800/80 space-y-3 transition-colors">
        <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 dark:text-slate-300">
          <div className="flex items-center gap-1.5 truncate">
            <Tv className="w-3.5 h-3.5 text-rose-500 dark:text-rose-400 shrink-0" />
            <span className="text-slate-500 dark:text-slate-400">القناة:</span>
            <span className="font-bold text-slate-800 dark:text-slate-200 truncate">{match.channel}</span>
          </div>

          <div className="flex items-center gap-1.5 truncate">
            <Mic className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400 shrink-0" />
            <span className="text-slate-500 dark:text-slate-400">المعلق:</span>
            <span className="font-bold text-slate-800 dark:text-slate-200 truncate">{match.commentator}</span>
          </div>

          <div className="col-span-2 flex items-center gap-1.5 text-slate-500 dark:text-slate-400 text-[10px] truncate">
            <MapPin className="w-3 h-3 text-slate-400 dark:text-slate-500 shrink-0" />
            <span className="truncate">{match.stadium}</span>
          </div>
        </div>

        {/* Watch Stream CTA Button */}
        <button
          id={`watch-match-btn-${match.id}`}
          onClick={() => onSelectMatch(match)}
          className={`w-full py-2.5 px-4 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all transform active:scale-98 shadow-sm cursor-pointer ${
            isLive
              ? 'bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white shadow-rose-600/30'
              : isUpcoming
              ? 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-700'
              : 'bg-slate-100 hover:bg-slate-200 dark:bg-[#192236] dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700'
          }`}
        >
          {isLive ? (
            <>
              <Play className="w-4 h-4 fill-white text-white animate-pulse" />
              <span>مشاهدة البث المباشر (VIP)</span>
              <span className="mr-auto text-[10px] bg-black/30 px-2 py-0.5 rounded-full font-bold">
                {match.servers.length} سيرفرات
              </span>
            </>
          ) : isUpcoming ? (
            <>
              <Clock className="w-4 h-4 text-amber-500 dark:text-amber-400" />
              <span>تفاصيل المباراة وسيرفرات البث</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-slate-500 dark:fill-slate-300 text-slate-500 dark:text-slate-300" />
              <span>مشاهدة الملخص والأهداف الكاملة</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
