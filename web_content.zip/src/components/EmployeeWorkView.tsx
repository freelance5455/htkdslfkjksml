import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CalendarPlus,
  CheckSquare,
  Clock,
  Edit3,
  FileSpreadsheet,
  Plus,
  Search,
  Trash2,
  UserCheck,
  UserX,
  Users,
  X,
} from 'lucide-react';
import {
  ATTENDANCE_STATUSES,
  AttendanceLog,
  AttendanceStatus,
  ConfirmDialogState,
  EMPLOYEE_DIVISIONS,
  EmployeeDivision,
  EmployeeRecord,
  EmployeeShift,
  FIELD_LIMITS,
  HOST_LIVE_SHIFTS,
} from '../types/ops';
import {
  createAttendanceLog,
  deleteAttendanceLog,
  updateAttendanceLog,
} from '../lib/firestoreOps';
import {
  createCalendarEvent,
  createSpreadsheet,
  createTask,
  listTaskLists,
  overwriteSheetValues,
} from '../lib/workspaceApi';

interface EmployeeWorkViewProps {
  ownerId: string;
  isAdmin: boolean;
  userName: string;
  userEmail: string;
  userDivision: string;
  employees: EmployeeRecord[];
  logs: AttendanceLog[];
  accessToken: string | null;
  onRequestConfirm: (dialog: ConfirmDialogState) => void;
  onReconnectWorkspace: () => void;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
  onSeedStarterAttendance: () => void;
  seeding: boolean;
}

const STATUS_TEXT_CLASS: Record<AttendanceStatus, string> = {
  'Hadir Tepat Waktu': 'text-emerald-700 font-semibold',
  Terlambat: 'text-orange-700 font-semibold',
  Izin: 'text-amber-700 font-semibold',
  Sakit: 'text-amber-700 font-semibold',
  'Tanpa Keterangan': 'text-red-700 font-semibold',
};

export const EmployeeWorkView: React.FC<EmployeeWorkViewProps> = ({
  ownerId,
  isAdmin,
  userName,
  userEmail,
  userDivision,
  employees,
  logs,
  accessToken,
  onRequestConfirm,
  onReconnectWorkspace,
  onNotify,
  onSeedStarterAttendance,
  seeding,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'Semua' | AttendanceStatus>('Semua');
  const [divisionFilter, setDivisionFilter] = useState<'Semua' | EmployeeDivision>('Semua');
  const [dateFilter, setDateFilter] = useState('');

  // Form Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editingLog, setEditingLog] = useState<AttendanceLog | null>(null);
  const [employeeName, setEmployeeName] = useState('');
  const [employeeEmail, setEmployeeEmail] = useState('');
  const [division, setDivision] = useState<EmployeeDivision>('Gudang & Packing');
  const [workDate, setWorkDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [shift, setShift] = useState<EmployeeShift>('');
  const [attendanceStatus, setAttendanceStatus] =
    useState<AttendanceStatus>('Hadir Tepat Waktu');
  const [lateMinutes, setLateMinutes] = useState('15');
  const [workTask, setWorkTask] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  const filteredLogs = useMemo(() => {
    const q = search.trim().toLowerCase();
    return logs.filter((log) => {
      if (statusFilter !== 'Semua' && log.attendanceStatus !== statusFilter) return false;
      if (divisionFilter !== 'Semua' && log.division !== divisionFilter) return false;
      if (dateFilter && log.workDate !== dateFilter) return false;
      if (!q) return true;
      return (
        log.employeeName.toLowerCase().includes(q) ||
        log.division.toLowerCase().includes(q) ||
        log.workTask.toLowerCase().includes(q) ||
        log.notes.toLowerCase().includes(q)
      );
    });
  }, [logs, search, statusFilter, divisionFilter, dateFilter]);

  const onTimeCount = logs.filter((l) => l.attendanceStatus === 'Hadir Tepat Waktu').length;
  const lateLogs = logs.filter((l) => l.attendanceStatus === 'Terlambat');
  const totalLateMinutes = lateLogs.reduce((acc, l) => acc + (l.lateMinutes || 0), 0);
  const leaveCount = logs.filter(
    (l) => l.attendanceStatus === 'Izin' || l.attendanceStatus === 'Sakit'
  ).length;
  const alphaCount = logs.filter((l) => l.attendanceStatus === 'Tanpa Keterangan').length;

  const openCreateModal = () => {
    setEditingLog(null);
    let initialDiv: EmployeeDivision = 'Gudang & Packing';
    if (isAdmin) {
      setEmployeeName('');
      setEmployeeEmail('');
      setDivision('Gudang & Packing');
    } else {
      const empDiv: EmployeeDivision =
        userDivision === 'Gudang & Packing' ||
        userDivision === 'Host Live' ||
        userDivision === 'Konten Kreator'
          ? userDivision
          : 'Gudang & Packing';
      initialDiv = empDiv;
      setEmployeeName(userName);
      setEmployeeEmail(userEmail);
      setDivision(empDiv);
    }
    setWorkDate(new Date().toISOString().slice(0, 10));
    setShift(initialDiv === 'Host Live' ? 'Shift 1' : '');
    setAttendanceStatus('Hadir Tepat Waktu');
    setLateMinutes('15');
    setWorkTask('');
    setNotes('');
    setFormError('');
    setModalOpen(true);
  };

  const openEditModal = (log: AttendanceLog) => {
    if (!isAdmin) return;
    setEditingLog(log);
    setEmployeeName(log.employeeName);
    setEmployeeEmail(log.employeeEmail || '');
    setDivision(log.division);
    setWorkDate(log.workDate);
    setShift(log.division === 'Host Live' ? (log.shift === 'Shift 2' ? 'Shift 2' : 'Shift 1') : '');
    setAttendanceStatus(log.attendanceStatus);
    setLateMinutes(String(log.lateMinutes || 15));
    setWorkTask(log.workTask);
    setNotes(log.notes);
    setFormError('');
    setModalOpen(true);
  };

  const handleDivisionChange = (nextDiv: EmployeeDivision) => {
    setDivision(nextDiv);
    if (nextDiv === 'Host Live') {
      setShift((prev) => (prev === 'Shift 2' ? 'Shift 2' : 'Shift 1'));
    } else {
      setShift('');
    }
  };

  const handleSelectKnownEmployee = (empId: string) => {
    const found = employees.find((e) => e.id === empId);
    if (!found) return;
    setEmployeeName(found.employeeName);
    setEmployeeEmail(found.email);
    setDivision(found.division);
    setShift(
      found.division === 'Host Live' ? (found.shift === 'Shift 2' ? 'Shift 2' : 'Shift 1') : ''
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      const normalizedShift: EmployeeShift =
        division === 'Host Live' ? (shift === 'Shift 2' ? 'Shift 2' : 'Shift 1') : '';
      const payload = {
        employeeName,
        employeeEmail: isAdmin ? employeeEmail : userEmail,
        division,
        workDate,
        shift: normalizedShift,
        attendanceStatus,
        lateMinutes: attendanceStatus === 'Terlambat' ? Number(lateMinutes) || 1 : 0,
        workTask,
        notes,
      };
      if (editingLog && isAdmin) {
        await updateAttendanceLog(editingLog.id, payload);
        onNotify(`Catatan kerja ${employeeName} diperbarui.`, 'success');
      } else {
        await createAttendanceLog(ownerId, payload);
        onNotify(`Catatan kerja ${employeeName} berhasil disimpan.`, 'success');
      }
      setModalOpen(false);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Gagal menyimpan catatan kerja.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteLog = (log: AttendanceLog) => {
    if (!isAdmin) return;
    onRequestConfirm({
      open: true,
      title: `Hapus Catatan Kerja ${log.employeeName}?`,
      description: `Catatan kehadiran tanggal ${log.workDate} (${log.attendanceStatus}) akan dihapus permanen.`,
      confirmLabel: 'Hapus Catatan',
      variant: 'danger',
      onConfirm: async () => {
        await deleteAttendanceLog(log.id);
        onNotify(`Catatan ${log.employeeName} dihapus.`, 'success');
      },
    });
  };

  const handleExportSheets = () => {
    if (!accessToken) {
      onReconnectWorkspace();
      return;
    }
    if (filteredLogs.length === 0) {
      onNotify('Tidak ada catatan kerja untuk diekspor.', 'error');
      return;
    }
    onRequestConfirm({
      open: true,
      title: 'Ekspor Daftar Kerja Karyawan ke Google Sheets?',
      description: `Membuat spreadsheet baru berisi ${filteredLogs.length} catatan kerja & kehadiran karyawan Tiga Rekan ID.`,
      confirmLabel: 'Buat & Ekspor ke Sheets',
      onConfirm: async () => {
        const title = `Kehadiran Karyawan Tiga Rekan ID - ${new Date().toLocaleDateString('id-ID')}`;
        const meta = await createSpreadsheet(accessToken, title, 'Kehadiran');
        const tabTitle = meta.sheets[0]?.properties?.title || 'Kehadiran';
        const rows: (string | number)[][] = [
          ['Tanggal', 'Karyawan', 'Divisi', 'Shift (Host Live)', 'Status', 'Telat (Menit)', 'Tugas Kerja', 'Catatan'],
          ...filteredLogs.map((l) => [
            l.workDate,
            l.employeeName,
            l.division,
            l.division === 'Host Live' && l.shift ? l.shift : '-',
            l.attendanceStatus,
            l.lateMinutes || 0,
            l.workTask,
            l.notes,
          ]),
        ];
        await overwriteSheetValues(accessToken, meta.spreadsheetId, tabTitle, rows);
        onNotify(`Spreadsheet "${title}" berhasil dibuat di Google Sheets.`, 'success');
      },
    });
  };

  const handleScheduleCalendar = (log: AttendanceLog) => {
    if (!accessToken) {
      onReconnectWorkspace();
      return;
    }
    const start = new Date(`${log.workDate}T09:00:00`);
    const end = new Date(start.getTime() + 60 * 60 * 1000);
    const shiftLine = log.division === 'Host Live' && log.shift ? `Shift: ${log.shift}\n` : '';
    onRequestConfirm({
      open: true,
      title: 'Catat ke Google Calendar?',
      description: `Menambahkan catatan ${log.attendanceStatus} atas nama ${log.employeeName} ke Google Calendar.`,
      confirmLabel: 'Tambahkan ke Calendar',
      onConfirm: async () => {
        await createCalendarEvent(accessToken, {
          summary: `[${log.attendanceStatus}] ${log.employeeName} (${log.division})`,
          description: `${shiftLine}Tugas: ${log.workTask || '-'}\nTelat: ${log.lateMinutes} menit\nCatatan: ${log.notes || '-'}`,
          location: log.division,
          startIso: start.toISOString(),
          endIso: end.toISOString(),
        });
        onNotify(`Agenda ${log.employeeName} ditambahkan ke Google Calendar.`, 'success');
      },
    });
  };

  const handleCreateFollowUpTask = (log: AttendanceLog) => {
    if (!accessToken) {
      onReconnectWorkspace();
      return;
    }
    const shiftInfo = log.division === 'Host Live' && log.shift ? ` · ${log.shift}` : '';
    onRequestConfirm({
      open: true,
      title: 'Buat Tugas Tindak Lanjut di Google Tasks?',
      description: `Membuat pengingat tindak lanjut untuk ${log.employeeName} (${log.attendanceStatus}).`,
      confirmLabel: 'Buat di Google Tasks',
      onConfirm: async () => {
        const lists = await listTaskLists(accessToken);
        const listId = lists[0]?.id || '@default';
        await createTask(accessToken, listId, {
          title: `Tindak lanjut ${log.attendanceStatus}: ${log.employeeName} (${log.division})`,
          notes: `Tanggal: ${log.workDate}${shiftInfo}\nTugas: ${log.workTask || '-'}\nCatatan: ${log.notes || '-'}`,
          dueIso: new Date(`${log.workDate}T17:00:00`).toISOString(),
        });
        onNotify(`Tugas tindak lanjut ${log.employeeName} dibuat di Google Tasks.`, 'success');
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 pb-5 border-b border-stone-200">
        <div>
          <p className="text-xs font-semibold text-orange-700">
            Operasional Tim · {isAdmin ? 'Akses Penuh Administrator' : `Karyawan ${userDivision}`}
          </p>
          <h1 className="text-xl sm:text-2xl font-bold text-stone-900 tracking-tight mt-1">
            Daftar Kerja & Kehadiran Karyawan
          </h1>
          <p className="text-sm text-stone-600 mt-1 max-w-2xl">
            Catat aktivitas kerja harian tim Gudang & Packing, Host Live, dan Konten Kreator beserta keterlambatan, izin, sakit, dan ketidakhadiran.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-2.5 sm:gap-3 w-full lg:w-auto shrink-0">
          {isAdmin && logs.length === 0 && (
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              type="button"
              onClick={onSeedStarterAttendance}
              disabled={seeding}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors whitespace-nowrap shrink-0 disabled:opacity-60"
            >
              <Plus className="w-4 h-4" />
              {seeding ? 'Memuat...' : 'Muat Contoh Data'}
            </motion.button>
          )}
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            type="button"
            onClick={handleExportSheets}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors whitespace-nowrap shrink-0"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            Ekspor ke Google Sheets
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            Catat Kehadiran & Kerja
          </motion.button>
        </div>
      </div>

      {/* 4-Column KPI Summary Strip */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white border border-stone-200 rounded-xl p-4 sm:p-5">
          <div className="flex items-center justify-between text-xs font-medium text-stone-500">
            <span className="truncate">Total Catatan Kerja</span>
            <Users className="w-4 h-4 text-orange-500 shrink-0" />
          </div>
          <div className="mt-2.5 sm:mt-3 flex items-baseline justify-between gap-2">
            <span className="text-xl sm:text-2xl font-bold text-stone-900 font-mono tabular-nums">
              {logs.length}
            </span>
            <span className="text-[11px] sm:text-xs text-stone-500 tabular-nums">
              {filteredLogs.length} tampil
            </span>
          </div>
          <p className="mt-1.5 sm:mt-2 text-[11px] sm:text-xs text-stone-600 truncate">
            Seluruh catatan operasional
          </p>
        </div>

        <div className="bg-white border border-stone-200 rounded-xl p-4 sm:p-5">
          <div className="flex items-center justify-between text-xs font-medium text-stone-500">
            <span className="truncate">Hadir Tepat Waktu</span>
            <UserCheck className="w-4 h-4 text-emerald-700 shrink-0" />
          </div>
          <div className="mt-2.5 sm:mt-3">
            <span className="text-xl sm:text-2xl font-bold text-emerald-700 font-mono tabular-nums">
              {onTimeCount}
            </span>
          </div>
          <p className="mt-1.5 sm:mt-2 text-[11px] sm:text-xs text-stone-600 truncate">
            Sesuai jadwal masuk
          </p>
        </div>

        <div className="bg-white border border-stone-200 rounded-xl p-4 sm:p-5">
          <div className="flex items-center justify-between text-xs font-medium text-stone-500">
            <span className="truncate">Catatan Terlambat</span>
            <Clock className="w-4 h-4 text-orange-600 shrink-0" />
          </div>
          <div className="mt-2.5 sm:mt-3 flex items-baseline justify-between gap-2">
            <span className="text-xl sm:text-2xl font-bold text-orange-700 font-mono tabular-nums">
              {lateLogs.length}
            </span>
            <span className="text-[11px] sm:text-xs font-mono text-stone-600 tabular-nums">
              {totalLateMinutes} mnt
            </span>
          </div>
          <p className="mt-1.5 sm:mt-2 text-[11px] sm:text-xs text-stone-600 truncate">
            Akumulasi keterlambatan
          </p>
        </div>

        <div className="bg-white border border-stone-200 rounded-xl p-4 sm:p-5">
          <div className="flex items-center justify-between text-xs font-medium text-stone-500">
            <span className="truncate">Izin, Sakit & Alpha</span>
            <UserX className="w-4 h-4 text-red-600 shrink-0" />
          </div>
          <div className="mt-2.5 sm:mt-3 flex items-baseline justify-between gap-1">
            <span className="text-xl sm:text-2xl font-bold text-stone-900 font-mono tabular-nums">
              {leaveCount + alphaCount}
            </span>
            <span className="text-[11px] sm:text-xs text-red-700 font-semibold tabular-nums truncate">
              {alphaCount} Alpha
            </span>
          </div>
          <p className="mt-1.5 sm:mt-2 text-[11px] sm:text-xs text-stone-600 tabular-nums truncate">
            {leaveCount} izin / sakit
          </p>
        </div>
      </div>

      {/* Filters Toolbar */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3 sm:gap-4">
        <div className="w-full xl:w-auto overflow-x-auto pb-1 xl:pb-0">
          <div className="inline-flex items-center gap-1 p-1 bg-stone-100 rounded-xl min-w-max">
            {(['Semua', ...ATTENDANCE_STATUSES] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  statusFilter === st
                    ? 'bg-white text-orange-700 shadow-sm'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:flex sm:flex-wrap items-center gap-2.5 sm:gap-3 w-full xl:w-auto">
          <div className="grid grid-cols-2 sm:flex items-center gap-2.5">
            <select
              value={divisionFilter}
              onChange={(e) => setDivisionFilter(e.target.value as 'Semua' | EmployeeDivision)}
              aria-label="Filter divisi karyawan"
              className="w-full sm:w-auto px-3 py-2 text-sm bg-white border border-stone-300 rounded-lg text-stone-700 focus:outline-none focus:border-orange-600"
            >
              <option value="Semua">Semua Divisi</option>
              {EMPLOYEE_DIVISIONS.map((div) => (
                <option key={div} value={div}>
                  {div}
                </option>
              ))}
            </select>

            <div className="flex items-center gap-2">
              <input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                aria-label="Filter tanggal kerja"
                className="w-full sm:w-auto px-3 py-2 text-sm font-mono bg-white border border-stone-300 rounded-lg text-stone-700 focus:outline-none focus:border-orange-600"
              />
              {dateFilter && (
                <button
                  type="button"
                  onClick={() => setDateFilter('')}
                  className="text-xs font-semibold text-orange-700 hover:underline whitespace-nowrap shrink-0"
                >
                  Reset
                </button>
              )}
            </div>
          </div>

          <div className="relative w-full sm:w-60">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari nama, tugas, alasan..."
              className="pl-9 pr-3 py-2 text-sm bg-white border border-stone-300 rounded-lg w-full focus:outline-none focus:border-orange-600"
            />
          </div>
        </div>
      </div>

      {/* Data Presentation: Mobile Cards + Desktop Table */}
      <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
        {filteredLogs.length === 0 ? (
          <div className="p-8 sm:p-10 text-center">
            <p className="text-sm font-semibold text-stone-800">
              {logs.length === 0
                ? 'Belum ada catatan kerja & kehadiran'
                : 'Tidak ada catatan sesuai filter'}
            </p>
            <p className="text-xs text-stone-500 mt-1 mb-4">
              Catat aktivitas kerja harian, keterlambatan, izin, sakit, maupun alpha.
            </p>
            {logs.length === 0 && (
              <button
                type="button"
                onClick={openCreateModal}
                className="px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700"
              >
                Catat Kehadiran Pertama
              </button>
            )}
          </div>
        ) : (
          <>
            {/* Mobile Card List */}
            <div className="md:hidden divide-y divide-stone-100">
              {filteredLogs.map((log) => (
                <div key={log.id} className="p-4 space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-stone-900 truncate">
                        {log.employeeName}
                      </p>
                      <p className="text-xs font-medium text-orange-700 mt-0.5">
                        {log.division}
                        {log.division === 'Host Live' && log.shift ? ` · ${log.shift}` : ''}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-mono text-xs font-bold text-stone-800 tabular-nums">
                        {log.workDate}
                      </p>
                      <p className={`text-xs mt-0.5 ${STATUS_TEXT_CLASS[log.attendanceStatus]}`}>
                        {log.attendanceStatus}
                        {log.attendanceStatus === 'Terlambat' && log.lateMinutes > 0
                          ? ` (+${log.lateMinutes}m)`
                          : ''}
                      </p>
                    </div>
                  </div>

                  {log.workTask && (
                    <div className="text-xs text-stone-800 bg-stone-50 rounded-lg px-3 py-2 leading-relaxed">
                      <span className="font-semibold text-stone-600">Tugas: </span>
                      {log.workTask}
                    </div>
                  )}

                  {log.notes && (
                    <p className="text-xs text-stone-600 leading-relaxed">
                      <span className="font-semibold text-stone-500">Catatan: </span>
                      {log.notes}
                    </p>
                  )}

                  <div className="pt-1 flex items-center justify-end gap-1 border-t border-stone-100">
                    <button
                      type="button"
                      onClick={() => handleScheduleCalendar(log)}
                      title="Catat ke Google Calendar"
                      className="p-2 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                    >
                      <CalendarPlus className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCreateFollowUpTask(log)}
                      title="Buat Tugas Tindak Lanjut"
                      className="p-2 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                    >
                      <CheckSquare className="w-4 h-4" />
                    </button>
                    {isAdmin && (
                      <>
                        <button
                          type="button"
                          onClick={() => openEditModal(log)}
                          title="Sunting catatan"
                          className="p-2 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteLog(log)}
                          title="Hapus catatan"
                          className="p-2 text-stone-500 hover:text-red-700 hover:bg-red-50 rounded-md"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-stone-200 bg-stone-50 text-xs font-semibold text-stone-600">
                    <th className="py-3 px-4 whitespace-nowrap">Tanggal</th>
                    <th className="py-3 px-4 whitespace-nowrap">Karyawan & Divisi</th>
                    <th className="py-3 px-4 whitespace-nowrap">Status Kehadiran</th>
                    <th className="py-3 px-4 whitespace-nowrap">Daftar Kerja Harian</th>
                    <th className="py-3 px-4 whitespace-nowrap">Catatan / Alasan</th>
                    <th className="py-3 px-4 whitespace-nowrap text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 text-sm">
                  {filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-orange-50/40 transition-colors">
                      <td className="py-3 px-4 align-top whitespace-nowrap">
                        <div className="font-mono text-xs font-bold text-stone-900 tabular-nums">
                          {log.workDate}
                        </div>
                        {log.division === 'Host Live' && log.shift && (
                          <div className="text-xs text-stone-500 mt-0.5">{log.shift}</div>
                        )}
                      </td>
                      <td className="py-3 px-4 align-top whitespace-nowrap">
                        <div className="font-medium text-stone-900">{log.employeeName}</div>
                        <div className="text-xs text-orange-700 font-medium mt-0.5">
                          {log.division}
                        </div>
                      </td>
                      <td className="py-3 px-4 align-top whitespace-nowrap">
                        <div className={`text-xs ${STATUS_TEXT_CLASS[log.attendanceStatus]}`}>
                          {log.attendanceStatus}
                        </div>
                        {log.attendanceStatus === 'Terlambat' && log.lateMinutes > 0 && (
                          <div className="text-xs font-mono text-orange-700 tabular-nums mt-0.5">
                            +{log.lateMinutes} menit
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 align-top max-w-xs">
                        <p className="text-xs text-stone-800 leading-relaxed">
                          {log.workTask || '-'}
                        </p>
                      </td>
                      <td className="py-3 px-4 align-top max-w-xs">
                        <p className="text-xs text-stone-600 leading-relaxed">{log.notes || '-'}</p>
                      </td>
                      <td className="py-3 px-4 align-top text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleScheduleCalendar(log)}
                            title="Catat ke Google Calendar"
                            className="p-1.5 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                          >
                            <CalendarPlus className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleCreateFollowUpTask(log)}
                            title="Buat Tugas Tindak Lanjut"
                            className="p-1.5 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                          >
                            <CheckSquare className="w-4 h-4" />
                          </button>
                          {isAdmin && (
                            <>
                              <button
                                type="button"
                                onClick={() => openEditModal(log)}
                                title="Sunting catatan"
                                className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteLog(log)}
                                title="Hapus catatan"
                                className="p-1.5 text-stone-500 hover:text-red-700 hover:bg-red-50 rounded-md"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      {/* Create / Edit Modal */}
      <AnimatePresence>
        {modalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 flex items-center justify-center bg-stone-900/40 p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
              className="w-full max-w-lg bg-white border border-stone-200 rounded-xl p-5 sm:p-6 shadow-xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-3 border-b border-stone-200 mb-4">
                <h2 className="text-base font-bold text-stone-900">
                  {editingLog ? 'Edit Catatan Kerja Karyawan' : 'Catat Kerja & Kehadiran'}
                </h2>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="p-1.5 text-stone-400 hover:text-stone-700 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {formError && (
                <div className="mb-4 p-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
                  {formError}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                {isAdmin && employees.length > 0 && !editingLog && (
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Pilih dari Daftar Karyawan (Opsional)
                    </label>
                    <select
                      defaultValue=""
                      onChange={(e) => handleSelectKnownEmployee(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-stone-50 focus:outline-none focus:border-orange-600"
                    >
                      <option value="">-- Pilih Karyawan Terdaftar --</option>
                      {employees.map((emp) => (
                        <option key={emp.id} value={emp.id}>
                          {emp.employeeName} ({emp.division})
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Nama Karyawan
                    </label>
                    <input
                      type="text"
                      required
                      readOnly={!isAdmin}
                      maxLength={FIELD_LIMITS.employeeNameMax}
                      value={employeeName}
                      onChange={(e) => setEmployeeName(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg read-only:bg-stone-50 focus:outline-none focus:border-orange-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">Divisi</label>
                    <select
                      value={division}
                      disabled={!isAdmin}
                      onChange={(e) => handleDivisionChange(e.target.value as EmployeeDivision)}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white disabled:bg-stone-50 focus:outline-none focus:border-orange-600"
                    >
                      {EMPLOYEE_DIVISIONS.map((div) => (
                        <option key={div} value={div}>
                          {div}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {isAdmin && (
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Email Akun Karyawan (Opsional agar tampil di akun ybs)
                    </label>
                    <input
                      type="email"
                      maxLength={FIELD_LIMITS.emailMax}
                      value={employeeEmail}
                      onChange={(e) => setEmployeeEmail(e.target.value)}
                      placeholder="karyawan@gmail.com"
                      className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                )}

                <div
                  className={`grid grid-cols-1 ${
                    division === 'Host Live' ? 'sm:grid-cols-2' : ''
                  } gap-4`}
                >
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Tanggal Kerja
                    </label>
                    <input
                      type="date"
                      required
                      value={workDate}
                      onChange={(e) => setWorkDate(e.target.value)}
                      className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                  {division === 'Host Live' && (
                    <div>
                      <label className="block text-xs font-medium text-stone-700 mb-1">
                        Status Shift Kerja
                      </label>
                      <select
                        value={shift || 'Shift 1'}
                        onChange={(e) => setShift(e.target.value as EmployeeShift)}
                        className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                      >
                        {HOST_LIVE_SHIFTS.map((sh) => (
                          <option key={sh} value={sh}>
                            {sh}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Status Kehadiran
                    </label>
                    <select
                      value={attendanceStatus}
                      onChange={(e) => setAttendanceStatus(e.target.value as AttendanceStatus)}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                    >
                      {ATTENDANCE_STATUSES.map((st) => (
                        <option key={st} value={st}>
                          {st}
                        </option>
                      ))}
                    </select>
                  </div>

                  {attendanceStatus === 'Terlambat' && (
                    <div>
                      <label className="block text-xs font-medium text-stone-700 mb-1">
                        Durasi Terlambat (Menit)
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={FIELD_LIMITS.lateMinutesMax}
                        required
                        value={lateMinutes}
                        onChange={(e) => setLateMinutes(e.target.value)}
                        className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                      />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Daftar Kerja Harian
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.workTaskMax}
                    value={workTask}
                    onChange={(e) => setWorkTask(e.target.value)}
                    placeholder="Misal: Packing batch pagi / Host Live TikTok / Editing Reels"
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Catatan / Alasan (Telat, Izin, Sakit, Alpha)
                  </label>
                  <textarea
                    rows={2}
                    maxLength={FIELD_LIMITS.attendanceNotesMax}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div className="flex flex-col-reverse sm:flex-row justify-end gap-2.5 sm:gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="px-4 py-2.5 sm:py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="px-4 py-2.5 sm:py-2 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 disabled:opacity-60"
                  >
                    {saving ? 'Menyimpan...' : 'Simpan Catatan'}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
