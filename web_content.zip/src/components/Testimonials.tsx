import { testimonials } from "../data/content";
import { StarIcon } from "./icons";

export function Testimonials() {
  return (
    <section id="testimonials" className="relative py-20 sm:py-28">
      <div className="pointer-events-none absolute right-0 top-1/4 h-[400px] w-[400px] rounded-full bg-violet-600/10 blur-[120px]" />

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <p className="reveal text-sm font-semibold tracking-wider text-brand-400 uppercase">
            Testimonials
          </p>
          <h2 className="reveal delay-100 mt-3 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            Loved by teams who{" "}
            <span className="text-gradient-brand">hate busywork</span>
          </h2>
          <p className="reveal delay-200 mt-4 text-base text-ink-400 sm:text-lg">
            From scrappy startups to regulated enterprises—operators choose
            Cascade when the stakes are high and the pace is faster.
          </p>
        </div>

        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {testimonials.map((t, i) => {
            const delays = ["delay-100", "delay-200", "delay-300"] as const;
            return (
            <figure
              key={t.name}
              className={`reveal ${delays[i]} card-lift flex flex-col rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.06] to-white/[0.02] p-6 sm:p-7`}
            >
              <div className="flex gap-0.5" aria-label={`${t.rating} out of 5 stars`}>
                {Array.from({ length: t.rating }).map((_, si) => (
                  <StarIcon
                    key={si}
                    size={16}
                    className="text-amber-400"
                  />
                ))}
              </div>
              <blockquote className="mt-4 flex-1">
                <p className="text-sm leading-relaxed text-ink-300 sm:text-[15px]">
                  “{t.quote}”
                </p>
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3 border-t border-white/8 pt-5">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-brand-400 to-brand-700 text-sm font-semibold text-white">
                  {t.avatar}
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">
                    {t.name}
                  </div>
                  <div className="text-xs text-ink-500">
                    {t.role}, {t.company}
                  </div>
                </div>
              </figcaption>
            </figure>
          );
          })}
        </div>

        {/* Rating bar */}
        <div className="reveal mt-12 flex flex-col items-center justify-center gap-4 sm:flex-row sm:gap-8">
          <div className="flex items-center gap-2">
            <div className="flex gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <StarIcon key={i} size={18} className="text-amber-400" />
              ))}
            </div>
            <span className="text-sm font-medium text-white">4.9 / 5</span>
          </div>
          <div className="hidden h-4 w-px bg-white/15 sm:block" />
          <p className="text-sm text-ink-500">
            Based on 2,400+ reviews on G2, Capterra & Gartner
          </p>
        </div>
      </div>
    </section>
  );
}
