import { Play, Star } from "lucide-react";
import { REVIEWS } from "../lib/data";

function Stars({ n }: { n: number }) {
  return (
    <div className="flex gap-0.5" aria-label={`${n} de 5 estrellas`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} size={13} className={i < n ? "fill-gold text-gold" : "text-slate-700"} aria-hidden="true" />
      ))}
    </div>
  );
}

export default function Testimonials() {
  return (
    <section id="opiniones" className="scroll-mt-28 border-t border-white/5 bg-[#070c26]/60 py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="eyebrow">Prueba social</p>
            <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-white sm:text-5xl">
              Les encanta.<br /><span className="grad-text">Y no quieren su TV Box de vuelta.</span>
            </h2>
          </div>
          <div className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.03] px-5 py-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-600">
              <Play size={22} fill="#04061a" className="text-abyss" aria-hidden="true" />
            </div>
            <div>
              <p className="font-display text-3xl font-black leading-none text-white">4.8<span className="text-base text-slate-500">/5</span></p>
              <Stars n={5} />
              <p className="mt-1 text-[11px] text-slate-500">+12.400 reseñas en Google Play</p>
            </div>
          </div>
        </div>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {REVIEWS.map((r) => (
            <figure key={r.name} className="tile flex flex-col rounded-2xl p-5">
              <Stars n={r.stars} />
              <blockquote className="mt-3 flex-1 text-sm leading-relaxed text-slate-200">“{r.text}”</blockquote>
              <figcaption className="mt-4 flex items-center gap-3 border-t border-white/5 pt-4">
                <span className={`flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br text-[11px] font-bold text-white ${r.tone}`}>{r.initials}</span>
                <span>
                  <span className="block text-sm font-bold text-white">{r.name}</span>
                  <span className="text-[11px] text-slate-500">{r.role}</span>
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
        <p className="mt-5 text-center text-[10px] uppercase tracking-[0.22em] text-slate-600">Reseñas verificadas de Google Play · selección editorial TV LO3 · actualizadas semanalmente</p>
      </div>
    </section>
  );
}
