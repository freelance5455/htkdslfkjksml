import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowDown,
  Check,
  Copy,
  ExternalLink,
  Globe,
  Volume2,
  Wrench,
} from 'lucide-react';
import type { ChatMessage, UtilityPanelId } from '../types';

interface ConversationPanelProps {
  messages: ChatMessage[];
  assistantName: string;
  isThinking: boolean;
  lowPowerActive?: boolean;
  onSelectPrompt: (prompt: string) => void;
  onOpenUtility: (utilityId: UtilityPanelId) => void;
  onSpeakMessage: (text: string) => void;
}

const STARTER_PROMPTS = [
  'Jarvis, aaj kya kar sakte ho?',
  'Time batao',
  'Meri battery kitni hai',
  'Mujhe search karke batao latest AI news',
  'Calculator kholo',
  'Quantum computing simple Hinglish mein samjhao',
];

export const ConversationPanel: React.FC<ConversationPanelProps> = ({
  messages,
  assistantName,
  isThinking,
  lowPowerActive = false,
  onSelectPrompt,
  onOpenUtility,
  onSpeakMessage,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const scrollEndRef = useRef<HTMLDivElement | null>(null);
  const isNearBottomRef = useRef(true);
  const knownIdsRef = useRef<Set<string>>(new Set(messages.map((m) => m.id)));
  const [typingState, setTypingState] = useState<{
    id: string;
    visibleCount: number;
  } | null>(null);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(100);
  const [isScrollable, setIsScrollable] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  const updateScrollMetrics = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const maxScroll = el.scrollHeight - el.clientHeight;
    if (maxScroll <= 16) {
      setIsScrollable(false);
      setShowScrollBottom(false);
      setScrollProgress(100);
      isNearBottomRef.current = true;
      return;
    }
    setIsScrollable(true);
    const distanceFromBottom = maxScroll - el.scrollTop;
    isNearBottomRef.current = distanceFromBottom <= 120;
    setShowScrollBottom(distanceFromBottom > 96);
    setScrollProgress(Math.min(100, Math.max(0, Math.round((el.scrollTop / maxScroll) * 100))));
  };

  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    scrollEndRef.current?.scrollIntoView({ behavior, block: 'end' });
    isNearBottomRef.current = true;
    setShowScrollBottom(false);
  };

  // Start typewriter animation only for newly arrived non-error assistant messages
  useEffect(() => {
    let newestToAnimate: ChatMessage | null = null;
    const now = Date.now();

    for (const msg of messages) {
      if (!knownIdsRef.current.has(msg.id)) {
        knownIdsRef.current.add(msg.id);
        if (
          msg.role === 'assistant' &&
          !msg.isError &&
          msg.text.length > 0 &&
          now - msg.timestamp < 5000 &&
          !reducedMotion &&
          !lowPowerActive
        ) {
          newestToAnimate = msg;
        }
      }
    }

    if (newestToAnimate) {
      setTypingState({ id: newestToAnimate.id, visibleCount: 0 });
    }
  }, [messages, lowPowerActive, reducedMotion]);

  // Advance active typewriter effect smoothly
  useEffect(() => {
    if (!typingState) return;
    if (reducedMotion || lowPowerActive) {
      setTypingState(null);
      return;
    }

    const target = messages.find((m) => m.id === typingState.id);
    if (!target || typingState.visibleCount >= target.text.length) {
      setTypingState(null);
      return;
    }

    const step = Math.max(1, Math.min(6, Math.ceil(target.text.length / 95)));
    const timer = window.setTimeout(() => {
      setTypingState((prev) => {
        if (!prev || prev.id !== target.id) return prev;
        const nextCount = Math.min(target.text.length, prev.visibleCount + step);
        return nextCount >= target.text.length
          ? null
          : { id: target.id, visibleCount: nextCount };
      });
      if (isNearBottomRef.current) {
        scrollEndRef.current?.scrollIntoView({ behavior: 'auto', block: 'end' });
      }
    }, 18);

    return () => window.clearTimeout(timer);
  }, [typingState, messages, lowPowerActive, reducedMotion]);

  useEffect(() => {
    const lastRole = messages[messages.length - 1]?.role;
    if (lastRole === 'user' || isNearBottomRef.current) {
      scrollEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
    const timer = window.setTimeout(updateScrollMetrics, 80);
    return () => window.clearTimeout(timer);
  }, [messages.length, isThinking]);

  const handleCopy = async (id: string, text: string) => {
    let copied = false;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
        copied = true;
      }
    } catch {
      // Fallback below for restricted iframe or mobile WebView contexts
    }

    if (!copied) {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.setAttribute('readonly', '');
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        copied = document.execCommand('copy');
        document.body.removeChild(textarea);
      } catch {
        copied = false;
      }
    }

    if (copied) {
      setCopiedId(id);
      window.setTimeout(() => setCopiedId((prev) => (prev === id ? null : prev)), 1800);
    }
  };

  if (messages.length === 0 && !isThinking) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center px-3 py-4 text-center">
        <p className="max-w-sm text-sm text-slate-300 leading-relaxed">
          Tap the mic or type below in Hindi, Hinglish, or English. Try a quick starter:
        </p>
        <div className="mt-4 flex flex-wrap justify-center gap-2 max-w-lg">
          {STARTER_PROMPTS.map((prompt) => (
            <button
              key={prompt}
              type="button"
              onClick={() => onSelectPrompt(prompt)}
              className="min-h-[44px] rounded-xl border border-sky-400/20 bg-[#091428]/90 px-3.5 py-2 text-left text-xs font-medium text-sky-100 hover:border-cyan-400/45 hover:bg-[#0d1d38] transition-colors"
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex flex-1 min-h-0 flex-col">
      {isScrollable && (
        <div
          className="h-[2px] w-full shrink-0 bg-sky-950/60"
          role="progressbar"
          aria-label="Conversation reading progress"
          aria-valuenow={scrollProgress}
          aria-valuemin={0}
          aria-valuemax={100}
        >
          <div
            className="h-full bg-gradient-to-r from-sky-500 to-cyan-300 transition-[width] duration-150"
            style={{ width: `${scrollProgress}%` }}
          />
        </div>
      )}

      <div
        ref={scrollContainerRef}
        onScroll={updateScrollMetrics}
        className="flex-1 overflow-y-auto custom-scrollbar px-3 sm:px-4 py-3 space-y-3.5"
      >
      {messages.map((msg) => {
        const isUser = msg.role === 'user';
        const isTyping = typingState?.id === msg.id;
        const displayedText = isTyping
          ? msg.text.slice(0, typingState.visibleCount)
          : msg.text;
        const timeStr = new Date(msg.timestamp).toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        });

        return (
          <div
            key={msg.id}
            className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
          >
            <div
              onClick={isTyping ? () => setTypingState(null) : undefined}
              title={isTyping ? 'Tap to show full response' : undefined}
              className={`max-w-[90%] sm:max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                isUser
                  ? 'bg-sky-500/20 border border-sky-400/35 text-slate-50 rounded-br-md'
                  : msg.isError
                    ? 'bg-rose-950/40 border border-rose-400/30 text-rose-100 rounded-bl-md'
                    : 'bg-[#0b1529]/95 border border-sky-400/18 text-slate-100 rounded-bl-md'
              }`}
            >
              {/* Clean unboxed attribution metadata */}
              <div className="mb-1.5 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
                <span className="font-medium text-sky-300/90">
                  {isUser ? 'You' : assistantName}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">{timeStr}</span>
                {!isUser && msg.knowledgeMode && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span
                      className={
                        msg.knowledgeMode === 'live-web'
                          ? 'text-cyan-300 font-medium'
                          : 'text-slate-400'
                      }
                    >
                      {msg.knowledgeMode === 'live-web'
                        ? 'Live Web Search'
                        : msg.knowledgeMode === 'local-command'
                          ? 'Device Command'
                          : 'AI Knowledge'}
                    </span>
                  </>
                )}
              </div>

              <div className="whitespace-pre-wrap break-words">
                {displayedText}
                {isTyping && (
                  <span
                    aria-hidden="true"
                    className="ml-0.5 inline-block h-[1em] w-[6px] align-text-bottom bg-cyan-300/90"
                  />
                )}
              </div>

              {/* Action Card for commands / tools / external URLs */}
              {!isTyping && msg.actionCard && (
                <div className="mt-3 pt-2.5 border-t border-sky-400/15">
                  {msg.actionCard.type === 'url' && msg.actionCard.url ? (
                    <a
                      href={msg.actionCard.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-cyan-500/15 border border-cyan-400/35 px-3.5 py-2 text-xs font-semibold text-cyan-200 hover:bg-cyan-500/25 transition-colors"
                    >
                      <ExternalLink className="h-4 w-4 shrink-0" />
                      <span>{msg.actionCard.label}</span>
                      {msg.actionCard.detail && (
                        <span className="text-cyan-300/70 font-normal">
                          ({msg.actionCard.detail})
                        </span>
                      )}
                    </a>
                  ) : msg.actionCard.type === 'utility' && msg.actionCard.utilityId ? (
                    <button
                      type="button"
                      onClick={() => onOpenUtility(msg.actionCard!.utilityId!)}
                      className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-sky-500/15 border border-sky-400/35 px-3.5 py-2 text-xs font-semibold text-sky-200 hover:bg-sky-500/25 transition-colors"
                    >
                      <Wrench className="h-4 w-4 shrink-0" />
                      <span>{msg.actionCard.label}</span>
                    </button>
                  ) : msg.actionCard.type === 'unsupported' ? (
                    <div className="flex items-start gap-2 text-xs text-amber-200/90">
                      <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-amber-300" />
                      <span>
                        {msg.actionCard.label}
                        {msg.actionCard.detail ? ` — ${msg.actionCard.detail}` : ''}
                      </span>
                    </div>
                  ) : null}
                </div>
              )}

              {/* Grounded Web Search Source Links */}
              {!isTyping && msg.sources && msg.sources.length > 0 && (
                <div className="mt-3 pt-2.5 border-t border-sky-400/15">
                  <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-medium text-cyan-300">
                    <Globe className="h-3.5 w-3.5" />
                    <span>Verified Web Sources</span>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    {msg.sources.slice(0, 5).map((src, index) => (
                      <a
                        key={`${src.uri}-${index}`}
                        href={src.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between gap-2 rounded-lg border border-sky-400/15 bg-[#060d1c] px-2.5 py-2 text-xs text-sky-200 hover:border-cyan-400/40 transition-colors"
                      >
                        <span className="truncate">{src.title}</span>
                        <ExternalLink className="h-3.5 w-3.5 shrink-0 text-cyan-400" />
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {/* Assistant message action row: Copy & Speak */}
              {!isUser && (
                <div className="mt-2.5 flex items-center gap-1 pt-1">
                  <button
                    type="button"
                    onClick={() => void handleCopy(msg.id, msg.text)}
                    aria-label="Copy AI response"
                    className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs text-slate-400 hover:bg-slate-800/70 hover:text-cyan-200 transition-colors"
                  >
                    {copiedId === msg.id ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-cyan-300" />
                        <span className="text-cyan-300">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                  {!msg.isError && (
                    <button
                      type="button"
                      onClick={() => onSpeakMessage(msg.text)}
                      aria-label="Speak response"
                      className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs text-slate-400 hover:bg-slate-800/70 hover:text-cyan-200 transition-colors"
                    >
                      <Volume2 className="h-3.5 w-3.5" />
                      <span>Speak</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        );
      })}

      {isThinking && (
        <div className="flex items-start">
          <div className="rounded-2xl rounded-bl-md border border-sky-400/20 bg-[#0b1529]/95 px-4 py-3 text-sm text-sky-200">
            <div className="flex items-center gap-2">
              <span className="inline-block h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
              <span>PROCESSING · {assistantName} is thinking…</span>
            </div>
          </div>
        </div>
      )}

      <div ref={scrollEndRef} />
      </div>

      {showScrollBottom && (
        <button
          type="button"
          onClick={() => scrollToBottom('smooth')}
          aria-label="Scroll to bottom of conversation"
          className="absolute bottom-3 right-3 z-20 inline-flex min-h-[44px] items-center gap-2 rounded-full border border-cyan-400/45 bg-[#071329]/95 px-3.5 py-2 text-xs font-semibold text-cyan-200 shadow-lg backdrop-blur-md hover:bg-[#0d2042] active:scale-[0.97] transition-all"
        >
          <span className="font-mono tabular-nums text-[11px] text-sky-300">
            {scrollProgress}%
          </span>
          <ArrowDown className="h-4 w-4 text-cyan-300" />
          <span>Latest</span>
        </button>
      )}
    </div>
  );
};
