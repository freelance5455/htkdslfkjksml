/**
 * GODEX Phase 1 - Project Architecture Intelligence & Module Graph View
 * Visual AST layer decomposition, interactive module inspector, dependency tracing, and symbol cross-referencing.
 */

import React, { useState, useEffect } from 'react';
import { 
  Layers, 
  Box, 
  Cpu, 
  Database, 
  FileCode, 
  ArrowRight, 
  ExternalLink, 
  Sparkles,
  GitFork,
  Code2,
  CheckCircle2,
  Workflow,
  AlertTriangle,
  Package,
  Route as RouteIcon,
  Zap,
  RefreshCw,
  Search
} from 'lucide-react';
import { ProjectIntelligence } from '../intelligence/intelligenceEngine';
import { ProjectIntelligenceState, GraphNode, SymbolKind } from '../intelligence/types';

interface GodexArchitectureViewProps {
  files: Record<string, string>;
  onSelectFile: (path: string) => void;
}

export const GodexArchitectureView: React.FC<GodexArchitectureViewProps> = ({
  files,
  onSelectFile
}) => {
  const [intelState, setIntelState] = useState<ProjectIntelligenceState>(ProjectIntelligence.getState());
  const [selectedNodeId, setSelectedNodeId] = useState<string>('src/App.tsx');
  const [activeLayerFilter, setActiveLayerFilter] = useState<'all' | 'ui' | 'services' | 'core' | 'config' | 'external'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const unsub = ProjectIntelligence.subscribe(state => {
      setIntelState(state);
      if (!state.files[selectedNodeId] && Object.keys(state.files).length > 0) {
        setSelectedNodeId(Object.keys(state.files)[0]);
      }
    });
    return unsub;
  }, [selectedNodeId]);

  const { graph, metadata, health } = intelState;

  // Build architecture layers dynamically from graph nodes
  const layers = [
    {
      id: 'ui',
      name: 'UI & Component Layer',
      badge: 'Frontend',
      color: 'border-cyan-500/40 bg-cyan-950/20 text-cyan-300',
      description: 'React functional components, responsive views, modal dialogs, and layout shells.',
      nodes: graph.nodes.filter(n => n.layer === 'ui')
    },
    {
      id: 'services',
      name: 'Services & Intelligence Layer',
      badge: 'Logic & AI',
      color: 'border-purple-500/40 bg-purple-950/20 text-purple-300',
      description: 'Project Intelligence Engine, AST Parsers, Graph Builders, Terminal Sandbox, and AI Brain.',
      nodes: graph.nodes.filter(n => n.layer === 'services')
    },
    {
      id: 'core',
      name: 'Core State & Type Manifests',
      badge: 'Core State',
      color: 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300',
      description: 'TypeScript interfaces, project contracts, schemas, and starter blueprints.',
      nodes: graph.nodes.filter(n => n.layer === 'core')
    },
    {
      id: 'config',
      name: 'Configuration & Entry Layer',
      badge: 'Config',
      color: 'border-amber-500/40 bg-amber-950/20 text-amber-300',
      description: 'Vite config, Package manifests, Tailwind styles, and HTML entry points.',
      nodes: graph.nodes.filter(n => n.layer === 'config')
    },
    {
      id: 'external',
      name: 'External Package Dependencies',
      badge: 'Packages',
      color: 'border-blue-500/40 bg-blue-950/20 text-blue-300',
      description: 'NPM packages, framework libraries, and UI component dependencies.',
      nodes: graph.nodes.filter(n => n.layer === 'external')
    }
  ];

  const selectedFile = intelState.files[selectedNodeId];
  const selectedNode = graph.nodes.find(n => n.id === selectedNodeId) || graph.nodes[0];

  // Incoming (who imports this?) & Outgoing (what does this import?)
  const incomingDependencies = graph.reverseAdjacency[selectedNodeId] || [];
  const outgoingDependencies = graph.adjacency[selectedNodeId] || [];

  const getSymbolBadgeColor = (kind: SymbolKind) => {
    switch (kind) {
      case 'component': return 'bg-cyan-950/70 text-cyan-300 border-cyan-800/60';
      case 'hook': return 'bg-indigo-950/70 text-indigo-300 border-indigo-800/60';
      case 'function': return 'bg-purple-950/70 text-purple-300 border-purple-800/60';
      case 'interface': return 'bg-emerald-950/70 text-emerald-300 border-emerald-800/60';
      case 'type': return 'bg-teal-950/70 text-teal-300 border-teal-800/60';
      case 'class': return 'bg-amber-950/70 text-amber-300 border-amber-800/60';
      default: return 'bg-neutral-800 text-neutral-300 border-neutral-700';
    }
  };

  const filteredLayers = activeLayerFilter === 'all' 
    ? layers 
    : layers.filter(l => l.id === activeLayerFilter);

  return (
    <div className="flex-1 h-full flex flex-col bg-[#08090D] overflow-y-auto select-none font-sans p-4 md:p-6 space-y-6">
      {/* Top Header & Metrics */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1C2230] pb-5">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#141A26] border border-purple-500/40 flex items-center justify-center text-purple-400 shadow-md">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">Project Intelligence & Module Graph</h2>
              <p className="text-xs text-neutral-400 font-mono">AST Module Graph, Symbol Index & Dependency Tracing</p>
            </div>
          </div>
        </div>

        {/* Global Stats Counter */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="px-3 py-2 rounded-lg bg-[#0E121B] border border-[#1E2638]">
            <div className="text-[10px] text-neutral-500 uppercase">Tracked Files</div>
            <div className="text-sm font-bold text-cyan-300">{metadata.totalFiles}</div>
          </div>
          <div className="px-3 py-2 rounded-lg bg-[#0E121B] border border-[#1E2638]">
            <div className="text-[10px] text-neutral-500 uppercase">AST Symbols</div>
            <div className="text-sm font-bold text-purple-300">{health.totalSymbols}</div>
          </div>
          <div className="px-3 py-2 rounded-lg bg-[#0E121B] border border-[#1E2638]">
            <div className="text-[10px] text-neutral-500 uppercase">Graph Edges</div>
            <div className="text-sm font-bold text-emerald-300">{graph.edges.length}</div>
          </div>
          <div className="px-3 py-2 rounded-lg bg-[#0E121B] border border-[#1E2638]">
            <div className="text-[10px] text-neutral-500 uppercase">Health Score</div>
            <div className="text-sm font-bold text-cyan-300">{health.score}%</div>
          </div>
        </div>
      </div>

      {/* Layer Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'all', label: 'All Layers' },
          { id: 'ui', label: 'UI Components' },
          { id: 'services', label: 'Services & Engine' },
          { id: 'core', label: 'Core State & Types' },
          { id: 'config', label: 'Config & Entry' },
          { id: 'external', label: 'External Packages' }
        ].map(filter => (
          <button
            key={filter.id}
            onClick={() => setActiveLayerFilter(filter.id as any)}
            className={`px-3 py-1 rounded-lg text-xs font-mono transition-all whitespace-nowrap ${
              activeLayerFilter === filter.id
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm font-bold'
                : 'bg-[#0E121B] text-neutral-400 hover:text-neutral-200 border border-[#1A2230]'
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {/* Main Architecture Decomposition */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Left 2 Cols: Architectural Layers */}
        <div className="xl:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-wider">
              Architectural Hierarchy & Module Layers
            </span>
            <span className="text-[10px] font-mono text-neutral-500">
              Auto-constructed via AST Ingestion
            </span>
          </div>

          <div className="space-y-4">
            {filteredLayers.map((layer, idx) => (
              <div
                key={layer.id}
                className="p-4 rounded-xl bg-[#0B0E16] border border-[#1B2230] space-y-3 relative group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-mono px-2 py-0.5 rounded font-bold border ${layer.color}`}>
                      {layer.badge}
                    </span>
                    <h3 className="text-sm font-bold text-white">{layer.name}</h3>
                  </div>
                  <span className="text-[10px] font-mono text-neutral-500">
                    {layer.nodes.length} nodes
                  </span>
                </div>

                <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                  {layer.description}
                </p>

                {/* Module Nodes Grid */}
                <div className="flex flex-wrap gap-2 pt-1">
                  {layer.nodes.map((node) => {
                    const isSelected = selectedNodeId === node.id;
                    return (
                      <button
                        key={node.id}
                        onClick={() => setSelectedNodeId(node.id)}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono transition-all ${
                          isSelected
                            ? 'bg-[#151E2E] text-cyan-300 border border-cyan-500/70 shadow-sm shadow-cyan-950/40'
                            : 'bg-[#0E121B] text-neutral-300 hover:bg-[#141A26] border border-[#1F2738]'
                        }`}
                      >
                        {node.layer === 'external' ? (
                          <Package className="w-3.5 h-3.5 text-blue-400" />
                        ) : (
                          <FileCode className={`w-3.5 h-3.5 ${isSelected ? 'text-cyan-400' : 'text-neutral-500'}`} />
                        )}
                        <span className="truncate max-w-[170px]">{node.name}</span>
                        {node.symbolsCount > 0 && (
                          <span className="text-[9px] font-bold px-1 rounded bg-[#162032] text-cyan-400">
                            {node.symbolsCount}s
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: Selected Node Deep Inspector */}
        <div className="space-y-4">
          <span className="text-xs font-mono font-bold text-neutral-400 uppercase tracking-wider">
            Module & Symbol Inspector
          </span>

          {selectedNode ? (
            <div className="p-4 rounded-xl bg-[#0B0E16] border border-[#1F2738] space-y-4 font-mono text-xs">
              <div className="space-y-1">
                <div className="text-[10px] text-neutral-500 uppercase">Selected Module Node</div>
                <div className="text-sm font-bold text-white truncate">{selectedNode.name}</div>
                <div className="text-[11px] text-cyan-400 truncate">{selectedNode.id}</div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#181F2C]">
                <div className="p-2 rounded bg-[#0E121A] border border-[#1A2230]">
                  <div className="text-[10px] text-neutral-500">Symbols Defined</div>
                  <div className="text-sm font-bold text-cyan-300">{selectedFile ? selectedFile.symbols.length : 0}</div>
                </div>
                <div className="p-2 rounded bg-[#0E121A] border border-[#1A2230]">
                  <div className="text-[10px] text-neutral-500">Lines / Size</div>
                  <div className="text-sm font-bold text-purple-300">
                    {selectedFile ? `${selectedFile.lines}L (${(selectedFile.bytes / 1024).toFixed(1)}K)` : 'External'}
                  </div>
                </div>
              </div>

              {/* Defined Symbols List */}
              {selectedFile && selectedFile.symbols.length > 0 && (
                <div className="pt-2 border-t border-[#181F2C] space-y-2">
                  <div className="text-[10px] text-neutral-400 uppercase font-bold flex items-center justify-between">
                    <span>Exported Symbols ({selectedFile.symbols.length})</span>
                    <span className="text-cyan-400 text-[9px]">AST PARSED</span>
                  </div>
                  <div className="space-y-1 max-h-36 overflow-y-auto pr-1">
                    {selectedFile.symbols.map(sym => (
                      <div key={sym.id} className="p-1.5 rounded bg-[#0E121B] border border-[#182030] flex items-center justify-between text-[11px]">
                        <span className="text-white font-semibold truncate">{sym.name}</span>
                        <span className={`text-[9px] uppercase px-1.5 py-0.2 rounded border ${getSymbolBadgeColor(sym.kind)}`}>
                          {sym.kind}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Incoming Dependencies */}
              <div className="pt-2 border-t border-[#181F2C] space-y-1.5">
                <div className="text-[10px] text-neutral-400 uppercase font-bold">
                  Imported By ({incomingDependencies.length})
                </div>
                {incomingDependencies.length === 0 ? (
                  <div className="text-[11px] text-neutral-500">No internal modules import this.</div>
                ) : (
                  <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                    {incomingDependencies.map(dep => (
                      <span key={dep} onClick={() => setSelectedNodeId(dep)} className="cursor-pointer text-[10px] bg-[#121826] hover:bg-[#182236] text-cyan-300 px-2 py-0.5 rounded border border-[#1E283E] truncate max-w-full">
                        {dep.split('/').pop()}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Outgoing Dependencies */}
              <div className="pt-2 border-t border-[#181F2C] space-y-1.5">
                <div className="text-[10px] text-neutral-400 uppercase font-bold">
                  Imports ({outgoingDependencies.length})
                </div>
                {outgoingDependencies.length === 0 ? (
                  <div className="text-[11px] text-neutral-500">No outgoing imports.</div>
                ) : (
                  <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                    {outgoingDependencies.map(dep => (
                      <span key={dep} onClick={() => !dep.startsWith('pkg:') && setSelectedNodeId(dep)} className={`text-[10px] px-2 py-0.5 rounded border truncate max-w-full ${
                        dep.startsWith('pkg:') 
                          ? 'bg-[#101420] text-blue-300 border-blue-900/40' 
                          : 'cursor-pointer bg-[#121826] hover:bg-[#182236] text-purple-300 border-[#1E283E]'
                      }`}>
                        {dep.replace('pkg:', '').split('/').pop()}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Open in Editor */}
              {!selectedNode.id.startsWith('pkg:') && (
                <button
                  onClick={() => onSelectFile(selectedNode.id)}
                  className="w-full py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold transition-colors flex items-center justify-center gap-2 shadow-sm font-sans"
                >
                  <span>Open in Source Editor</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          ) : (
            <div className="p-8 text-center text-xs text-neutral-500 rounded-xl bg-[#0B0E16] border border-[#1B2230]">
              Select a module from the architecture diagram to inspect its metadata and symbols.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
