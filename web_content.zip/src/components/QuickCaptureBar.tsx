import React, { useState } from "react";
import {
  Plus,
  Mic,
  CheckSquare,
  Sparkles,
  Frame,
  ChevronDown,
  ArrowRight,
  Smile,
  Tag,
  Paperclip,
  Check
} from "lucide-react";
import { Note, ThemeAccent } from "../types";
import { ALL_FRAME_PRESETS, FramePreset } from "../utils/frames";
import { THEME_ACCENTS } from "../utils/theme";

interface QuickCaptureBarProps {
  onSaveQuickNote: (note: Partial<Note>) => void;
  onOpenDetailedModal: (initialDraft?: Partial<Note>) => void;
  categories: string[];
  themeAccent?: ThemeAccent;
  onOpenAIChat: () => void;
  onOpenSideGallery: () => void;
}

export const QuickCaptureBar: React.FC<QuickCaptureBarProps> = ({
  onSaveQuickNote,
  onOpenDetailedModal,
  categories,
  themeAccent = "teal",
  onOpenAIChat,
  onOpenSideGallery,
}) => {
  const [content, setContent] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(categories[0] || "Genel");
  const [isChecklistMode, setIsChecklistMode] = useState(false);
  const [selectedFrame, setSelectedFrame] = useState<FramePreset | null>(null);
  const [showFrameDropdown, setShowFrameDropdown] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  const themeDef = THEME_ACCENTS[themeAccent] || THEME_ACCENTS.teal;

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    let finalContent = content.trim();
    let tasks: { id: string; text: string; completed: boolean }[] = [];

    if (isChecklistMode) {
      const lines = content.split("\n").filter((l) => l.trim().length > 0);
      tasks = lines.map((l, i) => ({
        id: `task-${Date.now()}-${i}`,
        text: l.replace(/^[-*•]\s*/, "").trim(),
        completed: false,
      }));
      finalContent = lines.map((l) => `• ${l.replace(/^[-*•]\s*/, "").trim()}`).join("<br/>");
    }

    if (selectedFrame) {
      finalContent = selectedFrame.getHtml(finalContent, content.slice(0, 30));
    }

    onSaveQuickNote({
      title: content.length > 40 ? content.substring(0, 40) + "..." : content,
      content: finalContent,
      category: selectedCategory === "Tümü" ? "Genel" : selectedCategory,
      tags: isChecklistMode ? ["#görevler"] : selectedFrame ? ["#çerçeve"] : ["#hızlı"],
      tasks: tasks.length > 0 ? tasks : undefined,
    });

    setContent("");
    setIsChecklistMode(false);
    setSelectedFrame(null);
    setShowSuccessToast(true);
    setTimeout(() => setShowSuccessToast(false), 2500);
  };

  const handleDetailedOpen = () => {
    onOpenDetailedModal({
      title: content.length > 40 ? content.substring(0, 40) + "..." : content,
      content: isChecklistMode
        ? content
            .split("\n")
            .map((l) => `• ${l.trim()}`)
            .join("\n")
        : content,
      category: selectedCategory === "Tümü" ? "Genel" : selectedCategory,
    });
    setContent("");
    setIsChecklistMode(false);
    setSelectedFrame(null);
  };

  return (
    <div className="relative w-full">
      {/* Toast Alert */}
      {showSuccessToast && (
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 z-20 bg-emerald-600 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg flex items-center gap-1.5 animate-in fade-in slide-in-from-top-2">
          <Check className="w-3.5 h-3.5" />
          <span>Hızlı not kaydedildi!</span>
        </div>
      )}

      <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl p-2.5 sm:p-4 border border-slate-200/90 dark:border-slate-800 shadow-sm hover:shadow-md transition-all focus-within:ring-2 focus-within:ring-teal-500/30 focus-within:border-teal-500">
        <form onSubmit={handleQuickSubmit} className="space-y-2.5">
          {/* Top text input */}
          <div className="flex items-start gap-2 sm:gap-2.5">
            <div
              className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl ${themeDef.bgLight} ${themeDef.bgLightDark} ${themeDef.text} ${themeDef.textDark} flex items-center justify-center shrink-0 mt-0.5`}
            >
              {isChecklistMode ? <CheckSquare className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
            </div>

            <div className="flex-1 min-w-0">
              {isChecklistMode ? (
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Yapılacakları satır satır yazın (Enter ile yeni madde)..."
                  rows={3}
                  className="w-full bg-transparent text-xs sm:text-sm font-medium text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none resize-none"
                />
              ) : (
                <input
                  type="text"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Hızlıca aklınızdaki bir fikri, notu veya görevi yazın... (Enter ile kaydet)"
                  className="w-full bg-transparent text-xs sm:text-sm font-medium text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none"
                />
              )}
            </div>
          </div>

          {/* Bottom toolbar */}
          <div className="flex items-center justify-between gap-1.5 sm:gap-2 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex-wrap">
            {/* Left helpers */}
            <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
              {/* Category selector */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-1 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none cursor-pointer"
              >
                {categories
                  .filter((c) => c !== "Tümü")
                  .map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
              </select>

              {/* Checklist mode toggle */}
              <button
                type="button"
                onClick={() => setIsChecklistMode(!isChecklistMode)}
                title="Yapılacaklar listesi modunu aç/kapat"
                className={`flex items-center gap-1 text-[11px] font-semibold px-2 py-1 rounded-xl border transition-colors ${
                  isChecklistMode
                    ? "bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-200 border-teal-300 dark:border-teal-700"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:bg-slate-200/60"
                }`}
              >
                <CheckSquare className="w-3 h-3 text-teal-600" />
                <span>Liste</span>
              </button>

              {/* 30-Frame Selector */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowFrameDropdown(!showFrameDropdown)}
                  title="30 Çerçeve Kutusundan Seç"
                  className={`flex items-center gap-1 text-[11px] font-semibold px-2 py-1 rounded-xl border transition-colors ${
                    selectedFrame
                      ? "bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-200 border-teal-400 font-bold"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:bg-slate-200/60"
                  }`}
                >
                  <Frame className="w-3 h-3 text-teal-600" />
                  <span>{selectedFrame ? selectedFrame.name : "Çerçeve"}</span>
                  <ChevronDown className="w-2.5 h-2.5 text-slate-400" />
                </button>

                {showFrameDropdown && (
                  <div className="absolute left-0 top-full mt-1 w-64 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-xl z-30 p-2 text-xs space-y-1 animate-in fade-in">
                    <div className="text-[10px] font-bold text-slate-400 px-1 uppercase tracking-wider">
                      Hızlı Çerçeve Seçimi
                    </div>
                    <div className="max-h-48 overflow-y-auto space-y-0.5 pr-1">
                      {ALL_FRAME_PRESETS.slice(0, 12).map((fp) => (
                        <button
                          key={fp.id}
                          type="button"
                          onClick={() => {
                            setSelectedFrame(selectedFrame?.id === fp.id ? null : fp);
                            setShowFrameDropdown(false);
                          }}
                          className={`w-full flex items-center justify-between px-2 py-1.5 rounded-lg text-left transition-colors ${
                            selectedFrame?.id === fp.id
                              ? "bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-bold"
                              : "hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
                          }`}
                        >
                          <span className="flex items-center gap-1.5">
                            <span>{fp.iconSymbol}</span>
                            <span>{fp.name}</span>
                          </span>
                          <span className="text-[9px] text-slate-400">{fp.category}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Elements & Stickers quick trigger */}
              <button
                type="button"
                onClick={onOpenSideGallery}
                title="Öğeler (Elements) & Çıkartma Kütüphanesini Aç"
                className="hidden sm:flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-200/60 transition-colors"
              >
                <span>🧩 Öğeler</span>
              </button>

              {/* AI Spark trigger */}
              <button
                type="button"
                onClick={onOpenAIChat}
                title="Yapay Zeka ile Fikir Geliştir"
                className="flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-100 transition-colors"
              >
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span className="hidden sm:inline">AI Fikir</span>
              </button>
            </div>

            {/* Right actions */}
            <div className="flex items-center gap-1.5 ml-auto">
              <button
                type="button"
                onClick={handleDetailedOpen}
                className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 px-2 py-1 rounded-lg transition-colors flex items-center gap-1"
              >
                <span>Gelişmiş Editör</span>
                <ArrowRight className="w-3 h-3" />
              </button>

              <button
                type="submit"
                disabled={!content.trim()}
                className={`px-4 py-1.5 rounded-xl text-xs font-bold text-white transition-all shadow-xs flex items-center gap-1 ${
                  content.trim()
                    ? `${themeDef.buttonBg} hover:opacity-95 active:scale-95 cursor-pointer`
                    : "bg-slate-300 dark:bg-slate-700 cursor-not-allowed opacity-60"
                }`}
              >
                <span>Kaydet</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
