import React, { useState } from 'react';
import { Camera, HardDrive, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';

interface PermisosModalProps {
  onAceptado: () => void;
}

export const PermisosModal: React.FC<PermisosModalProps> = ({ onAceptado }) => {
  const [solicitando, setSolicitando] = useState(false);
  const [estadoCamara, setEstadoCamara] = useState<'pendiente' | 'concedido' | 'denegado'>('pendiente');

  const solicitarPermisoCamara = async () => {
    if (estadoCamara === 'denegado') {
      onAceptado();
      return;
    }
    setSolicitando(true);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        stream.getTracks().forEach((track) => track.stop());
        setEstadoCamara('concedido');
        setTimeout(() => {
          onAceptado();
        }, 300);
      } else {
        setEstadoCamara('concedido');
        onAceptado();
      }
    } catch (err) {
      console.warn('Permiso de cámara no concedido o no disponible:', err);
      setEstadoCamara('denegado');
    } finally {
      setSolicitando(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-fadeIn">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 md:p-8 space-y-6">
        <div className="text-center space-y-2">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/10 dark:bg-amber-500/20 text-amber-500 flex items-center justify-center">
            <Camera size={32} />
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white">Permisos de la Aplicación</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Para que el taller funcione al 100%, necesitamos acceso a la cámara y al almacenamiento local del dispositivo.
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex items-start gap-3.5 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500 shrink-0">
              <Camera size={20} />
            </div>
            <div className="text-left flex-1">
              <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Cámara del Taller</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Fotografiar vehículos que entran, detalles de fallas, piezas y estado de entrega.
              </p>
            </div>
            {estadoCamara === 'concedido' && <CheckCircle2 className="text-emerald-500 shrink-0" size={20} />}
            {estadoCamara === 'denegado' && <AlertCircle className="text-amber-500 shrink-0" size={20} />}
          </div>

          <div className="flex items-start gap-3.5 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60">
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-500 shrink-0">
              <HardDrive size={20} />
            </div>
            <div className="text-left flex-1">
              <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Almacenamiento Local</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Guardar las carpetas por placa y fotos de manera privada en tu navegador.
              </p>
            </div>
            <CheckCircle2 className="text-emerald-500 shrink-0" size={20} />
          </div>
        </div>

        {estadoCamara === 'denegado' && (
          <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 text-xs text-amber-800 dark:text-amber-300">
            <p className="font-semibold">Cámara no detectada o permiso denegado.</p>
            <p className="mt-1">
              Puedes continuar de todos modos; tendrás la opción de subir fotos existentes o volver a activar la cámara en cualquier momento.
            </p>
          </div>
        )}

        <div className="space-y-2 pt-2">
          <button
            onClick={solicitarPermisoCamara}
            disabled={solicitando}
            className="w-full py-3.5 px-6 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm shadow-lg shadow-amber-600/30 active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>{solicitando ? 'Comprobando cámara…' : 'Permitir y Continuar'}</span>
            <ArrowRight size={18} />
          </button>

          {estadoCamara === 'denegado' && (
            <button
              onClick={onAceptado}
              className="w-full py-2.5 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition"
            >
              Continuar sin cámara directa (usar archivos)
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
