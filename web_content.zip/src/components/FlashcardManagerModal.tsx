import React, { useState } from 'react';
import { Flashcard, Topic } from '../types';
import { X, Plus, Trash2, Edit2, Sparkles, HelpCircle, Layers, Check } from 'lucide-react';

interface FlashcardManagerModalProps {
  topic: Topic;
  isOpen: boolean;
  onClose: () => void;
  onUpdateFlashcards: (topicId: string, updatedCards: Flashcard[]) => void;
  onStartStudy: (topic: Topic) => void;
}

export const FlashcardManagerModal: React.FC<FlashcardManagerModalProps> = ({
  topic,
  isOpen,
  onClose,
  onUpdateFlashcards,
  onStartStudy,
}) => {
  const [cards, setCards] = useState<Flashcard[]>(topic.flashcards || []);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form fields
  const [front, setFront] = useState('');
  const [back, setBack] = useState('');
  const [hint, setHint] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  const handleSaveCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!front.trim() || !back.trim()) return;

    let updated: Flashcard[];
    if (editingId) {
      updated = cards.map((c) =>
        c.id === editingId
          ? { ...c, front: front.trim(), back: back.trim(), hint: hint.trim() || undefined }
          : c
      );
    } else {
      const newCard: Flashcard = {
        id: `fc-${Date.now()}`,
        topicId: topic.id,
        front: front.trim(),
        back: back.trim(),
        hint: hint.trim() || undefined,
        createdAt: new Date().toISOString(),
        reviewCount: 0,
        ratingHistory: [],
      };
      updated = [...cards, newCard];
    }

    setCards(updated);
    onUpdateFlashcards(topic.id, updated);
    resetForm();
  };

  const handleDeleteCard = (cardId: string) => {
    const updated = cards.filter((c) => c.id !== cardId);
    setCards(updated);
    onUpdateFlashcards(topic.id, updated);
  };

  const handleEditClick = (card: Flashcard) => {
    setEditingId(card.id);
    setFront(card.front);
    setBack(card.back);
    setHint(card.hint || '');
    setIsAdding(true);
  };

  const resetForm = () => {
    setFront('');
    setBack('');
    setHint('');
    setEditingId(null);
    setIsAdding(false);
  };

  // Smart flashcard extraction from notes and key concepts
  const handleGenerateSmartCards = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const generated: Flashcard[] = [];

      // Extract from key concepts
      if (topic.keyConcepts && topic.keyConcepts.length > 0) {
        topic.keyConcepts.forEach((concept, i) => {
          generated.push({
            id: `fc-gen-${Date.now()}-${i}`,
            topicId: topic.id,
            front: `Define or explain the core mechanism of: "${concept}"`,
            back: `In the context of ${topic.title}: ${concept} is a foundational pillar.\nKey context: ${topic.notes.slice(0, 160)}...`,
            hint: `Focus on how ${concept} applies to ${topic.title}.`,
            createdAt: new Date().toISOString(),
            reviewCount: 0,
            ratingHistory: [],
          });
        });
      }

      // Add a synthesis card
      if (topic.notes && topic.notes.length > 20) {
        generated.push({
          id: `fc-gen-${Date.now()}-sum`,
          topicId: topic.id,
          front: `What is the primary objective or principle behind ${topic.title}?`,
          back: topic.notes,
          hint: 'Summarize the core mechanism in 1-2 sentences.',
          createdAt: new Date().toISOString(),
          reviewCount: 0,
          ratingHistory: [],
        });
      }

      const merged = [...cards, ...generated];
      setCards(merged);
      onUpdateFlashcards(topic.id, merged);
      setIsGenerating(false);
    }, 400);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="flashcard-modal-title"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-xl overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 id="flashcard-modal-title" className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Flashcards: {topic.title}
              </h2>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                {cards.length} {cards.length === 1 ? 'card' : 'cards'} ready for spaced revision
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Action row */}
          {!isAdding && (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setIsAdding(true)}
                className="px-3.5 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <Plus className="w-4 h-4" />
                Add New Card
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleGenerateSmartCards}
                  disabled={isGenerating}
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
                  title="Generate revision flashcards from your notes and key concepts"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                  {isGenerating ? 'Extracting...' : 'Auto-Generate Cards'}
                </button>

                {cards.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onStartStudy(topic);
                    }}
                    className="px-3.5 py-2 text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border border-emerald-200 dark:border-emerald-800 rounded-lg flex items-center gap-1.5 transition-colors"
                  >
                    Start Revision Session
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Add / Edit Form */}
          {isAdding && (
            <form onSubmit={handleSaveCard} className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700 space-y-4">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-800 dark:text-slate-200">
                <span>{editingId ? 'Edit Flashcard' : 'Create Flashcard'}</span>
                <button
                  type="button"
                  onClick={resetForm}
                  className="text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-normal"
                >
                  Cancel
                </button>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Front: Question / Prompt / Key Term <span className="text-rose-500">*</span>
                </label>
                <textarea
                  required
                  rows={2}
                  value={front}
                  onChange={(e) => setFront(e.target.value)}
                  placeholder="e.g. What is the Log Matching Invariant in Raft?"
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Back: Answer / Explanation <span className="text-rose-500">*</span>
                </label>
                <textarea
                  required
                  rows={3}
                  value={back}
                  onChange={(e) => setBack(e.target.value)}
                  placeholder="e.g. If two logs contain an entry with the same index and term, then they are identical in all entries up through that index."
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Optional Hint / Mnemonic
                </label>
                <input
                  type="text"
                  value={hint}
                  onChange={(e) => setHint(e.target.value)}
                  placeholder="e.g. Think about prefix matching"
                  className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-xs"
                >
                  {editingId ? 'Update Card' : 'Save Flashcard'}
                </button>
              </div>
            </form>
          )}

          {/* Cards List */}
          <div className="space-y-3">
            {cards.length === 0 ? (
              <div className="text-center py-8 text-slate-500 dark:text-slate-400 text-xs">
                No flashcards created yet. Click "Add New Card" or "Auto-Generate Cards" above.
              </div>
            ) : (
              cards.map((card, idx) => (
                <div
                  key={card.id}
                  className="p-4 bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 rounded-xl space-y-2 group"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                        <span>Card #{idx + 1}</span>
                        <span>·</span>
                        <span>Reviewed {card.reviewCount} times</span>
                      </div>
                      <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                        {card.front}
                      </div>
                      <div className="text-xs text-slate-600 dark:text-slate-300 whitespace-pre-line bg-white dark:bg-slate-900/60 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800/80">
                        {card.back}
                      </div>
                      {card.hint && (
                        <div className="text-[11px] text-amber-700 dark:text-amber-300 flex items-center gap-1">
                          <HelpCircle className="w-3 h-3 shrink-0" />
                          <span>Hint: {card.hint}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-1 shrink-0 opacity-80 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => handleEditClick(card)}
                        className="p-1.5 text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-md transition-colors"
                        title="Edit flashcard"
                        aria-label={`Edit card ${idx + 1}`}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteCard(card.id)}
                        className="p-1.5 text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 rounded-md transition-colors"
                        title="Delete flashcard"
                        aria-label={`Delete card ${idx + 1}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span>
            Regular active recall transfers concepts from working memory to permanent storage.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
