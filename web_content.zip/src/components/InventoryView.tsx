import React, { useState } from 'react';
import { Product, StoreSettings } from '../types';
import { 
  Search, 
  Filter, 
  Download, 
  Upload, 
  Plus, 
  Minus, 
  Edit, 
  Trash2, 
  Barcode as BarcodeIcon, 
  AlertTriangle, 
  Boxes,
  ArrowUpDown,
  CheckCircle2
} from 'lucide-react';

interface InventoryViewProps {
  inventory: Product[];
  settings: StoreSettings;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onUpdateStock: (productId: string, newStock: number) => void;
  onOpenBarcodeModal: (product: Product) => void;
  onImportProducts: (products: Product[]) => void;
  onNavigateToRegister: () => void;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  inventory,
  settings,
  onEditProduct,
  onDeleteProduct,
  onUpdateStock,
  onOpenBarcodeModal,
  onImportProducts,
  onNavigateToRegister
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [stockFilter, setStockFilter] = useState<'all' | 'low' | 'out'>('all');
  const [sortBy, setSortBy] = useState<'name' | 'price' | 'stock'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Stock adjustment modal
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<string>('0');
  const [adjustMode, setAdjustMode] = useState<'add' | 'subtract' | 'set'>('add');

  // Delete product confirmation modal state (no window.confirm)
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);

  const categories = ['All', ...Array.from(new Set(inventory.map(p => p.category).filter(Boolean)))];

  // Filtering & sorting
  const filtered = inventory.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.code.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesStock = 
      stockFilter === 'all' ? true :
      stockFilter === 'low' ? p.stock <= p.minStock && p.stock > 0 :
      stockFilter === 'out' ? p.stock <= 0 : true;

    return matchesSearch && matchesCat && matchesStock;
  });

  const sorted = [...filtered].sort((a, b) => {
    let comp = 0;
    if (sortBy === 'name') comp = a.name.localeCompare(b.name);
    else if (sortBy === 'price') comp = a.price - b.price;
    else if (sortBy === 'stock') comp = a.stock - b.stock;
    return sortOrder === 'asc' ? comp : -comp;
  });

  // CSV Export
  const handleExportCSV = () => {
    const headers = ['Code', 'Name', 'Category', 'Price', 'CostPrice', 'Stock', 'MinStock', 'Unit'];
    const rows = inventory.map(item => [
      `"${item.code}"`,
      `"${item.name.replace(/"/g, '""')}"`,
      `"${item.category || ''}"`,
      item.price,
      item.costPrice || 0,
      item.stock,
      item.minStock,
      `"${item.unit || 'pcs'}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `inventory-export-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // CSV Import
  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
        if (lines.length <= 1) return;

        const importedProducts: Product[] = [];
        for (let i = 1; i < lines.length; i++) {
          const cols = lines[i].split(',').map(c => c.replace(/^"|"$/g, '').trim());
          if (cols.length >= 4) {
            const code = cols[0];
            const name = cols[1];
            const category = cols[2] || 'General';
            const price = parseFloat(cols[3]) || 0;
            const costPrice = parseFloat(cols[4]) || 0;
            const stock = parseInt(cols[5], 10) || 0;
            const minStock = parseInt(cols[6], 10) || 5;
            const unit = cols[7] || 'pcs';

            if (code && name) {
              importedProducts.push({
                id: `prod-import-${Date.now()}-${i}`,
                code,
                name,
                category,
                price,
                costPrice,
                stock,
                minStock,
                unit,
                createdAt: new Date().toISOString()
              });
            }
          }
        }

        if (importedProducts.length > 0) {
          onImportProducts(importedProducts);
          setFeedbackNotice(`Successfully imported ${importedProducts.length} items from CSV.`);
          setTimeout(() => setFeedbackNotice(null), 3500);
        } else {
          setFeedbackNotice('No valid products found in CSV.');
          setTimeout(() => setFeedbackNotice(null), 3500);
        }
      } catch (err) {
        setFeedbackNotice('Failed to parse CSV file: ' + err);
        setTimeout(() => setFeedbackNotice(null), 3500);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Handle stock modal save
  const handleApplyStockAdjustment = () => {
    if (!adjustingProduct) return;
    const delta = parseInt(adjustAmount, 10);
    if (isNaN(delta)) return;

    let nextStock = adjustingProduct.stock;
    if (adjustMode === 'add') nextStock += delta;
    else if (adjustMode === 'subtract') nextStock = Math.max(0, nextStock - delta);
    else if (adjustMode === 'set') nextStock = Math.max(0, delta);

    onUpdateStock(adjustingProduct.id, nextStock);
    setAdjustingProduct(null);
    setAdjustAmount('0');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header Card */}
      <div className="glass-card rounded-3xl p-5 sm:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Boxes className="w-5 h-5 text-cyan-400" />
              <h2 className="text-xl font-black text-slate-100">Inventory Stock Manager</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {inventory.length} total products registered • {inventory.reduce((a, b) => a + b.stock, 0)} total units
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onNavigateToRegister}
              className="px-3.5 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Product
            </button>

            <button
              onClick={handleExportCSV}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>

            <label className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              Import CSV
              <input type="file" accept=".csv" onChange={handleImportCSV} className="hidden" />
            </label>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2">
          {/* Search */}
          <div className="sm:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by product name or barcode..."
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Category Dropdown */}
          <div className="sm:col-span-3">
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              {categories.map(c => (
                <option key={c} value={c}>Category: {c}</option>
              ))}
            </select>
          </div>

          {/* Stock status filter */}
          <div className="sm:col-span-2">
            <select
              value={stockFilter}
              onChange={e => setStockFilter(e.target.value as 'all' | 'low' | 'out')}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="all">All Stock</option>
              <option value="low">Low Stock (≤ Alert)</option>
              <option value="out">Out of Stock</option>
            </select>
          </div>

          {/* Sort order toggle */}
          <div className="sm:col-span-2 flex gap-1">
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as 'name' | 'price' | 'stock')}
              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-2 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="name">Sort: Name</option>
              <option value="price">Sort: Price</option>
              <option value="stock">Sort: Stock</option>
            </select>
            <button
              onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
              className="px-2.5 bg-slate-800 border border-slate-700 rounded-xl text-slate-300 hover:text-white cursor-pointer"
              title="Toggle Ascending / Descending"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Inventory Items List */}
      <div className="space-y-3">
        {sorted.length === 0 ? (
          <div className="glass-card rounded-3xl p-12 text-center space-y-3 text-slate-500">
            <Boxes className="w-12 h-12 mx-auto text-slate-600" />
            <p className="text-sm font-semibold">No products match your criteria</p>
            <p className="text-xs text-slate-500">Try adjusting your search terms or filters above.</p>
          </div>
        ) : (
          sorted.map(item => {
            const isOutOfStock = item.stock <= 0;
            const isLowStock = item.stock <= item.minStock && !isOutOfStock;

            return (
              <div
                key={item.id}
                className="glass-card rounded-2xl p-4 transition hover:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                {/* Product Info */}
                <div className="space-y-1 flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-bold text-sm text-slate-100">
                      {item.name}
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                      {item.category}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                    <span className="font-mono text-cyan-400 font-semibold flex items-center gap-1">
                      <BarcodeIcon className="w-3 h-3 text-slate-500" />
                      {item.code}
                    </span>
                    <span>•</span>
                    <span className="font-bold text-slate-200">
                      Price: {settings.currency}{item.price.toFixed(2)}
                    </span>
                    {item.costPrice > 0 && (
                      <span className="text-slate-500">
                        (Cost: {settings.currency}{item.costPrice.toFixed(2)})
                      </span>
                    )}
                  </div>
                </div>

                {/* Stock Level Badges & Quick Action */}
                <div className="flex flex-wrap items-center gap-3">
                  <div className="text-left md:text-right">
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-bold px-2.5 py-1 rounded-xl border flex items-center gap-1 ${
                        isOutOfStock
                          ? 'bg-rose-500/15 border-rose-500/30 text-rose-300'
                          : isLowStock
                          ? 'bg-amber-500/15 border-amber-500/30 text-amber-300'
                          : 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                      }`}>
                        {isOutOfStock && <AlertTriangle className="w-3 h-3" />}
                        {isLowStock && <AlertTriangle className="w-3 h-3" />}
                        {!isOutOfStock && !isLowStock && <CheckCircle2 className="w-3 h-3" />}
                        {item.stock} {item.unit}
                      </span>

                      <button
                        onClick={() => {
                          setAdjustingProduct(item);
                          setAdjustAmount('5');
                          setAdjustMode('add');
                        }}
                        title="Adjust Stock Quantity"
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold cursor-pointer"
                      >
                        Adjust
                      </button>
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-0.5">
                      Min Alert: {item.minStock} {item.unit}
                    </span>
                  </div>

                  {/* Product row action icons */}
                  <div className="flex items-center gap-1 border-l border-slate-800 pl-3">
                    <button
                      onClick={() => onOpenBarcodeModal(item)}
                      title="View & Print Barcode Label"
                      className="p-2 text-cyan-400 hover:bg-cyan-500/10 rounded-xl transition cursor-pointer"
                    >
                      <BarcodeIcon className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onEditProduct(item)}
                      title="Edit Product Details"
                      className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-xl transition cursor-pointer"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Delete "${item.name}" from inventory?`)) {
                          onDeleteProduct(item.id);
                        }
                      }}
                      title="Delete Product"
                      className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Adjust Stock Dialog */}
      {adjustingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-4 shadow-2xl">
            <div>
              <h3 className="font-bold text-sm text-slate-100">Adjust Stock Quantity</h3>
              <p className="text-xs text-slate-400 truncate mt-0.5">{adjustingProduct.name}</p>
              <p className="text-xs font-semibold text-cyan-400 mt-1">Current Stock: {adjustingProduct.stock} {adjustingProduct.unit}</p>
            </div>

            <div className="flex gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => setAdjustMode('add')}
                className={`flex-1 py-1 text-xs font-bold rounded-lg cursor-pointer transition ${
                  adjustMode === 'add' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
                }`}
              >
                + Restock
              </button>
              <button
                type="button"
                onClick={() => setAdjustMode('subtract')}
                className={`flex-1 py-1 text-xs font-bold rounded-lg cursor-pointer transition ${
                  adjustMode === 'subtract' ? 'bg-rose-500 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                - Reduce
              </button>
              <button
                type="button"
                onClick={() => setAdjustMode('set')}
                className={`flex-1 py-1 text-xs font-bold rounded-lg cursor-pointer transition ${
                  adjustMode === 'set' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                = Set Exact
              </button>
            </div>

            <div>
              <label className="text-xs text-slate-400 mb-1 block">
                {adjustMode === 'add' && 'Amount to Add'}
                {adjustMode === 'subtract' && 'Amount to Deduct'}
                {adjustMode === 'set' && 'New Exact Quantity'}
              </label>
              <input
                type="number"
                min="0"
                value={adjustAmount}
                onChange={e => setAdjustAmount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-base font-bold text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setAdjustingProduct(null)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApplyStockAdjustment}
                className="flex-1 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
