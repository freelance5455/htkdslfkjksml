import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckSquare,
  Edit3,
  FileSpreadsheet,
  Minus,
  Plus,
  Search,
  Store,
  Trash2,
  X,
} from 'lucide-react';
import {
  ConfirmDialogState,
  FIELD_LIMITS,
  InventoryItem,
  STORE_NAMES,
  StoreName,
} from '../types/ops';
import {
  adjustInventoryStock,
  createInventoryItem,
  deleteInventoryItem,
  updateInventoryItemByAdmin,
} from '../lib/firestoreOps';
import {
  createSpreadsheet,
  createTask,
  listTaskLists,
  overwriteSheetValues,
} from '../lib/workspaceApi';

interface InventoryViewProps {
  ownerId: string;
  isAdmin: boolean;
  userDivision: string;
  teamEmails: string[];
  inventory: InventoryItem[];
  accessToken: string | null;
  onRequestConfirm: (dialog: ConfirmDialogState) => void;
  onReconnectWorkspace: () => void;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

const formatIDR = (val: number) =>
  new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0,
  }).format(val);

export const InventoryView: React.FC<InventoryViewProps> = ({
  ownerId,
  isAdmin,
  userDivision,
  teamEmails,
  inventory,
  accessToken,
  onRequestConfirm,
  onReconnectWorkspace,
  onNotify,
}) => {
  const [activeStore, setActiveStore] = useState<StoreName>('Tiga Rekan ID (TikTok)');
  const [search, setSearch] = useState('');
  const [onlyLowStock, setOnlyLowStock] = useState(false);

  const canAdjustStock = isAdmin || userDivision === 'Gudang & Packing';

  // Add / Edit SKU Modal (Admin Only)
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [formStore, setFormStore] = useState<StoreName>(activeStore);
  const [sku, setSku] = useState('');
  const [productName, setProductName] = useState('');
  const [category, setCategory] = useState('Umum');
  const [stock, setStock] = useState('25');
  const [minStock, setMinStock] = useState('10');
  const [unitPrice, setUnitPrice] = useState('100000');
  const [warehouseLocation, setWarehouseLocation] = useState('Rak A-01');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  const storeItems = useMemo(
    () => inventory.filter((item) => item.store === activeStore),
    [inventory, activeStore]
  );

  const filteredItems = useMemo(() => {
    const q = search.trim().toLowerCase();
    return storeItems.filter((item) => {
      if (onlyLowStock && item.stock > item.minStock) return false;
      if (!q) return true;
      return (
        item.sku.toLowerCase().includes(q) ||
        item.productName.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        (item.warehouseLocation || '').toLowerCase().includes(q)
      );
    });
  }, [storeItems, search, onlyLowStock]);

  const openAddModal = () => {
    setEditingItem(null);
    setFormStore(activeStore);
    setSku('');
    setProductName('');
    setCategory('Umum');
    setStock('25');
    setMinStock('10');
    setUnitPrice('100000');
    setWarehouseLocation('Rak A-01');
    setFormError('');
    setModalOpen(true);
  };

  const openEditModal = (item: InventoryItem) => {
    setEditingItem(item);
    setFormStore(item.store);
    setSku(item.sku);
    setProductName(item.productName);
    setCategory(item.category);
    setStock(String(item.stock));
    setMinStock(String(item.minStock));
    setUnitPrice(String(item.unitPrice));
    setWarehouseLocation(item.warehouseLocation);
    setFormError('');
    setModalOpen(true);
  };

  const handleSaveSku = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setFormError('');
    setSaving(true);
    try {
      const payload = {
        store: formStore,
        sku,
        productName,
        category,
        stock: Number(stock) || 0,
        minStock: Number(minStock) || 0,
        unitPrice: Number(unitPrice) || 0,
        warehouseLocation,
        teamEmails,
      };
      if (editingItem) {
        await updateInventoryItemByAdmin(editingItem.id, payload);
        onNotify(`SKU ${sku} (${formStore}) diperbarui.`, 'success');
      } else {
        await createInventoryItem(ownerId, payload);
        onNotify(`SKU ${sku} ditambahkan ke ${formStore}.`, 'success');
      }
      setActiveStore(formStore);
      setModalOpen(false);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Gagal menyimpan SKU.');
    } finally {
      setSaving(false);
    }
  };

  const handleStepStock = async (item: InventoryItem, delta: number) => {
    if (!canAdjustStock) return;
    const next = Math.max(0, item.stock + delta);
    await adjustInventoryStock(item.id, next);
  };

  const handleDeleteSku = (item: InventoryItem) => {
    onRequestConfirm({
      open: true,
      title: `Hapus SKU ${item.sku} dari ${item.store}?`,
      description: `Produk "${item.productName}" akan dihapus permanen dari inventaris toko ini.`,
      confirmLabel: 'Hapus SKU',
      variant: 'danger',
      onConfirm: async () => {
        await deleteInventoryItem(item.id);
        onNotify(`SKU ${item.sku} dihapus.`, 'success');
      },
    });
  };

  const handleCreateRestockTask = (item: InventoryItem) => {
    if (!accessToken) {
      onReconnectWorkspace();
      return;
    }
    onRequestConfirm({
      open: true,
      title: 'Buat Tugas Restock di Google Tasks?',
      description: `Menambahkan pengingat restock untuk ${item.productName} (${item.store}) ke Google Tasks Anda.`,
      confirmLabel: 'Buat Tugas Restock',
      details: [
        `Toko: ${item.store}`,
        `SKU: ${item.sku} · Sisa stok: ${item.stock} pcs (Min: ${item.minStock})`,
      ],
      onConfirm: async () => {
        const lists = await listTaskLists(accessToken);
        const targetListId = lists[0]?.id || '@default';
        await createTask(accessToken, targetListId, {
          title: `Restock [${item.store}] ${item.sku} - ${item.productName}`,
          notes: `Stok saat ini: ${item.stock} pcs (Min ${item.minStock}). Lokasi: ${item.warehouseLocation || '-'}.`,
          dueIso: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
        });
        onNotify(`Tugas restock untuk ${item.sku} dibuat di Google Tasks.`, 'success');
      },
    });
  };

  const handleExportStoreSheet = () => {
    if (!accessToken) {
      onReconnectWorkspace();
      return;
    }
    if (filteredItems.length === 0) {
      onNotify(`Tidak ada data SKU di ${activeStore} untuk diekspor.`, 'error');
      return;
    }
    onRequestConfirm({
      open: true,
      title: `Ekspor Stok ${activeStore} ke Google Sheets?`,
      description: `Membuat spreadsheet baru berisi ${filteredItems.length} baris SKU khusus toko ${activeStore}.`,
      confirmLabel: 'Buat & Tulis ke Sheets',
      onConfirm: async () => {
        const title = `Stok ${activeStore} - ${new Date().toLocaleDateString('id-ID')}`;
        const meta = await createSpreadsheet(accessToken, title, 'Stok Gudang');
        const tabTitle = meta.sheets[0]?.properties?.title || 'Stok Gudang';
        const rows: (string | number)[][] = [
          ['Toko', 'SKU', 'Nama Produk', 'Kategori', 'Stok', 'Batas Minimum', 'Harga (IDR)', 'Lokasi Rak', 'Status'],
          ...filteredItems.map((i) => [
            i.store,
            i.sku,
            i.productName,
            i.category,
            i.stock,
            i.minStock,
            i.unitPrice,
            i.warehouseLocation || '',
            i.stock <= i.minStock ? 'Perlu Restock' : 'Aman',
          ]),
        ];
        await overwriteSheetValues(accessToken, meta.spreadsheetId, tabTitle, rows);
        onNotify(`Spreadsheet "${title}" berhasil dibuat di Google Sheets.`, 'success');
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-5 border-b border-stone-200">
        <div>
          <p className="text-xs font-semibold text-orange-700">
            Gudang & Stok Terpisah per Toko
          </p>
          <h1 className="text-xl sm:text-2xl font-bold text-stone-900 tracking-tight mt-1">
            Inventaris SKU & Gudang
          </h1>
          <p className="text-sm text-stone-600 mt-1">
            Kelola stok terpisah untuk Tiga Rekan ID (TikTok), Veelo Store ID (TikTok), dan Tiga Rekan ID (Shopee).
          </p>
        </div>

        <div className="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-2.5 sm:gap-3 w-full md:w-auto shrink-0">
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            type="button"
            onClick={handleExportStoreSheet}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors whitespace-nowrap shrink-0"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            Ekspor Toko Ini ke Sheets
          </motion.button>
          {isAdmin && (
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              type="button"
              onClick={openAddModal}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              Tambah SKU Toko
            </motion.button>
          )}
        </div>
      </div>

      {/* 3-Store Switcher Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
        {STORE_NAMES.map((storeOption) => {
          const itemsForStore = inventory.filter((i) => i.store === storeOption);
          const lowForStore = itemsForStore.filter((i) => i.stock <= i.minStock).length;
          const isSelected = activeStore === storeOption;
          return (
            <motion.button
              key={storeOption}
              type="button"
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.99 }}
              onClick={() => setActiveStore(storeOption)}
              className={`relative text-left rounded-xl p-4 border transition-colors ${
                isSelected
                  ? 'bg-orange-50/70 border-orange-500'
                  : 'bg-white border-stone-200 hover:border-orange-300'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <Store
                    className={`w-4 h-4 shrink-0 ${
                      isSelected ? 'text-orange-600' : 'text-stone-400'
                    }`}
                  />
                  <span
                    className={`text-sm font-bold truncate ${
                      isSelected ? 'text-orange-900' : 'text-stone-900'
                    }`}
                  >
                    {storeOption}
                  </span>
                </div>
                {isSelected && (
                  <span className="text-[11px] font-semibold text-orange-700 shrink-0">
                    Aktif
                  </span>
                )}
              </div>
              <div className="mt-3 flex items-baseline justify-between text-xs">
                <span className="font-mono font-semibold text-stone-800 tabular-nums">
                  {itemsForStore.length} SKU
                </span>
                <span
                  className={`tabular-nums ${
                    lowForStore > 0 ? 'text-amber-700 font-semibold' : 'text-stone-500'
                  }`}
                >
                  {lowForStore > 0 ? `${lowForStore} perlu restock` : 'Semua stok aman'}
                </span>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div className="grid grid-cols-2 sm:inline-flex items-center gap-1 p-1 bg-stone-100 rounded-xl w-full sm:w-auto self-start">
          <button
            type="button"
            onClick={() => setOnlyLowStock(false)}
            className={`px-3 py-2 sm:py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap text-center ${
              !onlyLowStock ? 'bg-white text-orange-700 shadow-sm' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Semua SKU ({storeItems.length})
          </button>
          <button
            type="button"
            onClick={() => setOnlyLowStock(true)}
            className={`px-3 py-2 sm:py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap text-center ${
              onlyLowStock ? 'bg-white text-orange-700 shadow-sm' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Stok Menipis ({storeItems.filter((i) => i.stock <= i.minStock).length})
          </button>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={`Cari SKU di ${activeStore}...`}
            className="pl-9 pr-3 py-2 text-sm bg-white border border-stone-300 rounded-lg w-full focus:outline-none focus:border-orange-600"
          />
        </div>
      </div>

      {/* Store Inventory Mobile Cards + Desktop Table */}
      <motion.div
        key={activeStore}
        initial={{ opacity: 0, y: 4 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
        className="bg-white border border-stone-200 rounded-xl overflow-hidden"
      >
        {filteredItems.length === 0 ? (
          <div className="p-8 sm:p-10 text-center">
            <p className="text-sm font-semibold text-stone-800">
              {storeItems.length === 0
                ? `Belum ada SKU di ${activeStore}`
                : 'Tidak ada SKU sesuai filter'}
            </p>
            <p className="text-xs text-stone-500 mt-1 mb-4">
              {isAdmin
                ? `Tambahkan produk untuk toko ${activeStore} agar stok gudangnya terpisah rapi.`
                : 'Hubungi Administrator untuk menambahkan SKU baru pada toko ini.'}
            </p>
            {isAdmin && storeItems.length === 0 && (
              <button
                type="button"
                onClick={openAddModal}
                className="px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700"
              >
                Tambah SKU Pertama
              </button>
            )}
          </div>
        ) : (
          <>
            {/* Mobile Card List */}
            <div className="md:hidden divide-y divide-stone-100">
              {filteredItems.map((item) => {
                const isLow = item.stock <= item.minStock;
                return (
                  <div key={item.id} className="p-4 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-mono text-xs font-bold text-stone-900">{item.sku}</p>
                        <p className="text-sm font-semibold text-stone-900 mt-0.5 leading-snug">
                          {item.productName}
                        </p>
                        <p className="text-xs text-stone-500 mt-0.5">
                          {item.category} · {item.warehouseLocation || 'Rak Utama'}
                        </p>
                      </div>
                      <span
                        className={`text-xs font-semibold shrink-0 ${
                          isLow ? 'text-amber-700' : 'text-emerald-700'
                        }`}
                      >
                        {isLow ? `Min ${item.minStock}` : 'Aman'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-3 pt-1">
                      <span className="font-mono text-xs font-semibold text-stone-800 tabular-nums">
                        {formatIDR(item.unitPrice)}
                      </span>

                      <div className="flex items-center gap-2">
                        {canAdjustStock && (
                          <button
                            type="button"
                            onClick={() => handleStepStock(item, -1)}
                            disabled={item.stock <= 0}
                            className="w-9 h-9 flex items-center justify-center text-stone-700 bg-stone-100 hover:bg-orange-100 hover:text-orange-700 rounded-lg disabled:opacity-40"
                            aria-label={`Kurangi stok ${item.sku}`}
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                        )}
                        <span className="min-w-[3rem] text-center font-mono tabular-nums text-sm font-bold text-stone-900">
                          {item.stock}
                        </span>
                        {canAdjustStock && (
                          <button
                            type="button"
                            onClick={() => handleStepStock(item, 1)}
                            className="w-9 h-9 flex items-center justify-center text-stone-700 bg-stone-100 hover:bg-orange-100 hover:text-orange-700 rounded-lg"
                            aria-label={`Tambah stok ${item.sku}`}
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="pt-1 flex items-center justify-end gap-1 border-t border-stone-100">
                      <button
                        type="button"
                        onClick={() => handleCreateRestockTask(item)}
                        title="Buat Tugas Restock di Google Tasks"
                        className="p-2 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                      >
                        <CheckSquare className="w-4 h-4" />
                      </button>
                      {isAdmin && (
                        <>
                          <button
                            type="button"
                            onClick={() => openEditModal(item)}
                            title="Edit SKU"
                            className="p-2 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteSku(item)}
                            title="Hapus SKU"
                            className="p-2 text-stone-500 hover:text-red-700 hover:bg-red-50 rounded-md"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-stone-200 bg-stone-50 text-xs font-semibold text-stone-600">
                    <th className="py-3 px-4 whitespace-nowrap">Kode SKU</th>
                    <th className="py-3 px-4 whitespace-nowrap">Nama Produk & Kategori</th>
                    <th className="py-3 px-4 whitespace-nowrap">Lokasi Rak</th>
                    <th className="py-3 px-4 whitespace-nowrap text-right">Harga Satuan</th>
                    <th className="py-3 px-4 whitespace-nowrap text-center">Stok Gudang</th>
                    <th className="py-3 px-4 whitespace-nowrap">Status</th>
                    <th className="py-3 px-4 whitespace-nowrap text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 text-sm">
                  {filteredItems.map((item) => {
                    const isLow = item.stock <= item.minStock;
                    return (
                      <tr key={item.id} className="hover:bg-orange-50/40 transition-colors">
                        <td className="py-3 px-4 font-mono text-xs font-bold text-stone-900 whitespace-nowrap">
                          {item.sku}
                        </td>
                        <td className="py-3 px-4 max-w-xs">
                          <div className="font-medium text-stone-900 truncate">{item.productName}</div>
                          <div className="text-xs text-stone-500 mt-0.5">{item.category}</div>
                        </td>
                        <td className="py-3 px-4 text-xs text-stone-600 whitespace-nowrap">
                          {item.warehouseLocation || 'Rak Utama'}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-stone-900 whitespace-nowrap">
                          {formatIDR(item.unitPrice)}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="flex items-center justify-center gap-2">
                            {canAdjustStock && (
                              <button
                                type="button"
                                onClick={() => handleStepStock(item, -1)}
                                disabled={item.stock <= 0}
                                className="p-1 text-stone-600 bg-stone-100 hover:bg-orange-100 hover:text-orange-700 rounded disabled:opacity-40"
                                aria-label={`Kurangi stok ${item.sku}`}
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <span className="w-12 text-center font-mono tabular-nums font-semibold text-stone-900">
                              {item.stock}
                            </span>
                            {canAdjustStock && (
                              <button
                                type="button"
                                onClick={() => handleStepStock(item, 1)}
                                className="p-1 text-stone-600 bg-stone-100 hover:bg-orange-100 hover:text-orange-700 rounded"
                                aria-label={`Tambah stok ${item.sku}`}
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span
                            className={`text-xs font-semibold ${
                              isLow ? 'text-amber-700' : 'text-emerald-700'
                            }`}
                          >
                            {isLow ? `Perlu Restock (Min ${item.minStock})` : 'Stok Aman'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleCreateRestockTask(item)}
                              title="Buat Tugas Restock di Google Tasks"
                              className="p-1.5 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                            >
                              <CheckSquare className="w-4 h-4" />
                            </button>
                            {isAdmin && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => openEditModal(item)}
                                  title="Edit SKU"
                                  className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteSku(item)}
                                  title="Hapus SKU"
                                  className="p-1.5 text-stone-500 hover:text-red-700 hover:bg-red-50 rounded-md"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </motion.div>

      {/* Add / Edit SKU Modal (Admin Only) */}
      <AnimatePresence>
        {modalOpen && isAdmin && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 flex items-center justify-center bg-stone-900/40 p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
              className="w-full max-w-lg bg-white border border-stone-200 rounded-xl p-6 shadow-xl"
            >
              <div className="flex items-center justify-between pb-3 border-b border-stone-200 mb-4">
                <h2 className="text-base font-bold text-stone-900">
                  {editingItem ? `Edit SKU ${editingItem.sku}` : 'Tambah SKU Baru'}
                </h2>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="p-1 text-stone-400 hover:text-stone-700 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {formError && (
                <div className="mb-4 p-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
                  {formError}
                </div>
              )}

              <form onSubmit={handleSaveSku} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Toko Tujuan
                  </label>
                  <select
                    value={formStore}
                    onChange={(e) => setFormStore(e.target.value as StoreName)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                  >
                    {STORE_NAMES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">Kode SKU</label>
                    <input
                      type="text"
                      required
                      minLength={FIELD_LIMITS.skuMin}
                      maxLength={FIELD_LIMITS.skuMax}
                      value={sku}
                      onChange={(e) => setSku(e.target.value)}
                      placeholder="TRK-SRM-01"
                      className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">Kategori</label>
                    <input
                      type="text"
                      required
                      maxLength={FIELD_LIMITS.categoryMax}
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Nama Produk
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={FIELD_LIMITS.productNameMax}
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">Stok</label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={stock}
                      onChange={(e) => setStock(e.target.value)}
                      className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Batas Min
                    </label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={minStock}
                      onChange={(e) => setMinStock(e.target.value)}
                      className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Harga (Rp)
                    </label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={unitPrice}
                      onChange={(e) => setUnitPrice(e.target.value)}
                      className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Lokasi Rak Gudang
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.warehouseLocationMax}
                    value={warehouseLocation}
                    onChange={(e) => setWarehouseLocation(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="px-4 py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="px-4 py-2 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 disabled:opacity-60"
                  >
                    {saving ? 'Menyimpan...' : 'Simpan SKU'}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
