import React, { useState } from 'react';
import {
  Search,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  AlertTriangle,
  Receipt,
  Edit2,
  Trash2,
  SlidersHorizontal,
  Package,
  Layers,
  CheckCircle,
} from 'lucide-react';
import { CalculatedProduct, Product, StoreData, Transaction } from '../types';
import { formatMoney, formatNumber, formatDisplayDate } from '../utils/formatters';
import { feedback } from '../utils/haptics';
import { ConfirmModal } from './ConfirmModal';

interface InventoryViewProps {
  store: StoreData;
  calculated: Record<string, CalculatedProduct>;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onEditTransaction: (txn: Transaction) => void;
  onDeleteTransaction: (txnId: string) => void;
  onQuickSale: (productId: string) => void;
  onQuickPurchase: (productId: string) => void;
  onViewReceipt: (txn: Transaction) => void;
  onOpenAddItem: () => void;
  initialTab?: 'all' | 'in' | 'out' | 'low';
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  store,
  calculated,
  onEditProduct,
  onDeleteProduct,
  onEditTransaction,
  onDeleteTransaction,
  onQuickSale,
  onQuickPurchase,
  onViewReceipt,
  onOpenAddItem,
  initialTab = 'all',
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const [subTab, setSubTab] = useState<'all' | 'in' | 'out' | 'low'>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'stock-desc' | 'stock-asc' | 'value' | 'margin'>('name');
  const [deleteConfirm, setDeleteConfirm] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const productsList = store.products;
  const productMap = Object.fromEntries(store.products.map((p) => [p.id, p]));

  // Filter products
  const filteredProducts = productsList.filter((p) => {
    const calc = calculated[p.id];
    if (subTab === 'low' && (!calc || !calc.isLowStock)) {
      return false;
    }
    if (selectedCategory !== 'all' && p.cat !== selectedCategory) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = p.name.toLowerCase().includes(q);
      const matchCat = p.cat.toLowerCase().includes(q);
      const matchSku = p.sku && p.sku.toLowerCase().includes(q);
      return matchName || matchCat || matchSku;
    }
    return true;
  });

  // Sort products
  filteredProducts.sort((a, b) => {
    const calcA = calculated[a.id];
    const calcB = calculated[b.id];
    if (sortBy === 'name') {
      return a.name.localeCompare(b.name);
    }
    if (sortBy === 'stock-desc') {
      return (calcB?.qty || 0) - (calcA?.qty || 0);
    }
    if (sortBy === 'stock-asc') {
      return (calcA?.qty || 0) - (calcB?.qty || 0);
    }
    if (sortBy === 'value') {
      return (calcB?.stockValue || 0) - (calcA?.stockValue || 0);
    }
    if (sortBy === 'margin') {
      const marginA = a.price > 0 ? (a.price - a.cost) / a.price : 0;
      const marginB = b.price > 0 ? (b.price - b.cost) / b.price : 0;
      return marginB - marginA;
    }
    return 0;
  });

  // Filter Transactions (Stock In or Stock Out)
  const isTxnTab = subTab === 'in' || subTab === 'out';
  const targetType = subTab === 'in' ? 'P' : 'S';

  const filteredTransactions = store.txns
    .filter((t) => {
      if (t.type !== targetType) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const p = productMap[t.pid];
        const matchItem = p && p.name.toLowerCase().includes(q);
        const matchCust = t.cust && t.cust.toLowerCase().includes(q);
        const matchNote = t.note && t.note.toLowerCase().includes(q);
        return matchItem || matchCust || matchNote;
      }
      return true;
    })
    .sort((a, b) => b.date.localeCompare(a.date) || (b.time || '').localeCompare(a.time || ''));

  const countP = store.txns.filter((t) => t.type === 'P').length;
  const countS = store.txns.filter((t) => t.type === 'S').length;
  const countLow = Object.values(calculated).filter((c) => c.isLowStock).length;

  return (
    <div className="space-y-3.5 pb-20">
      {/* Segment Tabs (Android Pill segmented buttons) */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {[
          { id: 'all', label: `Items (${store.products.length})` },
          { id: 'in', label: `Stock In (${countP})` },
          { id: 'out', label: `Stock Out (${countS})` },
          { id: 'low', label: `Low Stock (${countLow})` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setSubTab(tab.id as any);
              feedback.vibrateSoft(hapticsEnabled);
              feedback.playTap(soundEnabled);
            }}
            className={`px-3.5 py-1.5 rounded-full font-semibold transition shrink-0 ${
              subTab === tab.id
                ? 'bg-[#d9262c] text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Search & Sort Controls */}
      <div className="flex gap-2 items-center">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isTxnTab
                ? subTab === 'in'
                  ? 'Search stock in by product or supplier...'
                  : 'Search sales by product or customer...'
                : 'Search products by name, SKU, category...'
            }
            className="w-full pl-9 pr-3 py-2 text-xs rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-red-500 shadow-xs"
          />
        </div>

        {!isTxnTab && (
          <div className="shrink-0">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="py-2 px-2.5 text-xs rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-red-500 shadow-xs"
            >
              <option value="name">Name (A-Z)</option>
              <option value="stock-desc">Stock (High-Low)</option>
              <option value="stock-asc">Stock (Low-High)</option>
              <option value="value">Value (High-Low)</option>
              <option value="margin">Margin %</option>
            </select>
          </div>
        )}
      </div>

      {/* Category horizontal chips (when viewing products) */}
      {!isTxnTab && (
        <div className="flex gap-1.5 overflow-x-auto pb-0.5 no-scrollbar text-[11px]">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1 rounded-xl font-medium transition shrink-0 ${
              selectedCategory === 'all'
                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            All Categories
          </button>
          {store.cats.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-xl font-medium transition shrink-0 ${
                selectedCategory === cat
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      )}

      {/* Main List Rendering */}
      {isTxnTab ? (
        // TRANSACTIONS LIST
        <div className="space-y-2.5">
          {filteredTransactions.length === 0 ? (
            <div className="p-8 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-400 text-xs">
              No entries found. Tap + at the bottom to record an entry.
            </div>
          ) : (
            filteredTransactions.map((t) => {
              const p = productMap[t.pid];
              const isIn = t.type === 'P';
              const totalAmt = t.qty * t.rate;

              return (
                <div
                  key={t.id}
                  className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs relative overflow-hidden"
                >
                  {/* Top corner badge */}
                  <div
                    className={`absolute top-0 right-0 px-2.5 py-0.5 rounded-bl-xl font-bold text-[10px] tracking-wider uppercase ${
                      isIn
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                    }`}
                  >
                    {isIn ? 'Stock In' : 'Stock Out'}
                  </div>

                  <div className="flex justify-between items-start pr-18">
                    <div>
                      <div className="font-bold text-xs text-slate-900 dark:text-white">
                        {p ? p.name : '(Deleted item)'}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {formatDisplayDate(t.date)} {t.time ? `• ${t.time}` : ''}
                      </div>
                      <div className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">
                        {isIn ? 'Supplier' : 'Customer'}: <span className="font-semibold">{t.cust || (isIn ? 'General Supplier' : 'Walk-in Customer')}</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div
                        className={`text-sm font-extrabold ${
                          isIn ? 'text-blue-600 dark:text-blue-400' : 'text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {isIn ? '+' : '−'}{formatNumber(t.qty)} {p ? p.unit : ''}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        @ {formatMoney(t.rate, store.cur)}
                      </div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white mt-0.5">
                        {formatMoney(totalAmt, store.cur)}
                      </div>
                    </div>
                  </div>

                  {/* Payment method and actions row */}
                  <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                    <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {t.paymentMethod || 'cash'}
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onViewReceipt(t)}
                        className="text-[11px] text-red-600 dark:text-red-400 font-semibold hover:underline flex items-center gap-1"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        Slip
                      </button>
                      <button
                        onClick={() => onEditTransaction(t)}
                        className="text-[11px] text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1"
                      >
                        <Edit2 className="w-3 h-3" />
                        Edit
                      </button>
                      <button
                        onClick={() => {
                          setDeleteConfirm({
                            isOpen: true,
                            title: 'Delete Entry',
                            message: `Delete this ${isIn ? 'Stock In (Purchase)' : 'Stock Out (Sale)'} entry of ${t.qty} ${p?.unit || 'units'}? Stock levels will recalculate automatically.`,
                            onConfirm: () => onDeleteTransaction(t.id),
                          });
                        }}
                        className="text-[11px] text-rose-500 font-semibold hover:underline flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" />
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      ) : (
        // PRODUCTS LIST
        <div className="space-y-3">
          {filteredProducts.length === 0 ? (
            <div className="p-8 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-400 text-xs">
              <Package className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <div>No products match your search or filter.</div>
              <button
                onClick={onOpenAddItem}
                className="mt-3 px-4 py-2 rounded-xl bg-[#d9262c] text-white font-semibold text-xs inline-flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                Add New Item
              </button>
            </div>
          ) : (
            filteredProducts.map((p) => {
              const calc = calculated[p.id];
              const isLow = calc?.isLowStock ?? false;
              const margin = p.price > 0 ? ((p.price - p.cost) / p.price) * 100 : 0;

              return (
                <div
                  key={p.id}
                  className={`p-3.5 rounded-2xl bg-white dark:bg-slate-900 border transition shadow-xs ${
                    isLow
                      ? 'border-red-300 dark:border-red-900/60 ring-1 ring-red-400/30'
                      : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <div className="font-bold text-xs text-slate-900 dark:text-white leading-tight">
                        {p.name}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          {p.cat}
                        </span>
                        {p.sku && (
                          <span className="text-[10px] text-slate-400 font-mono">
                            SKU: {p.sku}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="flex items-center justify-end gap-1 mb-1">
                        <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                          In: {calc ? formatNumber(calc.inq) : 0}
                        </span>
                        <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                          Out: {calc ? formatNumber(calc.sold) : 0}
                        </span>
                      </div>

                      <div
                        className={`text-base font-extrabold tracking-tight ${
                          isLow ? 'text-red-600 dark:text-red-400' : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {calc ? formatNumber(calc.qty) : p.open} <span className="text-xs font-normal text-slate-500">{p.unit}</span>
                      </div>

                      <div className="text-[10px] font-medium text-slate-500 mt-0.5">
                        {isLow ? (
                          <span className="text-red-600 font-bold flex items-center justify-end gap-0.5">
                            <AlertTriangle className="w-3 h-3" /> Low (Min: {p.min})
                          </span>
                        ) : (
                          <span>In Stock</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Financial metrics row */}
                  <div className="mt-3 grid grid-cols-4 gap-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-[11px]">
                    <div>
                      <div className="text-[10px] text-slate-400">Cost</div>
                      <div className="font-semibold text-slate-700 dark:text-slate-200">
                        {formatMoney(p.cost, store.cur)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">Price</div>
                      <div className="font-semibold text-slate-700 dark:text-slate-200">
                        {formatMoney(p.price, store.cur)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">Valuation</div>
                      <div className="font-semibold text-slate-700 dark:text-slate-200">
                        {formatMoney(calc ? calc.stockValue : p.open * p.cost, store.cur)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">Margin</div>
                      <div className="font-bold text-emerald-600 dark:text-emerald-400">
                        {margin.toFixed(0)}%
                      </div>
                    </div>
                  </div>

                  {/* Card Action Row */}
                  <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => onQuickSale(p.id)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px] flex items-center gap-1 active:scale-95 transition"
                      >
                        <ArrowUpRight className="w-3 h-3" />
                        + Sale
                      </button>
                      <button
                        onClick={() => onQuickPurchase(p.id)}
                        className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-[11px] flex items-center gap-1 active:scale-95 transition"
                      >
                        <ArrowDownLeft className="w-3 h-3" />
                        + Restock
                      </button>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => onEditProduct(p)}
                        className="text-[11px] text-slate-600 dark:text-slate-300 hover:text-slate-900 font-medium"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => {
                          setDeleteConfirm({
                            isOpen: true,
                            title: 'Delete Product',
                            message: `Delete "${p.name}" and all associated transaction history? This cannot be undone.`,
                            onConfirm: () => onDeleteProduct(p.id),
                          });
                        }}
                        className="text-[11px] text-red-500 font-medium hover:underline"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* In-app Deletion Confirm Modal */}
      <ConfirmModal
        isOpen={deleteConfirm.isOpen}
        title={deleteConfirm.title}
        message={deleteConfirm.message}
        confirmLabel="Delete"
        isDestructive={true}
        onConfirm={deleteConfirm.onConfirm}
        onClose={() => setDeleteConfirm((prev) => ({ ...prev, isOpen: false }))}
        soundEnabled={soundEnabled}
        hapticsEnabled={hapticsEnabled}
      />
    </div>
  );
};
