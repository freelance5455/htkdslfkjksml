import React, { useState } from 'react';
import { Check, Flame, Package, Swords, X } from 'lucide-react';
import { FRUITS, WEAPONS } from '../game/worldData';
import { FruitType, PlayerStats, WeaponType } from '../types/game';

interface InventoryModalProps {
  stats: PlayerStats;
  onClose: () => void;
  onEatFruit: (fruit: FruitType) => void;
  onEquipWeapon: (weapon: WeaponType) => void;
  onBuyWeapon: (weapon: WeaponType) => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  stats,
  onClose,
  onEatFruit,
  onEquipWeapon,
  onBuyWeapon,
}) => {
  const [activeTab, setActiveTab] = useState<'fruits' | 'weapons'>('fruits');

  const storedFruits = stats.inventory.filter((item) => item.type === 'fruit');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Pirate Inventory</h2>
              <p className="text-xs text-slate-400">Manage Devil Fruits, Swords, and combat gear</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 px-6 pt-3 gap-4">
          <button
            onClick={() => setActiveTab('fruits')}
            className={`pb-2.5 text-xs font-bold transition-colors cursor-pointer flex items-center gap-2 border-b-2 ${
              activeTab === 'fruits'
                ? 'border-purple-400 text-purple-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Flame className="w-4 h-4" />
            <span>Devil Fruits ({storedFruits.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('weapons')}
            className={`pb-2.5 text-xs font-bold transition-colors cursor-pointer flex items-center gap-2 border-b-2 ${
              activeTab === 'weapons'
                ? 'border-sky-400 text-sky-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Swords className="w-4 h-4" />
            <span>Weapons & Swords</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          {activeTab === 'fruits' && (
            <div>
              {/* Equipped Fruit Card */}
              <div className="bg-slate-950/80 border border-purple-800/60 rounded-xl p-4 mb-4 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono text-purple-400 font-bold uppercase tracking-wider">
                    Currently Equipped
                  </span>
                  <div className="text-base font-bold text-white mt-0.5">
                    {stats.equippedFruit !== 'none'
                      ? FRUITS[stats.equippedFruit]?.name
                      : 'No Fruit (Normal Human Body)'}
                  </div>
                  {stats.equippedFruit !== 'none' && (
                    <div className="text-xs text-slate-300 font-mono mt-1">
                      Fruit Mastery Level: <span className="text-amber-400 font-bold">{stats.fruitMastery}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Stored Fruit List */}
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                Stored Fruit Inventory
              </div>

              {storedFruits.length === 0 ? (
                <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-8 text-center text-slate-400 text-xs">
                  No Devil Fruits stored in bag. Visit the Fruit Dealer to spin or search under island palm trees!
                </div>
              ) : (
                <div className="space-y-2">
                  {storedFruits.map((item) => {
                    const fruit = FRUITS[item.itemKey];
                    const isCurrentlyEquipped = stats.equippedFruit === item.itemKey;
                    return (
                      <div
                        key={item.id}
                        className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-purple-950/80 border border-purple-800 flex items-center justify-center text-purple-400">
                            <Flame className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm text-white">{fruit?.name || item.name}</span>
                              <span className="text-[10px] font-mono text-purple-300 bg-purple-950 px-1.5 py-0.5 rounded border border-purple-800">
                                {fruit?.rarity || 'Common'}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">{fruit?.description}</p>
                          </div>
                        </div>

                        {isCurrentlyEquipped ? (
                          <div className="flex items-center gap-1 text-xs font-bold text-emerald-400 px-3 py-1.5">
                            <Check className="w-4 h-4" />
                            <span>Active</span>
                          </div>
                        ) : (
                          <button
                            onClick={() => onEatFruit(item.itemKey as FruitType)}
                            className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-lg transition-transform active:scale-95 cursor-pointer shrink-0"
                          >
                            Eat Fruit
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {activeTab === 'weapons' && (
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                Available Fighting Styles & Swords
              </div>

              {(Object.keys(WEAPONS) as WeaponType[]).map((wKey) => {
                const weapon = WEAPONS[wKey];
                const isEquipped = stats.equippedWeapon === wKey;
                const isFreeOrOwned = weapon.price === 0 || stats.inventory.some((i) => i.itemKey === wKey);

                return (
                  <div
                    key={wKey}
                    className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-sky-400">
                        <Swords className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-white">{weapon.name}</span>
                          <span className="text-[11px] font-mono text-amber-400 font-semibold">
                            Base DMG: {weapon.damage}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">{weapon.description}</p>
                      </div>
                    </div>

                    <div>
                      {isEquipped ? (
                        <div className="flex items-center gap-1 text-xs font-bold text-emerald-400 px-3 py-1.5">
                          <Check className="w-4 h-4" />
                          <span>Equipped</span>
                        </div>
                      ) : isFreeOrOwned ? (
                        <button
                          onClick={() => onEquipWeapon(wKey)}
                          className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-lg transition-transform active:scale-95 cursor-pointer"
                        >
                          Equip
                        </button>
                      ) : (
                        <button
                          onClick={() => onBuyWeapon(wKey)}
                          disabled={stats.beli < weapon.price}
                          className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-transform active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                        >
                          Buy ({weapon.price.toLocaleString()} Beli)
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
