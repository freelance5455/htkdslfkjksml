import React, { useState } from 'react';
import { GameEngine } from '../game/engine';
import { ITEMS } from '../game/items';
import { HotbarItemIcon } from './HUD';
import { X, ArrowDownToLine, Trash2, Utensils, CheckCircle2, Backpack, Package } from 'lucide-react';

interface InventoryModalProps {
  engine: GameEngine;
  onClose: () => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({ engine, onClose }) => {
  const [selectedSlotIndex, setSelectedSlotIndex] = useState<number | null>(0);
  const [dragFromIndex, setDragFromIndex] = useState<number | null>(null);

  const selectedSlot = selectedSlotIndex !== null ? engine.inventory[selectedSlotIndex] : null;
  const selectedDef = selectedSlot && selectedSlot.item ? ITEMS[selectedSlot.item] : null;

  const handleSlotClick = (idx: number) => {
    if (dragFromIndex !== null) {
      engine.swapInventorySlots(dragFromIndex, idx);
      setDragFromIndex(null);
      setSelectedSlotIndex(idx);
    } else {
      setSelectedSlotIndex(idx);
    }
  };

  const handleUseItem = () => {
    if (selectedSlotIndex === null) return;
    const slot = engine.inventory[selectedSlotIndex];
    if (slot && slot.item) {
      const def = ITEMS[slot.item];
      if (def.category === 'food') {
        engine.selectHotbarSlot(selectedSlotIndex < 5 ? selectedSlotIndex : 0);
        engine.useCurrentItem();
      }
    }
  };

  const handleEquipHotbar = () => {
    if (selectedSlotIndex === null) return;
    // Swap into hotbar slot 0 if not already in hotbar
    if (selectedSlotIndex >= 5) {
      engine.swapInventorySlots(selectedSlotIndex, 0);
      setSelectedSlotIndex(0);
      engine.selectHotbarSlot(0);
    } else {
      engine.selectHotbarSlot(selectedSlotIndex);
    }
  };

  const handleDropItem = () => {
    if (selectedSlotIndex === null) return;
    engine.dropItemFromInventory(selectedSlotIndex);
  };

  // Chest storage transfer
  const activeChest = engine.activeOpenChest;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-2 sm:p-6 font-['Tajawal',sans-serif]">
      <div className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto bg-neutral-900 border-2 border-amber-600/80 rounded-2xl shadow-2xl p-3.5 sm:p-6 text-white flex flex-col gap-3 sm:gap-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-700 pb-3">
          <div className="flex items-center gap-2">
            <Backpack className="w-5 h-5 text-amber-400" />
            <h2 className="text-base sm:text-lg font-bold text-amber-300">
              {activeChest ? 'صندوق التخزين والمؤن' : 'حقيبة البقاء — 20 خانة'}
            </h2>
          </div>
          <button
            id="btn-close-inventory"
            onClick={() => {
              if (engine.activeOpenChest) engine.activeOpenChest = null;
              onClose();
            }}
            className="p-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chest Storage section if open */}
        {activeChest && (
          <div className="bg-neutral-950/80 border border-amber-500/40 p-3 rounded-xl flex flex-col gap-2">
            <span className="text-xs font-bold text-amber-400">محتويات الصندوق (8 خانات):</span>
            <div className="grid grid-cols-4 gap-2">
              {activeChest.storage?.map((slot, cIdx) => (
                <div
                  key={cIdx}
                  onClick={() => {
                    // Move from chest to inventory
                    if (slot && slot.item) {
                      const added = engine.addToInventory(slot.item, slot.count);
                      if (added && activeChest.storage) {
                        activeChest.storage[cIdx] = null;
                      }
                    }
                  }}
                  className="h-12 border-2 border-dashed border-amber-700/60 bg-neutral-900 rounded-lg flex items-center justify-center relative cursor-pointer hover:border-amber-400"
                >
                  {slot && slot.item ? (
                    <>
                      <HotbarItemIcon itemId={slot.item} />
                      {slot.count > 1 && (
                        <span className="absolute bottom-0.5 right-1 text-[10px] font-mono font-bold bg-black/80 px-1 rounded text-white">
                          {slot.count}
                        </span>
                      )}
                    </>
                  ) : (
                    <span className="text-[10px] text-neutral-600">فارغ</span>
                  )}
                </div>
              ))}
            </div>
            <span className="text-[10px] text-neutral-400 text-left">
              * انقر على عنصر في الصندوق لنقله للحقيبة، أو استخدم زر "تخزين في الصندوق" أدناه.
            </span>
          </div>
        )}

        {/* Main 5x4 Grid (20 Slots) */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>الشبكة الرئيسية (5 × 4)</span>
            <span className="text-amber-400/80">السطر الأول = شريط الوصول السريع</span>
          </div>

          <div className="grid grid-cols-5 gap-2 bg-neutral-950/60 p-3 rounded-xl border border-neutral-800">
            {engine.inventory.map((slot, idx) => {
              const isSelected = selectedSlotIndex === idx;
              const isHotbar = idx < 5;
              const itemDef = slot && slot.item ? ITEMS[slot.item] : null;

              return (
                <button
                  key={idx}
                  id={`inv-slot-${idx}`}
                  onClick={() => handleSlotClick(idx)}
                  className={`relative h-12 sm:h-14 rounded-lg border-2 flex items-center justify-center transition cursor-pointer ${
                    isSelected
                      ? 'border-amber-400 bg-amber-950/50 shadow-md shadow-amber-500/20'
                      : isHotbar
                      ? 'border-neutral-700 bg-neutral-800/80 hover:border-neutral-500'
                      : 'border-neutral-800 bg-neutral-900/80 hover:border-neutral-600'
                  }`}
                >
                  {slot && slot.item ? (
                    <>
                      <HotbarItemIcon itemId={slot.item} />
                      {slot.count > 1 && (
                        <span className="absolute bottom-1 right-1 text-[10px] font-mono font-bold text-white bg-black/80 px-1 rounded">
                          {slot.count}
                        </span>
                      )}
                      {slot.durability !== undefined && itemDef?.maxDurability && (
                        <div className="absolute bottom-1 left-1 right-1 h-1 bg-neutral-800 rounded-xs overflow-hidden">
                          <div
                            className="h-full bg-cyan-400"
                            style={{ width: `${(slot.durability / itemDef.maxDurability) * 100}%` }}
                          />
                        </div>
                      )}
                    </>
                  ) : (
                    <span className="text-[10px] font-mono text-neutral-700">{idx + 1}</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Item Details & Actions */}
        <div className="bg-neutral-950/90 border border-neutral-800 p-3 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 min-h-[76px]">
          {selectedDef && selectedSlot ? (
            <>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <div className="w-11 h-11 bg-neutral-800 rounded-lg border border-neutral-700 flex items-center justify-center shrink-0">
                  <HotbarItemIcon itemId={selectedDef.id} />
                </div>
                <div className="flex flex-col text-right">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-amber-300">{selectedDef.nameAr}</span>
                    <span className="text-[10px] font-mono bg-neutral-800 px-1.5 py-0.5 rounded text-neutral-400">
                      الكمية: {selectedSlot.count}
                    </span>
                  </div>
                  <span className="text-xs text-neutral-300 leading-snug">{selectedDef.descriptionAr}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                {selectedDef.category === 'food' && (
                  <button
                    onClick={handleUseItem}
                    className="flex items-center gap-1 bg-cyan-700 hover:bg-cyan-600 active:scale-95 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer"
                  >
                    <Utensils className="w-3.5 h-3.5" />
                    <span>تناول الطعام</span>
                  </button>
                )}

                <button
                  onClick={handleEquipHotbar}
                  className="flex items-center gap-1 bg-amber-700 hover:bg-amber-600 active:scale-95 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>تجهيز باليد</span>
                </button>

                {activeChest && activeChest.storage && (
                  <button
                    onClick={() => {
                      if (selectedSlotIndex === null) return;
                      const emptyCIdx = activeChest.storage?.findIndex((s) => s === null);
                      if (emptyCIdx !== undefined && emptyCIdx !== -1 && activeChest.storage) {
                        activeChest.storage[emptyCIdx] = { ...selectedSlot };
                        engine.inventory[selectedSlotIndex] = null;
                        setSelectedSlotIndex(null);
                      }
                    }}
                    className="flex items-center gap-1 bg-emerald-700 hover:bg-emerald-600 active:scale-95 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer"
                  >
                    <ArrowDownToLine className="w-3.5 h-3.5" />
                    <span>تخزين بالصندوق</span>
                  </button>
                )}

                <button
                  onClick={handleDropItem}
                  className="p-2 bg-red-950/80 hover:bg-red-900 border border-red-800 text-red-300 active:scale-95 rounded-lg text-xs transition cursor-pointer"
                  title="إسقاط العنصر في الأرض"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </>
          ) : (
            <span className="text-xs text-neutral-500 w-full text-center py-2">
              اختر خانة لعرض تفاصيل العنصر أو نقله وتجهيزه.
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
