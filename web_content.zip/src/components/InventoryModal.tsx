import React, { useMemo, useState } from 'react';
import { Backpack, Trash2, Check, Shield, X, Coins, Sparkles } from 'lucide-react';
import { ITEMS, RARITY_META } from '../game/data/items';
import { InventoryEntry, ItemCategory } from '../game/types';
import { ItemIcon } from './ItemIcon';

interface InventoryModalProps {
  open: boolean;
  inventory: InventoryEntry[];
  gold: number;
  elementShards: number;
  onClose: () => void;
  onUseItem: (index: number) => void;
  onEquipItem: (index: number) => void;
  onDropItem: (index: number) => void;
}

const CATEGORIES: Array<{ id: 'all' | ItemCategory; labelAr: string }> = [
  { id: 'all', labelAr: 'الكل' },
  { id: 'weapon', labelAr: 'الأسلحة' },
  { id: 'armor', labelAr: 'الدروع' },
  { id: 'consumable', labelAr: 'طعام وجرعات' },
  { id: 'material', labelAr: 'موارد' },
];

export const InventoryModal: React.FC<InventoryModalProps> = ({
  open,
  inventory,
  gold,
  elementShards,
  onClose,
  onUseItem,
  onEquipItem,
  onDropItem,
}) => {
  const [category, setCategory] = useState<'all' | ItemCategory>('all');
  const [selectedIdx, setSelectedIdx] = useState<number | null>(0);

  const filteredItems = useMemo(() => {
    return inventory
      .map((entry, idx) => ({ entry, idx, def: ITEMS[entry.itemId] }))
      .filter((x) => x.def && (category === 'all' || x.def.category === category));
  }, [inventory, category]);

  if (!open) return null;

  const selected =
    selectedIdx !== null && inventory[selectedIdx]
      ? {
          entry: inventory[selectedIdx],
          idx: selectedIdx,
          def: ITEMS[inventory[selectedIdx].itemId],
        }
      : filteredItems[0] ?? null;

  const rarity = selected?.def ? RARITY_META[selected.def.rarity] : null;

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-2 sm:p-5"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-amber-500/35 bg-slate-900 text-slate-100 shadow-2xl">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-4 py-3 sm:px-5">
          <div className="flex items-center gap-2.5">
            <Backpack className="h-5 w-5 text-amber-400" />
            <h2 className="text-base font-bold text-amber-100 sm:text-lg">المخزون</h2>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1 rounded-lg border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 font-bold text-amber-300">
              <Coins className="h-3.5 w-3.5" />
              {gold}
            </span>
            <span className="flex items-center gap-1 rounded-lg border border-sky-500/30 bg-sky-500/10 px-2.5 py-1 font-bold text-sky-300">
              <Sparkles className="h-3.5 w-3.5" />
              {elementShards} شظية
            </span>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-700 bg-slate-800 p-2 text-slate-300 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex gap-1.5 overflow-x-auto border-b border-slate-800 bg-slate-950/50 px-4 py-2.5">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setCategory(c.id)}
              className={`shrink-0 rounded-lg border px-3 py-1.5 text-xs font-bold transition ${
                category === c.id
                  ? 'border-amber-400 bg-amber-500/20 text-amber-100'
                  : 'border-slate-700 bg-slate-800/70 text-slate-300 hover:border-slate-600'
              }`}
            >
              {c.labelAr}
            </button>
          ))}
        </div>

        {/* Body: Visual Square Grid + Detail Inspector */}
        <div className="grid flex-1 grid-cols-1 overflow-hidden sm:grid-cols-5">
          {/* Square Grid */}
          <div className="hud-scroll col-span-3 overflow-y-auto p-4">
            {filteredItems.length === 0 ? (
              <div className="flex h-40 items-center justify-center text-sm text-slate-400">
                لا توجد أغراض في هذا التصنيف.
              </div>
            ) : (
              <div className="grid grid-cols-4 gap-2.5 sm:grid-cols-5">
                {filteredItems.map(({ entry, idx, def }) => {
                  const r = RARITY_META[def.rarity];
                  const isSel = selected?.idx === idx;
                  return (
                    <button
                      key={`${entry.itemId}_${idx}`}
                      type="button"
                      onClick={() => setSelectedIdx(idx)}
                      className={`relative flex aspect-square flex-col items-center justify-center rounded-xl border-2 p-1.5 transition active:scale-95 ${r.borderClass} ${r.bgClass} ${
                        isSel ? 'ring-2 ring-amber-300' : ''
                      }`}
                    >
                      <ItemIcon kind={def.icon} tintHex={def.tintHex} className="h-9 w-9 sm:h-10 sm:w-10" />
                      <span className="mt-1 line-clamp-1 w-full text-center text-[10px] font-semibold text-slate-200">
                        {def.nameAr}
                      </span>
                      {entry.quantity > 1 && (
                        <span className="absolute top-1 left-1 rounded bg-slate-950/90 px-1.5 py-0.5 font-mono text-[10px] font-bold text-amber-200">
                          {entry.quantity}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Item Details Panel */}
          <div className="col-span-2 flex flex-col justify-between border-t border-slate-800 bg-slate-950/70 p-4 sm:border-t-0 sm:border-r">
            {selected?.def && rarity ? (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`flex h-16 w-16 shrink-0 items-center justify-center rounded-xl border-2 ${rarity.borderClass} ${rarity.bgClass}`}
                  >
                    <ItemIcon kind={selected.def.icon} tintHex={selected.def.tintHex} className="h-11 w-11" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">{selected.def.nameAr}</div>
                    <div className={`text-xs font-semibold ${rarity.textClass}`}>
                      {rarity.labelAr} • الكمية: {selected.entry.quantity}
                    </div>
                  </div>
                </div>

                <p className="text-xs leading-relaxed text-slate-300">
                  {selected.def.descriptionAr}
                </p>

                {/* Stats */}
                {selected.def.stats && (
                  <div className="space-y-1 rounded-xl border border-slate-800 bg-slate-900/80 p-2.5 text-xs">
                    {selected.def.stats.attack && (
                      <div className="text-rose-300">• الهجوم: +{selected.def.stats.attack}</div>
                    )}
                    {selected.def.stats.defense && (
                      <div className="text-sky-300">• الدفاع: +{selected.def.stats.defense}</div>
                    )}
                    {selected.def.stats.magic && (
                      <div className="text-purple-300">• السحر: +{selected.def.stats.magic}</div>
                    )}
                    {selected.def.stats.maxHp && (
                      <div className="text-emerald-300">• الصحة القصوى: +{selected.def.stats.maxHp}</div>
                    )}
                    {selected.def.stats.maxMana && (
                      <div className="text-indigo-300">• المانا القصوى: +{selected.def.stats.maxMana}</div>
                    )}
                    {selected.def.stats.speedBonus && (
                      <div className="text-teal-300">
                        • السرعة: +{Math.round(selected.def.stats.speedBonus * 100)}%
                      </div>
                    )}
                  </div>
                )}

                {selected.def.consumable && (
                  <div className="space-y-1 rounded-xl border border-slate-800 bg-slate-900/80 p-2.5 text-xs text-emerald-300">
                    {selected.def.consumable.hp && <div>• استعادة الصحة: +{selected.def.consumable.hp}</div>}
                    {selected.def.consumable.mana && <div>• استعادة المانا: +{selected.def.consumable.mana}</div>}
                    {selected.def.consumable.hunger && <div>• الشبع: +{selected.def.consumable.hunger}%</div>}
                    {selected.def.consumable.thirst && <div>• الارتواء: +{selected.def.consumable.thirst}%</div>}
                  </div>
                )}
              </div>
            ) : (
              <div className="text-xs text-slate-400">اضغط على أي غرض لعرض تفاصيله.</div>
            )}

            {selected?.def && (
              <div className="mt-4 flex flex-wrap gap-2">
                {selected.def.equipSlot && (
                  <button
                    type="button"
                    onClick={() => onEquipItem(selected.idx)}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-amber-600 px-3 py-2.5 text-xs font-bold text-white hover:bg-amber-500"
                  >
                    <Shield className="h-4 w-4" />
                    تجهيز
                  </button>
                )}
                {selected.def.consumable && (
                  <button
                    type="button"
                    onClick={() => onUseItem(selected.idx)}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2.5 text-xs font-bold text-white hover:bg-emerald-500"
                  >
                    <Check className="h-4 w-4" />
                    استخدام
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onDropItem(selected.idx)}
                  className="flex items-center justify-center gap-1 rounded-xl border border-rose-500/40 bg-rose-500/15 px-3 py-2.5 text-xs font-bold text-rose-300 hover:bg-rose-500/25"
                >
                  <Trash2 className="h-4 w-4" />
                  تخلص
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
