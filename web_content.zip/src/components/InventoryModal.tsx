import React, { useState } from 'react';
import { useGame } from '../context/GameContext.tsx';
import type { InventoryItem } from '../types/game.ts';
import { Lock, Unlock, DollarSign, ShieldCheck, X } from 'lucide-react';

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({ isOpen, onClose }) => {
  const {
    inventory,
    player,
    toggleItemLock,
    toggleKeepTenUnits,
    bulkSellCategory,
    sellSingleItem,
  } = useGame();

  const [activeTab, setActiveTab] = useState<1 | 2 | 3 | 4 | 5 | 6>(2);
  const [sellResultNotice, setSellResultNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const tabsConfig = [
    { id: 1 as const, label: '🌱 Giống & Phôi Lai', hideBulkSell: true },
    { id: 2 as const, label: '🌾 Nông Sản & Quả', hideBulkSell: false },
    { id: 3 as const, label: '🥚 Chăn Nuôi, Mật & Nấm', hideBulkSell: false },
    { id: 4 as const, label: '🐟 Thủy Hải Sản', hideBulkSell: false },
    { id: 5 as const, label: '🥐 Thành Phẩm Chế Biến', hideBulkSell: false },
    { id: 6 as const, label: '🧪 Vật Tư & Thức Ăn', hideBulkSell: true },
  ];

  const currentTabConfig = tabsConfig.find((t) => t.id === activeTab) || tabsConfig[0];
  const itemsInTab = inventory.filter((i) => i.categoryTab === activeTab);

  const handleBulkSell = () => {
    const res = bulkSellCategory(activeTab);
    if (res.countSold > 0) {
      setSellResultNotice(`Đã bán ${res.countSold} món, thu về +${res.goldEarned.toLocaleString()} 🪙 Vàng!`);
    } else {
      setSellResultNotice('Không có món hàng nào vượt quá 10 đơn vị hoặc tất cả đã bị khóa!');
    }
    setTimeout(() => setSellResultNotice(null), 3500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-in fade-in">
      <div className="bg-stone-900 border-2 border-stone-700 rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-stone-950 p-4 border-b border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl sm:text-3xl">📦</span>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-amber-300">Kho Đồ Nông Trại Thông Minh</h2>
              <p className="text-xs text-stone-400">
                Phân loại 6 danh mục • Khóa vật phẩm an toàn 🔒 • Công tắc giữ lại 10 đơn vị
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-stone-100 transition"
            aria-label="Đóng Kho Đồ"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 6 Tabs */}
        <div className="bg-stone-900/90 border-b border-stone-800 px-3 py-2 flex items-center gap-1.5 overflow-x-auto scrollbar-thin">
          {tabsConfig.map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold whitespace-nowrap transition ${
                activeTab === tab.id
                  ? 'bg-amber-500/20 text-amber-300 border-amber-400 shadow ring-1 ring-amber-400/40'
                  : 'bg-stone-800 text-stone-400 border-stone-700 hover:text-stone-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Action sub-bar: Safe bulk selling & Keep 10 toggle */}
        <div className="bg-stone-950/70 px-4 py-2 border-b border-stone-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          {/* Keep 10 toggle */}
          <label className="flex items-center gap-2 cursor-pointer select-none text-stone-300">
            <input
              type="checkbox"
              checked={player.keepTenUnitsActive}
              onChange={toggleKeepTenUnits}
              className="w-4 h-4 rounded text-amber-500 accent-amber-500 bg-stone-800 border-stone-600 focus:ring-0"
            />
            <span className="flex items-center gap-1 font-semibold">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Tự động giữ lại 10 đơn vị mỗi loại (để chế biến / lai tạo)
            </span>
          </label>

          {/* Bulk sell button for allowed tabs */}
          {!currentTabConfig.hideBulkSell && (
            <button
              type="button"
              onClick={handleBulkSell}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold transition shadow"
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>Bán Hết Danh Mục Này</span>
            </button>
          )}
        </div>

        {sellResultNotice && (
          <div className="mx-4 mt-2 p-2 rounded-xl bg-amber-950/60 border border-amber-500/50 text-amber-200 text-xs font-bold animate-pulse text-center">
            {sellResultNotice}
          </div>
        )}

        {/* Items Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          {itemsInTab.length === 0 ? (
            <div className="text-center py-16 text-stone-500 text-sm">
              <p>Danh mục này hiện đang trống!</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
              {itemsInTab.map((item) => (
                <div
                  key={item.id}
                  className={`bg-stone-950 border-2 rounded-2xl p-3 flex flex-col justify-between space-y-2 relative transition ${
                    item.locked ? 'border-amber-600/60' : 'border-stone-800 hover:border-stone-700'
                  }`}
                >
                  {/* Top: Tier badge & Lock toggle */}
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] px-1.5 py-0.2 bg-stone-800 text-amber-400 rounded font-bold border border-stone-700">
                      Bậc {item.tier}
                    </span>

                    <button
                      type="button"
                      onClick={() => toggleItemLock(item.id)}
                      className={`p-1 rounded-lg border transition ${
                        item.locked
                          ? 'bg-amber-600/30 text-amber-300 border-amber-500'
                          : 'bg-stone-800 text-stone-500 border-stone-700 hover:text-stone-300'
                      }`}
                      title={item.locked ? 'Đã khóa chống bán' : 'Khóa món đồ'}
                    >
                      {item.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                    </button>
                  </div>

                  {/* Icon & Name */}
                  <div className="flex flex-col items-center text-center">
                    <span className="text-3xl sm:text-4xl mb-1">{item.icon}</span>
                    <h4 className="text-xs font-bold text-stone-100 truncate max-w-full">{item.name}</h4>
                    <span className="text-[11px] text-stone-400 mt-0.5 font-semibold">
                      Số lượng: <strong className="text-amber-400">{item.count}</strong>
                    </span>
                  </div>

                  {/* Footer: Sell single */}
                  <div className="flex items-center justify-between pt-1 border-t border-stone-800/80 text-[11px]">
                    <span className="text-amber-400 font-bold">{item.sellPrice} 🪙</span>
                    <button
                      type="button"
                      disabled={item.locked}
                      onClick={() => sellSingleItem(item.id, 1)}
                      className={`px-2 py-0.5 rounded-lg font-bold transition ${
                        item.locked
                          ? 'bg-stone-800 text-stone-600 cursor-not-allowed'
                          : 'bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700'
                      }`}
                    >
                      Bán 1
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
