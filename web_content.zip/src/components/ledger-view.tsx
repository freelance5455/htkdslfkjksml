import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Field, PnlText, Segment, Sheet } from "@/components/ui";
import { formatKrw, formatMan, formatPrice, formatQty, parseNum, today } from "@/lib/format";
import { cleanSymbol } from "@/lib/symbols";
import { usePortfolio } from "@/lib/store";
import type { Currency, PriceMode, Tx, TxKind } from "@/lib/types";

export type TradeRequest = { nonce: number; kind: TxKind; holdingId: string | null };

export function LedgerView({ request }: { request: TradeRequest | null }) {
  const txs = usePortfolio((state) => state.txs);
  const accounts = usePortfolio((state) => state.accounts);
  const removeTx = usePortfolio((state) => state.removeTx);
  const [kindFilter, setKindFilter] = useState<"all" | TxKind>("all");
  const [year, setYear] = useState("all");
  const [month, setMonth] = useState("all");
  const [accountId, setAccountId] = useState("all");
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<TradeRequest | null>(null);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);

  useEffect(() => {
    if (!request) return;
    setDraft(request);
    setOpen(true);
  }, [request]);

  const years = useMemo(() => {
    const set = new Set(txs.map((tx) => tx.date.slice(0, 4)));
    set.add(String(new Date().getFullYear()));
    return [...set].sort((a, b) => b.localeCompare(a));
  }, [txs]);

  const filtered = txs.filter((tx) => {
    if (kindFilter !== "all" && tx.kind !== kindFilter) return false;
    if (accountId !== "all" && tx.accountId !== accountId) return false;
    if (year !== "all" && !tx.date.startsWith(year)) return false;
    if (month !== "all" && tx.date.slice(5, 7) !== month) return false;
    return true;
  });

  const sums = {
    buy: filtered.filter((tx) => tx.kind === "buy").reduce((sum, tx) => sum + tx.amountKrw, 0),
    sell: filtered.filter((tx) => tx.kind === "sell").reduce((sum, tx) => sum + tx.amountKrw, 0),
    dividend: filtered.filter((tx) => tx.kind === "dividend").reduce((sum, tx) => sum + tx.amountKrw, 0),
  };

  const yearRollup = useMemo(() => {
    const map = new Map<string, { buy: number; sell: number; dividend: number }>();
    for (const tx of filtered) {
      const key = tx.date.slice(0, 4);
      const row = map.get(key) ?? { buy: 0, sell: 0, dividend: 0 };
      row[tx.kind] += tx.amountKrw;
      map.set(key, row);
    }
    return [...map.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  }, [filtered]);

  const groups: { month: string; items: Tx[] }[] = [];
  for (const tx of filtered) {
    const key = tx.date.slice(0, 7);
    const last = groups[groups.length - 1];
    if (!last || last.month !== key) groups.push({ month: key, items: [tx] });
    else last.items.push(tx);
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-base font-semibold">매매·배당 기록</h2>
        <button
          type="button"
          className="h-11 rounded-lg bg-primary px-3 text-sm font-medium text-primary-fg"
          onClick={() => {
            setDraft({ nonce: Date.now(), kind: "buy", holdingId: null });
            setOpen(true);
          }}
        >
          기록하기
        </button>
      </div>
      <Segment
        value={kindFilter}
        onChange={setKindFilter}
        options={[
          { id: "all", label: "전체" },
          { id: "buy", label: "매수" },
          { id: "sell", label: "매도" },
          { id: "dividend", label: "배당" },
        ]}
      />
      <div className="grid grid-cols-3 gap-2">
        <select className="field" aria-label="연도" value={year} onChange={(event) => setYear(event.target.value)}>
          <option value="all">모든 해</option>
          {years.map((item) => (
            <option key={item} value={item}>
              {item}년
            </option>
          ))}
        </select>
        <select className="field" aria-label="월" value={month} onChange={(event) => setMonth(event.target.value)}>
          <option value="all">모든 달</option>
          {Array.from({ length: 12 }, (_, index) => String(index + 1).padStart(2, "0")).map((item) => (
            <option key={item} value={item}>
              {Number(item)}월
            </option>
          ))}
        </select>
        <select className="field" aria-label="계좌" value={accountId} onChange={(event) => setAccountId(event.target.value)}>
          <option value="all">모든 계좌</option>
          {accounts.map((account) => (
            <option key={account.id} value={account.id}>
              {account.name}
            </option>
          ))}
        </select>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <Sum label="매수" value={sums.buy} />
        <Sum label="매도" value={sums.sell} />
        <Sum label="배당" value={sums.dividend} />
      </div>
      {year === "all" && yearRollup.length > 1 ? (
        <section className="card overflow-hidden">
          <header className="border-b border-line px-4 py-3 text-sm font-semibold">연도별</header>
          <ul>
            {yearRollup.map(([itemYear, row]) => (
              <li key={itemYear} className="border-t border-line px-4 py-3 first:border-t-0">
                <p className="text-sm font-medium tabular-nums">{itemYear}</p>
                <p className="text-xs tabular-nums text-muted">
                  매수 {formatMan(row.buy)} · 매도 {formatMan(row.sell)} · 배당 {formatMan(row.dividend)}
                </p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
      {groups.length === 0 ? <p className="text-sm text-muted">이 조건의 기록이 없습니다.</p> : null}
      {groups.map((group) => {
        const monthBuy = group.items.filter((tx) => tx.kind === "buy").reduce((sum, tx) => sum + tx.amountKrw, 0);
        const monthSell = group.items.filter((tx) => tx.kind === "sell").reduce((sum, tx) => sum + tx.amountKrw, 0);
        const monthDiv = group.items.filter((tx) => tx.kind === "dividend").reduce((sum, tx) => sum + tx.amountKrw, 0);
        return (
        <section key={group.month} className="card overflow-hidden">
          <header className="border-b border-line px-4 py-3">
            <p className="text-sm font-semibold tabular-nums">{group.month.replace("-", ".")}</p>
            <p className="text-xs tabular-nums text-muted">
              매수 {formatMan(monthBuy)} · 매도 {formatMan(monthSell)} · 배당 {formatMan(monthDiv)}
            </p>
          </header>
          <ul>
            {group.items.map((tx) => {
              const account = accounts.find((item) => item.id === tx.accountId);
              return (
                <li key={tx.id} className="border-t border-line px-4 py-3 first:border-t-0">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">
                        {labelOf(tx.kind)} · {tx.name}
                      </p>
                      <p className="truncate text-xs text-muted">
                        {tx.date} · {account?.name ?? "계좌 없음"}
                        {tx.kind === "dividend"
                          ? ` · ${tx.currency === "USD" ? formatPrice(tx.price, "USD") : formatKrw(tx.price)}`
                          : ` · ${formatQty(tx.quantity)} × ${formatPrice(tx.price, tx.currency)}`}
                      </p>
                      {tx.kind === "sell" ? (
                        <p className="text-xs">
                          <PnlText value={tx.realizedKrw}>실현 {formatKrw(tx.realizedKrw)}</PnlText>
                        </p>
                      ) : null}
                    </div>
                    <p className="shrink-0 text-right">
                      <span className="block text-sm font-medium tabular-nums">{formatKrw(tx.amountKrw)}</span>
                      {pendingDelete === tx.id ? (
                        <span className="mt-1 flex justify-end gap-1">
                          <button type="button" className="h-11 px-2 text-xs text-down" onClick={() => { removeTx(tx.id); setPendingDelete(null); }}>
                            삭제
                          </button>
                          <button type="button" className="h-11 px-2 text-xs" onClick={() => setPendingDelete(null)}>
                            취소
                          </button>
                        </span>
                      ) : (
                        <button type="button" className="h-11 text-xs text-muted" onClick={() => setPendingDelete(tx.id)}>
                          삭제
                        </button>
                      )}
                    </p>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
        );
      })}
      <Sheet open={open} title="기록하기" onClose={() => setOpen(false)}>
        {draft && open ? <TradeForm key={draft.nonce} request={draft} onClose={() => setOpen(false)} /> : null}
      </Sheet>
    </div>
  );
}

function Sum({ label, value }: { label: string; value: number }) {
  return (
    <div className="card px-3 py-3">
      <p className="text-xs text-muted">{label}</p>
      <p className="text-sm font-semibold tabular-nums">{formatKrw(value)}</p>
    </div>
  );
}

function labelOf(kind: TxKind) {
  if (kind === "buy") return "매수";
  if (kind === "sell") return "매도";
  return "배당";
}

function TradeForm({ request, onClose }: { request: TradeRequest; onClose: () => void }) {
  const data = usePortfolio();
  const [kind, setKind] = useState<TxKind>(request.kind);
  const [mode, setMode] = useState<"existing" | "new">(request.holdingId || request.kind !== "buy" ? "existing" : "existing");
  const [holdingId, setHoldingId] = useState(request.holdingId ?? data.holdings.find((item) => item.quantity > 0)?.id ?? "");
  const [date, setDate] = useState(today());
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState<Currency>("KRW");
  const [name, setName] = useState("");
  const [symbol, setSymbol] = useState("");
  const [accountId, setAccountId] = useState(data.accounts[0]?.id ?? "");
  const [newAccount, setNewAccount] = useState("");
  const [classId, setClassId] = useState(data.classes[0]?.id ?? "");
  const [priceMode, setPriceMode] = useState<PriceMode>("auto");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);

  const holding = data.holdings.find((item) => item.id === holdingId) ?? null;
  const openHoldings = data.holdings.filter((item) => item.quantity > 0 || item.id === request.holdingId);

  useEffect(() => {
    if (holding && kind === "dividend") setCurrency(holding.currency);
  }, [holding, kind]);

  function submit(event: FormEvent) {
    event.preventDefault();
    const qty = parseNum(quantity);
    const px = parseNum(price);
    const cash = parseNum(amount);
    let message: string | null = "입력값을 확인해 주세요.";
    if (kind === "dividend") {
      if (!holding) message = "종목을 선택하세요.";
      else message = data.addDividend({ holdingId: holding.id, amount: cash ?? 0, currency, date });
    } else if (kind === "sell") {
      if (!holding) message = "종목을 선택하세요.";
      else message = data.sell({ holdingId: holding.id, quantity: qty ?? 0, price: px ?? 0, date });
    } else if (mode === "existing") {
      if (!holding) message = "종목을 선택하세요.";
      else message = data.buyExisting({ holdingId: holding.id, quantity: qty ?? 0, price: px ?? 0, date });
    } else {
      if (priceMode === "auto" && !cleanSymbol(symbol)) {
        setError("자동 시세는 티커가 필요합니다.");
        return;
      }
      message = data.buyNew({
        accountId: newAccount.trim() ? "" : accountId,
        newAccountName: newAccount,
        classId,
        name,
        symbol,
        currency,
        priceMode,
        quantity: qty ?? 0,
        avgPrice: px ?? 0,
        currentPrice: priceMode === "fx" ? data.market.fx : px ?? 0,
        date,
        price: px ?? 0,
      });
    }
    if (message) {
      setError(message);
      setDone(null);
      return;
    }
    setError(null);
    setDone("반영했습니다.");
    setPrice("");
    setQuantity("");
    setAmount("");
  }

  const sellQty = parseNum(quantity);
  const sellPx = parseNum(price);
  const preview =
    kind === "sell" && holding && sellQty && sellPx
      ? (sellPx - holding.avgPrice) * sellQty * (holding.currency === "USD" ? data.market.fx : 1)
      : null;

  return (
    <form className="space-y-3" onSubmit={submit}>
      <Segment
        value={kind}
        onChange={setKind}
        options={[
          { id: "buy", label: "매수" },
          { id: "sell", label: "매도" },
          { id: "dividend", label: "배당" },
        ]}
      />
      {kind === "buy" ? (
        <Segment
          value={mode}
          onChange={setMode}
          options={[
            { id: "existing", label: "보유 종목" },
            { id: "new", label: "새 종목" },
          ]}
        />
      ) : null}
      {kind !== "buy" || mode === "existing" ? (
        <Field label="종목">
          <select className="field" value={holdingId} onChange={(event) => setHoldingId(event.target.value)}>
            {openHoldings.map((item) => {
              const account = data.accounts.find((entry) => entry.id === item.accountId);
              return (
                <option key={item.id} value={item.id}>
                  {item.name} · {account?.name} · {formatQty(item.quantity)}
                </option>
              );
            })}
          </select>
        </Field>
      ) : (
        <>
          <Field label="이름">
            <input className="field" value={name} onChange={(event) => setName(event.target.value)} />
          </Field>
          <Field label="티커">
            <input className="field" value={symbol} placeholder="VOO, 005930" onChange={(event) => setSymbol(event.target.value)} />
          </Field>
          <Field label="계좌">
            <select className="field" value={accountId} onChange={(event) => setAccountId(event.target.value)}>
              {data.accounts.map((account) => (
                <option key={account.id} value={account.id}>
                  {account.name}
                </option>
              ))}
              <option value="">새 계좌</option>
            </select>
          </Field>
          {accountId === "" ? (
            <Field label="새 계좌 이름">
              <input className="field" value={newAccount} onChange={(event) => setNewAccount(event.target.value)} />
            </Field>
          ) : null}
          <Field label="자산군">
            <select className="field" value={classId} onChange={(event) => setClassId(event.target.value)}>
              {data.classes.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="통화">
              <select className="field" value={currency} onChange={(event) => setCurrency(event.target.value as Currency)}>
                <option value="KRW">원화</option>
                <option value="USD">달러</option>
              </select>
            </Field>
            <Field label="시세">
              <select className="field" value={priceMode} onChange={(event) => setPriceMode(event.target.value as PriceMode)}>
                <option value="auto">자동</option>
                <option value="manual">직접</option>
                <option value="fx">환율 연동</option>
              </select>
            </Field>
          </div>
        </>
      )}
      <Field label="날짜">
        <input className="field" type="date" value={date} onChange={(event) => setDate(event.target.value)} />
      </Field>
      {kind === "dividend" ? (
        <>
          <Field label="배당 총액">
            <input className="field tabular-nums" inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} />
          </Field>
          <Field label="통화">
            <select className="field" value={currency} onChange={(event) => setCurrency(event.target.value as Currency)}>
              <option value="KRW">원화</option>
              <option value="USD">달러</option>
            </select>
          </Field>
        </>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          <Field label="가격">
            <input className="field tabular-nums" inputMode="decimal" value={price} onChange={(event) => setPrice(event.target.value)} />
          </Field>
          <Field label="수량">
            <input className="field tabular-nums" inputMode="decimal" value={quantity} onChange={(event) => setQuantity(event.target.value)} />
          </Field>
        </div>
      )}
      {kind === "sell" && holding ? (
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted">보유 {formatQty(holding.quantity)}</span>
          <button type="button" className="h-11 px-2" onClick={() => setQuantity(String(holding.quantity))}>
            전량
          </button>
        </div>
      ) : null}
      {preview != null ? (
        <p className="text-sm">
          예상 실현손익 <PnlText value={preview}>{formatKrw(preview)}</PnlText>
        </p>
      ) : null}
      {error ? <p className="text-sm text-down">{error}</p> : null}
      {done ? <p className="text-sm text-up">{done}</p> : null}
      <button type="submit" className="h-11 w-full rounded-lg bg-primary text-sm font-medium text-primary-fg">
        반영
      </button>
      <button type="button" className="h-11 w-full text-sm text-muted" onClick={onClose}>
        닫기
      </button>
    </form>
  );
}
