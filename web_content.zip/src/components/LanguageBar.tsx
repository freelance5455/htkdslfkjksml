import { ArrowLeftRight } from 'lucide-react';
import {
  OUTPUT_LANGUAGE_OPTIONS,
  SPEAKING_LANGUAGE_OPTIONS,
} from '../constants/languages';

interface LanguageBarProps {
  speakingCode: string;
  outputCode: string;
  isTranslating: boolean;
  onSpeakingChange: (code: string) => void;
  onOutputChange: (code: string) => void;
  onSwap: () => void;
}

export function LanguageBar({
  speakingCode,
  outputCode,
  isTranslating,
  onSpeakingChange,
  onOutputChange,
  onSwap,
}: LanguageBarProps) {
  return (
    <section
      aria-label="Language Selection"
      className="rounded-2xl border border-slate-200/90 bg-white p-4 shadow-[0_1px_3px_rgba(15,23,42,0.04)]"
    >
      <div className="grid grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] items-end gap-2.5 sm:gap-3">
        <div className="min-w-0">
          <label
            htmlFor="speaking-language-select"
            className="mb-1.5 block truncate text-xs font-medium text-slate-500"
          >
            Speaking Language
          </label>
          <select
            id="speaking-language-select"
            aria-label="Speaking Language"
            value={speakingCode}
            onChange={(e) => onSpeakingChange(e.target.value)}
            className="h-11 w-full rounded-xl border border-slate-200 bg-slate-50/70 px-3 text-sm font-medium text-slate-900 transition-colors hover:border-slate-300 focus:border-blue-600 focus:bg-white focus:outline-none"
          >
            {SPEAKING_LANGUAGE_OPTIONS.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.englishName} ({lang.nativeName})
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={onSwap}
          disabled={isTranslating}
          aria-label="Swap speaking and target languages"
          title="Swap languages"
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500 transition-colors hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900 focus-visible:outline-2 focus-visible:outline-blue-600 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <ArrowLeftRight className="h-4 w-4" aria-hidden="true" />
        </button>

        <div className="min-w-0">
          <label
            htmlFor="output-language-select"
            className="mb-1.5 block truncate text-xs font-medium text-slate-500"
          >
            Translate To
          </label>
          <select
            id="output-language-select"
            aria-label="Translate To"
            value={outputCode}
            disabled={isTranslating}
            onChange={(e) => onOutputChange(e.target.value)}
            className="h-11 w-full rounded-xl border border-slate-200 bg-slate-50/70 px-3 text-sm font-medium text-slate-900 transition-colors hover:border-slate-300 focus:border-blue-600 focus:bg-white focus:outline-none disabled:cursor-not-allowed disabled:opacity-60"
          >
            {OUTPUT_LANGUAGE_OPTIONS.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.code === 'same'
                  ? 'Original'
                  : `${lang.englishName} (${lang.nativeName})`}
              </option>
            ))}
          </select>
        </div>
      </div>
    </section>
  );
}
