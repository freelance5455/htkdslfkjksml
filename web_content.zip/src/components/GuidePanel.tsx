import { Card } from "./UI";

const STEPS = [
  {
    n: "1",
    t: "Ajuste a sensibilidade no app",
    d: "Na aba Sensibilidade mexa em Horizontal e Vertical e veja a leitura ao vivo (graus por pixel).",
  },
  {
    n: "2",
    t: "Copie os valores prontos",
    d: "No card “Valores para colar no Free Fire” aparece o número exato de cada campo do jogo. Use o botão Copiar.",
  },
  {
    n: "3",
    t: "No jogo: Configurações › Sensibilidade",
    d: "Em “Geral” coloque os valores Vertical e Horizontal; depois preencha Ponto Vermelho, Mira 2x, Mira 4x, Mira AWM e Olhadinha.",
  },
  {
    n: "4",
    t: "Posicione o touch",
    d: "Na aba Controles arraste os botões no preview para o lugar onde seu dedo confortável fica (o Free Fire permite mover e redimensionar os botões).",
  },
  {
    n: "5",
    t: "Treine e meca",
    d: "Use o Treino para sentir o ganho do arraste e o controle de recuo antes de entrar na partida.",
  },
];

const TIPS = [
  "Sensibilidade horizontal alta = mira rápida, mas com mais erro. Comece entre 50% e 70%.",
  "A vertical costuma ser 5% a 10% menor que a horizontal — evita mirar “para cima” sem querer.",
  "Curva acima de 1.0 dá precisão nos ajustes pequenos; curva 1.0 é o mais natural.",
  "Zona morta entre 2 e 6 px e offset de 2 a 4 px eliminam o tremor do dedo sem tirar a resposta.",
  "Suavização entre 15% e 30% deixa a mira estável sem parecer “lagada”.",
  "Para AWM, multiplicadores entre 20% e 35% da geral deixam o quick-scope bem mais fino.",
  "Troque o perfil por arma: um perfil “Mira Alta” para AK/M4 e outro “Sniper” para AWM.",
];

export default function GuidePanel() {
  return (
    <div className="space-y-4">
      <Card title="Como usar no Free Fire" icon="📖" desc="Passo a passo para levar seus ajustes para o jogo.">
        <ol className="space-y-3">
          {STEPS.map((s) => (
            <li key={s.n} className="flex gap-3">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-xl bg-lime-400/15 text-xs font-bold text-lime-300">
                {s.n}
              </span>
              <div>
                <div className="text-[13px] font-semibold text-slate-100">{s.t}</div>
                <div className="mt-0.5 text-[11px] leading-relaxed text-slate-400">{s.d}</div>
              </div>
            </li>
          ))}
        </ol>
      </Card>

      <Card title="Dicas de touch" icon="💡" desc="Ajustes que mais impactam na mira.">
        <ul className="space-y-2">
          {TIPS.map((t) => (
            <li
              key={t}
              className="flex gap-2 rounded-2xl border border-white/10 bg-white/[0.03] px-3 py-2 text-[12px] leading-relaxed text-slate-300"
            >
              <span className="text-lime-300">▸</span>
              {t}
            </li>
          ))}
        </ul>
      </Card>

      <Card title="Aviso importante" icon="⚠️" desc="Transparência sobre o que o app faz e o que não faz.">
        <div className="space-y-2 text-[12px] leading-relaxed text-slate-300">
          <p>
            Este app é um <strong className="text-slate-100">companheiro de ajuste e treino</strong>. Ele
            calcula, salva e simula o comportamento do touch para você encontrar a sensibilidade ideal —
            o Free Fire não permite que apps de terceiros alterem o toque por dentro do jogo (o Android
            bloqueia isso por segurança).
          </p>
          <p>
            Por isso o fluxo recomendado é: <strong className="text-lime-300">ajuste aqui → copie os
            números → cole nas configurações de controle do jogo</strong>. O Treino existe para você
            calibrar o toque antes da partida.
          </p>
          <p className="text-slate-500">
            Em dispositivos rootados existem Overlay/hookers que injetam botões sobre o jogo, mas isso
            viola os termos de uso do Free Fire e pode banar a conta. Este app não faz isso.
          </p>
        </div>
      </Card>
    </div>
  );
}
