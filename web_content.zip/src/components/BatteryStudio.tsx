import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import type { Battery, Language } from '../types';
import type { OperatingMode } from './ShuttleStudio';

function webglAvailable(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('webgl2') || canvas.getContext('webgl');
    return !!ctx;
  } catch {
    return false;
  }
}

/** Returns a display string only for verified telemetry, otherwise null (shown as UNKNOWN). */
export function readoutValue(verified: boolean, value: number | null, unit: string): string | null {
  if (!verified || value === null) return null;
  return `${value}${unit}`;
}

interface BatteryStudioProps {
  battery: Battery;
  language: Language;
  mode: OperatingMode;
  animated: boolean;
}

export default function BatteryStudio({ battery, language, mode, animated }: BatteryStudioProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState(false);
  const [removed, setRemoved] = useState(false);
  const stateRef = useRef({ battery, mode, animated, removed });
  stateRef.current = { battery, mode, animated, removed };

  const verified = battery.connectionMode === 'REAL';
  const motionOn = animated && mode === 'SIMULATION' && (battery.status === 'Charging' || battery.status === 'Discharging');
  const ar = language === 'ar';

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    if (!webglAvailable()) {
      setFailed(true);
      return;
    }
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      setFailed(true);
      return;
    }

    const W = mount.clientWidth || 640;
    const H = 360;
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, W / H, 0.1, 100);
    camera.position.set(4.6, 3.4, 5.2);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 3;
    controls.maxDistance = 14;
    controls.target.set(0, 0.6, 0);

    scene.add(new THREE.HemisphereLight(0xdfe9f2, 0x1a2430, 1.0));
    const key = new THREE.DirectionalLight(0xffffff, 1.4);
    key.position.set(5, 8, 4);
    scene.add(key);
    const grid = new THREE.GridHelper(10, 10, 0x3a4a5a, 0x222f3c);
    grid.position.y = -0.02;
    scene.add(grid);

    const pack = new THREE.Group();
    scene.add(pack);

    const shellMat = new THREE.MeshStandardMaterial({ color: 0x5b6a78, metalness: 0.5, roughness: 0.45, transparent: true, opacity: 0.32 });
    const shell = new THREE.Mesh(new THREE.BoxGeometry(3.4, 1.1, 2.0), shellMat);
    shell.position.y = 0.75;
    pack.add(shell);
    const lid = new THREE.Mesh(
      new THREE.BoxGeometry(3.4, 0.08, 2.0),
      new THREE.MeshStandardMaterial({ color: 0x39485a, metalness: 0.5, roughness: 0.5 }),
    );
    lid.position.y = 1.34;
    pack.add(lid);

    const cells: THREE.Mesh[] = [];
    const cellGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.85, 18);
    for (let row = 0; row < 3; row++) {
      for (let col = 0; col < 4; col++) {
        const cell = new THREE.Mesh(
          cellGeo,
          new THREE.MeshStandardMaterial({ color: 0x67c4cf, metalness: 0.3, roughness: 0.4, emissive: 0x1c4a52, emissiveIntensity: 0.25 }),
        );
        cell.position.set(-1.2 + col * 0.8, 0.72, -0.66 + row * 0.66);
        pack.add(cell);
        cells.push(cell);
      }
    }

    // BMS board
    const bms = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 0.08, 0.7),
      new THREE.MeshStandardMaterial({ color: 0x2e7d5b, metalness: 0.2, roughness: 0.6 }),
    );
    bms.position.set(0.9, 1.28, 0.4);
    pack.add(bms);

    // Power connectors
    const connMat = new THREE.MeshStandardMaterial({ color: 0xd28b4b, metalness: 0.6, roughness: 0.35 });
    const connA = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.3, 0.3), connMat);
    connA.position.set(-1.85, 0.75, 0.5);
    const connB = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.3, 0.3), connMat);
    connB.position.set(-1.85, 0.75, -0.5);
    pack.add(connA, connB);

    // Temperature sensor locations
    const sensorMat = new THREE.MeshStandardMaterial({ color: 0x76d4ff, emissive: 0x2a7fa8, emissiveIntensity: 0.9 });
    const sensorGeo = new THREE.SphereGeometry(0.08, 10, 10);
    const sensorAnchors: Array<[number, number, number]> = [[-1.5, 1.32, -0.85], [1.5, 1.32, -0.85], [-1.5, 1.32, 0.85], [1.5, 1.32, 0.85]];
    sensorAnchors.forEach(([x, y, z]) => {
      const s = new THREE.Mesh(sensorGeo, sensorMat);
      s.position.set(x, y, z);
      pack.add(s);
    });

    // Tray (installation / removal illustration)
    const tray = new THREE.Mesh(
      new THREE.BoxGeometry(3.8, 0.1, 2.4),
      new THREE.MeshStandardMaterial({ color: 0x2a3542, metalness: 0.5, roughness: 0.5 }),
    );
    tray.position.y = 0.12;
    pack.add(tray);

    const onResize = () => {
      const w = mount.clientWidth || 640;
      camera.aspect = w / H;
      camera.updateProjectionMatrix();
      renderer.setSize(w, H);
    };
    const resizeObserver = new ResizeObserver(onResize);
    resizeObserver.observe(mount);
    onResize();

    let raf = 0;
    let visible = true;
    const onVisibility = () => {
      visible = !document.hidden;
    };
    document.addEventListener('visibilitychange', onVisibility);
    const clock = new THREE.Clock();
    let slideT = 0;

    const paint = () => {
      const s = stateRef.current;
      const isVerified = s.battery.connectionMode === 'REAL';
      const soc = s.battery.soc;
      const lit = isVerified && soc !== null ? Math.round((soc / 100) * cells.length) : 0;
      cells.forEach((cell, i) => {
        const mat = cell.material as THREE.MeshStandardMaterial;
        if (i < lit) {
          mat.color.setHex(0x64c99b);
          mat.emissive.setHex(0x1d5c40);
          mat.emissiveIntensity = 0.5;
        } else if (!isVerified) {
          mat.color.setHex(0x55636f);
          mat.emissive.setHex(0x000000);
          mat.emissiveIntensity = 0;
        } else {
          mat.color.setHex(0x2c3a48);
          mat.emissive.setHex(0x000000);
          mat.emissiveIntensity = 0;
        }
      });
      const flow = s.animated && s.mode === 'SIMULATION' && (s.battery.status === 'Charging' || s.battery.status === 'Discharging');
      connMat.emissive.setHex(flow ? 0xd28b4b : 0x000000);
      connMat.emissiveIntensity = flow ? 0.8 + Math.sin(clock.elapsedTime * 5) * 0.3 : 0;
    };

    const loop = () => {
      raf = requestAnimationFrame(loop);
      if (!visible) return;
      const s = stateRef.current;
      const dt = Math.min(clock.getDelta(), 0.05);
      const target = s.removed ? 1 : 0;
      slideT += Math.sign(target - slideT) * Math.min(Math.abs(target - slideT), dt * 1.8);
      shell.position.x = slideT * 0.0;
      lid.position.y = 1.34 + slideT * 0.9;
      pack.position.z = slideT * 1.6;
      cells.forEach((c) => {
        c.position.y = 0.72 + slideT * 0.45;
      });
      paint();
      controls.update();
      renderer.render(scene, camera);
    };
    loop();

    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener('visibilitychange', onVisibility);
      resizeObserver.disconnect();
      controls.dispose();
      scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.isMesh) {
          mesh.geometry.dispose();
          const mat = mesh.material as THREE.Material;
          mat.dispose();
        }
      });
      renderer.dispose();
      if (renderer.domElement.parentElement === mount) mount.removeChild(renderer.domElement);
    };
  }, []);

  const readout = (label: string, value: string | null, reported?: string) => (
    <div className="detail-item">
      <span>{label}</span>
      <strong>{value === null ? (ar ? 'غير معروف' : 'UNKNOWN') : value}</strong>
      {value === null && reported && <small className="muted-text">{reported}</small>}
    </div>
  );

  if (failed) {
    return (
      <div className="studio-fallback" role="img" aria-label={ar ? 'عرض البطارية غير متاح' : 'Battery 3D unavailable'}>
        <div className="studio-caption">{battery.id} · {ar ? 'عرض البطارية' : 'BATTERY ASSEMBLY'}</div>
        <p className="muted-text">{ar ? 'العرض ثلاثي الأبعاد غير متاح على هذا الجهاز.' : '3D viewing is not available on this device.'}</p>
      </div>
    );
  }

  return (
    <div className="studio">
      <div ref={mountRef} className="studio-canvas studio-canvas-battery" tabIndex={0} role="application" aria-label={`${battery.id} battery assembly. Drag to rotate, scroll to zoom.`} />
      <div className="studio-overlay-top">
        <span className="studio-caption">{battery.id} · {ar ? 'مجموعة البطارية' : 'BATTERY ASSEMBLY'}</span>
        {motionOn ? (
          <span className="studio-badge badge-sim">SIMULATION · {battery.status.toUpperCase()}</span>
        ) : verified ? (
          <span className="studio-badge badge-live">VERIFIED TELEMETRY</span>
        ) : (
          <span className="studio-badge badge-off">{ar ? 'غير مؤكد' : 'UNVERIFIED'}</span>
        )}
      </div>
      <div className="studio-overlay-bottom">
        <div className="studio-tools" role="group" aria-label={ar ? 'عرض التركيب' : 'Installation view'}>
          <button className={!removed ? 'tool-active' : ''} onClick={() => setRemoved(false)} aria-pressed={!removed}>
            {ar ? 'مركبة' : 'Installed'}
          </button>
          <button className={removed ? 'tool-active' : ''} onClick={() => setRemoved(true)} aria-pressed={removed}>
            {ar ? 'خارجة للصيانة' : 'Removed'}
          </button>
        </div>
        <span className="studio-hint">{ar ? 'اسحب للتدوير · عجلة الفأرة للتقريب' : 'Drag to rotate · scroll to zoom'}</span>
      </div>
      <div className="battery-stat-grid studio-readouts">
        {readout(ar ? 'مستوى الشحن' : 'State of charge', readoutValue(verified, battery.soc, '%'), battery.soc !== null && !verified ? (ar ? `قراءة مبلغ عنها ${battery.soc}% — غير مؤكدة` : `Reported ${battery.soc}% — not verified telemetry`) : undefined)}
        {readout(ar ? 'حالة البطارية' : 'State of health', readoutValue(verified, battery.soh, '%'))}
        {readout(ar ? 'الحرارة' : 'Temperature', readoutValue(verified, battery.temperature, '°C'))}
        {readout(ar ? 'الجهد' : 'Voltage', readoutValue(verified, battery.voltage, ' V'))}
      </div>
    </div>
  );
}
