import React, { useState } from 'react';
import { ArrowLeft, Search, Flame } from 'lucide-react';
import { Asset, AssetType } from '../types/trading';
import { OTC_ASSETS, MARKET_ASSETS } from '../data/assets';
import { soundManager } from '../utils/soundEffects';

interface AssetSelectViewProps {
  type: AssetType;
  onBack: () => void;
  onSelectAsset: (asset: Asset) => void;
}

export const AssetSelectView: React.FC<AssetSelectViewProps> = ({
  type,
  onBack,
  onSelectAsset,
}) => {
  const [search, setSearch] = useState('');
  const assetList = type === 'OTC' ? OTC_ASSETS : MARKET_ASSETS;

  const filteredAssets = assetList.filter(
    (a) =>
      a.symbol.toLowerCase().includes(search.toLowerCase()) ||
      a.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="w-full max-w-lg mx-auto flex flex-col items-center px-3 py-3">
      {/* Top Bar with Back */}
      <div className="w-full flex items-center justify-between mb-3">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-zinc-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <span className="text-[11px] font-mono text-zinc-400 font-semibold">
          {type === 'OTC' ? '30 OTC Assets' : '24 Market Assets'}
        </span>
      </div>

      {/* Title */}
      <h2 className="text-base font-black text-slate-100 tracking-wider uppercase mb-3 text-center">
        SELECT ASSET
      </h2>

      {/* Search Input */}
      <div className="w-full relative mb-3">
        <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={`Search ${type} pairs (e.g. EUR, USD, INR, BDT)...`}
          className="w-full bg-[#180710] border border-[#3b1223] focus:border-red-500 text-xs text-white rounded-xl pl-9 pr-3 py-2.5 outline-none placeholder:text-zinc-600 font-mono"
        />
      </div>

      {/* 2-Column Asset Grid (Screenshots 4 & 5) */}
      <div className="w-full grid grid-cols-2 gap-2 max-h-[500px] overflow-y-auto pr-0.5 custom-scrollbar">
        {filteredAssets.map((asset) => (
          <button
            key={asset.id}
            onClick={() => {
              soundManager.playPip();
              onSelectAsset(asset);
            }}
            className="w-full py-3 px-2 bg-[#1a0711] hover:bg-[#280c1b] border border-[#381121] hover:border-red-500/70 rounded-xl flex items-center justify-between text-left transition-all duration-150 active:scale-95 group shadow-sm"
          >
            <div className="flex flex-col truncate pr-1">
              <div className="flex items-center gap-1">
                <span className="text-xs font-extrabold text-slate-100 font-mono tracking-tight group-hover:text-red-400 transition-colors truncate">
                  {asset.symbol}
                </span>
                {asset.isHot && (
                  <Flame className="w-3 h-3 text-red-500 fill-red-500 shrink-0" />
                )}
              </div>
              <span className="text-[10px] text-zinc-500 font-mono mt-0.5">
                {asset.currentPrice.toFixed(asset.decimals)}
              </span>
            </div>

            {/* Payout Tag */}
            <span className="text-[10px] font-bold font-mono px-1.5 py-0.5 bg-emerald-950/70 text-emerald-400 border border-emerald-800/40 rounded shrink-0">
              {asset.payout}%
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};
