import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wallet, 
  Link2, 
  ExternalLink, 
  Copy, 
  Check, 
  Power, 
  ArrowUpRight, 
  Layers, 
  ShieldCheck, 
  Sparkles, 
  RefreshCw, 
  Send, 
  FileSignature, 
  Globe, 
  X,
  ChevronDown,
  QrCode
} from 'lucide-react';
import { 
  walletConnectService, 
  ConnectedWeb3Wallet, 
  Web3ChainId, 
  Web3WalletProvider, 
  SUPPORTED_CHAINS 
} from '../lib/walletConnectService';

interface WalletConnectPanelProps {
  onShowToast?: (msg: string) => void;
}

export const WalletConnectPanel: React.FC<WalletConnectPanelProps> = ({ onShowToast }) => {
  const [wallet, setWallet] = useState<ConnectedWeb3Wallet | null>(() => walletConnectService.getWallet());
  const [showConnectModal, setShowConnectModal] = useState<boolean>(false);
  const [showSendModal, setShowSendModal] = useState<boolean>(false);
  const [showSignModal, setShowSignModal] = useState<boolean>(false);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [selectedChain, setSelectedChain] = useState<Web3ChainId>('ethereum');
  const [copiedAddress, setCopiedAddress] = useState<boolean>(false);
  
  // Send Transaction Inputs
  const [sendToAddress, setSendToAddress] = useState<string>('');
  const [sendAmount, setSendAmount] = useState<string>('0.1');
  const [isSending, setIsSending] = useState<boolean>(false);
  const [sendSuccessHash, setSendSuccessHash] = useState<string | null>(null);

  // Sign Message Inputs
  const [messageToSign, setMessageToSign] = useState<string>('JUHNKRIX MUSIKA PROPHETIC TREASURY AUTHORIZATION • TIMESTAMP: ' + new Date().toISOString());
  const [isSigning, setIsSigning] = useState<boolean>(false);
  const [signatureResult, setSignatureResult] = useState<string | null>(null);

  useEffect(() => {
    const unsub = walletConnectService.subscribe(w => setWallet(w));
    return () => unsub();
  }, []);

  const handleCopyAddress = (addr: string) => {
    navigator.clipboard.writeText(addr);
    setCopiedAddress(true);
    onShowToast?.('✓ Copied Web3 address to clipboard!');
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  const handleConnectProvider = async (provider: Web3WalletProvider) => {
    setIsConnecting(true);
    try {
      const res = await walletConnectService.connect(provider, selectedChain);
      setShowConnectModal(false);
      onShowToast?.(`✓ Connected ${provider.toUpperCase()} (${res.chain.name})`);
    } catch (err: any) {
      onShowToast?.(`❌ Connection failed: ${err.message}`);
    } finally {
      setIsConnecting(false);
    }
  };

  const handleSwitchChain = async (chainId: Web3ChainId) => {
    setSelectedChain(chainId);
    if (wallet?.isConnected) {
      await walletConnectService.switchChain(chainId);
      onShowToast?.(`✓ Switched network to ${SUPPORTED_CHAINS[chainId].name}`);
    }
  };

  const handleDisconnect = () => {
    walletConnectService.disconnect();
    onShowToast?.('✓ Web3 wallet disconnected.');
  };

  const handleExecuteSend = async () => {
    if (!sendToAddress.trim() || Number(sendAmount) <= 0) {
      onShowToast?.('⚠️ Please enter a valid recipient address and amount.');
      return;
    }
    setIsSending(true);
    try {
      const res = await walletConnectService.sendTransaction(sendToAddress.trim(), Number(sendAmount));
      setSendSuccessHash(res.txHash);
      onShowToast?.(`✓ Broadcasted ${sendAmount} ${wallet?.chain.symbol} on ${wallet?.chain.name}!`);
      setTimeout(() => {
        setShowSendModal(false);
        setSendSuccessHash(null);
        setSendToAddress('');
      }, 3000);
    } catch (err: any) {
      onShowToast?.(`❌ Transaction error: ${err.message}`);
    } finally {
      setIsSending(false);
    }
  };

  const handleExecuteSign = async () => {
    setIsSigning(true);
    try {
      const res = await walletConnectService.signMessage(messageToSign);
      setSignatureResult(res.signature);
      onShowToast?.('✓ EIP-712 Prophetic Treasury Authorization Signed!');
    } catch (err: any) {
      onShowToast?.(`❌ Signing error: ${err.message}`);
    } finally {
      setIsSigning(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="bg-slate-950 border-2 border-indigo-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden space-y-6"
    >
      <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-xs font-black uppercase tracking-wider">
            <Link2 className="w-3.5 h-3.5 text-indigo-400" />
            <span>CROSS-CHAIN ASSET MANAGEMENT • WALLETCONNECT V2</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-100 flex items-center space-x-2">
            <span>External Web3 Wallets & Native Liquidity</span>
          </h3>
          <p className="text-xs text-slate-400 max-w-xl">
            Link external Ethereum, Base, Solana, and Polygon wallets for instant cross-chain asset swaps and sovereign on-chain settlements.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {wallet?.isConnected ? (
            <button
              onClick={handleDisconnect}
              className="px-4 py-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center space-x-1.5 transition-all"
            >
              <Power className="w-3.5 h-3.5" />
              <span>Disconnect</span>
            </button>
          ) : (
            <button
              onClick={() => setShowConnectModal(true)}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600 hover:from-indigo-400 hover:to-purple-400 text-white font-extrabold text-xs flex items-center space-x-2 shadow-xl shadow-indigo-500/30 transition-all hover:scale-105"
            >
              <Wallet className="w-4 h-4" />
              <span>CONNECT WALLET</span>
            </button>
          )}
        </div>
      </div>

      {/* Connected State / Disconnected State Content */}
      {wallet?.isConnected ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative z-10">
          {/* Card 1: Connected Wallet & Chain */}
          <div className="bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-5 space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400 font-bold uppercase tracking-wider">Connected Provider</span>
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 font-mono text-[10px] font-bold uppercase">
                {wallet.provider}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="font-mono text-sm font-black text-amber-200">
                {wallet.shortAddress}
              </div>
              <button
                onClick={() => handleCopyAddress(wallet.address)}
                className="text-slate-400 hover:text-amber-300 p-1.5 rounded-lg bg-slate-800"
              >
                {copiedAddress ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            {/* Network Selector Dropdown */}
            <div className="pt-2 border-t border-slate-800">
              <span className="text-[10px] text-slate-400 block mb-1">Active Network:</span>
              <select
                value={wallet.chain.id}
                onChange={(e) => handleSwitchChain(e.target.value as Web3ChainId)}
                className="w-full bg-slate-950 border border-slate-700 text-xs text-slate-200 rounded-xl px-3 py-2 focus:border-indigo-400 focus:outline-none font-bold"
              >
                {Object.values(SUPPORTED_CHAINS).map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.symbol})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Card 2: Native Balance */}
          <div className="bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-5 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400 font-bold uppercase tracking-wider">External Asset Balance</span>
              <span className="text-[10px] text-emerald-400 font-bold">Synced Live</span>
            </div>

            <div className="text-2xl sm:text-3xl font-black text-slate-100">
              {wallet.balanceNative.toFixed(4)} <span className="text-indigo-400 text-lg">{wallet.chain.symbol}</span>
            </div>

            <div className="text-xs text-slate-400">
              ≈ <span className="font-bold text-amber-300">${wallet.balanceUsd.toLocaleString('en-US', { minimumFractionDigits: 2 })} USD</span>
            </div>

            <div className="pt-2 text-[10px] text-slate-500 flex items-center space-x-1">
              <Globe className="w-3 h-3 text-slate-400" />
              <span>RPC: {wallet.chain.rpcUrl}</span>
            </div>
          </div>

          {/* Card 3: Quick Native Web3 Actions */}
          <div className="bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-5 flex flex-col justify-between space-y-3">
            <div>
              <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-2">Web3 Operations</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setShowSendModal(true)}
                  className="py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 transition-all"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
                <button
                  onClick={() => setShowSignModal(true)}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-indigo-500/30 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all"
                >
                  <FileSignature className="w-3.5 h-3.5" />
                  <span>Sign</span>
                </button>
              </div>
            </div>

            <a
              href={`${wallet.chain.explorerUrl}/address/${wallet.address}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center justify-center space-x-1 pt-2 border-t border-slate-800"
            >
              <span>View On Explorer</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      ) : (
        /* Disconnected Overview State */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 relative z-10">
          {[
            { name: 'MetaMask', symbol: 'ETH', color: 'from-amber-500 to-orange-500', desc: 'Ethereum & Base L2' },
            { name: 'Phantom', symbol: 'SOL', color: 'from-purple-500 to-indigo-500', desc: 'Solana High-Speed Layer' },
            { name: 'Coinbase Wallet', symbol: 'MULTI', color: 'from-blue-500 to-cyan-500', desc: 'Base & Smart Accounts' },
            { name: 'WalletConnect v2', symbol: 'ANY', color: 'from-teal-500 to-emerald-500', desc: '300+ Mobile Wallets' }
          ].map((item, idx) => (
            <div 
              key={idx}
              onClick={() => setShowConnectModal(true)}
              className="bg-slate-900/60 hover:bg-slate-900 border border-slate-800 hover:border-indigo-500/40 rounded-2xl p-4 cursor-pointer transition-all hover:scale-102 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-extrabold text-sm text-slate-200">{item.name}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-amber-300">
                    {item.symbol}
                  </span>
                </div>
                <p className="text-xs text-slate-400">{item.desc}</p>
              </div>
              <span className="text-[11px] font-bold text-indigo-400 mt-3 flex items-center space-x-1">
                <span>Connect Now</span>
                <ArrowUpRight className="w-3 h-3" />
              </span>
            </div>
          ))}
        </div>
      )}

      {/* CONNECT WALLET MODAL */}
      <AnimatePresence>
        {showConnectModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-900 border-2 border-indigo-500/50 rounded-3xl max-w-md w-full p-6 space-y-6 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2">
                  <Wallet className="w-5 h-5 text-indigo-400" />
                  <h4 className="text-lg font-black text-slate-100">Connect Web3 Wallet</h4>
                </div>
                <button
                  onClick={() => setShowConnectModal(false)}
                  className="text-slate-400 hover:text-slate-200 p-1.5 rounded-xl bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Chain Selector */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300">Choose Primary Network:</label>
                <div className="grid grid-cols-2 gap-2">
                  {(Object.keys(SUPPORTED_CHAINS) as Web3ChainId[]).map((cid) => (
                    <button
                      key={cid}
                      onClick={() => setSelectedChain(cid)}
                      className={`p-2.5 rounded-xl text-xs font-bold text-left transition-all ${
                        selectedChain === cid
                          ? 'bg-indigo-600 text-white shadow-md'
                          : 'bg-slate-950 text-slate-300 border border-slate-800 hover:border-indigo-500/30'
                      }`}
                    >
                      <div>{SUPPORTED_CHAINS[cid].name}</div>
                      <div className="text-[10px] text-indigo-200 font-mono">{SUPPORTED_CHAINS[cid].symbol}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Provider List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300">Choose Wallet Provider:</label>
                <div className="space-y-2">
                  {[
                    { id: 'metamask', name: 'MetaMask', icon: '🦊' },
                    { id: 'walletconnect', name: 'WalletConnect v2', icon: '🔗' },
                    { id: 'coinbase', name: 'Coinbase Wallet', icon: '🔵' },
                    { id: 'phantom', name: 'Phantom (Solana)', icon: '👻' },
                    { id: 'rainbow', name: 'Rainbow Wallet', icon: '🌈' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      disabled={isConnecting}
                      onClick={() => handleConnectProvider(p.id as Web3WalletProvider)}
                      className="w-full p-3 rounded-2xl bg-slate-950 hover:bg-indigo-950/40 border border-slate-800 hover:border-indigo-500/50 flex items-center justify-between transition-all"
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-xl">{p.icon}</span>
                        <span className="text-xs font-extrabold text-slate-100">{p.name}</span>
                      </div>
                      <ChevronDown className="w-4 h-4 text-slate-500 -rotate-90" />
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SEND TRANSACTION MODAL */}
      <AnimatePresence>
        {showSendModal && wallet && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-900 border-2 border-indigo-500/50 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h4 className="text-lg font-black text-slate-100 flex items-center space-x-2">
                  <Send className="w-4 h-4 text-indigo-400" />
                  <span>Send {wallet.chain.symbol}</span>
                </h4>
                <button onClick={() => setShowSendModal(false)} className="text-slate-400 hover:text-slate-200">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Recipient Web3 Address:</label>
                  <input
                    type="text"
                    value={sendToAddress}
                    onChange={(e) => setSendToAddress(e.target.value)}
                    placeholder="0x... or Solana public key"
                    className="w-full bg-slate-950 border border-slate-700 text-xs text-slate-100 rounded-xl px-3 py-2.5 font-mono focus:border-indigo-400 focus:outline-none"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-bold text-slate-300">Amount ({wallet.chain.symbol}):</span>
                    <span className="text-slate-400">Available: {wallet.balanceNative.toFixed(4)}</span>
                  </div>
                  <input
                    type="number"
                    step="0.01"
                    value={sendAmount}
                    onChange={(e) => setSendAmount(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 text-xs text-slate-100 rounded-xl px-3 py-2.5 font-mono focus:border-indigo-400 focus:outline-none"
                  />
                </div>

                {sendSuccessHash && (
                  <div className="p-3 bg-emerald-500/20 border border-emerald-400/40 rounded-xl text-xs text-emerald-300 font-mono break-all">
                    ✓ Tx Hash: {sendSuccessHash}
                  </div>
                )}

                <button
                  disabled={isSending}
                  onClick={handleExecuteSend}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-400 hover:to-purple-400 text-white font-black text-xs flex items-center justify-center space-x-2 shadow-lg shadow-indigo-500/30 transition-all"
                >
                  {isSending ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  <span>DISPATCH ON-CHAIN</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SIGN MESSAGE MODAL */}
      <AnimatePresence>
        {showSignModal && wallet && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-900 border-2 border-indigo-500/50 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h4 className="text-lg font-black text-slate-100 flex items-center space-x-2">
                  <FileSignature className="w-4 h-4 text-indigo-400" />
                  <span>EIP-712 Message Authorization</span>
                </h4>
                <button onClick={() => setShowSignModal(false)} className="text-slate-400 hover:text-slate-200">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Authorization Payload:</label>
                  <textarea
                    rows={3}
                    value={messageToSign}
                    onChange={(e) => setMessageToSign(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 text-xs text-slate-100 rounded-xl p-3 font-mono focus:border-indigo-400 focus:outline-none"
                  />
                </div>

                {signatureResult && (
                  <div className="p-3 bg-indigo-500/20 border border-indigo-400/40 rounded-xl text-xs text-indigo-300 font-mono break-all">
                    ✓ Signature: {signatureResult}
                  </div>
                )}

                <button
                  disabled={isSigning}
                  onClick={handleExecuteSign}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-400 hover:to-purple-400 text-white font-black text-xs flex items-center justify-center space-x-2 shadow-lg shadow-indigo-500/30 transition-all"
                >
                  {isSigning ? <RefreshCw className="w-4 h-4 animate-spin" /> : <FileSignature className="w-4 h-4" />}
                  <span>SIGN WITH PRIVATE KEY</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
