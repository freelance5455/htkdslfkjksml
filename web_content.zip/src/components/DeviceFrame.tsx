import React, { useState } from 'react';
import { Smartphone, Monitor, ShieldCheck, Sparkles } from 'lucide-react';
import { StatusBar } from './StatusBar';

interface DeviceFrameProps {
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ children }) => {
  const [isFrameEnabled, setIsFrameEnabled] = useState(true);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-start p-0 sm:p-4 md:p-6 font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Desktop Top Control Bar */}
      <header className="w-full max-w-md md:max-w-xl lg:max-w-2xl mb-3 hidden sm:flex items-center justify-between px-4 py-2 bg-slate-800/80 backdrop-blur border border-slate-700/60 rounded-2xl text-xs">
        <div className="flex items-center space-x-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-bold text-white tracking-wide">MEDIGUIDE AI</span>
          <span className="text-slate-400">| Android MD3 UI</span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsFrameEnabled(!isFrameEnabled)}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-xl font-medium transition-all ${
              isFrameEnabled
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            {isFrameEnabled ? <Smartphone className="w-3.5 h-3.5" /> : <Monitor className="w-3.5 h-3.5" />}
            {isFrameEnabled ? 'Phone View' : 'Expanded View'}
          </button>
        </div>
      </header>

      {/* Main Container - Android Smartphone Mockup on desktop */}
      <div
        className={`w-full transition-all duration-300 ${
          isFrameEnabled
            ? 'max-w-md sm:rounded-[40px] sm:border-[8px] sm:border-slate-800 sm:shadow-2xl sm:shadow-blue-900/30 overflow-hidden'
            : 'max-w-2xl sm:rounded-3xl border border-slate-800 overflow-hidden'
        } bg-slate-50 text-slate-800 min-h-screen sm:min-h-[840px] flex flex-col relative`}
      >
        {/* Top Camera Notch / Punchhole for Android styling */}
        {isFrameEnabled && (
          <div className="hidden sm:block absolute top-0 left-1/2 -translate-x-1/2 w-28 h-5 bg-slate-900 rounded-b-2xl z-50 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-blue-900/50" />
            </div>
          </div>
        )}

        {/* Android Status Bar */}
        <StatusBar />

        {/* App Content Body */}
        <div className="flex-1 flex flex-col relative overflow-y-auto pb-20">
          {children}
        </div>
      </div>
    </div>
  );
};
