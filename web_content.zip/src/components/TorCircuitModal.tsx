import React, { useState } from 'react';
import { Globe, RefreshCw, X, ShieldCheck, ArrowRight, Lock } from 'lucide-react';

interface TorCircuitModalProps {
  isOpen: boolean;
  onClose: () => void;
  destinationUrl: string;
}

export const TorCircuitModal: React.FC<TorCircuitModalProps> = ({
  isOpen,
  onClose,
  destinationUrl,
}) => {
  const [isRenewing, setIsRenewing] = useState(false);
  const [circuitSeed, setCircuitSeed] = useState(1);

  if (!isOpen) return null;

  const relays = circuitSeed % 2 === 1 ? [
    { name: 'Guard Relay', location: 'Reykjavik, Iceland 🇮🇸', ip: '185.220.101.5', flag: '🇮🇸' },
    { name: 'Middle Relay', location: 'Zurich, Switzerland 🇨🇭', ip: '194.26.29.112', flag: '🇨🇭' },
    { name: 'Exit Relay', location: 'Amsterdam, Netherlands 🇳🇱', ip: '185.107.56.88', flag: '🇳🇱' },
  ] : [
    { name: 'Guard Relay', location: 'Oslo, Norway 🇳🇴', ip: '193.187.91.24', flag: '🇳🇴' },
    { name: 'Middle Relay', location: 'Stockholm, Sweden 🇸🇪', ip: '185.165.170.9', flag: '🇸🇪' },
    { name: 'Exit Relay', location: 'Frankfurt, Germany 🇩🇪', ip: '178.17.174.19', flag: '🇩🇪' },
  ];

  const handleRenew = () => {
    setIsRenewing(true);
    setTimeout(() => {
      setCircuitSeed(s => s + 1);
      setIsRenewing(false);
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md px-4 select-none animate-fade-in">
      <div className="w-full max-w-sm bg-slate-900 border border-purple-800/60 rounded-3xl shadow-2xl overflow-hidden p-5 animate-scale-in">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-950 text-purple-400 border border-purple-800/60">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">Tor Onion Circuit</h3>
              <p className="text-[11px] text-purple-300 font-mono">3-Hop Encrypted Path</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Relays Flow */}
        <div className="py-4 space-y-3">
          {/* Start: Device */}
          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-sm" />
              <span className="font-semibold text-slate-200">Aegis Android (This App)</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">10.0.2.16 (Local)</span>
          </div>

          {/* Relays */}
          {relays.map((relay, idx) => (
            <div key={relay.name} className="relative pl-6">
              {/* Connector line */}
              <div className="absolute left-3 -top-3 bottom-0 w-0.5 bg-purple-700/50" />
              <div className="p-2.5 rounded-xl bg-purple-950/40 border border-purple-800/40 flex items-center justify-between text-xs">
                <div>
                  <div className="flex items-center gap-1.5 font-semibold text-purple-200">
                    <Lock className="w-3 h-3 text-purple-400" />
                    <span>{relay.name}</span>
                  </div>
                  <p className="text-[10px] text-slate-400">{relay.location}</p>
                </div>
                <span className="text-[10px] font-mono text-purple-300">{relay.ip}</span>
              </div>
            </div>
          ))}

          {/* End Destination */}
          <div className="relative pl-6">
            <div className="absolute left-3 -top-3 bottom-0 w-0.5 bg-emerald-700/50" />
            <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-semibold text-emerald-200 truncate max-w-[170px]">
                  {destinationUrl || 'Destination Server'}
                </span>
              </div>
              <span className="text-[10px] text-emerald-300 font-semibold">Protected</span>
            </div>
          </div>
        </div>

        {/* Action button */}
        <div className="pt-2">
          <button
            onClick={handleRenew}
            disabled={isRenewing}
            className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRenewing ? 'animate-spin' : ''}`} />
            <span>{isRenewing ? 'Building New Circuit...' : 'New Circuit for this Site'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
