import { getFormulaById } from "../data";
import { useAppState } from "../state/AppState";
import FormulaCard from "./FormulaCard";

function EmptyState({ icon, title, desc }: { icon: string; title: string; desc: string }) {
  return (
    <div className="mx-auto mt-16 max-w-md text-center">
      <div className="text-4xl">{icon}</div>
      <h2 className="mt-3 text-lg font-semibold text-slate-700 dark:text-slate-200">{title}</h2>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{desc}</p>
    </div>
  );
}

export function FavoritesView() {
  const { favorites } = useAppState();
  const formulas = favorites.map((id) => getFormulaById(id)).filter(Boolean) as ReturnType<typeof getFormulaById>[];

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">My Favorites</h1>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Formulas you've bookmarked for quick revision.</p>
      {formulas.length === 0 ? (
        <EmptyState icon="⭐" title="No favorites yet" desc="Tap the star on any formula card or page to save it here." />
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {formulas.map((f) => f && <FormulaCard key={f.id} formula={f} />)}
        </div>
      )}
    </div>
  );
}

export function RecentView() {
  const { recent } = useAppState();
  const formulas = recent.map((id) => getFormulaById(id)).filter(Boolean) as ReturnType<typeof getFormulaById>[];

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Recently Viewed</h1>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Formulas you've opened during this session.</p>
      {formulas.length === 0 ? (
        <EmptyState icon="🕒" title="Nothing viewed yet" desc="Formulas you open will show up here for this session." />
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {formulas.map((f) => f && <FormulaCard key={f.id} formula={f} />)}
        </div>
      )}
    </div>
  );
}
