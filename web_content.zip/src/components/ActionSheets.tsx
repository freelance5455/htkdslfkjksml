import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  FileText,
  IndianRupee,
  ListTodo,
  Receipt,
  UserPlus,
  X,
} from 'lucide-react';
import {
  Client,
  ExpenseCategory,
  ExpenseItem,
  Payment,
  PaymentMode,
  ProjectType,
  TaskItem,
  TaskPriority,
  TaskStage,
} from '../types';

export type ActiveModalType =
  | null
  | 'addMenu'
  | 'client'
  | 'payment'
  | 'task'
  | 'expense';

interface ActionSheetsProps {
  modal: ActiveModalType;
  clients: Client[];
  preselectedClientId?: string | null;
  onClose: () => void;
  onSelectAddAction: (action: 'client' | 'payment' | 'invoice' | 'task' | 'expense') => void;
  onAddClient: (client: Omit<Client, 'id' | 'reminderHistory'>) => void;
  onAddPayment: (payment: Omit<Payment, 'id'>) => void;
  onAddTask: (task: Omit<TaskItem, 'id'>) => void;
  onAddExpense: (expense: Omit<ExpenseItem, 'id'>) => void;
}

export const ActionSheets: React.FC<ActionSheetsProps> = ({
  modal,
  clients,
  preselectedClientId,
  onClose,
  onSelectAddAction,
  onAddClient,
  onAddPayment,
  onAddTask,
  onAddExpense,
}) => {
  const today = new Date().toISOString().split('T')[0];

  const [cName, setCName] = useState('');
  const [cCity, setCCity] = useState('');
  const [cType, setCType] = useState<ProjectType>('Website');
  const [cTitle, setCTitle] = useState('');
  const [cPhone, setCPhone] = useState('+91 ');
  const [cTotal, setCTotal] = useState('');
  const [cPaid, setCPaid] = useState('0');

  const [pClientId, setPClientId] = useState(preselectedClientId || clients[0]?.id || '');
  const [pAmount, setPAmount] = useState('');
  const [pDate, setPDate] = useState(today);
  const [pMode, setPMode] = useState<PaymentMode>('UPI');
  const [pNote, setPNote] = useState('');

  const [tTitle, setTTitle] = useState('');
  const [tClientId, setTClientId] = useState(clients[0]?.id || 'studio');
  const [tDeadline, setTDeadline] = useState(today);
  const [tPriority, setTPriority] = useState<TaskPriority>('high');
  const [tStage, setTStage] = useState<TaskStage>('todo');

  const [eTitle, setETitle] = useState('');
  const [eAmount, setEAmount] = useState('');
  const [eCategory, setECategory] = useState<ExpenseCategory>('Hardware');
  const [eDate, setEDate] = useState(today);
  const [eNote, setENote] = useState('');

  useEffect(() => {
    if (preselectedClientId) {
      setPClientId(preselectedClientId);
    } else if ((!pClientId || !clients.some((c) => c.id === pClientId)) && clients[0]) {
      setPClientId(clients[0].id);
    }
    if (clients[0] && tClientId === 'studio') {
      setTClientId(clients[0].id);
    }
  }, [preselectedClientId, clients, pClientId, tClientId]);

  const handleClientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const totalAmount = Math.max(0, Number(cTotal) || 0);
    const paidAmount = Math.max(0, Math.min(totalAmount, Number(cPaid) || 0));
    const hasPending = totalAmount - paidAmount > 0;
    onAddClient({
      name: cName.trim(),
      city: cCity.trim(),
      projectType: cType,
      projectTitle: cTitle.trim() || `${cType} Project`,
      phone: cPhone.trim(),
      totalAmount,
      paidAmount,
      pendingSince: hasPending ? today : undefined,
      status: hasPending ? 'active' : 'completed',
      notes: '',
    });
    setCName('');
    setCCity('');
    setCTitle('');
    setCTotal('');
    setCPaid('0');
    onClose();
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pClientId) return;
    const amt = Math.max(1, Number(pAmount) || 0);
    onAddPayment({
      clientId: pClientId,
      amount: amt,
      date: pDate,
      mode: pMode,
      note: pNote.trim() || 'Payment received',
    });
    setPAmount('');
    setPNote('');
    onClose();
  };

  const handleTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tTitle.trim()) return;
    onAddTask({
      title: tTitle.trim(),
      clientId: tClientId,
      deadline: tDeadline,
      priority: tPriority,
      stage: tStage,
    });
    setTTitle('');
    onClose();
  };

  const handleExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Math.max(1, Number(eAmount) || 0);
    if (!eTitle.trim()) return;
    onAddExpense({
      title: eTitle.trim(),
      amount: amt,
      category: eCategory,
      date: eDate,
      note: eNote.trim(),
    });
    setETitle('');
    setEAmount('');
    setENote('');
    onClose();
  };

  return (
    <AnimatePresence>
      {modal && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16, ease: 'easeOut' }}
          className="fixed inset-0 z-50 bg-slate-900/40 flex items-end sm:items-center justify-center p-0 sm:p-4"
          onClick={onClose}
        >
          {modal === 'addMenu' ? (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md surface-card rounded-t-[20px] rounded-b-none sm:rounded-[16px] overflow-hidden shadow-xl pb-[env(safe-area-inset-bottom)] mb-0 sm:mb-8"
            >
              <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
                <div className="space-y-0.5">
                  <h2 className="font-display text-base font-bold text-[#0F172A]">Quick Create</h2>
                  <p className="text-xs text-slate-500">Add a record to CoderStudios</p>
                </div>
                <button
                  type="button"
                  onClick={onClose}
                  className="w-8 h-8 rounded-[8px] border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" strokeWidth={1.75} />
                </button>
              </div>

              <div className="divide-y divide-slate-200">
                {[
                  {
                    id: 'client' as const,
                    label: 'Add Client',
                    sub: 'New project contract & profile',
                    icon: UserPlus,
                  },
                  {
                    id: 'payment' as const,
                    label: 'Add Payment',
                    sub: 'UPI, Bank Transfer, or Cash entry',
                    icon: IndianRupee,
                  },
                  {
                    id: 'invoice' as const,
                    label: 'Create Invoice',
                    sub: 'Generate PDF, PNG & WhatsApp invoice',
                    icon: FileText,
                  },
                  {
                    id: 'task' as const,
                    label: 'Add Task',
                    sub: 'Assign Kanban deliverable & deadline',
                    icon: ListTodo,
                  },
                  {
                    id: 'expense' as const,
                    label: 'Add Expense',
                    sub: 'Log hardware, team, or cloud cost',
                    icon: Receipt,
                  },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => onSelectAddAction(item.id)}
                      className="w-full px-6 py-3.5 flex items-center gap-3.5 hover:bg-slate-50 transition-colors duration-150 text-left cursor-pointer"
                    >
                      <div className="w-9 h-9 rounded-[8px] border border-slate-200 bg-slate-50 flex items-center justify-center shrink-0">
                        <Icon className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />
                      </div>
                      <div className="space-y-0.5">
                        <p className="font-display text-sm font-bold text-[#0F172A]">{item.label}</p>
                        <p className="text-xs text-slate-500">{item.sub}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          ) : (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg surface-card rounded-t-[20px] rounded-b-none sm:rounded-[16px] p-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] max-h-[90dvh] overflow-y-auto shadow-xl"
            >
              {modal === 'client' && (
                <form onSubmit={handleClientSubmit} className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <h2 className="font-display text-lg font-bold text-[#0F172A]">
                      Add New Client
                    </h2>
                    <button
                      type="button"
                      onClick={onClose}
                      className="w-8 h-8 rounded-[8px] border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-600 cursor-pointer"
                    >
                      <X className="w-4 h-4" strokeWidth={1.75} />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">
                        Client Name
                      </label>
                      <input
                        type="text"
                        required
                        value={cName}
                        onChange={(e) => setCName(e.target.value)}
                        placeholder="Client Name"
                        className="w-full h-10 px-3 text-sm field-input"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">City</label>
                      <input
                        type="text"
                        required
                        value={cCity}
                        onChange={(e) => setCCity(e.target.value)}
                        placeholder="City"
                        className="w-full h-10 px-3 text-sm field-input"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">
                        Project Type
                      </label>
                      <select
                        value={cType}
                        onChange={(e) => setCType(e.target.value as ProjectType)}
                        className="w-full h-10 px-3 text-sm field-input"
                      >
                        <option value="Website">Website</option>
                        <option value="App">App</option>
                        <option value="Website + App">Website + App</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">
                        Phone / WhatsApp
                      </label>
                      <input
                        type="text"
                        required
                        value={cPhone}
                        onChange={(e) => setCPhone(e.target.value)}
                        className="w-full h-10 px-3 text-sm field-input"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-medium text-slate-600">
                      Project Title
                    </label>
                    <input
                      type="text"
                      value={cTitle}
                      onChange={(e) => setCTitle(e.target.value)}
                      placeholder="E-Commerce Web Platform"
                      className="w-full h-10 px-3 text-sm field-input"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">
                        Contract Amount (₹)
                      </label>
                      <input
                        type="number"
                        required
                        min={0}
                        value={cTotal}
                        onChange={(e) => setCTotal(e.target.value)}
                        placeholder="40000"
                        className="w-full h-10 px-3 text-sm tabular-nums field-input"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">
                        Advance Paid (₹)
                      </label>
                      <input
                        type="number"
                        min={0}
                        value={cPaid}
                        onChange={(e) => setCPaid(e.target.value)}
                        className="w-full h-10 px-3 text-sm tabular-nums field-input"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="btn-primary w-full h-11 text-sm font-semibold cursor-pointer"
                  >
                    Save Client
                  </button>
                </form>
              )}

              {modal === 'payment' && (
                clients.length === 0 ? (
                  <div className="space-y-4 text-center py-2">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                      <h2 className="font-display text-lg font-bold text-[#0F172A]">
                        Record Payment
                      </h2>
                      <button
                        type="button"
                        onClick={onClose}
                        className="w-8 h-8 rounded-[8px] border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-600 cursor-pointer"
                      >
                        <X className="w-4 h-4" strokeWidth={1.75} />
                      </button>
                    </div>
                    <p className="text-sm text-slate-500">
                      Add a client first so payments link accurately to their balance.
                    </p>
                    <button
                      type="button"
                      onClick={() => onSelectAddAction('client')}
                      className="btn-primary w-full h-11 text-sm font-semibold cursor-pointer"
                    >
                      Add Client First
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handlePaymentSubmit} className="space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                      <h2 className="font-display text-lg font-bold text-[#0F172A]">
                        Record Payment
                      </h2>
                      <button
                        type="button"
                        onClick={onClose}
                        className="w-8 h-8 rounded-[8px] border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-600 cursor-pointer"
                      >
                        <X className="w-4 h-4" strokeWidth={1.75} />
                      </button>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">
                        Select Client
                      </label>
                      <select
                        value={pClientId}
                        onChange={(e) => setPClientId(e.target.value)}
                        className="w-full h-10 px-3 text-sm field-input"
                      >
                        {clients.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name} ({c.city})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="block text-xs font-medium text-slate-600">
                          Amount (₹)
                        </label>
                        <input
                          type="number"
                          required
                          min={1}
                          value={pAmount}
                          onChange={(e) => setPAmount(e.target.value)}
                          placeholder="15000"
                          className="w-full h-10 px-3 text-sm tabular-nums field-input"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-xs font-medium text-slate-600">
                          Payment Date
                        </label>
                        <input
                          type="date"
                          required
                          value={pDate}
                          onChange={(e) => setPDate(e.target.value)}
                          className="w-full h-10 px-3 text-sm field-input"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">
                        Payment Mode
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['UPI', 'Bank', 'Cash'] as PaymentMode[]).map((mode) => (
                          <button
                            key={mode}
                            type="button"
                            onClick={() => setPMode(mode)}
                            className={`h-10 rounded-[8px] text-xs font-semibold border transition-colors duration-150 cursor-pointer ${
                              pMode === mode
                                ? 'bg-[#0F172A] text-white border-[#0F172A]'
                                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                            }`}
                          >
                            {mode}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">Note</label>
                      <input
                        type="text"
                        value={pNote}
                        onChange={(e) => setPNote(e.target.value)}
                        placeholder="Milestone settlement"
                        className="w-full h-10 px-3 text-sm field-input"
                      />
                    </div>

                    <button
                      type="submit"
                      className="btn-primary w-full h-11 text-sm font-semibold cursor-pointer"
                    >
                      Save Payment
                    </button>
                  </form>
                )
              )}

              {modal === 'task' && (
                <form onSubmit={handleTaskSubmit} className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <h2 className="font-display text-lg font-bold text-[#0F172A]">Add Task</h2>
                    <button
                      type="button"
                      onClick={onClose}
                      className="w-8 h-8 rounded-[8px] border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-600 cursor-pointer"
                    >
                      <X className="w-4 h-4" strokeWidth={1.75} />
                    </button>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-medium text-slate-600">Task Title</label>
                    <input
                      type="text"
                      required
                      value={tTitle}
                      onChange={(e) => setTTitle(e.target.value)}
                      placeholder="Deploy production build"
                      className="w-full h-10 px-3 text-sm field-input"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">Client</label>
                      <select
                        value={tClientId}
                        onChange={(e) => setTClientId(e.target.value)}
                        className="w-full h-10 px-3 text-sm field-input"
                      >
                        <option value="studio">CoderStudios (Internal)</option>
                        {clients.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">Deadline</label>
                      <input
                        type="date"
                        required
                        value={tDeadline}
                        onChange={(e) => setTDeadline(e.target.value)}
                        className="w-full h-10 px-3 text-sm field-input"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">Priority</label>
                      <select
                        value={tPriority}
                        onChange={(e) => setTPriority(e.target.value as TaskPriority)}
                        className="w-full h-10 px-3 text-sm field-input"
                      >
                        <option value="high">High</option>
                        <option value="medium">Medium</option>
                        <option value="low">Low</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">Column</label>
                      <select
                        value={tStage}
                        onChange={(e) => setTStage(e.target.value as TaskStage)}
                        className="w-full h-10 px-3 text-sm field-input"
                      >
                        <option value="todo">To Do</option>
                        <option value="doing">Doing</option>
                        <option value="done">Done</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="btn-primary w-full h-11 text-sm font-semibold cursor-pointer"
                  >
                    Create Task
                  </button>
                </form>
              )}

              {modal === 'expense' && (
                <form onSubmit={handleExpenseSubmit} className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <h2 className="font-display text-lg font-bold text-[#0F172A]">Add Expense</h2>
                    <button
                      type="button"
                      onClick={onClose}
                      className="w-8 h-8 rounded-[8px] border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-600 cursor-pointer"
                    >
                      <X className="w-4 h-4" strokeWidth={1.75} />
                    </button>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-medium text-slate-600">
                      Expense Title
                    </label>
                    <input
                      type="text"
                      required
                      value={eTitle}
                      onChange={(e) => setETitle(e.target.value)}
                      placeholder="Domain & Cloud Hosting"
                      className="w-full h-10 px-3 text-sm field-input"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">
                        Amount (₹)
                      </label>
                      <input
                        type="number"
                        required
                        min={1}
                        value={eAmount}
                        onChange={(e) => setEAmount(e.target.value)}
                        placeholder="2500"
                        className="w-full h-10 px-3 text-sm tabular-nums field-input"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-xs font-medium text-slate-600">Date</label>
                      <input
                        type="date"
                        required
                        value={eDate}
                        onChange={(e) => setEDate(e.target.value)}
                        className="w-full h-10 px-3 text-sm field-input"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-medium text-slate-600">Category</label>
                    <select
                      value={eCategory}
                      onChange={(e) => setECategory(e.target.value as ExpenseCategory)}
                      className="w-full h-10 px-3 text-sm field-input"
                    >
                      <option value="Hardware">Hardware</option>
                      <option value="Team & Events">Team &amp; Events</option>
                      <option value="Cloud & Hosting">Cloud &amp; Hosting</option>
                      <option value="Marketing">Marketing</option>
                      <option value="Operations">Operations</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-medium text-slate-600">Note</label>
                    <input
                      type="text"
                      value={eNote}
                      onChange={(e) => setENote(e.target.value)}
                      placeholder="Optional memo"
                      className="w-full h-10 px-3 text-sm field-input"
                    />
                  </div>

                  <button
                    type="submit"
                    className="btn-primary w-full h-11 text-sm font-semibold cursor-pointer"
                  >
                    Save Expense
                  </button>
                </form>
              )}
            </motion.div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
};
