import React, { useState } from 'react';
import { User, ShortageItem } from '../../types';
import { storageService } from '../../services/storage';
import {
  AlertTriangle,
  Plus,
  Package,
  Clock,
  CheckCircle2,
  Info,
  Shield,
  Layers,
} from 'lucide-react';

interface ShortagesReportViewProps {
  currentUser: User;
  shortages: ShortageItem[];
  onShortageAdded: () => void;
}

export const ShortagesReportView: React.FC<ShortagesReportViewProps> = ({
  currentUser,
  shortages,
  onShortageAdded,
}) => {
  const [product, setProduct] = useState('');
  const [quantity, setQuantity] = useState('');
  const [comment, setComment] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Common restaurant quick items
  const quickProducts = [
    'Camarón',
    'Servilletas',
    'Aceite para freír',
    'Arroz blanco',
    'Limones frescos',
    'Jarabes para coctelería',
    'Detergente lavalozas',
    'Rollos de papel ticket',
  ];

  const quickUnits = ['1 kg', '2 kg', '3 kg', '5 kg', '1 caja', '5 paquetes', '2 litros', '1 pieza'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!product.trim() || !quantity.trim()) {
      setErrorMsg('Por favor escribe el nombre del producto y la cantidad faltante.');
      return;
    }

    storageService.reportShortage(
      {
        product: product.trim(),
        quantity: quantity.trim(),
        comment: comment.trim() || 'Reportado en cambio de turno',
      },
      currentUser
    );

    setProduct('');
    setQuantity('');
    setComment('');
    setErrorMsg('');
    setSuccessMsg('¡Faltante registrado con éxito! Aparecerá en la lista de compras del Administrador.');
    setTimeout(() => setSuccessMsg(''), 4000);
    onShortageAdded();
  };

  // Filter shortages for this area or today
  const areaShortages = shortages.filter((s) => s.areaId === currentUser.areaId);

  return (
    <div className="space-y-5 max-w-4xl mx-auto">
      {/* Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-neutral-200">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2.5 py-0.5 rounded-md border border-orange-200 flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            Reporte de Insumos
          </span>
          <span className="text-xs font-semibold text-neutral-600 bg-neutral-100 px-2.5 py-0.5 rounded-md">
            {currentUser.areaName} • {currentUser.shift}
          </span>
        </div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
          Reportar Faltantes y Desabasto
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-1">
          Registra cualquier producto, materia prima o material que falte. Se enviará directamente al apartado de <strong>Compras Pendientes</strong> de la Gerencia.
        </p>
      </div>

      {/* Report Form */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-neutral-200 shadow-xs">
        <h2 className="text-base font-bold text-neutral-900 mb-3 flex items-center gap-2">
          <Plus className="w-5 h-5 text-orange-600" />
          Nuevo Reporte de Faltante
        </h2>

        {successMsg && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs sm:text-sm text-emerald-800 font-semibold flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {errorMsg && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-xs sm:text-sm text-red-800 font-semibold flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Producto */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                Producto o Material <span className="text-red-500">*</span>
              </label>
              <input
                id="shortage-product-input"
                type="text"
                value={product}
                onChange={(e) => setProduct(e.target.value)}
                placeholder="Ej. Camarón, Servilletas, Aceite..."
                className="w-full p-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
              />
              {/* Quick suggestions */}
              <div className="flex flex-wrap gap-1 mt-1.5">
                {quickProducts.slice(0, 4).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setProduct(p)}
                    className="text-[11px] bg-neutral-100 hover:bg-orange-50 hover:text-orange-700 text-neutral-600 px-2 py-0.5 rounded-md border border-neutral-200 transition-all"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Cantidad */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                Cantidad Faltante <span className="text-red-500">*</span>
              </label>
              <input
                id="shortage-quantity-input"
                type="text"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="Ej. 3 kg, 5 paquetes, 2 cajas..."
                className="w-full p-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
              />
              {/* Quick units */}
              <div className="flex flex-wrap gap-1 mt-1.5">
                {quickUnits.slice(0, 5).map((u) => (
                  <button
                    key={u}
                    type="button"
                    onClick={() => setQuantity(u)}
                    className="text-[11px] bg-neutral-100 hover:bg-orange-50 hover:text-orange-700 text-neutral-600 px-2 py-0.5 rounded-md border border-neutral-200 transition-all"
                  >
                    {u}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Comentario */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
              Comentario o Razón (Opcional)
            </label>
            <input
              id="shortage-comment-input"
              type="text"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Ej. Se terminó durante el turno matutino por alta demanda..."
              className="w-full p-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all"
            />
          </div>

          {/* Info Badge */}
          <div className="p-3 bg-neutral-100 rounded-xl border border-neutral-200 flex items-center justify-between text-xs text-neutral-600">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-neutral-500 shrink-0" />
              <span>
                Reportando como: <strong>{currentUser.name}</strong> ({currentUser.shift})
              </span>
            </div>
            <span className="text-[11px] text-neutral-400 font-medium">Solo Admin gestiona compras</span>
          </div>

          {/* Submit button */}
          <button
            id="btn-submit-shortage"
            type="submit"
            className="w-full py-3.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-xs active:scale-[0.98] transition-all"
          >
            <AlertTriangle className="w-5 h-5 stroke-[2.5]" />
            <span>Registrar Faltante Ahora</span>
          </button>
        </form>
      </div>

      {/* Reported Items in this Area */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-1.5 px-1">
          <Package className="w-4 h-4 text-orange-600" />
          Faltantes Reportados en {currentUser.areaName} ({areaShortages.length})
        </h2>

        {areaShortages.length === 0 ? (
          <div className="bg-white rounded-2xl p-6 text-center border border-neutral-200 text-xs text-neutral-500">
            No hay faltantes registrados en esta área actualmente.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {areaShortages.map((item) => (
              <div
                key={item.id}
                id={`shortage-item-${item.id}`}
                className="bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs flex flex-col justify-between space-y-2.5"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-base font-extrabold text-neutral-900 tracking-tight">
                      {item.product}
                    </span>
                    <span
                      className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                        item.status === 'Comprado'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : 'bg-amber-100 text-amber-900 border border-amber-200'
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>

                  <div className="text-sm font-bold text-orange-600 mt-0.5">
                    Cantidad: {item.quantity}
                  </div>

                  {item.comment && (
                    <p className="text-xs text-neutral-600 mt-1 italic leading-relaxed">
                      "{item.comment}"
                    </p>
                  )}
                </div>

                <div className="pt-2 border-t border-neutral-100 text-[11px] text-neutral-500 flex items-center justify-between">
                  <span>Por {item.reportedByName}</span>
                  <span>{item.date} • {item.time}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
