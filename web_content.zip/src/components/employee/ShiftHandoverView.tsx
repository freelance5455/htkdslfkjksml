import React, { useState } from 'react';
import { User, TaskTemplate, TaskRecord, ShortageItem, ShiftHandover } from '../../types';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
import {
  Repeat,
  CheckCircle2,
  Clock,
  AlertTriangle,
  MessageSquare,
  Send,
  Calendar,
  Check,
  RotateCcw,
} from 'lucide-react';

interface ShiftHandoverViewProps {
  currentUser: User;
  templates: TaskTemplate[];
  records: TaskRecord[];
  shortages: ShortageItem[];
  handovers: ShiftHandover[];
  onHandoverCompleted: () => void;
}

export const ShiftHandoverView: React.FC<ShiftHandoverViewProps> = ({
  currentUser,
  templates,
  records,
  shortages,
  handovers,
  onHandoverCompleted,
}) => {
  const { logout } = useAuth();
  const [observations, setObservations] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completedSuccess, setCompletedSuccess] = useState(false);

  // Filter tasks executed in this shift & area
  const shiftRecords = records.filter(
    (r) => r.shift === currentUser.shift && r.areaId === currentUser.areaId
  );

  const doneTasks = shiftRecords.filter((r) => r.status === 'realizada');
  const pendingTasks = shiftRecords.filter((r) => r.status === 'pendiente');

  // Filter shortages reported in this shift & area
  const shiftShortages = shortages.filter(
    (s) => s.shift === currentUser.shift && s.areaId === currentUser.areaId
  );

  // Filter area handovers history
  const areaHandovers = handovers.filter((h) => h.areaId === currentUser.areaId);

  const handleSubmitHandover = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const completedTasksSummary = doneTasks.map((t) => t.title);
    const pendingTasksSummary = pendingTasks.map((t) => ({
      title: t.title,
      reason: t.pendingReason || 'Sin motivo especificado',
    }));
    const shortagesSummary = shiftShortages.map((s) => ({
      product: s.product,
      quantity: s.quantity,
    }));

    storageService.saveShiftHandover(
      {
        observations: observations.trim() || 'Entrega regular sin incidencias extraordinarias.',
        completedTasksSummary,
        pendingTasksSummary,
        shortagesSummary,
      },
      currentUser
    );

    setIsSubmitting(false);
    setCompletedSuccess(true);
    onHandoverCompleted();
  };

  return (
    <div className="space-y-5 max-w-4xl mx-auto">
      {/* Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-neutral-200">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2.5 py-0.5 rounded-md border border-orange-200 flex items-center gap-1">
            <Repeat className="w-3.5 h-3.5" />
            Cierre y Relevo
          </span>
          <span className="text-xs font-semibold text-neutral-600 bg-neutral-100 px-2.5 py-0.5 rounded-md">
            {currentUser.areaName} • {currentUser.shift}
          </span>
        </div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
          Entrega de Turno a Siguiente Relevo
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-1">
          Revisa el resumen de tus tareas realizadas, pendientes y faltantes para que el siguiente turno tome el control sin contratiempos.
        </p>
      </div>

      {completedSuccess ? (
        <div className="bg-white rounded-2xl p-6 sm:p-8 text-center border border-emerald-200 shadow-sm space-y-4 animate-in fade-in">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h2 className="text-xl font-extrabold text-neutral-900">
            ¡Turno Entregado Exitosamente!
          </h2>
          <p className="text-sm text-neutral-600 max-w-md mx-auto">
            Se ha guardado el reporte con tus {doneTasks.length} tareas realizadas, {pendingTasks.length} pendientes y {shiftShortages.length} faltantes. El siguiente relevo podrá consultar tus notas.
          </p>
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => setCompletedSuccess(false)}
              className="px-5 py-2.5 rounded-xl border border-neutral-300 text-neutral-700 font-semibold text-sm hover:bg-neutral-50"
            >
              Ver Resumen
            </button>
            <button
              onClick={logout}
              className="px-6 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-sm shadow-xs"
            >
              Cerrar Sesión para Siguiente Turno
            </button>
          </div>
        </div>
      ) : (
        /* Handover Live Form / Summary */
        <form onSubmit={handleSubmitHandover} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* 1. Tareas Realizadas */}
            <div className="bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs">
              <div className="flex items-center justify-between border-b border-neutral-100 pb-2 mb-2.5">
                <div className="flex items-center gap-1.5 font-bold text-xs uppercase tracking-wider text-emerald-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Realizadas ({doneTasks.length})</span>
                </div>
              </div>

              {doneTasks.length === 0 ? (
                <p className="text-xs text-neutral-400 italic py-2">
                  No marcaste tareas como realizadas en este turno.
                </p>
              ) : (
                <ul className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {doneTasks.map((t) => (
                    <li
                      key={t.id}
                      className="text-xs text-neutral-800 font-medium flex items-start gap-1.5 bg-emerald-50/50 p-2 rounded-lg border border-emerald-100/80"
                    >
                      <span className="text-emerald-600 font-bold">✓</span>
                      <span className="truncate">{t.title}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* 2. Tareas Pendientes */}
            <div className="bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs">
              <div className="flex items-center justify-between border-b border-neutral-100 pb-2 mb-2.5">
                <div className="flex items-center gap-1.5 font-bold text-xs uppercase tracking-wider text-amber-700">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span>Pendientes ({pendingTasks.length})</span>
                </div>
              </div>

              {pendingTasks.length === 0 ? (
                <p className="text-xs text-emerald-600 font-medium py-2">
                  ¡Excelente! No hay tareas pendientes en este turno.
                </p>
              ) : (
                <ul className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {pendingTasks.map((t) => (
                    <li
                      key={t.id}
                      className="text-xs text-amber-950 font-medium bg-amber-50/70 p-2 rounded-lg border border-amber-200"
                    >
                      <div className="font-bold">{t.title}</div>
                      <div className="text-[11px] text-amber-800 mt-0.5 italic">
                        Motivo: "{t.pendingReason}"
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* 3. Faltantes Reportados */}
            <div className="bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs">
              <div className="flex items-center justify-between border-b border-neutral-100 pb-2 mb-2.5">
                <div className="flex items-center gap-1.5 font-bold text-xs uppercase tracking-wider text-orange-700">
                  <AlertTriangle className="w-4 h-4 text-orange-600" />
                  <span>Faltantes ({shiftShortages.length})</span>
                </div>
              </div>

              {shiftShortages.length === 0 ? (
                <p className="text-xs text-neutral-400 italic py-2">
                  Sin faltantes reportados en este turno.
                </p>
              ) : (
                <ul className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {shiftShortages.map((s) => (
                    <li
                      key={s.id}
                      className="text-xs text-neutral-900 font-medium bg-orange-50/60 p-2 rounded-lg border border-orange-100"
                    >
                      <div className="font-bold">{s.product}</div>
                      <div className="text-[11px] text-orange-700">{s.quantity}</div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* 4. Observaciones de Entrega */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-neutral-200 shadow-xs space-y-2">
            <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider">
              Observaciones y Notas para el Siguiente Turno <span className="text-neutral-400 font-normal">(Opcional)</span>
            </label>
            <textarea
              id="handover-observations-input"
              rows={3}
              value={observations}
              onChange={(e) => setObservations(e.target.value)}
              placeholder="Ej. Dejé camarón descongelando en cámara fría, revisar la mesa 4 que tiene reserva a las 8pm, el piso se trapeó a las 2:30pm..."
              className="w-full p-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all leading-relaxed"
            />
          </div>

          {/* Big Action Button */}
          <button
            id="btn-deliver-shift"
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-black text-base flex items-center justify-center gap-2 shadow-md active:scale-[0.98] transition-all"
          >
            <Send className="w-5 h-5 stroke-[2.5]" />
            <span>Firmar y Entregar {currentUser.shift} ({currentUser.name})</span>
          </button>
        </form>
      )}

      {/* Historial de Cambios de Turno en el Área */}
      <div className="space-y-3 pt-3">
        <h2 className="text-sm font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-1.5 px-1">
          <Calendar className="w-4 h-4 text-orange-600" />
          Historial de Entregas en {currentUser.areaName} ({areaHandovers.length})
        </h2>

        {areaHandovers.length === 0 ? (
          <div className="bg-white rounded-2xl p-6 text-center border border-neutral-200 text-xs text-neutral-500">
            Aún no hay entregas de turno registradas en esta área.
          </div>
        ) : (
          <div className="space-y-3">
            {areaHandovers.map((h) => (
              <div
                key={h.id}
                className="bg-white rounded-2xl p-4 sm:p-5 border border-neutral-200 shadow-xs space-y-2.5"
              >
                <div className="flex items-start justify-between gap-2 border-b border-neutral-100 pb-2">
                  <div>
                    <span className="text-xs font-bold text-orange-700 bg-orange-50 px-2 py-0.5 rounded border border-orange-200">
                      {h.fromShift}
                    </span>
                    <span className="ml-2 font-bold text-neutral-900 text-sm">{h.employeeName}</span>
                  </div>
                  <span className="text-xs text-neutral-500">
                    {h.date} a las {h.time}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-neutral-700 italic bg-neutral-50 p-2.5 rounded-xl border border-neutral-200/70">
                  "{h.observations}"
                </p>

                <div className="flex items-center gap-3 text-xs text-neutral-600 font-medium">
                  <span className="text-emerald-700">✓ {h.completedTasksSummary?.length || 0} realizadas</span>
                  <span>•</span>
                  <span className="text-amber-700">⏳ {h.pendingTasksSummary?.length || 0} pendientes</span>
                  <span>•</span>
                  <span className="text-orange-700">⚠️ {h.shortagesSummary?.length || 0} faltantes</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
