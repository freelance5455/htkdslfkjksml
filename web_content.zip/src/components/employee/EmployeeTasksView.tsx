import React, { useState } from 'react';
import { User, TaskTemplate, TaskRecord } from '../../types';
import { storageService } from '../../services/storage';
import { Modal } from '../common/Modal';
import {
  CheckCircle2,
  Clock,
  AlertCircle,
  Sparkles,
  Search,
  Check,
  RotateCcw,
  Info,
  Calendar,
} from 'lucide-react';

interface EmployeeTasksViewProps {
  currentUser: User;
  templates: TaskTemplate[];
  records: TaskRecord[];
  onTaskUpdated: () => void;
}

export const EmployeeTasksView: React.FC<EmployeeTasksViewProps> = ({
  currentUser,
  templates,
  records,
  onTaskUpdated,
}) => {
  const [filter, setFilter] = useState<'todas' | 'por_hacer' | 'realizadas' | 'pendientes'>('todas');
  const [searchQuery, setSearchQuery] = useState('');
  const [pendingModalTask, setPendingModalTask] = useState<TaskTemplate | null>(null);
  const [pendingReason, setPendingReason] = useState('');
  const [reasonError, setReasonError] = useState('');

  // Filter templates for current employee's area
  const areaTemplates = templates.filter(
    (t) =>
      t.areaId === currentUser.areaId &&
      (t.shiftTarget === 'Todos' || !t.shiftTarget || t.shiftTarget === currentUser.shift)
  );

  // Helper to find today's execution record for a template in this shift
  const todayRecord = (templateId: string) => {
    return records.find(
      (r) =>
        r.templateId === templateId &&
        r.shift === currentUser.shift &&
        r.areaId === currentUser.areaId
    );
  };

  const handleMarkDone = (template: TaskTemplate) => {
    storageService.markTaskDone(template, currentUser);
    onTaskUpdated();
  };

  const handleOpenPendingModal = (template: TaskTemplate) => {
    setPendingModalTask(template);
    setPendingReason('');
    setReasonError('');
  };

  const handleConfirmPending = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pendingReason.trim()) {
      setReasonError('Debes ingresar un motivo explicando por qué no se pudo realizar.');
      return;
    }
    if (!pendingModalTask) return;

    storageService.markTaskPending(pendingModalTask, currentUser, pendingReason.trim());
    setPendingModalTask(null);
    setPendingReason('');
    onTaskUpdated();
  };

  // Quick preset reasons for faster mobile input
  const quickReasons = [
    'No se alcanzó a realizar durante el turno por alta afluencia',
    'Falta de insumos / producto agotado',
    'Equipo o máquina en mantenimiento',
    'Se priorizaron pedidos urgentes de salón',
  ];

  // Filter by status & search
  const filteredTemplates = areaTemplates.filter((template) => {
    const rec = todayRecord(template.id);
    const matchesSearch =
      template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (template.description && template.description.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    if (filter === 'por_hacer') return !rec || (rec.status !== 'realizada' && rec.status !== 'pendiente');
    if (filter === 'realizadas') return rec?.status === 'realizada';
    if (filter === 'pendientes') return rec?.status === 'pendiente';
    return true;
  });

  // Calculate progress stats
  const totalAreaTasks = areaTemplates.length;
  const completedCount = areaTemplates.filter((t) => todayRecord(t.id)?.status === 'realizada').length;
  const pendingCount = areaTemplates.filter((t) => todayRecord(t.id)?.status === 'pendiente').length;
  const progressPercent = totalAreaTasks > 0 ? Math.round((completedCount / totalAreaTasks) * 100) : 0;

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Shift & Area Hero Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-neutral-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2.5 py-0.5 rounded-md border border-orange-200">
                {currentUser.areaName || 'Área'}
              </span>
              <span className="text-xs font-semibold text-neutral-600 bg-neutral-100 px-2.5 py-0.5 rounded-md">
                {currentUser.shift}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900 mt-1">
              Tareas Asignadas del Turno
            </h1>
            <p className="text-xs sm:text-sm text-neutral-500 mt-0.5">
              Solo el Administrador define las tareas. Marca cada tarea realizada o indica el motivo si queda pendiente.
            </p>
          </div>

          {/* Progress Circle / Bar */}
          <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-200/80 flex items-center justify-between sm:justify-center gap-4 shrink-0">
            <div className="text-left sm:text-right">
              <div className="text-xs text-neutral-500 font-medium">Progreso del Turno</div>
              <div className="text-lg font-black text-neutral-900">
                {completedCount} / {totalAreaTasks} <span className="text-xs text-neutral-500 font-normal">tareas</span>
              </div>
            </div>
            <div className="relative w-12 h-12 flex items-center justify-center rounded-full bg-orange-100 text-orange-600 font-bold text-sm">
              {progressPercent}%
            </div>
          </div>
        </div>

        {/* Progress bar line */}
        <div className="w-full bg-neutral-100 h-2 rounded-full overflow-hidden mt-4">
          <div
            className="bg-orange-600 h-full transition-all duration-300 rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Filter Tabs & Search */}
      <div className="space-y-2">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <button
            id="filter-todas"
            onClick={() => setFilter('todas')}
            className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all active:scale-95 ${
              filter === 'todas'
                ? 'bg-neutral-900 text-white shadow-xs'
                : 'bg-white text-neutral-600 hover:bg-neutral-100 border border-neutral-200'
            }`}
          >
            Todas ({totalAreaTasks})
          </button>
          <button
            id="filter-por_hacer"
            onClick={() => setFilter('por_hacer')}
            className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all active:scale-95 ${
              filter === 'por_hacer'
                ? 'bg-orange-600 text-white shadow-xs'
                : 'bg-white text-neutral-600 hover:bg-neutral-100 border border-neutral-200'
            }`}
          >
            Por Realizar ({totalAreaTasks - completedCount - pendingCount})
          </button>
          <button
            id="filter-realizadas"
            onClick={() => setFilter('realizadas')}
            className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all active:scale-95 ${
              filter === 'realizadas'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-neutral-600 hover:bg-neutral-100 border border-neutral-200'
            }`}
          >
            Realizadas ({completedCount})
          </button>
          <button
            id="filter-pendientes"
            onClick={() => setFilter('pendientes')}
            className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all active:scale-95 ${
              filter === 'pendientes'
                ? 'bg-amber-500 text-neutral-900 shadow-xs'
                : 'bg-white text-neutral-600 hover:bg-neutral-100 border border-neutral-200'
            }`}
          >
            Pendientes ({pendingCount})
          </button>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-neutral-400" />
          <input
            id="search-tasks-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Buscar tareas en ${currentUser.areaName || 'tu área'}...`}
            className="w-full pl-9 pr-4 py-2.5 text-sm bg-white border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all"
          />
        </div>
      </div>

      {/* Task Cards List */}
      {filteredTemplates.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-neutral-200">
          <CheckCircle2 className="w-12 h-12 text-neutral-300 mx-auto mb-2" />
          <h3 className="text-base font-bold text-neutral-700">No hay tareas en esta vista</h3>
          <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
            {searchQuery
              ? 'No se encontraron tareas que coincidan con la búsqueda.'
              : 'Todas las tareas correspondientes han sido atendidas o no hay asignadas para este turno.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTemplates.map((template) => {
            const rec = todayRecord(template.id);
            const isDone = rec?.status === 'realizada';
            const isPending = rec?.status === 'pendiente';

            return (
              <div
                key={template.id}
                id={`task-card-${template.id}`}
                className={`bg-white rounded-2xl p-4 sm:p-5 border transition-all duration-200 shadow-xs ${
                  isDone
                    ? 'border-emerald-200 bg-emerald-50/20'
                    : isPending
                    ? 'border-amber-300 bg-amber-50/30'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      {template.priority === 'Urgente' && (
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-red-100 text-red-700">
                          Urgente
                        </span>
                      )}
                      {template.priority === 'Alta' && (
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-orange-100 text-orange-700">
                          Alta prioridad
                        </span>
                      )}
                      <span className="text-[11px] text-neutral-400 font-medium">
                        Área: {currentUser.areaName}
                      </span>
                    </div>

                    <h3
                      className={`text-base sm:text-lg font-bold tracking-tight ${
                        isDone ? 'text-neutral-800 line-through decoration-emerald-500/60' : 'text-neutral-900'
                      }`}
                    >
                      {template.title}
                    </h3>

                    {template.description && (
                      <p className="text-xs sm:text-sm text-neutral-600 mt-1 leading-relaxed">
                        {template.description}
                      </p>
                    )}

                    {/* Status Log Details */}
                    {isDone && rec && (
                      <div className="mt-3 p-2.5 rounded-xl bg-emerald-100/60 border border-emerald-200 flex items-start gap-2 text-xs text-emerald-900">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold">Realizada por: {rec.completedByName || currentUser.name}</span>
                          <span className="mx-1.5">•</span>
                          <span>Hora: {rec.time}</span>
                          <span className="mx-1.5">•</span>
                          <span>Fecha: {rec.date}</span>
                        </div>
                      </div>
                    )}

                    {isPending && rec && (
                      <div className="mt-3 p-2.5 rounded-xl bg-amber-100/70 border border-amber-200 flex items-start gap-2 text-xs text-amber-950">
                        <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <div className="font-bold text-amber-900">
                            Marcada como PENDIENTE ({rec.time} - {rec.pendingReportedByName || currentUser.name})
                          </div>
                          <div className="mt-0.5 text-amber-800">
                            <strong>Motivo:</strong> {rec.pendingReason}
                          </div>
                          <div className="text-[11px] text-amber-700 mt-0.5">
                            Se notificará y pasará al siguiente turno.
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Big Action Buttons for Fast Touchscreen Usage */}
                <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center gap-2">
                  {!isDone ? (
                    <>
                      {/* Green Realizada Button */}
                      <button
                        id={`btn-done-${template.id}`}
                        onClick={() => handleMarkDone(template)}
                        className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-xs active:scale-[0.98] transition-all"
                      >
                        <Check className="w-5 h-5 stroke-[2.5]" />
                        <span>Marcar Realizada</span>
                      </button>

                      {/* Amber Pendiente Button */}
                      {!isPending && (
                        <button
                          id={`btn-pending-${template.id}`}
                          onClick={() => handleOpenPendingModal(template)}
                          className="py-3 px-3.5 sm:px-5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 border border-amber-200 active:scale-[0.98] transition-all"
                        >
                          <Clock className="w-4 h-4 text-amber-700" />
                          <span>Pendiente</span>
                        </button>
                      )}
                    </>
                  ) : (
                    /* Allow unchecking or re-marking if marked by mistake */
                    <button
                      id={`btn-reopen-${template.id}`}
                      onClick={() => handleOpenPendingModal(template)}
                      className="py-2 px-3 rounded-lg text-xs font-semibold text-neutral-500 hover:text-neutral-800 hover:bg-neutral-100 flex items-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Cambiar a Pendiente</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal: Marcar Tarea como Pendiente con Motivo */}
      <Modal
        isOpen={!!pendingModalTask}
        onClose={() => setPendingModalTask(null)}
        title="Marcar Tarea como Pendiente"
        subtitle={pendingModalTask ? `Tarea: "${pendingModalTask.title}"` : ''}
      >
        <form onSubmit={handleConfirmPending} className="space-y-4">
          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-start gap-2.5 text-xs text-amber-900">
            <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <p>
              El motivo quedará registrado con tu nombre (<strong>{currentUser.name}</strong>) y turno (<strong>{currentUser.shift}</strong>), y aparecerá automáticamente para el empleado del siguiente turno.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Motivo o Justificación <span className="text-red-500">*</span>
            </label>
            <textarea
              id="pending-reason-input"
              rows={3}
              value={pendingReason}
              onChange={(e) => {
                setPendingReason(e.target.value);
                if (reasonError) setReasonError('');
              }}
              placeholder="Ej. No se alcanzó a realizar durante el turno por alta afluencia de comensales..."
              className="w-full p-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all"
              autoFocus
            />
            {reasonError && <p className="text-xs text-red-600 font-medium mt-1">{reasonError}</p>}
          </div>

          {/* Quick preset suggestions */}
          <div>
            <label className="block text-[11px] font-semibold text-neutral-500 uppercase tracking-wider mb-1">
              Motivos frecuentes:
            </label>
            <div className="flex flex-wrap gap-1.5">
              {quickReasons.map((reason, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPendingReason(reason)}
                  className="text-left text-xs bg-neutral-100 hover:bg-amber-100 hover:text-amber-900 text-neutral-700 px-2.5 py-1.5 rounded-lg border border-neutral-200 transition-all"
                >
                  + {reason}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setPendingModalTask(null)}
              className="px-4 py-2.5 rounded-xl text-neutral-600 hover:bg-neutral-100 font-semibold text-sm"
            >
              Cancelar
            </button>
            <button
              id="btn-confirm-pending"
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-neutral-900 font-bold text-sm shadow-xs active:scale-95 transition-all"
            >
              Guardar como Pendiente
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
