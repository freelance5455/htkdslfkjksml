import React from 'react';
import { User, TaskRecord, ShiftHandover } from '../../types';
import { storageService } from '../../services/storage';
import {
  ClockAlert,
  CheckCircle2,
  Calendar,
  Clock,
  ArrowRight,
  MessageSquare,
  ShieldAlert,
  Check,
} from 'lucide-react';

interface PreviousShiftPendingsViewProps {
  currentUser: User;
  records: TaskRecord[];
  handovers: ShiftHandover[];
  onTaskResolved: () => void;
}

export const PreviousShiftPendingsView: React.FC<PreviousShiftPendingsViewProps> = ({
  currentUser,
  records,
  handovers,
  onTaskResolved,
}) => {
  // Find pending tasks in this area from another shift or marked as pending
  const areaPendings = records.filter(
    (r) =>
      r.areaId === currentUser.areaId &&
      (r.status === 'pendiente' || (r.resolvedInNextShift && r.resolvedShift === currentUser.shift))
  );

  // Separate currently pending vs already resolved in this shift
  const unresolvedTasks = areaPendings.filter((r) => r.status === 'pendiente');
  const resolvedTasks = areaPendings.filter((r) => r.resolvedInNextShift);

  // Find latest handover note for this area
  const latestHandover = handovers.find((h) => h.areaId === currentUser.areaId);

  const handleResolveTask = (recordId: string) => {
    storageService.resolvePreviousShiftPending(recordId, currentUser);
    onTaskResolved();
  };

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-neutral-200">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600 bg-amber-50 px-2.5 py-0.5 rounded-md border border-amber-200 flex items-center gap-1">
            <ClockAlert className="w-3.5 h-3.5" />
            Relevo de Turno
          </span>
          <span className="text-xs font-semibold text-neutral-600 bg-neutral-100 px-2.5 py-0.5 rounded-md">
            Área: {currentUser.areaName}
          </span>
        </div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
          Pendientes Dejados por el Turno Anterior
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-1">
          Aquí puedes ver las tareas que el turno previo no completó y su motivo. Al resolverlas, quedará registrado automáticamente quién las terminó, fecha y hora.
        </p>
      </div>

      {/* Latest Handover Observation Note */}
      {latestHandover && (
        <div className="bg-amber-500/10 border border-amber-300 rounded-2xl p-4 text-amber-950">
          <div className="flex items-center justify-between gap-2 border-b border-amber-200/80 pb-2 mb-2.5">
            <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-amber-900">
              <MessageSquare className="w-4 h-4 text-amber-700" />
              <span>Última Nota de Entrega ({latestHandover.fromShift})</span>
            </div>
            <span className="text-xs text-amber-800 font-medium">
              Por {latestHandover.employeeName} • {latestHandover.time}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-amber-900 italic font-medium leading-relaxed">
            "{latestHandover.observations || 'Sin observaciones adicionales registradas.'}"
          </p>
        </div>
      )}

      {/* Unresolved Tasks List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            Tareas Por Continuar ({unresolvedTasks.length})
          </h2>
          {unresolvedTasks.length === 0 && (
            <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full">
              ¡Al día! Todo completado
            </span>
          )}
        </div>

        {unresolvedTasks.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-neutral-200">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
            <h3 className="text-base font-bold text-neutral-800">
              No hay pendientes sin resolver en este momento
            </h3>
            <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
              El turno anterior dejó todas sus tareas en orden o ya han sido resueltas.
            </p>
          </div>
        ) : (
          unresolvedTasks.map((rec) => (
            <div
              key={rec.id}
              id={`pending-rec-${rec.id}`}
              className="bg-white rounded-2xl p-4 sm:p-5 border-2 border-amber-200 shadow-xs space-y-3 hover:border-amber-300 transition-all"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                      Dejó: {rec.shift}
                    </span>
                    <span className="text-[11px] text-neutral-500">
                      Fecha: {rec.date} • {rec.time}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-neutral-900">{rec.title}</h3>
                </div>
              </div>

              {/* Motivo box */}
              <div className="bg-neutral-50 rounded-xl p-3 border border-neutral-200 text-xs">
                <div className="font-semibold text-neutral-700 mb-0.5">
                  Motivo reportado por {rec.pendingReportedByName || 'Empleado anterior'}:
                </div>
                <div className="text-neutral-900 font-medium leading-relaxed bg-amber-50/60 p-2 rounded-lg border border-amber-100 text-amber-950">
                  "{rec.pendingReason || 'No se especificó motivo.'}"
                </div>
              </div>

              {/* Big Action Button to Complete */}
              <button
                id={`btn-resolve-${rec.id}`}
                onClick={() => handleResolveTask(rec.id)}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-xs active:scale-[0.98] transition-all"
              >
                <Check className="w-5 h-5 stroke-[2.5]" />
                <span>Tomar y Completar en mi Turno ({currentUser.shift})</span>
              </button>
            </div>
          ))
        )}
      </div>

      {/* Already Resolved Section */}
      {resolvedTasks.length > 0 && (
        <div className="space-y-3 pt-4 border-t border-neutral-200">
          <h2 className="text-sm font-bold text-neutral-700 uppercase tracking-wider flex items-center gap-1.5 px-1">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            Pendientes Resueltos Durante Este Turno ({resolvedTasks.length})
          </h2>

          <div className="space-y-2">
            {resolvedTasks.map((rec) => (
              <div
                key={rec.id}
                className="bg-emerald-50/50 rounded-xl p-3.5 border border-emerald-200 text-xs text-emerald-950 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <div className="font-bold text-sm text-neutral-900">{rec.title}</div>
                  <div className="text-emerald-800 text-[11px] mt-0.5">
                    Original de {rec.shift} (Motivo: "{rec.pendingReason}")
                  </div>
                </div>
                <div className="bg-white px-3 py-1.5 rounded-lg border border-emerald-200 font-semibold text-emerald-900 shrink-0 text-left sm:text-right">
                  ✓ Resuelta por: {rec.resolvedByName || currentUser.name}
                  <div className="text-[10px] text-neutral-500 font-normal">
                    {rec.resolvedDate} a las {rec.resolvedTime} ({rec.resolvedShift})
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
