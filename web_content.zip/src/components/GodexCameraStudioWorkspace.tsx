/**
 * GODEX P4.8 — Cinematic Camera & Optical Simulation Workspace
 * 
 * Professional Cinematography & Optical Intelligence Console:
 * 1. Physical Camera Body & Sensor Format Selector (ARRI, RED, Sony, IMAX, S35, Full Frame)
 * 2. Cine Lens & Focal Length Optics (FOV, 35mm Equivalent, Anamorphic Squeeze)
 * 3. Aperture, Focus Distance & Depth of Field Physics (Near/Far limits, Hyperfocal, CoC, Bokeh)
 * 4. 3D Camera Pose, Kinematics & Trajectory Waypoints
 * 5. Deterministic Optical Simulation Preview Canvas (Vignette, Distortion, Flare, Grain)
 * 6. Multi-Shot Narrative Planning & Spatial Continuity Inspector (180° axis, 30° jump cut, etc.)
 * 7. Prompt-to-Camera Intelligence Analyzer
 * 
 * Fully responsive across Mobile (390x844), Tablet (768x1024), and Desktop (1280x800).
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Camera,
  Compass,
  Sliders,
  Eye,
  Layers,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Info,
  Maximize2,
  RotateCcw,
  Zap,
  Activity,
  Film,
  Play,
  Pause,
  ChevronRight,
  ShieldCheck,
  Cpu,
  Target,
  RefreshCw,
  Box,
  Compass as CompassIcon
} from 'lucide-react';
import {
  CameraBodyProfile,
  LensProfile,
  CameraShotSpec,
  ShotArchetype,
  CameraContinuityReport,
  PromptCameraExtraction
} from '../builder/creative/camera/cinematicCameraTypes';
import { CAMERA_BODIES, CINE_LENSES } from '../builder/creative/camera/cameraBodiesAndLenses';
import { OpticalSimulationEngine } from '../builder/creative/camera/opticalSimulationEngine';
import { CameraContinuityEngine } from '../builder/creative/camera/cameraContinuityEngine';
import { CameraControlEngine } from '../builder/creative/cameraControlEngine';
import { PromptCameraExtractor } from '../builder/creative/camera/promptCameraExtractor';
import { ShotPlanningEngine } from '../builder/creative/shotPlanningEngine';
import { DeviceCapabilityProfiler } from '../builder/creative/deviceCapabilityProfiler';
import { CameraMovementType, SpeedCurveType } from '../builder/creative/creativeStudioTypes';

interface GodexCameraStudioWorkspaceProps {
  onApplyShotToJob?: (spec: CameraShotSpec) => void;
  initialPrompt?: string;
}

export const GodexCameraStudioWorkspace: React.FC<GodexCameraStudioWorkspaceProps> = ({
  onApplyShotToJob,
  initialPrompt = 'Cinematic close-up portrait, 85mm lens, f/1.4 shallow depth of field, slow dolly in, ARRI Alexa'
}) => {
  const opticalEngine = useMemo(() => OpticalSimulationEngine.getInstance(), []);
  const continuityEngine = useMemo(() => CameraContinuityEngine.getInstance(), []);
  const cameraControl = useMemo(() => CameraControlEngine.getInstance(), []);
  const promptExtractor = useMemo(() => PromptCameraExtractor.getInstance(), []);
  const shotPlanner = useMemo(() => ShotPlanningEngine.getInstance(), []);
  const deviceProfiler = useMemo(() => DeviceCapabilityProfiler.getInstance(), []);

  // --- Active State ---
  const [selectedBodyId, setSelectedBodyId] = useState<string>('arri-alexa-mini-lf');
  const [selectedLensId, setSelectedLensId] = useState<string>('arri-master-prime-35');
  const [focalLengthMm, setFocalLengthMm] = useState<number>(35);
  const [apertureFStop, setApertureFStop] = useState<number>(1.4);
  const [focusDistanceMeters, setFocusDistanceMeters] = useState<number>(2.5);
  const [iso, setIso] = useState<number>(800);
  const [shutterAngleDeg, setShutterAngleDeg] = useState<number>(180);
  const [fps, setFps] = useState<24 | 25 | 30 | 48 | 60 | 120>(24);

  // 3D Pose & Kinematics
  const [cameraHeight, setCameraHeight] = useState<number>(1.6);
  const [cameraPan, setCameraPan] = useState<number>(0);
  const [cameraTilt, setCameraTilt] = useState<number>(0);
  const [cameraRoll, setCameraRoll] = useState<number>(0);
  const [movementType, setMovementType] = useState<CameraMovementType>('DOLLY_IN');
  const [movementIntensity, setMovementIntensity] = useState<number>(6);
  const [speedCurve, setSpeedCurve] = useState<SpeedCurveType>('EASE_IN_OUT');
  const [shotArchetype, setShotArchetype] = useState<ShotArchetype>('MCU');

  // Interactive Prompt Analysis
  const [promptText, setPromptText] = useState<string>(initialPrompt);
  const [activeTab, setActiveTab] = useState<'OPTICS' | 'KINEMATICS' | 'SHOTS_CONTINUITY' | 'PROMPT_PARSER'>('OPTICS');

  // Preview animation
  const [isPlayingTrajectory, setIsPlayingTrajectory] = useState<boolean>(false);
  const [trajectoryProgress, setTrajectoryProgress] = useState<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Multi-Shot Sequence
  const [plannedShots, setPlannedShots] = useState<CameraShotSpec[]>([]);
  const [continuityReport, setContinuityReport] = useState<CameraContinuityReport | null>(null);

  // Active Profiles
  const currentBody: CameraBodyProfile = CAMERA_BODIES[selectedBodyId] || opticalEngine.getDefaultCamera();
  const currentLens: LensProfile = CINE_LENSES[selectedLensId] || opticalEngine.getDefaultLens();

  // Optical Calculations (Deterministic Physics)
  const opticalParams = useMemo(() => {
    return opticalEngine.computeOpticalParameters(
      currentBody,
      currentLens,
      focalLengthMm,
      apertureFStop,
      focusDistanceMeters,
      iso
    );
  }, [opticalEngine, currentBody, currentLens, focalLengthMm, apertureFStop, focusDistanceMeters, iso]);

  // Prompt Extraction
  const promptAnalysis: PromptCameraExtraction = useMemo(() => {
    return promptExtractor.extractCameraIntent(promptText);
  }, [promptExtractor, promptText]);

  // Waypoints Calculation
  const waypoints = useMemo(() => {
    return cameraControl.generateTrajectoryWaypoints(
      {
        heightMeters: cameraHeight,
        distanceToSubjectMeters: focusDistanceMeters,
        panDeg: cameraPan,
        tiltDeg: cameraTilt,
        rollDeg: cameraRoll
      },
      {
        movementType,
        intensity: movementIntensity,
        speedCurve
      },
      4.0,
      focalLengthMm,
      12
    );
  }, [cameraControl, cameraHeight, focusDistanceMeters, cameraPan, cameraTilt, cameraRoll, movementType, movementIntensity, speedCurve, focalLengthMm]);

  // Sync lens selection to default focal length
  const handleLensChange = (lensId: string) => {
    setSelectedLensId(lensId);
    const l = CINE_LENSES[lensId];
    if (l) {
      setFocalLengthMm(l.focalLengthMm);
      setApertureFStop(l.maxApertureFStop);
    }
  };

  // Generate Multi-Shot sequence
  const handlePlanMultiShotScene = () => {
    const planResult = shotPlanner.planCinematicScene(
      {
        prompt: promptText,
        cameraMovement: movementType,
        subjectMotionIntensity: movementIntensity,
        durationSec: 8,
        aspectRatio: '16:9',
        resolution: '1080p'
      },
      {
        cameraBodyId: selectedBodyId,
        lensId: selectedLensId,
        focalLengthMm,
        apertureFStop,
        focusDistanceMeters,
        iso,
        totalDurationSec: 8
      }
    );
    setPlannedShots(planResult.shots);
    setContinuityReport(planResult.continuityReport);
  };

  // Apply Prompt Extraction to Active Camera
  const handleApplyPromptToCamera = () => {
    if (typeof promptAnalysis.focalLengthMm === 'number') {
      setFocalLengthMm(promptAnalysis.focalLengthMm);
    }
    if (typeof promptAnalysis.apertureFStop === 'number') {
      setApertureFStop(promptAnalysis.apertureFStop);
    }
    if (promptAnalysis.cameraMovement !== 'UNKNOWN') {
      setMovementType(promptAnalysis.cameraMovement as CameraMovementType);
    }
    if (promptAnalysis.archetype !== 'UNKNOWN') {
      setShotArchetype(promptAnalysis.archetype as ShotArchetype);
    }
    if (promptAnalysis.cameraBodyHint) {
      const lower = promptAnalysis.cameraBodyHint.toLowerCase();
      if (lower.includes('red')) setSelectedBodyId('red-v-raptor-vv');
      else if (lower.includes('imax')) setSelectedBodyId('imax-65mm-15perf');
      else if (lower.includes('sony')) setSelectedBodyId('sony-venice-2');
      else setSelectedBodyId('arri-alexa-mini-lf');
    }
  };

  // Trajectory Playback loop
  useEffect(() => {
    let animId: number;
    if (isPlayingTrajectory) {
      let startTime = performance.now();
      const loop = (now: number) => {
        const elapsed = (now - startTime) / 1000;
        const progress = (elapsed % 4.0) / 4.0;
        setTrajectoryProgress(progress);
        animId = requestAnimationFrame(loop);
      };
      animId = requestAnimationFrame(loop);
    } else {
      setTrajectoryProgress(0);
    }
    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [isPlayingTrajectory]);

  // Render Optical Simulation to Canvas Preview
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear
    ctx.fillStyle = '#060A14';
    ctx.fillRect(0, 0, width, height);

    // Draw Simulated Horizon & Subject Focus Circle
    const horizonY = height * 0.5 - (cameraTilt * 1.5);
    const panOffset = cameraPan * 2.0;

    // Background Depth Grid
    ctx.save();
    ctx.strokeStyle = '#1E293B';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, horizonY);
    ctx.lineTo(width, horizonY);
    ctx.stroke();

    // Perspective lines
    for (let x = -width; x <= width * 2; x += 40) {
      ctx.beginPath();
      ctx.moveTo(width / 2 + panOffset, horizonY);
      ctx.lineTo(x, height);
      ctx.strokeStyle = '#0F172A';
      ctx.stroke();
    }
    ctx.restore();

    // Subject Focal Anchor Disc (Simulating DOF bokeh circle)
    const currentWaypointIndex = Math.min(
      waypoints.length - 1,
      Math.floor(trajectoryProgress * waypoints.length)
    );
    const activePose = isPlayingTrajectory ? waypoints[currentWaypointIndex]?.pose : {
      heightMeters: cameraHeight,
      distanceToSubjectMeters: focusDistanceMeters,
      panDeg: cameraPan,
      tiltDeg: cameraTilt,
      rollDeg: cameraRoll
    };

    const subjectX = width / 2 + (activePose.panDeg * 2.5);
    const subjectY = height * 0.55 - (activePose.tiltDeg * 2.0);
    const subjectScale = Math.max(0.4, Math.min(2.5, 4.0 / Math.max(0.5, activePose.distanceToSubjectMeters)));

    // Bokeh Disc of Confusion representation
    ctx.save();
    const blurRadius = Math.max(2, (apertureFStop < 2.0 ? 12 : 4) * (1.0 / subjectScale));
    ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
    ctx.beginPath();
    ctx.arc(subjectX, subjectY, 28 * subjectScale, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#38BDF8';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(subjectX, subjectY, 20 * subjectScale, 0, Math.PI * 2);
    ctx.stroke();

    // Subject text
    ctx.fillStyle = '#E2E8F0';
    ctx.font = '10px ui-monospace, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`FOCAL TARGET (${focusDistanceMeters}m)`, subjectX, subjectY + 35 * subjectScale);
    ctx.restore();

    // Apply Real Optical Simulation (Vignette, Anamorphic Streak, Grain)
    const isMobile = deviceProfiler.isMobileDevice();
    opticalEngine.renderOpticalPreviewToCanvas(ctx, width, height, opticalParams, isMobile);

    // Draw Rule of Thirds Overlays
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.strokeRect(width * 0.333, 0, 1, height);
    ctx.strokeRect(width * 0.666, 0, 1, height);
    ctx.strokeRect(0, height * 0.333, width, 1);
    ctx.strokeRect(0, height * 0.666, width, 1);
    ctx.restore();

    // Top HUD
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.fillRect(8, 8, width - 16, 22);
    ctx.fillStyle = '#10B981';
    ctx.font = '10px ui-monospace, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`FPS: ${fps} | SHUTTER: ${shutterAngleDeg}° (1/${fps * 2}s) | ISO: ${iso} | ${currentBody.sensorFormat}`, 14, 23);
    ctx.textAlign = 'right';
    ctx.fillText(`${focalLengthMm}mm | f/${apertureFStop} | FOV: ${opticalParams.fov.horizontalDeg}°`, width - 14, 23);
  }, [
    opticalEngine,
    opticalParams,
    cameraTilt,
    cameraPan,
    cameraRoll,
    cameraHeight,
    focusDistanceMeters,
    apertureFStop,
    focalLengthMm,
    fps,
    shutterAngleDeg,
    iso,
    currentBody,
    isPlayingTrajectory,
    trajectoryProgress,
    waypoints,
    deviceProfiler
  ]);

  return (
    <div id="godex-camera-studio-workspace" className="flex flex-col h-full bg-[#050A14] text-neutral-200 overflow-hidden font-sans border-t border-[#141F36]">
      {/* Top Header Bar */}
      <div className="flex flex-wrap items-center justify-between px-3 sm:px-4 py-2.5 bg-[#090F1D] border-b border-[#142342] gap-2 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="p-1.5 rounded-md bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 shrink-0">
            <Camera className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h2 className="text-xs sm:text-sm font-bold text-white tracking-wide truncate flex items-center gap-2">
              <span>Cinematic Camera & Optical Studio</span>
              <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                P4.8 PRODUCTION
              </span>
            </h2>
            <p className="text-[10px] text-neutral-400 truncate">
              Physical optics • {currentBody.name} • {currentLens.name}
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 overflow-x-auto max-w-full">
          <button
            onClick={() => setActiveTab('OPTICS')}
            className={`px-2.5 py-1 rounded text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'OPTICS'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-[#121E36]'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Optics & DOF</span>
          </button>
          <button
            onClick={() => setActiveTab('KINEMATICS')}
            className={`px-2.5 py-1 rounded text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'KINEMATICS'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-[#121E36]'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>3D Kinematics</span>
          </button>
          <button
            onClick={() => setActiveTab('SHOTS_CONTINUITY')}
            className={`px-2.5 py-1 rounded text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'SHOTS_CONTINUITY'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-[#121E36]'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Shots & Continuity</span>
          </button>
          <button
            onClick={() => setActiveTab('PROMPT_PARSER')}
            className={`px-2.5 py-1 rounded text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'PROMPT_PARSER'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-[#121E36]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-300" />
            <span>Prompt Extractor</span>
          </button>
        </div>
      </div>

      {/* Main Workspace Body */}
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-y-auto lg:overflow-hidden">
        {/* Left Side: Control Matrix */}
        <div className="w-full lg:w-[420px] xl:w-[460px] flex flex-col border-b lg:border-b-0 lg:border-r border-[#142342] bg-[#070D1B] shrink-0 overflow-y-auto p-3 sm:p-4 space-y-4">
          
          {/* TAB 1: OPTICS & SENSOR */}
          {activeTab === 'OPTICS' && (
            <div className="space-y-4 text-xs font-mono">
              {/* Camera Body Selection */}
              <div className="space-y-1.5 bg-[#0B1326] p-3 rounded-lg border border-[#16274D]">
                <label className="text-[11px] font-bold text-cyan-300 flex items-center justify-between">
                  <span>CAMERA BODY & SENSOR</span>
                  <span className="text-[10px] text-neutral-400">{currentBody.cropFactorVsFullFrame}x Crop</span>
                </label>
                <select
                  value={selectedBodyId}
                  onChange={e => setSelectedBodyId(e.target.value)}
                  className="w-full bg-[#050A14] border border-[#1E3360] rounded-md px-2.5 py-1.5 text-neutral-200 text-xs focus:outline-none focus:border-cyan-500"
                >
                  {Object.values(CAMERA_BODIES).map(body => (
                    <option key={body.id} value={body.id}>
                      {body.name} ({body.sensorWidthMm}x{body.sensorHeightMm}mm)
                    </option>
                  ))}
                </select>
                <div className="grid grid-cols-2 gap-2 text-[10px] text-neutral-400 pt-1">
                  <div>Format: <span className="text-neutral-200">{currentBody.sensorFormat}</span></div>
                  <div>Dynamic Range: <span className="text-neutral-200">{currentBody.baseDynamicRangeStops} stops</span></div>
                  <div>Color Science: <span className="text-neutral-300 col-span-2 truncate">{currentBody.colorScience}</span></div>
                </div>
              </div>

              {/* Lens Selection */}
              <div className="space-y-1.5 bg-[#0B1326] p-3 rounded-lg border border-[#16274D]">
                <label className="text-[11px] font-bold text-cyan-300 flex items-center justify-between">
                  <span>CINE LENS PRESET</span>
                  <span className="text-[10px] text-neutral-400">
                    {currentLens.anamorphicSqueezeRatio > 1 ? `${currentLens.anamorphicSqueezeRatio}x Anamorphic` : 'Spherical'}
                  </span>
                </label>
                <select
                  value={selectedLensId}
                  onChange={e => handleLensChange(e.target.value)}
                  className="w-full bg-[#050A14] border border-[#1E3360] rounded-md px-2.5 py-1.5 text-neutral-200 text-xs focus:outline-none focus:border-cyan-500"
                >
                  {Object.values(CINE_LENSES).map(lens => (
                    <option key={lens.id} value={lens.id}>
                      {lens.name} (T{lens.maxApertureFStop})
                    </option>
                  ))}
                </select>
              </div>

              {/* Focal Length Slider */}
              <div className="space-y-1.5 bg-[#0B1326] p-3 rounded-lg border border-[#16274D]">
                <div className="flex items-center justify-between text-neutral-300">
                  <span className="font-bold text-neutral-200">FOCAL LENGTH</span>
                  <span className="text-cyan-400 font-bold">{focalLengthMm}mm</span>
                </div>
                <input
                  type="range"
                  min={12}
                  max={200}
                  step={1}
                  value={focalLengthMm}
                  onChange={e => setFocalLengthMm(Number(e.target.value))}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
                <div className="flex flex-wrap gap-1 pt-1">
                  {[18, 24, 35, 50, 85, 100, 135].map(mm => (
                    <button
                      key={mm}
                      onClick={() => setFocalLengthMm(mm)}
                      className={`px-1.5 py-0.5 rounded text-[10px] border ${
                        focalLengthMm === mm
                          ? 'bg-cyan-600/30 border-cyan-400 text-cyan-300 font-bold'
                          : 'bg-[#050A14] border-[#16274D] text-neutral-400 hover:text-white'
                      }`}
                    >
                      {mm}mm
                    </button>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-2 text-[10px] text-neutral-400 pt-1 border-t border-[#142342]">
                  <div>Horizontal FOV: <span className="text-cyan-300 font-semibold">{opticalParams.fov.horizontalDeg}°</span></div>
                  <div>35mm Equiv: <span className="text-neutral-200">{opticalParams.fov.focalLength35mmEquivalentMm}mm</span></div>
                </div>
              </div>

              {/* Aperture (f-stop) */}
              <div className="space-y-1.5 bg-[#0B1326] p-3 rounded-lg border border-[#16274D]">
                <div className="flex items-center justify-between text-neutral-300">
                  <span className="font-bold text-neutral-200">APERTURE (F-STOP)</span>
                  <span className="text-emerald-400 font-bold">f/{apertureFStop}</span>
                </div>
                <input
                  type="range"
                  min={1.2}
                  max={22}
                  step={0.1}
                  value={apertureFStop}
                  onChange={e => setApertureFStop(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <div className="flex flex-wrap gap-1 pt-1">
                  {[1.2, 1.4, 2.0, 2.8, 4.0, 5.6, 8.0, 11, 16].map(f => (
                    <button
                      key={f}
                      onClick={() => setApertureFStop(f)}
                      className={`px-1.5 py-0.5 rounded text-[10px] border ${
                        Math.abs(apertureFStop - f) < 0.1
                          ? 'bg-emerald-600/30 border-emerald-400 text-emerald-300 font-bold'
                          : 'bg-[#050A14] border-[#16274D] text-neutral-400 hover:text-white'
                      }`}
                    >
                      f/{f}
                    </button>
                  ))}
                </div>
              </div>

              {/* Focus Distance */}
              <div className="space-y-1.5 bg-[#0B1326] p-3 rounded-lg border border-[#16274D]">
                <div className="flex items-center justify-between text-neutral-300">
                  <span className="font-bold text-neutral-200">FOCUS DISTANCE</span>
                  <span className="text-amber-400 font-bold">{focusDistanceMeters} meters</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={20}
                  step={0.1}
                  value={focusDistanceMeters}
                  onChange={e => setFocusDistanceMeters(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
                <div className="flex gap-1 pt-1">
                  {[0.8, 1.5, 2.5, 5.0, 10.0].map(m => (
                    <button
                      key={m}
                      onClick={() => setFocusDistanceMeters(m)}
                      className={`px-2 py-0.5 rounded text-[10px] border ${
                        focusDistanceMeters === m
                          ? 'bg-amber-600/30 border-amber-400 text-amber-300 font-bold'
                          : 'bg-[#050A14] border-[#16274D] text-neutral-400 hover:text-white'
                      }`}
                    >
                      {m}m
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: 3D KINEMATICS & POSE */}
          {activeTab === 'KINEMATICS' && (
            <div className="space-y-4 text-xs font-mono">
              {/* Movement Type */}
              <div className="space-y-1.5 bg-[#0B1326] p-3 rounded-lg border border-[#16274D]">
                <label className="text-[11px] font-bold text-cyan-300 flex items-center justify-between">
                  <span>CAMERA TRAJECTORY TYPE</span>
                  <Compass className="w-3.5 h-3.5 text-cyan-400" />
                </label>
                <select
                  value={movementType}
                  onChange={e => setMovementType(e.target.value as CameraMovementType)}
                  className="w-full bg-[#050A14] border border-[#1E3360] rounded-md px-2.5 py-1.5 text-neutral-200 text-xs focus:outline-none focus:border-cyan-500"
                >
                  <option value="DOLLY_IN">Dolly In (Push Forward)</option>
                  <option value="DOLLY_OUT">Dolly Out (Pull Back)</option>
                  <option value="PAN_RIGHT">Pan Right (Smooth Lateral)</option>
                  <option value="PAN_LEFT">Pan Left (Smooth Lateral)</option>
                  <option value="TILT_UP">Tilt Up (Vertical Pan)</option>
                  <option value="TILT_DOWN">Tilt Down (Vertical Pan)</option>
                  <option value="TRUCK_RIGHT">Truck Right (Lateral Track)</option>
                  <option value="TRUCK_LEFT">Truck Left (Lateral Track)</option>
                  <option value="ORBIT_360">Orbital 360° Arc</option>
                  <option value="CRANE_UP">Crane Up (Ascend Boom)</option>
                  <option value="CRANE_DOWN">Crane Down (Descend Boom)</option>
                  <option value="ZOOM_PULL">Cinematic Zoom Pull</option>
                  <option value="TRACKING_SHOT">Tracking Shot (Subject Follow)</option>
                  <option value="DEPTH_AWARE_MOVEMENT">Depth-Aware Parallax Flow</option>
                  <option value="HANDHELD_DYNAMIC">Handheld Dynamic Run</option>
                  <option value="STATIC">Static Locked Tripod</option>
                </select>
              </div>

              {/* Speed Curve & Intensity */}
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1 bg-[#0B1326] p-2.5 rounded-lg border border-[#16274D]">
                  <label className="text-[10px] text-neutral-400">SPEED CURVE</label>
                  <select
                    value={speedCurve}
                    onChange={e => setSpeedCurve(e.target.value as SpeedCurveType)}
                    className="w-full bg-[#050A14] border border-[#1E3360] rounded px-2 py-1 text-neutral-200 text-xs"
                  >
                    <option value="EASE_IN_OUT">Ease In Out</option>
                    <option value="LINEAR">Linear Constant</option>
                    <option value="EXPONENTIAL">Exponential Ramp</option>
                    <option value="SMOOTH_RAMP">Smooth Ramp</option>
                  </select>
                </div>
                <div className="space-y-1 bg-[#0B1326] p-2.5 rounded-lg border border-[#16274D]">
                  <div className="flex justify-between text-[10px] text-neutral-400">
                    <span>INTENSITY</span>
                    <span className="text-cyan-300 font-bold">{movementIntensity}/10</span>
                  </div>
                  <input
                    type="range"
                    min={1}
                    max={10}
                    value={movementIntensity}
                    onChange={e => setMovementIntensity(Number(e.target.value))}
                    className="w-full accent-cyan-500 cursor-pointer pt-1"
                  />
                </div>
              </div>

              {/* Physical Pose Controls (Height, Pan, Tilt, Roll) */}
              <div className="space-y-2.5 bg-[#0B1326] p-3 rounded-lg border border-[#16274D]">
                <div className="text-[11px] font-bold text-neutral-300">SPATIAL POSE (ORIGIN)</div>
                
                <div>
                  <div className="flex justify-between text-[10px] text-neutral-400">
                    <span>Camera Height (m)</span>
                    <span className="text-neutral-200">{cameraHeight}m</span>
                  </div>
                  <input
                    type="range"
                    min={0.3}
                    max={5.0}
                    step={0.1}
                    value={cameraHeight}
                    onChange={e => setCameraHeight(Number(e.target.value))}
                    className="w-full accent-neutral-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[10px] text-neutral-400">
                    <span>Pan Yaw (°)</span>
                    <span className="text-neutral-200">{cameraPan}°</span>
                  </div>
                  <input
                    type="range"
                    min={-90}
                    max={90}
                    value={cameraPan}
                    onChange={e => setCameraPan(Number(e.target.value))}
                    className="w-full accent-neutral-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[10px] text-neutral-400">
                    <span>Tilt Pitch (°)</span>
                    <span className="text-neutral-200">{cameraTilt}°</span>
                  </div>
                  <input
                    type="range"
                    min={-45}
                    max={45}
                    value={cameraTilt}
                    onChange={e => setCameraTilt(Number(e.target.value))}
                    className="w-full accent-neutral-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[10px] text-neutral-400">
                    <span>Roll / Dutch Angle (°)</span>
                    <span className="text-neutral-200">{cameraRoll}°</span>
                  </div>
                  <input
                    type="range"
                    min={-30}
                    max={30}
                    value={cameraRoll}
                    onChange={e => setCameraRoll(Number(e.target.value))}
                    className="w-full accent-neutral-400"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SHOTS & CONTINUITY */}
          {activeTab === 'SHOTS_CONTINUITY' && (
            <div className="space-y-4 text-xs font-mono">
              <div className="flex items-center justify-between">
                <button
                  onClick={handlePlanMultiShotScene}
                  className="w-full py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold rounded-lg shadow-sm flex items-center justify-center gap-2"
                >
                  <Film className="w-4 h-4" />
                  <span>Synthesize Multi-Shot Sequence</span>
                </button>
              </div>

              {/* Continuity Audit Summary */}
              {continuityReport && (
                <div className={`p-3 rounded-lg border ${
                  continuityReport.passed
                    ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                    : 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                }`}>
                  <div className="flex items-center justify-between font-bold text-[11px] pb-1">
                    <span className="flex items-center gap-1.5">
                      {continuityReport.passed ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
                      Continuity Score: {continuityReport.score}/100
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/40">
                      {continuityReport.totalShots} Shots
                    </span>
                  </div>
                  <p className="text-[10px] text-neutral-300 leading-relaxed">
                    {continuityReport.summary}
                  </p>

                  {/* Issues list */}
                  {continuityReport.issues.length > 0 && (
                    <div className="mt-2 space-y-1.5 pt-2 border-t border-white/10">
                      {continuityReport.issues.map((iss, idx) => (
                        <div key={idx} className="bg-black/30 p-2 rounded text-[10px]">
                          <div className="font-bold text-amber-400">{iss.title} ({iss.severity})</div>
                          <div className="text-neutral-400">{iss.description}</div>
                          <div className="text-cyan-300 mt-1">Rec: {iss.recommendation}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Planned Shots List */}
              {plannedShots.length > 0 && (
                <div className="space-y-2">
                  <div className="text-[11px] font-bold text-neutral-300">GENERATED SHOT SPECIFICATIONS</div>
                  {plannedShots.map((shot, idx) => (
                    <div key={shot.shotId} className="bg-[#0B1326] p-2.5 rounded-lg border border-[#16274D] space-y-1">
                      <div className="flex items-center justify-between font-bold text-cyan-300 text-[11px]">
                        <span>Shot {idx + 1}: {shot.archetype} ({shot.focalLengthMm}mm)</span>
                        <span className="text-neutral-400 text-[10px]">{shot.durationSec}s</span>
                      </div>
                      <div className="text-[10px] text-neutral-400">
                        {shot.cameraBody.name} • f/{shot.apertureFStop} • {shot.kinematics.movementType}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: PROMPT EXTRACTOR */}
          {activeTab === 'PROMPT_PARSER' && (
            <div className="space-y-4 text-xs font-mono">
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-purple-300 flex items-center justify-between">
                  <span>PROMPT TO CAMERA INTELLIGENCE</span>
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                </label>
                <textarea
                  value={promptText}
                  onChange={e => setPromptText(e.target.value)}
                  rows={3}
                  className="w-full bg-[#050A14] border border-[#1E3360] rounded-md p-2 text-neutral-200 text-xs focus:outline-none focus:border-purple-500"
                  placeholder="Enter cinematic description..."
                />
              </div>

              {/* Extraction Evidence */}
              <div className="bg-[#0B1326] p-3 rounded-lg border border-[#16274D] space-y-2">
                <div className="flex items-center justify-between text-[11px] font-bold text-neutral-300">
                  <span>PARSED CAMERA ATTRIBUTES</span>
                  <span className="text-purple-400 text-[10px]">
                    Confidence: {(promptAnalysis.confidence.overall * 100).toFixed(0)}%
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px] text-neutral-400">
                  <div>Focal Length: <span className="text-cyan-300 font-bold">{promptAnalysis.focalLengthMm}</span></div>
                  <div>Aperture: <span className="text-emerald-300 font-bold">{promptAnalysis.apertureFStop}</span></div>
                  <div>Archetype: <span className="text-amber-300 font-bold">{promptAnalysis.archetype}</span></div>
                  <div>Movement: <span className="text-pink-300 font-bold">{promptAnalysis.cameraMovement}</span></div>
                </div>

                {promptAnalysis.cameraBodyHint && (
                  <div className="text-[10px] text-neutral-400">
                    Camera Body Hint: <span className="text-neutral-200 font-semibold">{promptAnalysis.cameraBodyHint}</span>
                  </div>
                )}

                <button
                  onClick={handleApplyPromptToCamera}
                  className="w-full mt-2 py-1.5 bg-purple-700 hover:bg-purple-600 text-white font-bold rounded text-xs transition-colors"
                >
                  Apply Extracted Intent to Active Camera
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Side: Viewport & Optical Telemetry */}
        <div className="flex-1 min-w-0 flex flex-col bg-[#030712] overflow-y-auto p-3 sm:p-4 space-y-4">
          
          {/* Real-time Optical Preview Stage */}
          <div className="relative w-full aspect-video max-h-[380px] bg-[#02050D] rounded-xl border border-[#16274D] overflow-hidden flex items-center justify-center shadow-lg">
            <canvas
              ref={canvasRef}
              width={640}
              height={360}
              className="w-full h-full object-contain"
            />

            {/* Trajectory Play / Scrub Overlay */}
            <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 text-xs">
              <button
                onClick={() => setIsPlayingTrajectory(!isPlayingTrajectory)}
                className="flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 font-bold"
              >
                {isPlayingTrajectory ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isPlayingTrajectory ? 'Pause Trajectory' : 'Play Trajectory (4s)'}</span>
              </button>

              <div className="text-[10px] text-neutral-400 font-mono">
                {currentLens.name} • {opticalParams.fov.horizontalDeg}° H-FOV
              </div>
            </div>
          </div>

          {/* Optical Telemetry Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 font-mono text-xs">
            {/* 1. Depth of Field Card */}
            <div className="bg-[#070D1B] p-3 rounded-lg border border-[#142342] space-y-1">
              <div className="text-[10px] text-neutral-400 font-bold flex items-center gap-1">
                <Target className="w-3 h-3 text-cyan-400" />
                <span>TOTAL DOF</span>
              </div>
              <div className="text-sm font-bold text-white">
                {opticalParams.dof.totalDofMeters === 'INFINITY' ? '∞ Infinity' : `${opticalParams.dof.totalDofMeters}m`}
              </div>
              <div className="text-[9px] text-neutral-500">
                Near: {opticalParams.dof.nearLimitMeters}m • Far: {opticalParams.dof.farLimitMeters}m
              </div>
            </div>

            {/* 2. Hyperfocal Distance */}
            <div className="bg-[#070D1B] p-3 rounded-lg border border-[#142342] space-y-1">
              <div className="text-[10px] text-neutral-400 font-bold flex items-center gap-1">
                <CompassIcon className="w-3 h-3 text-emerald-400" />
                <span>HYPERFOCAL</span>
              </div>
              <div className="text-sm font-bold text-emerald-400">
                {opticalParams.dof.hyperfocalDistanceMeters}m
              </div>
              <div className="text-[9px] text-neutral-500">
                Sharp from {(opticalParams.dof.hyperfocalDistanceMeters / 2).toFixed(1)}m to ∞
              </div>
            </div>

            {/* 3. Circle of Confusion */}
            <div className="bg-[#070D1B] p-3 rounded-lg border border-[#142342] space-y-1">
              <div className="text-[10px] text-neutral-400 font-bold flex items-center gap-1">
                <Eye className="w-3 h-3 text-amber-400" />
                <span>CoC ZEISS</span>
              </div>
              <div className="text-sm font-bold text-amber-400">
                {opticalParams.dof.cocMm} mm
              </div>
              <div className="text-[9px] text-neutral-500">
                Scaled to {currentBody.sensorFormat}
              </div>
            </div>

            {/* 4. Bokeh Disc at Infinity */}
            <div className="bg-[#070D1B] p-3 rounded-lg border border-[#142342] space-y-1">
              <div className="text-[10px] text-neutral-400 font-bold flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-pink-400" />
                <span>BOKEH DISC</span>
              </div>
              <div className="text-sm font-bold text-pink-400">
                {opticalParams.dof.bokehDiameterAtInfinityMm} mm
              </div>
              <div className="text-[9px] text-neutral-500">
                Background blur circle diameter
              </div>
            </div>
          </div>

          {/* Epistemic Truth & Invariant Verification Banner */}
          <div className="p-3 rounded-lg bg-[#070E20] border border-cyan-500/20 text-neutral-300 text-xs flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <div className="font-bold text-white text-[11px] flex items-center gap-2">
                <span>Deterministic Cinematography Invariant Verified</span>
                <span className="px-1.5 py-0.2 rounded text-[9px] bg-emerald-500/20 text-emerald-300 font-mono">
                  LOCAL_DETERMINISTIC
                </span>
              </div>
              <p className="text-[10px] text-neutral-400 leading-relaxed font-mono">
                Field of View, Depth of Field, Zeiss CoC, and 3D Trajectories execute 100% locally via physical trigonometry. If generating neural video, backend engine status is truthfully verified.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
