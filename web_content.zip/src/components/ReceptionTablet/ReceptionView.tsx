import React, { useState } from 'react';
import {
  DoorClosed,
  Users,
  CheckCircle2,
  Clock,
  Trash2,
  Sparkles,
  Smartphone,
  Eye,
  Heart,
  Church,
} from 'lucide-react';
import { useChurch } from '../../context/ChurchContext';
import { QuickVisitorForm } from './QuickVisitorForm';

export const ReceptionView: React.FC = () => {
  const { visitors, deleteVisitor, service } = useChurch();
  const [viewMode, setViewMode] = useState<'receptionist' | 'self_service'>('receptionist');

  const pendingVisitors = visitors.filter((v) => v.status === 'pending');
  const presentedVisitors = visitors.filter((v) => v.status === 'presented');

  return (
    <div className="min-h-[calc(100vh-105px)] bg-neutral-950 text-white p-3 sm:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Top Reception Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl bg-neutral-900/80 border border-neutral-800 p-4 sm:p-5">
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <DoorClosed className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                  Tablet da Porta / Recepção
                </h2>
                <span className="rounded-full bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 text-xs font-semibold text-emerald-400">
                  Pronto para Enviar
                </span>
              </div>
              <p className="text-xs sm:text-sm text-neutral-400">
                Cadastre os visitantes na chegada. Os nomes surgem no tablet do altar em tempo real.
              </p>
            </div>
          </div>

          {/* Mode Switcher: Receptionist vs Self-Service Totem */}
          <div className="flex items-center gap-2 bg-neutral-950 p-1.5 rounded-2xl border border-neutral-800">
            <button
              onClick={() => setViewMode('receptionist')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition ${
                viewMode === 'receptionist'
                  ? 'bg-neutral-800 text-amber-400 shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Users className="h-4 w-4" />
              <span>Modo Recepção</span>
            </button>
            <button
              onClick={() => setViewMode('self_service')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition ${
                viewMode === 'self_service'
                  ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Smartphone className="h-4 w-4" />
              <span>Modo Totem Visitante</span>
            </button>
          </div>
        </div>

        {/* Self Service Totem View */}
        {viewMode === 'self_service' ? (
          <div className="max-w-2xl mx-auto rounded-3xl bg-neutral-900 border border-neutral-800 p-6 sm:p-10 shadow-2xl space-y-6">
            <div className="text-center space-y-2">
              <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-500/15 text-amber-400 border border-amber-500/30 mb-2">
                <Church className="h-7 w-7" />
              </div>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
                Seja Muito Bem-Vindo!
              </h3>
              <p className="text-sm sm:text-base text-neutral-300 max-w-md mx-auto">
                É uma honra receber você na casa do Senhor Jesus. Por favor, deixe seu nome abaixo para que o Pastor e a igreja possam orar por você e sua família!
              </p>
              <p className="text-xs text-amber-400/90 italic font-medium pt-1">
                &ldquo;Alegrei-me quando me disseram: Vamos à casa do SENHOR.&rdquo; — Salmos 122:1
              </p>
            </div>

            <QuickVisitorForm isSelfService={true} />
          </div>
        ) : (
          /* Standard Receptionist View: 2 Columns on Tablet / Desktop */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Quick Registration Form */}
            <div className="lg:col-span-7 bg-neutral-900/90 border border-neutral-800 rounded-3xl p-5 sm:p-7 shadow-xl">
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-neutral-800">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-amber-400" />
                    Novo Visitante Chegando
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Preencha e envie para o púlpito com 1 clique
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-neutral-400 block">Culto Atual</span>
                  <span className="text-xs font-semibold text-amber-400">{service.title}</span>
                </div>
              </div>

              <QuickVisitorForm isSelfService={false} />
            </div>

            {/* Right: Live List of Visitors Today */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-neutral-900/90 border border-neutral-800 rounded-3xl p-5 shadow-xl flex flex-col h-full max-h-[820px]">
                {/* Header & Counters */}
                <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
                  <div className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-amber-400" />
                    <h3 className="font-bold text-base text-white">Visitantes Hoje</h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                      {pendingVisitors.length} no Altar
                    </span>
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                      {presentedVisitors.length} Apresentados
                    </span>
                  </div>
                </div>

                {/* List container */}
                <div className="flex-1 overflow-y-auto divide-y divide-neutral-800/80 pr-1 mt-2 space-y-2">
                  {visitors.length === 0 ? (
                    <div className="py-16 text-center text-neutral-500 space-y-2">
                      <Users className="h-10 w-10 mx-auto text-neutral-600" />
                      <p className="text-sm font-medium">Nenhum visitante cadastrado ainda neste culto.</p>
                      <p className="text-xs text-neutral-500">
                        Os nomes enviados no formulário ao lado aparecerão aqui e no altar.
                      </p>
                    </div>
                  ) : (
                    visitors.map((visitor) => {
                      const isPresented = visitor.status === 'presented';
                      return (
                        <div
                          key={visitor.id}
                          className="pt-3 pb-3 flex items-start justify-between gap-3 group transition"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm sm:text-base text-white">
                                {visitor.name}
                              </span>
                              {visitor.companionCount > 0 && (
                                <span className="rounded-md bg-neutral-800 text-[11px] font-semibold text-neutral-300 px-1.5 py-0.5">
                                  +{visitor.companionCount}
                                </span>
                              )}
                              {visitor.isFirstTime && (
                                <span className="rounded-md bg-amber-500/20 text-[10px] font-bold text-amber-300 px-1.5 py-0.5 border border-amber-500/30">
                                  1ª Vez
                                </span>
                              )}
                            </div>

                            {/* Details subtitle */}
                            <div className="flex flex-wrap items-center gap-x-2 text-xs text-neutral-400">
                              {visitor.cityOrNeighborhood && (
                                <span>{visitor.cityOrNeighborhood}</span>
                              )}
                              {visitor.invitedBy && (
                                <>
                                  <span>•</span>
                                  <span>Convite: {visitor.invitedBy}</span>
                                </>
                              )}
                            </div>

                            {/* Status Pill */}
                            <div className="pt-1">
                              {isPresented ? (
                                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 text-[11px] font-semibold text-emerald-400">
                                  <CheckCircle2 className="h-3 w-3" /> Já Apresentado pelo Pastor
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 text-[11px] font-semibold text-amber-300 animate-pulse">
                                  <Clock className="h-3 w-3" /> No Altar (Aguardando Saudação)
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Delete accidental entry button */}
                          <button
                            onClick={() => {
                              if (confirm(`Remover visitante "${visitor.name}"?`)) {
                                deleteVisitor(visitor.id);
                              }
                            }}
                            className="opacity-60 hover:opacity-100 p-2 text-neutral-500 hover:text-rose-400 hover:bg-neutral-800 rounded-lg transition"
                            title="Excluir cadastro"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
