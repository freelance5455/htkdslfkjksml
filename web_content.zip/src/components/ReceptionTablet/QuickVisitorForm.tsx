import React, { useState, useRef } from 'react';
import {
  Send,
  User,
  Phone,
  MapPin,
  HeartHandshake,
  Users,
  Sparkles,
  CheckCircle2,
  Crown,
  Smile,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useChurch } from '../../context/ChurchContext';
import { formatPhoneNumber } from '../../utils/whatsapp';
import { VisitorCategory } from '../../types';

interface Props {
  isSelfService?: boolean;
}

export const QuickVisitorForm: React.FC<Props> = ({ isSelfService = false }) => {
  const { addVisitor, service } = useChurch();

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [cityOrNeighborhood, setCityOrNeighborhood] = useState('');
  const [companionCount, setCompanionCount] = useState<number>(0);
  const [companionsDetails, setCompanionsDetails] = useState('');
  const [invitedBy, setInvitedBy] = useState('');
  const [isFirstTime, setIsFirstTime] = useState<boolean>(true);
  const [category, setCategory] = useState<VisitorCategory>('adulto');
  const [prayerRequest, setPrayerRequest] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastSubmittedName, setLastSubmittedName] = useState<string | null>(null);

  const nameInputRef = useRef<HTMLInputElement>(null);

  const commonInvites = [
    'Membro da Igreja',
    'Amigo / Vizinho',
    'Familiar',
    'Redes Sociais / Instagram',
    'Passando em frente',
  ];

  const categories: { id: VisitorCategory; label: string; icon: React.ReactNode }[] = [
    { id: 'adulto', label: 'Visitante Geral', icon: <Smile className="h-4 w-4" /> },
    { id: 'pastor_lider', label: 'Pastor / Líder Visitante', icon: <Crown className="h-4 w-4 text-amber-400" /> },
    { id: 'jovem', label: 'Jovem / Adolescente', icon: <Sparkles className="h-4 w-4 text-cyan-400" /> },
    { id: 'melhor_idade', label: 'Melhor Idade', icon: <HeartHandshake className="h-4 w-4 text-rose-400" /> },
  ];

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPhone(formatPhoneNumber(e.target.value));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsSubmitting(true);

    const success = await addVisitor({
      name: name.trim(),
      phone: phone.trim() || undefined,
      cityOrNeighborhood: cityOrNeighborhood.trim() || undefined,
      companionCount,
      companionsDetails: companionsDetails.trim() || undefined,
      invitedBy: invitedBy.trim() || undefined,
      isFirstTime,
      category,
      prayerRequest: prayerRequest.trim() || undefined,
    });

    setIsSubmitting(false);

    if (success) {
      setLastSubmittedName(name.trim());

      // Trigger pleasant burst of festive confetti
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.7 },
          colors: ['#f59e0b', '#10b981', '#3b82f6', '#ec4899'],
        });
      } catch (err) {
        // ignore if blocked
      }

      // Reset form
      setName('');
      setPhone('');
      setCityOrNeighborhood('');
      setCompanionCount(0);
      setCompanionsDetails('');
      setInvitedBy('');
      setIsFirstTime(true);
      setCategory('adulto');
      setPrayerRequest('');

      // Auto clear success message after 4s
      setTimeout(() => {
        setLastSubmittedName(null);
      }, 5000);

      // Refocus name input for rapid next entry
      setTimeout(() => {
        nameInputRef.current?.focus();
      }, 100);
    }
  };

  return (
    <div className="w-full">
      {/* Success Notification Banner */}
      {lastSubmittedName && (
        <div className="mb-4 flex items-center justify-between rounded-2xl bg-emerald-500/15 border border-emerald-500/30 p-4 text-emerald-200 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-7 w-7 text-emerald-400 shrink-0" />
            <div>
              <p className="font-bold text-base text-white">
                Visitante enviado ao Altar com sucesso!
              </p>
              <p className="text-xs text-emerald-300">
                O nome de <strong>&quot;{lastSubmittedName}&quot;</strong> já está na tela do Pastor Dirigente no púlpito.
              </p>
            </div>
          </div>
          <button
            onClick={() => setLastSubmittedName(null)}
            className="text-xs font-semibold text-emerald-400 hover:text-white px-2 py-1"
          >
            Fechar
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Visitor Full Name - Touch Huge Input */}
        <div>
          <label className="block text-sm font-bold text-neutral-200 mb-1.5 flex items-center gap-2">
            <User className="h-4 w-4 text-amber-400" />
            <span>Nome Completo do Visitante *</span>
          </label>
          <input
            ref={nameInputRef}
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ex: João da Silva ou Família Rodrigues"
            required
            autoFocus
            className="w-full rounded-2xl bg-neutral-900 border-2 border-neutral-700/80 px-4 py-3.5 text-base sm:text-lg font-medium text-white placeholder-neutral-500 shadow-inner focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition"
          />
        </div>

        {/* Two-Column Grid for Neighborhood & Phone */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1 flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 text-amber-400" />
              <span>Bairro ou Cidade de onde veio</span>
            </label>
            <input
              type="text"
              value={cityOrNeighborhood}
              onChange={(e) => setCityOrNeighborhood(e.target.value)}
              placeholder="Ex: Centro / Bairro Esperança"
              className="w-full rounded-xl bg-neutral-900 border border-neutral-700/80 px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1 flex items-center gap-1.5">
              <Phone className="h-3.5 w-3.5 text-amber-400" />
              <span>WhatsApp / Telefone celular (Opcional)</span>
            </label>
            <input
              type="tel"
              value={phone}
              onChange={handlePhoneChange}
              maxLength={15}
              placeholder="(11) 99999-9999"
              className="w-full rounded-xl bg-neutral-900 border border-neutral-700/80 px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
            />
          </div>
        </div>

        {/* Companions / Family count */}
        <div className="rounded-2xl bg-neutral-900/60 border border-neutral-800 p-3.5 space-y-2.5">
          <label className="block text-xs font-semibold text-neutral-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Users className="h-4 w-4 text-amber-400" />
              <span>Veio acompanhado? (Quantos familiares/amigos?)</span>
            </span>
            <span className="text-amber-400 font-bold">
              {companionCount === 0 ? 'Sozinho(a)' : `+${companionCount} acompanhante(s)`}
            </span>
          </label>

          <div className="flex items-center gap-2">
            {[0, 1, 2, 3, 4, 5].map((num) => (
              <button
                type="button"
                key={num}
                onClick={() => setCompanionCount(num)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition ${
                  companionCount === num
                    ? 'bg-amber-500 text-neutral-950 shadow-sm'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                {num === 0 ? 'Sozinho' : `+${num}`}
              </button>
            ))}
          </div>

          {companionCount > 0 && (
            <input
              type="text"
              value={companionsDetails}
              onChange={(e) => setCompanionsDetails(e.target.value)}
              placeholder="Ex: Esposa Mariana e filho Pedro (8 anos)"
              className="w-full rounded-xl bg-neutral-900 border border-neutral-700/80 px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
            />
          )}
        </div>

        {/* Invited By */}
        <div>
          <label className="block text-xs font-semibold text-neutral-300 mb-1 flex items-center gap-1.5">
            <HeartHandshake className="h-3.5 w-3.5 text-amber-400" />
            <span>Quem convidou para o culto?</span>
          </label>
          <input
            type="text"
            value={invitedBy}
            onChange={(e) => setInvitedBy(e.target.value)}
            placeholder="Ex: Irmão Marcos, Pastor, Amigo de trabalho"
            className="w-full rounded-xl bg-neutral-900 border border-neutral-700/80 px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 mb-2"
          />
          <div className="flex flex-wrap gap-1.5">
            {commonInvites.map((chip) => (
              <button
                type="button"
                key={chip}
                onClick={() => setInvitedBy(chip)}
                className="rounded-lg bg-neutral-800 hover:bg-neutral-700 border border-neutral-700/70 px-2.5 py-1 text-[11px] text-neutral-300 transition"
              >
                {chip}
              </button>
            ))}
          </div>
        </div>

        {/* First time vs Returning + Special category */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {/* First time */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              É a primeira vez na igreja?
            </label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setIsFirstTime(true)}
                className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition ${
                  isFirstTime
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                    : 'bg-neutral-800/80 border-neutral-700 text-neutral-400 hover:bg-neutral-700'
                }`}
              >
                Sim, 1ª vez! ⭐
              </button>
              <button
                type="button"
                onClick={() => setIsFirstTime(false)}
                className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition ${
                  !isFirstTime
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                    : 'bg-neutral-800/80 border-neutral-700 text-neutral-400 hover:bg-neutral-700'
                }`}
              >
                Já visitei antes
              </button>
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Tipo de Visitante / Destaque
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as VisitorCategory)}
              className="w-full rounded-xl bg-neutral-800 border border-neutral-700 px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Prayer Request (Optional) */}
        <div>
          <label className="block text-xs font-semibold text-neutral-300 mb-1">
            Pedido de Oração ou Motivo Especial (Opcional)
          </label>
          <input
            type="text"
            value={prayerRequest}
            onChange={(e) => setPrayerRequest(e.target.value)}
            placeholder="Ex: Pela saúde da família, causa na justiça, libertação"
            className="w-full rounded-xl bg-neutral-900 border border-neutral-700/80 px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Giant Action Button specifically made for tablet taps */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting || !name.trim()}
            className={`w-full flex items-center justify-center gap-3 rounded-2xl py-4 sm:py-5 px-6 text-base sm:text-lg font-black tracking-wide transition-all shadow-xl ${
              !name.trim() || isSubmitting
                ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-neutral-950 shadow-amber-500/25 active:scale-[0.98]'
            }`}
          >
            <Send className="h-6 w-6 shrink-0" />
            <span>{isSubmitting ? 'ENVIANDO AO ALTAR...' : 'ENVIAR PARA O ALTAR AGORA'}</span>
          </button>
          <p className="mt-2 text-center text-[11px] text-neutral-400">
            Ao clicar, o nome e dados aparecem instantaneamente na tela do Pastor no altar.
          </p>
        </div>
      </form>
    </div>
  );
};
