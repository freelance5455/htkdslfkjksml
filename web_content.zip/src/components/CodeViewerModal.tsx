import React, { useState } from 'react';
import { X, Copy, Check, Download, FileCode, Terminal } from 'lucide-react';
import {
  SERVER_PY_CODE,
  REQUIREMENTS_TXT_CODE,
  HTML_CODE,
  CSS_CODE,
  SCRIPT_JS_CODE,
  ANDROID_MANIFEST_XML_CODE,
  README_MD_CODE,
} from '../data/exportTemplates';

interface CodeViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDownloadZip: () => void;
}

type TabType = 'server.py' | 'index.html' | 'script.js' | 'style.css' | 'AndroidManifest.xml' | 'requirements.txt' | 'README.md';

export const CodeViewerModal: React.FC<CodeViewerModalProps> = ({
  isOpen,
  onClose,
  onDownloadZip,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('server.py');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const getCodeForTab = () => {
    switch (activeTab) {
      case 'server.py':
        return SERVER_PY_CODE;
      case 'index.html':
        return HTML_CODE;
      case 'script.js':
        return SCRIPT_JS_CODE;
      case 'style.css':
        return CSS_CODE;
      case 'AndroidManifest.xml':
        return ANDROID_MANIFEST_XML_CODE;
      case 'requirements.txt':
        return REQUIREMENTS_TXT_CODE;
      case 'README.md':
        return README_MD_CODE;
      default:
        return '';
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(getCodeForTab());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.warn("Nusxa olishda xatolik:", e);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-slate-950 border border-cyan-500/40 rounded-xl overflow-hidden shadow-[0_0_40px_rgba(6,182,212,0.25)] flex flex-col h-[88vh]">
        {/* Yuqori sarlavha paneli */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-cyan-500/20 bg-slate-900/80 shrink-0">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-cyan-400" />
            <span className="font-display text-sm tracking-wider text-cyan-300">
              JARVIS // MANBA KODLARI BAZASI
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onDownloadZip}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-xs font-bold rounded-lg transition-colors shadow-sm"
              title="Barcha fayllarni bitta ZIP arxiv qilib yuklash"
            >
              <Download className="w-3.5 h-3.5" />
              <span>ZIP Yuklab olish</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white transition-colors rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tablar paneli */}
        <div className="flex items-center gap-1 px-4 py-2 border-b border-slate-800 bg-slate-900/40 overflow-x-auto shrink-0">
          {(
            [
              'server.py',
              'index.html',
              'script.js',
              'style.css',
              'AndroidManifest.xml',
              'requirements.txt',
              'README.md',
            ] as TabType[]
          ).map((tab) => {
            const isActive = activeTab === tab;
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-lg transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                }`}
              >
                <FileCode className="w-3.5 h-3.5" />
                {tab}
              </button>
            );
          })}
        </div>

        {/* Kod matni va Nusxa olish paneli */}
        <div className="relative flex-1 overflow-hidden bg-black flex flex-col">
          <div className="absolute top-3 right-4 z-10">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-cyan-300 border border-cyan-500/30 rounded-lg text-xs font-mono transition-colors shadow-md backdrop-blur-sm"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Nusxalandi!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Kodni nusxalash</span>
                </>
              )}
            </button>
          </div>

          <pre className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-200 leading-relaxed selection:bg-cyan-500 selection:text-black">
            <code>{getCodeForTab()}</code>
          </pre>
        </div>

        {/* Pastki axborot paneli */}
        <div className="px-5 py-2.5 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between text-[11px] text-slate-400 shrink-0">
          <div>
            Fayl: <span className="font-mono text-cyan-300">{activeTab}</span> (Render & APK uchun 100% shay)
          </div>
          <div className="font-mono">
            Dasturchi: <span className="text-cyan-400">Мухаммадризо</span>
          </div>
        </div>
      </div>
    </div>
  );
};
