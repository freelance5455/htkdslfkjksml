import React from 'react';
import { Plus, X, Flame, ShieldCheck, Globe, Check, Layers } from 'lucide-react';
import { Tab } from '../types/browser';

interface TabSwitcherProps {
  isOpen: boolean;
  onClose: () => void;
  tabs: Tab[];
  activeTabId: string;
  onSelectTab: (tabId: string) => void;
  onCloseTab: (tabId: string) => void;
  onNewTab: () => void;
  onCloseAll: () => void;
}

export const TabSwitcher: React.FC<TabSwitcherProps> = ({
  isOpen,
  onClose,
  tabs,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onNewTab,
  onCloseAll,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col select-none animate-fade-in">
      {/* Top Header Bar */}
      <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-emerald-400" />
          <h2 className="text-base font-bold text-slate-100">
            {tabs.length} Private {tabs.length === 1 ? 'Tab' : 'Tabs'}
          </h2>
        </div>

        <div className="flex items-center gap-2">
          {tabs.length > 1 && (
            <button
              onClick={onCloseAll}
              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-orange-400 hover:text-orange-300 text-xs font-semibold flex items-center gap-1 transition-all"
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Burn All</span>
            </button>
          )}

          <button
            id="tab-switcher-new-btn"
            onClick={onNewTab}
            className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition-all active:scale-95 shadow-md flex items-center justify-center"
            title="New Private Tab"
          >
            <Plus className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all active:scale-95"
          >
            Done
          </button>
        </div>
      </div>

      {/* Tabs Grid */}
      <div className="flex-1 p-4 overflow-y-auto grid grid-cols-2 gap-3.5 max-w-xl mx-auto w-full no-scrollbar">
        {tabs.map((tab) => {
          const isActive = tab.id === activeTabId;
          const totalBlocked = tab.trackersBlocked + tab.fingerprintsBlocked + tab.cookiesBlocked;

          return (
            <div
              key={tab.id}
              onClick={() => {
                onSelectTab(tab.id);
                onClose();
              }}
              className={`group relative rounded-2xl overflow-hidden border transition-all cursor-pointer flex flex-col h-44 bg-slate-900 shadow-xl ${
                isActive
                  ? 'border-emerald-500 ring-2 ring-emerald-500/30'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Card Tab Header */}
              <div className="px-2.5 py-2 bg-slate-850 bg-slate-950/80 flex items-center justify-between border-b border-slate-800/80">
                <div className="flex items-center gap-1.5 min-w-0 flex-1">
                  <Globe className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="text-xs font-semibold text-slate-200 truncate">
                    {tab.title || 'New Tab'}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onCloseTab(tab.id);
                  }}
                  className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ml-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Card Preview Body */}
              <div className="flex-1 p-3 bg-slate-900/60 flex flex-col justify-between relative overflow-hidden">
                <div className="space-y-1">
                  <p className="text-[11px] text-slate-400 truncate font-mono">
                    {tab.url.replace(/^https?:\/\//, '')}
                  </p>
                  {tab.content?.summary && (
                    <p className="text-[10px] text-slate-500 line-clamp-3 leading-relaxed">
                      {tab.content.summary}
                    </p>
                  )}
                </div>

                {/* Bottom Shield Badge */}
                <div className="flex items-center justify-between pt-2">
                  <div className="flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-md border border-emerald-800/40">
                    <ShieldCheck className="w-3 h-3" />
                    <span>{totalBlocked} blocked</span>
                  </div>

                  {isActive && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Floating Bar */}
      <div className="p-4 bg-slate-900/90 border-t border-slate-800 flex justify-center">
        <button
          onClick={onNewTab}
          className="w-full max-w-sm py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>Open New Private Tab</span>
        </button>
      </div>
    </div>
  );
};
