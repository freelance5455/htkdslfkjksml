import React, { useState, useEffect } from 'react';
import { 
  X, 
  ShieldCheck, 
  Lock, 
  Key, 
  LogOut, 
  LayoutDashboard, 
  ListOrdered, 
  Users, 
  Settings as SettingsIcon, 
  Plus, 
  RefreshCw,
  Gift,
  Database,
  Bell,
  UserCheck
} from 'lucide-react';
import { 
  WeeklyQuiz, 
  AdminOverviewStats, 
  WeeklyQuizStatus 
} from '../types';
import AdminOverview from './admin/AdminOverview';
import AdminQuizList from './admin/AdminQuizList';
import AdminQuizEditor from './admin/AdminQuizEditor';
import AdminSubmissionsView from './admin/AdminSubmissionsView';
import AdminSettingsView from './admin/AdminSettingsView';
import AdminQuestionBank from './admin/AdminQuestionBank';
import AdminNotificationManager from './admin/AdminNotificationManager';
import AdminLoginModal from './admin/AdminLoginModal';

interface AdminWeeklyQuizModalProps {
  language: string;
  onClose: () => void;
  onQuizUpdated?: () => void;
  onLogoutAdmin?: () => void;
}

type AdminTab = 'overview' | 'quizzes' | 'notifications' | 'question_bank' | 'edit_quiz' | 'submissions' | 'settings';

export default function AdminWeeklyQuizModal({
  language,
  onClose,
  onQuizUpdated,
  onLogoutAdmin
}: AdminWeeklyQuizModalProps) {
  const [adminToken, setAdminToken] = useState<string>(() => localStorage.getItem('edumind_admin_token') || '');
  const [adminUser, setAdminUser] = useState<{ id: string; email: string; name: string; role: 'admin' } | null>(null);
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');

  // Data States
  const [stats, setStats] = useState<AdminOverviewStats | null>(null);
  const [quizzes, setQuizzes] = useState<WeeklyQuiz[]>([]);
  const [selectedQuiz, setSelectedQuiz] = useState<WeeklyQuiz | null>(null);
  const [isNewQuiz, setIsNewQuiz] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  // Verify Session on token change or mount
  useEffect(() => {
    if (adminToken) {
      fetch('/api/admin/verify-session', {
        headers: { 'x-admin-token': adminToken }
      })
        .then(res => res.json())
        .then(data => {
          if (data.valid && data.user) {
            setAdminUser(data.user);
          } else {
            handleLogout();
          }
        })
        .catch(() => {
          handleLogout();
        });
    }
  }, [adminToken]);

  // Fetch overview stats and quizzes
  const fetchAdminData = async () => {
    if (!adminToken) return;
    setLoading(true);
    try {
      const [overviewRes, quizzesRes] = await Promise.all([
        fetch('/api/admin/overview', { headers: { 'x-admin-token': adminToken } }),
        fetch('/api/admin/quizzes', { headers: { 'x-admin-token': adminToken } })
      ]);

      if (overviewRes.status === 401 || quizzesRes.status === 401) {
        handleLogout();
        return;
      }

      const overviewData = await overviewRes.json();
      const quizzesData = await quizzesRes.json();

      if (overviewData.stats) setStats(overviewData.stats);
      if (quizzesData.quizzes) setQuizzes(quizzesData.quizzes);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (adminToken) {
      fetchAdminData();
    }
  }, [adminToken]);

  const handleLogout = async () => {
    if (adminToken) {
      try {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: { 'x-admin-token': adminToken }
        });
      } catch (e) {}
    }
    setAdminToken('');
    setAdminUser(null);
    localStorage.removeItem('edumind_admin_token');
    setActiveTab('overview');
    onLogoutAdmin?.();
  };

  // Admin Actions
  const handleOpenCreateQuiz = () => {
    const defaultNew: WeeklyQuiz = {
      id: `weekly-quiz-${Date.now()}`,
      weekNumber: quizzes.length + 1,
      title: `Weekly Quiz Challenge #${quizzes.length + 1}`,
      description: 'সর্বোচ্চ সঠিক উত্তর দিয়ে লিডারবোর্ডের শীর্ষে থাকুন এবং জিতে নিন বিশেষ আকর্ষণীয় পুরস্কার!',
      targetLevel: 'SSC CHSL / CGL & Competitive Exams',
      subjects: ['Quantitative Aptitude', 'Reasoning', 'General Knowledge', 'General Science'],
      timeLimit: 15,
      startDate: new Date().toISOString().split('T')[0],
      startTime: '08:00 AM',
      endDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      endTime: '11:59 PM',
      status: 'live',
      negativeMarking: true,
      negativeMarksPerWrong: 0.25,
      marksPerQuestion: 1.0,
      prizeName: 'Premium Notebook & Study Planner Set',
      prizeDescription: '১ম স্থানাধিকারী শীর্ষ শিক্ষার্থীকে সম্পূর্ণ বিনামূল্যে কুরিয়ারে পাঠানো হবে।',
      prizeImage: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
      prizeValue: '₹750',
      prizePosition: '1st Prize',
      prizeTerms: 'ফিজিক্যাল কুরিয়ারের মাধ্যমে বিজয়ীর ঠিকানায় পৌঁছানো হবে।',
      questions: [
        {
          id: 'q-sample-1',
          question: 'ভারতের সংবিধানের কোন ধারায় মৌলিক অধিকারের নিশ্চয়তা দেওয়া হয়েছে?',
          options: ['ধারা ১২-৩৫', 'ধারা ৩৬-৫১', 'ধারা ৫১A', 'ধারা ৩৭০'],
          correctOptionIndex: 0,
          explanation: 'সংবিধানের ৩য় ভাগে ধারা ১২ থেকে ৩৫ পর্যন্ত মৌলিক অধিকার বর্ণিত হয়েছে।',
          subject: 'General Knowledge',
          difficulty: 'Medium'
        }
      ],
      questionCount: 1,
      participantsCount: 0,
      winnerVerified: false,
      prizeStatus: 'Pending Verification',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      rules: [
        'প্রত্যেক শিক্ষার্থী শুধুমাত্র ১ বার অংশগ্রহণের সুযোগ পাবে।',
        'সময়ের আগে সাবমিট করলে বোনাস টাইমিং স্কোর লিডারবোর্ডে অগ্রাধিকার পাবে।',
        'ভুল উত্তরের ক্ষেত্রে ২৫% (০.২৫) নেগেティブ মার্কিং কার্যকর হবে।',
        'কোনো ট্যাব পরিবর্তন বা নকল শনাক্ত হলে ফলাফল স্বয়ংক্রিয় বাতিল হবে।'
      ]
    };
    setSelectedQuiz(defaultNew);
    setIsNewQuiz(true);
    setActiveTab('edit_quiz');
  };

  const handleEditQuiz = (quiz: WeeklyQuiz) => {
    setSelectedQuiz(quiz);
    setIsNewQuiz(false);
    setActiveTab('edit_quiz');
  };

  const handleSaveQuiz = async (quizData: Partial<WeeklyQuiz>) => {
    try {
      const res = await fetch('/api/admin/quiz', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify(quizData)
      });

      if (res.ok) {
        await fetchAdminData();
        setActiveTab('quizzes');
        onQuizUpdated?.();
      }
    } catch (err) {
      console.error('Failed to save quiz:', err);
    }
  };

  const handleDeleteQuiz = async (id: string) => {
    if (!window.confirm(language === 'bn' ? 'আপনি কি নিশ্চিতভাবে এই কুইজটি মুছে ফেলতে চান?' : 'Are you sure you want to delete this quiz?')) return;
    try {
      const res = await fetch(`/api/admin/quiz/${id}`, {
        method: 'DELETE',
        headers: { 'x-admin-token': adminToken }
      });
      if (res.ok) {
        await fetchAdminData();
        onQuizUpdated?.();
      }
    } catch (err) {
      console.error('Delete error:', err);
    }
  };

  const handleDuplicateQuiz = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/quiz/${id}/duplicate`, {
        method: 'POST',
        headers: { 'x-admin-token': adminToken }
      });
      if (res.ok) {
        await fetchAdminData();
        onQuizUpdated?.();
      }
    } catch (err) {
      console.error('Duplicate error:', err);
    }
  };

  const handleSetStatus = async (id: string, status: WeeklyQuizStatus) => {
    try {
      const res = await fetch(`/api/admin/quiz/${id}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        await fetchAdminData();
        onQuizUpdated?.();
      }
    } catch (err) {
      console.error('Status update error:', err);
    }
  };

  const handleExtendTime = async (id: string, hours: number) => {
    try {
      const res = await fetch(`/api/admin/quiz/${id}/extend-time`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({ extendHours: hours })
      });
      if (res.ok) {
        await fetchAdminData();
        onQuizUpdated?.();
      }
    } catch (err) {
      console.error('Extend time error:', err);
    }
  };

  const handleToggleArchive = async (id: string, isArchived: boolean) => {
    try {
      const res = await fetch(`/api/admin/quiz/${id}/archive`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({ isArchived })
      });
      if (res.ok) {
        await fetchAdminData();
        onQuizUpdated?.();
      }
    } catch (err) {
      console.error('Archive error:', err);
    }
  };

  const handleBroadcastAlert = async (quizId: string) => {
    try {
      const res = await fetch(`/api/admin/quiz/${quizId}/broadcast-10min-alert`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        }
      });
      const data = await res.json();
      if (res.ok) {
        alert(language === 'bn' 
          ? `সফলভাবে শিক্ষার্থীদের কাছে ১০ মিনিট আগের নোটিফিকেশন অ্যালার্ট পাঠানো হয়েছে!` 
          : `10-minute warning alert sent to ${data.subscribersCount || 0} registered students!`);
      } else {
        alert(data.error || 'Failed to send alert');
      }
    } catch (err) {
      console.error('Broadcast alert error:', err);
    }
  };

  const handleVerifyWinner = async (quizId: string, winnerUserId: string) => {
    try {
      const res = await fetch(`/api/admin/quiz/${quizId}/verify-winner`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({ winnerUserId })
      });
      if (res.ok) {
        await fetchAdminData();
        onQuizUpdated?.();
      }
    } catch (err) {
      console.error('Verify winner error:', err);
    }
  };

  const handleUpdatePrizeStatus = async (quizId: string, status: string, notes: string) => {
    try {
      const res = await fetch(`/api/admin/quiz/${quizId}/prize-status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({ prizeStatus: status, deliveryNotes: notes })
      });
      if (res.ok) {
        await fetchAdminData();
        onQuizUpdated?.();
      }
    } catch (err) {
      console.error('Update prize status error:', err);
    }
  };

  const handleViewSubmissions = (quiz: WeeklyQuiz) => {
    setSelectedQuiz(quiz);
    setActiveTab('submissions');
  };

  // If Not Authenticated: Render Dedicated Admin Login Screen
  if (!adminToken) {
    return (
      <AdminLoginModal
        language={language}
        onClose={onClose}
        onSuccess={(token, user) => {
          setAdminToken(token);
          setAdminUser(user);
          localStorage.setItem('edumind_admin_token', token);
        }}
      />
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95">
        
        {/* Top Navbar */}
        <div className="bg-slate-800/90 border-b border-slate-700 px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3 shrink-0">
          
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-xl">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-black text-white">
                  {language === 'bn' ? 'StudySkill কুইজ অ্যাডমিন হাব' : 'StudySkill Quiz Admin Hub'}
                </h2>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-black rounded-md flex items-center gap-1">
                  <UserCheck className="w-3 h-3" />
                  <span>ADMIN</span>
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {adminUser?.email ? `${adminUser.email} • ` : ''}
                {language === 'bn' ? 'অনুমোদিত অ্যাডমিনিস্ট্রেটর কনসোল' : 'Authorized Control Console'}
              </p>
            </div>
          </div>

          {/* Navigation Tab Pills */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs overflow-x-auto">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'overview' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'ওভারভিউ' : 'Overview'}</span>
            </button>

            <button
              onClick={() => setActiveTab('quizzes')}
              className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'quizzes' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ListOrdered className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'সকল কুইজ' : 'Quizzes'}</span>
            </button>

            <button
              onClick={() => setActiveTab('notifications')}
              className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'notifications' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Bell className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'পুশ নোটিফিকেশন' : 'Push Alerts'}</span>
            </button>

            <button
              onClick={() => setActiveTab('question_bank')}
              className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'question_bank' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'প্রশ্নব্যাংক' : 'Question Bank'}</span>
            </button>

            <button
              onClick={() => {
                const current = quizzes.find(q => q.status === 'live') || quizzes[0];
                if (current) setSelectedQuiz(current);
                setActiveTab('submissions');
              }}
              className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'submissions' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'ফলাফল ও বিজয়ী' : 'Submissions'}</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'settings' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <SettingsIcon className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'সেটিংস' : 'Settings'}</span>
            </button>
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={fetchAdminData}
              title="Refresh Data"
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl cursor-pointer transition-all"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>

            <button
              onClick={handleLogout}
              title="Logout Admin"
              className="p-2 bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white rounded-xl cursor-pointer transition-all"
            >
              <LogOut className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl cursor-pointer transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

        </div>

        {/* Modal Main Content Body */}
        <div className="overflow-y-auto flex-1 bg-slate-900">
          {activeTab === 'overview' && (
            <AdminOverview
              language={language}
              stats={stats}
              loading={loading}
              onNavigate={(tab) => {
                if (tab === 'submissions') {
                  const curr = stats?.currentQuiz || quizzes[0];
                  if (curr) setSelectedQuiz(curr);
                }
                setActiveTab(tab as any);
              }}
              onOpenCreate={handleOpenCreateQuiz}
              onEditQuiz={handleEditQuiz}
              onVerifyWinnerQuick={(quizId) => {
                const target = quizzes.find(q => q.id === quizId);
                if (target) {
                  setSelectedQuiz(target);
                  setActiveTab('submissions');
                }
              }}
            />
          )}

          {activeTab === 'quizzes' && (
            <AdminQuizList
              language={language}
              quizzes={quizzes}
              loading={loading}
              onOpenCreate={handleOpenCreateQuiz}
              onEditQuiz={handleEditQuiz}
              onDeleteQuiz={handleDeleteQuiz}
              onDuplicateQuiz={handleDuplicateQuiz}
              onSetStatus={handleSetStatus}
              onExtendTime={handleExtendTime}
              onToggleArchive={handleToggleArchive}
              onViewSubmissions={handleViewSubmissions}
              onBroadcastAlert={handleBroadcastAlert}
            />
          )}

          {activeTab === 'notifications' && (
            <AdminNotificationManager
              language={language}
              adminToken={adminToken}
            />
          )}

          {activeTab === 'question_bank' && (
            <AdminQuestionBank
              language={language}
              adminToken={adminToken}
              onAddToQuiz={(q) => {
                // If currently editing quiz, add question to it
                if (selectedQuiz) {
                  setSelectedQuiz({
                    ...selectedQuiz,
                    questions: [...(selectedQuiz.questions || []), q],
                    questionCount: (selectedQuiz.questions?.length || 0) + 1
                  });
                  setActiveTab('edit_quiz');
                } else {
                  alert(language === 'bn' ? 'প্রশ্নটি কুইজে যুক্ত করতে আগে একটি কুইজ সিলেক্ট বা তৈরি করুন।' : 'Select or create a quiz to attach this question.');
                }
              }}
            />
          )}

          {activeTab === 'edit_quiz' && selectedQuiz && (
            <AdminQuizEditor
              language={language}
              quiz={selectedQuiz}
              adminToken={adminToken}
              isNew={isNewQuiz}
              onSave={handleSaveQuiz}
              onCancel={() => setActiveTab('quizzes')}
            />
          )}

          {activeTab === 'submissions' && (
            <AdminSubmissionsView
              language={language}
              quiz={selectedQuiz || stats?.currentQuiz || quizzes[0]}
              adminToken={adminToken}
              onVerifyWinner={handleVerifyWinner}
              onUpdatePrizeStatus={handleUpdatePrizeStatus}
            />
          )}

          {activeTab === 'settings' && (
            <AdminSettingsView
              language={language}
              adminToken={adminToken}
              onSettingsUpdated={fetchAdminData}
            />
          )}
        </div>

      </div>
    </div>
  );
}
