import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, X, Heart, Bell } from 'lucide-react';
import { AppTheme } from '../types';

interface SalawatBannerProps {
  isVisible: boolean;
  count: number;
  theme: AppTheme;
  onDismiss: () => void;
  onIncrementCount: () => void;
  onOpenSettings?: () => void;
}

export const SalawatBanner: React.FC<SalawatBannerProps> = ({
  isVisible,
  count,
  theme,
  onDismiss,
  onIncrementCount,
  onOpenSettings,
}) => {
  const isDark = theme === 'dark';

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          id="salawat-reminder-banner"
          initial={{ opacity: 0, y: -40, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -30, scale: 0.95 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="fixed top-4 left-4 right-4 z-50 max-w-lg mx-auto pointer-events-auto"
        >
          <div
            className={`relative overflow-hidden rounded-2xl border shadow-2xl p-4 transition-colors ${
              isDark
                ? 'bg-slate-900/95 border-emerald-500/40 text-slate-100 shadow-emerald-950/50 backdrop-blur-md'
                : theme === 'parchment'
                ? 'bg-amber-50/95 border-amber-300/80 text-amber-950 shadow-amber-900/20 backdrop-blur-md'
                : 'bg-white/95 border-emerald-600/30 text-slate-900 shadow-emerald-900/15 backdrop-blur-md'
            }`}
          >
            {/* Background decorative glow */}
            <div className="absolute -top-12 -right-12 w-32 h-32 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-start gap-3 relative z-10">
              {/* Icon badge */}
              <div
                className={`w-11 h-11 shrink-0 rounded-2xl flex items-center justify-center border shadow-sm ${
                  isDark
                    ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-400'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-700'
                }`}
              >
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>

              {/* Text content */}
              <div className="flex-1 min-w-0 pr-1">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold tracking-wide bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                    <Bell className="w-3 h-3" />
                    تذكير بالصلاة على النبي ﷺ
                  </span>

                  <button
                    onClick={onDismiss}
                    aria-label="إغلاق التنبيه"
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <p
                  className="text-base sm:text-lg font-bold leading-relaxed text-slate-900 dark:text-slate-100"
                  style={{ fontFamily: 'Amiri, Traditional Arabic, serif' }}
                >
                  اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَىٰ سَيِّدِنَا مُحَمَّدٍ وَعَلَىٰ آلِهِ وَصَحْبِهِ وَسَلِّمْ
                </p>

                {/* Actions & counter */}
                <div className="mt-3 flex items-center flex-wrap gap-2 pt-2 border-t border-slate-200/50 dark:border-slate-800">
                  <button
                    onClick={onIncrementCount}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-transform active:scale-95 shadow-sm ${
                      isDark
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                        : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                    }`}
                  >
                    <Heart className="w-3.5 h-3.5 fill-current" />
                    صلَّيتُ على النَّبِيّ (+1)
                  </button>

                  <span className="text-xs text-slate-500 dark:text-slate-400 px-2 py-1">
                    إجمالي الصلوات: <strong className="font-bold text-emerald-600 dark:text-emerald-400">{count}</strong>
                  </span>

                  {onOpenSettings && (
                    <button
                      onClick={() => {
                        onDismiss();
                        onOpenSettings();
                      }}
                      className="mr-auto text-xs text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 underline underline-offset-2 transition-colors"
                    >
                      ضبط التذكير
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
