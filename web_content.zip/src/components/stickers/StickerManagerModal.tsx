import React, { useState } from 'react';
import { CustomSticker } from '../../types';
import { X, Upload, Trash2, Sparkles, Image as ImageIcon } from 'lucide-react';

interface StickerManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  stickers: CustomSticker[];
  onSaveSticker: (sticker: CustomSticker) => void;
  onDeleteSticker: (id: string) => void;
  onSelectSticker?: (sticker: CustomSticker) => void;
}

export const StickerManagerModal: React.FC<StickerManagerModalProps> = ({
  isOpen,
  onClose,
  stickers,
  onSaveSticker,
  onDeleteSticker,
  onSelectSticker,
}) => {
  if (!isOpen) return null;

  const [stickerName, setStickerName] = useState('');
  const [previewUrl, setPreviewUrl] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!stickerName) {
        setStickerName(file.name.replace(/\.[^/.]+$/, ''));
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddSticker = (e: React.FormEvent) => {
    e.preventDefault();
    if (!previewUrl) return;

    const newSticker: CustomSticker = {
      id: 'sticker-' + Date.now(),
      name: stickerName.trim() || 'Sticker ' + (stickers.length + 1),
      dataUrl: previewUrl,
      createdAt: new Date().toISOString(),
    };

    onSaveSticker(newSticker);
    setStickerName('');
    setPreviewUrl('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div className="w-full max-w-lg glass-panel rounded-3xl p-5 sm:p-6 border border-white/15 shadow-2xl flex flex-col justify-between max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-zinc-300" />
            <h3 className="text-base font-bold text-white tracking-tight font-['Syne']">
              Stickers Personalizados
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Upload form */}
        <form onSubmit={handleAddSticker} className="glass-panel-subtle rounded-2xl p-4 border border-white/[0.08] space-y-3 text-xs mb-4">
          <label className="text-slate-300 font-semibold block">Importar sticker desde tu dispositivo</label>
          <div className="flex items-center gap-3">
            {previewUrl ? (
              <div className="w-14 h-14 rounded-xl border border-white/20 overflow-hidden bg-slate-900 shrink-0 flex items-center justify-center p-1">
                <img src={previewUrl} alt="Preview" className="max-w-full max-h-full object-contain" />
              </div>
            ) : (
              <div className="w-14 h-14 rounded-xl border border-dashed border-white/20 bg-white/[0.02] shrink-0 flex items-center justify-center text-slate-500">
                <ImageIcon className="w-5 h-5" />
              </div>
            )}

            <div className="flex-1 space-y-2">
              <input
                type="text"
                value={stickerName}
                onChange={(e) => setStickerName(e.target.value)}
                placeholder="Nombre o etiqueta del sticker..."
                className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-white/30"
              />
              <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/15 text-white font-medium cursor-pointer border border-white/10 transition-all text-xs">
                <Upload className="w-3.5 h-3.5 text-zinc-300" />
                <span>Seleccionar imagen (PNG / GIF / JPG)</span>
                <input type="file" accept="image/*" onChange={handleFileChange} className="sr-only" />
              </label>
            </div>
          </div>

          {previewUrl && (
            <div className="flex justify-end pt-1">
              <button
                type="submit"
                className="px-4 py-1.5 bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs rounded-xl shadow transition-all"
              >
                Guardar sticker
              </button>
            </div>
          )}
        </form>

        {/* Stickers Grid */}
        <div className="space-y-2 flex-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Tus stickers guardados ({stickers.length})</span>
            {onSelectSticker && <span className="text-zinc-300">Toca uno para reaccionar</span>}
          </div>

          {stickers.length === 0 ? (
            <div className="text-center py-10 text-slate-500 text-xs">
              Aún no has importado stickers. Puedes subir imágenes para usarlas como reacciones personalizadas.
            </div>
          ) : (
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-3 max-h-64 overflow-y-auto p-1">
              {stickers.map((s) => (
                <div
                  key={s.id}
                  onClick={() => onSelectSticker?.(s)}
                  className="group relative aspect-square rounded-2xl glass-panel-interactive border border-white/10 p-2 flex flex-col items-center justify-center cursor-pointer hover:border-white/30"
                  title={s.name}
                >
                  <img src={s.dataUrl} alt={s.name} className="max-w-full max-h-full object-contain" />
                  <span className="text-[9px] text-slate-400 truncate max-w-full mt-1 block">
                    {s.name}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteSticker(s.id);
                    }}
                    className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/80 text-zinc-400 hover:text-white opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"
                    title="Eliminar sticker"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
