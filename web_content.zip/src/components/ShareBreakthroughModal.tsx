import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Download, 
  Share2, 
  Copy, 
  Check, 
  X, 
  Flame, 
  HeartHandshake, 
  CheckCircle2, 
  Palette, 
  Smartphone, 
  Square,
  ShieldCheck,
  Maximize2
} from 'lucide-react';

export interface BreakthroughSharePayload {
  title: string;
  text: string;
  testimony?: string;
  category?: string;
  date?: string;
  isAnswered?: boolean;
}

interface ShareBreakthroughModalProps {
  payload: BreakthroughSharePayload | null;
  onClose: () => void;
  onShowToast?: (msg: string) => void;
}

type CardTheme = 'celestial-gold' | 'prophetic-fire' | 'midnight-glory' | 'emerald-victory' | 'heavenly-dawn';
type CardFormat = 'square' | 'story';

export const ShareBreakthroughModal: React.FC<ShareBreakthroughModalProps> = ({ payload, onClose, onShowToast }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  
  const [selectedTheme, setSelectedTheme] = useState<CardTheme>('celestial-gold');
  const [cardFormat, setCardFormat] = useState<CardFormat>('square');
  const [copiedImage, setCopiedImage] = useState<boolean>(false);
  const [copiedCaption, setCopiedCaption] = useState<boolean>(false);
  const [isRendering, setIsRendering] = useState<boolean>(false);
  const [previewDataUrl, setPreviewDataUrl] = useState<string>('');

  if (!payload) return null;

  const entryTitle = payload.title || 'My Divine Breakthrough';
  const entryText = payload.testimony || payload.text || 'The Lord has done marvelous things for me!';
  const entryCategory = payload.category || 'Testimony & Breakthrough';
  const entryDate = payload.date || new Date().toISOString().split('T')[0];
  const isAnswered = payload.isAnswered !== false;

  // Render Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    setIsRendering(true);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = cardFormat === 'square' ? 1080 : 1080;
    const height = cardFormat === 'square' ? 1080 : 1920;

    canvas.width = width;
    canvas.height = height;

    // 1. Background Gradient Setup
    let bgGradient: CanvasGradient;
    let accentColor = '#f59e0b';
    let secondaryAccent = '#fbbf24';
    let textColor = '#ffffff';
    let subTextColor = '#fde68a';

    if (selectedTheme === 'celestial-gold') {
      bgGradient = ctx.createRadialGradient(width / 2, height / 3, 50, width / 2, height / 2, width);
      bgGradient.addColorStop(0, '#2e1905');
      bgGradient.addColorStop(0.5, '#120b02');
      bgGradient.addColorStop(1, '#050301');
      accentColor = '#f59e0b';
      secondaryAccent = '#fde047';
      subTextColor = '#fef08a';
    } else if (selectedTheme === 'prophetic-fire') {
      bgGradient = ctx.createLinearGradient(0, 0, width, height);
      bgGradient.addColorStop(0, '#3b0707');
      bgGradient.addColorStop(0.5, '#1f0404');
      bgGradient.addColorStop(1, '#080101');
      accentColor = '#ef4444';
      secondaryAccent = '#f97316';
      subTextColor = '#fed7aa';
    } else if (selectedTheme === 'midnight-glory') {
      bgGradient = ctx.createLinearGradient(0, 0, width, height);
      bgGradient.addColorStop(0, '#0b132b');
      bgGradient.addColorStop(0.5, '#050814');
      bgGradient.addColorStop(1, '#02040a');
      accentColor = '#38bdf8';
      secondaryAccent = '#818cf8';
      subTextColor = '#bae6fd';
    } else if (selectedTheme === 'emerald-victory') {
      bgGradient = ctx.createLinearGradient(0, 0, width, height);
      bgGradient.addColorStop(0, '#062d1a');
      bgGradient.addColorStop(0.5, '#03140c');
      bgGradient.addColorStop(1, '#010503');
      accentColor = '#10b981';
      secondaryAccent = '#34d399';
      subTextColor = '#a7f3d0';
    } else {
      // heavenly-dawn
      bgGradient = ctx.createLinearGradient(0, 0, width, height);
      bgGradient.addColorStop(0, '#261138');
      bgGradient.addColorStop(0.5, '#12081d');
      bgGradient.addColorStop(1, '#06020a');
      accentColor = '#c084fc';
      secondaryAccent = '#f472b6';
      subTextColor = '#f5d0fe';
    }

    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, width, height);

    // 2. Decorative Celestial Geometry & Borders
    // Outer border
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 6;
    ctx.strokeRect(40, 40, width - 80, height - 80);

    // Inner hairline gold frame
    ctx.strokeStyle = secondaryAccent;
    ctx.globalAlpha = 0.4;
    ctx.lineWidth = 2;
    ctx.strokeRect(55, 55, width - 110, height - 110);
    ctx.globalAlpha = 1.0;

    // Corner decorative accents
    const cornerSize = 40;
    const corners = [
      [55, 55],
      [width - 55, 55],
      [55, height - 55],
      [width - 55, height - 55]
    ];
    ctx.fillStyle = accentColor;
    corners.forEach(([cx, cy]) => {
      ctx.beginPath();
      ctx.arc(cx, cy, 6, 0, Math.PI * 2);
      ctx.fill();
    });

    // 3. Top Header: JUHNKRIX MUSIKA Covenant Brand
    ctx.textAlign = 'center';
    ctx.fillStyle = secondaryAccent;
    ctx.font = 'bold 24px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.letterSpacing = '6px';
    ctx.fillText('JUHNKRIX MUSIKA • SOVEREIGN COVENANT ALTAR', width / 2, 120);

    // Badge Pill
    const badgeY = 160;
    ctx.fillStyle = 'rgba(245, 158, 11, 0.15)';
    ctx.beginPath();
    ctx.roundRect(width / 2 - 200, badgeY - 24, 400, 44, 22);
    ctx.fill();
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = subTextColor;
    ctx.font = 'bold 18px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.letterSpacing = '2px';
    ctx.fillText(
      isAnswered ? `🙌 DIVINE BREAKTHROUGH TESTIMONY` : `🕊️ PROPHETIC PRAYER DECREE`,
      width / 2,
      badgeY + 4
    );

    // Category & Date Sub-header
    ctx.fillStyle = '#94a3b8';
    ctx.font = '500 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.letterSpacing = '1px';
    ctx.fillText(`Category: ${entryCategory.toUpperCase()}  |  ${entryDate}`, width / 2, badgeY + 60);

    // 4. Main Title
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 46px Georgia, serif';
    ctx.shadowColor = accentColor;
    ctx.shadowBlur = 16;

    // Word wrap helper for title
    const maxTitleWidth = width - 200;
    const titleWords = entryTitle.split(' ');
    let titleLine = '';
    let titleY = badgeY + 140;

    titleWords.forEach((word) => {
      const testLine = titleLine + word + ' ';
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxTitleWidth && titleLine !== '') {
        ctx.fillText(titleLine.trim(), width / 2, titleY);
        titleLine = word + ' ';
        titleY += 56;
      } else {
        titleLine = testLine;
      }
    });
    ctx.fillText(titleLine.trim(), width / 2, titleY);
    ctx.shadowBlur = 0; // Reset shadow

    // Gold Divider Line
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(width / 2 - 120, titleY + 30);
    ctx.lineTo(width / 2 + 120, titleY + 30);
    ctx.stroke();

    // 5. Main Testimony / Prayer Text Box
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'italic 30px Georgia, serif';
    const textStartY = titleY + 90;
    const maxTextWidth = width - 240;
    const words = `"${entryText}"`.split(' ');
    let line = '';
    let curY = textStartY;

    words.forEach((word) => {
      const testLine = line + word + ' ';
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxTextWidth && line !== '') {
        ctx.fillText(line.trim(), width / 2, curY);
        line = word + ' ';
        curY += 44;
      } else {
        line = testLine;
      }
    });
    ctx.fillText(line.trim(), width / 2, curY);

    // 6. Scripture Seal / Anointing Decree
    const scriptureY = Math.max(curY + 70, height - 240);
    ctx.fillStyle = subTextColor;
    ctx.font = 'bold 22px Georgia, serif';
    ctx.fillText('“He that dwelleth in the secret place of the most High shall abide.” — Psalm 91:1', width / 2, scriptureY);

    // 7. Footer Stamp & Sovereign Seal
    const footerY = height - 100;
    ctx.fillStyle = '#64748b';
    ctx.font = 'bold 18px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.letterSpacing = '3px';
    ctx.fillText('PROPHET JUHNKRIX SYNVAGORD • 528HZ WORSHIP FREQUENCY', width / 2, footerY - 20);

    ctx.fillStyle = secondaryAccent;
    ctx.font = '600 16px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.fillText('Shared via JUHNKRIX MUSIKA Global Prayer Altar | prophetjuhnkrix.com', width / 2, footerY + 10);

    // Create preview data URL
    const dataUrl = canvas.toDataURL('image/png');
    setPreviewDataUrl(dataUrl);
    setIsRendering(false);
  }, [payload, selectedTheme, cardFormat]);

  const handleDownloadPng = () => {
    if (!canvasRef.current) return;
    const dataUrl = canvasRef.current.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `JUHNKRIX_Breakthrough_${entryTitle.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    if (onShowToast) onShowToast('📸 Breakthrough Image Card downloaded successfully!');
  };

  const handleCopyImageToClipboard = async () => {
    if (!canvasRef.current) return;
    try {
      canvasRef.current.toBlob(async (blob) => {
        if (!blob) return;
        try {
          const item = new ClipboardItem({ 'image/png': blob });
          await navigator.clipboard.write([item]);
          setCopiedImage(true);
          setTimeout(() => setCopiedImage(false), 2500);
          if (onShowToast) onShowToast('Image copied to clipboard! Paste directly into Instagram, Twitter, or WhatsApp.');
        } catch (e) {
          // Fallback: Copy Caption
          handleCopyCaption();
        }
      });
    } catch (err) {
      handleCopyCaption();
    }
  };

  const handleCopyCaption = () => {
    const caption = `🙌 DIVINE BREAKTHROUGH TESTIMONY!\n\n"${entryTitle}"\n\n"${entryText}"\n\n🕊️ Category: ${entryCategory}\n📅 Date: ${entryDate}\n\n✝️ "He that dwelleth in the secret place of the most High shall abide under the shadow of the Almighty." — Psalm 91:1\n\n#JUHNKRIXMUSIKA #Breakthrough #PraiseGod #Testimony #Prophetic #GospelMusic #PrayerAltar`;
    navigator.clipboard.writeText(caption);
    setCopiedCaption(true);
    setTimeout(() => setCopiedCaption(false), 2500);
    if (onShowToast) onShowToast('Social media caption copied with hashtags!');
  };

  const handleWebShare = async () => {
    if (!canvasRef.current) return;
    try {
      canvasRef.current.toBlob(async (blob) => {
        if (blob && navigator.share && navigator.canShare) {
          const file = new File([blob], `breakthrough-${Date.now()}.png`, { type: 'image/png' });
          if (navigator.canShare({ files: [file] })) {
            await navigator.share({
              title: `Breakthrough: ${entryTitle}`,
              text: `Testimony from JUHNKRIX MUSIKA Prayer Altar: ${entryText}`,
              files: [file]
            });
            if (onShowToast) onShowToast('Shared to social media!');
            return;
          }
        }
        // Fallback
        handleCopyCaption();
      });
    } catch (e) {
      handleCopyCaption();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/50 rounded-3xl max-w-4xl w-full p-6 sm:p-8 space-y-6 shadow-2xl text-slate-100 max-h-[95vh] overflow-y-auto relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2.5 rounded-full bg-slate-900/80 text-slate-400 hover:text-amber-200 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title */}
        <div className="text-center space-y-1.5">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>SHARE MY BREAKTHROUGH • SOCIAL MEDIA GENERATOR</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
            Generate Shareable Testimony Card
          </h2>
          <p className="text-xs text-slate-300 max-w-xl mx-auto">
            Create high-definition visual cards for Instagram, Twitter, Facebook, and WhatsApp Stories to declare God's faithfulness.
          </p>
        </div>

        {/* Customization Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950/80 p-4 rounded-2xl border border-amber-500/20">
          {/* Theme Selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
              <Palette className="w-3.5 h-3.5 text-amber-400" />
              <span>Card Aesthetic Palette</span>
            </label>
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'celestial-gold', name: 'Celestial Gold', color: 'bg-amber-500' },
                { id: 'prophetic-fire', name: 'Prophetic Fire', color: 'bg-red-500' },
                { id: 'midnight-glory', name: 'Midnight Glory', color: 'bg-cyan-500' },
                { id: 'emerald-victory', name: 'Emerald Victory', color: 'bg-emerald-500' },
                { id: 'heavenly-dawn', name: 'Heavenly Dawn', color: 'bg-purple-500' }
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setSelectedTheme(t.id as CardTheme)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 border transition-all ${
                    selectedTheme === t.id
                      ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md'
                      : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-amber-500/30'
                  }`}
                >
                  <span className={`w-2.5 h-2.5 rounded-full ${t.color}`} />
                  <span>{t.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Ratio Selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
              <Maximize2 className="w-3.5 h-3.5 text-amber-400" />
              <span>Aspect Ratio / Social Format</span>
            </label>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setCardFormat('square')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 border transition-all ${
                  cardFormat === 'square'
                    ? 'bg-amber-500 text-slate-950 border-amber-300'
                    : 'bg-slate-900 text-slate-300 border-slate-800'
                }`}
              >
                <Square className="w-3.5 h-3.5" />
                <span>1:1 Square (Feed / Twitter / IG)</span>
              </button>

              <button
                onClick={() => setCardFormat('story')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 border transition-all ${
                  cardFormat === 'story'
                    ? 'bg-amber-500 text-slate-950 border-amber-300'
                    : 'bg-slate-900 text-slate-300 border-slate-800'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>9:16 Story (WhatsApp / Stories)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Hidden Canvas Element used for Rendering */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Live Card Image Preview */}
        <div className="flex justify-center bg-slate-950/90 p-4 rounded-2xl border-2 border-amber-500/30 shadow-inner max-h-80 overflow-y-auto">
          {previewDataUrl ? (
            <img
              src={previewDataUrl}
              alt="Breakthrough Card Preview"
              className={`rounded-xl shadow-2xl object-contain border border-amber-500/40 ${
                cardFormat === 'square' ? 'max-h-72 w-auto' : 'max-h-72 w-auto'
              }`}
            />
          ) : (
            <div className="py-16 text-center text-xs text-slate-500">
              Rendering card preview...
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <button
            onClick={handleCopyCaption}
            className="py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-200 font-bold text-xs flex items-center justify-center space-x-2 border border-amber-500/30 transition-all shadow-md"
          >
            {copiedCaption ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-amber-400" />}
            <span>{copiedCaption ? 'Copied Caption!' : 'Copy Social Caption'}</span>
          </button>

          <button
            onClick={handleCopyImageToClipboard}
            className="py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-cyan-200 font-bold text-xs flex items-center justify-center space-x-2 border border-cyan-500/40 transition-all shadow-md"
          >
            {copiedImage ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4 text-cyan-400" />}
            <span>{copiedImage ? 'Image Copied!' : 'Copy Image to Clipboard'}</span>
          </button>

          <button
            onClick={handleDownloadPng}
            className="py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 transition-all shadow-xl shadow-amber-500/20 hover:scale-102"
          >
            <Download className="w-4 h-4 text-slate-950" />
            <span>Download PNG Card</span>
          </button>
        </div>
      </div>
    </div>
  );
};
