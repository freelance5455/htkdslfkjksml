import { useEffect, useState } from "react";
import { applyStats, emptyStats, summarize, type LiveEvent, type Stats } from "@/lib/live/model";

export function useOverlayBody() {
  useEffect(() => {
    document.body.dataset.overlay = "true";
    return () => {
      delete document.body.dataset.overlay;
    };
  }, []);
}

export function useOverlayFeed(room: string) {
  const [feed, setFeed] = useState<LiveEvent[]>([]);
  const [stats, setStats] = useState<Stats>(emptyStats());

  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin) return;
      const data = event.data as {
        source?: string;
        event?: LiveEvent;
        snapshot?: LiveEvent[];
        stats?: Stats;
      };
      if (!data || data.source !== "onda") return;
      if (data.snapshot) setFeed(data.snapshot);
      if (data.stats) setStats(data.stats);
      else if (data.snapshot) setStats(summarize(data.snapshot));
      if (data.event) {
        const incoming = data.event;
        if (incoming.kind === "status" || incoming.kind === "sync") return;
        setFeed((current) => (current.some((item) => item.id === incoming.id) ? current : [...current, incoming].slice(-180)));
        setStats((current) => applyStats(current, incoming));
      }
    };
    window.addEventListener("message", onMessage);

    let source: EventSource | null = null;
    const embedded = window.parent !== window;
    if (!embedded && room) {
      source = new EventSource(`/api/live?room=${encodeURIComponent(room)}`);
      source.onmessage = (message) => {
        const incoming = JSON.parse(message.data) as LiveEvent;
        if (incoming.kind === "status") return;
        if (incoming.kind === "sync") {
          setStats({
            viewers: incoming.viewers,
            likes: incoming.likes,
            follows: incoming.follows,
            shares: incoming.shares,
            coins: incoming.coins,
            ranks: incoming.ranks,
          });
          return;
        }
        setFeed((current) => (current.some((item) => item.id === incoming.id) ? current : [...current, incoming].slice(-180)));
        if (!incoming.replay) setStats((current) => applyStats(current, incoming));
      };
    }

    return () => {
      window.removeEventListener("message", onMessage);
      source?.close();
    };
  }, [room]);

  return { feed, stats };
}
