import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft } from 'lucide-react';
import { soundEngine } from '../../audio/soundEngine';
import { screenReader } from '../../audio/screenReader';
import { ConsoleStoreIcon } from '../icons/ConsoleIcons';

interface GameStoreOverlayProps {
  onClose: () => void;
}

export const GameStoreOverlay: React.FC<GameStoreOverlayProps> = ({ onClose }) => {
  useEffect(() => {
    screenReader.speak(
      'Game Store. No games in the store yet. New digital releases and classic titles will appear here as they become available. Tap Back or press Escape to return.'
    );
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 8 }}
      transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
      className="absolute inset-0 z-30 flex flex-col bg-[#060912]/96 p-8 md:p-10"
      onWheel={() => soundEngine.playScroll()}
    >
      <div className="flex items-center justify-between border-b border-white/12 pb-5">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onFocus={() => screenReader.speak('Back button. Returns to Home dashboard.')}
            onClick={() => {
              soundEngine.playBack();
              onClose();
            }}
            className="flex items-center gap-2 px-4 py-2 bg-white/8 hover:bg-white/15 border border-white/15 text-sm font-medium text-white transition-colors cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="w-4 h-4 text-sky-300" />
            <span>Back</span>
          </button>
          <h2 className="font-display text-2xl font-semibold tracking-tight text-white">
            Game Store
          </h2>
        </div>

        <span className="text-xs text-slate-400 font-mono-tabular">0 Titles Available</span>
      </div>

      <div className="flex-1 overflow-y-auto console-scroll flex flex-col items-center justify-center text-center px-6 py-6">
        <div className="w-24 h-24 border border-sky-400/40 bg-[#0b1324] flex items-center justify-center mb-6 shrink-0">
          <ConsoleStoreIcon className="w-11 h-11 text-sky-400" />
        </div>
        <h3 className="font-display text-2xl font-semibold text-white mb-2">
          No games in the store yet
        </h3>
        <p className="text-sm text-slate-400 max-w-md leading-relaxed">
          The Retro Game System storefront is ready. New digital releases and classic titles will
          appear here as they become available.
        </p>
      </div>
    </motion.div>
  );
};
