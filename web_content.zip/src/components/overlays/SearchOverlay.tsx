import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Search as SearchIcon, X } from 'lucide-react';
import { soundEngine } from '../../audio/soundEngine';
import { screenReader } from '../../audio/screenReader';

interface SearchOverlayProps {
  onClose: () => void;
}

export const SearchOverlay: React.FC<SearchOverlayProps> = ({ onClose }) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    inputRef.current?.focus();
    screenReader.speak(
      'Search Games. Type a title to search across your Store and Library. Currently zero games are available.'
    );
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 8 }}
      transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
      className="absolute inset-0 z-30 flex flex-col bg-[#060912]/96 p-8 md:p-10"
      onWheel={() => soundEngine.playScroll()}
    >
      <div className="flex items-center justify-between border-b border-white/12 pb-5">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onFocus={() => screenReader.speak('Back button. Returns to Home dashboard.')}
            onClick={() => {
              soundEngine.playBack();
              onClose();
            }}
            className="flex items-center gap-2 px-4 py-2 bg-white/8 hover:bg-white/15 border border-white/15 text-sm font-medium text-white transition-colors cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="w-4 h-4 text-sky-300" />
            <span>Back</span>
          </button>
          <h2 className="font-display text-2xl font-semibold tracking-tight text-white">
            Search Games
          </h2>
        </div>

        <span className="text-xs text-slate-400 font-mono-tabular">0 Matches</span>
      </div>

      <div className="flex-1 overflow-y-auto console-scroll flex flex-col items-center pt-10 pb-6 px-4">
        <div className="w-full max-w-2xl">
          <div className="relative flex items-center bg-[#0d1322] border border-white/20 focus-within:border-sky-400 transition-colors">
            <SearchIcon className="w-5 h-5 text-sky-400 ml-4 shrink-0" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                soundEngine.playScroll();
              }}
              placeholder="Search titles across Store and Library..."
              className="w-full bg-transparent px-4 py-4 text-base text-white placeholder:text-slate-500 focus:outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => {
                  soundEngine.playBack();
                  setQuery('');
                  screenReader.speak('Search cleared.');
                  inputRef.current?.focus();
                }}
                aria-label="Clear search"
                className="p-3 mr-1 text-slate-400 hover:text-sky-300 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="mt-14 flex flex-col items-center text-center">
            <p className="font-display text-xl font-medium text-slate-200 mb-2">
              {query.trim()
                ? `No games found for "${query.trim()}"`
                : 'No games available to search yet'}
            </p>
            <p className="text-sm text-slate-400 max-w-md">
              Your Retro Game System library and store currently contain 0 titles. Once games are
              added, you can search them instantly from here.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
