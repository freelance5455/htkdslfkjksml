import { useEffect, useState } from "react";
import { ChatLine, GoalMeter } from "@/components/live/bits";
import { useOverlayBody, useOverlayFeed } from "@/components/overlays/use-overlay-feed";
import { isChatVisible, type Settings } from "@/lib/live/model";
import type { OverlayLook } from "@/lib/live/search";

export function lookFrom(search: OverlayLook): Pick<Settings, "showJoins" | "showLikes" | "modsOnly" | "blocked"> {
  return {
    showJoins: search.joins,
    showLikes: search.likes,
    modsOnly: search.mods,
    blocked: search.blocked,
  };
}

export function ChatOverlay({ look }: { look: OverlayLook }) {
  useOverlayBody();
  const { feed } = useOverlayFeed(look.room);
  const [now, setNow] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);
  const settings = lookFrom(look);
  const lines = feed.filter((event) => {
    if (!isChatVisible(event, settings, [])) return false;
    if (!look.hide || !event.ts || !now) return true;
    return now - event.ts < look.hide * 1000;
  });

  return (
    <main className="flex min-h-dvh flex-col justify-end p-3">
      <div className="flex flex-col">
        {lines.slice(-12).map((event) => (
          <ChatLine key={event.id} event={event} scale={look.scale} />
        ))}
      </div>
    </main>
  );
}

export function AlertOverlay({ look }: { look: OverlayLook }) {
  useOverlayBody();
  const { feed } = useOverlayFeed(look.room);
  const [now, setNow] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 400);
    return () => window.clearInterval(id);
  }, []);
  const gift = [...feed].reverse().find((event) => event.kind === "gift");
  const visible = gift && gift.kind === "gift" && (!gift.ts || !now || now - gift.ts < 6000) ? gift : null;

  return (
    <main className="flex min-h-dvh items-end p-4">
      {visible ? (
        <div key={visible.id} className="onda-rise rounded-lg border border-line bg-surface px-4 py-3">
          <div>
            <p className="text-sm text-muted">{visible.user.nick} envió</p>
            <p className="font-display text-4xl text-hot">{visible.gift}</p>
            <p className="tabular-nums text-fg">
              {visible.repeat > 1 ? `×${visible.repeat} · ` : ""}
              {visible.diamonds * visible.repeat} monedas
            </p>
          </div>
        </div>
      ) : null}
    </main>
  );
}

export function GoalOverlay({
  look,
  metric,
  goal,
}: {
  look: OverlayLook;
  metric: "likes" | "follows" | "coins";
  goal: number;
}) {
  useOverlayBody();
  const { stats } = useOverlayFeed(look.room);
  const value = metric === "likes" ? stats.likes : metric === "follows" ? stats.follows : stats.coins;
  const label = metric === "likes" ? "Likes" : metric === "follows" ? "Follows" : "Monedas";
  return (
    <main className="flex min-h-dvh items-end p-4">
      <div className="w-full max-w-xl rounded-lg border border-line bg-surface p-4">
        <GoalMeter label={label} value={value} goal={goal} large />
      </div>
    </main>
  );
}

export function RankOverlay({ look }: { look: OverlayLook }) {
  useOverlayBody();
  const { stats } = useOverlayFeed(look.room);
  return (
    <main className="flex min-h-dvh items-start p-4">
      <section className="w-full max-w-sm rounded-lg border border-line bg-surface p-4">
        <h1 className="font-display text-2xl text-fg">Top regalos</h1>
        <ol className="mt-3 flex flex-col gap-2">
          {stats.ranks.slice(0, 5).map((row, index) => (
            <li key={row.name} className="flex items-center gap-3 text-fg">
              <span className={`w-6 tabular-nums font-semibold ${index === 0 ? "text-signal" : "text-muted"}`}>
                {index + 1}
              </span>
              <span className="min-w-0 flex-1 truncate">{row.nick}</span>
              <span className="tabular-nums text-sm text-muted">{row.coins}</span>
            </li>
          ))}
          {stats.ranks.length === 0 ? <li className="text-sm text-muted">Aún no hay regalos.</li> : null}
        </ol>
      </section>
    </main>
  );
}
