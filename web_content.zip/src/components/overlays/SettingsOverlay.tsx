import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import {
  Accessibility,
  ArrowLeft,
  AudioLines,
  Check,
  Gauge,
  Image as ImageIcon,
  Maximize2,
  Music,
  Play,
  RotateCcw,
  Sliders,
  Volume2,
} from 'lucide-react';
import {
  DEFAULT_SETTINGS,
  SystemSettings,
  VOICE_OPTIONS,
  WALLPAPER_OPTIONS,
} from '../../types/system';
import { soundEngine } from '../../audio/soundEngine';
import { screenReader } from '../../audio/screenReader';
import { useSwipeNavigation } from '../../hooks/useSwipeNavigation';
import { WallpaperBackdrop } from '../WallpaperBackdrop';

interface SettingsOverlayProps {
  profileName: string;
  settings: SystemSettings;
  onUpdateSettings: (next: SystemSettings) => void;
  onReplayStartup: () => void;
  onToggleFullscreen: () => void;
  isFullscreen: boolean;
  isRotatedPortrait?: boolean;
  onClose: () => void;
}

type SettingsTabId = 'wallpaper' | 'audio' | 'accessibility' | 'system';

const TAB_ORDER: SettingsTabId[] = ['wallpaper', 'audio', 'accessibility', 'system'];

export const SettingsOverlay: React.FC<SettingsOverlayProps> = ({
  profileName,
  settings,
  onUpdateSettings,
  onReplayStartup,
  onToggleFullscreen,
  isFullscreen,
  isRotatedPortrait = false,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<SettingsTabId>('wallpaper');
  const scrollBodyRef = useRef<HTMLDivElement | null>(null);

  const activeVoice = VOICE_OPTIONS[0];

  useEffect(() => {
    screenReader.speak(
      `System Settings for ${profileName}. Wallpaper tab open. Swipe left or right to switch between Wallpaper, Audio, Accessibility, and Display tabs.`
    );
  }, [profileName]);

  const updateField = <K extends keyof SystemSettings>(key: K, value: SystemSettings[K]) => {
    onUpdateSettings({ ...settings, [key]: value });
  };

  const tabs: { id: SettingsTabId; label: string; icon: React.ReactNode }[] = [
    { id: 'wallpaper', label: 'Wallpaper', icon: <ImageIcon className="w-4 h-4" /> },
    { id: 'audio', label: 'Audio & SFX', icon: <Volume2 className="w-4 h-4" /> },
    { id: 'accessibility', label: 'Accessibility', icon: <Accessibility className="w-4 h-4" /> },
    { id: 'system', label: 'Display & Boot', icon: <Sliders className="w-4 h-4" /> },
  ];

  const handleTabSwitch = (nextTab: SettingsTabId) => {
    const prevIdx = TAB_ORDER.indexOf(activeTab);
    const nextIdx = TAB_ORDER.indexOf(nextTab);
    if (nextIdx > prevIdx) soundEngine.playScrollRight();
    else if (nextIdx < prevIdx) soundEngine.playScrollLeft();
    else soundEngine.playHighlight();

    setActiveTab(nextTab);
    if (scrollBodyRef.current) {
      scrollBodyRef.current.scrollTop = 0;
    }

    if (nextTab === 'wallpaper') {
      screenReader.speak(
        `Wallpaper tab. Select any of the ${WALLPAPER_OPTIONS.length} themes to save directly to ${profileName}.`
      );
    } else if (nextTab === 'audio') {
      screenReader.speak(
        `Audio and Sound Effects tab. Adjust master volume, background music, and 8-bit sound effects for ${profileName}.`
      );
    } else if (nextTab === 'accessibility') {
      screenReader.speak(
        `Accessibility tab. Screen reader is ${
          settings.screenReaderEnabled ? 'on' : 'off'
        }, using our calm soft-voiced US English African American female accessibility voice.`
      );
    } else {
      screenReader.speak(
        'Display and Boot tab. Toggle fullscreen landscape mode, replay the boot sequence, or restore defaults.'
      );
    }
  };

  const { swipeHandlers } = useSwipeNavigation({
    onSwipeLeft: () => {
      const idx = TAB_ORDER.indexOf(activeTab);
      const next = TAB_ORDER[(idx - 1 + TAB_ORDER.length) % TAB_ORDER.length];
      handleTabSwitch(next);
    },
    onSwipeRight: () => {
      const idx = TAB_ORDER.indexOf(activeTab);
      const next = TAB_ORDER[(idx + 1) % TAB_ORDER.length];
      handleTabSwitch(next);
    },
    isRotatedPortrait,
    stepPx: 75,
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 8 }}
      transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
      {...swipeHandlers}
      className="absolute inset-0 z-30 flex flex-col bg-[#060912]/96 p-6 md:p-10"
    >
      {/* Responsive Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/12 pb-4 shrink-0">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onFocus={() => screenReader.speak('Back button. Returns to Home dashboard.')}
            onClick={() => {
              soundEngine.playBack();
              onClose();
            }}
            className="flex items-center gap-2 px-4 py-2 bg-white/8 hover:bg-white/15 border border-white/15 text-sm font-medium text-white transition-colors cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="w-4 h-4 text-sky-300" />
            <span>Back</span>
          </button>
          <div>
            <h2 className="font-display text-xl md:text-2xl font-semibold tracking-tight text-white">
              System Settings
            </h2>
            <p className="text-xs text-sky-300/90 mt-0.5">
              Saved Profile: {profileName} · Voice: {activeVoice.name}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 bg-[#0b1120] p-1 border border-white/12 overflow-x-auto max-w-full">
          {tabs.map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => handleTabSwitch(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-sky-400 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-white/6'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Scrollable Body */}
      <div
        ref={scrollBodyRef}
        onScroll={() => soundEngine.playScroll()}
        className="flex-1 overflow-y-auto console-scroll pt-6 pr-2 pb-6"
      >
        {activeTab === 'wallpaper' && (
          <div className="max-w-6xl">
            <div className="flex items-baseline justify-between mb-5">
              <div>
                <h3 className="font-display text-lg font-semibold text-white">
                  System Wallpaper
                </h3>
                <p className="text-sm text-slate-400 mt-0.5">
                  Saved uniquely for <span className="text-sky-300">{profileName}</span>. Choose
                  from {WALLPAPER_OPTIONS.length} custom console themes.
                </p>
              </div>
              <span className="text-xs font-mono-tabular text-sky-300">
                {WALLPAPER_OPTIONS.length} Themes
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {WALLPAPER_OPTIONS.map((wp) => {
                const isSelected = settings.wallpaperId === wp.id;
                return (
                  <button
                    key={wp.id}
                    type="button"
                    onFocus={() =>
                      screenReader.speak(
                        `${wp.name}. ${wp.subtitle}. ${
                          isSelected ? 'Currently active.' : 'Tap to apply to profile.'
                        }`
                      )
                    }
                    onClick={() => {
                      soundEngine.playSelect();
                      updateField('wallpaperId', wp.id);
                      screenReader.speak(
                        `${wp.name} wallpaper applied and saved to ${profileName}.`
                      );
                    }}
                    className={`group text-left transition-all cursor-pointer border ${
                      isSelected
                        ? 'border-2 border-sky-400 bg-[#0d1729]'
                        : 'border-white/15 hover:border-sky-300/50 bg-[#0a0f1c]'
                    }`}
                  >
                    <div
                      className="aspect-video w-full overflow-hidden relative"
                      style={{ backgroundColor: wp.baseColor }}
                    >
                      <WallpaperBackdrop wallpaperId={wp.id} className="w-full h-full" />
                      {isSelected && (
                        <span className="absolute top-1.5 right-1.5 px-2 py-0.5 bg-sky-400 text-slate-950 text-[10px] font-semibold">
                          Active
                        </span>
                      )}
                    </div>
                    <div className="p-3">
                      <div className="font-display text-xs font-semibold text-white truncate">
                        {wp.name}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-2 leading-snug">
                        {wp.subtitle}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'audio' && (
          <div className="max-w-5xl grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Master, Music & 8-Bit Sound Effects */}
            <div className="space-y-6 bg-[#0b1120] border border-white/12 p-6">
              <h3 className="font-display text-lg font-semibold text-white">
                Music &amp; Sound Effects
              </h3>

              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-slate-200 font-medium">Master Volume</span>
                  <span className="font-mono-tabular text-sky-300">
                    {Math.round(settings.masterVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.masterVolume * 100)}
                  onFocus={() =>
                    screenReader.speak(
                      `Master Volume slider, ${Math.round(settings.masterVolume * 100)} percent.`
                    )
                  }
                  onChange={(e) => {
                    updateField('masterVolume', Number(e.target.value) / 100);
                    soundEngine.playScroll();
                  }}
                  className="w-full accent-sky-400 cursor-pointer"
                />
              </div>

              {/* Background Piano Music */}
              <div className="pt-4 border-t border-white/10">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <Music className="w-4 h-4 text-sky-400" />
                    <span className="text-sm font-medium text-slate-200">
                      Background Music (Space &amp; C-Major Piano)
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const next = !settings.musicEnabled;
                      updateField('musicEnabled', next);
                      if (next) {
                        soundEngine.playSelect();
                        screenReader.speak('Background music turned on.');
                      } else {
                        soundEngine.playBack();
                        screenReader.speak('Background music turned off.');
                      }
                    }}
                    className={`px-3.5 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                      settings.musicEnabled
                        ? 'bg-sky-400 text-slate-950'
                        : 'bg-white/10 text-slate-300'
                    }`}
                  >
                    {settings.musicEnabled ? 'On' : 'Off'}
                  </button>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                  <span>Music Level</span>
                  <span className="font-mono-tabular text-slate-200">
                    {Math.round(settings.musicVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  disabled={!settings.musicEnabled}
                  value={Math.round(settings.musicVolume * 100)}
                  onChange={(e) =>
                    updateField('musicVolume', Number(e.target.value) / 100)
                  }
                  className="w-full accent-sky-400 cursor-pointer disabled:opacity-40"
                />
              </div>

              {/* 8-Bit UI SFX */}
              <div className="pt-4 border-t border-white/10">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <Volume2 className="w-4 h-4 text-sky-400" />
                    <span className="text-sm font-medium text-slate-200">
                      8-Bit UI Sound Effects
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const next = !settings.sfxEnabled;
                      updateField('sfxEnabled', next);
                      if (next) soundEngine.playSelect();
                      screenReader.speak(
                        next ? '8-bit sound effects enabled.' : '8-bit sound effects muted.'
                      );
                    }}
                    className={`px-3.5 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                      settings.sfxEnabled
                        ? 'bg-sky-400 text-slate-950'
                        : 'bg-white/10 text-slate-300'
                    }`}
                  >
                    {settings.sfxEnabled ? 'On' : 'Off'}
                  </button>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                  <span>Effects Level</span>
                  <span className="font-mono-tabular text-slate-200">
                    {Math.round(settings.sfxVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  disabled={!settings.sfxEnabled}
                  value={Math.round(settings.sfxVolume * 100)}
                  onChange={(e) =>
                    updateField('sfxVolume', Number(e.target.value) / 100)
                  }
                  className="w-full accent-sky-400 cursor-pointer disabled:opacity-40"
                />
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-slate-200">
                    Startup Meteor &amp; Iron Audio
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Realistic crash, iron clang, and spark foley
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const next = !settings.startupAudioEnabled;
                    updateField('startupAudioEnabled', next);
                    if (next) soundEngine.playSelect();
                    else soundEngine.playBack();
                    screenReader.speak(
                      next ? 'Startup audio enabled.' : 'Startup audio muted.'
                    );
                  }}
                  className={`px-3.5 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                    settings.startupAudioEnabled
                      ? 'bg-sky-400 text-slate-950'
                      : 'bg-white/10 text-slate-300'
                  }`}
                >
                  {settings.startupAudioEnabled ? 'On' : 'Off'}
                </button>
              </div>
            </div>

            {/* Sound Test Console */}
            <div className="bg-[#0b1120] border border-white/12 p-6 flex flex-col justify-between">
              <div>
                <h3 className="font-display text-lg font-semibold text-white mb-1">
                  System Sound Preview
                </h3>
                <p className="text-xs text-slate-400 mb-5">
                  Audition 8-bit UI effects, space starfield clash, unlock chime, and meteor crash
                  foley.
                </p>

                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => soundEngine.playHighlight()}
                    className="px-3.5 py-2.5 bg-white/6 hover:bg-white/12 border border-white/12 text-xs font-medium text-slate-100 text-left transition-colors cursor-pointer"
                  >
                    8-Bit Highlight
                  </button>
                  <button
                    type="button"
                    onClick={() => soundEngine.playSelect()}
                    className="px-3.5 py-2.5 bg-white/6 hover:bg-white/12 border border-white/12 text-xs font-medium text-slate-100 text-left transition-colors cursor-pointer"
                  >
                    8-Bit Select
                  </button>
                  <button
                    type="button"
                    onClick={() => soundEngine.playScrollLeft()}
                    className="px-3.5 py-2.5 bg-white/6 hover:bg-white/12 border border-white/12 text-xs font-medium text-slate-100 text-left transition-colors cursor-pointer"
                  >
                    8-Bit Scroll Left
                  </button>
                  <button
                    type="button"
                    onClick={() => soundEngine.playScrollRight()}
                    className="px-3.5 py-2.5 bg-white/6 hover:bg-white/12 border border-white/12 text-xs font-medium text-slate-100 text-left transition-colors cursor-pointer"
                  >
                    8-Bit Scroll Right
                  </button>
                  <button
                    type="button"
                    onClick={() => soundEngine.playScroll()}
                    className="px-3.5 py-2.5 bg-white/6 hover:bg-white/12 border border-white/12 text-xs font-medium text-slate-100 text-left transition-colors cursor-pointer"
                  >
                    8-Bit List Scroll
                  </button>
                  <button
                    type="button"
                    onClick={() => soundEngine.playBack()}
                    className="px-3.5 py-2.5 bg-white/6 hover:bg-white/12 border border-white/12 text-xs font-medium text-slate-100 text-left transition-colors cursor-pointer"
                  >
                    8-Bit Back
                  </button>
                  <button
                    type="button"
                    onClick={() => soundEngine.playHomeUnlock()}
                    className="px-3.5 py-2.5 bg-white/6 hover:bg-white/12 border border-white/12 text-xs font-medium text-sky-300 text-left transition-colors cursor-pointer"
                  >
                    Home Unlock Chime
                  </button>
                  <button
                    type="button"
                    onClick={() => soundEngine.playStarfieldClash()}
                    className="px-3.5 py-2.5 bg-white/6 hover:bg-white/12 border border-white/12 text-xs font-medium text-sky-300 text-left transition-colors cursor-pointer"
                  >
                    Starfield Clash
                  </button>
                  <button
                    type="button"
                    onClick={() => soundEngine.playMeteorImpact()}
                    className="col-span-2 px-3.5 py-2.5 bg-white/6 hover:bg-white/12 border border-white/12 text-xs font-medium text-sky-300 text-left transition-colors cursor-pointer"
                  >
                    Meteor Crash &amp; Iron Sparks
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'accessibility' && (
          <div className="max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Unified Calm US English Soft-Voiced Screen Reader Profile */}
            <div className="lg:col-span-6 bg-[#0b1120] border border-white/12 p-6 flex flex-col justify-between gap-5">
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-display text-lg font-semibold text-white">
                      Accessibility Voice
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Unified across Profile Selection, Home Screen, Settings, and every game or
                      app.
                    </p>
                  </div>
                  <span className="text-[11px] font-mono-tabular text-sky-300 bg-sky-500/10 border border-sky-400/30 px-2.5 py-1 whitespace-nowrap shrink-0">
                    System Lock Active
                  </span>
                </div>

                <div className="p-5 bg-[#0e1b33] border-2 border-sky-400 shadow-[0_0_24px_rgba(56,189,248,0.18)]">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <AudioLines className="w-5 h-5 text-sky-300 shrink-0" />
                      <div>
                        <div className="font-display text-base font-semibold text-white">
                          {activeVoice.name}
                        </div>
                        <div className="text-[11px] font-mono-tabular text-sky-300 mt-0.5">
                          {activeVoice.regionLabel}
                        </div>
                      </div>
                    </div>
                    <span className="px-2.5 py-0.5 text-[10px] font-semibold bg-sky-400 text-slate-950 shrink-0">
                      Active
                    </span>
                  </div>

                  <p className="text-xs text-slate-200 mt-3 leading-relaxed">
                    {activeVoice.description}. Gently ducks background music while speaking so tiles,
                    menus, and console actions remain crisp and effortless to follow.
                  </p>

                  <div className="mt-4 pt-3 border-t border-white/10 flex items-center gap-1.5 text-[11px] font-medium text-sky-300">
                    <Check className="w-3.5 h-3.5" />
                    <span>Consistent calm narration across every screen</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                disabled={!settings.screenReaderEnabled}
                onClick={() => {
                  soundEngine.playSelect();
                  screenReader.speak(
                    `Hello ${profileName}. Welcome to Retro Game System. This is your calm, soft-voiced US English accessibility screen reader, staying consistent across every screen and game.`,
                    { immediate: true, bypassHints: true }
                  );
                }}
                className="w-full py-3 bg-sky-400 hover:bg-sky-300 disabled:opacity-40 text-slate-950 text-xs font-semibold transition-colors cursor-pointer"
              >
                Test Calm Voice ({activeVoice.name})
              </button>
            </div>

            {/* Right Column: Screen Reader Toggle, Level, Speed & Hints */}
            <div className="lg:col-span-6 bg-[#0b1120] border border-white/12 p-6 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Accessibility className="w-4 h-4 text-sky-400" />
                  <div>
                    <div className="text-sm font-medium text-slate-100">
                      Voice Screen Reader
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Reads tiles, menus, and descriptions aloud
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const next = !settings.screenReaderEnabled;
                    updateField('screenReaderEnabled', next);
                    if (next) {
                      soundEngine.playSelect();
                      screenReader.updateSettings({
                        enabled: true,
                        volume: settings.screenReaderVolume,
                        masterVolume: settings.masterVolume,
                        voiceId: 'maya-us',
                        rate: settings.screenReaderRate,
                        hintsEnabled: settings.screenReaderHintsEnabled,
                      });
                      screenReader.speak(
                        `Voice screen reader enabled using ${activeVoice.name}.`,
                        { immediate: true, bypassHints: true }
                      );
                    } else {
                      soundEngine.playBack();
                      screenReader.stop();
                    }
                  }}
                  className={`px-3.5 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                    settings.screenReaderEnabled
                      ? 'bg-sky-400 text-slate-950'
                      : 'bg-white/10 text-slate-300'
                  }`}
                >
                  {settings.screenReaderEnabled ? 'On' : 'Off'}
                </button>
              </div>

              {/* Voice Volume */}
              <div className="pt-4 border-t border-white/10">
                <div className="flex items-center justify-between text-xs text-slate-300 mb-2">
                  <span className="font-medium">Voice Level</span>
                  <span className="font-mono-tabular text-sky-300">
                    {Math.round(settings.screenReaderVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  disabled={!settings.screenReaderEnabled}
                  value={Math.round(settings.screenReaderVolume * 100)}
                  onChange={(e) =>
                    updateField('screenReaderVolume', Number(e.target.value) / 100)
                  }
                  className="w-full accent-sky-400 cursor-pointer disabled:opacity-40"
                />
              </div>

              {/* Speaking Speed */}
              <div className="pt-4 border-t border-white/10">
                <div className="flex items-center justify-between text-xs text-slate-300 mb-2">
                  <span className="flex items-center gap-1.5 font-medium">
                    <Gauge className="w-3.5 h-3.5 text-sky-400" />
                    Speaking Speed
                  </span>
                  <span className="font-mono-tabular text-sky-300">
                    {settings.screenReaderRate.toFixed(2)}x
                  </span>
                </div>
                <input
                  type="range"
                  min={75}
                  max={135}
                  step={5}
                  disabled={!settings.screenReaderEnabled}
                  value={Math.round(settings.screenReaderRate * 100)}
                  onChange={(e) =>
                    updateField('screenReaderRate', Number(e.target.value) / 100)
                  }
                  className="w-full accent-sky-400 cursor-pointer disabled:opacity-40"
                />
                <div className="grid grid-cols-3 gap-2 mt-2.5">
                  {[
                    { label: '0.85x Calm', val: 0.85 },
                    { label: '1.0x Default', val: 1.0 },
                    { label: '1.2x Brisk', val: 1.2 },
                  ].map((preset) => {
                    const activeRate = Math.abs(settings.screenReaderRate - preset.val) < 0.03;
                    return (
                      <button
                        key={preset.val}
                        type="button"
                        disabled={!settings.screenReaderEnabled}
                        onClick={() => {
                          soundEngine.playHighlight();
                          updateField('screenReaderRate', preset.val);
                        }}
                        className={`py-1.5 text-[11px] font-medium border transition-colors cursor-pointer disabled:opacity-40 ${
                          activeRate
                            ? 'bg-sky-400/20 border-sky-400 text-sky-200'
                            : 'bg-white/5 border-white/12 text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        {preset.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Navigation Hints Toggle */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-medium text-slate-100">
                    Spoken Action Hints
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Include &ldquo;Double-tap to open&rdquo; navigation prompts
                  </div>
                </div>
                <button
                  type="button"
                  disabled={!settings.screenReaderEnabled}
                  onClick={() => {
                    const next = !settings.screenReaderHintsEnabled;
                    updateField('screenReaderHintsEnabled', next);
                    soundEngine.playHighlight();
                    screenReader.speak(
                      next
                        ? 'Spoken action hints enabled.'
                        : 'Spoken action hints hidden. Only feature names and descriptions will be read.',
                      { immediate: true, bypassHints: true }
                    );
                  }}
                  className={`px-3.5 py-1.5 text-xs font-semibold transition-colors cursor-pointer disabled:opacity-40 ${
                    settings.screenReaderHintsEnabled
                      ? 'bg-sky-400 text-slate-950'
                      : 'bg-white/10 text-slate-300'
                  }`}
                >
                  {settings.screenReaderHintsEnabled ? 'On' : 'Off'}
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'system' && (
          <div className="max-w-3xl space-y-5">
            <div className="bg-[#0b1120] border border-white/12 p-6 flex items-center justify-between gap-6">
              <div>
                <h3 className="font-display text-base font-semibold text-white">
                  Landscape Fullscreen Mode
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Expand Retro Game System to full screen and lock landscape orientation when
                  supported by your browser.
                </p>
              </div>
              <button
                type="button"
                onFocus={() =>
                  screenReader.speak(
                    isFullscreen
                      ? 'Exit Fullscreen button.'
                      : 'Enter Fullscreen button. Expands launcher to landscape fullscreen.'
                  )
                }
                onClick={() => {
                  soundEngine.playSelect();
                  onToggleFullscreen();
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-sky-400 hover:bg-sky-300 text-slate-950 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Maximize2 className="w-4 h-4" />
                <span>{isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}</span>
              </button>
            </div>

            <div className="bg-[#0b1120] border border-white/12 p-6 flex items-center justify-between gap-6">
              <div>
                <h3 className="font-display text-base font-semibold text-white">
                  Replay Boot Sequence
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Watch the meteor crash, iron &amp; spark reformation into the gold controller, and
                  zoom-and-spin transition again.
                </p>
              </div>
              <button
                type="button"
                onFocus={() =>
                  screenReader.speak(
                    'Replay Intro button. Plays the meteor crash and gold controller startup sequence again.'
                  )
                }
                onClick={() => {
                  soundEngine.playSelect();
                  onReplayStartup();
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/18 border border-white/20 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Play className="w-4 h-4 text-sky-300" />
                <span>Replay Intro</span>
              </button>
            </div>

            <div className="bg-[#0b1120] border border-white/12 p-6 flex items-center justify-between gap-6">
              <div>
                <h3 className="font-display text-base font-semibold text-white">
                  Restore {profileName} Defaults
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Reset wallpaper, music, sound effects, and accessibility settings back to factory
                  defaults.
                </p>
              </div>
              <button
                type="button"
                onFocus={() =>
                  screenReader.speak(
                    `Reset Defaults button. Restores default wallpaper and audio settings for ${profileName}.`
                  )
                }
                onClick={() => {
                  soundEngine.playBack();
                  onUpdateSettings({ ...DEFAULT_SETTINGS });
                  screenReader.speak(`Default settings restored for ${profileName}.`);
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-white/8 hover:bg-white/15 border border-white/15 text-slate-200 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-4 h-4 text-sky-300" />
                <span>Reset Defaults</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
};
