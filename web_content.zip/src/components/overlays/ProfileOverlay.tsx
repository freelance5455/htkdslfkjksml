import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Award, Ghost, LogOut, Sparkles } from 'lucide-react';
import { Profile, WallpaperOption } from '../../types/system';
import { soundEngine } from '../../audio/soundEngine';
import { screenReader } from '../../audio/screenReader';

interface ProfileOverlayProps {
  profile: Profile;
  wallpaper: WallpaperOption;
  onRecordProgress: (xpAmount: number, milestone?: string) => void;
  onSwitchProfile: () => void;
  onClose: () => void;
}

export const ProfileOverlay: React.FC<ProfileOverlayProps> = ({
  profile,
  wallpaper,
  onRecordProgress,
  onSwitchProfile,
  onClose,
}) => {
  const [imgError, setImgError] = useState(false);

  const xpPercent = Math.min(
    100,
    Math.round((profile.progression.xp / Math.max(1, profile.progression.xpToNext)) * 100)
  );

  useEffect(() => {
    screenReader.speak(
      `Profile screen for ${profile.name}. Level ${profile.progression.level}, ${profile.progression.sessionsCount} sessions logged, currently using ${wallpaper.name} wallpaper. Select Go to Profile Selection to switch players.`
    );
  }, [
    profile.name,
    profile.progression.level,
    profile.progression.sessionsCount,
    wallpaper.name,
  ]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 8 }}
      transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
      className="absolute inset-0 z-30 flex flex-col bg-[#060912]/96 p-8 md:p-10"
      onWheel={() => soundEngine.playScroll()}
    >
      <div className="flex items-center justify-between border-b border-white/12 pb-5">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onFocus={() => screenReader.speak('Back button. Returns to Home dashboard.')}
            onClick={() => {
              soundEngine.playBack();
              onClose();
            }}
            className="flex items-center gap-2 px-4 py-2 bg-white/8 hover:bg-white/15 border border-white/15 text-sm font-medium text-white transition-colors cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="w-4 h-4 text-sky-300" />
            <span>Back</span>
          </button>
          <h2 className="font-display text-2xl font-semibold tracking-tight text-white">
            Profile &amp; Saved Progression
          </h2>
        </div>

        <span className="text-xs text-sky-300 font-mono-tabular">
          Level {profile.progression.level} · Auto-Saved
        </span>
      </div>

      <div className="flex-1 overflow-y-auto console-scroll flex flex-col items-center justify-center px-6 py-5">
        <div className="w-full max-w-2xl bg-[#0d1322] border border-white/15 p-6 md:p-8 space-y-6 my-auto">
          <div className="flex flex-col sm:flex-row items-center gap-7">
            <div className="w-32 h-32 aspect-square shrink-0 border-2 border-sky-400 bg-[#090e1a] overflow-hidden flex items-center justify-center">
              {!imgError ? (
                <img
                  src={profile.avatarUrl}
                  alt={profile.name}
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Ghost className="w-14 h-14 text-sky-300" />
              )}
            </div>

            <div className="flex-1 w-full text-center sm:text-left">
              <div className="text-xs text-sky-300 font-medium mb-1">Active Player Slot</div>
              <h3 className="font-display text-2xl font-semibold text-white">
                {profile.name}
              </h3>

              {/* XP Progression Bar */}
              <div className="mt-3">
                <div className="flex items-center justify-between text-xs text-slate-300 mb-1.5 font-mono-tabular">
                  <span>Level {profile.progression.level}</span>
                  <span>
                    {profile.progression.xp} / {profile.progression.xpToNext} XP ({xpPercent}%)
                  </span>
                </div>
                <div className="w-full h-2 bg-[#060912] border border-white/10 overflow-hidden">
                  <div
                    className="h-full bg-sky-400 transition-all duration-300"
                    style={{ width: `${xpPercent}%` }}
                  />
                </div>
              </div>

              <div className="mt-4 grid grid-cols-3 gap-2.5 text-left">
                <div className="bg-[#090e1a] border border-white/10 p-2.5">
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                    Sessions
                  </div>
                  <div className="font-mono-tabular text-sm font-semibold text-white mt-0.5">
                    {profile.progression.sessionsCount}
                  </div>
                </div>
                <div className="bg-[#090e1a] border border-white/10 p-2.5">
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                    Saved Theme
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-medium text-white mt-0.5 truncate">
                    <span
                      className="w-2 h-2 shrink-0"
                      style={{ backgroundColor: wallpaper.accentHex }}
                    />
                    <span className="truncate">{wallpaper.name}</span>
                  </div>
                </div>
                <div className="bg-[#090e1a] border border-white/10 p-2.5">
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                    Games
                  </div>
                  <div className="font-mono-tabular text-sm font-semibold text-white mt-0.5">
                    {profile.gamesCount}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Unlocked Milestones */}
          <div className="border-t border-white/10 pt-5">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-200 mb-3">
              <Award className="w-4 h-4 text-sky-400" />
              <span>Saved Milestones ({profile.progression.unlockedMilestones.length})</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {profile.progression.unlockedMilestones.map((ms) => (
                <span
                  key={ms}
                  className="px-2.5 py-1 bg-sky-500/12 border border-sky-400/30 text-xs text-sky-200"
                >
                  {ms}
                </span>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/10">
            <button
              type="button"
              onClick={() => {
                soundEngine.playSelect();
                onRecordProgress(25, 'Daily Check-In');
                screenReader.speak(
                  `Progress checkpoint saved for ${profile.name}. Plus 25 experience points.`
                );
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-white/8 hover:bg-white/15 border border-white/15 text-slate-100 text-xs font-semibold transition-colors cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-sky-300" />
              <span>Save Check-In (+25 XP)</span>
            </button>

            <button
              type="button"
              onFocus={() =>
                screenReader.speak(
                  'Go to Profile Selection button. Returns to the dark starfield screen to switch or add players.'
                )
              }
              onClick={() => {
                soundEngine.playSelect();
                onSwitchProfile();
              }}
              className="flex items-center gap-2 px-5 py-2.5 bg-sky-400 hover:bg-sky-300 text-slate-950 text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              <LogOut className="w-4 h-4" />
              <span>Go to Profile Selection</span>
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
