import { MapContainer, TileLayer } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import FitToReports from "@/components/map/FitToReports";
import ReportPins from "@/components/map/ReportPins";

const COIMBATORE = [11.012, 76.965];

export default function CityMap({ reports, height = 380 }) {
  const pinned = reports.filter(
    (report) => typeof report.lat === "number" && typeof report.lng === "number"
  );

  return (
    <div
      className="relative z-0 overflow-hidden rounded-2xl border border-border"
      style={{ height }}
    >
      <MapContainer
        center={COIMBATORE}
        zoom={12}
        scrollWheelZoom={false}
        className="h-full w-full"
      >
        <TileLayer
          attribution='Tiles &copy; <a href="https://www.esri.com/">Esri</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}"
          maxZoom={19}
        />
        <FitToReports points={pinned.map((report) => [report.lat, report.lng])} />
        <ReportPins reports={pinned} />
      </MapContainer>
    </div>
  );
}