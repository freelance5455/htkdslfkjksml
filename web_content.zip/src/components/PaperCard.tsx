import React from 'react';
import { 
  FileText, 
  Download, 
  Eye, 
  Heart, 
  Bookmark, 
  CheckCircle2, 
  Calendar, 
  MapPin, 
  School, 
  Sparkles, 
  ShieldCheck,
  FileCheck2,
  Share2
} from 'lucide-react';
import { Paper, Language } from '../types';
import { TRANSLATIONS } from '../lib/translations';

interface PaperCardProps {
  paper: Paper;
  language: Language;
  onSelect: (paper: Paper) => void;
  onBookmarkToggle: (paperId: string) => void;
  isBookmarked: boolean;
  onLikeToggle: (paperId: string) => void;
  isLiked: boolean;
  onDownload: (paper: Paper) => void;
}

export const PaperCard: React.FC<PaperCardProps> = ({
  paper,
  language,
  onSelect,
  onBookmarkToggle,
  isBookmarked,
  onLikeToggle,
  isLiked,
  onDownload
}) => {
  const t = TRANSLATIONS[language];

  // Medium color theme
  const mediumColor = 
    paper.medium === 'Sinhala' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' :
    paper.medium === 'English' ? 'bg-sky-500/10 text-sky-400 border-sky-500/30' :
    'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 hover:border-slate-700 hover:shadow-2xl hover:shadow-amber-500/5 transition-all flex flex-col justify-between group relative overflow-hidden">
      
      {/* Top Header Tags */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="px-2.5 py-0.5 text-[11px] font-extrabold rounded-lg bg-amber-500 text-slate-950 uppercase tracking-wider">
              {paper.grade}
            </span>
            <span className={`px-2.5 py-0.5 text-[11px] font-bold rounded-lg border ${mediumColor}`}>
              {paper.medium}
            </span>
            <span className="px-2.5 py-0.5 text-[11px] font-semibold rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
              {paper.paperType}
            </span>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onBookmarkToggle(paper.id);
            }}
            className={`p-1.5 rounded-xl transition-all cursor-pointer ${
              isBookmarked ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
            title="Bookmark Paper"
          >
            <Bookmark className="w-4 h-4 fill-current" />
          </button>
        </div>

        {/* Paper Title */}
        <h3
          onClick={() => onSelect(paper)}
          className="text-base font-bold text-white group-hover:text-amber-300 cursor-pointer line-clamp-2 transition-colors mb-2 leading-snug"
        >
          {paper.title}
        </h3>

        {/* Metadata Badges (Subject, School, Year, Province) */}
        <div className="space-y-1.5 mb-4 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="font-bold text-slate-200">{paper.subject}</span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-300 font-medium">{paper.year}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <School className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span className="line-clamp-1">{paper.school}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span>{paper.province} Province</span>
            {paper.hasMarkingScheme && (
              <span className="ml-auto inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                <FileCheck2 className="w-3 h-3" />
                <span>Marking Scheme</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Uploader & Actions Footer */}
      <div className="pt-3 border-t border-slate-800/80 space-y-3">
        
        {/* Uploader pill & Stats */}
        <div className="flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <img
              src={paper.uploaderAvatar}
              alt={paper.uploaderName}
              className="w-6 h-6 rounded-full object-cover ring-1 ring-amber-500/30"
            />
            <span className="text-[11px] font-semibold text-slate-300 line-clamp-1">
              {paper.uploaderName}
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <Eye className="w-3.5 h-3.5 text-slate-500" />
              <span>{paper.viewsCount}</span>
            </span>
            <span className="flex items-center gap-1">
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-bold text-amber-300">{paper.downloadCount}</span>
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => onSelect(paper)}
            className="w-full py-2 px-3 text-xs font-bold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700/80 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5 text-amber-400" />
            <span>{t.previewBtn}</span>
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onDownload(paper);
            }}
            className="w-full py-2 px-3 text-xs font-bold rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-500/10 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.downloadBtn}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
