import { useEffect, useRef } from 'react';
import { Check, Copy, Download, Loader2, Wand2 } from 'lucide-react';
import { resolveEffectiveOutputLanguage } from '../constants/languages';
import {
  countWords,
  getTextDirection,
  getTranscriptFontClass,
} from '../utils/formatting';

interface WrittenSheetProps {
  writtenText: string;
  livePreviewText: string;
  speakingCode: string;
  outputCode: string;
  isTranslatingSheet: boolean;
  isCommittingNext: boolean;
  isEnhancingSheet: boolean;
  justEnhanced: boolean;
  copied: boolean;
  downloaded: boolean;
  onWrittenTextChange: (nextText: string) => void;
  onEnhanceText: () => void;
  onCopyText: () => void;
  onDownloadTxt: () => void;
}

export function WrittenSheet({
  writtenText,
  livePreviewText,
  speakingCode,
  outputCode,
  isTranslatingSheet,
  isCommittingNext,
  isEnhancingSheet,
  justEnhanced,
  copied,
  downloaded,
  onWrittenTextChange,
  onEnhanceText,
  onCopyText,
  onDownloadTxt,
}: WrittenSheetProps) {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const effectiveLang = resolveEffectiveOutputLanguage(speakingCode, outputCode);
  const combinedForScript = writtenText || livePreviewText;
  const dir = getTextDirection(effectiveLang.code, combinedForScript);
  const fontClass = getTranscriptFontClass(effectiveLang.code, combinedForScript);
  const totalWords = countWords([writtenText, livePreviewText].filter(Boolean).join(' '));
  const hasAnyText = Boolean(writtenText.trim() || livePreviewText.trim());
  const canEnhance =
    Boolean(writtenText.trim()) &&
    !isEnhancingSheet &&
    !isTranslatingSheet &&
    !isCommittingNext;

  // Auto-resize textarea cleanly as full paragraphs grow (no forced page scroll)
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.max(220, el.scrollHeight)}px`;
  }, [writtenText]);

  return (
    <section
      aria-label="Written Text Document"
      className="flex h-full min-h-[360px] flex-col rounded-2xl border border-slate-200/90 bg-white p-5 shadow-[0_2px_16px_rgba(15,23,42,0.04)] sm:p-6"
    >
      {/* Clean Header with metadata + Enhance, Copy, and Clean .TXT Download buttons */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2.5 border-b border-slate-100 pb-3.5">
        <div className="flex items-center gap-2">
          <h2 className="text-sm font-semibold text-slate-900">Written Text</h2>
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span aria-hidden="true">·</span>
            <span>{effectiveLang.englishName}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">
              {totalWords} {totalWords === 1 ? 'word' : 'words'}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {isTranslatingSheet ? (
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-600">
              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
              <span>Translating...</span>
            </span>
          ) : isCommittingNext ? (
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-600">
              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
              <span>Formatting...</span>
            </span>
          ) : null}

          <button
            type="button"
            onClick={onEnhanceText}
            disabled={!canEnhance}
            title="Fix broken words, punctuation, and capitalization with AI"
            className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50/80 px-3 py-1.5 text-xs font-semibold text-blue-700 whitespace-nowrap transition-colors hover:border-blue-300 hover:bg-blue-100/80 active:scale-[0.98] disabled:cursor-not-allowed disabled:border-slate-200 disabled:bg-slate-50 disabled:text-slate-400"
          >
            {isEnhancingSheet ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin shrink-0" aria-hidden="true" />
                <span>Enhancing...</span>
              </>
            ) : justEnhanced ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0" aria-hidden="true" />
                <span>Enhanced</span>
              </>
            ) : (
              <>
                <Wand2 className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                <span>Enhance</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={onCopyText}
            disabled={!hasAnyText}
            aria-label="Copy clean text"
            title="Copy clean text"
            className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 whitespace-nowrap transition-colors hover:bg-slate-50 hover:text-slate-900 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-45"
          >
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0" aria-hidden="true" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                <span>Copy</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={onDownloadTxt}
            disabled={!hasAnyText}
            aria-label="Download clean text as .txt file"
            title="Download clean text (.txt)"
            className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 whitespace-nowrap transition-colors hover:border-blue-200 hover:bg-blue-50/60 hover:text-blue-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-45"
          >
            {downloaded ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0" aria-hidden="true" />
                <span>Saved</span>
              </>
            ) : (
              <>
                <Download className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                <span>TXT</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Pure-White Writing Canvas (writes full text cleanly below without forced auto-scroll) */}
      <div className="flex flex-1 flex-col">
        <textarea
          ref={textareaRef}
          dir={writtenText ? dir : 'ltr'}
          value={writtenText}
          onChange={(e) => onWrittenTextChange(e.target.value)}
          placeholder={
            livePreviewText
              ? ''
              : 'Your full spoken text writes cleanly here line by line. Press Next after each sentence or paragraph to lock it in.'
          }
          aria-label="Written transcript text"
          className={`w-full flex-1 resize-none border-0 bg-transparent p-0 text-[17px] text-slate-900 placeholder:font-sans placeholder:text-sm placeholder:text-slate-400 focus:outline-none ${
            writtenText ? fontClass : 'font-sans'
          }`}
        />

        {/* Real-time full text flowing cleanly underneath committed paragraphs */}
        {livePreviewText && (
          <div
            dir={dir}
            className={`mt-3 border-t border-dashed border-slate-200 pt-3 text-[17px] text-slate-600 ${fontClass}`}
          >
            <p className="whitespace-pre-wrap">{livePreviewText}</p>
          </div>
        )}
      </div>
    </section>
  );
}
