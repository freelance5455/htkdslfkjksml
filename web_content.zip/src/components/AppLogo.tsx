import React from 'react';

interface AppLogoProps {
  size?: number;
  className?: string;
  withGlow?: boolean;
}

/**
 * Dignified Islamic App Emblem: The Holy Quran on wooden Rehal with gilded crescent & star
 * Deep obsidian emerald medallion with royal gold accents.
 */
export const AppLogo: React.FC<AppLogoProps> = ({ 
  size = 54, 
  className = '',
  withGlow = true
}) => {
  const uniqueId = React.useId().replace(/:/g, '');
  const goldGradId = `gold-grad-${uniqueId}`;
  const goldLightGradId = `gold-light-${uniqueId}`;
  const deepEmeraldGradId = `deep-emerald-${uniqueId}`;
  const auraGlowId = `aura-glow-${uniqueId}`;
  const pageGradId = `page-grad-${uniqueId}`;
  const woodGradId = `wood-grad-${uniqueId}`;

  return (
    <div 
      className={`relative inline-flex items-center justify-center select-none shrink-0 ${className}`}
      style={{ width: size, height: size }}
      role="img"
      aria-label="شعار حصن المسلم - المصحف الشريف والهلال المبارك"
    >
      {/* Soft Ambient Eye-Comfortable Emerald Glow */}
      {withGlow && (
        <div 
          className="absolute inset-0 rounded-full bg-emerald-500/25 blur-md transform scale-110 pointer-events-none"
        />
      )}

      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="relative z-10 drop-shadow-lg"
      >
        <defs>
          {/* Deep Islamic Emerald Background Gradient */}
          <linearGradient id={deepEmeraldGradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#064e3b" />
            <stop offset="45%" stopColor="#032c21" />
            <stop offset="100%" stopColor="#011610" />
          </linearGradient>

          {/* Warm Royal Gold Gradient */}
          <linearGradient id={goldGradId} x1="20%" y1="0%" x2="80%" y2="100%">
            <stop offset="0%" stopColor="#FEF3C7" />
            <stop offset="30%" stopColor="#F59E0B" />
            <stop offset="70%" stopColor="#D97706" />
            <stop offset="100%" stopColor="#92400E" />
          </linearGradient>

          {/* Light Gilded Gold */}
          <linearGradient id={goldLightGradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFBEB" />
            <stop offset="50%" stopColor="#FDE68A" />
            <stop offset="100%" stopColor="#F59E0B" />
          </linearGradient>

          {/* Sacred Mushaf Pages Ivory Gradient */}
          <linearGradient id={pageGradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="60%" stopColor="#FBF7EE" />
            <stop offset="100%" stopColor="#EFE5CD" />
          </linearGradient>

          {/* Traditional Carved Wooden Stand (Rehal) Gradient */}
          <linearGradient id={woodGradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#9A3412" />
            <stop offset="40%" stopColor="#78350F" />
            <stop offset="100%" stopColor="#451A03" />
          </linearGradient>

          {/* Luminous Divine Aura */}
          <radialGradient id={auraGlowId} cx="50%" cy="45%" r="50%">
            <stop offset="0%" stopColor="#FDE68A" stopOpacity="0.45" />
            <stop offset="40%" stopColor="#10B981" stopOpacity="0.18" />
            <stop offset="100%" stopColor="#02140E" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Outer Circular Disc */}
        <circle 
          cx="50" 
          cy="50" 
          r="47.5" 
          fill={`url(#${deepEmeraldGradId})`} 
          stroke={`url(#${goldGradId})`} 
          strokeWidth="2.2" 
        />

        {/* Inner Subtle Beaded Ring */}
        <circle 
          cx="50" 
          cy="50" 
          r="44" 
          stroke={`url(#${goldGradId})`} 
          strokeWidth="0.75" 
          strokeDasharray="2 3" 
          strokeOpacity="0.6" 
        />

        {/* Divine Light Aura */}
        <circle cx="50" cy="50" r="42" fill={`url(#${auraGlowId})`} />

        {/* Radiating Light Rays behind Holy Quran */}
        <g stroke={`url(#${goldLightGradId})`} strokeWidth="0.8" strokeOpacity="0.35">
          <line x1="50" y1="42" x2="50" y2="24" />
          <line x1="50" y1="42" x2="36" y2="26" />
          <line x1="50" y1="42" x2="64" y2="26" />
          <line x1="50" y1="42" x2="25" y2="34" />
          <line x1="50" y1="42" x2="75" y2="34" />
        </g>

        {/* Celestial Crescent at Top Arch */}
        <path
          d="M50 14C53 14 55.5 15.5 56.5 17C53.5 16 51 17 49.5 19C48 17.5 48.5 15 50 14Z"
          fill={`url(#${goldLightGradId})`}
        />

        {/* Brilliant 8-pointed star inside crescent */}
        <path
          d="M50 20L50.7 21.6L52.5 22.3L50.7 23L50 24.8L49.3 23L47.5 22.3L49.3 21.6L50 20Z"
          fill={`url(#${goldLightGradId})`}
        />

        {/* ========================================= */}
        {/* CARVED WOODEN QURAN STAND (REHAL / رحل)   */}
        {/* ========================================= */}
        {/* Left Leg of the Wooden Stand */}
        <path
          d="M32 64L24 78C23.5 79 24.5 80 26 80H35L47 62H41L32 64Z"
          fill={`url(#${woodGradId})`}
          stroke={`url(#${goldGradId})`}
          strokeWidth="0.6"
        />
        {/* Right Leg of the Wooden Stand */}
        <path
          d="M68 64L76 78C76.5 79 75.5 80 74 80H65L53 62H59L68 64Z"
          fill={`url(#${woodGradId})`}
          stroke={`url(#${goldGradId})`}
          strokeWidth="0.6"
        />
        {/* Central Wooden X-Cross Joint */}
        <path
          d="M44 60L50 67L56 60L50 56L44 60Z"
          fill="#3B1700"
          stroke={`url(#${goldGradId})`}
          strokeWidth="0.75"
        />

        {/* ========================================= */}
        {/* THE HOLY QURAN (المصحف الشريف المفتوح)     */}
        {/* ========================================= */}
        {/* Hardcover Green & Gilded Binding Shadow */}
        <path
          d="M21 54C28 50 42 49 50 54C58 49 72 50 79 54L78 57C71 53 58 52 50 56.5C42 52 29 53 22 57L21 54Z"
          fill="#064E3B"
          stroke={`url(#${goldGradId})`}
          strokeWidth="0.8"
        />

        {/* Left Pages of the Holy Quran */}
        <path
          d="M50 53.5C42 49 28 50 22 53.5L24 37C30 34 43 33 50 37.5V53.5Z"
          fill={`url(#${pageGradId})`}
          stroke={`url(#${goldGradId})`}
          strokeWidth="0.8"
        />
        {/* Right Pages of the Holy Quran */}
        <path
          d="M50 53.5C58 49 72 50 78 53.5L76 37C70 34 57 33 50 37.5V53.5Z"
          fill={`url(#${pageGradId})`}
          stroke={`url(#${goldGradId})`}
          strokeWidth="0.8"
        />

        {/* Gilded Borders on Left Page */}
        <path
          d="M48 39C42 35.5 32 36.5 26.5 39L25.5 51C30.5 48.5 41 47.5 48 51V39Z"
          stroke={`url(#${goldGradId})`}
          strokeWidth="0.6"
          fill="none"
          strokeOpacity="0.8"
        />
        {/* Gilded Borders on Right Page */}
        <path
          d="M52 39C58 35.5 68 36.5 73.5 39L74.5 51C69.5 48.5 59 47.5 52 51V39Z"
          stroke={`url(#${goldGradId})`}
          strokeWidth="0.6"
          fill="none"
          strokeOpacity="0.8"
        />

        {/* Symbolic Sacred Arabic Calligraphy Lines on Left Page */}
        <g stroke={`url(#${goldGradId})`} strokeWidth="0.8" strokeLinecap="round" strokeOpacity="0.75">
          <line x1="30" y1="41" x2="45" y2="40" />
          <line x1="29" y1="44" x2="46" y2="43" />
          <line x1="28" y1="47" x2="46" y2="46" />
        </g>
        {/* Symbolic Sacred Arabic Calligraphy Lines on Right Page */}
        <g stroke={`url(#${goldGradId})`} strokeWidth="0.8" strokeLinecap="round" strokeOpacity="0.75">
          <line x1="55" y1="40" x2="70" y2="41" />
          <line x1="54" y1="43" x2="71" y2="44" />
          <line x1="54" y1="46" x2="72" y2="47" />
        </g>

        {/* Holy Quran Ribbon Bookmark (الفواصل المذهبة) */}
        <path
          d="M50 38C50.5 43 51 52 50 60C49.5 63 47.5 67 46 69L50 67L54 69C52.5 67 50.5 63 50 60V38Z"
          fill={`url(#${goldLightGradId})`}
        />

        {/* Small Sacred Ornamental Center Medallions */}
        <circle cx="37" cy="48.5" r="1.2" fill={`url(#${goldGradId})`} />
        <circle cx="63" cy="48.5" r="1.2" fill={`url(#${goldGradId})`} />
      </svg>
    </div>
  );
};
