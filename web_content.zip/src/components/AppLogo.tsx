import React from 'react';

interface AppLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  gradient?: string;
  glowColor?: string;
}

export const AppLogo: React.FC<AppLogoProps> = ({
  size = 'md',
  className = '',
  gradient,
  glowColor,
}) => {
  // Dimension & typography configurations
  const config = {
    sm: {
      container: 'w-8 h-8 rounded-xl',
      textSize: 'text-base',
      strokeWidth: 2,
      r: 13.5,
    },
    md: {
      container: 'w-9 h-9 rounded-2xl',
      textSize: 'text-lg',
      strokeWidth: 2.2,
      r: 13.8,
    },
    lg: {
      container: 'w-10 h-10 rounded-xl',
      textSize: 'text-xl',
      strokeWidth: 2.3,
      r: 14,
    },
    xl: {
      container: 'w-14 h-14 rounded-2xl',
      textSize: 'text-2xl',
      strokeWidth: 2.8,
      r: 14,
    },
  }[size];

  const defaultGradient = 'linear-gradient(135deg, #059669 0%, #10b981 50%, #047857 100%)';
  const defaultGlow = '#059669';

  return (
    <div
      className={`relative ${config.container} flex items-center justify-center text-white font-black select-none shrink-0 overflow-hidden shadow-lg transition-transform ${className}`}
      style={{
        background: gradient || defaultGradient,
        boxShadow: `0 8px 20px -3px ${glowColor || defaultGlow}50`,
      }}
    >
      {/* Inner Circular Outline matching the stroke thickness and exact white color of the 'ট'/৳ character */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none"
        viewBox="0 0 36 36"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle
          cx="18"
          cy="18"
          r={config.r}
          stroke="#ffffff"
          strokeWidth={config.strokeWidth}
          strokeLinecap="round"
        />
      </svg>

      {/* Taka Symbol ৳ / 'ট' in bold white */}
      <span className={`relative z-10 leading-none ${config.textSize} pt-0.5 drop-shadow-sm`}>
        ৳
      </span>
    </div>
  );
};
