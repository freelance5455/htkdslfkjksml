import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, ChevronDown, Sparkles, Timer, ArrowUpRight, Check, Activity } from 'lucide-react';
import { DateTime } from 'luxon';
import {
  parseNYInput,
  formatDisplayDate,
  formatDisplayTime,
  formatInputDate,
  formatInputTime,
  getNYTzAbbr,
  getOffsetDiffDescription,
  getCurrentNYDateTime,
  getJaswanthKillZones,
  NY_ZONE,
  INDIA_ZONE,
} from '../utils/timeZone';
import { ConversionRecord, AppSettings } from '../types';
import { DateTimePickerModal } from './DateTimePickerModal';
import { playTickSound, playStartChime } from '../utils/audio';

interface ConverterViewProps {
  settings: AppSettings;
  onSaveRecord: (record: ConversionRecord) => void;
  presetToLoad: ConversionRecord | null;
  onClearPreset: () => void;
}

export const ConverterView: React.FC<ConverterViewProps> = ({
  settings,
  onSaveRecord,
  presetToLoad,
  onClearPreset,
}) => {
  // Input fields (defaulting to 16/05/2025 and 08:46:00 as shown in the screenshot)
  const [startDateStr, setStartDateStr] = useState<string>('16/05/2025');
  const [startTimeStr, setStartTimeStr] = useState<string>('08:46:00');

  // Clock running state
  // anchorNYMillis: the exact simulated New York timestamp (in milliseconds) at anchorStartRealMillis
  const [anchorNYMillis, setAnchorNYMillis] = useState<number>(() => {
    return parseNYInput('16/05/2025', '08:46:00').toMillis();
  });
  const [anchorStartRealMillis, setAnchorStartRealMillis] = useState<number | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [pausedElapsedMillis, setPausedElapsedMillis] = useState<number>(0);

  // Future countdown state
  const [isCountingDown, setIsCountingDown] = useState<boolean>(false);
  const [countdownRemainingSecs, setCountdownRemainingSecs] = useState<number>(0);

  // Active instant displayed on clocks
  const [currentNYDt, setCurrentNYDt] = useState<DateTime>(() => {
    return parseNYInput('16/05/2025', '08:46:00');
  });

  // Modal picker states
  const [pickerModal, setPickerModal] = useState<{
    isOpen: boolean;
    type: 'date' | 'time';
  }>({
    isOpen: false,
    type: 'date',
  });

  // Load preset if requested from History
  useEffect(() => {
    if (presetToLoad) {
      setStartDateStr(presetToLoad.nyDateFormatted);
      setStartTimeStr(presetToLoad.nyTimeFormatted);
      const parsed = parseNYInput(presetToLoad.nyDateFormatted, presetToLoad.nyTimeFormatted);
      setAnchorNYMillis(parsed.toMillis());
      setAnchorStartRealMillis(Date.now());
      setPausedElapsedMillis(0);
      setIsRunning(true);
      setIsCountingDown(false);
      setCurrentNYDt(parsed);
      onClearPreset();
    }
  }, [presetToLoad, onClearPreset]);

  // Main real-time clock advance loop
  useEffect(() => {
    let timerId: number | undefined;

    const tick = () => {
      if (isCountingDown) {
        const now = Date.now();
        const targetMillis = anchorNYMillis;
        const diffMs = targetMillis - now;
        if (diffMs <= 0) {
          // Countdown reached! Start running
          setIsCountingDown(false);
          setIsRunning(true);
          setAnchorStartRealMillis(Date.now());
          setPausedElapsedMillis(0);
          if (settings.audioTick) playStartChime();
        } else {
          setCountdownRemainingSecs(Math.ceil(diffMs / 1000));
        }
        return;
      }

      if (isRunning && anchorStartRealMillis !== null) {
        const realElapsed = Date.now() - anchorStartRealMillis + pausedElapsedMillis;
        const simulatedMillis = anchorNYMillis + realElapsed;
        const updatedDt = DateTime.fromMillis(simulatedMillis, { zone: NY_ZONE });
        setCurrentNYDt(updatedDt);
      }
    };

    // Run tick immediately and then every 250ms for snappy, smooth seconds sync
    tick();
    timerId = window.setInterval(tick, 250);

    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [isRunning, isCountingDown, anchorStartRealMillis, anchorNYMillis, pausedElapsedMillis, settings.audioTick]);

  // Handle "▶ Start from selected time"
  const handleStartFromSelected = (forceImmediate: boolean = false) => {
    const selectedNY = parseNYInput(startDateStr, startTimeStr);
    const targetMillis = selectedNY.toMillis();
    const now = Date.now();

    // Check if future relative to real now
    if (!forceImmediate && targetMillis > now) {
      // It's in the future! Start countdown mode
      const remainingSecs = Math.ceil((targetMillis - now) / 1000);
      setCountdownRemainingSecs(remainingSecs);
      setIsCountingDown(true);
      setIsRunning(false);
      setAnchorNYMillis(targetMillis);
      setPausedElapsedMillis(0);
      setCurrentNYDt(selectedNY);
      if (settings.audioTick) playStartChime();
      return;
    }

    // Normal or forced immediate start
    setIsCountingDown(false);
    setAnchorNYMillis(targetMillis);
    setAnchorStartRealMillis(Date.now());
    setPausedElapsedMillis(0);
    setIsRunning(true);
    setCurrentNYDt(selectedNY);

    if (settings.audioTick) {
      playStartChime();
    }

    // Save to History
    const indiaDt = selectedNY.setZone(INDIA_ZONE);
    const offsetDiff = getOffsetDiffDescription(selectedNY);
    const newRecord: ConversionRecord = {
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: Date.now(),
      nyDateFormatted: startDateStr,
      nyTimeFormatted: startTimeStr,
      nyFullDateDisplay: formatDisplayDate(selectedNY),
      nyTimeDisplay: formatDisplayTime(selectedNY, settings.use24Hour),
      nyTzAbbr: getNYTzAbbr(selectedNY),
      nyOffsetString: offsetDiff.nyOffsetLabel,
      indiaFullDateDisplay: formatDisplayDate(indiaDt),
      indiaTimeDisplay: formatDisplayTime(indiaDt, settings.use24Hour),
      indiaTzAbbr: 'IST',
      indiaOffsetString: 'UTC+5:30',
      offsetDiffHours: offsetDiff.diffFormatted,
    };
    onSaveRecord(newRecord);
  };

  // Handle "Set current time"
  const handleSetCurrentTime = () => {
    const currentNY = getCurrentNYDateTime();
    const newDate = formatInputDate(currentNY);
    const newTime = formatInputTime(currentNY);
    setStartDateStr(newDate);
    setStartTimeStr(newTime);
    setCurrentNYDt(currentNY);

    // If currently running, sync the anchor to real time now
    if (isRunning) {
      setAnchorNYMillis(currentNY.toMillis());
      setAnchorStartRealMillis(Date.now());
      setPausedElapsedMillis(0);
    }
  };

  // Handle Pause/Resume
  const handleTogglePause = () => {
    if (isRunning) {
      // Pause
      if (anchorStartRealMillis !== null) {
        const elapsedSinceStart = Date.now() - anchorStartRealMillis;
        setPausedElapsedMillis((prev) => prev + elapsedSinceStart);
      }
      setIsRunning(false);
    } else {
      // Resume
      setAnchorStartRealMillis(Date.now());
      setIsRunning(true);
    }
  };

  // Handle Reset to 16/05/2025 08:46:00
  const handleReset = () => {
    setIsRunning(false);
    setIsCountingDown(false);
    setPausedElapsedMillis(0);
    setAnchorStartRealMillis(null);
    setStartDateStr('16/05/2025');
    setStartTimeStr('08:46:00');
    const initialDt = parseNYInput('16/05/2025', '08:46:00');
    setAnchorNYMillis(initialDt.toMillis());
    setCurrentNYDt(initialDt);
  };

  // India clock instant is calculated directly from currentNYDt!
  // This guarantees 100% mathematical synchronization at the exact same instant.
  const currentIndiaDt = currentNYDt.setZone(INDIA_ZONE);
  const nyOffsetInfo = getOffsetDiffDescription(currentNYDt);
  const killZones = getJaswanthKillZones(currentNYDt);
  const activeKillZones = killZones.filter((z) => z.isActive);

  // Format countdown string: "02h 15m 30s"
  const formatCountdown = (totalSecs: number) => {
    const hours = Math.floor(totalSecs / 3600);
    const minutes = Math.floor((totalSecs % 3600) / 60);
    const seconds = totalSecs % 60;
    return `${String(hours).padStart(2, '0')}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`;
  };

  return (
    <div className="space-y-3.5 pb-24 animate-in fade-in duration-150">
      {/* Description text matching screenshot */}
      <p className="text-[13px] text-slate-500 font-normal leading-relaxed">
        Set a date and time to start both clocks from that moment.
      </p>

      {/* Main Input Card matching screenshot */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100/90">
        {/* Start date */}
        <div className="mb-3">
          <label className="block text-[13px] font-medium text-slate-600 mb-1.5">
            Start date
          </label>
          <button
            type="button"
            onClick={() => setPickerModal({ isOpen: true, type: 'date' })}
            className="w-full flex items-center justify-between px-3.5 py-2.5 bg-white border border-slate-200/90 hover:border-blue-400 rounded-xl text-left transition-colors group cursor-pointer"
          >
            <span className="text-[15px] font-medium text-slate-900 tracking-tight">
              {startDateStr}
            </span>
            <ChevronDown className="w-4 h-4 text-slate-500 group-hover:text-blue-600 transition-colors" />
          </button>
        </div>

        {/* Start time */}
        <div className="mb-4">
          <label className="block text-[13px] font-medium text-slate-600 mb-1.5">
            Start time
          </label>
          <button
            type="button"
            onClick={() => setPickerModal({ isOpen: true, type: 'time' })}
            className="w-full flex items-center justify-between px-3.5 py-2.5 bg-white border border-slate-200/90 hover:border-blue-400 rounded-xl text-left transition-colors group cursor-pointer"
          >
            <span className="text-[15px] font-medium text-slate-900 font-mono tracking-tight">
              {startTimeStr}
            </span>
            <ChevronDown className="w-4 h-4 text-slate-500 group-hover:text-blue-600 transition-colors" />
          </button>
        </div>

        {/* Action Buttons matching screenshot */}
        <div className="space-y-2.5">
          {/* "▶ Start from selected time" button */}
          <button
            type="button"
            onClick={() => handleStartFromSelected(false)}
            className="w-full py-3 px-4 bg-[#e8f0fe] hover:bg-[#d9e7fd] text-slate-900 font-semibold text-[15px] rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.99] shadow-xs cursor-pointer"
          >
            <span className="text-slate-900 text-xs">▶</span>
            <span>Start from selected time</span>
          </button>

          {/* Row with "Set current time" and auxiliary controls */}
          <div className="flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={handleSetCurrentTime}
              className="py-2.5 px-4 bg-[#e8f0fe] hover:bg-[#d9e7fd] text-slate-900 font-medium text-[14px] rounded-xl transition-all active:scale-[0.99] cursor-pointer"
            >
              Set current time
            </button>

            <div className="flex items-center gap-1.5">
              {/* Play/Pause toggle when running */}
              {isRunning && (
                <button
                  type="button"
                  onClick={handleTogglePause}
                  className="py-2.5 px-3 bg-amber-50 hover:bg-amber-100 text-amber-800 font-medium text-xs rounded-xl flex items-center gap-1 transition-colors cursor-pointer"
                  title="Pause clocks"
                >
                  <Pause size={14} />
                  <span>Pause</span>
                </button>
              )}
              {!isRunning && anchorStartRealMillis !== null && !isCountingDown && (
                <button
                  type="button"
                  onClick={handleTogglePause}
                  className="py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-medium text-xs rounded-xl flex items-center gap-1 transition-colors cursor-pointer"
                  title="Resume clocks"
                >
                  <Play size={14} className="fill-emerald-800" />
                  <span>Resume</span>
                </button>
              )}

              {/* Reset button */}
              <button
                type="button"
                onClick={handleReset}
                className="p-2.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                title="Reset to default reference"
              >
                <RotateCcw size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* Future Countdown Alert if triggered */}
        {isCountingDown && (
          <div className="mt-3.5 p-3 rounded-xl bg-amber-50/80 border border-amber-200/80 text-amber-900 text-xs animate-in fade-in">
            <div className="flex items-center justify-between mb-1">
              <span className="font-semibold flex items-center gap-1.5">
                <Timer size={14} className="text-amber-600 animate-spin" />
                <span>Future moment selected:</span>
              </span>
              <span className="font-mono font-bold text-sm bg-amber-200/60 px-2 py-0.5 rounded">
                {formatCountdown(countdownRemainingSecs)}
              </span>
            </div>
            <p className="text-[11px] text-amber-700 leading-tight mb-2">
              Clocks will automatically start advancing when this moment arrives.
            </p>
            <button
              type="button"
              onClick={() => handleStartFromSelected(true)}
              className="w-full py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-semibold text-xs transition-colors"
            >
              Simulate Immediately (Skip Countdown)
            </button>
          </div>
        )}

        {/* Running status badge */}
        {isRunning && (
          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="font-medium text-slate-700">Clocks running live</span>
            </span>
            <span className="text-[11px] text-slate-400">
              Synchronized 1:1 in real time
            </span>
          </div>
        )}
      </div>

      {/* New York Card matching screenshot */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-100/90 relative overflow-hidden">
        {/* Header: Flag + Name + Timezone indicator */}
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <span className="text-base" role="img" aria-label="USA flag">
              🇺🇸
            </span>
            <span className="text-[15px] font-medium text-slate-700">
              New York
            </span>
          </div>

          {/* Timezone Indicator tag: EDT or EST */}
          <div className="flex items-center gap-1.5">
            <span
              className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                nyOffsetInfo.isDST
                  ? 'bg-amber-100/80 text-amber-800'
                  : 'bg-blue-100/80 text-blue-800'
              }`}
              title={`New York is in ${nyOffsetInfo.isDST ? 'Daylight Saving Time (EDT, UTC-4)' : 'Standard Time (EST, UTC-5)'}`}
            >
              {getNYTzAbbr(currentNYDt)}
            </span>
            <span className="text-[10px] font-mono text-slate-400 font-medium">
              {nyOffsetInfo.nyOffsetLabel}
            </span>
          </div>
        </div>

        {/* Large Digital Time */}
        <div className="py-1">
          <div className="text-[32px] sm:text-[38px] font-bold tracking-tight text-slate-900 font-mono leading-none">
            {formatDisplayTime(currentNYDt, settings.use24Hour)}
          </div>
        </div>

        {/* Date Display */}
        <div className="text-[13px] font-normal text-slate-500 mt-1">
          {formatDisplayDate(currentNYDt)}
        </div>

        {/* Optional Active Kill Zone Badge */}
        {settings.showKillzones && activeKillZones.length > 0 && (
          <div className="mt-3 pt-2.5 border-t border-slate-100 flex flex-wrap gap-1.5 items-center">
            {activeKillZones.map((zone) => (
              <span
                key={zone.id}
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/60"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>{zone.name} (Active)</span>
              </span>
            ))}
          </div>
        )}
      </div>

      {/* India (IST) Card matching screenshot */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-100/90 relative overflow-hidden">
        {/* Header: Flag + Name + IST Indicator */}
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <span className="text-base" role="img" aria-label="India flag">
              🇮🇳
            </span>
            <span className="text-[15px] font-medium text-slate-700">
              India (IST)
            </span>
          </div>

          {/* Timezone Indicator tag: IST */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-amber-100/80 text-amber-800">
              IST
            </span>
            <span className="text-[10px] font-mono text-slate-400 font-medium">
              UTC+5:30
            </span>
          </div>
        </div>

        {/* Large Digital Time */}
        <div className="py-1">
          <div className="text-[32px] sm:text-[38px] font-bold tracking-tight text-slate-900 font-mono leading-none">
            {formatDisplayTime(currentIndiaDt, settings.use24Hour)}
          </div>
        </div>

        {/* Date Display */}
        <div className="flex items-center justify-between text-[13px] font-normal text-slate-500 mt-1">
          <span>{formatDisplayDate(currentIndiaDt)}</span>
          <span className="text-[11px] font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">
            IST is {nyOffsetInfo.diffFormatted} ahead
          </span>
        </div>
      </div>

      {/* Jaswanth Kill Zones Table Card */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-100/90">
        <div className="flex items-center justify-between mb-2.5">
          <div>
            <h3 className="text-[15px] font-bold text-slate-900 tracking-tight">
              Jaswanth Kill Zones
            </h3>
            <p className="text-[11px] text-slate-500">New York Local Time ↔ India (IST)</p>
          </div>
          {activeKillZones.length > 0 && (
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100/80 text-emerald-800 border border-emerald-300/60 uppercase tracking-wide">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
              <span>{activeKillZones[0].name} Active</span>
            </span>
          )}
        </div>

        <div className="overflow-x-auto -mx-1">
          <table className="w-full text-left text-xs min-w-[340px]">
            <thead>
              <tr className="border-b border-slate-200/80 text-slate-400 font-semibold text-[11px]">
                <th className="pb-2 font-medium">Kill Zone</th>
                <th className="pb-2 font-medium">New York Time</th>
                <th className="pb-2 font-medium text-amber-700">Summer IST (EDT)</th>
                <th className="pb-2 font-medium text-sky-700">Winter IST (EST)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[11px]">
              {killZones.map((zone) => {
                return (
                  <tr
                    key={zone.id}
                    className={`transition-colors ${
                      zone.isActive
                        ? 'bg-emerald-50/80 text-emerald-950 font-semibold'
                        : 'text-slate-700 hover:bg-slate-50/70'
                    }`}
                  >
                    <td className="py-2.5 pr-2">
                      <div className="flex items-center gap-1.5">
                        {zone.isActive && (
                          <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0 animate-pulse"></span>
                        )}
                        <span className={zone.isActive ? 'text-emerald-900 font-bold' : 'font-semibold text-slate-800'}>
                          {zone.name}
                        </span>
                      </div>
                      {zone.isActive && (
                        <span className="inline-block mt-0.5 text-[9px] font-bold tracking-wide uppercase px-1.5 py-0.2 bg-emerald-600 text-white rounded">
                          Active Now
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 pr-2 font-mono text-[11px] whitespace-nowrap">
                      {zone.nyTimeRange}
                    </td>
                    <td className="py-2.5 pr-2 font-mono text-[11px] text-amber-800 whitespace-nowrap">
                      {zone.summerIstRange}
                    </td>
                    <td className="py-2.5 pr-2 font-mono text-[11px] text-sky-800 whitespace-nowrap">
                      {zone.winterIstRange}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Small explanation footer matching screenshot */}
      <p className="text-[12px] text-slate-500/90 font-normal leading-relaxed px-0.5">
        New York daylight-saving changes are handled automatically. The selected New York date/time is the starting point; both clocks advance together in real time.
      </p>

      {/* Modal Date / Time picker */}
      <DateTimePickerModal
        isOpen={pickerModal.isOpen}
        type={pickerModal.type}
        currentDateVal={startDateStr}
        currentTimeVal={startTimeStr}
        onClose={() => setPickerModal({ isOpen: false, type: 'date' })}
        onSaveDate={(newDate) => {
          setStartDateStr(newDate);
          // If not running, preview the selected time immediately on clocks
          if (!isRunning) {
            const dt = parseNYInput(newDate, startTimeStr);
            setAnchorNYMillis(dt.toMillis());
            setCurrentNYDt(dt);
          }
        }}
        onSaveTime={(newTime) => {
          setStartTimeStr(newTime);
          // If not running, preview the selected time immediately on clocks
          if (!isRunning) {
            const dt = parseNYInput(startDateStr, newTime);
            setAnchorNYMillis(dt.toMillis());
            setCurrentNYDt(dt);
          }
        }}
      />
    </div>
  );
};
