import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  Search,
  MapPin,
  Mic,
  Send,
  X,
  Bot,
  User,
  Sparkles,
  ExternalLink,
  Volume2,
  VolumeX,
  Loader2,
  Radio,
} from 'lucide-react';
import { AudioVoiceTranscriber } from './AudioVoiceTranscriber';

interface AIAssistantModalProps {
  lang: 'bn' | 'en';
  onClose: () => void;
  defaultTab?: 'chat' | 'search' | 'maps' | 'live';
}

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({
  lang,
  onClose,
  defaultTab = 'chat',
}) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'search' | 'maps' | 'live'>(defaultTab);

  // 1. Chat State
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'model',
      text:
        lang === 'bn'
          ? 'আসসালামু আলাইকুম জাহেদ ভাই! আমি আপনার বিজনেস ও মোবাইল পার্টস এআই সহকারী। যে কোন মোবাইল ডিসপ্লে মডেলের কম্প্যাটিবিলিটি, পাইকারি বাজার রেট, কাস্টমারকে বাকি রিমাইন্ডার এসএমএস লেখা, বা ওকা/মেরামত পরামর্শের জন্য আমাকে জিজ্ঞেস করতে পারেন।'
          : 'Hello! I am your AI Business Assistant for mobile LCD & parts management. Ask me about display compatibility, repair tips, or business advice!',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // 2. Search Grounding State
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState('');
  const [searchSources, setSearchSources] = useState<{ title: string; uri: string }[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // 3. Maps Grounding State
  const [mapsQuery, setMapsQuery] = useState('');
  const [mapsResult, setMapsResult] = useState('');
  const [isMapsLoading, setIsMapsLoading] = useState(false);

  // 4. Live Voice State
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [liveStatus, setLiveStatus] = useState<'idle' | 'connecting' | 'listening' | 'speaking'>('idle');
  const wsRef = useRef<WebSocket | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Handle Chat Submit (gemini-3.5-flash)
  const handleSendChat = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || isChatLoading) return;

    const userMsg: ChatMessage = {
      id: `u_${Date.now()}`,
      role: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newThread = [...messages, userMsg];
    setMessages(newThread);
    setInputMessage('');
    setIsChatLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newThread.map((m) => ({ role: m.role, text: m.text })),
        }),
      });

      const data = await res.json();
      if (data.success && data.reply) {
        const botMsg: ChatMessage = {
          id: `m_${Date.now()}`,
          role: 'model',
          text: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, botMsg]);
      } else {
        throw new Error(data.error || 'Failed to reply');
      }
    } catch (e: any) {
      console.error(e);
      const errorMsg: ChatMessage = {
        id: `err_${Date.now()}`,
        role: 'model',
        text: 'দুঃখিত, সার্ভারের সাথে সংযোগে সমস্যা হয়েছে। অনুগ্রহ করে পুনরায় চেষ্টা করুন।',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Handle Search Grounding (gemini-3.5-flash + googleSearch)
  const handleGoogleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || isSearching) return;

    setIsSearching(true);
    setSearchResult('');
    setSearchSources([]);

    try {
      const res = await fetch('/api/search-grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery.trim() }),
      });

      const data = await res.json();
      if (data.success) {
        setSearchResult(data.answer);
        setSearchSources(data.sources || []);
      } else {
        setSearchResult('তথ্য অনুসন্ধানে সমস্যা হয়েছে।');
      }
    } catch (err) {
      setSearchResult('সার্ভার এরর');
    } finally {
      setIsSearching(false);
    }
  };

  // Handle Maps Grounding (gemini-3.5-flash + googleMaps)
  const handleGoogleMaps = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mapsQuery.trim() || isMapsLoading) return;

    setIsMapsLoading(true);
    setMapsResult('');

    try {
      const res = await fetch('/api/maps-grounding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: mapsQuery.trim(),
          location: 'Balaganj, Sylhet, Bangladesh',
        }),
      });

      const data = await res.json();
      if (data.success) {
        setMapsResult(data.answer);
      } else {
        setMapsResult('ম্যাপস তথ্য অনুসন্ধানে সমস্যা হয়েছে।');
      }
    } catch (err) {
      setMapsResult('সার্ভার এরর');
    } finally {
      setIsMapsLoading(false);
    }
  };

  // Toggle Live API Voice Conversation (gemini-3.8-live)
  const toggleLiveSession = async () => {
    if (isLiveActive) {
      // Disconnect
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      setIsLiveActive(false);
      setLiveStatus('idle');
      return;
    }

    setLiveStatus('connecting');
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = async () => {
        setIsLiveActive(true);
        setLiveStatus('listening');

        // Setup microphone audio capture at 16kHz
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          const audioCtx = new AudioContext({ sampleRate: 16000 });
          audioContextRef.current = audioCtx;
          const source = audioCtx.createMediaStreamSource(stream);
          const processor = audioCtx.createScriptProcessor(4096, 1, 1);
          source.connect(processor);
          processor.connect(audioCtx.destination);

          processor.onaudioprocess = (e) => {
            if (ws.readyState === WebSocket.OPEN) {
              const inputData = e.inputBuffer.getChannelData(0);
              // Convert Float32Array to 16-bit PCM
              const pcm16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                pcm16[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7fff;
              }
              // Base64 encode
              const binary = String.fromCharCode(...new Uint8Array(pcm16.buffer));
              const base64 = btoa(binary);
              ws.send(JSON.stringify({ audio: base64 }));
            }
          };
        } catch (micErr) {
          console.error('Live mic error:', micErr);
          alert('মাইক্রোফোন চালু করতে সমস্যা হয়েছে।');
        }
      };

      ws.onmessage = async (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.audio) {
            setLiveStatus('speaking');
            // Play raw audio
            const binary = atob(msg.audio);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) {
              bytes[i] = binary.charCodeAt(i);
            }
            const pcm16 = new Int16Array(bytes.buffer);
            const float32 = new Float32Array(pcm16.length);
            for (let i = 0; i < pcm16.length; i++) {
              float32[i] = pcm16[i] / 32768.0;
            }

            const playCtx = new AudioContext({ sampleRate: 24000 });
            const buffer = playCtx.createBuffer(1, float32.length, 24000);
            buffer.getChannelData(0).set(float32);
            const source = playCtx.createBufferSource();
            source.buffer = buffer;
            source.connect(playCtx.destination);
            source.start();
            source.onended = () => {
              setLiveStatus('listening');
            };
          }
        } catch (e) {
          console.warn('Live playback error:', e);
        }
      };

      ws.onclose = () => {
        setIsLiveActive(false);
        setLiveStatus('idle');
      };
    } catch (err) {
      console.error('Live session init error:', err);
      setIsLiveActive(false);
      setLiveStatus('idle');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col h-[650px] max-h-[90vh]">
        {/* Header with Feature Tabs */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-500 to-indigo-500 flex items-center justify-center text-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm flex items-center gap-1.5">
                <span>স্মার্ট এআই সহকারী (Gemini AI)</span>
                <span className="px-2 py-0.2 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-mono border border-blue-500/30">
                  Business AI
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">জায়েদ আহমেদ • বালাগঞ্জ, সিলেট</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feature Navigation Tabs */}
        <div className="flex items-center justify-around bg-slate-100 p-1.5 border-b border-slate-200 text-xs font-bold">
          <button
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'chat' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
            <span>চ্যাটবট</span>
          </button>

          <button
            onClick={() => setActiveTab('search')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'search' ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Search className="w-3.5 h-3.5 text-blue-600" />
            <span>মার্কেট সার্চ</span>
          </button>

          <button
            onClick={() => setActiveTab('maps')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'maps' ? 'bg-white text-emerald-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <MapPin className="w-3.5 h-3.5 text-emerald-600" />
            <span>ম্যাপস ও কুরিয়ার</span>
          </button>

          <button
            onClick={() => setActiveTab('live')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'live' ? 'bg-white text-rose-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Radio className="w-3.5 h-3.5 text-rose-600 animate-pulse" />
            <span>লাইভ ভয়েস</span>
          </button>
        </div>

        {/* TAB 1: GEMINI CHATBOT (gemini-3.5-flash) */}
        {activeTab === 'chat' && (
          <div className="flex-1 flex flex-col justify-between overflow-hidden p-4 bg-slate-50">
            {/* Messages Thread */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex gap-2.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {m.role === 'model' && (
                    <div className="w-7 h-7 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 text-xs shadow-2xs">
                      <Bot className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed whitespace-pre-wrap ${
                      m.role === 'user'
                        ? 'bg-blue-600 text-white rounded-br-xs shadow-xs'
                        : 'bg-white border border-slate-200/80 text-slate-800 rounded-bl-xs shadow-xs'
                    }`}
                  >
                    {m.text}
                    <span
                      className={`block text-[9px] mt-1 ${
                        m.role === 'user' ? 'text-blue-200 text-right' : 'text-slate-400'
                      }`}
                    >
                      {m.timestamp}
                    </span>
                  </div>

                  {m.role === 'user' && (
                    <div className="w-7 h-7 rounded-xl bg-slate-200 text-slate-700 flex items-center justify-center shrink-0 text-xs shadow-2xs">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              ))}

              {isChatLoading && (
                <div className="flex items-center gap-2 text-slate-400 text-xs py-2">
                  <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                  <span>এআই সহকারী উত্তর প্রস্তুত করছে...</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Suggestion Chips */}
            <div className="py-2 flex items-center gap-1.5 overflow-x-auto scrollbar-none text-[11px]">
              {[
                'Samsung A12 এর সাথে কোন কোন LCD ম্যাচ করে?',
                'কাস্টমারকে ভদ্রভাবে বাকি চাওয়ার এসএমএস লিখে দাও',
                'Oppo A57 এর চার্জিং রিবন প্রবলেম সল্যুশন কি?',
                'OCA মেশিনে বাবল থাকার মূল কারণ কি?',
              ].map((chip, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendChat(chip)}
                  className="px-2.5 py-1 rounded-full bg-white border border-slate-200 text-slate-700 hover:bg-indigo-50 hover:border-indigo-200 whitespace-nowrap cursor-pointer transition-colors"
                >
                  {chip}
                </button>
              ))}
            </div>

            {/* Chat Input Bar */}
            <div className="pt-2 border-t border-slate-200 flex items-center gap-2">
              {/* Audio Voice Transcriber Button */}
              <AudioVoiceTranscriber
                onTranscribeComplete={(text) => setInputMessage((prev) => `${prev} ${text}`.trim())}
                lang={lang}
              />

              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
                placeholder="আপনার প্রশ্ন বা সমস্যা লিখুন অথবা মুখে বলুন..."
                className="flex-1 px-3.5 py-2.5 rounded-2xl bg-white border border-slate-200 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />

              <button
                onClick={() => handleSendChat()}
                disabled={!inputMessage.trim() || isChatLoading}
                className="p-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white cursor-pointer shadow-xs active:scale-95 transition-all"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: GOOGLE SEARCH GROUNDING (gemini-3.5-flash + googleSearch) */}
        {activeTab === 'search' && (
          <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-slate-50">
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl text-xs text-blue-900 font-medium">
              🌐 Google Search এর লাইভ ডাটা দিয়ে মোবাইল ডিসপ্লে রেট, নতুন মডেলের স্পেসিফিকেশন ও পাইকারি বাজার বিশ্লেষণ করুন।
            </div>

            <form onSubmit={handleGoogleSearch} className="flex gap-2">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="যেমন: Redmi Note 10 AMOLED display price in Bangladesh"
                className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-medium"
              />
              <button
                type="submit"
                disabled={isSearching}
                className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                {isSearching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                <span>অনুসন্ধান</span>
              </button>
            </form>

            {searchResult && (
              <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-3 text-xs">
                <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <span>লাইভ সার্চ ফলাফল:</span>
                </h4>
                <div className="text-slate-700 leading-relaxed whitespace-pre-wrap">{searchResult}</div>

                {searchSources.length > 0 && (
                  <div className="pt-2 border-t border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                      তথ্যসূত্র (Web Citations):
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {searchSources.map((src, i) => (
                        <a
                          key={i}
                          href={src.uri}
                          target="_blank"
                          rel="noreferrer"
                          className="px-2 py-0.5 rounded bg-slate-100 hover:bg-blue-50 text-blue-700 text-[10px] font-semibold flex items-center gap-1 truncate max-w-xs"
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span className="truncate">{src.title}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: GOOGLE MAPS GROUNDING (gemini-3.5-flash + googleMaps) */}
        {activeTab === 'maps' && (
          <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-slate-50">
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900 font-medium">
              📍 সিলেট, বালাগঞ্জ বা ঢাকার আশেপাশের মোবাইল সার্ভিস মার্কেট, পাইকারি দোকান বা সুন্দরবন/এসএ পরিবহন কুরিয়ার খুঁজুন।
            </div>

            <form onSubmit={handleGoogleMaps} className="flex gap-2">
              <input
                type="text"
                value={mapsQuery}
                onChange={(e) => setMapsQuery(e.target.value)}
                placeholder="যেমন: Balaganj to Sylhet mobile repair wholesale market"
                className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-medium"
              />
              <button
                type="submit"
                disabled={isMapsLoading}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                {isMapsLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <MapPin className="w-4 h-4" />}
                <span>ম্যাপস খুঁজুন</span>
              </button>
            </form>

            {mapsResult && (
              <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-2 text-xs">
                <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <span>লোকেশন ও কুরিয়ার তথ্য:</span>
                </h4>
                <div className="text-slate-700 leading-relaxed whitespace-pre-wrap">{mapsResult}</div>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: LIVE VOICE (gemini-3.8-live) */}
        {activeTab === 'live' && (
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center space-y-6 bg-slate-50">
            <div className="max-w-md space-y-2">
              <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-700 font-bold text-xs">
                Live Voice API • gemini-3.8-live
              </span>
              <h3 className="text-lg font-black text-slate-900">
                রিয়েল-টাইম লাইভ ভয়েস কথোপকথন
              </h3>
              <p className="text-xs text-slate-500">
                এআই-এর সাথে সরাসরি মুখে কথা বলুন এবং তাত্ক্ষণিক অডিও উত্তর শুনুন।
              </p>
            </div>

            {/* Pulsing Mic Circle */}
            <div className="relative">
              {isLiveActive && (
                <div className="absolute inset-0 rounded-full bg-rose-500/20 animate-ping" />
              )}
              <button
                onClick={toggleLiveSession}
                className={`w-28 h-28 rounded-full flex flex-col items-center justify-center shadow-xl transition-all cursor-pointer relative z-10 ${
                  isLiveActive
                    ? 'bg-rose-600 text-white ring-4 ring-rose-300'
                    : 'bg-white border-2 border-slate-200 text-slate-700 hover:border-rose-500 hover:text-rose-600'
                }`}
              >
                <Mic className="w-10 h-10 mb-1" />
                <span className="text-[11px] font-bold">
                  {isLiveActive ? 'কথা হচ্ছে...' : 'শুরু করুন'}
                </span>
              </button>
            </div>

            <div className="text-xs font-semibold text-slate-600">
              {liveStatus === 'connecting' && 'সংযোগ স্থাপন হচ্ছে...'}
              {liveStatus === 'listening' && '🟢 শুনছি... আপনি মুখে কথা বলুন'}
              {liveStatus === 'speaking' && '🔊 এআই উত্তর দিচ্ছে...'}
              {liveStatus === 'idle' && 'মাইক্রোফোনে চাপ দিয়ে কথা শুরু করুন'}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
