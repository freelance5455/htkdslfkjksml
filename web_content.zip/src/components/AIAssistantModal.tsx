import React, { useState } from 'react';
import { Camera, CheckCircle2, HelpCircle, Mic, Send, Sparkles, X } from 'lucide-react';
import { compressImageFile } from '../lib/mediaUtils';
import { BUILTIN_COURSES, COMMON_SUBJECT_NAMES } from '../lib/tevetaCatalog';
import type { LanguageCode, UserProfile } from '../types';

interface AIAssistantModalProps {
  open: boolean;
  onClose: () => void;
  profile: UserProfile;
  language: LanguageCode;
  initialContext?: string;
  initialSubject?: string;
  initialCourse?: string;
}

interface ChatEntry {
  role: 'user' | 'assistant';
  text: string;
  disclaimer?: string;
}

interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({
  open,
  onClose,
  profile,
  language,
  initialContext = '',
  initialSubject = '',
  initialCourse = '',
}) => {
  const [aiLang, setAiLang] = useState<LanguageCode>(language);
  const [course, setCourse] = useState(initialCourse || profile.course || BUILTIN_COURSES[0].name);
  const [subject, setSubject] = useState(initialSubject || COMMON_SUBJECT_NAMES[0]);
  const [level, setLevel] = useState(profile.level || 'Level 1');
  const [contextText, setContextText] = useState(initialContext);
  const [question, setQuestion] = useState(
    initialContext ? 'Please explain this section clearly step-by-step for my TEVETA studies.' : ''
  );
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Practice Quiz Mode
  const [mode, setMode] = useState<'tutor' | 'quiz'>('tutor');
  const [quizNotice, setQuizNotice] = useState('');
  const [quizItems, setQuizItems] = useState<QuizQuestion[]>([]);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});

  if (!open) return null;

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const compressed = await compressImageFile(file, 960, 0.78);
    setImageDataUrl(compressed);
  };

  const handleVoicePrompt = () => {
    const SpeechRecognition =
      (window as unknown as { SpeechRecognition?: new () => unknown; webkitSpeechRecognition?: new () => unknown })
        .SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: new () => unknown }).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError('Voice speech recognition is not supported on this browser. Please type your question.');
      return;
    }
    const recognition = new SpeechRecognition() as {
      lang: string;
      start: () => void;
      onresult: (ev: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
    };
    recognition.lang = aiLang === 'ny' ? 'ny-MW' : 'en-US';
    recognition.onresult = (ev) => {
      const transcript = ev.results?.[0]?.[0]?.transcript || '';
      if (transcript) setQuestion((prev) => `${prev ? `${prev} ` : ''}${transcript}`);
    };
    recognition.start();
  };

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    const currentQ = question.trim();
    setMessages((prev) => [...prev, { role: 'user', text: currentQ }]);
    setQuestion('');
    setLoading(true);
    setError(null);

    try {
      const resp = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: currentQ,
          language: aiLang,
          course,
          subject,
          level,
          contextText,
          imageBase64: imageDataUrl || '',
          imageMimeType: 'image/jpeg',
          history: messages.slice(-6),
        }),
      });
      const data = (await resp.json()) as { answer?: string; disclaimer?: string; error?: string };
      if (!resp.ok) {
        throw new Error(data.error || 'AI service returned an error');
      }
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', text: data.answer || '', disclaimer: data.disclaimer },
      ]);
      setImageDataUrl(null);
      setContextText('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach TEVET AI Assistant');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateQuiz = async () => {
    setLoading(true);
    setError(null);
    setQuizItems([]);
    setSelectedAnswers({});
    try {
      const resp = await fetch('/api/ai/quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          course,
          subject,
          level,
          language: aiLang,
          count: 4,
        }),
      });
      const data = (await resp.json()) as {
        notice?: string;
        questions?: QuizQuestion[];
        error?: string;
      };
      if (!resp.ok) {
        throw new Error(data.error || 'Quiz generation failed');
      }
      setQuizNotice(data.notice || 'AI-generated study practice (not official TEVETA exam questions).');
      setQuizItems(data.questions || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate quiz');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-700 text-white flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display font-bold text-base text-slate-900 dark:text-white">
                TEVET AI ASSISTANT
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Study explanations & worked steps (distinguished from official TEVETA papers)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Context Selectors */}
        <div className="p-3 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-2">
          <select
            value={course}
            onChange={(e) => setCourse(e.target.value)}
            className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-2 text-xs"
          >
            {BUILTIN_COURSES.map((c) => (
              <option key={c.id} value={c.name}>{c.trade}</option>
            ))}
          </select>
          <select
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-2 text-xs"
          >
            {COMMON_SUBJECT_NAMES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
            <option value="Course Practical & Theory">Course Practical & Theory</option>
          </select>
          <select
            value={aiLang}
            onChange={(e) => setAiLang(e.target.value as LanguageCode)}
            className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-2 text-xs"
          >
            <option value="en">Language: English</option>
            <option value="ny">Language: Chichewa</option>
          </select>
          <div className="flex gap-1 p-0.5 bg-slate-200 dark:bg-slate-800 rounded-xl">
            <button
              type="button"
              onClick={() => setMode('tutor')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg ${
                mode === 'tutor' ? 'bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400' : ''
              }`}
            >
              Study Chat
            </button>
            <button
              type="button"
              onClick={() => setMode('quiz')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg ${
                mode === 'quiz' ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400' : ''
              }`}
            >
              Quiz Prep
            </button>
          </div>
        </div>

        {/* Body */}
        {mode === 'tutor' ? (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {contextText && (
                <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-xs">
                  <div className="flex items-center justify-between font-semibold mb-1">
                    <span>Attached Library Excerpt</span>
                    <button type="button" onClick={() => setContextText('')} className="text-slate-500">
                      Clear
                    </button>
                  </div>
                  <p className="line-clamp-3 text-slate-600 dark:text-slate-300">{contextText}</p>
                </div>
              )}

              {messages.length === 0 && (
                <div className="text-center py-8 space-y-2">
                  <p className="font-display font-semibold text-sm">
                    Ask any question in English or Chichewa
                  </p>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    Solve numeracy/Ohm&apos;s law calculations, interpret technical drawings, upload a photo of a homework problem, or get workshop practical steps for {course}.
                  </p>
                </div>
              )}

              {messages.map((m, idx) => (
                <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm space-y-2 ${
                      m.role === 'user'
                        ? 'bg-blue-700 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100'
                    }`}
                  >
                    <p className="whitespace-pre-wrap leading-relaxed">{m.text}</p>
                    {m.disclaimer && (
                      <p className="text-[11px] opacity-75 pt-1 border-t border-current/15">
                        {m.disclaimer}
                      </p>
                    )}
                  </div>
                </div>
              ))}

              {loading && (
                <p className="text-xs text-slate-500 animate-pulse">TEVET AI is preparing your explanation...</p>
              )}
              {error && (
                <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/50 text-xs text-red-700 dark:text-red-300">
                  {error}
                </div>
              )}
            </div>

            {imageDataUrl && (
              <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 flex items-center gap-3">
                <img src={imageDataUrl} alt="Question upload" className="w-12 h-12 rounded-lg object-cover" />
                <span className="text-xs text-slate-500 flex-1">Question photo attached</span>
                <button type="button" onClick={() => setImageDataUrl(null)} className="text-xs text-red-600">
                  Remove
                </button>
              </div>
            )}

            <form onSubmit={handleAsk} className="p-3 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
              <label className="min-h-[42px] min-w-[42px] rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800">
                <Camera className="w-4 h-4" />
                <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              </label>
              <button
                type="button"
                onClick={handleVoicePrompt}
                title="Voice input"
                className="min-h-[42px] min-w-[42px] rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <Mic className="w-4 h-4" />
              </button>
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder={
                  aiLang === 'ny'
                    ? 'Funsani funso lanu la maphunziro pano...'
                    : 'Ask a study question or paste a calculation...'
                }
                className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm"
              />
              <button
                type="submit"
                disabled={loading}
                className="min-h-[42px] px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </>
        ) : (
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-display font-semibold text-sm">
                  Assessment Revision Quiz ({subject})
                </h3>
                <p className="text-xs text-slate-500">
                  Test your readiness for {course} ({level}).
                </p>
              </div>
              <button
                type="button"
                onClick={handleGenerateQuiz}
                disabled={loading}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <HelpCircle className="w-4 h-4" />
                <span>{loading ? 'Generating...' : 'Generate Practice Quiz'}</span>
              </button>
            </div>

            {quizNotice && (
              <p className="text-xs text-slate-500 dark:text-slate-400">{quizNotice}</p>
            )}
            {error && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/50 text-xs text-red-700">
                {error}
              </div>
            )}

            <div className="space-y-4">
              {quizItems.map((q, qIdx) => {
                const chosen = selectedAnswers[qIdx];
                return (
                  <div
                    key={qIdx}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2.5"
                  >
                    <p className="font-semibold text-sm">
                      {qIdx + 1}. {q.question}
                    </p>
                    <div className="space-y-1.5">
                      {q.options.map((opt, oIdx) => {
                        const isPicked = chosen === oIdx;
                        const isCorrect = oIdx === q.correctIndex;
                        return (
                          <button
                            key={oIdx}
                            type="button"
                            onClick={() =>
                              setSelectedAnswers((prev) => ({ ...prev, [qIdx]: oIdx }))
                            }
                            className={`w-full text-left px-3.5 py-2 rounded-xl border text-xs flex items-center justify-between cursor-pointer ${
                              chosen === undefined
                                ? 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                                : isCorrect
                                ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300'
                                : isPicked
                                ? 'border-red-400 bg-red-50 dark:bg-red-950/40 text-red-700'
                                : 'border-slate-200 dark:border-slate-800 opacity-75'
                            }`}
                          >
                            <span>{opt}</span>
                            {chosen !== undefined && isCorrect && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                            )}
                          </button>
                        );
                      })}
                    </div>
                    {chosen !== undefined && (
                      <p className="text-xs text-slate-600 dark:text-slate-300 pt-1">
                        <strong>Explanation:</strong> {q.explanation}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
