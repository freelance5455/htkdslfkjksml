import { useState } from 'react';
import { Student, Lesson } from '../types';
import {
  Search,
  Plus,
  Phone,
  DollarSign,
  Calendar,
  Sparkles,
  ChevronRight
} from 'lucide-react';

interface StudentListViewProps {
  students: Student[];
  lessons: Lesson[];
  onAddStudent: () => void;
  onEditStudent: (student: Student) => void;
  onSelectStudent: (student: Student) => void;
  onMarkPayment: (student: Student) => void;
  onScheduleLessonForStudent: (student: Student) => void;
}

export const StudentListView = ({
  students,
  lessons,
  onAddStudent,
  onEditStudent,
  onSelectStudent,
  onMarkPayment,
  onScheduleLessonForStudent,
}: StudentListViewProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSubject, setFilterSubject] = useState<'all' | 'english' | 'turkish'>('all');
  const [filterCurrency, setFilterCurrency] = useState<'all' | 'TL' | 'USD'>('all');

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.phone.includes(searchTerm) ||
      (student.email && student.email.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesSubject = filterSubject === 'all' || student.subject === filterSubject;
    const matchesCurrency = filterCurrency === 'all' || student.currency === filterCurrency;

    return matchesSearch && matchesSubject && matchesCurrency;
  });

  return (
    <div className="space-y-4">
      {/* Top action bar & search */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#121214] p-4 rounded-2xl border border-zinc-800 shadow-xl">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Öğrenci adı, telefon veya e-posta ara..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-zinc-900 focus:bg-zinc-850 rounded-xl border border-zinc-800 focus:outline-none focus:ring-2 focus:ring-rose-500/30 focus:border-rose-500 text-stone-100 transition-all placeholder:text-stone-500"
          />
        </div>

        {/* Filter Badges */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <div className="flex items-center bg-zinc-900 border border-zinc-800 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setFilterSubject('all')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                filterSubject === 'all' ? 'bg-zinc-800 shadow-xs text-white font-bold' : 'text-stone-400'
              }`}
            >
              Tümü
            </button>
            <button
              onClick={() => setFilterSubject('english')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                filterSubject === 'english' ? 'bg-sky-950 text-sky-300 font-bold border border-sky-800/40' : 'text-stone-400'
              }`}
            >
              İngilizce
            </button>
            <button
              onClick={() => setFilterSubject('turkish')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                filterSubject === 'turkish' ? 'bg-rose-950 text-rose-300 font-bold border border-rose-800/40' : 'text-stone-400'
              }`}
            >
              Türkçe
            </button>
          </div>

          <div className="flex items-center bg-zinc-900 border border-zinc-800 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setFilterCurrency('all')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                filterCurrency === 'all' ? 'bg-zinc-800 shadow-xs text-white font-bold' : 'text-stone-400'
              }`}
            >
              Döviz
            </button>
            <button
              onClick={() => setFilterCurrency('TL')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                filterCurrency === 'TL' ? 'bg-emerald-950 text-emerald-300 font-bold border border-emerald-800/40' : 'text-stone-400'
              }`}
            >
              ₺ (TL)
            </button>
            <button
              onClick={() => setFilterCurrency('USD')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                filterCurrency === 'USD' ? 'bg-sky-950 text-sky-300 font-bold border border-sky-800/40' : 'text-stone-400'
              }`}
            >
              $ (USD)
            </button>
          </div>

          <button
            onClick={onAddStudent}
            className="flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-rose-950/40 shrink-0 cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Yeni Öğrenci</span>
          </button>
        </div>
      </div>

      {/* Comprehensive Table View */}
      <div className="bg-[#121214] rounded-2xl border border-zinc-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-zinc-900/90 border-b border-zinc-800 text-[11px] font-bold text-stone-400 uppercase tracking-wider">
                <th className="py-3.5 px-4">Öğrenci & İletişim</th>
                <th className="py-3.5 px-4">Ders & Ücret</th>
                <th className="py-3.5 px-4">Ödeme Döngüsü</th>
                <th className="py-3.5 px-4">Döngü İlerlemesi</th>
                <th className="py-3.5 px-4">Sonraki Planlı Ders</th>
                <th className="py-3.5 px-4 text-right">İşlemler</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80 text-xs text-stone-300">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-stone-500">
                    Kayıtlı öğrenci bulunamadı.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((student) => {
                  const studentLessons = lessons.filter((l) => l.studentId === student.id);
                  const nextScheduled = studentLessons
                    .filter((l) => l.status === 'scheduled')
                    .sort((a, b) => a.date.localeCompare(b.date))[0];

                  const isCycleComplete = student.lessonsInCurrentCycle >= student.paymentFrequency;
                  const cyclePaymentAmount = student.hourlyRate * student.paymentFrequency;
                  const currencySymbol = student.currency === 'USD' ? '$' : '₺';
                  const isPaymentDueNext = student.lessonsInCurrentCycle === student.paymentFrequency - 1;

                  return (
                    <tr
                      key={student.id}
                      className="hover:bg-zinc-850/60 transition-colors group cursor-pointer"
                      onClick={() => onSelectStudent(student)}
                    >
                      {/* Name & Contact */}
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold font-serif text-sm ${
                              student.subject === 'english'
                                ? 'bg-sky-950 text-sky-300 border border-sky-800/50'
                                : 'bg-rose-950 text-rose-300 border border-rose-800/50'
                            }`}
                          >
                            {student.name.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-white group-hover:text-rose-400 transition-colors text-sm">
                              {student.name}
                            </div>
                            <div className="text-[11px] text-stone-400 flex items-center gap-1.5 mt-0.5">
                              <span>{student.phone}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Subject & Rate */}
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              student.subject === 'english'
                                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                                : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            }`}
                          >
                            {student.subject === 'english' ? 'İngilizce' : 'Türkçe'}
                          </span>
                        </div>
                        <div className="font-bold text-stone-100 font-mono text-sm">
                          {student.hourlyRate.toLocaleString('tr-TR')} {currencySymbol}{' '}
                          <span className="text-[10px] font-normal text-stone-400">/ ders</span>
                        </div>
                      </td>

                      {/* Payment Cycle Rule */}
                      <td className="py-4 px-4">
                        <div className="font-medium text-stone-200">
                          {student.paymentFrequency === 1 ? (
                            <span className="inline-flex items-center gap-1 text-emerald-300 font-semibold bg-emerald-950/80 border border-emerald-800/50 px-2 py-0.5 rounded-full text-[11px]">
                              Her derste peşin
                            </span>
                          ) : (
                            <span className="text-stone-300 font-medium">
                              Her <span className="font-bold text-white">{student.paymentFrequency}</span> derste bir
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-stone-400 mt-0.5">
                          Paket: <span className="font-semibold text-stone-200">{cyclePaymentAmount.toLocaleString('tr-TR')} {currencySymbol}</span>
                        </div>
                      </td>

                      {/* Current Cycle Progress Bar */}
                      <td className="py-4 px-4">
                        <div className="w-36">
                          <div className="flex items-center justify-between text-[11px] mb-1">
                            <span className="font-semibold text-stone-300">
                              {student.lessonsInCurrentCycle} / {student.paymentFrequency} ders
                            </span>
                            {isCycleComplete ? (
                              <span className="text-[10px] font-bold text-amber-400 animate-pulse">
                                Ödeme Vakti!
                              </span>
                            ) : isPaymentDueNext ? (
                              <span className="text-[10px] font-bold text-amber-400/90">
                                Sıradaki son ders
                              </span>
                            ) : null}
                          </div>

                          {/* Step visual indicator */}
                          <div className="flex gap-1 h-2">
                            {Array.from({ length: student.paymentFrequency }).map((_, idx) => (
                              <div
                                key={idx}
                                className={`flex-1 rounded-sm transition-all ${
                                  idx < student.lessonsInCurrentCycle
                                    ? isCycleComplete
                                      ? 'bg-amber-400'
                                      : 'bg-emerald-500'
                                    : idx === student.paymentFrequency - 1
                                    ? 'bg-amber-950 border border-amber-500/50'
                                    : 'bg-zinc-800'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </td>

                      {/* Next Scheduled Lesson */}
                      <td className="py-4 px-4">
                        {nextScheduled ? (
                          <div>
                            <div className="font-medium text-stone-200 flex items-center gap-1.5">
                              <Calendar className="w-3.5 h-3.5 text-stone-500" />
                              <span>{nextScheduled.date}</span>
                              <span className="font-bold text-rose-400">{nextScheduled.time}</span>
                            </div>
                            {nextScheduled.isPaymentLesson && (
                              <div className="text-[10px] font-bold text-amber-400 mt-0.5 flex items-center gap-1">
                                <Sparkles className="w-3 h-3 text-amber-400" />
                                <span>Bu ders ödeme alınacak</span>
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="text-stone-500 italic">Planlı ders yok</span>
                        )}
                      </td>

                      {/* Action buttons */}
                      <td className="py-4 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onMarkPayment(student)}
                            title="Ödeme Tahsil Et"
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer active:scale-95 ${
                              isCycleComplete
                                ? 'bg-amber-500 hover:bg-amber-400 text-stone-950 shadow-md shadow-amber-500/30 animate-pulse'
                                : 'bg-zinc-800 hover:bg-zinc-700 text-stone-200 border border-zinc-700'
                            }`}
                          >
                            <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                            <span>Ödeme Al</span>
                          </button>

                          <button
                            onClick={() => onScheduleLessonForStudent(student)}
                            title="Yeni Ders Planla"
                            className="p-1.5 hover:bg-zinc-800 text-stone-400 hover:text-stone-200 rounded-xl transition-all cursor-pointer"
                          >
                            <Calendar className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => onEditStudent(student)}
                            title="Düzenle"
                            className="p-1.5 hover:bg-zinc-800 text-stone-400 hover:text-stone-200 rounded-xl transition-all cursor-pointer"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
