import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Box,
  CheckCircle2,
  Circle,
  Code2,
  Copy,
  Cylinder,
  MousePointer,
  Move,
  PackagePlus,
  Play,
  Plus,
  RotateCcw,
  RotateCw,
  Scaling,
  Trash2,
  Undo2,
  X,
} from 'lucide-react';
import { AvatarConfig, StudioPart, StudioScript } from '../types/game';
import { createAvatarRig } from '../engine/avatar';
import {
  compileStudioScript,
  MODEL_JADI_PRESETS,
  SCRIPT_TEMPLATES,
} from '../engine/studioModelsAndScripts';

interface StudioEditor3DProps {
  projectTitle: string;
  projectDescription: string;
  parts: StudioPart[];
  scripts: StudioScript[];
  avatar: AvatarConfig;
  onChangeParts: (next: StudioPart[]) => void;
  onChangeScripts: (next: StudioScript[]) => void;
  onSaveProject: () => void;
  onPublishProject: (meta: { name: string; description: string }) => void;
  onTestPlay: () => void;
  onExitStudio: () => void;
}

const PART_COLORS = ['#38bdf8', '#f43f5e', '#22c55e', '#facc15', '#a855f7', '#fb923c', '#f8fafc', '#334155'];

export const StudioEditor3D: React.FC<StudioEditor3DProps> = ({
  projectTitle,
  projectDescription,
  parts,
  scripts,
  avatar,
  onChangeParts,
  onChangeScripts,
  onSaveProject,
  onPublishProject,
  onTestPlay,
  onExitStudio,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [selectedId, setSelectedId] = useState<string | null>(parts[0]?.id ?? null);
  const [toolMode, setToolMode] = useState<'select' | 'move' | 'rotate' | 'scale'>('move');
  const [toolboxTab, setToolboxTab] = useState<'parts' | 'models'>('parts');
  const [history, setHistory] = useState<StudioPart[][]>([]);
  const [outputLogs, setOutputLogs] = useState<string[]>([
    `Proyek dibuka: ${projectTitle}`,
    'Siap membangun! Tambah Part, Model Jadi, atau Script untuk membuat sistem apa pun.',
  ]);

  // Publish Modal State
  const [publishOpen, setPublishOpen] = useState(false);
  const [pubName, setPubName] = useState(projectTitle);
  const [pubDesc, setPubDesc] = useState(projectDescription);
  const [pubError, setPubError] = useState<string | null>(null);

  // Script Editor State
  const [editingScriptId, setEditingScriptId] = useState<string | null>(null);

  const partsRef = useRef(parts);
  partsRef.current = parts;
  const selectedIdRef = useRef(selectedId);
  selectedIdRef.current = selectedId;
  const toolModeRef = useRef(toolMode);
  toolModeRef.current = toolMode;

  const sceneSyncRef = useRef<(() => void) | null>(null);

  const pushLog = (msg: string) => {
    setOutputLogs((prev) => [...prev.slice(-5), msg]);
  };

  const commitParts = (next: StudioPart[], logMsg?: string) => {
    setHistory((h) => [...h.slice(-15), parts]);
    onChangeParts(next);
    if (logMsg) pushLog(logMsg);
  };

  const selectedPart = parts.find((p) => p.id === selectedId) ?? null;
  const editingScript = scripts.find((s) => s.id === editingScriptId) ?? null;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas');
        const gl = probe.getContext('webgl2') || probe.getContext('webgl');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const gpu = String(gl.getParameter(ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth || 640, container.clientHeight || 400);
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#bae6fd');

    const pmrem = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmrem.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(
      50,
      (container.clientWidth || 640) / (container.clientHeight || 400),
      0.1,
      200
    );
    camera.position.set(12, 10, 14);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.target.set(0, 1.5, 0);

    scene.add(new THREE.HemisphereLight(0xffffff, 0x64748b, 1.0));
    const sun = new THREE.DirectionalLight(0xfffbeb, 1.4);
    sun.position.set(15, 25, 15);
    scene.add(sun);

    // Baseplate + Grid
    const baseMesh = new THREE.Mesh(
      new THREE.BoxGeometry(32, 1.2, 32),
      new THREE.MeshStandardMaterial({ color: '#cbd5e1', roughness: 0.7 })
    );
    baseMesh.position.y = 0;
    scene.add(baseMesh);

    const grid = new THREE.GridHelper(32, 32, 0x475569, 0x94a3b8);
    grid.position.y = 0.62;
    scene.add(grid);

    // Avatar Preview at Spawn
    const rig = createAvatarRig(avatar);
    rig.root.position.set(0, 0.6, 4);
    scene.add(rig.root);

    const partsGroup = new THREE.Group();
    scene.add(partsGroup);

    // 3D Move/Rotate Gizmo Group for Selected Part
    const gizmoGroup = new THREE.Group();
    scene.add(gizmoGroup);

    const buildAxisGizmo = () => {
      const g = new THREE.Group();
      const xAxis = new THREE.Mesh(
        new THREE.CylinderGeometry(0.05, 0.05, 3.2, 8),
        new THREE.MeshBasicMaterial({ color: '#ef4444', depthTest: false })
      );
      xAxis.rotation.z = Math.PI / 2;
      const yAxis = new THREE.Mesh(
        new THREE.CylinderGeometry(0.05, 0.05, 3.2, 8),
        new THREE.MeshBasicMaterial({ color: '#22c55e', depthTest: false })
      );
      const zAxis = new THREE.Mesh(
        new THREE.CylinderGeometry(0.05, 0.05, 3.2, 8),
        new THREE.MeshBasicMaterial({ color: '#3b82f6', depthTest: false })
      );
      zAxis.rotation.x = Math.PI / 2;
      g.add(xAxis, yAxis, zAxis);
      g.renderOrder = 30;
      return g;
    };

    const buildRotateGizmo = () => {
      const g = new THREE.Group();
      const ringX = new THREE.Mesh(
        new THREE.TorusGeometry(2.6, 0.045, 8, 36),
        new THREE.MeshBasicMaterial({ color: '#ef4444', depthTest: false })
      );
      ringX.rotation.y = Math.PI / 2;
      const ringY = new THREE.Mesh(
        new THREE.TorusGeometry(2.6, 0.045, 8, 36),
        new THREE.MeshBasicMaterial({ color: '#22c55e', depthTest: false })
      );
      ringY.rotation.x = Math.PI / 2;
      const ringZ = new THREE.Mesh(
        new THREE.TorusGeometry(2.6, 0.045, 8, 36),
        new THREE.MeshBasicMaterial({ color: '#3b82f6', depthTest: false })
      );
      g.add(ringX, ringY, ringZ);
      g.renderOrder = 30;
      return g;
    };

    const axisGizmo = buildAxisGizmo();
    const rotateGizmo = buildRotateGizmo();
    gizmoGroup.add(axisGizmo, rotateGizmo);

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let disposed = false;

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const st = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (st === gl.UNSIGNALED) frameId = window.setTimeout(poll, 5);
        else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const requestRender = () => {
      if (disposed) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame(() => {
        if (disposed) return;
        renderDirty = false;
        controls.update();
        renderer.render(scene, camera);
        const done = () => {
          renderBusy = false;
          if (renderDirty) requestRender();
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    };

    const rebuildParts = () => {
      while (partsGroup.children.length > 0) {
        const c = partsGroup.children[0] as THREE.Mesh;
        partsGroup.remove(c);
        c.geometry.dispose();
        (c.material as THREE.Material).dispose();
      }
      let selPart: StudioPart | null = null;
      for (const p of partsRef.current) {
        let geo: THREE.BufferGeometry;
        if (p.shape === 'cylinder') geo = new THREE.CylinderGeometry(0.5, 0.5, 1, 18);
        else if (p.shape === 'sphere') geo = new THREE.SphereGeometry(0.5, 18, 16);
        else geo = new THREE.BoxGeometry(1, 1, 1);

        const isSel = p.id === selectedIdRef.current;
        if (isSel) selPart = p;
        const mat = new THREE.MeshStandardMaterial({
          color: p.color,
          roughness: 0.4,
          emissive: isSel ? '#ffffff' : '#000000',
          emissiveIntensity: isSel ? 0.18 : 0,
        });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(p.x, p.y, p.z);
        mesh.scale.set(p.sx, p.sy, p.sz);
        mesh.rotation.set(
          THREE.MathUtils.degToRad(p.rx ?? 0),
          THREE.MathUtils.degToRad(p.ry ?? 0),
          THREE.MathUtils.degToRad(p.rz ?? 0)
        );
        mesh.userData.partId = p.id;
        partsGroup.add(mesh);
      }

      if (selPart) {
        gizmoGroup.visible = true;
        gizmoGroup.position.set(selPart.x, selPart.y, selPart.z);
        const gizmoScale = Math.max(0.8, Math.max(selPart.sx, selPart.sy, selPart.sz) * 0.35);
        gizmoGroup.scale.setScalar(gizmoScale);
        axisGizmo.visible = toolModeRef.current === 'move';
        rotateGizmo.visible = toolModeRef.current === 'rotate' || toolModeRef.current === 'move';
        rotateGizmo.rotation.set(
          THREE.MathUtils.degToRad(selPart.rx ?? 0),
          THREE.MathUtils.degToRad(selPart.ry ?? 0),
          THREE.MathUtils.degToRad(selPart.rz ?? 0)
        );
      } else {
        gizmoGroup.visible = false;
      }

      requestRender();
    };

    sceneSyncRef.current = rebuildParts;
    rebuildParts();

    controls.addEventListener('change', requestRender);

    const onClick = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(partsGroup.children, false);
      if (hits.length > 0) {
        const id = hits[0].object.userData.partId as string;
        setSelectedId(id);
      }
    };
    renderer.domElement.addEventListener('click', onClick);

    const onResize = () => {
      const w = container.clientWidth || 640;
      const h = container.clientHeight || 400;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    };
    window.addEventListener('resize', onResize);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      controls.removeEventListener('change', requestRender);
      renderer.domElement.removeEventListener('click', onClick);
      window.removeEventListener('resize', onResize);
      controls.dispose();
      rig.dispose();
      baseMesh.geometry.dispose();
      (baseMesh.material as THREE.Material).dispose();
      gizmoGroup.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          (obj as THREE.Mesh).geometry.dispose();
          ((obj as THREE.Mesh).material as THREE.Material).dispose();
        }
      });
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [avatar]);

  useEffect(() => {
    sceneSyncRef.current?.();
  }, [parts, selectedId, toolMode]);

  const addPart = (shape: StudioPart['shape'], kind: StudioPart['kind'] = 'normal') => {
    const id = `part-${Date.now()}`;
    const labelMap: Record<StudioPart['kind'], string> = {
      normal: shape === 'cylinder' ? 'Silinder' : shape === 'sphere' ? 'Bola' : 'Part',
      bounce: 'BouncePad',
      checkpoint: 'Checkpoint',
      finish: 'FinishPad',
      hazard: 'LavaBar',
    };
    const colorMap: Record<StudioPart['kind'], string> = {
      normal: '#38bdf8',
      bounce: '#06b6d4',
      checkpoint: '#22c55e',
      finish: '#facc15',
      hazard: '#ef4444',
    };
    const nextPart: StudioPart = {
      id,
      name: `${labelMap[kind]}_${parts.length + 1}`,
      shape,
      x: 0,
      y: 1.5,
      z: -4 - parts.length * 1.2,
      sx: kind === 'normal' ? 4 : 3.5,
      sy: 1,
      sz: kind === 'normal' ? 4 : 3.5,
      rx: 0,
      ry: 0,
      rz: 0,
      color: colorMap[kind],
      kind,
    };
    commitParts([...parts, nextPart], `Ditambahkan: ${nextPart.name}`);
    setSelectedId(id);
  };

  const addModelJadi = (presetId: string) => {
    const preset = MODEL_JADI_PRESETS.find((m) => m.id === presetId);
    if (!preset) return;
    const zPos = -5 - Math.min(18, parts.length * 0.9);
    const spawned = preset.build(zPos);
    commitParts([...parts, ...spawned], `Model Jadi ditambahkan: ${preset.name} (${spawned.length} part)`);
    if (spawned[0]) setSelectedId(spawned[0].id);
  };

  const addNewScript = (templateId = 'tpl-spin') => {
    const tpl = SCRIPT_TEMPLATES.find((t) => t.id === templateId) ?? SCRIPT_TEMPLATES[0];
    const id = `scr-${Date.now()}`;
    const nextScript: StudioScript = {
      id,
      name: `${tpl.name.replace(/\s+/g, '')}_${scripts.length + 1}`,
      enabled: true,
      targetPartId: selectedPart?.id ?? parts[0]?.id ?? 'all',
      code: tpl.code,
    };
    onChangeScripts([...scripts, nextScript]);
    setEditingScriptId(id);
    pushLog(`Script ditambahkan: ${nextScript.name}`);
  };

  const updateScript = (id: string, patch: Partial<StudioScript>) => {
    onChangeScripts(scripts.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  };

  const deleteScript = (id: string) => {
    onChangeScripts(scripts.filter((s) => s.id !== id));
    if (editingScriptId === id) setEditingScriptId(null);
    pushLog('Script dihapus.');
  };

  const testCompileScript = (script: StudioScript) => {
    const dummy = { x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0, color: '#fff' };
    const noopApi = {
      setSpeed: () => {},
      setJumpPower: () => {},
      setGravity: () => {},
      giveCoins: () => {},
      teleport: () => {},
      heal: () => {},
      respawn: () => {},
      say: () => {},
      setColor: () => {},
      setRainbow: () => {},
      log: () => {},
    };
    const res = compileStudioScript(script, dummy, dummy, noopApi, { x: 0, y: 0, z: 0 });
    if (res.error) {
      pushLog(`Error di ${script.name}: ${res.error}`);
    } else {
      pushLog(`Script "${script.name}" valid dan siap dijalankan!`);
    }
  };

  const nudgeSelected = (dx: number, dy: number, dz: number) => {
    if (!selectedPart) return;
    commitParts(
      parts.map((p) =>
        p.id === selectedPart.id
          ? {
              ...p,
              x: Number((p.x + dx).toFixed(2)),
              y: Number((p.y + dy).toFixed(2)),
              z: Number((p.z + dz).toFixed(2)),
            }
          : p
      )
    );
  };

  const rotateSelected = (drx: number, dry: number, drz: number) => {
    if (!selectedPart) return;
    const norm = (deg: number) => ((deg % 360) + 360) % 360;
    commitParts(
      parts.map((p) =>
        p.id === selectedPart.id
          ? {
              ...p,
              rx: norm((p.rx ?? 0) + drx),
              ry: norm((p.ry ?? 0) + dry),
              rz: norm((p.rz ?? 0) + drz),
            }
          : p
      )
    );
  };

  const resetRotationSelected = () => {
    if (!selectedPart) return;
    commitParts(
      parts.map((p) => (p.id === selectedPart.id ? { ...p, rx: 0, ry: 0, rz: 0 } : p)),
      `Rotasi ${selectedPart.name} direset ke 0°`
    );
  };

  const scaleSelected = (dsx: number, dsy: number, dsz: number) => {
    if (!selectedPart) return;
    commitParts(
      parts.map((p) =>
        p.id === selectedPart.id
          ? {
              ...p,
              sx: Math.max(0.5, Number((p.sx + dsx).toFixed(2))),
              sy: Math.max(0.4, Number((p.sy + dsy).toFixed(2))),
              sz: Math.max(0.5, Number((p.sz + dsz).toFixed(2))),
            }
          : p
      )
    );
  };

  const duplicateSelected = () => {
    if (!selectedPart) return;
    const copy: StudioPart = {
      ...selectedPart,
      id: `part-${Date.now()}`,
      name: `${selectedPart.name}_Copy`,
      z: selectedPart.z - 4,
    };
    commitParts([...parts, copy], `Duplikat: ${copy.name}`);
    setSelectedId(copy.id);
  };

  const deleteSelected = () => {
    if (!selectedPart) return;
    const remaining = parts.filter((p) => p.id !== selectedPart.id);
    commitParts(remaining, `Dihapus: ${selectedPart.name}`);
    setSelectedId(remaining[0]?.id ?? null);
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    const prev = history[history.length - 1];
    setHistory((h) => h.slice(0, -1));
    onChangeParts(prev);
    pushLog('Undo perubahan terakhir');
  };

  const openPublishModal = () => {
    setPubName(projectTitle);
    setPubDesc(projectDescription);
    setPubError(null);
    setPublishOpen(true);
  };

  const submitPublish = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = pubName.trim();
    const cleanDesc = pubDesc.trim();
    if (cleanName.length < 3) {
      setPubError('Nama map harus diisi minimal 3 karakter!');
      return;
    }
    if (cleanDesc.length < 5) {
      setPubError('Deskripsi map wajib diisi minimal 5 karakter!');
      return;
    }
    onPublishProject({ name: cleanName, description: cleanDesc });
    setPublishOpen(false);
    pushLog(`Map "${cleanName}" berhasil dipublikasikan ke Beranda!`);
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-zinc-950 text-zinc-100 overflow-hidden">
      {/* Top Studio Action Bar */}
      <div className="flex items-center justify-between gap-4 px-3 py-2 bg-black border-b border-zinc-800 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={onExitStudio}
            className="p-1.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-200 cursor-pointer shrink-0"
            aria-label="Kembali ke Kreator"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <span className="font-display font-bold text-sm truncate">{projectTitle}</span>
          <button
            type="button"
            onClick={() => {
              onSaveProject();
              pushLog('Proyek disimpan ke penyimpanan lokal.');
            }}
            className="px-3 py-1 text-xs font-semibold bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 rounded cursor-pointer whitespace-nowrap shrink-0"
          >
            Simpan
          </button>
          <button
            type="button"
            onClick={openPublishModal}
            className="px-3 py-1 text-xs font-bold bg-white hover:bg-zinc-200 text-black rounded cursor-pointer whitespace-nowrap shrink-0"
          >
            Publish
          </button>
        </div>

        <button
          type="button"
          onClick={onTestPlay}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-black rounded cursor-pointer whitespace-nowrap shrink-0"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          Test
        </button>
      </div>

      {/* Ribbon Toolbar */}
      <div className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 border-b border-zinc-800 overflow-x-auto shrink-0">
        <button
          type="button"
          onClick={() => setToolMode('select')}
          className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium cursor-pointer whitespace-nowrap shrink-0 ${
            toolMode === 'select' ? 'bg-white text-black font-bold' : 'hover:bg-zinc-800 text-zinc-300'
          }`}
        >
          <MousePointer className="w-3.5 h-3.5" />
          Select
        </button>
        <button
          type="button"
          onClick={() => setToolMode('move')}
          className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium cursor-pointer whitespace-nowrap shrink-0 ${
            toolMode === 'move' ? 'bg-white text-black font-bold' : 'hover:bg-zinc-800 text-zinc-300'
          }`}
        >
          <Move className="w-3.5 h-3.5" />
          Move
        </button>
        <button
          type="button"
          onClick={() => setToolMode('rotate')}
          className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium cursor-pointer whitespace-nowrap shrink-0 ${
            toolMode === 'rotate' ? 'bg-white text-black font-bold' : 'hover:bg-zinc-800 text-zinc-300'
          }`}
        >
          <RotateCw className="w-3.5 h-3.5" />
          Rotate
        </button>
        <button
          type="button"
          onClick={() => setToolMode('scale')}
          className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium cursor-pointer whitespace-nowrap shrink-0 ${
            toolMode === 'scale' ? 'bg-white text-black font-bold' : 'hover:bg-zinc-800 text-zinc-300'
          }`}
        >
          <Scaling className="w-3.5 h-3.5" />
          Scale
        </button>

        <div className="w-px h-5 bg-zinc-700 mx-1 shrink-0" />

        <button
          type="button"
          onClick={handleUndo}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded text-xs hover:bg-zinc-800 text-zinc-300 cursor-pointer whitespace-nowrap shrink-0"
        >
          <Undo2 className="w-3.5 h-3.5" />
          Undo
        </button>
        <button
          type="button"
          onClick={() => nudgeSelected(0, 0.5, 0)}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded text-xs hover:bg-zinc-800 text-zinc-300 cursor-pointer whitespace-nowrap shrink-0"
        >
          <ArrowUp className="w-3.5 h-3.5 text-sky-400" />
          Naik
        </button>
        <button
          type="button"
          onClick={() => nudgeSelected(0, -0.5, 0)}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded text-xs hover:bg-zinc-800 text-zinc-300 cursor-pointer whitespace-nowrap shrink-0"
        >
          <ArrowDown className="w-3.5 h-3.5 text-sky-400" />
          Turun
        </button>

        <div className="w-px h-5 bg-zinc-700 mx-1 shrink-0" />

        <button
          type="button"
          onClick={() => addPart('box', 'normal')}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded text-xs hover:bg-zinc-800 text-zinc-300 cursor-pointer whitespace-nowrap shrink-0"
        >
          <Box className="w-3.5 h-3.5 text-amber-400" />
          Part
        </button>
        <button
          type="button"
          onClick={() => setToolboxTab((t) => (t === 'models' ? 'parts' : 'models'))}
          className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded text-xs cursor-pointer whitespace-nowrap shrink-0 ${
            toolboxTab === 'models' ? 'bg-white text-black font-bold' : 'hover:bg-zinc-800 text-zinc-300'
          }`}
        >
          <PackagePlus className="w-3.5 h-3.5" />
          Model Jadi
        </button>
        <button
          type="button"
          onClick={() => addNewScript('tpl-custom')}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded text-xs bg-zinc-800 hover:bg-zinc-700 text-emerald-300 font-semibold cursor-pointer whitespace-nowrap shrink-0"
        >
          <Code2 className="w-3.5 h-3.5" />
          + Script
        </button>
        <button
          type="button"
          onClick={duplicateSelected}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded text-xs hover:bg-zinc-800 text-zinc-300 cursor-pointer whitespace-nowrap shrink-0"
        >
          <Copy className="w-3.5 h-3.5" />
          Duplikat
        </button>
        <button
          type="button"
          onClick={deleteSelected}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded text-xs hover:bg-rose-900/50 text-rose-300 cursor-pointer whitespace-nowrap shrink-0"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Hapus
        </button>
      </div>

      {/* Main 3-Column Studio Workspace */}
      <div className="flex-1 min-h-0 flex overflow-hidden">
        {/* Left Toolbox: Parts & Model Jadi */}
        <aside className="hidden sm:flex flex-col w-48 bg-zinc-950 border-r border-zinc-800 p-2.5 gap-2.5 overflow-y-auto shrink-0">
          <div className="grid grid-cols-2 gap-1 p-1 rounded-lg bg-zinc-900 border border-zinc-800">
            <button
              type="button"
              onClick={() => setToolboxTab('parts')}
              className={`py-1 rounded text-[11px] font-bold cursor-pointer ${
                toolboxTab === 'parts' ? 'bg-white text-black' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Part
            </button>
            <button
              type="button"
              onClick={() => setToolboxTab('models')}
              className={`py-1 rounded text-[11px] font-bold cursor-pointer ${
                toolboxTab === 'models' ? 'bg-white text-black' : 'text-zinc-400 hover:text-white'
              }`}
            >
              Model Jadi
            </button>
          </div>

          {toolboxTab === 'parts' ? (
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => addPart('box', 'normal')}
                className="flex flex-col items-center justify-center gap-1 p-2.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] cursor-pointer"
              >
                <Box className="w-4 h-4 text-sky-400" />
                Part
              </button>
              <button
                type="button"
                onClick={() => addPart('cylinder', 'normal')}
                className="flex flex-col items-center justify-center gap-1 p-2.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] cursor-pointer"
              >
                <Cylinder className="w-4 h-4 text-amber-400" />
                Cylinder
              </button>
              <button
                type="button"
                onClick={() => addPart('sphere', 'normal')}
                className="flex flex-col items-center justify-center gap-1 p-2.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] cursor-pointer"
              >
                <Circle className="w-4 h-4 text-emerald-400" />
                Ball
              </button>
              <button
                type="button"
                onClick={() => addPart('box', 'bounce')}
                className="flex flex-col items-center justify-center gap-1 p-2.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] cursor-pointer"
              >
                <ArrowUp className="w-4 h-4 text-cyan-400" />
                Bounce
              </button>
              <button
                type="button"
                onClick={() => addPart('box', 'checkpoint')}
                className="flex flex-col items-center justify-center gap-1 p-2.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] cursor-pointer"
              >
                <Box className="w-4 h-4 text-green-400" />
                Stage
              </button>
              <button
                type="button"
                onClick={() => addPart('box', 'finish')}
                className="flex flex-col items-center justify-center gap-1 p-2.5 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] cursor-pointer"
              >
                <Box className="w-4 h-4 text-yellow-400" />
                Finish
              </button>
              <button
                type="button"
                onClick={() => addPart('box', 'hazard')}
                className="col-span-2 flex items-center justify-center gap-1.5 p-2 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] text-rose-300 cursor-pointer"
              >
                <Box className="w-4 h-4 text-rose-500" />
                Lava Hazard
              </button>
            </div>
          ) : (
            <div className="space-y-1.5">
              <div className="text-[11px] text-zinc-400">Klik untuk taruh ke map:</div>
              {MODEL_JADI_PRESETS.map((model) => (
                <button
                  key={model.id}
                  type="button"
                  onClick={() => addModelJadi(model.id)}
                  className="w-full text-left p-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 cursor-pointer flex items-center gap-2"
                >
                  <span
                    style={{ backgroundColor: model.previewColor }}
                    className="w-3.5 h-3.5 rounded shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px] font-bold text-white truncate">{model.name}</div>
                    <div className="text-[10px] text-zinc-400">
                      {model.category} · {model.partsCount} part
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </aside>

        {/* Center 3D Viewport + Floating Move/Rotate GUI + Output */}
        <div className="flex-1 min-w-0 flex flex-col">
          <div className="flex-1 min-h-0 w-full relative">
            <div ref={mountRef} className="w-full h-full" />

            {/* Floating GUI Move & Rotate Gizmo Controls when Move/Rotate is active */}
            {selectedPart && (toolMode === 'move' || toolMode === 'rotate') && (
              <motion.div
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="absolute bottom-3 right-3 z-20 w-60 rounded-2xl bg-zinc-950/92 border border-white/20 p-3 space-y-2.5 shadow-2xl"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-white truncate">
                    {toolMode === 'rotate' ? 'GUI Rotate' : 'GUI Move & Rotate'} · {selectedPart.name}
                  </span>
                  <button
                    type="button"
                    onClick={resetRotationSelected}
                    title="Reset Rotasi 0°"
                    className="p-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                  </button>
                </div>

                {/* Move Quick Pad */}
                {toolMode === 'move' && (
                  <div className="grid grid-cols-3 gap-1 text-[10px] font-bold">
                    <button
                      type="button"
                      onClick={() => nudgeSelected(0, 0.5, 0)}
                      className="py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-emerald-300 cursor-pointer"
                    >
                      Naik
                    </button>
                    <button
                      type="button"
                      onClick={() => nudgeSelected(0, 0, -1)}
                      className="py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-white cursor-pointer"
                    >
                      ↑ Maju
                    </button>
                    <button
                      type="button"
                      onClick={() => nudgeSelected(0, -0.5, 0)}
                      className="py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-emerald-300 cursor-pointer"
                    >
                      Turun
                    </button>
                    <button
                      type="button"
                      onClick={() => nudgeSelected(-1, 0, 0)}
                      className="py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-white cursor-pointer"
                    >
                      ← Kiri
                    </button>
                    <button
                      type="button"
                      onClick={() => nudgeSelected(0, 0, 1)}
                      className="py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-white cursor-pointer"
                    >
                      ↓ Mundur
                    </button>
                    <button
                      type="button"
                      onClick={() => nudgeSelected(1, 0, 0)}
                      className="py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-white cursor-pointer"
                    >
                      Kanan →
                    </button>
                  </div>
                )}

                {/* Rotate Quick GUI Pad (always easy to use while moving or rotating) */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-zinc-400">
                    <span>Rotasi (Derajat)</span>
                    <span className="font-mono text-zinc-300">
                      {selectedPart.rx ?? 0}° / {selectedPart.ry ?? 0}° / {selectedPart.rz ?? 0}°
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-1 text-[10px] font-bold">
                    <button
                      type="button"
                      onClick={() => rotateSelected(15, 0, 0)}
                      className="py-1.5 rounded bg-rose-500/20 border border-rose-500/40 hover:bg-rose-500/35 text-rose-200 cursor-pointer"
                    >
                      ↻ X +15°
                    </button>
                    <button
                      type="button"
                      onClick={() => rotateSelected(0, 45, 0)}
                      className="py-1.5 rounded bg-emerald-500/20 border border-emerald-500/40 hover:bg-emerald-500/35 text-emerald-200 cursor-pointer"
                    >
                      ↻ Y +45°
                    </button>
                    <button
                      type="button"
                      onClick={() => rotateSelected(0, 0, 15)}
                      className="py-1.5 rounded bg-sky-500/20 border border-sky-500/40 hover:bg-sky-500/35 text-sky-200 cursor-pointer"
                    >
                      ↻ Z +15°
                    </button>
                    <button
                      type="button"
                      onClick={() => rotateSelected(-15, 0, 0)}
                      className="py-1 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-300 cursor-pointer"
                    >
                      ↺ X -15°
                    </button>
                    <button
                      type="button"
                      onClick={() => rotateSelected(0, -45, 0)}
                      className="py-1 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-300 cursor-pointer"
                    >
                      ↺ Y -45°
                    </button>
                    <button
                      type="button"
                      onClick={() => rotateSelected(0, 0, -15)}
                      className="py-1 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-300 cursor-pointer"
                    >
                      ↺ Z -15°
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          <div className="h-20 bg-black border-t border-zinc-800 px-3 py-1.5 overflow-y-auto shrink-0">
            <div className="text-[11px] font-semibold text-zinc-400 mb-0.5">Output</div>
            {outputLogs.map((line, i) => (
              <div key={i} className="text-[11px] font-mono text-zinc-300 leading-snug">
                {line}
              </div>
            ))}
          </div>
        </div>

        {/* Right Explorer & Properti */}
        <aside className="w-56 md:w-64 bg-zinc-950 border-l border-zinc-800 flex flex-col overflow-hidden shrink-0">
          <div className="p-2.5 border-b border-zinc-800 flex-1 overflow-y-auto space-y-3">
            <div>
              <div className="text-xs font-bold text-zinc-300 mb-2">Explorer</div>
              <div className="text-xs font-semibold bg-white/10 text-white px-2 py-1 rounded mb-1">
                Workspace ({parts.length})
              </div>
              <div className="space-y-1 pl-2">
                {parts.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedId(p.id)}
                    className={`w-full text-left px-2 py-1 rounded text-xs flex items-center justify-between cursor-pointer ${
                      selectedId === p.id ? 'bg-white text-black font-bold' : 'text-zinc-300 hover:bg-zinc-800'
                    }`}
                  >
                    <span className="truncate">{p.name}</span>
                    <span
                      style={{ backgroundColor: p.color }}
                      className="w-2.5 h-2.5 rounded-sm shrink-0 ml-1 border border-black/30"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Scripts Section in Explorer */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold bg-emerald-500/15 text-emerald-300 px-2 py-1 rounded mb-1">
                <span>Scripts ({scripts.length})</span>
                <button
                  type="button"
                  onClick={() => addNewScript('tpl-custom')}
                  className="p-0.5 rounded hover:bg-emerald-500/30 cursor-pointer"
                  title="Tambah Script Baru"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
              {scripts.length === 0 ? (
                <button
                  type="button"
                  onClick={() => addNewScript('tpl-spin')}
                  className="w-full text-left px-2 py-1.5 rounded text-[11px] text-zinc-400 hover:text-white hover:bg-zinc-900 cursor-pointer"
                >
                  + Buat Script pertama...
                </button>
              ) : (
                <div className="space-y-1 pl-2">
                  {scripts.map((sc) => (
                    <button
                      key={sc.id}
                      type="button"
                      onClick={() => setEditingScriptId(sc.id)}
                      className={`w-full text-left px-2 py-1 rounded text-xs flex items-center justify-between cursor-pointer ${
                        editingScriptId === sc.id
                          ? 'bg-emerald-500 text-black font-bold'
                          : 'text-zinc-300 hover:bg-zinc-800'
                      }`}
                    >
                      <span className="inline-flex items-center gap-1.5 truncate">
                        <Code2 className="w-3 h-3 shrink-0" />
                        <span className="truncate">{sc.name}</span>
                      </span>
                      <span
                        className={`w-2 h-2 rounded-full shrink-0 ${
                          sc.enabled ? 'bg-emerald-400' : 'bg-zinc-600'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="p-2.5 border-t border-zinc-800 space-y-2.5 overflow-y-auto max-h-72">
            <div className="text-xs font-bold text-zinc-300">Properti</div>
            {selectedPart ? (
              <>
                <div className="text-[11px] text-zinc-400 font-mono leading-tight">
                  Pos: ({selectedPart.x}, {selectedPart.y}, {selectedPart.z})
                  <br />
                  Rot: ({selectedPart.rx ?? 0}°, {selectedPart.ry ?? 0}°, {selectedPart.rz ?? 0}°)
                  <br />
                  Size: ({selectedPart.sx}, {selectedPart.sy}, {selectedPart.sz})
                </div>

                {toolMode === 'scale' ? (
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => scaleSelected(0.5, 0, 0.5)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      + Lebar
                    </button>
                    <button
                      type="button"
                      onClick={() => scaleSelected(-0.5, 0, -0.5)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      - Lebar
                    </button>
                    <button
                      type="button"
                      onClick={() => scaleSelected(0, 0.5, 0)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      + Tinggi
                    </button>
                    <button
                      type="button"
                      onClick={() => scaleSelected(0, -0.5, 0)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      - Tinggi
                    </button>
                  </div>
                ) : toolMode === 'rotate' ? (
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => rotateSelected(15, 0, 0)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      Putar X +15°
                    </button>
                    <button
                      type="button"
                      onClick={() => rotateSelected(-15, 0, 0)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      Putar X -15°
                    </button>
                    <button
                      type="button"
                      onClick={() => rotateSelected(0, 45, 0)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      Putar Y +45°
                    </button>
                    <button
                      type="button"
                      onClick={() => rotateSelected(0, -45, 0)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      Putar Y -45°
                    </button>
                    <button
                      type="button"
                      onClick={() => rotateSelected(0, 0, 15)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      Putar Z +15°
                    </button>
                    <button
                      type="button"
                      onClick={() => rotateSelected(0, 0, -15)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      Putar Z -15°
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => nudgeSelected(-1, 0, 0)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      ← Kiri
                    </button>
                    <button
                      type="button"
                      onClick={() => nudgeSelected(1, 0, 0)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      Kanan →
                    </button>
                    <button
                      type="button"
                      onClick={() => nudgeSelected(0, 0, -1)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      ↑ Maju
                    </button>
                    <button
                      type="button"
                      onClick={() => nudgeSelected(0, 0, 1)}
                      className="px-2 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 rounded cursor-pointer"
                    >
                      Mundur ↓
                    </button>
                  </div>
                )}

                <div>
                  <div className="text-[11px] text-zinc-400 mb-1">Warna</div>
                  <div className="flex flex-wrap gap-1.5">
                    {PART_COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() =>
                          commitParts(
                            parts.map((p) => (p.id === selectedPart.id ? { ...p, color: c } : p))
                          )
                        }
                        style={{ backgroundColor: c }}
                        className={`w-5 h-5 rounded cursor-pointer ${
                          selectedPart.color === c ? 'ring-2 ring-white' : ''
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="text-xs text-zinc-500">Pilih atau tambah Part untuk mengedit.</div>
            )}
          </div>
        </aside>
      </div>

      {/* Publish Map Modal (Nama Map & Deskripsi Map Wajib Diisi) */}
      <AnimatePresence>
        {publishOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
            <motion.form
              initial={{ scale: 0.94, opacity: 0, y: 12 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.94, opacity: 0, y: 12 }}
              onSubmit={submitPublish}
              className="w-full max-w-md rounded-2xl bg-zinc-950 border border-white/20 p-5 space-y-4 shadow-2xl"
            >
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-extrabold text-white">Publish Map ke Slapbox</h2>
                <button
                  type="button"
                  onClick={() => setPublishOpen(false)}
                  className="text-zinc-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">Nama Map *</label>
                  <input
                    type="text"
                    value={pubName}
                    onChange={(e) => setPubName(e.target.value)}
                    placeholder="Contoh: Obby Menara Naga"
                    className="w-full px-3 py-2 rounded-xl bg-black border border-white/20 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">Deskripsi Map *</label>
                  <textarea
                    rows={3}
                    value={pubDesc}
                    onChange={(e) => setPubDesc(e.target.value)}
                    placeholder="Jelaskan keseruan map kamu, aturan, atau sistem script di dalamnya..."
                    className="w-full px-3 py-2 rounded-xl bg-black border border-white/20 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-white resize-none"
                  />
                </div>
                <div className="text-[11px] text-zinc-400">
                  Isi map: {parts.length} part · {scripts.filter((s) => s.enabled).length} script aktif
                </div>
                {pubError && (
                  <div className="text-xs font-semibold text-rose-400 bg-rose-950/50 border border-rose-500/30 px-3 py-2 rounded-lg">
                    {pubError}
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPublishOpen(false)}
                  className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-white cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 text-xs font-extrabold text-black cursor-pointer"
                >
                  Publish Sekarang
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>

      {/* Script Editor Modal */}
      <AnimatePresence>
        {editingScript && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
            <motion.div
              initial={{ scale: 0.94, opacity: 0, y: 12 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.94, opacity: 0, y: 12 }}
              className="w-full max-w-2xl rounded-2xl bg-zinc-950 border border-white/20 p-5 space-y-4 shadow-2xl max-h-[90vh] flex flex-col"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Code2 className="w-5 h-5 text-emerald-400" />
                  <h2 className="font-display text-lg font-extrabold text-white">Slapbox Script Editor</h2>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingScriptId(null)}
                  className="text-zinc-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 mb-1">Nama Script</label>
                  <input
                    type="text"
                    value={editingScript.name}
                    onChange={(e) => updateScript(editingScript.id, { name: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-black border border-white/20 text-xs text-white focus:outline-none focus:border-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 mb-1">Target Part</label>
                  <select
                    value={editingScript.targetPartId}
                    onChange={(e) => updateScript(editingScript.id, { targetPartId: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-black border border-white/20 text-xs text-white focus:outline-none focus:border-white"
                  >
                    <option value="all">Semua Part</option>
                    {parts.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex items-end gap-2">
                  <button
                    type="button"
                    onClick={() => updateScript(editingScript.id, { enabled: !editingScript.enabled })}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                      editingScript.enabled ? 'bg-emerald-500 text-black' : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    {editingScript.enabled ? 'Status: Aktif' : 'Status: Nonaktif'}
                  </button>
                </div>
              </div>

              <div>
                <div className="text-[11px] font-bold text-zinc-400 mb-1.5">Template Sistem Siap Pakai:</div>
                <div className="flex flex-wrap gap-1.5">
                  {SCRIPT_TEMPLATES.map((tpl) => (
                    <button
                      key={tpl.id}
                      type="button"
                      onClick={() => updateScript(editingScript.id, { code: tpl.code })}
                      title={tpl.description}
                      className="px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-white/15 text-[11px] font-semibold text-zinc-200 cursor-pointer"
                    >
                      {tpl.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex-1 min-h-0 flex flex-col">
                <div className="text-[11px] text-zinc-400 mb-1 font-mono">
                  API: part (.x .y .z .rx .ry .rz .color) · base · player · api.setSpeed(n) · api.setJumpPower(n) · api.setGravity(n) · api.giveCoins(n) · api.teleport(x,y,z) · api.say(teks)
                </div>
                <textarea
                  rows={8}
                  value={editingScript.code}
                  onChange={(e) => updateScript(editingScript.id, { code: e.target.value })}
                  spellCheck={false}
                  className="w-full flex-1 px-3 py-2.5 rounded-xl bg-black border border-white/20 text-xs font-mono text-emerald-300 focus:outline-none focus:border-emerald-400 resize-none"
                />
              </div>

              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => deleteScript(editingScript.id)}
                  className="px-3 py-2 rounded-xl bg-rose-950/60 hover:bg-rose-900/70 border border-rose-500/30 text-xs font-bold text-rose-300 cursor-pointer"
                >
                  Hapus Script
                </button>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => testCompileScript(editingScript)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-white cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Uji Sintaks
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      testCompileScript(editingScript);
                      setEditingScriptId(null);
                    }}
                    className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 text-xs font-extrabold text-black cursor-pointer"
                  >
                    Simpan & Tutup
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
