import { useState, useEffect, lazy, Suspense } from 'react'
import { searchProducts, deleteProduct, db } from '../db/database'
import { inr } from '../lib/format'
import ProductForm from './ProductForm'

const BarcodeScanner = lazy(() => import('./BarcodeScanner'))

export default function Products({ refreshTick, onChange }) {
  const [query, setQuery] = useState('')
  const [items, setItems] = useState([])
  const [form, setForm] = useState(null)
  const [scanning, setScanning] = useState(false)

  useEffect(() => {
    searchProducts(query).then(setItems)
  }, [query, refreshTick])

  async function handleDelete(p) {
    if (!window.confirm(`Delete "${p.name}"?`)) return
    await deleteProduct(p.id)
    onChange()
  }

  async function handleScan(code) {
    const existing = await db.products.where('barcode').equals(code).first()
    if (existing) {
      setForm(existing)
    } else {
      setForm({ barcode: code, name: '', category: '', mrp: 0, price: 0, stock: 0 })
    }
    setScanning(false)
  }

  return (
    <div>
      <div className="row">
        <input
          className="input grow"
          placeholder="Search naam / barcode…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button className="btn btn-primary" onClick={() => setScanning(true)}>
          Scan
        </button>
        <button className="btn btn-primary" onClick={() => setForm({})}>
          +
        </button>
      </div>

      <p className="muted count">{items.length} products</p>

      <ul className="list">
        {items.map((p) => (
          <li key={p.id} className="list-item">
            <div className="item-main">
              <div className="item-title">{p.name || '(no name)'}</div>
              <div className="item-sub">
                <span className="badge">{p.category || '—'}</span>
                <span className="muted">BC: {p.barcode}</span>
              </div>
            </div>
            <div className="item-price">
              <div>{inr(p.price)}</div>
              <div className="muted small">stock {p.stock ?? 0}</div>
            </div>
            <div className="item-actions">
              <button className="btn btn-small" onClick={() => setForm(p)}>
                Edit
              </button>
              <button className="btn btn-small btn-danger" onClick={() => handleDelete(p)}>
                Del
              </button>
            </div>
          </li>
        ))}
      </ul>

      {form !== null && (
        <ProductForm
          product={form}
          onClose={() => setForm(null)}
          onSaved={() => {
            setForm(null)
            onChange()
          }}
        />
      )}

      {scanning && (
        <Suspense
          fallback={
            <div className="scanner-loading">
              <div className="spinner" />
              <p className="muted">Camera khul raha hai…</p>
            </div>
          }
        >
          <BarcodeScanner onScan={handleScan} onClose={() => setScanning(false)} />
        </Suspense>
      )}
    </div>
  )
}