import React, { useState, useRef } from 'react';
import { ThreeCharacterViewer } from './ThreeCharacterViewer';
import { CameraPreset, LightingPreset, ModelMetadata } from '../types';
import { 
  UploadCloud, 
  RotateCw, 
  Sun, 
  Camera, 
  Sparkles, 
  Info, 
  Layers, 
  RefreshCw,
  Box,
  FileCode,
  CheckCircle2
} from 'lucide-react';

interface CharacterStudioViewProps {
  modelMeta: ModelMetadata | null;
  onModelLoaded: (meta: ModelMetadata) => void;
  customModel?: { buffer: ArrayBuffer; name: string } | null;
  onModelImported?: (buffer: ArrayBuffer, name: string) => void;
  onClearCustomModel?: () => void;
}

export const CharacterStudioView: React.FC<CharacterStudioViewProps> = ({
  modelMeta,
  onModelLoaded,
  customModel = null,
  onModelImported,
  onClearCustomModel,
}) => {
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('front');
  const [lightingPreset, setLightingPreset] = useState<LightingPreset>('cyber-neon');
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [localGlb, setLocalGlb] = useState<{ buffer: ArrayBuffer; name: string } | null>(null);

  // Animation Controls State
  const [idleEnabled, setIdleEnabled] = useState<boolean>(true);
  const [blinkEnabled, setBlinkEnabled] = useState<boolean>(true);
  const [headMovementEnabled, setHeadMovementEnabled] = useState<boolean>(true);

  const effectiveGlb = customModel !== undefined && customModel !== null ? customModel : localGlb;

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImport = (buffer: ArrayBuffer, name: string) => {
    setLocalGlb({ buffer, name });
    onModelImported?.(buffer, name);
  };

  const handleClear = React.useCallback(() => {
    setLocalGlb(null);
    onClearCustomModel?.();
  }, [onClearCustomModel]);

  // Handle Drag and Drop
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.name.toLowerCase().endsWith('.glb') || file.name.toLowerCase().endsWith('.gltf')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const buffer = event.target?.result as ArrayBuffer;
          if (buffer) {
            handleImport(buffer, file.name);
          }
        };
        reader.readAsArrayBuffer(file);
      }
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const buffer = event.target?.result as ArrayBuffer;
        if (buffer) {
          handleImport(buffer, file.name);
        }
      };
      reader.readAsArrayBuffer(file);
    }
    e.target.value = '';
  };

  return (
    <div 
      className="relative w-full h-full flex flex-col bg-[#07070e] overflow-hidden"
      onDragEnter={handleDrag}
      onDragOver={handleDrag}
      onDragLeave={handleDrag}
      onDrop={handleDrop}
    >
      {/* 3D Viewport Area */}
      <div className="relative flex-1 w-full h-[60%] sm:h-[65%]">
        <ThreeCharacterViewer
          onModelLoaded={onModelLoaded}
          interactiveControls={true}
          showModelUploadButton={true}
          activeCameraPreset={cameraPreset}
          onCameraPresetChange={setCameraPreset}
          activeLightingPreset={lightingPreset}
          externalGlbBuffer={effectiveGlb}
          onModelImported={handleImport}
          onClearCustomModel={handleClear}
          idleEnabled={idleEnabled}
          onIdleToggle={setIdleEnabled}
          blinkEnabled={blinkEnabled}
          onBlinkToggle={setBlinkEnabled}
          headMovementEnabled={headMovementEnabled}
          onHeadMovementToggle={setHeadMovementEnabled}
        />

        {/* Drag & Drop Visual Indicator */}
        {dragActive && (
          <div className="absolute inset-4 border-2 border-dashed border-[#ff2d78] bg-[#07070e]/85 backdrop-blur-md rounded-2xl flex flex-col items-center justify-center z-40 pointer-events-none">
            <UploadCloud className="w-12 h-12 text-[#ff2d78] animate-bounce mb-2" />
            <p className="font-cyber text-lg text-white font-bold">Release to Import .glb</p>
            <p className="text-xs text-slate-400 mt-1">Binary glTF 3D model asset</p>
          </div>
        )}
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".glb,.gltf"
        onChange={handleFileInput}
        className="hidden"
      />

      {/* Studio Configuration Dock */}
      <div className="h-[40%] sm:h-[35%] bg-[#0b0b16] border-t border-[#ff2d78]/25 p-3 sm:p-4 overflow-y-auto">
        <div className="max-w-2xl mx-auto space-y-3">
          {/* Header & Upload Action */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-cyber font-bold text-sm tracking-wide text-white flex items-center gap-2">
                <Box className="w-4 h-4 text-[#ff2d78]" />
                3D CHARACTER WORKSHOP
              </h2>
              <p className="text-[11px] text-slate-400 font-sans">
                Rotate, zoom, calibrate lighting, toggle animations, and import models
              </p>
            </div>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-gradient-to-r from-[#ff2d78] to-[#9333ea] hover:brightness-110 text-white font-cyber text-xs px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-md active:scale-95"
            >
              <UploadCloud className="w-3.5 h-3.5" />
              <span>Import .glb</span>
            </button>
          </div>

          {/* Model Statistics & Rig Inspection Panel */}
          <div className="bg-[#121224] border border-slate-800 rounded-xl p-2.5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-cyber font-bold text-slate-200 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-[#06b6d4]" />
                MODEL TELEMETRY & RIG INSPECTION
              </span>
              <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-[#1b1b33] text-[#ff70a6]">
                {modelMeta?.source === 'imported-glb' ? 'Custom Import' : '002 Procedural Rig'}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center mb-2">
              <div className="bg-[#0b0b16] p-2 rounded-lg border border-slate-800/80">
                <span className="block text-[10px] text-slate-400 font-mono-code uppercase">Meshes</span>
                <span className="font-cyber font-bold text-xs text-white">
                  {modelMeta?.meshCount ?? 22}
                </span>
              </div>
              <div className="bg-[#0b0b16] p-2 rounded-lg border border-slate-800/80">
                <span className="block text-[10px] text-slate-400 font-mono-code uppercase">Vertices</span>
                <span className="font-cyber font-bold text-xs text-emerald-400">
                  {modelMeta ? modelMeta.vertexCount.toLocaleString() : '4,200'}
                </span>
              </div>
              <div className="bg-[#0b0b16] p-2 rounded-lg border border-slate-800/80">
                <span className="block text-[10px] text-slate-400 font-mono-code uppercase">Rig Status</span>
                <span className={`font-cyber font-bold text-xs ${modelMeta?.isRigged !== false ? 'text-[#ff2d78]' : 'text-amber-400'}`}>
                  {modelMeta?.isRigged !== false ? `${modelMeta?.boneCount ?? 16} Bones` : 'Unrigged'}
                </span>
              </div>
              <div className="bg-[#0b0b16] p-2 rounded-lg border border-slate-800/80">
                <span className="block text-[10px] text-slate-400 font-mono-code uppercase">Eye Blink</span>
                <span className={`font-cyber font-bold text-xs ${modelMeta?.hasBlinkSupport !== false ? 'text-[#06b6d4]' : 'text-slate-500'}`}>
                  {modelMeta?.hasBlinkSupport !== false ? 'Active' : 'No Morphs'}
                </span>
              </div>
            </div>

            {/* Rig Details Description */}
            <div className="bg-[#0b0b16] px-2.5 py-1.5 rounded-lg border border-slate-800/60 text-[10px] font-mono-code text-slate-400 flex items-center justify-between">
              <span className="text-slate-500">Rig Diagnostics:</span>
              <span className="text-slate-300 font-medium truncate ml-2">
                {modelMeta?.rigDetails ?? 'Procedural Anime Avatar with Dynamic Eye & Breath Rigs'}
              </span>
            </div>
          </div>

          {/* Animation Suite Controls (Phase 1) */}
          <div className="bg-[#121224] border border-[#ff2d78]/25 rounded-xl p-2.5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-cyber font-bold text-slate-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#ff2d78]" />
                ANIMATION SUITE CONTROLS
              </span>
              <span className="text-[10px] font-mono-code text-slate-400">
                Zero-GC Realtime Engine
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {/* Idle Motion Button */}
              <button
                onClick={() => setIdleEnabled(!idleEnabled)}
                className={`py-2 px-2 rounded-xl text-left border transition-all ${
                  idleEnabled
                    ? 'bg-[#1e1028] border-[#ff2d78]/70 shadow-[0_0_10px_rgba(255,45,120,0.25)]'
                    : 'bg-[#15152a] border-slate-800 text-slate-500'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono-code uppercase text-slate-400">Body Idle</span>
                  <span className={`w-2 h-2 rounded-full ${idleEnabled ? 'bg-[#ff2d78] shadow-[0_0_6px_#ff2d78]' : 'bg-slate-600'}`} />
                </div>
                <div className="font-cyber font-bold text-xs text-white mt-0.5">
                  {idleEnabled ? 'Idle: ON' : 'Idle: OFF'}
                </div>
              </button>

              {/* Eye Blinking Button */}
              <button
                onClick={() => setBlinkEnabled(!blinkEnabled)}
                className={`py-2 px-2 rounded-xl text-left border transition-all ${
                  blinkEnabled && modelMeta?.hasBlinkSupport !== false
                    ? 'bg-[#0f1e28] border-[#06b6d4]/70 shadow-[0_0_10px_rgba(6,182,212,0.25)]'
                    : 'bg-[#15152a] border-slate-800 text-slate-500'
                }`}
                title={modelMeta?.hasBlinkSupport === false ? "Model has no eye morph targets" : undefined}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono-code uppercase text-slate-400">Auto Blink</span>
                  <span className={`w-2 h-2 rounded-full ${blinkEnabled && modelMeta?.hasBlinkSupport !== false ? 'bg-[#06b6d4] shadow-[0_0_6px_#06b6d4]' : 'bg-slate-600'}`} />
                </div>
                <div className="font-cyber font-bold text-xs text-white mt-0.5">
                  {modelMeta?.hasBlinkSupport === false ? 'Blink: N/A' : blinkEnabled ? 'Blink: ON' : 'Blink: OFF'}
                </div>
              </button>

              {/* Head Tilt Button */}
              <button
                onClick={() => setHeadMovementEnabled(!headMovementEnabled)}
                className={`py-2 px-2 rounded-xl text-left border transition-all ${
                  headMovementEnabled
                    ? 'bg-[#180f28] border-[#9333ea]/70 shadow-[0_0_10px_rgba(147,51,234,0.25)]'
                    : 'bg-[#15152a] border-slate-800 text-slate-500'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono-code uppercase text-slate-400">Head Tilt</span>
                  <span className={`w-2 h-2 rounded-full ${headMovementEnabled ? 'bg-[#9333ea] shadow-[0_0_6px_#9333ea]' : 'bg-slate-600'}`} />
                </div>
                <div className="font-cyber font-bold text-xs text-white mt-0.5">
                  {headMovementEnabled ? 'Head: ON' : 'Head: OFF'}
                </div>
              </button>
            </div>
          </div>

          {/* Camera & Lighting Environment Selectors */}
          <div className="grid grid-cols-2 gap-2.5">
            {/* Camera View Angle */}
            <div className="bg-[#121224] border border-slate-800 rounded-xl p-2.5">
              <span className="text-[11px] font-cyber font-semibold text-slate-300 block mb-1.5 flex items-center gap-1">
                <Camera className="w-3 h-3 text-[#ff2d78]" />
                CAMERA ANGLE
              </span>
              <div className="grid grid-cols-2 gap-1 text-[10px] font-cyber">
                {(['front', 'portrait', 'full', 'isometric'] as CameraPreset[]).map((cam) => (
                  <button
                    key={cam}
                    onClick={() => setCameraPreset(cam)}
                    className={`py-1 rounded capitalize transition-all ${
                      cameraPreset === cam
                        ? 'bg-[#ff2d78] text-white shadow-[0_0_8px_#ff2d78]'
                        : 'bg-[#18182f] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {cam}
                  </button>
                ))}
              </div>
            </div>

            {/* Lighting Environment */}
            <div className="bg-[#121224] border border-slate-800 rounded-xl p-2.5">
              <span className="text-[11px] font-cyber font-semibold text-slate-300 block mb-1.5 flex items-center gap-1">
                <Sun className="w-3 h-3 text-[#f59e0b]" />
                ENVIRONMENT LIGHT
              </span>
              <div className="grid grid-cols-2 gap-1 text-[10px] font-cyber">
                {(['cyber-neon', 'crimson-cockpit', 'studio', 'deep-space'] as LightingPreset[]).map((light) => (
                  <button
                    key={light}
                    onClick={() => setLightingPreset(light)}
                    className={`py-1 rounded capitalize truncate px-1 transition-all ${
                      lightingPreset === light
                        ? 'bg-[#9333ea] text-white shadow-[0_0_8px_#9333ea]'
                        : 'bg-[#18182f] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {light.replace('-', ' ')}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="text-[11px] text-slate-400 text-center pb-2">
            Tip: Pinch with two fingers to zoom, drag with one finger to rotate around 002.
          </div>
        </div>
      </div>
    </div>
  );
};
