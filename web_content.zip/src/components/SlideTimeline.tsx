import React from 'react';
import { Plus, Trash2, ArrowLeft, ArrowRight, Image as ImageIcon } from 'lucide-react';
import { SlideItem } from '../types';

interface SlideTimelineProps {
  slides: SlideItem[];
  currentIndex: number;
  onSelectSlide: (index: number) => void;
  onRemoveSlide: (index: number) => void;
  onMoveSlide: (index: number, direction: 'left' | 'right') => void;
  onAddFiles: (files: FileList) => void;
}

export const SlideTimeline: React.FC<SlideTimelineProps> = ({
  slides,
  currentIndex,
  onSelectSlide,
  onRemoveSlide,
  onMoveSlide,
  onAddFiles,
}) => {
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  return (
    <div className="w-full bg-neutral-900/90 border border-neutral-800 rounded-xl p-3.5 shadow-lg flex flex-col gap-2.5">
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 font-semibold text-neutral-300">
          <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
          <span>স্লাইড টাইমলাইন (Slide Sequence — {slides.length} টি ছবি)</span>
        </div>
        <span className="text-[11px] text-neutral-500">
          ছবিতে ক্লিক করে জাম্প করুন অথবা ক্রম পরিবর্তন করুন
        </span>
      </div>

      {/* Thumbnails row */}
      <div className="flex items-center gap-2.5 overflow-x-auto pb-1.5 pt-0.5 scrollbar-thin scrollbar-thumb-neutral-700">
        {slides.map((slide, idx) => {
          const isActive = idx === currentIndex;
          return (
            <div
              key={slide.id || idx}
              className={`group relative flex-shrink-0 w-20 h-14 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                isActive
                  ? 'border-emerald-400 ring-2 ring-emerald-500/50 shadow-lg scale-105'
                  : 'border-neutral-700 hover:border-neutral-500 opacity-75 hover:opacity-100'
              }`}
              onClick={() => onSelectSlide(idx)}
            >
              <img
                src={slide.url}
                alt={slide.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />

              {/* Number Badge */}
              <span className="absolute bottom-1 left-1 bg-black/70 backdrop-blur-sm text-[10px] font-bold text-white px-1.5 py-0.2 rounded">
                #{idx + 1}
              </span>

              {/* Action Overlays on hover */}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1 p-1">
                {idx > 0 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onMoveSlide(idx, 'left');
                    }}
                    title="বামে সরান"
                    className="p-1 rounded bg-neutral-800 hover:bg-neutral-700 text-white"
                  >
                    <ArrowLeft className="w-2.5 h-2.5" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemoveSlide(idx);
                  }}
                  title="ছবি মুছুন"
                  className="p-1 rounded bg-rose-600/80 hover:bg-rose-600 text-white"
                >
                  <Trash2 className="w-2.5 h-2.5" />
                </button>
                {idx < slides.length - 1 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onMoveSlide(idx, 'right');
                    }}
                    title="ডানে সরান"
                    className="p-1 rounded bg-neutral-800 hover:bg-neutral-700 text-white"
                  >
                    <ArrowRight className="w-2.5 h-2.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}

        {/* Add more button */}
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="flex-shrink-0 w-20 h-14 rounded-lg border-2 border-dashed border-neutral-700 hover:border-emerald-500 hover:bg-neutral-800/60 transition-colors flex flex-col items-center justify-center text-neutral-400 hover:text-emerald-400 gap-0.5"
          title="আরও ছবি যোগ করুন"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files.length > 0) {
                onAddFiles(e.target.files);
              }
            }}
          />
          <Plus className="w-4 h-4" />
          <span className="text-[10px] font-medium">যোগ করুন</span>
        </button>
      </div>
    </div>
  );
};
