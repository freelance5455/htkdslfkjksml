import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Send, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Trash2, 
  Flame, 
  Shield, 
  RefreshCw,
  Eye,
  Calendar,
  Layers
} from 'lucide-react';
import { 
  propheticNotificationEngine, 
  PropheticPushMessage, 
  CURATED_WORDS_OF_KNOWLEDGE 
} from '../lib/propheticNotificationEngine';

export const PropheticPushNotificationManager: React.FC = () => {
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [queue, setQueue] = useState<PropheticPushMessage[]>([]);
  const [history, setHistory] = useState<PropheticPushMessage[]>([]);

  // Composer Form state
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [scriptureAnchor, setScriptureAnchor] = useState('');
  const [category, setCategory] = useState<PropheticPushMessage['category']>('Breakthrough');
  const [scheduleDelayMins, setScheduleDelayMins] = useState<number>(0); // 0 = instantly
  const [deliveryMethod, setDeliveryMethod] = useState<'both' | 'toast' | 'push'>('both');
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  const refreshData = () => {
    setPermission(propheticNotificationEngine.getPermissionStatus());
    setQueue(propheticNotificationEngine.getQueue());
    setHistory(propheticNotificationEngine.getHistory());
  };

  useEffect(() => {
    refreshData();
    const interval = setInterval(refreshData, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleRequestPermission = async () => {
    const res = await propheticNotificationEngine.requestPushPermission();
    setPermission(res);
    if (res === 'granted') {
      setSuccessBanner('Browser Push Notifications Granted! Believers can now receive words on home screens.');
      setTimeout(() => setSuccessBanner(null), 4000);
    }
  };

  const handleSelectCuratedPreset = (preset: typeof CURATED_WORDS_OF_KNOWLEDGE[0]) => {
    setTitle(preset.title);
    setMessage(preset.message);
    setScriptureAnchor(preset.scriptureAnchor);
    setCategory(preset.category);
  };

  const handleDispatchOrSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) return;

    const scheduledTime = scheduleDelayMins === 0 ? Date.now() : Date.now() + scheduleDelayMins * 60 * 1000;

    propheticNotificationEngine.scheduleMessage({
      sender: 'Prophet JUHNKRIX SYNVAGORD',
      title,
      message,
      scriptureAnchor: scriptureAnchor || 'Hebrews 11:1 — "Now faith is the substance of things hoped for."',
      category,
      scheduledTime,
      deliveryMethod
    });

    if (scheduleDelayMins === 0) {
      setSuccessBanner('Prophetic Word dispatched in real-time across Home Screen and App Toasts!');
    } else {
      setSuccessBanner(`Prophetic Word queued! It will automatically deploy in ${scheduleDelayMins} minute(s).`);
    }

    // Reset form
    setTitle('');
    setMessage('');
    setScriptureAnchor('');
    setScheduleDelayMins(0);
    refreshData();

    setTimeout(() => setSuccessBanner(null), 4000);
  };

  const handleCancelScheduled = (id: string) => {
    propheticNotificationEngine.cancelMessage(id);
    refreshData();
  };

  const handleTriggerQuickTest = () => {
    propheticNotificationEngine.dispatchMessage({
      id: `test-${Date.now()}`,
      sender: 'Prophet JUHNKRIX SYNVAGORD',
      title: 'Word of Knowledge: Immediate Favor',
      message: 'The Lord is pouring out fresh anointing right now. Stand firm, your deliverance is established!',
      scriptureAnchor: 'Exodus 14:14 — "The Lord shall fight for you, and ye shall hold your peace."',
      category: 'Breakthrough',
      scheduledTime: Date.now(),
      status: 'DISPATCHED',
      createdAt: Date.now(),
      deliveryMethod: 'both'
    });
  };

  return (
    <div className="bg-slate-900/90 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 space-y-8 shadow-2xl relative overflow-hidden">
      {/* Background Accent */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-5">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase tracking-wider flex items-center space-x-1">
              <Flame className="w-3 h-3 text-amber-400" />
              <span>Prophetic Push Notification Engine</span>
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Owner Altar • Prophet JUHNKRIX SYNVAGORD
            </span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold font-serif text-amber-100 mt-1">
            Real-Time Word of Knowledge & Scheduled Decrees
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
            Broadcast divine words of knowledge, healing decrees, and encouragement directly to believers’ mobile home screens and in-app ambient toast interfaces.
          </p>
        </div>

        {/* Permission Status & Request Button */}
        <div className="flex items-center gap-2">
          {permission === 'granted' ? (
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Push Notifications Active</span>
            </div>
          ) : (
            <button
              onClick={handleRequestPermission}
              className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 text-slate-950 font-bold text-xs shadow-lg hover:scale-102 transition-all cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              <span>Enable Push Notifications</span>
            </button>
          )}

          <button
            onClick={handleTriggerQuickTest}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-all cursor-pointer"
            title="Fire a test Word of Knowledge immediately"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Test Word</span>
          </button>
        </div>
      </div>

      {/* Success Notification Alert */}
      {successBanner && (
        <div className="p-3.5 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl flex items-center space-x-2 text-xs font-semibold text-emerald-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{successBanner}</span>
        </div>
      )}

      {/* Curated Presets Library */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono font-bold uppercase text-amber-300 tracking-wider flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Curated Words of Knowledge (Quick Presets)</span>
          </span>
          <span className="text-[11px] text-slate-400">Click any preset to load into composer</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {CURATED_WORDS_OF_KNOWLEDGE.map((preset, i) => (
            <div
              key={i}
              onClick={() => handleSelectCuratedPreset(preset)}
              className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-amber-500/50 hover:bg-amber-950/20 transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold">
                    {preset.category}
                  </span>
                  <span className="text-[10px] text-slate-400 group-hover:text-amber-300 transition-colors">Select ↵</span>
                </div>
                <h5 className="text-xs font-bold text-slate-100 group-hover:text-amber-200 line-clamp-1">
                  {preset.title}
                </h5>
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                  {preset.message}
                </p>
              </div>
              <div className="text-[10px] font-serif italic text-amber-400/80 truncate pt-2 border-t border-slate-800/60 mt-2">
                {preset.scriptureAnchor}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Word Composer Form */}
      <form onSubmit={handleDispatchOrSchedule} className="bg-slate-950/70 border border-amber-500/30 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h4 className="text-sm font-bold font-serif text-amber-200 flex items-center space-x-2">
            <Send className="w-4 h-4 text-amber-400" />
            <span>Compose Prophetic Word of Knowledge</span>
          </h4>
          <span className="text-[11px] text-slate-400">Author: Prophet JUHNKRIX SYNVAGORD</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">Message Title / Subject</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Word of Knowledge: Financial Breakthrough"
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">Spiritual Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
            >
              <option value="Breakthrough">Breakthrough</option>
              <option value="Healing">Healing</option>
              <option value="Financial Favor">Financial Favor</option>
              <option value="Prophetic Direction">Prophetic Direction</option>
              <option value="Rest & Peace">Rest & Peace</option>
              <option value="Miracle Provision">Miracle Provision</option>
            </select>
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-semibold text-slate-300">Prophetic Word Content (Message for the Believer)</label>
          <textarea
            required
            rows={3}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type the holy revelation, words of encouragement, or word of knowledge released by the Spirit..."
            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs text-slate-100 focus:outline-none focus:border-amber-400 leading-relaxed resize-none"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">Scripture Reference Anchor</label>
            <input
              type="text"
              value={scriptureAnchor}
              onChange={(e) => setScriptureAnchor(e.target.value)}
              placeholder="e.g. Isaiah 43:19 — Behold, I will do a new thing..."
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span>Scheduling Option</span>
              <span className="text-[10px] text-amber-400 font-mono">
                {scheduleDelayMins === 0 ? 'Immediate Real-Time' : `In ${scheduleDelayMins} mins`}
              </span>
            </label>
            <select
              value={scheduleDelayMins}
              onChange={(e) => setScheduleDelayMins(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
            >
              <option value={0}>⚡ Send Immediately (Real-Time Push)</option>
              <option value={1}>⏱️ Schedule in 1 Minute (Live Demonstration)</option>
              <option value={5}>⏱️ Schedule in 5 Minutes</option>
              <option value={15}>⏱️ Schedule in 15 Minutes</option>
              <option value={60}>⏱️ Schedule in 1 Hour</option>
              <option value={360}>🌅 Morning Watch (In 6 Hours)</option>
            </select>
          </div>
        </div>

        {/* Submit Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <div className="text-[11px] text-slate-400 flex items-center space-x-2">
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            <span>Delivers via Browser Push Notification & Glowing In-App Toast</span>
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:scale-102 text-slate-950 font-extrabold text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center space-x-2 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>
              {scheduleDelayMins === 0 ? 'Broadcast Instantly to All Believers' : `Schedule Prophetic Word (${scheduleDelayMins}m)`}
            </span>
          </button>
        </div>
      </form>

      {/* Queue & History Displays */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pending Queue */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-mono font-bold uppercase text-amber-300 flex items-center space-x-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Pending Scheduled Queue ({queue.length})</span>
            </span>
            <button
              onClick={refreshData}
              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 transition-colors"
              title="Refresh"
            >
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>

          {queue.length === 0 ? (
            <p className="text-xs text-slate-500 italic py-4 text-center">
              No scheduled messages pending. All words have been dispatched.
            </p>
          ) : (
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {queue.map((item) => (
                <div key={item.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3 text-xs">
                  <div className="space-y-0.5 min-w-0">
                    <div className="font-bold text-slate-200 truncate">{item.title}</div>
                    <div className="text-[11px] text-slate-400 truncate">{item.message}</div>
                    <div className="text-[10px] text-amber-400 font-mono">
                      Scheduled for: {new Date(item.scheduledTime).toLocaleTimeString()}
                    </div>
                  </div>
                  <button
                    onClick={() => handleCancelScheduled(item.id)}
                    className="p-1.5 rounded-lg bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 transition-all flex-shrink-0"
                    title="Cancel scheduled dispatch"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Dispatched History */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-mono font-bold uppercase text-emerald-300 flex items-center space-x-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Dispatched Prophetic Decrees ({history.length})</span>
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Real-time log</span>
          </div>

          {history.length === 0 ? (
            <p className="text-xs text-slate-500 italic py-4 text-center">
              No previous dispatches recorded yet.
            </p>
          ) : (
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {history.map((item) => (
                <div key={item.id} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800/80 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200">{item.title}</span>
                    <span className="text-[10px] text-emerald-400 font-mono">✓ Dispatched</span>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-1">{item.message}</p>
                  <div className="text-[10px] text-slate-500 font-mono">
                    {new Date(item.createdAt).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
