import React, { useState } from 'react';
import {
  Search,
  MapPin,
  Briefcase,
  DollarSign,
  CheckCircle2,
  Send,
  PlusCircle,
  Sparkles,
  X,
  Filter,
  Check,
  Building,
  Target,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { JobListing, Language, JobApplication, UserProfileData } from '../types';
import { SAMPLE_JOBS } from '../data/mockData';
import { translations } from '../translations/translations';
import { synthesizeApplicationPitch } from '../services/aiFallbackService';

interface Props {
  language: Language;
  onApplyJob: (application: JobApplication) => void;
  appliedJobIds: string[];
  userProfile: UserProfileData;
}

export const FindJobs: React.FC<Props> = ({
  language,
  onApplyJob,
  appliedJobIds,
  userProfile,
}) => {
  const [jobs, setJobs] = useState<JobListing[]>(SAMPLE_JOBS);
  const [searchQuery, setSearchQuery] = useState('');
  const [locationFilter, setLocationFilter] = useState<'all' | 'remote' | 'on-site' | 'hybrid'>('all');
  const [selectedJob, setSelectedJob] = useState<JobListing | null>(null);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [coverNote, setCoverNote] = useState('');
  const [isGeneratingAiPitch, setIsGeneratingAiPitch] = useState(false);
  const [isPostJobModalOpen, setIsPostJobModalOpen] = useState(false);

  // New Job state
  const [newTitle, setNewTitle] = useState('');
  const [newCompany, setNewCompany] = useState('');
  const [newLocation, setNewLocation] = useState('Addis Ababa, Ethiopia');
  const [newSalary, setNewSalary] = useState('');
  const [newProblemSolved, setNewProblemSolved] = useState('');

  const t = translations[language].jobs;

  const filteredJobs = jobs.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.titleAm.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.requirements.some((r) => r.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesLocation =
      locationFilter === 'all' || job.locationType === locationFilter;

    return matchesSearch && matchesLocation;
  });

  const handleOpenApply = (job: JobListing) => {
    setSelectedJob(job);
    setCoverNote(
      `Hello ${job.company} Team,\n\nI am applying for the ${job.title} position because my background in problem solving and initiative directly aligns with your mission to solve "${job.problemSolved}". I would love to bring my skills to your team.`
    );
    setIsApplyModalOpen(true);
  };

  const handleGenerateAiPitch = async () => {
    if (!selectedJob) return;
    setIsGeneratingAiPitch(true);
    let pitch: any = null;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 7000);

      const response = await fetch('/api/gemini/tailor-application', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        signal: controller.signal,
        body: JSON.stringify({
          userProfile,
          targetJob: selectedJob,
          language,
        }),
      });

      clearTimeout(timeoutId);

      if (response.ok) {
        const data = await response.json().catch(() => null);
        if (data?.data?.coverLetter) {
          pitch = data.data;
        }
      }
    } catch (err: any) {
      console.warn('Network issue in pitch generator, using engine:', err?.message);
    }

    if (!pitch || !pitch.coverLetter) {
      pitch = synthesizeApplicationPitch(
        language === 'am' ? selectedJob.titleAm : selectedJob.title,
        selectedJob.company,
        language
      );
    }

    setCoverNote(pitch.coverLetter);
    setIsGeneratingAiPitch(false);
  };

  const handleSubmitApplication = () => {
    if (!selectedJob) return;

    const application: JobApplication = {
      id: `app_${Date.now()}`,
      jobId: selectedJob.id,
      jobTitle: language === 'am' ? selectedJob.titleAm : selectedJob.title,
      company: selectedJob.company,
      appliedAt: new Date().toISOString(),
      status: 'submitted',
      coverNote,
    };

    onApplyJob(application);
    setIsApplyModalOpen(false);

    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#059669', '#10b981', '#34d399'],
      });
    } catch {}
  };

  const handleCreateJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newCompany) return;

    const newJob: JobListing = {
      id: `job_${Date.now()}`,
      title: newTitle,
      titleAm: newTitle,
      company: newCompany,
      location: newLocation,
      locationType: 'on-site',
      category: 'business',
      type: 'full-time',
      salaryRange: newSalary || 'Negotiable',
      description: `Opportunity to solve local operational challenges at ${newCompany}.`,
      descriptionAm: `በ${newCompany} ውስጥ ያሉ የፈጠራ እና የስራ እድሎችን የመምራት ስራ።`,
      requirements: ['Enthusiasm for problem solving', 'Strong communication skills'],
      requirementsAm: ['ችግሮችን የመፍታት ዝግጁነት', 'ጥሩ ተግባቦት'],
      postedAt: 'Just now',
      problemSolved: newProblemSolved || 'Driving local efficiency and growth.',
      problemSolvedAm: 'የአካባቢውን የስራ እና የአገልግሎት ቅልጥፍና ማሳደግ።',
    };

    setJobs([newJob, ...jobs]);
    setIsPostJobModalOpen(false);
    setNewTitle('');
    setNewCompany('');
    setNewSalary('');
    setNewProblemSolved('');
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-3xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
            <Briefcase className="w-4 h-4 text-emerald-600" />
            <span>PROJECT ZERO • TALENT & GIGS</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900">{t.title}</h2>
          <p className="text-xs text-slate-500 mt-1 max-w-lg">{t.subtitle}</p>
        </div>

        <button
          onClick={() => setIsPostJobModalOpen(true)}
          className="self-start sm:self-center px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-sm shrink-0 cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{t.postJob}</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full pl-11 pr-4 py-3 rounded-2xl bg-white border border-slate-200 text-slate-800 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500 placeholder:text-slate-400 shadow-xs"
          />
        </div>

        {/* Location Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-semibold">
          {[
            { id: 'all', label: t.filterAll },
            { id: 'remote', label: t.filterRemote },
            { id: 'on-site', label: t.filterOnSite },
            { id: 'hybrid', label: t.filterHybrid },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setLocationFilter(item.id as any)}
              className={`px-3.5 py-1.5 rounded-full whitespace-nowrap transition-all ${
                locationFilter === item.id
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Job Cards List */}
      <div className="space-y-4">
        {filteredJobs.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 text-slate-500 text-xs">
            {t.noJobsFound}
          </div>
        ) : (
          filteredJobs.map((job) => {
            const isApplied = appliedJobIds.includes(job.id);
            const title = language === 'am' ? job.titleAm : job.title;
            const description = language === 'am' ? job.descriptionAm : job.description;
            const problem = language === 'am' ? job.problemSolvedAm : job.problemSolved;
            const reqs = language === 'am' ? job.requirementsAm : job.requirements;

            return (
              <div
                key={job.id}
                className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm hover:border-emerald-300 transition-all space-y-4 group"
              >
                {/* Header row */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200">
                        {job.category}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-600">
                        {job.locationType}
                      </span>
                      <span className="text-[11px] text-slate-400">{job.postedAt}</span>
                    </div>

                    <h3 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-emerald-800 transition-colors">
                      {title}
                    </h3>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1">
                      <span className="flex items-center font-semibold text-slate-700">
                        <Building className="w-3.5 h-3.5 mr-1 text-slate-400" />
                        {job.company}
                      </span>
                      <span className="flex items-center">
                        <MapPin className="w-3.5 h-3.5 mr-1 text-slate-400" />
                        {job.location}
                      </span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="inline-block px-3 py-1 rounded-xl bg-emerald-50 text-emerald-900 font-extrabold text-xs">
                      {job.salaryRange}
                    </span>
                  </div>
                </div>

                {/* Problem this role solves (PROJECT ZERO Core Theme) */}
                <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-100 text-xs">
                  <div className="flex items-center space-x-1.5 font-bold text-emerald-950 mb-1">
                    <Target className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t.problemAddressed}</span>
                  </div>
                  <p className="text-emerald-900 leading-relaxed font-medium">{problem}</p>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-600 leading-relaxed">{description}</p>

                {/* Requirements Pills */}
                <div className="space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    {t.requirements}
                  </div>
                  <ul className="text-xs text-slate-600 space-y-1 list-disc list-inside">
                    {reqs.slice(0, 3).map((r, i) => (
                      <li key={i} className="line-clamp-1">
                        {r}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Footer Action */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    {job.type} • Verified Employer
                  </span>

                  <button
                    onClick={() => handleOpenApply(job)}
                    disabled={isApplied}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                      isApplied
                        ? 'bg-emerald-100 text-emerald-800 cursor-default'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                    }`}
                  >
                    {isApplied ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>{t.applied}</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>{t.applyNow}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Apply Modal */}
      {isApplyModalOpen && selectedJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-lg border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="bg-gradient-to-r from-emerald-800 to-teal-800 p-5 text-white flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-base">{t.applyModalTitle}</h3>
                <p className="text-emerald-200 text-xs mt-0.5">
                  {selectedJob.title} @ {selectedJob.company}
                </p>
              </div>
              <button
                onClick={() => setIsApplyModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              {/* Applicant Profile preview */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-900">{userProfile.displayName}</div>
                  <div className="text-slate-500 text-[11px]">{userProfile.email} • {userProfile.location}</div>
                </div>
                <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                  CV Linked
                </span>
              </div>

              {/* Cover Note with AI generator option */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-bold text-slate-700">Application Note / Pitch</label>
                  <button
                    onClick={handleGenerateAiPitch}
                    disabled={isGeneratingAiPitch}
                    className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 flex items-center space-x-1"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{isGeneratingAiPitch ? t.generatingCover : t.generateCoverAi}</span>
                  </button>
                </div>
                <textarea
                  value={coverNote}
                  onChange={(e) => setCoverNote(e.target.value)}
                  placeholder={t.coverLetterPlaceholder}
                  rows={5}
                  className="w-full p-3 rounded-2xl bg-slate-50 border border-slate-200 text-slate-800 text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white leading-relaxed resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  onClick={() => setIsApplyModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmitApplication}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center space-x-1.5 shadow-sm"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{t.submitApplication}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Post a Job Modal */}
      {isPostJobModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl w-full max-w-lg border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="bg-gradient-to-r from-emerald-800 to-teal-800 p-5 text-white flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-base">{t.postJob}</h3>
                <p className="text-emerald-200 text-xs mt-0.5">
                  Hire problem solvers from the Project Zero community
                </p>
              </div>
              <button
                onClick={() => setIsPostJobModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateJob} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Job Title / Role</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Solar Technician or Operations Lead"
                  className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Company / Organization</label>
                <input
                  type="text"
                  required
                  value={newCompany}
                  onChange={(e) => setNewCompany(e.target.value)}
                  placeholder="e.g. GreenHorizon Enterprises"
                  className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Location</label>
                  <input
                    type="text"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Compensation</label>
                  <input
                    type="text"
                    value={newSalary}
                    onChange={(e) => setNewSalary(e.target.value)}
                    placeholder="e.g. 20,000 ETB / mo"
                    className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  What Problem Will This Person Solve? (Project Zero Core)
                </label>
                <input
                  type="text"
                  value={newProblemSolved}
                  onChange={(e) => setNewProblemSolved(e.target.value)}
                  placeholder="e.g. Resolving supply chain bottlenecks for farmers"
                  className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-3 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsPostJobModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                >
                  Publish Listing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
