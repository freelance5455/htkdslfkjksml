import React, { useState } from 'react';
import {
  Users,
  Flame,
  Sparkle,
  Smile,
  Footprints,
  Sun,
  Coffee,
  HeartHandshake,
  BookOpen,
  Zap,
  Clock,
  Star,
  Search,
  ShieldCheck,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { RegulationTool } from '../types/index.ts';

interface SpaceParentsProps {
  tools: RegulationTool[];
  onOpenTool: (tool: RegulationTool, version: 'short' | 'full') => void;
  favorites: string[];
  onToggleFavorite: (toolId: string) => void;
}

export const SpaceParents: React.FC<SpaceParentsProps> = ({
  tools,
  onOpenTool,
  favorites,
  onToggleFavorite,
}) => {
  const { t } = useTranslation();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    { id: 'all', label: t('parentsSpace.categories.all') },
    { id: 'parent_crisis', label: t('parentsSpace.categories.parent_crisis') },
    { id: 'co_regulation', label: t('parentsSpace.categories.co_regulation') },
    { id: 'parent_care', label: t('parentsSpace.categories.parent_care') },
  ];

  const parentTools = tools.filter((tool) => {
    if (tool.space !== 'parents') return false;
    const matchesCategory = activeCategory === 'all' || tool.category === activeCategory;
    const matchesSearch =
      searchQuery === '' ||
      tool.titleKey.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.shortDescriptionKey.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getToolIcon = (name: string) => {
    switch (name) {
      case 'Flame':
        return <Flame className="w-5 h-5 text-red-500" />;
      case 'Sparkle':
        return <Sparkle className="w-5 h-5 text-amber-500" />;
      case 'Smile':
        return <Smile className="w-5 h-5 text-emerald-500" />;
      case 'Footprints':
        return <Footprints className="w-5 h-5 text-indigo-500" />;
      case 'Sun':
        return <Sun className="w-5 h-5 text-orange-500" />;
      case 'Coffee':
        return <Coffee className="w-5 h-5 text-teal-500" />;
      case 'HeartHandshake':
        return <HeartHandshake className="w-5 h-5 text-rose-500" />;
      case 'BookOpen':
        return <BookOpen className="w-5 h-5 text-cyan-600" />;
      default:
        return <Users className="w-5 h-5 text-teal-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Golden Rule of Co-Regulation Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-teal-500/15 via-emerald-500/10 to-amber-500/15 border border-teal-200/80 dark:border-teal-900/60 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-extrabold tracking-wider px-2.5 py-1 rounded-full bg-teal-600 text-white shadow-2xs">
                {t('parentsSpace.bannerTitle')}
              </span>
            </div>
            <p className="text-sm font-semibold text-teal-950 dark:text-teal-100 leading-relaxed pt-1">
              "{t('parentsSpace.bannerText')}"
            </p>
          </div>

          <div className="flex items-center gap-2 bg-white/80 dark:bg-slate-800/80 backdrop-blur-xs p-3 rounded-2xl border border-teal-100 dark:border-slate-700 shrink-0">
            <ShieldCheck className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            <div className="text-xs">
              <span className="font-bold block text-slate-800 dark:text-slate-100">
                Théorie Polyvagale
              </span>
              <span className="text-slate-500 dark:text-slate-400">
                L’attachement sécure avant la raison
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shadow-2xs ${
                activeCategory === cat.id
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64 shrink-0">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher (ex: colère, volcan, reset...)"
            className="w-full text-xs pl-9 pr-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-400 shadow-2xs"
          />
        </div>
      </div>

      {/* Parent Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {parentTools.map((tool) => {
          const isFav = favorites.includes(tool.id);
          return (
            <div
              key={tool.id}
              className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group hover:border-teal-200 dark:hover:border-slate-700"
            >
              <div>
                {/* Header: Icon, Tags, Favorite */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="w-10 h-10 rounded-2xl bg-teal-50 dark:bg-slate-800 flex items-center justify-center border border-teal-100/60 dark:border-slate-700 shadow-2xs group-hover:scale-105 transition-transform">
                    {getToolIcon(tool.iconName)}
                  </div>

                  <div className="flex items-center gap-1.5">
                    {tool.emergencyRelevant && (
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200/60 dark:border-rose-900">
                        Urgence Crise
                      </span>
                    )}
                    <button
                      onClick={() => onToggleFavorite(tool.id)}
                      className={`p-1.5 rounded-lg transition-colors ${
                        isFav
                          ? 'text-amber-500 fill-amber-500'
                          : 'text-slate-300 dark:text-slate-600 hover:text-amber-400'
                      }`}
                      title={isFav ? 'Retirer des favoris' : 'Ajouter aux favoris'}
                    >
                      <Star className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Title & Description */}
                <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-base leading-snug mb-1 group-hover:text-teal-600 transition-colors">
                  {tool.titleKey}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-4">
                  {tool.shortDescriptionKey}
                </p>
              </div>

              {/* Action Buttons: Short & Full */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <button
                  onClick={() => onOpenTool(tool, 'short')}
                  className="flex-1 py-2 px-3 rounded-xl bg-teal-50 hover:bg-teal-100 dark:bg-teal-950/30 dark:hover:bg-teal-900/40 text-teal-800 dark:text-teal-300 text-xs font-bold transition-all flex items-center justify-center gap-1 shadow-2xs"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>Court ({tool.durationShortMin} min)</span>
                </button>

                <button
                  onClick={() => onOpenTool(tool, 'full')}
                  className="flex-1 py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition-all flex items-center justify-center gap-1 shadow-2xs"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>Complet ({tool.durationFullMin} min)</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
