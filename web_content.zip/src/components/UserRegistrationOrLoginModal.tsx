import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Smartphone,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Key,
  User,
  Mail,
  CheckCircle2,
  AlertTriangle,
  HardDrive,
  Upload,
  ArrowRight,
  RefreshCw,
  Cpu,
  Fingerprint,
  Radio,
  FileCheck2,
  X
} from 'lucide-react';
import { deviceRegistryEngine, RegisteredDeviceRecord, DeviceTelemetryInspection } from '../lib/deviceRegistryEngine';
import { selfCustodialBackupEngine, BackupScanResult } from '../lib/selfCustodialBackupEngine';
import { DeviceScanAnimation } from './DeviceScanAnimation';
import { DeviceIntegrityReport } from '../lib/deviceSecurityScanner';

interface UserRegistrationOrLoginModalProps {
  isOpen: boolean;
  onSuccess: (userProfile: { fullName: string; email: string; deviceRecord: RegisteredDeviceRecord }) => void;
  onNavigateToBackupPage?: () => void;
}

export const UserRegistrationOrLoginModal: React.FC<UserRegistrationOrLoginModalProps> = ({
  isOpen,
  onSuccess,
  onNavigateToBackupPage
}) => {
  const [mode, setMode] = useState<'REGISTER' | 'LOGIN'>('REGISTER');
  const [fullName, setFullName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [phoneNumber, setPhoneNumber] = useState<string>('+234 ');
  
  // Device inspection state
  const [inspectingHardware, setInspectingHardware] = useState<boolean>(true);
  const [hardwareSpecs, setHardwareSpecs] = useState<DeviceTelemetryInspection | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  // Post-Approval Previous Profile Popup Screen
  const [approvedDeviceRecord, setApprovedDeviceRecord] = useState<RegisteredDeviceRecord | null>(null);
  const [showBackupPrompt, setShowBackupPrompt] = useState<boolean>(false);
  const [isScanningMedia, setIsScanningMedia] = useState<boolean>(false);
  const [restoreNotice, setRestoreNotice] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const runInspection = async () => {
      setInspectingHardware(true);
      try {
        const specs = await deviceRegistryEngine.inspectCurrentDevice();
        setHardwareSpecs(specs);
      } catch (err) {
        console.warn('Hardware inspection error:', err);
      } finally {
        setInspectingHardware(false);
      }
    };
    runInspection();
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!email.trim() || !password.trim()) {
      setErrorMsg('Please provide your accurate Email Address and Password.');
      return;
    }

    if (mode === 'REGISTER' && !fullName.trim()) {
      setErrorMsg('Please enter your accurate Full Name.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Execute fast hardware detection, signing, and approval within seconds
      const result = await deviceRegistryEngine.registerAndApproveDevice({
        fullName: mode === 'REGISTER' ? fullName.trim() : (fullName.trim() || 'Prophetic Believer'),
        email: email.trim().toLowerCase(),
        password: password.trim(),
        phoneNumber: phoneNumber.trim()
      });

      // Store passkey hash locally for session authorization
      localStorage.setItem('juhnkrix_user_pass_hash', `HASH-ED25519-${btoa(password.trim()).slice(0, 16)}`);
      localStorage.setItem('juhnkrix_current_session_token', `SESSION-50M-NODE-${Date.now()}`);

      setApprovedDeviceRecord(result.device);

      // Check if user has an existing profile to restore
      if (result.hasPreviousProfile || mode === 'LOGIN' || result.isFirstTimeDevice) {
        setShowBackupPrompt(true);
      } else {
        onSuccess({
          fullName: result.device.registeredUser.fullName,
          email: result.device.registeredUser.email,
          deviceRecord: result.device
        });
      }
    } catch (err: any) {
      setErrorMsg(`Device approval failure: ${err?.message || 'Decentralized node error'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // User clicked "RESTORE BACKUP PROFILE" on the prompt screen
  const handleRestoreFromPrompt = async () => {
    setIsScanningMedia(true);
    setRestoreNotice('Scanning SD CARD, FLASHDRIVE, HARD DRIVE, or EXTERNAL HARD DISK...');
    setErrorMsg(null);

    try {
      const scan = await selfCustodialBackupEngine.scanForBackupMedia();

      if (!scan.mediaDetected || !scan.hasBackupFile || !scan.backupPayload) {
        setIsScanningMedia(false);
        setErrorMsg(
          scan.error ||
          'There is no SD CARD, HARD DRIVE, FLASHDRIVE, and EXTERNAL HARD DISK in the your device, please insert a SD CARD, HARD DRIVE, FLASHDRIVE, and EXTERNAL HARD DISK'
        );
        return;
      }

      // Check for authentic backup
      if (!scan.isAuthenticJuhnkrixBackup) {
        setIsScanningMedia(false);
        setErrorMsg('Please insert the right SD CARD, HARD DRIVE, FLASHDRIVE, and EXTERNAL HARD DISK where the backup was saved');
        return;
      }

      // Strict Anti-Fraud verification: Names, Password, and Email Address must match exactly!
      const verifyResult = await selfCustodialBackupEngine.verifyAndRestoreProfile(
        scan.backupPayload,
        {
          fullName: fullName.trim() || approvedDeviceRecord?.registeredUser.fullName || '',
          email: email.trim().toLowerCase() || approvedDeviceRecord?.registeredUser.email || '',
          password: password.trim()
        }
      );

      setIsScanningMedia(false);

      if (!verifyResult.success) {
        // Immediate rejection with fraud notification
        setErrorMsg(
          `${verifyResult.message} The informations on the backup profile mismatched! Therefore, please try again or startup a new profile afresh.`
        );
        return;
      }

      // Exact match confirmed!
      setRestoreNotice(verifyResult.message);
      setTimeout(() => {
        if (approvedDeviceRecord) {
          onSuccess({
            fullName: approvedDeviceRecord.registeredUser.fullName,
            email: approvedDeviceRecord.registeredUser.email,
            deviceRecord: approvedDeviceRecord
          });
        }
      }, 2000);
    } catch (err: any) {
      setIsScanningMedia(false);
      setErrorMsg(`Restoration error: ${err?.message || 'Media access exception'}`);
    }
  };

  const handleSkipRestoreAndContinue = () => {
    if (approvedDeviceRecord) {
      onSuccess({
        fullName: approvedDeviceRecord.registeredUser.fullName,
        email: approvedDeviceRecord.registeredUser.email,
        deviceRecord: approvedDeviceRecord
      });
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto bg-slate-900 border-2 border-amber-500/60 rounded-3xl p-6 sm:p-8 shadow-2xl text-slate-100 font-sans"
      >
        {/* Glow Effects */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* SCREEN 1: REGISTRATION & LOGIN WITH REAL-TIME HARDWARE INSPECTION */}
        {!showBackupPrompt ? (
          <div className="space-y-5">
            {/* Header */}
            <div className="text-center space-y-2">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-500/20 to-yellow-500/30 border-2 border-amber-400 mx-auto flex items-center justify-center text-amber-300 shadow-xl shadow-amber-500/20">
                <Smartphone className="w-8 h-8" />
              </div>
              <span className="px-3 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-black uppercase tracking-wider inline-block">
                DECENTRALIZED 50M PEER ACCESS
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight font-serif">
                {mode === 'REGISTER' ? 'USER REGISTRATION & DEVICE APPROVAL' : 'USER LOGIN & DEVICE VERIFICATION'}
              </h2>
              <p className="text-xs text-slate-300 font-mono max-w-md mx-auto">
                No centralized web hosting company controls JUHNKRIX MUSIKA. Your device connects directly to the 50,000,000 users decentralized internet network.
              </p>
            </div>

            {/* Toggle Modes */}
            <div className="flex rounded-2xl bg-slate-950 p-1 border border-slate-800">
              <button
                type="button"
                onClick={() => { setMode('REGISTER'); setErrorMsg(null); }}
                className={`flex-1 py-2 text-xs font-mono font-bold rounded-xl transition-all cursor-pointer ${
                  mode === 'REGISTER'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Register New Device
              </button>
              <button
                type="button"
                onClick={() => { setMode('LOGIN'); setErrorMsg(null); }}
                className={`flex-1 py-2 text-xs font-mono font-bold rounded-xl transition-all cursor-pointer ${
                  mode === 'LOGIN'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Login to Device
              </button>
            </div>

            {/* Device Scan Animation visualizing the Registered Device Information inspection process */}
            <div className="space-y-2">
              <DeviceScanAnimation
                compact={true}
                title="Registered Device Information Inspection"
                subtitle="Verifying IMEI, Model, Manufacturer & Decentralized Storage Integrity"
                onScanComplete={(rep: DeviceIntegrityReport) => {
                  setHardwareSpecs({
                    serialNumber: rep.identifiers.serialNumber,
                    productKey: rep.identifiers.productKey,
                    manufacturer: rep.identifiers.manufacturer,
                    imei: rep.identifiers.imei,
                    model: rep.identifiers.model,
                    osVersion: rep.identifiers.version,
                    deviceName: rep.identifiers.deviceName,
                    screenResolution: rep.identifiers.screenResolution,
                    hardwareConcurrency: rep.identifiers.hardwareConcurrency,
                    deviceMemoryGb: rep.identifiers.deviceMemoryGb,
                    gpuRenderer: rep.identifiers.gpuRenderer
                  });
                }}
              />
            </div>

            {errorMsg && (
              <div className="p-3 rounded-2xl bg-rose-950/80 border border-rose-500/50 text-xs font-mono text-rose-200 flex items-start gap-2 shadow-md">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs font-mono">
              {mode === 'REGISTER' && (
                <div>
                  <label className="text-slate-300 block mb-1 font-bold">Full Legal / Spiritual Name:</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Sister Grace Adebayo"
                      required
                      className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl pl-9 pr-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="text-slate-300 block mb-1 font-bold">Accurate Email Address:</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. grace.adebayo@sanctuarypraise.org"
                    required
                    className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl pl-9 pr-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-bold">Master Password:</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your accurate master password..."
                    required
                    className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl pl-9 pr-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none"
                  />
                </div>
              </div>

              {mode === 'REGISTER' && (
                <div>
                  <label className="text-slate-300 block mb-1 font-bold">Phone / Telegram Number (Optional):</label>
                  <input
                    type="text"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="+234 803 000 0000"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-2 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-mono text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 hover:scale-[1.02] transition-all cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Signing & Approving Device...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 text-slate-950" />
                    <span>{mode === 'REGISTER' ? 'Register & Approve This Device' : 'Login & Authorize This Device'}</span>
                  </>
                )}
              </button>
            </form>

            <div className="text-center pt-2 border-t border-slate-800 text-[10px] text-slate-500 font-mono">
              Serial numbers, product keys, IMEI, and models are securely registered into the hidden decentralized vault for Prophet JUHNKRIX SYNVAGORD.
            </div>
          </div>
        ) : (
          /* SCREEN 2: POST-APPROVAL PREVIOUS PROFILE BACKUP RESTORE PROMPT */
          <div className="space-y-5 text-center">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border-2 border-emerald-400 mx-auto flex items-center justify-center text-emerald-400 shadow-xl shadow-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <span className="px-3 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono font-black uppercase tracking-wider inline-block">
                DEVICE SIGNED & APPROVED IN SECONDS
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white font-serif">
                DO YOU HAVE A BACKUP PROFILE YOU MIGHT WANT TO LOAD AND CONTINUE USING YOUR PREVIOUS PROFILE?
              </h2>
            </div>

            {/* Exact Required Prompt Text */}
            <div className="p-4 rounded-2xl bg-slate-950 border-2 border-amber-500/50 text-left font-mono text-xs text-amber-200/90 leading-relaxed shadow-lg">
              <p>
                <strong>IF YES:</strong> THEN MAKE SURE YOU HAVE THE <strong>SD CARD OR FLASHDRIVE OR THE EXTERNAL HARD DRIVE OR HARDDISK</strong> WHERE YOU HAVE BACKUP OF YOUR PREVIOUS PROFILE INSERTED INTO YOUR DEVICE AND CLICK ON THE <strong>'RESTORE BACKUP PROFILE'</strong> ICON BUTTON BELOW TO RESTORE PREVIOUS PROFILE.
              </p>
            </div>

            {restoreNotice && (
              <div className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-xs font-mono text-emerald-200 text-left flex items-center gap-2 shadow-md">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{restoreNotice}</span>
              </div>
            )}

            {errorMsg && (
              <div className="p-3.5 rounded-2xl bg-rose-950/80 border border-rose-500/50 text-xs font-mono text-rose-200 text-left flex items-start gap-2 shadow-md">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-3 pt-2">
              <button
                type="button"
                onClick={handleRestoreFromPrompt}
                disabled={isScanningMedia}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-mono text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/25 hover:scale-[1.02] transition-all cursor-pointer"
              >
                <Upload className={`w-4 h-4 ${isScanningMedia ? 'animate-bounce' : ''}`} />
                <span>{isScanningMedia ? 'Scanning Inserted Drive...' : 'RESTORE BACKUP PROFILE'}</span>
              </button>

              <button
                type="button"
                onClick={handleSkipRestoreAndContinue}
                className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-bold transition-all cursor-pointer"
              >
                No Backup / Startup a New Profile Afresh →
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
