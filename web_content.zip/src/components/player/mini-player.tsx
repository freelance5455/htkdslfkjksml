import { Play, X } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useLibrary } from "@/lib/library-store";
import { usePlayer } from "@/lib/player-store";
import { useSettings } from "@/lib/settings-store";

export function MiniPlayer() {
  const currentId = usePlayer((s) => s.currentId);
  const close = usePlayer((s) => s.close);
  const background = useSettings((s) => s.backgroundPlayback);
  const item = useLibrary((s) => s.items.find((i) => i.id === currentId));
  if (!currentId || !item || !background) return null;
  const pct = item.duration > 0 ? (item.position / item.duration) * 100 : 0;

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-14 z-40 px-3 md:bottom-4">
      <div className="pointer-events-auto mx-auto flex max-w-xl items-center gap-3 rounded-xl bg-elevated p-2 shadow-[var(--shadow-float)]">
        <Link
          to="/player/$id"
          params={{ id: item.id }}
          className="flex min-w-0 flex-1 items-center gap-3 px-2"
          aria-label={`Continue ${item.name}`}
        >
          <span className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-fg">
            <Play className="size-4 fill-current" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-medium">{item.name}</span>
            <Progress value={pct} className="mt-1" />
          </span>
        </Link>
        <Button size="icon-sm" variant="ghost" aria-label="Dismiss" onClick={() => close()}>
          <X />
        </Button>
      </div>
    </div>
  );
}
