import React from 'react';
import { useMusic } from '../../context/MusicContext';
import { CoverArt } from '../common/CoverArt';
import { Play, Pause, SkipForward, Heart } from 'lucide-react';
import { EqualizerAnimation } from '../common/EqualizerAnimation';

export const MiniPlayer: React.FC = () => {
  const {
    currentSong,
    isPlaying,
    currentTime,
    duration,
    togglePlayPause,
    playNext,
    setIsNowPlayingOpen,
    likedSongIds,
    toggleLikeSong
  } = useMusic();

  if (!currentSong) return null;

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;
  const isLiked = likedSongIds.includes(currentSong.id);

  return (
    <div className="w-full px-2.5 pb-1">
      <div
        onClick={() => setIsNowPlayingOpen(true)}
        role="button"
        tabIndex={0}
        aria-label={`Open now playing: ${currentSong.title}`}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            setIsNowPlayingOpen(true);
          }
        }}
        className="relative overflow-hidden w-full max-w-2xl mx-auto rounded-2xl bg-[#161824]/95 hover:bg-[#1a1d2c] border border-white/[0.1] shadow-xl backdrop-blur-xl cursor-pointer transition-all duration-200 group"
      >
        {/* Progress bar on top edge */}
        <div className="absolute top-0 left-0 right-0 h-[2.5px] bg-white/10 z-20 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 transition-all duration-200"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Content row */}
        <div className="flex items-center justify-between p-2 sm:px-3">
          {/* Left: Artwork + Title + Artist */}
          <div className="flex items-center gap-3 min-w-0 pr-2">
            <div className="relative shrink-0">
              <CoverArt
                artKey={currentSong.albumArt}
                title={currentSong.title}
                artist={currentSong.artist}
                colorTheme={currentSong.colorTheme}
                size="sm"
                className="w-11 h-11 rounded-xl shadow-md"
              />
              {isPlaying && (
                <div className="absolute inset-0 bg-black/40 rounded-xl flex items-center justify-center pointer-events-none">
                  <EqualizerAnimation isPlaying={isPlaying} barsCount={3} height={12} color="bg-white" />
                </div>
              )}
            </div>

            <div className="truncate">
              <div className="flex items-center gap-1.5">
                <p className="font-semibold text-xs sm:text-sm text-slate-100 truncate group-hover:text-purple-300 transition-colors">
                  {currentSong.title}
                </p>
              </div>
              <p className="text-[11px] text-slate-400 truncate">
                {currentSong.artist}
              </p>
            </div>
          </div>

          {/* Right: Controls */}
          <div
            className="flex items-center gap-1 sm:gap-2 shrink-0"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Like button */}
            <button
              onClick={() => toggleLikeSong(currentSong.id)}
              className="p-2 min-w-[36px] min-h-[36px] flex items-center justify-center text-slate-400 hover:text-pink-500 transition-colors"
              aria-label={isLiked ? 'Unlike song' : 'Like song'}
            >
              <Heart
                className={`w-4 h-4 ${isLiked ? 'fill-pink-500 text-pink-500' : ''}`}
              />
            </button>

            {/* Play/Pause */}
            <button
              onClick={togglePlayPause}
              className="w-9 h-9 rounded-full bg-white text-black hover:bg-slate-200 active:scale-95 flex items-center justify-center shadow-md transition-all"
              aria-label={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? (
                <Pause className="w-4 h-4 fill-black" />
              ) : (
                <Play className="w-4 h-4 fill-black ml-0.5" />
              )}
            </button>

            {/* Next Track */}
            <button
              onClick={playNext}
              className="p-2 min-w-[36px] min-h-[36px] flex items-center justify-center text-slate-400 hover:text-white transition-colors"
              aria-label="Next song"
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
