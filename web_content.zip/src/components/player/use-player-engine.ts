import { useCallback, useEffect, useRef, useState } from "react";
import { applyEq } from "@/lib/equalizer";
import { getFile, getObjectUrl } from "@/lib/file-registry";
import { useLibrary } from "@/lib/library-store";
import type { AspectMode, MediaItem } from "@/lib/media-types";
import { usePlayer } from "@/lib/player-store";
import { useSettings } from "@/lib/settings-store";
import { clamp } from "@/lib/utils";

export function mediaSrc(item: MediaItem): string | undefined {
  if (item.source === "url" || item.source === "download") return item.url;
  return getObjectUrl(item.id) ?? (getFile(item.id) ? getObjectUrl(item.id) : item.url);
}

export function usePlayerEngine(item: MediaItem | undefined, mediaRef: React.RefObject<HTMLMediaElement | null>) {
  const rememberPlay = useLibrary((s) => s.rememberPlay);
  const setError = usePlayer((s) => s.setError);
  const setPlaying = usePlayer((s) => s.setPlaying);
  const settings = useSettings();
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(item?.duration ?? 0);
  const [buffered, setBuffered] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [speed, setSpeed] = useState(settings.defaultSpeed);
  const [brightness, setBrightness] = useState(1);
  const [aspect, setAspect] = useState<AspectMode>(settings.aspect);
  const [waiting, setWaiting] = useState(false);
  const saveTimer = useRef<number | null>(null);

  const src = item ? mediaSrc(item) : undefined;

  useEffect(() => {
    const el = mediaRef.current;
    if (!el || !item) return;
    el.playbackRate = speed;
    el.volume = volume;
    el.muted = muted;
  }, [mediaRef, item, speed, volume, muted]);

  useEffect(() => {
    const el = mediaRef.current;
    if (!el || !item) return;
    if (!settings.eqEnabled) return;
    void applyEq(el, settings.eqBands, settings.bassBoost, settings.normalize, settings.stereo);
  }, [
    mediaRef,
    item,
    settings.eqEnabled,
    settings.eqBands,
    settings.bassBoost,
    settings.normalize,
    settings.stereo,
  ]);

  useEffect(() => {
    const el = mediaRef.current;
    if (!el || !item || !src) return;
    const onMeta = () => {
      setDuration(el.duration || 0);
      if (settings.resumePlayback && item.position > 3 && item.position < (el.duration || Infinity) - 2) {
        try {
          el.currentTime = item.position;
        } catch {
          /* ignore */
        }
      }
    };
    const onTime = () => {
      setCurrentTime(el.currentTime);
      if (el.buffered.length) {
        setBuffered(el.buffered.end(el.buffered.length - 1));
      }
      if (saveTimer.current) window.clearTimeout(saveTimer.current);
      saveTimer.current = window.setTimeout(() => {
        rememberPlay(item.id, el.currentTime, el.duration);
      }, 800);
    };
    const onWait = () => setWaiting(true);
    const onPlay = () => {
      setWaiting(false);
      setPlaying(true);
    };
    const onPause = () => setPlaying(false);
    const onErr = () => {
      const err = el.error;
      const map: Record<number, string> = {
        1: "Playback aborted.",
        2: "Network error while loading media.",
        3: "This file is corrupt or uses an unsupported codec.",
        4: "This media type is not supported in this browser.",
      };
      setError(map[err?.code ?? 0] ?? "Playback failed.");
    };
    const onEnd = () => {
      rememberPlay(item.id, el.duration || item.position, el.duration);
      setPlaying(false);
    };
    el.addEventListener("loadedmetadata", onMeta);
    el.addEventListener("timeupdate", onTime);
    el.addEventListener("waiting", onWait);
    el.addEventListener("playing", onPlay);
    el.addEventListener("play", onPlay);
    el.addEventListener("pause", onPause);
    el.addEventListener("error", onErr);
    el.addEventListener("ended", onEnd);
    const play = el.play();
    if (play) play.catch(() => setPlaying(false));
    return () => {
      el.removeEventListener("loadedmetadata", onMeta);
      el.removeEventListener("timeupdate", onTime);
      el.removeEventListener("waiting", onWait);
      el.removeEventListener("playing", onPlay);
      el.removeEventListener("play", onPlay);
      el.removeEventListener("pause", onPause);
      el.removeEventListener("error", onErr);
      el.removeEventListener("ended", onEnd);
      if (saveTimer.current) window.clearTimeout(saveTimer.current);
      rememberPlay(item.id, el.currentTime, el.duration);
    };
  }, [item?.id, src, mediaRef, rememberPlay, setError, setPlaying, settings.resumePlayback]);

  useEffect(() => {
    if (!item || typeof navigator === "undefined" || !navigator.mediaSession) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: item.name,
      artist: "UPLAY.IND",
      album: item.folder,
    });
    const el = mediaRef.current;
    navigator.mediaSession.setActionHandler("play", () => void el?.play());
    navigator.mediaSession.setActionHandler("pause", () => el?.pause());
    navigator.mediaSession.setActionHandler("seekbackward", () => {
      if (el) el.currentTime = Math.max(0, el.currentTime - settings.doubleTapSeek);
    });
    navigator.mediaSession.setActionHandler("seekforward", () => {
      if (el) el.currentTime = Math.min(el.duration || 0, el.currentTime + settings.doubleTapSeek);
    });
    return () => {
      navigator.mediaSession.setActionHandler("play", null);
      navigator.mediaSession.setActionHandler("pause", null);
      navigator.mediaSession.setActionHandler("seekbackward", null);
      navigator.mediaSession.setActionHandler("seekforward", null);
    };
  }, [item, mediaRef, settings.doubleTapSeek]);

  const seek = useCallback(
    (time: number) => {
      const el = mediaRef.current;
      if (!el) return;
      el.currentTime = clamp(time, 0, el.duration || 0);
      setCurrentTime(el.currentTime);
    },
    [mediaRef],
  );

  const skip = useCallback(
    (delta: number) => {
      const el = mediaRef.current;
      if (!el) return;
      seek(el.currentTime + delta);
    },
    [mediaRef, seek],
  );

  const toggle = useCallback(() => {
    const el = mediaRef.current;
    if (!el) return;
    if (el.paused) void el.play();
    else el.pause();
  }, [mediaRef]);

  return {
    src,
    currentTime,
    duration,
    buffered,
    volume,
    setVolume,
    muted,
    setMuted,
    speed,
    setSpeed,
    brightness,
    setBrightness,
    aspect,
    setAspect,
    waiting,
    seek,
    skip,
    toggle,
  };
}
