import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  ChevronLeft,
  Gauge,
  ListMusic,
  Lock,
  LockOpen,
  Maximize,
  Minimize,
  Pause,
  PictureInPicture2,
  Play,
  Ratio,
  SkipBack,
  SkipForward,
  Subtitles,
  Volume2,
  VolumeX,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { decoderDescription, decoderHelp } from "@/lib/codecs";
import { SPEED_PRESETS } from "@/lib/constants";
import { useLibrary } from "@/lib/library-store";
import type { AspectMode, MediaItem } from "@/lib/media-types";
import { usePlayer } from "@/lib/player-store";
import { useSettings } from "@/lib/settings-store";
import { activeCue, readSubtitleFile, shiftCues } from "@/lib/subtitles";
import { cn, formatDuration } from "@/lib/utils";
import { usePlayerEngine } from "@/components/player/use-player-engine";
import { eqSpectrum } from "@/lib/equalizer";

const ASPECTS: { id: AspectMode; label: string }[] = [
  { id: "contain", label: "Fit" },
  { id: "cover", label: "Crop" },
  { id: "fill", label: "Stretch" },
];

export function PlayerScreen({ item }: { item: MediaItem }) {
  const navigate = useNavigate();
  const items = useLibrary((s) => s.items);
  const mediaRef = useRef<HTMLVideoElement | HTMLAudioElement | null>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const engine = usePlayerEngine(item, mediaRef);
  const locked = usePlayer((s) => s.locked);
  const setLocked = usePlayer((s) => s.setLocked);
  const error = usePlayer((s) => s.error);
  const setError = usePlayer((s) => s.setError);
  const playing = usePlayer((s) => s.playing);
  const cues = usePlayer((s) => s.cues);
  const subtitleName = usePlayer((s) => s.subtitleName);
  const setCues = usePlayer((s) => s.setCues);
  const nextId = usePlayer((s) => s.nextId);
  const prevId = usePlayer((s) => s.prevId);
  const open = usePlayer((s) => s.open);
  const settings = useSettings();
  const [show, setShow] = useState(true);
  const hideTimer = useRef<number | null>(null);
  const [fs, setFs] = useState(false);
  const [gestureHint, setGestureHint] = useState<string | null>(null);
  const [bars, setBars] = useState<number[]>(() => Array.from({ length: 16 }, () => 0.2));

  const cue = useMemo(
    () => activeCue(shiftCues(cues, settings.subtitleDelay), engine.currentTime),
    [cues, engine.currentTime, settings.subtitleDelay],
  );

  const bumpUi = useCallback(() => {
    if (locked) return;
    setShow(true);
    if (hideTimer.current) window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => {
      if (usePlayer.getState().playing) setShow(false);
    }, settings.autoHideControlsMs);
  }, [locked, settings.autoHideControlsMs]);

  useEffect(() => {
    bumpUi();
    return () => {
      if (hideTimer.current) window.clearTimeout(hideTimer.current);
    };
  }, [bumpUi, item.id]);

  useEffect(() => {
    const el = mediaRef.current;
    if (!el || item.kind !== "audio") return;
    let raf = 0;
    const tick = () => {
      setBars(eqSpectrum(el, 16));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [item.id, item.kind]);

  const go = (id: string | null) => {
    if (!id) return;
    const next = items.find((i) => i.id === id);
    if (!next) return;
    open(next, items.filter((i) => i.kind === next.kind));
    void navigate({ to: "/player/$id", params: { id: next.id } });
  };

  const toggleFs = async () => {
    const root = rootRef.current;
    if (!root) return;
    try {
      if (!document.fullscreenElement) {
        await root.requestFullscreen();
        setFs(true);
      } else {
        await document.exitFullscreen();
        setFs(false);
      }
    } catch {
      toast.error("Fullscreen is not available.");
    }
  };

  const togglePip = async () => {
    const el = mediaRef.current;
    if (!el || item.kind !== "video") return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if ("requestPictureInPicture" in el) {
        await (el as HTMLVideoElement).requestPictureInPicture();
      }
    } catch {
      toast.error("Picture-in-picture is not available on this device.");
    }
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (locked && e.key !== "Escape") return;
      bumpUi();
      switch (e.key) {
        case " ":
        case "k":
          e.preventDefault();
          engine.toggle();
          break;
        case "ArrowLeft":
          engine.skip(e.shiftKey ? -settings.doubleTapSeek : -5);
          break;
        case "ArrowRight":
          engine.skip(e.shiftKey ? settings.doubleTapSeek : 5);
          break;
        case "ArrowUp":
          e.preventDefault();
          engine.setVolume(Math.min(1, engine.volume + 0.05));
          break;
        case "ArrowDown":
          e.preventDefault();
          engine.setVolume(Math.max(0, engine.volume - 0.05));
          break;
        case "f":
          void toggleFs();
          break;
        case "m":
          engine.setMuted(!engine.muted);
          break;
        case "n":
          go(nextId());
          break;
        case "p":
          go(prevId());
          break;
        case "Escape":
          if (document.fullscreenElement) void document.exitFullscreen();
          else void navigate({ to: "/" });
          break;
        default:
          break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const src = engine.src;
  const missing = item.source === "local" && !src;

  return (
    <div
      ref={rootRef}
      className="player-root relative flex h-dvh flex-col overflow-hidden bg-black text-white"
      style={
        {
          "--player-brightness": String(engine.brightness),
          "--subtitle-size": `${settings.subtitleSize}rem`,
          "--subtitle-color": settings.subtitleColor,
          "--subtitle-offset": `${settings.subtitlePosition}%`,
        } as React.CSSProperties
      }
    >
      <input
        ref={fileInput}
        type="file"
        accept=".srt,.vtt,text/vtt,application/x-subrip"
        className="sr-only"
        onChange={async (e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (!file) return;
          const parsed = await readSubtitleFile(file);
          if (!parsed.length) {
            toast.error("Could not read that subtitle file.");
            return;
          }
          setCues(parsed, file.name);
          toast.success(`Loaded ${file.name}`);
        }}
      />
      {item.kind === "video" ? (
        <video
          ref={(n) => {
            mediaRef.current = n;
          }}
          src={src}
          className={cn(
            "player-video absolute inset-0 size-full bg-black",
            engine.aspect === "contain" && "object-contain",
            engine.aspect === "cover" && "object-cover",
            engine.aspect === "fill" && "object-fill",
          )}
          playsInline
          controls={false}
          onError={() => {
            const el = mediaRef.current;
            const err = el?.error;
            const map: Record<number, string> = {
              1: "Playback aborted.",
              2: "Network error while loading media.",
              3: "This file is corrupt or uses an unsupported codec.",
              4: "This media type is not supported, or the URL is not a playable file.",
            };
            setError(map[err?.code ?? 0] ?? "Playback failed.");
          }}
          onClick={(e) => e.preventDefault()}
        />
      ) : (
        <>
          <audio
            ref={(n) => {
              mediaRef.current = n;
            }}
            src={src}
            className="hidden"
          />
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-8 bg-[radial-gradient(circle_at_50%_30%,rgb(30_224_194_/_0.12),transparent_55%)]">
            <p className="font-display text-3xl font-semibold">{item.name}</p>
            <div className="flex h-24 items-end gap-1">
              {bars.map((v, i) => (
                <span
                  key={i}
                  className="w-2 origin-bottom rounded-full bg-primary"
                  style={{ height: `${Math.max(8, v * 96)}px` }}
                />
              ))}
            </div>
          </div>
        </>
      )}

      <GestureLayer
        enabled={settings.gestures && !locked}
        brightnessEnabled={settings.brightnessGesture}
        seekSeconds={settings.doubleTapSeek}
        duration={engine.duration}
        currentTime={engine.currentTime}
        volume={engine.volume}
        brightness={engine.brightness}
        onToggle={() => {
          if (show) engine.toggle();
          else bumpUi();
        }}
        onSeek={(t) => engine.seek(t)}
        onSkip={(d) => engine.skip(d)}
        onVolume={(v) => engine.setVolume(v)}
        onBrightness={(b) => engine.setBrightness(b)}
        onHint={setGestureHint}
        onPointer={() => bumpUi()}
      />

      {settings.subtitleEnabled && cue ? (
        <div className="subtitle-cue pointer-events-none absolute inset-x-8 z-20 mx-auto max-w-3xl rounded-md px-3 py-1.5 text-center font-medium leading-snug">
          {cue.text}
        </div>
      ) : null}

      {gestureHint ? (
        <div className="pointer-events-none absolute left-1/2 top-1/3 z-30 -translate-x-1/2 rounded-lg bg-black/70 px-4 py-2 text-sm tabular-nums">
          {gestureHint}
        </div>
      ) : null}

      {engine.waiting ? (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
          <div className="size-10 animate-spin rounded-full border-2 border-white/20 border-t-primary" />
        </div>
      ) : null}

      {missing ? (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-black/80 p-6 text-center">
          <p className="font-display text-xl">File is not linked</p>
          <p className="max-w-sm text-sm text-white/70">
            Local files are not stored in the cloud. Choose the original file to continue.
          </p>
        </div>
      ) : null}

      {error ? (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-black/80 p-6 text-center">
          <p className="font-display text-xl">Can’t play this</p>
          <p className="max-w-sm text-sm text-white/70">{error}</p>
          <p className="max-w-sm text-xs text-white/50">{decoderHelp()}</p>
          <Button onClick={() => void navigate({ to: "/" })}>Back home</Button>
        </div>
      ) : null}

      <div
        className={cn(
          "absolute inset-0 z-40 flex flex-col justify-between bg-gradient-to-b from-black/70 via-transparent to-black/80 p-3 transition-opacity duration-200 sm:p-5",
          show && !locked ? "pointer-events-none opacity-100" : "pointer-events-none opacity-0",
        )}
      >
        <div className="pointer-events-auto flex items-start gap-2">
          <Button
            size="icon"
            variant="ghost"
            className="text-white hover:bg-white/10"
            onClick={() => void navigate({ to: "/" })}
            aria-label="Back"
          >
            <ChevronLeft />
          </Button>
          <div className="min-w-0 flex-1 pt-2">
            <h1 className="truncate font-display text-base font-semibold">{item.name}</h1>
            <p className="truncate text-xs text-white/60">
              {decoderDescription()} · {item.mime || item.ext.toUpperCase()}
              {item.width && item.height ? ` · ${item.width}×${item.height}` : ""}
            </p>
          </div>
          <Button
            size="icon"
            variant="ghost"
            className="text-white hover:bg-white/10"
            onClick={() => setLocked(true)}
            aria-label="Lock controls"
          >
            <LockOpen />
          </Button>
        </div>

        <div className="pointer-events-auto space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-12 text-xs tabular-nums text-white/70">{formatDuration(engine.currentTime)}</span>
            <Slider
              min={0}
              max={Math.max(engine.duration, 0.1)}
              step={0.1}
              value={[engine.currentTime]}
              onValueChange={([v]) => engine.seek(v ?? 0)}
              aria-label="Seek"
            />
            <span className="w-12 text-right text-xs tabular-nums text-white/70">
              {formatDuration(engine.duration)}
            </span>
          </div>
          <div className="flex items-center justify-between gap-1">
            <div className="flex items-center">
              <Button
                size="icon"
                variant="ghost"
                className="text-white hover:bg-white/10"
                onClick={() => engine.setMuted(!engine.muted)}
                aria-label={engine.muted ? "Unmute" : "Mute"}
              >
                {engine.muted || engine.volume === 0 ? <VolumeX /> : <Volume2 />}
              </Button>
              <div className="hidden w-24 sm:block">
                <Slider
                  min={0}
                  max={1}
                  step={0.01}
                  value={[engine.muted ? 0 : engine.volume]}
                  onValueChange={([v]) => {
                    engine.setMuted(false);
                    engine.setVolume(v ?? 0);
                  }}
                  aria-label="Volume"
                />
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Button
                size="icon"
                variant="ghost"
                className="text-white hover:bg-white/10"
                onClick={() => engine.skip(-settings.doubleTapSeek)}
                aria-label="Rewind"
              >
                <SkipBack />
              </Button>
              <Button
                size="icon"
                className="size-12 rounded-full"
                onClick={engine.toggle}
                aria-label={playing ? "Pause" : "Play"}
              >
                {playing ? <Pause className="fill-current" /> : <Play className="fill-current" />}
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="text-white hover:bg-white/10"
                onClick={() => engine.skip(settings.doubleTapSeek)}
                aria-label="Forward"
              >
                <SkipForward />
              </Button>
            </div>
            <div className="flex items-center">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="icon" variant="ghost" className="text-white hover:bg-white/10" aria-label="Speed">
                    <Gauge />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuLabel>Playback speed</DropdownMenuLabel>
                  {SPEED_PRESETS.map((s) => (
                    <DropdownMenuItem key={s} onSelect={() => engine.setSpeed(s)}>
                      {s === engine.speed ? "• " : ""}
                      {s}×
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="icon" variant="ghost" className="text-white hover:bg-white/10" aria-label="Aspect">
                    <Ratio />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {ASPECTS.map((a) => (
                    <DropdownMenuItem key={a.id} onSelect={() => engine.setAspect(a.id)}>
                      {a.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="icon" variant="ghost" className="text-white hover:bg-white/10" aria-label="Tracks">
                    <Subtitles />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuLabel>Subtitles</DropdownMenuLabel>
                  <DropdownMenuItem onSelect={() => useSettings.getState().set("subtitleEnabled", !settings.subtitleEnabled)}>
                    {settings.subtitleEnabled ? "Disable" : "Enable"}
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => fileInput.current?.click()}>Load SRT / VTT</DropdownMenuItem>
                  {subtitleName ? <DropdownMenuItem disabled>{subtitleName}</DropdownMenuItem> : null}
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel>Audio</DropdownMenuLabel>
                  <AudioTracks mediaRef={mediaRef} />
                </DropdownMenuContent>
              </DropdownMenu>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="icon" variant="ghost" className="text-white hover:bg-white/10" aria-label="Queue">
                    <ListMusic />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onSelect={() => go(prevId())}>Previous</DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => go(nextId())}>Next</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              {item.kind === "video" && settings.pipEnabled ? (
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-white hover:bg-white/10"
                  onClick={() => void togglePip()}
                  aria-label="Picture in picture"
                >
                  <PictureInPicture2 />
                </Button>
              ) : null}
              <Button
                size="icon"
                variant="ghost"
                className="text-white hover:bg-white/10"
                onClick={() => void toggleFs()}
                aria-label="Fullscreen"
              >
                {fs ? <Minimize /> : <Maximize />}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {locked ? (
        <button
          type="button"
          className="absolute right-4 top-4 z-50 rounded-full bg-black/60 p-3 text-white"
          onClick={() => setLocked(false)}
          aria-label="Unlock controls"
        >
          <Lock className="size-5" />
        </button>
      ) : null}
    </div>
  );
}

function AudioTracks({ mediaRef }: { mediaRef: React.RefObject<HTMLMediaElement | null> }) {
  const el = mediaRef.current as HTMLMediaElement & {
    audioTracks?: ArrayLike<{ enabled: boolean; label: string; language: string }>;
  } | null;
  const tracks = el?.audioTracks ? Array.from(el.audioTracks) : [];
  const setLabel = usePlayer((s) => s.setAudioTrackLabel);
  if (!tracks.length) {
    return <DropdownMenuItem disabled>Default (this browser exposes one mix)</DropdownMenuItem>;
  }
  return (
    <>
      {tracks.map((t, i) => (
        <DropdownMenuItem
          key={i}
          onSelect={() => {
            for (let j = 0; j < tracks.length; j++) {
              const track = tracks[j] as { enabled: boolean };
              track.enabled = j === i;
            }
            setLabel(t.label || t.language || `Track ${i + 1}`);
          }}
        >
          {t.label || t.language || `Track ${i + 1}`}
        </DropdownMenuItem>
      ))}
    </>
  );
}

function GestureLayer({
  enabled,
  brightnessEnabled,
  seekSeconds,
  duration,
  currentTime,
  volume,
  brightness,
  onToggle,
  onSeek,
  onSkip,
  onVolume,
  onBrightness,
  onHint,
  onPointer,
}: {
  enabled: boolean;
  brightnessEnabled: boolean;
  seekSeconds: number;
  duration: number;
  currentTime: number;
  volume: number;
  brightness: number;
  onToggle: () => void;
  onSeek: (t: number) => void;
  onSkip: (d: number) => void;
  onVolume: (v: number) => void;
  onBrightness: (b: number) => void;
  onHint: (s: string | null) => void;
  onPointer: () => void;
}) {
  const start = useRef<{ x: number; y: number; t: number; vol: number; bri: number; time: number; zone: "l" | "r" | "c"; mode: "none" | "seek" | "vol" | "bri" } | null>(null);
  const lastTap = useRef(0);
  const pendingToggle = useRef<number | null>(null);

  const down = (e: React.PointerEvent) => {
    if (!enabled) {
      onPointer();
      return;
    }
    onPointer();
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - rect.left;
    const zone = x < rect.width * 0.33 ? "l" : x > rect.width * 0.66 ? "r" : "c";
    start.current = {
      x: e.clientX,
      y: e.clientY,
      t: Date.now(),
      vol: volume,
      bri: brightness,
      time: currentTime,
      zone,
      mode: "none",
    };
  };
  const move = (e: React.PointerEvent) => {
    const s = start.current;
    if (!s) return;
    const dx = e.clientX - s.x;
    const dy = e.clientY - s.y;
    if (s.mode === "none") {
      if (Math.abs(dx) > 18 && Math.abs(dx) > Math.abs(dy)) s.mode = "seek";
      else if (Math.abs(dy) > 18) s.mode = s.zone === "l" && brightnessEnabled ? "bri" : "vol";
    }
    if (s.mode === "seek") {
      const delta = (dx / 280) * Math.min(120, duration || 120);
      const next = Math.max(0, Math.min(duration, s.time + delta));
      onSeek(next);
      onHint(formatDuration(next));
    } else if (s.mode === "vol") {
      const next = Math.max(0, Math.min(1, s.vol - dy / 220));
      onVolume(next);
      onHint(`Volume ${Math.round(next * 100)}%`);
    } else if (s.mode === "bri") {
      const next = Math.max(0.3, Math.min(1.6, s.bri - dy / 260));
      onBrightness(next);
      onHint(`Brightness ${Math.round(next * 100)}%`);
    }
  };
  const up = (e: React.PointerEvent) => {
    const s = start.current;
    start.current = null;
    onHint(null);
    if (!s) return;
    const dist = Math.hypot(e.clientX - s.x, e.clientY - s.y);
    if (s.mode !== "none") return;
    if (dist > 12) return;
    const now = Date.now();
    if (now - lastTap.current < 280) {
      if (pendingToggle.current) {
        window.clearTimeout(pendingToggle.current);
        pendingToggle.current = null;
      }
      lastTap.current = 0;
      if (s.zone === "l") onSkip(-seekSeconds);
      else if (s.zone === "r") onSkip(seekSeconds);
      else onToggle();
      return;
    }
    lastTap.current = now;
    pendingToggle.current = window.setTimeout(() => {
      pendingToggle.current = null;
      onToggle();
    }, 280);
  };

  return (
    <div
      className="absolute inset-0 z-10"
      onPointerDown={down}
      onPointerMove={move}
      onPointerUp={up}
      onPointerCancel={() => {
        start.current = null;
        onHint(null);
      }}
    />
  );
}

