import React from 'react';
import { useMusic } from '../../context/MusicContext';
import { CoverArt } from '../common/CoverArt';
import { EqualizerAnimation } from '../common/EqualizerAnimation';
import { Play, Trash2, ArrowUp, ArrowDown, Sparkles } from 'lucide-react';

interface QueueSheetProps {
  onClose: () => void;
}

export const QueueSheet: React.FC<QueueSheetProps> = () => {
  const {
    queue,
    queueIndex,
    currentSong,
    isPlaying,
    playSong,
    removeFromQueue,
    reorderQueue
  } = useMusic();

  return (
    <div className="flex flex-col h-full bg-[#12141f] text-slate-100 rounded-t-3xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.08]">
        <div>
          <h3 className="font-display font-bold text-base text-white">Playing Queue</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            {queue.length} track{queue.length === 1 ? '' : 's'} in line
          </p>
        </div>
      </div>

      {/* Queue items list */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2 no-scrollbar">
        {queue.map((song, idx) => {
          const isCurrent = idx === queueIndex;

          return (
            <div
              key={`${song.id}-${idx}`}
              className={`flex items-center justify-between p-2.5 rounded-2xl transition-all ${
                isCurrent
                  ? 'bg-purple-900/30 border border-purple-500/30 shadow-md'
                  : 'bg-white/[0.02] hover:bg-white/[0.05] border border-transparent'
              }`}
            >
              {/* Left: Index / Equalizer + Art + Details */}
              <div
                className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                onClick={() => playSong(song)}
              >
                <div className="w-5 text-center shrink-0">
                  {isCurrent ? (
                    <EqualizerAnimation isPlaying={isPlaying} barsCount={3} height={14} color="bg-purple-400" />
                  ) : (
                    <span className="text-xs text-slate-500 font-mono">{idx + 1}</span>
                  )}
                </div>

                <CoverArt
                  artKey={song.albumArt}
                  title={song.title}
                  artist={song.artist}
                  colorTheme={song.colorTheme}
                  size="sm"
                  className="w-10 h-10 rounded-xl"
                />

                <div className="min-w-0 flex-1">
                  <p
                    className={`font-semibold text-xs sm:text-sm truncate ${
                      isCurrent ? 'text-purple-300' : 'text-slate-200'
                    }`}
                  >
                    {song.title}
                  </p>
                  <p className="text-[11px] text-slate-400 truncate">{song.artist}</p>
                </div>
              </div>

              {/* Right: Actions */}
              <div className="flex items-center gap-1 shrink-0 ml-2">
                {/* Move Up */}
                {idx > 0 && (
                  <button
                    onClick={() => reorderQueue(idx, idx - 1)}
                    title="Move up"
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                )}

                {/* Move Down */}
                {idx < queue.length - 1 && (
                  <button
                    onClick={() => reorderQueue(idx, idx + 1)}
                    title="Move down"
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                )}

                {/* Remove */}
                {queue.length > 1 && (
                  <button
                    onClick={() => removeFromQueue(idx)}
                    title="Remove from queue"
                    className="p-1.5 text-slate-400 hover:text-red-400 rounded-lg hover:bg-white/10"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
