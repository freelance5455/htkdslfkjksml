/**
 * مشغّل يوتيوب مخصّص فوق YouTube IFrame Player API.
 * كل أزرار يوتيوب مخفيّة (controls=0) وتُغطّى بطبقة شفافة تمنع النقر على العنوان
 * أو الفيديوهات المقترحة، ونرسم أدواتنا الخاصّة فوقها.
 *
 * الاستخدام الأساسي:
 * <VideoPlayer videoId={id} startAt={120} chapters={chapters} onProgress={fn} onEnded={fn} />
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Gauge,
  Loader2,
  Maximize,
  Minimize,
  MonitorPlay,
  Pause,
  PictureInPicture2,
  Play,
  Repeat2,
  RotateCcw,
  RotateCw,
  Settings2,
  StickyNote,
  Volume1,
  Volume2,
  VolumeX,
  WifiOff,
  Focus,
} from 'lucide-react';
import type { Chapter, Lesson, Settings } from '../../types';
import { extractVideoId } from '../../utils/extractVideoId';
import { cn, formatDuration } from '../../utils/format';
import { useYouTubePlayer, type PlayerStatus } from '../../hooks/useYouTubePlayer';
import { useVideoProgress } from '../../hooks/useVideoProgress';
import { useActiveStudy } from '../../hooks/useActiveStudy';
import { PlayerMenu, type MenuSection } from './PlayerMenu';

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

const ERROR_MESSAGES: Record<number, { title: string; body: string }> = {
  2: {
    title: 'رابط الفيديو غير صالح',
    body: 'تأكد من معرّف الفيديو في ملف المحتوى. المعرّف الصحيح يتكوّن من ١١ حرفاً.',
  },
  5: {
    title: 'تعذّر تشغيل المشغّل',
    body: 'حدث خطأ في مشغّل HTML5 أو انقطع الاتصال. أعد المحاولة من هنا بعد التأكد من الشبكة.',
  },
  100: {
    title: 'الفيديو غير موجود',
    body: 'قد يكون الفيديو محذوفاً أو خاصاً. راجع رابطه في ملف المحتوى.',
  },
  101: {
    title: 'مالك الفيديو منع التضمين',
    body: 'لا يسمح صاحب الفيديو بتشغيله داخل المواقع الأخرى، ولا يمكن للتطبيق تجاوز هذا الإعداد. جرّب درساً آخر من داخل منارة.',
  },
  150: {
    title: 'مالك الفيديو منع التضمين',
    body: 'لا يسمح صاحب الفيديو بتشغيله داخل المواقع الأخرى، ولا يمكن للتطبيق تجاوز هذا الإعداد. جرّب درساً آخر من داخل منارة.',
  },
};

export interface VideoPlayerProps {
  /** معرّف يوتيوب أو رابط بأي صيغة */
  videoId: string;
  /** الثانية التي يبدأ منها التشغيل (للاستئناف) */
  startAt?: number;
  chapters?: Chapter[];
  onProgress?: (position: number, duration: number) => void;
  onEnded?: () => void;
  lesson?: Lesson;
  title?: string;
  settings?: Settings;
  onSettingsChange?: (patch: Partial<Settings>) => void;
  nextLabel?: string;
  onNext?: () => void;
  onPrevious?: () => void;
  previousLabel?: string;
  onAddNote?: (time: number) => void;
  onBookmark?: (time: number) => void;
  theater?: boolean;
  onToggleTheater?: () => void;
  focusMode?: boolean;
  onToggleFocus?: () => void;
  autoPlayNext?: boolean;
  /** طلب قفز خارجي (من قائمة الفصول أو الملاحظات): يتغيّر المفتاح فيُنفَّذ القفز */
  seekTo?: { time: number; key: number; play?: boolean } | null;
  className?: string;
}

export function VideoPlayer({
  videoId,
  startAt = 0,
  chapters = [],
  onProgress,
  onEnded,
  lesson,
  title,
  settings,
  onSettingsChange,
  nextLabel,
  onNext,
  onPrevious,
  previousLabel,
  onAddNote,
  onBookmark,
  theater,
  onToggleTheater,
  focusMode,
  onToggleFocus,
  autoPlayNext = true,
  seekTo,
  className,
}: VideoPlayerProps) {
  const resolvedId = useMemo(() => extractVideoId(videoId), [videoId]);
  const containerRef = useRef<HTMLDivElement>(null);
  const hostRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const hideTimer = useRef<number | null>(null);
  const lastTap = useRef<{ time: number; x: number }>({ time: 0, x: 0 });
  const dragRef = useRef<{ startY: number; startVolume: number; moved: boolean } | null>(null);
  const playerRefStatus = useRef<PlayerStatus>('loading');
  const loopGuard = useRef(0);
  const appliedSeekKey = useRef<number | null>(null);

  const [reloadToken, setReloadToken] = useState(0);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [menu, setMenu] = useState<MenuSection>(null);
  const [scrub, setScrub] = useState<number | null>(null);
  const [hover, setHover] = useState<{ x: number; time: number } | null>(null);
  const [loop, setLoop] = useState<{ a: number | null; b: number | null }>({ a: null, b: null });
  const [resumeDismissed, setResumeDismissed] = useState(false);
  const [centerToast, setCenterToast] = useState<{ id: number; text: string } | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [mini, setMini] = useState(false);
  const [online, setOnline] = useState(() => navigator.onLine);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [hint, setHint] = useState<string | null>(null);
  const [started, setStarted] = useState(false);

  const initialVolume = settings?.lastVolume ?? 80;

  const player = useYouTubePlayer({
    videoId: resolvedId,
    startAt,
    hostRef,
    reloadToken,
    dataSaver: settings?.dataSaver,
    initialVolume,
    onProgress: (position, duration) => {
      onProgress?.(position, duration);
      if (loop.a !== null && loop.b !== null && position >= loop.b) {
        // حارس زمني يمنع تكرار القفز في كل إطار
        const now = Date.now();
        if (now - loopGuard.current > 1200) {
          loopGuard.current = now;
          player.seek(loop.a);
          setCenterToast({ id: Date.now(), text: 'تكرار المقطع' });
        }
      }
    },
    onEnded: () => {
      onEnded?.();
    },
  });

  const { state } = player;
  playerRefStatus.current = state.status;
  useActiveStudy(state.status === 'playing', lesson?.subjectId, 'video');
  useEffect(() => {
    if (state.status === 'playing' || state.status === 'buffering') setStarted(true);
  }, [state.status]);
  const duration = state.duration || 0;
  const position = scrub ?? state.currentTime;

  useVideoProgress({
    lesson,
    currentTime: state.currentTime,
    duration,
    status: state.status,
  });

  const startPlayback = useCallback(() => {
    setStarted(true);
    player.play();
  }, [player]);

  /* --------------------------- قفز خارجي --------------------------- */
  useEffect(() => {
    if (!seekTo) return;
    if (!['ready', 'paused', 'playing'].includes(state.status)) return;
    if (appliedSeekKey.current === seekTo.key) return;
    appliedSeekKey.current = seekTo.key;
    player.seek(seekTo.time);
    if (seekTo.play !== false) player.play();
    // تُنفّذ القفزة بعد onReady مرة واحدة؛ فتح ملاحظة لا يبدأ صوتاً دون طلب الطالب.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seekTo?.key, state.status]);

  /* ------------------------- إظهار/إخفاء الأزرار ------------------------- */
  const reveal = useCallback(() => {
    setControlsVisible(true);
    if (hideTimer.current) window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => {
      // لا نُخفي الأزرار إذا كان الفيديو متوقفاً: الطالب يحتاج زر التشغيل
      if (playerRefStatus.current === 'playing') {
        setControlsVisible(false);
        setMenu(null);
      }
    }, 3000);
  }, []);

  useEffect(() => {
    reveal();
    return () => {
      if (hideTimer.current) window.clearTimeout(hideTimer.current);
    };
  }, [reveal]);

  useEffect(() => {
    if (state.status !== 'playing') setControlsVisible(true);
  }, [state.status]);

  /* ---------------------------- عدّاد التالي ---------------------------- */
  useEffect(() => {
    if (state.status === 'ended' && nextLabel && onNext && autoPlayNext) {
      setCountdown(5);
    } else {
      setCountdown(null);
    }
  }, [state.status, nextLabel, onNext, autoPlayNext]);

  useEffect(() => {
    if (countdown === null) return undefined;
    if (countdown <= 0) {
      onNext?.();
      return undefined;
    }
    const id = window.setTimeout(() => setCountdown((c) => (c === null ? null : c - 1)), 1000);
    return () => window.clearTimeout(id);
  }, [countdown, onNext]);

  /* ------------------------------ الإنترنت ------------------------------ */
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);

  /* ---------------------------- ملء الشاشة ---------------------------- */
  useEffect(() => {
    const handler = () => {
      const active = document.fullscreenElement === containerRef.current;
      setIsFullscreen(active);
      const orientation = screen.orientation as ScreenOrientation & {
        lock?: (o: string) => Promise<void>;
        unlock?: () => void;
      };
      if (active) orientation.lock?.('landscape').catch(() => undefined);
      else orientation.unlock?.();
    };
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  const toggleFullscreen = useCallback(async () => {
    const el = containerRef.current;
    if (!el) return;
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await el.requestFullscreen({ navigationUI: 'hide' });
    } catch {
      setCenterToast({ id: Date.now(), text: 'تعذّر تفعيل ملء الشاشة في هذا المتصفح' });
    }
  }, []);

  const enterMini = useCallback(async () => {
    // نحاول أولاً صورة داخل صورة الحقيقية، ثم ننتقل إلى نافذة مصغّرة داخل التطبيق
    try {
      const anyVideo = document.querySelector('video');
      if (document.pictureInPictureEnabled && anyVideo) {
        await anyVideo.requestPictureInPicture();
        return;
      }
    } catch {
      /* يمنع المتصفح PiP لمشغّل يوتيوب */
    }
    setMini(true);
    setHint('شغّلنا نافذة مصغّرة داخل التطبيق — PiP لمشغّل يوتيوب غير مدعوم في هذا المتصفح.');
  }, []);

  /* ------------------------ إيماءات النقر والسحب ------------------------ */
  const seekBy = useCallback(
    (delta: number) => {
      player.seekBy(delta);
      setCenterToast({ id: Date.now(), text: delta > 0 ? `+${delta} ثانية` : `${delta} ثانية` });
    },
    [player],
  );

  const handlePointUp = (event: React.PointerEvent<HTMLDivElement>) => {
    const target = event.currentTarget;
    const rect = target.getBoundingClientRect();
    const x = event.clientX - rect.left;
    // سحب عمودي للصوت؟
    if (dragRef.current) {
      const moved = dragRef.current.moved;
      dragRef.current = null;
      if (moved) return;
    }
    const now = Date.now();
    const isDouble = now - lastTap.current.time < 320 && Math.abs(x - lastTap.current.x) < 60;
    lastTap.current = { time: now, x };

    if (isDouble) {
      const ratio = x / rect.width;
      if (ratio < 0.4) seekBy(-10);
      else if (ratio > 0.6) seekBy(10);
      else player.toggle();
      return;
    }
    if (state.status === 'playing') {
      player.pause();
    } else if (state.status !== 'error' && state.status !== 'loading') {
      startPlayback();
    }
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current) return;
    const dy = dragRef.current.startY - event.clientY;
    if (Math.abs(dy) > 12) {
      dragRef.current.moved = true;
      const next = Math.max(0, Math.min(100, dragRef.current.startVolume + (dy / 2.2)));
      player.setVolume(next);
      setCenterToast({ id: Date.now(), text: `الصوت ${Math.round(next)}%` });
    }
  };

  /* --------------------- اختصارات لوحة المفاتيح --------------------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable)
      ) {
        return;
      }
      if (document.querySelector('[role="dialog"]')) return;

      const key = e.key;
      const lower = key.toLowerCase();
      const interactive = Boolean(target?.closest('button, a, [role="button"], summary, [contenteditable="true"]'));
      // لا نعطّل المسافة/الأسهم عندما يكون التركيز على زر أو رابط (لتبقى متاحة للوصول)
      if (
        !interactive &&
        [' ', 'k', 'j', 'l', 'arrowleft', 'arrowright', 'arrowup', 'arrowdown', 'f'].includes(lower)
      ) {
        e.preventDefault();
      }

      if (lower === ' ' || lower === 'k') player.toggle();
      else if (lower === 'j') seekBy(-10);
      else if (lower === 'l') seekBy(10);
      else if (lower === 'arrowleft') seekBy(-5);
      else if (lower === 'arrowright') seekBy(5);
      else if (lower === 'arrowup') player.setVolume(state.volume + 5);
      else if (lower === 'arrowdown') player.setVolume(state.volume - 5);
      else if (lower === 'm') player.toggleMute();
      else if (lower === 'f') void toggleFullscreen();
      else if (lower === ',') {
        const idx = SPEEDS.findIndex((s) => s >= state.rate);
        const next = SPEEDS[Math.max(0, idx - 1)] ?? 1;
        player.setRate(next);
        onSettingsChange?.({ lastRate: next });
        setCenterToast({ id: Date.now(), text: `السرعة ${next}×` });
      } else if (lower === '.') {
        const idx = SPEEDS.findIndex((s) => s > state.rate);
        const next = SPEEDS[idx === -1 ? SPEEDS.length - 1 : idx] ?? 1;
        player.setRate(next);
        onSettingsChange?.({ lastRate: next });
        setCenterToast({ id: Date.now(), text: `السرعة ${next}×` });
      } else if (lower === 'b' && onBookmark) onBookmark(state.currentTime);
      else if (lower === 'n' && onAddNote) onAddNote(state.currentTime);
      else if (lower === 'escape' && focusMode) onToggleFocus?.();
      else if (/^[0-9]$/.test(key) && duration > 0) player.seek((Number(key) / 10) * duration);
      reveal();
    };

    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [
    player,
    state.volume,
    state.rate,
    state.currentTime,
    duration,
    seekBy,
    toggleFullscreen,
    onSettingsChange,
    onBookmark,
    onAddNote,
    focusMode,
    onToggleFocus,
    reveal,
  ]);

  useEffect(() => {
    if (!centerToast) return undefined;
    const id = window.setTimeout(() => setCenterToast(null), 900);
    return () => window.clearTimeout(id);
  }, [centerToast]);

  const commitSeek = (value: number) => {
    player.seek(value);
    setScrub(null);
  };

  const handleTimelineHover = (event: React.PointerEvent<HTMLDivElement>) => {
    const rect = timelineRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0) return;
    const ratio = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
    setHover({ x: ratio * 100, time: ratio * duration });
  };

  const applyRate = (r: number) => {
    player.setRate(r);
    onSettingsChange?.({ lastRate: r });
  };

  const changeQuality = (q: string) => {
    player.setQuality(q);
    onSettingsChange?.({ dataSaver: false });
  };

  const toggleDataSaver = (value: boolean) => {
    onSettingsChange?.({ dataSaver: value });
    if (value) {
      const lowest = state.qualities.filter((q) => q !== 'default').at(-1);
      if (lowest) player.setQuality(lowest);
    }
  };

  const errorInfo = state.errorCode !== null ? ERROR_MESSAGES[state.errorCode] : undefined;
  const status: PlayerStatus = state.status;
  const showResume = startAt > 5 && !resumeDismissed && status !== 'playing' && status !== 'error';

  return (
    <div
      ref={containerRef}
      className={cn(
        'group/player relative isolate select-none overflow-hidden bg-black',
        mini
          ? 'fixed bottom-4 end-4 z-[65] w-[min(88vw,20rem)] rounded-2xl shadow-2xl ring-1 ring-white/20'
          : 'w-full rounded-3xl',
        isFullscreen && 'rounded-none',
        className,
      )}
      style={{ aspectRatio: isFullscreen ? 'auto' : '16 / 9', height: isFullscreen ? '100%' : undefined }}
      tabIndex={0}
      role="region"
      aria-label={title ? `مشغّل درس ${title}` : 'مشغّل الفيديو'}
      onPointerMove={() => {
        if (status === 'playing') reveal();
      }}
      onMouseLeave={() => {
        if (status === 'playing') setControlsVisible(false);
      }}
    >
      {/* حاوية يوتيوب */}
      <div ref={hostRef} className="absolute inset-0 h-full w-full [&>iframe]:pointer-events-none [&>iframe]:h-full [&>iframe]:w-full" />

      {/* طبقة شفافة تمنع أي تفاعل مع يوتيوب وتستقبل إيماءاتنا */}
      <div
        className="absolute inset-0 z-10"
        onPointerDown={(event) => {
          dragRef.current = { startY: event.clientY, startVolume: state.muted ? 0 : state.volume, moved: false };
          reveal();
        }}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointUp}
        onDoubleClick={(e) => e.preventDefault()}
        aria-hidden="true"
      />

      {/* عنوان الدرس أعلى المشغّل */}
      <AnimatePresence>
        {controlsVisible && started && status !== 'error' && !mini ? (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="pointer-events-none absolute inset-x-0 top-0 z-20 bg-gradient-to-b from-black/70 to-transparent px-3 pb-8 pt-3 sm:px-4"
          >
            <p className="truncate text-xs font-medium text-white/90 sm:text-sm">{title ?? 'درس'}</p>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* شاشة التحميل */}
      {status === 'loading' ? (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-[#08131b]">
          <div className="h-10 w-10 animate-spin rounded-full border-2 border-white/20 border-t-[var(--gold)]" />
          <p className="text-xs text-white/60">جارٍ تحضير المشغّل…</p>
          <div className="absolute inset-x-4 bottom-4 h-1 animate-pulse rounded-full bg-white/10" />
        </div>
      ) : null}

      {/* شاشة الخطأ */}
      {status === 'error' ? (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-[#0b1a24] px-6 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-[var(--gold)]">
            <WifiOff size={22} />
          </div>
          <p className="font-display text-base text-white">{errorInfo?.title ?? 'تعذّر تشغيل الفيديو'}</p>
          <p className="max-w-sm text-xs leading-relaxed text-white/60">{errorInfo?.body}</p>
          <div className="mt-1 flex flex-wrap items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => setReloadToken((t) => t + 1)}
              className="focus-ring rounded-full bg-white px-4 py-2 text-xs font-semibold text-[#0b1a24]"
            >
              إعادة المحاولة
            </button>
          </div>
        </div>
      ) : null}

      {/* غلاف تشغيل مخصّص يغطّي واجهة يوتيوب قبل أول تشغيل */}
      {!started && status !== 'error' && status !== 'loading' ? (
        <button
          type="button"
          onClick={startPlayback}
          className="group/poster absolute inset-0 z-20 flex flex-col items-center justify-center gap-2.5 overflow-hidden bg-[#061a26] px-5 text-center"
          aria-label={`تشغيل الدرس: ${title ?? 'فيديو'}`}
        >
          <span
            className="absolute inset-0 opacity-70"
            style={{
              background:
                'radial-gradient(80% 120% at 80% 0%, rgba(230,165,46,0.25), transparent 55%), radial-gradient(60% 90% at 10% 100%, rgba(18,64,90,0.9), transparent 60%), linear-gradient(145deg, #06212f 0%, #061a26 60%, #04121a 100%)',
            }}
            aria-hidden="true"
          />
          <span
            className="pointer-events-none absolute inset-0 opacity-[0.07]"
            style={{
              backgroundImage:
                'repeating-linear-gradient(45deg, #fff 0 1px, transparent 1px 14px)',
            }}
            aria-hidden="true"
          />
          <span className="relative flex h-16 w-16 items-center justify-center rounded-full bg-[var(--gold)] text-[#3a2606] shadow-[0_18px_50px_-12px_rgba(0,0,0,0.8)] transition-transform duration-200 group-hover/poster:scale-105">
            <Play size={26} className="fill-current" />
          </span>
          <span className="relative mt-1 max-w-md truncate font-display text-[0.95rem] text-white sm:text-base">
            {title ?? 'اضغط للتشغيل'}
          </span>
          <span className="relative text-[0.68rem] text-white/60">
            اضغط للتشغيل · {formatDuration(lesson?.duration ?? duration)} · يوتيوب موثوق
          </span>
          {startAt > 5 ? (
            <span className="relative rounded-full bg-white/10 px-2.5 py-1 text-[0.66rem] text-white/80">
              سيُستأنف من {formatDuration(startAt)}
            </span>
          ) : null}
        </button>
      ) : null}

      {/* زر التشغيل الكبير عند الإيقاف بعد البدء */}
      {started && status !== 'error' && status !== 'loading' && controlsVisible && status !== 'playing' ? (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
          <button
            type="button"
            onClick={() => player.play()}
            aria-label="متابعة التشغيل"
            className="focus-ring pointer-events-auto flex h-14 w-14 items-center justify-center rounded-full bg-black/45 text-white shadow-xl backdrop-blur transition-transform hover:scale-105 active:scale-95"
          >
            <Play size={24} className="fill-current" />
          </button>
        </div>
      ) : null}

      {status === 'buffering' ? (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
          <Loader2 size={34} className="animate-spin text-white/80" />
        </div>
      ) : null}

      {status === 'ended' ? (
        <div className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center gap-2 bg-[#061a26] text-center text-white" aria-live="polite">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-[var(--gold)]"><Play size={20} /></span>
          <p className="font-display text-base">انتهى الدرس</p>
          <p className="text-xs text-white/60">أنت ما زلت داخل منارة — تابع بالدرس التالي أو أعد المشاهدة.</p>
        </div>
      ) : null}

      {/* رسالة تابع من… */}
      <AnimatePresence>
        {showResume ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute bottom-20 start-1/2 z-30 flex -translate-x-1/2 items-center gap-2 rounded-full bg-[#0b1a24]/92 px-3 py-2 text-white shadow-xl backdrop-blur"
          >
            <span className="text-xs">تابع من {formatDuration(startAt)}</span>
            <button
              type="button"
              onClick={() => {
                player.seek(startAt);
                player.play();
                setResumeDismissed(true);
              }}
              className="focus-ring rounded-full bg-[var(--gold)] px-2.5 py-1 text-[0.7rem] font-semibold text-[#3a2606]"
            >
              متابعة
            </button>
            <button
              type="button"
              onClick={() => {
                player.seek(0);
                setResumeDismissed(true);
              }}
              className="focus-ring rounded-full border border-white/25 px-2.5 py-1 text-[0.7rem] text-white/85"
            >
              من البداية
            </button>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* عدّاد الدرس التالي */}
      <AnimatePresence>
        {countdown !== null && nextLabel ? (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="absolute inset-x-3 bottom-16 z-30 flex items-center justify-between gap-3 rounded-2xl bg-[#0b1a24]/94 px-3 py-2.5 text-white shadow-2xl backdrop-blur"
          >
            <div className="min-w-0">
              <p className="text-[0.68rem] text-white/55">الدرس التالي بعد {countdown} ث</p>
              <p className="truncate text-xs font-medium">{nextLabel}</p>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setCountdown(null);
                  onNext?.();
                }}
                className="focus-ring rounded-full bg-[var(--gold)] px-3 py-1.5 text-[0.7rem] font-semibold text-[#3a2606]"
              >
                تشغيل الآن
              </button>
              <button
                type="button"
                onClick={() => setCountdown(null)}
                className="focus-ring rounded-full border border-white/25 px-2.5 py-1.5 text-[0.7rem]"
              >
                إلغاء
              </button>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* تنبيه الإنترنت */}
      {!online ? (
        <div className="absolute inset-x-0 top-0 z-40 flex items-center justify-center gap-2 bg-[var(--danger)] px-3 py-1.5 text-[0.7rem] text-white">
          <WifiOff size={13} /> انقطع الاتصال — سيستأنف التشغيل عند عودة الشبكة
        </div>
      ) : null}

      {/* تلميح مركزي */}
      <AnimatePresence>
        {centerToast ? (
          <motion.div
            key={centerToast.id}
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="pointer-events-none absolute start-1/2 top-1/2 z-40 -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-black/70 px-4 py-2 text-sm font-medium text-white backdrop-blur"
          >
            {centerToast.text}
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* شريط التحكّم */}
      <AnimatePresence>
        {controlsVisible && started && status !== 'error' && !mini ? (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            className="absolute inset-x-0 bottom-0 z-30 bg-gradient-to-t from-black/85 via-black/55 to-transparent px-2 pb-2 pt-8 sm:px-3"
            onClick={(e) => e.stopPropagation()}
          >
            {/* شريط التقدم */}
            <div className="px-1">
              <div
                ref={timelineRef}
                className="group/timeline relative h-4 w-full cursor-pointer"
                dir="ltr"
                onPointerMove={handleTimelineHover}
                onPointerLeave={() => setHover(null)}
              >
                <div className="absolute inset-x-0 top-1/2 h-1 -translate-y-1/2 overflow-hidden rounded-full bg-white/25">
                  <div
                    className="absolute inset-y-0 left-0 bg-white/25"
                    style={{ width: `${Math.min(100, state.buffered * 100)}%` }}
                  />
                  <div
                    className="absolute inset-y-0 left-0 bg-[var(--gold)]"
                    style={{ width: duration > 0 ? `${(position / duration) * 100}%` : '0%' }}
                  />
                </div>

                {/* علامات الفصول */}
                {duration > 0
                  ? chapters.map((chapter) => (
                      <span
                        key={`${chapter.time}-${chapter.title}`}
                        className="absolute top-1/2 h-2 w-[2px] -translate-y-1/2 rounded bg-white/55"
                        style={{ left: `${(chapter.time / duration) * 100}%` }}
                        title={`${formatDuration(chapter.time)} — ${chapter.title}`}
                      />
                    ))
                  : null}

                {/* علامتا A-B */}
                {loop.a !== null && duration > 0 ? (
                  <span className="absolute -top-1 h-6 w-[2px] bg-[#7dd3fc]" style={{ left: `${(loop.a / duration) * 100}%` }} />
                ) : null}
                {loop.b !== null && duration > 0 ? (
                  <span className="absolute -top-1 h-6 w-[2px] bg-[#7dd3fc]" style={{ left: `${(loop.b / duration) * 100}%` }} />
                ) : null}

                {hover ? (
                  <span
                    className="pointer-events-none absolute -top-8 -translate-x-1/2 rounded-md bg-black/85 px-1.5 py-0.5 text-[0.65rem] text-white"
                    style={{ left: `${hover.x}%` }}
                  >
                    {formatDuration(hover.time)}
                  </span>
                ) : null}

                <input
                  type="range"
                  min={0}
                  max={duration || 0}
                  step={0.5}
                  value={position}
                  aria-label="شريط تقدم الفيديو"
                  onChange={(e) => setScrub(Number(e.target.value))}
                  onPointerUp={() => scrub !== null && commitSeek(scrub)}
                  onKeyUp={() => scrub !== null && commitSeek(scrub)}
                  onBlur={() => scrub !== null && commitSeek(scrub)}
                  className="player-range absolute inset-0 h-4 w-full opacity-0"
                />
              </div>

              <div className="mt-0.5 flex items-center justify-between text-[0.68rem] text-white/70" dir="ltr">
                <span>{formatDuration(position)}</span>
                <span>{formatDuration(duration)}</span>
              </div>
            </div>

            {/* الأزرار */}
            <div className="mt-1 flex items-center gap-0.5">
              <button
                type="button"
                onClick={() => player.toggle()}
                aria-label={status === 'playing' ? 'إيقاف مؤقت' : 'تشغيل'}
                className="focus-ring flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12"
              >
                {status === 'playing' ? <Pause size={20} className="fill-current" /> : <Play size={20} className="fill-current" />}
              </button>

              <button
                type="button"
                onClick={() => seekBy(-10)}
                aria-label="تأخير ١٠ ثوانٍ"
                className="focus-ring hidden h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12 sm:flex"
              >
                <RotateCcw size={18} />
              </button>
              <button
                type="button"
                onClick={() => seekBy(10)}
                aria-label="تقديم ١٠ ثوانٍ"
                className="focus-ring hidden h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12 sm:flex"
              >
                <RotateCw size={18} />
              </button>

              {/* الصوت */}
              <div className="group/volume flex items-center">
                <button
                  type="button"
                  onClick={() => {
                    player.toggleMute();
                    onSettingsChange?.({ lastVolume: state.volume });
                  }}
                  aria-label={state.muted ? 'إلغاء كتم الصوت' : 'كتم الصوت'}
                  className="focus-ring flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12"
                >
                  {state.muted || state.volume === 0 ? <VolumeX size={18} /> : state.volume < 50 ? <Volume1 size={18} /> : <Volume2 size={18} />}
                </button>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={state.muted ? 0 : state.volume}
                  aria-label="مستوى الصوت"
                  dir="ltr"
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    player.setVolume(v);
                    onSettingsChange?.({ lastVolume: v });
                  }}
                  className="player-range hidden h-1 w-16 cursor-pointer rounded-full bg-white/30 sm:block"
                />
              </div>

              <div className="mx-1 hidden text-[0.7rem] text-white/65 sm:block" dir="ltr">
                {formatDuration(position)} / {formatDuration(duration)}
              </div>

              <span className="flex-1" />

              {onAddNote ? (
                <button
                  type="button"
                  onClick={() => onAddNote(state.currentTime)}
                  aria-label="أضف ملاحظة عند هذه اللحظة"
                  title="أضف ملاحظة (N)"
                  className="focus-ring hidden h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12 sm:flex"
                >
                  <StickyNote size={18} />
                </button>
              ) : null}
              {onBookmark ? (
                <button
                  type="button"
                  onClick={() => onBookmark(state.currentTime)}
                  aria-label="إضافة إشارة مرجعية"
                  title="إشارة مرجعية (B)"
                  className="focus-ring hidden h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12 sm:flex"
                >
                  <Bookmark size={18} />
                </button>
              ) : null}

              <button
                type="button"
                onClick={() => setMenu(menu === 'loop' ? null : 'loop')}
                aria-label="تكرار مقطع"
                title="تكرار مقطع A-B"
                className={cn(
                  'focus-ring hidden h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12 sm:flex',
                  loop.a !== null && 'text-[var(--gold)]',
                )}
              >
                <Repeat2 size={18} />
              </button>

              <button
                type="button"
                onClick={() => setMenu(menu === 'speed' ? null : 'speed')}
                aria-label="سرعة التشغيل"
                className="focus-ring flex h-10 items-center justify-center gap-1 rounded-full px-2 text-[0.72rem] font-medium text-white hover:bg-white/12"
              >
                <Gauge size={17} />
                <span dir="ltr">{state.rate}×</span>
              </button>

              <button
                type="button"
                onClick={() => setMenu(menu === 'quality' ? null : 'quality')}
                aria-label="جودة الفيديو"
                className="focus-ring hidden h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12 sm:flex"
              >
                <MonitorPlay size={18} />
              </button>

              {onToggleFocus ? (
                <button
                  type="button"
                  onClick={onToggleFocus}
                  aria-label={focusMode ? 'إيقاف وضع التركيز' : 'وضع التركيز'}
                  title="وضع التركيز"
                  className="focus-ring hidden h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12 lg:flex"
                >
                  <Focus size={18} />
                </button>
              ) : null}

              {onToggleTheater ? (
                <button
                  type="button"
                  onClick={onToggleTheater}
                  aria-label={theater ? 'إنهاء وضع المسرح' : 'وضع المسرح'}
                  title="وضع المسرح"
                  className={cn(
                    'focus-ring hidden h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12 lg:flex',
                    theater && 'text-[var(--gold)]',
                  )}
                >
                  <MonitorPlay size={18} />
                </button>
              ) : null}

              <button
                type="button"
                onClick={() => void enterMini()}
                aria-label="صورة داخل صورة"
                title="صورة داخل صورة"
                className="focus-ring hidden h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12 sm:flex"
              >
                <PictureInPicture2 size={18} />
              </button>

              <button
                type="button"
                onClick={() => setMenu(menu ? null : 'speed')}
                aria-label="إعدادات المشغّل"
                className="focus-ring flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12 sm:hidden"
              >
                <Settings2 size={18} />
              </button>

              <button
                type="button"
                onClick={() => void toggleFullscreen()}
                aria-label={isFullscreen ? 'إنهاء ملء الشاشة' : 'ملء الشاشة'}
                className="focus-ring flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/12"
              >
                {isFullscreen ? <Minimize size={18} /> : <Maximize size={18} />}
              </button>
            </div>

            {/* أزرار الدرس السابق/التالي */}
            {onPrevious || onNext ? (
              <div className="mt-1 flex items-center justify-between gap-2 border-t border-white/10 pt-1.5">
                <button
                  type="button"
                  onClick={() => onNext?.()}
                  disabled={!onNext}
                  className="focus-ring flex min-w-0 items-center gap-1 rounded-lg px-1.5 py-1 text-[0.7rem] text-white/80 hover:bg-white/10 disabled:opacity-40"
                >
                  <ChevronLeft size={14} />
                  <span className="truncate">{nextLabel ?? 'الدرس التالي'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => onPrevious?.()}
                  disabled={!onPrevious}
                  className="focus-ring flex min-w-0 items-center gap-1 rounded-lg px-1.5 py-1 text-[0.7rem] text-white/80 hover:bg-white/10 disabled:opacity-40"
                >
                  <span className="truncate">{previousLabel ?? 'الدرس السابق'}</span>
                  <ChevronRight size={14} />
                </button>
              </div>
            ) : null}
          </motion.div>
        ) : null}
      </AnimatePresence>

      <PlayerMenu
        open={menu !== null}
        section={menu}
        rate={state.rate}
        qualities={state.qualities}
        currentQuality={state.quality}
        dataSaver={settings?.dataSaver ?? false}
        loop={loop}
        onRate={applyRate}
        onQuality={changeQuality}
        onDataSaver={toggleDataSaver}
        onLoop={(action) => {
          if (action === 'a') setLoop((l) => ({ ...l, a: state.currentTime }));
          if (action === 'b') setLoop((l) => ({ ...l, b: state.currentTime > (l.a ?? 0) ? state.currentTime : null }));
          if (action === 'clear') setLoop({ a: null, b: null });
        }}
        onClose={() => setMenu(null)}
      />

      {/* نافذة مصغّرة */}
      {mini ? (
        <div className="absolute inset-x-0 top-0 z-40 flex items-center justify-between bg-black/70 px-2 py-1">
          <span className="truncate text-[0.65rem] text-white/85">نافذة مصغّرة</span>
          <button
            type="button"
            onClick={() => setMini(false)}
            className="focus-ring rounded-full bg-white/15 px-2 py-0.5 text-[0.65rem] text-white"
          >
            تكبير
          </button>
        </div>
      ) : null}

      {hint ? (
        <button
          type="button"
          onClick={() => setHint(null)}
          className="absolute inset-x-2 bottom-2 z-40 rounded-xl bg-black/80 px-2 py-1.5 text-[0.65rem] leading-relaxed text-white/80"
        >
          {hint}
        </button>
      ) : null}

      {/* شارة الاختصارات على الشاشات الكبيرة */}
      {!mini && started ? (
        <div
          dir="rtl"
          className="pointer-events-none absolute bottom-2 end-2 z-20 hidden items-center gap-1 rounded-full bg-black/40 px-2 py-1 text-[0.6rem] text-white/60 lg:flex"
        >
          مسافة: تشغيل · J/L: ١٠ ثوانٍ · F: ملء الشاشة
        </div>
      ) : null}
    </div>
  );
}


export default VideoPlayer;
