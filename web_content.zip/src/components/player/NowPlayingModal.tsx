import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import { CoverArt } from '../common/CoverArt';
import { EqualizerAnimation } from '../common/EqualizerAnimation';
import { LyricsView } from './LyricsView';
import { QueueSheet } from './QueueSheet';
import { SleepTimerModal } from '../modals/SleepTimerModal';
import { AddToPlaylistModal } from '../modals/AddToPlaylistModal';
import { ShareModal } from '../modals/ShareModal';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  Heart,
  ChevronDown,
  Volume2,
  VolumeX,
  ListMusic,
  FileText,
  Share2,
  ArrowDownToLine,
  Check,
  Moon,
  PlusSquare,
  Sparkles,
  Sliders
} from 'lucide-react';

export const NowPlayingModal: React.FC = () => {
  const {
    currentSong,
    isPlaying,
    currentTime,
    duration,
    togglePlayPause,
    playNext,
    playPrevious,
    seekTo,
    volume,
    setVolume,
    shuffle,
    toggleShuffle,
    repeat,
    toggleRepeat,
    isNowPlayingOpen,
    setIsNowPlayingOpen,
    likedSongIds,
    toggleLikeSong,
    downloadedSongIds,
    toggleDownloadSong,
    user,
    updateUserSettings
  } = useMusic();

  const [activeTab, setActiveTab] = useState<'player' | 'lyrics' | 'queue'>('player');
  const [isSleepModalOpen, setIsSleepModalOpen] = useState(false);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [isDraggingSeek, setIsDraggingSeek] = useState(false);
  const [seekValue, setSeekValue] = useState(0);

  if (!isNowPlayingOpen || !currentSong) return null;

  const isLiked = likedSongIds.includes(currentSong.id);
  const isDownloaded = downloadedSongIds.includes(currentSong.id);

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setSeekValue(val);
  };

  const handleSeekStart = () => {
    setIsDraggingSeek(true);
    setSeekValue(currentTime);
  };

  const handleSeekEnd = () => {
    setIsDraggingSeek(false);
    seekTo(seekValue);
  };

  const effectiveTime = isDraggingSeek ? seekValue : currentTime;
  const progressPercent = duration > 0 ? (effectiveTime / duration) * 100 : 0;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0b0c10] text-slate-100 overflow-hidden animate-in fade-in slide-in-from-bottom duration-300">
      {/* Dynamic blurred album background with gradient overlay */}
      <div
        className="absolute inset-0 opacity-40 blur-3xl scale-125 pointer-events-none transition-all duration-700"
        style={{
          background: `radial-gradient(circle at 50% 30%, ${currentSong.colorTheme.from} 0%, ${currentSong.colorTheme.to} 70%, #000000 100%)`
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-[#0b0c10]/85 to-[#0b0c10] pointer-events-none" />

      {/* Top Bar / Drag handle */}
      <div className="relative z-10 flex items-center justify-between px-5 pt-3 pb-2 shrink-0">
        <button
          onClick={() => setIsNowPlayingOpen(false)}
          className="p-2 -ml-2 rounded-full hover:bg-white/10 active:scale-90 transition-transform"
          aria-label="Collapse player"
        >
          <ChevronDown className="w-6 h-6 text-slate-300" />
        </button>

        {/* View Switcher: Player / Lyrics / Queue */}
        <div className="flex items-center gap-1 bg-white/[0.08] backdrop-blur-md p-1 rounded-2xl border border-white/10">
          <button
            onClick={() => setActiveTab('player')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'player'
                ? 'bg-white/20 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Track
          </button>
          <button
            onClick={() => setActiveTab('lyrics')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all ${
              activeTab === 'lyrics'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3 h-3" />
            <span>Lyrics</span>
          </button>
          <button
            onClick={() => setActiveTab('queue')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all ${
              activeTab === 'queue'
                ? 'bg-white/20 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ListMusic className="w-3 h-3" />
            <span>Queue</span>
          </button>
        </div>

        {/* Audio Quality & Sleep Timer Trigger */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsSleepModalOpen(true)}
            title="Set Sleep Timer"
            className="p-2 rounded-full hover:bg-white/10 text-slate-300 hover:text-purple-300 transition-colors"
          >
            <Moon className="w-5 h-5" />
          </button>

          <div className="relative">
            <button
              onClick={() => setShowQualityMenu(!showQualityMenu)}
              className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-[11px] font-semibold text-purple-300 border border-white/10 transition-colors"
            >
              {user.settings.audioQuality}
            </button>

            {showQualityMenu && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setShowQualityMenu(false)} />
                <div className="absolute right-0 mt-2 w-44 rounded-2xl glass-panel p-2 shadow-2xl z-50 animate-in fade-in zoom-in-95">
                  <div className="text-[10px] uppercase font-semibold text-slate-400 px-2 py-1 border-b border-white/10 mb-1">
                    Streaming Quality
                  </div>
                  {(['Auto', 'Low', 'Normal', 'High', 'Very High'] as const).map((q) => (
                    <button
                      key={q}
                      onClick={() => {
                        updateUserSettings({ audioQuality: q });
                        setShowQualityMenu(false);
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                        user.settings.audioQuality === q
                          ? 'bg-purple-600 text-white'
                          : 'text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      <span>{q}</span>
                      {user.settings.audioQuality === q && <Check className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Main Body View */}
      <div className="relative z-10 flex-1 overflow-hidden flex flex-col max-w-lg mx-auto w-full px-5 py-2">
        {activeTab === 'lyrics' ? (
          <LyricsView
            lyrics={currentSong.lyrics}
            currentTime={currentTime}
            onSeek={seekTo}
            songTitle={currentSong.title}
            artistName={currentSong.artist}
          />
        ) : activeTab === 'queue' ? (
          <QueueSheet onClose={() => setActiveTab('player')} />
        ) : (
          /* Main Track View */
          <div className="flex-1 flex flex-col justify-between py-2">
            {/* Center Artwork with smooth Vinyl/Pulse effect */}
            <div className="flex-1 flex items-center justify-center py-4 min-h-0">
              <div className="relative group max-h-[320px] max-w-[320px] w-full aspect-square flex items-center justify-center">
                {/* Glow bloom */}
                <div
                  className="absolute inset-0 rounded-3xl blur-2xl opacity-50 transition-opacity duration-500 pointer-events-none"
                  style={{
                    backgroundColor: currentSong.colorTheme.accent
                  }}
                />

                <CoverArt
                  artKey={currentSong.albumArt}
                  title={currentSong.title}
                  artist={currentSong.artist}
                  colorTheme={currentSong.colorTheme}
                  size="full"
                  isVinyl={true}
                  isPlaying={isPlaying}
                  className="w-full h-full rounded-3xl shadow-2xl transition-transform duration-500"
                />
              </div>
            </div>

            {/* Song Meta + Like + Add */}
            <div className="flex items-center justify-between mt-2 pt-2">
              <div className="min-w-0 pr-3">
                <h1 className="font-display font-extrabold text-xl sm:text-2xl text-white tracking-tight truncate">
                  {currentSong.title}
                </h1>
                <p className="text-sm sm:text-base text-slate-400 font-medium truncate mt-0.5">
                  {currentSong.artist}
                </p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[11px] text-purple-400 font-medium">
                    {currentSong.album}
                  </span>
                  <span className="text-slate-600">·</span>
                  <span className="text-[11px] text-slate-500 font-medium">
                    {currentSong.genre}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {/* Like Button */}
                <button
                  onClick={() => toggleLikeSong(currentSong.id)}
                  aria-label={isLiked ? 'Unlike song' : 'Like song'}
                  className="p-3 rounded-full hover:bg-white/10 active:scale-90 transition-transform"
                >
                  <Heart
                    className={`w-6 h-6 transition-colors ${
                      isLiked ? 'fill-pink-500 text-pink-500' : 'text-slate-300'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Animated Equalizer Waveform */}
            <div className="mt-3 flex items-center justify-center">
              <EqualizerAnimation
                isPlaying={isPlaying}
                barsCount={28}
                height={22}
                mode="wave"
                color="bg-gradient-to-t from-purple-500 to-pink-400"
                className="w-full justify-between"
              />
            </div>

            {/* Progress Slider */}
            <div className="mt-3">
              <div className="relative flex items-center">
                <input
                  type="range"
                  min={0}
                  max={duration || 100}
                  step={0.5}
                  value={effectiveTime}
                  onChange={handleSeekChange}
                  onMouseDown={handleSeekStart}
                  onTouchStart={handleSeekStart}
                  onMouseUp={handleSeekEnd}
                  onTouchEnd={handleSeekEnd}
                  className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-purple-500 focus:outline-none"
                  style={{
                    background: `linear-gradient(to right, #a855f7 ${progressPercent}%, rgba(255,255,255,0.15) ${progressPercent}%)`
                  }}
                />
              </div>
              <div className="flex justify-between items-center text-[11px] font-mono text-slate-400 mt-1.5">
                <span>{formatTime(effectiveTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Main Playback Controls */}
            <div className="flex items-center justify-between px-2 mt-2">
              {/* Shuffle */}
              <button
                onClick={toggleShuffle}
                aria-label="Toggle shuffle"
                className={`p-2.5 rounded-full transition-colors ${
                  shuffle ? 'text-purple-400 bg-purple-500/10' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Shuffle className="w-5 h-5" />
              </button>

              {/* Prev */}
              <button
                onClick={playPrevious}
                aria-label="Previous track"
                className="p-3 rounded-full hover:bg-white/10 active:scale-95 text-slate-200 hover:text-white transition-all"
              >
                <SkipBack className="w-7 h-7 fill-slate-200" />
              </button>

              {/* Play / Pause Primary Button */}
              <button
                onClick={togglePlayPause}
                aria-label={isPlaying ? 'Pause' : 'Play'}
                className="w-16 h-16 rounded-full bg-gradient-to-tr from-purple-500 via-pink-500 to-indigo-500 text-white flex items-center justify-center shadow-lg shadow-purple-500/30 active:scale-95 hover:scale-105 transition-all"
              >
                {isPlaying ? (
                  <Pause className="w-8 h-8 fill-white" />
                ) : (
                  <Play className="w-8 h-8 fill-white ml-1" />
                )}
              </button>

              {/* Next */}
              <button
                onClick={playNext}
                aria-label="Next track"
                className="p-3 rounded-full hover:bg-white/10 active:scale-95 text-slate-200 hover:text-white transition-all"
              >
                <SkipForward className="w-7 h-7 fill-slate-200" />
              </button>

              {/* Repeat */}
              <button
                onClick={toggleRepeat}
                aria-label="Toggle repeat"
                className={`p-2.5 rounded-full transition-colors ${
                  repeat !== 'off'
                    ? 'text-purple-400 bg-purple-500/10'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {repeat === 'one' ? (
                  <Repeat1 className="w-5 h-5" />
                ) : (
                  <Repeat className="w-5 h-5" />
                )}
              </button>
            </div>

            {/* Bottom Auxiliary Bar: Volume, Download, Add, Share */}
            <div className="flex items-center justify-between pt-3 px-2 border-t border-white/[0.08] mt-2">
              {/* Volume Slider */}
              <div className="flex items-center gap-2 flex-1 max-w-[140px]">
                <button
                  onClick={() => setVolume(volume > 0 ? 0 : 0.85)}
                  className="text-slate-400 hover:text-white"
                >
                  {volume === 0 ? (
                    <VolumeX className="w-4 h-4" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  className="w-full h-1 bg-white/20 rounded appearance-none accent-purple-400 cursor-pointer"
                />
              </div>

              {/* Secondary Action Icons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => toggleDownloadSong(currentSong.id)}
                  title={isDownloaded ? 'Downloaded' : 'Download for offline'}
                  className={`p-2 rounded-full hover:bg-white/10 transition-colors ${
                    isDownloaded ? 'text-emerald-400' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {isDownloaded ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <ArrowDownToLine className="w-4 h-4" />
                  )}
                </button>

                <button
                  onClick={() => setIsPlaylistModalOpen(true)}
                  title="Add to playlist"
                  className="p-2 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                >
                  <PlusSquare className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setIsShareModalOpen(true)}
                  title="Share"
                  className="p-2 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      <SleepTimerModal
        isOpen={isSleepModalOpen}
        onClose={() => setIsSleepModalOpen(false)}
      />

      <AddToPlaylistModal
        song={currentSong}
        isOpen={isPlaylistModalOpen}
        onClose={() => setIsPlaylistModalOpen(false)}
      />

      <ShareModal
        song={currentSong}
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />
    </div>
  );
};
