interface TeacherUploadsPlaylistProps {
  playlistId: string;
  channelName: string;
}

const YOUTUBE_UPLOADS_PLAYLIST_ID = /^UU[A-Za-z0-9_-]{22}$/;

export function TeacherUploadsPlaylist({ playlistId, channelName }: TeacherUploadsPlaylistProps) {
  if (!YOUTUBE_UPLOADS_PLAYLIST_ID.test(playlistId)) {
    return (
      <p
        role="status"
        className="rounded-xl bg-[var(--surface-2)] p-3 text-sm leading-relaxed text-[var(--ink-soft)]"
      >
        تعذر فتح مكتبة القناة لأن معرّف قائمة الرفع غير صالح.
      </p>
    );
  }

  const src = `https://www.youtube-nocookie.com/embed?listType=playlist&list=${encodeURIComponent(playlistId)}&playsinline=1&controls=1&rel=0&iv_load_policy=3&hl=ar&autoplay=0`;

  return (
    <div className="relative aspect-video overflow-hidden rounded-2xl bg-black">
      <iframe
        title={`مكتبة الفيديوهات الكاملة لقناة ${channelName}`}
        src={src}
        loading="lazy"
        referrerPolicy="strict-origin-when-cross-origin"
        sandbox="allow-scripts allow-same-origin allow-presentation"
        allow="encrypted-media; picture-in-picture; fullscreen"
        allowFullScreen
        tabIndex={0}
        className="absolute inset-0 h-full w-full border-0"
      />
    </div>
  );
}
