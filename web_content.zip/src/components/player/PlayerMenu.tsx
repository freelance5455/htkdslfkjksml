import { AnimatePresence, motion } from 'framer-motion';
import { Check, Gauge, MonitorPlay, Repeat2, Timer } from 'lucide-react';
import { qualityLabel } from '../../hooks/useYouTubePlayer';
import { cn } from '../../utils/format';

const RATES = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

export type MenuSection = 'speed' | 'quality' | 'loop' | null;

export function PlayerMenu({
  open,
  section,
  rate,
  qualities,
  currentQuality,
  dataSaver,
  loop,
  onRate,
  onQuality,
  onDataSaver,
  onLoop,
  onClose,
}: {
  open: boolean;
  section: MenuSection;
  rate: number;
  qualities: string[];
  currentQuality: string;
  dataSaver: boolean;
  loop: { a: number | null; b: number | null };
  onRate: (rate: number) => void;
  onQuality: (q: string) => void;
  onDataSaver: (v: boolean) => void;
  onLoop: (action: 'a' | 'b' | 'clear') => void;
  onClose: () => void;
}) {
  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          initial={{ opacity: 0, y: 8, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 6, scale: 0.98 }}
          transition={{ duration: 0.16 }}
          className="absolute bottom-16 end-2 z-40 w-64 overflow-hidden rounded-2xl border border-white/10 bg-[#0b1a24]/96 p-2 text-white shadow-2xl backdrop-blur-md sm:end-3"
          role="menu"
          aria-label="إعدادات المشغّل"
        >
          <div className="mb-1 flex items-center gap-1.5 px-2 py-1 text-[0.7rem] text-white/55">
            {section === 'speed' ? <Gauge size={13} /> : null}
            {section === 'quality' ? <MonitorPlay size={13} /> : null}
            {section === 'loop' ? <Repeat2 size={13} /> : null}
            <span>
              {section === 'speed' ? 'سرعة التشغيل' : section === 'quality' ? 'جودة الفيديو' : 'تكرار مقطع'}
            </span>
          </div>

          {section === 'speed' ? (
            <ul className="space-y-0.5">
              {RATES.map((r) => (
                <li key={r}>
                  <button
                    type="button"
                    role="menuitemradio"
                    aria-checked={Math.abs(rate - r) < 0.01}
                    onClick={() => {
                      onRate(r);
                      onClose();
                    }}
                    className={cn(
                      'flex w-full items-center justify-between rounded-xl px-2.5 py-2 text-sm hover:bg-white/10',
                      Math.abs(rate - r) < 0.01 && 'text-[var(--gold)]',
                    )}
                  >
                    <span>{r === 1 ? 'عادي (1×)' : `${r}×`}</span>
                    {Math.abs(rate - r) < 0.01 ? <Check size={15} /> : null}
                  </button>
                </li>
              ))}
            </ul>
          ) : null}

          {section === 'quality' ? (
            <ul className="space-y-0.5">
              {qualities.map((q) => (
                <li key={q}>
                  <button
                    type="button"
                    role="menuitemradio"
                    aria-checked={currentQuality === q}
                    onClick={() => {
                      onQuality(q);
                      onClose();
                    }}
                    className={cn(
                      'flex w-full items-center justify-between rounded-xl px-2.5 py-2 text-sm hover:bg-white/10',
                      currentQuality === q && 'text-[var(--gold)]',
                    )}
                  >
                    <span>{q === 'default' ? 'تلقائي (موصى به)' : qualityLabel(q)}</span>
                    {currentQuality === q ? <Check size={15} /> : null}
                  </button>
                </li>
              ))}
              <li className="mt-1 border-t border-white/10 pt-1">
                <button
                  type="button"
                  role="menuitemcheckbox"
                  aria-checked={dataSaver}
                  onClick={() => onDataSaver(!dataSaver)}
                  className="flex w-full items-center justify-between rounded-xl px-2.5 py-2 text-sm hover:bg-white/10"
                >
                  <span className="flex items-center gap-1.5">
                    <Timer size={14} /> توفير البيانات
                  </span>
                  <span
                    className={cn(
                      'flex h-5 w-9 items-center rounded-full p-0.5 transition-colors',
                      dataSaver ? 'bg-[var(--gold)]' : 'bg-white/20',
                    )}
                  >
                    <span
                      className={cn(
                        'h-4 w-4 rounded-full bg-white transition-transform',
                        dataSaver ? '-translate-x-4' : 'translate-x-0',
                      )}
                    />
                  </span>
                </button>
              </li>
            </ul>
          ) : null}

          {section === 'loop' ? (
            <div className="space-y-1 px-1 pb-1">
              <p className="px-1.5 pb-1 text-[0.7rem] leading-relaxed text-white/55">
                حدّد بداية ونهاية مقطع لإعادة سماعه تلقائياً.
              </p>
              <button
                type="button"
                onClick={() => onLoop('a')}
                className="flex w-full items-center justify-between rounded-xl px-2.5 py-2 text-sm hover:bg-white/10"
              >
                <span>تعيين البداية (A)</span>
                <span className="text-white/60">{loop.a !== null ? 'تم' : '—'}</span>
              </button>
              <button
                type="button"
                onClick={() => onLoop('b')}
                className="flex w-full items-center justify-between rounded-xl px-2.5 py-2 text-sm hover:bg-white/10"
              >
                <span>تعيين النهاية (B)</span>
                <span className="text-white/60">{loop.b !== null ? 'تم' : '—'}</span>
              </button>
              <button
                type="button"
                onClick={() => onLoop('clear')}
                className="flex w-full items-center justify-between rounded-xl px-2.5 py-2 text-sm text-white/70 hover:bg-white/10"
              >
                <span>إلغاء التكرار</span>
              </button>
            </div>
          ) : null}
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
