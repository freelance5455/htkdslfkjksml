import React, { useEffect, useRef } from 'react';
import { LyricLine } from '../../types/music';
import { Share2, Check, Sparkles } from 'lucide-react';

interface LyricsViewProps {
  lyrics: LyricLine[];
  currentTime: number;
  onSeek: (seconds: number) => void;
  songTitle: string;
  artistName: string;
}

export const LyricsView: React.FC<LyricsViewProps> = ({
  lyrics,
  currentTime,
  onSeek,
  songTitle,
  artistName
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const activeLineRef = useRef<HTMLParagraphElement>(null);
  const [copiedText, setCopiedText] = React.useState<string | null>(null);

  // Determine active lyric index
  let activeIndex = -1;
  for (let i = 0; i < lyrics.length; i++) {
    if (currentTime >= lyrics[i].time) {
      activeIndex = i;
    } else {
      break;
    }
  }

  // Auto scroll smoothly to active lyric
  useEffect(() => {
    if (activeLineRef.current && containerRef.current) {
      activeLineRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [activeIndex]);

  const handleShareLine = (text: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const shareMessage = `"${text}" — from ${songTitle} by ${artistName} on Music Express`;
    navigator.clipboard?.writeText(shareMessage);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2500);
  };

  if (!lyrics || lyrics.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center px-4">
        <Sparkles className="w-10 h-10 text-purple-400 mb-3 opacity-60" />
        <p className="text-base font-semibold text-slate-200">Lyrics unavailable</p>
        <p className="text-xs text-slate-400 mt-1 max-w-xs">
          We couldn&apos;t load synchronized lyrics for this track. Enjoy the instrumental melody!
        </p>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full flex flex-col">
      {/* Toast alert when lyric copied */}
      {copiedText && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-30 bg-purple-600 text-white text-xs font-medium px-3 py-1.5 rounded-full shadow-lg flex items-center gap-1.5 animate-in fade-in">
          <Check className="w-3.5 h-3.5" />
          <span>Lyric copied for sharing!</span>
        </div>
      )}

      {/* Lyrics container */}
      <div
        ref={containerRef}
        className="flex-1 overflow-y-auto px-4 py-8 space-y-6 text-center select-none no-scrollbar"
      >
        {lyrics.map((line, idx) => {
          const isActive = idx === activeIndex;
          const isPast = idx < activeIndex;

          return (
            <div
              key={idx}
              ref={isActive ? activeLineRef : null}
              onClick={() => onSeek(line.time)}
              className={`group cursor-pointer transition-all duration-300 py-1.5 px-3 rounded-xl flex items-center justify-center gap-2 ${
                isActive
                  ? 'scale-105 opacity-100 font-bold'
                  : isPast
                  ? 'opacity-40 hover:opacity-75'
                  : 'opacity-30 hover:opacity-70'
              }`}
            >
              <p
                className={`text-base sm:text-xl font-display tracking-tight transition-colors duration-200 ${
                  isActive
                    ? 'bg-gradient-to-r from-purple-200 via-white to-pink-200 bg-clip-text text-transparent drop-shadow-sm'
                    : 'text-slate-300'
                }`}
              >
                {line.text}
              </p>

              {/* Share button on hover/tap */}
              <button
                onClick={(e) => handleShareLine(line.text, e)}
                title="Share lyric quote"
                className="opacity-0 group-hover:opacity-100 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-opacity"
              >
                <Share2 className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>

      <div className="pb-3 text-center">
        <span className="text-[11px] text-slate-500">
          Tap any lyric to jump directly to that point in the song
        </span>
      </div>
    </div>
  );
};
