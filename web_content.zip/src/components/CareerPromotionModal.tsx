import React from 'react';
import { CareerPosition } from '../game/types';
import { Sparkles, Trophy, ArrowUpRight, CheckCircle2, Briefcase } from 'lucide-react';
import { playLevelUpSound, playClickSound } from '../utils/audio';

interface CareerPromotionModalProps {
  position: CareerPosition;
  onClose: () => void;
}

export const CareerPromotionModal: React.FC<CareerPromotionModalProps> = ({
  position,
  onClose
}) => {
  React.useEffect(() => {
    playLevelUpSound();
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-md bg-slate-900 border border-amber-500/50 rounded-3xl p-6 shadow-2xl text-right animate-in fade-in zoom-in-95 duration-200 relative overflow-hidden">
        <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600" />
        
        <div className="text-center pb-4 border-b border-slate-800">
          <div className="inline-flex p-3 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 mb-2">
            <Trophy className="w-8 h-8 animate-bounce text-amber-400" />
          </div>
          <h2 className="text-xl font-black text-amber-300">🎉 ألف مبروك الترقية الوظيفية!</h2>
          <p className="text-xs text-slate-300 mt-1">
            تقديراً لاجتهادك وعدد أيام عملك الفعلية وتطور مهاراتك، تمت ترقيتك بنجاح!
          </p>
        </div>

        <div className="mt-4 p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          <div>
            <span className="text-[10px] text-amber-400 font-bold block">المسمى الوظيفي الجديد:</span>
            <div className="text-base font-bold text-slate-100 flex items-center gap-1.5 mt-0.5">
              <span>🎖️</span>
              <span>{position.title}</span>
            </div>
            <span className="text-[11px] text-slate-400">{position.department} • رتبة {position.tier} من 5</span>
          </div>

          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-between text-xs">
            <span className="text-amber-300 font-semibold">الراتب الأساسي الجديد:</span>
            <span className="font-black text-amber-400 text-sm font-mono">{position.basePay.toLocaleString('en-US')} ج.م / وردية</span>
          </div>

          <div>
            <span className="text-[11px] font-semibold text-slate-300 block mb-1">المسؤوليات الجديدة:</span>
            <p className="text-xs text-slate-300 leading-relaxed bg-slate-900 p-2.5 rounded-xl border border-slate-800">
              {position.responsibilities}
            </p>
          </div>

          <div className="text-[11px] text-emerald-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>{position.perkDescription}</span>
          </div>
        </div>

        <button
          onClick={() => { playClickSound(); onClose(); }}
          className="mt-4 w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs transition shadow-lg shadow-amber-500/20 active:scale-95"
        >
          متابعة العمل بالرتبة الجديدة 🚀
        </button>
      </div>
    </div>
  );
};
