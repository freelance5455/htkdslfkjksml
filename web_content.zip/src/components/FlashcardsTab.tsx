import React, { useState } from 'react';
import { RotateCw, Volume2, Shuffle, ChevronLeft, ChevronRight } from 'lucide-react';
import { WordData, CognitiveStatus } from '../types';
import { speakWord, sound } from '../services/sound';

interface FlashcardsTabProps {
  words: WordData[];
  masteredWords: string[];
  reviseWords: string[];
  learnWords: string[];
  onSetStatus: (word: string, status: 'mastered' | 'revise' | 'learn') => void;
  voiceLang?: 'en-US' | 'en-GB';
}

export const FlashcardsTab: React.FC<FlashcardsTabProps> = ({
  words,
  masteredWords,
  reviseWords,
  learnWords,
  onSetStatus,
  voiceLang = 'en-US',
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const currentWord = words[currentIndex % words.length] || words[0];

  const getStatus = (word: string): CognitiveStatus => {
    if (masteredWords.includes(word)) return 'mastered';
    if (reviseWords.includes(word)) return 'revise';
    if (learnWords.includes(word)) return 'learn';
    return 'unassigned';
  };

  const status = getStatus(currentWord.word);

  const handleFlip = () => {
    sound.flip();
    setIsFlipped(!isFlipped);
  };

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % words.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + words.length) % words.length);
  };

  const handleShuffle = () => {
    setIsFlipped(false);
    const randomIdx = Math.floor(Math.random() * words.length);
    setCurrentIndex(randomIdx);
    sound.triggerFloatingXp(5);
  };

  const handleCognitiveAction = (actionStatus: 'mastered' | 'revise' | 'learn') => {
    onSetStatus(currentWord.word, actionStatus);
    handleNext();
  };

  return (
    <div className="flex-1 smooth-scroll p-4 flex flex-col justify-between pb-28 max-w-md mx-auto w-full select-none">
      
      {/* Top Header Controls */}
      <div className="w-full flex items-center justify-between text-xs font-extrabold text-slate-400">
        <span>Card {(currentIndex % words.length) + 1} of {words.length}</span>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShuffle}
            className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-emerald-500 transition-colors"
            title="Random shuffle"
          >
            <Shuffle className="w-4 h-4" />
          </button>

          <button
            onClick={() => speakWord(currentWord.word, voiceLang)}
            className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-emerald-500 transition-colors"
            title="Pronounce"
          >
            <Volume2 className="w-4 h-4" />
          </button>

          <span className="text-amber-500 font-bold text-[11px] bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded-md">
            Tap to Flip
          </span>
        </div>
      </div>

      {/* 3D Flip Card Container */}
      <div className="w-full my-auto py-2">
        <div
          className="w-full h-[380px] perspective-1000 cursor-pointer"
          onClick={handleFlip}
        >
          <div
            className={`w-full h-full relative transform-style-3d transition-transform duration-500 rounded-3xl shadow-xl ${
              isFlipped ? 'rotate-y-180' : ''
            }`}
          >
            
            {/* Front Card Face */}
            <div className="absolute inset-0 backface-hidden bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-6 flex flex-col justify-between items-center text-center shadow-sm">
              <div className="w-full flex justify-between items-center">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold capitalize">
                  {currentWord.pos}
                </span>

                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    status === 'mastered'
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                      : status === 'revise'
                      ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                      : status === 'learn'
                      ? 'bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                  }`}
                >
                  {status === 'mastered' ? '✓ Group A' : status === 'revise' ? '⚡ Group B' : status === 'learn' ? '🎯 Group C' : 'New'}
                </span>
              </div>

              <div className="my-auto space-y-2">
                <h2 className="text-4xl sm:text-5xl font-black text-slate-900 dark:text-white tracking-tight">
                  {currentWord.word}
                </h2>
                <div className="flex items-center justify-center gap-2">
                  <span className="font-mono text-emerald-600 dark:text-emerald-400 text-sm">
                    {currentWord.ipa}
                  </span>
                  <span className="font-bengali text-xs text-slate-400">
                    {currentWord.bengaliPron}
                  </span>
                </div>
                <p className="text-xs text-slate-400 pt-3 font-medium">
                  Tap card to reveal definition, mnemonic & collocations
                </p>
              </div>

              <div className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                <RotateCw className="w-3.5 h-3.5" /> Flip Card
              </div>
            </div>

            {/* Back Card Face */}
            <div className="absolute inset-0 backface-hidden rotate-y-180 bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 text-white rounded-3xl p-6 flex flex-col justify-between text-left shadow-xl border-2 border-emerald-500/40">
              <div className="flex justify-between items-baseline border-b border-white/10 pb-2">
                <span className="font-black text-xl text-emerald-300">
                  {currentWord.word}
                </span>
                <span className="font-bengali font-bold text-amber-300 text-sm">
                  {currentWord.bengali.split('(')[0]}
                </span>
              </div>

              <div className="my-auto space-y-3 font-sans">
                <div>
                  <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">
                    Core Definition:
                  </div>
                  <p className="text-xs text-slate-100 font-medium mt-0.5 leading-snug">
                    {currentWord.simpleDef}
                  </p>
                </div>

                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 font-bengali">
                  <div className="text-[9px] uppercase tracking-wider text-amber-400 font-bold">
                    Mnemonic Hook (মনে রাখার ছন্দ):
                  </div>
                  <p className="text-xs text-slate-200 mt-0.5 leading-relaxed">
                    {currentWord.mnemonicBengali}
                  </p>
                </div>

                <div>
                  <div className="text-[9px] uppercase tracking-wider text-emerald-400 font-bold">
                    Top Collocation:
                  </div>
                  <p className="text-xs text-slate-200 font-mono mt-0.5">
                    {currentWord.quickRevision?.collocation || 'High exam frequency'}
                  </p>
                </div>
              </div>

              <div className="text-center text-[11px] text-slate-400 font-medium">
                Tap card to flip back
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Navigation Arrows & Action Buttons */}
      <div className="w-full space-y-2 pt-2">
        <div className="flex items-center justify-between px-2 text-slate-400 text-xs">
          <button
            onClick={handlePrev}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center gap-1 font-bold text-slate-700 dark:text-slate-300"
          >
            <ChevronLeft className="w-4 h-4" /> Prev
          </button>

          <span className="font-mono font-bold text-[11px]">
            Card {currentIndex + 1}
          </span>

          <button
            onClick={handleNext}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center gap-1 font-bold text-slate-700 dark:text-slate-300"
          >
            Next <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* 3 Cognitive Status Assignment Buttons */}
        <div className="w-full grid grid-cols-3 gap-2">
          <button
            onClick={() => handleCognitiveAction('learn')}
            className="py-3 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-2xl shadow-[0_4px_0_0_#e11d48] flex flex-col items-center justify-center active:translate-y-1 transition-all"
          >
            <span>Need to Learn</span>
            <span className="text-[9px] font-bengali font-normal">গ্রুপ C (নতুন)</span>
          </button>

          <button
            onClick={() => handleCognitiveAction('revise')}
            className="py-3 bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs rounded-2xl shadow-[0_4px_0_0_#d97706] flex flex-col items-center justify-center active:translate-y-1 transition-all"
          >
            <span>Need to Revise</span>
            <span className="text-[9px] font-bengali font-normal">গ্রুপ B (রিভাইজ)</span>
          </button>

          <button
            onClick={() => handleCognitiveAction('mastered')}
            className="py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl shadow-[0_4px_0_0_#059669] flex flex-col items-center justify-center active:translate-y-1 transition-all"
          >
            <span>Already Known</span>
            <span className="text-[9px] font-bengali font-normal">গ্রুপ A (আয়ত্ত)</span>
          </button>
        </div>
      </div>

    </div>
  );
};
