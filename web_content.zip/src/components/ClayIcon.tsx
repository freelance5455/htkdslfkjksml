import { Icon } from "./ui";
import { cn } from "../utils/cn";

export default function ClayIcon({
  kind,
  className,
}: {
  kind: "web" | "dashboard" | "mobile" | "code";
  className?: string;
}) {
  return (
    <div
      aria-hidden="true"
      className={cn("clay-object", `clay-${kind}`, className)}
    >
      {kind === "web" && (
        <>
          <div className="clay-browser-top">
            <i />
            <i />
            <i />
          </div>
          <span className="clay-line" />
          <span className="clay-line short" />
          <div className="clay-web-block" />
        </>
      )}
      {kind === "dashboard" && (
        <>
          <div className="clay-grid-block one" />
          <div className="clay-grid-block two" />
          <div className="clay-grid-block three" />
          <div className="clay-grid-block four" />
        </>
      )}
      {kind === "mobile" && (
        <>
          <div className="clay-phone-screen">
            <span />
            <span />
            <span />
          </div>
          <div className="clay-home" />
        </>
      )}
      {kind === "code" && <Icon name="code" className="h-[38px] w-[38px]" />}
    </div>
  );
}
