import { useEffect, useState } from "react";
import {
  BookOpen,
  ChevronLeft,
  Copy,
  Download,
  FileUp,
  FolderOpen,
  Plus,
  Printer,
  Save,
  School,
  Sparkles,
  Trash2,
  Upload,
} from "lucide-react";
import {
  COLUMNS,
  type SchemeDocument,
  type SchoolInfo,
  type Topic,
  type WeekRow,
  applyHomework,
  blankTopic,
  blankWeek,
  buildDocument,
  defaultInfo,
  documentFromRows,
  endtermRow,
  formatStamp,
  generateCustomScheme,
  generateMyScheme,
  interpretTable,
  loadStore,
  mergeInfo,
  midtermRow,
  parseDelimitedTable,
  parseSyllabus,
  rowsToUnits,
  sampleMathTopics,
  saveStore,
  schemeName,
  schemeToCsv,
  schemeToHtml,
  schemeToPlain,
  schemeToWord,
  scrapeInfo,
  stampDates,
  topicsFromRows,
  topicsToUnits,
  safeFileName,
} from "@/lib/scheme";
import { FILE_ACCEPT, readTeacherFile, tablesFromHtml } from "@/lib/read-files";

type View = "home" | "info" | "create" | "my" | "syllabus" | "existing" | "saved" | "export" | "editor";

const inputClass =
  "min-h-12 w-full rounded-xl border border-line bg-card px-3 py-2 text-base text-ink outline-none focus:border-blue";
const areaClass =
  "min-h-28 w-full rounded-xl border border-line bg-card px-3 py-2 text-base leading-normal text-ink outline-none focus:border-blue";

const INFO_LABELS: { key: keyof SchoolInfo; label: string }[] = [
  { key: "ministry", label: "Ministry" },
  { key: "school", label: "School" },
  { key: "teacher", label: "Teacher" },
  { key: "subject", label: "Subject" },
  { key: "className", label: "Class" },
  { key: "term", label: "Term" },
  { key: "year", label: "Year" },
  { key: "department", label: "Department" },
];

function Field({
  label,
  value,
  onChange,
  placeholder,
  area,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  area?: boolean;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-bold text-blue">{label}</span>
      {area ? (
        <textarea className={areaClass} value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} />
      ) : (
        <input className={inputClass} type={type} value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} />
      )}
    </label>
  );
}

function InfoFields({
  info,
  onChange,
  showWeeks,
}: {
  info: SchoolInfo;
  onChange: (patch: Partial<SchoolInfo>) => void;
  showWeeks?: boolean;
}) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <Field label="Ministry of Education" value={info.ministry} onChange={(ministry) => onChange({ ministry })} placeholder="MINISTRY OF EDUCATION" />
      </div>
      <div className="sm:col-span-2">
        <Field label="School name" value={info.school} onChange={(school) => onChange({ school })} placeholder="Type the school name" />
      </div>
      <Field label="Teacher's name" value={info.teacher} onChange={(teacher) => onChange({ teacher })} placeholder="Your name" />
      <Field label="Subject" value={info.subject} onChange={(subject) => onChange({ subject })} placeholder="e.g. Mathematics" />
      <Field label="Class or grade" value={info.className} onChange={(className) => onChange({ className })} placeholder="e.g. Grade 10 or Form 4" />
      <Field label="Term" value={info.term} onChange={(term) => onChange({ term })} placeholder="e.g. 1" />
      <Field label="Year" value={info.year} onChange={(year) => onChange({ year })} placeholder="2026" />
      <Field label="Department" value={info.department} onChange={(department) => onChange({ department })} placeholder="e.g. Mathematics" />
      {showWeeks ? (
        <label className="block">
          <span className="mb-1 block text-sm font-bold text-blue">Number of weeks</span>
          <input
            className={inputClass}
            type="number"
            min={1}
            max={20}
            value={info.weeks}
            onChange={(event) => onChange({ weeks: Math.min(20, Math.max(1, Number(event.target.value) || 1)) })}
          />
        </label>
      ) : null}
      <label className="block">
        <span className="mb-1 block text-sm font-bold text-blue">Date Week 1 begins</span>
        <input className={inputClass} type="date" value={info.startDate} onChange={(event) => onChange({ startDate: event.target.value })} />
      </label>
    </div>
  );
}

function ReadLimits() {
  return (
    <div className="rounded-2xl border border-line bg-gold-soft p-4 text-sm leading-normal text-ink">
      <p className="font-bold text-gold-deep">What can be read on this device</p>
      <p className="mt-1">
        Pasted text, .txt, .csv, Word (.docx) and Excel (.xlsx) can be read here. A typed PDF can be read when it contains real text. A scanned PDF or a photo of a page cannot — this app has no OCR. Old Word files (.doc) need to be saved as .docx, or pasted below. If a file looks wrong, correct it in the box. The app will not invent missing syllabus content.
      </p>
    </div>
  );
}

function TopicCard({
  topic,
  onChange,
  onDelete,
}: {
  topic: Topic;
  onChange: (patch: Partial<Topic>) => void;
  onDelete: () => void;
}) {
  return (
    <article className="rounded-2xl border border-line bg-card p-4">
      <div className="flex items-start gap-3">
        <input
          type="checkbox"
          className="mt-3 size-5 accent-green"
          checked={topic.selected}
          onChange={(event) => onChange({ selected: event.target.checked })}
          aria-label={`Include ${topic.name || "topic"}`}
        />
        <div className="grid flex-1 gap-3 sm:grid-cols-[5rem_1fr]">
          <Field label="No." value={topic.number} onChange={(number) => onChange({ number })} placeholder="1" />
          <Field label="Topic" value={topic.name} onChange={(name) => onChange({ name })} placeholder="Topic name" />
        </div>
      </div>
      <div className="mt-3">
        <Field label="Subtopics (one on each line)" value={topic.subtopics} onChange={(subtopics) => onChange({ subtopics })} area placeholder={"The Cartesian plane\nGradient of a straight line"} />
      </div>
      <details className="mt-3">
        <summary className="min-h-12 cursor-pointer py-2 font-bold text-blue">Competencies, activities, aids and references</summary>
        <div className="grid gap-3 pt-2">
          <Field label="Specific competencies" value={topic.competencies} onChange={(competencies) => onChange({ competencies })} area placeholder="Leave blank to get an editable suggestion later" />
          <Field label="Learning outcomes or expected standards" value={topic.outcomes} onChange={(outcomes) => onChange({ outcomes })} area />
          <Field label="Teaching activities, if the syllabus gives them" value={topic.activities} onChange={(activities) => onChange({ activities })} area />
          <Field label="Teaching and learning aids" value={topic.aids} onChange={(aids) => onChange({ aids })} area />
          <Field label="References" value={topic.references} onChange={(references) => onChange({ references })} area />
          {topic.unsorted ? (
            <Field label="Lines that were not labelled — move them if they belong above" value={topic.unsorted} onChange={(unsorted) => onChange({ unsorted })} area />
          ) : null}
        </div>
      </details>
      <button type="button" onClick={onDelete} className="mt-2 inline-flex min-h-12 items-center gap-2 font-bold text-gold-deep">
        <Trash2 className="size-4" />
        Remove topic
      </button>
    </article>
  );
}

function SchemeSheet({ info, rows }: { info: SchoolInfo; rows: WeekRow[] }) {
  const pairs: [string, string][] = [
    ["Teacher", info.teacher],
    ["Subject", info.subject],
    ["Class", info.className],
    ["Term", info.term],
    ["Year", info.year],
    ["Department", info.department],
  ];
  return (
    <article className="bg-paper text-ink">
      <header className="mb-4 text-center">
        <p className="text-sm font-bold uppercase tracking-wide">{info.ministry.trim() || "MINISTRY OF EDUCATION"}</p>
        <p className="mt-1 font-display text-2xl font-bold uppercase">{info.school.trim() || " "}</p>
        <p className="mt-1 text-sm font-bold tracking-wide">SCHEME OF WORK</p>
        <dl className="mx-auto mt-3 grid max-w-3xl grid-cols-2 gap-x-6 gap-y-1 text-left text-sm">
          {pairs.map(([label, value]) => (
            <div key={label}>
              <dt className="inline font-bold">{label}: </dt>
              <dd className="inline">{value}</dd>
            </div>
          ))}
        </dl>
      </header>
      <table className="scheme-table">
        <thead>
          <tr>
            {COLUMNS.map((column) => (
              <th key={column.key}>{column.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className={`kind-${row.kind}`}>
              {COLUMNS.map((column) => (
                <td key={column.key}>{String(row[column.key] ?? "")}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </article>
  );
}

export function SchemeApp() {
  const [view, setView] = useState<View>("home");
  const [info, setInfo] = useState<SchoolInfo>(defaultInfo);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [current, setCurrent] = useState<SchemeDocument | null>(null);
  const [saved, setSaved] = useState<SchemeDocument[]>([]);
  const [syllabusText, setSyllabusText] = useState("");
  const [schemeText, setSchemeText] = useState("");
  const [uploadedRows, setUploadedRows] = useState<WeekRow[]>([]);
  const [foundInfo, setFoundInfo] = useState<Partial<SchoolInfo>>({});
  const [infoTicks, setInfoTicks] = useState<Record<string, boolean>>({});
  const [banner, setBanner] = useState("");
  const [warn, setWarn] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [busy, setBusy] = useState(false);
  const [useMyRules, setUseMyRules] = useState(true);
  const [homeworkOn, setHomeworkOn] = useState(true);

  useEffect(() => {
    const stored = loadStore();
    if (stored) {
      setInfo(stored.info);
      setTopics(stored.topics);
      setCurrent(stored.current);
      setSaved(stored.saved);
      setSyllabusText(stored.syllabusText);
      setSchemeText(stored.schemeText);
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    const timer = window.setTimeout(() => {
      saveStore({ info, topics, current, saved, syllabusText, schemeText });
    }, 350);
    return () => window.clearTimeout(timer);
  }, [hydrated, info, topics, current, saved, syllabusText, schemeText]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [view]);

  function flash(message: string, tone: "ok" | "warn" = "ok") {
    setBanner(message);
    setWarn(tone === "warn");
  }

  function go(next: View) {
    setView(next);
  }

  function patchInfo(patch: Partial<SchoolInfo>) {
    setInfo((prev) => ({ ...prev, ...patch }));
    setCurrent((prev) => (prev ? { ...prev, info: { ...prev.info, ...patch }, name: schemeName({ ...prev.info, ...patch }) } : prev));
  }

  function patchTopic(id: string, patch: Partial<Topic>) {
    setTopics((prev) => prev.map((topic) => (topic.id === id ? { ...topic, ...patch } : topic)));
  }

  function applyFoundInfo(): SchoolInfo {
    const keys = (Object.keys(foundInfo) as (keyof SchoolInfo)[]).filter((key) => infoTicks[key] !== false);
    return mergeInfo(info, foundInfo, keys);
  }

  function selectedTopics(): Topic[] {
    const chosen = topics.filter((topic) => topic.selected && topic.name.trim());
    return chosen.length ? chosen : topics.filter((topic) => topic.name.trim());
  }

  async function handleFile(file: File, target: "syllabus" | "scheme") {
    setBusy(true);
    flash("Reading the file…");
    try {
      const result = await readTeacherFile(file);
      const table = result.tables.length ? result.tables : tablesFromHtml(result.html);
      const interpreted = interpretTable(table.length ? table : parseDelimitedTable(result.text));
      const syllabus = parseSyllabus(result.text);
      setFoundInfo(scrapeInfo(result.text));
      setInfoTicks({});
      if (target === "syllabus") {
        setSyllabusText(result.text);
        const nextTopics = syllabus.topics.length ? syllabus.topics : interpreted.topics;
        if (nextTopics.length) setTopics(nextTopics);
        flash([result.warning, nextTopics.length ? syllabus.note || interpreted.note : syllabus.note].filter(Boolean).join(" "), result.warning ? "warn" : "ok");
      } else {
        setSchemeText(result.text);
        setUploadedRows(interpreted.rows);
        const nextTopics = interpreted.topics.length ? interpreted.topics : syllabus.topics;
        if (nextTopics.length) setTopics(nextTopics);
        const note = [result.warning, interpreted.note, !interpreted.rows.length ? syllabus.note : ""].filter(Boolean).join(" ");
        flash(note || "File read. Check the preview and tick what you want to keep.", result.warning ? "warn" : "ok");
      }
    } catch {
      flash("That file could not be read. Paste the text into the box instead.", "warn");
    } finally {
      setBusy(false);
    }
  }

  function reread(target: "syllabus" | "scheme") {
    const text = target === "syllabus" ? syllabusText : schemeText;
    const syllabus = parseSyllabus(text);
    const interpreted = interpretTable(parseDelimitedTable(text));
    setFoundInfo(scrapeInfo(text));
    if (target === "syllabus") {
      if (syllabus.topics.length || interpreted.topics.length) setTopics(syllabus.topics.length ? syllabus.topics : interpreted.topics);
      flash(syllabus.note, syllabus.topics.length ? "ok" : "warn");
      return;
    }
    setUploadedRows(interpreted.rows);
    const nextTopics = interpreted.topics.length ? interpreted.topics : syllabus.topics;
    if (nextTopics.length) setTopics(nextTopics);
    flash([interpreted.note, syllabus.note].filter(Boolean).join(" ") || "Text read.", "ok");
  }

  function loadSample() {
    if (topics.some((topic) => topic.name.trim()) && !window.confirm("Replace the topics on this page with the Mathematics sample? Saved schemes stay as they are.")) return;
    setTopics(sampleMathTopics());
    setInfo((prev) => ({
      ...prev,
      subject: prev.subject.trim() || "Mathematics",
      department: prev.department.trim() || "Mathematics",
    }));
    flash("Sample Mathematics topics are ready. They are only an example — replace them with your real syllabus. Suggested cells are not official wording.");
  }

  function generate(mode: "my-scheme" | "custom") {
    const units = topicsToUnits(topics);
    if (!units.length && !window.confirm("No topics are ticked. Teaching weeks will be left blank. Continue?")) return;
    if (current && !window.confirm("This replaces the scheme that is open now. Save it first if you still need that copy. Continue?")) return;
    const actualMode = mode === "my-scheme" || useMyRules ? "my-scheme" : "custom";
    const nextInfo = actualMode === "my-scheme" ? { ...info, weeks: 13 } : info;
    const generated = actualMode === "my-scheme" ? generateMyScheme(nextInfo, units) : generateCustomScheme(nextInfo, units, homeworkOn);
    setInfo(nextInfo);
    setCurrent(buildDocument(nextInfo, topics, generated, actualMode, syllabusText || schemeText));
    setView("editor");
  }

  function openGeneratedMy() {
    const units = topicsToUnits(topics);
    if (!units.length && !window.confirm("No topics are ticked. Teaching weeks will be left blank. Continue?")) return;
    if (current && !window.confirm("This replaces the scheme that is open now. Save it first if you still need that copy. Continue?")) return;
    const nextInfo = { ...applyFoundInfo(), weeks: 13 };
    const generated = generateMyScheme(nextInfo, units);
    setInfo(nextInfo);
    setCurrent(buildDocument(nextInfo, topics, generated, "my-scheme", schemeText || syllabusText));
    setView("editor");
  }

  function useUploaded(kind: "as-is" | "edit" | "convert" | "fresh") {
    const nextInfo = applyFoundInfo();
    const pickedRows = uploadedRows.filter((row) => row.selected);
    const named = topics.filter((topic) => topic.selected && topic.name.trim());
    if (kind === "fresh") {
      const seed = named.length ? named : topicsFromRows(pickedRows);
      if (!seed.length) {
        flash("Tick at least one topic or row to reuse, or add a topic yourself.", "warn");
        return;
      }
      setInfo(nextInfo);
      setTopics(seed);
      setUseMyRules(true);
      setView("create");
      flash("Ticked items are ready. Check the school details, then build the scheme. Unticked items were not brought in.");
      return;
    }
    if (kind === "convert") {
      const units = pickedRows.length ? rowsToUnits(pickedRows) : topicsToUnits(named);
      if (!units.length && !window.confirm("Nothing was ticked. A blank 13-week MY SCHEME will be created. Continue?")) return;
      const info13 = { ...nextInfo, weeks: 13 };
      const generated = generateMyScheme(info13, units);
      const dropped = uploadedRows.filter((row) => !row.selected).length;
      const notice = `${generated.notice} ${dropped ? `${dropped} unticked row${dropped === 1 ? "" : "s"} were left out. ` : ""}Your original wording is kept under the table. Nothing was deleted without being kept there.`;
      setInfo(info13);
      setCurrent({ ...buildDocument(info13, named.length ? named : topicsFromRows(pickedRows), { ...generated, notice }, "my-scheme", schemeText), notice });
      setView("editor");
      return;
    }
    if (!pickedRows.length && !named.length) {
      flash("Tick the rows or topics you want to keep.", "warn");
      return;
    }
    if (pickedRows.length) {
      const dropped = uploadedRows.length - pickedRows.length;
      const notice =
        kind === "edit"
          ? `Edit any cell, then save. ${dropped ? `${dropped} unticked row${dropped === 1 ? " was" : "s were"} not copied. ` : ""}Original wording is kept under the table.`
          : `The ticked rows were copied as they were. ${dropped ? `${dropped} unticked row${dropped === 1 ? " was" : "s were"} left out. ` : ""}You can still convert this to MY SCHEME.`;
      setInfo(nextInfo);
      setCurrent(documentFromRows(nextInfo, named.length ? named : topicsFromRows(pickedRows), pickedRows, notice, schemeText, "custom"));
      setView("editor");
      return;
    }
    const generated = generateCustomScheme(nextInfo, topicsToUnits(named), false);
    setInfo(nextInfo);
    setCurrent(
      buildDocument(
        nextInfo,
        named,
        {
          ...generated,
          notice: "No table was found, so the topics were placed week by week. Use Convert to MY SCHEME if you want the 13-week rules.",
        },
        "custom",
        schemeText,
      ),
    );
    setView("editor");
  }

  function patchRow(id: string, patch: Partial<WeekRow>) {
    setCurrent((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        updatedAt: new Date().toISOString(),
        rows: prev.rows.map((row) => {
          if (row.id !== id) return row;
          const next = { ...row, ...patch };
          if (patch.topic !== undefined) {
            if (/mid-?term/i.test(next.topic)) next.kind = "midterm";
            else if (/end-of-term|end of term/i.test(next.topic)) next.kind = "endterm";
            else if (row.kind === "midterm" || row.kind === "endterm") next.kind = "teach";
          }
          return next;
        }),
      };
    });
  }

  function saveCurrent() {
    if (!current) {
      flash("There is no scheme to save yet.", "warn");
      return;
    }
    const next: SchemeDocument = { ...current, info, name: schemeName(info), updatedAt: new Date().toISOString() };
    setCurrent(next);
    setSaved((list) => {
      const index = list.findIndex((item) => item.id === next.id);
      if (index === -1) return [next, ...list];
      const copy = [...list];
      copy[index] = next;
      return copy;
    });
    flash("Saved on this device. Find it under View saved schemes.");
  }

  function openSaved(doc: SchemeDocument) {
    setCurrent(doc);
    setInfo(doc.info);
    setTopics(doc.topics || []);
    setView("editor");
  }

  function deleteSaved(id: string) {
    const doc = saved.find((item) => item.id === id);
    if (!doc || !window.confirm(`Delete “${doc.name}” from this device?`)) return;
    setSaved((list) => list.filter((item) => item.id !== id));
    if (current?.id === id) setCurrent(null);
    flash("Deleted from this device.");
  }

  async function copyScheme() {
    if (!current) {
      go("export");
      flash("Create or open a scheme first, then copy it.", "warn");
      return;
    }
    const doc = { ...current, info };
    const html = schemeToHtml(doc);
    const text = schemeToPlain(doc);
    try {
      if (typeof ClipboardItem !== "undefined" && navigator.clipboard?.write) {
        await navigator.clipboard.write([
          new ClipboardItem({
            "text/html": new Blob([html], { type: "text/html" }),
            "text/plain": new Blob([text], { type: "text/plain" }),
          }),
        ]);
      } else {
        await navigator.clipboard.writeText(text);
      }
      flash("Copied. Paste it into Word, Google Docs, or a message.");
    } catch {
      flash("The browser blocked copying. Use Download Word document instead.", "warn");
    }
  }

  function downloadWord() {
    if (!current) return;
    const doc = { ...current, info, name: schemeName(info) };
    const blob = new Blob([schemeToWord(doc)], { type: "application/msword" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = safeFileName(info, "doc");
    link.click();
    URL.revokeObjectURL(url);
    flash("Word document downloaded. Open it in Word or Google Docs.");
  }

  function downloadCsv() {
    if (!current) return;
    const doc = { ...current, info };
    const blob = new Blob([schemeToCsv(doc)], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = safeFileName(info, "csv");
    link.click();
    URL.revokeObjectURL(url);
  }

  function printScheme() {
    if (!current) {
      go("export");
      flash("Create or open a scheme first, then print it.", "warn");
      return;
    }
    window.setTimeout(() => window.print(), 200);
  }

  function fillDates() {
    if (!current) return;
    if (!info.startDate) {
      flash("Choose the date Week 1 begins, then tap Fill dates.", "warn");
      return;
    }
    setCurrent({ ...current, info, rows: stampDates(current.rows, info.startDate) });
    flash("Week dates filled from the Week 1 date. You can still edit each one.");
  }

  function restoreRules() {
    if (!current) return;
    if (!window.confirm("Put Week 6 back to the midterm test only, and Week 13 back to end-of-term activities? Other weeks stay. Homework lines are written again.")) return;
    let rows = current.rows.map((row) => {
      if (row.week === 6) {
        const fresh = midtermRow(row.weekText, row.date);
        return { ...fresh, id: row.id };
      }
      if (row.week === 13) {
        const fresh = endtermRow(row.weekText, row.date);
        return { ...fresh, id: row.id };
      }
      return row;
    });
    if (!rows.some((row) => row.week === 6)) rows.push(midtermRow("Week 6", ""));
    if (!rows.some((row) => row.week === 13)) rows.push(endtermRow("Week 13", ""));
    rows = applyHomework(rows.sort((a, b) => a.week - b.week), true);
    setCurrent({
      ...current,
      mode: "my-scheme",
      info: { ...info, weeks: 13 },
      rows,
      notice: "Week 6 is the midterm test again and Week 13 is end-of-term work. Homework was refreshed, including after Week 12. Your other weeks were kept.",
    });
    setInfo((prev) => ({ ...prev, weeks: 13 }));
    flash("MY SCHEME rules restored for Week 6, Week 13 and homework.");
  }

  function addWeek() {
    if (!current) return;
    const week = current.rows.reduce((max, row) => Math.max(max, row.week), 0) + 1;
    setCurrent({ ...current, rows: [...current.rows, blankWeek(week)] });
  }

  function removeWeek(row: WeekRow) {
    if (!current) return;
    const special = current.mode === "my-scheme" && (row.week === 6 || row.week === 13);
    const question = special
      ? `Week ${row.week} follows the MY SCHEME rules. Remove it anyway?`
      : `Remove Week ${row.week} from this scheme?`;
    if (!window.confirm(question)) return;
    setCurrent({ ...current, rows: current.rows.filter((item) => item.id !== row.id) });
  }

  const bannerBox = banner ? (
    <p role="status" className={`rounded-2xl px-4 py-3 text-sm leading-normal ${warn ? "bg-gold-soft text-ink" : "bg-green-soft text-ink"}`}>
      {banner}
    </p>
  ) : null;

  return (
    <div className="min-h-screen bg-bg text-ink">
      <div className="print:hidden">
        <header className="bg-blue text-paper">
          <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-4">
            {view !== "home" ? (
              <button type="button" onClick={() => go("home")} className="grid size-12 place-items-center rounded-xl bg-blue-deep" aria-label="Back to home">
                <ChevronLeft className="size-6" />
              </button>
            ) : (
              <span className="grid size-12 place-items-center rounded-xl bg-gold text-ink">
                <School className="size-6" />
              </span>
            )}
            <div className="min-w-0">
              <p className="font-display text-xl font-bold leading-tight">MY SCHEME GENERATOR</p>
              <p className="text-sm text-gold-soft">Create, Edit, Copy and Print Your Scheme of Work.</p>
            </div>
          </div>
          <div className="h-1 bg-gold" />
        </header>

        <main className="mx-auto grid max-w-5xl gap-4 px-4 py-4">
          {bannerBox}

          {view === "home" ? (
            <>
              <section className="rounded-2xl border border-line bg-card p-5 shadow-sm">
                <p className="text-sm font-bold uppercase tracking-wide text-green">For teachers in Zambia</p>
                <h1 className="mt-1 font-display text-3xl font-bold text-blue">MY SCHEME GENERATOR</h1>
                <p className="mt-2 text-lg leading-snug text-muted">Create, Edit, Copy and Print Your Scheme of Work.</p>
                {current ? (
                  <button type="button" onClick={() => go("editor")} className="mt-4 min-h-12 text-left font-bold text-blue">
                    Continue: {current.name}
                  </button>
                ) : null}
              </section>
              <div className="grid gap-3 sm:grid-cols-2">
                <button type="button" onClick={() => go("create")} className="flex min-h-24 items-center gap-4 rounded-2xl bg-blue px-4 py-4 text-left text-paper sm:col-span-1">
                  <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-paper text-blue"><Plus className="size-6" /></span>
                  <span className="min-w-0"><span className="block text-lg font-bold">CREATE NEW SCHEME</span><span className="text-sm text-gold-soft">Start from your topics and school details.</span></span>
                </button>
                <button type="button" onClick={() => go("my")} className="flex min-h-24 items-center gap-4 rounded-2xl bg-gold px-4 py-4 text-left text-ink">
                  <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-paper text-green"><Sparkles className="size-6" /></span>
                  <span className="min-w-0"><span className="block text-lg font-bold">MY SCHEME</span><span className="text-sm">13 weeks, midterm in Week 6, homework every two weeks.</span></span>
                </button>
                <button type="button" onClick={() => go("syllabus")} className="flex min-h-24 items-center gap-4 rounded-2xl bg-green px-4 py-4 text-left text-paper">
                  <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-paper text-green"><Upload className="size-6" /></span>
                  <span className="min-w-0"><span className="block text-lg font-bold">UPLOAD SYLLABUS</span><span className="text-sm text-gold-soft">Read topics, then choose what to include.</span></span>
                </button>
                <button type="button" onClick={() => go("existing")} className="flex min-h-24 items-center gap-4 rounded-2xl bg-blue-deep px-4 py-4 text-left text-paper">
                  <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-paper text-blue"><FileUp className="size-6" /></span>
                  <span className="min-w-0"><span className="block text-lg font-bold">UPLOAD EXISTING SCHEME</span><span className="text-sm text-gold-soft">Use it, edit it, or convert it to MY SCHEME.</span></span>
                </button>
                <button type="button" onClick={() => go("saved")} className="flex min-h-24 items-center gap-4 rounded-2xl border border-line bg-card px-4 py-4 text-left text-ink">
                  <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-blue-wash text-blue"><FolderOpen className="size-6" /></span>
                  <span className="min-w-0"><span className="block text-lg font-bold">VIEW SAVED SCHEMES</span><span className="text-sm text-muted">Stored on this phone, tablet or computer.</span></span>
                </button>
                <button type="button" onClick={() => go("export")} className="flex min-h-24 items-center gap-4 rounded-2xl bg-gold-soft px-4 py-4 text-left text-ink">
                  <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-paper text-gold-deep"><Copy className="size-6" /></span>
                  <span className="min-w-0"><span className="block text-lg font-bold">COPY OR EXPORT DOCUMENT</span><span className="text-sm text-muted">Copy, or download a Word or Excel-style file.</span></span>
                </button>
                <button type="button" onClick={printScheme} className="flex min-h-24 items-center gap-4 rounded-2xl bg-green-soft px-4 py-4 text-left text-ink sm:col-span-2">
                  <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-paper text-green"><Printer className="size-6" /></span>
                  <span className="min-w-0"><span className="block text-lg font-bold">PRINT SCHEME</span><span className="text-sm text-muted">Print the open scheme, or save it as a PDF from the print box.</span></span>
                </button>
              </div>
              <button type="button" onClick={() => go("info")} className="min-h-12 rounded-2xl border border-line bg-card px-4 text-left font-bold text-blue">
                School and teacher details{info.school.trim() ? `: ${info.school}` : ""}
              </button>
            </>
          ) : null}

          {view === "info" ? (
            <section className="grid gap-4 rounded-2xl border border-line bg-card p-4">
              <h2 className="font-display text-2xl font-bold text-blue">School and teacher details</h2>
              <p className="text-sm leading-normal text-muted">Change these whenever you need to. Nothing is locked to one school.</p>
              <InfoFields info={info} onChange={patchInfo} showWeeks />
              <button type="button" onClick={() => { flash("Details kept on this device."); go("home"); }} className="min-h-12 rounded-xl bg-blue px-4 font-bold text-paper">
                Save details
              </button>
            </section>
          ) : null}

          {view === "create" || view === "my" ? (
            <section className="grid gap-4">
              <div className="rounded-2xl border border-line bg-card p-4">
                <h2 className="font-display text-2xl font-bold text-blue">{view === "my" ? "MY SCHEME" : "Create a new scheme"}</h2>
                {view === "my" ? (
                  <ul className="mt-3 grid gap-2 text-sm leading-normal">
                    <li className="rounded-xl bg-blue-wash px-3 py-2">The scheme covers exactly 13 weeks.</li>
                    <li className="rounded-xl bg-gold-soft px-3 py-2">Week 6 is the midterm test only. No normal topic or subtopic is placed there.</li>
                    <li className="rounded-xl bg-green-soft px-3 py-2">Week 13 is end-of-term activities / test, unless you later edit that row yourself.</li>
                    <li className="rounded-xl bg-blue-wash px-3 py-2">Homework is added after Weeks 2, 4, 6, 8, 10 and 12. Week 12 is included.</li>
                    <li className="rounded-xl bg-card px-3 py-2">The table always has the same eight columns. You can edit every cell after it is built.</li>
                  </ul>
                ) : (
                  <div className="mt-3 grid gap-3">
                    <label className="flex min-h-12 items-center gap-3 text-sm font-bold">
                      <input type="checkbox" className="size-5 accent-green" checked={useMyRules} onChange={(event) => setUseMyRules(event.target.checked)} />
                      Use MY SCHEME rules (13 weeks, midterm in Week 6, end of term in Week 13)
                    </label>
                    {!useMyRules ? (
                      <label className="flex min-h-12 items-center gap-3 text-sm font-bold">
                        <input type="checkbox" className="size-5 accent-green" checked={homeworkOn} onChange={(event) => setHomeworkOn(event.target.checked)} />
                        Add homework in Learning Activities after every two weeks
                      </label>
                    ) : null}
                  </div>
                )}
              </div>
              <div className="rounded-2xl border border-line bg-card p-4">
                <h3 className="font-bold text-blue">School and teacher</h3>
                <div className="mt-3">
                  <InfoFields info={info} onChange={patchInfo} showWeeks={view === "create" && !useMyRules} />
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={() => setTopics((prev) => [...prev, blankTopic()])} className="inline-flex min-h-12 items-center gap-2 rounded-xl bg-green px-4 font-bold text-paper">
                  <Plus className="size-5" /> Add a topic
                </button>
                <button type="button" onClick={loadSample} className="inline-flex min-h-12 items-center gap-2 rounded-xl bg-gold px-4 font-bold text-ink">
                  <BookOpen className="size-5" /> Sample Mathematics topics
                </button>
                <button type="button" onClick={() => go("syllabus")} className="inline-flex min-h-12 items-center gap-2 rounded-xl border border-line bg-card px-4 font-bold text-blue">
                  <Upload className="size-5" /> Use an uploaded syllabus
                </button>
              </div>
              {topics.length === 0 ? (
                <p className="rounded-2xl border border-dashed border-line bg-card px-4 py-6 text-sm text-muted">No topics yet. Add your own, or load the sample to see the shape of a scheme. Topics are not invented for you.</p>
              ) : (
                topics.map((topic) => (
                  <TopicCard
                    key={topic.id}
                    topic={topic}
                    onChange={(patch) => patchTopic(topic.id, patch)}
                    onDelete={() => setTopics((prev) => prev.filter((item) => item.id !== topic.id))}
                  />
                ))
              )}
              <button
                type="button"
                onClick={() => (view === "my" ? openGeneratedMy() : generate(useMyRules ? "my-scheme" : "custom"))}
                className="min-h-14 rounded-2xl bg-blue px-4 text-lg font-bold text-paper"
              >
                {view === "my" || useMyRules ? "Build MY SCHEME" : "Build scheme"}
              </button>
            </section>
          ) : null}

          {view === "syllabus" ? (
            <section className="grid gap-4">
              <div className="rounded-2xl border border-line bg-card p-4">
                <h2 className="font-display text-2xl font-bold text-blue">UPLOAD SYLLABUS</h2>
                <p className="mt-2 text-sm leading-normal text-muted">Choose a file or paste the syllabus. Tick the topics you want, and correct any mistakes before you build the scheme.</p>
              </div>
              <ReadLimits />
              <label className="flex min-h-28 cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-blue bg-blue-wash px-4 py-5 text-center">
                <Upload className="size-7 text-blue" />
                <span className="text-base font-bold text-blue">{busy ? "Reading…" : "Tap to choose a syllabus file"}</span>
                <input
                  className="sr-only"
                  type="file"
                  accept={FILE_ACCEPT}
                  disabled={busy}
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (file) void handleFile(file, "syllabus");
                    event.target.value = "";
                  }}
                />
              </label>
              <label className="block">
                <span className="mb-1 block text-sm font-bold text-blue">Or paste the syllabus text</span>
                <textarea className={areaClass} value={syllabusText} onChange={(event) => setSyllabusText(event.target.value)} placeholder="Paste the syllabus here, then tap Read this text." />
              </label>
              <button type="button" onClick={() => reread("syllabus")} className="min-h-12 rounded-xl bg-green px-4 font-bold text-paper">
                Read this text
              </button>
              <p className="text-sm font-bold text-muted">{selectedTopics().length} topic{selectedTopics().length === 1 ? "" : "s"} ready</p>
              {topics.map((topic) => (
                <TopicCard key={topic.id} topic={topic} onChange={(patch) => patchTopic(topic.id, patch)} onDelete={() => setTopics((prev) => prev.filter((item) => item.id !== topic.id))} />
              ))}
              <div className="grid gap-2 sm:grid-cols-2">
                <button type="button" onClick={() => go("my")} className="min-h-12 rounded-xl bg-gold px-4 font-bold text-ink">Use ticked topics in MY SCHEME</button>
                <button type="button" onClick={() => { setUseMyRules(false); go("create"); }} className="min-h-12 rounded-xl bg-blue px-4 font-bold text-paper">Use ticked topics in a new scheme</button>
              </div>
            </section>
          ) : null}

          {view === "existing" ? (
            <section className="grid gap-4">
              <div className="rounded-2xl border border-line bg-card p-4">
                <h2 className="font-display text-2xl font-bold text-blue">UPLOAD EXISTING SCHEME</h2>
                <p className="mt-2 text-sm leading-normal text-muted">Start from a scheme you already have. Tick only the parts you want to reuse. Your original wording is kept when you convert.</p>
              </div>
              <ReadLimits />
              <label className="flex min-h-28 cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-green bg-green-soft px-4 py-5 text-center">
                <FileUp className="size-7 text-green" />
                <span className="text-base font-bold text-green">{busy ? "Reading…" : "Tap to choose a scheme file"}</span>
                <input
                  className="sr-only"
                  type="file"
                  accept={FILE_ACCEPT}
                  disabled={busy}
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (file) void handleFile(file, "scheme");
                    event.target.value = "";
                  }}
                />
              </label>
              <label className="block">
                <span className="mb-1 block text-sm font-bold text-blue">Or paste the scheme</span>
                <textarea className={areaClass} value={schemeText} onChange={(event) => setSchemeText(event.target.value)} placeholder="Paste the scheme here, then tap Read this text." />
              </label>
              <button type="button" onClick={() => reread("scheme")} className="min-h-12 rounded-xl bg-green px-4 font-bold text-paper">Read this text</button>
              {Object.keys(foundInfo).length ? (
                <div className="rounded-2xl border border-line bg-card p-4">
                  <h3 className="font-bold text-blue">Details found in the file</h3>
                  <p className="mt-1 text-sm text-muted">Untick anything you do not want copied onto your scheme.</p>
                  <div className="mt-3 grid gap-2">
                    {(Object.keys(foundInfo) as (keyof SchoolInfo)[]).map((key) => (
                      <label key={key} className="flex min-h-12 items-center gap-3 text-sm">
                        <input
                          type="checkbox"
                          className="size-5 accent-green"
                          checked={infoTicks[key] !== false}
                          onChange={(event) => setInfoTicks((prev) => ({ ...prev, [key]: event.target.checked }))}
                        />
                        <span><strong>{INFO_LABELS.find((item) => item.key === key)?.label || key}: </strong>{String(foundInfo[key])}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ) : null}
              {uploadedRows.length ? (
                <div className="grid gap-2">
                  <h3 className="font-bold text-blue">Rows found — tick what to reuse</h3>
                  {uploadedRows.map((row) => (
                    <label key={row.id} className="flex gap-3 rounded-2xl border border-line bg-card p-3">
                      <input
                        type="checkbox"
                        className="mt-1 size-5 accent-green"
                        checked={row.selected}
                        onChange={(event) => setUploadedRows((prev) => prev.map((item) => (item.id === row.id ? { ...item, selected: event.target.checked } : item)))}
                      />
                      <span className="text-sm leading-normal">
                        <span className="font-bold">Week {row.week}: {row.topic || "No topic"}</span>
                        {row.subtopic ? <span className="mt-1 block text-muted">{row.subtopic}</span> : null}
                      </span>
                    </label>
                  ))}
                </div>
              ) : null}
              {topics.length ? (
                <div className="grid gap-3">
                  <h3 className="font-bold text-blue">Topics you can reuse</h3>
                  {topics.map((topic) => (
                    <TopicCard key={topic.id} topic={topic} onChange={(patch) => patchTopic(topic.id, patch)} onDelete={() => setTopics((prev) => prev.filter((item) => item.id !== topic.id))} />
                  ))}
                </div>
              ) : null}
              <div className="grid gap-2">
                <button type="button" onClick={() => useUploaded("as-is")} className="min-h-12 rounded-xl bg-blue px-4 text-left font-bold text-paper">A. USE AS IT IS</button>
                <button type="button" onClick={() => useUploaded("edit")} className="min-h-12 rounded-xl bg-blue-deep px-4 text-left font-bold text-paper">B. EDIT EXISTING SCHEME</button>
                <button type="button" onClick={() => useUploaded("convert")} className="min-h-12 rounded-xl bg-gold px-4 text-left font-bold text-ink">C. CONVERT TO MY SCHEME</button>
                <button type="button" onClick={() => useUploaded("fresh")} className="min-h-12 rounded-xl bg-green px-4 text-left font-bold text-paper">D. CREATE A NEW SCHEME FROM IT</button>
              </div>
            </section>
          ) : null}

          {view === "saved" ? (
            <section className="grid gap-3">
              <h2 className="font-display text-2xl font-bold text-blue">Saved schemes</h2>
              {saved.length === 0 ? <p className="rounded-2xl border border-dashed border-line bg-card px-4 py-6 text-sm text-muted">Nothing is saved yet. Build a scheme, then tap Save scheme. It stays on this device.</p> : null}
              {saved.map((doc) => (
                <article key={doc.id} className="rounded-2xl border border-line bg-card p-4">
                  <h3 className="font-bold text-ink">{doc.name}</h3>
                  <p className="text-sm text-muted">{doc.info.school || "No school name"} · {formatStamp(doc.updatedAt)} · {doc.mode === "my-scheme" ? "MY SCHEME" : "Custom"}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" onClick={() => openSaved(doc)} className="min-h-12 rounded-xl bg-blue px-4 font-bold text-paper">Open</button>
                    <button
                      type="button"
                      onClick={() => {
                        const copy: SchemeDocument = { ...doc, id: `${doc.id}-copy`, name: `${doc.name} copy`, rows: doc.rows.map((row) => ({ ...row, id: `${row.id}c` })), updatedAt: new Date().toISOString() };
                        setSaved((list) => [copy, ...list]);
                        flash("A copy was saved on this device.");
                      }}
                      className="min-h-12 rounded-xl border border-line bg-paper px-4 font-bold text-blue"
                    >
                      Duplicate
                    </button>
                    <button type="button" onClick={() => deleteSaved(doc.id)} className="min-h-12 rounded-xl bg-gold-soft px-4 font-bold text-ink">Delete</button>
                  </div>
                </article>
              ))}
            </section>
          ) : null}

          {view === "export" ? (
            <section className="grid gap-4">
              <h2 className="font-display text-2xl font-bold text-blue">Copy or export</h2>
              {current ? (
                <>
                  <p className="text-sm text-muted">Open scheme: {schemeName(info)}</p>
                  <div className="grid gap-2 sm:grid-cols-2">
                    <button type="button" onClick={() => void copyScheme()} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-blue px-4 font-bold text-paper"><Copy className="size-5" /> Copy scheme</button>
                    <button type="button" onClick={downloadWord} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-green px-4 font-bold text-paper"><Download className="size-5" /> Download Word</button>
                    <button type="button" onClick={downloadCsv} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-gold px-4 font-bold text-ink"><Download className="size-5" /> Download CSV</button>
                    <button type="button" onClick={printScheme} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-blue-deep px-4 font-bold text-paper"><Printer className="size-5" /> Print</button>
                  </div>
                  <button type="button" onClick={() => go("editor")} className="min-h-12 font-bold text-blue">Edit this scheme first</button>
                </>
              ) : (
                <p className="rounded-2xl border border-dashed border-line bg-card px-4 py-6 text-sm text-muted">There is no scheme open. Create one, or open a saved scheme, then come back to copy or export it.</p>
              )}
              <a href="/my-scheme-generator.html" download="MY-SCHEME-GENERATOR.html" className="inline-flex min-h-12 items-center gap-2 font-bold text-green">
                <Download className="size-5" /> Download this app as one HTML file for offline use
              </a>
            </section>
          ) : null}

          {view === "editor" && current ? (
            <section className="grid gap-4">
              <div className="rounded-2xl border border-line bg-card p-4 text-center">
                <p className="text-sm font-bold uppercase tracking-wide text-blue">{info.ministry.trim() || "MINISTRY OF EDUCATION"}</p>
                <div className="mx-auto mt-2 max-w-xl">
                  <Field label="School name" value={info.school} onChange={(school) => patchInfo({ school })} placeholder="Type the school name" />
                </div>
                <p className="mt-3 text-sm font-bold tracking-wide">SCHEME OF WORK</p>
                <p className="mt-1 text-sm text-muted">Change any detail. Nothing is locked.</p>
              </div>
              <InfoFields info={info} onChange={patchInfo} showWeeks={current.mode !== "my-scheme"} />
              {current.notice ? <p className="rounded-2xl bg-blue-wash px-4 py-3 text-sm leading-normal">{current.notice}</p> : null}
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={saveCurrent} className="inline-flex min-h-12 items-center gap-2 rounded-xl bg-green px-4 font-bold text-paper"><Save className="size-5" /> Save scheme</button>
                <button type="button" onClick={() => void copyScheme()} className="inline-flex min-h-12 items-center gap-2 rounded-xl bg-blue px-4 font-bold text-paper"><Copy className="size-5" /> Copy</button>
                <button type="button" onClick={downloadWord} className="inline-flex min-h-12 items-center gap-2 rounded-xl bg-blue-deep px-4 font-bold text-paper"><Download className="size-5" /> Word</button>
                <button type="button" onClick={downloadCsv} className="inline-flex min-h-12 items-center gap-2 rounded-xl bg-gold px-4 font-bold text-ink">CSV</button>
                <button type="button" onClick={printScheme} className="inline-flex min-h-12 items-center gap-2 rounded-xl bg-green-soft px-4 font-bold text-ink"><Printer className="size-5" /> Print</button>
                <button type="button" onClick={fillDates} className="min-h-12 rounded-xl border border-line bg-card px-4 font-bold text-blue">Fill dates</button>
                <button type="button" onClick={restoreRules} className="min-h-12 rounded-xl border border-line bg-gold-soft px-4 font-bold text-ink">Restore Week 6 and 13</button>
              </div>
              <p className="text-sm text-muted">Homework stays inside Learning Activities. There is no ninth column. On a phone, each week is a card. Swipe is not needed.</p>
              <div className="grid gap-4 md:hidden">
                {current.rows.map((row) => (
                  <WeekCard key={row.id} row={row} onChange={(patch) => patchRow(row.id, patch)} onRemove={() => removeWeek(row)} />
                ))}
              </div>
              <div className="hidden md:block">
                <div className="overflow-x-auto rounded-2xl border border-line">
                  <table className="scheme-table">
                    <thead>
                      <tr>
                        {COLUMNS.map((column) => (
                          <th key={column.key}>{column.label}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {current.rows.map((row) => (
                        <tr key={row.id} className={`kind-${row.kind}`}>
                          {COLUMNS.map((column) => (
                            <td key={column.key}>
                              <textarea
                                className="min-h-28 w-full bg-transparent text-sm leading-normal text-ink outline-none"
                                aria-label={`${column.label}, week ${row.week}`}
                                value={String(row[column.key] ?? "")}
                                onChange={(event) => patchRow(row.id, { [column.key]: event.target.value } as Partial<WeekRow>)}
                              />
                              {column.key === "weekText" ? (
                                <button type="button" onClick={() => removeWeek(row)} className="min-h-12 font-bold text-gold-deep">
                                  Remove week
                                </button>
                              ) : null}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <button type="button" onClick={addWeek} className="min-h-12 rounded-xl border border-dashed border-blue bg-card font-bold text-blue">Add a week</button>
              {current.originalText ? (
                <details className="rounded-2xl border border-line bg-card p-4">
                  <summary className="min-h-12 cursor-pointer font-bold text-blue">Original wording from your file</summary>
                  <pre className="mt-3 max-h-80 overflow-auto whitespace-pre-wrap text-sm">{current.originalText}</pre>
                </details>
              ) : null}
            </section>
          ) : null}

          <footer className="pb-6 text-sm leading-normal text-muted">
            <p>Your schemes stay on this device. They are not sent anywhere.</p>
            <a className="mt-2 inline-flex min-h-12 items-center font-bold text-blue" href="/my-scheme-generator.html" download="MY-SCHEME-GENERATOR.html">
              Download one HTML file to use offline
            </a>
          </footer>
        </main>
      </div>
      {current ? (
        <div className="hidden print:block">
          <SchemeSheet info={info} rows={current.rows} />
        </div>
      ) : null}
    </div>
  );
}

function WeekCard({ row, onChange, onRemove }: { row: WeekRow; onChange: (patch: Partial<WeekRow>) => void; onRemove: () => void }) {
  const tone = row.kind === "midterm" ? "border-gold bg-gold-soft" : row.kind === "endterm" ? "border-green bg-green-soft" : row.kind === "consolidation" ? "border-blue bg-blue-wash" : "border-line bg-card";
  return (
    <article className={`grid gap-3 rounded-2xl border-2 p-4 ${tone}`}>
      <div className="flex items-center justify-between gap-2">
        <h3 className="font-bold text-blue">Week {row.week}</h3>
        <button type="button" onClick={onRemove} className="inline-flex min-h-12 items-center gap-1 font-bold text-gold-deep">
          <Trash2 className="size-4" /> Remove
        </button>
      </div>
      {COLUMNS.map((column) => (
        <label key={column.key} className="block">
          <span className="mb-1 block text-sm font-bold text-blue">{column.label}</span>
          <textarea
            className={areaClass}
            value={String(row[column.key] ?? "")}
            aria-label={`${column.label}, week ${row.week}`}
            onChange={(event) => onChange({ [column.key]: event.target.value })}
          />
        </label>
      ))}
    </article>
  );
}
