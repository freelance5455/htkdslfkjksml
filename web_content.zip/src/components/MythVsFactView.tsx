import React, { useState, useEffect } from 'react';
import {
  Search,
  Heart,
  Bookmark,
  Share2,
  Globe,
  XCircle,
  CheckCircle2,
  BookOpen,
  Lightbulb,
  Sparkles,
  ChevronRight,
  Check,
  Flame,
  ShieldCheck,
  X,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopAppBar } from './TopAppBar';
import { MythLanguage, MythCategoryMeta, MythItem } from '../types/myth';
import { ReadAloudButton } from './ReadAloudButton';
import { PreferredLanguage } from '../types';
import {
  MYTH_CATEGORIES,
  ALL_MYTHS,
  getMythsByCategory,
  searchMyths,
  getMythOfTheDay
} from '../data/mythData';

interface MythVsFactViewProps {
  onBack: () => void;
}

export const MythVsFactView: React.FC<MythVsFactViewProps> = ({ onBack }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<MythLanguage>('English');
  const [activeTab, setActiveTab] = useState<'categories' | 'saved' | 'search'>('categories');
  const [selectedCategory, setSelectedCategory] = useState<MythCategoryMeta | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Local storage bookmarks state
  const [savedMythIds, setSavedMythIds] = useState<string[]>([]);
  const [favoriteMythIds, setFavoriteMythIds] = useState<string[]>([]);
  const [copiedShareId, setCopiedShareId] = useState<string | null>(null);

  // Myth of the Day
  const dailyMyth = getMythOfTheDay();

  // Load saved/favorited myths from LocalStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('mediguide_saved_myths_v1');
      if (saved) setSavedMythIds(JSON.parse(saved));

      const favs = localStorage.getItem('mediguide_favorite_myths_v1');
      if (favs) setFavoriteMythIds(JSON.parse(favs));
    } catch (e) {
      console.warn('Failed to load saved myths:', e);
    }
  }, []);

  // Save bookmarked myths
  const toggleSaveMyth = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    let updated: string[];
    if (savedMythIds.includes(id)) {
      updated = savedMythIds.filter((item) => item !== id);
    } else {
      updated = [...savedMythIds, id];
    }
    setSavedMythIds(updated);
    try {
      localStorage.setItem('mediguide_saved_myths_v1', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to persist saved myths:', e);
    }
  };

  // Toggle Favorite
  const toggleFavoriteMyth = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    let updated: string[];
    if (favoriteMythIds.includes(id)) {
      updated = favoriteMythIds.filter((item) => item !== id);
    } else {
      updated = [...favoriteMythIds, id];
    }
    setFavoriteMythIds(updated);
    try {
      localStorage.setItem('mediguide_favorite_myths_v1', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to persist favorite myths:', e);
    }
  };

  // Share card handler
  const handleShareMyth = async (myth: MythItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const content = myth.content[selectedLanguage] || myth.content.English;
    const text = `❌ MYTH: ${content.myth}\n\n✅ FACT: ${content.fact}\n\n📖 EXPLANATION: ${content.explanation}\n\n💡 TIP: ${content.healthTip}\n\n📚 Ref: ${content.reference} (via MediGuide AI Health)`;

    if (navigator.share) {
      try {
        await navigator.share({ title: 'Myth vs Fact - MediGuide AI', text });
        return;
      } catch (err) {
        // Fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(text);
      setCopiedShareId(myth.id);
      setTimeout(() => setCopiedShareId(null), 2000);
    } catch (err) {
      console.warn('Clipboard copy failed:', err);
    }
  };

  // Determine list of displayed myths
  const getDisplayedMyths = (): MythItem[] => {
    if (activeTab === 'saved') {
      return ALL_MYTHS.filter((m) => savedMythIds.includes(m.id) || favoriteMythIds.includes(m.id));
    }

    if (searchQuery.trim().length > 0) {
      return searchMyths(searchQuery, selectedLanguage);
    }

    if (selectedCategory) {
      return getMythsByCategory(selectedCategory.id);
    }

    return ALL_MYTHS;
  };

  const displayedMyths = getDisplayedMyths();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      <TopAppBar
        title="Myth vs Fact"
        subtitle="Medically Verified Health Misconceptions"
        onBack={
          selectedCategory
            ? () => setSelectedCategory(null)
            : activeTab !== 'categories'
            ? () => setActiveTab('categories')
            : onBack
        }
        badge="Material Design 3"
        badgeColor="bg-rose-100 text-rose-800 border-rose-200"
      />

      <div className="p-4 max-w-4xl mx-auto w-full space-y-5">
        {/* Top Control Bar: Search & Language Switcher */}
        <div className="bg-white p-3 sm:p-4 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (e.target.value.trim().length > 0 && activeTab !== 'search') {
                    setActiveTab('search');
                  } else if (e.target.value.trim().length === 0 && activeTab === 'search') {
                    setActiveTab('categories');
                  }
                }}
                placeholder={
                  selectedLanguage === 'Hindi'
                    ? 'बीमारी, दवा या पोषण संबंधी खोजें...'
                    : selectedLanguage === 'Marathi'
                    ? 'आजार, औषध किंवा आहाराविषयी शोधा...'
                    : 'Search by disease, medicine, nutrition, keyword...'
                }
                className="w-full pl-10 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded-full"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Language Switcher */}
            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl border border-slate-200 shrink-0">
              <Globe className="w-3.5 h-3.5 text-rose-600 ml-1.5 hidden sm:block" />
              {(['English', 'Hindi', 'Marathi'] as MythLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setSelectedLanguage(lang)}
                  className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    selectedLanguage === lang
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Navigation: Categories vs Bookmarks */}
          <div className="flex items-center gap-2 pt-1 border-t border-slate-100 text-xs">
            <button
              onClick={() => {
                setActiveTab('categories');
                setSelectedCategory(null);
                setSearchQuery('');
              }}
              className={`px-4 py-2 rounded-xl font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'categories' && !selectedCategory
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <span>Explore Categories</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('saved');
                setSelectedCategory(null);
              }}
              className={`px-4 py-2 rounded-xl font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'saved'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
              <span>
                Saved & Favorites ({savedMythIds.length + favoriteMythIds.length})
              </span>
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* HERO BANNER: DAILY MYTH OF THE DAY */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'categories' && !selectedCategory && !searchQuery && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-slate-900 via-indigo-950 to-rose-950 text-white p-6 rounded-3xl shadow-xl space-y-4 border border-slate-800 relative overflow-hidden"
          >
            <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-3">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-[11px] font-black uppercase tracking-wider border border-rose-500/30">
                <Flame className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
                <span>Myth of the Day</span>
              </div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                Medically Verified Today
              </span>
            </div>

            {(() => {
              const content = dailyMyth.content[selectedLanguage] || dailyMyth.content.English;
              const isSaved = savedMythIds.includes(dailyMyth.id);
              const isFav = favoriteMythIds.includes(dailyMyth.id);

              return (
                <div className="space-y-4">
                  {/* Myth & Fact Split */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-4 rounded-2xl bg-red-950/60 border border-red-500/30 text-red-100 space-y-1">
                      <p className="text-[11px] font-black uppercase tracking-wider text-red-400 flex items-center gap-1">
                        <XCircle className="w-4 h-4 text-red-400" />
                        <span>❌ Myth</span>
                      </p>
                      <p className="text-xs sm:text-sm font-bold leading-relaxed">{content.myth}</p>
                    </div>

                    <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-100 space-y-1">
                      <p className="text-[11px] font-black uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>✅ Fact</span>
                      </p>
                      <p className="text-xs sm:text-sm font-bold leading-relaxed">{content.fact}</p>
                    </div>
                  </div>

                  {/* Explanation & Tip */}
                  <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 text-xs">
                    <div className="flex items-start gap-2 text-blue-200">
                      <BookOpen className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                      <p className="leading-relaxed"><strong className="text-blue-300 font-extrabold">Detailed Explanation: </strong>{content.explanation}</p>
                    </div>

                    <div className="flex items-start gap-2 text-amber-200 pt-1 border-t border-white/10">
                      <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <p className="leading-relaxed"><strong className="text-amber-300 font-extrabold">Health Tip: </strong>{content.healthTip}</p>
                    </div>
                  </div>

                  {/* Footer & Actions */}
                  <div className="flex items-center justify-between text-[11px] pt-1">
                    <div className="flex items-center gap-1 text-slate-300 font-bold">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Reference: {content.reference}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <ReadAloudButton
                        id={`daily-myth-${dailyMyth.id}`}
                        text={`Myth: ${content.myth}. Fact: ${content.fact}. Explanation: ${content.explanation}. Health Tip: ${content.healthTip}.`}
                        language={selectedLanguage as PreferredLanguage}
                        variant="pill"
                        className="bg-white/20 hover:bg-white/30 text-white border border-white/20 rounded-xl"
                      />

                      <button
                        onClick={(e) => toggleFavoriteMyth(dailyMyth.id, e)}
                        className={`p-2 rounded-xl transition-all cursor-pointer ${
                          isFav ? 'bg-rose-600 text-white' : 'bg-white/10 hover:bg-white/20 text-slate-200'
                        }`}
                        title="Favorite"
                      >
                        <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-white' : ''}`} />
                      </button>

                      <button
                        onClick={(e) => toggleSaveMyth(dailyMyth.id, e)}
                        className={`p-2 rounded-xl transition-all cursor-pointer ${
                          isSaved ? 'bg-amber-500 text-white' : 'bg-white/10 hover:bg-white/20 text-slate-200'
                        }`}
                        title="Save for Later"
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-white' : ''}`} />
                      </button>

                      <button
                        onClick={(e) => handleShareMyth(dailyMyth, e)}
                        className="px-3 py-1.5 bg-white text-slate-900 font-black rounded-xl hover:bg-slate-100 transition-all cursor-pointer flex items-center gap-1"
                      >
                        {copiedShareId === dailyMyth.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
                        <span>{copiedShareId === dailyMyth.id ? 'Copied' : 'Share'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })()}
          </motion.div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 1: CATEGORY GRID (HOME VIEW) */}
        {/* ------------------------------------------------------------- */}
        {activeTab === 'categories' && !selectedCategory && !searchQuery && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
                {selectedLanguage === 'Hindi'
                  ? 'स्वास्थ्य श्रेणी चुनें (Myth Categories)'
                  : selectedLanguage === 'Marathi'
                  ? 'श्रेणी निवडा (Myth Categories)'
                  : 'Myth Categories'}
              </h3>
              <span className="text-xs text-rose-600 font-bold">10 Categories Available</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {MYTH_CATEGORIES.map((cat) => {
                const title =
                  selectedLanguage === 'Hindi'
                    ? cat.nameHi
                    : selectedLanguage === 'Marathi'
                    ? cat.nameMr
                    : cat.nameEn;

                const desc =
                  selectedLanguage === 'Hindi'
                    ? cat.descriptionHi
                    : selectedLanguage === 'Marathi'
                    ? cat.descriptionMr
                    : cat.descriptionEn;

                const count = getMythsByCategory(cat.id).length;

                return (
                  <motion.div
                    key={cat.id}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    onClick={() => setSelectedCategory(cat)}
                    className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-rose-400 hover:shadow-md transition-all cursor-pointer flex items-start justify-between gap-4 group"
                  >
                    <div className="flex items-start gap-3.5">
                      <div
                        className={`w-12 h-12 rounded-2xl ${cat.iconBg} text-white flex items-center justify-center text-2xl shadow-inner shrink-0 group-hover:scale-110 transition-transform`}
                      >
                        <span>{cat.emoji}</span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-sm text-slate-900 group-hover:text-rose-700 transition-colors">
                            {title}
                          </h4>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black border ${cat.badgeBg}`}>
                            {count} Myths
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 leading-relaxed font-medium line-clamp-2">{desc}</p>
                      </div>
                    </div>

                    <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center shrink-0 group-hover:bg-rose-600 group-hover:text-white transition-colors">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 2: CATEGORY FILTERED OR SEARCH OR SAVED CARDS LIST */}
        {/* ------------------------------------------------------------- */}
        {(selectedCategory || activeTab === 'saved' || searchQuery.trim().length > 0) && (
          <div className="space-y-4">
            {/* List Header */}
            <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
              <div className="flex items-center gap-3">
                {selectedCategory ? (
                  <div className={`w-10 h-10 rounded-xl ${selectedCategory.iconBg} text-white flex items-center justify-center text-xl shadow-xs`}>
                    <span>{selectedCategory.emoji}</span>
                  </div>
                ) : (
                  <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center text-xl shadow-xs">
                    {activeTab === 'saved' ? <Bookmark className="w-5 h-5 text-amber-400 fill-amber-400" /> : <Search className="w-5 h-5" />}
                  </div>
                )}

                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">
                    {selectedCategory
                      ? selectedLanguage === 'Hindi'
                        ? selectedCategory.nameHi
                        : selectedLanguage === 'Marathi'
                        ? selectedCategory.nameMr
                        : selectedCategory.nameEn
                      : activeTab === 'saved'
                      ? 'Saved & Favorite Myths'
                      : `Search Results for "${searchQuery}"`}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Showing {displayedMyths.length} medically verified myth vs fact cards
                  </p>
                </div>
              </div>

              {selectedCategory && (
                <button
                  onClick={() => setSelectedCategory(null)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-all cursor-pointer"
                >
                  View All Categories
                </button>
              )}
            </div>

            {/* Empty state when no cards match */}
            {displayedMyths.length === 0 && (
              <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                  <Info className="w-8 h-8" />
                </div>
                <h4 className="font-extrabold text-slate-800 text-sm">No Myths Found</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {activeTab === 'saved'
                    ? 'You have not bookmarked any Myth vs Fact cards yet. Click the heart or bookmark icon on any card to save it here.'
                    : 'Try searching with a different keyword like "dengue", "antibiotics", "fever", or "sugar".'}
                </p>
              </div>
            )}

            {/* List of Myth vs Fact Cards */}
            <div className="space-y-4">
              {displayedMyths.map((myth) => {
                const content = myth.content[selectedLanguage] || myth.content.English;
                const isSaved = savedMythIds.includes(myth.id);
                const isFav = favoriteMythIds.includes(myth.id);

                return (
                  <motion.div
                    key={myth.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white rounded-3xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all overflow-hidden"
                  >
                    {/* Top Red (Myth) and Green (Fact) Split Section */}
                    <div className="p-5 space-y-3">
                      {/* RED = MYTH */}
                      <div className="p-4 rounded-2xl bg-red-50 border border-red-200 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-black uppercase tracking-wider text-red-700 flex items-center gap-1.5">
                            <XCircle className="w-4 h-4 text-red-600" />
                            <span>❌ Myth</span>
                          </span>
                          <span className="text-[10px] text-red-500 font-bold uppercase">Common Misconception</span>
                        </div>
                        <p className="text-xs sm:text-sm font-bold text-red-950 leading-snug">{content.myth}</p>
                      </div>

                      {/* GREEN = FACT */}
                      <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-black uppercase tracking-wider text-emerald-700 flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            <span>✅ Fact</span>
                          </span>
                          <span className="text-[10px] text-emerald-600 font-bold uppercase">Medical Science</span>
                        </div>
                        <p className="text-xs sm:text-sm font-bold text-emerald-950 leading-snug">{content.fact}</p>
                      </div>

                      {/* BLUE = DETAILED EXPLANATION */}
                      <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 space-y-1">
                        <span className="text-[11px] font-black uppercase tracking-wider text-blue-700 flex items-center gap-1.5">
                          <BookOpen className="w-4 h-4 text-blue-600" />
                          <span>📖 Detailed Explanation</span>
                        </span>
                        <p className="text-xs text-blue-950 font-medium leading-relaxed">{content.explanation}</p>
                      </div>

                      {/* ORANGE = HEALTH TIP */}
                      <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-1">
                        <span className="text-[11px] font-black uppercase tracking-wider text-amber-800 flex items-center gap-1.5">
                          <Lightbulb className="w-4 h-4 text-amber-600" />
                          <span>💡 Health Tip</span>
                        </span>
                        <p className="text-xs text-amber-950 font-medium leading-relaxed">{content.healthTip}</p>
                      </div>
                    </div>

                    {/* Card Footer with Trusted Reference & Action Buttons */}
                    <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                      {/* TRUSTED MEDICAL REFERENCE */}
                      <div className="flex items-center gap-1.5 text-slate-600 font-extrabold text-[11px]">
                        <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>📚 Reference: <span className="text-slate-900">{content.reference}</span></span>
                      </div>

                      {/* ACTIONS */}
                      <div className="flex items-center gap-2 ml-auto">
                        <button
                          onClick={(e) => toggleFavoriteMyth(myth.id, e)}
                          className={`p-2 rounded-xl transition-all cursor-pointer border ${
                            isFav
                              ? 'bg-rose-600 text-white border-rose-600'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                          title="Favorite"
                        >
                          <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-white' : ''}`} />
                        </button>

                        <button
                          onClick={(e) => toggleSaveMyth(myth.id, e)}
                          className={`p-2 rounded-xl transition-all cursor-pointer border ${
                            isSaved
                              ? 'bg-amber-500 text-white border-amber-500'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                          title="Save for Later"
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-white' : ''}`} />
                        </button>

                        <button
                          onClick={(e) => handleShareMyth(myth, e)}
                          className="px-3.5 py-2 bg-slate-900 hover:bg-black text-white font-black rounded-xl transition-all cursor-pointer flex items-center gap-1.5 text-[11px] shadow-2xs"
                        >
                          {copiedShareId === myth.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Copied!</span>
                            </>
                          ) : (
                            <>
                              <Share2 className="w-3.5 h-3.5 text-slate-300" />
                              <span>Share</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
