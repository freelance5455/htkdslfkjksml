import React from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Plus,
  Flame,
  Cake,
  Heart,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { CalendarDay, HebrewEvent, LocationPreset, UserSettings } from '../types';
import { getMonthDays, UpcomingHolidayCountdown, isDayAssociatedWithUpcomingHoliday } from '../services/hebrewCalendarService';
import { getTranslations } from '../services/i18n';

interface CalendarMonthViewProps {
  currentDate: Date;
  onDateChange?: (date: Date) => void;
  days?: CalendarDay[];
  selectedDay?: CalendarDay | null;
  selectedDate?: Date;
  onSelectDay: (day: CalendarDay) => void;
  location: LocationPreset;
  events?: HebrewEvent[];
  settings?: UserSettings;
  onUpdateSettings?: (newSettings: Partial<UserSettings>) => void;
  onOpenAddEvent: (defaultDate?: CalendarDay) => void;
  upcomingHoliday?: UpcomingHolidayCountdown | null;
}

const WEEKDAYS = [
  { en: 'Sun', he: 'ראשון' },
  { en: 'Mon', he: 'שני' },
  { en: 'Tue', he: 'שלישי' },
  { en: 'Wed', he: 'רביעי' },
  { en: 'Thu', he: 'חמישי' },
  { en: 'Fri', he: 'שישי' },
  { en: 'Sat', he: 'שַׁבָּת' },
];

export const CalendarMonthView: React.FC<CalendarMonthViewProps> = ({
  currentDate,
  onDateChange,
  days: propDays,
  selectedDay,
  selectedDate,
  onSelectDay,
  location,
  events = [],
  settings,
  onOpenAddEvent,
  upcomingHoliday,
}) => {
  const t = getTranslations(settings?.language || 'en');
  const isRtl = (settings?.language || 'en') === 'he';

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const days = propDays || getMonthDays(year, month, location, events);

  // Month navigation
  const prevMonth = () => {
    if (onDateChange) {
      onDateChange(new Date(year, month - 1, 1));
    }
  };

  const nextMonth = () => {
    if (onDateChange) {
      onDateChange(new Date(year, month + 1, 1));
    }
  };

  const prevYear = () => {
    if (onDateChange) {
      onDateChange(new Date(year - 1, month, 1));
    }
  };

  const nextYear = () => {
    if (onDateChange) {
      onDateChange(new Date(year + 1, month, 1));
    }
  };

  const goToToday = () => {
    if (onDateChange) {
      onDateChange(new Date());
    }
  };

  const gregorianMonthName = currentDate.toLocaleDateString(
    isRtl ? 'he-IL' : 'en-US',
    {
      month: 'long',
      year: 'numeric',
    }
  );

  // Calculate the primary Hebrew month represented in this calendar view
  const middleDay = days[Math.floor(days.length / 2)] || days[0];
  const hebrewMonthOverview = middleDay
    ? `${middleDay.hebrewMonthNameHe} ${middleDay.hebrewYearLetters}`
    : '';

  const touchStartX = React.useRef<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diffX = touchStartX.current - touchEndX;
    const minSwipeDistance = 50;

    if (Math.abs(diffX) > minSwipeDistance) {
      if (diffX > 0) {
        nextMonth();
      } else {
        prevMonth();
      }
    }
    touchStartX.current = null;
  };

  return (
    <div 
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className="bg-[#121212] rounded-xl border border-[#2A2A2A] shadow-2xl overflow-hidden select-none touch-pan-y"
    >
      {/* Month Header Banner */}
      <div className="p-6 sm:p-8 border-b border-[#2A2A2A] flex flex-col sm:flex-row items-center justify-between gap-6 bg-[#161616]">
        {/* Left: Hebrew Month title in Gold & English Month Subtitle on ONE LINE */}
        <div className="flex flex-row items-baseline gap-3 flex-wrap">
          <h2 className="text-2xl sm:text-3xl font-serif font-medium text-[#C5A267] tracking-tight font-serif-hebrew" dir="rtl">
            {hebrewMonthOverview}
          </h2>
          <span className="text-sm font-medium text-[#888888] whitespace-nowrap">
            ({gregorianMonthName})
          </span>
        </div>

        {/* Right: Controls (Previous, Today, Next, Add Event) */}
        <div className="flex items-center gap-3">
          <button
            id="today-btn"
            onClick={goToToday}
            className="px-4 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs sm:text-sm font-medium text-[#D1D1D1] transition-colors"
          >
            {t.today}
          </button>
          <div className="flex items-center rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] p-0.5">
            <button
              id="prev-year-btn"
              onClick={prevYear}
              className="p-1.5 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
              title={isRtl ? "שנה קודמת" : "Previous Year"}
            >
              <ChevronsLeft className="w-4 h-4" />
            </button>
            <button
              id="prev-month-btn"
              onClick={prevMonth}
              className="p-1.5 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
              title={t.previousMonth}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              id="next-month-btn"
              onClick={nextMonth}
              className="p-1.5 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
              title={t.nextMonth}
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              id="next-year-btn"
              onClick={nextYear}
              className="p-1.5 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
              title={isRtl ? "שנה הבאה" : "Next Year"}
            >
              <ChevronsRight className="w-4 h-4" />
            </button>
          </div>
          <button
            id="add-event-quick-btn"
            onClick={() => onOpenAddEvent(selectedDay || undefined)}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs sm:text-sm font-bold shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addEvent}</span>
          </button>
        </div>
      </div>

      {/* Weekday Header */}
      <div className="grid grid-cols-7 border-b border-[#2A2A2A] bg-[#161616]">
        {WEEKDAYS.map((wd, i) => (
          <div
            key={wd.en}
            className={`py-3.5 px-2 text-center border-r last:border-r-0 border-[#2A2A2A] ${
              i === 6 ? 'bg-[#1a1610]/40' : ''
            }`}
          >
            <div
              className={`text-xs uppercase tracking-widest font-semibold ${
                i === 6 ? 'text-[#C5A267]' : 'text-[#555555]'
              }`}
            >
              {wd.en}
            </div>
            <div className="text-[10px] text-[#444444] font-hebrew mt-0.5" dir="rtl">
              {wd.he}
            </div>
          </div>
        ))}
      </div>

      {/* Calendar Grid (Days) */}
      <div className="grid grid-cols-7 gap-px bg-[#2A2A2A]">
        {days.map((day, idx) => {
          const isCurrentMonth = day.gregorianDate.getMonth() === month;
          const isSelected =
            (selectedDay && selectedDay.dateKey === day.dateKey) ||
            (selectedDate &&
              selectedDate.getFullYear() === day.gregorianDate.getFullYear() &&
              selectedDate.getMonth() === day.gregorianDate.getMonth() &&
              selectedDate.getDate() === day.gregorianDate.getDate());

          const isShabbat = day.isShabbat;
          const isErevShabbat = day.isErevShabbat;
          const hasMajorHoliday = day.isMajorHoliday;
          const hasHoliday = day.holidays.length > 0;
          const isUpcomingHolidayDay = isDayAssociatedWithUpcomingHoliday(day, upcomingHoliday);

          // Determine Elegant Dark cell gradient/background & highlight
          let cellBg = 'bg-[#121212]';
          if (!isCurrentMonth) {
            cellBg = 'bg-[#121212] opacity-30';
          } else if (isUpcomingHolidayDay) {
            // Subtle gold background indicator for the upcoming major holiday
            cellBg = 'bg-gradient-to-br from-[#241c10] via-[#1c160d] to-[#121212]';
          } else if (hasMajorHoliday) {
            cellBg = 'bg-gradient-to-br from-[#1a1610] to-[#251f14]';
          } else if (hasHoliday || isErevShabbat) {
            cellBg = 'bg-gradient-to-br from-[#121212] to-[#1a1610]';
          } else if (isShabbat) {
            cellBg = 'bg-[#141414]';
          } else if (day.isToday) {
            cellBg = 'bg-[#1A1A1A]';
          }

          return (
            <div
              key={day.dateKey + '_' + idx}
              onClick={() => onSelectDay(day)}
              className={`h-28 sm:h-32 md:h-36 p-2 sm:p-3 transition-all flex flex-col justify-between relative cursor-pointer group select-none ${cellBg} ${
                isSelected
                  ? 'ring-2 ring-[#C5A267] ring-inset z-20 bg-[#1A1A1A]'
                  : isUpcomingHolidayDay && isCurrentMonth
                  ? 'ring-1 ring-[#C5A267]/60 border border-[#C5A267]/40 shadow-[inset_0_0_15px_rgba(197,162,103,0.12)] z-10'
                  : 'hover:bg-[#181818]'
              }`}
            >
              {/* Day Header: Secular Number on left/right & Hebrew Number in Gematriya */}
              <div className="flex items-start justify-between">
                {/* Secular Gregorian Date */}
                <span
                  className={`text-xs ${
                    day.isToday
                      ? 'text-white font-bold'
                      : isUpcomingHolidayDay && isCurrentMonth
                      ? 'text-[#C5A267] font-semibold'
                      : !isCurrentMonth
                      ? 'text-[#444444]'
                      : 'text-[#666666]'
                  }`}
                >
                  {day.gregorianDate.getDate()}
                </span>

                {/* Hebrew Date Number in Gematriya */}
                <div className="flex items-center gap-1">
                  <span
                    dir="rtl"
                    className={`text-sm sm:text-base font-serif-hebrew font-bold ${
                      day.isToday
                        ? 'text-[#C5A267] font-extrabold'
                        : isUpcomingHolidayDay && isCurrentMonth
                        ? 'text-[#E5C287] font-extrabold'
                        : !isCurrentMonth
                        ? 'text-[#444444]'
                        : isShabbat
                        ? 'text-[#EAEAEA]'
                        : 'text-[#D1D1D1]'
                    }`}
                  >
                    {day.hebrewDayLetters}
                  </span>
                  {(day.hebrewDay === 1 || day.isRoshChodesh) && isCurrentMonth && (
                    <span className="text-[10px] text-[#C5A267] font-hebrew font-medium hidden sm:inline" dir="rtl">
                      {day.hebrewMonthNameHe}
                    </span>
                  )}
                </div>
              </div>

              {/* Day Content: Holiday Badges, Torah Parasha, Events */}
              <div className="flex flex-col gap-1 my-1 overflow-hidden">
                {/* Holidays */}
                {day.holidays.map((h, hIdx) => {
                  const isPesachOrMajor =
                    h.category === 'major' || h.name.toLowerCase().includes('pesach');
                  const isHighlightedUpcoming = isUpcomingHolidayDay && isCurrentMonth;

                  return (
                    <div
                      key={hIdx}
                      className={`py-0.5 px-2 rounded-xs border-l-2 text-[10px] truncate font-medium transition-all ${
                        isHighlightedUpcoming
                          ? 'bg-[#2b2112] border-l-[#C5A267] border border-[#C5A267]/50 text-[#FCD34D] shadow-xs'
                          : isPesachOrMajor
                          ? 'bg-[#251f14] border-l-[#FCD34D] text-[#FCD34D]'
                          : h.category === 'fast'
                          ? 'bg-[#261317] border-l-rose-500 text-rose-400'
                          : 'bg-[#1A1A1A] border-l-[#C5A267] text-[#C5A267]'
                      }`}
                      title={isRtl ? h.hebrewName : `${h.name} (${h.hebrewName})`}
                      dir={isRtl ? 'rtl' : 'ltr'}
                    >
                      <span className="truncate">
                        {isRtl ? h.hebrewName : h.name}
                      </span>
                    </div>
                  );
                })}

                {/* Shabbat Parasha Reading */}
                {isShabbat && day.parasha && (
                  <div
                    className="py-0.5 px-2 rounded-xs bg-[#16202e] border-l-2 border-blue-400 text-[10px] text-blue-300 truncate font-medium flex items-center gap-1"
                    title={isRtl ? day.parasha.hebrewName : day.parasha.name}
                    dir={isRtl ? 'rtl' : 'ltr'}
                  >
                    <BookOpen className="w-2.5 h-2.5 shrink-0 text-blue-400" />
                    <span className="truncate">
                      {isRtl 
                        ? (day.parasha.hebrewName || day.parasha.name.replace('Parashat ', 'פרשת ')) 
                        : day.parasha.name.replace('Parashat ', '')}
                    </span>
                  </div>
                )}

                {/* Omer Count */}
                {day.omer && (
                  <div className="text-[10px] text-[#C5A267] font-medium truncate" dir="rtl">
                    🌾 {day.omer.textHe}
                  </div>
                )}

                {/* Personal Hebrew Events */}
                {day.events.map((ev) => (
                  <div
                    key={ev.id}
                    className="py-0.5 px-2 rounded-xs bg-[#1A1A1A] text-[10px] text-[#D1D1D1] border-l-2 truncate flex items-center gap-1"
                    style={{ borderLeftColor: ev.color || '#C5A267' }}
                    title={isRtl ? (ev.displayHebrewTitle || ev.displayTitle || ev.title) : `${ev.displayTitle || ev.title} (${ev.type})`}
                    dir={isRtl ? 'rtl' : 'ltr'}
                  >
                    {ev.type === 'yahrzeit' ? (
                      <Flame className="w-2.5 h-2.5 shrink-0 text-blue-400" />
                    ) : ev.type === 'birthday' ? (
                      <Cake className="w-2.5 h-2.5 shrink-0 text-[#C5A267]" />
                    ) : (
                      <Sparkles className="w-2.5 h-2.5 shrink-0 text-emerald-400" />
                    )}
                    <span className="truncate">
                      {isRtl ? (ev.displayHebrewTitle || ev.displayTitle || ev.title) : (ev.displayTitle || ev.title)}
                    </span>
                  </div>
                ))}
              </div>

              {/* Day Footer: Indicator Dot / Candle Lighting / Havdalah */}
              <div className="flex items-center justify-between mt-auto pt-1 border-t border-[#2A2A2A]/40 text-[10px] text-[#666666]">
                {isErevShabbat && day.candleLighting ? (
                  <span className="text-[#FCD34D] font-medium flex items-center gap-0.5">
                    🕯️ {day.candleLighting}
                  </span>
                ) : isShabbat && day.havdalah ? (
                  <span className="text-blue-300 font-medium flex items-center gap-0.5">
                    🍷 {day.havdalah}
                  </span>
                ) : (
                  <span className="text-[9px] text-[#555555] font-hebrew truncate" dir="rtl">
                    {day.hebrewMonthNameHe}
                  </span>
                )}

                {/* Today gold indicator dot / upcoming holiday star */}
                {day.isToday ? (
                  <div className="flex gap-1 items-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#C5A267]"></div>
                  </div>
                ) : isUpcomingHolidayDay && isCurrentMonth ? (
                  <div className="flex gap-1 items-center" title={isRtl ? 'מועד חג קרוב' : 'Upcoming Holiday'}>
                    <div className="w-1.5 h-1.5 rounded-full bg-[#C5A267] animate-pulse"></div>
                  </div>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
