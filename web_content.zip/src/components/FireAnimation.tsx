import React, { useState } from 'react';
import { Flame, Trash2, ShieldCheck, Sparkles, X } from 'lucide-react';

interface FireAnimationProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmBurn: () => void;
  tabCount: number;
}

export const FireAnimation: React.FC<FireAnimationProps> = ({
  isOpen,
  onClose,
  onConfirmBurn,
  tabCount,
}) => {
  const [isBurning, setIsBurning] = useState(false);

  if (!isOpen) return null;

  const handleExecuteBurn = () => {
    setIsBurning(true);
    // Let the burning flame particle effect play for 1.2s before executing the shredder callback
    setTimeout(() => {
      onConfirmBurn();
      setIsBurning(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md px-4 select-none">
      {isBurning ? (
        /* Cinematic Burning Ember Screen */
        <div className="relative w-full max-w-sm p-8 rounded-3xl bg-gradient-to-b from-orange-950 via-slate-950 to-black border border-orange-600/50 shadow-2xl flex flex-col items-center justify-center text-center overflow-hidden">
          {/* Animated Glow Rings */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-orange-600/30 via-transparent to-transparent animate-pulse" />

          {/* Ember particles simulation */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="absolute top-1/2 left-1/4 w-2 h-2 rounded-full bg-orange-400 animate-ping opacity-75" />
            <div className="absolute top-1/3 right-1/4 w-3 h-3 rounded-full bg-amber-400 animate-bounce opacity-80" />
            <div className="absolute bottom-1/3 left-1/3 w-2 h-2 rounded-full bg-red-500 animate-pulse opacity-90" />
          </div>

          <div className="relative z-10 p-5 rounded-full bg-orange-900/60 border border-orange-500/80 mb-4 shadow-xl animate-bounce">
            <Flame className="w-12 h-12 text-orange-400 fill-orange-500 animate-pulse" />
          </div>

          <h3 className="relative z-10 text-xl font-bold text-white mb-1">
            Incinerating Session...
          </h3>
          <p className="relative z-10 text-xs text-orange-200/80 font-mono">
            Shredding {tabCount} tabs, cookies, cache & RAM
          </p>
        </div>
      ) : (
        /* Confirmation Dialog */
        <div className="w-full max-w-sm bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden p-6 animate-scale-in">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-orange-950/70 border border-orange-700/50 text-orange-400">
                <Flame className="w-6 h-6 fill-orange-500/20" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-100">Burn Browsing Data</h3>
                <p className="text-xs text-slate-400">Instant Ephemeral Shredder</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-2.5 my-4 text-xs text-slate-300">
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start gap-2.5">
              <Trash2 className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
              <span>
                Close all <strong>{tabCount} open tab{tabCount !== 1 ? 's' : ''}</strong> and destroy active DOM memory.
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                Purge site cookies, HTTP cache, localStorage, and clipboard traces.
              </span>
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <button
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 font-semibold text-xs active:scale-95 transition-all"
            >
              Cancel
            </button>
            <button
              id="confirm-burn-btn"
              onClick={handleExecuteBurn}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold text-xs shadow-lg shadow-orange-900/40 active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              <Flame className="w-3.5 h-3.5 fill-white" />
              <span>Burn Data</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
