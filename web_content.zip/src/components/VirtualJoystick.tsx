import React, { useRef, useState, useEffect } from 'react';

interface VirtualJoystickProps {
  onMove: (x: number, y: number) => void;
  onJump: () => void;
  onInteract: () => void;
  onRunToggle: (running: boolean) => void;
  isRunning: boolean;
  canInteract: boolean;
  interactLabel?: string;
}

export const VirtualJoystick: React.FC<VirtualJoystickProps> = ({
  onMove,
  onJump,
  onInteract,
  onRunToggle,
  isRunning,
  canInteract,
  interactLabel = 'Interact',
}) => {
  const stickRef = useRef<HTMLDivElement>(null);
  const [touchPos, setTouchPos] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const touchIdRef = useRef<number | null>(null);
  const centerRef = useRef({ x: 0, y: 0 });

  const maxRadius = 45;

  const handleTouchStart = (e: React.TouchEvent) => {
    if (touchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    touchIdRef.current = touch.identifier;
    setIsDragging(true);

    if (stickRef.current) {
      const rect = stickRef.current.getBoundingClientRect();
      centerRef.current = {
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === touchIdRef.current) {
        const dx = touch.clientX - centerRef.current.x;
        const dy = touch.clientY - centerRef.current.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const clampedDist = Math.min(dist, maxRadius);
        const angle = Math.atan2(dy, dx);

        const nx = Math.cos(angle) * clampedDist;
        const ny = Math.sin(angle) * clampedDist;

        setTouchPos({ x: nx, y: ny });

        // Normalize output between -1 and 1
        const normalizedX = nx / maxRadius;
        const normalizedY = ny / maxRadius;
        onMove(normalizedX, normalizedY);
        break;
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchIdRef.current) {
        touchIdRef.current = null;
        setIsDragging(false);
        setTouchPos({ x: 0, y: 0 });
        onMove(0, 0);
        break;
      }
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none z-30 select-none">
      {/* Left Virtual Joystick */}
      <div
        ref={stickRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={handleTouchEnd}
        className="pointer-events-auto absolute bottom-8 left-6 w-32 h-32 rounded-full bg-slate-900/60 border-2 border-amber-400/40 flex items-center justify-center touch-none"
      >
        <div
          style={{
            transform: `translate(${touchPos.x}px, ${touchPos.y}px)`,
          }}
          className={`w-14 h-14 rounded-full ${
            isDragging ? 'bg-amber-400 scale-110' : 'bg-amber-500/80'
          } shadow-lg border-2 border-white/60 transition-transform duration-75 flex items-center justify-center text-xs font-bold text-slate-950`}
        >
          MOVE
        </div>
      </div>

      {/* Right Action Buttons */}
      <div className="pointer-events-auto absolute bottom-8 right-6 flex flex-col items-end gap-3">
        {/* Interact Button (Shown brightly when near target) */}
        <button
          onClick={onInteract}
          className={`px-5 py-3 rounded-2xl font-bold shadow-xl border-2 flex items-center gap-2 active:scale-95 transition-all ${
            canInteract
              ? 'bg-amber-500 text-slate-950 border-white ring-4 ring-amber-400/50'
              : 'bg-slate-800/80 text-amber-200/60 border-amber-500/20'
          }`}
        >
          <span className="text-lg">⭐</span>
          <span className="text-sm uppercase tracking-wide">{interactLabel} [E]</span>
        </button>

        <div className="flex items-center gap-3">
          {/* Sprint Run Button */}
          <button
            onClick={() => onRunToggle(!isRunning)}
            className={`w-14 h-14 rounded-full font-bold text-xs uppercase shadow-lg border-2 flex items-center justify-center active:scale-95 transition-all ${
              isRunning
                ? 'bg-orange-500 text-white border-white ring-2 ring-orange-300'
                : 'bg-slate-800/80 text-amber-200 border-amber-500/30'
            }`}
          >
            RUN
          </button>

          {/* Jump Button */}
          <button
            onClick={onJump}
            className="w-16 h-16 rounded-full bg-sky-500 hover:bg-sky-400 active:scale-90 text-white font-extrabold text-sm shadow-xl border-2 border-white flex flex-col items-center justify-center transition-transform"
          >
            <span>JUMP</span>
            <span className="text-[10px] text-sky-100">SPACE</span>
          </button>
        </div>
      </div>
    </div>
  );
};
