import React, { useRef, useState, useEffect } from 'react';

interface VirtualJoystickProps {
  onMove: (vector: { x: number; y: number }) => void;
}

export const VirtualJoystick: React.FC<VirtualJoystickProps> = ({ onMove }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [touchId, setTouchId] = useState<number | null>(null);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const [isActive, setIsActive] = useState(false);

  const radius = 45; // Maximum travel radius

  const handleTouchStart = (e: React.TouchEvent) => {
    e.stopPropagation();
    if (touchId !== null) return;
    const touch = e.changedTouches[0];
    setTouchId(touch.identifier);
    setIsActive(true);
    updateVector(touch.clientX, touch.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    e.stopPropagation();
    if (touchId === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === touchId) {
        updateVector(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    e.stopPropagation();
    if (touchId === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchId) {
        setTouchId(null);
        setIsActive(false);
        setKnobPos({ x: 0, y: 0 });
        onMove({ x: 0, y: 0 });
        break;
      }
    }
  };

  const updateVector = (clientX: number, clientY: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const dist = Math.hypot(dx, dy);

    if (dist === 0) {
      setKnobPos({ x: 0, y: 0 });
      onMove({ x: 0, y: 0 });
      return;
    }

    const clampedDist = Math.min(dist, radius);
    const normX = dx / dist;
    const normY = dy / dist;

    setKnobPos({
      x: normX * clampedDist,
      y: normY * clampedDist,
    });

    onMove({
      x: (normX * clampedDist) / radius,
      y: (normY * clampedDist) / radius,
    });
  };

  useEffect(() => {
    const handleGlobalEnd = () => {
      setTouchId(null);
      setIsActive(false);
      setKnobPos({ x: 0, y: 0 });
      onMove({ x: 0, y: 0 });
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (isActive && touchId === -99) {
        updateVector(e.clientX, e.clientY);
      }
    };
    const handleMouseUp = () => {
      if (isActive && touchId === -99) {
        handleGlobalEnd();
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('touchend', handleGlobalEnd);
    window.addEventListener('touchcancel', handleGlobalEnd);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchend', handleGlobalEnd);
      window.removeEventListener('touchcancel', handleGlobalEnd);
    };
  }, [isActive, touchId, onMove]);

  const handleMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsActive(true);
    setTouchId(-99);
    updateVector(e.clientX, e.clientY);
  };

  return (
    <div
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchEnd}
      className="relative w-28 h-28 rounded-full bg-slate-900/60 backdrop-blur-xs border-2 border-slate-600/60 flex items-center justify-center select-none touch-none shadow-xl pointer-events-auto"
    >
      {/* Center resting ring */}
      <div className="w-10 h-10 rounded-full border border-slate-500/30" />

      {/* Floating Joystick Thumb Knob */}
      <div
        className={`absolute w-14 h-14 rounded-full transition-transform ${
          isActive
            ? 'bg-amber-500/90 shadow-lg shadow-amber-500/40 border-2 border-white'
            : 'bg-slate-400/70 border-2 border-slate-300'
        }`}
        style={{
          transform: `translate(${knobPos.x}px, ${knobPos.y}px)`,
          transition: isActive ? 'none' : 'transform 0.12s ease-out',
        }}
      />
    </div>
  );
};
