import React, { useRef, useState } from 'react';

interface VirtualJoystickProps {
  onMove: (x: number, y: number, sprinting: boolean) => void;
}

export const VirtualJoystick: React.FC<VirtualJoystickProps> = ({ onMove }) => {
  const baseRef = useRef<HTMLDivElement | null>(null);
  const pointerIdRef = useRef<number | null>(null);
  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const [active, setActive] = useState(false);

  const maxRadius = 44;

  const updateFromClient = (clientX: number, clientY: number) => {
    const el = baseRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;

    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);

    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }

    setKnobOffset({ x: dx, y: dy });

    const normX = dx / maxRadius;
    const normY = -dy / maxRadius; // Up on screen = +1 forward
    const mag = Math.hypot(normX, normY);
    if (mag < 0.1) {
      onMove(0, 0, false);
    } else {
      onMove(normX, normY, false);
    }
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (pointerIdRef.current !== null) return;
    pointerIdRef.current = e.pointerId;
    setActive(true);
    e.currentTarget.setPointerCapture(e.pointerId);
    updateFromClient(e.clientX, e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerId !== pointerIdRef.current) return;
    e.stopPropagation();
    updateFromClient(e.clientX, e.clientY);
  };

  const resetStick = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerId !== pointerIdRef.current) return;
    e.stopPropagation();
    pointerIdRef.current = null;
    setActive(false);
    setKnobOffset({ x: 0, y: 0 });
    onMove(0, 0, false);
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      // Ignore
    }
  };

  return (
    <div
      ref={baseRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={resetStick}
      onPointerCancel={resetStick}
      className="touch-none-zone relative flex h-32 w-32 items-center justify-center rounded-full border-2 border-amber-400/35 bg-slate-950/65 shadow-lg"
      aria-label="Virtual Movement Joystick"
    >
      <div className="pointer-events-none absolute inset-3 rounded-full border border-slate-400/20" />
      <div
        className={`pointer-events-none h-13 w-13 rounded-full border-2 shadow-md transition-colors ${
          active
            ? 'border-amber-300 bg-amber-500/80'
            : 'border-slate-300/60 bg-slate-700/80'
        }`}
        style={{
          transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`,
        }}
      />
    </div>
  );
};
