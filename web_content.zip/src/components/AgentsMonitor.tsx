import React from 'react';
import {
  Activity,
  Bot,
  Brain,
  Code,
  Compass,
  Cpu,
  Eye,
  MessageSquare,
  Search,
  Shield,
  Zap,
} from 'lucide-react';
import { AgentInfo, AgentMessage, AgentRole } from '../types.ts';

interface AgentsMonitorProps {
  agents: AgentInfo[];
  recentMessages: AgentMessage[];
}

const AGENT_ICONS: Record<AgentRole, React.ReactNode> = {
  GENERAL: <Bot className="w-5 h-5 text-sky-600" />,
  PLANNER: <Compass className="w-5 h-5 text-purple-600" />,
  RESEARCH: <Search className="w-5 h-5 text-blue-600" />,
  CODING: <Code className="w-5 h-5 text-emerald-600" />,
  VISION: <Eye className="w-5 h-5 text-amber-600" />,
  AUTOMATION: <Zap className="w-5 h-5 text-rose-600" />,
  SECURITY: <Shield className="w-5 h-5 text-indigo-600" />,
};

export const AgentsMonitor: React.FC<AgentsMonitorProps> = ({ agents, recentMessages }) => {
  return (
    <div id="agents-monitor-panel" className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 font-sans">
            <Cpu className="w-5 h-5 text-sky-600" />
            Autonomous Agent Subsystem
          </h2>
          <p className="text-xs text-slate-600 font-mono mt-0.5">
            Decentralized multi-agent architecture with controlled communication channels and role specialization.
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono">
          <span className="px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-700 shadow-xs">
            ACTIVE UNITS: <strong className="text-sky-800 font-bold">{agents.length}</strong>
          </span>
          <span className="px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-1.5 shadow-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            COORDINATOR ONLINE
          </span>
        </div>
      </div>

      {/* Agents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {agents.map((agent) => (
          <div
            key={agent.role}
            className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between hover:border-sky-300 hover:shadow-xs transition-all"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 shadow-xs">
                    {AGENT_ICONS[agent.role] || <Bot className="w-5 h-5 text-sky-600" />}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 font-sans">{agent.name}</h3>
                    <span className="text-[10px] font-mono text-sky-800 uppercase tracking-wider font-semibold">
                      ROLE: {agent.role}
                    </span>
                  </div>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
              </div>

              <p className="text-xs text-slate-600 leading-relaxed mb-4 font-sans">{agent.description}</p>
            </div>

            <div>
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block mb-2 font-bold">
                Core Capabilities
              </span>
              <div className="flex flex-wrap gap-1.5">
                {agent.capabilities.map((cap, i) => (
                  <span
                    key={i}
                    className="px-2.5 py-1 rounded-md bg-slate-50 border border-slate-200 text-slate-700 text-[10px] font-mono font-medium shadow-xs"
                  >
                    {cap}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Inter-Agent Message Wire */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-purple-600" />
            <h3 className="text-xs font-mono font-bold text-slate-900 uppercase tracking-wider">
              Inter-Agent Communication Bus Telemetry
            </h3>
          </div>
          <span className="text-[10px] font-mono text-slate-500 font-medium">ENCRYPTED INTERNAL CHANNELS</span>
        </div>

        {recentMessages.length === 0 ? (
          <p className="text-xs font-mono text-slate-500 py-6 text-center">
            No inter-agent messages recorded yet. Messages will stream when an autonomous task dispatches sub-agents.
          </p>
        ) : (
          <div className="space-y-2 max-h-56 overflow-y-auto pr-1 scrollbar-thin">
            {recentMessages.map((msg) => (
              <div
                key={msg.id}
                className="bg-slate-50 border border-slate-200 p-3 rounded-xl text-xs font-mono flex items-start gap-3 shadow-xs"
              >
                <div className="flex items-center gap-1.5 flex-shrink-0 text-slate-500 text-[11px]">
                  <span className="font-bold text-sky-800">[{msg.fromAgent}]</span>
                  <span className="text-slate-400">&rarr;</span>
                  <span className="font-bold text-purple-800">[{msg.toAgent}]</span>
                </div>
                <div className="flex-1 text-slate-800">{msg.content}</div>
                <span className="text-[10px] text-slate-500 flex-shrink-0">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
