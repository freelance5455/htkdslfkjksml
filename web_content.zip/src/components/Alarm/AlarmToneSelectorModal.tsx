import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Check,
  Upload,
  Music,
  Play,
  Square,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import {
  ALARM_TONE_OPTIONS,
  getSelectedTone,
  setSelectedTone,
  previewRingtone,
  stopRingtonePreview,
  isRingtonePreviewing,
  setCustomAudioData,
  getCustomAudioInfo,
  AlarmToneOption
} from '../../utils/alarmAudio';
import { useApp } from '../../context/AppContext';

interface AlarmToneSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTone?: (toneId: string) => void;
  currentTone?: string;
}

export const AlarmToneSelectorModal: React.FC<AlarmToneSelectorModalProps> = ({
  isOpen,
  onClose,
  onSelectTone,
  currentTone,
}) => {
  const { language } = useApp();
  const isBn = language === 'bn';

  const [activeTone, setActiveTone] = useState<string>(() => currentTone || getSelectedTone());
  const [playingToneId, setPlayingToneId] = useState<string | null>(null);
  const [customInfo, setCustomInfo] = useState(() => getCustomAudioInfo());
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setActiveTone(currentTone || getSelectedTone());
      setCustomInfo(getCustomAudioInfo());
      setUploadError(null);
    } else {
      stopRingtonePreview();
      setPlayingToneId(null);
    }
  }, [isOpen, currentTone]);

  // Clean up on unmount and listen for preview stop events
  useEffect(() => {
    const handlePreviewStopped = () => {
      setPlayingToneId(null);
    };
    window.addEventListener('habivio:preview-stopped', handlePreviewStopped);
    return () => {
      window.removeEventListener('habivio:preview-stopped', handlePreviewStopped);
      stopRingtonePreview();
    };
  }, []);

  if (!isOpen) return null;

  const handleTogglePlay = (toneId: string) => {
    if (playingToneId === toneId && isRingtonePreviewing(toneId)) {
      stopRingtonePreview();
      setPlayingToneId(null);
    } else {
      stopRingtonePreview();
      setPlayingToneId(toneId);
      previewRingtone(toneId);
    }
  };

  const handleSelect = (toneId: string) => {
    setActiveTone(toneId);
    setSelectedTone(toneId);
    if (onSelectTone) {
      onSelectTone(toneId);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|ogg|m4a|aac)$/i)) {
      setUploadError(isBn ? 'অনুগ্রহ করে একটি অডিও ফাইল (MP3/WAV/AAC) নির্বাচন করুন' : 'Please select a valid audio file (MP3/WAV/AAC)');
      return;
    }

    // Limit size to ~5MB for localStorage
    if (file.size > 5 * 1024 * 1024) {
      setUploadError(isBn ? 'ফাইলের আকার সর্বোচ্চ ৫ মেগাবাইট হতে হবে' : 'File size must be under 5MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setCustomAudioData(dataUrl, file.name);
      setCustomInfo({ name: file.name, hasAudio: true });
      setActiveTone('custom_audio');
      setSelectedTone('custom_audio');
      if (onSelectTone) {
        onSelectTone('custom_audio');
      }
      setUploadError(null);
      // Auto-preview uploaded sound
      handleTogglePlay('custom_audio');
    };
    reader.onerror = () => {
      setUploadError(isBn ? 'ফাইল পড়তে ব্যর্থ হয়েছে' : 'Failed to read audio file');
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800/80 bg-linear-to-r from-violet-500/10 via-indigo-500/5 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-violet-600/10 dark:bg-violet-500/20 text-violet-600 dark:text-violet-400 flex items-center justify-center">
              <Music size={20} />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 font-bangla-display">
                {isBn ? 'অ্যালার্মের রিংটোন পরিবর্তন' : 'Change Alarm Ringtone'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-bangla-display">
                {isBn ? 'আপনার মন মতো পছন্দের সুর বা নিজস্ব অডিও বাছাই করুন' : 'Pick your preferred wake sound or upload your own'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Quick Ringtone Mute / Turn Off Button */}
        <div className="px-4 pt-3 pb-1">
          <div
            onClick={() => handleSelect('silent')}
            className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
              activeTone === 'silent'
                ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-700 shadow-xs ring-1 ring-rose-500/20'
                : 'bg-slate-100/80 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 hover:bg-rose-50/50 dark:hover:bg-rose-950/20'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-xl text-lg ${
                activeTone === 'silent'
                  ? 'bg-rose-500 text-white'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200'
              }`}>
                <VolumeX size={18} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-slate-800 dark:text-slate-100">
                    {isBn ? 'অ্যালার্মের শব্দ বন্ধ রাখুন (রিংটোন অফ)' : 'Turn Alarm Sound OFF (Silent Mode)'}
                  </span>
                  {activeTone === 'silent' && (
                    <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-bold">
                      {isBn ? 'শব্দ বন্ধ' : 'Muted'}
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {isBn
                    ? 'কোনো শব্দ বাজবে না, তবে স্ক্রিন জ্বলে উঠবে ও ভাইব্রেশন হবে'
                    : 'No sound will play; alerts via screen wake & tactile vibration'}
                </p>
              </div>
            </div>

            <button
              type="button"
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTone === 'silent'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-rose-100 hover:text-rose-700'
              }`}
            >
              {activeTone === 'silent' ? (isBn ? 'সক্রিয়' : 'Active') : (isBn ? 'শব্দ বন্ধ করুন' : 'Mute Sound')}
            </button>
          </div>
        </div>

        {/* Content list */}
        <div className="p-4 space-y-2.5 overflow-y-auto flex-1 font-bangla-display">
          <div className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider px-1">
            {isBn ? 'অথবা পছন্দের সুর বাছাই করুন:' : 'Or Select Preferred Ringtone:'}
          </div>

          {ALARM_TONE_OPTIONS.map((tone: AlarmToneOption) => {
            const isSelected = activeTone === tone.id;
            const isPlaying = playingToneId === tone.id && isRingtonePreviewing();
            const isCustom = tone.id === 'custom_audio';
            const isSilent = tone.id === 'silent';

            return (
              <div
                key={tone.id}
                onClick={() => handleSelect(tone.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  isSelected
                    ? isSilent
                      ? 'bg-rose-50/80 dark:bg-rose-950/40 border-rose-400 dark:border-rose-600 shadow-sm ring-1 ring-rose-500/20'
                      : 'bg-violet-50/80 dark:bg-violet-950/40 border-violet-400 dark:border-violet-600 shadow-sm ring-1 ring-violet-500/20'
                    : 'bg-slate-50/60 dark:bg-slate-800/50 border-slate-200/80 dark:border-slate-700/60 hover:border-slate-300 dark:hover:border-slate-600'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="text-2xl shrink-0 p-2 rounded-xl bg-white dark:bg-slate-800 shadow-xs border border-slate-100 dark:border-slate-700/60">
                    {tone.icon}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-800 dark:text-slate-100 truncate">
                        {isBn ? tone.nameBn : tone.nameEn}
                      </span>
                      {isSelected && (
                        <span className={`px-2 py-0.5 rounded-full text-white text-[10px] font-bold ${
                          isSilent ? 'bg-rose-600' : 'bg-violet-600'
                        }`}>
                          {isBn ? 'নির্বাচিত' : 'Active'}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                      {isCustom && customInfo.hasAudio
                        ? `${isBn ? 'ফাইল: ' : 'File: '} ${customInfo.name}`
                        : (isBn ? tone.descriptionBn : tone.descriptionEn)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {/* Custom upload trigger if custom_audio */}
                  {isCustom && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        fileInputRef.current?.click();
                      }}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-300 dark:hover:bg-slate-600 flex items-center gap-1.5 transition-colors"
                      title={isBn ? 'অডিও ফাইল আপলোড করুন' : 'Upload Audio File'}
                    >
                      <Upload size={12} />
                      <span>{isBn ? 'আপলোড' : 'Upload'}</span>
                    </button>
                  )}

                  {/* Play / Test Audio Button or Mute Indicator */}
                  {isSilent ? (
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                        isSelected
                          ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 font-bold'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                      }`}
                      title={isBn ? 'শব্দ বন্ধ' : 'Muted'}
                    >
                      <VolumeX size={15} />
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (isCustom && !customInfo.hasAudio) {
                          fileInputRef.current?.click();
                          return;
                        }
                        handleTogglePlay(tone.id);
                      }}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                        isPlaying
                          ? 'bg-rose-500 text-white animate-pulse shadow-md'
                          : 'bg-violet-100 dark:bg-violet-900/50 text-violet-700 dark:text-violet-300 hover:bg-violet-200 dark:hover:bg-violet-800/60'
                      }`}
                      title={isPlaying ? (isBn ? 'থামান' : 'Stop') : (isBn ? 'শুনুন' : 'Preview')}
                    >
                      {isPlaying ? <Square size={14} className="fill-current" /> : <Play size={14} className="fill-current ml-0.5" />}
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*,.mp3,.wav,.ogg,.m4a"
            onChange={handleFileUpload}
            className="hidden"
          />

          {uploadError && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle size={14} className="shrink-0" />
              <span>{uploadError}</span>
            </div>
          )}

          {/* Offline Assurance note */}
          <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-800 dark:text-amber-300 text-xs flex items-start gap-2.5">
            <Sparkles size={16} className="shrink-0 text-amber-500 mt-0.5" />
            <p className="leading-relaxed">
              {isBn
                ? 'আপনার নির্বাচিত রিংটোনটি ব্রাউজারের সিন্থেসাইজারে সরাসরি সংরক্ষিত থাকে, তাই কোনো ইন্টারনেট সংযোগ ছাড়াই ডিভাইস লক থাকা অবস্থায়ও উচ্চ শব্দে বাজবে।'
                : 'Your selected ringtone is generated natively in the device synthesizer, guaranteeing loud alarms even when offline and screen is locked.'}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/90">
          <span className="text-xs text-slate-500 dark:text-slate-400 font-bangla-display">
            {isBn ? 'বর্তমান টোন: ' : 'Active Tone: '}
            <strong className="text-slate-800 dark:text-slate-200">
              {ALARM_TONE_OPTIONS.find((o) => o.id === activeTone)?.[isBn ? 'nameBn' : 'nameEn'] || activeTone}
            </strong>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 active:scale-95 text-white text-xs font-bold font-bangla-display shadow-md shadow-violet-500/20 transition-all flex items-center gap-1.5"
          >
            <Check size={14} />
            <span>{isBn ? 'সম্পন্ন করুন' : 'Confirm'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
