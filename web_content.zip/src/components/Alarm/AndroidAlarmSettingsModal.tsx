import React, { useState, useEffect } from 'react';
import {
  X,
  Smartphone,
  ShieldCheck,
  AlertTriangle,
  BatteryCharging,
  Bell,
  Clock,
  Volume2,
  VolumeX,
  Lock,
  ExternalLink,
  CheckCircle2,
  HelpCircle,
  Play,
  Square,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  getAlarmPermissionsStatus,
  requestExactAlarmPermission,
  requestIgnoreBatteryOptimizations,
  openRedmiAutostartSettings,
  isNativeAndroid,
  AlarmPermissionsStatus,
} from '../../utils/nativeAlarmBridge';
import {
  SOUND_LIBRARY,
  previewRingtone,
  stopRingtonePreview,
  isRingtonePreviewing,
  getSelectedTone,
  setSelectedTone,
} from '../../utils/audioManager';

interface AndroidAlarmSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTestScreenOffAlarm: (delaySec?: number) => void;
}

export const AndroidAlarmSettingsModal: React.FC<AndroidAlarmSettingsModalProps> = ({
  isOpen,
  onClose,
  onTestScreenOffAlarm,
}) => {
  const { language } = useApp();
  const isBn = language === 'bn';

  const [permissions, setPermissions] = useState<AlarmPermissionsStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [activePreviewTone, setActivePreviewTone] = useState<string | null>(null);
  const [defaultTone, setDefaultTone] = useState(() => getSelectedTone());
  const [redmiTabOpen, setRedmiTabOpen] = useState(true);

  const fetchStatus = async () => {
    setLoading(true);
    const status = await getAlarmPermissionsStatus();
    setPermissions(status);
    setLoading(false);
  };

  useEffect(() => {
    if (isOpen) {
      fetchStatus();
      setDefaultTone(getSelectedTone());
    } else {
      stopRingtonePreview();
      setActivePreviewTone(null);
    }
  }, [isOpen]);

  useEffect(() => {
    const onPreviewStop = () => setActivePreviewTone(null);
    window.addEventListener('habivio:preview-stopped', onPreviewStop);
    return () => {
      window.removeEventListener('habivio:preview-stopped', onPreviewStop);
      stopRingtonePreview();
    };
  }, []);

  if (!isOpen) return null;

  const handlePreview = (toneId: string) => {
    if (activePreviewTone === toneId && isRingtonePreviewing(toneId)) {
      stopRingtonePreview();
      setActivePreviewTone(null);
    } else {
      stopRingtonePreview();
      previewRingtone(toneId);
      setActivePreviewTone(toneId);
    }
  };

  const handleSelectDefault = (toneId: string) => {
    setSelectedTone(toneId);
    setDefaultTone(toneId);
  };

  const handleRequestExactAlarm = async () => {
    await requestExactAlarmPermission();
    setTimeout(fetchStatus, 2000);
  };

  const handleRequestBatteryExemption = async () => {
    await requestIgnoreBatteryOptimizations();
    setTimeout(fetchStatus, 2000);
  };

  const handleOpenAutostart = async () => {
    await openRedmiAutostartSettings();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-700/80 p-5 sm:p-6 shadow-2xl text-white animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white bg-slate-800/80 transition-colors"
          aria-label="Close"
        >
          <X size={18} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-2xl bg-linear-to-tr from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-600/30">
            <Smartphone size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-black text-white">
                {isBn ? 'অ্যান্ড্রয়েড ও রেডমি স্মার্ট অ্যালার্ম সিস্টেম' : 'Android & Redmi Smart Alarm System'}
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                PRO
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {isBn
                ? 'স্ক্রিন অফ, লক স্ক্রিন এবং ব্যাকগ্রাউন্ডে ১০০% নির্ভরযোগ্য অ্যালার্ম নিশ্চিত করুন'
                : 'Ensure 100% reliable alarms when screen is off, locked, or app is closed'}
            </p>
          </div>
        </div>

        {/* System & Architecture Status Banner */}
        <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 text-xs mb-4 flex items-center justify-between">
          <div className="space-y-0.5">
            <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider block">
              {isBn ? 'সিস্টেম স্ট্যাটাস:' : 'System Engine:'}
            </span>
            <span className="font-semibold text-white">
              {isNativeAndroid()
                ? `Android Native (AlarmManager + FullScreenIntent)`
                : `Web / PWA Audio Engine (WebWorker + ServiceWorker)`}
            </span>
            {permissions?.manufacturer && (
              <span className="text-[11px] text-slate-400 block">
                {permissions.manufacturer.toUpperCase()} {permissions.model} (Android SDK {permissions.sdkInt})
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={fetchStatus}
            disabled={loading}
            className="px-2.5 py-1 rounded-xl bg-indigo-600/40 hover:bg-indigo-600 text-[11px] font-bold text-indigo-200 transition-colors shrink-0"
          >
            {loading ? '...' : (isBn ? 'রিফ্রেশ' : 'Refresh')}
          </button>
        </div>

        {/* Test Alarm with Countdown Tool */}
        <div className="p-4 rounded-2xl bg-linear-to-r from-rose-950/40 to-slate-900 border border-rose-500/30 mb-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lock size={16} className="text-rose-400" />
              <span className="text-xs font-bold text-white">
                {isBn ? 'স্ক্রিন অফ ও লক স্ক্রিন টেস্ট' : 'Screen-Off & Lock-Screen Test'}
              </span>
            </div>
            <span className="text-[10px] text-rose-300 font-mono font-bold bg-rose-500/20 px-2 py-0.5 rounded-md">
              ৫ সেকেন্ড
            </span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            {isBn
              ? 'নিচের বাটনে চাপ দিয়ে মোবাইল সাথে সাথে লক করুন। ৫ সেকেন্ড পর স্ক্রিন জেগে উঠে উচ্চস্বরে ফুলস্ক্রিন অ্যালার্ম বাজবে।'
              : 'Tap below and lock your phone immediately. After 5 seconds, screen will turn on and trigger full-screen alarm.'}
          </p>
          <button
            type="button"
            onClick={() => {
              onClose();
              onTestScreenOffAlarm(5);
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-linear-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-rose-600/30 active:scale-95 transition-all"
          >
            <Clock size={14} />
            <span>{isBn ? 'এখনই লক স্ক্রিন অ্যালার্ম টেস্ট করুন (5s)' : 'Test Lock-Screen Alarm Now (5s)'}</span>
          </button>
        </div>

        {/* Redmi / Xiaomi / MIUI Specific Guidance Section (Requirement 10) */}
        <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/80 mb-4 space-y-3">
          <div
            className="flex items-center justify-between cursor-pointer"
            onClick={() => setRedmiTabOpen(!redmiTabOpen)}
          >
            <div className="flex items-center gap-2">
              <span className="text-base">📱</span>
              <span className="text-xs font-bold text-white">
                {isBn ? 'রেডমি / শাওমি (MIUI / HyperOS) বিশেষ সেটিংস' : 'Redmi / Xiaomi (MIUI / HyperOS) Optimization'}
              </span>
            </div>
            <span className="text-[11px] text-violet-400 font-bold">
              {redmiTabOpen ? (isBn ? 'সংক্ষেপ করুন' : 'Collapse') : (isBn ? 'দেখুন' : 'Expand')}
            </span>
          </div>

          {redmiTabOpen && (
            <div className="space-y-2.5 pt-2 border-t border-slate-700/70 text-xs text-slate-300">
              <div className="flex items-start gap-2 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">1</span>
                <div className="space-y-1">
                  <p className="font-semibold text-white">
                    {isBn ? 'Autostart (স্বয়ংক্রিয় চালু) অন করুন' : 'Enable Autostart'}
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    {isBn
                      ? 'Xiaomi Security App > Manage Apps > Habivio > "Autostart" অন রাখুন যাতে ব্যাকগ্রাউন্ডে অ্যালার্ম বন্ধ না হয়।'
                      : 'Go to Security App > Manage Apps > Habivio > enable "Autostart" so alarms fire when phone is asleep.'}
                  </p>
                  {isNativeAndroid() && (
                    <button
                      type="button"
                      onClick={handleOpenAutostart}
                      className="inline-flex items-center gap-1 text-[11px] font-bold text-violet-400 hover:text-violet-300 underline pt-0.5"
                    >
                      <span>{isBn ? 'Autostart সেটিংস খুলুন' : 'Open Autostart Settings'}</span>
                      <ExternalLink size={10} />
                    </button>
                  )}
                </div>
              </div>

              <div className="flex items-start gap-2 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">2</span>
                <div className="space-y-1">
                  <p className="font-semibold text-white">
                    {isBn ? 'Battery Saver: "No restrictions" নির্বাচন করুন' : 'Battery Saver: Set "No restrictions"'}
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    {isBn
                      ? 'অ্যাপ সেটিংসে গিয়ে ব্যাটারি সেভার অপশনে "No restrictions" (কোনো বিধিনিষেধ নেই) দিন।'
                      : 'In App Info > Battery Saver, choose "No restrictions" so MIUI does not kill the alarm timer.'}
                  </p>
                  {isNativeAndroid() && (
                    <button
                      type="button"
                      onClick={handleRequestBatteryExemption}
                      className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 hover:text-emerald-300 underline pt-0.5"
                    >
                      <span>{isBn ? 'ব্যাটারি ছাড় সক্রিয় করুন' : 'Exempt from Battery Saver'}</span>
                      <ExternalLink size={10} />
                    </button>
                  )}
                </div>
              </div>

              <div className="flex items-start gap-2 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-violet-500/20 text-violet-400 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">3</span>
                <div className="space-y-1">
                  <p className="font-semibold text-white">
                    {isBn ? 'লক স্ক্রিন নোটিফিকেশন পারমিশন' : 'Show on Lock Screen Permission'}
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    {isBn
                      ? 'Other Permissions থেকে "Show on Lock screen" এবং "Display pop-up windows" অন রাখুন।'
                      : 'Under Other Permissions, turn on "Show on Lock screen" & "Display pop-up windows while running in background".'}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Hardware Button Silencing Guide (Requirement 4) */}
        <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/80 mb-4 space-y-2.5">
          <div className="flex items-center gap-2">
            <VolumeX size={16} className="text-amber-400" />
            <h4 className="text-xs font-bold text-white">
              {isBn ? 'হার্ডওয়্যার বাটন দিয়ে সাউন্ড মিউট করার নিয়ম' : 'Hardware Buttons Silencing Rules'}
            </h4>
          </div>
          <div className="space-y-2 text-xs text-slate-300 leading-relaxed">
            <p>
              • <strong>Volume Up / Volume Down:</strong>{' '}
              {isBn
                ? 'অ্যালার্ম বাজার সময় যেকোনো ভলিউম বাটন এক চাপ দিলে তাৎক্ষণিকভাবে সাউন্ড ও ভাইব্রেশন মিউট হয়ে যাবে।'
                : 'Pressing Volume Up or Volume Down immediately silences sound and vibration.'}
            </p>
            <p>
              • <strong>Power Button:</strong>{' '}
              {isBn
                ? 'অ্যান্ড্রয়েড সিস্টেমের নিরাপত্তা বিধিনিষেধ অনুযায়ী পাওয়ার বাটন চেপে স্ক্রিন অফ করলে সাউন্ড স্বয়ংক্রিয়ভাবে মিউট হয়।'
                : 'Per Android system restrictions, turning off the screen via Power button safely silences the sound.'}
            </p>
          </div>
        </div>

        {/* Alarm Sound Audition & Library (Requirement 6) */}
        <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/80 mb-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Volume2 size={16} className="text-violet-400" />
              <h4 className="text-xs font-bold text-white">
                {isBn ? 'অ্যালার্ম সাউন্ড লাইব্রেরি (শুনুন ও ডিফল্ট নির্বাচন করুন)' : 'Sound Library (Audition & Default)'}
              </h4>
            </div>
            {activePreviewTone && (
              <button
                type="button"
                onClick={() => {
                  stopRingtonePreview();
                  setActivePreviewTone(null);
                }}
                className="px-2 py-0.5 rounded-lg bg-rose-600 text-white text-[10px] font-bold flex items-center gap-1"
              >
                <Square size={10} className="fill-current" />
                <span>{isBn ? 'থামান' : 'Stop'}</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
            {SOUND_LIBRARY.filter((s) => s.id !== 'silent' && s.id !== 'custom_audio').map((sound) => {
              const isPlaying = activePreviewTone === sound.id && isRingtonePreviewing(sound.id);
              const isDefault = defaultTone === sound.id;

              return (
                <div
                  key={sound.id}
                  className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 transition-all ${
                    isPlaying
                      ? 'bg-violet-950/70 border-violet-500 ring-1 ring-violet-500/50'
                      : isDefault
                      ? 'bg-slate-850 border-violet-600/50'
                      : 'bg-slate-900 border-slate-800'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm">{sound.icon}</span>
                      <span className="text-xs font-bold text-slate-100 truncate">
                        {isBn ? sound.nameBn : sound.nameEn}
                      </span>
                    </div>
                    {isDefault && (
                      <span className="text-[9px] font-extrabold text-violet-400 block mt-0.5">
                        {isBn ? '✓ ডিফল্ট' : '✓ Default'}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => handlePreview(sound.id)}
                      className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all ${
                        isPlaying
                          ? 'bg-rose-600 text-white'
                          : 'bg-slate-800 hover:bg-slate-700 text-violet-300'
                      }`}
                      title={isPlaying ? 'Stop' : 'Play'}
                    >
                      {isPlaying ? <Square size={11} className="fill-current" /> : <Play size={11} className="fill-current ml-0.5" />}
                    </button>

                    {!isDefault && (
                      <button
                        type="button"
                        onClick={() => handleSelectDefault(sound.id)}
                        className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-violet-600 hover:text-white text-[10px] font-bold text-slate-300 transition-colors"
                      >
                        {isBn ? 'বাছুন' : 'Set'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Done / Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="w-full py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all"
        >
          {isBn ? 'ঠিক আছে (সম্পন্ন)' : 'Close & Apply'}
        </button>
      </div>
    </div>
  );
};
