import React, { useState } from 'react';
import { Subject, SubCategory, Quiz, SUBJECTS_DATA } from '../types';
import {
  Calculator,
  Globe,
  Brain,
  Languages,
  ShieldAlert,
  BookOpen,
  ChevronRight,
  Layers,
  Percent,
  Shapes,
  Landmark,
  Scale,
  Compass,
  FlaskConical,
  MessageSquare,
  Puzzle,
  SpellCheck,
  BookA,
  Palette,
  Crown,
  Map,
  Building2,
  Type,
  Book,
  Play,
  ArrowLeft,
  CheckCircle,
  Sparkles,
  HelpCircle,
  FileQuestion,
  Download
} from 'lucide-react';

interface SubjectGridProps {
  quizzes: Quiz[];
  onStartQuiz: (quiz: Quiz) => void;
  onOpenCreateQuiz?: () => void;
  onDownloadQuiz?: (quiz: Quiz) => void;
}

export const SubjectGrid: React.FC<SubjectGridProps> = ({ quizzes, onStartQuiz, onOpenCreateQuiz, onDownloadQuiz }) => {
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [selectedSubCategoryId, setSelectedSubCategoryId] = useState<string | null>(null);

  const selectedSubject = SUBJECTS_DATA.find((s) => s.id === selectedSubjectId);
  const selectedSubCategory = selectedSubject?.subcategories.find((sc) => sc.id === selectedSubCategoryId);

  // Icon resolver
  const renderIcon = (name: string, className = 'w-6 h-6') => {
    switch (name) {
      case 'Calculator': return <Calculator className={className} />;
      case 'Globe': return <Globe className={className} />;
      case 'Brain': return <Brain className={className} />;
      case 'Languages': return <Languages className={className} />;
      case 'ShieldAlert': return <ShieldAlert className={className} />;
      case 'BookOpen': return <BookOpen className={className} />;
      case 'Layers': return <Layers className={className} />;
      case 'Percent': return <Percent className={className} />;
      case 'Shapes': return <Shapes className={className} />;
      case 'Landmark': return <Landmark className={className} />;
      case 'Scale': return <Scale className={className} />;
      case 'Compass': return <Compass className={className} />;
      case 'FlaskConical': return <FlaskConical className={className} />;
      case 'MessageSquare': return <MessageSquare className={className} />;
      case 'Puzzle': return <Puzzle className={className} />;
      case 'SpellCheck': return <SpellCheck className={className} />;
      case 'BookA': return <BookA className={className} />;
      case 'Palette': return <Palette className={className} />;
      case 'Crown': return <Crown className={className} />;
      case 'Map': return <Map className={className} />;
      case 'Building2': return <Building2 className={className} />;
      case 'Type': return <Type className={className} />;
      case 'Book': return <Book className={className} />;
      default: return <FileQuestion className={className} />;
    }
  };

  const getSubjectQuizCount = (subjectId: string) => {
    return quizzes.filter((q) => q.subjectId === subjectId).length;
  };

  const getSubCategoryQuizCount = (subjectId: string, subId: string) => {
    return quizzes.filter((q) => q.subjectId === subjectId && q.subCategoryId === subId).length;
  };

  // 1. Breadcrumbs Header
  const renderBreadcrumb = () => {
    return (
      <div className="bg-white px-4 py-3 rounded-2xl border border-slate-200 shadow-xs mb-6 flex flex-wrap items-center gap-2 text-xs sm:text-sm font-medium text-slate-600">
        <button
          onClick={() => {
            setSelectedSubjectId(null);
            setSelectedSubCategoryId(null);
          }}
          className={`flex items-center gap-1.5 hover:text-blue-600 transition ${
            !selectedSubjectId ? 'text-blue-600 font-bold' : ''
          }`}
        >
          <Layers className="w-4 h-4 text-blue-500" />
          <span>सभी 6 विषय ब्लॉक</span>
        </button>

        {selectedSubject && (
          <>
            <ChevronRight className="w-4 h-4 text-slate-400" />
            <button
              onClick={() => setSelectedSubCategoryId(null)}
              className={`hover:text-blue-600 transition ${
                !selectedSubCategoryId ? 'text-blue-600 font-bold' : ''
              }`}
            >
              {selectedSubject.name}
            </button>
          </>
        )}

        {selectedSubCategory && (
          <>
            <ChevronRight className="w-4 h-4 text-slate-400" />
            <span className="text-slate-900 font-bold truncate max-w-[200px] sm:max-w-none">
              {selectedSubCategory.name}
            </span>
          </>
        )}
      </div>
    );
  };

  // 2. Render Main 6 Subject Blocks
  if (!selectedSubjectId) {
    return (
      <div className="space-y-6">
        <div className="text-center space-y-2 mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>विशेषज्ञ एवं एआई द्वारा तैयार मॉक टेस्ट</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            विषयानुसार टेस्ट सीरीज़ (Subject-wise Quiz)
          </h2>
          <p className="text-slate-600 max-w-xl mx-auto text-sm">
            अपनी परीक्षा तैयारी को मजबूत करने के लिए नीचे दिए गए 6 प्रमुख विषयों में से चुनें:
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {SUBJECTS_DATA.map((subject) => {
            const count = getSubjectQuizCount(subject.id);
            return (
              <div
                key={subject.id}
                onClick={() => setSelectedSubjectId(subject.id)}
                className={`group relative overflow-hidden bg-gradient-to-br ${subject.color} rounded-2xl p-6 text-white shadow-md hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1.5 cursor-pointer border border-white/20 flex flex-col justify-between min-h-[190px]`}
              >
                {/* Decorative background glow */}
                <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none group-hover:scale-150 transition duration-500" />

                <div className="flex justify-between items-start">
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-white/20 backdrop-blur-md border border-white/30 tracking-wider">
                    Block {subject.num}
                  </span>
                  <div className="w-12 h-12 rounded-xl bg-white/15 backdrop-blur-md flex items-center justify-center border border-white/20 group-hover:scale-110 transition duration-300">
                    {renderIcon(subject.iconName, 'w-6 h-6 text-white')}
                  </div>
                </div>

                <div className="mt-4">
                  <h3 className="font-extrabold text-xl leading-tight text-white drop-shadow-xs">
                    {subject.name}
                  </h3>
                  <div className="mt-3 flex items-center justify-between text-xs text-white/90 border-t border-white/20 pt-2.5">
                    <span>{subject.subcategories.length} सब-ब्लॉक्स</span>
                    <span className="font-semibold bg-black/20 px-2 py-0.5 rounded-full">
                      {count} {count === 1 ? 'टेस्ट उपलब्ध' : 'टेस्ट उपलब्ध'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // 3. Render Subcategories for selected subject
  if (selectedSubject && !selectedSubCategoryId) {
    return (
      <div className="space-y-6">
        {renderBreadcrumb()}

        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center text-sm">
                {selectedSubject.num}
              </span>
              <span>{selectedSubject.name} के सब-ब्लॉक्स</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              अध्ययन विषय चुनें और उससे संबंधित टेस्ट पेपर्स हल करें।
            </p>
          </div>
          <button
            onClick={() => setSelectedSubjectId(null)}
            className="flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-blue-600 bg-white border border-slate-200 px-3 py-1.5 rounded-lg shadow-2xs hover:bg-slate-50 transition"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> वापस जाएं
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {selectedSubject.subcategories.map((sub) => {
            const count = getSubCategoryQuizCount(selectedSubject.id, sub.id);
            return (
              <div
                key={sub.id}
                onClick={() => setSelectedSubCategoryId(sub.id)}
                className="group bg-white p-5 rounded-2xl border border-slate-200 hover:border-blue-500 hover:shadow-lg transition-all duration-200 cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition flex items-center justify-center shrink-0 shadow-2xs">
                    {renderIcon(sub.iconName, 'w-6 h-6')}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-base group-hover:text-blue-600 transition">
                      {sub.name}
                    </h4>
                    <span className="inline-block mt-1 text-xs text-slate-500 font-medium">
                      {count > 0 ? `${count} टेस्ट उपलब्ध` : 'टेस्ट पेपर्स देखें'}
                    </span>
                  </div>
                </div>
                <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 group-hover:text-blue-600 group-hover:bg-blue-50 transition">
                  <ChevronRight className="w-5 h-5" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // 4. Render Quizzes in selected subcategory
  const filteredQuizzes = quizzes.filter(
    (q) => q.subjectId === selectedSubjectId && q.subCategoryId === selectedSubCategoryId
  );

  return (
    <div className="space-y-6">
      {renderBreadcrumb()}

      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h3 className="text-xl sm:text-2xl font-bold text-slate-900">
            {selectedSubCategory?.name}
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            उपलब्ध मॉक टेस्ट पेपर्स - अपनी तैयारी जांचें एवं विस्तृत व्याख्या देखें।
          </p>
        </div>
        <button
          onClick={() => setSelectedSubCategoryId(null)}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-blue-600 bg-white border border-slate-200 px-3 py-1.5 rounded-lg shadow-2xs hover:bg-slate-50 transition"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> सब-ब्लॉक सूची पर जाएं
        </button>
      </div>

      {filteredQuizzes.length === 0 ? (
        <div className="text-center py-16 px-4 bg-white rounded-2xl border-2 border-dashed border-slate-200 shadow-2xs space-y-4">
          <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto text-2xl">
            <BookOpen className="w-8 h-8 text-slate-400" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-lg">इस सब-ब्लॉक में अभी कोई टेस्ट नहीं है</h4>
            <p className="text-sm text-slate-500 max-w-md mx-auto mt-1">
              आप Admin Panel से Gemini AI की मदद से कुछ ही सेकंड में नया टेस्ट जनरेट करके जोड़ सकते हैं!
            </p>
          </div>
          {onOpenCreateQuiz && (
            <button
              onClick={onOpenCreateQuiz}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl shadow-md transition"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>AI द्वारा नया टेस्ट बनाएं</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredQuizzes.map((quiz) => (
            <div
              key={quiz.id}
              className="group bg-white p-5 rounded-2xl border border-slate-200 hover:border-blue-400 hover:shadow-lg transition-all duration-200 flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <h4 className="font-bold text-slate-900 text-lg leading-snug group-hover:text-blue-600 transition">
                    {quiz.title}
                  </h4>
                  <span className="shrink-0 text-xs font-semibold px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-100">
                    {quiz.questions.length} प्रश्न (MCQ)
                  </span>
                </div>
                {quiz.description && (
                  <p className="text-xs sm:text-sm text-slate-500 mt-2 line-clamp-2">
                    {quiz.description}
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-mono">
                  {new Date(quiz.createdAt).toLocaleDateString('hi-IN', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                  })}
                </span>
                <button
                  onClick={() => onStartQuiz(quiz)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold rounded-xl transition flex items-center gap-1.5 shadow-sm group-hover:shadow group-hover:bg-blue-700"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>टेस्ट शुरू करें (Start Test)</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
