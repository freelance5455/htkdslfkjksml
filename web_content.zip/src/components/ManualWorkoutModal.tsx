import React, { useState } from 'react';
import { Workout, WorkoutType } from '../types';
import { formatDuration, calculatePace } from '../utils/runningCalculations';
import { X, Save, PlusCircle, CheckCircle } from 'lucide-react';

interface ManualWorkoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (workout: Workout) => void;
}

export const ManualWorkoutModal: React.FC<ManualWorkoutModalProps> = ({
  isOpen,
  onClose,
  onSave,
}) => {
  const [workoutType, setWorkoutType] = useState<WorkoutType>('treadmill');
  const [distanceKm, setDistanceKm] = useState<number>(5.0);
  const [durationMinutes, setDurationMinutes] = useState<number>(25);
  const [durationSeconds, setDurationSeconds] = useState<number>(30);
  const [rpe, setRpe] = useState<number>(6);
  const [sleepHours, setSleepHours] = useState<number>(7.5);
  const [energyLevel, setEnergyLevel] = useState<number>(4);
  const [sorenessScore, setSorenessScore] = useState<number>(2);
  const [notes, setNotes] = useState('');
  const [weather, setWeather] = useState('Indoor Treadmill');

  if (!isOpen) return null;

  const totalDurationSec = durationMinutes * 60 + durationSeconds;
  const distanceMeters = Math.round(distanceKm * 1000);
  const calculatedPace = calculatePace(distanceMeters, totalDurationSec);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const is1600m = workoutType === 'time_trial' || (distanceMeters >= 1580 && distanceMeters <= 1650);

    const workout: Workout = {
      id: 'manual-' + Date.now(),
      date: new Date().toISOString().split('T')[0],
      startTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      workoutType,
      title: `${workoutType.toUpperCase().replace('_', ' ')} (Manual)`,
      distanceKm,
      distanceMeters,
      durationSeconds: totalDurationSec,
      durationFormatted: formatDuration(totalDurationSec),
      avgPace: calculatedPace,
      avgSpeedKmh: Number(((distanceKm / (totalDurationSec / 3600)) || 0).toFixed(1)),
      rpe,
      sleepHours,
      energyLevel,
      sorenessScore,
      notes,
      weather,
      splits: [],
      routeCoordinates: [],
      isTimeTrial: is1600m,
      timeTrialTimeFormatted: is1600m ? formatDuration(totalDurationSec) : undefined,
    };

    onSave(workout);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-zinc-900 border border-zinc-700 rounded-3xl p-5 shadow-2xl space-y-4 my-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 border-b border-zinc-800 pb-3">
          <PlusCircle className="w-5 h-5 text-[#00FF66]" />
          <h2 className="font-athletic text-base font-extrabold uppercase text-white">
            Log Manual / Indoor Workout
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="font-semibold text-zinc-300 block mb-1">Workout Type</label>
            <select
              value={workoutType}
              onChange={(e) => setWorkoutType(e.target.value as WorkoutType)}
              className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white"
            >
              <option value="treadmill">Treadmill Run</option>
              <option value="easy">Easy Aerobic Base Run</option>
              <option value="intervals">1600m Intervals (Track)</option>
              <option value="tempo">Tempo Run</option>
              <option value="track_reps">Track Repetitions</option>
              <option value="time_trial">1600m Timed Trial</option>
              <option value="recovery">Active Recovery</option>
              <option value="walk_cross">Walk / Cross-Training</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-zinc-300 block mb-1">Distance (KM)</label>
              <input
                type="number"
                step="0.05"
                min="0.1"
                max="100"
                value={Number.isNaN(distanceKm) || distanceKm === 0 ? '' : distanceKm}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  setDistanceKm(Number.isNaN(val) ? 0 : val);
                }}
                className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white font-mono-numbers"
              />
            </div>

            <div>
              <label className="font-semibold text-zinc-300 block mb-1">Calculated Pace</label>
              <div className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-[#00FF66] font-mono-numbers font-bold">
                {calculatedPace} /km
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-zinc-300 block mb-1">Minutes</label>
              <input
                type="number"
                min="0"
                max="300"
                value={Number.isNaN(durationMinutes) ? '' : durationMinutes}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  setDurationMinutes(Number.isNaN(val) ? 0 : val);
                }}
                className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white font-mono-numbers"
              />
            </div>

            <div>
              <label className="font-semibold text-zinc-300 block mb-1">Seconds</label>
              <input
                type="number"
                min="0"
                max="59"
                value={Number.isNaN(durationSeconds) ? '' : durationSeconds}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  setDurationSeconds(Number.isNaN(val) ? 0 : val);
                }}
                className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-sm text-white font-mono-numbers"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="font-semibold text-zinc-300">Rate of Perceived Exertion (RPE):</span>
              <span className="font-bold text-[#00FF66]">{rpe} / 10</span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={rpe}
              onChange={(e) => setRpe(parseInt(e.target.value))}
              className="w-full accent-[#00FF66] bg-zinc-800 h-2 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <label className="font-semibold text-zinc-300 block mb-1">Notes</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. 1.0% incline on treadmill, felt smooth"
              className="w-full bg-black border border-zinc-700 rounded-xl px-3 py-2 text-xs text-white"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-xl bg-[#00FF66] text-black font-athletic font-black text-sm uppercase tracking-wide flex items-center justify-center gap-1.5 hover:bg-[#10B981] transition shadow-md glow-neon-sm active:scale-95"
          >
            <Save className="w-4 h-4" />
            <span>Save Manual Entry</span>
          </button>
        </form>
      </div>
    </div>
  );
};
