import React, { useState } from "react";
import {
  BrainCircuit,
  Sparkles,
  Loader2,
  Wand2,
  Download,
  Maximize2,
  BookOpen,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Microscope,
  FileText,
  Share2,
  Check,
  Dna,
  Atom,
  FlaskConical,
  ExternalLink,
  FileImage,
  Layers,
  Palette,
  Eye,
  X,
  Heart,
} from "lucide-react";
import { MindMapData, MindMapNode, GeneratedImage } from "../types";
import {
  generateMindMapFromParagraph,
  SAMPLE_PARAGRAPHS,
} from "../utils/mindMapGenerator";
import { generateSingleMindMapImage } from "../utils/mindMapCanvasExporter";
import { SmartImage } from "./SmartImage";
import { downloadImage } from "../utils/downloadImage";

interface MindMapStudioProps {
  onSendToEditor: (image: GeneratedImage) => void;
  onOpenImageModal: (image: GeneratedImage) => void;
  onSaveToGallery?: (image: GeneratedImage) => void;
  userApiKey?: string;
  onOpenKeyModal: () => void;
}

export const MindMapStudio: React.FC<MindMapStudioProps> = ({
  onSendToEditor,
  onOpenImageModal,
  onSaveToGallery,
  userApiKey,
  onOpenKeyModal,
}) => {
  const [inputText, setInputText] = useState<string>(
    SAMPLE_PARAGRAPHS[0].paragraph
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [loadingStep, setLoadingStep] = useState("");
  const [mindMap, setMindMap] = useState<MindMapData | null>(null);
  const [selectedNode, setSelectedNode] = useState<MindMapNode | null>(null);
  const [zoomScale, setZoomScale] = useState(1);
  const [copiedText, setCopiedText] = useState(false);

  // Single Consolidated Diagram Graphic States
  const [singleDiagramUrl, setSingleDiagramUrl] = useState<string | null>(null);
  const [isBuildingDiagram, setIsBuildingDiagram] = useState(false);
  const [isDiagramModalOpen, setIsDiagramModalOpen] = useState(false);

  const handleBuildSingleDiagram = async (dataToUse?: MindMapData) => {
    const targetMap = dataToUse || mindMap;
    if (!targetMap) return;

    setIsBuildingDiagram(true);
    try {
      const graphicUrl = await generateSingleMindMapImage(targetMap);
      setSingleDiagramUrl(graphicUrl);
      setIsDiagramModalOpen(true);

      // Save complete consolidated image to gallery if available
      if (onSaveToGallery) {
        onSaveToGallery({
          id: `mindmap_diagram_${Date.now()}`,
          url: graphicUrl,
          prompt: `Mind Map Diagram: ${targetMap.topicTitle} (Consolidated boxes, circles & colorful connected lines)`,
          aspectRatio: "16:9",
          style: "Mind Map Diagram",
          timestamp: Date.now(),
        });
      }
    } catch (err: any) {
      console.error("Failed to generate single diagram image:", err);
    } finally {
      setIsBuildingDiagram(false);
    }
  };

  const handleGenerate = async (overrideText?: string) => {
    const textToUse = overrideText !== undefined ? overrideText : inputText;
    if (!textToUse.trim()) return;

    setIsGenerating(true);
    setLoadingStep("Extracting key concepts & micro-image prompts...");
    try {
      const data = await generateMindMapFromParagraph(
        textToUse,
        userApiKey,
        (step) => setLoadingStep(step)
      );
      setMindMap(data);
      const root = data.nodes.find((n) => n.isMainRoot);
      if (root) setSelectedNode(root);

      // Save all generated node images to gallery automatically
      data.nodes.forEach((node) => {
        if (node.imageObj && onSaveToGallery) {
          onSaveToGallery(node.imageObj);
        }
      });

      // Automatically construct single consolidated mind map diagram image
      setTimeout(() => {
        handleBuildSingleDiagram(data);
      }, 400);
    } catch (err: any) {
      console.error("Failed to generate mind map:", err);
      alert(err.message || "Failed to generate mind map.");
    } finally {
      setIsGenerating(false);
    }
  };

  const rootNode = mindMap?.nodes.find((n) => n.isMainRoot);
  const subNodes = mindMap?.nodes.filter((n) => !n.isMainRoot) || [];

  const handleCopySummary = () => {
    if (!mindMap) return;
    let text = `# Scientific Mind Map: ${mindMap.topicTitle}\n\n`;
    mindMap.nodes.forEach((node) => {
      text += `## ${node.isMainRoot ? "Central Topic: " : "- "}${node.title}\n`;
      text += `Summary: ${node.summary}\n`;
      text += `Image Prompt: ${node.imagePrompt}\n\n`;
    });
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 via-indigo-950/60 to-slate-900 border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                <BrainCircuit className="w-5 h-5 animate-pulse" />
              </span>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Paragraph to Micro-Image Mind Map
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 uppercase">
                AI Micrographs
              </span>
            </div>
            <p className="text-xs text-slate-300 max-w-2xl">
              Paste any scientific or educational paragraph. Our AI automatically extracts key concepts, generates small micro-images for every node, and allows precision image editing on every node!
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onOpenKeyModal}
              className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 flex items-center gap-1.5 transition"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>AI Engine Setup</span>
            </button>
          </div>
        </div>
      </div>

      {/* Input Section & Scientific Presets */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-lg">
        {/* Presets Header */}
        <div className="space-y-2">
          <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5 uppercase tracking-wider">
            <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
            <span>Sample Scientific Text Presets</span>
          </span>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_PARAGRAPHS.map((preset, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setInputText(preset.paragraph);
                  handleGenerate(preset.paragraph);
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 hover:border-indigo-500/50 text-slate-200 text-xs font-medium transition flex items-center gap-1.5"
              >
                {idx === 0 && <Microscope className="w-3.5 h-3.5 text-emerald-400" />}
                {idx === 1 && <FlaskConical className="w-3.5 h-3.5 text-cyan-400" />}
                {idx === 2 && <Dna className="w-3.5 h-3.5 text-pink-400" />}
                {idx === 3 && <Atom className="w-3.5 h-3.5 text-purple-400" />}
                <span>{preset.title}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Text Input */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-indigo-400" />
              <span>Scientific Paragraph Input</span>
            </span>
            <span className="text-[11px] text-slate-500">
              {inputText.length} characters
            </span>
          </label>
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Paste your scientific or educational paragraph here (e.g. Mitochondria electron microscopic structure, photosynthesis, DNA replication)..."
            rows={4}
            className="w-full p-4 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500 transition resize-none"
          />
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-between pt-2">
          <span className="text-[11px] text-slate-400 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-emerald-400" />
            <span>Generates connected node tree + micro-images per topic</span>
          </span>

          <button
            onClick={() => handleGenerate()}
            disabled={isGenerating || !inputText.trim()}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white font-bold text-xs shadow-lg shadow-indigo-500/25 flex items-center gap-2 transition disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-white" />
                <span>{loadingStep || "Generating Mind Map..."}</span>
              </>
            ) : (
              <>
                <BrainCircuit className="w-4 h-4" />
                <span>Generate Micro-Image Mind Map</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Mind Map Interactive Visual Display */}
      {mindMap && (
        <div className="space-y-4">
          {/* Header Controls */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <h3 className="text-sm font-bold text-white">
                Mind Map: {mindMap.topicTitle}
              </h3>
              <span className="text-xs text-slate-400">
                ({mindMap.nodes.length} Micro-Image Nodes)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  onClick={() => setZoomScale((z) => Math.max(0.6, z - 0.1))}
                  className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-300"
                  title="Zoom Out"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span className="px-2 font-mono text-[11px] text-slate-400">
                  {Math.round(zoomScale * 100)}%
                </span>
                <button
                  onClick={() => setZoomScale((z) => Math.min(1.4, z + 0.1))}
                  className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-300"
                  title="Zoom In"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setZoomScale(1)}
                  className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-300 ml-1"
                  title="Reset Scale"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                onClick={() => handleBuildSingleDiagram()}
                disabled={isBuildingDiagram}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition disabled:opacity-50"
              >
                {isBuildingDiagram ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <FileImage className="w-3.5 h-3.5 text-pink-300" />
                )}
                <span>View Single Mind Map Graphic Image</span>
              </button>

              <button
                onClick={handleCopySummary}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition"
              >
                {copiedText ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Share2 className="w-3.5 h-3.5 text-indigo-400" />
                )}
                <span>{copiedText ? "Copied!" : "Export Outline"}</span>
              </button>
            </div>
          </div>

          {/* Visual Mind Map Graph Container */}
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 relative overflow-x-auto min-h-[500px] flex flex-col items-center justify-center">
            <div
              className="w-full max-w-5xl transition-transform duration-300 space-y-8"
              style={{ transform: `scale(${zoomScale})`, transformOrigin: "top center" }}
            >
              {/* Central Root Node */}
              {rootNode && (
                <div className="flex justify-center">
                  <div
                    onClick={() => setSelectedNode(rootNode)}
                    className={`p-5 rounded-2xl bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 border-2 ${
                      selectedNode?.id === rootNode.id
                        ? "border-emerald-400 shadow-xl shadow-emerald-500/20"
                        : "border-indigo-500/50 hover:border-indigo-400"
                    } transition cursor-pointer max-w-lg w-full shadow-2xl space-y-3 relative group`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-[11px] font-bold uppercase tracking-wider border border-indigo-500/30">
                        {rootNode.category || "Central Topic"}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">Root Node</span>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-bold text-white text-lg leading-snug flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 inline-block animate-pulse"></span>
                        {rootNode.title}
                      </h4>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        {rootNode.summary}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Connected Lines SVG Branch Indicator */}
              <div className="flex justify-center -my-2 pointer-events-none">
                <svg className="w-full max-w-3xl h-12 stroke-indigo-500/40" fill="none">
                  <path d="M 50% 0 L 50% 24 M 15% 24 L 85% 24 M 15% 24 L 15% 48 M 38% 24 L 38% 48 M 62% 24 L 62% 48 M 85% 24 L 85% 48" strokeWidth="2" strokeDasharray="4 4" />
                </svg>
              </div>

              {/* Sub-Topics Nodes Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {subNodes.map((node) => {
                  const isSelected = selectedNode?.id === node.id;
                  return (
                    <div
                      key={node.id}
                      onClick={() => setSelectedNode(node)}
                      className={`p-4 rounded-2xl bg-slate-900 border ${
                        isSelected
                          ? "border-emerald-400 ring-2 ring-emerald-500/20 bg-slate-900/90"
                          : "border-slate-800 hover:border-indigo-500/50"
                      } transition cursor-pointer flex flex-col justify-between space-y-3 shadow-lg group`}
                    >
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-indigo-300 text-[10px] font-semibold border border-slate-700">
                            {node.category || "Subtopic"}
                          </span>
                          <span className="w-2 h-2 rounded-full bg-indigo-500/60"></span>
                        </div>

                        <div className="space-y-1.5 pt-1">
                          <h5 className="font-bold text-slate-100 text-sm leading-tight border-b border-slate-800 pb-2">
                            {node.title}
                          </h5>
                          <p className="text-xs text-slate-300 leading-relaxed pt-1">
                            {node.summary}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Selected Node Details Card */}
          {selectedNode && (
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-between gap-5">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px] font-bold uppercase border border-indigo-500/30">
                    Selected Node Concept
                  </span>
                  <span className="text-xs font-semibold text-slate-400">
                    {selectedNode.category}
                  </span>
                </div>
                <h4 className="font-bold text-white text-base">
                  {selectedNode.title}
                </h4>
                <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                  {selectedNode.summary}
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Single Consolidated Mind Map Graphic Preview Modal */}
      {isDiagramModalOpen && singleDiagramUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-5xl bg-slate-900 border border-purple-500/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400 border border-purple-500/30">
                  <FileImage className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Consolidated Single Mind Map Diagram
                  </h3>
                  <p className="text-[11px] text-slate-400 font-mono">
                    Text in boxes & circles with colorful connected lines & embedded micro-images
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => downloadImage(singleDiagramUrl, `mindmap_full_diagram_${Date.now()}.png`)}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition shadow-md"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Diagram PNG</span>
                </button>
                <button
                  onClick={() => setIsDiagramModalOpen(false)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Modal Body: High Resolution Canvas Diagram Preview */}
            <div className="p-4 overflow-auto bg-slate-950 flex items-center justify-center min-h-[400px]">
              <img
                src={singleDiagramUrl}
                alt="Full Mind Map Graphic"
                className="max-w-full max-h-[70vh] object-contain rounded-xl border border-slate-800 shadow-2xl"
              />
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-900 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-mono">
                <Check className="w-3.5 h-3.5" />
                <span>Single 1600x1050 graphic generated successfully & saved to gallery!</span>
              </span>

              <button
                onClick={() => setIsDiagramModalOpen(false)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
