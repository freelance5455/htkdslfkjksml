import React, { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, RotateCcw } from 'lucide-react';
import type { AttendanceRecord, ComputedDay, DayStatus, UserProfile } from '../types';
import {
  MAX_NOTE_LENGTH,
  WEEKDAYS_SHORT_HEADERS,
  computeMonthDays,
  formatArabicDateFull,
  formatArabicMonthYear,
  formatDateKey,
  getDaysInMonth,
  getStatusLabelAr,
  getStatusShortAr,
  getWeekdayUTC,
} from '../utils/attendance';

interface AttendanceCalendarProps {
  year: number;
  month: number;
  todayKey: string;
  profile: UserProfile;
  recordsMap: Map<string, AttendanceRecord>;
  saving: boolean;
  onChangeMonth: (nextYear: number, nextMonth: number) => void;
  onGoToToday: () => void;
  onSetDayOverride: (dateKey: string, status: DayStatus, note: string) => Promise<void>;
  onDeleteDayOverride: (dateKey: string) => Promise<void>;
}

export const AttendanceCalendar: React.FC<AttendanceCalendarProps> = ({
  year,
  month,
  todayKey,
  profile,
  recordsMap,
  saving,
  onChangeMonth,
  onGoToToday,
  onSetDayOverride,
  onDeleteDayOverride,
}) => {
  const [selectedDateKey, setSelectedDateKey] = useState<string | null>(null);
  const [noteInput, setNoteInput] = useState<string>('');

  const { calendarDays, summary } = useMemo(
    () => computeMonthDays(year, month, todayKey, profile, recordsMap),
    [year, month, todayKey, profile, recordsMap]
  );

  // Leading empty cells so Saturday (index 6) is column 0
  const firstDayKey = formatDateKey(year, month, 1);
  const firstWeekday = getWeekdayUTC(firstDayKey);
  const leadingEmptyCount = WEEKDAYS_SHORT_HEADERS.findIndex((w) => w.index === firstWeekday);
  const totalInMonth = getDaysInMonth(year, month);

  const selectedDayInfo: ComputedDay | null = useMemo(() => {
    if (!selectedDateKey) return null;
    const found = calendarDays.find((d) => d?.date === selectedDateKey);
    if (found) return found;
    const manual = recordsMap.get(selectedDateKey);
    if (manual) {
      return {
        date: selectedDateKey,
        weekday: getWeekdayUTC(selectedDateKey),
        status: manual.status,
        source: 'manual',
        isFirstReturnDay: profile.returnStartDate === selectedDateKey,
        isFuture: selectedDateKey > todayKey,
        note: manual.note || '',
      };
    }
    return null;
  }, [selectedDateKey, calendarDays, recordsMap, profile.returnStartDate, todayKey]);

  const handleSelectDay = (dayNumber: number) => {
    const key = formatDateKey(year, month, dayNumber);
    setSelectedDateKey(key);
    const manual = recordsMap.get(key);
    setNoteInput(manual?.note ?? '');
  };

  const handlePrevMonth = () => {
    if (month === 1) onChangeMonth(year - 1, 12);
    else onChangeMonth(year, month - 1);
  };

  const handleNextMonth = () => {
    if (month === 12) onChangeMonth(year + 1, 1);
    else onChangeMonth(year, month + 1);
  };

  return (
    <section id="calendar" className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-5">
      {/* Header + Attached Month Counts */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900">
            التقويم الشهري — {formatArabicMonthYear(year, month)}
          </h2>
          <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-600 tabular-nums">
            <span>
              حضور الشهر:{' '}
              <strong className="font-semibold text-emerald-700">{summary.workDays} يوم</strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              اعتيادي:{' '}
              <strong className="font-semibold text-sky-700">{summary.annualLeaveDays} يوم</strong>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handlePrevMonth}
            aria-label="الشهر السابق"
            className="p-2 min-h-[40px] min-w-[40px] inline-flex items-center justify-center border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <ChevronRight className="w-4 h-4" aria-hidden="true" />
          </button>
          <button
            type="button"
            onClick={onGoToToday}
            className="px-3.5 py-2 min-h-[40px] text-xs font-medium border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap"
          >
            الشهر الحالي
          </button>
          <button
            type="button"
            onClick={handleNextMonth}
            aria-label="الشهر التالي"
            className="p-2 min-h-[40px] min-w-[40px] inline-flex items-center justify-center border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Calendar Grid */}
      <div>
        <div className="grid grid-cols-7 gap-1.5 mb-2 text-center">
          {WEEKDAYS_SHORT_HEADERS.map((w) => (
            <div key={w.index} className="text-xs font-semibold text-slate-500 py-1">
              <span className="hidden sm:inline">{w.label}</span>
              <span className="sm:hidden">{w.short}</span>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1.5">
          {Array.from({ length: leadingEmptyCount }).map((_, idx) => (
            <div key={`empty-${idx}`} className="min-h-[68px] sm:min-h-[76px] rounded-lg bg-slate-50/50" />
          ))}

          {Array.from({ length: totalInMonth }).map((_, idx) => {
            const dayNumber = idx + 1;
            const dateKey = formatDateKey(year, month, dayNumber);
            const info = calendarDays[idx];
            const isToday = dateKey === todayKey;
            const isSelected = dateKey === selectedDateKey;
            const isFirstReturn = profile.returnStartDate === dateKey;

            let cellStyle = 'bg-white border-slate-200 text-slate-700 hover:border-slate-300';
            let statusTextColor = 'text-slate-700';

            if (info) {
              if (info.status === 'work') {
                cellStyle =
                  info.isFuture && info.source === 'auto'
                    ? 'bg-emerald-50/40 border-emerald-200/60 text-emerald-900 opacity-70 hover:opacity-100'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-950 hover:border-emerald-300';
                statusTextColor = 'text-emerald-800';
              } else {
                cellStyle = 'bg-sky-50 border-sky-200 text-sky-950 hover:border-sky-300';
                statusTextColor = 'text-sky-800';
              }
            }

            return (
              <button
                key={dateKey}
                type="button"
                onClick={() => handleSelectDay(dayNumber)}
                className={`min-h-[68px] sm:min-h-[76px] p-2 rounded-lg border text-right flex flex-col justify-between transition-colors focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-slate-900 ${cellStyle} ${
                  isSelected ? 'ring-2 ring-slate-900 ring-offset-1' : ''
                }`}
              >
                <div className="flex items-center justify-between gap-1 w-full">
                  <span
                    className={`text-xs sm:text-sm font-mono-num tabular-nums ${
                      isToday
                        ? 'font-bold underline decoration-2 underline-offset-4 text-slate-900'
                        : 'font-semibold'
                    }`}
                  >
                    {dayNumber}
                  </span>
                  {isFirstReturn && (
                    <span className="text-[10px] font-semibold text-slate-900 hidden sm:inline">
                      العودة
                    </span>
                  )}
                </div>

                {info ? (
                  <div className="w-full">
                    <span className={`block text-[11px] sm:text-xs font-semibold truncate ${statusTextColor}`}>
                      {info.isFuture && info.source === 'auto'
                        ? `متوقع: ${getStatusShortAr(info.status)}`
                        : getStatusShortAr(info.status)}
                    </span>
                    {info.source === 'manual' && info.status === 'work' && (
                      <span className="hidden sm:block text-[10px] text-slate-500 truncate">
                        يدوي
                      </span>
                    )}
                  </div>
                ) : (
                  <span className="text-[10px] text-slate-400">—</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Inline Day Inspector */}
      {selectedDateKey && (
        <div className="border-t border-slate-200 pt-4 flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div className="space-y-1">
            <div className="text-sm font-bold text-slate-900">
              {formatArabicDateFull(selectedDateKey)}
            </div>
            <div className="text-xs text-slate-600 flex flex-wrap items-center gap-2">
              {selectedDayInfo ? (
                <>
                  <span>
                    الحالة الحالية:{' '}
                    <strong
                      className={
                        selectedDayInfo.status === 'work' ? 'text-emerald-700' : 'text-sky-700'
                      }
                    >
                      {getStatusLabelAr(selectedDayInfo.status)}
                    </strong>
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {selectedDayInfo.source === 'manual' ? 'تم تسجيله يدوياً' : 'محسوب تلقائياً'}
                  </span>
                </>
              ) : (
                <span>يمكنك تسجيل هذا اليوم كحضور أو إجازة اعتيادي.</span>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <input
              type="text"
              value={noteInput}
              maxLength={MAX_NOTE_LENGTH}
              onChange={(e) => setNoteInput(e.target.value)}
              placeholder="ملاحظة اختيارية"
              className="px-3 py-2 min-h-[40px] w-full sm:w-48 text-xs text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
            <button
              type="button"
              disabled={saving}
              onClick={() => void onSetDayOverride(selectedDateKey, 'work', noteInput)}
              className="px-3.5 py-2 min-h-[40px] text-xs font-semibold text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors whitespace-nowrap"
            >
              حضور
            </button>
            <button
              type="button"
              disabled={saving}
              onClick={() => void onSetDayOverride(selectedDateKey, 'annual', noteInput)}
              className="px-3.5 py-2 min-h-[40px] text-xs font-semibold text-sky-900 bg-sky-50 hover:bg-sky-100 border border-sky-200 rounded-lg transition-colors whitespace-nowrap"
            >
              إجازة اعتيادي
            </button>
            {recordsMap.has(selectedDateKey) && (
              <button
                type="button"
                disabled={saving}
                onClick={() => void onDeleteDayOverride(selectedDateKey)}
                className="inline-flex items-center gap-1 px-3 py-2 min-h-[40px] text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
              >
                <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                <span>العودة للتلقائي</span>
              </button>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
