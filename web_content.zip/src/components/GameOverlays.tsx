import { formatTime, mapById, MISSION, WAVES, type ControlSettings, type Loadout, type SpeciesKey } from "@/data";
import {
  AnimalMark,
  ArrowLeft,
  ArrowRight,
  AwardIcon,
  BookIcon,
  CheckIcon,
  ClockIcon,
  CompassIcon,
  CrosshairIcon,
  LocateIcon,
  MountainMark,
  MutedIcon,
  PlayIcon,
  ReloadIcon,
  RifleIcon,
  SoundIcon,
  TargetIcon,
  TrophyIcon,
} from "@/components/Icons";

/* ---------------------------------- pause --------------------------------- */

interface PauseProps {
  loadout: Loadout;
  harvested: number;
  score: number;
  timeLeft: number;
  shots: number;
  hits: number;
  muted: boolean;
  waveIndex: number;
  wavesCleared: number;
  controls: ControlSettings;
  onResume: () => void;
  onGuide: () => void;
  onLoadout: () => void;
  onControls: () => void;
  onRestart: () => void;
  onQuit: () => void;
  onToggleMute: () => void;
}

export function PauseOverlay({
  loadout,
  harvested,
  score,
  timeLeft,
  shots,
  hits,
  muted,
  waveIndex,
  wavesCleared,
  controls,
  onResume,
  onGuide,
  onLoadout,
  onControls,
  onRestart,
  onQuit,
  onToggleMute,
}: PauseProps) {
  const accuracy = shots > 0 ? Math.round((hits / shots) * 100) : 0;
  const items = [
    { label: "Resume the hunt", detail: "Back to the ridge", action: onResume, icon: <PlayIcon size={15} />, primary: true },
    { label: "Field guide", detail: "Species, habits & ethics", action: onGuide, icon: <BookIcon size={15} /> },
    { label: "Change rifle", detail: `${loadout.name} · ${loadout.calibre}`, action: onLoadout, icon: <RifleIcon size={16} /> },
    { label: "Android controls", detail: `Option ${controls.layout} · ${controls.layout === "A" ? "Thumbstick" : "Field D-pad"}`, action: onControls, icon: <LocateIcon size={15} /> },
    { label: "Restart assignment", detail: "A fresh morning, same ridge", action: onRestart, icon: <ReloadIcon size={15} /> },
    { label: "Return to camp", detail: "Abandon this expedition", action: onQuit, icon: <ArrowLeft size={15} /> },
  ];

  return (
    <div className="fixed inset-0 z-[72] flex items-center justify-center overflow-y-auto p-3 sm:p-6">
      <div className="absolute inset-0 animate-fade bg-bark-950/72 backdrop-blur-xl" onClick={onResume} />
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Hunt paused"
        className="relative z-10 my-auto grid max-h-[92dvh] w-full max-w-3xl animate-rise overflow-y-auto rounded-sm border border-sand-100/16 bg-bark-900 shadow-[0_40px_120px_-30px_rgba(0,0,0,0.95)] md:grid-cols-[0.82fr_1.18fr]"
      >
        <div className="relative overflow-hidden border-b border-sand-100/10 p-6 md:border-b-0 md:border-r sm:p-7">
          <div className="absolute inset-0 bg-gradient-to-br from-bark-700/70 via-bark-900 to-bark-950" />
          <div className="absolute inset-0 sight-grid opacity-25" />
          <div className="relative">
            <span className="text-brass-300">
              <MountainMark size={38} />
            </span>
            <p className="eyebrow mt-4 text-[0.52rem] text-brass-300">Ridgeline Hunting Club</p>
            <h2 className="mt-2 font-serif text-3xl leading-none text-sand-100">Hold the ridge.</h2>
            <p className="mt-2 text-[0.78rem] leading-relaxed text-sand-300/75">The wind will wait. The mountain always does.</p>

            <div className="mt-6 rounded-sm border border-sand-100/12 bg-bark-950/40 p-3.5">
              <p className="eyebrow text-[0.46rem] text-sand-400">Assignment progress</p>
              <div className="mt-2 flex items-end justify-between">
                <p className="font-serif text-lg leading-none text-sand-100">{MISSION.name}</p>
                <p className="num text-sm text-brass-300">{wavesCleared} / {WAVES.length}</p>
              </div>
              <div className="mt-2.5 flex gap-1">
                {WAVES.map((wave, index) => (
                  <span
                    key={wave.id}
                    className={`h-1 flex-1 ${index < wavesCleared ? "bg-brass-300" : index === waveIndex ? "bg-brass-300/45" : "bg-sand-100/15"}`}
                  />
                ))}
              </div>
              <p className="eyebrow mt-1.5 text-[0.42rem] text-sand-400">
                Drive {Math.min(waveIndex + 1, WAVES.length)} of {WAVES.length} · {harvested} taken
              </p>
              <div className="mt-3 grid grid-cols-3 gap-2 border-t border-sand-100/10 pt-2.5">
                {[
                  ["Score", score.toLocaleString()],
                  ["Accuracy", `${accuracy}%`],
                  ["Time", formatTime(timeLeft)],
                ].map(([label, value]) => (
                  <div key={label}>
                    <p className="eyebrow text-[0.42rem] text-sand-400">{label}</p>
                    <p className="num mt-1 text-[0.8rem] text-sand-100">{value}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-sand-300/70">
                <CompassIcon size={12} className="text-brass-300/80" />
                <span className="eyebrow text-[0.44rem]">Unit 12 · Northern Range</span>
              </span>
              <button
                onClick={onToggleMute}
                aria-label={muted ? "Unmute" : "Mute"}
                className="flex h-8 w-8 items-center justify-center rounded-sm border border-sand-100/16 text-sand-300 transition hover:border-brass-300/50 hover:text-brass-300"
              >
                {muted ? <MutedIcon size={14} /> : <SoundIcon size={14} />}
              </button>
            </div>
          </div>
        </div>

        <div className="p-5 sm:p-7">
          <div className="flex items-center justify-between">
            <span className="eyebrow text-brass-300">Paused · field camp</span>
            <span className="num text-[0.62rem] tracking-[0.14em] text-sand-400">{loadout.calibre}</span>
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <span className="rounded-sm border border-sand-100/14 px-2 py-1">
              <span className="eyebrow text-[0.42rem] text-sand-300">{mapById(controls.map).name}</span>
            </span>
            <span className={`rounded-sm border px-2 py-1 ${controls.infiniteAmmo ? "border-brass-300/35 bg-brass-300/8" : "border-sand-100/14"}`}>
              <span className="eyebrow text-[0.42rem] text-brass-300">{controls.infiniteAmmo ? "∞ ammunition" : "Limited ammo"}</span>
            </span>
            <span className="rounded-sm border border-sand-100/14 px-2 py-1">
              <span className="eyebrow text-[0.42rem] text-sand-300">Android · Option {controls.layout}</span>
            </span>
          </div>
          <div className="mt-4 space-y-1.5">
            {items.map((item, index) => (
              <button
                key={item.label}
                onClick={item.action}
                className={`group flex w-full items-center gap-3 rounded-sm border px-3.5 py-3 text-left transition ${
                  item.primary
                    ? "border-brass-300/50 bg-brass-300/12 hover:bg-brass-300/20"
                    : "border-sand-100/10 hover:border-sand-100/20 hover:bg-sand-100/5"
                }`}
              >
                <span className={`flex h-8 w-8 items-center justify-center rounded-sm border ${item.primary ? "border-brass-300/40 text-brass-300" : "border-sand-100/15 text-sand-300"}`}>
                  {item.icon}
                </span>
                <span className="min-w-0 flex-1">
                  <span className={`block font-condensed text-[0.86rem] uppercase tracking-[0.12em] ${item.primary ? "text-brass-200" : "text-sand-100"}`}>
                    {item.label}
                  </span>
                  <span className="eyebrow mt-0.5 block text-[0.44rem] text-sand-400">{item.detail}</span>
                </span>
                <span className="num text-[0.58rem] text-sand-400/60">{String(index + 1).padStart(2, "0")}</span>
                <ArrowRight size={13} className="text-sand-400 transition-transform group-hover:translate-x-0.5 group-hover:text-brass-300" />
              </button>
            ))}
          </div>

          <div className="mt-4 grid grid-cols-3 gap-2 border-t border-sand-100/10 pt-3.5">
            {[
              ["Move", "W A S D"],
              ["Steady", "SHIFT"],
              ["Reload", "R"],
            ].map(([label, keys]) => (
              <div key={label} className="flex items-center gap-2">
                <kbd className="rounded-[2px] border border-sand-100/18 bg-bark-950/40 px-1.5 py-1 font-condensed text-[0.52rem] uppercase tracking-[0.08em] text-sand-200">
                  {keys}
                </kbd>
                <span className="eyebrow text-[0.4rem] text-sand-400">{label}</span>
              </div>
            ))}
          </div>
          <p className="mt-3 flex items-center gap-1.5 text-[0.6rem] text-sand-400">
            <CrosshairIcon size={11} className="text-brass-300/70" />
            Press <kbd className="rounded-[2px] border border-sand-100/20 px-1 font-condensed text-[0.55rem] text-sand-200">ESC</kbd> to close this menu
          </p>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- results -------------------------------- */

export interface HuntOutcome {
  completed: boolean;
  score: number;
  harvested: number;
  shots: number;
  hits: number;
  accuracy: number;
  longestShot: number;
  bag: Partial<Record<SpeciesKey, number>>;
  timeLeft: number;
  objectives: { label: string; met: boolean; bonus: number }[];
  bonus: number;
  wavesCleared: number;
  waveBonus: number;
}

interface ResultsProps {
  outcome: HuntOutcome;
  loadout: Loadout;
  onReplay: () => void;
  onCamp: () => void;
  onRecords: () => void;
}

export function ResultsOverlay({ outcome, loadout, onReplay, onCamp, onRecords }: ResultsProps) {
  const bag = Object.entries(outcome.bag).filter(([, count]) => (count ?? 0) > 0) as [SpeciesKey, number][];
  const totalScore = outcome.score + outcome.bonus;

  return (
    <div className="fixed inset-0 z-[74] flex items-center justify-center overflow-y-auto p-3 sm:p-6">
      <div className="absolute inset-0 animate-fade bg-bark-950/82 backdrop-blur-xl" />
      <div className="pointer-events-none absolute inset-0 grain" />
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Hunt results"
        className="relative z-10 my-auto w-full max-w-3xl animate-rise overflow-hidden rounded-sm border border-sand-100/18 bg-bark-900 shadow-[0_50px_140px_-30px_rgba(0,0,0,0.95)]"
      >
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brass-300/70 to-transparent" />
        <div className="relative overflow-hidden border-b border-sand-100/10 bg-gradient-to-br from-bark-700/70 via-bark-900 to-bark-950 px-5 py-6 text-center sm:px-8 sm:py-8">
          <div className="absolute inset-0 sight-grid opacity-20" />
          <div className="absolute left-1/2 top-1/2 h-48 w-48 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brass-300/10 blur-3xl" />
          <div className="relative">
            <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-brass-300/40 bg-brass-300/10 text-brass-300">
              {outcome.completed ? <TrophyIcon size={28} /> : <ClockIcon size={26} />}
            </span>
            <p className="eyebrow mt-4 text-[0.55rem] text-brass-300">
              {outcome.completed ? "Assignment complete · The Golden Ridge" : "Last light · The Golden Ridge"}
            </p>
            <h2 className="mt-2 font-serif text-[2.4rem] leading-none text-sand-100 sm:text-[3.1rem]">
              {outcome.completed ? "A morning well kept." : "The ridge keeps its own time."}
            </h2>
            <p className="mx-auto mt-3 max-w-md text-pretty text-[0.82rem] leading-relaxed text-sand-300/80">
              {outcome.completed
                ? "Three clean harvests, honest decisions, and a walk back to camp with something to remember. The mountain noticed."
                : "Not every morning ends with a full tag. The wild owes you nothing — and there is always first light tomorrow."}
            </p>

            <div className="mt-5 inline-flex items-baseline gap-2 rounded-sm border border-brass-300/25 bg-bark-950/45 px-5 py-2.5">
              <span className="num text-4xl leading-none text-brass-300">{totalScore.toLocaleString()}</span>
              <span className="eyebrow text-[0.5rem] text-sand-400">final score</span>
            </div>
          </div>
        </div>

        <div className="px-5 py-5 sm:px-8 sm:py-6">
          <div className="grid grid-cols-2 gap-px overflow-hidden rounded-sm border border-sand-100/10 bg-sand-100/10 sm:grid-cols-4">
            {[
              { label: "Harvested", value: `${outcome.harvested} / ${MISSION.goal}`, icon: <TargetIcon size={14} /> },
              { label: "Accuracy", value: `${Math.round(outcome.accuracy)}%`, icon: <CrosshairIcon size={14} /> },
              { label: "Longest shot", value: outcome.longestShot > 0 ? `${Math.round(outcome.longestShot)} m` : "—", icon: <CompassIcon size={14} /> },
              { label: "Time remaining", value: formatTime(outcome.timeLeft), icon: <ClockIcon size={14} /> },
            ].map((item) => (
              <div key={item.label} className="bg-bark-900 px-3.5 py-3.5">
                <span className="text-brass-300/80">{item.icon}</span>
                <p className="num mt-2 text-2xl leading-none text-sand-100">{item.value}</p>
                <p className="eyebrow mt-1.5 text-[0.44rem] text-sand-400">{item.label}</p>
              </div>
            ))}
          </div>

          <div className="mt-3 flex flex-col gap-2 rounded-sm border border-sand-100/10 bg-bark-950/25 px-3.5 py-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <span className="text-brass-300"><TargetIcon size={13} /></span>
              <span className="eyebrow text-[0.44rem] text-sand-300/80">Drives cleared</span>
              <span className="num text-[0.72rem] text-sand-100">{outcome.wavesCleared} / {WAVES.length}</span>
            </div>
            <div className="flex flex-1 gap-1 sm:max-w-[220px]">
              {WAVES.map((wave, index) => (
                <span key={wave.id} className={`h-1.5 flex-1 rounded-full ${index < outcome.wavesCleared ? "bg-brass-300" : "bg-sand-100/15"}`} />
              ))}
            </div>
            {outcome.waveBonus > 0 && <span className="num text-[0.6rem] text-brass-300">+{outcome.waveBonus.toLocaleString()} drive bonus</span>}
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_0.9fr]">
            <div className="rounded-sm border border-sand-100/10 p-3.5">
              <p className="eyebrow text-[0.46rem] text-brass-300">Assignment objectives</p>
              <div className="mt-2.5 space-y-2">
                {outcome.objectives.map((objective) => (
                  <div key={objective.label} className="flex items-center gap-2.5">
                    <span className={`flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-full border ${objective.met ? "border-brass-300/50 bg-brass-300/15 text-brass-300" : "border-sand-100/20 text-sand-400/50"}`}>
                      {objective.met ? <CheckIcon size={10} /> : <span className="h-px w-1.5 bg-current" />}
                    </span>
                    <span className={`flex-1 text-[0.72rem] ${objective.met ? "text-sand-200" : "text-sand-400"}`}>{objective.label}</span>
                    <span className={`num text-[0.6rem] ${objective.met ? "text-brass-300" : "text-sand-400/50"}`}>+{objective.bonus}</span>
                  </div>
                ))}
              </div>
              <div className="mt-3 flex items-center gap-2 border-t border-sand-100/10 pt-2.5">
                <RifleIcon size={13} className="text-brass-300/80" />
                <span className="eyebrow text-[0.44rem] text-sand-400">{loadout.name} · {loadout.calibre}</span>
              </div>
            </div>

            <div className="rounded-sm border border-sand-100/10 p-3.5">
              <p className="eyebrow text-[0.46rem] text-brass-300">The bag</p>
              {bag.length > 0 ? (
                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  {bag.map(([key, count]) => (
                    <span key={key} className="flex items-center gap-1.5 rounded-sm border border-brass-300/20 bg-brass-300/5 px-2 py-1.5 text-[0.66rem] capitalize text-sand-200">
                      <span className="text-brass-300">
                        <AnimalMark species={key} size={16} />
                      </span>
                      {key} <span className="num text-brass-300">×{count}</span>
                    </span>
                  ))}
                </div>
              ) : (
                <p className="mt-3 text-[0.7rem] leading-relaxed text-sand-400">
                  The bag stayed empty — but a morning in the quiet is its own kind of take.
                </p>
              )}
              <button
                onClick={onRecords}
                className="mt-3 flex items-center gap-1.5 font-condensed text-[0.58rem] uppercase tracking-[0.14em] text-brass-300 transition hover:text-brass-200"
              >
                <AwardIcon size={12} /> Open record book <ArrowRight size={11} />
              </button>
            </div>
          </div>

          <div className="mt-5 flex flex-col gap-2 sm:flex-row">
            <button onClick={onReplay} className="btn-primary h-12 flex-1 text-xs">
              <ReloadIcon size={13} /> Hunt the ridge again
            </button>
            <button onClick={onCamp} className="btn-ghost h-12 flex-1 text-xs">
              <ArrowLeft size={13} /> Return to camp
            </button>
          </div>
          <p className="mt-3 text-center text-[0.58rem] text-sand-400/70">
            Your expedition has been entered into the club record book.
          </p>
        </div>
      </div>
    </div>
  );
}
