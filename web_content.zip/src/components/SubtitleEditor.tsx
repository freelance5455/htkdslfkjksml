import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Play,
  Download,
  Upload,
  Check,
  Subtitles,
  FileText,
  HelpCircle,
} from 'lucide-react';
import { SubtitleCue } from '../types';
import { exportToSrt, exportToVtt, parseSrt } from '../services/subtitleParser';
import { hindiTtsService } from '../services/ttsService';

interface SubtitleEditorProps {
  subtitles: SubtitleCue[];
  onUpdateSubtitles: (cues: SubtitleCue[]) => void;
  videoDuration: number;
}

export const SubtitleEditor: React.FC<SubtitleEditorProps> = ({
  subtitles,
  onUpdateSubtitles,
  videoDuration,
}) => {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [successToast, setSuccessToast] = useState<string>('');

  const triggerToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(''), 3000);
  };

  const handleFieldChange = (
    id: number,
    field: 'startTime' | 'endTime' | 'hindiText' | 'originalText',
    value: any
  ) => {
    const updated = subtitles.map((cue) => {
      if (cue.id === id) {
        return { ...cue, [field]: value };
      }
      return cue;
    });
    onUpdateSubtitles(updated);
  };

  const handleAddCue = () => {
    const lastCue = subtitles[subtitles.length - 1];
    const newStart = lastCue ? parseFloat((lastCue.endTime + 0.5).toFixed(1)) : 0;
    const newEnd = parseFloat((newStart + 4.0).toFixed(1));

    const newCue: SubtitleCue = {
      id: Date.now(),
      startTime: newStart,
      endTime: newEnd,
      hindiText: 'नया हिंदी उपशीर्षक यहाँ लिखें...',
      originalText: 'New English subtitle here...',
      romanizedHindi: 'Naya Hindi upsheershak yahan likhein...',
    };

    onUpdateSubtitles([...subtitles, newCue]);
    setEditingId(newCue.id);
    triggerToast('नया उपशीर्षक जोड़ा गया');
  };

  const handleDeleteCue = (id: number) => {
    const filtered = subtitles.filter((c) => c.id !== id);
    onUpdateSubtitles(filtered);
    triggerToast('उपशीर्षक हटा दिया गया');
  };

  // Download SRT
  const handleExportSrt = () => {
    const srt = exportToSrt(subtitles);
    const blob = new Blob([srt], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'hindi_subtitles.srt';
    link.click();
    URL.revokeObjectURL(url);
    triggerToast('hindi_subtitles.srt डाउनलोड हो गया');
  };

  // Download VTT
  const handleExportVtt = () => {
    const vtt = exportToVtt(subtitles);
    const blob = new Blob([vtt], { type: 'text/vtt;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'hindi_subtitles.vtt';
    link.click();
    URL.revokeObjectURL(url);
    triggerToast('hindi_subtitles.vtt डाउनलोड हो गया');
  };

  // Import SRT file
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        const parsed = parseSrt(text);
        if (parsed.length > 0) {
          onUpdateSubtitles(parsed);
          triggerToast(`${parsed.length} उपशीर्षक सफलतापूर्वक आयात किए गए`);
        } else {
          alert('मान्य SRT उपशीर्षक नहीं मिला।');
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Subtitles className="w-5 h-5 text-orange-400" />
            <span>मैनुअल हिंदी उपशीर्षक संपादक (Manual Subtitle Editor)</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            बिना किसी शुल्क या एपीआई के सीधे हिंदी उपशीर्षक और टाइमस्टैम्प संपादित करें (Zero-Cost Offline Mode)
          </p>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer transition-colors border border-slate-700">
            <Upload className="w-3.5 h-3.5" />
            <span>SRT आयात करें</span>
            <input type="file" accept=".srt,.vtt,.txt" onChange={handleImportFile} className="hidden" />
          </label>

          <button
            onClick={handleExportSrt}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors border border-slate-700"
          >
            <Download className="w-3.5 h-3.5" />
            <span>SRT निर्यात</span>
          </button>

          <button
            onClick={handleExportVtt}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors border border-slate-700"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>VTT निर्यात</span>
          </button>

          <button
            onClick={handleAddCue}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>नया उपशीर्षक जोड़ें</span>
          </button>
        </div>
      </div>

      {/* Toast Notification */}
      {successToast && (
        <div className="px-4 py-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Subtitle Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-semibold">
                <th className="p-3 w-12 text-center">#</th>
                <th className="p-3 w-32">शुरुआत (Sec)</th>
                <th className="p-3 w-32">समाप्ति (Sec)</th>
                <th className="p-3">हिंदी उपशीर्षक (Hindi Subtitle)</th>
                <th className="p-3">मूल टेक्स्ट (English Source)</th>
                <th className="p-3 w-28 text-center">कार्रवाई</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {subtitles.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500">
                    कोई उपशीर्षक नहीं है। नया जोड़ने के लिए ऊपर दिए गए बटन पर क्लिक करें।
                  </td>
                </tr>
              ) : (
                subtitles.map((cue, index) => (
                  <tr
                    key={cue.id}
                    className="hover:bg-slate-800/40 transition-colors group"
                  >
                    <td className="p-3 text-center font-mono text-slate-500">
                      {index + 1}
                    </td>

                    <td className="p-3">
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          step="0.1"
                          min="0"
                          value={cue.startTime}
                          onChange={(e) =>
                            handleFieldChange(cue.id, 'startTime', parseFloat(e.target.value) || 0)
                          }
                          className="w-16 bg-slate-950 border border-slate-800 rounded px-2 py-1 font-mono text-slate-200 focus:outline-none focus:border-orange-500"
                        />
                        <span className="text-[10px] text-slate-500">सेकंड</span>
                      </div>
                    </td>

                    <td className="p-3">
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          step="0.1"
                          min="0"
                          value={cue.endTime}
                          onChange={(e) =>
                            handleFieldChange(cue.id, 'endTime', parseFloat(e.target.value) || 0)
                          }
                          className="w-16 bg-slate-950 border border-slate-800 rounded px-2 py-1 font-mono text-slate-200 focus:outline-none focus:border-orange-500"
                        />
                        <span className="text-[10px] text-slate-500">सेकंड</span>
                      </div>
                    </td>

                    <td className="p-3">
                      <textarea
                        rows={2}
                        value={cue.hindiText}
                        onChange={(e) => handleFieldChange(cue.id, 'hindiText', e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 font-hindi text-yellow-300 font-medium focus:outline-none focus:border-orange-500 leading-relaxed text-xs"
                      />
                    </td>

                    <td className="p-3">
                      <textarea
                        rows={2}
                        value={cue.originalText || ''}
                        onChange={(e) => handleFieldChange(cue.id, 'originalText', e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-300 focus:outline-none focus:border-orange-500 text-xs"
                      />
                    </td>

                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          title="इस हिंदी टेक्स्ट को बोलकर सुनें"
                          onClick={() => hindiTtsService.speakHindiText(cue.hindiText)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-orange-600 text-slate-300 hover:text-white transition-colors"
                        >
                          <Play className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          title="हटाएं"
                          onClick={() => handleDeleteCue(cue.id)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-red-600 text-slate-400 hover:text-white transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
