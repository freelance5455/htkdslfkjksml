"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { ApiError, apiPost, apiPut } from "@/lib/client/api";
import { Spinner } from "./ui";

type Mode = "login" | "signup" | "forgot" | "reset";

const COPY: Record<Mode, { title: string; subtitle: string; cta: string }> = {
  login: { title: "Welcome back", subtitle: "Sign in to keep creating.", cta: "Sign in" },
  signup: { title: "Create your account", subtitle: "Start with free credits — no card needed.", cta: "Create account" },
  forgot: { title: "Reset your password", subtitle: "We'll send a reset link to your email.", cta: "Send reset link" },
  reset: { title: "Choose a new password", subtitle: "Make it at least 8 characters with a number.", cta: "Update password" },
};

export default function AuthCard({ mode, token = "" }: { mode: Mode; token?: string }) {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "", token });
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const copy = COPY[mode];

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (busy) return;
    setError(null);
    setInfo(null);
    setBusy(true);
    try {
      if (mode === "login") {
        await apiPost("/api/auth/login", { email: form.email, password: form.password });
        router.push("/home");
        router.refresh();
        return;
      }
      if (mode === "signup") {
        await apiPost("/api/auth/signup", form);
        router.push("/home");
        router.refresh();
        return;
      }
      if (mode === "forgot") {
        const res = await apiPost<{ message: string; devToken?: string }>("/api/auth/password", { email: form.email });
        setInfo(
          res.devToken
            ? `${res.message} Dev reset link: /reset-password?token=${res.devToken}`
            : res.message,
        );
        return;
      }
      await apiPut("/api/auth/password", form);
      setInfo("Password updated. Redirecting to sign in…");
      setTimeout(() => router.push("/login"), 1200);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto w-full max-w-md px-4 py-10">
      <Link href="/" className="mb-6 flex items-center justify-center gap-2">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-lg">🛠️</span>
        <span className="font-bold">Creator Toolkit</span>
      </Link>
      <div className="card p-5">
        <h1 className="text-xl font-bold">{copy.title}</h1>
        <p className="mt-1 text-sm text-[color:var(--muted)]">{copy.subtitle}</p>

        <form onSubmit={submit} className="mt-4 space-y-3" noValidate>
          {mode === "signup" ? (
            <div>
              <label className="label" htmlFor="name">
                Name
              </label>
              <input
                id="name"
                className="input"
                autoComplete="name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Alex Rivera"
              />
            </div>
          ) : null}

          {mode !== "reset" ? (
            <div>
              <label className="label" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                className="input"
                autoComplete="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="you@channel.com"
              />
            </div>
          ) : null}

          {mode !== "forgot" ? (
            <div>
              <label className="label" htmlFor="password">
                {mode === "reset" ? "New password" : "Password"}
              </label>
              <input
                id="password"
                type="password"
                required
                className="input"
                autoComplete={mode === "login" ? "current-password" : "new-password"}
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder="••••••••"
              />
            </div>
          ) : null}

          {mode === "signup" || mode === "reset" ? (
            <div>
              <label className="label" htmlFor="confirm">
                Confirm password
              </label>
              <input
                id="confirm"
                type="password"
                required
                className="input"
                autoComplete="new-password"
                value={form.confirmPassword}
                onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
                placeholder="••••••••"
              />
            </div>
          ) : null}

          {error ? (
            <p className="rounded-xl border border-rose-400/30 bg-rose-500/10 p-3 text-sm text-rose-100">{error}</p>
          ) : null}
          {info ? (
            <p className="rounded-xl border border-emerald-400/30 bg-emerald-500/10 p-3 text-sm break-words text-emerald-100">
              {info}
            </p>
          ) : null}

          <button type="submit" className="btn btn-primary w-full" disabled={busy}>
            {busy ? (
              <>
                <Spinner /> Working…
              </>
            ) : (
              copy.cta
            )}
          </button>
        </form>

        <div className="mt-4 space-y-1 text-center text-xs text-[color:var(--muted)]">
          {mode === "login" ? (
            <>
              <p>
                New here?{" "}
                <Link href="/signup" className="text-violet-300">
                  Create an account
                </Link>
              </p>
              <p>
                <Link href="/forgot-password" className="text-violet-300">
                  Forgot your password?
                </Link>
              </p>
            </>
          ) : (
            <p>
              Already have an account?{" "}
              <Link href="/login" className="text-violet-300">
                Sign in
              </Link>
            </p>
          )}
        </div>
      </div>
      <p className="mt-4 text-center text-[0.7rem] text-[color:var(--muted)]">
        Passwords are hashed with scrypt and sessions use httpOnly cookies.
      </p>
    </div>
  );
}
