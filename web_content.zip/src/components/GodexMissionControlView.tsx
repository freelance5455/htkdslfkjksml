/**
 * GODEX Phase 1.2 — Mission Control Center UI
 * Full user-facing Mission Control experience with real-time DAG task visualization,
 * epistemic evidence inspection, multi-agent status matrix, human approval gates,
 * pause/resume/cancel controls, truthful failure/recovery diagnostics, and 25-suite simulation runner.
 */

import React, { useState, useEffect, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  Compass,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Shield,
  Layers,
  Cpu,
  Brain,
  FileCode,
  Activity,
  Award,
  Terminal,
  RefreshCw,
  Plus,
  Send,
  Lock,
  Eye,
  Check,
  ChevronRight,
  GitBranch,
  Search,
  Sparkles,
  ShieldAlert,
  ArrowRight,
  CheckSquare,
  HelpCircle,
  Sliders,
  FolderGit2,
  FileCheck2,
  Zap,
  Info,
  AlertCircle,
  Database,
  History,
  Trash2
} from 'lucide-react';
import { Mission, AutonomyLevel, MissionStatus, MissionTimelineEvent } from '../mission/missionTypes';
import { MissionManager } from '../mission/missionManager';
import { MissionHistorySummary } from '../mission/missionPersistence';
import { SimulationMissionTestRunner, MissionTestResult } from '../mission/simulationMissionTest';
import { OrchestrationTask, AgentRoleType } from '../orchestration/orchestrationTypes';
import { EngineeringMemoryEngine } from '../memory/engineeringMemory';
import { EngineeringMemoryEntry, MemoryTrustLevel } from '../memory/memoryTypes';
import { MemoryInvalidationEngine } from '../memory/memoryInvalidation';

interface GodexMissionControlViewProps {
  files: Record<string, string>;
  onFileMutated?: (files: Record<string, string>) => void;
  onSelectWorkspaceView?: (view: string) => void;
}

export function GodexMissionControlView({
  files,
  onFileMutated,
  onSelectWorkspaceView
}: GodexMissionControlViewProps) {
  const [mission, setMission] = useState<Mission | null>(() => MissionManager.getInstance().getActiveMission());
  const [allMissions, setAllMissions] = useState<Mission[]>(() => MissionManager.getInstance().getAllMissions());
  const [activeTab, setActiveTab] = useState<'overview' | 'tasks' | 'agents' | 'activity' | 'evidence' | 'recovery' | 'checkpoints' | 'memory' | 'history' | 'tests'>('overview');
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [autonomyLevel, setAutonomyLevel] = useState<AutonomyLevel>('CONTROLLED');
  const [newMissionObjective, setNewMissionObjective] = useState<string>('');
  const [isStartingMission, setIsStartingMission] = useState(false);
  const [testResults, setTestResults] = useState<{ passedCount: number; totalCount: number; results: MissionTestResult[] } | null>(null);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [approvalNotes, setApprovalNotes] = useState<string>('');
  const [taskFilter, setTaskFilter] = useState<'ALL' | 'ACTIVE' | 'COMPLETED' | 'BLOCKED_FAILED'>('ALL');
  const [viewMode, setViewMode] = useState<'graph' | 'list'>('graph');
  const [persistedHistory, setPersistedHistory] = useState<MissionHistorySummary[]>(() => MissionManager.getInstance().getHistorySummaries());
  const [memoryTrustFilter, setMemoryTrustFilter] = useState<'ALL' | MemoryTrustLevel>('ALL');
  const [memorySearchQuery, setMemorySearchQuery] = useState<string>('');
  const [invalidationFeedback, setInvalidationFeedback] = useState<string | null>(null);

  useEffect(() => {
    const manager = MissionManager.getInstance();
    const unsub = manager.subscribe(m => {
      setMission({ ...m });
      setAllMissions(manager.getAllMissions());
      setPersistedHistory(manager.getHistorySummaries());
      if (m.autonomyLevel) setAutonomyLevel(m.autonomyLevel);
      if (m.status === 'COMPLETED' && m.evidence && m.evidence.verificationScore >= 80) {
        try {
          confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } });
        } catch {
          // confetti fallback
        }
      }
    });
    return () => unsub();
  }, []);

  const handleStartMission = async (objectiveText?: string) => {
    const obj = objectiveText || newMissionObjective;
    if (!obj.trim() || isStartingMission) return;
    setIsStartingMission(true);
    try {
      const manager = MissionManager.getInstance();
      await manager.startMission(obj, files, autonomyLevel, onFileMutated);
      setNewMissionObjective('');
    } catch (err) {
      console.error('Failed to start mission:', err);
    } finally {
      setIsStartingMission(false);
    }
  };

  const handlePause = () => {
    MissionManager.getInstance().pauseMission();
  };

  const handleResume = async () => {
    await MissionManager.getInstance().resumeMission(files, onFileMutated);
  };

  const handleCancel = () => {
    MissionManager.getInstance().cancelMission();
  };

  const handleReplan = () => {
    if (!mission) return;
    MissionManager.getInstance().replanActiveMission('Manual developer replan requested', files);
  };

  const handleApprove = async () => {
    const notes = approvalNotes.trim() || 'Approved via Mission Control UI';
    await MissionManager.getInstance().approveCurrentAction(notes);
    setApprovalNotes('');
  };

  const handleReject = async () => {
    const reason = approvalNotes.trim() || 'Declined by developer via Mission Control UI';
    await MissionManager.getInstance().rejectCurrentAction(reason);
    setApprovalNotes('');
  };

  const handleLoadMission = (missionId: string) => {
    const loaded = MissionManager.getInstance().loadMissionById(missionId, files);
    if (loaded) {
      setMission({ ...loaded });
      setActiveTab('overview');
    }
  };

  const handleClearHistory = () => {
    MissionManager.getInstance().clearHistory();
    setPersistedHistory(MissionManager.getInstance().getHistorySummaries());
  };

  const handleRunSimulationTests = async () => {
    setIsRunningTests(true);
    try {
      const res = await SimulationMissionTestRunner.runAllTests();
      setTestResults(res);
      setActiveTab('tests');
    } catch (err) {
      console.error('Failed to run mission simulation tests:', err);
    } finally {
      setIsRunningTests(false);
    }
  };

  const getStatusBadge = (status: MissionStatus) => {
    switch (status) {
      case 'COMPLETED':
        return {
          label: 'COMPLETED',
          classes: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
          dot: 'bg-emerald-400 animate-pulse'
        };
      case 'EXECUTING':
        return {
          label: 'EXECUTING',
          classes: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/40',
          dot: 'bg-cyan-400 animate-ping'
        };
      case 'VERIFYING':
        return {
          label: 'VERIFYING (6-PILLAR)',
          classes: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/40',
          dot: 'bg-indigo-400 animate-spin'
        };
      case 'WAITING_FOR_APPROVAL':
        return {
          label: 'APPROVAL GATE ACTIVE',
          classes: 'bg-amber-500/15 text-amber-300 border-amber-500/40 animate-pulse',
          dot: 'bg-amber-400 animate-ping'
        };
      case 'RECOVERING':
        return {
          label: 'SELF-HEALING RECOVERY',
          classes: 'bg-purple-500/15 text-purple-300 border-purple-500/40',
          dot: 'bg-purple-400 animate-pulse'
        };
      case 'REPLANNING':
        return {
          label: 'DAG REPLANNING',
          classes: 'bg-violet-500/15 text-violet-300 border-violet-500/40',
          dot: 'bg-violet-400 animate-spin'
        };
      case 'PAUSED':
        return {
          label: 'PAUSED',
          classes: 'bg-yellow-500/10 text-yellow-300 border-yellow-500/30',
          dot: 'bg-yellow-400'
        };
      case 'BLOCKED':
        return {
          label: 'BLOCKED (INTERVENTION REQUIRED)',
          classes: 'bg-rose-500/15 text-rose-300 border-rose-500/40',
          dot: 'bg-rose-400'
        };
      case 'FAILED':
        return {
          label: 'FAILED',
          classes: 'bg-rose-500/20 text-rose-400 border-rose-500/50',
          dot: 'bg-rose-500'
        };
      case 'CANCELLED':
        return {
          label: 'CANCELLED',
          classes: 'bg-slate-800 text-slate-400 border-slate-700',
          dot: 'bg-slate-500'
        };
      default:
        return {
          label: status,
          classes: 'bg-slate-800/80 text-slate-300 border-slate-700',
          dot: 'bg-slate-400'
        };
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'CRITICAL':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/40';
      case 'HIGH':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/40';
      case 'MEDIUM':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40';
      default:
        return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  const getRoleBadge = (role: AgentRoleType) => {
    switch (role) {
      case 'ARCHITECT':
        return { bg: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30', label: 'Architect' };
      case 'RESEARCHER':
        return { bg: 'bg-blue-500/15 text-blue-300 border-blue-500/30', label: 'Researcher' };
      case 'CODER':
        return { bg: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30', label: 'Safe Coder' };
      case 'DEBUGGER':
        return { bg: 'bg-rose-500/15 text-rose-300 border-rose-500/30', label: 'Debugger' };
      case 'TESTER':
        return { bg: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30', label: 'Tester' };
      case 'REVIEWER':
        return { bg: 'bg-purple-500/15 text-purple-300 border-purple-500/30', label: 'Reviewer' };
      case 'VERIFIER':
        return { bg: 'bg-teal-500/15 text-teal-300 border-teal-500/30', label: 'Verifier' };
      default:
        return { bg: 'bg-slate-800 text-slate-300 border-slate-700', label: role };
    }
  };

  const filteredTasks = useMemo(() => {
    if (!mission) return [];
    if (taskFilter === 'ACTIVE') {
      return mission.tasks.filter(t => t.status === 'RUNNING' || t.status === 'READY' || t.status === 'WAITING' || (t.status as string) === 'WAITING_FOR_APPROVAL');
    }
    if (taskFilter === 'COMPLETED') {
      return mission.tasks.filter(t => t.status === 'COMPLETED');
    }
    if (taskFilter === 'BLOCKED_FAILED') {
      return mission.tasks.filter(t => t.status === 'FAILED' || t.status === 'BLOCKED' || t.status === 'CANCELLED');
    }
    return mission.tasks;
  }, [mission, taskFilter]);

  const selectedTask = mission?.tasks.find(t => t.id === selectedTaskId) || mission?.tasks.find(t => t.status === 'RUNNING') || mission?.tasks[0];
  const activeExecutingTask = mission?.tasks.find(t => t.status === 'RUNNING' || t.id === mission.activeTaskId);

  return (
    <div className="flex flex-col h-full bg-[#0A0F1C] text-slate-100 overflow-hidden select-none font-sans">
      {/* 1. TOP MISSION CONTROL BANNER */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 bg-[#0D1527] border-b border-[#18233C]">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-400 shadow-sm">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold tracking-widest text-slate-400 uppercase">GODEX Mission Control</span>
              {mission ? (
                (() => {
                  const badge = getStatusBadge(mission.status);
                  return (
                    <span className={`px-2.5 py-0.5 text-[11px] font-bold rounded-md border flex items-center gap-1.5 ${badge.classes}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                      {badge.label}
                    </span>
                  );
                })()
              ) : (
                <span className="px-2 py-0.5 text-[10px] font-medium rounded border bg-slate-800 text-slate-400 border-slate-700">
                  IDLE / STANDBY
                </span>
              )}
              {mission && (
                <span className={`px-2 py-0.5 text-[10px] font-semibold rounded border ${getRiskColor(mission.riskLevel)}`}>
                  RISK: {mission.riskLevel}
                </span>
              )}
            </div>
            <h1 className="text-sm font-semibold text-slate-100 truncate max-w-xl mt-0.5">
              {mission ? mission.title : 'Ready to launch autonomous engineering mission'}
            </h1>
          </div>
        </div>

        {/* Action Controls & Autonomy Selector */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Autonomy Level Control */}
          <div className="flex items-center gap-1 bg-[#111A30] p-1 rounded-lg border border-[#1E2C4D] text-xs">
            <span className="text-slate-400 px-1 font-mono text-[11px]">Autonomy:</span>
            {(['ASSISTED', 'CONTROLLED', 'AUTONOMOUS'] as AutonomyLevel[]).map(lvl => (
              <button
                key={lvl}
                onClick={() => setAutonomyLevel(lvl)}
                className={`px-2 py-0.5 rounded font-medium text-xs transition-all ${
                  autonomyLevel === lvl
                    ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>

          {/* Pause / Resume / Cancel Controls */}
          {mission && mission.status === 'EXECUTING' && (
            <button
              onClick={handlePause}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-semibold transition shadow-sm cursor-pointer"
            >
              <Pause className="w-3.5 h-3.5" /> Pause
            </button>
          )}

          {mission && mission.status === 'PAUSED' && (
            <button
              onClick={handleResume}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition shadow-sm cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" /> Resume
            </button>
          )}

          {mission && (mission.status === 'EXECUTING' || mission.status === 'WAITING_FOR_APPROVAL' || mission.status === 'PAUSED' || mission.status === 'RECOVERING') && (
            <button
              onClick={handleCancel}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-semibold transition cursor-pointer"
            >
              <XCircle className="w-3.5 h-3.5" /> Cancel
            </button>
          )}

          {mission && (
            <button
              onClick={handleReplan}
              title="Dynamically replan remaining tasks"
              className="flex items-center gap-1 px-2.5 py-1.5 bg-[#141F38] hover:bg-[#1C2A4A] text-slate-300 border border-[#23355C] rounded-lg text-xs font-semibold transition cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Replan
            </button>
          )}

          <button
            onClick={handleRunSimulationTests}
            disabled={isRunningTests}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 rounded-lg text-xs font-semibold transition disabled:opacity-50 cursor-pointer"
          >
            <Shield className="w-3.5 h-3.5" /> {isRunningTests ? 'Executing 25 Suites...' : 'Run Simulation Suite'}
          </button>
        </div>
      </div>

      {/* 2. HUMAN APPROVAL GATE BANNER */}
      {mission?.status === 'WAITING_FOR_APPROVAL' && mission.approvalGate && (
        <div className="bg-[#1C160B] border-b border-amber-500/50 px-5 py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-in fade-in duration-300">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 bg-amber-500/25 text-amber-300 rounded-xl border border-amber-500/40 shrink-0">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                  Human Approval Gate Triggered
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-500/20 text-amber-300 rounded border border-amber-500/30">
                  POLICY: {mission.autonomyLevel}
                </span>
              </div>
              <div className="text-sm font-semibold text-slate-100 mt-0.5">
                {mission.approvalGate.action}
              </div>
              <div className="text-xs text-amber-200/80 mt-1 max-w-2xl">
                <strong>Reason:</strong> {mission.approvalGate.reason} | <strong>Evidence:</strong> {mission.approvalGate.evidence}
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto">
            <input
              type="text"
              placeholder="Optional developer approval notes..."
              value={approvalNotes}
              onChange={e => setApprovalNotes(e.target.value)}
              className="px-3 py-1.5 bg-[#0D1322] border border-amber-500/40 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleApprove}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition shadow cursor-pointer"
              >
                <Check className="w-3.5 h-3.5" /> Approve & Execute
              </button>
              <button
                onClick={handleReject}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1 px-4 py-1.5 bg-rose-600/30 hover:bg-rose-600/40 text-rose-300 border border-rose-500/40 rounded-lg text-xs font-bold transition cursor-pointer"
              >
                <XCircle className="w-3.5 h-3.5" /> Reject / Block
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. LIVE PROGRESS & STATS BAR */}
      {mission && (
        <div className="bg-[#0B101E] border-b border-[#18233C] px-5 py-2.5 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3.5 flex-1 min-w-[280px]">
            <div className="w-full max-w-md bg-[#131C33] rounded-full h-2.5 overflow-hidden border border-[#202E54]">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 via-cyan-400 to-emerald-400 transition-all duration-500 rounded-full"
                style={{ width: `${mission.progress.percentage}%` }}
              />
            </div>
            <span className="font-mono text-cyan-400 font-bold text-xs">{mission.progress.percentage}%</span>
            <span className="text-slate-400 text-xs">
              <strong className="text-slate-200">{mission.completedTasks.length}</strong> / {mission.tasks.length} tasks verified
            </span>
          </div>

          <div className="flex items-center gap-4 text-slate-400 text-xs">
            {activeExecutingTask && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-cyan-950/40 border border-cyan-800/60 rounded-md text-cyan-300 font-mono text-[11px]">
                <Activity className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                <span className="font-bold">[{activeExecutingTask.role}]</span>
                <span className="truncate max-w-[160px]">{activeExecutingTask.title}</span>
              </div>
            )}
            <span>Gates: <strong className="text-slate-200">{mission.progress.passedGatesCount}/{mission.progress.totalGatesCount}</strong></span>
            <span>Checkpoints: <strong className="text-slate-200">{mission.checkpoints.length}</strong></span>
            <span>Memories: <strong className="text-slate-200">{mission.memoryReferences.length}</strong></span>
          </div>
        </div>
      )}

      {/* 4. TAB NAVIGATION */}
      <div className="flex items-center gap-1 px-5 bg-[#090E1B] border-b border-[#18233C] overflow-x-auto text-xs shrink-0">
        {[
          { id: 'overview', label: 'Mission Overview', icon: Compass },
          { id: 'tasks', label: `DAG Tasks (${mission?.tasks.length || 0})`, icon: Layers },
          { id: 'agents', label: 'Agent Matrix', icon: Cpu },
          { id: 'activity', label: `Timeline (${mission?.timeline.length || 0})`, icon: Activity },
          { id: 'evidence', label: '7-Pillar Evidence', icon: Award },
          { id: 'recovery', label: `Recovery & Loops ${mission?.status === 'RECOVERING' || mission?.status === 'BLOCKED' ? '(!)' : ''}`, icon: RotateCcw },
          { id: 'checkpoints', label: `Checkpoints (${mission?.checkpoints.length || 0})`, icon: FolderGit2 },
          { id: 'history', label: `Durable History (${persistedHistory.length})`, icon: Database },
          { id: 'memory', label: 'Knowledge Hub', icon: Brain },
          { id: 'tests', label: `Simulation Suite ${testResults ? `(${testResults.passedCount}/${testResults.totalCount})` : '(25)'}`, icon: Shield }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3.5 py-2.5 font-medium border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5 font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* 5. MAIN TAB CONTENT */}
      <div className="flex-1 overflow-y-auto p-5">
        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-5 max-w-5xl mx-auto">
            {/* New Mission Launcher Card */}
            <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-5 shadow-sm">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2.5 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" /> Launch Autonomous Engineering Mission
              </h2>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={newMissionObjective}
                  onChange={e => setNewMissionObjective(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleStartMission()}
                  placeholder="Describe engineering objective (e.g. 'Build a complete authentication system with JWT, role-based gates, and tests')"
                  className="flex-1 px-3.5 py-2.5 bg-[#090E1B] border border-[#202E54] rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
                <button
                  onClick={() => handleStartMission()}
                  disabled={isStartingMission || !newMissionObjective.trim()}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition disabled:opacity-50 shadow-sm cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" /> {isStartingMission ? 'Decomposing...' : 'Start Mission'}
                </button>
              </div>

              {/* Sample Mission Presets */}
              <div className="flex flex-wrap gap-2 mt-3.5 text-xs">
                <span className="text-slate-500 self-center text-[11px] font-medium">Presets:</span>
                {[
                  'Build complete auth module with JWT, token refresh, and tests',
                  'Refactor state management with strict TypeScript type assertions',
                  'Add payment checkout workflow with schema validation and sanitization',
                  'Optimize application bundle performance and run full security audit',
                  'Generate comprehensive unit test suite covering state transitions'
                ].map(preset => (
                  <button
                    key={preset}
                    onClick={() => {
                      setNewMissionObjective(preset);
                      handleStartMission(preset);
                    }}
                    className="px-2.5 py-1 bg-[#141E36] hover:bg-[#1B294A] text-slate-300 rounded border border-[#22335C] transition text-left truncate max-w-xs text-[11px] cursor-pointer"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Current Active Mission Overview */}
            {mission ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Left 2 Cols: Mission Details */}
                <div className="md:col-span-2 space-y-4">
                  {/* Mission Summary Card */}
                  <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4.5 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                        Mission Objective & Specifications
                      </h3>
                      <span className="text-xs font-mono text-slate-400">ID: {mission.id}</span>
                    </div>
                    <p className="text-sm text-slate-100 font-medium leading-relaxed bg-[#090E1B] p-3 rounded-lg border border-[#1A2642]">
                      {mission.objective}
                    </p>
                    <div className="flex flex-wrap gap-2 text-xs">
                      <span className="px-2.5 py-1 bg-[#141E36] text-slate-300 rounded-md border border-[#22335C]">
                        Priority: <strong>{mission.priority}</strong>
                      </span>
                      <span className="px-2.5 py-1 bg-[#141E36] text-slate-300 rounded-md border border-[#22335C]">
                        Autonomy: <strong>{mission.autonomyLevel}</strong>
                      </span>
                      <span className="px-2.5 py-1 bg-[#141E36] text-slate-300 rounded-md border border-[#22335C]">
                        DAG Tasks: <strong>{mission.tasks.length} total</strong>
                      </span>
                      <span className="px-2.5 py-1 bg-[#141E36] text-slate-300 rounded-md border border-[#22335C]">
                        Retries: <strong>{mission.budget.currentRetries}/{mission.budget.maxRetries}</strong>
                      </span>
                    </div>
                  </div>

                  {/* Failure / Blocked Alert Card if active */}
                  {(mission.status === 'FAILED' || mission.status === 'BLOCKED' || mission.status === 'RECOVERING') && (
                    <div className="bg-rose-950/30 border border-rose-500/40 rounded-xl p-4 space-y-2">
                      <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase">
                        <AlertCircle className="w-4 h-4" />
                        {mission.status === 'RECOVERING' ? 'Mission Self-Healing Recovery Active' : 'Mission Requires Diagnostic Attention'}
                      </div>
                      <p className="text-xs text-rose-200">
                        {mission.failureSummary?.whyFailed || 'Task execution or verification did not satisfy constraints.'}
                      </p>
                      {mission.failureSummary?.whatFailed && mission.failureSummary.whatFailed.length > 0 && (
                        <div className="text-[11px] text-rose-300/80">
                          <strong>Failed Components:</strong> {mission.failureSummary.whatFailed.join(', ')}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Active Task Card */}
                  <div className="bg-[#0F1629] border border-indigo-500/30 rounded-xl p-4.5 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                        <Activity className="w-3.5 h-3.5 animate-pulse" /> Current Focused Task
                      </span>
                      {selectedTask && (
                        (() => {
                          const r = getRoleBadge(selectedTask.role);
                          return (
                            <span className={`text-xs font-mono px-2.5 py-0.5 rounded border ${r.bg}`}>
                              {selectedTask.role}
                            </span>
                          );
                        })()
                      )}
                    </div>
                    {selectedTask ? (
                      <div className="space-y-1.5">
                        <h4 className="text-sm font-semibold text-slate-100">{selectedTask.title}</h4>
                        <p className="text-xs text-slate-400">{selectedTask.description}</p>
                        <div className="pt-2 text-[11px] text-slate-400 flex flex-wrap gap-3">
                          <span>Status: <strong className="text-cyan-400">{selectedTask.status}</strong></span>
                          <span>Target Files: <strong className="text-slate-200">{selectedTask.targetFiles.join(', ') || 'Global Project Scope'}</strong></span>
                        </div>
                        {selectedTask.statusMessage && (
                          <div className="mt-2 p-2 bg-[#090E1B] rounded border border-[#1A2642] font-mono text-[11px] text-emerald-400">
                            {selectedTask.statusMessage}
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-500">No task currently selected.</p>
                    )}
                  </div>
                </div>

                {/* Right Col: Epistemic Grounding Matrix */}
                <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4.5 space-y-3.5">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <Brain className="w-3.5 h-3.5 text-indigo-400" /> Epistemic Grounding
                    </h3>
                    <span className="text-[10px] text-slate-500">Truthful State</span>
                  </div>

                  {mission.evidence?.epistemicBreakdown ? (
                    <div className="space-y-3 text-xs">
                      <div className="p-2.5 bg-emerald-950/20 border border-emerald-500/20 rounded-lg">
                        <div className="text-[11px] font-bold text-emerald-400 uppercase flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Known (AST Verified)
                        </div>
                        <ul className="list-disc list-inside text-slate-300 space-y-1 mt-1 text-[11px]">
                          {mission.evidence.epistemicBreakdown.known.slice(0, 4).map((k, i) => (
                            <li key={i} className="truncate">{k}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="p-2.5 bg-cyan-950/20 border border-cyan-500/20 rounded-lg">
                        <div className="text-[11px] font-bold text-cyan-400 uppercase flex items-center gap-1">
                          <Info className="w-3 h-3" /> Likely (Inferred Structure)
                        </div>
                        <ul className="list-disc list-inside text-slate-300 space-y-1 mt-1 text-[11px]">
                          {mission.evidence.epistemicBreakdown.likely.slice(0, 3).map((l, i) => (
                            <li key={i} className="truncate">{l}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="p-2.5 bg-amber-950/20 border border-amber-500/20 rounded-lg">
                        <div className="text-[11px] font-bold text-amber-400 uppercase flex items-center gap-1">
                          <HelpCircle className="w-3 h-3" /> Unknown (Boundaries)
                        </div>
                        <ul className="list-disc list-inside text-slate-300 space-y-1 mt-1 text-[11px]">
                          {mission.evidence.epistemicBreakdown.unknown.length > 0 ? (
                            mission.evidence.epistemicBreakdown.unknown.map((u, i) => (
                              <li key={i} className="truncate">{u}</li>
                            ))
                          ) : (
                            <li className="text-slate-500">Zero unresolved boundary unknowns.</li>
                          )}
                        </ul>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 bg-[#090E1B] border border-dashed border-[#1E2C4D] rounded-lg text-center">
                      <Brain className="w-6 h-6 text-slate-600 mx-auto mb-1.5" />
                      <p className="text-xs text-slate-400 font-medium">Grounding Matrix Compiling</p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Epistemic knowledge compiles during real task execution & validation.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="p-10 text-center bg-[#0F1629]/50 border border-dashed border-[#1E2C4D] rounded-xl">
                <Compass className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                <p className="text-sm font-semibold text-slate-300">No autonomous mission currently loaded.</p>
                <p className="text-xs text-slate-500 mt-1">Enter an engineering goal above or select a preset to launch DAG execution.</p>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: TASKS (DAG VIEW & LIST VIEW) */}
        {activeTab === 'tasks' && mission && (
          <div className="space-y-4 max-w-5xl mx-auto">
            {/* Filter & View Mode Controls */}
            <div className="flex items-center justify-between flex-wrap gap-2 bg-[#0F1629] p-2.5 rounded-lg border border-[#1E2C4D]">
              <div className="flex items-center gap-1 text-xs">
                <span className="text-slate-400 font-medium px-1 text-[11px]">Filter:</span>
                {(['ALL', 'ACTIVE', 'COMPLETED', 'BLOCKED_FAILED'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setTaskFilter(f)}
                    className={`px-2.5 py-1 rounded text-xs transition cursor-pointer ${
                      taskFilter === f ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {f === 'ALL' ? 'All Tasks' : f === 'ACTIVE' ? 'Active / Ready' : f === 'COMPLETED' ? 'Completed' : 'Blocked / Failed'}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-1 text-xs">
                <button
                  onClick={() => setViewMode('graph')}
                  className={`px-2.5 py-1 rounded text-xs transition cursor-pointer ${
                    viewMode === 'graph' ? 'bg-[#1E2C4D] text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  DAG Flow
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-2.5 py-1 rounded text-xs transition cursor-pointer ${
                    viewMode === 'list' ? 'bg-[#1E2C4D] text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  List Inspector
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Task Items / DAG Graph */}
              <div className="md:col-span-2 space-y-2.5">
                {filteredTasks.map((task, idx) => {
                  const isSelected = selectedTaskId === task.id || (!selectedTaskId && idx === 0);
                  const isCompleted = task.status === 'COMPLETED';
                  const isRunning = task.status === 'RUNNING';
                  const isFailed = task.status === 'FAILED';
                  const isWaitingApproval = task.status === 'WAITING' || (task.status as string) === 'WAITING_FOR_APPROVAL';
                  const roleBadge = getRoleBadge(task.role);
                  const taskRisk = (task as any).riskLevel || task.risk || 'LOW';

                  return (
                    <div
                      key={task.id}
                      onClick={() => setSelectedTaskId(task.id)}
                      className={`p-3.5 rounded-xl border cursor-pointer transition flex items-start justify-between gap-3 ${
                        isSelected
                          ? 'bg-[#121B33] border-indigo-500 shadow-md'
                          : 'bg-[#0F1629] border-[#1E2C4D] hover:border-[#2E4273]'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="mt-0.5">
                          {isCompleted ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          ) : isRunning ? (
                            <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin" />
                          ) : isWaitingApproval ? (
                            <AlertTriangle className="w-4 h-4 text-amber-400 animate-pulse" />
                          ) : isFailed ? (
                            <XCircle className="w-4 h-4 text-rose-400" />
                          ) : (
                            <div className="w-4 h-4 rounded-full border border-slate-600 flex items-center justify-center text-[10px] text-slate-400 font-mono">
                              {idx + 1}
                            </div>
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold text-slate-100">{task.title}</span>
                            <span className={`px-1.5 py-0.5 text-[10px] font-mono rounded border ${roleBadge.bg}`}>
                              {task.role}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{task.description}</div>
                          
                          <div className="flex items-center gap-3 mt-2 text-[10px] text-slate-400">
                            {task.dependencies.length > 0 && (
                              <span className="flex items-center gap-1 font-mono text-slate-400">
                                <GitBranch className="w-3 h-3 text-slate-500" /> Depends on: {task.dependencies.join(', ')}
                              </span>
                            )}
                            {task.targetFiles.length > 0 && (
                              <span className="font-mono text-slate-400 truncate max-w-xs">
                                Targets: {task.targetFiles.join(', ')}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-1 shrink-0">
                        <span className={`px-2 py-0.5 text-[10px] font-bold rounded border ${
                          isCompleted ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
                          isRunning ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30 animate-pulse' :
                          isWaitingApproval ? 'bg-amber-500/15 text-amber-300 border-amber-500/40 animate-pulse' :
                          isFailed ? 'bg-rose-500/10 text-rose-400 border-rose-500/30' :
                          'bg-slate-800 text-slate-400 border-slate-700'
                        }`}>
                          {task.status}
                        </span>
                        <span className={`text-[10px] font-semibold ${
                          taskRisk === 'CRITICAL' ? 'text-rose-400' :
                          taskRisk === 'HIGH' ? 'text-amber-400' :
                          'text-slate-500'
                        }`}>
                          {taskRisk}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Task Detail Inspector Drawer */}
              <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4.5 space-y-3.5">
                <div className="flex items-center justify-between pb-2 border-b border-[#1A2642]">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Task Specification
                  </h3>
                  {selectedTask && (
                    <span className="font-mono text-[10px] text-slate-500">#{selectedTask.id}</span>
                  )}
                </div>

                {selectedTask ? (
                  <div className="space-y-3 text-xs">
                    <div>
                      <div className="text-slate-500 text-[10px] uppercase font-bold">Title</div>
                      <div className="font-semibold text-slate-100 mt-0.5">{selectedTask.title}</div>
                    </div>
                    <div>
                      <div className="text-slate-500 text-[10px] uppercase font-bold">Description & Contract</div>
                      <div className="text-slate-300 leading-relaxed mt-0.5 bg-[#090E1B] p-2.5 rounded border border-[#1A2642]">
                        {selectedTask.description}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <div className="text-slate-500 text-[10px] uppercase font-bold">Assigned Role</div>
                        <div className="font-mono text-cyan-300 font-semibold mt-0.5">{selectedTask.role}</div>
                      </div>
                      <div>
                        <div className="text-slate-500 text-[10px] uppercase font-bold">Risk Level</div>
                        <div className={`font-semibold mt-0.5 ${
                          ((selectedTask as any).riskLevel || selectedTask.risk) === 'CRITICAL' ? 'text-rose-400' :
                          ((selectedTask as any).riskLevel || selectedTask.risk) === 'HIGH' ? 'text-amber-400' : 'text-slate-300'
                        }`}>
                          {(selectedTask as any).riskLevel || selectedTask.risk || 'LOW'}
                        </div>
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-500 text-[10px] uppercase font-bold">Target Files</div>
                      <div className="font-mono text-slate-200 mt-0.5 text-[11px] bg-[#090E1B] p-1.5 rounded border border-[#1A2642]">
                        {selectedTask.targetFiles.length > 0 ? selectedTask.targetFiles.join(', ') : 'Global Scope'}
                      </div>
                    </div>
                    {selectedTask.statusMessage && (
                      <div>
                        <div className="text-slate-500 text-[10px] uppercase font-bold">Execution Output</div>
                        <div className="p-2.5 bg-[#090E1B] rounded border border-[#1A2642] font-mono text-[11px] text-emerald-400 leading-relaxed">
                          {selectedTask.statusMessage}
                        </div>
                      </div>
                    )}
                    {selectedTask.error && (
                      <div>
                        <div className="text-rose-400 text-[10px] uppercase font-bold">Error Diagnostic</div>
                        <div className="p-2.5 bg-rose-950/30 rounded border border-rose-800/50 font-mono text-[11px] text-rose-300">
                          {selectedTask.error}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500">Select any task to inspect its dependencies and execution output.</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: AGENTS MATRIX */}
        {activeTab === 'agents' && (
          <div className="max-w-5xl mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Phase 6 Multi-Agent Operational Matrix
              </h3>
              <span className="text-xs text-slate-500">Deterministic Autonomous Roles</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {[
                { role: 'ARCHITECT' as AgentRoleType, title: 'System Architect', desc: 'Designs modular structure, contract types, and DAG decomposition strategies.' },
                { role: 'RESEARCHER' as AgentRoleType, title: 'Deep Code Researcher', desc: 'Inspects symbols, AST dependencies, and project requirements.' },
                { role: 'CODER' as AgentRoleType, title: 'Safe Mutation Coder', desc: 'Applies surgical AST patches gated through ConflictManager and ControlPlane.' },
                { role: 'DEBUGGER' as AgentRoleType, title: 'Self-Healing Debugger', desc: 'Diagnoses failure root causes, generates repair plans, and enforces loop boundaries.' },
                { role: 'TESTER' as AgentRoleType, title: 'Verification Tester', desc: 'Executes unit tests, static assertions, and chaos test suites.' },
                { role: 'REVIEWER' as AgentRoleType, title: 'Security & AST Reviewer', desc: 'Sanitizes secrets, detects security regressions, and validates syntax.' },
                { role: 'VERIFIER' as AgentRoleType, title: 'Final Dossier Verifier', desc: 'Assembles comprehensive 6-pillar evidence dossiers and confirms release criteria.' }
              ].map(ag => {
                const assignedTasks = mission?.tasks.filter(t => t.role === ag.role) || [];
                const isRunning = assignedTasks.some(t => t.status === 'RUNNING');
                const isVerified = assignedTasks.some(t => t.status === 'COMPLETED');

                return (
                  <div key={ag.role} className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4 flex flex-col justify-between space-y-3">
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-mono text-xs font-bold text-cyan-400">{ag.role}</span>
                        <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                          isRunning ? 'bg-cyan-500/20 text-cyan-300 animate-pulse' :
                          isVerified ? 'bg-emerald-500/20 text-emerald-300' :
                          'bg-slate-800 text-slate-500'
                        }`}>
                          {isRunning ? 'ACTIVE' : isVerified ? 'VERIFIED' : 'IDLE'}
                        </span>
                      </div>
                      <div className="text-xs font-semibold text-slate-100">{ag.title}</div>
                      <div className="text-[11px] text-slate-400 mt-1 leading-relaxed">{ag.desc}</div>
                    </div>
                    <div className="pt-2 border-t border-[#1A2642] flex items-center justify-between text-[11px] text-slate-500">
                      <span>Tasks: <strong>{assignedTasks.length}</strong></span>
                      <span>Completed: <strong className="text-slate-300">{assignedTasks.filter(t => t.status === 'COMPLETED').length}</strong></span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 4: ACTIVITY TIMELINE */}
        {activeTab === 'activity' && mission && (
          <div className="max-w-4xl mx-auto space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Chronological Mission Event Stream
            </h3>
            {mission.timeline.length > 0 ? (
              mission.timeline.slice().reverse().map((ev, i) => (
                <div key={ev.id || i} className="p-3.5 bg-[#0F1629] border border-[#1E2C4D] rounded-xl flex items-start gap-3 text-xs">
                  <div className="mt-0.5">
                    {ev.status === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> :
                     ev.status === 'warning' ? <AlertTriangle className="w-4 h-4 text-amber-400" /> :
                     ev.status === 'error' ? <XCircle className="w-4 h-4 text-rose-400" /> :
                     <Clock className="w-4 h-4 text-cyan-400" />}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-200">{ev.title}</span>
                        {ev.agentRole && (
                          <span className="px-1.5 py-0.2 bg-[#141F38] text-cyan-300 rounded font-mono text-[10px]">
                            {ev.agentRole}
                          </span>
                        )}
                        <span className="px-1.5 py-0.2 bg-slate-800 text-slate-400 rounded text-[10px]">
                          {ev.stage}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-slate-500">
                        {new Date(ev.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-slate-400 mt-1 leading-relaxed">{ev.description}</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-500">Timeline events will appear as mission proceeds.</p>
            )}
          </div>
        )}

        {/* TAB 5: 6-PILLAR EVIDENCE DOSSIER */}
        {activeTab === 'evidence' && (
          <div className="max-w-4xl mx-auto space-y-4">
            {mission?.evidence ? (
              <div className="space-y-4">
                <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-5 flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-100">Verification Evidence Dossier</h3>
                    <p className="text-xs text-slate-400 mt-0.5">Aggregated from static typechecks, build tests, security scans, and AST integrity</p>
                  </div>
                  <div className="text-3xl font-bold font-mono text-emerald-400 bg-emerald-950/40 px-4 py-2 rounded-xl border border-emerald-500/30">
                    {mission.evidence.verificationScore} / 100
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                  {/* Pillar 1: Typecheck */}
                  <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4">
                    <div className="text-slate-500 text-[10px] uppercase font-bold">1. Static Typecheck</div>
                    <div className={`font-semibold mt-1.5 flex items-center gap-1.5 ${mission.evidence.typecheckResult.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {mission.evidence.typecheckResult.passed ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                      {mission.evidence.typecheckResult.passed ? 'PASSED (0 type errors)' : `FAILED (${mission.evidence.typecheckResult.errorCount} errors)`}
                    </div>
                  </div>

                  {/* Pillar 2: Production Build */}
                  <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4">
                    <div className="text-slate-500 text-[10px] uppercase font-bold">2. Production Build Execution</div>
                    <div className={`font-semibold mt-1.5 flex items-center gap-1.5 ${mission.evidence.buildResult.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {mission.evidence.buildResult.passed ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                      {mission.evidence.buildResult.passed ? 'PASSED (Clean bundle compilation)' : 'BUILD FAILED'}
                    </div>
                  </div>

                  {/* Pillar 3: Test Suite */}
                  <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4">
                    <div className="text-slate-500 text-[10px] uppercase font-bold">3. Test Suite Assertions</div>
                    <div className={`font-semibold mt-1.5 flex items-center gap-1.5 ${mission.evidence.testResults.failed === 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {mission.evidence.testResults.failed === 0 ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                      {mission.evidence.testResults.summary}
                    </div>
                  </div>

                  {/* Pillar 4: Security Sanitizer */}
                  <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4">
                    <div className="text-slate-500 text-[10px] uppercase font-bold">4. Security Sanitizer Audit</div>
                    <div className={`font-semibold mt-1.5 flex items-center gap-1.5 ${mission.evidence.securityAudit.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {mission.evidence.securityAudit.passed ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                      {mission.evidence.securityAudit.passed ? 'PASSED (0 hardcoded secrets)' : `${mission.evidence.securityAudit.violations.length} violations`}
                    </div>
                  </div>

                  {/* Mutated Files */}
                  <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4 sm:col-span-2">
                    <div className="text-slate-500 text-[10px] uppercase font-bold">Verified Mutated Files</div>
                    <div className="font-mono text-slate-200 mt-1.5">
                      {mission.evidence.filesChanged.length > 0 ? (
                        <div className="flex flex-wrap gap-1.5">
                          {mission.evidence.filesChanged.map(f => (
                            <span key={f} className="px-2 py-0.5 bg-[#090E1B] border border-[#1E2C4D] rounded text-[11px]">
                              {f}
                            </span>
                          ))}
                        </div>
                      ) : (
                        '0 files modified (Read-only or pure verification mission)'
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-10 text-center bg-[#0F1629] border border-dashed border-[#1E2C4D] rounded-xl">
                <Award className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="text-xs text-slate-400 font-medium">Evidence dossier compiles upon mission completion.</p>
              </div>
            )}
          </div>
        )}

        {/* TAB 6: RECOVERY & LOOP PROTECTION */}
        {activeTab === 'recovery' && mission && (
          <div className="max-w-4xl mx-auto space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Self-Healing Recovery & Loop Protection Status
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4">
                <div className="text-slate-500 text-[10px] uppercase font-bold">Consecutive Failures</div>
                <div className="text-xl font-bold font-mono text-slate-100 mt-1">
                  {mission.loopProtection.consecutiveFailures} / 3 max
                </div>
              </div>
              <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4">
                <div className="text-slate-500 text-[10px] uppercase font-bold">Oscillating Files</div>
                <div className="text-xl font-bold font-mono text-slate-100 mt-1">
                  {mission.loopProtection.oscillatingFiles.length}
                </div>
              </div>
              <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4">
                <div className="text-slate-500 text-[10px] uppercase font-bold">Total Retries</div>
                <div className="text-xl font-bold font-mono text-slate-100 mt-1">
                  {mission.budget.currentRetries} / {mission.budget.maxRetries}
                </div>
              </div>
            </div>

            {mission.failureSummary ? (
              <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-4.5 space-y-3.5 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-[#1A2642]">
                  <h4 className="font-bold text-slate-200 uppercase text-[11px]">Latest Failure Diagnosis & Recovery Strategy</h4>
                  <div className="flex items-center gap-2">
                    {mission.failureSummary.category && (
                      <span className="px-2 py-0.5 rounded font-mono text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
                        {mission.failureSummary.category}
                      </span>
                    )}
                    {mission.failureSummary.recoveryStrategy && (
                      <span className="px-2 py-0.5 rounded font-mono text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
                        {mission.failureSummary.recoveryStrategy}
                      </span>
                    )}
                  </div>
                </div>

                <div className="p-3 bg-rose-950/20 border border-rose-800/40 rounded-lg text-rose-300 leading-relaxed font-mono text-[11px]">
                  {mission.failureSummary.whyFailed}
                </div>

                {mission.failureSummary.suggestedPatchHint && (
                  <div className="p-2.5 bg-indigo-950/30 border border-indigo-700/40 rounded-lg text-indigo-200 text-[11px]">
                    <div className="text-[10px] font-bold uppercase text-indigo-400 mb-0.5">Engineering Memory Hint (Phase 7)</div>
                    {mission.failureSummary.suggestedPatchHint}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                  <div>
                    <div className="text-slate-500 text-[10px] uppercase font-bold">Preserved Tasks</div>
                    <div className="text-emerald-300 font-semibold mt-0.5">
                      {mission.failureSummary.whatCompleted.length > 0 ? `${mission.failureSummary.whatCompleted.length} tasks` : 'None'}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500 text-[10px] uppercase font-bold">Invalidated Tasks</div>
                    <div className="text-amber-300 font-semibold mt-0.5">
                      {mission.failureSummary.invalidatedTasks?.length ? `${mission.failureSummary.invalidatedTasks.length} tasks` : '0 tasks'}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500 text-[10px] uppercase font-bold">Remaining Tasks</div>
                    <div className="text-slate-300 font-semibold mt-0.5">
                      {mission.failureSummary.whatRemains.length} tasks
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-6 bg-[#0F1629] border border-[#1E2C4D] rounded-xl text-center text-xs text-slate-400">
                Zero active failure states recorded. Adaptive recovery & loop protection running nominal.
              </div>
            )}
          </div>
        )}

        {/* TAB 7: CHECKPOINTS */}
        {activeTab === 'checkpoints' && mission && (
          <div className="max-w-4xl mx-auto space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Mission Rollback Checkpoints
            </h3>
            {mission.checkpoints.length > 0 ? (
              mission.checkpoints.map((cpId, idx) => (
                <div key={cpId} className="p-3.5 bg-[#0F1629] border border-[#1E2C4D] rounded-xl flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <FolderGit2 className="w-4 h-4 text-cyan-400" />
                    <div>
                      <div className="font-semibold text-slate-200">Checkpoint #{idx + 1} ({cpId})</div>
                      <div className="text-[11px] text-slate-400">Reversible baseline snapshot captured prior to mutation</div>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 bg-[#141E36] text-slate-300 rounded font-mono text-[10px] border border-[#22335C]">
                    REVERSIBLE
                  </span>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-500">Zero checkpoints recorded.</p>
            )}
          </div>
        )}

        {/* TAB 8: VERIFIED ENGINEERING MEMORY (P1.5) */}
        {activeTab === 'memory' && (
          <div className="max-w-4xl mx-auto space-y-4">
            {/* Header & Advisory Banner */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#1E2C4D]">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                  <Database className="w-4 h-4 text-cyan-400" />
                  Verified Engineering Memory Intelligence (P1.5)
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Durable knowledge graph with cryptographic fingerprints, trust levels, and truth-first advisory ranking.
                </p>
              </div>
              <button
                onClick={() => {
                  try {
                    const memEngine = EngineeringMemoryEngine.getInstance();
                    const invalidationResult = MemoryInvalidationEngine.invalidateStaleEntriesByFingerprints(
                      memEngine.getStore(),
                      files
                    );
                    setInvalidationFeedback(
                      `Audit complete: ${invalidationResult.totalChecked} memories checked, ${invalidationResult.invalidatedCount} marked stale/invalid.`
                    );
                    setTimeout(() => setInvalidationFeedback(null), 5000);
                  } catch (err) {
                    setInvalidationFeedback(`Audit error: ${String(err)}`);
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#141E36] hover:bg-[#1B294A] text-cyan-300 border border-cyan-500/30 rounded-lg text-xs font-medium transition cursor-pointer self-start sm:self-auto"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Re-Verify Against Workspace
              </button>
            </div>

            {/* Invalidation Alert Banner */}
            {invalidationFeedback && (
              <div className="p-3 bg-cyan-950/30 border border-cyan-500/40 rounded-xl text-xs text-cyan-200 flex items-center gap-2 animate-fadeIn">
                <Info className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>{invalidationFeedback}</span>
              </div>
            )}

            {/* Advisory Principle Notice */}
            <div className="p-3 bg-[#090E1B] border border-amber-500/30 rounded-xl text-xs text-amber-200/90 flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-300">Core Epistemic Invariant:</strong> Historical memory is strictly{' '}
                <span className="underline decoration-amber-400 font-semibold">ADVISORY</span>. Active workspace AST,
                compiler diagnostics, static types, and test assertions take absolute precedence over historical records.
              </div>
            </div>

            {/* Memory Trust Level Stats Bar */}
            {(() => {
              const memStore = EngineeringMemoryEngine.getInstance().getStore();
              const stats = memStore.getStatsSummary();
              return (
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
                  <div className="bg-[#0F1629] border border-[#1E2C4D] rounded-xl p-3">
                    <div className="text-slate-500 text-[10px] uppercase font-bold">Total Memories</div>
                    <div className="text-xl font-bold font-mono text-slate-100 mt-0.5">{stats.totalMemories}</div>
                  </div>
                  <div className="bg-[#0F1629] border border-emerald-500/30 rounded-xl p-3">
                    <div className="text-emerald-400 text-[10px] uppercase font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Verified
                    </div>
                    <div className="text-xl font-bold font-mono text-emerald-300 mt-0.5">
                      {stats.trustLevelCounts.VERIFIED || 0}
                    </div>
                  </div>
                  <div className="bg-[#0F1629] border border-cyan-500/30 rounded-xl p-3">
                    <div className="text-cyan-400 text-[10px] uppercase font-bold flex items-center gap-1">
                      <Info className="w-3 h-3" /> Advisory
                    </div>
                    <div className="text-xl font-bold font-mono text-cyan-300 mt-0.5">
                      {stats.trustLevelCounts.ADVISORY || 0}
                    </div>
                  </div>
                  <div className="bg-[#0F1629] border border-amber-500/30 rounded-xl p-3">
                    <div className="text-amber-400 text-[10px] uppercase font-bold flex items-center gap-1">
                      <Clock className="w-3 h-3" /> Stale
                    </div>
                    <div className="text-xl font-bold font-mono text-amber-300 mt-0.5">
                      {stats.trustLevelCounts.STALE || 0}
                    </div>
                  </div>
                  <div className="bg-[#0F1629] border border-rose-500/30 rounded-xl p-3">
                    <div className="text-rose-400 text-[10px] uppercase font-bold flex items-center gap-1">
                      <XCircle className="w-3 h-3" /> Invalid
                    </div>
                    <div className="text-xl font-bold font-mono text-rose-300 mt-0.5">
                      {stats.trustLevelCounts.INVALID || 0}
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Filter Bar */}
            <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                {(['ALL', 'VERIFIED', 'ADVISORY', 'STALE', 'INVALID'] as const).map(lvl => (
                  <button
                    key={lvl}
                    onClick={() => setMemoryTrustFilter(lvl)}
                    className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer text-[11px] whitespace-nowrap ${
                      memoryTrustFilter === lvl
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                        : 'bg-[#0F1629] text-slate-400 border border-[#1E2C4D] hover:bg-[#141E36]'
                    }`}
                  >
                    {lvl === 'ALL' ? 'All Trust Levels' : lvl}
                  </button>
                ))}
              </div>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Filter memory by query or file..."
                  value={memorySearchQuery}
                  onChange={e => setMemorySearchQuery(e.target.value)}
                  className="w-full sm:w-64 px-3 py-1.5 bg-[#090E1B] border border-[#1E2C4D] rounded-lg text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            {/* Memory List */}
            {(() => {
              const memEngine = EngineeringMemoryEngine.getInstance();
              const allEntries = memEngine.getStore().getAllEntries();
              const filtered = allEntries.filter(entry => {
                if (memoryTrustFilter !== 'ALL' && (entry.trustLevel || 'ADVISORY') !== memoryTrustFilter) {
                  return false;
                }
                if (memorySearchQuery.trim()) {
                  const q = memorySearchQuery.toLowerCase();
                  const matchContent = entry.content.toLowerCase().includes(q);
                  const matchFile = entry.relatedFiles.some(f => f.toLowerCase().includes(q));
                  const matchSymbol = entry.relatedSymbols.some(s => s.toLowerCase().includes(q));
                  const matchType = entry.type.toLowerCase().includes(q);
                  return matchContent || matchFile || matchSymbol || matchType;
                }
                return true;
              });

              if (filtered.length === 0) {
                return (
                  <div className="p-8 text-center bg-[#0F1629] border border-dashed border-[#1E2C4D] rounded-xl text-xs text-slate-400">
                    <Database className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                    No engineering memory entries match the selected filters.
                  </div>
                );
              }

              return (
                <div className="space-y-3">
                  {filtered.map(entry => {
                    const trust = entry.trustLevel || 'ADVISORY';
                    const trustBadge = {
                      VERIFIED: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
                      ADVISORY: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
                      STALE: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
                      INVALID: 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    }[trust];

                    return (
                      <div
                        key={entry.id}
                        className="p-4 bg-[#0F1629] border border-[#1E2C4D] hover:border-[#2A3F6D] rounded-xl text-xs space-y-2.5 transition"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold border ${trustBadge}`}>
                              {trust}
                            </span>
                            <span className="px-2 py-0.5 rounded font-mono text-[10px] bg-[#141E36] text-slate-300 border border-[#22335C]">
                              {entry.type}
                            </span>
                            <span className="px-2 py-0.5 rounded font-mono text-[10px] bg-[#090E1B] text-slate-400 border border-[#1A2642]">
                              {entry.epistemicStatus}
                            </span>
                            {entry.sourceMissionId && (
                              <span className="font-mono text-[10px] text-indigo-400">
                                Mission #{entry.sourceMissionId.slice(-6)}
                              </span>
                            )}
                          </div>
                          <span className="font-mono text-[10px] text-slate-500 shrink-0">
                            #{entry.id}
                          </span>
                        </div>

                        <p className="text-slate-200 font-medium leading-relaxed">{entry.content}</p>

                        {/* Fingerprints & Associated Files */}
                        {entry.relatedFiles.length > 0 && (
                          <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[11px]">
                            <span className="text-slate-500 text-[10px] font-semibold">Files:</span>
                            {entry.relatedFiles.map(f => {
                              const hasFingerprint = entry.fileFingerprints && entry.fileFingerprints[f];
                              return (
                                <span
                                  key={f}
                                  className="px-2 py-0.5 bg-[#090E1B] border border-[#1A2642] rounded text-slate-300 font-mono text-[10px] flex items-center gap-1"
                                >
                                  <FileCode className="w-2.5 h-2.5 text-cyan-400" />
                                  {f}
                                  {hasFingerprint && (
                                    <span className="text-[9px] text-emerald-400 font-mono" title="Cryptographic Content Fingerprint Verified">
                                      ✓fp
                                    </span>
                                  )}
                                </span>
                              );
                            })}
                          </div>
                        )}

                        {/* Evidence & Provenance */}
                        {entry.evidence.length > 0 && (
                          <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                            <span className="text-slate-500 text-[10px] font-semibold">Evidence:</span>
                            {entry.evidence.map((ev, i) => (
                              <span key={i} className="px-1.5 py-0.5 bg-[#141E36] text-slate-400 rounded text-[10px] font-mono">
                                {ev}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>
        )}

        {/* TAB 9: PERSISTENT HISTORY & SAFE RESUME */}
        {activeTab === 'history' && (
          <div className="max-w-4xl mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Durable Mission History & Crash-Safe Recovery (P1.4)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Interrupted missions can be safely resumed without duplicate mutations or state loss.
                </p>
              </div>
              {persistedHistory.length > 0 && (
                <button
                  onClick={handleClearHistory}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-medium transition cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Clear History
                </button>
              )}
            </div>

            {persistedHistory.length > 0 ? (
              <div className="space-y-3">
                {persistedHistory.map(h => (
                  <div
                    key={h.id}
                    className={`p-4 rounded-xl border transition-all text-xs ${
                      mission?.id === h.id
                        ? 'bg-[#111B33] border-indigo-500/50 shadow-sm'
                        : 'bg-[#0F1629] border-[#1E2C4D] hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-200 text-sm">{h.title}</span>
                          <span className="font-mono text-[10px] text-slate-500">#{h.id.slice(-8)}</span>
                          {mission?.id === h.id && (
                            <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/40 text-[10px] font-bold">
                              ACTIVE
                            </span>
                          )}
                        </div>
                        <p className="text-slate-400 text-xs">{h.objective || (h as any).userIntent}</p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {(h.resumable || (h as any).isResumable) && mission?.id !== h.id && (
                          <button
                            onClick={() => handleLoadMission(h.id)}
                            className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition shadow cursor-pointer"
                          >
                            <Play className="w-3.5 h-3.5" /> Resume Mission
                          </button>
                        )}
                        {mission?.id !== h.id && !(h.resumable || (h as any).isResumable) && (
                          <button
                            onClick={() => handleLoadMission(h.id)}
                            className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" /> Inspect Evidence
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-[#18233C] flex items-center justify-between text-[11px] text-slate-400">
                      <div className="flex items-center gap-4">
                        <span>Status: <strong className="text-slate-200">{h.status}</strong></span>
                        <span>Progress: <strong className="text-cyan-400">{Math.round((h.completedTasksCount / (h.totalTasksCount || 1)) * 100)}%</strong> ({h.completedTasksCount}/{h.totalTasksCount} tasks)</span>
                        {h.verificationScore !== undefined && (
                          <span>Score: <strong className="text-emerald-400">{h.verificationScore}/100</strong></span>
                        )}
                      </div>
                      <span className="font-mono text-slate-500">
                        Updated {new Date(h.updatedAt).toLocaleString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-10 text-center bg-[#0F1629] border border-dashed border-[#1E2C4D] rounded-xl">
                <Database className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="text-xs text-slate-400 font-medium">No persisted mission history yet. Start a mission to see durable records.</p>
              </div>
            )}
          </div>
        )}

        {/* TAB 9: SIMULATION TESTS */}
        {activeTab === 'tests' && (
          <div className="max-w-4xl mx-auto space-y-3.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Deterministic Mission Simulation Suite (25 Tests)
              </h3>
              <button
                onClick={handleRunSimulationTests}
                disabled={isRunningTests}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold disabled:opacity-50 transition cursor-pointer"
              >
                {isRunningTests ? 'Running Suite...' : 'Re-run 25 Tests'}
              </button>
            </div>

            {testResults ? (
              <div className="space-y-2.5">
                <div className="p-4 bg-[#0F1629] border border-[#1E2C4D] rounded-xl flex items-center justify-between text-xs">
                  <span className="text-slate-200 font-semibold">Simulation Test Suite Status:</span>
                  <span className="font-mono text-emerald-400 font-bold text-sm bg-emerald-950/30 px-3 py-1 rounded-lg border border-emerald-500/30">
                    {testResults.passedCount} / {testResults.totalCount} PASSED (100%)
                  </span>
                </div>
                <div className="space-y-1.5 max-h-[460px] overflow-y-auto">
                  {testResults.results.map(r => (
                    <div
                      key={r.name}
                      className="px-3.5 py-2.5 bg-[#0F1629]/80 border border-[#1E2C4D] rounded-lg flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        {r.passed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <XCircle className="w-4 h-4 text-rose-400" />
                        )}
                        <span className="text-slate-200 font-medium">{r.name}</span>
                      </div>
                      <span className="font-mono text-slate-500 text-[11px]">{r.durationMs}ms</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-10 text-center bg-[#0F1629] border border-dashed border-[#1E2C4D] rounded-xl">
                <Shield className="w-8 h-8 text-indigo-400 mx-auto mb-2" />
                <p className="text-xs text-slate-300 font-medium">Click "Run Simulation Suite" to execute all 25 mission simulation test suites.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
