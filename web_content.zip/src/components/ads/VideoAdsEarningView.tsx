import React, { useState, useEffect } from 'react';
import { 
  Tv, 
  Play, 
  Pause, 
  Clock, 
  Coins, 
  Sparkles, 
  CheckCircle2, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Zap, 
  ShieldCheck, 
  Award,
  Flame,
  Check,
  TrendingUp,
  MonitorPlay
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

export const VideoAdsEarningView: React.FC = () => {
  const { currentUser, adjustUserCoins, language } = useApp();

  const TOTAL_REQUIRED_SECONDS = 40 * 60; // 40 minutes = 2400 seconds as explicitly requested

  const [secondsWatched, setSecondsWatched] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('taskearn_40min_ads_watched_seconds');
      return saved ? Math.min(TOTAL_REQUIRED_SECONDS, parseInt(saved, 10)) : 0;
    } catch {
      return 0;
    }
  });

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [activeAdIndex, setActiveAdIndex] = useState<number>(0);
  const [hasClaimed29Coins, setHasClaimed29Coins] = useState<boolean>(false);

  const SPONSORED_ADS = [
    {
      brand: 'Tata Neu Super App',
      tagline: 'Earn 5% NeuCoins on every order & grocery!',
      category: 'Shopping & Travel',
      accent: 'from-purple-600 to-indigo-700',
      duration: '45s'
    },
    {
      brand: 'PhonePe UPI & Wealth',
      tagline: 'Zero-commission Gold investment & fast payments',
      category: 'FinTech India',
      accent: 'from-violet-700 to-purple-800',
      duration: '30s'
    },
    {
      brand: 'Flipkart Big Billion Days',
      tagline: 'Up to 80% off on flagship smartphones & laptops',
      category: 'E-Commerce',
      accent: 'from-blue-600 to-amber-600',
      duration: '40s'
    },
    {
      brand: 'Zepto 10-Minute Delivery',
      tagline: 'Fresh organic groceries delivered in 10 minutes flat',
      category: 'Quick Commerce',
      accent: 'from-pink-600 to-rose-700',
      duration: '35s'
    },
    {
      brand: 'Redmi 5G Superphone',
      tagline: 'Experience lightning fast Snapdragon 5G speed',
      category: 'Smartphones',
      accent: 'from-orange-600 to-red-600',
      duration: '45s'
    }
  ];

  // Auto increment watched timer when playing
  useEffect(() => {
    let interval: any = null;
    if (isPlaying && secondsWatched < TOTAL_REQUIRED_SECONDS) {
      interval = setInterval(() => {
        setSecondsWatched((prev) => {
          const next = prev + speedMultiplier;
          if (next >= TOTAL_REQUIRED_SECONDS) {
            setIsPlaying(false);
            return TOTAL_REQUIRED_SECONDS;
          }
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, secondsWatched, speedMultiplier]);

  // Persist progress
  useEffect(() => {
    try {
      localStorage.setItem('taskearn_40min_ads_watched_seconds', secondsWatched.toString());
    } catch {
      // ignore
    }
  }, [secondsWatched]);

  // Rotate ad slide every 30 seconds
  useEffect(() => {
    if (!isPlaying) return;
    const adInterval = setInterval(() => {
      setActiveAdIndex((prev) => (prev + 1) % SPONSORED_ADS.length);
    }, 15000);
    return () => clearInterval(adInterval);
  }, [isPlaying]);

  const is40MinutesCompleted = secondsWatched >= TOTAL_REQUIRED_SECONDS;
  const progressPercent = Math.min(100, Math.round((secondsWatched / TOTAL_REQUIRED_SECONDS) * 100));

  const formatSeconds = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCollect29Coins = () => {
    if (!currentUser) return;
    adjustUserCoins(
      currentUser.id,
      29, 
      '40 Minutes Video Ads Completed — Collected 29 Coins'
    );
    setHasClaimed29Coins(true);
    confetti({
      particleCount: 90,
      spread: 75,
      origin: { y: 0.6 }
    });
  };

  const handleFastSimulate40Mins = () => {
    setSecondsWatched(TOTAL_REQUIRED_SECONDS);
    setIsPlaying(false);
  };

  const handleResetProgress = () => {
    setSecondsWatched(0);
    setIsPlaying(false);
    setHasClaimed29Coins(false);
    try {
      localStorage.removeItem('taskearn_40min_ads_watched_seconds');
    } catch {
      // ignore
    }
  };

  const currentAd = SPONSORED_ADS[activeAdIndex];

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-rose-950 via-slate-900 to-red-950 border border-rose-500/30 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
                <Tv className="w-3 h-3 text-rose-400" />
                40 Minutes Video Ads Marathon
              </span>
              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black flex items-center gap-1">
                <Coins className="w-3 h-3 text-amber-400" />
                29 Coins Target
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
              <MonitorPlay className="w-5 h-5 text-rose-400" />
              <span>{language === 'bn' ? '৪০ মিনিট ভিডিও বিজ্ঞাপন — ২৯ কয়েন সংগ্রহ' : '40-Min Video Ads — Collect 29 Coins'}</span>
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'bn'
                ? 'স্পনসরড বিজ্ঞাপন ভিডিও চালিয়ে রাখুন, ৪০ মিনিট সম্পূর্ণ হলে সরাসরি ২৯ কয়েন সংগ্রহ করুন।'
                : 'Watch premium sponsored video campaigns for 40 minutes and collect guaranteed 29 Coins!'}
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-900/80 p-2.5 rounded-xl border border-rose-500/20 self-start sm:self-auto">
            <Coins className="w-5 h-5 text-amber-400 animate-bounce" />
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-bold">Reward Pool</span>
              <span className="text-sm font-black text-amber-300">29 Coins Collected</span>
            </div>
          </div>
        </div>
      </div>

      {/* Video Ad Player Simulator */}
      <div className="rounded-3xl bg-slate-900 border border-rose-500/30 overflow-hidden shadow-2xl space-y-0">
        {/* Screen Area */}
        <div className={`relative h-56 sm:h-64 bg-gradient-to-br ${currentAd.accent} flex flex-col justify-between p-4 sm:p-5 transition-colors duration-700`}>
          {/* Ad Top Bar */}
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-black/50 backdrop-blur-md text-white text-[10px] font-black uppercase tracking-wider border border-white/20">
                SPONSORED AD #{activeAdIndex + 1}
              </span>
              <span className="text-xs text-white/90 font-bold bg-white/20 px-2 py-0.5 rounded-md backdrop-blur-md">
                {currentAd.category}
              </span>
            </div>

            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-1.5 rounded-xl bg-black/40 text-white hover:bg-black/60 backdrop-blur-md transition-colors cursor-pointer"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>

          {/* Ad Content Hero */}
          <div className="text-center space-y-2 relative z-10">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center text-2xl shadow-lg">
              📢
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white drop-shadow-md">
              {currentAd.brand}
            </h3>
            <p className="text-xs sm:text-sm text-white/90 font-medium max-w-sm mx-auto drop-shadow-sm">
              {currentAd.tagline}
            </p>
          </div>

          {/* Bottom Stream Status */}
          <div className="flex items-center justify-between text-xs text-white/90 relative z-10">
            <span className="flex items-center gap-1.5 font-bold">
              <span className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
              {isPlaying ? (language === 'bn' ? 'বিজ্ঞাপন সম্প্রচারিত হচ্ছে...' : 'Streaming Sponsored Ad...') : (language === 'bn' ? 'বিজ্ঞাপন বিরতি' : 'Ad Paused')}
            </span>
            <span className="font-mono text-xs font-black bg-black/40 px-2 py-0.5 rounded-md backdrop-blur-md">
              {formatSeconds(secondsWatched)} / 40:00
            </span>
          </div>

          {/* Glow Overlay */}
          <div className="absolute inset-0 bg-radial from-transparent to-black/40 pointer-events-none" />
        </div>

        {/* Player Controls & 40-Min Tracker */}
        <div className="p-4 sm:p-5 bg-slate-950 space-y-4">
          {/* Progress Bar & Stats */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-rose-400" />
                <span>{progressPercent}% {language === 'bn' ? '৪০ মিনিট সম্পন্ন' : 'of 40 Minutes Completed'}</span>
              </span>
              <span className="font-mono text-rose-400 font-black">
                {Math.floor(secondsWatched / 60)} / 40 mins
              </span>
            </div>

            <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden relative">
              <div 
                className="h-full bg-gradient-to-r from-rose-500 via-amber-500 to-emerald-400 transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* Milestones */}
            <div className="flex justify-between text-[10px] text-slate-500 font-bold px-1">
              <span>0m</span>
              <span>10m</span>
              <span>20m</span>
              <span>30m</span>
              <span className="text-rose-400 font-black">40m Goal (29 Coins)</span>
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800">
            {/* Play/Pause */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className={`px-5 py-2.5 rounded-xl font-black text-xs flex items-center gap-2 transition-all cursor-pointer shadow-md ${
                  isPlaying
                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                    : 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30 active:scale-95'
                }`}
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-4 h-4" />
                    <span>{language === 'bn' ? 'বিজ্ঞাপন পজ করুন' : 'Pause Ads'}</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>{language === 'bn' ? 'বিজ্ঞাপন শুরু করুন' : 'Play 40m Ads'}</span>
                  </>
                )}
              </button>

              {/* Speed Multipliers */}
              <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
                {[1, 2, 5, 20].map((spd) => (
                  <button
                    key={spd}
                    onClick={() => setSpeedMultiplier(spd)}
                    className={`px-2 py-1 rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                      speedMultiplier === spd
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>

            {/* Simulation test & reset */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleFastSimulate40Mins}
                className="px-3 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center gap-1 cursor-pointer"
                title="Instant test for 40-minute completion"
              >
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>{language === 'bn' ? 'সিমুলেট ৪০ মিনিট' : 'Simulate 40m'}</span>
              </button>

              <button
                type="button"
                onClick={handleResetProgress}
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 cursor-pointer"
                title="Reset timer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Collect 29 Coins Button */}
          <div className="pt-2">
            {is40MinutesCompleted ? (
              hasClaimed29Coins ? (
                <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-center space-y-1">
                  <div className="flex items-center justify-center gap-2 text-emerald-400 font-black text-sm">
                    <CheckCircle2 className="w-5 h-5" />
                    <span>{language === 'bn' ? '২৯ কয়েন সফলভাবে সংগৃহীত হয়েছে!' : '29 Coins Successfully Collected!'}</span>
                  </div>
                  <p className="text-xs text-slate-300">
                    {language === 'bn' ? 'আপনার ব্যালেন্সে ২৯ কয়েন যোগ হয়েছে।' : '29 Coins added directly to your cash wallet balance.'}
                  </p>
                </div>
              ) : (
                <button
                  onClick={handleCollect29Coins}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-emerald-500 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-xl shadow-rose-500/20 animate-pulse hover:scale-[1.02] active:scale-95 transition-all cursor-pointer"
                >
                  <Coins className="w-5 h-5 text-slate-950" />
                  <span>{language === 'bn' ? '🎉 ২৯ কয়েন সংগ্রহ করুন (Collect 29 Coins)' : '🎉 Collect 29 Coins (40-Min Ads Complete)'}</span>
                </button>
              )
            ) : (
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                <Clock className="w-4 h-4 text-slate-500" />
                <span>
                  {language === 'bn'
                    ? `৪০ মিনিট বিজ্ঞাপন দেখা শেষ হলে ২৯ কয়েন ক্লেইম বাটন সক্রিয় হবে (বাকি: ${Math.max(0, 40 - Math.floor(secondsWatched / 60))} মিনিট)`
                    : `Collect 29 Coins button activates once 40 minutes is reached (${Math.max(0, 40 - Math.floor(secondsWatched / 60))}m remaining)`}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
