import { useEffect, useRef, useState } from "react";
import { useStore } from "../lib/store";
import { Icon, IconButton } from "./ui";
import { cn } from "../utils/cn";

export default function TerminalView() {
  const { s, set, execute, pushTerm, showToast } = useStore();
  const [command, setCommand] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => {
    end.current?.scrollIntoView({ block: "end" });
  }, [s.terminal.length]);
  const run = async (input = command) => {
    if (!input.trim() || busy) return;
    setCommand("");
    if (input.trim() === "clear") {
      set({ terminal: [] });
      return;
    }
    pushTerm([{ kind: "cmd", text: input.trim() }]);
    setBusy(true);
    const result = await execute({
      kind: "shell",
      label: "Workspace command",
      cmd: input.trim(),
    });
    pushTerm([
      {
        kind: result.status === "done" ? "out" : "err",
        text: result.output ?? result.note,
      },
    ]);
    setBusy(false);
  };
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex h-14 shrink-0 items-center gap-2 border-b border-line px-4 sm:px-7">
        <Icon name="terminal" className="h-4 w-4 text-accent" />
        <span className="min-w-0 flex-1 truncate font-mono text-xs">
          {s.workspacePath}
        </span>
        <span className="hidden text-[10px] text-muted sm:block">
          Browser console / not a native shell
        </span>
        <IconButton
          name="copy"
          label="Copy console output"
          onClick={async () => {
            try {
              await navigator.clipboard.writeText(
                s.terminal.map((line) => line.text).join("\n"),
              );
              showToast("Console output copied.");
            } catch {
              showToast("Clipboard unavailable.");
            }
          }}
        />
        <IconButton
          name="trash"
          label="Clear console"
          onClick={() => set({ terminal: [] })}
        />
      </div>
      <div className="min-h-0 flex-1 overflow-auto px-4 py-6 font-mono text-[12px] leading-6 sm:px-7">
        {s.terminal.map((line) => (
          <div
            key={line.id}
            className={cn(
              "whitespace-pre-wrap break-words",
              line.kind === "cmd"
                ? "mb-1 mt-5 text-fg"
                : line.kind === "err"
                  ? "text-danger"
                  : line.kind === "ok"
                    ? "text-ok"
                    : "text-muted",
            )}
          >
            {line.kind === "cmd" && <span className="mr-2 text-accent">$</span>}
            {line.text}
          </div>
        ))}
        <div ref={end} />
      </div>
      {!s.permissions.shell && (
        <div className="flex shrink-0 items-start gap-3 border-t border-line px-4 py-4 sm:px-7">
          <Icon name="lock" className="mt-1 h-4 w-4 text-muted" />
          <div className="flex-1">
            <p className="text-xs">Workspace commands are disabled.</p>
            <p className="mt-1 text-[11px] text-muted">
              Enable the built-in file commands. This does not grant a native
              shell.
            </p>
            <button
              onClick={() =>
                set((state) => ({
                  permissions: { ...state.permissions, shell: true },
                }))
              }
              className="mt-2 text-xs text-accent hover:underline"
            >
              Enable built-in commands
            </button>
          </div>
        </div>
      )}
      <div className="shrink-0 border-t border-line px-3 pb-4 pt-2 sm:px-7">
        <div className="mb-2 flex gap-3">
          {["ls", "tree", "pwd", "help"].map((cmd) => (
            <button
              key={cmd}
              onClick={() => void run(cmd)}
              className="rounded-md px-2 py-1 font-mono text-[10px] text-muted hover:bg-surface2 hover:text-accent"
            >
              {cmd}
            </button>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void run();
          }}
          className="flex items-center gap-2 rounded-xl border border-line bg-surface px-3"
        >
          <span className="font-mono text-sm text-accent">$</span>
          <input
            aria-label="Console command"
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            autoComplete="off"
            spellCheck={false}
            placeholder="Type a command. Try ls or help."
            className="h-12 min-w-0 flex-1 bg-transparent font-mono text-xs outline-none placeholder:text-muted/60"
          />
          <button
            aria-label="Run command"
            type="submit"
            disabled={!command.trim() || busy}
            className="grid h-8 w-8 place-items-center rounded-lg bg-accent text-white disabled:opacity-30"
          >
            <Icon name="send" className="h-4 w-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
