import React, { useState, useEffect, useRef } from 'react';
import { FileItem } from '../types';
import { 
  Terminal as TerminalIcon, 
  Trash2, 
  Play, 
  Maximize2, 
  Minimize2, 
  X, 
  ChevronRight, 
  AlertTriangle, 
  AlertCircle, 
  Info 
} from 'lucide-react';

interface LogEntry {
  id: string;
  type: 'log' | 'error' | 'warn' | 'info' | 'command' | 'result';
  content: string;
  timestamp: string;
}

interface TerminalViewProps {
  files: FileItem[];
  activeFileId: string | null;
  isOpen: boolean;
  onClose: () => void;
  onToggleExpand?: () => void;
  isExpanded?: boolean;
}

export const TerminalView: React.FC<TerminalViewProps> = ({
  files,
  activeFileId,
  isOpen,
  onClose,
  onToggleExpand,
  isExpanded = false,
}) => {
  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: 'init_1',
      type: 'info',
      content: 'NEXORA Terminal Console v2.0 initialized. Ready for execution.',
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);
  const [command, setCommand] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const logContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll on new logs
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  // Listen for console bridge messages from PreviewView iframe
  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (e.data && e.data.type === 'NEXORA_CONSOLE') {
        const entry: LogEntry = {
          id: Math.random().toString(36).substring(2, 9),
          type: (e.data.logType as any) || 'log',
          content: e.data.content,
          timestamp: new Date().toLocaleTimeString(),
        };
        setLogs((prev) => [...prev, entry]);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  if (!isOpen) return null;

  const appendLog = (type: LogEntry['type'], content: string) => {
    setLogs((prev) => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        type,
        content,
        timestamp: new Date().toLocaleTimeString(),
      },
    ]);
  };

  const clearLogs = () => {
    setLogs([]);
  };

  const executeCommand = (cmdText: string) => {
    const trimmed = cmdText.trim();
    if (!trimmed) return;

    appendLog('command', `> ${trimmed}`);
    setHistory((prev) => [...prev, trimmed]);
    setHistoryIndex(-1);
    setCommand('');

    // Capture console output during eval
    const captured: LogEntry[] = [];
    const origLog = console.log;
    const origError = console.error;
    const origWarn = console.warn;
    const origInfo = console.info;

    const makeEntry = (type: LogEntry['type'], args: any[]) => {
      captured.push({
        id: Math.random().toString(36).substring(2, 9),
        type,
        content: args.map((a) => (typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a))).join(' '),
        timestamp: new Date().toLocaleTimeString(),
      });
    };

    console.log = (...args) => makeEntry('log', args);
    console.error = (...args) => makeEntry('error', args);
    console.warn = (...args) => makeEntry('warn', args);
    console.info = (...args) => makeEntry('info', args);

    try {
      // Evaluate in window scope
      let evalCode = trimmed.replace(/^(?:let|const)\s+/gm, 'var ');
      const result = window.eval(evalCode);

      if (result !== undefined) {
        makeEntry('result', [result]);
      }
    } catch (err: any) {
      makeEntry('error', [err?.message || String(err)]);
    } finally {
      console.log = origLog;
      console.error = origError;
      console.warn = origWarn;
      console.info = origInfo;
    }

    if (captured.length > 0) {
      setLogs((prev) => [...prev, ...captured]);
    }
  };

  const handleRunActiveJs = () => {
    const file = files.find((f) => f.id === activeFileId);
    if (!file) return;

    appendLog('info', `Running ${file.name}...`);
    executeCommand(file.content);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      executeCommand(command);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (history.length === 0) return;
      const nextIdx = historyIndex === -1 ? history.length - 1 : Math.max(0, historyIndex - 1);
      setHistoryIndex(nextIdx);
      setCommand(history[nextIdx] || '');
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex === -1) return;
      const nextIdx = historyIndex + 1;
      if (nextIdx >= history.length) {
        setHistoryIndex(-1);
        setCommand('');
      } else {
        setHistoryIndex(nextIdx);
        setCommand(history[nextIdx] || '');
      }
    }
  };

  return (
    <div
      className={`border-t theme-border bg-[#14151b] flex flex-col shrink-0 text-xs font-mono transition-all z-20 ${
        isExpanded ? 'h-full w-full' : 'h-52 w-full'
      }`}
    >
      {/* Terminal Header */}
      <div className="h-8 px-3 flex items-center justify-between border-b border-[#262833] bg-[#121318] shrink-0 select-none">
        <div className="flex items-center space-x-2">
          <TerminalIcon className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-semibold text-slate-300 text-[11px] uppercase tracking-wider">
            Console Terminal
          </span>
          <span className="text-[10px] theme-text-muted">({logs.length} logs)</span>
        </div>

        <div className="flex items-center space-x-1.5">
          {/* Run Active JS */}
          <button
            onClick={handleRunActiveJs}
            className="flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 transition-colors cursor-pointer"
            title="Execute Current File in Console"
          >
            <Play className="w-2.5 h-2.5 fill-current" />
            <span>Run File</span>
          </button>

          {/* Clear Logs */}
          <button
            onClick={clearLogs}
            className="p-1 theme-text-muted hover:text-red-400 rounded transition-colors cursor-pointer"
            title="Clear Console"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          {/* Expand/Collapse */}
          {onToggleExpand && (
            <button
              onClick={onToggleExpand}
              className="p-1 theme-text-muted hover:text-white rounded transition-colors cursor-pointer"
              title={isExpanded ? 'Collapse Terminal' : 'Maximize Terminal'}
            >
              {isExpanded ? (
                <Minimize2 className="w-3.5 h-3.5" />
              ) : (
                <Maximize2 className="w-3.5 h-3.5" />
              )}
            </button>
          )}

          {/* Close */}
          <button
            onClick={onClose}
            className="p-1 theme-text-muted hover:text-white rounded transition-colors cursor-pointer"
            title="Close Terminal"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Logs Output Area */}
      <div
        ref={logContainerRef}
        className="flex-grow p-2.5 overflow-y-auto space-y-1.5 select-text"
      >
        {logs.map((log) => {
          let color = 'text-slate-300';
          let icon = null;

          if (log.type === 'error') {
            color = 'text-red-400 bg-red-500/10 px-1 py-0.5 rounded';
            icon = <AlertCircle className="w-3 h-3 text-red-400 shrink-0 inline mr-1" />;
          } else if (log.type === 'warn') {
            color = 'text-amber-400 bg-amber-500/10 px-1 py-0.5 rounded';
            icon = <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0 inline mr-1" />;
          } else if (log.type === 'info') {
            color = 'text-cyan-400';
            icon = <Info className="w-3 h-3 text-cyan-400 shrink-0 inline mr-1" />;
          } else if (log.type === 'command') {
            color = 'text-slate-400 font-semibold';
          } else if (log.type === 'result') {
            color = 'text-emerald-400 font-bold';
          }

          return (
            <div key={log.id} className="flex items-start space-x-2 text-[11px] leading-relaxed">
              <span className="text-[10px] text-slate-500 shrink-0 select-none">
                {log.timestamp}
              </span>
              <div className={`flex-grow font-mono whitespace-pre-wrap break-all ${color}`}>
                {icon}
                {log.content}
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive REPL Prompt */}
      <div className="h-8 px-2 flex items-center border-t border-[#262833] bg-[#0e0f14] shrink-0">
        <ChevronRight className="w-3.5 h-3.5 text-cyan-400 shrink-0 mr-1.5" />
        <input
          type="text"
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type JavaScript code here (e.g. let name = 'amaan'; console.log(name))"
          className="w-full bg-transparent border-none text-[11px] font-mono text-slate-100 placeholder:text-slate-600 outline-none"
        />
      </div>
    </div>
  );
};
