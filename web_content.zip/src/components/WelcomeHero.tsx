import React from 'react';
import { Sparkles, MessageSquareHeart, Coffee, HelpCircle, Utensils } from 'lucide-react';
import { PromptSuggestion } from '../types';

interface WelcomeHeroProps {
  onSelectPrompt: (prompt: string) => void;
  onOpenGuide: () => void;
}

const SUGGESTIONS: PromptSuggestion[] = [
  {
    title: 'Hang sapa sebenarnya?',
    prompt: 'Hang sapa sebenarnya? Boleh cerita sikit pasai diri hang dan awat hang suka cakap loghat utara?',
    category: 'utara',
    icon: '🌾',
  },
  {
    title: 'Port Nasi Kandar Padu',
    prompt: 'Habaq mai sat mana tempat makan nasi kandar paling padu dan kuah banjir campur yang sedap kat Penang atau Kedah!',
    category: 'utara',
    icon: '🍛',
  },
  {
    title: 'Resepi Laksa Kedah Pekat',
    prompt: 'Bagi resepi laksa Kedah yang asli dengan kuah ikan pekat, bau bunga kantan dan daun kesum yang menusuk kalbu.',
    category: 'utara',
    icon: '🍜',
  },
  {
    title: 'Tips Elak Malas & Lemau',
    prompt: 'Bagi tips santai macam mana nak hilangkan rasa malas dan lemau waktu petang bila ada banyak kerja nak buat.',
    category: 'santai',
    icon: '☕',
  },
  {
    title: 'Terangkan AI Cara Mudah',
    prompt: 'Tolong terangkan apa itu Artificial Intelligence (AI) dan Large Language Model macam hang ni dengan cara paling mudah difahami.',
    category: 'pintar',
    icon: '🤖',
  },
  {
    title: 'Pantun Santai Utara',
    prompt: 'Bina 2 rangkap pantun empat kerat yang ada loghat utara dan lawak santai pasai kawan yang kuat makan.',
    category: 'utara',
    icon: '📜',
  },
];

export const WelcomeHero: React.FC<WelcomeHeroProps> = ({
  onSelectPrompt,
  onOpenGuide,
}) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] max-w-2xl mx-auto px-4 py-8 text-center animate-fade-in">
      {/* Glowing Avatar */}
      <div className="relative mb-6">
        <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-tr from-purple-800 via-fuchsia-600 to-violet-500 flex items-center justify-center shadow-[0_0_40px_rgba(168,85,247,0.5)] border border-purple-400/50 animate-purple-glow">
          <Sparkles className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
        </div>
        <div className="absolute -bottom-2 -right-2 px-2.5 py-1 rounded-full bg-[#120629] border border-purple-500/40 text-[11px] font-bold text-purple-300 shadow-md flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          Aktif
        </div>
      </div>

      {/* Main Titles */}
      <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight bg-gradient-to-r from-white via-purple-100 to-purple-400 bg-clip-text text-transparent">
        Hai! Cek HANN AI.
      </h2>
      <p className="mt-2 text-sm sm:text-base text-purple-200/80 max-w-md leading-relaxed">
        Chatbot pintar Bahasa Melayu dengan citarasa <strong className="text-purple-300 font-semibold">loghat utara</strong> yang sempoi, mesra dan serba boleh.
      </p>

      {/* Quick guide button */}
      <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
        <button
          onClick={onOpenGuide}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-900/30 hover:bg-purple-800/40 border border-purple-500/30 text-xs font-medium text-purple-300 hover:text-white transition-all shadow-sm"
        >
          <HelpCircle className="w-3.5 h-3.5 text-purple-400" />
          <span>Lihat Panduan & Arahan Ujian</span>
        </button>
      </div>

      {/* Suggestion Chips Grid */}
      <div className="mt-8 w-full text-left">
        <div className="flex items-center justify-between mb-3 px-1">
          <span className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
            <MessageSquareHeart className="w-3.5 h-3.5 text-fuchsia-400" />
            Cuba Tanya Soalan Ni (Klik Sekali):
          </span>
          <span className="text-[11px] text-purple-400/60 hidden sm:inline">Klik untuk hantar</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {SUGGESTIONS.map((item, idx) => (
            <button
              key={idx}
              onClick={() => onSelectPrompt(item.prompt)}
              className="group p-3 rounded-xl bg-[#14082c]/80 hover:bg-[#1f0d40] border border-purple-900/40 hover:border-purple-500/50 text-left transition-all hover:scale-[1.01] active:scale-[0.99] flex items-start gap-2.5 shadow-sm"
            >
              <span className="text-xl shrink-0 p-1 rounded-lg bg-purple-950/60 border border-purple-800/40 group-hover:bg-purple-900/50 transition-colors">
                {item.icon}
              </span>
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-purple-100 group-hover:text-purple-300 transition-colors truncate">
                  {item.title}
                </h4>
                <p className="text-[11px] text-slate-400 group-hover:text-slate-300 line-clamp-2 mt-0.5 leading-snug">
                  {item.prompt}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
