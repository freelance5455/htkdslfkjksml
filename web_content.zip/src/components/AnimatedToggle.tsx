import { motion } from "framer-motion";

interface AnimatedToggleProps {
  icon: string;
  label: string;
  checked: boolean;
  onChange: () => void;
}

export default function AnimatedToggle({ icon, label, checked, onChange }: AnimatedToggleProps) {
  return (
    <motion.button
      onClick={onChange}
      whileTap={{ scale: 0.95 }}
      className={`relative flex w-full items-center justify-between gap-3 rounded-2xl px-3.5 py-2.5 overflow-hidden transition-colors ${
        checked ? "bg-orange-500/15" : "bg-white/5"
      }`}
    >
      {checked && (
        <motion.div
          layoutId={`glow-${label}`}
          className="absolute inset-0 rounded-2xl border border-orange-400/60"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1, boxShadow: "0 0 16px rgba(249,115,22,0.45)" }}
          transition={{ duration: 0.25 }}
        />
      )}
      <span className="relative z-10 flex items-center gap-2 text-left">
        <span className="text-lg">{icon}</span>
        <span className="text-sm font-semibold text-slate-100">{label}</span>
      </span>

      <span
        className={`relative z-10 flex h-6 w-11 shrink-0 items-center rounded-full p-0.5 transition-colors duration-300 ${
          checked ? "bg-orange-500" : "bg-slate-600"
        }`}
      >
        <motion.span
          layout
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
          className="h-5 w-5 rounded-full bg-white shadow-md"
          style={{ marginLeft: checked ? "auto" : 0 }}
        />
      </span>
    </motion.button>
  );
}
