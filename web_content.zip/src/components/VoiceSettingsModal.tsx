import React, { useState, useEffect } from 'react';
import { 
  Volume2, Sliders, RotateCcw, Save, Play, CheckCircle2, 
  Lock, Key, Sparkles, X, Activity, ShieldCheck, Info 
} from 'lucide-react';
import { 
  voiceEngine, 
  JarvisMasterVoiceProfile, 
  calculateEffectivePitch, 
  calculateEffectiveRate 
} from '../services/voiceService';

interface VoiceSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPlayReferenceSample?: () => void;
}

export const VoiceSettingsModal: React.FC<VoiceSettingsModalProps> = ({
  isOpen,
  onClose,
  onPlayReferenceSample,
}) => {
  const [profile, setProfile] = useState<JarvisMasterVoiceProfile>(() => voiceEngine.getVoiceConfig());
  const [depth, setDepth] = useState<number>(profile.depth ?? 85);
  const [speed, setSpeed] = useState<number>(profile.speed ?? 0.90);
  const [pitchSemitones, setPitchSemitones] = useState<number>(profile.pitchSemitones ?? -2);
  const [elevenLabsKey, setElevenLabsKey] = useState<string>(() => voiceEngine.getElevenLabsApiKey());
  const [showKey, setShowKey] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isPlayingRef, setIsPlayingRef] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const current = voiceEngine.getVoiceConfig();
      setProfile(current);
      setDepth(current.depth ?? 85);
      setSpeed(current.speed ?? 0.90);
      setPitchSemitones(current.pitchSemitones ?? -2);
      setElevenLabsKey(voiceEngine.getElevenLabsApiKey());
      setSaveSuccess(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const effectivePitch = calculateEffectivePitch(depth, pitchSemitones);
  const effectiveRate = calculateEffectiveRate(speed);

  const handlePreview = async () => {
    setIsTesting(true);
    // Apply temporary settings for preview
    voiceEngine.updateVoiceSettings({ depth, speed, pitchSemitones });
    await voiceEngine.previewVoice(
      'All systems operational, Harman Sir. Voice depth and masculine resonance calibrated to your exact specifications.',
      {
        onEnd: () => setIsTesting(false),
        onError: () => setIsTesting(false),
      }
    );
  };

  const handlePlayReference = () => {
    if (onPlayReferenceSample) {
      setIsPlayingRef(true);
      onPlayReferenceSample();
      setTimeout(() => setIsPlayingRef(false), 4000);
    } else {
      setIsPlayingRef(true);
      voiceEngine.playVoiceReferenceSample(() => setIsPlayingRef(false));
    }
  };

  const handleSave = () => {
    voiceEngine.setElevenLabsApiKey(elevenLabsKey);
    const updated = voiceEngine.updateVoiceSettings({
      depth,
      speed,
      pitchSemitones,
    });
    setProfile(updated);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleReset = () => {
    const res = voiceEngine.resetVoiceSettings();
    setProfile(res);
    setDepth(85);
    setSpeed(0.90);
    setPitchSemitones(-2);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-gray-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-xl bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-cyan-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100 flex items-center gap-2">
              JARVIS Master Voice Intelligence
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono-tech">
                GEORGE // BRITISH MALE BARITONE
              </span>
            </h3>
          </div>
          <button 
            onClick={onClose} 
            className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 p-5 overflow-y-auto space-y-5 text-sm text-cyan-100">
          
          {/* Identity Lock Banner */}
          <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-start gap-3">
            <Lock className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <div className="font-bold text-cyan-200 font-tech uppercase tracking-wider flex items-center gap-2">
                PERMANENT MALE IDENTITY LOCKED // ANTI-SWITCH GUARANTEE
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              </div>
              <p className="text-cyan-300/80 leading-relaxed">
                JARVIS is permanently anchored to the ElevenLabs British male baritone (Voice ID: <code className="text-cyan-200">JBFqnCBsd6RMkjVDRZzb</code>) with a calibrated Web Speech fallback. Zero automatic switching to female or robotic browser voices.
              </p>
            </div>
          </div>

          {/* Sliders Console */}
          <div className="p-4 rounded-xl bg-gray-950/80 border border-cyan-500/30 space-y-5">
            <div className="flex items-center justify-between border-b border-cyan-500/20 pb-2">
              <div className="flex items-center gap-2 text-xs font-tech uppercase text-cyan-300 tracking-wider">
                <Sliders className="w-4 h-4 text-cyan-400" />
                Acoustic Calibration Controls
              </div>
              <span className="text-[11px] font-mono-tech text-cyan-400/80">
                PITCH: {effectivePitch}x • SPEED: {effectiveRate}x
              </span>
            </div>

            {/* 1. Depth Slider (0% - 100%, default 85%) */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <label className="font-tech text-cyan-200 font-bold uppercase flex items-center gap-1.5">
                  Voice Depth & Chest Resonance
                  <span className="text-[10px] text-cyan-400/80 font-mono-tech">(Default: 85%)</span>
                </label>
                <span className="font-mono-tech text-cyan-300 font-bold">{depth}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="1"
                value={depth}
                onChange={(e) => setDepth(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-gray-800 rounded-lg h-2 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-cyan-400/60 font-mono-tech">
                <span>0% (Standard Pacing)</span>
                <span>50% (Rich Resonance)</span>
                <span>85% (Optimal JARVIS Deep Baritone)</span>
                <span>100% (Maximum Depth)</span>
              </div>
            </div>

            {/* 2. Speed Slider (0.75x - 1.50x, default 0.90x) */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <label className="font-tech text-cyan-200 font-bold uppercase flex items-center gap-1.5">
                  Conversational Speed
                  <span className="text-[10px] text-cyan-400/80 font-mono-tech">(Default: 0.90x)</span>
                </label>
                <span className="font-mono-tech text-cyan-300 font-bold">{speed.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.75"
                max="1.50"
                step="0.05"
                value={speed}
                onChange={(e) => setSpeed(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-gray-800 rounded-lg h-2 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-cyan-400/60 font-mono-tech">
                <span>0.75x (Deliberate)</span>
                <span>0.90x (Natural Conversational)</span>
                <span>1.10x (Fast)</span>
                <span>1.50x (Rapid Briefing)</span>
              </div>
            </div>

            {/* 3. Pitch Slider (-6 to +6 Semitones, default -2) */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <label className="font-tech text-cyan-200 font-bold uppercase flex items-center gap-1.5">
                  Masculine Pitch Offset
                  <span className="text-[10px] text-cyan-400/80 font-mono-tech">(Default: -2 semitones)</span>
                </label>
                <span className="font-mono-tech text-cyan-300 font-bold">
                  {pitchSemitones > 0 ? `+${pitchSemitones}` : pitchSemitones} semitones
                </span>
              </div>
              <input
                type="range"
                min="-6"
                max="6"
                step="1"
                value={pitchSemitones}
                onChange={(e) => setPitchSemitones(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-gray-800 rounded-lg h-2 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-cyan-400/60 font-mono-tech">
                <span>-6 (Deep Bass)</span>
                <span>-2 (Commanding Baritone)</span>
                <span>0 (Neutral Male)</span>
                <span>+6 (High Tenor)</span>
              </div>
            </div>
          </div>

          {/* ElevenLabs API Key Config */}
          <div className="p-4 rounded-xl bg-gray-950/80 border border-cyan-500/30 space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-tech uppercase text-cyan-200 font-bold flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-cyan-400" />
                ElevenLabs API Key (Optional Cloud HD Mode)
              </label>
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="text-[11px] text-cyan-400/80 hover:text-cyan-200 cursor-pointer underline"
              >
                {showKey ? 'Hide' : 'Show Key'}
              </button>
            </div>
            <input
              type={showKey ? 'text' : 'password'}
              placeholder="xi-api-key (e.g. sk_... or leave empty for calibrated local male engine)"
              value={elevenLabsKey}
              onChange={(e) => setElevenLabsKey(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-cyan-500/30 text-xs text-cyan-100 placeholder:text-gray-500 focus:outline-none focus:border-cyan-400 font-mono-tech"
            />
            <p className="text-[11px] text-cyan-400/70 flex items-center gap-1">
              <Info className="w-3 h-3 text-cyan-400 shrink-0" />
              If empty or offline, JARVIS seamlessly uses the local calibrated British male engine with the exact same depth and pitch.
            </p>
          </div>

          {/* Audio Reference Sample Player */}
          <div className="p-3.5 rounded-xl bg-gray-950/80 border border-cyan-500/30 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-cyan-200 font-tech uppercase">
                Harman Sir's Voice Reference File
              </div>
              <div className="text-[11px] text-cyan-400/70 font-mono-tech">
                voice-preview (1).mp3 // Master Timbre Reference
              </div>
            </div>
            <button
              onClick={handlePlayReference}
              disabled={isPlayingRef}
              className="px-3 py-1.5 rounded-lg bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 text-xs font-tech uppercase flex items-center gap-1.5 cursor-pointer disabled:opacity-50 transition-all active:scale-95"
            >
              <Play className={`w-3.5 h-3.5 text-cyan-400 ${isPlayingRef ? 'animate-pulse' : ''}`} />
              {isPlayingRef ? 'Playing Sample...' : 'Play Reference'}
            </button>
          </div>

          {/* Success Banner */}
          {saveSuccess && (
            <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Voice settings updated and permanently committed to local storage, Harman Sir.</span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-cyan-500/20">
            <button
              onClick={handleReset}
              className="px-3.5 py-2 rounded-xl bg-gray-950 hover:bg-gray-800 border border-cyan-500/30 text-cyan-300 text-xs font-tech uppercase flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Defaults
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePreview}
                disabled={isTesting}
                className="px-4 py-2 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/50 text-cyan-200 text-xs font-tech uppercase flex items-center gap-1.5 cursor-pointer transition-all disabled:opacity-50"
              >
                <Activity className={`w-3.5 h-3.5 text-cyan-400 ${isTesting ? 'animate-spin' : ''}`} />
                {isTesting ? 'Testing Voice...' : 'Test / Preview Voice'}
              </button>

              <button
                onClick={handleSave}
                className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-gray-950 font-bold text-xs uppercase font-tech flex items-center gap-1.5 cursor-pointer transition-all shadow-lg glow-cyan-sm active:scale-95"
              >
                <Save className="w-3.5 h-3.5" />
                Save Voice
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
