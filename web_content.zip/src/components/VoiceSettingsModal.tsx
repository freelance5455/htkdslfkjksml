import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  Check,
  Mic,
  Play,
  Settings2,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { VoicePersonality, VoiceSettings } from '../types.ts';

interface VoiceSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: VoiceSettings;
  onSaveSettings: (newSettings: VoiceSettings) => void;
  onTestVoice: (settings: VoiceSettings) => void;
}

export const VoiceSettingsModal: React.FC<VoiceSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onTestVoice,
}) => {
  const [localSettings, setLocalSettings] = useState<VoiceSettings>(settings);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [speechSupported, setSpeechSupported] = useState<boolean>(true);
  const [sttSupported, setSttSupported] = useState<boolean>(true);

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    if (!('speechSynthesis' in window)) {
      setSpeechSupported(false);
    } else {
      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        setAvailableVoices(voices);
        if (voices.length > 0 && !localSettings.voiceURI) {
          // Select default or preferred english voice
          const defaultVoice =
            voices.find((v) => v.name.includes('Google') || v.name.includes('Natural') || v.lang.startsWith('en')) ||
            voices[0];
          if (defaultVoice) {
            setLocalSettings((prev) => ({ ...prev, voiceURI: defaultVoice.voiceURI }));
          }
        }
      };

      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }

    const hasStt = !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
    setSttSupported(hasStt);
  }, []);

  if (!isOpen) return null;

  const handlePersonalityChange = (personality: VoicePersonality) => {
    let rate = 1.0;
    let pitch = 1.0;

    switch (personality) {
      case 'CALM':
        rate = 0.92;
        pitch = 0.95;
        break;
      case 'PROFESSIONAL':
        rate = 1.05;
        pitch = 1.0;
        break;
      case 'FRIENDLY':
        rate = 1.1;
        pitch = 1.1;
        break;
      case 'TECHNICAL':
        rate = 1.0;
        pitch = 0.9;
        break;
      case 'CONCISE':
        rate = 1.25;
        pitch = 1.0;
        break;
    }

    setLocalSettings((prev) => ({
      ...prev,
      personality,
      rate,
      pitch,
    }));
  };

  const handleSave = () => {
    onSaveSettings(localSettings);
    onClose();
  };

  return (
    <div
      id="voice-settings-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 animate-in fade-in"
    >
      <div
        id="voice-settings-modal-card"
        className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-xl space-y-5"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-50 text-sky-700 border border-sky-200">
              <Settings2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 font-sans">
                Voice Experience & Speech Engine
              </h2>
              <p className="text-xs text-slate-500 font-mono">
                JARVIS 5.1 Web Speech Foundation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close voice settings modal"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Honest Limitations & Capability Notice */}
        <div className="p-3.5 rounded-xl bg-sky-50/60 border border-sky-200 text-xs text-slate-700 space-y-1.5">
          <div className="flex items-center gap-1.5 font-semibold text-sky-900">
            <AlertCircle className="w-4 h-4 text-sky-600 shrink-0" />
            <span>Browser Architecture & Capability Truth</span>
          </div>
          <p className="text-[12px] leading-relaxed text-slate-600">
            Voice synthesis (TTS) and speech recognition (STT) operate directly via the browser Web Speech API.
            JARVIS does not run a deceptive background wake-word engine; microphone input requires explicit operator click and browser permission.
          </p>
          <div className="flex items-center gap-3 pt-1 text-[11px] font-mono text-slate-500">
            <span>Speech Synthesis (TTS): <strong className={speechSupported ? 'text-emerald-700' : 'text-rose-700'}>{speechSupported ? 'Supported' : 'Unavailable'}</strong></span>
            <span>•</span>
            <span>Speech Recognition (STT): <strong className={sttSupported ? 'text-emerald-700' : 'text-amber-700'}>{sttSupported ? 'Supported' : 'Unavailable in frame'}</strong></span>
          </div>
        </div>

        {/* Master Toggle */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
          <div className="flex items-center gap-2.5">
            {localSettings.enabled ? (
              <Volume2 className="w-4 h-4 text-sky-600" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
            <div>
              <div className="text-xs font-bold text-slate-800 font-sans">
                Voice Response Synthesis
              </div>
              <div className="text-[11px] text-slate-500 font-mono">
                Speak mission outcomes aloud upon completion
              </div>
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={localSettings.enabled}
            onClick={() => setLocalSettings((prev) => ({ ...prev, enabled: !prev.enabled }))}
            className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
              localSettings.enabled ? 'bg-sky-600' : 'bg-slate-300'
            }`}
          >
            <div
              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                localSettings.enabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Personality Preset Selection */}
        <div className="space-y-2">
          <label className="text-xs font-mono font-bold text-slate-700 uppercase">
            Voice Personality Preset
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
            {(['CALM', 'PROFESSIONAL', 'FRIENDLY', 'TECHNICAL', 'CONCISE'] as VoicePersonality[]).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => handlePersonalityChange(p)}
                className={`px-2 py-1.5 text-xs font-mono rounded-lg border transition-all text-center ${
                  localSettings.personality === p
                    ? 'bg-sky-50 border-sky-400 text-sky-900 font-bold shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Voice Selection */}
        {availableVoices.length > 0 && (
          <div className="space-y-1.5">
            <label className="text-xs font-mono font-bold text-slate-700 uppercase">
              Browser Voice
            </label>
            <select
              value={localSettings.voiceURI || ''}
              onChange={(e) => setLocalSettings((prev) => ({ ...prev, voiceURI: e.target.value }))}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-800 font-sans focus:outline-none focus:border-sky-500"
            >
              {availableVoices.map((v) => (
                <option key={v.voiceURI} value={v.voiceURI}>
                  {v.name} ({v.lang})
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Sliders: Rate, Pitch, Volume */}
        <div className="space-y-3 pt-1 font-mono text-xs text-slate-700">
          <div>
            <div className="flex justify-between mb-1">
              <span>Speech Rate:</span>
              <span className="font-bold">{localSettings.rate.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.6"
              max="1.8"
              step="0.05"
              value={localSettings.rate}
              onChange={(e) => setLocalSettings((prev) => ({ ...prev, rate: parseFloat(e.target.value) }))}
              className="w-full accent-sky-600"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span>Pitch:</span>
              <span className="font-bold">{localSettings.pitch.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.6"
              max="1.4"
              step="0.05"
              value={localSettings.pitch}
              onChange={(e) => setLocalSettings((prev) => ({ ...prev, pitch: parseFloat(e.target.value) }))}
              className="w-full accent-sky-600"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span>Volume:</span>
              <span className="font-bold">{Math.round(localSettings.volume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="1.0"
              step="0.05"
              value={localSettings.volume}
              onChange={(e) => setLocalSettings((prev) => ({ ...prev, volume: parseFloat(e.target.value) }))}
              className="w-full accent-sky-600"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={() => onTestVoice(localSettings)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-mono font-semibold transition-colors"
          >
            <Play className="w-3.5 h-3.5 text-sky-600" />
            <span>TEST VOICE</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 text-xs font-sans font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-sans font-semibold transition-all shadow-xs"
            >
              <Check className="w-4 h-4" />
              <span>Save Settings</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
