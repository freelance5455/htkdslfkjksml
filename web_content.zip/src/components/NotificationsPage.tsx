import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  Bell,
  CheckCircle2,
  Calendar,
  DollarSign,
  Trash2,
  Check,
  ArrowRight,
  ChevronLeft,
  Mail,
  RotateCcw,
  Ticket,
} from 'lucide-react';
import { AppNotification } from '../types';
import { EmptyState } from './ui/EmptyState';

export const NotificationsPage: React.FC = () => {
  const {
    notifications,
    clearAllNotifications,
    dismissNotification,
    setCurrentPage,
    setActiveVirtualTicket,
    tickets,
    events,
    showToast,
  } = useApp();

  const [filterType, setFilterType] = useState<'all' | 'unread' | 'sales_refunds'>('all');
  const [selectedReceiptNotif, setSelectedReceiptNotif] = useState<AppNotification | null>(null);

  const filteredNotifications = useMemo(() => {
    return notifications.filter((n) => {
      if (filterType === 'unread') return !n.isRead;
      if (filterType === 'sales_refunds') {
        return (
          n.type === 'refund' ||
          n.type === 'ticket_sale' ||
          n.type === 'payment_payout' ||
          n.type === 'email_dispatch'
        );
      }
      return true;
    });
  }, [notifications, filterType]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleToggleRead = (n: AppNotification, e: React.MouseEvent) => {
    e.stopPropagation();
    n.isRead = !n.isRead;
    showToast(n.isRead ? 'Marked as read' : 'Marked as unread');
  };

  const handleNotificationClick = (n: AppNotification) => {
    n.isRead = true;
    if (n.type === 'refund') {
      setSelectedReceiptNotif(n);
      return;
    }
    if (n.type === 'ticket_sale') {
      setCurrentPage('dashboard');
      return;
    }
    if (n.ticketId) {
      const match = tickets.find((t) => t.ticketId === n.ticketId);
      if (match) {
        setActiveVirtualTicket(match);
        return;
      }
    }
    if (n.type === 'payment_payout') {
      setCurrentPage('dashboard');
    } else {
      setCurrentPage('tickets');
    }
  };

  return (
    <div className="min-h-screen bg-[#090a0d] text-[#f4f4f6] pt-24 pb-28">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
        {/* Apple HIG Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#1f2229]">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentPage('home')}
              className="w-9 h-9 rounded-full border border-[#232733] bg-[#111317] hover:bg-[#16181f] text-[#9496a1] hover:text-white flex items-center justify-center transition-colors cursor-pointer shadow-xs"
              title="Back to Discover"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                  Global Alert Feed
                </span>
                {unreadCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                    {unreadCount} unread
                  </span>
                )}
              </div>
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white mt-0.5">
                Notifications
              </h1>
            </div>
          </div>

          {notifications.length > 0 && (
            <button
              onClick={clearAllNotifications}
              className="px-3.5 py-1.5 rounded-full border border-[#232733] bg-[#111317] hover:bg-red-500/10 hover:border-red-500/30 text-xs font-semibold text-[#9496a1] hover:text-red-400 transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto shadow-xs"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All</span>
            </button>
          )}
        </div>

        {/* Apple Segmented Tabs (All, Unread, Sales & Refunds) */}
        <div className="inline-flex items-center p-1 bg-[#16181f] rounded-full border border-[#232733]">
          {(
            [
              { id: 'all', label: `All (${notifications.length})` },
              { id: 'unread', label: `Unread (${unreadCount})` },
              { id: 'sales_refunds', label: 'Passes & Refunds' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id)}
              className={`px-4 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                filterType === tab.id
                  ? 'bg-[#252834] text-white shadow-xs font-bold border border-[#353a4b]'
                  : 'text-[#9496a1] hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Notifications List */}
        {filteredNotifications.length === 0 ? (
          <EmptyState
            icon={<Bell className="w-6 h-6 text-[#646875]" />}
            title="All caught up"
            description={
              filterType === 'unread'
                ? 'You have read all notifications.'
                : 'Ticket orders, vouchers, sales receipts, and automated refunds will appear here in real-time.'
            }
            actionText={filterType !== 'all' ? 'View All Alerts' : 'Discover Events'}
            onAction={() => (filterType !== 'all' ? setFilterType('all') : setCurrentPage('home'))}
          />
        ) : (
          <div className="space-y-3">
            {filteredNotifications.map((n) => {
              const isRefund = n.type === 'refund';
              const isEmail = n.type === 'email_dispatch';
              const isSale = n.type === 'ticket_sale';
              const isPayout = n.type === 'payment_payout';

              return (
                <div
                  key={n.id}
                  onClick={() => handleNotificationClick(n)}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer flex items-start gap-4 group shadow-sm ${
                    !n.isRead
                      ? 'bg-[#141720] border-emerald-500/40 hover:border-emerald-500/70'
                      : 'bg-[#111317] border-[#1f2229] hover:border-[#262934]'
                  }`}
                >
                  {/* Category Indicator Icon */}
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 mt-0.5 border ${
                      isRefund
                        ? 'bg-amber-500/10 border-amber-500/20 text-amber-400'
                        : isEmail
                        ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                        : isSale
                        ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                        : isPayout
                        ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                        : 'bg-blue-500/10 border-blue-500/20 text-blue-400'
                    }`}
                  >
                    {isRefund ? (
                      <RotateCcw className="w-5 h-5" />
                    ) : isEmail ? (
                      <Mail className="w-5 h-5" />
                    ) : isSale ? (
                      <Ticket className="w-5 h-5" />
                    ) : isPayout ? (
                      <DollarSign className="w-5 h-5" />
                    ) : (
                      <Calendar className="w-5 h-5" />
                    )}
                  </div>

                  {/* Content Area */}
                  <div className="flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-white truncate group-hover:text-emerald-400 transition-colors">
                        {n.title}
                      </h3>
                      {!n.isRead && (
                        <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                      )}
                    </div>

                    <p className="text-xs text-[#9496a1] leading-relaxed mt-1">
                      {n.message}
                    </p>

                    {/* Metadata & Quick Action Link */}
                    <div className="flex flex-wrap items-center gap-3 mt-2 text-[11px] text-[#646875] font-mono">
                      <span>{n.timestamp || 'Just now'}</span>
                      <span>·</span>

                      {isRefund && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedReceiptNotif(n);
                          }}
                          className="text-amber-400 flex items-center gap-1 hover:underline font-bold"
                        >
                          <Mail className="w-3 h-3" />
                          <span>Simulated Refund Receipt</span>
                        </button>
                      )}

                      {isEmail && (
                        <span className="text-emerald-400 flex items-center gap-1 font-bold group-hover:underline">
                          <Mail className="w-3 h-3" />
                          <span>Delivered to Email Inbox</span>
                        </span>
                      )}

                      {isSale && (
                        <span className="text-emerald-400 flex items-center gap-1 font-bold group-hover:underline">
                          <Ticket className="w-3 h-3" />
                          <span>View Buyer on Host Dashboard</span>
                        </span>
                      )}

                      {!isRefund && !isEmail && !isSale && (
                        <span className="text-emerald-400 flex items-center gap-1 group-hover:underline">
                          <span>View Details</span>
                          <ArrowRight className="w-3 h-3" />
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions (Read/Unread Toggle + Dismiss) */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => handleToggleRead(n, e)}
                      className="p-1.5 rounded-lg text-[#646875] hover:text-white transition-colors"
                      title={n.isRead ? 'Mark as unread' : 'Mark as read'}
                    >
                      <Check className={`w-3.5 h-3.5 ${n.isRead ? 'opacity-30' : 'text-emerald-400 font-bold'}`} />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        dismissNotification(n.id);
                      }}
                      className="p-1.5 rounded-lg text-[#646875] hover:text-red-400 transition-colors"
                      title="Dismiss alert"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Automated Refund Email Receipt Simulation Modal */}
        {selectedReceiptNotif && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
            onClick={() => setSelectedReceiptNotif(null)}
          >
            <div
              className="w-full max-w-md bg-[#111317] rounded-[32px] p-6 border border-[#1f2229] shadow-2xl space-y-4 text-[#f4f4f6]"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between pb-3 border-b border-[#1f2229]">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold uppercase tracking-wider text-[#9496a1]">
                    Automated Transaction Receipt
                  </span>
                </div>
                <button
                  onClick={() => setSelectedReceiptNotif(null)}
                  className="text-[#9496a1] hover:text-white text-xs font-bold"
                >
                  Close
                </button>
              </div>

              <div className="space-y-2">
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-amber-400 block">
                    100% Automated Refund Executed
                  </span>
                  <h4 className="text-base font-bold text-white">
                    {selectedReceiptNotif.title}
                  </h4>
                  <p className="text-xs text-[#9496a1]">
                    {selectedReceiptNotif.message}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-[#16181f] border border-[#232733] text-xs font-mono space-y-1.5 text-[#9496a1]">
                  <div className="flex justify-between">
                    <span>Dispatched To:</span>
                    <span className="text-white font-bold">Original Payment Method</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Refund Amount:</span>
                    <span className="text-emerald-400 font-bold">
                      {selectedReceiptNotif.refundAmount ? `KSh ${selectedReceiptNotif.refundAmount.toLocaleString()}` : 'Full Amount'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Dispatch Date:</span>
                    <span>{selectedReceiptNotif.date || 'Today'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Automated Trigger:</span>
                    <span>Host Event Deletion</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedReceiptNotif(null)}
                className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
