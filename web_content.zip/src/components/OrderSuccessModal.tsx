import React, { useEffect, useState } from 'react';
import { Order, StoreSettings, AppLanguage } from '../types';
import { formatPKR, generateWhatsAppOrderUrl } from '../utils/storage';
import confetti from 'canvas-confetti';
import { CheckCircle2, MessageCircle, Phone, Copy, Check, Share2, Sparkles, X, ArrowLeft } from 'lucide-react';

interface OrderSuccessModalProps {
  order: Order | null;
  onClose: () => void;
  settings: StoreSettings;
  language: AppLanguage;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  onClose,
  settings,
  language
}) => {
  if (!order) return null;
  const isUrdu = language === 'ur';
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Fire festive celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (e) {
      // ignore
    }
  }, []);

  const whatsappUrl = generateWhatsAppOrderUrl(order, settings.whatsappNumber);

  const handleCopyReceipt = () => {
    const text = 
`آرڈر سلپ - اویس بلال سٹور
آرڈر نمبر: #${order.id}
گاہک: ${order.customerName}
موبائل: ${order.customerPhone}
گاؤں: ${order.villageName}
پتہ: ${order.streetAddress}
کل رقم: Rs. ${order.total}
رابطہ: محمد اویس بلال 03017144300`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 animate-in zoom-in-95 duration-200">
      <div className="bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl my-4 flex flex-col">
        {/* Success Header */}
        <div className="bg-gradient-to-br from-emerald-600 via-emerald-700 to-emerald-900 text-white p-6 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-black/20 hover:bg-black/30 transition text-white"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center mx-auto mb-3 border-2 border-white/40 shadow-inner">
            <CheckCircle2 className="w-10 h-10 text-amber-300" />
          </div>

          <h2 className="text-xl sm:text-2xl font-black">
            {isUrdu ? 'آرڈر کامیابی سے درج ہو گیا ہے!' : 'Order Placed Successfully!'}
          </h2>
          <p className="text-emerald-100 text-xs sm:text-sm mt-1 max-w-sm mx-auto">
            {isUrdu 
              ? 'محمد اویس بلال کو واٹس ایپ پر آرڈر میسج بھیجنے کے لیے نیچے دیے گئے بٹن پر کلک کریں'
              : 'Tap below to send this order message directly to Muhammad Owais Bilal on WhatsApp'}
          </p>

          <div className="mt-3 inline-block bg-emerald-950/50 backdrop-blur-xs px-3 py-1 rounded-full text-xs font-mono font-bold text-amber-300 border border-emerald-500/30">
            {isUrdu ? 'آرڈر نمبر:' : 'Order ID:'} #{order.id}
          </div>
        </div>

        {/* WhatsApp Big Action Button */}
        <div className="p-4 sm:p-5 bg-emerald-50 border-b border-emerald-100 flex flex-col gap-2">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3.5 px-4 rounded-2xl shadow-lg flex items-center justify-center gap-2.5 text-base transition transform active:scale-98 animate-bounce"
          >
            <MessageCircle className="w-6 h-6 fill-white text-emerald-600 shrink-0" />
            <span>{isUrdu ? 'واٹس ایپ پر آرڈر بھیجیں (اویس بلال)' : 'Send Order on WhatsApp'}</span>
          </a>

          <div className="flex items-center justify-between text-xs text-emerald-800 px-1">
            <span>اویس بلال کا واٹس ایپ: <strong>{settings.phone}</strong></span>
            <a
              href={`tel:${settings.phone}`}
              className="text-emerald-700 font-bold underline flex items-center gap-1"
            >
              <Phone className="w-3.5 h-3.5 text-amber-600" />
              <span>فوری فون کریں</span>
            </a>
          </div>
        </div>

        {/* Order Receipt Details */}
        <div className="p-4 sm:p-5 flex-1 overflow-y-auto space-y-4">
          {/* Customer & Village Info */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-xs space-y-1.5">
            <div className="flex justify-between">
              <span className="text-slate-500">{isUrdu ? 'گاہک کا نام:' : 'Customer Name:'}</span>
              <span className="font-bold text-slate-800">{order.customerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">{isUrdu ? 'موبائل نمبر:' : 'Phone:'}</span>
              <span className="font-mono font-bold text-slate-800">{order.customerPhone}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">{isUrdu ? 'گاؤں / چک:' : 'Village:'}</span>
              <span className="font-bold text-emerald-800">{order.villageName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">{isUrdu ? 'پتہ / نشانی:' : 'Address:'}</span>
              <span className="font-medium text-slate-700 text-right max-w-[65%]">{order.streetAddress}</span>
            </div>
            {order.notes && (
              <div className="pt-1.5 border-t border-slate-200 text-slate-600">
                <span className="font-bold text-slate-700">{isUrdu ? 'اضافی سامان / نوٹ: ' : 'Notes: '}</span>
                <span>{order.notes}</span>
              </div>
            )}
          </div>

          {/* Ordered Items List */}
          <div>
            <h4 className="font-bold text-xs text-slate-700 mb-2">
              {isUrdu ? 'سامان کی فہرست:' : 'Ordered Items:'}
            </h4>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-white text-xs">
              {order.items.map((item, idx) => (
                <div key={idx} className="p-2.5 flex items-center justify-between">
                  <div className="flex-1 pr-2">
                    <p className="font-bold text-slate-800">
                      {item.urduName || item.name}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      {item.quantity} × {formatPKR(item.price, isUrdu)} ({item.unit})
                    </p>
                  </div>
                  <span className="font-black text-emerald-800">
                    {formatPKR(item.total, isUrdu)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Totals */}
          <div className="bg-slate-100 rounded-2xl p-3 text-xs space-y-1">
            <div className="flex justify-between text-slate-600">
              <span>{isUrdu ? 'سامان کی قیمت:' : 'Subtotal:'}</span>
              <span>{formatPKR(order.subtotal, isUrdu)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>{isUrdu ? 'ڈیلیوری چارجز:' : 'Delivery Fee:'}</span>
              <span className="font-bold text-emerald-700">
                {order.deliveryFee === 0 ? (isUrdu ? 'مفت' : 'FREE') : formatPKR(order.deliveryFee, isUrdu)}
              </span>
            </div>
            <div className="pt-1 border-t border-slate-200 flex justify-between font-black text-sm text-slate-900">
              <span>{isUrdu ? 'کل رقم:' : 'Total:'}</span>
              <span className="text-emerald-800">{formatPKR(order.total, isUrdu)}</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2">
          <button
            onClick={handleCopyReceipt}
            className="flex-1 flex items-center justify-center gap-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold py-2.5 rounded-xl text-xs transition"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-500" />}
            <span>{copied ? (isUrdu ? 'سلپ کاپی ہو گئی' : 'Copied!') : (isUrdu ? 'سلپ کاپی کریں' : 'Copy Slip')}</span>
          </button>

          <button
            onClick={onClose}
            className="flex-1 bg-emerald-800 hover:bg-emerald-900 text-white font-bold py-2.5 rounded-xl text-xs transition text-center"
          >
            {isUrdu ? 'دکان پر واپس جائیں' : 'Back to Shop'}
          </button>
        </div>
      </div>
    </div>
  );
};
