import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Layers,
  Calendar,
  Download,
  FileText,
  CheckCircle2,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { downloadEbookAsHtml } from '../utils/htmlDownloader';

export const CurrentAffairsView: React.FC = () => {
  const { currentAffairs, ebooks, showToast } = useApp();
  const [filterCategory, setFilterCategory] = useState<string>('All');

  const filteredItems = currentAffairs.filter(
    (item) => filterCategory === 'All' || item.category === filterCategory
  );

  const handleDownloadPdf = (title: string) => {
    // Look up matching ebook if available, or generate digest
    const foundBook = ebooks.find((b) => b.title.includes('Current Affairs')) || ebooks[0];
    downloadEbookAsHtml(foundBook, true);
    showToast(`Downloading Current Affairs study file for "${title.substring(0, 24)}..."`, 'success');
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8">
      {/* Top Banner */}
      <div className="bg-[#0B192C] text-white rounded-2xl p-6 sm:p-8 mb-6 border border-[#1E3E62] shadow-lg">
        <div className="max-w-2xl">
          <span className="text-xs font-bold text-amber-400 bg-amber-400/10 px-2.5 py-0.5 rounded border border-amber-400/20 uppercase tracking-wider">
            Daily & Monthly Digests
          </span>
          <h1 className="text-xl sm:text-3xl font-black text-white mt-1">
            Current Affairs & General Awareness Hub
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Specially tailored for Assam Police, ADRE 2.0, Railway NTPC, and Central SSC examinations.
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 text-xs">
        {['All', 'Assam & NE', 'National', 'Economy'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
              filterCategory === cat
                ? 'bg-[#0B192C] text-amber-400 shadow-sm'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            {cat === 'All' ? 'All Headlines & Digests' : cat}
          </button>
        ))}
      </div>

      {/* Articles & PDF cards */}
      <div className="space-y-4">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs hover:border-amber-400 transition-colors"
          >
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                  {item.category}
                </span>
                {item.isMonthlyPdf && (
                  <span className="text-[10px] font-black text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                    MONTHLY COMPILATION PDF
                  </span>
                )}
              </div>
              <div className="text-[11px] text-slate-500 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>{item.date}</span>
              </div>
            </div>

            <div className="mt-3">
              <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                {item.title}
              </h3>

              <div className="mt-3 space-y-1.5">
                {item.highlights.map((point, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{point}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-medium">
                {item.pages} Pages • {item.fileSize}
              </span>

              <button
                onClick={() => handleDownloadPdf(item.title)}
                className="flex items-center gap-1.5 font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 px-3.5 py-1.5 rounded-lg transition-colors shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{item.isMonthlyPdf ? 'Download Free Monthly PDF' : 'Download Study Notes'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
