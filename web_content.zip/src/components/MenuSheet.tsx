import React from 'react';
import { 
  Bookmark, 
  Download, 
  Settings, 
  Share2, 
  Search, 
  BookOpen, 
  Laptop, 
  Globe, 
  ShieldAlert, 
  X, 
  Plus, 
  RotateCw,
  Cpu
} from 'lucide-react';
import { Tab } from '../types/browser';

interface MenuSheetProps {
  isOpen: boolean;
  onClose: () => void;
  currentTab: Tab;
  onNewTab: () => void;
  onRefresh: () => void;
  onToggleReader: () => void;
  onToggleDesktop: () => void;
  onOpenSettings: () => void;
  onOpenBookmarks: () => void;
  onOpenDownloads: () => void;
  onOpenTorCircuit: () => void;
  onShareLink: () => void;
  onAddBookmark: () => void;
  onFindInPage: () => void;
}

export const MenuSheet: React.FC<MenuSheetProps> = ({
  isOpen,
  onClose,
  currentTab,
  onNewTab,
  onRefresh,
  onToggleReader,
  onToggleDesktop,
  onOpenSettings,
  onOpenBookmarks,
  onOpenDownloads,
  onOpenTorCircuit,
  onShareLink,
  onAddBookmark,
  onFindInPage,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm select-none animate-fade-in">
      {/* Tap backdrop to dismiss */}
      <div className="flex-1" onClick={onClose} />

      {/* Bottom Sheet Menu */}
      <div className="w-full max-w-lg mx-auto bg-slate-900 border-t border-slate-700/80 rounded-t-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-slide-up">
        {/* Handle */}
        <div className="pt-3 pb-1 flex justify-center cursor-grab" onClick={onClose}>
          <div className="w-12 h-1.5 rounded-full bg-slate-700" />
        </div>

        {/* Quick Icon Actions Row (New Tab, Bookmark, Share, Refresh) */}
        <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between">
          <button
            onClick={() => {
              onNewTab();
              onClose();
            }}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-colors"
          >
            <Plus className="w-5 h-5 text-emerald-400" />
            <span className="text-[10px] font-medium">New Tab</span>
          </button>

          <button
            onClick={() => {
              onAddBookmark();
              onClose();
            }}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-colors"
          >
            <Bookmark className="w-5 h-5 text-amber-400" />
            <span className="text-[10px] font-medium">Bookmark</span>
          </button>

          <button
            onClick={() => {
              onShareLink();
              onClose();
            }}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-colors"
          >
            <Share2 className="w-5 h-5 text-cyan-400" />
            <span className="text-[10px] font-medium">Clean Share</span>
          </button>

          <button
            onClick={() => {
              onRefresh();
              onClose();
            }}
            className="flex flex-col items-center gap-1 text-slate-300 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-colors"
          >
            <RotateCw className="w-5 h-5 text-slate-400" />
            <span className="text-[10px] font-medium">Reload</span>
          </button>
        </div>

        {/* Menu Items List */}
        <div className="p-3 overflow-y-auto space-y-1 no-scrollbar text-sm font-medium text-slate-200">
          {/* Reader View */}
          <button
            onClick={() => {
              onToggleReader();
              onClose();
            }}
            className="w-full px-3.5 py-2.5 rounded-xl hover:bg-slate-800/80 flex items-center justify-between transition-colors"
          >
            <div className="flex items-center gap-3">
              <BookOpen className="w-4 h-4 text-emerald-400" />
              <span>Reader Mode</span>
            </div>
            <span className={`text-xs px-2 py-0.5 rounded-md ${currentTab.readerMode ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60' : 'text-slate-500'}`}>
              {currentTab.readerMode ? 'Active' : 'Off'}
            </span>
          </button>

          {/* Desktop Site Toggle */}
          <button
            onClick={() => {
              onToggleDesktop();
              onClose();
            }}
            className="w-full px-3.5 py-2.5 rounded-xl hover:bg-slate-800/80 flex items-center justify-between transition-colors"
          >
            <div className="flex items-center gap-3">
              <Laptop className="w-4 h-4 text-slate-400" />
              <span>Desktop Site</span>
            </div>
            <span className={`text-xs px-2 py-0.5 rounded-md ${currentTab.desktopMode ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60' : 'text-slate-500'}`}>
              {currentTab.desktopMode ? 'Active' : 'Off'}
            </span>
          </button>

          {/* Find in Page */}
          <button
            onClick={() => {
              onFindInPage();
              onClose();
            }}
            className="w-full px-3.5 py-2.5 rounded-xl hover:bg-slate-800/80 flex items-center gap-3 transition-colors"
          >
            <Search className="w-4 h-4 text-slate-400" />
            <span>Find in Page</span>
          </button>

          <div className="h-px bg-slate-800 my-1" />

          {/* Tor Relay Circuit Details */}
          <button
            onClick={() => {
              onOpenTorCircuit();
              onClose();
            }}
            className="w-full px-3.5 py-2.5 rounded-xl hover:bg-slate-800/80 flex items-center justify-between transition-colors"
          >
            <div className="flex items-center gap-3">
              <Globe className="w-4 h-4 text-purple-400" />
              <span>Tor Onion Circuit</span>
            </div>
            <span className="text-[11px] text-purple-300 font-mono">3 Relays Active</span>
          </button>

          {/* Bookmarks */}
          <button
            onClick={() => {
              onOpenBookmarks();
              onClose();
            }}
            className="w-full px-3.5 py-2.5 rounded-xl hover:bg-slate-800/80 flex items-center gap-3 transition-colors"
          >
            <Bookmark className="w-4 h-4 text-amber-400" />
            <span>Bookmarks</span>
          </button>

          {/* Downloads */}
          <button
            onClick={() => {
              onOpenDownloads();
              onClose();
            }}
            className="w-full px-3.5 py-2.5 rounded-xl hover:bg-slate-800/80 flex items-center gap-3 transition-colors"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>Downloads</span>
          </button>

          <div className="h-px bg-slate-800 my-1" />

          {/* Settings */}
          <button
            onClick={() => {
              onOpenSettings();
              onClose();
            }}
            className="w-full px-3.5 py-2.5 rounded-xl hover:bg-slate-800/80 flex items-center gap-3 transition-colors text-slate-100"
          >
            <Settings className="w-4 h-4 text-slate-300" />
            <span>Privacy Settings</span>
          </button>
        </div>

        {/* Close Button at Bottom */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 font-semibold text-xs active:scale-95 transition-all"
          >
            Close Menu
          </button>
        </div>
      </div>
    </div>
  );
};
