import React from 'react';
import { RotateCcw, BookOpen, Award, CheckCircle2, Pill, Shirt } from 'lucide-react';

interface EndGameModalProps {
  score: number;
  correctCount: number;
  totalQuestions: number;
  collectedCapsules: number;
  walletPoints: number;
  onRestart: () => void;
  onOpenStudyGuide: () => void;
  onOpenSkinStore: () => void;
}

export const EndGameModal: React.FC<EndGameModalProps> = ({
  score,
  correctCount,
  totalQuestions,
  collectedCapsules,
  walletPoints,
  onRestart,
  onOpenStudyGuide,
  onOpenSkinStore,
}) => {
  const accuracy = Math.round((correctCount / totalQuestions) * 100);

  let title = 'بطل الصيدلة!';
  let emoji = '🏆';
  let badgeText = 'كيميائي متميز';

  if (score >= 2100) {
    title = 'أسطورة الصيدلة التحليلية!';
    emoji = '👑🏆';
    badgeText = 'علامة كاملة وإتقان فائق';
  } else if (score >= 1700) {
    title = 'عاش يا دكتور! أداء مبهر';
    emoji = '🌟🧪';
    badgeText = 'صيدلي محترف';
  } else if (score >= 1200) {
    title = 'برافو! إنجاز ممتاز في المعمل';
    emoji = '🧑‍🔬';
    badgeText = 'كيميائي صاعد واعد';
  } else {
    title = 'مغامرة رائعة يا دكتور!';
    emoji = '💪💊';
    badgeText = 'متدرب مجتهد';
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#030615e6] backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl bg-gradient-to-b from-[#142352] to-[#090f28] border border-[#68eeff99] shadow-[0_0_50px_rgba(76,245,255,0.3)] p-6 sm:p-8 text-center text-white">
        {/* Hero Emoji & Trophy */}
        <div className="text-6xl mb-2">{emoji}</div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1b2f6b] border border-[#4cf5ff60] text-xs font-bold text-[#ffe18a] mb-3">
          <Award className="w-4 h-4 text-[#ffe18a]" />
          <span>{badgeText}</span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#4cf5ff] mb-2">{title}</h1>
        <p className="text-slate-300 text-sm leading-relaxed mb-6">
          أتممت جميع محطات المعمل الـ 20 بنجاح، وتغلبت على عقبات المنصات والتسريبات وجمعت الكبسولات!
        </p>

        {/* Score Card Grid */}
        <div className="grid grid-cols-3 gap-2.5 mb-5">
          <div className="bg-[#0b1434] border border-[#2d417c] rounded-2xl p-3">
            <span className="text-xs text-slate-400 block mb-1">النقاط الكلية</span>
            <div className="text-xl sm:text-2xl font-black text-[#ffe18a] font-mono-num">
              {score}
            </div>
          </div>

          <div className="bg-[#0b1434] border border-[#2d417c] rounded-2xl p-3">
            <span className="text-xs text-slate-400 block mb-1">إجابات صحيحة</span>
            <div className="text-xl sm:text-2xl font-black text-[#38ef7d] font-mono-num flex items-center justify-center gap-1">
              <CheckCircle2 className="w-4 h-4 text-[#38ef7d] hidden sm:inline" />
              <span>
                {correctCount} / {totalQuestions}
              </span>
            </div>
          </div>

          <div className="bg-[#0b1434] border border-[#2d417c] rounded-2xl p-3">
            <span className="text-xs text-slate-400 block mb-1">الكبسولات</span>
            <div className="text-xl sm:text-2xl font-black text-[#4cf5ff] font-mono-num flex items-center justify-center gap-1">
              <Pill className="w-4 h-4 text-[#4cf5ff] hidden sm:inline" />
              <span>{collectedCapsules}</span>
            </div>
          </div>
        </div>

        {/* Accuracy Progress & Wallet */}
        <div className="bg-[#0a1230] border border-[#233568] rounded-2xl p-3.5 mb-6 text-right">
          <div className="flex justify-between text-xs text-slate-300 font-bold mb-1.5">
            <span>نسبة الدقة في الأسئلة</span>
            <span className="text-[#ffe18a] font-mono-num">{accuracy}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-[#141f48] overflow-hidden mb-2">
            <div
              className="h-full bg-gradient-to-r from-[#4cf5ff] to-[#38ef7d] transition-all duration-500"
              style={{ width: `${accuracy}%` }}
            />
          </div>
          <div className="text-xs text-slate-300 flex items-center justify-between pt-1 border-t border-white/10">
            <span>رصيد محفظة النقاط الكلي:</span>
            <strong className="text-[#ffe18a] font-mono-num">{walletPoints} نقطة متاحة للشراء</strong>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-2.5">
          <button
            onClick={onRestart}
            className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-[#4cf5ff] to-[#9b6bff] text-[#071129] font-bold text-sm shadow-[0_4px_16px_rgba(76,245,255,0.3)] hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>جولة جديدة</span>
          </button>

          <button
            onClick={onOpenSkinStore}
            className="py-3 px-4 rounded-2xl bg-[#1b326c] hover:bg-[#254391] border border-[#4cf5ff80] text-white font-bold text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <Shirt className="w-4 h-4 text-[#4cf5ff]" />
            <span>متجر الاسكنات</span>
          </button>

          <button
            onClick={onOpenStudyGuide}
            className="py-3 px-4 rounded-2xl bg-[#142352] hover:bg-[#1a2f6d] border border-[#5a7bc4] text-white font-bold text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <BookOpen className="w-4 h-4 text-[#ffe18a]" />
            <span>المراجعة</span>
          </button>
        </div>
      </div>
    </div>
  );
};
