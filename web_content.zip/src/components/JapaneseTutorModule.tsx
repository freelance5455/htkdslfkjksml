import React, { useState } from 'react';
import {
  Languages,
  Send,
  Volume2,
  Sparkles,
  AlertCircle,
  BookOpen,
  CheckCheck,
  Mic,
  GraduationCap,
} from 'lucide-react';
import type { VoiceProfileId } from '../types';
import { VOICE_PROFILES, extractReadableError } from '../utils/rajuEngine';

interface JapaneseTutorProps {
  selectedVoice: VoiceProfileId;
  onVoiceChange: (voice: VoiceProfileId) => void;
  onEarnXp: (amount: number) => void;
  onRecordTokens: (tokens: number) => void;
}

type TutorMode =
  | 'daily_lesson'
  | 'grammar_check'
  | 'vocabulary'
  | 'conversation'
  | 'pronunciation_feedback'
  | 'jlpt_test';

interface TutorTurn {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  mode: TutorMode;
}

const MODE_OPTIONS: Array<{ id: TutorMode; label: string; promptPlaceholder: string }> = [
  {
    id: 'daily_lesson',
    label: 'Daily Lesson',
    promptPlaceholder: 'Ask Sensei for today’s N5/N4 lesson (e.g., Teach me how to order food in Japanese using Hinglish)...',
  },
  {
    id: 'grammar_check',
    label: 'Grammar Mistake Corrector',
    promptPlaceholder: 'Paste your Japanese sentence to check mistakes (e.g., わたしは 図書館 を 勉強します)...',
  },
  {
    id: 'vocabulary',
    label: 'Vocabulary Explorer',
    promptPlaceholder: 'Ask about any word or Kanji (e.g., Explain 富士山, 火山, 山道 in Hindi/Hinglish)...',
  },
  {
    id: 'conversation',
    label: 'Japanese Conversation',
    promptPlaceholder: 'Practice roleplay with Sensei (e.g., こんにちは！駅はどこですか？)...',
  },
  {
    id: 'pronunciation_feedback',
    label: 'Pronunciation Coach',
    promptPlaceholder: 'Type a phrase to get syllable mora timing & Hindi sound guide (e.g., ありがとうございます)...',
  },
  {
    id: 'jlpt_test',
    label: 'JLPT Practice Test',
    promptPlaceholder: 'Request a mini JLPT N5–N1 quiz from Sensei...',
  },
];

export const JapaneseTutorModule: React.FC<JapaneseTutorProps> = ({
  selectedVoice,
  onVoiceChange,
  onEarnXp,
  onRecordTokens,
}) => {
  const [mode, setMode] = useState<TutorMode>('daily_lesson');
  const [level, setLevel] = useState('Absolute Beginner (JLPT N5)');
  const [explainLanguage, setExplainLanguage] = useState<'Hinglish' | 'Hindi' | 'English' | 'Japanese'>('Hinglish');
  const [input, setInput] = useState('');
  const [turns, setTurns] = useState<TutorTurn[]>([
    {
      id: 'tutor_welcome',
      role: 'assistant',
      mode: 'daily_lesson',
      content:
        'こんにちは (Konnichiwa)! Main aapka RAJU AI Japanese Sensei hoon.\n\nAaj hum Hinglish aur Hindi ke easy examples se **Daily Lesson, Grammar Mistake Correction, Vocabulary, Pronunciation, aur JLPT N5–N1** practice karenge!\n\nExample try karein: *"Mujhe 「わたしは 図書館を 勉強します」 ka grammar mistake check karke Hindi mein samjhaiye."*',
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [speakingTurnId, setSpeakingTurnId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const activeModeMeta = MODE_OPTIONS.find((m) => m.id === mode) || MODE_OPTIONS[0];

  const handleSendToSensei = async (overrideText?: string) => {
    const msg = (overrideText ?? input).trim();
    if (!msg) return;
    setErrorMsg(null);
    if (overrideText === undefined) setInput('');

    const userTurn: TutorTurn = {
      id: `t_u_${Date.now()}`,
      role: 'user',
      content: msg,
      mode,
    };
    setTurns((prev) => [...prev, userTurn]);
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/japanese-tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          level,
          explainLanguage,
          userMessage: msg,
          history: turns.slice(-8).map((t) => ({ role: t.role, content: t.content })),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(extractReadableError(data.error || data, 'Japanese Tutor request failed.'));
      }
      const replyTurn: TutorTurn = {
        id: `t_a_${Date.now()}`,
        role: 'assistant',
        content: data.reply || '',
        mode,
      };
      setTurns((prev) => [...prev, replyTurn]);
      if (data.usage?.totalTokens) onRecordTokens(data.usage.totalTokens);
      onEarnXp(15);
    } catch (err) {
      setErrorMsg(extractReadableError(err, 'Unable to reach AI Japanese Tutor.'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSpeakTurn = async (turn: TutorTurn) => {
    setErrorMsg(null);
    setSpeakingTurnId(turn.id);
    const tutorVoice: VoiceProfileId =
      selectedVoice === 'My Voice' ? 'Japanese Teacher' : selectedVoice;
    try {
      const res = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: turn.content.replace(/[*#_`]/g, '').slice(0, 800),
          voiceProfile: tutorVoice,
          speed: 'slow',
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(extractReadableError(data.error || data, 'TTS voice playback failed.'));
      }
      if (data.audioBase64) {
        const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
        audio.onended = () => setSpeakingTurnId(null);
        await audio.play();
      } else {
        setSpeakingTurnId(null);
      }
    } catch (err) {
      setSpeakingTurnId(null);
      setErrorMsg(extractReadableError(err, 'Unable to synthesize Tutor voice.'));
    }
  };

  const quickSenseiPrompts = [
    {
      label: 'Fix Grammar Mistake',
      mode: 'grammar_check' as TutorMode,
      text: 'Please check and correct my sentence: 「わたしは まいにち がっこうを いきます。」 Explain in Hinglish.',
    },
    {
      label: 'Today’s N5 Daily Lesson',
      mode: 'daily_lesson' as TutorMode,
      text: 'Teach me 5 essential daily Japanese phrases with Hiragana, Romaji, and Hinglish meanings.',
    },
    {
      label: 'Pronunciation Guide',
      mode: 'pronunciation_feedback' as TutorMode,
      text: 'How do I pronounce ありがとうございます and きっぷ (double consonant) naturally? Give Hindi phonetic tips.',
    },
    {
      label: 'Mini JLPT Test',
      mode: 'jlpt_test' as TutorMode,
      text: 'Give me a 3-question interactive JLPT check on particles and Kanji with solutions.',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <GraduationCap className="w-6 h-6 text-cyan-400" />
            AI Japanese Tutor (日本語の先生 — Hinglish & Hindi)
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Personal Japanese Sensei from Absolute Beginner to JLPT N1 with grammar mistake correction, pronunciation coaching, and anime/teacher voice audio.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            aria-label="JLPT Level"
            value={level}
            onChange={(e) => setLevel(e.target.value)}
            className="px-3 py-2 rounded-xl bg-[#0B102B] border border-slate-800 text-xs text-white"
          >
            <option>Absolute Beginner (JLPT N5)</option>
            <option>Elementary (JLPT N4)</option>
            <option>Intermediate (JLPT N3)</option>
            <option>Upper Intermediate (JLPT N2)</option>
            <option>Mastery (JLPT N1)</option>
          </select>

          <select
            aria-label="Explanation Language"
            value={explainLanguage}
            onChange={(e) => setExplainLanguage(e.target.value as typeof explainLanguage)}
            className="px-3 py-2 rounded-xl bg-[#0B102B] border border-slate-800 text-xs text-cyan-300 font-semibold"
          >
            <option value="Hinglish">Explain in Hinglish</option>
            <option value="Hindi">Explain in Hindi (हिंदी)</option>
            <option value="English">Explain in English</option>
            <option value="Japanese">Japanese Immersion</option>
          </select>

          <select
            aria-label="Tutor Voice Personality"
            value={selectedVoice}
            onChange={(e) => onVoiceChange(e.target.value as VoiceProfileId)}
            className="px-3 py-2 rounded-xl bg-[#0B102B] border border-slate-800 text-xs text-purple-300 font-semibold"
          >
            {VOICE_PROFILES.filter((v) => !v.isFutureFeature).map((v) => (
              <option key={v.id} value={v.id}>
                Voice: {v.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Mode Switcher Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1.5 rounded-2xl bg-[#0B102B] border border-slate-800">
        {MODE_OPTIONS.map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => setMode(m.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition ${
              mode === m.id
                ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {errorMsg && (
        <div role="alert" className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <button type="button" onClick={() => setErrorMsg(null)} className="underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Quick Sensei Prompts */}
      <div className="flex flex-wrap gap-2">
        {quickSenseiPrompts.map((qp) => (
          <button
            key={qp.label}
            type="button"
            onClick={() => {
              setMode(qp.mode);
              handleSendToSensei(qp.text);
            }}
            className="px-3 py-1.5 rounded-xl bg-[#0B102B] border border-slate-800 hover:border-cyan-400 text-xs text-slate-200 flex items-center gap-1.5 transition"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            {qp.label}
          </button>
        ))}
      </div>

      {/* Tutor Conversation Panel */}
      <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
        <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
          {turns.map((t) => (
            <div
              key={t.id}
              className={`flex ${t.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[88%] rounded-2xl p-4 text-sm leading-relaxed space-y-2 ${
                  t.role === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white'
                    : 'bg-[#060919] border border-slate-800 text-slate-100'
                }`}
              >
                <div className="flex items-center justify-between gap-4 text-[11px] text-slate-400">
                  <span className="font-semibold text-cyan-300 flex items-center gap-1.5">
                    {t.role === 'assistant' ? (
                      <>
                        <Languages className="w-3.5 h-3.5" />
                        Sensei ({explainLanguage})
                      </>
                    ) : (
                      <>
                        <CheckCheck className="w-3.5 h-3.5" />
                        You
                      </>
                    )}
                  </span>
                  {t.role === 'assistant' && (
                    <button
                      type="button"
                      onClick={() => handleSpeakTurn(t)}
                      disabled={speakingTurnId === t.id}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 flex items-center gap-1"
                    >
                      <Volume2 className={`w-3 h-3 ${speakingTurnId === t.id ? 'animate-pulse' : ''}`} />
                      {speakingTurnId === t.id ? 'Speaking...' : `Read (${selectedVoice === 'My Voice' ? 'Japanese Teacher' : selectedVoice})`}
                    </button>
                  )}
                </div>
                <div className="whitespace-pre-wrap">{t.content}</div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="p-4 rounded-2xl bg-[#060919] border border-slate-800 text-xs text-cyan-300 flex items-center gap-2 w-fit">
              <BookOpen className="w-4 h-4 animate-pulse" />
              Sensei is preparing your {explainLanguage} explanation...
            </div>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendToSensei();
          }}
          className="flex gap-2 pt-3 border-t border-slate-800/80"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={activeModeMeta.promptPlaceholder}
            aria-label="Ask AI Japanese Sensei"
            className="flex-1 min-w-0 px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            Ask Sensei
          </button>
        </form>
      </div>
    </div>
  );
};
