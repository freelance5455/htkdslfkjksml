import React, { useState } from 'react';
import { Layers, Move, Play, Square, X, Sparkles, Smartphone, Check } from 'lucide-react';
import { SoundItem } from '../types';

interface FloatingOverlaySimulatorProps {
  sounds: SoundItem[];
  onPlaySound: (sound: SoundItem) => void;
  onStopAll: () => void;
  activeSoundId: string | null;
}

export const FloatingOverlaySimulator: React.FC<FloatingOverlaySimulatorProps> = ({
  sounds,
  onPlaySound,
  onStopAll,
  activeSoundId,
}) => {
  const [bubblePos, setBubblePos] = useState({ x: 28, y: 120 });
  const [isPaletteOpen, setIsPaletteOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - bubblePos.x,
      y: e.clientY - bubblePos.y,
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const parent = e.currentTarget.getBoundingClientRect();
    const newX = Math.max(10, Math.min(parent.width - 70, e.clientX - parent.left - 25));
    const newY = Math.max(10, Math.min(parent.height - 70, e.clientY - parent.top - 25));
    setBubblePos({ x: newX, y: newY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-[#0e101a] border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">
              FEATURE SIMULATOR
            </span>
            <span className="text-xs text-slate-400">Android System Alert Window</span>
          </div>
          <h3 className="font-orbitron text-xl font-bold text-white flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-red-500" />
            Free Fire In-Game Floating Overlay Simulator
          </h3>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            অ্যান্ড্রয়েড অ্যাপটিতে রয়েছে <code className="text-cyan-300">FloatingSoundboardService</code>। গেম মিনিমাইজ না করেই স্ক্রিনে ভাসমান REX বাটনে চাপ দিয়ে সাউন্ড প্লে করতে পারবেন। নিচে ড্র্যাগ করে টেস্ট করুন:
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 bg-cyan-950/40 px-3 py-2 rounded-xl border border-cyan-800/40">
          <Move className="w-4 h-4 shrink-0" />
          <span>Drag REX Bubble Anywhere</span>
        </div>
      </div>

      {/* Mobile Mockup Screen */}
      <div
        className="relative mx-auto w-full max-w-3xl h-[420px] rounded-3xl border-4 border-slate-800 bg-gradient-to-br from-[#0c0d14] via-[#121524] to-[#08090f] overflow-hidden shadow-2xl select-none"
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Background Gaming HUD simulation */}
        <div className="absolute inset-0 opacity-40 pointer-events-none cyber-grid flex flex-col justify-between p-6">
          <div className="flex justify-between items-center text-xs font-mono text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>FREE FIRE • BATTLE ROYALE (ALIVE: 48)</span>
            </div>
            <div className="text-red-400 font-bold">ZONE SHRINKING: 01:24</div>
          </div>

          <div className="text-center font-orbitron text-3xl font-black text-slate-700/40 tracking-widest">
            BERMUDA RANKED
          </div>

          <div className="flex justify-between items-end text-xs font-mono text-slate-500">
            <div>HP: 200/200 [ARMOR LVL 3]</div>
            <div>PING: 24ms • 60 FPS</div>
          </div>
        </div>

        {/* Draggable Floating REX Bubble */}
        <div
          style={{ left: `${bubblePos.x}px`, top: `${bubblePos.y}px` }}
          className="absolute z-30 cursor-move"
          onMouseDown={handleMouseDown}
        >
          <div
            onClick={(e) => {
              e.stopPropagation();
              if (!isDragging) setIsPaletteOpen(!isPaletteOpen);
            }}
            className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-red-600 to-rose-900 border-2 border-cyan-400 shadow-[0_0_20px_rgba(255,30,68,0.7)] hover:scale-105 active:scale-95 transition-transform"
          >
            <span className="font-orbitron font-black text-xs tracking-wider text-white">
              REX
            </span>
            <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-cyan-400 border-2 border-black animate-pulse" />
          </div>
        </div>

        {/* Floating Mini Sound Palette Overlay */}
        {isPaletteOpen && (
          <div
            style={{
              left: `${Math.min(bubblePos.x + 65, 480)}px`,
              top: `${Math.max(20, Math.min(bubblePos.y - 20, 160))}px`,
            }}
            className="absolute z-40 w-64 rounded-2xl border border-cyan-500/50 bg-[#0e101cf2] backdrop-blur-md p-3.5 shadow-2xl space-y-3"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-1.5 font-orbitron text-xs font-bold text-white">
                <span className="text-red-500">REX</span> SOUNDS
              </div>
              <button
                onClick={() => setIsPaletteOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Stop Button */}
            <button
              onClick={() => {
                onStopAll();
              }}
              className="w-full py-1.5 rounded-lg bg-red-950/80 border border-red-500/50 text-[11px] font-chakra font-bold text-red-300 hover:bg-red-900/60 transition-colors flex items-center justify-center gap-1.5"
            >
              <Square className="w-3 h-3 fill-current" /> STOP ACTIVE SOUND
            </button>

            {/* Quick Sound Buttons List */}
            <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
              {sounds.length === 0 ? (
                <p className="text-[11px] text-slate-400 text-center py-4">
                  কোনো সাউন্ড নেই। প্রথমে Soundboard ট্যাবে সাউন্ড আপলোড করুন।
                </p>
              ) : (
                sounds.slice(0, 8).map((sound) => {
                  const isPlaying = activeSoundId === sound.id;
                  return (
                    <button
                      key={sound.id}
                      onClick={() => onPlaySound(sound)}
                      className={`w-full flex items-center justify-between px-2.5 py-2 rounded-xl text-left text-xs font-chakra font-bold transition-all ${
                        isPlaying
                          ? 'bg-red-600 text-white shadow-[0_0_12px_rgba(255,30,68,0.7)]'
                          : 'bg-[#181b2b] text-slate-200 hover:bg-[#20253b] hover:text-cyan-300'
                      }`}
                    >
                      <span className="truncate pr-2">{sound.name}</span>
                      {isPlaying ? (
                        <Square className="w-3 h-3 fill-current shrink-0" />
                      ) : (
                        <Play className="w-3 h-3 fill-current shrink-0 text-cyan-400" />
                      )}
                    </button>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
