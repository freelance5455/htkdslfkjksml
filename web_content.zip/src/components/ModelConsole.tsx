import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  Brain,
  CheckCircle2,
  Clock,
  Coins,
  Cpu,
  Database,
  ExternalLink,
  Layers,
  Play,
  RefreshCw,
  Shield,
  Sparkles,
  Zap,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { ModelMetadata } from '../types.ts';

interface ModelConsoleProps {
  hasGeminiApiKey?: boolean;
}

export const ModelConsole: React.FC<ModelConsoleProps> = ({ hasGeminiApiKey }) => {
  const [models, setModels] = useState<ModelMetadata[]>([]);
  const [decisions, setDecisions] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [probePrompt, setProbePrompt] = useState('Verify model availability and response latency.');
  const [probeCategory, setProbeCategory] = useState<'general' | 'reasoning' | 'coding' | 'fast'>('general');
  const [probeResult, setProbeResult] = useState<any | null>(null);
  const [isProbing, setIsProbing] = useState(false);
  const [selectedModelFilter, setSelectedModelFilter] = useState<string>('all');

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [modelsData, decisionsData] = await Promise.all([
        api.getModels(),
        api.getModelDecisions(15),
      ]);
      setModels(modelsData.models || []);
      setDecisions(decisionsData.decisions || []);
    } catch (err) {
      console.error('Failed to load model registry data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleRunProbe = async () => {
    if (!probePrompt.trim()) return;
    setIsProbing(true);
    setProbeResult(null);
    try {
      const res = await api.testModelProbe({
        prompt: probePrompt,
        category: probeCategory,
      });
      setProbeResult(res);
      await loadData();
    } catch (err: any) {
      setProbeResult({ success: false, error: err?.message || 'Probe execution failed' });
    } finally {
      setIsProbing(false);
    }
  };

  const getStatusBadge = (model: any) => {
    const health = model.health?.status || (model.isHealthy ? 'healthy' : 'unavailable');

    switch (health) {
      case 'healthy':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            HEALTHY
          </span>
        );
      case 'degraded':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            DEGRADED
          </span>
        );
      case 'rate_limited':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-purple-50 text-purple-700 border border-purple-200">
            <Clock className="w-3 h-3 text-purple-600" />
            RATE LIMITED
          </span>
        );
      case 'auth_failure':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <Shield className="w-3 h-3 text-rose-600" />
            AUTH REQUIRED
          </span>
        );
      case 'timeout':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-orange-50 text-orange-700 border border-orange-200">
            <AlertCircle className="w-3 h-3 text-orange-600" />
            TIMEOUT
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-600 border border-slate-200">
            <AlertCircle className="w-3 h-3 text-slate-500" />
            UNAVAILABLE
          </span>
        );
    }
  };

  const filteredModels = models.filter((m) => {
    if (selectedModelFilter === 'all') return true;
    if (selectedModelFilter === 'google') return m.provider === 'google-gemini';
    if (selectedModelFilter === 'local') return m.provider === 'local-heuristic';
    return true;
  });

  return (
    <div id="jarvis-model-console" className="space-y-6">
      {/* Top Banner: Router Architecture Status */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-600 shrink-0">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 tracking-tight">
                  INTELLIGENT MODEL ROUTER & MULTI-TIER ENGINE
                </h2>
                <span className="text-[11px] px-2 py-0.5 rounded bg-sky-100 text-sky-800 font-mono font-semibold">
                  ACTIVE ROUTING
                </span>
              </div>
              <p className="text-sm text-slate-600 mt-0.5">
                Multi-factor capability routing, automated fallback chains, bounded schema repair, and isolated edge execution.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <button
              id="refresh-models-btn"
              onClick={loadData}
              disabled={isLoading}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-semibold transition-all shadow-xs"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-sky-600' : ''}`} />
              <span>Refresh Metrics</span>
            </button>
          </div>
        </div>

        {/* Fallback Flow Indicator */}
        <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-[11px] font-mono text-slate-500 uppercase font-semibold">
              Primary Model Engine
            </div>
            <div className="flex items-center gap-2 mt-1">
              <Sparkles className="w-4 h-4 text-sky-600" />
              <span className="text-sm font-bold text-slate-900">
                {hasGeminiApiKey ? 'Gemini 3.8 Flash' : 'Edge Heuristic'}
              </span>
            </div>
            <div className="text-xs text-slate-500 mt-1 font-mono">
              {hasGeminiApiKey ? 'Server-Side Google GenAI SDK' : 'Offline Safe Edge Engine'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-[11px] font-mono text-slate-500 uppercase font-semibold">
              Secondary Fallback
            </div>
            <div className="flex items-center gap-2 mt-1">
              <Brain className="w-4 h-4 text-indigo-600" />
              <span className="text-sm font-bold text-slate-900">Gemini 3.1 Pro Preview</span>
            </div>
            <div className="text-xs text-slate-500 mt-1 font-mono">
              Deep reasoning & complex code analysis
            </div>
          </div>

          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-[11px] font-mono text-slate-500 uppercase font-semibold">
              Deterministic Safety Net
            </div>
            <div className="flex items-center gap-2 mt-1">
              <Cpu className="w-4 h-4 text-emerald-600" />
              <span className="text-sm font-bold text-slate-900">JARVIS Local Heuristic</span>
            </div>
            <div className="text-xs text-slate-500 mt-1 font-mono">
              0ms latency, zero API cost, guaranteed output
            </div>
          </div>
        </div>
      </div>

      {/* Model Fleet Cards */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
              Registered Model Fleet ({filteredModels.length})
            </h3>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-xs">
            <button
              onClick={() => setSelectedModelFilter('all')}
              className={`px-2.5 py-1 rounded-md transition-all font-medium ${
                selectedModelFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Providers
            </button>
            <button
              onClick={() => setSelectedModelFilter('google')}
              className={`px-2.5 py-1 rounded-md transition-all font-medium ${
                selectedModelFilter === 'google'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Google Gemini
            </button>
            <button
              onClick={() => setSelectedModelFilter('local')}
              className={`px-2.5 py-1 rounded-md transition-all font-medium ${
                selectedModelFilter === 'local'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Edge Local
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredModels.map((model: any) => {
            const isLocal = model.provider === 'local-heuristic';
            return (
              <div
                key={model.id}
                id={`model-card-${model.id}`}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-slate-900 text-sm">{model.name}</h4>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">
                          {model.id}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5 font-medium">
                        Provider: <span className="font-semibold text-slate-700">{model.provider}</span>
                      </div>
                    </div>
                    {getStatusBadge(model)}
                  </div>

                  {/* Capabilities */}
                  <div className="flex items-center gap-1.5 flex-wrap mt-3">
                    <span className="text-[10px] px-2 py-0.5 rounded-md bg-sky-50 text-sky-800 font-semibold border border-sky-200 uppercase">
                      {model.category}
                    </span>
                    {(model.capabilities || []).map((cap: string) => (
                      <span
                        key={cap}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-mono"
                      >
                        {cap}
                      </span>
                    ))}
                  </div>

                  {/* Operational Telemetry */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4 pt-3 border-t border-slate-100 text-center font-mono">
                    <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <div className="text-[10px] text-slate-500 uppercase">Latency</div>
                      <div className="text-xs font-bold text-slate-900 mt-0.5">
                        {model.telemetry?.averageLatencyMs || model.averageLatencyMs || 0}ms
                      </div>
                    </div>

                    <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <div className="text-[10px] text-slate-500 uppercase">Requests</div>
                      <div className="text-xs font-bold text-slate-900 mt-0.5">
                        {model.telemetry?.requestCount || model.totalRequests || 0}
                      </div>
                    </div>

                    <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <div className="text-[10px] text-slate-500 uppercase">Tokens</div>
                      <div className="text-xs font-bold text-slate-900 mt-0.5">
                        {((model.telemetry?.totalTokens || model.totalTokensUsed || 0) / 1000).toFixed(1)}k
                      </div>
                    </div>

                    <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <div className="text-[10px] text-slate-500 uppercase">Est. Cost</div>
                      <div className="text-xs font-bold text-emerald-700 mt-0.5">
                        ${(model.telemetry?.estimatedTotalCostUsd || 0).toFixed(4)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer notes */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <span className="font-mono text-[11px]">
                    Context: {model.contextWindow?.toLocaleString()} tokens
                  </span>
                  {model.telemetry?.fallbackCount > 0 && (
                    <span className="text-amber-700 font-medium font-mono text-[11px]">
                      Fallbacks: {model.telemetry.fallbackCount}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Live Model Routing Probe */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-sky-600" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
              Live Model Routing Probe
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            Directly test deterministic router candidate scoring
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="md:col-span-3">
            <input
              id="model-probe-input"
              type="text"
              value={probePrompt}
              onChange={(e) => setProbePrompt(e.target.value)}
              placeholder="Enter probe prompt..."
              className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500 font-sans"
            />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={probeCategory}
              onChange={(e: any) => setProbeCategory(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg border border-slate-200 bg-white text-slate-700 font-semibold focus:outline-none focus:ring-2 focus:ring-sky-500"
            >
              <option value="general">Category: General</option>
              <option value="reasoning">Category: Reasoning</option>
              <option value="coding">Category: Coding</option>
              <option value="fast">Category: Fast</option>
            </select>

            <button
              id="execute-probe-btn"
              onClick={handleRunProbe}
              disabled={isProbing || !probePrompt.trim()}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-all disabled:opacity-50 shrink-0 shadow-xs"
            >
              {isProbing ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Play className="w-3.5 h-3.5 fill-current" />
              )}
              <span>{isProbing ? 'Probing...' : 'Probe Router'}</span>
            </button>
          </div>
        </div>

        {/* Probe Output */}
        {probeResult && (
          <div className="mt-4 p-4 rounded-lg bg-slate-50 border border-slate-200 text-xs">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span
                  className={`font-bold font-mono px-2 py-0.5 rounded text-[11px] ${
                    probeResult.success
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {probeResult.success ? 'PROBE SUCCESSFUL' : 'PROBE FAILED'}
                </span>
                {probeResult.decision && (
                  <span className="font-mono text-slate-600 font-semibold">
                    Decision: {probeResult.decision.status} ({probeResult.decision.selectedModelId})
                  </span>
                )}
              </div>
              {probeResult.response && (
                <span className="font-mono text-slate-500">
                  Latency: {probeResult.response.latencyMs}ms | Cost: ${probeResult.response.usage?.estimatedCostUsd?.toFixed(4) || '0.0000'}
                </span>
              )}
            </div>

            <div className="font-mono text-slate-700 bg-white p-3 rounded-md border border-slate-200 whitespace-pre-wrap leading-relaxed">
              {probeResult.response?.text || probeResult.error || JSON.stringify(probeResult, null, 2)}
            </div>
          </div>
        )}
      </div>

      {/* Auditable Decision History Log */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
              Recent Model Routing Decisions ({decisions.length})
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">Deterministic audit trail</span>
        </div>

        {decisions.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-xs font-mono">
            No routing decisions recorded in current session.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 font-mono text-xs">
            {decisions.map((dec) => {
              const isFallback = dec.status === 'ROUTE_FALLBACK';
              const isFailed = dec.status === 'ROUTE_FAILED';
              return (
                <div key={dec.id} className="py-3 flex flex-col md:flex-row md:items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                          isFallback
                            ? 'bg-amber-100 text-amber-800'
                            : isFailed
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {dec.status}
                      </span>
                      <span className="font-bold text-slate-900">{dec.selectedModelId || 'None'}</span>
                      <span className="text-slate-400 text-[11px]">via {dec.selectedProvider}</span>
                      <span className="text-slate-300">•</span>
                      <span className="text-slate-500 text-[11px]">
                        {new Date(dec.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-slate-600 text-[11px] mt-1 font-sans">
                      {dec.reasoning}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-slate-500 text-[11px] shrink-0">
                    <span>Latency: <strong>{dec.totalLatencyMs}ms</strong></span>
                    <span>Attempts: <strong>{dec.attemptedModels?.length || 1}</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
