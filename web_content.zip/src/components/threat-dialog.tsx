import { ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useShield } from "@/lib/store";
import { verdictLabel } from "@/lib/reputation";

export function ThreatDialog() {
  const pending = useShield((s) => s.pending);
  const resolve = useShield((s) => s.resolvePending);

  if (!pending) return null;
  const { inspection, app } = pending;
  const tone =
    inspection.verdict === "malicious"
      ? "danger"
      : inspection.verdict === "suspicious"
        ? "warn"
        : "muted";

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-4 sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-labelledby="threat-title"
    >
      <div className="w-full max-w-md rounded-xl border border-border bg-bg-elevated p-5 shadow-[0_24px_80px_rgba(0,0,0,0.45)]">
        <div className="flex items-start gap-3">
          <span className="flex size-10 items-center justify-center rounded-md bg-danger/15 text-danger">
            <ShieldAlert className="size-5" />
          </span>
          <div>
            <p className="text-xs uppercase tracking-wider text-muted">
              Nachfrage
            </p>
            <h2 id="threat-title" className="mt-1 text-lg font-medium">
              Dieser Aufruf ist nicht klar vertrauenswürdig
            </h2>
          </div>
        </div>

        <dl className="mt-5 space-y-3 text-sm">
          <div className="flex justify-between gap-4">
            <dt className="text-muted">Ziel</dt>
            <dd className="font-mono text-xs text-fg">{inspection.displayHost}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-muted">App</dt>
            <dd>{app}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-muted">Bewertung</dt>
            <dd>
              <Badge tone={tone}>{verdictLabel(inspection.verdict)}</Badge>
            </dd>
          </div>
        </dl>

        <ul className="mt-5 space-y-2">
          {inspection.findings.map((f) => (
            <li
              key={f.code}
              className="rounded-md border border-border bg-surface px-3 py-2"
            >
              <p className="text-sm font-medium">{f.title}</p>
              <p className="mt-0.5 text-xs leading-relaxed text-muted">
                {f.detail}
              </p>
            </li>
          ))}
        </ul>

        <div className="mt-6 flex flex-col gap-2">
          <Button variant="danger" onClick={() => resolve("blocked")}>
            Blockieren
          </Button>
          <Button variant="secondary" onClick={() => resolve("allowed")}>
            Nur diesmal erlauben
          </Button>
          <Button variant="ghost" onClick={() => resolve("trusted")}>
            Immer vertrauen
          </Button>
        </div>
      </div>
    </div>
  );
}
