import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, Trophy, Users, ShieldAlert, Key, Copy, Check, 
  AlertCircle, CheckCircle2, ArrowRight, Wallet, Info, 
  Clock, ShieldCheck, FileText, RefreshCw
} from 'lucide-react';

export const TournamentModal: React.FC = () => {
  const { 
    selectedTournament, 
    setSelectedTournament, 
    user, 
    activeAdminUser,
    registerForTournament, 
    setCurrentTab,
    getSecureRoomCredentials,
    language 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'details' | 'register' | 'slots' | 'room'>('details');
  const [ign, setIgn] = useState(user.ffIgn || '');
  const [uid, setUid] = useState(user.ffUid || '');
  const [teamName, setTeamName] = useState('');
  const [teammate1Ign, setTeammate1Ign] = useState('');
  const [teammate1Uid, setTeammate1Uid] = useState('');
  const [teammate2Ign, setTeammate2Ign] = useState('');
  const [teammate2Uid, setTeammate2Uid] = useState('');
  const [teammate3Ign, setTeammate3Ign] = useState('');
  const [teammate3Uid, setTeammate3Uid] = useState('');
  
  const [submitting, setSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copiedRoom, setCopiedRoom] = useState(false);
  const [copiedPass, setCopiedPass] = useState(false);

  if (!selectedTournament) return null;

  const isRegistered = selectedTournament.registeredSlots.some(s => s.userId === user.id);
  const userSlot = selectedTournament.registeredSlots.find(s => s.userId === user.id);
  const hasEnoughFunds = user.walletBalance >= selectedTournament.entryFee;
  const isSquad = selectedTournament.category === 'squad';
  const isDuo = selectedTournament.category === 'duo';

  // Secure room credential authorization check (Super Admin only in admin preview)
  const isPrivilegedAdmin = Boolean(activeAdminUser && activeAdminUser.role === 'super_admin');
  const roomCreds = getSecureRoomCredentials(selectedTournament.id);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ign.trim() || !uid.trim()) {
      setStatusMessage({ type: 'error', text: 'Free Fire IGN and UID are required!' });
      return;
    }

    setSubmitting(true);
    setStatusMessage(null);

    const teammates = [];
    if (isDuo || isSquad) {
      if (teammate1Ign) teammates.push({ ign: teammate1Ign, uid: teammate1Uid || '11111111' });
    }
    if (isSquad) {
      if (teammate2Ign) teammates.push({ ign: teammate2Ign, uid: teammate2Uid || '22222222' });
      if (teammate3Ign) teammates.push({ ign: teammate3Ign, uid: teammate3Uid || '33333333' });
    }

    const res = registerForTournament(selectedTournament.id, {
      ign: ign.trim(),
      uid: uid.trim(),
      teamName: teamName.trim() || undefined,
      teammates: teammates.length > 0 ? teammates : undefined
    });

    setSubmitting(false);

    if (res.success) {
      setStatusMessage({ type: 'success', text: res.message });
      setActiveTab('room');
    } else {
      setStatusMessage({ type: 'error', text: res.message });
    }
  };

  const copyRoomId = () => {
    if (roomCreds.roomId) {
      navigator.clipboard.writeText(roomCreds.roomId);
      setCopiedRoom(true);
      setTimeout(() => setCopiedRoom(false), 2000);
    }
  };

  const copyPassword = () => {
    if (roomCreds.roomPassword) {
      navigator.clipboard.writeText(roomCreds.roomPassword);
      setCopiedPass(true);
      setTimeout(() => setCopiedPass(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-[#0c1017] border border-red-950/60 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden text-slate-100">
        {/* Header Bar */}
        <div className="relative h-28 sm:h-36 w-full overflow-hidden bg-slate-900 shrink-0">
          <img 
            src={selectedTournament.bannerImage} 
            alt={selectedTournament.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0c1017] via-[#0c1017]/60 to-transparent" />
          
          <button
            onClick={() => setSelectedTournament(null)}
            className="absolute top-3 right-3 p-1.5 rounded-lg bg-black/60 text-slate-300 hover:text-white transition-colors border border-white/10"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-3 left-4 right-4">
            <div className="flex items-center gap-2 text-xs text-red-400 font-bold uppercase tracking-wider mb-1 flex-wrap">
              <span>{selectedTournament.matchType}</span>
              <span>·</span>
              <span>{selectedTournament.map}</span>
              <span>·</span>
              <span className="capitalize">{selectedTournament.category}</span>
              <span>·</span>
              <span className={`px-2 py-0.5 rounded text-[10px] border ${
                selectedTournament.prizePoolStatus === 'guaranteed'
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                  : selectedTournament.prizePoolStatus === 'funded'
                  ? 'bg-blue-500/20 border-blue-500/40 text-blue-400'
                  : 'bg-amber-500/20 border-amber-500/40 text-amber-400'
              }`}>
                {selectedTournament.prizePoolStatus.toUpperCase()} PRIZE
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-display font-extrabold text-white line-clamp-1">
              {selectedTournament.title}
            </h2>
          </div>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-[#090b10] px-3 gap-1 shrink-0 overflow-x-auto">
          <button
            onClick={() => setActiveTab('details')}
            className={`px-3 py-2.5 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 ${
              activeTab === 'details' ? 'border-red-500 text-white' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {language === 'bn' ? 'বিস্তারিত ও প্রাইজ' : 'Prize & Rules'}
          </button>

          <button
            onClick={() => setActiveTab('slots')}
            className={`px-3 py-2.5 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 ${
              activeTab === 'slots' ? 'border-red-500 text-white' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {language === 'bn' ? 'স্লট তালিকা (' + selectedTournament.bookedSlots + '/' + selectedTournament.totalSlots + ')' : `Slots (${selectedTournament.bookedSlots}/${selectedTournament.totalSlots})`}
          </button>

          <button
            onClick={() => setActiveTab('room')}
            className={`px-3 py-2.5 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'room' ? 'border-red-500 text-white' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Key className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'bn' ? 'কাস্টম রুম আইডি' : 'Room ID & Pass'}</span>
          </button>

          {!isRegistered && (
            <button
              onClick={() => setActiveTab('register')}
              className={`px-3 py-2.5 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 ${
                activeTab === 'register' ? 'border-red-500 text-white' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {language === 'bn' ? 'রেজিস্ট্রেশন করুন' : 'Join Match'}
            </button>
          )}
        </div>

        {/* Scrollable Modal Content */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">
          {/* Status Message */}
          {statusMessage && (
            <div className={`p-3 rounded-xl text-xs flex items-center gap-2 border ${
              statusMessage.type === 'success' 
                ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300' 
                : 'bg-red-950/40 border-red-500/50 text-red-300'
            }`}>
              {statusMessage.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
              <span>{statusMessage.text}</span>
            </div>
          )}

          {/* TAB 1: DETAILS & CUSTOMIZABLE PRIZE BREAKDOWN */}
          {activeTab === 'details' && (
            <div className="space-y-4">
              {/* Prize Pool Highlights */}
              <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-400">
                    {language === 'bn' ? 'পুরস্কার বণ্টন কাঠামো:' : 'Prize Pool Breakdown:'}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${
                    selectedTournament.prizePoolStatus === 'guaranteed'
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      : selectedTournament.prizePoolStatus === 'funded'
                      ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                      : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                  }`}>
                    {selectedTournament.prizePoolStatus} Status
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                  <div className="bg-[#090b10] border border-amber-500/30 p-2.5 rounded-xl">
                    <span className="text-[10px] text-amber-400 font-bold block">🥇 1st Place</span>
                    <span className="text-base font-bold font-mono text-white tabular-nums">৳{selectedTournament.firstPrize}</span>
                  </div>
                  <div className="bg-[#090b10] border border-slate-700 p-2.5 rounded-xl">
                    <span className="text-[10px] text-slate-300 font-bold block">🥈 2nd Place</span>
                    <span className="text-base font-bold font-mono text-white tabular-nums">৳{selectedTournament.secondPrize}</span>
                  </div>
                  <div className="bg-[#090b10] border border-amber-900/40 p-2.5 rounded-xl">
                    <span className="text-[10px] text-amber-600 font-bold block">🥉 3rd Place</span>
                    <span className="text-base font-bold font-mono text-white tabular-nums">৳{selectedTournament.thirdPrize}</span>
                  </div>
                  <div className="bg-[#090b10] border border-red-600/30 p-2.5 rounded-xl">
                    <span className="text-[10px] text-red-400 font-bold block">🎯 Per Kill</span>
                    <span className="text-base font-bold font-mono text-red-400 tabular-nums">৳{selectedTournament.perKill}</span>
                  </div>
                </div>

                {selectedTournament.prizeDistributionRules && (
                  <div className="mt-3 p-2.5 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-slate-300">
                    <strong className="text-amber-400 block mb-0.5">Distribution Details:</strong>
                    {selectedTournament.prizeDistributionRules}
                  </div>
                )}
              </div>

              {/* Tournament Specs */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-[#121620] p-3 rounded-xl border border-slate-800/80">
                  <span className="text-slate-400 block mb-0.5">Match Schedule</span>
                  <span className="font-semibold text-white font-mono">
                    {new Date(selectedTournament.scheduleTime).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
                  </span>
                </div>
                <div className="bg-[#121620] p-3 rounded-xl border border-slate-800/80">
                  <span className="text-slate-400 block mb-0.5">Registration Deadline</span>
                  <span className="font-semibold text-amber-400 font-mono">
                    {selectedTournament.registrationDeadline 
                      ? new Date(selectedTournament.registrationDeadline).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })
                      : 'Until Slots Full'}
                  </span>
                </div>
                <div className="bg-[#121620] p-3 rounded-xl border border-slate-800/80">
                  <span className="text-slate-400 block mb-0.5">Entry Fee</span>
                  <span className="font-bold text-red-400 font-mono text-sm">৳{selectedTournament.entryFee} BDT</span>
                </div>
                <div className="bg-[#121620] p-3 rounded-xl border border-slate-800/80">
                  <span className="text-slate-400 block mb-0.5">Slots Capacity</span>
                  <span className="font-semibold text-emerald-400 font-mono">
                    {selectedTournament.bookedSlots} / {selectedTournament.totalSlots} Slots
                  </span>
                </div>
              </div>

              {/* Refund Rules */}
              {selectedTournament.refundRules && (
                <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-300 mb-1.5">
                    <FileText className="w-4 h-4 text-blue-400" />
                    <span>Refund &amp; Cancellation Policy</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {selectedTournament.refundRules}
                  </p>
                </div>
              )}

              {/* Official Rules */}
              <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-300 mb-2">
                  <ShieldAlert className="w-4 h-4 text-red-400" />
                  <span>{language === 'bn' ? 'অফিশিয়াল টুর্নামেন্ট নিয়মাবলী:' : 'Official Tournament Rules:'}</span>
                </div>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {selectedTournament.rules.map((rule, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-red-500 font-bold">•</span>
                      <span>{rule}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Bottom CTA on Details tab */}
              {!isRegistered ? (
                <button
                  onClick={() => setActiveTab('register')}
                  className="w-full py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-950/40"
                >
                  <span>{language === 'bn' ? 'এখনই রেজিস্ট্রেশন করুন' : 'Proceed to Register'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <div className="p-3 bg-emerald-950/30 border border-emerald-500/30 rounded-xl flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 text-emerald-300">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>You are registered on Slot #{userSlot?.slotNumber}</span>
                  </div>
                  <button
                    onClick={() => setActiveTab('room')}
                    className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg"
                  >
                    View Room ID
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: ROOM CREDENTIALS (Strictly gated by 4 clear states & participant check) */}
          {activeTab === 'room' && (
            <div className="space-y-4">
              <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5">
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <Key className="w-5 h-5 text-amber-400" />
                    <h4 className="text-sm font-bold text-white font-display">
                      {language === 'bn' ? 'ফ্রি ফায়ার কাস্টম রুম ক্রিডেনশিয়াল' : 'Free Fire Custom Room Credentials'}
                    </h4>
                  </div>

                  {/* Room Status Badge */}
                  <div className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border ${
                    selectedTournament.roomStatus === 'available'
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                      : selectedTournament.roomStatus === 'scheduled'
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                      : selectedTournament.roomStatus === 'completed'
                      ? 'bg-slate-700 border-slate-600 text-slate-300'
                      : 'bg-red-500/20 border-red-500 text-red-300'
                  }`}>
                    {selectedTournament.roomStatus === 'available' ? 'Room details available' :
                     selectedTournament.roomStatus === 'scheduled' ? 'Waiting for room details' :
                     selectedTournament.roomStatus === 'completed' ? 'Match completed' :
                     'Room details not added'}
                  </div>
                </div>

                {/* State 1: User is NOT registered */}
                {!isRegistered && !isPrivilegedAdmin ? (
                  <div className="text-center py-8">
                    <div className="w-12 h-12 rounded-full bg-red-600/10 border border-red-600/30 flex items-center justify-center mx-auto mb-3 text-red-400">
                      <ShieldAlert className="w-6 h-6" />
                    </div>
                    <h4 className="text-sm font-bold text-white mb-1">Access Restricted</h4>
                    <p className="text-xs text-slate-400 mb-4 max-w-sm mx-auto">
                      Unregistered users cannot retrieve private room credentials. Register for this tournament to gain access.
                    </p>
                    <button
                      onClick={() => setActiveTab('register')}
                      className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl text-xs inline-flex items-center gap-1.5"
                    >
                      <span>Join Tournament (৳{selectedTournament.entryFee})</span>
                    </button>
                  </div>
                ) : /* State 2: Room details not added */
                selectedTournament.roomStatus === 'not_added' || !selectedTournament.roomId ? (
                  <div className="text-center py-8">
                    <div className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto mb-3 text-slate-400">
                      <Clock className="w-6 h-6" />
                    </div>
                    <h4 className="text-sm font-bold text-white mb-1">Room Details Not Added</h4>
                    <p className="text-xs text-slate-400 max-w-sm mx-auto">
                      The tournament administrator has not yet generated or added the custom room details. They will be manually saved and scheduled prior to match start.
                    </p>
                  </div>
                ) : /* State 3: Waiting for room details */
                selectedTournament.roomStatus === 'scheduled' && !isPrivilegedAdmin ? (
                  <div className="text-center py-8">
                    <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto mb-3 text-amber-400">
                      <Clock className="w-6 h-6" />
                    </div>
                    <h4 className="text-sm font-bold text-white mb-1">Waiting for Room Details</h4>
                    <p className="text-xs text-slate-400 max-w-sm mx-auto">
                      Room credentials are saved and scheduled to unlock automatically 15 minutes before the match start time. You will receive an instant notification!
                    </p>
                    {selectedTournament.roomReleaseTime && (
                      <div className="mt-3 inline-block px-3 py-1 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-amber-400">
                        Release Time: {new Date(selectedTournament.roomReleaseTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    )}
                  </div>
                ) : /* State 4: Match completed */
                selectedTournament.roomStatus === 'completed' || selectedTournament.status === 'completed' ? (
                  <div className="text-center py-8">
                    <div className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto mb-3 text-emerald-400">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <h4 className="text-sm font-bold text-white mb-1">Match Completed</h4>
                    <p className="text-xs text-slate-400 max-w-sm mx-auto">
                      This tournament has ended. Check the Results tab to see full scoreboard standings and prize payouts.
                    </p>
                  </div>
                ) : (
                  /* State 5: Room details available */
                  <div className="space-y-3">
                    <div className="bg-[#080a0f] border border-amber-500/40 rounded-xl p-3">
                      <div className="text-[11px] text-slate-400 mb-1">Free Fire Custom Room ID:</div>
                      <div className="flex items-center justify-between">
                        <span className="text-xl font-bold font-mono text-white tracking-widest">
                          {roomCreds.roomId}
                        </span>
                        <button
                          onClick={copyRoomId}
                          className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 rounded-lg border border-slate-700"
                        >
                          {copiedRoom ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedRoom ? 'Copied' : 'Copy ID'}</span>
                        </button>
                      </div>
                    </div>

                    <div className="bg-[#080a0f] border border-amber-500/40 rounded-xl p-3">
                      <div className="text-[11px] text-slate-400 mb-1">Free Fire Room Password:</div>
                      <div className="flex items-center justify-between">
                        <span className="text-xl font-bold font-mono text-white tracking-widest">
                          {roomCreds.roomPassword}
                        </span>
                        <button
                          onClick={copyPassword}
                          className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 rounded-lg border border-slate-700"
                        >
                          {copiedPass ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedPass ? 'Copied' : 'Copy Password'}</span>
                        </button>
                      </div>
                    </div>

                    <div className="p-3 bg-blue-950/30 border border-blue-800/40 rounded-xl text-xs text-blue-200 flex items-start gap-2">
                      <Info className="w-4 h-4 shrink-0 mt-0.5 text-blue-400" />
                      <div>
                        <strong>Instructions:</strong> Open Free Fire &gt; Click Mode selector &gt; Select 'Custom' &gt; Search Room ID &gt; Enter Password &gt; Take designated Slot #{userSlot?.slotNumber || '1'}.
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: SLOTS GRID */}
          {activeTab === 'slots' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Booked: {selectedTournament.bookedSlots} / {selectedTournament.totalSlots} Slots</span>
                <span className="text-emerald-400 font-semibold">{selectedTournament.totalSlots - selectedTournament.bookedSlots} available</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-72 overflow-y-auto pr-1">
                {Array.from({ length: selectedTournament.totalSlots }).map((_, i) => {
                  const slotNum = i + 1;
                  const registered = selectedTournament.registeredSlots.find(s => s.slotNumber === slotNum);
                  const isMine = registered?.userId === user.id;

                  return (
                    <div
                      key={slotNum}
                      className={`p-2.5 rounded-xl border text-xs flex flex-col justify-between ${
                        isMine
                          ? 'bg-emerald-950/50 border-emerald-500 text-emerald-200'
                          : registered
                          ? 'bg-slate-900/60 border-slate-800 text-slate-400'
                          : 'bg-[#121620] border-slate-800/80 text-slate-500'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-mono font-bold text-slate-300">Slot #{slotNum}</span>
                        {isMine && <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-bold">YOU</span>}
                      </div>
                      <div className="truncate font-semibold text-slate-200 text-[11px]">
                        {registered ? (registered.teamName || registered.ffIgn) : 'Empty Slot'}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: REGISTRATION FORM */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="p-3 bg-[#121620] border border-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-400 block">Available Balance:</span>
                  <span className="text-base font-bold font-mono text-emerald-400">৳{user.walletBalance} BDT</span>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-slate-400 block">Entry Fee:</span>
                  <span className="text-base font-bold font-mono text-red-400">৳{selectedTournament.entryFee} BDT</span>
                </div>
              </div>

              {!hasEnoughFunds && (
                <div className="p-3 bg-red-950/40 border border-red-500/50 rounded-xl text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2 text-red-300">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>Insufficient funds! Please add money to register.</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedTournament(null);
                      setCurrentTab('wallet');
                    }}
                    className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-lg shrink-0"
                  >
                    Add Money
                  </button>
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Free Fire In-Game Name (IGN) *
                  </label>
                  <input
                    type="text"
                    required
                    value={ign}
                    onChange={e => setIgn(e.target.value)}
                    placeholder="e.g. VIPER๛SHADOW"
                    className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Free Fire Player UID *
                  </label>
                  <input
                    type="text"
                    required
                    value={uid}
                    onChange={e => setUid(e.target.value)}
                    placeholder="e.g. 248910283"
                    className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500 font-mono"
                  />
                </div>

                {(isDuo || isSquad) && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Team Name (Optional)
                    </label>
                    <input
                      type="text"
                      value={teamName}
                      onChange={e => setTeamName(e.target.value)}
                      placeholder="e.g. DELTA FORCE"
                      className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
                    />
                  </div>
                )}

                {(isDuo || isSquad) && (
                  <div className="p-3 bg-[#121620] border border-slate-800 rounded-xl space-y-2">
                    <span className="text-xs font-semibold text-slate-300 block">Teammate 1 Details</span>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="Teammate IGN"
                        value={teammate1Ign}
                        onChange={e => setTeammate1Ign(e.target.value)}
                        className="px-2.5 py-1.5 bg-[#090b10] border border-slate-800 rounded-lg text-xs text-white focus:border-red-500"
                      />
                      <input
                        type="text"
                        placeholder="Teammate UID"
                        value={teammate1Uid}
                        onChange={e => setTeammate1Uid(e.target.value)}
                        className="px-2.5 py-1.5 bg-[#090b10] border border-slate-800 rounded-lg text-xs text-white focus:border-red-500 font-mono"
                      />
                    </div>
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={submitting || !hasEnoughFunds}
                className="w-full py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-950/50"
              >
                <span>
                  {submitting 
                    ? 'Processing Entry...' 
                    : `Pay ৳${selectedTournament.entryFee} & Confirm Slot`}
                </span>
                <CheckCircle2 className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
