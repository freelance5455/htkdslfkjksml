import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeftRight, ChevronDown, Coins, LoaderCircle, ShoppingCart, Store, Zap } from "lucide-react";
import { toast } from "sonner";
import { ImageDropzone, MAX_FILES } from "@/components/image-dropzone";
import { ResultPanel } from "@/components/result-panel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { analyzeAccount } from "@/lib/analyze";
import { compressImage } from "@/lib/compress-image";
import { appraisalToText } from "@/lib/copy-result";
import type { Appraisal, PlatformId, TradeIntent } from "@/lib/types";
import { cn } from "@/lib/utils";

const ERRORS: Record<string, string> = {
  unavailable: "AI ဝန်ဆောင်မှု ယာယီမရရှိပါ။ ခဏနေမှ ပြန်ကြိုးစားပါ။",
  "need-input": "စခရင်ရှော့ပုံ (သို့) Strength ထည့်သွင်းပေးပါ။",
  empty: "AI ထံမှ အချက်အလက် ရယူ၍ မရပါ။",
  busy: "ဆာဗာအလုပ်များနေပါသည်။ ခဏနေမှ ပြန်ကြိုးစားပါ။",
  timeout: "အချိန်ပြည့်သွားပါသည်။ ပုံအရေအတွက် လျှော့ပြီး ပြန်စမ်းပါ။",
  failed: "တွက်ချက်၍ မရပါ။ အင်တာနက်ချိတ်ဆက်မှု စစ်ဆေးပါ။",
  "too-large": "ပုံအရွယ်အစား ကြီးလွန်းပါသည်။",
  "image-only": "ဓာတ်ပုံဖိုင်များသာ တင်ပေးပါ။",
};

const LOADING_STEPS = [
  "ပုံများ ဖတ်နေသည်...",
  "ကတ်များ ခွဲနေသည်...",
  "ပေါက်စျေး ချိန်နေသည်...",
];

type StoredResult = {
  appraisal: Appraisal;
  intent: TradeIntent;
  platform: PlatformId;
  timestamp: string;
};

const STORAGE_KEY = "bruno_last_appraisal";

export function Calculator() {
  const [intent, setIntent] = useState<TradeIntent>("buy");
  const [platform, setPlatform] = useState<PlatformId>("mobile");
  const [strength, setStrength] = useState("");
  const [coins, setCoins] = useState("");
  const [hasLinkError, setHasLinkError] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [result, setResult] = useState<StoredResult | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as StoredResult;
      if (parsed?.appraisal?.finalMin != null) setResult(parsed);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    const urls = files.map((f) => URL.createObjectURL(f));
    setPreviews(urls);
    return () => urls.forEach((u) => URL.revokeObjectURL(u));
  }, [files]);

  useEffect(() => {
    if (!loading) return;
    setLoadingStep(0);
    const id = window.setInterval(() => {
      setLoadingStep((s) => (s + 1) % LOADING_STEPS.length);
    }, 2200);
    return () => window.clearInterval(id);
  }, [loading]);

  const canSubmit = useMemo(
    () => files.length > 0 || strength.trim().length > 0,
    [files.length, strength],
  );

  function addFiles(incoming: File[]) {
    setFiles((prev) => {
      const room = MAX_FILES - prev.length;
      if (room <= 0) {
        toast.error(`အများဆုံး ${MAX_FILES} ပုံသာ တင်ခွင့်ရှိပါသည်။`);
        return prev;
      }
      if (incoming.length > room) {
        toast.error(`အများဆုံး ${MAX_FILES} ပုံသာဖြစ်၍ ပထမ ${room} ပုံကိုသာ ထည့်ထားသည်။`);
      }
      return prev.concat(incoming.slice(0, room));
    });
  }

  async function onAnalyze() {
    if (!canSubmit) {
      toast.error(ERRORS["need-input"]);
      return;
    }
    setLoading(true);
    try {
      const images = [];
      for (const file of files) {
        images.push(await compressImage(file));
      }
      const response = await analyzeAccount({
        data: {
          intent,
          platform,
          strength: strength.trim(),
          coins: coins.trim(),
          hasLinkError,
          images,
        },
      });
      if (!response.ok) {
        toast.error(ERRORS[response.error] ?? ERRORS.failed);
        return;
      }
      const next: StoredResult = {
        appraisal: response.appraisal,
        intent,
        platform,
        timestamp: new Date().toLocaleTimeString("my-MM", {
          hour: "2-digit",
          minute: "2-digit",
        }),
      };
      setResult(next);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* quota */
      }
      window.setTimeout(() => {
        resultRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }, 50);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      toast.error(ERRORS[msg] ?? ERRORS.failed);
    } finally {
      setLoading(false);
    }
  }

  async function copyResult() {
    if (!result) return;
    const text = appraisalToText(result.appraisal, result.intent, result.platform);
    try {
      await navigator.clipboard.writeText(text);
      toast.success("ရလဒ်အား ကူးယူပြီးပါပြီ");
      return;
    } catch {
      /* fallback below */
    }
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.left = "-9999px";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      if (ok) toast.success("ရလဒ်အား ကူးယူပြီးပါပြီ");
      else toast.error("Copy လုပ်၍ မရပါ");
    } catch {
      toast.error("Copy လုပ်၍ မရပါ");
    }
  }

  return (
    <>
      <form
        className="mb-6 rounded-[var(--radius-2xl)] bg-surface p-5 shadow-[var(--shadow-border)]"
        onSubmit={(e) => {
          e.preventDefault();
          void onAnalyze();
        }}
      >
        <div className="mb-5">
          <Label>
            <ArrowLeftRight className="size-3.5 text-accent" aria-hidden />
            ရည်ရွယ်ချက်
          </Label>
          <div className="grid grid-cols-2 gap-1 rounded-[var(--radius-lg)] bg-bg p-1 shadow-[var(--shadow-border)]">
            <button
              type="button"
              onClick={() => setIntent("buy")}
              className={cn(
                "flex h-11 items-center justify-center gap-1.5 rounded-[var(--radius-md)] text-sm font-bold transition-[background-color,color] duration-150",
                intent === "buy" ? "bg-accent/15 text-accent" : "text-muted hover:text-fg",
              )}
            >
              <ShoppingCart className="size-4" aria-hidden />
              ဝယ်ယူမည်
            </button>
            <button
              type="button"
              onClick={() => setIntent("sell")}
              className={cn(
                "flex h-11 items-center justify-center gap-1.5 rounded-[var(--radius-md)] text-sm font-bold transition-[background-color,color] duration-150",
                intent === "sell" ? "bg-accent/15 text-accent" : "text-muted hover:text-fg",
              )}
            >
              <Store className="size-4" aria-hidden />
              ရောင်းချမည်
            </button>
          </div>
        </div>

        <div className="mb-5">
          <Label htmlFor="platform">Platform</Label>
          <div className="relative">
            <select
              id="platform"
              value={platform}
              onChange={(e) => setPlatform(e.target.value as PlatformId)}
              className="h-11 w-full appearance-none rounded-[var(--radius-md)] bg-bg px-3.5 pr-10 text-sm text-fg shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <option value="mobile">Mobile (Android / iOS)</option>
              <option value="pc">PC (Steam)</option>
              <option value="console">Console (PlayStation / Xbox)</option>
            </select>
            <ChevronDown
              className="pointer-events-none absolute top-1/2 right-3.5 size-4 -translate-y-1/2 text-muted"
              aria-hidden
            />
          </div>
        </div>

        <div className="mb-5">
          <ImageDropzone
            files={files}
            previews={previews}
            onAdd={addFiles}
            onRemove={(i) => setFiles((prev) => prev.filter((_, idx) => idx !== i))}
            onClear={() => setFiles([])}
          />
        </div>

        <div className="mb-5 grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="strength">
              <Zap className="size-3.5 text-accent" aria-hidden />
              Strength
            </Label>
            <Input
              id="strength"
              type="number"
              inputMode="numeric"
              min={0}
              placeholder="3180"
              value={strength}
              onChange={(e) => setStrength(e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="coins">
              <Coins className="size-3.5 text-accent" aria-hidden />
              eFo Coins
            </Label>
            <Input
              id="coins"
              type="number"
              inputMode="numeric"
              min={0}
              placeholder="500"
              value={coins}
              onChange={(e) => setCoins(e.target.value)}
            />
          </div>
        </div>

        <label
          className={cn(
            "mb-6 flex cursor-pointer items-start gap-3 rounded-[var(--radius-lg)] px-3.5 py-3 transition-[background-color,box-shadow] duration-150",
            hasLinkError
              ? "bg-danger/15 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-danger)_55%,transparent)]"
              : "bg-danger/10 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-danger)_25%,transparent)]",
          )}
        >
          <input
            type="checkbox"
            className="mt-0.5 size-5 accent-[var(--color-danger)]"
            checked={hasLinkError}
            onChange={(e) => setHasLinkError(e.target.checked)}
          />
          <span>
            <span className="flex items-center gap-1.5 text-sm font-bold text-danger">
              Google Link Error (Dead Link) ပါဝင်သည်
            </span>
            <span className="mt-0.5 block text-xs text-muted">
              ဂျီးလင့်ပါပါက စျေးကွက်ပေါက်စျေး ၅၀% မှ ၈၀% အထိ လျော့ကျသည်။
            </span>
          </span>
        </label>

        <Button type="submit" size="lg" disabled={loading}>
          {loading ? (
            <>
              <LoaderCircle className="size-5 animate-spin" aria-hidden />
              <span>{LOADING_STEPS[loadingStep]}</span>
            </>
          ) : (
            "ပေါက်စျေး စစ်ဆေးတွက်ချက်မည်"
          )}
        </Button>
      </form>

      {result ? (
        <div ref={resultRef}>
          <ResultPanel
            appraisal={result.appraisal}
            intent={result.intent}
            timestamp={`${result.timestamp} တွင် တွက်ချက်သည်`}
            onCopy={() => void copyResult()}
            onClose={() => setResult(null)}
          />
        </div>
      ) : (
        <aside className="hidden rounded-[var(--radius-2xl)] bg-surface p-6 text-sm text-muted shadow-[var(--shadow-border)] lg:block">
          <p className="font-display text-lg font-semibold tracking-tight text-fg">
            ရလဒ် ဤနေရာတွင် ပေါ်မည်
          </p>
          <p className="mt-2 leading-relaxed">
            Squad စခရင်ရှော့ (သို့) Strength ထည့်ပြီး တွက်ချက်ပါ။ AI က Free vs Paid
            ကတ်များကို ခွဲခြမ်းပြီး မြန်မာစျေးကွက်ပေါက်စျေးကို ပြန်ပေးပါမည်။
          </p>
        </aside>
      )}
    </>
  );
}
