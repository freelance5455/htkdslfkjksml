import React, { useState, useMemo, useEffect } from 'react';
import {
  X, CheckCircle, ShieldCheck, Banknote,
  ArrowRight, Tag, AlertCircle, Loader2, Truck, Check,
  MapPin, Clock, Lock
} from 'lucide-react';
import { CartItem } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { getProductById } from '../../data/products';
import { useLanguage } from '../../context/LanguageContext';
import {
  verifyIndianPinCode,
  verifyLocationMatchesPin,
  IndiaPostVerificationResult,
} from '../../utils/locationService';

const GoogleLogo: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg className={`${className} flex-shrink-0`} viewBox="0 0 24 24" aria-hidden="true">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
  </svg>
);

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onOrderSuccess: () => void;
  onViewOrders?: () => void;
  onTrackOrder?: (order: any) => void;
  onRequireLogin?: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  onOrderSuccess,
  onViewOrders,
  onTrackOrder,
  onRequireLogin,
}) => {
  const { user, addresses, createOrder } = useAuth();
  const { t } = useLanguage();

  const [selectedAddressId, setSelectedAddressId] = useState<string>(
    addresses.find((a) => a.isDefault)?.id || (addresses[0]?.id ?? 'new')
  );
  // Dynamic initialization avoiding hardcoded defaults
  const getInitialAddress = () => {
    try {
      const saved = localStorage.getItem('ntix_saved_address');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          fullName: parsed.name || user?.name || '',
          phone: parsed.phone || user?.phone || '',
          street: parsed.street || '',
          city: parsed.city || localStorage.getItem('ntix_delivery_city') || '',
          state: parsed.state || '',
          pincode: parsed.pincode || localStorage.getItem('ntix_delivery_pin') || '',
        };
      }
    } catch {}
    return {
      fullName: user?.name || '',
      phone: user?.phone || '',
      street: '',
      city: localStorage.getItem('ntix_delivery_city') || '',
      state: '',
      pincode: localStorage.getItem('ntix_delivery_pin') || '',
    };
  };

  const initialAddr = getInitialAddress();
  const [fullName, setFullName] = useState(initialAddr.fullName);
  const [phone, setPhone] = useState(initialAddr.phone);
  const [email, setEmail] = useState(user?.email || '');
  const [street, setStreet] = useState(initialAddr.street);
  const [city, setCity] = useState(initialAddr.city);
  const [state, setState] = useState(initialAddr.state);
  const [pincode, setPincode] = useState(initialAddr.pincode);
  const [agreedToTerms, setAgreedToTerms] = useState(true);

  // PIN code verification states
  const [pinVerification, setPinVerification] = useState<IndiaPostVerificationResult | null>(null);
  const [isVerifyingPin, setIsVerifyingPin] = useState(false);

  useEffect(() => {
    if (user) {
      if (user.name && !fullName) setFullName(user.name);
      if (user.email) setEmail(user.email);
      if (user.phone && !phone) setPhone(user.phone);
    }
  }, [user]);

  // Sync address when opening if no addresses exist
  useEffect(() => {
    if (isOpen && (addresses.length === 0 || selectedAddressId === 'new')) {
      const addr = getInitialAddress();
      if (!street && addr.street) setStreet(addr.street);
      if (!city && addr.city) setCity(addr.city);
      if (!pincode && addr.pincode) setPincode(addr.pincode);
      if (!fullName && addr.fullName) setFullName(addr.fullName);
      if (!phone && addr.phone) setPhone(addr.phone);

      if (addr.pincode && addr.pincode.length === 6) {
        verifyIndianPinCode(addr.pincode).then(setPinVerification);
      }
    }
  }, [isOpen, selectedAddressId, addresses.length]);

  const handlePinChange = async (val: string) => {
    const clean = val.replace(/\D/g, '').slice(0, 6);
    setPincode(clean);
    setCheckoutError(null);

    if (clean.length === 6) {
      setIsVerifyingPin(true);
      try {
        const res = await verifyIndianPinCode(clean);
        setPinVerification(res);
        if (res.isValid) {
          if (!city.trim() && res.district) setCity(res.district);
          if (!state.trim() && res.state) setState(res.state);
        }
      } finally {
        setIsVerifyingPin(false);
      }
    } else {
      setPinVerification(null);
    }
  };

  const [couponCode, setCouponCode] = useState('');
  const [couponDiscount, setCouponDiscount] = useState<number>(0);
  const [couponMessage, setCouponMessage] = useState<string | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<any>(null);

  const resolvedItems = useMemo(() => {
    return items
      .map((it) => {
        const rawId = it.product?.id || (it as any).productId;
        const authoritative = getProductById(rawId) || it.product;
        if (!authoritative) return null;
        return {
          ...it,
          product: authoritative,
          quantity: Math.max(1, Math.floor(Number(it.quantity) || 1)),
        };
      })
      .filter((it): it is CartItem => it !== null);
  }, [items]);

  const rawSubtotal = resolvedItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const isFreeDelivery = rawSubtotal >= 999;
  const deliveryFee = rawSubtotal === 0 ? 0 : isFreeDelivery ? 0 : 99;
  const finalTotal = Math.max(0, rawSubtotal - couponDiscount + deliveryFee);

  if (!isOpen) return null;

  if (!user) {
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
        <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 sm:p-8 text-center space-y-4 border border-[#EAEAEA]">
          <div className="w-16 h-16 rounded-full bg-[#000000] text-[#FFD400] flex items-center justify-center mx-auto shadow-xs">
            <Lock className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl font-black text-[#111111]">
              Sign In to Place Order
            </h3>
            <p className="text-xs text-[#666666] mt-2 leading-relaxed">
              Please sign in with your Google account to complete your Cash on Delivery purchase securely on OMAZIFY.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              onClose();
              onRequireLogin?.();
            }}
            className="w-full h-12 flex items-center justify-center gap-3 px-5 bg-white hover:bg-[#FFF9DB] text-[#111111] font-black text-sm rounded-xl border border-[#111111] shadow-2xs transition-all cursor-pointer group"
          >
            <GoogleLogo className="w-5 h-5 group-hover:scale-105 transition-transform" />
            <span>Continue with Google</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="text-xs font-semibold text-[#666666] hover:text-[#000000] block mx-auto cursor-pointer"
          >
            Cancel & Return to Cart
          </button>
        </div>
      </div>
    );
  }

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    setCouponError(null);
    setCouponMessage(null);
    try {
      const res = await api.validateCoupon(couponCode, rawSubtotal);
      setCouponDiscount(res.discountAmount);
      setCouponMessage(res.message);
    } catch (err: any) {
      setCouponError(err.message || 'Invalid coupon.');
      setCouponDiscount(0);
    }
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setCheckoutError('Please sign in with Google to place this order.');
      onRequireLogin?.();
      return;
    }
    if (!agreedToTerms) {
      setCheckoutError('Please accept the Terms & Conditions and Government Consumer Protection declaration to proceed.');
      return;
    }

    setIsSubmitting(true);
    setCheckoutError(null);

    let shippingPayload = {
      fullName,
      phone,
      email: user?.email || email,
      street,
      city,
      state,
      pincode,
    };

    if (selectedAddressId !== 'new') {
      const saved = addresses.find((a) => a.id === selectedAddressId);
      if (saved) {
        shippingPayload = {
          fullName: saved.fullName,
          phone: saved.phone,
          email: user?.email || email,
          street: saved.street,
          city: saved.city,
          state: saved.state,
          pincode: saved.pincode,
        };
      }
    }

    const cleanPin = (shippingPayload.pincode || '').replace(/\s+/g, '');
    const pinRegex = /^[1-9][0-9]{5}$/;
    if (!pinRegex.test(cleanPin)) {
      setCheckoutError('Please enter a valid 6-digit Indian PIN code.');
      setIsSubmitting(false);
      return;
    }

    const pinCheck = await verifyIndianPinCode(cleanPin);
    if (!pinCheck.isValid) {
      setCheckoutError('The delivery PIN code could not be verified in India Post directory. Please enter a valid Indian postal PIN code.');
      setIsSubmitting(false);
      return;
    }

    if (resolvedItems.length === 0) {
      setCheckoutError('Your cart has no available items to order.');
      setIsSubmitting(false);
      return;
    }

    try {
      const payload = {
        items: resolvedItems.map((it) => ({
          productId: it.product.id,
          quantity: it.quantity,
          selectedSize: it.selectedSize,
          selectedColor: it.selectedColor,
        })),
        shippingAddress: shippingPayload,
        paymentMethod: 'cod',
        couponCode: couponDiscount > 0 ? couponCode : undefined,
      };

      const newOrder = await createOrder(payload);
      setConfirmedOrder(newOrder);
      onOrderSuccess();
    } catch (err: any) {
      setCheckoutError(err.message || 'Failed to complete order. Please check stock and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 md:p-6 animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[95vh] flex flex-col border border-[#EAEAEA]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#EAEAEA] bg-white sticky top-0 z-20">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#000000]" />
            <h2 className="text-base font-black text-[#111111]">
              {confirmedOrder ? 'Order Confirmed' : 'Cash on Delivery Checkout'}
            </h2>
            <span className="inline-flex items-center gap-1 text-[11px] font-black text-[#000000] bg-[#FFD400] px-2.5 py-0.5 rounded-md">
              <Banknote className="w-3.5 h-3.5 text-black" />
              100% Cash on Delivery
            </span>
          </div>
          {!confirmedOrder && (
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-[#FAFAFA] hover:bg-[#EAEAEA] text-[#111111] flex items-center justify-center transition-colors cursor-pointer"
              aria-label="Close checkout"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="overflow-y-auto p-5 sm:p-8 flex-1">
          {confirmedOrder ? (
            <div className="text-center py-6 sm:py-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#FFF9DB] text-[#000000] border-2 border-[#FFD400] flex items-center justify-center mx-auto shadow-xs">
                <CheckCircle className="w-9 h-9" />
              </div>
              <div>
                <span className="text-[11px] font-black uppercase tracking-wider text-[#000000] bg-[#FFD400] px-3 py-1 rounded-md">
                  Cash on Delivery Confirmed
                </span>
                <h3 className="text-2xl font-black text-[#111111] mt-2">Order Placed Successfully!</h3>
                <p className="text-xs sm:text-sm text-[#666666] mt-1">
                  Order ID: <span className="font-mono font-black text-[#000000]">{confirmedOrder.id}</span>
                </p>
                <p className="text-xs text-[#666666] mt-2 max-w-md mx-auto">
                  Your shipment is being prepared. Pay <strong className="text-[#000000] font-black text-sm">₹{confirmedOrder.total?.toLocaleString()}</strong> in cash to the delivery agent when your parcel arrives.
                </p>
              </div>

              <div className="p-4 bg-[#FAFAFA] rounded-2xl border border-[#EAEAEA] max-w-md mx-auto text-left text-xs space-y-2">
                <div className="flex justify-between font-semibold text-[#666666]">
                  <span>Shipping Destination:</span>
                  <span className="text-[#111111] font-bold truncate max-w-[200px]">
                    {confirmedOrder.shippingAddress?.street}, {confirmedOrder.shippingAddress?.city}
                  </span>
                </div>
                <div className="flex justify-between font-semibold text-[#666666]">
                  <span>Payment Mode:</span>
                  <span className="uppercase text-[#000000] font-black bg-[#FFD400] px-2 py-0.5 rounded">
                    Cash on Delivery (COD)
                  </span>
                </div>
                <div className="flex justify-between font-semibold text-[#666666]">
                  <span>Payment Status:</span>
                  <span className="text-[#111111] font-bold">
                    Pay at Doorstep
                  </span>
                </div>
                <div className="flex justify-between font-bold text-[#111111] border-t border-[#EAEAEA] pt-2 text-sm">
                  <span>Amount to Pay at Delivery:</span>
                  <span className="text-[#000000] font-black">₹{confirmedOrder.total?.toLocaleString()}</span>
                </div>
              </div>

              <div className="max-w-md mx-auto p-4 rounded-2xl bg-white border border-[#EAEAEA] text-left text-xs space-y-2.5 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#FFD400]"></span>
                    </span>
                    <span className="text-[11px] font-black uppercase tracking-wider text-[#111111]">
                      Live Order Tracking
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-[#000000] bg-[#FFF9DB] px-2 py-0.5 rounded border border-[#FFD400]/40">
                    Active Shipment
                  </span>
                </div>

                <div className="space-y-1.5 bg-[#FAFAFA] p-3 rounded-xl border border-[#EAEAEA]">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-[#000000] flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-[#111111]">
                        Current Location: OMAZIFY Central Logistics Hub, Bengaluru
                      </p>
                      <p className="text-[11px] text-[#666666]">
                        Order verified & barcode attached. Scheduled for surface courier pickup.
                      </p>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#EAEAEA] flex items-center justify-between">
                    <span className="text-[#666666] font-semibold flex items-center gap-1 text-[11px]">
                      <Clock className="w-3.5 h-3.5 text-[#000000]" />
                      Expected Delivery Date:
                    </span>
                    <span className="font-black text-[#111111] text-xs">
                      {new Date(confirmedOrder.expectedDeliveryDate || Date.now() + 86400000 * 4).toLocaleDateString('en-IN', {
                        weekday: 'short',
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 pt-2 max-w-md mx-auto">
                {onTrackOrder && (
                  <button
                    type="button"
                    onClick={() => onTrackOrder(confirmedOrder)}
                    className="w-full sm:w-auto px-6 py-3 bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black rounded-xl text-xs shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Truck className="w-4 h-4" />
                    <span>Track Order</span>
                  </button>
                )}
                {onViewOrders && (
                  <button
                    type="button"
                    onClick={() => onViewOrders()}
                    className="w-full sm:w-auto px-5 py-3 bg-white border border-[#111111] text-[#111111] hover:bg-[#FFF9DB] font-bold rounded-xl text-xs transition-all cursor-pointer"
                  >
                    My Orders
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onClose()}
                  className="w-full sm:w-auto px-4 py-2.5 text-[#666666] hover:text-[#000000] font-bold text-xs cursor-pointer"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmitOrder} className="space-y-6">
              {checkoutError && (
                <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{checkoutError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                <div className="md:col-span-7 space-y-5">
                  {addresses.length > 0 && (
                    <div>
                      <h3 className="text-xs font-black text-[#111111] uppercase tracking-wider mb-2">
                        1. Select Delivery Address
                      </h3>
                      <div className="space-y-2">
                        {addresses.map((addr) => (
                          <label
                            key={addr.id}
                            className={`flex items-start gap-2.5 p-3 rounded-xl border cursor-pointer transition-all ${
                              selectedAddressId === addr.id
                                ? 'border-[#000000] bg-[#FFF9DB]/40 shadow-2xs'
                                : 'border-[#EAEAEA] bg-white hover:bg-[#FAFAFA]'
                            }`}
                          >
                            <input
                              type="radio"
                              name="shippingAddr"
                              value={addr.id}
                              checked={selectedAddressId === addr.id}
                              onChange={() => setSelectedAddressId(addr.id)}
                              className="mt-0.5 accent-black"
                            />
                            <div className="text-xs">
                              <p className="font-bold text-[#111111]">{addr.fullName} • {addr.phone}</p>
                              <p className="text-[#666666] text-[11px] mt-0.5">
                                {addr.street}, {addr.city}, {addr.state} - {addr.pincode}
                              </p>
                            </div>
                          </label>
                        ))}
                        <label
                          className={`flex items-center gap-2 p-2.5 rounded-xl border cursor-pointer text-xs ${
                            selectedAddressId === 'new'
                              ? 'border-[#000000] bg-[#FFF9DB]/40 font-bold text-[#000000]'
                              : 'border-[#EAEAEA] bg-white text-[#666666] hover:bg-[#FAFAFA]'
                          }`}
                        >
                          <input
                            type="radio"
                            name="shippingAddr"
                            value="new"
                            checked={selectedAddressId === 'new'}
                            onChange={() => setSelectedAddressId('new')}
                            className="accent-black"
                          />
                          <span>Enter a different delivery address</span>
                        </label>
                      </div>
                    </div>
                  )}

                  {(addresses.length === 0 || selectedAddressId === 'new') && (
                    <div>
                      <h3 className="text-xs font-black text-[#111111] uppercase tracking-wider mb-2.5">
                        {addresses.length === 0 ? '1. Contact & Shipping Address' : 'New Delivery Address'}
                      </h3>
                      <div className="space-y-3">
                        <div>
                          <label className="text-[11px] font-semibold text-[#666666] block mb-1">Full Name</label>
                          <input
                            type="text"
                            required
                            value={fullName}
                            onChange={(e) => setFullName(e.target.value)}
                            className="w-full h-9 px-3 text-xs bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:border-[#000000] focus:outline-none"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="text-[11px] font-semibold text-[#666666] block mb-1">Phone Number (10 digits)</label>
                            <input
                              type="tel"
                              required
                              value={phone}
                              onChange={(e) => setPhone(e.target.value)}
                              placeholder="+91 9876543210"
                              className="w-full h-9 px-3 text-xs bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:border-[#000000] focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[11px] font-semibold text-[#666666] block mb-1">Email</label>
                            <input
                              type="email"
                              required
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                              className="w-full h-9 px-3 text-xs bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:border-[#000000] focus:outline-none"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="text-[11px] font-semibold text-[#666666] block mb-1">Street Address, Flat / House / Building</label>
                          <input
                            type="text"
                            required
                            value={street}
                            onChange={(e) => setStreet(e.target.value)}
                            className="w-full h-9 px-3 text-xs bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:border-[#000000] focus:outline-none"
                          />
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <label className="text-[11px] font-semibold text-[#666666] block mb-1">City</label>
                            <input
                              type="text"
                              required
                              value={city}
                              onChange={(e) => setCity(e.target.value)}
                              className="w-full h-9 px-3 text-xs bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:border-[#000000] focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[11px] font-semibold text-[#666666] block mb-1">State</label>
                            <input
                              type="text"
                              required
                              value={state}
                              onChange={(e) => setState(e.target.value)}
                              className="w-full h-9 px-3 text-xs bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:border-[#000000] focus:outline-none"
                            />
                          </div>
                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <label className="text-[11px] font-semibold text-[#666666]">PIN Code (6 digits)</label>
                              {isVerifyingPin && (
                                <span className="text-[10px] text-amber-700 font-medium flex items-center gap-1">
                                  <Loader2 className="w-2.5 h-2.5 animate-spin" />
                                </span>
                              )}
                            </div>
                            <input
                              type="text"
                              required
                              maxLength={6}
                              placeholder="e.g. 110001"
                              value={pincode}
                              onChange={(e) => handlePinChange(e.target.value)}
                              className="w-full h-9 px-3 text-xs bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:border-[#000000] focus:outline-none font-bold"
                            />
                            {pinVerification && pinVerification.isValid && (
                              <p className="text-[10px] text-emerald-700 font-semibold mt-1 flex items-center gap-1">
                                <Check className="w-3 h-3 text-emerald-600 flex-shrink-0" />
                                <span className="truncate">India Post: {pinVerification.district || pinVerification.state}</span>
                              </p>
                            )}
                            {pinVerification && !pinVerification.isValid && (
                              <p className="text-[10px] text-rose-600 font-semibold mt-1 flex items-center gap-1">
                                <AlertCircle className="w-3 h-3 text-rose-500 flex-shrink-0" />
                                <span>Unverified PIN</span>
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  <div>
                    <div className="flex items-center justify-between mb-2.5">
                      <h3 className="text-xs font-black text-[#111111] uppercase tracking-wider">
                        2. Payment Option
                      </h3>
                      <span className="text-[10px] text-[#000000] font-black bg-[#FFD400] px-2.5 py-0.5 rounded">
                        Zero Online Risk
                      </span>
                    </div>

                    <div className="p-4 rounded-xl border border-[#EAEAEA] bg-white shadow-2xs">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-xl bg-[#FAFAFA] text-[#000000] border border-[#EAEAEA] flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Banknote className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-black text-[#111111]">
                              Cash on Delivery (COD)
                            </span>
                            <span className="text-[10px] font-bold text-[#000000] bg-[#FFF9DB] px-2 py-0.5 rounded border border-[#FFD400]/40">
                              Active & Verified
                            </span>
                          </div>
                          <p className="text-xs text-[#666666] mt-1 leading-relaxed">
                            No advance payment or card details required. Pay ₹{finalTotal.toLocaleString()} in cash directly to our delivery courier at your doorstep.
                          </p>
                          <div className="mt-3 pt-2.5 border-t border-[#EAEAEA] flex flex-wrap items-center gap-3 text-[11px] text-[#111111] font-semibold">
                            <span className="flex items-center gap-1">
                              <Check className="w-3.5 h-3.5 text-black" />
                              Free COD Handling
                            </span>
                            <span className="flex items-center gap-1">
                              <Check className="w-3.5 h-3.5 text-black" />
                              Inspect Before Payment
                            </span>
                            <span className="flex items-center gap-1">
                              <Check className="w-3.5 h-3.5 text-black" />
                              7-Day Return Guarantee
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#EAEAEA]">
                    <label className="flex items-start gap-2.5 text-xs text-[#666666] cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={agreedToTerms}
                        onChange={(e) => setAgreedToTerms(e.target.checked)}
                        className="mt-0.5 accent-black h-4 w-4 rounded"
                      />
                      <span className="text-[11px] text-[#666666] leading-snug">
                        I confirm that this order is placed via <strong className="text-[#111111]">Cash on Delivery (COD)</strong> in accordance with the <strong className="text-[#111111]">Consumer Protection (E-Commerce) Rules, 2020</strong>.
                      </span>
                    </label>
                  </div>
                </div>

                <div className="md:col-span-5 bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl sm:rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xs font-black text-[#111111] uppercase tracking-wider mb-3">
                      Order Summary ({resolvedItems.length} {resolvedItems.length === 1 ? 'item' : 'items'})
                    </h3>

                    <div className="max-h-40 overflow-y-auto divide-y divide-[#EAEAEA] pr-1">
                      {resolvedItems.map((it, idx) => (
                        <div key={`${it.product.id}-${idx}`} className="py-2 flex items-center justify-between text-xs">
                          <div className="min-w-0 pr-2">
                            <p className="font-bold text-[#111111] truncate">{it.product.name}</p>
                            <p className="text-[10px] text-[#666666]">
                              Qty: {it.quantity} {it.selectedSize ? `• ${it.selectedSize}` : ''}
                            </p>
                          </div>
                          <span className="font-black text-[#111111] flex-shrink-0">
                            ₹{(it.product.price * it.quantity).toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="mt-3 pt-3 border-t border-[#EAEAEA]">
                      <div className="flex gap-1.5">
                        <div className="relative flex-1">
                          <Tag className="w-3.5 h-3.5 text-[#666666] absolute left-2.5 top-1/2 -translate-y-1/2" />
                          <input
                            type="text"
                            value={couponCode}
                            onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                            placeholder="Coupon Code"
                            className="w-full h-8 pl-8 pr-2 text-xs font-mono font-bold bg-white border border-[#EAEAEA] rounded-lg uppercase"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={handleApplyCoupon}
                          className="px-3 h-8 bg-[#000000] text-[#FFD400] rounded-lg text-xs font-bold hover:bg-neutral-800 cursor-pointer"
                        >
                          Apply
                        </button>
                      </div>
                      {couponMessage && (
                        <p className="text-[11px] text-emerald-600 font-semibold mt-1">{couponMessage}</p>
                      )}
                      {couponError && (
                        <p className="text-[11px] text-red-600 font-semibold mt-1">{couponError}</p>
                      )}
                    </div>

                    <div className="border-t border-[#EAEAEA] pt-3 mt-3 space-y-1.5 text-xs">
                      <div className="flex justify-between text-[#666666]">
                        <span>Subtotal</span>
                        <span>₹{rawSubtotal.toLocaleString()}</span>
                      </div>
                      {couponDiscount > 0 && (
                        <div className="flex justify-between text-emerald-600 font-semibold">
                          <span>Coupon Discount ({couponCode})</span>
                          <span>- ₹{couponDiscount.toLocaleString()}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-[#666666]">
                        <span>Delivery Fee</span>
                        <span className={rawSubtotal >= 999 ? 'text-emerald-600 font-bold' : ''}>
                          {rawSubtotal >= 999 ? 'FREE' : '₹99'}
                        </span>
                      </div>
                      <div className="flex justify-between text-[#666666]">
                        <span>COD Convenience Fee</span>
                        <span className="font-bold text-[#111111]">FREE (₹0)</span>
                      </div>
                      <div className="border-t border-[#EAEAEA] pt-2 flex justify-between font-black text-sm text-[#111111]">
                        <span>Total Amount</span>
                        <span className="text-[#000000] text-base">₹{finalTotal.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting || !agreedToTerms}
                    className="mt-6 w-full py-3.5 px-4 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition-all active:scale-95 cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Processing Order...</span>
                      </>
                    ) : (
                      <>
                        <Banknote className="w-4 h-4" />
                        <span>Place Order (₹{finalTotal.toLocaleString()})</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default CheckoutModal;
