import React, { useState } from 'react';
import { X, HeartHandshake, CheckCircle2, Shield, Send } from 'lucide-react';

interface PrayerRequestModalProps {
  onClose: () => void;
}

export const PrayerRequestModal: React.FC<PrayerRequestModalProps> = ({ onClose }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState('Healing & Health');
  const [requestText, setRequestText] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestText.trim()) return;
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/50 max-w-lg w-full rounded-3xl border border-amber-500/30 shadow-2xl p-6 sm:p-8 space-y-6 relative overflow-hidden">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-amber-300 transition-colors border border-amber-500/20 z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {!submitted ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest flex items-center space-x-1">
                <Shield className="w-3.5 h-3.5 text-amber-400" />
                <span>CONFIDENTIAL PRAYER ALTAR</span>
              </span>
              <h3 className="text-xl font-bold font-serif text-amber-100">
                Submit Your Prayer Request
              </h3>
              <p className="text-xs text-slate-300">
                Prophet JUHNKRIX SYNVAGORD and the global prayer warriors will lay hands in faith over your petition.
              </p>
            </div>

            <div className="space-y-3 pt-2">
              <div>
                <label className="text-xs font-semibold text-amber-300 block mb-1">Your Full Name</label>
                <input
                  type="text"
                  placeholder="Sister Mary / Brother Emmanuel"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/20 rounded-xl px-4 py-2 text-xs text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-amber-300 block mb-1">Contact Email</label>
                <input
                  type="email"
                  placeholder="your.email@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/20 rounded-xl px-4 py-2 text-xs text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-amber-300 block mb-1">Category of Need</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/20 rounded-xl px-4 py-2 text-xs text-amber-100 focus:outline-none focus:border-amber-400"
                >
                  <option value="Healing & Health">Healing & Health</option>
                  <option value="Financial Breakthrough">Financial Breakthrough</option>
                  <option value="Family Restoration">Family Restoration</option>
                  <option value="Deliverance">Deliverance & Freedom</option>
                  <option value="Prophetic Guidance">Prophetic Guidance</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-amber-300 block mb-1">Prayer Details</label>
                <textarea
                  rows={4}
                  placeholder="Write your request in detail..."
                  value={requestText}
                  onChange={(e) => setRequestText(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/20 rounded-xl p-4 text-xs text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-400 text-slate-950 font-bold text-xs flex items-center justify-center space-x-2 shadow-xl shadow-amber-500/20 hover:scale-[1.02] transition-all"
            >
              <Send className="w-4 h-4 text-slate-950" />
              <span>Send Petition to Prophet JUHNKRIX Altar</span>
            </button>
          </form>
        ) : (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="text-2xl font-bold font-serif text-amber-100">
              Prayer Petition Received!
            </h3>

            <p className="text-xs text-slate-300 leading-relaxed max-w-sm mx-auto">
              God bless you, <span className="text-amber-300 font-bold">{name || 'Believer'}</span>. Your prayer request has been logged onto Prophet JUHNKRIX SYNVAGORD&apos;s intercessory prayer altar.
            </p>

            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 text-xs text-amber-200/90 italic font-serif">
              &ldquo;I speak peace and instant divine alignment over your situation. Believe and receive in Jesus name.&rdquo;
            </div>

            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors"
            >
              Return to Sanctuary
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
