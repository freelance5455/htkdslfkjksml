import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { BookOpen } from "lucide-react";
import { GROK_PROVIDERS, authClient, signIn } from "@/lib/auth/client";
import { templateFromSeed } from "@/lib/paperly/templates";
import { CoverSheet, type CoverModel } from "./cover-sheet";

function modelFrom(seed: string, title: string, subtitle: string): CoverModel {
  const template = templateFromSeed(seed);
  return {
    title,
    subtitle,
    author: "Paperly",
    kicker: "كتاب",
    image: "",
    layout: template.layout,
    pattern: template.pattern,
    color1: template.c1,
    color2: template.c2,
    paper: template.paper,
    angle: template.angle,
  };
}

export function Landing() {
  return (
    <main className="landing">
      <section className="landing-copy">
        <div className="brand">
          <BookOpen aria-hidden />
          <strong>Paperly</strong>
        </div>
        <h1>مستندك، من الغلاف حتى ملف PDF.</h1>
        <p className="lede">
          اكتب أو الصق النص، أضف الصور والملفات، واختر من قوالب أغلفة تُولَّد بلا نهاية. المشاريع تُحفظ في حسابك.
        </p>
        <ul className="points">
          <li>صفحات A4 حقيقية وأرقام محتويات محسوبة</li>
          <li>تنزيل PDF من داخل التطبيق، بلا مكتبة خارجية</li>
          <li>سحب الصور، لصق الفقرات، وإرفاق الملفات</li>
        </ul>
        <AuthCard />
      </section>
      <section className="landing-art" aria-hidden>
        <div className="art-card">
          <CoverSheet model={modelFrom("editorial-4", "دفتر الورق", "غلاف يُولد من بذرة")} font="amiri" title="دفتر الورق" subtitle="غلاف يُولد من بذرة" author="Paperly" />
        </div>
        <div className="art-card art-back">
          <CoverSheet model={modelFrom("desert-7", "تقرير المساء", "صفحات جاهزة للطباعة")} font="plex" title="تقرير المساء" subtitle="صفحات جاهزة للطباعة" author="Paperly" />
        </div>
      </section>
    </main>
  );
}

export function ShellSkeleton() {
  return (
    <main className="gate">
      <BookOpen aria-hidden />
      <h1>Paperly</h1>
      <p>لحظة، نتحقق من الجلسة…</p>
    </main>
  );
}

function AuthCard() {
  const router = useRouter();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function submit() {
    setError(null);
    setPending(true);
    try {
      const result =
        mode === "up"
          ? await authClient.signUp.email({ email, password, name: name.trim() || "قارئ", callbackURL: "/" })
          : await authClient.signIn.email({ email, password, callbackURL: "/" });
      if (result.error) {
        setError(authMessage(result.error.message));
        return;
      }
      await router.invalidate();
      await router.navigate({ to: "/" });
    } catch (err) {
      setError(authMessage(err instanceof Error ? err.message : undefined));
    } finally {
      setPending(false);
    }
  }

  return (
    <form
      className="auth-card"
      onSubmit={(event) => {
        event.preventDefault();
        void submit();
      }}
    >
      <div className="row">
        <button type="button" className={mode === "in" ? "btn is-on" : "btn"} onClick={() => setMode("in")}>
          دخول
        </button>
        <button type="button" className={mode === "up" ? "btn is-on" : "btn"} onClick={() => setMode("up")}>
          حساب جديد
        </button>
      </div>
      {mode === "up" ? (
        <label className="field">
          <span>الاسم</span>
          <input value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" />
        </label>
      ) : null}
      <label className="field">
        <span>البريد</span>
        <input dir="ltr" type="email" required value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" />
      </label>
      <label className="field">
        <span>كلمة المرور</span>
        <input
          dir="ltr"
          type="password"
          required
          minLength={8}
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          autoComplete={mode === "up" ? "new-password" : "current-password"}
        />
      </label>
      {error ? <p className="form-error">{error}</p> : null}
      <button type="submit" className="btn btn-primary" disabled={pending}>
        {pending ? "لحظة…" : mode === "up" ? "إنشاء الحساب" : "دخول"}
      </button>
      <div className="auth-split">أو</div>
      {GROK_PROVIDERS.map((provider) => (
        <button
          key={provider.providerId}
          type="button"
          className="btn"
          onClick={() => {
            void signIn(provider.providerId, { callbackURL: "/" }).catch((err: unknown) => {
              setError(authMessage(err instanceof Error ? err.message : undefined));
            });
          }}
        >
          المتابعة عبر {provider.label}
        </button>
      ))}
    </form>
  );
}

function authMessage(message?: string) {
  if (!message) return "تعذر تسجيل الدخول";
  if (/invalid email or password/i.test(message)) return "البريد أو كلمة المرور غير صحيحة";
  if (/already exists/i.test(message)) return "هذا البريد مسجّل مسبقًا";
  if (/password/i.test(message)) return "استخدم 8 أحرف على الأقل لكلمة المرور";
  if (/invalid origin/i.test(message)) return "تعذر التحقق من المصدر. أعد المحاولة.";
  return message;
}
