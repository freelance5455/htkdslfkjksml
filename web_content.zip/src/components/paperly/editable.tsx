import { useEffect, useRef } from "react";

type EditableProps = {
  value: string;
  className?: string;
  onChange: (value: string) => void;
  onFocus?: () => void;
  onBlur?: () => void;
  onMultilinePaste?: (text: string) => boolean;
};

export function Editable({ value, className, onChange, onFocus, onBlur, onMultilinePaste }: EditableProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const node = ref.current;
    if (!node || document.activeElement === node) return;
    if (node.innerText !== value) node.innerText = value;
  }, [value]);

  return (
    <div
      ref={ref}
      className={className}
      contentEditable
      suppressContentEditableWarning
      role="textbox"
      spellCheck
      onFocus={onFocus}
      onBlur={onBlur}
      onPaste={(event) => {
        const text = event.clipboardData.getData("text/plain");
        if (onMultilinePaste?.(text)) {
          event.preventDefault();
          return;
        }
        event.preventDefault();
        const selection = window.getSelection();
        if (!selection?.rangeCount) return;
        const range = selection.getRangeAt(0);
        range.deleteContents();
        const node = document.createTextNode(text);
        range.insertNode(node);
        range.setStartAfter(node);
        range.collapse(true);
        selection.removeAllRanges();
        selection.addRange(range);
        onChange(event.currentTarget.innerText);
      }}
      onInput={(event) => onChange(event.currentTarget.innerText)}
    />
  );
}
