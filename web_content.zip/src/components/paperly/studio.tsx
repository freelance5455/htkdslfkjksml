import { useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import { BookOpen, Download, Minus, Plus, Printer, Upload } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import {
  applyTemplate,
  fresh,
  paginate,
  parseProject,
  textToBlocks,
  uid,
  type Block,
  type ProjectDoc,
} from "@/lib/paperly/model";
import { compressImage, isProjectFile, isTextFile, readAttachment } from "@/lib/paperly/media";
import { downloadPdf } from "@/lib/paperly/pdf";
import { deleteProject, getProject, listProjects, saveProject, type ProjectSummary } from "@/lib/paperly/projects.server";
import { randomSeed, templateFromSeed } from "@/lib/paperly/templates";
import type { Family } from "@/lib/paperly/templates";
import { DocumentView } from "./document-view";
import { Inspector, type Panel } from "./inspector";

const PANELS: { id: Panel; label: string }[] = [
  { id: "cover", label: "الغلاف" },
  { id: "write", label: "كتابة" },
  { id: "templates", label: "قوالب" },
  { id: "page", label: "الصفحة" },
  { id: "projects", label: "مشاريعي" },
];

export function Studio() {
  const user = useCurrentUser();
  const userId = user?.id ?? "";
  const [doc, setDoc] = useState<ProjectDoc | null>(null);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [panel, setPanel] = useState<Panel>("write");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [family, setFamily] = useState<Family | "all">("all");
  const [templateCount, setTemplateCount] = useState(18);
  const [zoom, setZoom] = useState(0.86);
  const [status, setStatus] = useState("…");
  const [toast, setToast] = useState<string | null>(null);
  const [booted, setBooted] = useState(false);
  const [bootError, setBootError] = useState<string | null>(null);
  const [pdfLabel, setPdfLabel] = useState("");
  const [dragging, setDragging] = useState(false);
  const docRef = useRef<ProjectDoc | null>(null);
  const selectedRef = useRef<string | null>(null);
  const past = useRef<ProjectDoc[]>([]);
  const future = useRef<ProjectDoc[]>([]);
  const lastHist = useRef(0);
  const fileRef = useRef<HTMLInputElement>(null);
  const targetRef = useRef<"cover" | string | null>(null);
  const userIdRef = useRef(userId);
  userIdRef.current = userId;
  selectedRef.current = selectedId;

  const show = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 2600);
  };

  const commit = (recipe: (current: ProjectDoc) => ProjectDoc) => {
    const current = docRef.current;
    if (!current) return;
    const next = recipe(current);
    const now = Date.now();
    if (now - lastHist.current > 500) {
      past.current.push(current);
      if (past.current.length > 40) past.current.shift();
      future.current = [];
    }
    lastHist.current = now;
    docRef.current = next;
    setDoc(next);
  };

  const undo = () => {
    const current = docRef.current;
    const prev = past.current.pop();
    if (!current || !prev) return;
    future.current.push(current);
    docRef.current = prev;
    setDoc(prev);
  };

  const redo = () => {
    const current = docRef.current;
    const next = future.current.pop();
    if (!current || !next) return;
    past.current.push(current);
    docRef.current = next;
    setDoc(next);
  };

  useEffect(() => {
    const fit = () => {
      const width = window.innerWidth;
      if (width < 960) setZoom(Math.max(0.36, Math.min(0.7, (width - 28) / 794)));
    };
    fit();
  }, []);

  useEffect(() => {
    if (!userId) return;
    let cancel = false;
    (async () => {
      try {
        const rows = await listProjects();
        if (cancel) return;
        setProjects(rows);
        if (rows[0]) {
          const full = await getProject({ data: rows[0].id });
          if (cancel) return;
          const draft = readDraft(userId, full.id);
          const next = draft && draft.updatedAt > full.updatedAt ? draft : full;
          docRef.current = next;
          setDoc(next);
        } else {
          const created = fresh("book");
          docRef.current = created;
          setDoc(created);
          await saveProject({ data: created });
          if (!cancel) setProjects([{ id: created.id, name: created.name, updatedAt: new Date().toISOString() }]);
        }
        if (!cancel) setBooted(true);
      } catch (error) {
        if (!cancel) setBootError(error instanceof Error ? error.message : "تعذر فتح المشاريع");
      }
    })();
    return () => {
      cancel = true;
    };
  }, [userId]);

  useEffect(() => {
    if (!booted || !doc || !userId) return;
    writeDraft(userId, doc);
    setStatus("يحفظ…");
    const snapshot = doc;
    const timer = window.setTimeout(() => {
      void saveProject({ data: snapshot })
        .then((result) => {
          if (docRef.current?.id === snapshot.id && (docRef.current.updatedAt ?? 0) <= snapshot.updatedAt + 1) {
            setStatus("محفوظ في حسابك");
          }
          if (result.warnings[0]) show(result.warnings[0]);
          setProjects((prev) => [
            { id: snapshot.id, name: snapshot.name, updatedAt: new Date(snapshot.updatedAt).toISOString() },
            ...prev.filter((item) => item.id !== snapshot.id),
          ]);
        })
        .catch(() => setStatus("تعذر الحفظ"));
    }, 700);
    return () => window.clearTimeout(timer);
  }, [doc, booted, userId]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest("input, textarea, [contenteditable='true']")) return;
      if (!(event.metaKey || event.ctrlKey) || event.key.toLowerCase() !== "z") return;
      event.preventDefault();
      if (event.shiftKey) redo();
      else undo();
    };
    const onPaste = (event: ClipboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest("input, textarea, [contenteditable='true']")) return;
      const files = [...(event.clipboardData?.files || [])];
      if (files.length) {
        event.preventDefault();
        void addIncoming(files);
        return;
      }
      const text = event.clipboardData?.getData("text/plain") || "";
      if (text.trim()) {
        event.preventDefault();
        insertText(text);
      }
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("paste", onPaste);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("paste", onPaste);
    };
  });

  const pages = useMemo(() => (doc ? paginate(doc) : []), [doc]);
  const words = useMemo(() => {
    if (!doc) return 0;
    return doc.blocks.reduce((sum, block) => {
      const text = `${block.title || ""} ${block.text || ""} ${(block.items || []).join(" ")}`.trim();
      if (!text) return sum;
      return sum + text.split(/\s+/).filter(Boolean).length;
    }, 0);
  }, [doc]);

  function insertText(text: string) {
    const blocks = textToBlocks(text);
    if (!blocks.length) return;
    commit((current) => {
      const copy = current.blocks.slice();
      const index = selectedRef.current ? copy.findIndex((block) => block.id === selectedRef.current) : copy.length - 1;
      copy.splice(Math.max(index, -1) + 1, 0, ...blocks);
      return { ...current, blocks: copy, updatedAt: Date.now() };
    });
    setSelectedId(blocks[0]?.id ?? null);
    setPanel("write");
    show(blocks.length > 1 ? `أُدرجت ${blocks.length} فقرات` : "أُدرج النص");
  }

  async function addIncoming(files: File[]) {
    const created: Block[] = [];
    let imported: ProjectDoc | null = null;
    for (const file of files) {
      try {
        if (isProjectFile(file)) {
          const parsed = parseProject(JSON.parse(await file.text()));
          if (!parsed) throw new Error("ملف المشروع غير صالح");
          imported = { ...parsed.doc, id: uid(), name: parsed.doc.name || file.name.replace(/\.json$/i, ""), updatedAt: Date.now() };
          if (parsed.warnings[0]) show(parsed.warnings[0]);
          continue;
        }
        if (isTextFile(file)) {
          created.push(...textToBlocks(await file.text()));
          continue;
        }
        if (file.type.startsWith("image/")) {
          created.push({ id: uid(), kind: "image", src: await compressImage(file), caption: "" });
          continue;
        }
        const attachment = await readAttachment(file);
        created.push({
          id: uid(),
          kind: "file",
          src: attachment.src,
          fileName: attachment.name,
          fileMime: attachment.mime,
          fileSize: attachment.size,
        });
      } catch (error) {
        show(error instanceof Error ? error.message : "تعذر إضافة الملف");
      }
    }
    if (imported) {
      past.current = [];
      future.current = [];
      docRef.current = imported;
      setDoc(imported);
      setSelectedId(null);
      show("تم فتح المشروع");
      return;
    }
    if (!created.length) return;
    commit((current) => ({ ...current, blocks: [...current.blocks, ...created], updatedAt: Date.now() }));
    setSelectedId(created[0]?.id ?? null);
    setPanel("write");
  }

  async function onPickedFile(event: ChangeEvent<HTMLInputElement>) {
    const files = [...(event.target.files || [])];
    event.target.value = "";
    const target = targetRef.current;
    targetRef.current = null;
    if (!files[0] || !docRef.current) return;
    try {
      if (target === "cover") {
        const src = await compressImage(files[0]);
        commit((current) => ({ ...current, cover: { ...current.cover, image: src }, updatedAt: Date.now() }));
        show("أُضيفت صورة الغلاف");
        return;
      }
      if (target) {
        const block = docRef.current.blocks.find((item) => item.id === target);
        if (block?.kind === "image") {
          const src = await compressImage(files[0]);
          commit((current) => ({
            ...current,
            updatedAt: Date.now(),
            blocks: current.blocks.map((item) => (item.id === target ? { ...item, src } : item)),
          }));
          show("أُضيفت الصورة");
          return;
        }
        if (block?.kind === "file") {
          const attachment = await readAttachment(files[0]);
          commit((current) => ({
            ...current,
            updatedAt: Date.now(),
            blocks: current.blocks.map((item) =>
              item.id === target
                ? { ...item, src: attachment.src, fileName: attachment.name, fileMime: attachment.mime, fileSize: attachment.size }
                : item,
            ),
          }));
          show("أُرفق الملف");
          return;
        }
      }
      await addIncoming(files);
    } catch (error) {
      show(error instanceof Error ? error.message : "تعذر قراءة الملف");
    }
  }

  function pick(target: "cover" | string | null, accept: string) {
    targetRef.current = target;
    if (fileRef.current) {
      fileRef.current.accept = accept;
      fileRef.current.multiple = target === null;
      fileRef.current.click();
    }
  }

  async function openProject(id: string) {
    if (docRef.current) {
      try {
        await saveProject({ data: docRef.current });
      } catch {
        /* the next save retries */
      }
    }
    const next = await getProject({ data: id });
    const draft = readDraft(userIdRef.current, id);
    const chosen = draft && draft.updatedAt > next.updatedAt ? draft : next;
    past.current = [];
    future.current = [];
    docRef.current = chosen;
    setDoc(chosen);
    setSelectedId(null);
    setPanel("write");
  }

  async function removeProject(id: string) {
    await deleteProject({ data: id });
    const rest = projects.filter((item) => item.id !== id);
    setProjects(rest);
    if (docRef.current?.id !== id) return;
    if (rest[0]) {
      const next = await getProject({ data: rest[0].id });
      docRef.current = next;
      setDoc(next);
      return;
    }
    const created = fresh("book");
    docRef.current = created;
    setDoc(created);
  }

  async function onPdf() {
    const root = document.getElementById("paperly-doc");
    if (!root || !doc || pdfLabel) return;
    setPdfLabel("جاري تجهيز الصفحات");
    try {
      await downloadPdf(root, doc.name, (current, total) => setPdfLabel(`الصفحة ${current} من ${total}`));
      show("تم تنزيل PDF");
    } catch (error) {
      console.error(error);
      show("تعذر إنشاء PDF. استخدم الطباعة ثم «حفظ كـ PDF».");
    } finally {
      setPdfLabel("");
    }
  }

  if (bootError) {
    return (
      <main className="gate">
        <h1>تعذر فتح Paperly</h1>
        <p>{bootError}</p>
      </main>
    );
  }

  if (!doc) {
    return (
      <main className="gate">
        <BookOpen aria-hidden />
        <h1>Paperly</h1>
        <p>نحضر مستنداتك…</p>
      </main>
    );
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <BookOpen aria-hidden />
          <strong>Paperly</strong>
        </div>
        <input
          className="name-input"
          aria-label="اسم المشروع"
          value={doc.name}
          onChange={(event) => commit((current) => ({ ...current, name: event.target.value, updatedAt: Date.now() }))}
        />
        <div className="top-actions">
          <span className="status">{pdfLabel || status}</span>
          <button type="button" className="btn" onClick={undo} aria-label="تراجع">
            تراجع
          </button>
          <button type="button" className="btn" onClick={() => pick(null, ".json,.txt,.md,.csv,image/*,.pdf,application/pdf") }>
            <Upload aria-hidden />
            استيراد
          </button>
          <button type="button" className="btn" onClick={() => window.print()}>
            <Printer aria-hidden />
            طباعة
          </button>
          <button type="button" className="btn btn-primary" onClick={() => void onPdf()} disabled={Boolean(pdfLabel)}>
            <Download aria-hidden />
            {pdfLabel ? "يجهّز…" : "تنزيل PDF"}
          </button>
          <UserButton />
        </div>
      </header>
      <div className="workspace">
        <aside className="rail">
          <div className="label">اللوحات</div>
          <div className="rail-nav">
            {PANELS.map((item) => (
              <button key={item.id} type="button" className={panel === item.id ? "rail-btn is-on" : "rail-btn"} onClick={() => setPanel(item.id)}>
                {item.label}
              </button>
            ))}
          </div>
          <button
            type="button"
            className="btn"
            onClick={() => {
              const template = templateFromSeed(randomSeed());
              commit((current) => applyTemplate(current, template));
              setPanel("cover");
              show(template.name);
            }}
          >
            غلاف عشوائي
          </button>
          <p className="hint">القوالب تُولَّد من بذور لا تنتهي. النص والصورة يبقيان عند تغيير الغلاف.</p>
        </aside>
        <main
          className={dragging ? "stage is-dropping" : "stage"}
          onDragOver={(event) => {
            if (![...event.dataTransfer.types].includes("Files")) return;
            event.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(event) => {
            event.preventDefault();
            setDragging(false);
            void addIncoming([...event.dataTransfer.files]);
          }}
        >
          <div className="stagebar">
            <div>
              <div className="kicker">{pages.length} صفحات</div>
              <div className="stage-title">{doc.name}</div>
            </div>
            <div className="zoom">
              <button type="button" className="icon-btn" aria-label="تصغير" onClick={() => setZoom((value) => Math.max(0.35, Math.round((value - 0.08) * 100) / 100))}>
                <Minus />
              </button>
              <span className="tabular">{Math.round(zoom * 100)}%</span>
              <button type="button" className="icon-btn" aria-label="تكبير" onClick={() => setZoom((value) => Math.min(1.3, Math.round((value + 0.08) * 100) / 100))}>
                <Plus />
              </button>
            </div>
            <div className="tabular words">{words} كلمة</div>
          </div>
          <div className="viewport">
            {dragging ? <div className="drop-hint">أفلت الصور أو الملفات أو النص هنا</div> : null}
            <DocumentView
              doc={doc}
              pages={pages}
              zoom={zoom}
              selectedId={selectedId}
              onSelect={(id) => {
                setSelectedId(id);
                if (window.innerWidth < 960) setPanel("write");
              }}
              onEdit={(id, patch) =>
                commit((current) => ({
                  ...current,
                  updatedAt: Date.now(),
                  blocks: current.blocks.map((block) => (block.id === id ? { ...block, ...patch } : block)),
                }))
              }
              onCover={(patch) => commit((current) => ({ ...current, cover: { ...current.cover, ...patch }, updatedAt: Date.now() }))}
              onPasteText={(sourceId, text) => {
                if (!(text.includes("\n\n") || text.includes("\n#"))) return false;
                const blocks = textToBlocks(text);
                if (blocks.length < 2) return false;
                commit((current) => {
                  const index = current.blocks.findIndex((block) => block.id === sourceId);
                  const copy = current.blocks.slice();
                  if (index >= 0) copy.splice(index, 1, ...blocks);
                  else copy.push(...blocks);
                  return { ...current, blocks: copy, updatedAt: Date.now() };
                });
                setSelectedId(blocks[0]?.id ?? null);
                return true;
              }}
            />
          </div>
        </main>
        <Inspector
          doc={doc}
          panel={panel}
          selectedId={selectedId}
          projects={projects}
          family={family}
          templateCount={templateCount}
          onFamily={(next) => {
            setFamily(next);
            setTemplateCount(18);
          }}
          onMore={() => setTemplateCount((count) => count + 18)}
          onDoc={commit}
          onSelect={setSelectedId}
          onOpen={(id) => void openProject(id)}
          onDeleteProject={(id) => void removeProject(id)}
          onCreate={() => {
            const created = fresh(doc.type);
            past.current = [];
            future.current = [];
            docRef.current = created;
            setDoc(created);
            setSelectedId(null);
            setPanel("cover");
          }}
          onDuplicate={() => {
            const copy = structuredClone(doc);
            copy.id = uid();
            copy.name = `${doc.name} نسخة`.slice(0, 120);
            copy.updatedAt = Date.now();
            past.current = [];
            future.current = [];
            docRef.current = copy;
            setDoc(copy);
            show("تم إنشاء نسخة");
          }}
          onExport={() => {
            const blob = new Blob([JSON.stringify(doc, null, 2)], { type: "application/json" });
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = `${doc.name || "paperly"}.json`;
            link.click();
            URL.revokeObjectURL(url);
          }}
          onPickFiles={(targetId) => pick(targetId ?? null, targetId ? "*/*" : ".json,.txt,.md,image/*,.pdf,application/pdf")}
          onPickImage={(target) => pick(target, "image/*")}
          onInsertText={insertText}
        />
      </div>
      <nav className="mobile-nav">
        <button type="button" className={panel === "preview" ? "is-on" : ""} onClick={() => setPanel("preview")}>
          معاينة
        </button>
        {PANELS.map((item) => (
          <button key={item.id} type="button" className={panel === item.id ? "is-on" : ""} onClick={() => setPanel(item.id)}>
            {item.label}
          </button>
        ))}
      </nav>
      <input ref={fileRef} className="sr-only" type="file" onChange={(event) => void onPickedFile(event)} />
      {toast ? <div className="toast">{toast}</div> : null}
    </div>
  );
}

function readDraft(userId: string, id: string): ProjectDoc | null {
  try {
    const raw = localStorage.getItem(`paperly.draft.${userId}.${id}`);
    if (!raw) return null;
    return parseProject(JSON.parse(raw))?.doc ?? null;
  } catch {
    return null;
  }
}

function writeDraft(userId: string, value: ProjectDoc) {
  try {
    localStorage.setItem(`paperly.draft.${userId}.${value.id}`, JSON.stringify(value));
  } catch {
    /* the account copy remains the durable one */
  }
}
