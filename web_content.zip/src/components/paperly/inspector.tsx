import { useMemo, useState } from "react";
import {
  applyTemplate,
  BLOCK_LABEL,
  TYPE_LABEL,
  DOC_TYPES,
  moveBlock,
  type Block,
  type BlockKind,
  type DocType,
  type ProjectDoc,
} from "@/lib/paperly/model";
import {
  FAMILY_LABEL,
  FAMILIES,
  LAYOUTS,
  LAYOUT_LABEL,
  PATTERN_LABEL,
  PATTERNS,
  templateFromSeed,
  templateSeeds,
  type Family,
} from "@/lib/paperly/templates";
import type { ProjectSummary } from "@/lib/paperly/projects.server";
import { CoverSheet, coverModel } from "./cover-sheet";

export type Panel = "cover" | "write" | "page" | "templates" | "projects" | "preview";

type InspectorProps = {
  doc: ProjectDoc;
  panel: Panel;
  selectedId: string | null;
  projects: ProjectSummary[];
  family: Family | "all";
  templateCount: number;
  onFamily: (family: Family | "all") => void;
  onMore: () => void;
  onDoc: (recipe: (doc: ProjectDoc) => ProjectDoc) => void;
  onSelect: (id: string | null) => void;
  onOpen: (id: string) => void;
  onDeleteProject: (id: string) => void;
  onCreate: () => void;
  onDuplicate: () => void;
  onExport: () => void;
  onPickFiles: (targetId?: string) => void;
  onPickImage: (target: "cover" | string) => void;
  onInsertText: (text: string) => void;
};

const ADD: BlockKind[] = ["chapter", "heading", "text", "quote", "image", "file", "list", "pagebreak"];

export function Inspector(props: InspectorProps) {
  const { doc, panel } = props;
  return (
    <aside className="inspector" data-open={panel === "preview" ? "false" : "true"}>
      <div className="panel-title">{title(panel)}</div>
      {panel === "cover" ? <CoverPanel {...props} /> : null}
      {panel === "write" ? <WritePanel {...props} /> : null}
      {panel === "page" ? <PagePanel {...props} /> : null}
      {panel === "templates" ? <TemplatePanel {...props} /> : null}
      {panel === "projects" ? <ProjectsPanel {...props} /> : null}
      {panel === "preview" ? null : null}
    </aside>
  );
}

function title(panel: Panel) {
  switch (panel) {
    case "cover":
      return "الغلاف";
    case "write":
      return "الكتابة";
    case "page":
      return "الصفحة";
    case "templates":
      return "قوالب بلا نهاية";
    case "projects":
      return "مشاريعي";
    default:
      return "المعاينة";
  }
}

function CoverPanel({ doc, onDoc, onPickImage }: InspectorProps) {
  const model = coverModel(doc);
  const set = (patch: Partial<ProjectDoc["cover"]>) => onDoc((current) => ({ ...current, cover: { ...current.cover, ...patch }, updatedAt: Date.now() }));
  return (
    <div className="stack">
      <Field label="العنوان">
        <input value={doc.cover.title} onChange={(event) => set({ title: event.target.value })} />
      </Field>
      <Field label="العنوان الفرعي">
        <input value={doc.cover.subtitle} onChange={(event) => set({ subtitle: event.target.value })} />
      </Field>
      <Field label="المؤلف">
        <input value={doc.cover.author} onChange={(event) => set({ author: event.target.value })} />
      </Field>
      <div className="row">
        <button type="button" className="btn btn-primary" onClick={() => onPickImage("cover")}>
          صورة الغلاف
        </button>
        <button type="button" className="btn" onClick={() => set({ image: "" })} disabled={!doc.cover.image}>
          إزالة الصورة
        </button>
      </div>
      <p className="hint">الصورة تظهر خلف التدرج بوضوح، ويمكن استبدالها في أي وقت.</p>
      <div className="swatches">
        <Field label="لون ١">
          <input className="color" type="color" value={doc.cover.color1} onChange={(event) => set({ color1: event.target.value })} />
        </Field>
        <Field label="لون ٢">
          <input className="color" type="color" value={doc.cover.color2} onChange={(event) => set({ color2: event.target.value })} />
        </Field>
        <Field label="الورق">
          <input className="color" type="color" value={doc.cover.paper} onChange={(event) => set({ paper: event.target.value })} />
        </Field>
      </div>
      <Field label={`زاوية التدرج ${doc.cover.angle}°`}>
        <input type="range" min={0} max={360} value={doc.cover.angle} onChange={(event) => set({ angle: Number(event.target.value) })} />
      </Field>
      <div className="label">تكوين الغلاف</div>
      <div className="thumb-grid">
        {LAYOUTS.map((layout) => (
          <div
            key={layout}
            role="button"
            tabIndex={0}
            className={doc.cover.layout === layout ? "thumb is-on" : "thumb"}
            onClick={() => set({ layout })}
            onKeyDown={(event) => {
              if (event.key === "Enter" || event.key === " ") set({ layout });
            }}
          >
            <Thumb model={{ ...model, layout }} font={doc.settings.font} title={doc.cover.title} subtitle={doc.cover.subtitle} author={doc.cover.author} />
            <span>{LAYOUT_LABEL[layout]}</span>
          </div>
        ))}
      </div>
      <div className="label">النقش</div>
      <div className="chips">
        {PATTERNS.map((pattern) => (
          <button key={pattern} type="button" className={doc.cover.pattern === pattern ? "chip is-on" : "chip"} onClick={() => set({ pattern })}>
            {PATTERN_LABEL[pattern]}
          </button>
        ))}
      </div>
    </div>
  );
}

function WritePanel({ doc, selectedId, onDoc, onSelect, onPickImage, onPickFiles, onInsertText }: InspectorProps) {
  const [draft, setDraft] = useState("");
  const block = doc.blocks.find((item) => item.id === selectedId) ?? null;
  const patch = (id: string, partial: Partial<Block>) =>
    onDoc((current) => ({
      ...current,
      updatedAt: Date.now(),
      blocks: current.blocks.map((item) => (item.id === id ? { ...item, ...partial } : item)),
    }));
  const add = (kind: BlockKind) => {
    const next = createBlock(kind);
    onDoc((current) => {
      const blocks = current.blocks.slice();
      const index = selectedId ? blocks.findIndex((item) => item.id === selectedId) : blocks.length - 1;
      blocks.splice(Math.max(index, -1) + 1, 0, next);
      return { ...current, blocks, updatedAt: Date.now() };
    });
    onSelect(next.id);
    if (kind === "image") onPickImage(next.id);
    if (kind === "file") onPickFiles(next.id);
  };
  return (
    <div className="stack">
      <Field label="اكتب أو الصق">
        <textarea
          value={draft}
          rows={5}
          placeholder="الصق نصًا طويلًا هنا. سطر يبدأ بـ # يصبح فصلًا، و## عنوانًا، و> اقتباسًا. أسطر القائمة التي تبدأ بـ - تبقى قائمة."
          onChange={(event) => setDraft(event.target.value)}
          onPaste={(event) => {
            const text = event.clipboardData.getData("text/plain");
            if (text.includes("\n\n") || text.includes("\n#") || text.split("\n").length > 3) {
              event.preventDefault();
              onInsertText(text);
              setDraft("");
            }
          }}
        />
      </Field>
      <button
        type="button"
        className="btn btn-primary"
        onClick={() => {
          if (!draft.trim()) return;
          onInsertText(draft);
          setDraft("");
        }}
      >
        إدراج النص
      </button>
      <div className="add-grid">
        {ADD.map((kind) => (
          <button key={kind} type="button" className="btn" onClick={() => add(kind)}>
            {BLOCK_LABEL[kind]}
          </button>
        ))}
      </div>
      <div className="label">عناصر المستند</div>
      <div className="block-list-ui">
        {doc.blocks.map((item, index) => (
          <div key={item.id} className={item.id === selectedId ? "block-row is-on" : "block-row"}>
            <button type="button" className="block-name" onClick={() => onSelect(item.id)}>
              <span className="tabular">{index + 1}</span>
              {item.title?.trim() || item.fileName || BLOCK_LABEL[item.kind]}
            </button>
            <button type="button" className="icon-btn" aria-label="تحريك لأعلى" onClick={() => onDoc((current) => ({ ...current, blocks: moveBlock(current.blocks, item.id, -1), updatedAt: Date.now() }))}>
              ↑
            </button>
            <button type="button" className="icon-btn" aria-label="تحريك لأسفل" onClick={() => onDoc((current) => ({ ...current, blocks: moveBlock(current.blocks, item.id, 1), updatedAt: Date.now() }))}>
              ↓
            </button>
          </div>
        ))}
      </div>
      {block && block.kind !== "pagebreak" ? (
        <div className="stack editor">
          <div className="label">{BLOCK_LABEL[block.kind]}</div>
          {block.kind !== "image" && block.kind !== "file" && block.kind !== "text" && block.kind !== "quote" ? (
            <Field label="العنوان">
              <input value={block.title || ""} onChange={(event) => patch(block.id, { title: event.target.value })} />
            </Field>
          ) : null}
          {block.kind === "chapter" || block.kind === "heading" || block.kind === "text" || block.kind === "quote" ? (
            <Field label="النص">
              <textarea rows={8} value={block.text || ""} onChange={(event) => patch(block.id, { text: event.target.value })} />
            </Field>
          ) : null}
          {block.kind === "list" ? (
            <Field label="عنصر في كل سطر">
              <textarea rows={6} value={(block.items || []).join("\n")} onChange={(event) => patch(block.id, { items: event.target.value.split("\n") })} />
            </Field>
          ) : null}
          {block.kind === "image" ? (
            <>
              <button type="button" className="btn btn-primary" onClick={() => onPickImage(block.id)}>
                اختيار صورة
              </button>
              <Field label="تعليق">
                <input value={block.caption || ""} onChange={(event) => patch(block.id, { caption: event.target.value })} />
              </Field>
            </>
          ) : null}
          {block.kind === "file" ? (
            <>
              <button type="button" className="btn btn-primary" onClick={() => onPickFiles(block.id)}>
                اختيار ملف
              </button>
              <p className="hint">{block.fileName || "لم يُرفق ملف بعد"}</p>
            </>
          ) : null}
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => {
              onDoc((current) => ({ ...current, blocks: current.blocks.filter((item) => item.id !== block.id), updatedAt: Date.now() }));
              onSelect(null);
            }}
          >
            حذف العنصر
          </button>
        </div>
      ) : null}
    </div>
  );
}

function PagePanel({ doc, onDoc }: InspectorProps) {
  const set = (patch: Partial<ProjectDoc["settings"]>) => onDoc((current) => ({ ...current, settings: { ...current.settings, ...patch }, updatedAt: Date.now() }));
  return (
    <div className="stack">
      <div className="label">نوع المستند</div>
      <div className="type-grid">
        {DOC_TYPES.map((type) => (
          <button key={type} type="button" className={doc.type === type ? "choice is-on" : "choice"} onClick={() => onDoc((current) => ({ ...current, type: type as DocType, updatedAt: Date.now() }))}>
            {TYPE_LABEL[type]}
          </button>
        ))}
      </div>
      <Field label={`الهامش ${doc.settings.margin}`}>
        <input type="range" min={48} max={110} value={doc.settings.margin} onChange={(event) => set({ margin: Number(event.target.value) })} />
      </Field>
      <Field label={`حجم الخط ${doc.settings.fontSize}`}>
        <input type="range" min={14} max={26} value={doc.settings.fontSize} onChange={(event) => set({ fontSize: Number(event.target.value) })} />
      </Field>
      <Field label={`تباعد الأسطر ${doc.settings.lineHeight.toFixed(2)}`}>
        <input type="range" min={140} max={230} value={Math.round(doc.settings.lineHeight * 100)} onChange={(event) => set({ lineHeight: Number(event.target.value) / 100 })} />
      </Field>
      <label className="check">
        <input type="checkbox" checked={doc.settings.pageNumbers} onChange={(event) => set({ pageNumbers: event.target.checked })} />
        أرقام الصفحات
      </label>
      <div className="label">خط المتن</div>
      <div className="row">
        <button type="button" className={doc.settings.font === "amiri" ? "btn is-on" : "btn"} onClick={() => set({ font: "amiri" })}>
          أميري
        </button>
        <button type="button" className={doc.settings.font === "plex" ? "btn is-on" : "btn"} onClick={() => set({ font: "plex" })}>
          بلكس
        </button>
      </div>
      <div className="swatches">
        <Field label="حبر المتن">
          <input className="color" type="color" value={doc.settings.ink} onChange={(event) => set({ ink: event.target.value })} />
        </Field>
        <Field label="ورق الصفحات">
          <input className="color" type="color" value={doc.settings.paper} onChange={(event) => set({ paper: event.target.value })} />
        </Field>
        <Field label="لون الاقتباس">
          <input className="color" type="color" value={doc.settings.accent} onChange={(event) => set({ accent: event.target.value })} />
        </Field>
      </div>
    </div>
  );
}

function TemplatePanel({ doc, family, templateCount, onFamily, onMore, onDoc }: InspectorProps) {
  const seeds = useMemo(() => templateSeeds(family, 0, templateCount), [family, templateCount]);
  return (
    <div className="stack">
      <p className="hint">كل قالب بذرة مختلفة: ألوان، تكوين، ونقش. القائمة تكبر كلما طلبت المزيد، بلا سقف عملي.</p>
      <div className="chips">
        <button type="button" className={family === "all" ? "chip is-on" : "chip"} onClick={() => onFamily("all")}>
          الكل
        </button>
        {FAMILIES.map((item) => (
          <button key={item} type="button" className={family === item ? "chip is-on" : "chip"} onClick={() => onFamily(item)}>
            {FAMILY_LABEL[item]}
          </button>
        ))}
      </div>
      <div className="thumb-grid">
        {seeds.map((seed) => {
          const template = templateFromSeed(seed);
          const model = coverModel(doc, {
            layout: template.layout,
            pattern: template.pattern,
            color1: template.c1,
            color2: template.c2,
            paper: template.paper,
            angle: template.angle,
          });
          return (
            <div
              key={seed}
              role="button"
              tabIndex={0}
              className={doc.templateId === seed ? "thumb is-on" : "thumb"}
              onClick={() => onDoc((current) => applyTemplate(current, template))}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") onDoc((current) => applyTemplate(current, template));
              }}
            >
              <Thumb model={model} font={template.font} title={doc.cover.title} subtitle={doc.cover.subtitle} author={doc.cover.author} />
              <span>{template.name}</span>
            </div>
          );
        })}
      </div>
      <button type="button" className="btn" onClick={onMore}>
        المزيد من القوالب
      </button>
    </div>
  );
}


function ProjectsPanel({ doc, projects, onOpen, onDeleteProject, onCreate, onDuplicate, onExport }: InspectorProps) {
  const [pending, setPending] = useState<string | null>(null);
  return (
    <div className="stack">
      <div className="row">
        <button type="button" className="btn btn-primary" onClick={onCreate}>
          مستند جديد
        </button>
        <button type="button" className="btn" onClick={onDuplicate}>
          نسخ
        </button>
      </div>
      <button type="button" className="btn" onClick={onExport}>
        تنزيل نسخة JSON
      </button>
      <p className="hint">المشاريع محفوظة في حسابك. ملف JSON نسخة احتياطية يمكنك فتحها لاحقًا من زر الاستيراد.</p>
      {projects.length ? (
        projects.map((project) => (
          <div key={project.id} className={project.id === doc.id ? "project-row is-on" : "project-row"}>
            <button type="button" className="block-name" onClick={() => onOpen(project.id)}>
              <strong>{project.name}</strong>
              <span className="hint">{project.updatedAt.slice(0, 16).replace("T", " ")}</span>
            </button>
            {pending === project.id ? (
              <button type="button" className="btn btn-danger" onClick={() => onDeleteProject(project.id)}>
                تأكيد الحذف
              </button>
            ) : (
              <button type="button" className="icon-btn" aria-label="حذف المشروع" onClick={() => setPending(project.id)}>
                حذف
              </button>
            )}
          </div>
        ))
      ) : (
        <p className="empty-page">لا مشاريع بعد.</p>
      )}
    </div>
  );
}

function Thumb({
  model,
  font,
  title,
  subtitle,
  author,
}: {
  model: ReturnType<typeof coverModel>;
  font: "amiri" | "plex";
  title: string;
  subtitle: string;
  author: string;
}) {
  return (
    <div className="thumb-frame">
      <div className="thumb-scale">
        <CoverSheet model={model} font={font} title={title || "عنوان"} subtitle={subtitle} author={author} />
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
    </label>
  );
}

function createBlock(kind: BlockKind): Block {
  const id = crypto.randomUUID();
  switch (kind) {
    case "chapter":
      return { id, kind, title: "فصل جديد", text: "" };
    case "heading":
      return { id, kind, title: "عنوان جديد", text: "" };
    case "quote":
      return { id, kind, text: "" };
    case "image":
      return { id, kind, src: "", caption: "" };
    case "file":
      return { id, kind, src: "", fileName: "", caption: "" };
    case "list":
      return { id, kind, title: "", items: ["عنصر"] };
    case "pagebreak":
      return { id, kind };
    default:
      return { id, kind: "text", text: "" };
  }
}
