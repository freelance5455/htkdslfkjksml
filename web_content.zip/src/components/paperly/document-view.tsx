import { useEffect, useRef, useState } from "react";
import { CoverSheet, coverModel } from "./cover-sheet";
import { Editable } from "./editable";
import { formatBytes, type Block, type Page, type ProjectDoc, type RenderBlock } from "@/lib/paperly/model";

type DocumentViewProps = {
  doc: ProjectDoc;
  pages: Page[];
  zoom: number;
  selectedId: string | null;
  onSelect: (id: string) => void;
  onEdit: (id: string, patch: Partial<Block>) => void;
  onCover: (patch: Partial<ProjectDoc["cover"]>) => void;
  onPasteText: (sourceId: string, text: string) => boolean;
};

export function DocumentView({
  doc,
  pages,
  zoom,
  selectedId,
  onSelect,
  onEdit,
  onCover,
  onPasteText,
}: DocumentViewProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const pagesRef = useRef(pages);
  pagesRef.current = pages;
  const [held, setHeld] = useState<Page[] | null>(null);
  const shown = held ?? pages;
  const model = coverModel(doc);

  useEffect(() => {
    if (!selectedId) return;
    const node = rootRef.current?.querySelector(`[data-source="${CSS.escape(selectedId)}"]`);
    node?.scrollIntoView({ block: "nearest" });
  }, [selectedId]);

  const hold = () => setHeld(pagesRef.current);
  const release = () => setHeld(null);

  return (
    <div ref={rootRef} className="doc-zoom" id="paperly-doc" style={{ ["--zoom" as string]: String(zoom) }}>
      {shown.map((page, index) => {
        if (page.kind === "cover") {
          return (
            <CoverSheet
              key="cover"
              model={model}
              font={doc.settings.font}
              title={
                <Editable
                  className="editable"
                  value={doc.cover.title}
                  onChange={(title) => onCover({ title })}
                  onFocus={hold}
                  onBlur={release}
                />
              }
              subtitle={
                <Editable
                  className="editable"
                  value={doc.cover.subtitle}
                  onChange={(subtitle) => onCover({ subtitle })}
                  onFocus={hold}
                  onBlur={release}
                />
              }
              author={
                <Editable
                  className="editable"
                  value={doc.cover.author}
                  onChange={(author) => onCover({ author })}
                  onFocus={hold}
                  onBlur={release}
                />
              }
            />
          );
        }
        const pageNo = index + 1;
        if (page.kind === "toc") {
          return (
            <section
              key="toc"
              className={`sheet content font-${doc.settings.font}`}
              style={{ background: doc.settings.paper, color: doc.settings.ink }}
            >
              <div className="sheet-inner" style={{ padding: doc.settings.margin }}>
                <h2 className="toc-title">المحتويات</h2>
                {page.entries.length ? (
                  page.entries.map((entry) => (
                    <button key={entry.id} type="button" className="toc-row" onClick={() => onSelect(entry.id)}>
                      <span>{entry.title}</span>
                      <span className="tabular">{entry.page}</span>
                    </button>
                  ))
                ) : (
                  <p className="empty-page">أضف فصلًا أو عنوانًا ليظهر هنا.</p>
                )}
              </div>
              {doc.settings.pageNumbers ? <div className="page-number">{pageNo}</div> : null}
            </section>
          );
        }
        return (
          <section
            key={`p-${index}`}
            className={`sheet content font-${doc.settings.font}`}
            style={{ background: doc.settings.paper, color: doc.settings.ink, ["--accent" as string]: doc.settings.accent }}
          >
            <div
              className="sheet-inner"
              style={{
                padding: doc.settings.margin,
                fontSize: doc.settings.fontSize,
                lineHeight: doc.settings.lineHeight,
              }}
            >
              {page.blocks.length ? (
                page.blocks.map((block) => (
                  <BlockView
                    key={block.id}
                    block={block}
                    selected={selectedId === block.sourceId}
                    onSelect={() => onSelect(block.sourceId)}
                    onEdit={onEdit}
                    onFocus={hold}
                    onBlur={release}
                    onPasteText={onPasteText}
                  />
                ))
              ) : (
                <p className="empty-page">هذه الصفحة فارغة. أضف نصًا أو الصق من الحافظة.</p>
              )}
            </div>
            {doc.settings.pageNumbers ? <div className="page-number">{pageNo}</div> : null}
          </section>
        );
      })}
    </div>
  );
}

function BlockView({
  block,
  selected,
  onSelect,
  onEdit,
  onFocus,
  onBlur,
  onPasteText,
}: {
  block: RenderBlock;
  selected: boolean;
  onSelect: () => void;
  onEdit: (id: string, patch: Partial<Block>) => void;
  onFocus: () => void;
  onBlur: () => void;
  onPasteText: (sourceId: string, text: string) => boolean;
}) {
  const locked = Boolean(block.continued || block.continues);
  const edit = (patch: Partial<Block>) => onEdit(block.sourceId, patch);
  return (
    <div className={`block block-${block.kind}${selected ? " is-selected" : ""}`} data-source={block.sourceId} onClick={onSelect}>
      {block.continued ? <div className="cont-mark">يتبع</div> : null}
      {block.kind === "chapter" || block.kind === "heading" ? (
        <>
          {locked ? (
            block.title ? <div className="block-title">{block.title}</div> : null
          ) : (
            <Editable
              className="block-title editable"
              value={block.title || ""}
              onChange={(title) => edit({ title })}
              onFocus={onFocus}
              onBlur={onBlur}
            />
          )}
          <Body block={block} locked={locked} onEdit={edit} onFocus={onFocus} onBlur={onBlur} onPasteText={onPasteText} />
        </>
      ) : null}
      {block.kind === "text" || block.kind === "quote" ? (
        <Body block={block} locked={locked} onEdit={edit} onFocus={onFocus} onBlur={onBlur} onPasteText={onPasteText} quote={block.kind === "quote"} />
      ) : null}
      {block.kind === "list" ? (
        <div>
          {block.title ? <div className="block-title">{block.title}</div> : null}
          <ul className="block-list">
            {(block.items || []).map((item, index) => (
              <li key={`${block.id}-${index}`}>{item}</li>
            ))}
          </ul>
        </div>
      ) : null}
      {block.kind === "image" ? (
        <figure className="img-wrap">
          {block.src ? <img className="sheet-img" alt="" src={block.src} /> : <div className="img-missing">اختر صورة من لوحة الكتابة</div>}
          {block.caption ? <figcaption className="caption">{block.caption}</figcaption> : null}
        </figure>
      ) : null}
      {block.kind === "file" ? (
        <div className="file-card">
          <div>
            <strong>{block.fileName || "ملف"}</strong>
            <div className="caption">{formatBytes(block.fileSize || 0)}</div>
          </div>
          {block.src ? (
            <a href={block.src} download={block.fileName || "file"}>
              تنزيل
            </a>
          ) : (
            <span>بدون ملف</span>
          )}
        </div>
      ) : null}
      {block.continues ? <div className="cont-mark">تكملة في الصفحة التالية</div> : null}
    </div>
  );
}

function Body({
  block,
  locked,
  quote,
  onEdit,
  onFocus,
  onBlur,
  onPasteText,
}: {
  block: RenderBlock;
  locked: boolean;
  quote?: boolean;
  onEdit: (patch: Partial<Block>) => void;
  onFocus: () => void;
  onBlur: () => void;
  onPasteText: (sourceId: string, text: string) => boolean;
}) {
  const className = quote ? "block-quote editable" : "block-text editable";
  if (locked) return <div className={quote ? "block-quote" : "block-text"}>{block.text}</div>;
  return (
    <Editable
      className={className}
      value={block.text || ""}
      onChange={(text) => onEdit({ text })}
      onFocus={onFocus}
      onBlur={onBlur}
      onMultilinePaste={(text) => onPasteText(block.sourceId, text)}
    />
  );
}
