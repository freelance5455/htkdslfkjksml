import { useId, type CSSProperties, type ReactNode } from "react";
import type { ProjectDoc } from "@/lib/paperly/model";
import { TYPE_LABEL } from "@/lib/paperly/model";
import {
  contrastOn,
  isLayoutId,
  isPatternId,
  mixHex,
  type LayoutId,
  type PatternId,
} from "@/lib/paperly/templates";

export type CoverModel = {
  title: string;
  subtitle: string;
  author: string;
  kicker: string;
  image: string;
  layout: LayoutId;
  pattern: PatternId;
  color1: string;
  color2: string;
  paper: string;
  angle: number;
};

export function coverModel(doc: ProjectDoc, patch?: Partial<CoverModel>): CoverModel {
  return {
    title: doc.cover.title,
    subtitle: doc.cover.subtitle,
    author: doc.cover.author,
    kicker: TYPE_LABEL[doc.type],
    image: doc.cover.image.startsWith("data:image/") ? doc.cover.image : "",
    layout: isLayoutId(doc.cover.layout) ? doc.cover.layout : "center",
    pattern: isPatternId(doc.cover.pattern) ? doc.cover.pattern : "none",
    color1: doc.cover.color1,
    color2: doc.cover.color2,
    paper: doc.cover.paper,
    angle: doc.cover.angle,
    ...patch,
  };
}

function Pattern({ kind }: { kind: PatternId }) {
  const id = useId().replace(/:/g, "");
  if (kind === "none") return null;
  const common = { className: "cover-pattern", "aria-hidden": true as const };
  if (kind === "dots") {
    return (
      <svg {...common}>
        <defs>
          <pattern id={id} width="18" height="18" patternUnits="userSpaceOnUse">
            <circle cx="1.4" cy="1.4" r="1.15" fill="currentColor" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${id})`} />
      </svg>
    );
  }
  if (kind === "lines") {
    return (
      <svg {...common}>
        <defs>
          <pattern id={id} width="14" height="14" patternUnits="userSpaceOnUse">
            <path d="M0 14 L14 0" stroke="currentColor" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${id})`} />
      </svg>
    );
  }
  if (kind === "grid") {
    return (
      <svg {...common}>
        <defs>
          <pattern id={id} width="28" height="28" patternUnits="userSpaceOnUse">
            <path d="M28 0 H0 V28" fill="none" stroke="currentColor" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${id})`} />
      </svg>
    );
  }
  if (kind === "diamonds") {
    return (
      <svg {...common}>
        <defs>
          <pattern id={id} width="22" height="22" patternUnits="userSpaceOnUse">
            <path d="M11 1 L21 11 L11 21 L1 11 Z" fill="none" stroke="currentColor" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${id})`} />
      </svg>
    );
  }
  if (kind === "arcs") {
    return (
      <svg {...common}>
        <defs>
          <pattern id={id} width="36" height="18" patternUnits="userSpaceOnUse">
            <path d="M0 18 Q18 0 36 18" fill="none" stroke="currentColor" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${id})`} />
      </svg>
    );
  }
  if (kind === "rings") {
    return (
      <svg {...common}>
        <defs>
          <pattern id={id} width="32" height="32" patternUnits="userSpaceOnUse">
            <circle cx="16" cy="16" r="8" fill="none" stroke="currentColor" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${id})`} />
      </svg>
    );
  }
  if (kind === "cross") {
    return (
      <svg {...common}>
        <defs>
          <pattern id={id} width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M10 0 V20 M0 10 H20" stroke="currentColor" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${id})`} />
      </svg>
    );
  }
  return (
    <svg {...common}>
      <defs>
        <pattern id={id} width="40" height="16" patternUnits="userSpaceOnUse">
          <path d="M0 8 Q10 0 20 8 T40 8" fill="none" stroke="currentColor" strokeWidth="1" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${id})`} />
    </svg>
  );
}

function Copy({
  model,
  title,
  subtitle,
  author,
  long,
  showKicker = true,
  showAuthor = true,
}: {
  model: CoverModel;
  title: ReactNode;
  subtitle: ReactNode;
  author: ReactNode;
  long: boolean;
  showKicker?: boolean;
  showAuthor?: boolean;
}) {
  return (
    <div className="cover-copy">
      {showKicker ? <div className="cover-kicker">{model.kicker}</div> : null}
      <div className={long ? "cover-title is-long" : "cover-title"}>{title}</div>
      <div className="cover-sub">{subtitle}</div>
      {showAuthor ? <div className="cover-author">{author}</div> : null}
    </div>
  );
}

export function CoverSheet({
  model,
  font,
  title,
  subtitle,
  author,
}: {
  model: CoverModel;
  font: "amiri" | "plex";
  title: ReactNode;
  subtitle: ReactNode;
  author: ReactNode;
}) {
  const long = model.title.trim().length > 28;
  const style = {
    "--c1": model.color1,
    "--c2": model.color2,
    "--paper": model.paper,
    "--angle": `${model.angle}deg`,
    "--on-1": contrastOn(model.color1),
    "--on-2": contrastOn(model.color2),
    "--on-grad": contrastOn(mixHex(model.color1, model.color2)),
    "--on-paper": contrastOn(model.paper),
    background: model.paper,
  } as CSSProperties;
  const photo = model.image ? <div className="cover-photo" style={{ backgroundImage: `url("${model.image}")` }} /> : null;
  const pattern = <Pattern kind={model.pattern} />;
  const copy = <Copy model={model} title={title} subtitle={subtitle} author={author} long={long} />;
  let body: ReactNode;
  switch (model.layout) {
    case "band":
      body = (
        <>
          <div className="band-top">
            {photo}
            <div className="cover-wash" />
            {pattern}
          </div>
          <div className="band-bottom">{copy}</div>
        </>
      );
      break;
    case "split":
      body = (
        <div className="split">
          <div className="split-side">
            {pattern}
            <div className="cover-author">{author}</div>
          </div>
          <div className="split-main">
            {photo ? <div className="cover-photo is-faint" style={{ backgroundImage: `url("${model.image}")` }} /> : null}
            <Copy model={model} title={title} subtitle={subtitle} author={author} long={long} showAuthor={false} />
          </div>
        </div>
      );
      break;
    case "frame":
      body = (
        <>
          {pattern}
          <div className="frame-line">{copy}</div>
        </>
      );
      break;
    case "masthead":
      body = (
        <>
          <div className="mast-bar">
            <span>{model.kicker}</span>
            <span>{author}</span>
          </div>
          <div className="mast-main">
            <Copy model={model} title={title} subtitle={subtitle} author={author} long={long} showKicker={false} showAuthor={false} />
          </div>
          <div className="mast-rule" />
        </>
      );
      break;
    case "rail":
      body = (
        <>
          <div className="rail-bar" />
          <div className="rail-accent" />
          {pattern}
          <div className="cover-body">{copy}</div>
        </>
      );
      break;
    case "seal":
      body = (
        <>
          {photo}
          <div className="cover-wash" />
          {pattern}
          <div className="cover-body">
            <div className="seal-ring">{copy}</div>
          </div>
        </>
      );
      break;
    case "window":
      body = (
        <>
          <div className="window-frame" style={model.image ? { backgroundImage: `url("${model.image}")` } : undefined} />
          <div className="cover-body">{copy}</div>
        </>
      );
      break;
    case "poster":
      body = (
        <>
          {photo}
          <div className="cover-wash" />
          <div className="poster-block" />
          {pattern}
          <div className="cover-body">{copy}</div>
        </>
      );
      break;
    case "rules":
      body = (
        <div className="cover-body">
          <div className="cover-kicker">{model.kicker}</div>
          <div className="rule" />
          <div className={long ? "cover-title is-long" : "cover-title"}>{title}</div>
          <div className="rule" />
          <div className="cover-sub">{subtitle}</div>
          <div className="cover-author">{author}</div>
        </div>
      );
      break;
    case "blocks":
      body = (
        <>
          <div className="geo-a" />
          <div className="geo-b" />
          {pattern}
          <div className="cover-body">{copy}</div>
        </>
      );
      break;
    case "editorial":
      body = (
        <>
          <div className="ed-bar" />
          {pattern}
          <div className="cover-body">
            <div className="cover-kicker">{model.kicker}</div>
            <div>
              <div className={long ? "cover-title is-long" : "cover-title"}>{title}</div>
              <div className="cover-sub">{subtitle}</div>
            </div>
            <div className="cover-author">{author}</div>
          </div>
        </>
      );
      break;
    default:
      body = (
        <>
          {photo}
          <div className="cover-wash" />
          {pattern}
          <div className="cover-body">{copy}</div>
        </>
      );
  }
  return (
    <section dir="rtl" className={`sheet cover layout-${model.layout} font-${font}`} style={style}>
      {body}
    </section>
  );
}
