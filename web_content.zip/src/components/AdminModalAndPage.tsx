import { useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { signInWithPopup, signOut, type User } from 'firebase/auth';
import { doc, setDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import {
  ShieldCheck,
  UploadCloud,
  HelpCircle,
  Newspaper,
  Trash2,
  LogOut,
  X,
  Loader2,
  Check,
  AlertCircle,
  MessageSquareText,
  CheckCircle2,
  FlaskConical,
  RotateCcw,
  File as FileIcon,
} from 'lucide-react';
import {
  ADMIN_EMAIL,
  auth,
  db,
  googleProvider,
  OperationType,
  handleFirestoreError,
} from '../lib/firebase';
import {
  createSampleTestPdfFile,
  deleteFileBlob,
  deleteLocalFeedItem,
  formatFileSize,
  getFileBlobRecord,
  inferMimeFromFilename,
  readFileAsBlobWithProgress,
  saveBlobToIndexedDb,
  saveLocalFeedItem,
  uploadFileToIndexedDb,
  validateAdminFile,
} from '../lib/fileDb';
import type {
  Subject,
  WhatsNewItem,
  WhatsNewMediaType,
  WhatsNewTextKind,
} from '../types';
import { AdminButton } from './InteractiveButton';

interface AdminLoginModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function AdminLoginModal({ open, onClose, onSuccess }: AdminLoginModalProps) {
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleGoogleLogin = async () => {
    setErrorMsg(null);
    setLoading(true);
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      const email = (cred.user.email || '').toLowerCase();
      if (email !== ADMIN_EMAIL || !cred.user.emailVerified) {
        await signOut(auth);
        setErrorMsg('عذراً، هذا الحساب غير مصرح له بالدخول إلى لوحة المشرف.');
        return;
      }
      onSuccess();
      onClose();
    } catch (err) {
      const msg = err instanceof Error ? err.message : '';
      if (!msg.includes('popup-closed-by-user')) {
        setErrorMsg('تعذر تسجيل الدخول، تأكد من اتصال الإنترنت وحاول مرة أخرى.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-7 shadow-xl text-center relative"
          >
            <motion.button
              type="button"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onClose}
              aria-label="إغلاق"
              className="absolute top-4 left-4 min-w-[44px] min-h-[44px] rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer active:shadow-none"
            >
              <X className="w-5 h-5" />
            </motion.button>

            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-violet-50 dark:bg-violet-950 text-violet-700 dark:text-violet-300 flex items-center justify-center">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white mb-2">
              دخول المشرف
            </h2>
            <p className="text-slate-600 dark:text-slate-300 text-sm mb-6">
              هذه الصفحة مخصصة لمشرف المنصة فقط لنشر الملفات والنصوص والأخبار والأسئلة.
            </p>

            {errorMsg && (
              <div className="mb-5 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-sm font-bold flex items-center gap-2 text-right">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <AdminButton
              type="button"
              disabled={loading}
              onClick={handleGoogleLogin}
              className="w-full py-3.5 px-6 rounded-2xl bg-violet-600 hover:bg-violet-700 disabled:opacity-60 text-white font-bold text-base flex items-center justify-center gap-2 min-h-[48px]"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <ShieldCheck className="w-5 h-5" />
              )}
              <span>تسجيل الدخول بحساب Google للمشرف</span>
            </AdminButton>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface AdminPageProps {
  user: User;
  subjects: Subject[];
  items: WhatsNewItem[];
  onCloseAdmin: () => void;
  onFeedUpdated?: () => Promise<void> | void;
}

function extractReadableErrorMessage(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err || 'خطأ غير معروف');
  if (raw.startsWith('{')) {
    try {
      const parsed = JSON.parse(raw) as { error?: string };
      if (parsed.error) return parsed.error;
    } catch {
      // fall back to raw string
    }
  }
  return raw;
}

function stripExtension(name: string): string {
  const idx = name.lastIndexOf('.');
  return idx > 0 ? name.slice(0, idx) : name;
}

export function AdminPage({
  user,
  subjects,
  items,
  onCloseAdmin,
  onFeedUpdated,
}: AdminPageProps) {
  const adminTopRef = useRef<HTMLDivElement | null>(null);
  const filePickerRef = useRef<HTMLInputElement | null>(null);
  const newsImagePickerRef = useRef<HTMLInputElement | null>(null);
  const retryHandlerRef = useRef<(() => void) | null>(null);

  const [statusMsg, setStatusMsg] = useState<{
    type: 'ok' | 'err';
    text: string;
    canRetry?: boolean;
  } | null>(null);

  // Diagnostic Test Upload state ("تجربة رفع")
  const [testUploading, setTestUploading] = useState(false);
  const [testProgress, setTestProgress] = useState(0);
  const [testFileMeta, setTestFileMeta] = useState<{ name: string; size: number } | null>(null);
  const [testResult, setTestResult] = useState<{ ok: boolean; text: string } | null>(null);

  // Section 1: Upload File (FileReader -> Blob -> IndexedDB)
  const [fileTitle, setFileTitle] = useState('');
  const [fileSubject, setFileSubject] = useState(subjects[0]?.name || 'عام');
  const [fileMediaType, setFileMediaType] =
    useState<Exclude<WhatsNewMediaType, 'none'>>('pdf');
  const [fileInput, setFileInput] = useState<File | null>(null);
  const [stagedFileBlob, setStagedFileBlob] = useState<Blob | null>(null);
  const [fileReading, setFileReading] = useState(false);
  const [fileUploading, setFileUploading] = useState(false);
  const [fileProgress, setFileProgress] = useState<number>(0);
  const [fileUploadDone, setFileUploadDone] = useState(false);
  const [fileUploadError, setFileUploadError] = useState<string | null>(null);

  // Section 2: Publish Text
  const [textTitle, setTextTitle] = useState('');
  const [textKind, setTextKind] = useState<Exclude<WhatsNewTextKind, 'none'>>('ملخص');
  const [textSubject, setTextSubject] = useState('');
  const [textBody, setTextBody] = useState('');
  const [textPublishing, setTextPublishing] = useState(false);

  // Section 3: Publish News
  const [newsTitle, setNewsTitle] = useState('');
  const [newsDate, setNewsDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [newsImage, setNewsImage] = useState<File | null>(null);
  const [stagedNewsBlob, setStagedNewsBlob] = useState<Blob | null>(null);
  const [newsBody, setNewsBody] = useState('');
  const [newsPublishing, setNewsPublishing] = useState(false);
  const [newsProgress, setNewsProgress] = useState<number>(0);
  const [newsUploadDone, setNewsUploadDone] = useState(false);
  const [newsUploadError, setNewsUploadError] = useState<string | null>(null);

  // Section 4: Interactive Quiz
  const [quizTitle, setQuizTitle] = useState('');
  const [quizQuestion, setQuizQuestion] = useState('');
  const [quizOptions, setQuizOptions] = useState(['', '', '', '']);
  const [quizCorrectIndex, setQuizCorrectIndex] = useState(0);
  const [quizPublishing, setQuizPublishing] = useState(false);

  const createItemId = () => `item_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  const scrollToAdminTop = () => {
    adminTopRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  // Test Upload Handler ("تجربة رفع")
  const handleRunTestUpload = async () => {
    setTestUploading(true);
    setTestProgress(0);
    setTestResult(null);
    setStatusMsg(null);
    const sampleFile = createSampleTestPdfFile();
    setTestFileMeta({ name: sampleFile.name, size: sampleFile.size });

    try {
      const check = validateAdminFile(sampleFile);
      if (!check.valid) {
        throw new Error(check.error);
      }

      const testId = `test_${Date.now()}`;
      const blob = await readFileAsBlobWithProgress(sampleFile, setTestProgress);
      const idbUrl = await saveBlobToIndexedDb(
        testId,
        blob,
        sampleFile.name,
        sampleFile.type,
        setTestProgress
      );

      // Verify IndexedDB read-back succeeds
      const stored = await getFileBlobRecord(idbUrl);
      if (!stored || stored.blob.size !== sampleFile.size) {
        throw new Error('تعذر التحقق من الملف المحفوظ في IndexedDB');
      }

      // Clean up temporary test blob immediately so student feed stays clean
      await deleteFileBlob(idbUrl);

      setTestProgress(100);
      setTestResult({
        ok: true,
        text: 'تم رفع الملف بنجاح — تجربة الرفع شغالة والـ IndexedDB يحفظ ويقرأ الملفات بدون مشاكل.',
      });
      setStatusMsg({
        type: 'ok',
        text: 'تم رفع الملف بنجاح (تجربة الرفع شغالة بنجاح)',
      });
    } catch (err) {
      const reason = extractReadableErrorMessage(err);
      retryHandlerRef.current = handleRunTestUpload;
      setTestResult({
        ok: false,
        text: `حصل خطأ أثناء الرفع: ${reason}`,
      });
      setStatusMsg({
        type: 'err',
        text: `حصل خطأ أثناء الرفع: ${reason}`,
        canRetry: true,
      });
    } finally {
      setTestUploading(false);
    }
  };

  // Immediate file validation + FileReader -> Blob staging when picking a file
  const handleSelectUploadFile = async (selected: File | null) => {
    setFileUploadError(null);
    setFileUploadDone(false);
    setStatusMsg(null);
    setStagedFileBlob(null);
    setFileProgress(0);

    if (!selected) {
      setFileInput(null);
      return;
    }

    const validation = validateAdminFile(selected);
    if (!validation.valid) {
      setFileInput(null);
      if (filePickerRef.current) filePickerRef.current.value = '';
      setFileUploadError(validation.error);
      retryHandlerRef.current = () => {
        setFileUploadError(null);
        filePickerRef.current?.click();
      };
      return;
    }

    setFileInput(selected);
    setFileMediaType(validation.mediaType);
    if (!fileTitle.trim()) {
      setFileTitle(stripExtension(selected.name));
    }

    setFileReading(true);
    try {
      const blob = await readFileAsBlobWithProgress(selected, setFileProgress);
      setStagedFileBlob(blob);
      setFileProgress(100);
    } catch (err) {
      const reason = extractReadableErrorMessage(err);
      setFileInput(null);
      setStagedFileBlob(null);
      setFileUploadError(`حصل خطأ أثناء الرفع: ${reason}`);
      retryHandlerRef.current = () => {
        setFileUploadError(null);
        filePickerRef.current?.click();
      };
    } finally {
      setFileReading(false);
    }
  };

  // Execute Section 1 Publish (IndexedDB Blob + metadata + Firestore sync)
  const executePublishFile = async (
    targetFile: File,
    titleVal: string,
    subjectVal: string,
    mediaTypeVal: Exclude<WhatsNewMediaType, 'none'>,
    preReadBlob: Blob | null
  ) => {
    setFileUploading(true);
    setFileUploadError(null);
    setFileUploadDone(false);
    setStatusMsg(null);
    setFileProgress(10);

    try {
      const validation = validateAdminFile(targetFile);
      if (!validation.valid) {
        throw new Error(validation.error);
      }

      const itemId = createItemId();
      const uploaded = await uploadFileToIndexedDb(
        targetFile,
        itemId,
        setFileProgress,
        preReadBlob
      );

      const resolvedTitle = (titleVal.trim() || stripExtension(targetFile.name)).slice(0, 180);
      const resolvedSubject = (subjectVal.trim() || 'عام').slice(0, 120);
      const nowMs = Date.now();

      const newItem: WhatsNewItem = {
        id: itemId,
        title: resolvedTitle,
        description: '',
        category: 'file',
        textKind: 'none',
        subjectName: resolvedSubject,
        mediaType: mediaTypeVal,
        fileUrl: uploaded.fileUrl,
        fileName: uploaded.fileName.slice(0, 255),
        fileSize: Math.round(uploaded.size),
        newsDate: '',
        quizQuestion: '',
        quizOptions: [],
        quizCorrectIndex: -1,
        authorUid: user.uid,
        createdAtMs: nowMs,
      };

      // Persist metadata locally in IndexedDB so it's always resilient
      await saveLocalFeedItem(newItem);

      // Sync metadata to Firestore when online
      if (typeof navigator === 'undefined' || navigator.onLine) {
        const path = `whatsNew/${itemId}`;
        try {
          await setDoc(doc(db, 'whatsNew', itemId), {
            title: newItem.title,
            description: '',
            category: 'file',
            textKind: 'none',
            subjectName: newItem.subjectName,
            mediaType: newItem.mediaType,
            fileUrl: newItem.fileUrl,
            fileName: newItem.fileName,
            fileSize: newItem.fileSize,
            newsDate: '',
            quizQuestion: '',
            quizOptions: [],
            quizCorrectIndex: -1,
            authorUid: user.uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, path);
        }
      }

      await onFeedUpdated?.();

      setFileProgress(100);
      setFileUploadDone(true);
      setFileTitle('');
      setFileInput(null);
      setStagedFileBlob(null);
      if (filePickerRef.current) filePickerRef.current.value = '';

      setStatusMsg({ type: 'ok', text: 'تم رفع الملف بنجاح' });
      scrollToAdminTop();
    } catch (err) {
      const reason = extractReadableErrorMessage(err);
      const formatted =
        reason === 'الصيغة دي مش مدعومة' ||
        reason === 'الملف أكبر من 90 ميجا، ارفع ملف أصغر من 90 ميجا'
          ? reason
          : `حصل خطأ أثناء الرفع: ${reason}`;

      retryHandlerRef.current = () => {
        executePublishFile(targetFile, titleVal, subjectVal, mediaTypeVal, preReadBlob);
      };

      setFileUploadError(formatted);
      setStatusMsg({
        type: 'err',
        text: formatted,
        canRetry: true,
      });
    } finally {
      setFileUploading(false);
    }
  };

  // Section 1 Form Submit
  const handlePublishFile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fileInput || fileReading || fileUploading) return;
    await executePublishFile(
      fileInput,
      fileTitle,
      fileSubject,
      fileMediaType,
      stagedFileBlob
    );
  };

  // Section 2 Handler (Publish Text)
  const handlePublishText = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!textTitle.trim() || !textBody.trim()) return;
    setTextPublishing(true);
    setStatusMsg(null);

    try {
      const itemId = createItemId();
      const nowMs = Date.now();
      const newItem: WhatsNewItem = {
        id: itemId,
        title: textTitle.trim().slice(0, 180),
        description: textBody.trim().slice(0, 5000),
        category: 'text',
        textKind,
        subjectName: textSubject.trim().slice(0, 120),
        mediaType: 'none',
        fileUrl: '',
        fileName: '',
        fileSize: 0,
        newsDate: '',
        quizQuestion: '',
        quizOptions: [],
        quizCorrectIndex: -1,
        authorUid: user.uid,
        createdAtMs: nowMs,
      };

      await saveLocalFeedItem(newItem);

      if (typeof navigator === 'undefined' || navigator.onLine) {
        const path = `whatsNew/${itemId}`;
        try {
          await setDoc(doc(db, 'whatsNew', itemId), {
            title: newItem.title,
            description: newItem.description,
            category: 'text',
            textKind,
            subjectName: newItem.subjectName,
            mediaType: 'none',
            fileUrl: '',
            fileName: '',
            fileSize: 0,
            newsDate: '',
            quizQuestion: '',
            quizOptions: [],
            quizCorrectIndex: -1,
            authorUid: user.uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, path);
        }
      }

      await onFeedUpdated?.();

      setTextTitle('');
      setTextSubject('');
      setTextBody('');
      setStatusMsg({ type: 'ok', text: 'تم نشر النص بنجاح في قسم «نصوص وشروحات»!' });
      scrollToAdminTop();
    } catch (err) {
      const reason = extractReadableErrorMessage(err);
      setStatusMsg({
        type: 'err',
        text: `حصل خطأ أثناء الرفع: ${reason}`,
      });
    } finally {
      setTextPublishing(false);
    }
  };

  // News Image picker with FileReader -> Blob validation
  const handleSelectNewsImage = async (selected: File | null) => {
    setNewsUploadError(null);
    setNewsUploadDone(false);
    setNewsProgress(0);
    setStagedNewsBlob(null);

    if (!selected) {
      setNewsImage(null);
      return;
    }

    const validation = validateAdminFile(selected, { imagesOnly: true });
    if (!validation.valid) {
      setNewsImage(null);
      if (newsImagePickerRef.current) newsImagePickerRef.current.value = '';
      setNewsUploadError(validation.error);
      return;
    }

    setNewsImage(selected);
    try {
      const blob = await readFileAsBlobWithProgress(selected, setNewsProgress);
      setStagedNewsBlob(blob);
      setNewsProgress(100);
    } catch (err) {
      setNewsImage(null);
      setStagedNewsBlob(null);
      setNewsUploadError(`حصل خطأ أثناء الرفع: ${extractReadableErrorMessage(err)}`);
    }
  };

  // Section 3 Handler (Publish News)
  const handlePublishNews = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsTitle.trim() || !newsBody.trim()) return;
    setNewsPublishing(true);
    setNewsUploadError(null);
    setNewsUploadDone(false);
    setStatusMsg(null);

    try {
      const itemId = createItemId();
      let fileUrl = '';
      let fileName = '';
      let fileSize = 0;

      if (newsImage) {
        const uploaded = await uploadFileToIndexedDb(
          newsImage,
          `${itemId}_img`,
          setNewsProgress,
          stagedNewsBlob
        );
        fileUrl = uploaded.fileUrl;
        fileName = uploaded.fileName;
        fileSize = Math.round(uploaded.size);
        setNewsUploadDone(true);
      }

      const newItem: WhatsNewItem = {
        id: itemId,
        title: newsTitle.trim().slice(0, 180),
        description: newsBody.trim().slice(0, 5000),
        category: 'news',
        textKind: 'none',
        subjectName: '',
        mediaType: fileUrl ? 'image' : 'none',
        fileUrl,
        fileName: fileName.slice(0, 255),
        fileSize,
        newsDate: newsDate.slice(0, 40),
        quizQuestion: '',
        quizOptions: [],
        quizCorrectIndex: -1,
        authorUid: user.uid,
        createdAtMs: Date.now(),
      };

      await saveLocalFeedItem(newItem);

      if (typeof navigator === 'undefined' || navigator.onLine) {
        const path = `whatsNew/${itemId}`;
        try {
          await setDoc(doc(db, 'whatsNew', itemId), {
            title: newItem.title,
            description: newItem.description,
            category: 'news',
            textKind: 'none',
            subjectName: '',
            mediaType: newItem.mediaType,
            fileUrl: newItem.fileUrl,
            fileName: newItem.fileName,
            fileSize: newItem.fileSize,
            newsDate: newItem.newsDate,
            quizQuestion: '',
            quizOptions: [],
            quizCorrectIndex: -1,
            authorUid: user.uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, path);
        }
      }

      await onFeedUpdated?.();

      setNewsTitle('');
      setNewsImage(null);
      setStagedNewsBlob(null);
      if (newsImagePickerRef.current) newsImagePickerRef.current.value = '';
      setNewsBody('');
      setStatusMsg({ type: 'ok', text: 'تم نشر الخبر بنجاح في قسم «ما الجديد»!' });
      scrollToAdminTop();
    } catch (err) {
      const reason = extractReadableErrorMessage(err);
      const formatted = `حصل خطأ أثناء الرفع: ${reason}`;
      setNewsUploadError(formatted);
      setStatusMsg({ type: 'err', text: formatted });
    } finally {
      setNewsPublishing(false);
    }
  };

  // Section 4 Handler (Quiz)
  const handlePublishQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quizTitle.trim() || !quizQuestion.trim()) return;
    if (quizOptions.some((o) => !o.trim())) {
      setStatusMsg({ type: 'err', text: 'يرجى تعبئة جميع الخيارات الأربعة.' });
      return;
    }

    setQuizPublishing(true);
    setStatusMsg(null);

    try {
      const itemId = createItemId();
      const newItem: WhatsNewItem = {
        id: itemId,
        title: quizTitle.trim().slice(0, 180),
        description: '',
        category: 'quiz',
        textKind: 'none',
        subjectName: '',
        mediaType: 'none',
        fileUrl: '',
        fileName: '',
        fileSize: 0,
        newsDate: '',
        quizQuestion: quizQuestion.trim().slice(0, 600),
        quizOptions: quizOptions.map((o) => o.trim().slice(0, 300)),
        quizCorrectIndex,
        authorUid: user.uid,
        createdAtMs: Date.now(),
      };

      await saveLocalFeedItem(newItem);

      if (typeof navigator === 'undefined' || navigator.onLine) {
        const path = `whatsNew/${itemId}`;
        try {
          await setDoc(doc(db, 'whatsNew', itemId), {
            title: newItem.title,
            description: '',
            category: 'quiz',
            textKind: 'none',
            subjectName: '',
            mediaType: 'none',
            fileUrl: '',
            fileName: '',
            fileSize: 0,
            newsDate: '',
            quizQuestion: newItem.quizQuestion,
            quizOptions: newItem.quizOptions,
            quizCorrectIndex,
            authorUid: user.uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, path);
        }
      }

      await onFeedUpdated?.();

      setQuizTitle('');
      setQuizQuestion('');
      setQuizOptions(['', '', '', '']);
      setQuizCorrectIndex(0);
      setStatusMsg({ type: 'ok', text: 'تم نشر السؤال التفاعلي بنجاح!' });
      scrollToAdminTop();
    } catch (err) {
      const reason = extractReadableErrorMessage(err);
      setStatusMsg({
        type: 'err',
        text: `حصل خطأ أثناء الرفع: ${reason}`,
      });
    } finally {
      setQuizPublishing(false);
    }
  };

  const handleDeleteItem = async (item: WhatsNewItem) => {
    setStatusMsg(null);
    try {
      if (item.fileUrl && item.fileUrl.startsWith('idb://')) {
        await deleteFileBlob(item.fileUrl);
      } else if (item.fileUrl && item.fileUrl.startsWith('/uploads/')) {
        const storedName = item.fileUrl.split('/').pop() || '';
        if (storedName) {
          const idToken = await user.getIdToken();
          await fetch(`/api/upload/${encodeURIComponent(storedName)}`, {
            method: 'DELETE',
            headers: {
              Authorization: `Bearer ${idToken}`,
            },
          });
        }
      }

      await deleteLocalFeedItem(item.id);

      if (typeof navigator === 'undefined' || navigator.onLine) {
        const path = `whatsNew/${item.id}`;
        try {
          await deleteDoc(doc(db, 'whatsNew', item.id));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, path);
        }
      }

      await onFeedUpdated?.();
      setStatusMsg({ type: 'ok', text: 'تم حذف العنصر بنجاح.' });
    } catch (err) {
      setStatusMsg({
        type: 'err',
        text: extractReadableErrorMessage(err) || 'تعذر حذف العنصر.',
      });
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    onCloseAdmin();
  };

  // Keep inferMimeFromFilename referenced cleanly if needed for future extensions
  void inferMimeFromFilename;

  return (
    <section ref={adminTopRef} className="space-y-6 sm:space-y-8">
      {/* Executive Header */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-5 sm:p-7 flex flex-wrap items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-slate-900 dark:bg-violet-600 text-white flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-display text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              لوحة تحكم المشرف
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">{user.email}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <AdminButton
            type="button"
            disabled={testUploading}
            onClick={handleRunTestUpload}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-violet-600 hover:bg-violet-700 disabled:opacity-60 text-white text-sm font-bold min-h-[44px]"
          >
            {testUploading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <FlaskConical className="w-4 h-4" />
            )}
            <span>تجربة رفع</span>
          </AdminButton>

          <AdminButton
            type="button"
            onClick={handleLogout}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-rose-50 dark:bg-rose-950/70 hover:bg-rose-100 dark:hover:bg-rose-900 text-rose-700 dark:text-rose-300 text-sm font-bold min-h-[44px]"
          >
            <LogOut className="w-4 h-4" />
            <span>تسجيل خروج</span>
          </AdminButton>
        </div>
      </div>

      {/* Diagnostic Test Upload Live Card */}
      {(testUploading || testResult) && testFileMeta && (
        <div
          className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
            testResult?.ok === false
              ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800'
              : testResult?.ok
                ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
          }`}
        >
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs sm:text-sm font-bold">
            <div className="flex items-center gap-2 text-slate-800 dark:text-slate-100">
              {testResult?.ok ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              ) : testResult?.ok === false ? (
                <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0" />
              ) : (
                <Loader2 className="w-4 h-4 animate-spin text-violet-600 shrink-0" />
              )}
              <span>{testFileMeta.name}</span>
              <span className="text-slate-500 dark:text-slate-400 font-mono-num">
                ({formatFileSize(testFileMeta.size)})
              </span>
            </div>
            <span className="font-mono-num text-violet-700 dark:text-violet-300">
              {testProgress}%
            </span>
          </div>

          <div className="w-full h-2.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-200 ${
                testResult?.ok === false
                  ? 'bg-rose-500'
                  : testResult?.ok
                    ? 'bg-emerald-500'
                    : 'bg-violet-600'
              }`}
              style={{ width: `${testProgress}%` }}
            />
          </div>

          {testResult && (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p
                className={`text-xs sm:text-sm font-bold ${
                  testResult.ok
                    ? 'text-emerald-800 dark:text-emerald-200'
                    : 'text-rose-800 dark:text-rose-200'
                }`}
              >
                {testResult.text}
              </p>
              {!testResult.ok && (
                <AdminButton
                  type="button"
                  onClick={handleRunTestUpload}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold min-h-[38px]"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>حاول مرة تانية</span>
                </AdminButton>
              )}
            </div>
          )}
        </div>
      )}

      {/* Global Status Banner */}
      {statusMsg && (
        <div
          className={`p-4 rounded-2xl border font-bold text-sm flex flex-wrap items-center justify-between gap-3 ${
            statusMsg.type === 'ok'
              ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusMsg.type === 'ok' ? (
              <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
            ) : (
              <AlertCircle className="w-5 h-5 shrink-0" />
            )}
            <span>{statusMsg.text}</span>
          </div>

          {statusMsg.type === 'err' && statusMsg.canRetry && retryHandlerRef.current && (
            <AdminButton
              type="button"
              onClick={() => retryHandlerRef.current?.()}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold min-h-[38px]"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>حاول مرة تانية</span>
            </AdminButton>
          )}
        </div>
      )}

      {/* 3 Separate Independent Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Section 1: رفع ملفات */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 sm:p-7 shadow-xs space-y-5">
          <div className="flex items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-violet-50 dark:bg-violet-950/70 text-violet-700 dark:text-violet-300 flex items-center justify-center shrink-0">
                <UploadCloud className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
                  ١. رفع ملفات
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  يظهر في «ملفات وتلخيصات» (حتى 90 ميجا)
                </p>
              </div>
            </div>
          </div>

          <form onSubmit={handlePublishFile} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                عنوان الملف
              </label>
              <input
                type="text"
                required
                value={fileTitle}
                onChange={(e) => setFileTitle(e.target.value)}
                placeholder="مثال: مذكرة الفصل الثاني"
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:border-violet-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                المادة
              </label>
              <input
                type="text"
                required
                list="admin-subject-options"
                value={fileSubject}
                onChange={(e) => setFileSubject(e.target.value)}
                placeholder="اختر أو اكتب اسم المادة"
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:border-violet-500 outline-none"
              />
              <datalist id="admin-subject-options">
                {subjects.map((s) => (
                  <option key={s.id} value={s.name} />
                ))}
                <option value="الرياضيات" />
                <option value="الفيزياء" />
                <option value="الكيمياء" />
                <option value="الأحياء" />
                <option value="اللغة العربية" />
                <option value="اللغة الإنجليزية" />
              </datalist>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                اختر الملف (PDF - Word - PowerPoint - Excel - صورة - فيديو - صوت)
              </label>
              <input
                ref={filePickerRef}
                type="file"
                required={!fileInput}
                accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.csv,image/*,video/*,audio/*"
                onChange={(e) => {
                  const f = e.target.files?.[0] || null;
                  handleSelectUploadFile(f);
                }}
                className="w-full px-3.5 py-2.5 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-700 dark:text-slate-200 cursor-pointer"
              />
            </div>

            {/* Selected File Preview + Immediate Progress Bar (0 -> 100%) */}
            {(fileInput || fileReading || fileUploading || fileUploadDone) && (
              <div className="space-y-2 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
                {fileInput && (
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <FileIcon className="w-4 h-4 text-violet-600 dark:text-violet-400 shrink-0" />
                      <span className="font-bold text-slate-800 dark:text-slate-100 truncate">
                        {fileInput.name}
                      </span>
                    </div>
                    <span className="font-mono-num text-slate-500 dark:text-slate-400 shrink-0">
                      {formatFileSize(fileInput.size)}
                    </span>
                  </div>
                )}

                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                    {fileUploadDone ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                        <span className="text-emerald-600 dark:text-emerald-400">
                          تم رفع الملف بنجاح
                        </span>
                      </>
                    ) : fileUploading ? (
                      <span>جاري الحفظ في IndexedDB...</span>
                    ) : fileReading ? (
                      <span>جاري قراءة الملف...</span>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-violet-600 dark:text-violet-400 shrink-0" />
                        <span className="text-violet-700 dark:text-violet-300">
                          جاهز للنشر
                        </span>
                      </>
                    )}
                  </span>
                  <span className="font-mono-num text-violet-700 dark:text-violet-400">
                    {fileProgress}%
                  </span>
                </div>

                <div className="w-full h-2.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-200 ${
                      fileUploadDone ? 'bg-emerald-500' : 'bg-violet-600'
                    }`}
                    style={{ width: `${fileProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Inline Upload Error + Retry Button */}
            {fileUploadError && (
              <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 space-y-2.5">
                <div className="flex items-start gap-2 text-xs sm:text-sm font-bold">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{fileUploadError}</span>
                </div>
                {retryHandlerRef.current && (
                  <AdminButton
                    type="button"
                    onClick={() => retryHandlerRef.current?.()}
                    className="w-full py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 min-h-[38px]"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>
                      {fileUploadError === 'الصيغة دي مش مدعومة' ||
                      fileUploadError === 'الملف أكبر من 90 ميجا، ارفع ملف أصغر من 90 ميجا'
                        ? 'اختار ملف تاني'
                        : 'حاول مرة تانية'}
                    </span>
                  </AdminButton>
                )}
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                تصنيف الملف
              </label>
              <select
                value={fileMediaType}
                onChange={(e) =>
                  setFileMediaType(e.target.value as Exclude<WhatsNewMediaType, 'none'>)
                }
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm outline-none"
              >
                <option value="pdf">PDF</option>
                <option value="word">Word</option>
                <option value="powerpoint">PowerPoint</option>
                <option value="excel">Excel</option>
                <option value="image">صورة</option>
                <option value="video">فيديو</option>
                <option value="audio">ملف صوتي</option>
              </select>
            </div>

            <AdminButton
              type="submit"
              disabled={!fileInput || fileReading || fileUploading}
              className="w-full py-3 px-5 rounded-2xl bg-slate-900 dark:bg-violet-600 hover:bg-slate-800 dark:hover:bg-violet-700 disabled:opacity-60 text-white font-bold text-sm flex items-center justify-center gap-2 min-h-[46px]"
            >
              {(fileUploading || fileReading) && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>نشر</span>
            </AdminButton>
          </form>
        </div>

        {/* Section 2: نشر نص */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 sm:p-7 shadow-xs space-y-5">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="w-11 h-11 rounded-2xl bg-orange-50 dark:bg-orange-950/70 text-orange-600 dark:text-orange-400 flex items-center justify-center shrink-0">
              <MessageSquareText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
                ٢. نشر نص
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                يظهر في «نصوص وشروحات» بدفتر الملاحظات
              </p>
            </div>
          </div>

          <form onSubmit={handlePublishText} className="space-y-4">
            <div>
              <span className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                نوع النص
              </span>
              <div className="grid grid-cols-3 gap-2">
                {(['ملخص', 'تنبيه', 'شرح'] as const).map((kind) => (
                  <AdminButton
                    key={kind}
                    type="button"
                    onClick={() => setTextKind(kind)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold min-h-[40px] ${
                      textKind === kind
                        ? 'bg-orange-500 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 shadow-none'
                    }`}
                  >
                    {kind}
                  </AdminButton>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                العنوان
              </label>
              <input
                type="text"
                required
                value={textTitle}
                onChange={(e) => setTextTitle(e.target.value)}
                placeholder="مثال: شرح قاعدة السلسلة"
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:border-orange-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                المادة (اختياري)
              </label>
              <input
                type="text"
                value={textSubject}
                onChange={(e) => setTextSubject(e.target.value)}
                placeholder="مثال: الرياضيات"
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:border-orange-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                النص المكتوب
              </label>
              <textarea
                rows={5}
                required
                value={textBody}
                onChange={(e) => setTextBody(e.target.value)}
                placeholder="اكتب الملخص أو الشرح أو التنبيه هنا..."
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:border-orange-500 outline-none resize-y"
              />
            </div>

            <AdminButton
              type="submit"
              disabled={textPublishing}
              className="w-full py-3 px-5 rounded-2xl bg-orange-500 hover:bg-orange-600 disabled:opacity-60 text-white font-bold text-sm flex items-center justify-center gap-2 min-h-[46px]"
            >
              {textPublishing && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>نشر</span>
            </AdminButton>
          </form>
        </div>

        {/* Section 3: نشر أخبار */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 sm:p-7 shadow-xs space-y-5">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="w-11 h-11 rounded-2xl bg-blue-50 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
              <Newspaper className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
                ٣. نشر أخبار
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                يظهر في قسم «ما الجديد» للطالب
              </p>
            </div>
          </div>

          <form onSubmit={handlePublishNews} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                عنوان الخبر
              </label>
              <input
                type="text"
                required
                value={newsTitle}
                onChange={(e) => setNewsTitle(e.target.value)}
                placeholder="مثال: مواعيد المراجعة النهائية"
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:border-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                تاريخ الخبر
              </label>
              <input
                type="date"
                required
                value={newsDate}
                onChange={(e) => setNewsDate(e.target.value)}
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-mono-num focus:border-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                صورة للخبر (اختياري)
              </label>
              <input
                ref={newsImagePickerRef}
                type="file"
                accept="image/*"
                onChange={(e) => handleSelectNewsImage(e.target.files?.[0] || null)}
                className="w-full px-3.5 py-2.5 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-700 dark:text-slate-200 cursor-pointer"
              />
            </div>

            {(newsImage || newsPublishing || newsUploadDone) && (
              <div className="space-y-1.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
                {newsImage && (
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-bold text-slate-700 dark:text-slate-200 truncate">
                      {newsImage.name}
                    </span>
                    <span className="font-mono-num text-slate-500 shrink-0">
                      {formatFileSize(newsImage.size)}
                    </span>
                  </div>
                )}
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                    {newsUploadDone ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        <span className="text-emerald-600 dark:text-emerald-400">
                          تم رفع الصورة بنجاح
                        </span>
                      </>
                    ) : newsPublishing ? (
                      <span>جاري حفظ الصورة...</span>
                    ) : (
                      <span>الصورة جاهزة</span>
                    )}
                  </span>
                  <span className="font-mono-num text-blue-600 dark:text-blue-400">
                    {newsProgress}%
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-200 ${
                      newsUploadDone ? 'bg-emerald-500' : 'bg-blue-600'
                    }`}
                    style={{ width: `${newsProgress}%` }}
                  />
                </div>
              </div>
            )}

            {newsUploadError && (
              <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs font-bold space-y-2">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{newsUploadError}</span>
                </div>
                <AdminButton
                  type="button"
                  onClick={() => {
                    setNewsUploadError(null);
                    newsImagePickerRef.current?.click();
                  }}
                  className="w-full py-1.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 min-h-[34px]"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>اختار ملف تاني</span>
                </AdminButton>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                نص الخبر
              </label>
              <textarea
                rows={4}
                required
                value={newsBody}
                onChange={(e) => setNewsBody(e.target.value)}
                placeholder="اكتب تفاصيل الخبر..."
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:border-blue-500 outline-none resize-y"
              />
            </div>

            <AdminButton
              type="submit"
              disabled={newsPublishing}
              className="w-full py-3 px-5 rounded-2xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-bold text-sm flex items-center justify-center gap-2 min-h-[46px]"
            >
              {newsPublishing && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>نشر</span>
            </AdminButton>
          </form>
        </div>
      </div>

      {/* Section 4 + Published Items List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Interactive Quiz Card */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 sm:p-7 shadow-xs space-y-5">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="w-11 h-11 rounded-2xl bg-emerald-50 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
                نشر سؤال تفاعلي
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                يزيد من شريط تقدم الطالب عند الإجابة الصحيحة
              </p>
            </div>
          </div>

          <form onSubmit={handlePublishQuiz} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                عنوان السؤال / المادة
              </label>
              <input
                type="text"
                required
                value={quizTitle}
                onChange={(e) => setQuizTitle(e.target.value)}
                placeholder="مثال: اختبار سريع - الفيزياء"
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                نص السؤال
              </label>
              <textarea
                rows={2}
                required
                value={quizQuestion}
                onChange={(e) => setQuizQuestion(e.target.value)}
                placeholder="اكتب السؤال هنا..."
                className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm outline-none"
              />
            </div>

            <div className="space-y-2">
              <span className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                الخيارات الأربعة (حدد الإجابة الصحيحة)
              </span>
              {quizOptions.map((opt, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <motion.button
                    type="button"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setQuizCorrectIndex(idx)}
                    aria-label={`تحديد الخيار ${idx + 1} كإجابة صحيحة`}
                    className={`min-w-[40px] min-h-[40px] rounded-xl border-2 flex items-center justify-center shrink-0 cursor-pointer transition-colors shadow-xs active:shadow-none ${
                      quizCorrectIndex === idx
                        ? 'bg-emerald-500 border-emerald-500 text-white'
                        : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Check className="w-4 h-4" />
                  </motion.button>
                  <input
                    type="text"
                    required
                    value={opt}
                    onChange={(e) => {
                      const next = [...quizOptions];
                      next[idx] = e.target.value;
                      setQuizOptions(next);
                    }}
                    placeholder={`الخيار ${idx + 1}`}
                    className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm outline-none"
                  />
                </div>
              ))}
            </div>

            <AdminButton
              type="submit"
              disabled={quizPublishing}
              className="w-full py-3 px-5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white font-bold text-sm flex items-center justify-center gap-2 min-h-[46px]"
            >
              {quizPublishing && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>نشر</span>
            </AdminButton>
          </form>
        </div>

        {/* Published Items Manager */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 sm:p-7 shadow-xs space-y-4">
          <h2 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
            المنشورات الحالية ({items.length})
          </h2>

          {items.length === 0 ? (
            <p className="text-slate-500 dark:text-slate-400 text-sm py-8 text-center">
              لم يتم نشر أي محتوى بعد.
            </p>
          ) : (
            <div className="space-y-3 max-h-[430px] overflow-y-auto pl-1">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <p className="font-bold text-slate-900 dark:text-white text-sm truncate">
                      {item.title}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {item.category === 'file' || item.category === 'summary'
                        ? `ملف (${item.mediaType.toUpperCase()}) · ${item.subjectName || 'عام'}`
                        : item.category === 'text'
                          ? `نص (${item.textKind !== 'none' ? item.textKind : 'شرح'})`
                          : item.category === 'quiz'
                            ? 'سؤال تفاعلي'
                            : `خبر · ${item.newsDate || ''}`}
                    </p>
                  </div>

                  <AdminButton
                    type="button"
                    onClick={() => handleDeleteItem(item)}
                    aria-label={`حذف ${item.title}`}
                    className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 shrink-0 shadow-none"
                  >
                    <Trash2 className="w-4 h-4" />
                  </AdminButton>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
