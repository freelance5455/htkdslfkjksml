import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import type { DecodedPageAsset, FitMode } from '../types/comic';

export interface CurlTurnParams {
  frontPage: DecodedPageAsset | null;
  backPage: DecodedPageAsset | null;
  curlEdge: 'right' | 'left';
  fromProgress: number;
  toProgress: number;
  anchorYRatio: number;
  durationMs?: number;
  onComplete?: () => void;
}

export interface LiveCurlParams {
  frontPage: DecodedPageAsset | null;
  backPage: DecodedPageAsset | null;
  curlEdge: 'right' | 'left';
  progress: number;
  anchorYRatio: number;
}

export interface PageCurlStageHandle {
  animateTurn: (params: CurlTurnParams) => void;
  renderLive: (params: LiveCurlParams) => void;
  clear: () => void;
}

interface PageCurlStageProps {
  viewportWidth: number;
  viewportHeight: number;
  fitMode: FitMode;
  zoomMultiplier: number;
  readerBg: string;
}

interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

const imageElementCache = new Map<string, HTMLImageElement>();

function getOrLoadImage(url: string, onLoad: () => void): HTMLImageElement | null {
  const cached = imageElementCache.get(url);
  if (cached) {
    if (cached.complete && cached.naturalWidth > 0) {
      return cached;
    }
    return null;
  }

  const img = new Image();
  img.decoding = 'async';
  img.onload = () => {
    onLoad();
  };
  img.src = url;
  imageElementCache.set(url, img);

  if (imageElementCache.size > 48) {
    const oldestKey = imageElementCache.keys().next().value;
    if (oldestKey) imageElementCache.delete(oldestKey);
  }

  return img.complete && img.naturalWidth > 0 ? img : null;
}

export function preloadCurlAsset(asset: DecodedPageAsset | null | undefined): void {
  if (!asset) return;
  for (const tile of asset.tiles) {
    getOrLoadImage(tile.url, () => {});
  }
}

function computeFittedRect(
  asset: DecodedPageAsset,
  viewW: number,
  viewH: number,
  fitMode: FitMode,
  zoomMultiplier: number,
): Rect {
  const natW = Math.max(1, asset.width);
  const natH = Math.max(1, asset.height);

  let baseW = natW;
  let baseH = natH;

  if (fitMode === 'fit-width') {
    baseW = Math.min(viewW, 1024);
    baseH = baseW * (natH / natW);
  } else if (fitMode === 'fit-height') {
    baseH = viewH;
    baseW = baseH * (natW / natH);
  } else {
    const scale = Math.min(viewW / natW, viewH / natH, 1);
    baseW = natW * scale;
    baseH = natH * scale;
  }

  const w = baseW * zoomMultiplier;
  const h = baseH * zoomMultiplier;
  const x = (viewW - w) / 2;
  const y = (viewH - h) / 2;
  return { x, y, w, h };
}

function drawDecodedAsset(
  ctx: CanvasRenderingContext2D,
  asset: DecodedPageAsset,
  rect: Rect,
  onLateLoad: () => void,
  skipBackingFill = false,
) {
  if (asset.tiles.length === 0) return;

  if (!skipBackingFill) {
    ctx.fillStyle = '#f5f4ef';
    ctx.fillRect(rect.x, rect.y, rect.w, rect.h);
  }

  const totalNaturalHeight = Math.max(
    1,
    asset.tiles.reduce((sum, t) => sum + t.height, 0),
  );
  let yCursor = rect.y;

  for (const tile of asset.tiles) {
    const tileH = rect.h * (tile.height / totalNaturalHeight);
    const img = getOrLoadImage(tile.url, onLateLoad);
    if (img) {
      ctx.drawImage(img, rect.x, yCursor, rect.w, tileH);
    }
    yCursor += tileH;
  }
}

function traceHalfPlane(
  ctx: CanvasRenderingContext2D,
  mx: number,
  my: number,
  nx: number,
  ny: number,
  side: 1 | -1,
  extent: number,
) {
  const tx = -ny;
  const ty = nx;
  const sx = nx * side;
  const sy = ny * side;

  ctx.beginPath();
  ctx.moveTo(mx + tx * extent, my + ty * extent);
  ctx.lineTo(mx - tx * extent, my - ty * extent);
  ctx.lineTo(mx - tx * extent + sx * extent, my - ty * extent + sy * extent);
  ctx.lineTo(mx + tx * extent + sx * extent, my + ty * extent + sy * extent);
  ctx.closePath();
}

function easeOutQuart(t: number): number {
  return 1 - Math.pow(1 - t, 4);
}

export const PageCurlStage = forwardRef<PageCurlStageHandle, PageCurlStageProps>(
  ({ viewportWidth, viewportHeight, fitMode, zoomMultiplier, readerBg }, ref) => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const rafRef = useRef<number | null>(null);
    const activeFrameRef = useRef<LiveCurlParams | null>(null);
    const propsRef = useRef({ viewportWidth, viewportHeight, fitMode, zoomMultiplier, readerBg });
    propsRef.current = { viewportWidth, viewportHeight, fitMode, zoomMultiplier, readerBg };

    const stopRaf = () => {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };

    const drawFrame = (frame: LiveCurlParams | null) => {
      const canvas = canvasRef.current;
      const {
        viewportWidth: viewW,
        viewportHeight: viewH,
        fitMode: currentFit,
        zoomMultiplier: currentZoom,
        readerBg: bg,
      } = propsRef.current;

      if (!canvas || viewW <= 0 || viewH <= 0) return;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const targetW = Math.round(viewW * dpr);
      const targetH = Math.round(viewH * dpr);
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      if (!frame) {
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        canvas.style.opacity = '0';
        return;
      }

      canvas.style.opacity = '1';

      let lateRedrawQueued = false;
      const handleLateLoad = () => {
        if (lateRedrawQueued || !activeFrameRef.current) return;
        lateRedrawQueued = true;
        requestAnimationFrame(() => {
          if (activeFrameRef.current) {
            drawFrame(activeFrameRef.current);
          }
        });
      };

      ctx.save();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, viewW, viewH);

      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, viewW, viewH);

      const t = Math.max(0, Math.min(1, frame.progress));
      const rectA = frame.frontPage
        ? computeFittedRect(frame.frontPage, viewW, viewH, currentFit, currentZoom)
        : { x: 0, y: 0, w: viewW, h: viewH };
      const rectB = frame.backPage
        ? computeFittedRect(frame.backPage, viewW, viewH, currentFit, currentZoom)
        : rectA;

      if (t <= 0.002) {
        if (frame.frontPage) {
          drawDecodedAsset(ctx, frame.frontPage, rectA, handleLateLoad);
        }
        ctx.restore();
        return;
      }

      if (t >= 0.998) {
        if (frame.backPage) {
          drawDecodedAsset(ctx, frame.backPage, rectB, handleLateLoad);
        }
        ctx.restore();
        return;
      }

      // Clamp active peel box vertically to the visible viewport
      const fx0 = rectA.x;
      const fy0 = Math.max(0, rectA.y);
      const fw = Math.max(40, rectA.w);
      const fh = Math.max(40, Math.min(viewH, rectA.y + rectA.h) - fy0);

      const fromTop = frame.anchorYRatio < 0.34;
      const cx = frame.curlEdge === 'right' ? fx0 + fw : fx0;
      const cy = fromTop ? fy0 : fy0 + fh;

      const sweepDir = frame.curlEdge === 'right' ? -1 : 1;
      const px = cx + sweepDir * 2.08 * fw * t;

      // Natural Kindle diagonal lift angle following tap/drag height
      const rawBias = fromTop
        ? 0.13 + Math.max(0, frame.anchorYRatio) * 0.24
        : -(0.13 + Math.max(0, 1 - frame.anchorYRatio) * 0.22);
      const clampedBias = Math.max(-0.24, Math.min(0.24, rawBias));
      const py = cy + fh * clampedBias * Math.sin(Math.PI * t);

      const vx = cx - px;
      const vy = cy - py;
      const vLen = Math.hypot(vx, vy);

      if (vLen < 1.5) {
        if (frame.frontPage) {
          drawDecodedAsset(ctx, frame.frontPage, rectA, handleLateLoad);
        }
        ctx.restore();
        return;
      }

      const nx = vx / vLen;
      const ny = vy / vLen;
      const mx = (cx + px) * 0.5;
      const my = (cy + py) * 0.5;
      const extent = (viewW + viewH) * 4;
      const arcStrength = Math.sin(Math.PI * t);

      // 1. REVEALED PAGE UNDERNEATH (Back Page) + CAST CREASE SHADOW
      ctx.save();
      traceHalfPlane(ctx, mx, my, nx, ny, 1, extent);
      ctx.clip();

      if (frame.backPage) {
        drawDecodedAsset(ctx, frame.backPage, rectB, handleLateLoad);
      }

      const castSpan = Math.min(fw * 0.36, 170) * (0.35 + 0.65 * arcStrength);
      ctx.save();
      ctx.beginPath();
      ctx.rect(rectB.x, rectB.y, rectB.w, rectB.h);
      ctx.clip();

      const castGrad = ctx.createLinearGradient(
        mx,
        my,
        mx + nx * castSpan,
        my + ny * castSpan,
      );
      castGrad.addColorStop(0, 'rgba(0, 0, 0, 0.50)');
      castGrad.addColorStop(0.18, 'rgba(0, 0, 0, 0.30)');
      castGrad.addColorStop(0.52, 'rgba(0, 0, 0, 0.09)');
      castGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = castGrad;
      ctx.fillRect(rectB.x, rectB.y, rectB.w, rectB.h);
      ctx.restore();
      ctx.restore();

      // 2. FLAT UN-CURLED PORTION OF TOP PAGE (Front Page) + BEND SHADING
      ctx.save();
      traceHalfPlane(ctx, mx, my, nx, ny, -1, extent);
      ctx.clip();

      if (frame.frontPage) {
        drawDecodedAsset(ctx, frame.frontPage, rectA, handleLateLoad);

        const bendSpan = Math.max(18, Math.min(fw * 0.14, 58) * arcStrength);
        ctx.save();
        ctx.beginPath();
        ctx.rect(rectA.x, rectA.y, rectA.w, rectA.h);
        ctx.clip();

        const bendGrad = ctx.createLinearGradient(
          mx - nx * bendSpan,
          my - ny * bendSpan,
          mx,
          my,
        );
        bendGrad.addColorStop(0, 'rgba(0, 0, 0, 0)');
        bendGrad.addColorStop(0.65, 'rgba(0, 0, 0, 0.08)');
        bendGrad.addColorStop(1, 'rgba(0, 0, 0, 0.22)');
        ctx.fillStyle = bendGrad;
        ctx.fillRect(rectA.x, rectA.y, rectA.w, rectA.h);
        ctx.restore();
      }
      ctx.restore();

      // 3. CURLED BACKSIDE FLAP (Reflected Front Page Verso + Cylindrical Specular Highlight)
      const flapAlpha = t > 0.84 ? Math.max(0, (1 - t) / 0.16) : 1;
      if (frame.frontPage && flapAlpha > 0.01) {
        ctx.save();
        ctx.globalAlpha = flapAlpha;

        traceHalfPlane(ctx, mx, my, nx, ny, -1, extent);
        ctx.clip();

        // Reflection matrix across crease line (M, n)
        const dot = mx * nx + my * ny;
        const ra = 1 - 2 * nx * nx;
        const rb = -2 * nx * ny;
        const rc = -2 * nx * ny;
        const rd = 1 - 2 * ny * ny;
        const re = 2 * dot * nx;
        const rf = 2 * dot * ny;
        ctx.transform(ra, rb, rc, rd, re, rf);

        // Soft drop shadow cast by the lifted flap onto the flat front page beneath
        ctx.save();
        ctx.shadowColor = `rgba(0, 0, 0, ${(0.36 * flapAlpha).toFixed(3)})`;
        ctx.shadowBlur = 24;
        ctx.shadowOffsetX = -9 * nx;
        ctx.shadowOffsetY = -9 * ny;
        ctx.fillStyle = '#eceae3';
        ctx.fillRect(rectA.x, rectA.y, rectA.w, rectA.h);
        ctx.restore();

        ctx.beginPath();
        ctx.rect(rectA.x, rectA.y, rectA.w, rectA.h);
        ctx.clip();

        // Subtle mirrored artwork bleed-through like physical comic paper
        ctx.save();
        ctx.globalAlpha = flapAlpha * 0.24;
        drawDecodedAsset(ctx, frame.frontPage, rectA, handleLateLoad, true);
        ctx.restore();

        // Cylindrical paper roll shading: crease tuck -> bright specular crest -> outer edge shadow
        const curlWidth = Math.max(36, Math.min(fw * 0.44, vLen * 0.5));
        const curlGrad = ctx.createLinearGradient(
          mx,
          my,
          mx + nx * curlWidth,
          my + ny * curlWidth,
        );
        curlGrad.addColorStop(0, 'rgba(0, 0, 0, 0.24)');
        curlGrad.addColorStop(0.11, 'rgba(255, 255, 255, 0.64)');
        curlGrad.addColorStop(0.28, 'rgba(255, 255, 255, 0.20)');
        curlGrad.addColorStop(0.62, 'rgba(0, 0, 0, 0.05)');
        curlGrad.addColorStop(1, 'rgba(0, 0, 0, 0.18)');
        ctx.fillStyle = curlGrad;
        ctx.fillRect(rectA.x, rectA.y, rectA.w, rectA.h);

        // Crisp 1px paper edge border
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.15)';
        ctx.lineWidth = 1;
        ctx.strokeRect(rectA.x + 0.5, rectA.y + 0.5, rectA.w - 1, rectA.h - 1);

        ctx.restore();
      }

      ctx.restore();
    };

    useImperativeHandle(ref, () => ({
      animateTurn(params: CurlTurnParams) {
        stopRaf();
        const duration = Math.max(120, params.durationMs ?? 420);
        const startTime = performance.now();

        const step = (now: number) => {
          const raw = Math.min(1, Math.max(0, (now - startTime) / duration));
          const eased = easeOutQuart(raw);
          const progress =
            params.fromProgress + (params.toProgress - params.fromProgress) * eased;

          const frame: LiveCurlParams = {
            frontPage: params.frontPage,
            backPage: params.backPage,
            curlEdge: params.curlEdge,
            progress,
            anchorYRatio: params.anchorYRatio,
          };
          activeFrameRef.current = frame;
          drawFrame(frame);

          if (raw < 1) {
            rafRef.current = requestAnimationFrame(step);
          } else {
            rafRef.current = null;
            activeFrameRef.current = null;
            drawFrame(null);
            params.onComplete?.();
          }
        };

        rafRef.current = requestAnimationFrame(step);
      },
      renderLive(params: LiveCurlParams) {
        stopRaf();
        activeFrameRef.current = params;
        drawFrame(params);
      },
      clear() {
        stopRaf();
        activeFrameRef.current = null;
        drawFrame(null);
      },
    }));

    useEffect(() => {
      return () => {
        stopRaf();
      };
    }, []);

    return (
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none z-20 opacity-0"
        aria-hidden="true"
      />
    );
  },
);

PageCurlStage.displayName = 'PageCurlStage';
