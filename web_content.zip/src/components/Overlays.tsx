import { useMemo, useState } from "react";
import type { GameMode, GameResults, HighScore, HudState, Settings } from "@/game/types";
import { cn } from "@/utils/cn";
import { ChunkyButton, Icon, KeyCap, Modal, Panel, SectionTitle, Segmented, Slider, StarBurst, TeamBadge, Toggle } from "./ui";

/* ------------------------------------------------------------------ */
/* Pause                                                               */
/* ------------------------------------------------------------------ */

export function PauseOverlay({
  hud,
  settings,
  onResume,
  onRestart,
  onMenu,
  onSettingsChange,
  onOpenBriefing,
}: {
  hud: HudState | null;
  settings: Settings;
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
  onSettingsChange: (patch: Partial<Settings>) => void;
  onOpenBriefing: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center overflow-y-auto bg-ink/75 p-3 backdrop-blur-md">
      <Panel className="animate-pop-in relative my-auto w-full max-w-3xl overflow-hidden p-4 sm:p-5">
        <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 text-sun/10">
          <StarBurst className="animate-spin-slow" />
        </div>
        <div className="grid gap-4 md:grid-cols-[1.05fr_1fr]">
          <div>
            <div className="mb-1 flex items-center gap-2">
              <span className="grid h-10 w-10 place-items-center rounded-xl border-[3px] border-ink bg-coral text-white shadow-[0_3px_0_0_#241a35]">
                <Icon name="pause" className="h-5 w-5" />
              </span>
              <div>
                <p className="font-display text-2xl font-black uppercase leading-none tracking-tight text-cream text-outline-sm sm:text-3xl">Пауза</p>
                <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-cream/40">Матч приостановлен</p>
              </div>
            </div>
            {hud && (
              <div className="mt-3 grid grid-cols-3 gap-1.5">
                <PauseStat label="Счёт" value={hud.score.toLocaleString("ru-RU")} accent="text-sun" />
                <PauseStat label="Убийства" value={`${hud.kills}`} accent="text-cream" />
                <PauseStat label="Время" value={`${Math.floor(hud.timeLeft / 60)}:${String(Math.ceil(hud.timeLeft % 60)).padStart(2, "0")}`} accent="text-teal" />
              </div>
            )}
            <div className="mt-3 space-y-2">
              <ChunkyButton icon="play" onClick={onResume} className="w-full py-3 text-base">
                Продолжить
              </ChunkyButton>
              <div className="grid grid-cols-2 gap-2">
                <ChunkyButton icon="reload" variant="secondary" onClick={onRestart}>
                  Заново
                </ChunkyButton>
                <ChunkyButton icon="close" variant="ghost" onClick={onMenu}>
                  В меню
                </ChunkyButton>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-[9px] font-bold uppercase tracking-wider text-cream/35">
              <span className="flex items-center gap-1">
                <KeyCap>ESC</KeyCap> продолжить
              </span>
              <span className="flex items-center gap-1">
                <KeyCap>R</KeyCap> заново
              </span>
              <button type="button" onClick={onOpenBriefing} className="ml-auto flex items-center gap-1 text-teal hover:text-cream">
                <Icon name="info" className="h-3.5 w-3.5" /> Брифинг
              </button>
            </div>
          </div>

          <div className="rounded-2xl border-2 border-cream/10 bg-ink/35 p-3">
            <SectionTitle icon="settings">Быстрые настройки</SectionTitle>
            <div className="space-y-2">
              <Slider label="Чувствительность" value={settings.sensitivity} min={0.4} max={2} step={0.05} onChange={(v) => onSettingsChange({ sensitivity: v })} />
              <div className="grid grid-cols-2 gap-2">
                <Slider label="Звуки" value={settings.sfx} min={0} max={1} step={0.05} onChange={(v) => onSettingsChange({ sfx: v })} display={`${Math.round(settings.sfx * 100)}%`} />
                <Slider label="Музыка" value={settings.music} min={0} max={1} step={0.05} onChange={(v) => onSettingsChange({ music: v })} display={`${Math.round(settings.music * 100)}%`} />
              </div>
              <div>
                <p className="mb-1 text-[9px] font-black uppercase tracking-wider text-cream/40">Раскладка</p>
                <Segmented
                  options={[
                    { value: "classic", label: "Классика" },
                    { value: "compact", label: "Компакт" },
                  ]}
                  value={settings.layout}
                  onChange={(v) => onSettingsChange({ layout: v })}
                />
              </div>
              <div>
                <p className="mb-1 text-[9px] font-black uppercase tracking-wider text-cream/40">Качество</p>
                <Segmented
                  options={[
                    { value: "low", label: "Низкое" },
                    { value: "medium", label: "Среднее" },
                    { value: "high", label: "Высокое" },
                  ]}
                  value={settings.quality}
                  onChange={(v) => onSettingsChange({ quality: v })}
                />
              </div>
              <Toggle label="Тач-контроль" checked={settings.touch} onChange={(v) => onSettingsChange({ touch: v })} />
            </div>
          </div>
        </div>
      </Panel>
    </div>
  );
}

function PauseStat({ label, value, accent }: { label: string; value: string; accent: string }) {
  return (
    <div className="rounded-xl border-2 border-cream/10 bg-white/5 px-2 py-1.5 text-center">
      <p className="text-[7px] font-black uppercase tracking-wider text-cream/35">{label}</p>
      <p className={cn("font-display text-sm font-black", accent)}>{value}</p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Game over                                                           */
/* ------------------------------------------------------------------ */

const CONFETTI_COLORS = ["#ffb43c", "#ff6b4a", "#39d6c8", "#a08cff", "#9fe870", "#fff6e6"];

export function GameOverOverlay({
  results,
  highScores,
  newRecord,
  nickname,
  onRestart,
  onMenu,
}: {
  results: GameResults;
  highScores: HighScore[];
  newRecord: boolean;
  nickname: string;
  onRestart: () => void;
  onMenu: () => void;
}) {
  const confetti = useMemo(
    () =>
      Array.from({ length: 28 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 2.5,
        duration: 2.8 + Math.random() * 2,
        color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
        drift: `${Math.random() * 120 - 60}px`,
        rotate: Math.random() * 360,
      })),
    []
  );
  const best = highScores[0];
  const gap = best ? Math.max(0, best.score - results.score) : 0;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center overflow-y-auto bg-gradient-to-b from-ink/80 via-ink/90 to-ink-deep p-3 backdrop-blur-sm">
      {(results.won || newRecord) && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          {confetti.map((c) => (
            <span
              key={c.id}
              className="confetti-piece"
              style={{
                left: `${c.left}%`,
                backgroundColor: c.color,
                animationDelay: `${c.delay}s`,
                animationDuration: `${c.duration}s`,
                transform: `rotate(${c.rotate}deg)`,
                ["--drift" as string]: c.drift,
              }}
            />
          ))}
        </div>
      )}
      <Panel className="animate-pop-in relative my-auto w-full max-w-3xl overflow-hidden p-4 sm:p-5">
        <div className="pointer-events-none absolute -left-12 -top-12 h-44 w-44 text-teal/10">
          <StarBurst className="animate-spin-slow" />
        </div>
        <div className="grid gap-4 md:grid-cols-[1.15fr_1fr]">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border-[3px] border-ink px-2.5 py-1 font-display text-[10px] font-black uppercase tracking-wider shadow-[0_2px_0_0_#241a35]",
                  results.won ? "bg-lime text-ink" : "bg-coral text-white"
                )}
              >
                <Icon name={results.won ? "trophy" : "skull"} className="h-3.5 w-3.5" />
                {results.won ? "Победа" : "Поражение"}
              </span>
              {newRecord && (
                <span className="inline-flex animate-wiggle items-center gap-1 rounded-full border-[3px] border-ink bg-sun px-2.5 py-1 font-display text-[10px] font-black uppercase tracking-wider text-ink shadow-[0_2px_0_0_#241a35]">
                  <Icon name="crown" className="h-3.5 w-3.5" /> Новый рекорд
                </span>
              )}
              <span className="ml-auto text-[9px] font-bold uppercase tracking-wider text-cream/35">
                {results.mode === "dm" ? "Deathmatch" : "Team Deathmatch"} · {results.reason === "time" ? "время вышло" : "лимит очков"}
              </span>
            </div>
            <h2 className="mt-2 font-display text-[clamp(2rem,6vw,3.4rem)] font-black uppercase leading-[0.85] tracking-tight text-cream text-outline">
              {results.won ? "Бой выигран" : "Бой окончен"}
            </h2>
            <div className="mt-3 flex items-end gap-2">
              <span className="font-display text-5xl font-black leading-none text-sun text-outline sm:text-6xl">{results.score.toLocaleString("ru-RU")}</span>
              <span className="mb-1 text-[10px] font-black uppercase tracking-[0.2em] text-cream/40">очков</span>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-1.5 sm:grid-cols-4">
              <ResultStat icon="skull" label="Убийства" value={`${results.kills}`} />
              <ResultStat icon="heart" label="Смерти" value={`${results.deaths}`} />
              <ResultStat icon="target" label="Точность" value={`${results.accuracy}%`} />
              <ResultStat icon="bolt" label="Серия" value={`×${results.bestStreak}`} />
            </div>
            {results.mode === "tdm" && (
              <div className="mt-2 flex items-center justify-between rounded-xl border-2 border-cream/10 bg-white/5 px-3 py-1.5">
                <div className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full border border-ink bg-sun" />
                  <span className="text-[9px] font-black uppercase tracking-wider text-cream/50">SUN</span>
                  <span className="font-display text-lg font-black text-sun">{results.teamScores.sun}</span>
                </div>
                <span className="text-[9px] font-black text-cream/25">VS</span>
                <div className="flex items-center gap-1.5">
                  <span className="font-display text-lg font-black text-teal">{results.teamScores.tide}</span>
                  <span className="text-[9px] font-black uppercase tracking-wider text-cream/50">TIDE</span>
                  <span className="h-2.5 w-2.5 rounded-full border border-ink bg-teal" />
                </div>
              </div>
            )}
            <div className="mt-3 flex flex-col gap-2 sm:flex-row">
              <ChunkyButton icon="reload" onClick={onRestart} className="flex-1 py-3 text-base">
                Ещё раз
              </ChunkyButton>
              <ChunkyButton icon="close" variant="secondary" onClick={onMenu} className="sm:w-auto">
                В меню
              </ChunkyButton>
            </div>
            <div className="mt-2 flex items-center justify-between text-[9px] font-bold uppercase tracking-wider text-cream/35">
              <span className="flex items-center gap-1">
                <KeyCap>R</KeyCap> мгновенный реванш
              </span>
              <span>
                Место: <span className="text-cream">#{results.place}</span>
              </span>
            </div>
          </div>

          <div className="rounded-2xl border-2 border-cream/10 bg-ink/35 p-3">
            <SectionTitle icon="trophy" right={<span className="font-mono text-[9px] font-bold text-cream/35">ТОП-5</span>}>
              Доска почёта
            </SectionTitle>
            {highScores.length === 0 ? (
              <p className="rounded-xl border-2 border-dashed border-cream/15 px-3 py-6 text-center text-[11px] text-cream/40">Пока пусто. Сыграй ещё матч!</p>
            ) : (
              <div className="space-y-1.5">
                {highScores.slice(0, 5).map((entry, i) => {
                  const isNew = entry.name === nickname && entry.score === results.score && i < 5;
                  return (
                    <div
                      key={entry.id}
                      className={cn(
                        "flex items-center gap-2 rounded-xl border-2 px-2 py-1.5",
                        isNew ? "border-sun/70 bg-sun/15" : i === 0 ? "border-cream/20 bg-white/5" : "border-cream/10 bg-white/[0.03]"
                      )}
                    >
                      <span className={cn("grid h-6 w-6 shrink-0 place-items-center rounded-md border-2 border-ink font-display text-[10px] font-black", i === 0 ? "bg-sun text-ink" : i === 1 ? "bg-cream text-ink" : i === 2 ? "bg-coral text-white" : "bg-white/10 text-cream/60")}>{i + 1}</span>
                      <span className="min-w-0 flex-1 truncate font-display text-[11px] font-extrabold text-cream">{entry.name}</span>
                      <span className="font-mono text-[9px] font-bold text-cream/35">{entry.kills} K</span>
                      <span className="font-mono text-[11px] font-black text-sun">{entry.score.toLocaleString("ru-RU")}</span>
                    </div>
                  );
                })}
              </div>
            )}
            <div className="mt-2 rounded-xl border-2 border-cream/10 bg-white/5 px-3 py-2">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-black uppercase tracking-wider text-cream/40">Личный рекорд</span>
                <span className="font-display text-sm font-black text-sun">{best ? best.score.toLocaleString("ru-RU") : "—"}</span>
              </div>
              <p className="mt-1 text-[10px] leading-snug text-cream/40">
                {newRecord ? "Ты только что вписал себя в историю Песчаного форта." : gap > 0 ? `До рекорда не хватило ${gap.toLocaleString("ru-RU")} очков. Ещё забег?` : "Отличный результат. Попробуй побить свой рекорд."}
              </p>
            </div>
            <div className="mt-2 flex items-center justify-between rounded-xl border-2 border-cream/10 bg-white/5 px-3 py-2">
              <div className="flex items-center gap-1.5">
                <TeamBadge team={results.mode === "tdm" ? "sun" : "none"} />
                <span className="text-[9px] font-bold uppercase tracking-wider text-cream/40">{results.mode === "dm" ? "Solo" : "SUN"}</span>
              </div>
              <span className="font-display text-xs font-black text-cream">#{results.place}</span>
            </div>
          </div>
        </div>
      </Panel>
    </div>
  );
}

function ResultStat({ icon, label, value }: { icon: "skull" | "heart" | "target" | "bolt"; label: string; value: string }) {
  return (
    <div className="rounded-xl border-2 border-cream/10 bg-white/5 px-2 py-1.5">
      <div className="flex items-center gap-1 text-cream/35">
        <Icon name={icon} className="h-3 w-3" />
        <span className="text-[7px] font-black uppercase tracking-wider">{label}</span>
      </div>
      <p className="mt-0.5 font-display text-sm font-black text-cream">{value}</p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Settings                                                            */
/* ------------------------------------------------------------------ */

export function SettingsModal({
  settings,
  onChange,
  onClose,
  onResetScores,
}: {
  settings: Settings;
  onChange: (patch: Partial<Settings>) => void;
  onClose: () => void;
  onResetScores: () => void;
}) {
  const [confirmReset, setConfirmReset] = useState(false);
  return (
    <Modal onClose={onClose}>
      <div className="p-4 sm:p-5">
        <div className="mb-3 flex items-center gap-2">
          <span className="grid h-10 w-10 place-items-center rounded-xl border-[3px] border-ink bg-sun text-ink shadow-[0_3px_0_0_#241a35]">
            <Icon name="settings" className="h-5 w-5" />
          </span>
          <div>
            <h2 className="font-display text-xl font-black uppercase leading-none text-cream">Настройки</h2>
            <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-cream/40">Сохраняются на этом устройстве</p>
          </div>
        </div>
        <div className="grid gap-2 sm:grid-cols-2">
          <div className="space-y-2">
            <SectionTitle icon="touch">Управление</SectionTitle>
            <Slider label="Чувствительность обзора" value={settings.sensitivity} min={0.4} max={2} step={0.05} onChange={(v) => onChange({ sensitivity: v })} />
            <Toggle label="Инверсия оси Y" checked={settings.invertY} onChange={(v) => onChange({ invertY: v })} />
            <Toggle label="Тач-контроль" checked={settings.touch} onChange={(v) => onChange({ touch: v })} />
            <div>
              <p className="mb-1 text-[9px] font-black uppercase tracking-wider text-cream/40">Раскладка кнопок</p>
              <Segmented
                options={[
                  { value: "classic", label: "Классическая" },
                  { value: "compact", label: "Компактная" },
                ]}
                value={settings.layout}
                onChange={(v) => onChange({ layout: v })}
              />
            </div>
          </div>
          <div className="space-y-2">
            <SectionTitle icon="bolt">Графика и звук</SectionTitle>
            <div>
              <p className="mb-1 text-[9px] font-black uppercase tracking-wider text-cream/40">Качество рендера</p>
              <Segmented
                options={[
                  { value: "low", label: "Низкое" },
                  { value: "medium", label: "Среднее" },
                  { value: "high", label: "Высокое" },
                ]}
                value={settings.quality}
                onChange={(v) => onChange({ quality: v })}
              />
            </div>
            <Slider label="Громкость звуков" value={settings.sfx} min={0} max={1} step={0.05} onChange={(v) => onChange({ sfx: v })} display={`${Math.round(settings.sfx * 100)}%`} />
            <Slider label="Громкость музыки" value={settings.music} min={0} max={1} step={0.05} onChange={(v) => onChange({ music: v })} display={`${Math.round(settings.music * 100)}%`} />
            <div className="rounded-xl border-2 border-cream/10 bg-white/5 px-3 py-2 text-[10px] leading-snug text-cream/45">
              <span className="font-bold text-cream/70">Мультитач:</span> движение, обзор и огонь работают одновременно. На телефоне лучше включить тач-контроль и выбрать компактную раскладку.
            </div>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => {
              if (confirmReset) {
                onResetScores();
                setConfirmReset(false);
              } else {
                setConfirmReset(true);
              }
            }}
            className={cn(
              "rounded-xl border-2 px-3 py-2 text-[10px] font-black uppercase tracking-wider transition-colors",
              confirmReset ? "border-coral bg-coral text-white" : "border-cream/15 bg-white/5 text-cream/40 hover:text-coral"
            )}
          >
            {confirmReset ? "Точно сбросить? Нажми ещё раз" : "Сбросить рекорды"}
          </button>
          <ChunkyButton icon="check" onClick={onClose}>
            Готово
          </ChunkyButton>
        </div>
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ */
/* Briefing                                                            */
/* ------------------------------------------------------------------ */

type BriefingTab = "controls" | "godot" | "pipeline";

export function BriefingModal({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<BriefingTab>("controls");
  return (
    <Modal onClose={onClose} wide>
      <div className="max-h-[88vh] overflow-y-auto p-4 sm:p-5">
        <div className="mb-3 flex items-center gap-2 pr-10">
          <span className="grid h-10 w-10 place-items-center rounded-xl border-[3px] border-ink bg-grape text-ink shadow-[0_3px_0_0_#241a35]">
            <Icon name="info" className="h-5 w-5" />
          </span>
          <div>
            <h2 className="font-display text-xl font-black uppercase leading-none text-cream">Брифинг</h2>
            <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-cream/40">Управление · Godot-план · 3D-пайплайн</p>
          </div>
        </div>
        <div className="mb-3 flex gap-1 rounded-xl border-2 border-cream/10 bg-ink/50 p-1">
          {(
            [
              { id: "controls", label: "Управление", icon: "touch" },
              { id: "godot", label: "Godot-план", icon: "bolt" },
              { id: "pipeline", label: "3D-пайплайн", icon: "expand" },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={cn(
                "flex flex-1 items-center justify-center gap-1.5 rounded-lg px-2 py-2 text-[10px] font-extrabold uppercase tracking-wider transition-colors",
                tab === t.id ? "bg-sun text-ink" : "text-cream/50 hover:bg-white/10 hover:text-cream"
              )}
            >
              <Icon name={t.icon} className="h-3.5 w-3.5" />
              {t.label}
            </button>
          ))}
        </div>

        {tab === "controls" && <ControlsTab />}
        {tab === "godot" && <GodotTab />}
        {tab === "pipeline" && <PipelineTab />}
      </div>
    </Modal>
  );
}

function ControlsTab() {
  return (
    <div className="grid gap-3 md:grid-cols-2">
      <div className="rounded-2xl border-2 border-cream/10 bg-white/5 p-3">
        <SectionTitle icon="keyboard">Клавиатура и мышь</SectionTitle>
        <div className="space-y-1.5">
          <ControlLine keys={["W", "A", "S", "D"]} text="Движение. Полное отклонение — авто-бег." />
          <ControlLine keys={["МЫШЬ"]} text="Обзор камеры. Клик по экрану захватывает курсор." />
          <ControlLine keys={["ЛКМ"]} text="Огонь. Удерживай для автострельбы." />
          <ControlLine keys={["ПКМ"]} text="Прицел / зум. В 1-м лицо — приближение." />
          <ControlLine keys={["SPACE"]} text="Прыжок." />
          <ControlLine keys={["SHIFT"]} text="Присед. Уменьшает скорость и профиль." />
          <ControlLine keys={["R"]} text="Перезарядка." />
          <ControlLine keys={["1", "2", "3", "4"]} text="Смена оружия. Q — следующий слот." />
          <ControlLine keys={["G"]} text="Граната. На тач-кнопке — удержание и бросок." />
          <ControlLine keys={["E"]} text="Сесть / выйти из машины. Двери и рычаги." />
          <ControlLine keys={["V"]} text="Камера от 3-го / 1-го лица." />
          <ControlLine keys={["TAB"]} text="Таблица счёта." />
          <ControlLine keys={["ESC"]} text="Пауза." />
        </div>
      </div>
      <div className="space-y-3">
        <div className="rounded-2xl border-2 border-cream/10 bg-white/5 p-3">
          <SectionTitle icon="touch">Тач-управление</SectionTitle>
          <div className="space-y-1.5">
            <ControlLine keys={["ЛЕВЫЙ НИЗ"]} text="Виртуальный джойстик. Аналоговый вектор, авто-бег при полном отклонении." />
            <ControlLine keys={["ПРАВАЯ ЗОНА"]} text="Свайп-обзор. Yaw/Pitch, чувствительность настраивается." />
            <ControlLine keys={["ОГОНЬ"]} text="Большая кнопка справа. Удержание = автострельба." />
            <ControlLine keys={["ПРЫЖОК"]} text="Рядом с огнём." />
            <ControlLine keys={["ПРИСЕД"]} text="Переключатель." />
            <ControlLine keys={["ГРАНАТА"]} text="Удержание — прицел, отпускание — бросок." />
            <ControlLine keys={["МАШИНА"]} text="Вход / выход из техники." />
            <ControlLine keys={["ПРИЦЕЛ"]} text="Удержание — зум." />
            <ControlLine keys={["КАМЕРА"]} text="3-е ↔ 1-е лицо." />
          </div>
        </div>
        <div className="rounded-2xl border-2 border-teal/30 bg-teal/10 p-3">
          <div className="flex items-center gap-2">
            <Icon name="bolt" className="h-4 w-4 text-teal" />
            <p className="font-display text-[11px] font-extrabold uppercase tracking-wider text-teal">Мультитач обязателен</p>
          </div>
          <p className="mt-1 text-[11px] leading-snug text-cream/60">
            Движение, обзор и огонь обрабатываются разными pointerId. Джойстик и зона обзора не перехватывают нажатия друг друга. Настройки чувствительности и раскладки — в паузе и на стартовом экране.
          </p>
        </div>
      </div>
    </div>
  );
}

function ControlLine({ keys, text }: { keys: string[]; text: string }) {
  return (
    <div className="flex items-start gap-2">
      <div className="flex shrink-0 flex-wrap gap-1 pt-0.5">
        {keys.map((k) => (
          <KeyCap key={k}>{k}</KeyCap>
        ))}
      </div>
      <p className="text-[10px] leading-snug text-cream/55">{text}</p>
    </div>
  );
}

function GodotTab() {
  const stages = [
    ["01", "Прототип управления", "TouchControls CanvasLayer, джойстик, свайп-обзор, мультитач, две раскладки. InputEventScreenTouch/ScreenDrag."],
    ["02", "Персонаж и оружие", "CharacterBody3D, анимации idle/walk/run/jump/crouch/shoot/reload/death, 6 стволов, RayCast3D + физические снаряды."],
    ["03", "Боты", "NavigationAgent3D, патруль, обнаружение, стрельба, укрытия, 8–12 ботов, respawn."],
    ["04", "Арена", "Low-poly городок, укрытия, ящики, бочки, заборы, разрушаемые RigidBody3D, освещение и LOD."],
    ["05", "Техника", "VehicleBody3D, багги/джип/танк, вход-выход, стрельба с техники, урон и взрыв."],
    ["06", "Мультиплеер", "ENet/WebSocket, лобби, список серверов, синхронизация позиции/анимаций/выстрелов."],
    ["07", "Полировка", "Screen shake, частицы, hitmarker, kill-feed, звук, музыка, настройки, гейм-плей."],
    ["08", "Экспорт Android", "Landscape, VIBRATE + INTERNET, keystore, touch-настройки, Mobile-рендер, 60 fps."],
  ];
  return (
    <div className="grid gap-3 md:grid-cols-2">
      <div className="rounded-2xl border-2 border-cream/10 bg-white/5 p-3">
        <SectionTitle icon="bolt">Пошаговый план</SectionTitle>
        <div className="space-y-1.5">
          {stages.map(([n, title, text]) => (
            <div key={n} className="flex gap-2 rounded-xl border border-cream/5 bg-ink/30 px-2 py-1.5">
              <span className="grid h-5 w-5 shrink-0 place-items-center rounded-md border-2 border-ink bg-sun font-display text-[8px] font-black text-ink">{n}</span>
              <div>
                <p className="font-display text-[10px] font-extrabold uppercase tracking-wide text-cream">{title}</p>
                <p className="text-[9px] leading-snug text-cream/45">{text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="space-y-3">
        <div className="rounded-2xl border-2 border-cream/10 bg-white/5 p-3">
          <SectionTitle icon="expand">Структура проекта</SectionTitle>
          <pre className="overflow-x-auto rounded-xl border-2 border-ink bg-ink/60 p-2.5 font-mono text-[9px] leading-relaxed text-teal/90">{`tolok/
├── scenes/
│   ├── Main.tscn
│   ├── Arena.tscn
│   ├── Player.tscn
│   ├── Bot.tscn
│   ├── Vehicle.tscn
│   ├── Weapon.tscn
│   └── TouchControls.tscn
├── scripts/
│   ├── player_controller.gd
│   ├── virtual_joystick.gd
│   ├── touch_look.gd
│   ├── weapon.gd
│   ├── vehicle_controller.gd
│   ├── bot_ai.gd
│   └── network_sync.gd
├── assets/
│   ├── models/    # .glb
│   ├── textures/  # 512–1024 px atlas
│   ├── audio/
│   └── shaders/   # toon.gdshader
└── export_presets.cfg`}</pre>
        </div>
        <div className="rounded-2xl border-2 border-cream/10 bg-white/5 p-3">
          <SectionTitle icon="settings">Android-экспорт</SectionTitle>
          <div className="grid grid-cols-2 gap-1.5 text-[9px] text-cream/55">
            <ExportRow k="Orientation" v="Landscape" />
            <ExportRow k="Renderer" v="Mobile / Forward+" />
            <ExportRow k="Разрешения" v="VIBRATE, INTERNET" />
            <ExportRow k="Touch" v="Emulate mouse off" />
            <ExportRow k="FPS" v="Engine.max_fps = 60" />
            <ExportRow k="Пауза" v="NOTIFICATION_APPLICATION_PAUSED" />
            <ExportRow k="Keystore" v="release.keystore" />
            <ExportRow k="Формат" v="APK / AAB" />
          </div>
          <p className="mt-2 text-[9px] leading-snug text-cream/35">
            Autoload: GameSettings, AudioManager, NetworkManager. Отключи SSAO/SSR/SSIL, включи occlusion culling, LOD и запечённое освещение.
          </p>
        </div>
      </div>
    </div>
  );
}

function ExportRow({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between gap-1 rounded-lg border border-cream/5 bg-ink/30 px-1.5 py-1">
      <span className="text-cream/35">{k}</span>
      <span className="font-mono text-[8px] font-bold text-cream/70">{v}</span>
    </div>
  );
}

function PipelineTab() {
  return (
    <div className="grid gap-3 md:grid-cols-2">
      <div className="space-y-3">
        <div className="rounded-2xl border-2 border-cream/10 bg-white/5 p-3">
          <SectionTitle icon="expand">Blender → glTF → Godot</SectionTitle>
          <ol className="space-y-1.5 text-[10px] leading-snug text-cream/55">
            <li><span className="font-bold text-cream">1.</span> Моделируй в масштабе 1 м = 1 unit, персонаж ~1.8 м, оружие ~0.8 м.</li>
            <li><span className="font-bold text-cream">2.</span> Применяй transforms, не оставляй negative scale. Origin — в точке контакта с землёй.</li>
            <li><span className="font-bold text-cream">3.</span> Экспорт glTF 2.0 / GLB: +Y up, -Z forward, apply modifiers, include animations.</li>
            <li><span className="font-bold text-cream">4.</span> В Godot: Import → Mesh → LOD, Physics → Collision, проверь Skeleton3D и AnimationPlayer.</li>
            <li><span className="font-bold text-cream">5.</span> Материалы: StandardMaterial3D (Albedo + Metallic/Roughness) или ShaderMaterial с toon-шейдером.</li>
          </ol>
        </div>
        <div className="rounded-2xl border-2 border-cream/10 bg-white/5 p-3">
          <SectionTitle icon="target">Требования к ассетам</SectionTitle>
          <div className="grid grid-cols-2 gap-1.5">
            <ExportRow k="Персонаж" v="3–8k tris" />
            <ExportRow k="Машина" v="5–15k tris" />
            <ExportRow k="Оружие" v="1–3k tris" />
            <ExportRow k="Текстуры" v="512–1024 px" />
            <ExportRow k="UV" v="0–1, без наложений" />
            <ExportRow k="Анимации" v="30 fps, 6–8 клипов" />
            <ExportRow k="Скелет" v="Humanoid, 20–30 костей" />
            <ExportRow k="Полигоны" v="quads, bevel, без n-gon" />
          </div>
          <p className="mt-2 text-[9px] leading-snug text-cream/35">
                Silhouette first: крупные формы, читаемые пропорции. Bevel 2–4 мм, сглаженные фаски, без «мыла». Атлас текстур на персонажа/оружие.
          </p>
        </div>
      </div>
      <div className="space-y-3">
        <div className="rounded-2xl border-2 border-cream/10 bg-white/5 p-3">
          <SectionTitle icon="bolt">Cartoon-шейдер (Godot 4)</SectionTitle>
          <pre className="overflow-x-auto rounded-xl border-2 border-ink bg-ink/60 p-2.5 font-mono text-[8.5px] leading-relaxed text-lime/90">{`shader_type spatial;
render_mode unshaded, cull_disabled;

uniform vec3 albedo : source_color = vec3(1.0);
uniform vec3 rim_color : source_color = vec3(1.0, 0.7, 0.3);
uniform float rim_power = 2.5;
uniform sampler2D gradient : filter_nearest;

void fragment() {
    float ndl = dot(NORMAL, LIGHT0_DIRECTION) * 0.5 + 0.5;
    float band = texture(gradient, vec2(ndl, 0.0)).r;
    vec3 col = albedo * band;
    float rim = pow(1.0 - max(dot(NORMAL, VIEW), 0.0), rim_power);
    col += rim_color * rim * 0.35;
    ALBEDO = col;
    ROUGHNESS = 0.85;
    METALLIC = 0.0;
}`}</pre>
          <p className="mt-2 text-[9px] leading-snug text-cream/35">
            Для outline добавь дублирующий меш с cull_front и чуть большим масштабом. Rim-light повышает читаемость силуэта на мобильном экране.
          </p>
        </div>
        <div className="rounded-2xl border-2 border-teal/30 bg-teal/10 p-3">
          <div className="flex items-center gap-2">
            <Icon name="check" className="h-4 w-4 text-teal" />
            <p className="font-display text-[11px] font-extrabold uppercase tracking-wider text-teal">Оптимизация под мобильные</p>
          </div>
          <p className="mt-1 text-[10px] leading-snug text-cream/60">
            Mobile-рендер, без SSAO/SSR/SSIL, LOD на зданиях, occlusion culling, запечённое освещение, атласы текстур, Engine.max_fps = 60, пауза при NOTIFICATION_APPLICATION_PAUSED. Этот веб-прототип уже использует low-poly, toon-материалы и пул частиц.
          </p>
        </div>
      </div>
    </div>
  );
}


/* ------------------------------------------------------------------ */
/* Weapon wheel                                                        */
/* ------------------------------------------------------------------ */

const WHEEL_ICONS = ["crosshair", "bolt", "target", "grenade", "ammo", "star"] as const;

export function WeaponWheel({ hud, onSelect, onClose }: { hud: HudState; onSelect: (index: number) => void; onClose: () => void }) {
  return (
    <Modal onClose={onClose} wide>
      <div className="max-h-[88vh] overflow-y-auto p-4 sm:p-5">
        <div className="mb-3 flex items-center gap-2 pr-10">
          <span className="grid h-10 w-10 place-items-center rounded-xl border-[3px] border-ink bg-grape text-ink shadow-[0_3px_0_0_#241a35]">
            <Icon name="swap" className="h-5 w-5" />
          </span>
          <div>
            <h2 className="font-display text-xl font-black uppercase leading-none text-cream">Выбор оружия</h2>
            <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-cream/40">6 стволов · Бой на паузе</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {hud.weapons.map((weapon, i) => {
            const active = i === hud.weaponIndex;
            return (
              <button
                key={weapon.id}
                type="button"
                onClick={() => onSelect(i)}
                className={cn(
                  "group relative overflow-hidden rounded-2xl border-[3px] p-2.5 text-left transition-all",
                  active ? "border-ink bg-cream text-ink shadow-[0_4px_0_0_#241a35]" : "border-cream/15 bg-white/5 text-cream hover:border-cream/30 hover:bg-white/10"
                )}
              >
                <div className="flex items-start gap-2">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border-2 border-ink text-ink shadow-[0_2px_0_0_#241a35]" style={{ backgroundColor: weapon.color }}>
                    <Icon name={WHEEL_ICONS[i]} className="h-5 w-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <span className="truncate font-display text-[11px] font-black uppercase tracking-wide">{weapon.name}</span>
                      {active && <span className="rounded bg-ink px-1 text-[7px] font-black text-sun">В РУКАХ</span>}
                    </div>
                    <p className={cn("mt-0.5 text-[9px] font-bold uppercase tracking-wider", active ? "text-ink/50" : "text-cream/35")}>{weapon.short} · {weapon.ammo}/{weapon.reserve}</p>
                  </div>
                </div>
                <div className="mt-2 flex items-center gap-1">
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full border border-ink/30 bg-ink/20">
                    <div className="h-full rounded-full" style={{ width: `${Math.min(100, (weapon.ammo / Math.max(1, weapon.ammo + weapon.reserve)) * 100)}%`, backgroundColor: weapon.color }} />
                  </div>
                  <span className="font-mono text-[8px] font-bold opacity-50">{i + 1}</span>
                </div>
              </button>
            );
          })}
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border-2 border-cream/10 bg-white/5 px-3 py-2">
          <p className="text-[10px] leading-snug text-cream/45">
            Нажми на слот, чтобы взять оружие. Ближний бой — «Оса» и дробовик, дальний — снайпер и магнум.
          </p>
          <ChunkyButton icon="check" onClick={onClose} className="px-3 py-1.5 text-[10px]">
            В бой
          </ChunkyButton>
        </div>
      </div>
    </Modal>
  );
}


/* ------------------------------------------------------------------ */
/* Server browser                                                      */
/* ------------------------------------------------------------------ */

export interface ServerInfo {
  id: string;
  name: string;
  mode: GameMode;
  players: number;
  maxPlayers: number;
  ping: number;
  map: string;
  region: string;
}

const SERVERS: ServerInfo[] = [
  { id: "s1", name: "Песчаный форт 24/7", mode: "dm", players: 14, maxPlayers: 16, ping: 24, map: "Sand Fort ×2", region: "EU" },
  { id: "s2", name: "SUN vs TIDE", mode: "tdm", players: 12, maxPlayers: 16, ping: 38, map: "Sand Fort ×2", region: "EU" },
  { id: "s3", name: "Мясорубка", mode: "dm", players: 18, maxPlayers: 20, ping: 51, map: "Sand Fort ×2", region: "EU" },
  { id: "s4", name: "Ночная арена", mode: "tdm", players: 8, maxPlayers: 12, ping: 67, map: "Sand Fort ×2", region: "ASIA" },
  { id: "s5", name: "Тренировка ботов", mode: "dm", players: 3, maxPlayers: 16, ping: 12, map: "Sand Fort ×2", region: "EU" },
];

export function ServerBrowser({ onClose, onConnect, nickname }: { onClose: () => void; onConnect: (server: ServerInfo) => void; nickname: string }) {
  const [tab, setTab] = useState<"list" | "create">("list");
  const [connecting, setConnecting] = useState<string | null>(null);
  const [refresh, setRefresh] = useState(0);
  const [name, setName] = useState("Мой сервер");
  const [mode, setMode] = useState<GameMode>("tdm");
  const [maxPlayers, setMaxPlayers] = useState(16);

  const servers = useMemo(
    () =>
      SERVERS.map((s) => ({
        ...s,
        ping: Math.max(8, s.ping + ((refresh * 7 + s.id.charCodeAt(1) * 3) % 17) - 8),
        players: Math.max(1, Math.min(s.maxPlayers, s.players + ((refresh * 3 + s.id.charCodeAt(1)) % 5) - 2)),
      })),
    [refresh]
  );

  const connect = (server: ServerInfo) => {
    if (connecting) return;
    setConnecting(server.id);
    window.setTimeout(() => {
      setConnecting(null);
      onConnect(server);
    }, 850);
  };

  return (
    <Modal onClose={onClose} wide>
      <div className="max-h-[88vh] overflow-y-auto p-4 sm:p-5">
        <div className="mb-3 flex flex-wrap items-center gap-2 pr-10">
          <span className="grid h-10 w-10 place-items-center rounded-xl border-[3px] border-ink bg-teal text-ink shadow-[0_3px_0_0_#241a35]">
            <Icon name="server" className="h-5 w-5" />
          </span>
          <div>
            <h2 className="font-display text-xl font-black uppercase leading-none text-cream">Онлайн-серверы</h2>
            <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-cream/40">Играешь как {nickname || "Игрок"} · Демо-лобби</p>
          </div>
          <div className="ml-auto flex items-center gap-1 rounded-lg border-2 border-lime/30 bg-lime/10 px-2 py-1">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-lime" />
            <span className="text-[9px] font-black uppercase tracking-wider text-lime">1 248 онлайн</span>
          </div>
        </div>

        <div className="mb-3 flex gap-1 rounded-xl border-2 border-cream/10 bg-ink/50 p-1">
          <button
            type="button"
            onClick={() => setTab("list")}
            className={cn("flex flex-1 items-center justify-center gap-1.5 rounded-lg px-2 py-2 text-[10px] font-extrabold uppercase tracking-wider transition-colors", tab === "list" ? "bg-sun text-ink" : "text-cream/50 hover:bg-white/10 hover:text-cream")}
          >
            <Icon name="server" className="h-3.5 w-3.5" /> Список серверов
          </button>
          <button
            type="button"
            onClick={() => setTab("create")}
            className={cn("flex flex-1 items-center justify-center gap-1.5 rounded-lg px-2 py-2 text-[10px] font-extrabold uppercase tracking-wider transition-colors", tab === "create" ? "bg-sun text-ink" : "text-cream/50 hover:bg-white/10 hover:text-cream")}
          >
            <Icon name="bolt" className="h-3.5 w-3.5" /> Создать сервер
          </button>
        </div>

        {tab === "list" ? (
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <ChunkyButton icon="play" onClick={() => connect(servers[0])} className="flex-1 py-2.5 text-xs sm:flex-none">
                Быстрый матч
              </ChunkyButton>
              <button
                type="button"
                onClick={() => setRefresh((r) => r + 1)}
                className="flex items-center gap-1.5 rounded-xl border-2 border-cream/15 bg-white/5 px-3 py-2.5 text-[10px] font-black uppercase tracking-wider text-cream/60 transition-colors hover:bg-white/10 hover:text-cream"
              >
                <Icon name="reload" className="h-3.5 w-3.5" /> Обновить
              </button>
              <span className="ml-auto text-[9px] font-bold uppercase tracking-wider text-cream/30">Регион: EU · Пинг 12–67 мс</span>
            </div>
            <div className="overflow-hidden rounded-2xl border-2 border-cream/10">
              <div className="grid grid-cols-[1fr_58px_54px] gap-1 bg-ink/60 px-2 py-1.5 text-[8px] font-black uppercase tracking-wider text-cream/35 sm:grid-cols-[1fr_70px_64px_54px]">
                <span>Сервер</span>
                <span className="text-center">Режим</span>
                <span className="text-center">Игроки</span>
                <span className="hidden text-center sm:block">Пинг</span>
              </div>
              {servers.map((server) => (
                <div key={server.id} className="grid grid-cols-[1fr_58px_54px] items-center gap-1 border-t border-cream/5 px-2 py-2 sm:grid-cols-[1fr_70px_64px_54px]">
                  <div className="flex min-w-0 items-center gap-2">
                    <span className={cn("h-2 w-2 shrink-0 rounded-full border border-ink", server.ping < 40 ? "bg-lime" : server.ping < 60 ? "bg-sun" : "bg-coral")} />
                    <div className="min-w-0">
                      <p className="truncate font-display text-[10px] font-extrabold text-cream">{server.name}</p>
                      <p className="truncate text-[8px] font-bold uppercase tracking-wider text-cream/30">{server.map} · {server.region}</p>
                    </div>
                  </div>
                  <div className="flex justify-center">
                    <span className={cn("rounded-md border-2 border-ink px-1.5 py-0.5 text-[8px] font-black uppercase text-ink", server.mode === "tdm" ? "bg-teal" : "bg-coral text-white")}>
                      {server.mode === "tdm" ? "TDM" : "DM"}
                    </span>
                  </div>
                  <div className="text-center font-mono text-[10px] font-bold text-cream/60">
                    {server.players}/{server.maxPlayers}
                  </div>
                  <div className="hidden text-center font-mono text-[10px] font-bold text-lime sm:block">{server.ping} ms</div>
                  <button
                    type="button"
                    onClick={() => connect(server)}
                    disabled={!!connecting}
                    className="col-span-3 mt-1 flex items-center justify-center gap-1 rounded-lg border-2 border-ink bg-sun px-2 py-1.5 text-[9px] font-black uppercase tracking-wider text-ink shadow-[0_2px_0_0_#241a35] transition-transform active:translate-y-[1px] disabled:opacity-60 sm:col-span-4"
                  >
                    {connecting === server.id ? (
                      <>
                        <span className="h-3 w-3 animate-spin rounded-full border-2 border-ink/30 border-t-ink" /> Подключение...
                      </>
                    ) : (
                      <>
                        <Icon name="play" className="h-3 w-3" /> Подключиться
                      </>
                    )}
                  </button>
                </div>
              ))}
            </div>
            <p className="rounded-xl border-2 border-cream/10 bg-white/5 px-3 py-2 text-[9px] leading-snug text-cream/35">
              Демо-серверы работают локально и запускают матч с ботами. В Godot-версии этот список подключается к ENet/WebSocket-мастер-серверу, а матч синхронизирует позиции, анимации и выстрелы.
            </p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-2">
              <label className="block rounded-2xl border-2 border-cream/10 bg-white/5 px-3 py-2">
                <span className="mb-1 block text-[9px] font-black uppercase tracking-wider text-cream/40">Название сервера</span>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value.slice(0, 24))}
                  className="w-full bg-transparent font-display text-sm font-extrabold text-cream outline-none placeholder:text-cream/25"
                  placeholder="Мой сервер"
                />
              </label>
              <div>
                <p className="mb-1 text-[9px] font-black uppercase tracking-wider text-cream/40">Режим</p>
                <Segmented
                  options={[
                    { value: "dm", label: "Deathmatch" },
                    { value: "tdm", label: "Team Deathmatch" },
                  ]}
                  value={mode}
                  onChange={setMode}
                />
              </div>
              <Slider label="Максимум игроков" value={maxPlayers} min={8} max={20} step={1} onChange={setMaxPlayers} display={`${maxPlayers}`} />
            </div>
            <div className="flex flex-col justify-between rounded-2xl border-2 border-cream/10 bg-white/5 p-3">
              <div>
                <p className="font-display text-xs font-extrabold uppercase tracking-wider text-cream">Конфигурация</p>
                <div className="mt-2 space-y-1.5 text-[10px] text-cream/50">
                  <div className="flex justify-between"><span>Карта</span><span className="font-mono text-cream/80">Sand Fort ×2</span></div>
                  <div className="flex justify-between"><span>Режим</span><span className="font-mono text-cream/80">{mode === "tdm" ? "TDM 5×5" : "DM"}</span></div>
                  <div className="flex justify-between"><span>Боты</span><span className="font-mono text-cream/80">10</span></div>
                  <div className="flex justify-between"><span>Оружие</span><span className="font-mono text-cream/80">6 стволов</span></div>
                  <div className="flex justify-between"><span>Техника</span><span className="font-mono text-cream/80">Багги · Танк</span></div>
                </div>
              </div>
              <ChunkyButton
                icon="server"
                onClick={() => onConnect({ id: "custom", name: name.trim() || "Мой сервер", mode, players: 1, maxPlayers, ping: 12, map: "Sand Fort ×2", region: "EU" })}
                className="mt-3 w-full py-2.5 text-xs"
              >
                Создать и играть
              </ChunkyButton>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}
