import { useEffect, useRef, useState, type PointerEvent as PE, type ReactNode } from "react";
import { CAPITEC, SHOPS, ZONES, waLink, zoneLabel } from "../data/shops";
import { IMG } from "../media";
import { useStore } from "../store";
import type { MenuItem, Shop } from "../types";
import {
  IconArrow,
  IconBag,
  IconBank,
  IconBell,
  IconCash,
  IconCheck,
  IconCopy,
  IconHome,
  IconMinus,
  IconPin,
  IconPlus,
  IconSearch,
  IconStar,
  IconUser,
  IconWA,
  IconX,
} from "./Icons";

function Dock({ active }: { active: "home" | "search" | "orders" | "profile" }) {
  const { setModal, close, count } = useStore();
  const item = (id: typeof active, label: string, icon: ReactNode, on: () => void) => (
    <button onClick={on} className={`flex flex-col items-center gap-0.5 text-[10px] font-bold ${active === id ? "text-[#FF6A00]" : "text-white/40"}`}>
      {icon}
      {label}
    </button>
  );
  return (
    <div className="grid grid-cols-4 border-t border-white/8 bg-[#0d0d0d] px-2 py-2.5">
      {item("home", "Home", <IconHome className="h-5 w-5" />, close)}
      {item("search", "Search", <IconSearch className="h-5 w-5" />, () => setModal("search"))}
      <button onClick={() => setModal("cart")} className="relative flex flex-col items-center gap-0.5 text-[10px] font-bold text-white/40">
        <span className="relative">
          <IconBag className="h-5 w-5" />
          {count > 0 && (
            <span className="absolute -right-2 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-[#FF6A00] px-1 text-[9px] text-white">{count}</span>
          )}
        </span>
        Orders
      </button>
      {item("profile", "Profile", <IconUser className="h-5 w-5" />, () => setModal("auth"))}
    </div>
  );
}

function Frame({ children }: { children: ReactNode }) {
  const { close } = useStore();
  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center md:items-center">
      <button className="absolute inset-0 bg-black/70 fade" onClick={close} aria-label="Close" />
      <div className="sheet relative flex h-[100dvh] w-full max-w-[400px] flex-col overflow-hidden bg-[#0d0d0d] text-white md:h-[90vh] md:rounded-[28px]">
        {children}
      </div>
    </div>
  );
}

export function MenuModal() {
  const { modal, shop, close, addItem, setModal, total, count } = useStore();
  const [cat, setCat] = useState("Popular");
  const [pulse, setPulse] = useState<string | null>(null);
  const [slide, setSlide] = useState(0);
  const start = useRef({ x: 0, y: 0 });

  useEffect(() => {
    setCat("Popular");
  }, [shop?.id]);

  if (modal !== "menu" || !shop?.menu) return null;

  const cats = ["Popular", ...Array.from(new Set(shop.menu.map((m) => m.category)))];
  const items = cat === "Popular" ? shop.menu.slice(0, 8) : shop.menu.filter((m) => m.category === cat);
  const idx = Math.max(0, cats.indexOf(cat));

  const goCat = (dir: number) => {
    const next = idx + dir;
    if (next < 0 || next >= cats.length) return;
    setSlide(dir);
    window.setTimeout(() => {
      setCat(cats[next]);
      setSlide(0);
    }, 150);
  };

  const down = (e: PE<HTMLDivElement>) => {
    start.current = { x: e.clientX, y: e.clientY };
  };
  const up = (e: PE<HTMLDivElement>) => {
    const dx = e.clientX - start.current.x;
    const dy = e.clientY - start.current.y;
    if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy)) return;
    goCat(dx < 0 ? 1 : -1);
  };

  const add = (item: MenuItem) => {
    addItem(shop, item);
    setPulse(item.id);
    window.setTimeout(() => setPulse(null), 500);
  };

  return (
    <Frame>
      <div className="flex items-center justify-between px-4 pt-4">
        <button onClick={close} className="grid h-9 w-9 place-items-center rounded-full bg-white/8">
          <IconX className="h-4 w-4" />
        </button>
        <button className="grid h-9 w-9 place-items-center rounded-full bg-white/8">
          <IconBell className="h-4 w-4" />
        </button>
      </div>
      <div className="px-5 pt-3">
        <h2 className="text-[28px] font-extrabold leading-none">{shop.name}</h2>
        <div className="mt-2 flex flex-wrap items-center gap-2 text-[12px] text-white/55">
          <span className="inline-flex items-center gap-1 font-semibold text-white">
            <IconStar className="h-3.5 w-3.5 text-[#FF6A00]" /> {shop.rating.toFixed(1)}
          </span>
          <span>({shop.reviews}+)</span>
          <span>· {shop.eta}</span>
          <span>· {zoneLabel(shop.zone)}</span>
        </div>
      </div>
      <div className="relative mx-5 mt-4 overflow-hidden rounded-2xl">
        <img src={shop.image} alt="" className="h-36 w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/20 to-transparent" />
        <p className="absolute bottom-4 left-4 text-[20px] font-extrabold uppercase leading-none">
          {shop.name.split(" ")[0]}
          <br />
          <span className="text-[#FF6A00]">tap to add</span>
        </p>
      </div>
      <div className="hide-scroll mt-4 flex gap-2 overflow-x-auto px-5">
        {cats.map((c) => (
          <button key={c} onClick={() => setCat(c)} className={`shrink-0 rounded-full px-3 py-1.5 text-[12px] font-bold ${cat === c ? "bg-[#FF6A00]" : "bg-white/8 text-white/65"}`}>
            {c === "Popular" ? "Popular Picks" : c}
          </button>
        ))}
      </div>
      <p className="px-5 pt-2 text-[11px] text-white/40">Swipe left or right to change menu · or tap a chip</p>
      <div
        className="hide-scroll mt-1 flex-1 touch-pan-y space-y-1 overflow-y-auto px-4 pb-2"
        onPointerDown={down}
        onPointerUp={up}
        style={{
          transform: slide ? `translate3d(${slide * -22}px,0,0)` : "none",
          opacity: slide ? 0.55 : 1,
          transition: "transform .15s ease, opacity .15s ease",
        }}
      >
        {items.map((item) => (
          <div key={item.id} className="flex items-center gap-3 rounded-2xl px-1 py-2">
            <img src={item.image} alt="" className="h-14 w-14 shrink-0 rounded-xl object-cover" />
            <div className="min-w-0 flex-1">
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-[14px] font-bold leading-tight">{item.name}</h3>
                <span className="shrink-0 text-[14px] font-extrabold">R{item.price}</span>
              </div>
              <p className="mt-0.5 line-clamp-2 text-[11px] leading-snug text-white/45">{item.description}</p>
            </div>
            <button onClick={() => add(item)} className={`grid h-8 w-8 shrink-0 place-items-center rounded-full press ${pulse === item.id ? "bg-white text-black" : "bg-[#FF6A00]"}`}>
              {pulse === item.id ? <IconCheck className="h-4 w-4" /> : <IconPlus className="h-4 w-4" />}
            </button>
          </div>
        ))}
        <div className="mt-3 flex items-center justify-between pb-2 text-[11px] font-bold text-white/45">
          <button type="button" onClick={() => goCat(-1)} disabled={idx <= 0} className="disabled:opacity-30">
            ← {idx > 0 ? (cats[idx - 1] === "Popular" ? "Popular" : cats[idx - 1]) : ""}
          </button>
          <span className="text-[#FF6A00]">{cat === "Popular" ? "Popular Picks" : cat}</span>
          <button type="button" onClick={() => goCat(1)} disabled={idx >= cats.length - 1} className="disabled:opacity-30">
            {idx < cats.length - 1 ? cats[idx + 1] : ""} →
          </button>
        </div>
      </div>
      {count > 0 && (
        <button onClick={() => setModal("cart")} className="mx-4 mb-2 flex h-12 items-center justify-between rounded-full bg-[#FF6A00] px-4 text-sm font-bold press">
          <span className="inline-flex items-center gap-2">
            <span className="grid h-6 w-6 place-items-center rounded-full bg-black/20 text-xs">{count}</span>
            View Cart
          </span>
          <span>R{total}</span>
        </button>
      )}
      <Dock active="home" />
    </Frame>
  );
}

export function OrderPrompt() {
  const { modal, shop, close, addCustom, setModal, setZone } = useStore();
  const [want, setWant] = useState("");
  const [price, setPrice] = useState("");
  if (modal !== "prompt" || !shop) return null;
  const submit = () => {
    if (!want.trim()) return;
    setZone(shop.zone);
    addCustom(shop, want.trim(), want.trim(), Number(price) || 0);
    setModal("cart");
  };
  return (
    <Frame>
      <div className="relative h-44">
        <img src={shop.image} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] to-transparent" />
        <button onClick={close} className="absolute left-4 top-4 grid h-9 w-9 place-items-center rounded-full bg-black/50">
          <IconX className="h-4 w-4" />
        </button>
      </div>
      <div className="flex-1 px-5 pb-4">
        <p className="text-[11px] font-bold uppercase tracking-widest text-[#FF6A00]">{zoneLabel(shop.zone)}</p>
        <h2 className="mt-1 text-[26px] font-extrabold">{shop.name}</h2>
        <p className="mt-1 text-sm text-white/50">{shop.tagline}</p>
        <p className="mt-5 text-sm font-bold">What do you want to order?</p>
        <textarea value={want} onChange={(e) => setWant(e.target.value)} rows={4} placeholder="Type the items you want" className="field mt-3" />
        <input value={price} onChange={(e) => setPrice(e.target.value.replace(/[^\d.]/g, ""))} placeholder="Estimated total (optional)" className="field mt-2" />
        <div className="mt-4 grid grid-cols-2 gap-2">
          <a href={waLink(`Hi TurfBuddy, I want to order from ${shop.name}:\n${want || "(I'll type my items)"}`)} target="_blank" rel="noreferrer" className="flex h-12 items-center justify-center gap-2 rounded-full border border-white/12 text-sm font-bold">
            <IconWA className="h-4 w-4" /> WhatsApp
          </a>
          <button onClick={submit} disabled={!want.trim()} className="h-12 rounded-full bg-[#FF6A00] text-sm font-bold disabled:opacity-40">
            Add to cart
          </button>
        </div>
      </div>
      <Dock active="search" />
    </Frame>
  );
}

export function CartDrawer() {
  const { modal, cart, setQty, subtotal, delivery, total, setModal, close, clearCart, count } = useStore();
  const [note, setNote] = useState("");
  if (modal !== "cart") return null;
  return (
    <Frame>
      <div className="flex items-center justify-between px-5 pt-5">
        <div className="flex items-center gap-2">
          <button onClick={close} className="grid h-8 w-8 place-items-center">
            <IconX className="h-4 w-4" />
          </button>
          <div>
            <h2 className="text-[22px] font-extrabold leading-none">Your Cart</h2>
            <p className="mt-1 text-[12px] text-white/40">{count} items</p>
          </div>
        </div>
        {cart.length > 0 && (
          <button onClick={clearCart} className="text-[13px] font-bold text-[#FF6A00]">
            Clear
          </button>
        )}
      </div>
      <div className="hide-scroll mt-4 flex-1 space-y-3 overflow-y-auto px-5">
        {!cart.length && <p className="py-16 text-center text-sm text-white/40">Your cart is empty.</p>}
        {cart.map((c) => (
          <div key={c.key} className="flex items-center gap-3">
            <img src={c.image} alt="" className="h-14 w-14 rounded-xl object-cover" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[14px] font-bold">{c.name}</p>
              <p className="text-[11px] text-white/40">{c.shopName}</p>
            </div>
            <span className="text-[14px] font-extrabold">R{c.price * c.qty}</span>
            <div className="flex items-center gap-2 rounded-full bg-[#1c1c1c] px-1.5 py-1">
              <button onClick={() => setQty(c.key, c.qty - 1)} className="grid h-6 w-6 place-items-center">
                <IconMinus className="h-3.5 w-3.5" />
              </button>
              <span className="w-3 text-center text-sm font-bold">{c.qty}</span>
              <button onClick={() => setQty(c.key, c.qty + 1)} className="grid h-6 w-6 place-items-center">
                <IconPlus className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        ))}
        {cart.length > 0 && (
          <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Add a note (optional)" className="field mt-2" rows={2} />
        )}
        <div className="pt-2 text-[14px]">
          <Row label="Subtotal" value={`R${subtotal}`} />
          <Row label="Delivery Fee" value={cart.length ? `R${delivery}` : "—"} />
          <Row label="Total" value={`R${cart.length ? total : 0}`} bold />
        </div>
      </div>
      <div className="p-4">
        <button disabled={!cart.length} onClick={() => setModal("checkout")} className="h-12 w-full rounded-full bg-[#FF6A00] text-[15px] font-bold disabled:opacity-40">
          Checkout
        </button>
      </div>
      <Dock active="orders" />
    </Frame>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className={`flex items-center justify-between py-1.5 ${bold ? "text-[16px] font-extrabold" : "text-white/55"}`}>
      <span>{label}</span>
      <span className={bold ? "text-white" : ""}>{value}</span>
    </div>
  );
}

export function Checkout() {
  const { modal, cart, total, zone, setZone, user, placeOrder, setModal } = useStore();
  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [address, setAddress] = useState("");
  const [pay, setPay] = useState<"cash" | "capitec">("cash");
  const [when, setWhen] = useState<"asap" | "schedule">("asap");
  const [scheduleAt, setScheduleAt] = useState("");
  const [note, setNote] = useState("");
  const [copied, setCopied] = useState(false);
  const [paying, setPaying] = useState(false);
  if (modal !== "checkout") return null;

  const copyAcc = async () => {
    try {
      await navigator.clipboard.writeText(CAPITEC.account);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      /* ignore */
    }
  };

  const send = () => {
    if (!name.trim() || !phone.trim() || !address.trim() || !cart.length || paying) return;
    setPaying(true);
    window.setTimeout(() => {
    const order = placeOrder({
      name: name.trim(),
      phone: phone.trim(),
      address: address.trim(),
      zone,
      payment: pay,
      when,
      scheduleAt,
      note,
    });
    const lines = [
      `*TURFBUDDY ORDER #${order.id}*`,
      `Name: ${order.name}`,
      `Phone: ${order.phone}`,
      `Ordering From: ${zoneLabel(order.zone)}`,
      `Address: ${order.address}`,
      `When: ${when === "asap" ? "ASAP (30–45 min)" : scheduleAt || "Scheduled"}`,
      `Payment: ${pay === "cash" ? "Cash on Delivery" : `Capitec EFT ${CAPITEC.account} ${CAPITEC.name}`}`,
      "",
      "*ITEMS*",
      ...order.items.map((i) => `• ${i.qty}x ${i.name} (${i.shopName}) — R${i.price * i.qty}`),
      "",
      `Subtotal: R${order.subtotal}`,
      `Delivery: R${order.delivery}`,
      `*Total: R${order.total}*`,
      order.note ? `\nNote: ${order.note}` : "",
    ];
    window.open(waLink(lines.filter(Boolean).join("\n")), "_blank");
      setPaying(false);
    }, 900);
  };

  return (
    <Frame>
      <div className="flex items-center gap-2 px-4 pt-5">
        <button onClick={() => setModal("cart")} className="grid h-8 w-8 place-items-center">
          <IconArrow className="h-4 w-4 rotate-180" />
        </button>
        <h2 className="text-[22px] font-extrabold">Checkout</h2>
      </div>
      <div className="hide-scroll mt-4 flex-1 space-y-3 overflow-y-auto px-4 pb-3">
        <section className="rounded-2xl bg-[#1a1a1a] p-4">
          <h3 className="text-sm font-bold">Delivery Address</h3>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" className="field mt-3" />
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone number" className="field mt-2" />
          <input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Residence / street / room" className="field mt-2" />
          <select value={zone} onChange={(e) => setZone(e.target.value as typeof zone)} className="field mt-2">
            {ZONES.map((z) => (
              <option key={z.id} value={z.id}>
                Ordering From {z.label} · R{z.fee}
              </option>
            ))}
          </select>
        </section>
        <section className="rounded-2xl bg-[#1a1a1a] p-4">
          <h3 className="text-sm font-bold">Delivery Time</h3>
          <button onClick={() => setWhen("asap")} className="mt-3 flex w-full items-center gap-2 py-2 text-sm">
            <span className={`grid h-4 w-4 place-items-center rounded-full border ${when === "asap" ? "border-[#FF6A00]" : "border-white/30"}`}>
              {when === "asap" && <span className="h-2 w-2 rounded-full bg-[#FF6A00]" />}
            </span>
            ASAP (30–45 min)
          </button>
          <button onClick={() => setWhen("schedule")} className="flex w-full items-center gap-2 py-2 text-sm">
            <span className={`grid h-4 w-4 place-items-center rounded-full border ${when === "schedule" ? "border-[#FF6A00]" : "border-white/30"}`}>
              {when === "schedule" && <span className="h-2 w-2 rounded-full bg-[#FF6A00]" />}
            </span>
            Schedule Order
          </button>
          {when === "schedule" && <input type="datetime-local" value={scheduleAt} onChange={(e) => setScheduleAt(e.target.value)} className="field mt-2" />}
        </section>
        <section className="rounded-2xl bg-[#1a1a1a] p-4">
          <h3 className="text-sm font-bold">Payment Method</h3>
          <button onClick={() => setPay("cash")} className="mt-3 flex w-full items-center justify-between py-2 text-sm">
            <span className="inline-flex items-center gap-2 font-semibold">
              <IconCash className="h-4 w-4" /> Cash on Delivery
            </span>
          </button>
          <button onClick={() => setPay("capitec")} className="flex w-full items-center justify-between py-2 text-sm">
            <span className="inline-flex items-center gap-2 font-semibold">
              <IconBank className="h-4 w-4" /> Capitec / Card Payment
            </span>
          </button>
          {pay === "capitec" && (
            <div className="mt-3 rounded-xl border border-[#FF6A00]/30 bg-black/30 p-3">
              <p className="text-[11px] font-bold uppercase tracking-widest text-[#FF6A00]">Pay to Capitec</p>
              <p className="mt-1 font-bold">{CAPITEC.name}</p>
              <p className="mt-1 flex items-center justify-between font-mono text-lg">
                {CAPITEC.account}
                <button onClick={copyAcc} className="inline-flex items-center gap-1 rounded-full bg-white/10 px-2 py-1 text-[11px]">
                  <IconCopy className="h-3 w-3" /> {copied ? "Copied" : "Copy"}
                </button>
              </p>
              <p className="mt-1 text-xs text-white/50">Linked number {CAPITEC.phone}</p>
            </div>
          )}
        </section>
        <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Delivery note" rows={2} className="field" />
      </div>
      <div className="flex items-center justify-between gap-3 border-t border-white/8 p-4">
        <div>
          <p className="text-[11px] text-white/40">Total</p>
          <p className="text-[22px] font-extrabold">R{total}</p>
        </div>
        <button onClick={send} disabled={!name.trim() || !phone.trim() || !address.trim() || paying} className="h-12 flex-1 rounded-full bg-[#FF6A00] text-sm font-bold disabled:opacity-40">
          {paying ? "Processing…" : "Place Order"}
        </button>
      </div>
    </Frame>
  );
}

export function Success() {
  const { modal, order, close } = useStore();
  if (modal !== "success" || !order) return null;
  return (
    <div className="fixed inset-0 z-[80] grid place-items-center bg-black/70 fade">
      <div className="pop mx-4 w-full max-w-[380px] rounded-3xl bg-[#141414] p-8 text-center text-white">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#1F8A4C]">
          <IconCheck className="h-8 w-8" />
        </div>
        <h2 className="mt-4 text-2xl font-extrabold">Order placed</h2>
        <p className="mt-2 text-sm text-white/55">#{order.id} is on WhatsApp. We will confirm and start the run.</p>
        <p className="mt-4 text-3xl font-extrabold text-[#FF6A00]">R{order.total}</p>
        <button onClick={close} className="mt-6 h-11 w-full rounded-full bg-[#1F8A4C] text-sm font-bold">
          Done
        </button>
      </div>
    </div>
  );
}

export function AuthModal() {
  const { modal, close, setUser, user } = useStore();
  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  if (modal !== "auth") return null;
  return (
    <Frame>
      <div className="px-6 pt-8">
        <button onClick={close} className="mb-6">
          <IconX className="h-4 w-4" />
        </button>
        <h2 className="text-[28px] font-extrabold">{user ? "Your profile" : "Login"}</h2>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" className="field mt-6" />
        <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone" className="field mt-2" />
        <button
          onClick={() => {
            if (name.trim() && phone.trim()) {
              setUser({ name: name.trim(), phone: phone.trim() });
              close();
            }
          }}
          className="mt-5 h-12 w-full rounded-full bg-[#FF6A00] text-sm font-bold"
        >
          Continue
        </button>
      </div>
      <div className="mt-auto">
        <Dock active="profile" />
      </div>
    </Frame>
  );
}

export function SearchScreen() {
  const { modal, query, setQuery, openShop, setModal } = useStore();
  const [q, setQ] = useState(query);
  if (modal !== "search") return null;
  const list = SHOPS.filter((s) => !q || s.name.toLowerCase().includes(q.toLowerCase()) || s.tagline.toLowerCase().includes(q.toLowerCase()));
  return (
    <Frame>
      <div className="px-4 pt-4">
        <div className="flex items-center gap-2 text-[12px] text-white/50">
          <IconPin className="h-3.5 w-3.5 text-[#FF6A00]" /> Search
          <button onClick={() => setModal(null)} className="ml-auto">
            <IconX className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-3 flex items-center gap-2 rounded-full bg-[#1a1a1a] px-4 py-3">
          <IconSearch className="h-4 w-4 text-white/40" />
          <input
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setQuery(e.target.value);
            }}
            placeholder="Search shops or meals"
            className="w-full bg-transparent text-sm outline-none"
          />
        </div>
      </div>
      <div className="hide-scroll mt-3 flex-1 overflow-y-auto px-4 pb-2">
        {list.map((s) => (
          <ShopRow key={s.id} shop={s} onOpen={() => openShop(s)} />
        ))}
      </div>
      <Dock active="search" />
    </Frame>
  );
}

function ShopRow({ shop, onOpen }: { shop: Shop; onOpen: () => void }) {
  return (
    <button onClick={onOpen} className="mb-2 flex w-full items-center gap-3 rounded-2xl bg-[#141414] p-2 text-left">
      <img src={shop.image} alt="" className="h-14 w-14 rounded-xl object-cover" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-[14px] font-bold">{shop.name}</p>
        <p className="text-[11px] text-white/45">
          ★ {shop.rating} · {zoneLabel(shop.zone)}
        </p>
      </div>
    </button>
  );
}

export function Splash() {
  const { modal, setModal } = useStore();
  if (modal !== "splash") return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center md:items-center">
      <button className="absolute inset-0 bg-black/50 fade" onClick={() => setModal(null)} />
      <div className="sheet relative flex h-[100dvh] w-full max-w-[400px] flex-col overflow-hidden bg-[#1F8A4C] text-white md:h-[90vh] md:rounded-[28px]">
        <div className="px-8 pt-16">
          <p className="text-[48px] font-extrabold leading-none">TurfBuddy</p>
        </div>
        <img src={IMG.rider} alt="" className="mx-auto mt-6 h-[240px] w-[85%] rounded-3xl object-cover" />
        <div className="mt-auto px-8 pb-10">
          <button onClick={() => setModal("search")} className="h-12 w-full rounded-full bg-white text-sm font-bold text-[#171717]">
            Get Started
          </button>
        </div>
      </div>
    </div>
  );
}

export function Overlays() {
  return (
    <>
      <MenuModal />
      <OrderPrompt />
      <CartDrawer />
      <Checkout />
      <Success />
      <AuthModal />
      <SearchScreen />
      <Splash />
    </>
  );
}
