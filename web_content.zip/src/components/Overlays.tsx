import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Check,
  Compass,
  Crown,
  Droplet,
  Flame,
  Footprints,
  Gamepad2,
  Heart,
  Home,
  Keyboard,
  Landmark,
  Moon,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  Swords,
  Trophy,
  Volume2,
  VolumeX,
} from "lucide-react";
import { DuneRings, Ornament } from "./Brand";
import { ScoreTable } from "./HighScores";
import type { RunResult, ScoreEntry } from "@/game/types";
import { formatScore, formatTime } from "@/lib/scores";

const badge = "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-medium";

export function StartOverlay({
  onStart,
  bestScore,
  scores,
  playerName,
  onNameChange,
  muted,
  onMute,
}: {
  onStart: () => void;
  bestScore: number;
  scores: ScoreEntry[];
  playerName: string;
  onNameChange: (value: string) => void;
  muted: boolean;
  onMute: () => void;
}) {
  const [nameOpen, setNameOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (nameOpen) inputRef.current?.focus();
  }, [nameOpen]);

  return (
    <div className="absolute inset-0 z-40 overflow-y-auto no-scrollbar">
      <div className="absolute inset-0 bg-[linear-gradient(258deg,rgba(6,20,17,0.9)_0%,rgba(7,24,20,0.8)_44%,rgba(9,28,23,0.44)_100%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_52%_at_74%_46%,rgba(4,16,13,0.5),rgba(6,22,18,0.12)_62%,transparent_82%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_78%_2%,rgba(227,185,116,0.16),transparent_55%)]" />
      <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-[#061713]/70 to-transparent" />
      <DuneRings className="pointer-events-none absolute -left-16 bottom-10 h-[360px] w-[360px] text-[#e3b974]/20 sm:-left-6 sm:bottom-0 sm:h-[440px] sm:w-[440px]" />
      <div className="pointer-events-none absolute left-[16%] top-[-18%] hidden h-[420px] w-[420px] rounded-full border border-[#e3b974]/15 sm:block" />
      <div className="pointer-events-none absolute left-[12%] top-[-24%] hidden h-[520px] w-[520px] rounded-full border border-[#e3b974]/10 sm:block" />

      <div className="relative flex min-h-full w-full flex-col justify-between gap-4 p-4 sm:p-7 lg:p-9">
        <div className="flex items-center justify-between gap-2">
          <div className={`${badge} animate-fade-in border-[#f0d9a8]/25 bg-[#f0d9a8]/10 text-[#f0d9a8]`}>
            <Flame className="h-3 w-3" />
            <span>مغامرة · بقاء · عالم مفتوح مصغّر</span>
          </div>
          <button
            onClick={onMute}
            aria-label={muted ? "تشغيل الصوت" : "كتم الصوت"}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-[#f0d9a8]/25 bg-[#f0d9a8]/10 text-[#f0d9a8] transition hover:bg-[#f0d9a8]/20"
          >
            {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
          </button>
        </div>

        <div className="my-auto max-w-[610px] animate-fade-up py-2 sm:py-0">
          <div className="mb-2 flex items-center gap-2 text-[10px] font-medium tracking-[0.2em] text-[#e3b974]">
            <span className="h-px w-6 bg-[#e3b974]/60" />
            آخر واحة في الرمال
          </div>
          <h1 className="font-display text-[clamp(3.7rem,10vw,6rem)] font-bold leading-[0.95] text-[#f8eeda] drop-shadow-[0_4px_24px_rgba(0,0,0,0.35)]">
            سِراب
          </h1>
          <p className="mt-2 font-display text-[clamp(1.05rem,2.8vw,1.45rem)] leading-snug text-[#e9ca96]">
            واحة تتنفّس تحت الرمال.
          </p>
          <p className="mt-3 max-w-[470px] text-[12px] font-normal leading-[1.9] text-[#f0e6d1]/95 sm:text-[13px]">
            أنت آخر من يحمل النار. اجمع ذرات النور في الواحة المفتوحة، أيقظ الأضرحة الثلاثة، وواجه
            ظلال الغسق قبل أن ينطفئ سراجك.
          </p>

          <div className="mt-4 grid max-w-[450px] grid-cols-3 gap-1.5">
            {[
              { icon: <Sparkles className="h-3.5 w-3.5" />, title: "اجمع النور", sub: "سلسلة مضاعفة" },
              { icon: <Landmark className="h-3.5 w-3.5" />, title: "أيقظ ٣ أضرحة", sub: "أطلق الدورة" },
              { icon: <Swords className="h-3.5 w-3.5" />, title: "اهزم الظلال", sub: "وابقَ حيًّا" },
            ].map((item) => (
              <div
                key={item.title}
                className="rounded-xl border border-[#f0d9a8]/12 bg-[#102620]/45 px-2 py-2 backdrop-blur-sm"
              >
                <span className="mb-1 flex h-6 w-6 items-center justify-center rounded-full border border-[#e3b974]/30 bg-[#e3b974]/10 text-[#f0cd8b]">
                  {item.icon}
                </span>
                <p className="text-[10px] font-semibold leading-tight text-[#f2e6ce]">{item.title}</p>
                <p className="mt-0.5 text-[8px] text-[#d8c9aa]/60">{item.sub}</p>
              </div>
            ))}
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2.5">
            <button
              onClick={onStart}
              className="btn-primary group flex min-h-[48px] items-center gap-2.5 rounded-2xl px-5 py-3 text-sm font-bold sm:px-7"
            >
              <Compass className="h-4 w-4" strokeWidth={2.2} />
              ابدأ الرحلة
              <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
            </button>
            <div className="desktop-hint items-center gap-1.5 text-[10px] text-[#d8c9aa]/70">
              <kbd className="rounded-md border border-[#f0d9a8]/25 bg-[#f0d9a8]/10 px-1.5 py-0.5 font-sans text-[9px] text-[#f0d9a8]">
                Enter
              </kbd>
              للبدء
            </div>
            <button
              onClick={() => setNameOpen((v) => !v)}
              className="flex items-center gap-1.5 rounded-full border border-[#f0d9a8]/20 bg-[#f0d9a8]/5 px-2.5 py-1.5 text-[10px] text-[#f0d9a8]/85 transition hover:bg-[#f0d9a8]/15"
            >
              <Crown className="h-3 w-3" />
              <span className="max-w-[100px] truncate">{playerName}</span>
              <span className="text-[#f0d9a8]/40">تعديل</span>
            </button>
          </div>

          {nameOpen && (
            <div className="animate-fade-in mt-2 flex max-w-[300px] items-center gap-1.5">
              <input
                ref={inputRef}
                value={playerName}
                maxLength={18}
                onChange={(e) => onNameChange(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    setNameOpen(false);
                    e.stopPropagation();
                  }
                }}
                placeholder="اسم المسافر"
                className="h-8 w-full rounded-lg border border-[#f0d9a8]/25 bg-[#0d221e]/80 px-2.5 text-[11px] text-[#f8eeda] outline-none placeholder:text-[#d8c9aa]/35 focus:border-[#e3b974]/60"
              />
              <button
                onClick={() => setNameOpen(false)}
                className="flex h-8 items-center gap-1 rounded-lg bg-[#e3b974] px-2 text-[10px] font-semibold text-[#142e28]"
              >
                <Check className="h-3 w-3" />
                تم
              </button>
            </div>
          )}

          <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[9.5px] text-[#d8c9aa]/70 sm:text-[10px]">
            <span className="flex items-center gap-1.5">
              <Keyboard className="h-3 w-3 text-[#e3b974]/80" />
              <kbd className="font-sans text-[#f0e5cf]">WASD</kbd> حركة
            </span>
            <span className="flex items-center gap-1.5">
              <kbd className="rounded border border-[#f0d9a8]/20 px-1 font-sans text-[#f0e5cf]">Space</kbd> هجوم
            </span>
            <span className="flex items-center gap-1.5">
              <kbd className="rounded border border-[#f0d9a8]/20 px-1 font-sans text-[#f0e5cf]">Shift</kbd> اندفاع
            </span>
            <span className="flex items-center gap-1.5">
              <kbd className="rounded border border-[#f0d9a8]/20 px-1 font-sans text-[#f0e5cf]">E</kbd> تفاعل
            </span>
            <span className="flex items-center gap-1.5 sm:hidden">
              <Gamepad2 className="h-3 w-3 text-[#e3b974]/80" />
              عصا لمس + أزرار
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-end justify-between gap-2 border-t border-[#f0d9a8]/12 pt-3">
          <div className="flex items-center gap-2 text-[10px] text-[#d8c9aa]/65">
            <span className="flex h-6 w-6 items-center justify-center rounded-full border border-[#f0d9a8]/20">
              <Trophy className="h-3 w-3 text-[#e3b974]" />
            </span>
            أفضل مسار:
            <span className="nums font-semibold text-[#f5dba4]">{bestScore > 0 ? formatScore(bestScore) : "—"}</span>
          </div>
          <div className="hidden items-center gap-1.5 text-[9px] text-[#d8c9aa]/45 sm:flex">
            <Moon className="h-2.5 w-2.5" />
            الظلال تزداد قوة مع الغسق
            <span className="mx-1 h-1 w-1 rounded-full bg-[#e3b974]/40" />
            {scores.length > 0 ? `${scores.length} مسارات محفوظة` : "أول مسار لك"}
          </div>
        </div>
      </div>
    </div>
  );
}

export function PauseOverlay({
  onResume,
  onRestart,
  onHome,
  muted,
  onMute,
}: {
  onResume: () => void;
  onRestart: () => void;
  onHome: () => void;
  muted: boolean;
  onMute: () => void;
}) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center overflow-y-auto bg-[#071713]/60 p-3 backdrop-blur-[3px] sm:p-5">
      <div className="animate-pop relative w-full max-w-[400px] overflow-hidden rounded-[26px] border border-[#e3b974]/25 bg-[#102620]/96 p-5 text-[#f6ecd8] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.8)] sm:p-7">
        <div className="pointer-events-none absolute -left-16 -top-20 h-52 w-52 rounded-full border border-[#e3b974]/10" />
        <div className="pointer-events-none absolute -left-8 -top-12 h-36 w-36 rounded-full border border-[#e3b974]/10" />
        <div className="mb-4 flex items-start justify-between">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-[#e3b974]/35 bg-[#e3b974]/12">
            <Pause className="h-5 w-5 text-[#f0cd8b]" fill="currentColor" />
          </div>
          <button
            onClick={onMute}
            aria-label={muted ? "تشغيل الصوت" : "كتم الصوت"}
            className="flex h-8 w-8 items-center justify-center rounded-full border border-[#f0d9a8]/20 text-[#d8c9aa] transition hover:bg-[#f0d9a8]/10"
          >
            {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
          </button>
        </div>
        <p className="mb-1 text-[9px] font-medium uppercase tracking-[0.24em] text-[#e3b974]">استراحة مؤقتة</p>
        <h2 className="font-display text-3xl leading-tight text-[#f8eeda]">استراحة في الظل</h2>
        <p className="mt-2 text-[11px] leading-relaxed text-[#d8c9aa]/80">
          الوقت يتوقف هنا. خُذ نفسًا — الظلال تنتظر خارج دائرة الضوء.
        </p>
        <Ornament className="my-4 h-2.5 w-24 text-[#e3b974]/60" />
        <div className="space-y-2">
          <button
            onClick={onResume}
            className="btn-primary flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl text-sm font-bold"
          >
            <Play className="h-4 w-4" fill="currentColor" />
            متابعة الرحلة
            <kbd className="mr-auto hidden rounded border border-[#142e28]/20 px-1.5 py-0.5 text-[9px] font-medium opacity-60 sm:block">
              Esc
            </kbd>
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onRestart}
              className="flex min-h-[42px] items-center justify-center gap-1.5 rounded-xl border border-[#f0d9a8]/20 bg-[#f0d9a8]/[0.06] text-[11px] font-medium text-[#f1e4cb] transition hover:bg-[#f0d9a8]/12"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              من جديد
            </button>
            <button
              onClick={onHome}
              className="flex min-h-[42px] items-center justify-center gap-1.5 rounded-xl border border-[#f0d9a8]/20 bg-[#f0d9a8]/[0.06] text-[11px] font-medium text-[#f1e4cb] transition hover:bg-[#f0d9a8]/12"
            >
              <Home className="h-3.5 w-3.5" />
              القائمة
            </button>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-[9px] text-[#d8c9aa]/55">
          <span><kbd className="font-sans text-[#f0d9a8]">WASD</kbd> حركة</span>
          <span><kbd className="font-sans text-[#f0d9a8]">Space</kbd> هجوم</span>
          <span><kbd className="font-sans text-[#f0d9a8]">Shift</kbd> اندفاع</span>
          <span><kbd className="font-sans text-[#f0d9a8]">E</kbd> تفاعل</span>
        </div>
      </div>
    </div>
  );
}

export function GameOverOverlay({
  result,
  scores,
  savedRank,
  playerName,
  entryId,
  onNameChange,
  onRestart,
  onHome,
}: {
  result: RunResult;
  scores: ScoreEntry[];
  savedRank: number | null;
  playerName: string;
  entryId: string | null;
  onNameChange: (name: string) => void;
  onRestart: () => void;
  onHome: () => void;
}) {
  const isBest = result.score > 0 && scores.length > 0 && scores[0].score === result.score && scores[0].name === playerName;
  const newBest = savedRank === 1;

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center overflow-y-auto bg-[#071713]/72 p-2.5 backdrop-blur-[3px] sm:p-5">
      <div className="animate-pop relative my-auto w-full max-w-[520px] overflow-hidden rounded-[24px] border border-[#e3b974]/45 bg-[#f8f1e2] text-ink shadow-[0_36px_90px_-24px_rgba(0,0,0,0.75)] sm:rounded-[28px]">
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-l from-[#b98b4a] via-[#e3b974] to-[#7a9e8c]" />
        <div className="pointer-events-none absolute -left-16 -top-16 h-48 w-48 rounded-full border border-[#142e28]/8" />
        <DuneRings className="pointer-events-none absolute -bottom-12 -left-12 h-56 w-56 text-[#8b7a54]/25" />
        <div className="relative p-4 sm:p-6">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="mb-1 flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-[0.22em] text-[#a4753d]">
                <span className="h-px w-4 bg-[#a4753d]/50" />
                انتهت الرحلة
              </p>
              <h2 className="font-display text-[28px] leading-tight text-ink sm:text-[34px]">انطفأ سِراجك</h2>
              <p className="mt-0.5 text-[10px] text-ink-muted sm:text-[11px]">
                لكن الرمال تحفظ المسارات… هل تجرؤ على العودة؟
              </p>
            </div>
            <div className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-[#b98b4a]/40 bg-gradient-to-br from-[#f5dba4] to-[#d9b176] shadow-[0_8px_18px_-8px_rgba(120,80,30,0.6)] sm:h-14 sm:w-14">
              {newBest ? <Crown className="h-6 w-6 text-[#61431e]" /> : <Trophy className="h-6 w-6 text-[#61431e]" />}
              {newBest && (
                <span className="absolute -bottom-2 rounded-full border border-[#f8f1e2] bg-[#142e28] px-1.5 py-px text-[7px] font-semibold text-[#f5dba4]">
                  رقم قياسي
                </span>
              )}
            </div>
          </div>

          <div className="mt-3 flex items-end justify-between gap-3 rounded-2xl border border-[#142e28]/10 bg-white/55 px-3 py-2.5 sm:mt-4 sm:px-4 sm:py-3">
            <div>
              <p className="text-[8px] uppercase tracking-[0.18em] text-ink-faint">نقاط هذه الرحلة</p>
              <p className="nums text-3xl font-bold leading-tight text-ink sm:text-4xl">{formatScore(result.score)}</p>
            </div>
            <div className="text-left">
              <p className="text-[8px] uppercase tracking-[0.18em] text-ink-faint">الترتيب</p>
              <p className="nums text-sm font-semibold text-[#a4753d] sm:text-base">
                {savedRank ? `المركز ${savedRank}` : "خارج القائمة"}
              </p>
            </div>
            {isBest && (
              <span className="hidden items-center gap-1 rounded-full border border-[#b98b4a]/30 bg-[#e3b974]/25 px-2 py-1 text-[8px] font-semibold text-[#775126] sm:flex">
                <Sparkles className="h-2.5 w-2.5" />
                أفضل جولة
              </span>
            )}
          </div>

          <div className="mt-2.5 grid grid-cols-4 gap-1.5 sm:mt-3 sm:gap-2">
            {[
              { icon: <Landmark className="h-3 w-3" />, label: "أضرحة", value: result.shrines },
              { icon: <Swords className="h-3 w-3" />, label: "ظلال", value: result.kills },
              { icon: <Sparkles className="h-3 w-3" />, label: "نور", value: result.shards },
              { icon: <Moon className="h-3 w-3" />, label: "الزمن", value: formatTime(result.time) },
            ].map((s) => (
              <div key={s.label} className="rounded-xl border border-[#142e28]/10 bg-[#142e28]/[0.03] px-1.5 py-1.5 text-center">
                <span className="mx-auto mb-0.5 flex h-4 w-4 items-center justify-center text-[#8c6c40]">{s.icon}</span>
                <p className="nums text-xs font-bold leading-tight text-ink">{s.value}</p>
                <p className="text-[8px] text-ink-faint">{s.label}</p>
              </div>
            ))}
          </div>

          <div className="mt-3 flex items-center gap-2 rounded-xl border border-[#b98b4a]/25 bg-[#e3b974]/12 px-2.5 py-1.5">
            <Check className="h-3.5 w-3.5 shrink-0 text-[#5f855f]" />
            <label htmlFor="traveler-name" className="shrink-0 text-[9px] text-ink-muted">
              اسم المسافر
            </label>
            <input
              id="traveler-name"
              value={playerName}
              maxLength={18}
              onChange={(e) => onNameChange(e.target.value)}
              className="min-w-0 flex-1 rounded-md border border-[#142e28]/12 bg-white/65 px-2 py-1 text-[11px] font-medium text-ink outline-none transition focus:border-[#b98b4a]/70 focus:bg-white"
              placeholder="مسافر"
            />
            <span className="shrink-0 text-[8px] text-ink-faint">حُفظ تلقائيًا</span>
          </div>

          <div className="mt-3 flex items-center justify-between gap-2 sm:mt-4">
            <button
              onClick={onRestart}
              className="btn-primary flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl px-3 text-xs font-bold sm:text-sm"
            >
              <RotateCcw className="h-4 w-4" />
              العب مجددًا
              <kbd className="mr-auto hidden rounded border border-[#142e28]/20 px-1.5 py-0.5 text-[9px] opacity-60 sm:block">R</kbd>
            </button>
            <button
              onClick={onHome}
              aria-label="القائمة الرئيسية"
              className="btn-quiet flex h-[44px] w-[46px] shrink-0 items-center justify-center rounded-xl"
            >
              <Home className="h-4 w-4" />
            </button>
          </div>

          <div className="mt-3 border-t border-[#142e28]/10 pt-2">
            <div className="mb-1 flex items-center justify-between">
              <p className="flex items-center gap-1 text-[9px] font-semibold text-ink-soft">
                <Trophy className="h-3 w-3 text-[#a4753d]" />
                لوحة الشرف المحلية
              </p>
              <p className="text-[8px] text-ink-faint">أفضل {Math.min(scores.length, 3)} مسارات</p>
            </div>
            <ScoreTable scores={scores} highlightId={entryId} limit={3} dense />
          </div>

          <div className="mt-2 hidden items-center justify-center gap-3 text-[8px] text-ink-faint sm:flex">
            <span className="flex items-center gap-1"><Heart className="h-2.5 w-2.5" /> لا حياة بلا ماء</span>
            <span className="flex items-center gap-1"><Droplet className="h-2.5 w-2.5" /> القِرَب تعيدك</span>
            <span className="flex items-center gap-1"><Footprints className="h-2.5 w-2.5" /> اندفع عبر الظلال</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export function ControlsLegend({ dark = false }: { dark?: boolean }) {
  return (
    <div className={`flex flex-wrap items-center gap-x-3 gap-y-1 text-[9px] ${dark ? "text-sand-200/60" : "text-ink-faint"}`}>
      <span className="flex items-center gap-1"><Keyboard className="h-3 w-3" /> WASD</span>
      <span><kbd className="rounded border border-current/20 px-1">Space</kbd> هجوم</span>
      <span><kbd className="rounded border border-current/20 px-1">Shift</kbd> اندفاع</span>
      <span><kbd className="rounded border border-current/20 px-1">E</kbd> تفاعل</span>
    </div>
  );
}
