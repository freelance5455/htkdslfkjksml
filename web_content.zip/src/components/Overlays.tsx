import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { AlertTriangle, CheckCircle2, Info, XCircle, X } from "lucide-react";
import { useApp } from "../lib/store";
import { Btn } from "./ui";
import { cn } from "../utils/cn";

/* ---------------- Toasts ---------------- */

const TOAST_META = {
  success: { icon: CheckCircle2, cls: "text-emerald-400", bar: "bg-emerald-400" },
  error: { icon: XCircle, cls: "text-rose-400", bar: "bg-rose-400" },
  warning: { icon: AlertTriangle, cls: "text-gold-400", bar: "bg-gold-400" },
  info: { icon: Info, cls: "text-brand-300", bar: "bg-brand-400" },
} as const;

export function ToastHost() {
  const { toasts, dismissToast } = useApp();
  if (toasts.length === 0) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-20 sm:bottom-6 z-[70] flex flex-col items-center gap-2 px-4">
      {toasts.map((t) => {
        const meta = TOAST_META[t.type];
        const Icon = meta.icon;
        return (
          <div
            key={t.id}
            className="pointer-events-auto flex w-full max-w-md items-center gap-3 overflow-hidden rounded-2xl bg-brand-950/95 py-3 ps-4 pe-2 text-white shadow-pop ring-1 ring-white/10 backdrop-blur animate-toast-in"
          >
            <span className={cn("absolute inset-y-0 start-0 w-1", meta.bar)} />
            <Icon className={cn("size-5 shrink-0", meta.cls)} strokeWidth={2.2} />
            <div className="min-w-0 flex-1">
              {t.title && <div className="text-[11px] font-bold uppercase tracking-wide text-white/60">{t.title}</div>}
              <div className="text-[13px] font-semibold leading-5">{t.msg}</div>
            </div>
            <button
              onClick={() => dismissToast(t.id)}
              className="flex size-8 shrink-0 items-center justify-center rounded-lg text-white/60 hover:bg-white/10 cursor-pointer"
            >
              <X className="size-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}

/* ---------------- Confirm dialog ---------------- */

export function ConfirmHost() {
  const { confirmState, closeConfirm, t } = useApp();
  if (!confirmState) return null;
  const c = confirmState;
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-5">
      <div className="absolute inset-0 bg-brand-950/60 backdrop-blur-[3px] animate-fade-in" onClick={closeConfirm} />
      <div className="relative w-full max-w-sm rounded-3xl bg-white p-6 shadow-pop dark:border dark:border-white/10 dark:bg-[#0e1a30] animate-pop-in">
        <div
          className={cn(
            "mb-4 flex size-12 items-center justify-center rounded-2xl",
            c.danger !== false
              ? "bg-rose-50 text-rose-600 dark:bg-rose-500/15"
              : "bg-brand-50 text-brand-600 dark:bg-brand-500/15"
          )}
        >
          <AlertTriangle className="size-6" strokeWidth={2} />
        </div>
        <h3 className="text-[16px] font-extrabold text-slate-900 dark:text-white">{c.title}</h3>
        <p className="mt-1.5 text-[13px] leading-6 text-slate-500 dark:text-slate-400">{c.msg}</p>
        <div className="mt-6 flex gap-2.5">
          <Btn variant="outline" block onClick={closeConfirm}>
            {t("common.cancel")}
          </Btn>
          <Btn
            variant={c.danger !== false ? "danger" : "primary"}
            block
            onClick={() => {
              c.onConfirm();
              closeConfirm();
            }}
          >
            {c.confirmLabel ?? t("common.confirm")}
          </Btn>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Print portal ----------------
   Renders children into <body> under #print-portal which is the ONLY
   thing visible while printing (see index.css). Triggers window.print(). */

export function PrintSheet({ active, children, onDone }: { active: boolean; children: ReactNode; onDone?: () => void }) {
  useEffect(() => {
    if (!active) return;
    const id = requestAnimationFrame(() => setTimeout(() => window.print(), 80));
    const done = () => onDone?.();
    window.addEventListener("afterprint", done);
    return () => {
      cancelAnimationFrame(id);
      window.removeEventListener("afterprint", done);
    };
  }, [active, onDone]);
  if (!active) return null;
  let host = document.getElementById("print-portal");
  if (!host) {
    host = document.createElement("div");
    host.id = "print-portal";
    document.body.appendChild(host);
  }
  return createPortal(<div className="p-6">{children}</div>, host, "print");
}

export function PrintHeader({ title, sub }: { title: string; sub?: string }) {
  return (
    <div style={{ marginBottom: 16, borderBottom: "2px solid #0A1830", paddingBottom: 10 }}>
      <div style={{ fontSize: 20, fontWeight: 800 }}>{title}</div>
      {sub && <div style={{ fontSize: 12, color: "#5B6B84", marginTop: 2 }}>{sub}</div>}
    </div>
  );
}
