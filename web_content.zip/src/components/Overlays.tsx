import type { ReactNode } from "react";
import type { ArenaId, HudState, Quality } from "../game/types";
import { ARENAS } from "../game/types";
import {
  ArrowLeftIcon,
  CloseIcon,
  DodgeIcon,
  FlameIcon,
  GearIcon,
  HammerIcon,
  PauseIcon,
  PlayIcon,
  ShieldIcon,
  SoundOffIcon,
  SoundOnIcon,
  SwordIcon,
  TrophyIcon,
} from "./icons";

function Modal({
  title,
  eyebrow,
  onClose,
  children,
  wide,
}: {
  title: string;
  eyebrow?: string;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/75 p-2 backdrop-blur-sm sm:p-6">
      <div
        className={`panel panel-notch anim-rise relative flex max-h-[92dvh] w-full flex-col overflow-hidden ${wide ? "max-w-3xl" : "max-w-xl"}`}
      >
        <div className="flex items-start justify-between gap-3 border-b border-gold/20 px-4 py-3">
          <div>
            {eyebrow && <div className="text-[7px] font-bold uppercase tracking-[0.3em] text-gold/60">{eyebrow}</div>}
            <h2 className="font-display gold-text text-lg font-black tracking-[0.12em] sm:text-xl">{title}</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="btn-ghost grid h-8 w-8 shrink-0 place-items-center rounded-sm"
          >
            <CloseIcon className="h-4 w-4" />
          </button>
        </div>
        <div className="scroll-thin overflow-y-auto px-4 py-3">{children}</div>
      </div>
    </div>
  );
}

function ControlRow({ icon, label, p1, p2 }: { icon: ReactNode; label: string; p1: string; p2: string }) {
  return (
    <div className="grid grid-cols-[1fr_auto_auto] items-center gap-2 border-b border-white/5 py-1.5 last:border-0">
      <div className="flex items-center gap-1.5 text-[10px] font-semibold text-white/75">
        <span className="text-gold/70">{icon}</span>
        {label}
      </div>
      <span className="rounded border border-aether/30 bg-aether/10 px-1.5 py-0.5 text-[8px] font-bold tracking-wide text-aether">
        {p1}
      </span>
      <span className="rounded border border-inferno/30 bg-inferno/10 px-1.5 py-0.5 text-[8px] font-bold tracking-wide text-inferno">
        {p2}
      </span>
    </div>
  );
}

export function GuideModal({ onClose }: { onClose: () => void }) {
  return (
    <Modal title="HOW TO PLAY" eyebrow="Two champions · one screen" onClose={onClose} wide>
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <div className="mb-1 flex items-center justify-between">
            <span className="font-display text-[11px] font-bold tracking-[0.16em] text-aether">PLAYER 1 · AETHER</span>
            <span className="text-[7px] uppercase tracking-[0.16em] text-white/35">Left side</span>
          </div>
          <div className="rounded-sm border border-aether/20 bg-aether/5 px-2 py-1">
            <ControlRow icon={<SwordIcon className="h-3 w-3" />} label="Light attack" p1="J" p2="NUM 1 / ," />
            <ControlRow icon={<HammerIcon className="h-3 w-3" />} label="Heavy attack" p1="K" p2="NUM 2 / ." />
            <ControlRow icon={<DodgeIcon className="h-3 w-3" />} label="Dodge (i-frames)" p1="L" p2="NUM 3 / /" />
            <ControlRow icon={<FlameIcon className="h-3 w-3" />} label="Special (100 energy)" p1="U" p2="NUM 0 / R-Shift" />
            <ControlRow icon={<ShieldIcon className="h-3 w-3" />} label="Block (hold)" p1="SPACE" p2="NUM 5 / R-Ctrl" />
            <ControlRow icon={<ArrowLeftIcon className="h-3 w-3" />} label="Move" p1="W A S D" p2="ARROWS" />
          </div>
          <p className="mt-1.5 text-[9px] leading-relaxed text-white/45">
            On touch: use the joystick at the outer edge of your half and the four action buttons toward the centre.
            Player 1 owns the left half, Player 2 the right half. Both control sets work simultaneously.
          </p>
        </div>
        <div>
          <div className="mb-1 flex items-center justify-between">
            <span className="font-display text-[11px] font-bold tracking-[0.16em] text-inferno">PLAYER 2 · INFERNO</span>
            <span className="text-[7px] uppercase tracking-[0.16em] text-white/35">Right side</span>
          </div>
          <div className="rounded-sm border border-inferno/20 bg-inferno/5 px-2 py-1">
            <ControlRow icon={<SwordIcon className="h-3 w-3" />} label="Light attack" p1="J" p2="NUM 1 / ," />
            <ControlRow icon={<HammerIcon className="h-3 w-3" />} label="Heavy attack" p1="K" p2="NUM 2 / ." />
            <ControlRow icon={<DodgeIcon className="h-3 w-3" />} label="Dodge (i-frames)" p1="L" p2="NUM 3 / /" />
            <ControlRow icon={<FlameIcon className="h-3 w-3" />} label="Special (100 energy)" p1="U" p2="NUM 0 / R-Shift" />
            <ControlRow icon={<ShieldIcon className="h-3 w-3" />} label="Block (hold)" p1="SPACE" p2="NUM 5 / R-Ctrl" />
            <ControlRow icon={<ArrowLeftIcon className="h-3 w-3" />} label="Move" p1="W A S D" p2="ARROWS" />
          </div>
          <p className="mt-1.5 text-[9px] leading-relaxed text-white/45">
            Keyboard mapping is a desktop testing fallback. On Android, touch is the primary input; multi-touch is
            handled with pointer capture per control.
          </p>
        </div>
      </div>

      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <div className="rounded-sm border border-white/10 bg-white/[0.03] p-2">
          <div className="mb-1 text-[8px] font-bold tracking-[0.2em] text-gold/80">RULES OF THE ARENA</div>
          <ul className="space-y-1 text-[9px] leading-relaxed text-white/55">
            <li>• Best of three rounds. First to two round wins takes the match.</li>
            <li>• 100 health per round, 60 second timer. Higher health wins on time.</li>
            <li>• Light hits build energy; a full meter unlocks the special attack.</li>
            <li>• Attacks only land inside their real range and swing arc.</li>
            <li>• Dodging grants 0.3s of invulnerability. Blocking cuts damage by ~78%.</li>
            <li>• Heavy attacks are slow but huge; punish them after a whiff.</li>
          </ul>
        </div>
        <div className="rounded-sm border border-white/10 bg-white/[0.03] p-2">
          <div className="mb-1 text-[8px] font-bold tracking-[0.2em] text-gold/80">FIGHTER NOTES</div>
          <ul className="space-y-1 text-[9px] leading-relaxed text-white/55">
            <li>• <span className="text-aether">Aether</span> — fast arcing sword, long reach, quick recovery.</li>
            <li>• <span className="text-inferno">Inferno</span> — heavy cleaver, slower swings, brutal damage.</li>
            <li>• Both fighters auto-face each other; movement is camera-relative.</li>
            <li>• The camera pulls back as the fighters separate and closes in at close range.</li>
            <li>• Pause any time with the pause button; the game auto-pauses when the tab is hidden.</li>
          </ul>
        </div>
      </div>
    </Modal>
  );
}

export function SettingsModal({
  quality,
  arena,
  muted,
  volume,
  onQuality,
  onArena,
  onToggleMute,
  onVolume,
  onClose,
}: {
  quality: Quality;
  arena: ArenaId;
  muted: boolean;
  volume: number;
  onQuality: (q: Quality) => void;
  onArena: (a: ArenaId) => void;
  onToggleMute: () => void;
  onVolume: (v: number) => void;
  onClose: () => void;
}) {
  return (
    <Modal title="SETTINGS" eyebrow="Graphics · audio · arena" onClose={onClose}>
      <div className="space-y-3">
        <div>
          <div className="mb-1 text-[8px] font-bold tracking-[0.2em] text-gold/80">GRAPHICS QUALITY</div>
          <div className="grid grid-cols-3 gap-1.5">
            {(
              [
                ["low", "LOW", "No shadows, capped pixel ratio. Best for older phones."],
                ["medium", "MEDIUM", "1024 shadows, 1.5x pixel ratio. Recommended."],
                ["high", "HIGH", "2048 shadows, up to 2x pixel ratio. Desktop / flagship."],
              ] as [Quality, string, string][]
            ).map(([id, label, hint]) => (
              <button
                key={id}
                type="button"
                onClick={() => onQuality(id)}
                className="rounded-sm border p-2 text-left transition"
                style={{
                  borderColor: quality === id ? "#d9b36a" : "rgba(255,255,255,0.12)",
                  background: quality === id ? "rgba(217,179,106,0.14)" : "rgba(255,255,255,0.02)",
                }}
              >
                <div className="text-[10px] font-black tracking-[0.12em] text-white/85">{label}</div>
                <div className="mt-0.5 text-[7px] leading-tight text-white/40">{hint}</div>
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="mb-1 text-[8px] font-bold tracking-[0.2em] text-gold/80">BATTLEGROUND</div>
          <div className="grid grid-cols-2 gap-1.5">
            {(Object.keys(ARENAS) as ArenaId[]).map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => onArena(id)}
                className="rounded-sm border p-2 text-left"
                style={{
                  borderColor: arena === id ? "#d9b36a" : "rgba(255,255,255,0.12)",
                  background: arena === id ? "rgba(217,179,106,0.14)" : "rgba(255,255,255,0.02)",
                }}
              >
                <div className="font-display text-[9px] font-bold tracking-[0.1em] text-white/85">{ARENAS[id].name}</div>
                <div className="text-[7px] text-white/40">{ARENAS[id].subtitle}</div>
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="mb-1 text-[8px] font-bold tracking-[0.2em] text-gold/80">AUDIO</div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onToggleMute}
              className="btn-ghost flex items-center gap-1.5 rounded-sm px-2 py-1.5 text-[9px] font-bold tracking-[0.1em]"
            >
              {muted ? <SoundOffIcon className="h-3.5 w-3.5" /> : <SoundOnIcon className="h-3.5 w-3.5" />}
              {muted ? "MUTED" : "SOUND ON"}
            </button>
            <input
              aria-label="Volume"
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={volume}
              onChange={(e) => onVolume(Number(e.target.value))}
              className="min-w-0 flex-1"
            />
            <span className="w-8 text-right text-[9px] tabular-nums text-white/50">{Math.round(volume * 100)}%</span>
          </div>
          <p className="mt-1 text-[8px] leading-relaxed text-white/35">
            All sound is synthesized locally with the Web Audio API — no audio files are downloaded.
          </p>
        </div>
      </div>
    </Modal>
  );
}

export function NotesModal({ onClose }: { onClose: () => void }) {
  return (
    <Modal title="TECHNICAL NOTES" eyebrow="Honest build report" onClose={onClose} wide>
      <div className="space-y-3 text-[10px] leading-relaxed text-white/60">
        <div>
          <div className="mb-1 text-[8px] font-bold tracking-[0.2em] text-emerald-300/80">IMPLEMENTED AND WORKING</div>
          <ul className="grid gap-1 sm:grid-cols-2">
            <li>• Real Three.js 3D scene, arena, lighting, shadows and fog.</li>
            <li>• Two fully procedural joint-rigged warriors with layered armour.</li>
            <li>• AnimationMixer clips: idle, walk, run, light, heavy, dodge, block, hit, special, victory, KO.</li>
            <li>• Range + arc + timing hit detection, one hit per swing.</li>
            <li>• Health, energy, cooldowns, stun, knockback, i-frame dodge, block.</li>
            <li>• Best-of-three rounds, timer, score, rematch, pause, auto-pause.</li>
            <li>• Dual independent touch controls with pointer capture and multi-touch.</li>
            <li>• Dynamic camera, hit shake, sparks, trails, shockwave rings, embers.</li>
            <li>• Synthesized SFX and ambient score, mutable, offline.</li>
            <li>• Single-file production build with no runtime network requests.</li>
          </ul>
        </div>
        <div>
          <div className="mb-1 text-[8px] font-bold tracking-[0.2em] text-amber-300/80">NOT INCLUDED / LIMITATIONS</div>
          <ul className="space-y-1">
            <li>
              • <b>No external GLB/GLTF models.</b> No licensed rigged character asset was available offline, so the
              champions are built procedurally from primitives with a real joint hierarchy and AnimationMixer clips.
              They are not scanned or photogrammetry models.
            </li>
            <li>
              • <b>No recorded audio files.</b> Every sound effect and the music loop are synthesized at runtime; there
              are no .mp3/.ogg assets.
            </li>
            <li>• No online multiplayer, accounts, cloud saves or telemetry.</li>
            <li>• No guarantee of 60fps on every device; use LOW quality on weak hardware.</li>
            <li>• Tested in a desktop browser build; not tested on a physical Android device in this environment.</li>
          </ul>
        </div>
        <div>
          <div className="mb-1 text-[8px] font-bold tracking-[0.2em] text-gold/80">ANDROID / APK PACKAGING</div>
          <ol className="list-decimal space-y-1 pl-4">
            <li>Run <code className="keycap">npm install</code> then <code className="keycap">npm run build</code>.</li>
            <li>The build emits a self-contained <code className="keycap">dist/index.html</code> (JS/CSS inlined).</li>
            <li>
              Create a Capacitor shell: <code className="keycap">npm i @capacitor/core @capacitor/android</code>,{" "}
              <code className="keycap">npx cap init "Gods of War" com.example.titanarena --web-dir=dist</code>,{" "}
              <code className="keycap">npx cap add android</code>, <code className="keycap">npx cap sync android</code>.
            </li>
            <li>Open the generated <code className="keycap">android/</code> folder in Android Studio and build a signed APK/AAB.</li>
            <li>
              Alternative: load <code className="keycap">dist/index.html</code> from a local WebView (file access or copy
              into <code className="keycap">assets/</code>). No internet permission is required.
            </li>
          </ol>
        </div>
        <div className="rounded-sm border border-white/10 bg-white/[0.03] p-2 text-[9px] text-white/45">
          <b className="text-white/70">Performance:</b> geometry and materials are shared per fighter, particles are
          pooled, pixel ratio is capped, shadows are optional and the renderer is disposed on unmount. If you see
          stutter, switch to LOW and close other apps.
        </div>
        <a
          href="./downloads/titan-arena.zip"
          download
          className="btn-gold flex items-center justify-center gap-2 rounded-sm px-3 py-2.5 text-[10px] font-black tracking-[0.16em]"
        >
          DOWNLOAD OFFLINE BUILD (.ZIP)
        </a>
        <p className="text-center text-[8px] uppercase tracking-[0.14em] text-white/30">
          Contains the standalone index.html, README and the original source
        </p>
      </div>
    </Modal>
  );
}

export function PauseOverlay({
  hud,
  muted,
  onResume,
  onRestart,
  onSettings,
  onToggleMute,
  onQuit,
}: {
  hud: HudState;
  muted: boolean;
  onResume: () => void;
  onRestart: () => void;
  onSettings: () => void;
  onToggleMute: () => void;
  onQuit: () => void;
}) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 p-3 backdrop-blur-sm">
      <div className="panel panel-notch anim-rise w-full max-w-sm p-4">
        <div className="flex items-center gap-2">
          <PauseIcon className="h-4 w-4 text-gold" />
          <h2 className="font-display gold-text text-xl font-black tracking-[0.2em]">PAUSED</h2>
        </div>
        <div className="mt-2 flex items-center justify-between rounded-sm border border-white/10 bg-white/[0.03] px-2 py-1.5 text-[9px]">
          <span className="text-aether">{hud.fighters[0].name}</span>
          <span className="font-display text-sm font-bold text-white/80">
            {hud.score[0]} — {hud.score[1]}
          </span>
          <span className="text-inferno">{hud.fighters[1].name}</span>
        </div>
        <div className="mt-3 space-y-1.5">
          <button
            type="button"
            onClick={onResume}
            className="btn-gold flex w-full items-center justify-center gap-2 rounded-sm py-2.5 text-[11px] font-black tracking-[0.18em]"
          >
            <PlayIcon className="h-3.5 w-3.5" /> RESUME
          </button>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={onRestart}
              className="btn-ghost flex items-center justify-center gap-1.5 rounded-sm py-2 text-[9px] font-bold tracking-[0.12em]"
            >
              <DodgeIcon className="h-3 w-3" /> RESTART
            </button>
            <button
              type="button"
              onClick={onSettings}
              className="btn-ghost flex items-center justify-center gap-1.5 rounded-sm py-2 text-[9px] font-bold tracking-[0.12em]"
            >
              <GearIcon className="h-3 w-3" /> SETTINGS
            </button>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={onToggleMute}
              className="btn-ghost flex items-center justify-center gap-1.5 rounded-sm py-2 text-[9px] font-bold tracking-[0.12em]"
            >
              {muted ? <SoundOffIcon className="h-3 w-3" /> : <SoundOnIcon className="h-3 w-3" />}
              {muted ? "UNMUTE" : "MUTE"}
            </button>
            <button
              type="button"
              onClick={onQuit}
              className="btn-ghost flex items-center justify-center gap-1.5 rounded-sm py-2 text-[9px] font-bold tracking-[0.12em]"
            >
              <ArrowLeftIcon className="h-3 w-3" /> MAIN MENU
            </button>
          </div>
        </div>
        <p className="mt-2 text-center text-[8px] uppercase tracking-[0.14em] text-white/30">
          Round {hud.round} · {hud.timer}s remaining
        </p>
      </div>
    </div>
  );
}

export function ResultOverlay({
  hud,
  onRematch,
  onMenu,
}: {
  hud: HudState;
  onRematch: () => void;
  onMenu: () => void;
}) {
  const winner = hud.winner;
  const w = winner !== null ? hud.fighters[winner] : null;
  const color = winner === 0 ? "#54e2ff" : "#ff6a2a";
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-gradient-to-b from-black/60 via-black/80 to-black/95 p-3">
      <div className="panel panel-notch anim-rise relative w-full max-w-md overflow-hidden p-4 text-center sm:p-6">
        <div
          className="pointer-events-none absolute inset-0 opacity-50"
          style={{ background: `radial-gradient(90% 60% at 50% 0%, ${color}33, transparent 70%)` }}
        />
        <div className="relative">
          <div className="mx-auto mb-1 grid h-10 w-10 place-items-center rounded-full border border-gold/50 bg-gold/10">
            <TrophyIcon className="h-5 w-5 text-gold" />
          </div>
          <div className="text-[8px] font-bold uppercase tracking-[0.34em] text-gold/70">Match complete</div>
          <h2
            className="font-display mt-1 text-[clamp(26px,8vw,44px)] font-black leading-none tracking-[0.06em]"
            style={{ color, textShadow: `0 0 30px ${color}66` }}
          >
            {w ? w.name : "DRAW"}
          </h2>
          <div className="mt-1 text-[9px] uppercase tracking-[0.24em] text-white/50">
            {w ? "claims the Titan Arena" : "No champion crowned"}
          </div>

          <div className="mt-4 flex items-center justify-center gap-4">
            <div className="text-right">
              <div className="text-[8px] uppercase tracking-[0.16em] text-aether/80">{hud.fighters[0].name}</div>
              <div className="font-display text-2xl font-black text-white/90">{hud.score[0]}</div>
            </div>
            <div className="font-display text-xs tracking-[0.2em] text-gold/60">ROUNDS</div>
            <div className="text-left">
              <div className="text-[8px] uppercase tracking-[0.16em] text-inferno/80">{hud.fighters[1].name}</div>
              <div className="font-display text-2xl font-black text-white/90">{hud.score[1]}</div>
            </div>
          </div>

          <div className="mt-4 space-y-1.5">
            <button
              type="button"
              onClick={onRematch}
              className="btn-gold flex w-full items-center justify-center gap-2 rounded-sm py-2.5 text-[11px] font-black tracking-[0.18em]"
            >
              <DodgeIcon className="h-3.5 w-3.5" /> REMATCH
            </button>
            <button
              type="button"
              onClick={onMenu}
              className="btn-ghost flex w-full items-center justify-center gap-2 rounded-sm py-2 text-[10px] font-bold tracking-[0.16em]"
            >
              <ArrowLeftIcon className="h-3.5 w-3.5" /> MAIN MENU
            </button>
          </div>
          <p className="mt-2 text-[8px] uppercase tracking-[0.14em] text-white/30">
            Tip: change arena and graphics in the main menu
          </p>
        </div>
      </div>
    </div>
  );
}
