import { useState } from "react";
import { BadgeCheck, BookHeart, Check, Gift, Heart, Lock, Search, Sparkles, Ticket, Trophy, X } from "lucide-react";
import { CATS, CAT_MAP, FUR_MAP } from "../data/catalog";
import { CatAvatar } from "./Cat";
import { sfx } from "../lib/sound";

/* ---------------- Álbum de gatitos ---------------- */
interface AlbumProps {
  adopted: string[];
  activeCatId: string;
  catNames: Record<string, string>;
  friendship: Record<string, number>;
  onSelect: (catId: string) => void;
  onClose: () => void;
}

export function AlbumOverlay({ adopted, activeCatId, catNames, friendship, onSelect, onClose }: AlbumProps) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const list = CATS.filter((c) => c.name.toLowerCase().includes(query.toLowerCase()));
  const sel = selected ? CAT_MAP.get(selected) : null;

  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-[#12101c]">
      <div className="flex items-center justify-between border-b border-[#caa25a]/50 px-4 py-3">
        <h2 className="flex items-center gap-2 font-display text-lg font-semibold text-[#f5c451]">
          <BookHeart className="h-5 w-5" /> Álbum de gatitos
        </h2>
        <span className="rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-pink-300">
          {adopted.length} / 100 adoptados
        </span>
        <button onClick={onClose} aria-label="Cerrar" className="rounded-full bg-white/10 p-2 text-white active:scale-90"><X className="h-5 w-5" /></button>
      </div>
      <label className="mx-4 mt-3 flex items-center gap-2 rounded-xl border border-white/10 bg-black/40 px-3 py-2">
        <Search className="h-4 w-4 text-white/40" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar gatito..." className="w-full bg-transparent text-sm font-bold text-white placeholder:text-white/30 focus:outline-none" />
      </label>

      {sel && (
        <div className="modal-pop mx-4 mt-3 rounded-3xl border-2 border-[#caa25a] bg-[#1c1930] p-4">
          <div className="flex items-center gap-3">
            <span className="rounded-2xl bg-black/40 p-1.5">
              <CatAvatar fur={FUR_MAP.get(sel.furId)!} eyeColor={sel.eye} size={64} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-display text-lg font-semibold leading-tight text-[#ffe9a8]">{catNames[sel.id] ?? sel.name}</p>
              <p className="text-xs font-bold text-white/55">{sel.rarity} · Ojitos {sel.eyeName} · {sel.personality}</p>
              <p className="mt-1 flex items-center gap-1 text-xs font-extrabold text-pink-300">
                <Heart className="h-3.5 w-3.5" fill="currentColor" /> Amistad nivel {Math.min(10, Math.floor((friendship[sel.id] ?? 0) / 40) + 1)}
              </p>
            </div>
          </div>
          <p className="mt-2 text-[13px] font-semibold leading-snug text-white/70">{sel.desc}</p>
          {adopted.includes(sel.id) ? (
            <button
              onClick={() => { sfx.sparkle(); onSelect(sel.id); }}
              className="mt-3 min-h-[48px] w-full rounded-2xl bg-[#f5c451] font-display text-base font-bold text-[#241a02] active:scale-[0.98]"
            >
              {activeCatId === sel.id ? "¡Ya estoy jugando contigo!" : "Jugar con este gatito"}
            </button>
          ) : (
            <p className="mt-3 flex items-center gap-1.5 rounded-xl bg-white/5 px-3 py-2.5 text-xs font-bold text-white/50">
              <Lock className="h-4 w-4" /> Este gatito llega solo con un código de regalo de MICHILICIAS.
            </p>
          )}
        </div>
      )}

      <div className="no-scrollbar grid flex-1 grid-cols-4 gap-2 overflow-y-auto p-4">
        {list.map((cat) => {
          const owned = adopted.includes(cat.id);
          const fur = FUR_MAP.get(cat.furId)!;
          return (
            <button
              key={cat.id}
              onClick={() => { setSelected(cat.id); sfx.pop(); }}
              className={`flex flex-col items-center gap-1 rounded-2xl border px-1 py-2 transition active:scale-95 ${
                selected === cat.id ? "border-[#f5c451] bg-[#2a2210]" : "border-white/10 bg-[#1a1828]"
              }`}
            >
              {owned ? (
                <CatAvatar fur={fur} eyeColor={cat.eye} size={48} />
              ) : (
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-black/60">
                  <Lock className="h-5 w-5 text-white/35" />
                </span>
              )}
              <span className={`w-full truncate text-center text-[10px] font-extrabold ${owned ? "text-white/85" : "text-white/35"}`}>
                {owned ? (catNames[cat.id] ?? cat.name).split(" ").slice(0, 2).join(" ") : "???"}
              </span>
              {activeCatId === cat.id && <span className="rounded-full bg-[#f5c451] px-1.5 py-0.5 text-[8px] font-extrabold text-[#241a02]">ACTIVO</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- Canje de códigos ---------------- */
export interface RedeemOutcome {
  ok: boolean;
  text: string;
  rewards?: string[];
}

interface RedeemProps {
  testCodes: string[];
  onRedeem: (code: string) => RedeemOutcome;
  onClose: () => void;
}

export function RedeemModal({ testCodes, onRedeem, onClose }: RedeemProps) {
  const [value, setValue] = useState("");
  const [result, setResult] = useState<RedeemOutcome | null>(null);

  const submit = () => {
    if (!value.trim()) return;
    const out = onRedeem(value);
    setResult(out);
    if (out.ok) sfx.sparkle();
    else sfx.error();
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-5 backdrop-blur-sm">
      <div className="modal-pop w-full max-w-sm rounded-[26px] border-2 border-[#caa25a] bg-[#17141f] p-5 shadow-2xl">
        <div className="mb-1 flex items-center justify-between">
          <h2 className="flex items-center gap-2 font-display text-xl font-semibold text-[#f5c451]">
            <Gift className="h-5 w-5" /> Código de regalo
          </h2>
          <button onClick={onClose} aria-label="Cerrar" className="rounded-full bg-white/10 p-1.5 text-white active:scale-90"><X className="h-5 w-5" /></button>
        </div>
        <p className="mb-4 text-sm font-semibold text-white/55">
          Escribe el código que venía con tu compra de MICHILICIAS y recibe tus regalos exclusivos para siempre.
        </p>
        <input
          value={value}
          onChange={(e) => setValue(e.target.value.toUpperCase())}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder="XXXX-XXXX-XXXX"
          autoCapitalize="characters"
          className="w-full rounded-2xl border border-white/15 bg-black/40 px-4 py-3.5 text-center font-display text-lg font-semibold tracking-widest text-white placeholder:text-white/25 focus:border-[#f5c451] focus:outline-none"
        />
        {result && (
          <div className={`mt-3 rounded-2xl px-3.5 py-3 text-sm font-bold ${result.ok ? "bg-emerald-400/15 text-emerald-200" : "bg-rose-400/15 text-rose-200"}`}>
            <p>{result.text}</p>
            {result.rewards && result.rewards.length > 0 && (
              <ul className="mt-1.5 space-y-0.5">
                {result.rewards.map((r) => (
                  <li key={r} className="flex items-center gap-1.5"><Sparkles className="h-3.5 w-3.5 shrink-0" /> {r}</li>
                ))}
              </ul>
            )}
          </div>
        )}
        <button
          onClick={submit}
          className="mt-4 flex min-h-[52px] w-full items-center justify-center gap-2 rounded-2xl bg-[#f5c451] font-display text-base font-bold text-[#241a02] transition active:scale-[0.98]"
        >
          <Ticket className="h-5 w-5" /> Canjear regalo
        </button>
        {testCodes.length > 0 && (
          <div className="mt-4 rounded-xl border border-dashed border-white/15 bg-black/30 px-3 py-2.5">
            <p className="text-[10px] font-extrabold uppercase tracking-wider text-white/40">Códigos de prueba (solo demostración)</p>
            <div className="mt-1 flex flex-wrap gap-1.5">
              {testCodes.map((c) => (
                <button key={c} onClick={() => setValue(c)} className="rounded-full bg-white/8 px-2 py-1 font-mono text-[11px] font-bold text-amber-200 active:scale-95">
                  {c}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------- Misiones y logros ---------------- */
export interface MissionState {
  id: string;
  label: string;
  goal: number;
  prog: number;
  claimed: boolean;
  reward: number;
}

export interface AchievementState {
  id: string;
  name: string;
  desc: string;
  unlocked: boolean;
}

interface MissionsProps {
  missions: MissionState[];
  achievements: AchievementState[];
  onClaim: (id: string) => void;
  onClose: () => void;
}

export function MissionsOverlay({ missions, achievements, onClaim, onClose }: MissionsProps) {
  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-[#12101c]">
      <div className="flex items-center justify-between border-b border-[#caa25a]/50 px-4 py-3">
        <h2 className="flex items-center gap-2 font-display text-lg font-semibold text-[#f5c451]">
          <Trophy className="h-5 w-5" /> Misiones y logros
        </h2>
        <button onClick={onClose} aria-label="Cerrar" className="rounded-full bg-white/10 p-2 text-white active:scale-90"><X className="h-5 w-5" /></button>
      </div>
      <div className="no-scrollbar flex-1 overflow-y-auto p-4">
        <p className="mb-2 font-display text-base font-semibold text-pink-300">Misiones de hoy (opcionales)</p>
        <p className="mb-3 text-xs font-semibold text-white/45">Sin presiones: nadie te castiga por no hacerlas y tus gatitos siempre estarán bien.</p>
        <div className="flex flex-col gap-2">
          {missions.map((m) => {
            const done = m.prog >= m.goal;
            return (
              <div key={m.id} className="rounded-2xl border border-white/10 bg-[#1a1828] px-3.5 py-3">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-display text-sm font-semibold text-white">{m.label}</p>
                  <span className="text-xs font-extrabold text-amber-300">+{m.reward} monedas</span>
                </div>
                <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-pink-400 transition-all" style={{ width: `${Math.min(100, (m.prog / m.goal) * 100)}%` }} />
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-xs font-bold text-white/50">{Math.min(m.prog, m.goal)} / {m.goal}</span>
                  {m.claimed ? (
                    <span className="flex items-center gap-1 text-xs font-extrabold text-emerald-300"><BadgeCheck className="h-4 w-4" /> Reclamada</span>
                  ) : (
                    <button
                      disabled={!done}
                      onClick={() => onClaim(m.id)}
                      className={`rounded-full px-3 py-1.5 text-xs font-extrabold ${done ? "bg-[#f5c451] text-[#241a02] active:scale-95" : "bg-white/8 text-white/35"}`}
                    >
                      Reclamar
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <p className="mb-2 mt-6 font-display text-base font-semibold text-pink-300">Logros</p>
        <div className="grid grid-cols-2 gap-2">
          {achievements.map((a) => (
            <div key={a.id} className={`rounded-2xl border px-3 py-3 ${a.unlocked ? "border-[#caa25a]/60 bg-[#2a2210]" : "border-white/8 bg-[#171522]"}`}>
              <p className={`flex items-center gap-1.5 font-display text-[13px] font-semibold leading-tight ${a.unlocked ? "text-[#ffe9a8]" : "text-white/40"}`}>
                {a.unlocked ? <Trophy className="h-4 w-4 shrink-0 text-[#f5c451]" /> : <Lock className="h-4 w-4 shrink-0" />}
                {a.name}
              </p>
              <p className="mt-1 text-[11px] font-semibold leading-snug text-white/45">{a.desc}</p>
              {a.unlocked && <p className="mt-1 flex items-center gap-1 text-[10px] font-extrabold text-emerald-300"><Check className="h-3 w-3" /> ¡Logrado!</p>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
