import React, { useState } from 'react';
import {
  X,
  Calendar as CalendarIcon,
  Flame,
  Cake,
  Scroll,
  Sparkles,
  Clock,
  RefreshCw,
  Paintbrush,
  Bell,
  AlignLeft,
  Settings as SettingsIcon,
  ChevronDown,
  ChevronUp,
  MapPin,
  Users,
  UserPlus,
  Hash,
  Check,
} from 'lucide-react';
import { CalendarDay, HebrewEvent, HebrewEventType, UserSettings } from '../types';
import {
  HEBREW_MONTH_NAMES_LIST,
  convertGregorianToHebrew,
  getUpcomingHebrewEventOccurrences,
  getHebrewNumberGematriya,
} from '../services/hebrewCalendarService';
import { getTranslations } from '../services/i18n';

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveEvent: (event: HebrewEvent) => void;
  existingEvent?: HebrewEvent | null;
  defaultDay?: CalendarDay;
  settings?: UserSettings;
}

const COLOR_OPTIONS = [
  { value: '#C5A267', label: 'Gold', labelHe: 'זהב' },
  { value: '#60a5fa', label: 'Blue', labelHe: 'כחול' },
  { value: '#f472b6', label: 'Pink', labelHe: 'ורוד' },
  { value: '#a78bfa', label: 'Purple', labelHe: 'סגול' },
  { value: '#34d399', label: 'Green', labelHe: 'ירוק' },
  { value: '#f87171', label: 'Red', labelHe: 'אדום' },
  { value: '#2dd4bf', label: 'Teal', labelHe: 'טורקיז' },
  { value: '#fbbf24', label: 'Amber', labelHe: 'ענבר' },
];

const formatDateForInput = (d: Date) => {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const EventModal: React.FC<EventModalProps> = ({
  isOpen,
  onClose,
  onSaveEvent,
  existingEvent,
  defaultDay,
  settings,
}) => {
  const isRtl = settings?.language === 'he';
  const t = getTranslations(settings?.language || 'he');

  const EVENT_TYPES: Array<{
    id: HebrewEventType;
    label: string;
    icon: string;
    defaultColor: string;
  }> = [
    { id: 'birthday', label: isRtl ? t.hebrewBirthday : t.birthday, icon: '🎂', defaultColor: '#C5A267' },
    { id: 'yahrzeit', label: isRtl ? t.yahrzeitMemorial : t.yahrzeit, icon: '🕯️', defaultColor: '#60a5fa' },
    { id: 'anniversary', label: isRtl ? t.hebrewAnniversary : t.anniversary, icon: '💍', defaultColor: '#f472b6' },
    { id: 'barmitzvah', label: isRtl ? t.barBatMitzvah : t.barmitzvah, icon: '📜', defaultColor: '#a78bfa' },
    { id: 'custom', label: isRtl ? t.customHebrewEvent : t.customEvent, icon: '⭐', defaultColor: '#34d399' },
  ];

  const [title, setTitle] = useState(existingEvent?.title || '');
  const [hebrewTitle, setHebrewTitle] = useState(existingEvent?.hebrewTitle || '');
  const [type, setType] = useState<HebrewEventType>(existingEvent?.type || 'birthday');

  const initialHebDate = defaultDay
    ? { day: defaultDay.hebrewDay, month: defaultDay.hebrewMonth, year: defaultDay.hebrewYear }
    : convertGregorianToHebrew(new Date());

  const [hebrewDay, setHebrewDay] = useState<number>(existingEvent?.hebrewDay || initialHebDate.day);
  const [hebrewMonth, setHebrewMonth] = useState<number>(
    existingEvent?.hebrewMonth || initialHebDate.month
  );
  const [hebrewYear, setHebrewYear] = useState<number | undefined>(
    existingEvent?.hebrewYear || undefined
  );

  const initialGregorianDate = defaultDay
    ? formatDateForInput(defaultDay.gregorianDate)
    : existingEvent?.gregorianOriginDate || formatDateForInput(new Date());

  const [gregorianHelperDate, setGregorianHelperDate] = useState<string>(initialGregorianDate);
  const [recurrence, setRecurrence] = useState<'hebrew-annual' | 'hebrew-monthly' | 'once'>(
    existingEvent?.recurrence || 'hebrew-annual'
  );

  // Number of repeats state
  const [repeatEndMode, setRepeatEndMode] = useState<'forever' | 'count'>(
    existingEvent?.repeatCount && existingEvent.repeatCount > 0 ? 'count' : 'forever'
  );
  const [repeatCountValue, setRepeatCountValue] = useState<number>(
    existingEvent?.repeatCount && existingEvent.repeatCount > 0 ? existingEvent.repeatCount : 5
  );

  // Participants state
  const [participants, setParticipants] = useState<string[]>(
    existingEvent?.participants || []
  );
  const [participantInput, setParticipantInput] = useState<string>('');

  const [leapYearRule, setLeapYearRule] = useState<'adar2' | 'adar1' | 'both'>(
    existingEvent?.leapYearRule || 'adar2'
  );
  const [color, setColor] = useState(existingEvent?.color || '#C5A267');
  const [location, setLocation] = useState(existingEvent?.location || '');
  const [notes, setNotes] = useState(existingEvent?.notes || '');
  const [enableReminder, setEnableReminder] = useState(
    existingEvent?.enableReminder !== undefined ? existingEvent.enableReminder : true
  );
  const [reminderDaysBefore, setReminderDaysBefore] = useState<number>(
    existingEvent?.reminderDaysBefore !== undefined ? existingEvent.reminderDaysBefore : 1
  );
  const [candleLighting, setCandleLighting] = useState(
    existingEvent?.candleLighting || (existingEvent?.type === 'yahrzeit')
  );

  // Counter near event title feature (e.g. "Birthday (3)")
  const [showCounter, setShowCounter] = useState<boolean>(
    existingEvent?.showCounter ?? (existingEvent?.type === 'birthday' || type === 'birthday')
  );
  const [startHebrewYear, setStartHebrewYear] = useState<number | string>(
    existingEvent?.startHebrewYear ?? existingEvent?.hebrewYear ?? initialHebDate.year
  );
  const [counterStart, setCounterStart] = useState<number>(
    existingEvent?.counterStart !== undefined ? existingEvent.counterStart : 1
  );
  const [showAdvanced, setShowAdvanced] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleGregorianHelperChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setGregorianHelperDate(val);
    if (val) {
      const d = new Date(val + 'T12:00:00');
      const conv = convertGregorianToHebrew(d);
      setHebrewDay(conv.day);
      setHebrewMonth(conv.month);
      setHebrewYear(conv.year);
      if (!existingEvent?.startHebrewYear) {
        setStartHebrewYear(conv.year);
      }
    }
  };

  const handleTypeChange = (newType: HebrewEventType) => {
    setType(newType);
    const found = EVENT_TYPES.find((item) => item.id === newType);
    if (found) {
      setColor(found.defaultColor);
    }
    if (newType === 'yahrzeit') {
      setCandleLighting(true);
    }
    if (newType === 'birthday') {
      setShowCounter(true);
    }
  };

  const handleAddParticipant = () => {
    const raw = participantInput.trim();
    if (!raw) return;
    const splitNames = raw
      .split(/[,;\n]+/)
      .map((s) => s.trim())
      .filter(Boolean);

    if (splitNames.length === 0) return;

    setParticipants((prev) => {
      const next = [...prev];
      for (const name of splitNames) {
        if (!next.includes(name)) {
          next.push(name);
        }
      }
      return next;
    });
    setParticipantInput('');
  };

  const handleKeyDownParticipant = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      handleAddParticipant();
    }
  };

  const handleRemoveParticipant = (indexToRemove: number) => {
    setParticipants(participants.filter((_, idx) => idx !== indexToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert(t.pleaseEnterTitle);
      return;
    }

    const monthObj = HEBREW_MONTH_NAMES_LIST.find((m) => m.num === hebrewMonth) || HEBREW_MONTH_NAMES_LIST[0];
    const parsedStartYear = typeof startHebrewYear === 'number' ? startHebrewYear : parseInt(String(startHebrewYear), 10);

    const effectiveRepeatCount = recurrence !== 'once' && repeatEndMode === 'count' && repeatCountValue > 0
      ? repeatCountValue
      : undefined;

    const newEvent: HebrewEvent = {
      id: existingEvent?.id || `heb-ev-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      title: title.trim(),
      hebrewTitle: hebrewTitle.trim() || undefined,
      type,
      hebrewDay,
      hebrewMonth,
      hebrewMonthName: monthObj.name,
      hebrewYear: hebrewYear || (!isNaN(parsedStartYear) ? parsedStartYear : undefined),
      startHebrewYear: !isNaN(parsedStartYear) ? parsedStartYear : undefined,
      gregorianOriginDate: gregorianHelperDate || undefined,
      showCounter,
      counterStart: showCounter ? counterStart : undefined,
      recurrence,
      repeatCount: effectiveRepeatCount,
      participants: participants.length > 0 ? participants : undefined,
      leapYearRule: (hebrewMonth === 12 || hebrewMonth === 13) ? leapYearRule : 'adar2',
      color,
      location: location.trim() || undefined,
      notes: notes.trim() || undefined,
      candleLighting,
      enableReminder,
      reminderDaysBefore,
      createdAt: existingEvent?.createdAt || Date.now(),
      updatedAt: Date.now(),
    };

    onSaveEvent(newEvent);
    onClose();
  };

  // Preview upcoming Gregorian occurrences
  const selectedMonthObj = HEBREW_MONTH_NAMES_LIST.find((m) => m.num === hebrewMonth);
  const previewEvent: HebrewEvent = {
    id: 'preview',
    title: title || (isRtl ? 'אירוע לדוגמה' : 'Sample Event'),
    type,
    hebrewDay,
    hebrewMonth,
    hebrewMonthName: selectedMonthObj?.name || 'Nisan',
    recurrence,
    repeatCount: recurrence !== 'once' && repeatEndMode === 'count' ? repeatCountValue : undefined,
    startHebrewYear: typeof startHebrewYear === 'number' ? startHebrewYear : parseInt(String(startHebrewYear), 10) || initialHebDate.year,
    leapYearRule: 'adar2',
    color,
    enableReminder,
    reminderDaysBefore,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  const upcomingOccurrences = getUpcomingHebrewEventOccurrences(previewEvent, 4);

  const getGuestColor = (name: string) => {
    const colors = [
      { bg: 'bg-blue-500/20', text: 'text-blue-400', border: 'border-blue-500/30' },
      { bg: 'bg-amber-500/20', text: 'text-amber-400', border: 'border-amber-500/30' },
      { bg: 'bg-emerald-500/20', text: 'text-emerald-400', border: 'border-emerald-500/30' },
      { bg: 'bg-purple-500/20', text: 'text-purple-400', border: 'border-purple-500/30' },
      { bg: 'bg-rose-500/20', text: 'text-rose-400', border: 'border-rose-500/30' },
      { bg: 'bg-teal-500/20', text: 'text-teal-400', border: 'border-teal-500/30' },
      { bg: 'bg-indigo-500/20', text: 'text-indigo-400', border: 'border-indigo-500/30' },
    ];
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150"
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      <div className="bg-[#121212] rounded-2xl max-w-xl w-full border border-[#2A2A2A] shadow-2xl overflow-hidden my-8 flex flex-col text-[#D1D1D1]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#2A2A2A] flex items-center justify-between bg-[#161616]">
          <h3 className="font-bold text-base text-[#EAEAEA] font-serif-hebrew">
            {existingEvent ? t.editEvent : t.createEvent}
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#888888] hover:text-[#EAEAEA] hover:bg-[#252525] transition-colors cursor-pointer"
            title={t.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto max-h-[75vh]">
          {/* 1. Large Borderless Title */}
          <div className="px-1.5">
            <input
              type="text"
              required
              placeholder={t.eventTitlePlaceholder}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full text-2xl font-semibold bg-transparent border-b border-[#2A2A2A] pb-3 focus:border-[#C5A267] focus:outline-hidden text-[#EAEAEA] placeholder-[#555555] transition-all font-serif-hebrew"
            />
          </div>

          {/* 2. Flat Button Tabs for Event Type */}
          <div className="flex gap-2 pb-1 overflow-x-auto scrollbar-none border-b border-[#2A2A2A]/40">
            {EVENT_TYPES.map((item) => (
              <button
                type="button"
                key={item.id}
                onClick={() => handleTypeChange(item.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap border cursor-pointer ${
                  type === item.id
                    ? 'border-[#C5A267] bg-[#252525]/80 text-[#C5A267] shadow-sm'
                    : 'border-[#2A2A2A] bg-[#141414] text-[#888888] hover:bg-[#1D1D1D] hover:text-[#EAEAEA]'
                }`}
              >
                <span className="text-sm">{item.icon}</span>
                <span>{item.label}</span>
              </button>
            ))}
          </div>

          {/* 3. Icon-aligned rows */}
          <div className="space-y-5">
            {/* Row: Gregorian & Hebrew Date */}
            <div className="flex gap-4 items-start">
              <div className="text-gray-400 mt-2 shrink-0">
                <CalendarIcon className="w-5 h-5 text-[#888888]" />
              </div>
              <div className="flex-1 space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <input
                    type="date"
                    value={gregorianHelperDate}
                    onChange={handleGregorianHelperChange}
                    className="px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden min-w-[150px]"
                  />
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-bold text-[#C5A267] bg-[#252525] border border-[#3A3A3A] px-2.5 py-1.5 rounded-lg font-serif-hebrew">
                      {getHebrewNumberGematriya(hebrewDay)} {selectedMonthObj?.nameHe} {hebrewYear ? `(${hebrewYear})` : ''}
                      {!isRtl && ` — ${hebrewDay} ${selectedMonthObj?.name}`}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Row: Recurrence & Number of Repeats */}
            <div className="flex gap-4 items-start">
              <div className="text-gray-400 mt-2 shrink-0">
                <RefreshCw className="w-5 h-5 text-[#888888]" />
              </div>
              <div className="flex-1 space-y-3">
                <select
                  value={recurrence}
                  onChange={(e) => setRecurrence(e.target.value as any)}
                  className="w-full sm:w-72 px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
                >
                  <option value="hebrew-annual">{t.repeatsAnnuallyHebrew}</option>
                  <option value="hebrew-monthly">{t.repeatsMonthlyHebrew}</option>
                  <option value="once">{t.doesNotRepeat}</option>
                </select>

                {/* Repetitions limit / Number of repeats configuration */}
                {recurrence !== 'once' && (
                  <div className="p-3 rounded-xl border border-[#2A2A2A] bg-[#161616] space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-bold text-[#888888] uppercase tracking-wider flex items-center gap-1.5">
                        <Hash className="w-3.5 h-3.5 text-[#C5A267]" />
                        <span>{t.repeatCount}</span>
                      </label>
                      <span className="text-[10px] text-[#666666]">
                        {repeatEndMode === 'forever' ? t.repeatForever : `${repeatCountValue} ${t.times}`}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setRepeatEndMode('forever')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border cursor-pointer ${
                          repeatEndMode === 'forever'
                            ? 'border-[#C5A267] bg-[#C5A267]/15 text-[#C5A267]'
                            : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:text-[#EAEAEA]'
                        }`}
                      >
                        {t.repeatForever}
                      </button>

                      <button
                        type="button"
                        onClick={() => setRepeatEndMode('count')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border cursor-pointer ${
                          repeatEndMode === 'count'
                            ? 'border-[#C5A267] bg-[#C5A267]/15 text-[#C5A267]'
                            : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:text-[#EAEAEA]'
                        }`}
                      >
                        {t.repeatCustomCount}
                      </button>
                    </div>

                    {repeatEndMode === 'count' && (
                      <div className="pt-2 flex items-center gap-2">
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            min="1"
                            max="120"
                            value={repeatCountValue}
                            onChange={(e) => setRepeatCountValue(Math.max(1, parseInt(e.target.value, 10) || 1))}
                            className="w-20 px-3 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] font-mono text-center focus:border-[#C5A267] focus:outline-hidden"
                          />
                          <span className="text-xs text-[#888888]">{t.times}</span>
                        </div>

                        {/* Quick increment buttons */}
                        <div className="flex items-center gap-1.5">
                          {[3, 5, 10, 20, 50, 120].map((num) => (
                            <button
                              type="button"
                              key={num}
                              onClick={() => setRepeatCountValue(num)}
                              className={`px-2 py-1 rounded-md text-[10px] font-mono border transition-colors cursor-pointer ${
                                repeatCountValue === num
                                  ? 'border-[#C5A267] bg-[#C5A267] text-[#0F0F0F] font-bold'
                                  : 'border-[#2A2A2A] bg-[#1E1E1E] text-[#888888] hover:text-[#EAEAEA]'
                              }`}
                            >
                              {num}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Row: Participants & Guests (Google Calendar Style) */}
            <div className="flex gap-4 items-start">
              <div className="text-gray-400 mt-2 shrink-0">
                <Users className="w-5 h-5 text-[#888888]" />
              </div>
              <div className="flex-1 space-y-2.5">
                {/* Google Calendar Add Guests Input */}
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <UserPlus className={`w-4 h-4 absolute top-1/2 -translate-y-1/2 text-[#777777] ${isRtl ? 'right-3' : 'left-3'}`} />
                    <input
                      type="text"
                      placeholder={t.addParticipantPlaceholder}
                      value={participantInput}
                      onChange={(e) => setParticipantInput(e.target.value)}
                      onKeyDown={handleKeyDownParticipant}
                      className={`w-full py-2.5 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] placeholder-[#666666] focus:border-[#C5A267] focus:bg-[#1C1C1C] focus:outline-hidden transition-colors ${isRtl ? 'pr-9 pl-3' : 'pl-9 pr-3'}`}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleAddParticipant}
                    className="px-4 py-2.5 rounded-xl bg-[#222222] border border-[#3A3A3A] hover:bg-[#2A2A2A] hover:border-[#C5A267]/40 text-xs font-medium text-[#EAEAEA] transition-colors cursor-pointer"
                  >
                    {t.add}
                  </button>
                </div>

                {/* Google Calendar Style Guest List */}
                {participants.length > 0 && (
                  <div className="pt-1 space-y-2">
                    <div className="flex items-center justify-between text-[11px] text-[#888888] font-medium px-1">
                      <span>
                        {participants.length} {participants.length === 1 ? t.participantSingular : t.participantCount}
                      </span>
                    </div>

                    <div className="space-y-1.5 max-h-44 overflow-y-auto pr-1">
                      {participants.map((person, idx) => {
                        const avatarStyle = getGuestColor(person);
                        const isEmail = person.includes('@');
                        return (
                          <div
                            key={idx}
                            className="flex items-center justify-between px-3 py-2 rounded-xl bg-[#171717] border border-[#262626] hover:border-[#333333] transition-colors group"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shrink-0 border ${avatarStyle.bg} ${avatarStyle.text} ${avatarStyle.border}`}
                              >
                                {person.charAt(0).toUpperCase()}
                              </div>
                              <div className="min-w-0">
                                <p className="text-xs font-medium text-[#EAEAEA] truncate">
                                  {person}
                                </p>
                                {isEmail && (
                                  <p className="text-[10px] text-[#777777] truncate font-mono">
                                    {person}
                                  </p>
                                )}
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => handleRemoveParticipant(idx)}
                              className="p-1 rounded-lg text-[#666666] hover:text-rose-400 hover:bg-rose-500/10 opacity-75 group-hover:opacity-100 transition-all cursor-pointer"
                              title={isRtl ? 'הסרת אורח' : 'Remove guest'}
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Row: Hebrew Title Translation (Optional) */}
            <div className="flex gap-4 items-start">
              <div className="text-gray-400 mt-2 shrink-0">
                <Scroll className="w-5 h-5 text-[#888888]" />
              </div>
              <div className="flex-1 space-y-1">
                <label className="block text-[10px] uppercase font-bold text-[#666666] tracking-wider">
                  {t.hebrewTitleOptional}
                </label>
                <input
                  type="text"
                  placeholder={t.hebrewTitlePlaceholder}
                  dir="rtl"
                  value={hebrewTitle}
                  onChange={(e) => setHebrewTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] font-hebrew placeholder-[#555555] focus:border-[#C5A267] focus:outline-hidden"
                />
              </div>
            </div>

            {/* Row: Custom Color Swatches */}
            <div className="flex gap-4 items-start">
              <div className="text-gray-400 mt-1 shrink-0">
                <Paintbrush className="w-5 h-5 text-[#888888]" />
              </div>
              <div className="flex-1 space-y-1.5">
                <label className="block text-[10px] uppercase font-bold text-[#666666] tracking-wider">
                  {t.calendarEventColor}
                </label>
                <div className="flex flex-wrap gap-2.5">
                  {COLOR_OPTIONS.map((opt) => (
                    <button
                      type="button"
                      key={opt.value}
                      onClick={() => setColor(opt.value)}
                      className="w-6 h-6 rounded-full border border-black/30 flex items-center justify-center transition-all duration-150 transform hover:scale-110 relative cursor-pointer"
                      style={{ backgroundColor: opt.value }}
                      title={isRtl ? opt.labelHe : opt.label}
                    >
                      {color === opt.value && (
                        <span className="w-2.5 h-2.5 rounded-full bg-black/70 border border-white/20" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Row: Sleek Notifications Toggle & Selection */}
            <div className="flex gap-4 items-center">
              <div className="text-gray-400 shrink-0">
                <Bell className="w-5 h-5 text-[#888888]" />
              </div>
              <div className="flex-1 flex flex-wrap items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={enableReminder}
                    onChange={(e) => setEnableReminder(e.target.checked)}
                    className="w-4 h-4 rounded border-[#3A3A3A] bg-[#1A1A1A] text-[#C5A267] focus:ring-0"
                  />
                  <span className="text-xs text-[#EAEAEA]">
                    {t.enableReminderNotification}
                  </span>
                </label>

                {enableReminder && (
                  <select
                    value={reminderDaysBefore}
                    onChange={(e) => setReminderDaysBefore(parseInt(e.target.value, 10))}
                    className="px-2.5 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
                  >
                    <option value="0">{t.onDayOfEvent}</option>
                    <option value="1">{t.oneDayBefore}</option>
                    <option value="2">{t.twoDaysBefore}</option>
                    <option value="3">{t.threeDaysBefore}</option>
                    <option value="7">{t.oneWeekBefore}</option>
                  </select>
                )}
              </div>
            </div>

            {/* Row: Candle Lighting toggle for Yahrzeit memorial */}
            {type === 'yahrzeit' && (
              <div className={`flex gap-4 items-center ${isRtl ? 'pr-9' : 'pl-9'}`}>
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={candleLighting}
                    onChange={(e) => setCandleLighting(e.target.checked)}
                    className="w-4 h-4 rounded border-[#3A3A3A] bg-[#1A1A1A] text-[#C5A267] focus:ring-0"
                  />
                  <span className="text-xs text-[#EAEAEA]">
                    {t.candleLightingMemorial}
                  </span>
                </label>
              </div>
            )}

            {/* Row: Location */}
            <div className="flex gap-4 items-start">
              <div className="text-gray-400 mt-2 shrink-0">
                <MapPin className="w-5 h-5 text-[#888888]" />
              </div>
              <div className="flex-1 space-y-1">
                <input
                  type="text"
                  placeholder={t.addLocation}
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] placeholder-[#555555] focus:border-[#C5A267] focus:outline-hidden"
                />
              </div>
            </div>

            {/* Row: Notes / Description */}
            <div className="flex gap-4 items-start">
              <div className="text-gray-400 mt-2 shrink-0">
                <AlignLeft className="w-5 h-5 text-[#888888]" />
              </div>
              <div className="flex-1 space-y-1">
                <textarea
                  rows={3}
                  placeholder={t.addNotesPlaceholder}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] placeholder-[#555555] focus:border-[#C5A267] focus:outline-hidden resize-none"
                />
              </div>
            </div>

            {/* Row: Collapsible Advanced Settings */}
            <div className="flex gap-4 items-start">
              <div className="text-gray-400 mt-2 shrink-0">
                <SettingsIcon className="w-5 h-5 text-[#888888]" />
              </div>
              <div className="flex-1">
                <div className="border border-[#2A2A2A] rounded-xl bg-[#141414] overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="w-full px-4 py-3 flex items-center justify-between text-xs font-semibold text-[#888888] hover:text-[#EAEAEA] hover:bg-[#1C1C1C] transition-colors cursor-pointer"
                  >
                    <span>{t.advancedHebrewOptions}</span>
                    {showAdvanced ? (
                      <ChevronUp className="w-4 h-4 text-[#C5A267]" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-[#888888]" />
                    )}
                  </button>

                  {showAdvanced && (
                    <div className="p-4 border-t border-[#2A2A2A] space-y-4 bg-[#181818]/50 animate-in fade-in duration-100">
                      {/* Age / Occurrence Counter Option */}
                      <div className="space-y-2">
                        <label className="flex items-center gap-2 cursor-pointer select-none">
                          <input
                            type="checkbox"
                            checked={showCounter}
                            onChange={(e) => setShowCounter(e.target.checked)}
                            className="w-4 h-4 rounded border-[#3A3A3A] bg-[#1A1A1A] text-[#C5A267] focus:ring-0"
                          />
                          <span className="text-xs font-semibold text-[#EAEAEA]">
                            {t.showOccurrenceAgeCounter}
                          </span>
                        </label>
                        <p className="text-[10px] text-[#666666]">
                          {t.occurrenceCounterDesc}
                        </p>

                        {showCounter && (
                          <div className="grid grid-cols-2 gap-3 pt-1">
                            <div>
                              <label className="block text-[10px] text-[#888888] mb-1">
                                {t.startHebrewYearLabel}
                              </label>
                              <input
                                type="number"
                                placeholder="למשל: 5783"
                                value={startHebrewYear}
                                onChange={(e) => setStartHebrewYear(e.target.value)}
                                className="w-full px-3 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] font-mono focus:border-[#C5A267] focus:outline-hidden"
                              />
                            </div>

                            <div>
                              <label className="block text-[10px] text-[#888888] mb-1">
                                {t.initialCountLabel}
                              </label>
                              <input
                                type="number"
                                min="0"
                                value={counterStart}
                                onChange={(e) => setCounterStart(parseInt(e.target.value, 10) || 0)}
                                className="w-full px-3 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] font-mono focus:border-[#C5A267] focus:outline-hidden"
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Adar leap year rule if month is Adar 12/13 */}
                      {(hebrewMonth === 12 || hebrewMonth === 13) && (
                        <div className="space-y-1">
                          <label className="block text-[10px] font-semibold text-[#888888] uppercase tracking-wider">
                            {t.adarLeapYearRule}
                          </label>
                          <select
                            value={leapYearRule}
                            onChange={(e) => setLeapYearRule(e.target.value as any)}
                            className="w-full px-3 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
                          >
                            <option value="adar2">{t.observeAdar2}</option>
                            <option value="adar1">{t.observeAdar1}</option>
                            <option value="both">{t.observeBothAdars}</option>
                          </select>
                        </div>
                      )}

                      {/* Override Hebrew Date */}
                      <div className="pt-3 border-t border-[#2A2A2A] space-y-2">
                        <label className="block text-[10px] font-bold text-[#888888] uppercase tracking-wider">
                          {t.overrideHebrewDateDirectly}
                        </label>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] text-[#666666] mb-1">{t.month}</label>
                            <select
                              value={hebrewMonth}
                              onChange={(e) => setHebrewMonth(parseInt(e.target.value, 10))}
                              className="w-full px-2.5 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
                            >
                              {HEBREW_MONTH_NAMES_LIST.map((m) => (
                                <option key={m.num} value={m.num}>
                                  {isRtl ? `${m.nameHe} (${m.name})` : `${m.name} (${m.nameHe})`}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label className="block text-[10px] text-[#666666] mb-1">{t.day}</label>
                            <select
                              value={hebrewDay}
                              onChange={(e) => setHebrewDay(parseInt(e.target.value, 10))}
                              className="w-full px-2.5 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
                            >
                              {Array.from({ length: 30 }, (_, i) => i + 1).map((d) => (
                                <option key={d} value={d}>
                                  {getHebrewNumberGematriya(d)} ({d})
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* 4. Upcoming Dates Preview block inside the form */}
          <div className={`p-4 rounded-xl bg-[#161616] border border-[#2A2A2A] text-xs space-y-2 ${isRtl ? 'mr-9' : 'ml-9'}`}>
            <span className="text-[10px] font-bold text-[#888888] uppercase tracking-wider block">
              {t.upcomingGregorianOccurrences}
            </span>
            <div className="space-y-1.5">
              {upcomingOccurrences.map((occ, idx) => (
                <div key={idx} className="flex items-center justify-between text-[#888888]">
                  <span>{occ.hebrewYear} • {occ.hebrewDateStr}</span>
                  <span className="font-mono text-[#EAEAEA] font-semibold">
                    {occ.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    <span className="text-[10px] text-[#C5A267] mx-2 font-normal">
                      ({occ.daysUntil} {occ.daysUntil === 1 ? t.daySingular : t.days})
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Footer controls */}
          <div className="pt-4 border-t border-[#2A2A2A] flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs font-semibold text-[#888888] hover:text-[#EAEAEA] transition-colors cursor-pointer"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold shadow-sm transition-colors cursor-pointer"
            >
              {t.save}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
