import React from 'react';
import { AlertOctagon, Flame, Drama, AlertTriangle, HeartCrack, Smile, ArrowRight } from 'lucide-react';
import { StationEvent } from '../types/game';
import { soundFx } from '../utils/audio';

interface EventModalProps {
  event: StationEvent;
  onResolveChoice: (choiceIndex: number) => void;
}

export const EventModal: React.FC<EventModalProps> = ({ event, onResolveChoice }) => {
  const getEventIcon = (category: string) => {
    switch (category) {
      case 'breaking':
        return <Flame className="w-8 h-8 text-red-500 animate-bounce" />;
      case 'backstage':
        return <Drama className="w-8 h-8 text-purple-400" />;
      case 'sponsor':
        return <AlertTriangle className="w-8 h-8 text-amber-400" />;
      default:
        return <AlertOctagon className="w-8 h-8 text-red-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 select-none">
      <div className="w-full max-w-sm sm:max-w-md bg-slate-900 border-2 border-red-500/80 rounded-3xl p-5 shadow-2xl flex flex-col gap-4 relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Urgent Ticker Header */}
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <div className="w-14 h-14 rounded-2xl bg-red-950/60 border border-red-500/40 flex items-center justify-center shrink-0">
            {getEventIcon(event.category)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-red-600 text-white font-mono text-[10px] font-black uppercase tracking-widest animate-pulse">
                DECISÃO DA DIRETORIA
              </span>
              <span className="text-xs text-slate-400 font-mono">PLANTÃO EM TEMPO REAL</span>
            </div>
            <h2 className="text-lg md:text-xl font-bold text-white mt-1 leading-snug">
              {event.title}
            </h2>
          </div>
        </div>

        {/* Narrative Description */}
        <p className="text-sm text-slate-300 leading-relaxed bg-slate-950/80 p-4 rounded-xl border border-slate-800">
          {event.description}
        </p>

        {/* Choices Options */}
        <div className="space-y-3">
          {event.choices.map((choice, idx) => (
            <button
              key={idx}
              onClick={() => {
                soundFx.playClick();
                onResolveChoice(idx);
              }}
              className="w-full p-4 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-slate-700/80 hover:border-amber-400 text-left transition-all cursor-pointer group flex flex-col gap-1 shadow-md"
            >
              <div className="flex items-center justify-between text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
                <span>{choice.text}</span>
                <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity text-amber-400" />
              </div>
              <div className="text-xs text-slate-400 leading-normal">
                {choice.effectDescription}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
