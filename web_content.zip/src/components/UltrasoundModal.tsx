import React from 'react';
import { X, Heart, Sparkles, Activity } from 'lucide-react';
import { Gender } from '../game/types';
import { playClickSound, playHeartbeatSound } from '../utils/audio';

interface UltrasoundModalProps {
  partnerName: string;
  gender: Gender;
  message: string;
  onClose: () => void;
}

export const UltrasoundModal: React.FC<UltrasoundModalProps> = ({
  partnerName,
  gender,
  message,
  onClose
}) => {
  React.useEffect(() => {
    playHeartbeatSound();
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl p-6 shadow-2xl text-right animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Activity className="w-5 h-5 animate-pulse" />
            </span>
            <div>
              <h2 className="text-base font-bold text-slate-100">تقرير فحص السونار والاطمئنان</h2>
              <p className="text-[11px] text-slate-400">عيادة رعاية الأمومة والجنين</p>
            </div>
          </div>
          <button
            onClick={() => { playClickSound(); onClose(); }}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Ultrasound screen simulation */}
        <div className="mt-4 p-4 rounded-2xl bg-black border border-cyan-500/30 relative overflow-hidden text-center shadow-inner">
          <div className="absolute inset-0 bg-radial from-cyan-950/40 via-transparent to-transparent pointer-events-none" />
          <div className="flex items-center justify-between text-[10px] text-cyan-400 font-mono mb-2">
            <span>SONAR 4D ULTRASOUND</span>
            <span className="flex items-center gap-1">
              <Heart className="w-3 h-3 text-rose-500 animate-ping" />
              142 BPM
            </span>
          </div>

          <div className="py-6 my-1">
            <span className="text-5xl inline-block drop-shadow-[0_0_15px_rgba(34,211,238,0.4)]">
              {gender === 'boy' ? '👶🏻💙' : '👶🏻💖'}
            </span>
            <div className="mt-3 inline-block px-4 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-400 text-cyan-200 font-black text-sm">
              نوع الجنين المتوقع: {gender === 'boy' ? 'ولد صالح 👦' : 'بنت جميلة 👧'}
            </div>
          </div>

          <p className="text-[11px] text-slate-300 font-mono">
            حالة نمو الجنين ممتازة • نبض طبيعي • صحة {partnerName} مستقرة تماماً
          </p>
        </div>

        <p className="mt-4 text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-2xl border border-slate-800">
          {message}
        </p>

        <button
          onClick={() => { playClickSound(); onClose(); }}
          className="mt-4 w-full py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition flex items-center justify-center gap-1.5"
        >
          <span>الحمد لله، إتمام الزيارة</span>
          <Sparkles className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
