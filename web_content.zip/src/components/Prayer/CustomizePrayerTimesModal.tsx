import React, { useState } from 'react';
import { X, Clock, RotateCcw, Check, Sparkles } from 'lucide-react';
import { useApp, getTodayString } from '../../context/AppContext';
import { DEFAULT_PRAYER_PERIODS } from '../../utils/prayerTimes';

interface CustomizePrayerTimesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CustomizePrayerTimesModal: React.FC<CustomizePrayerTimesModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { prayers, setPrayerWaqtTimes, language, t } = useApp();
  const isBn = language === 'bn';
  const todayStr = getTodayString();
  const todayPrayers = (prayers[todayStr] || {}) as Record<string, any>;

  // Local state for start and end times
  const [times, setTimes] = useState<Record<string, { start: string; end: string }>>(() => {
    const initial: Record<string, { start: string; end: string }> = {};
    DEFAULT_PRAYER_PERIODS.forEach((p) => {
      initial[p.key] = {
        start: todayPrayers[`${p.key}Start`] || p.defaultStart,
        end: todayPrayers[`${p.key}End`] || p.defaultEnd,
      };
    });
    return initial;
  });

  if (!isOpen) return null;

  const handleChange = (key: string, field: 'start' | 'end', val: string) => {
    setTimes((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        [field]: val,
      },
    }));
  };

  const handleSaveAll = () => {
    DEFAULT_PRAYER_PERIODS.forEach((p) => {
      const pTimes = times[p.key];
      if (pTimes) {
        setPrayerWaqtTimes(p.key, pTimes.start, pTimes.end, todayStr);
      }
    });
    onClose();
  };

  const handleResetToDefault = () => {
    const defaults: Record<string, { start: string; end: string }> = {};
    DEFAULT_PRAYER_PERIODS.forEach((p) => {
      defaults[p.key] = {
        start: p.defaultStart,
        end: p.defaultEnd,
      };
      setPrayerWaqtTimes(p.key, p.defaultStart, p.defaultEnd, todayStr);
    });
    setTimes(defaults);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl text-slate-900 dark:text-slate-100 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400">
              <Clock size={18} />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t.editPrayerTimes}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isBn ? 'আপনার এলাকার মসজিদের সময় অনুযায়ী ওয়াক্ত নির্ধারণ করুন' : 'Adjust start & end waqt for your local city'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
          >
            <X size={18} />
          </button>
        </div>

        {/* Prayer Time Inputs */}
        <div className="space-y-3.5 py-4">
          {DEFAULT_PRAYER_PERIODS.map((p) => {
            const current = times[p.key] || { start: p.defaultStart, end: p.defaultEnd };
            return (
              <div
                key={p.key}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-700/60 flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-2.5 min-w-[90px]">
                  <span className="text-xl">{p.icon}</span>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      {isBn ? p.nameBn : p.nameEn}
                    </h4>
                    <span className="text-[10px] text-slate-400">{p.rakats}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-1 justify-end">
                  {/* Start time */}
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] text-slate-500 font-medium mb-1">
                      {t.prayerStartTime}
                    </span>
                    <input
                      type="time"
                      value={current.start}
                      onChange={(e) => handleChange(p.key, 'start', e.target.value)}
                      className="px-2 py-1 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                    />
                  </div>

                  <span className="text-slate-400 text-xs mt-3">→</span>

                  {/* End time */}
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] text-slate-500 font-medium mb-1">
                      {t.prayerEndTime}
                    </span>
                    <input
                      type="time"
                      value={current.end}
                      onChange={(e) => handleChange(p.key, 'end', e.target.value)}
                      className="px-2 py-1 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={handleResetToDefault}
            className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw size={14} />
            <span>{t.resetPrayerTimes}</span>
          </button>

          <button
            onClick={handleSaveAll}
            className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-violet-500/20 active:scale-95 transition-all"
          >
            <Check size={14} />
            <span>{t.savePrayerTimes}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
