import React, { useState, useEffect } from 'react';
import {
  MoonStar,
  Check,
  BookOpen,
  Plus,
  Minus,
  Sparkles,
  Calendar,
  CheckCircle2,
  Circle,
  Clock,
  HeartHandshake,
  Compass,
  AlertCircle,
  Bell,
  Settings2,
  Lock,
} from 'lucide-react';
import { useApp, getTodayString } from '../../context/AppContext';
import { DailyPrayers } from '../../types';
import { TasbihModal } from './TasbihModal';
import { CustomizePrayerTimesModal } from './CustomizePrayerTimesModal';
import {
  getAllPrayerStatuses,
  getActivePrayerWaqt,
  formatTo12Hour,
  toBengaliNumerals,
} from '../../utils/prayerTimes';
import { startAlarmSound, stopAlarmSound, primeAudioForBackground } from '../../utils/alarmAudio';
import { requestScreenWakeLock } from '../../utils/wakeLockManager';

// List of 114 Surahs for the Quran tracker
const SURAH_NAMES = [
  '1. Al-Fatihah', '2. Al-Baqarah', '3. Ali \'Imran', '4. An-Nisa', '5. Al-Ma\'idah',
  '6. Al-An\'am', '7. Al-A\'raf', '8. Al-Anfal', '9. At-Tawbah', '10. Yunus',
  '11. Hud', '12. Yusuf', '13. Ar-Ra\'d', '14. Ibrahim', '15. Al-Hijr',
  '16. An-Nahl', '17. Al-Isra', '18. Al-Kahf', '19. Maryam', '20. Ta-Ha',
  '21. Al-Anbiya', '22. Al-Hajj', '23. Al-Mu\'minun', '24. An-Nur', '25. Al-Furqan',
  '26. Ash-Shu\'ara', '27. An-Naml', '28. Al-Qasas', '29. Al-\'Ankabut', '30. Ar-Rum',
  '31. Luqman', '32. As-Sajdah', '33. Al-Ahzab', '34. Saba', '35. Fatir',
  '36. Ya-Sin', '37. As-Saffat', '38. Sad', '39. Az-Zumar', '40. Ghafir',
  '41. Fussilat', '42. Ash-Shura', '43. Az-Zukhruf', '44. Ad-Dukhan', '45. Al-Jathiyah',
  '46. Al-Ahqaf', '47. Muhammad', '48. Al-Fath', '49. Al-Hujurat', '50. Qaf',
  '51. Adh-Dhariyat', '52. At-Tur', '53. An-Najm', '54. Al-Qamar', '55. Ar-Rahman',
  '56. Al-Waqi\'ah', '57. Al-Hadid', '58. Al-Mujadila', '59. Al-Hashr', '60. Al-Mumtahanah',
  '61. As-Saff', '62. Al-Jumu\'ah', '63. Al-Munafiqun', '64. At-Taghabun', '65. At-Talaq',
  '66. At-Tahrim', '67. Al-Mulk', '68. Al-Qalam', '69. Al-Haqqah', '70. Al-Ma\'arij',
  '71. Nuh', '72. Al-Jinn', '73. Al-Muzzammil', '74. Al-Muddaththir', '75. Al-Qiyamah',
  '76. Al-Insan', '77. Al-Mursalat', '78. An-Naba', '79. An-Nazi\'at', '80. \'Abasa',
  '81. At-Takwir', '82. Al-Infitar', '83. Al-Mutaffifin', '84. Al-Inshiqaq', '85. Al-Buruj',
  '86. At-Tariq', '87. Al-A\'la', '88. Al-Ghashiyah', '89. Al-Fajr', '90. Al-Balad',
  '91. Ash-Shams', '92. Al-Layl', '93. Ad-Duha', '94. Ash-Sharh', '95. At-Tin',
  '96. Al-\'Alaq', '97. Al-Qadr', '98. Al-Bayyinah', '99. Az-Zalzalah', '100. Al-\'Adiyat',
  '101. Al-Qari\'ah', '102. At-Takathur', '103. Al-\'Asr', '104. Al-Humazah', '105. Al-Fil',
  '106. Quraysh', '107. Al-Ma\'un', '108. Al-Kawthar', '109. Al-Kafirun', '110. An-Nasr',
  '111. Al-Masad', '112. Al-Ikhlas', '113. Al-Falaq', '114. An-Nas'
];

export const PrayerAndSpiritualLife: React.FC = () => {
  const {
    prayers,
    togglePrayer,
    setPrayerTime,
    quran,
    updateQuran,
    addQuranPages,
    dhikr,
    incrementDhikr,
    resetDhikr,
    resetAllDhikr,
    language,
    t,
  } = useApp();

  const isBn = language === 'bn';
  const [isTasbihOpen, setIsTasbihOpen] = useState(false);
  const [isCustomizeTimesOpen, setIsCustomizeTimesOpen] = useState(false);
  const [editingPrayerTimeKey, setEditingPrayerTimeKey] = useState<keyof DailyPrayers | null>(null);
  const [customTimeInput, setCustomTimeInput] = useState('');

  // Lock-screen test alarm state
  const [lockTestCountdown, setLockTestCountdown] = useState<number | null>(null);

  // Live timer tick for accurate countdowns
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 10000); // Check every 10 seconds
    return () => clearInterval(timer);
  }, []);

  const todayStr = getTodayString();
  const todayPrayers = (prayers[todayStr] || {
    fajr: false,
    dhuhr: false,
    asr: false,
    maghrib: false,
    isha: false,
    tahajjud: false,
  }) as Record<string, any>;

  const obligatoryKeys: Array<keyof DailyPrayers> = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  const completedObligatory = obligatoryKeys.filter((k) => todayPrayers[k]).length;
  const prayerPercentage = Math.round((completedObligatory / 5) * 100);

  // Compute live prayer statuses with start, end, expiration, and countdown
  const allPrayerStatuses = getAllPrayerStatuses(todayPrayers, currentTime, isBn);
  const activeWaqt = getActivePrayerWaqt(todayPrayers, currentTime, isBn);

  const handleSavePrayerTime = (key: keyof DailyPrayers) => {
    if (customTimeInput) {
      setPrayerTime(key, customTimeInput);
    }
    setEditingPrayerTimeKey(null);
    setCustomTimeInput('');
  };

  // Trigger 5-second test alarm so user can lock screen and test
  const handleTriggerLockTest = () => {
    if (lockTestCountdown !== null) return;
    primeAudioForBackground();
    requestScreenWakeLock();
    let sec = 5;
    setLockTestCountdown(sec);

    const timer = setInterval(() => {
      sec -= 1;
      setLockTestCountdown(sec);
      if (sec <= 0) {
        clearInterval(timer);
        setLockTestCountdown(null);
        startAlarmSound(isBn ? 'নামাজের ওয়াক্ত অ্যালার্ম' : 'Prayer Waqt Alarm');
        if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
          try {
            new Notification('🔔 লক স্ক্রিন অ্যালার্ম সফল!', {
              body: 'স্ক্রিন লক থাকা অবস্থায় অ্যালার্ম রিংটোন ও ভাইব্রেশন নিখুঁতভাবে কাজ করছে।',
              icon: '/pwa-192x192.png',
              requireInteraction: true,
            });
          } catch {
            // ignore
          }
        }
      }
    }, 1000);
  };

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Header Hero Banner */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-violet-900 via-indigo-900 to-slate-900 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-44 h-44 bg-violet-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-xs font-semibold mb-2">
              <MoonStar size={13} className="text-amber-300" />
              <span>{t.spiritualTitle}</span>
            </div>
            <h2 className="text-2xl font-black tracking-tight">
              {isBn
                ? `${toBengaliNumerals(completedObligatory)} / ৫ ওয়াক্ত নামাজ আদায় সম্পন্ন`
                : `${completedObligatory} of 5 Prayers Offered`}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-md mt-1 leading-relaxed">
              {t.spiritualSubtitle}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsCustomizeTimesOpen(true)}
              className="px-3.5 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-md flex items-center gap-1.5 active:scale-95 transition-all"
              title="ওয়াক্তের সময় পরিবর্তন"
            >
              <Settings2 size={15} />
              <span className="hidden sm:inline">{t.editPrayerTimes}</span>
              <span className="sm:hidden">{isBn ? 'সময়সূচি' : 'Times'}</span>
            </button>

            <button
              onClick={() => setIsTasbihOpen(true)}
              className="px-4 py-2.5 rounded-2xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold shadow-md shadow-violet-500/30 flex items-center gap-2 active:scale-95 transition-all"
            >
              <Sparkles size={15} />
              <span>{t.tasbihTitle}</span>
            </button>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-300 mb-1.5">
            <span>{isBn ? 'দৈনিক নামাজের ধারাবাহিকতা' : 'Daily Prayer Consistency'}</span>
            <span className="font-bold text-amber-300">
              {isBn ? `${toBengaliNumerals(prayerPercentage)}%` : `${prayerPercentage}%`}
            </span>
          </div>
          <div className="w-full bg-white/15 rounded-full h-2 overflow-hidden">
            <div
              className="h-full bg-linear-to-r from-emerald-400 to-teal-300 rounded-full transition-all duration-500"
              style={{ width: `${prayerPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* 2. Active Waqt & Remaining Minutes Countdown Hero */}
      {activeWaqt && (
        <section className="bg-linear-to-br from-emerald-900/90 via-teal-900 to-slate-900 text-white rounded-3xl p-5 border border-emerald-500/30 shadow-lg relative overflow-hidden">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{activeWaqt.icon}</span>
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[11px] font-bold uppercase tracking-wider">
                    {t.prayerWaqtActive}
                  </span>
                  <span className="text-xs text-emerald-200/80 font-mono">
                    {activeWaqt.formattedTimeRange}
                  </span>
                </div>
                <h3 className="text-lg font-black text-white mt-0.5">
                  {isBn ? `${activeWaqt.name}ের ওয়াক্ত চলছে` : `Current Waqt: ${activeWaqt.name}`}
                </h3>
              </div>
            </div>

            {/* Complete quick toggle */}
            <button
              onClick={() => togglePrayer(activeWaqt.key as any)}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 ${
                todayPrayers[activeWaqt.key]
                  ? 'bg-emerald-500 text-white'
                  : 'bg-white/15 hover:bg-white/25 text-white'
              }`}
            >
              {todayPrayers[activeWaqt.key] ? (
                <>
                  <Check size={14} className="stroke-[3]" />
                  <span>{t.prayerRecorded}</span>
                </>
              ) : (
                <span>+ {isBn ? 'নামাজ আদায় করেছি' : 'Mark Done'}</span>
              )}
            </button>
          </div>

          {/* Large Countdown Clock */}
          <div className="mt-4 pt-3 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Clock size={16} className="text-emerald-300 shrink-0" />
              <span className="text-sm font-extrabold text-amber-300">
                {activeWaqt.formattedRemaining}
              </span>
            </div>

            {/* Visual urgency pill */}
            {activeWaqt.remainingMinutes <= 30 && activeWaqt.remainingMinutes > 0 && (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-300 bg-rose-500/20 px-2.5 py-0.5 rounded-full animate-pulse">
                <AlertCircle size={12} />
                <span>
                  {isBn
                    ? `ওয়াক্ত শেষ হতে বেশি সময় নেই (${activeWaqt.formattedHoursAndMinutes})`
                    : `Hurry! Only ${activeWaqt.formattedHoursAndMinutes} left`}
                </span>
              </span>
            )}
          </div>

          {/* Progress bar of waqt duration */}
          <div className="mt-2.5 w-full bg-white/10 rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                activeWaqt.remainingMinutes <= 20
                  ? 'bg-rose-400'
                  : activeWaqt.remainingMinutes <= 45
                  ? 'bg-amber-400'
                  : 'bg-emerald-400'
              }`}
              style={{ width: `${activeWaqt.progressPercent}%` }}
            />
          </div>
        </section>
      )}

      {/* 3. Lock-Screen Alarm Test Notice Card */}
      <div className="bg-linear-to-r from-amber-50 to-orange-50 dark:from-slate-800/80 dark:to-slate-800/50 border border-amber-200/80 dark:border-amber-900/40 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5">
            <Lock size={18} />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>{t.lockScreenAlarmTitle}</span>
              <span className="px-1.5 py-0.2 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-mono text-[10px]">
                Active
              </span>
            </h4>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5 leading-relaxed">
              {isBn
                ? 'ফোন লক থাকলেও স্ক্রিন ও সাউন্ড চালু রাখতে ওয়েক-লক ও ওয়েব-ওয়ার্কার সংযুক্ত করা হয়েছে।'
                : 'Enhanced with Screen Wake Lock & Background Web Worker so alarm rings reliably when locked.'}
            </p>
          </div>
        </div>

        <button
          onClick={handleTriggerLockTest}
          disabled={lockTestCountdown !== null}
          className={`shrink-0 px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs ${
            lockTestCountdown !== null
              ? 'bg-rose-600 text-white animate-pulse'
              : 'bg-amber-600 hover:bg-amber-700 text-white active:scale-95'
          }`}
        >
          <Bell size={14} />
          <span>
            {lockTestCountdown !== null
              ? (isBn ? `ফোন এখনই লক করুন: ${toBengaliNumerals(lockTestCountdown)}s...` : `Lock phone now: ${lockTestCountdown}s...`)
              : t.lockScreenAlarmTestBtn}
          </span>
        </button>
      </div>

      {/* 4. Today's 5 Daily Prayers + Tahajjud Tracker */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>{t.prayerProgress}</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isBn
                ? 'প্রতিটি ওয়াক্তের শুরু ও শেষ সময় এবং ওয়াক্ত শেষ হলে লাল চিহ্নে সতর্কবার্তা'
                : 'Waqt start & end times with live expiration red indicators'}
            </p>
          </div>

          <button
            onClick={() => setIsCustomizeTimesOpen(true)}
            className="text-xs font-semibold text-violet-600 dark:text-violet-400 hover:underline flex items-center gap-1"
          >
            <Settings2 size={13} />
            <span>{isBn ? 'সময় পরিবর্তন' : 'Edit Times'}</span>
          </button>
        </div>

        <div className="space-y-3">
          {allPrayerStatuses.map((item) => {
            const isCompleted = Boolean(todayPrayers[item.key]);
            const loggedTime = (todayPrayers as any)[`${item.key}Time`];

            // Card styling determination:
            // 1. Expired and not completed: Red alert styling!
            // 2. Completed: Green styling!
            // 3. Active: Indigo/Violet highlight!
            // 4. Upcoming: Neutral slate
            let cardClasses = 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200/60 dark:border-slate-700/60';
            if (item.isExpired && !isCompleted && item.key !== 'tahajjud') {
              cardClasses = 'bg-rose-50/90 dark:bg-rose-950/30 border-rose-300 dark:border-rose-800/80 shadow-xs';
            } else if (isCompleted) {
              cardClasses = 'bg-emerald-50/60 dark:bg-emerald-950/25 border-emerald-200/80 dark:border-emerald-800/60';
            } else if (item.isActive) {
              cardClasses = 'bg-indigo-50/50 dark:bg-indigo-950/30 border-indigo-300 dark:border-indigo-700/80 ring-2 ring-indigo-500/20';
            }

            return (
              <div
                key={item.key}
                className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${cardClasses}`}
              >
                <div className="flex items-start sm:items-center gap-3 min-w-0">
                  <span className="text-2xl shrink-0 mt-0.5 sm:mt-0">{item.icon}</span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {item.name}
                      </h4>

                      {/* Waqt status badges */}
                      {item.isExpired && (
                        <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-rose-600 text-white font-black shadow-xs tracking-wide">
                          <AlertCircle size={10} className="stroke-[3]" />
                          <span>{t.prayerWaqtExpired}</span>
                        </span>
                      )}

                      {item.isActive && (
                        <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-emerald-600 text-white font-bold animate-pulse">
                          <span>{t.prayerWaqtActive}</span>
                        </span>
                      )}

                      {item.isUpcoming && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold">
                          {t.prayerWaqtUpcoming}
                        </span>
                      )}

                      {item.key === 'tahajjud' && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-semibold">
                          Sunnah / Nafil
                        </span>
                      )}
                    </div>

                    {/* Start & End Times + Countdown */}
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs">
                      {/* Start Time */}
                      <span className="text-slate-700 dark:text-slate-300 font-medium">
                        <strong className="text-slate-900 dark:text-white">{t.prayerStartTime}:</strong>{' '}
                        {formatTo12Hour(item.startTime, isBn)}
                      </span>

                      {/* End Time */}
                      <span className="text-slate-700 dark:text-slate-300 font-medium">
                        <strong className="text-slate-900 dark:text-white">{t.prayerEndTime}:</strong>{' '}
                        {formatTo12Hour(item.endTime, isBn)}
                      </span>

                      {/* Remaining minutes countdown when active */}
                      {item.isActive && (
                        <span className="font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-100/80 dark:bg-indigo-900/60 px-2 py-0.5 rounded-md">
                          ⏳ {item.formattedRemaining}
                        </span>
                      )}

                      {/* Expiration red note if not completed */}
                      {item.isExpired && !isCompleted && item.key !== 'tahajjud' && (
                        <span className="font-bold text-rose-700 dark:text-rose-400">
                          • {isBn ? 'ওয়াক্ত পার হয়ে গেছে (ক্বাযা পড়ুন)' : 'Waqt expired (Qadha)'}
                        </span>
                      )}

                      {loggedTime && (
                        <span className="font-mono text-emerald-700 dark:text-emerald-400 text-[11px]">
                          • {isBn ? 'আদায়:' : 'Logged:'} {loggedTime}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions: Log time and Mark Done */}
                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  {editingPrayerTimeKey === item.key ? (
                    <div className="flex items-center gap-1">
                      <input
                        type="time"
                        value={customTimeInput}
                        onChange={(e) => setCustomTimeInput(e.target.value)}
                        className="text-xs px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800"
                      />
                      <button
                        onClick={() => handleSavePrayerTime(item.key as any)}
                        className="px-2 py-1 bg-violet-600 text-white rounded-lg text-xs font-semibold"
                      >
                        Set
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        setEditingPrayerTimeKey(item.key as any);
                        setCustomTimeInput(loggedTime || '');
                      }}
                      className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      title={isBn ? 'আদায়ের নির্দিষ্ট সময় নোট করুন' : 'Log completed time'}
                    >
                      <Clock size={15} />
                    </button>
                  )}

                  {/* Complete check button */}
                  <button
                    onClick={() => togglePrayer(item.key as any)}
                    className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 ${
                      isCompleted
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : item.isExpired
                        ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-xs'
                        : 'bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:border-violet-400'
                    }`}
                  >
                    {isCompleted ? (
                      <>
                        <Check size={14} className="stroke-[3]" />
                        <span>{t.prayerRecorded}</span>
                      </>
                    ) : item.isExpired ? (
                      <>
                        <AlertCircle size={14} />
                        <span>{isBn ? '+ ক্বাযা আদায়' : '+ Mark Qadha'}</span>
                      </>
                    ) : (
                      <span>+ {isBn ? 'আদায় করেছি' : 'Mark Done'}</span>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 5. Quran Reading Tracker */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400">
              <BookOpen size={18} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {t.quranProgressTitle}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {quran.pagesReadToday} / {quran.dailyGoalPages} {isBn ? 'পৃষ্ঠা পড়া সম্পন্ন' : 'pages read today'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => addQuranPages(-1)}
              className="w-8 h-8 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center hover:bg-slate-50 dark:hover:bg-slate-800 active:scale-95 transition-all"
              aria-label="Decrease pages"
            >
              <Minus size={14} />
            </button>
            <span className="font-mono text-sm font-bold w-6 text-center text-slate-900 dark:text-white">
              {quran.pagesReadToday}
            </span>
            <button
              onClick={() => addQuranPages(1)}
              className="w-8 h-8 rounded-xl bg-violet-600 text-white flex items-center justify-center hover:bg-violet-700 active:scale-95 transition-all shadow-xs"
              aria-label="Increase pages"
            >
              <Plus size={14} />
            </button>
          </div>
        </div>

        {/* Current Surah and Ayah Selectors */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              {t.currentSurah}
            </label>
            <select
              value={quran.currentSurah}
              onChange={(e) => updateQuran({ currentSurah: parseInt(e.target.value) || 1 })}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-violet-500"
            >
              {SURAH_NAMES.map((name, idx) => (
                <option key={idx + 1} value={idx + 1}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              {t.currentAyah}
            </label>
            <input
              type="number"
              min="1"
              max="286"
              value={quran.currentAyah}
              onChange={(e) => updateQuran({ currentAyah: parseInt(e.target.value) || 1 })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-mono font-semibold focus:outline-hidden focus:ring-2 focus:ring-violet-500"
            />
          </div>
        </div>
      </section>

      {/* 6. Daily Islamic Adhkar & Sunnah Deeds */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {t.dailyDhikrList}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isBn ? 'গণনা করতে স্পর্শ করুন' : 'Tap to increment daily remembrance count'}
            </p>
          </div>
          <button
            onClick={resetAllDhikr}
            className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
          >
            {isBn ? 'রিসেট' : 'Reset All'}
          </button>
        </div>

        <div className="space-y-2.5">
          {dhikr.map((item) => (
            <div
              key={item.id}
              className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                item.completed
                  ? 'bg-indigo-50/40 dark:bg-indigo-950/20 border-indigo-200/80 dark:border-indigo-800/50'
                  : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200/60 dark:border-slate-700/60'
              }`}
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                    {item.title}
                  </h4>
                  {item.completed && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 font-bold">
                      {isBn ? 'সম্পন্ন' : 'Complete'}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-serif pt-0.5">
                  {item.arabic}
                </p>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => incrementDhikr(item.id)}
                  className={`px-3 py-1.5 rounded-xl font-mono text-xs font-bold transition-all active:scale-95 ${
                    item.completed
                      ? 'bg-emerald-500 text-white shadow-xs'
                      : 'bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-800 dark:text-slate-200 hover:border-violet-400'
                  }`}
                >
                  {item.currentCount} / {item.targetCount}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Tasbih Modal */}
      <TasbihModal isOpen={isTasbihOpen} onClose={() => setIsTasbihOpen(false)} />

      {/* Customize Prayer Times Modal */}
      <CustomizePrayerTimesModal
        isOpen={isCustomizeTimesOpen}
        onClose={() => setIsCustomizeTimesOpen(false)}
      />
    </div>
  );
};
