import React, { useState } from 'react';
import { X, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { triggerCelebration } from '../../utils/confetti';

interface TasbihModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TasbihModal: React.FC<TasbihModalProps> = ({ isOpen, onClose }) => {
  const { t } = useApp();
  const [count, setCount] = useState(0);
  const [target, setTarget] = useState(33);
  const [haptic, setHaptic] = useState(true);

  if (!isOpen) return null;

  const handleTap = () => {
    const next = count + 1;
    setCount(next);

    if (haptic && typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(25);
      } catch {
        // ignore
      }
    }

    if (next % target === 0) {
      triggerCelebration(0.5);
      if (haptic && typeof window !== 'undefined' && 'vibrate' in navigator) {
        try {
          navigator.vibrate([40, 60, 40]);
        } catch {
          // ignore
        }
      }
    }
  };

  const handleReset = () => {
    setCount(0);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-sm rounded-3xl bg-linear-to-b from-slate-900 via-slate-900 to-indigo-950 border border-slate-800 p-6 shadow-2xl text-white text-center"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          aria-label="Close"
        >
          <X size={18} />
        </button>

        <h3 className="text-lg font-bold text-white mb-1">
          {t.tasbihTitle}
        </h3>
        <p className="text-xs text-slate-400 mb-6">
          {t.tasbihSubtitle}
        </p>

        {/* Target Presets */}
        <div className="flex justify-center gap-2 mb-6">
          {[33, 100, 500].map((num) => (
            <button
              key={num}
              onClick={() => {
                setTarget(num);
                setCount(0);
              }}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                target === num
                  ? 'bg-violet-600 text-white shadow-xs'
                  : 'bg-slate-800/80 text-slate-400 hover:text-white'
              }`}
            >
              Goal: {num}
            </button>
          ))}
        </div>

        {/* Big Counter Button */}
        <div className="my-6 flex justify-center">
          <button
            onClick={handleTap}
            className="w-48 h-48 rounded-full bg-linear-to-tr from-violet-600 to-sky-500 shadow-2xl shadow-violet-500/30 flex flex-col items-center justify-center p-4 active:scale-95 transition-all ring-8 ring-white/10 hover:ring-white/20 select-none cursor-pointer"
          >
            <span className="text-5xl font-black font-mono tracking-tight drop-shadow-md">
              {count}
            </span>
            <span className="text-xs font-semibold text-white/80 uppercase tracking-widest mt-1">
              {t.tapToCount}
            </span>
            <span className="text-[11px] text-sky-200 mt-2 font-mono">
              Cycle: {Math.floor(count / target)}
            </span>
          </button>
        </div>

        {/* Counter bottom controls */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800/80">
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
          >
            <RotateCcw size={14} />
            <span>{t.resetTasbih}</span>
          </button>

          <button
            onClick={() => setHaptic(!haptic)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
          >
            {haptic ? <Volume2 size={14} className="text-emerald-400" /> : <VolumeX size={14} />}
            <span>Haptic</span>
          </button>
        </div>
      </div>
    </div>
  );
};
