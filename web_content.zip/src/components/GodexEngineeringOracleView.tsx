/**
 * GODEX Engineering Oracle & Software Evolution View
 * Professional, evidence-grounded engineering intelligence view.
 * Features:
 * - Multidimensional Project Health (Architecture, Code, Testing, Runtime, UI, Security, Maintainability, Agent Reliability)
 * - Trajectory & Evolution Forecast
 * - Top Architectural Risks with Blast-Radius Scoring
 * - Top Preventative Opportunities
 * - Stable Boundaries (What NOT to Change)
 * - Expandable Epistemic Evidence Chains
 * - Interactive Question Consulting
 */

import React, { useState, useMemo } from 'react';
import { 
  Activity, 
  ShieldCheck, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  HelpCircle, 
  ChevronDown, 
  ChevronRight, 
  Layers, 
  Code2, 
  Cpu, 
  Zap, 
  Lock, 
  Sparkles, 
  CheckCircle2, 
  Compass, 
  RefreshCw,
  Search,
  Eye,
  Sliders
} from 'lucide-react';
import { EngineeringOracle, EngineeringOracleResult } from '../intelligence/engineeringOracle';
import { SoftwareEvolutionEngine, EvolutionEngineReport, HealthDimension } from '../intelligence/softwareEvolutionEngine';
import { ProjectDigitalTwin, DigitalTwinSnapshot } from '../intelligence/digitalTwin';
import { RealityRecord } from '../intelligence/realityGapDetector';

interface GodexEngineeringOracleViewProps {
  files: Record<string, string>;
  runtimeErrors?: string[];
  realityRecords?: RealityRecord[];
  onSelectFile?: (path: string) => void;
  onAskOracle?: (question: string) => void;
}

export const GodexEngineeringOracleView: React.FC<GodexEngineeringOracleViewProps> = ({
  files,
  runtimeErrors = [],
  realityRecords = [],
  onSelectFile,
  onAskOracle
}) => {
  const [userQuery, setUserQuery] = useState('');
  const [selectedDimension, setSelectedDimension] = useState<HealthDimension | null>(null);
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({});
  const [customOracleResult, setCustomOracleResult] = useState<EngineeringOracleResult | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'risks' | 'evolution' | 'stable' | 'query'>('overview');

  // Compute digital twin and oracle report memoized
  const digitalTwin = useMemo(() => {
    return ProjectDigitalTwin.createSnapshot(files, runtimeErrors);
  }, [files, runtimeErrors]);

  const oracleReport = useMemo(() => {
    const oracle = EngineeringOracle.getInstance();
    return oracle.query('', files, digitalTwin, realityRecords);
  }, [files, digitalTwin, realityRecords]);

  const evolutionReport: EvolutionEngineReport | null = useMemo(() => {
    const engine = SoftwareEvolutionEngine.getInstance();
    return engine.analyzeEvolution(digitalTwin, realityRecords);
  }, [digitalTwin, realityRecords]);

  const toggleExpand = (id: string) => {
    setExpandedItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleRunQuery = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!userQuery.trim()) return;
    const oracle = EngineeringOracle.getInstance();
    const res = oracle.query(userQuery, files, digitalTwin, realityRecords);
    setCustomOracleResult(res);
    setActiveSubTab('query');
  };

  const currentResult = customOracleResult || oracleReport;
  const healthModel = evolutionReport?.healthModel;

  const getDimensionIcon = (dim: HealthDimension) => {
    switch (dim) {
      case 'ARCHITECTURE_HEALTH': return Layers;
      case 'CODE_HEALTH': return Code2;
      case 'TEST_HEALTH': return CheckCircle2;
      case 'RUNTIME_HEALTH': return Cpu;
      case 'UI_HEALTH': return Sparkles;
      case 'SECURITY_HEALTH': return Lock;
      case 'MAINTAINABILITY_HEALTH': return Sliders;
      case 'AGENT_RELIABILITY': return ShieldCheck;
      default: return Activity;
    }
  };

  const getTrendIcon = (trend: 'IMPROVING' | 'STABLE' | 'DECLINING') => {
    if (trend === 'IMPROVING') return <TrendingUp className="w-3.5 h-3.5 text-emerald-400" aria-label="Improving" />;
    if (trend === 'DECLINING') return <TrendingDown className="w-3.5 h-3.5 text-rose-400" aria-label="Declining" />;
    return <Minus className="w-3.5 h-3.5 text-neutral-400" aria-label="Stable" />;
  };

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-emerald-400 border-emerald-800/60 bg-emerald-950/40';
    if (score >= 70) return 'text-cyan-300 border-cyan-800/60 bg-cyan-950/40';
    if (score >= 50) return 'text-amber-300 border-amber-800/60 bg-amber-950/40';
    return 'text-rose-400 border-rose-800/60 bg-rose-950/40';
  };

  return (
    <div id="godex-engineering-oracle-view" className="flex-1 h-full flex flex-col bg-[#07090D] text-neutral-200 overflow-hidden font-sans select-text">
      {/* Top Oracle Header */}
      <div className="px-4 py-3 border-b border-[#151B27] bg-[#0A0D15] flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-indigo-950/70 border border-indigo-700/60 flex items-center justify-center text-indigo-300">
            <Activity className="w-4 h-4" aria-hidden="true" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xs font-bold text-white font-mono tracking-wide">Engineering Oracle & Software Evolution</h2>
              <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-indigo-950/70 text-indigo-300 border border-indigo-800/60 font-semibold">
                PREDICTIVE REASONING
              </span>
            </div>
            <p className="text-[10px] text-neutral-400 font-mono">
              Evidence-based architectural risk forecasting & trajectory modeling • Zero physical mutations
            </p>
          </div>
        </div>

        {/* Quick Query Form */}
        <form onSubmit={handleRunQuery} className="flex items-center gap-1.5 min-w-[280px] max-w-md w-full sm:w-auto">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-1/2 -translate-y-1/2" aria-hidden="true" />
            <input
              type="text"
              value={userQuery}
              onChange={e => setUserQuery(e.target.value)}
              placeholder="Ask Oracle: What's becoming risky?"
              className="w-full bg-[#0D121C] border border-[#1C2538] rounded-md pl-8 pr-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-indigo-500 font-mono"
            />
          </div>
          <button
            type="submit"
            className="px-3 py-1.5 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-mono font-medium transition-colors"
          >
            Consult
          </button>
        </form>
      </div>

      {/* Sub-Tabs Navigation */}
      <div className="px-4 py-2 border-b border-[#151B27] bg-[#080B10] flex items-center gap-1 shrink-0 font-mono text-[11px] overflow-x-auto no-scrollbar">
        {[
          { id: 'overview', label: 'Health Matrix' },
          { id: 'risks', label: `Top Risks (${currentResult.risks.length})` },
          { id: 'evolution', label: 'Evolution Trajectory' },
          { id: 'stable', label: `What NOT to Change (${currentResult.whatNotToChange.length})` },
          { id: 'query', label: 'Oracle Output' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`px-3 py-1 rounded-md transition-all whitespace-nowrap ${
              activeSubTab === tab.id
                ? 'bg-[#141C2B] text-cyan-300 font-semibold border border-indigo-500/40'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E131E] border border-transparent'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Main Viewport Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* SUBTAB 1: HEALTH MATRIX OVERVIEW */}
        {activeSubTab === 'overview' && healthModel && (
          <div className="space-y-6">
            {/* Top Trajectory Banner */}
            <div className="p-4 rounded-xl bg-[#0B0E17] border border-[#182234] flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="text-[10px] font-mono text-neutral-400 uppercase tracking-wider">Overall Project Integrity</div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl font-bold font-mono text-white">{healthModel.overallIntegrity}<span className="text-sm text-neutral-500">/100</span></span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-medium bg-emerald-950/60 text-emerald-300 border border-emerald-800/70">
                    {healthModel.trajectory}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-4 text-xs font-mono text-neutral-400">
                <div>Files: <strong className="text-white">{digitalTwin.totalFiles}</strong></div>
                <div>Lines: <strong className="text-white">{digitalTwin.totalLines}</strong></div>
                <div>Isolation: <strong className="text-emerald-400">VERIFIED</strong></div>
              </div>
            </div>

            {/* 8-Dimensional Health Grid */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-neutral-300 font-mono uppercase tracking-wider">Multidimensional Health Model</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {Object.values(healthModel.metrics).map((metric) => {
                  const Icon = getDimensionIcon(metric.dimension);
                  const isSelected = selectedDimension === metric.dimension;
                  return (
                    <div
                      key={metric.dimension}
                      onClick={() => setSelectedDimension(isSelected ? null : metric.dimension)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#121929] border-indigo-500/70 shadow-sm'
                          : 'bg-[#0A0D15] border-[#151C2B] hover:border-[#222E46]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4 text-indigo-400" aria-hidden="true" />
                          <span className="text-[11px] font-mono font-semibold text-neutral-200">
                            {metric.dimension.replace('_HEALTH', '')}
                          </span>
                        </div>
                        {getTrendIcon(metric.trend)}
                      </div>
                      <div className="flex items-baseline justify-between">
                        <span className={`text-lg font-bold font-mono px-2 py-0.5 rounded ${getScoreColor(metric.score)}`}>
                          {metric.score}
                        </span>
                        <span className="text-[10px] font-mono text-neutral-500">
                          {metric.confidence} CONF
                        </span>
                      </div>
                      <div className="mt-2 text-[10px] text-neutral-400 font-mono truncate">
                        {metric.evidence[0] || 'Nominal telemetry'}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Selected Dimension Deep Dive */}
            {selectedDimension && healthModel.metrics[selectedDimension] && (
              <div className="p-4 rounded-xl bg-[#0C101A] border border-indigo-500/30 space-y-3 font-mono text-xs">
                <div className="flex items-center justify-between border-b border-[#182133] pb-2">
                  <h4 className="font-bold text-cyan-300 flex items-center gap-2">
                    <Sliders className="w-4 h-4" />
                    <span>Evidence Dossier: {selectedDimension}</span>
                  </h4>
                  <button
                    onClick={() => setSelectedDimension(null)}
                    className="text-[10px] text-neutral-400 hover:text-white"
                  >
                    Close
                  </button>
                </div>
                <div className="space-y-1.5 text-neutral-300">
                  <div className="text-[11px] font-bold text-neutral-400 uppercase">Empirical Evidence:</div>
                  {healthModel.metrics[selectedDimension].evidence.map((ev, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <span className="text-emerald-400">•</span>
                      <span>{ev}</span>
                    </div>
                  ))}
                  {healthModel.metrics[selectedDimension].unknowns.length > 0 && (
                    <div className="mt-3 pt-2 border-t border-[#182133] text-neutral-400">
                      <div className="text-[11px] font-bold uppercase text-amber-400/80">Acknowledged Unknowns:</div>
                      {healthModel.metrics[selectedDimension].unknowns.map((un, i) => (
                        <div key={i} className="flex items-start gap-2 text-neutral-400">
                          <span className="text-amber-400">•</span>
                          <span>{un}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* SUBTAB 2: TOP RISKS & PREDICTIONS */}
        {activeSubTab === 'risks' && (
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-neutral-300 font-mono uppercase tracking-wider">
              Top Architectural Risks & Blast Radius Forecasts
            </h3>
            {currentResult.risks.length === 0 ? (
              <div className="p-6 text-center text-xs text-neutral-400 rounded-xl bg-[#090C13] border border-[#141A26]">
                No elevated risks detected. All dependency boundaries and interface couplings are operating stably.
              </div>
            ) : (
              <div className="space-y-3">
                {currentResult.risks.map((risk) => {
                  const isExpanded = !!expandedItems[risk.id];
                  return (
                    <div key={risk.id} className="p-4 rounded-xl bg-[#0A0D15] border border-[#161D2B] space-y-2.5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                              risk.severity === 'CRITICAL' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                              risk.severity === 'HIGH' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                              'bg-cyan-950 text-cyan-300 border border-cyan-800'
                            }`}>
                              {risk.severity}
                            </span>
                            <span className="text-xs font-bold text-white font-mono">{risk.title}</span>
                          </div>
                          <p className="text-xs text-neutral-300 font-sans">{risk.description}</p>
                        </div>
                        <button
                          onClick={() => toggleExpand(risk.id)}
                          className="text-[11px] font-mono text-indigo-400 hover:text-indigo-300 flex items-center gap-1 shrink-0"
                        >
                          <span>{isExpanded ? 'Hide Evidence' : 'Why'}</span>
                          {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                        </button>
                      </div>

                      {isExpanded && (
                        <div className="p-3 rounded-lg bg-[#0E131F] border border-[#1B2436] space-y-2 font-mono text-[11px]">
                          <div className="font-bold text-cyan-300">Supporting Structural Evidence:</div>
                          <ul className="space-y-1 text-neutral-300">
                            {risk.evidence.map((ev, i) => (
                              <li key={i} className="flex items-start gap-1.5">
                                <span className="text-indigo-400">↳</span>
                                <span>{ev}</span>
                              </li>
                            ))}
                          </ul>
                          {risk.affectedFiles.length > 0 && (
                            <div className="pt-2 border-t border-[#1C263A] flex flex-wrap items-center gap-1.5">
                              <span className="text-neutral-500">Target File(s):</span>
                              {risk.affectedFiles.map((af, i) => (
                                <button
                                  key={i}
                                  onClick={() => onSelectFile?.(af)}
                                  className="px-2 py-0.5 rounded bg-[#131A28] text-cyan-300 border border-[#202B3E] hover:border-indigo-500"
                                >
                                  {af}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* SUBTAB 3: EVOLUTION TRAJECTORY */}
        {activeSubTab === 'evolution' && evolutionReport && (
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-neutral-300 font-mono uppercase tracking-wider">
              Project Evolution Timeline & Snapshot History
            </h3>
            <div className="p-4 rounded-xl bg-[#0A0D15] border border-[#161D2B] space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center font-mono text-xs">
                <div className="p-3 rounded-lg bg-[#0E131E] border border-[#192234]">
                  <div className="text-[10px] text-neutral-500">SNAPSHOT COUNT</div>
                  <strong className="text-sm text-cyan-300">{evolutionReport.snapshotHistory.length}</strong>
                </div>
                <div className="p-3 rounded-lg bg-[#0E131E] border border-[#192234]">
                  <div className="text-[10px] text-neutral-500">DEPENDENCY EDGES</div>
                  <strong className="text-sm text-indigo-300">{evolutionReport.latestSnapshot.dependencyCount}</strong>
                </div>
                <div className="p-3 rounded-lg bg-[#0E131E] border border-[#192234]">
                  <div className="text-[10px] text-neutral-500">AVG COMPLEXITY</div>
                  <strong className="text-sm text-emerald-300">{evolutionReport.latestSnapshot.averageComplexity} lines/file</strong>
                </div>
                <div className="p-3 rounded-lg bg-[#0E131E] border border-[#192234]">
                  <div className="text-[10px] text-neutral-500">ISOLATION STATUS</div>
                  <strong className="text-sm text-emerald-400">ISOLATED</strong>
                </div>
              </div>

              {/* UI Entropy Analysis */}
              <div className="space-y-2 pt-2 border-t border-[#182133]">
                <div className="text-xs font-bold font-mono text-neutral-300">UI Evolution & Design Token Consistency</div>
                <div className="p-3 rounded-lg bg-[#0E131E] border border-[#192234] flex items-center justify-between text-xs font-mono">
                  <span>Design Token Alignment:</span>
                  <strong className="text-emerald-400">{evolutionReport.uiEvolutionForecast.designTokenConsistencyScore}%</strong>
                </div>
                {evolutionReport.uiEvolutionForecast.entropyWarnings.map((warn, i) => (
                  <div key={i} className="p-2 rounded bg-amber-950/40 text-amber-300 border border-amber-800/50 text-xs font-mono flex items-center gap-2">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{warn}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 4: WHAT NOT TO CHANGE */}
        {activeSubTab === 'stable' && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h3 className="text-xs font-bold text-neutral-300 font-mono uppercase tracking-wider">
                Stable Architectural Boundaries (What NOT to Change)
              </h3>
              <p className="text-xs text-neutral-400">
                These modules exhibit clean cohesive interfaces, zero recurring errors, and low internal complexity. Modifying them introduces avoidable regression risk.
              </p>
            </div>

            {currentResult.whatNotToChange.length === 0 ? (
              <div className="p-6 text-center text-xs text-neutral-400 rounded-xl bg-[#090C13] border border-[#141A26]">
                All modules currently undergo active coupling.
              </div>
            ) : (
              <div className="space-y-2.5">
                {currentResult.whatNotToChange.map((sm, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl bg-[#0A0D15] border border-emerald-900/30 flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span className="text-xs font-bold font-mono text-white">{sm.module}</span>
                        <span className="text-[10px] font-mono px-2 py-0.2 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-800/60">
                          {sm.stabilityScore}/100 STABILITY
                        </span>
                      </div>
                      <p className="text-xs text-neutral-300 font-sans">{sm.reason}</p>
                      <div className="text-[10px] font-mono text-neutral-500">
                        {sm.evidence.join(' • ')}
                      </div>
                    </div>
                    <button
                      onClick={() => onSelectFile?.(sm.module)}
                      className="px-2.5 py-1 rounded bg-[#101622] hover:bg-[#162030] text-cyan-300 text-xs font-mono border border-[#1D273B]"
                    >
                      View
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* SUBTAB 5: ORACLE CONSULTATION OUTPUT */}
        {activeSubTab === 'query' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#151B27]">
              <h3 className="text-xs font-bold text-white font-mono flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <span>Consultation Response: {currentResult.question || 'Holistic Analysis'}</span>
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                {currentResult.confidence} CONFIDENCE
              </span>
            </div>

            {/* Markdown/Formatted Output */}
            <div className="p-4 rounded-xl bg-[#0A0D15] border border-[#171F2E] font-mono text-xs leading-relaxed whitespace-pre-wrap text-neutral-200">
              {currentResult.formattedAnswer || 'No query generated yet. Ask the Oracle a question above.'}
            </div>

            {/* Expandable Evidence Chain */}
            <div className="space-y-2">
              <div className="text-xs font-bold font-mono text-neutral-400 uppercase">Epistemic Evidence Classification</div>
              <div className="space-y-1.5 font-mono text-[11px]">
                {currentResult.observations.map((obs, i) => (
                  <div key={i} className="p-2 rounded bg-[#0D121C] border border-[#161D2C] flex items-center justify-between">
                    <span className="text-neutral-300">{obs.fact}</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#141B28] text-cyan-400 border border-[#1F2A3D]">
                      {obs.type}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
