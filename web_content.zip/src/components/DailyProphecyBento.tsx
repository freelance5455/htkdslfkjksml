import React, { useState, useEffect } from 'react';
import { Sparkles, RefreshCw, Bookmark, Share2, Check, Flame, Quote } from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';

interface ProphecyResponse {
  prophecyTitle: string;
  propheticWord: string;
  scriptureReference: string;
  spiritualFocus: string;
  declaration: string;
  dateGenerated?: string;
}

export const DailyProphecyBento: React.FC = () => {
  const [prophecy, setProphecy] = useState<ProphecyResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [saved, setSaved] = useState<boolean>(false);
  const [focusTopic, setFocusTopic] = useState<string>('Breakthrough & Divine Peace');

  const fetchProphecy = async (topic = focusTopic) => {
    setLoading(true);
    setCopied(false);
    try {
      const user = offlineCache.getProfile();
      const res = await fetch('/api/prophecy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userName: user.name || 'Anointed Believer',
          focusTopic: topic,
        }),
      });
      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }
      const data = await res.json();
      if (data && data.prophecyTitle) {
        setProphecy(data);
      } else {
        throw new Error('Invalid prophecy data');
      }
    } catch (e) {
      console.log('Using fallback prophetic word due to network/quota limit');
      setProphecy({
        prophecyTitle: "Prophetic Word of Unshakeable Favor",
        propheticWord: "Stand firm in worship today. The Lord is establishing your footsteps and filling your heart with heavenly stillness.",
        scriptureReference: "Isaiah 40:31 - 'Those who hope in the Lord will renew their strength.'",
        spiritualFocus: topic,
        declaration: "I declare that I am walking in divine acceleration and supernatural joy!",
        dateGenerated: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProphecy();
  }, []);

  const handleCopyDeclaration = () => {
    if (!prophecy) return;
    navigator.clipboard.writeText(prophecy.declaration);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSaveToProfile = () => {
    setSaved(!saved);
  };

  return (
    <div className="relative rounded-3xl overflow-hidden border border-amber-500/30 bg-gradient-to-br from-slate-900/90 via-slate-950 to-amber-950/20 p-6 sm:p-8 shadow-2xl backdrop-blur-xl group">
      {/* Background Divine Radial Glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-amber-500/20 transition-all duration-700" />

      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-amber-500/15 relative z-10">
        <div className="flex items-center space-x-2">
          <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300">
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400">
              PROPHET JUHNKRIX DAILY ORACLE
            </span>
            <h3 className="text-base sm:text-lg font-extrabold font-serif text-amber-100">
              Daily Prophetic Affirmation
            </h3>
          </div>
        </div>

        {/* Focus Topic Selector */}
        <div className="flex items-center space-x-2">
          <select
            value={focusTopic}
            onChange={(e) => {
              setFocusTopic(e.target.value);
              fetchProphecy(e.target.value);
            }}
            className="bg-slate-900 text-amber-200 border border-amber-500/30 rounded-xl text-xs px-3 py-1.5 focus:outline-none focus:border-amber-400"
          >
            <option value="Breakthrough & Divine Peace">Breakthrough & Peace</option>
            <option value="Supernatural Healing & Restoration">Healing & Health</option>
            <option value="Financial Grace & Abundance">Financial Favor</option>
            <option value="Spiritual Authority & Elevation">Spiritual Authority</option>
          </select>

          <button
            onClick={() => fetchProphecy()}
            disabled={loading}
            className="p-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 transition-colors disabled:opacity-50"
            title="Receive New Prophetic Word"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Content Stage */}
      {loading ? (
        <div className="py-12 flex flex-col items-center justify-center space-y-3 relative z-10 text-center">
          <div className="w-10 h-10 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-semibold text-amber-300 animate-pulse">
            Receiving Prophetic Word from Prophet JUHNKRIX SYNVAGORD...
          </p>
        </div>
      ) : prophecy ? (
        <div className="pt-6 space-y-4 relative z-10">
          <div>
            <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 mb-2">
              {prophecy.spiritualFocus} • {prophecy.dateGenerated || 'Today'}
            </span>
            <h4 className="text-lg sm:text-xl font-serif font-bold text-amber-200 leading-snug">
              {prophecy.prophecyTitle}
            </h4>
          </div>

          <div className="relative pl-4 border-l-2 border-amber-500/40 py-1">
            <Quote className="absolute -top-1 left-1.5 w-4 h-4 text-amber-500/20 pointer-events-none" />
            <p className="text-sm text-slate-200 leading-relaxed font-sans">
              {prophecy.propheticWord}
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950/70 border border-amber-500/15 text-xs text-amber-300/90 font-mono flex items-center justify-between">
            <span>{prophecy.scriptureReference}</span>
            <Flame className="w-4 h-4 text-amber-400 flex-shrink-0" />
          </div>

          {/* Daily Spoken Declaration Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-amber-500/15 border border-amber-400/30 flex items-center justify-between gap-3">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">
                Speak This Decree Out Loud
              </span>
              <p className="text-xs sm:text-sm font-semibold font-serif text-amber-100">
                &ldquo;{prophecy.declaration}&rdquo;
              </p>
            </div>

            <div className="flex items-center space-x-2 flex-shrink-0">
              <button
                onClick={handleCopyDeclaration}
                className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1 shadow-md shadow-amber-500/20 transition-all active:scale-95"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Share2 className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Speak'}</span>
              </button>

              <button
                onClick={handleSaveToProfile}
                className={`p-2 rounded-xl border transition-colors ${
                  saved
                    ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                    : 'bg-slate-900 text-slate-400 border-amber-500/20 hover:text-amber-200'
                }`}
                title="Save Word"
              >
                <Bookmark className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
