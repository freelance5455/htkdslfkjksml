"use client";

import { useMemo, useState } from "react";
import type { Attraction } from "@/db/schema";
import { CATEGORIES, COUNTRIES } from "@/lib/data";
import { useLang } from "@/lib/i18n";
import AttractionCard from "./AttractionCard";

const HERO =
  "https://images.pexels.com/photos/5976924/pexels-photo-5976924.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600";

export default function HomeClient({ attractions }: { attractions: Attraction[] }) {
  const { lang, t } = useLang();
  const [q, setQ] = useState("");
  const [country, setCountry] = useState("");
  const [category, setCategory] = useState("");
  const [sort, setSort] = useState<"popular" | "price" | "rating">("popular");

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    let res = attractions.filter((a) => {
      if (country && a.countryCode !== country) return false;
      if (category && a.category !== category) return false;
      if (!needle) return true;
      const hay = [a.nameEn, a.nameAr, a.cityEn, a.cityAr, COUNTRIES[a.countryCode]?.en, COUNTRIES[a.countryCode]?.ar]
        .join(" ")
        .toLowerCase();
      return hay.includes(needle);
    });
    if (sort === "price") res = [...res].sort((a, b) => a.price - b.price);
    if (sort === "rating") res = [...res].sort((a, b) => b.rating - a.rating);
    return res;
  }, [attractions, q, country, category, sort]);

  const chip = (active: boolean) =>
    `shrink-0 rounded-full px-4 py-2 text-sm font-medium transition ${
      active ? "bg-indigo-600 text-white shadow" : "bg-white text-slate-700 ring-1 ring-slate-200 hover:bg-slate-50"
    }`;

  return (
    <>
      <section className="relative isolate overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={HERO} alt="" className="absolute inset-0 -z-10 h-full w-full object-cover" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-indigo-950/80 via-indigo-900/60 to-slate-100" />
        <div className="mx-auto max-w-4xl px-4 pb-24 pt-16 text-center text-white sm:pt-24">
          <h1 className="text-3xl font-extrabold leading-tight drop-shadow sm:text-5xl">{t("heroTitle")}</h1>
          <p className="mx-auto mt-4 max-w-2xl text-base text-indigo-100 sm:text-lg">{t("heroSub")}</p>
          <div className="mx-auto mt-8 flex max-w-2xl flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <span className="pointer-events-none absolute start-4 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t("searchPh")}
                className="w-full rounded-2xl border-0 bg-white py-4 pe-4 ps-12 text-slate-900 shadow-xl outline-none ring-2 ring-transparent focus:ring-fuchsia-400"
              />
            </div>
            <button
              onClick={() => window.dispatchEvent(new CustomEvent("assistant:open", { detail: { listen: true } }))}
              className="flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-fuchsia-500 to-indigo-500 px-6 py-4 font-bold text-white shadow-xl transition hover:scale-[1.03]"
            >
              🎙️ {t("askAi")}
            </button>
          </div>
        </div>
      </section>

      <section className="mx-auto -mt-12 max-w-6xl px-4 pb-24">
        <div className="space-y-3 rounded-3xl bg-white/70 p-4 shadow-lg ring-1 ring-slate-200 backdrop-blur">
          <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
            <button className={chip(!country)} onClick={() => setCountry("")}>
              🌍 {t("allCountries")}
            </button>
            {Object.entries(COUNTRIES).map(([code, c]) => (
              <button key={code} className={chip(country === code)} onClick={() => setCountry(country === code ? "" : code)}>
                {c.flag} {c[lang]}
              </button>
            ))}
          </div>
          <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
            <button className={chip(!category)} onClick={() => setCategory("")}>
              ✨ {t("allCategories")}
            </button>
            {Object.entries(CATEGORIES).map(([code, c]) => (
              <button key={code} className={chip(category === code)} onClick={() => setCategory(category === code ? "" : code)}>
                {c.icon} {c[lang]}
              </button>
            ))}
          </div>
          <div className="flex items-center justify-between text-sm text-slate-600">
            <span>
              <b className="text-slate-900">{list.length}</b> {t("results")}
            </span>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as typeof sort)}
              className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm"
            >
              <option value="popular">{t("sortPopular")}</option>
              <option value="price">{t("sortPrice")}</option>
              <option value="rating">{t("sortRating")}</option>
            </select>
          </div>
        </div>

        {list.length === 0 ? (
          <p className="py-20 text-center text-slate-500">{t("noResults")}</p>
        ) : (
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((a) => (
              <AttractionCard key={a.id} a={a} />
            ))}
          </div>
        )}
        <p className="mt-12 text-center text-xs text-slate-400">{t("footer")}</p>
      </section>
    </>
  );
}
