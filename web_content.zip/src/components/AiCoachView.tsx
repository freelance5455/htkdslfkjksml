import React, { useState } from 'react';
import { TierLevel } from '../types';
import { Bot, Send, Clock } from 'lucide-react';

interface AiCoachViewProps {
  currentTier: TierLevel;
  onOpenPaywall: (tier?: TierLevel) => void;
}

export const AiCoachView: React.FC<AiCoachViewProps> = ({
  currentTier,
  onOpenPaywall,
}) => {
  const isLevel4Unlocked = currentTier >= 4;

  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      text: 'أهلاً بك! أنا موجه Cal AI الذكي لتحسين نتائجك وتعديل خطتك الغذائية في الوقت الفعلي. كيف يمكنني مساعدتك اليوم؟',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // Fasting Timer State
  const fastingHours = 14;
  const fastingMinutes = 25;

  const handleSend = () => {
    if (!inputText.trim()) return;

    const userMsg = inputText.trim();
    setMessages((prev) => [...prev, { role: 'user', text: userMsg }]);
    setInputText('');
    setIsTyping(true);

    setTimeout(() => {
      let reply = 'بناءً على أهدافك والوجبات التي مسحتها اليوم، أوصيك بالتركيز على شرب الماء الآن والحفاظ على عجز معتدل قدره 300 سعرة حرارية لضمان الحفاظ على الكتلة العضلية.';

      if (userMsg.includes('بروتين') || userMsg.includes('عضل')) {
        reply = 'ممتاز! للحصول على أقصى تخليق بروتيني، وزع كمية البروتين على 3 إلى 4 وجبات متباعدة بـ 3-4 ساعات، بمعدل 30-40غ بروتين في كل وجبة.';
      } else if (userMsg.includes('جوع') || userMsg.includes('سناك')) {
        reply = 'إذا شعرت بالجوع، جرب سناك منخفض السعرات عالي الحجم مثل الخيار المقطع مع ملح وليمون، أو حفنة لوز 20غ مع شاي أخضر دافئ.';
      } else if (userMsg.includes('صيام')) {
        reply = 'أنت حالياً في نافذة الصيام (14 ساعة و 25 دقيقة). في هذه المرحلة يبدأ جسمك بتفعيل الالتهام الذاتي (Autophagy) وحرق الدهون بكفاءة.';
      }

      setMessages((prev) => [...prev, { role: 'assistant', text: reply }]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      <div>
        <h1 className="text-2xl font-black text-white">موجه الذكاء الاصطناعي والصيام (AI Coach)</h1>
        <p className="text-sm text-slate-400 mt-1">
          إرشادات مخصصة وضبط فوري لخطة التغذية والصيام المتقطع
        </p>
      </div>

      {/* Level 4 Gating Banner */}
      {!isLevel4Unlocked && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-3">
          <div className="w-12 h-12 mx-auto rounded-xl bg-violet-500/10 border border-violet-500/30 flex items-center justify-center text-violet-400 text-xl">
            💎
          </div>
          <h2 className="text-lg font-bold text-white">موجه الذكاء الاصطناعي متاح في المستوى 4 (Elite Master)</h2>
          <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
            يتطلب المستوى 4: <strong className="text-violet-400">10 دعوات واشتراكاً نشطاً</strong> (منك أو من 4 مدعوين). يمكنك تجربة الفتح الفوري في لوحة المستويات.
          </p>
          <button
            onClick={() => onOpenPaywall(4)}
            className="px-5 py-2.5 bg-violet-600 hover:bg-violet-500 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            عرض متطلبات فتح المستوى 4
          </button>
        </div>
      )}

      {/* Main Grid */}
      <div className={`grid grid-cols-1 lg:grid-cols-3 gap-6 ${!isLevel4Unlocked ? 'opacity-40 pointer-events-none filter blur-[1px]' : ''}`}>
        {/* Left: Chat with AI Coach */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col h-[520px]">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">كوتش Cal AI المخصص</h3>
                <span className="text-[10px] text-emerald-400 font-semibold">متصل ومتابع لوجباتك</span>
              </div>
            </div>
            <span className="text-xs px-2 py-0.5 rounded bg-violet-500/10 text-violet-400 font-bold border border-violet-500/20">
              المستوى 4
            </span>
          </div>

          {/* Messages body */}
          <div className="flex-1 overflow-y-auto py-4 space-y-3">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex ${m.role === 'user' ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[80%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                    m.role === 'user'
                      ? 'bg-emerald-500 text-slate-950 font-medium rounded-br-xs'
                      : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-bl-xs'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="text-right text-xs text-slate-500 italic">
                كوتش Cal AI يفكر ويكتب...
              </div>
            )}
          </div>

          {/* Quick prompt pills */}
          <div className="flex gap-2 overflow-x-auto py-2 border-t border-slate-800/80">
            {['كيف أزيد بروتيني اليوم؟', 'هل وجبة الغداء متوازنة؟', 'أشعر بالجوع في الصيام'].map((q, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  setInputText(q);
                }}
                className="whitespace-nowrap shrink-0 px-2.5 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-[11px] text-slate-300 transition-colors"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input row */}
          <div className="pt-2 flex gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="اسأل الكوتش عن خطتك، وجباتك، أو السعرات..."
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
            <button
              onClick={handleSend}
              className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-bold flex items-center justify-center transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right: Smart Fasting Timer synced with meal scans */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-bold text-white">مؤقت الصيام المتقطع</h3>
            </div>
            <span className="text-xs text-emerald-400 font-bold">16:8 Protocol</span>
          </div>

          {/* Circular fasting clock */}
          <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800 text-center space-y-3">
            <div className="text-xs text-slate-400">مضى من فترة الصيام:</div>
            <div className="text-3xl font-black text-white tabular-nums">
              {fastingHours}:{fastingMinutes < 10 ? `0${fastingMinutes}` : fastingMinutes}
              <span className="text-xs text-slate-500 font-normal mr-1">ساعة</span>
            </div>
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-indigo-500 rounded-full"
                style={{ width: `${(14.4 / 16) * 100}%` }}
              />
            </div>
            <div className="text-[11px] text-indigo-300">
              المتبقي لفتح نافذة الأكل: 1 ساعة و 35 دقيقة
            </div>
          </div>

          <div className="space-y-2 text-xs text-slate-300">
            <div className="font-bold text-white">المزامنة التلقائية مع الوجبات:</div>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              يقوم Cal AI تلقائياً ببدء مؤقت الصيام عند التقاطك لآخر وجبة عشاء، ويحدد الوقت المثالي لوجبة الإفطار القادمة لمنع تباطؤ الأيض.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
