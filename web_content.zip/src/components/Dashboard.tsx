import React, { useMemo } from 'react';
import {
  ArrowRight,
  BarChart3,
  Boxes,
  DatabaseBackup,
  Factory,
  FileClock,
  Home,
  Settings,
  Sliders,
  Trash2,
  Wallet,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  computeDashboardMetric,
  formatCurrency,
  formatDate,
  formatNumber,
} from '../utils/calculations';
import type { NavSection } from '../types';

interface ActivityRow {
  id: string;
  date: string;
  sortKey: string;
  moduleLabel: string;
  description: string;
  detail: string;
  targetSection: NavSection;
  targetTab: string;
  recordId: string;
}

export const Dashboard: React.FC = () => {
  const { state, navigate, tr, themeTokens } = useApp();
  const isMobile = state.settings.viewMode === 'mobile';
  const cur = state.settings.currencyLabel || 'PKR';
  const dateFmt = state.settings.dateFormat;

  const recentActivity = useMemo<ActivityRow[]>(() => {
    const rows: ActivityRow[] = [];

    for (const p of state.purchases) {
      rows.push({
        id: `act_p_${p.id}`,
        date: p.date,
        sortKey: p.updatedAt || p.createdAt || p.date,
        moduleLabel: 'Home · Purchase',
        description: `${p.supplier || 'Atta / Purchase'} (${formatNumber(p.quantityMaund)} Maund)`,
        detail: formatCurrency(p.totalAmount, cur),
        targetSection: 'home',
        targetTab: 'purchases',
        recordId: p.id,
      });
    }

    for (const e of state.expenses) {
      rows.push({
        id: `act_e_${e.id}`,
        date: e.date,
        sortKey: e.updatedAt || e.createdAt || e.date,
        moduleLabel: 'Home · Expense',
        description: `${e.category} — ${e.description}`,
        detail: formatCurrency(e.amount, cur),
        targetSection: 'home',
        targetTab: 'expenses',
        recordId: e.id,
      });
    }

    for (const l of state.leaves) {
      const typeLabel =
        l.type === 'CL'
          ? 'Casual Leave'
          : l.type === 'SL'
            ? 'Sick Leave'
            : l.type === 'CPL_DUE'
              ? 'CPL Due'
              : 'CPL Used';
      rows.push({
        id: `act_l_${l.id}`,
        date: l.date,
        sortKey: l.updatedAt || l.createdAt || l.date,
        moduleLabel: 'Factory · Leave',
        description: `${typeLabel}${l.reason ? ` — ${l.reason}` : ''}`,
        detail: formatNumber(l.days),
        targetSection: 'factory',
        targetTab: 'leave',
        recordId: l.id,
      });
    }

    for (const task of state.tasks) {
      rows.push({
        id: `act_t_${task.id}`,
        date: task.dueDate || task.createdDate,
        sortKey: task.updatedAt || task.createdAt || task.createdDate,
        moduleLabel: 'Factory · Task',
        description: task.title,
        detail: `${task.status} · ${task.priority}`,
        targetSection: 'factory',
        targetTab: 'tasks',
        recordId: task.id,
      });
    }

    for (const tx of state.loanTransactions) {
      rows.push({
        id: `act_lt_${tx.id}`,
        date: tx.transactionDate,
        sortKey: tx.updatedAt || tx.createdAt || tx.transactionDate,
        moduleLabel: 'Personal · Loan',
        description: `${tx.personName} (${tx.type === 'received' ? 'Received' : 'Repaid'})`,
        detail: formatCurrency(tx.amount, cur),
        targetSection: 'personal',
        targetTab: 'loan',
        recordId: tx.id,
      });
    }

    for (const tx of state.committeeTransactions) {
      rows.push({
        id: `act_ct_${tx.id}`,
        date: tx.date,
        sortKey: tx.updatedAt || tx.createdAt || tx.date,
        moduleLabel: 'Personal · Committee',
        description: `${tx.committeeTitle} (${tx.type})`,
        detail: formatCurrency(tx.amount, cur),
        targetSection: 'personal',
        targetTab: 'committee',
        recordId: tx.id,
      });
    }

    for (const cr of state.customRecords) {
      const mod = state.customModules.find((m) => m.id === cr.moduleId);
      if (!mod || mod.archived) continue;
      const firstVal = Object.values(cr.values).find((v) => v !== '' && v !== null && v !== undefined);
      rows.push({
        id: `act_cr_${cr.id}`,
        date: cr.createdAt.slice(0, 10),
        sortKey: cr.updatedAt || cr.createdAt,
        moduleLabel: mod.name,
        description: String(firstVal ?? 'Custom Record'),
        detail: 'Record',
        targetSection: `custom:${mod.id}`,
        targetTab: '',
        recordId: cr.id,
      });
    }

    return rows.sort((a, b) => b.sortKey.localeCompare(a.sortKey)).slice(0, 10);
  }, [state, cur]);

  const moduleCards = useMemo(() => {
    const vis = state.settings.builtInModuleVisibility;
    const base: { id: NavSection; title: string; subtitle: string; icon: React.ReactNode; visible: boolean }[] = [
      {
        id: 'home',
        title: tr('nav_home'),
        subtitle: `${tr('home_purchases')} · ${tr('home_expenses')}`,
        icon: <Home className="h-5 w-5" />,
        visible: vis.home,
      },
      {
        id: 'factory',
        title: tr('nav_factory'),
        subtitle: `${tr('leave_management')} · ${tr('office_tasks')}`,
        icon: <Factory className="h-5 w-5" />,
        visible: vis.factory,
      },
      {
        id: 'personal',
        title: tr('nav_personal'),
        subtitle: `${tr('loan_manager')} · ${tr('committee_manager')}`,
        icon: <Wallet className="h-5 w-5" />,
        visible: vis.personal,
      },
      {
        id: 'reports',
        title: tr('nav_reports'),
        subtitle: 'Ledgers · CSV · Print',
        icon: <BarChart3 className="h-5 w-5" />,
        visible: true,
      },
      {
        id: 'settings',
        title: tr('nav_settings'),
        subtitle: 'Theme · Language · Rules',
        icon: <Settings className="h-5 w-5" />,
        visible: true,
      },
      {
        id: 'dynamic_settings',
        title: tr('nav_dynamic_settings'),
        subtitle: 'Modules · Fields · Formulas',
        icon: <Sliders className="h-5 w-5" />,
        visible: true,
      },
      {
        id: 'backup',
        title: tr('nav_backup'),
        subtitle: 'JSON Export & Restore',
        icon: <DatabaseBackup className="h-5 w-5" />,
        visible: true,
      },
      {
        id: 'recycle_bin',
        title: tr('nav_recycle_bin'),
        subtitle: `${state.recycleBin.length} deleted`,
        icon: <Trash2 className="h-5 w-5" />,
        visible: true,
      },
      {
        id: 'audit_log',
        title: tr('nav_audit_log'),
        subtitle: `${state.auditLog.length} events`,
        icon: <FileClock className="h-5 w-5" />,
        visible: true,
      },
    ];

    const custom = state.customModules
      .filter((m) => m.visible && !m.archived)
      .sort((a, b) => a.order - b.order)
      .map((m) => ({
        id: `custom:${m.id}` as NavSection,
        title: m.name,
        subtitle: m.description || 'Custom Module',
        icon: <Boxes className="h-5 w-5" />,
        visible: true,
      }));

    return [...base.filter((b) => b.visible), ...custom];
  }, [state.settings.builtInModuleVisibility, state.customModules, state.recycleBin.length, state.auditLog.length, tr]);

  const quickOverviewBlock = (
    <section aria-labelledby="quick-overview-heading" className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5">
      <div className="flex items-center justify-between gap-2 mb-3">
        <h2 id="quick-overview-heading" className="text-sm font-semibold text-slate-900">
          {tr('quick_overview')}
        </h2>
        <button
          type="button"
          onClick={() => navigate('settings')}
          className="text-xs font-medium text-emerald-700 hover:underline whitespace-nowrap"
        >
          {tr('configure_cards')}
        </button>
      </div>
      <div className={`grid gap-2.5 ${isMobile ? 'grid-cols-2' : 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-5'}`}>
        {state.settings.quickOverviewItems
          .filter((item) => item.visible)
          .map((item) => {
            const metric = item.metricKey ? computeDashboardMetric(state, item.metricKey) : null;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => navigate(item.targetSection, item.targetTab || '')}
                className="text-start rounded-lg border border-slate-200 bg-slate-50/70 p-3 hover:border-emerald-400 hover:bg-emerald-50/40 transition-colors"
              >
                <div className="text-xs font-medium text-slate-600 truncate">{item.label}</div>
                {metric && (
                  <div className="mt-1 text-sm font-bold text-slate-900 tabular-nums truncate">
                    {metric.formattedValue}
                  </div>
                )}
                {metric?.subtext && (
                  <div className="mt-0.5 text-[11px] text-slate-500 truncate">{metric.subtext}</div>
                )}
              </button>
            );
          })}
      </div>
    </section>
  );

  const summaryCardsBlock = (
    <section aria-label="Summary metrics" className={`grid gap-3.5 ${isMobile ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-4'}`}>
      {state.settings.dashboardCards.slice(0, 4).map((card) => {
        const primary = computeDashboardMetric(state, card.primaryMetric);
        const secondary = card.secondaryMetric
          ? computeDashboardMetric(state, card.secondaryMetric)
          : null;
        return (
          <div
            key={card.id}
            className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col justify-between"
          >
            <div>
              <div className="text-xs font-medium text-slate-500">{card.title || primary.label}</div>
              <div className="mt-1.5 text-2xl font-bold text-slate-900 tabular-nums tracking-tight">
                {primary.formattedValue}
              </div>
              {primary.subtext && (
                <div className="mt-1 text-xs text-slate-500 tabular-nums">{primary.subtext}</div>
              )}
            </div>

            {secondary && (
              <div className="mt-3 pt-3 border-t border-slate-100 flex items-baseline justify-between gap-2">
                <span className="text-xs text-slate-500 truncate">{secondary.label}</span>
                <span className="text-sm font-semibold text-emerald-700 tabular-nums shrink-0">
                  {secondary.formattedValue}
                </span>
              </div>
            )}
          </div>
        );
      })}
    </section>
  );

  const moduleCardsBlock = (
    <section aria-labelledby="modules-heading">
      <h2 id="modules-heading" className="text-sm font-semibold text-slate-900 mb-3">
        {tr('modules')}
      </h2>
      <div
        className={`grid gap-2.5 ${
          isMobile
            ? 'grid-cols-2 min-[350px]:grid-cols-3'
            : 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5'
        }`}
      >
        {moduleCards.map((mod) => (
          <button
            key={mod.id}
            type="button"
            onClick={() => navigate(mod.id)}
            className={`group text-start rounded-xl border border-slate-200 bg-white transition-colors hover:border-emerald-500 hover:bg-emerald-50/30 focus-visible:outline-2 focus-visible:outline-emerald-600 ${
              isMobile ? 'p-3 flex flex-col items-center text-center gap-2' : 'p-4 flex flex-col gap-2'
            }`}
          >
            <div
              className={`flex h-9 w-9 items-center justify-center rounded-lg text-white ${themeTokens.sidebarBg} group-hover:bg-emerald-600 transition-colors`}
            >
              {mod.icon}
            </div>
            <div className="min-w-0 w-full">
              <div className={`font-semibold text-slate-900 truncate ${isMobile ? 'text-xs' : 'text-sm'}`}>
                {mod.title}
              </div>
              {!isMobile && (
                <div className="text-xs text-slate-500 truncate mt-0.5">{mod.subtitle}</div>
              )}
            </div>
          </button>
        ))}
      </div>
    </section>
  );

  const recentActivityBlock = (
    <section aria-labelledby="recent-activity-heading" className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="px-4 sm:px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
        <h2 id="recent-activity-heading" className="text-sm font-semibold text-slate-900">
          {tr('recent_activity')}
        </h2>
        <button
          type="button"
          onClick={() => navigate('reports')}
          className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 hover:underline whitespace-nowrap"
        >
          <span>{tr('nav_reports')}</span>
          <ArrowRight className="h-3.5 w-3.5" />
        </button>
      </div>

      {recentActivity.length === 0 ? (
        <div className="px-5 py-10 text-center text-sm text-slate-500">
          {tr('no_recent_activity')}
        </div>
      ) : (
        <div className="divide-y divide-slate-100">
          {recentActivity.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => navigate(item.targetSection, item.targetTab, item.recordId)}
              className="w-full text-start px-4 sm:px-5 py-3 hover:bg-slate-50 transition-colors flex items-center justify-between gap-3"
            >
              <div className="min-w-0">
                <div className="text-sm font-medium text-slate-900 truncate">{item.description}</div>
                <div className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                  <span>{formatDate(item.date, dateFmt)}</span>
                  <span aria-hidden="true">·</span>
                  <span className="truncate">{item.moduleLabel}</span>
                </div>
              </div>
              <div className="text-sm font-semibold text-slate-800 tabular-nums whitespace-nowrap shrink-0">
                {item.detail}
              </div>
            </button>
          ))}
        </div>
      )}
    </section>
  );

  return (
    <div className="space-y-6">
      {isMobile ? (
        <>
          {quickOverviewBlock}
          {moduleCardsBlock}
          {summaryCardsBlock}
          {recentActivityBlock}
        </>
      ) : (
        <>
          {summaryCardsBlock}
          {quickOverviewBlock}
          {moduleCardsBlock}
          {recentActivityBlock}
        </>
      )}
    </div>
  );
};
