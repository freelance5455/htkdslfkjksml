import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Clock, 
  HelpCircle, 
  Award, 
  Calendar, 
  Plus, 
  CheckCircle2, 
  AlertCircle, 
  ChevronRight, 
  Sparkles,
  BookOpen,
  UserCheck,
  ShieldCheck,
  Zap,
  RefreshCw,
  Target,
  CheckSquare,
  Flame,
  Bookmark,
  RotateCcw,
  BarChart2,
  Lock,
  Edit3
} from 'lucide-react';
import { Subject, StudyPlanItem, ProgressReport, ExamType, UserProfile, DailyQuestionSet } from '../types';
import { INITIAL_STUDY_PLAN, SUBJECT_METADATA, EXAM_PREPS } from '../presets';
import { fetchOrGenerateDailyQuestionSet, calculateSubjectDistribution } from '../lib/dailyQuestionEngine';
import SubjectSelectionModal from './SubjectSelectionModal';
import TodaysQuestionsModal from './TodaysQuestionsModal';
import DailyTargetCard from './DailyTargetCard';
import WeeklyQuizCard from './WeeklyQuizCard';
import WeeklyQuizModal from './WeeklyQuizModal';
import WeeklyQuizLeaderboardModal from './WeeklyQuizLeaderboardModal';
import AdminWeeklyQuizModal from './AdminWeeklyQuizModal';
import QuizNotificationAlertBanner from './QuizNotificationAlertBanner';
import { WeeklyQuiz, WeeklyQuizSubmission } from '../types';

interface DashboardProps {
  language: string;
  progress: ProgressReport;
  studyPlan: StudyPlanItem[];
  setStudyPlan: React.Dispatch<React.SetStateAction<StudyPlanItem[]>>;
  examPrep: ExamType;
  setExamPrep: (exam: ExamType) => void;
  onNavigate: (tab: string) => void;
  onGeneratePlan: (subjects: string[], hours: number) => Promise<void>;
  isGeneratingPlan: boolean;
  userProfile?: UserProfile;
  setUserProfile?: React.Dispatch<React.SetStateAction<UserProfile>>;
  onOpenOnboarding?: () => void;
}

export default function Dashboard({
  language,
  progress,
  studyPlan,
  setStudyPlan,
  examPrep,
  setExamPrep,
  onNavigate,
  onGeneratePlan,
  isGeneratingPlan,
  userProfile,
  setUserProfile,
  onOpenOnboarding
}: DashboardProps) {
  const [dailySet, setDailySet] = useState<DailyQuestionSet | null>(null);

  const [showTodaysQuestions, setShowTodaysQuestions] = useState<boolean>(false);
  const [showSubjectModal, setShowSubjectModal] = useState<boolean>(false);
  const [selectedPracticeSubject, setSelectedPracticeSubject] = useState<string>('ALL');

  // Weekly Quiz & Admin States
  const [activeWeeklyQuizForTaking, setActiveWeeklyQuizForTaking] = useState<WeeklyQuiz | null>(null);
  const [activeWeeklyQuizForLeaderboard, setActiveWeeklyQuizForLeaderboard] = useState<WeeklyQuiz | null>(null);
  const [activeWeeklyQuizForResult, setActiveWeeklyQuizForResult] = useState<{ quiz: WeeklyQuiz; submission: WeeklyQuizSubmission } | null>(null);
  const [showAdminWeeklyQuiz, setShowAdminWeeklyQuiz] = useState<boolean>(false);
  const [quizKey, setQuizKey] = useState<number>(0);

  // Check if current user is Admin
  const isAdminUser = Boolean(
    typeof window !== 'undefined' && localStorage.getItem('edumind_admin_token')
  );

  // Secret Admin shortcut listener (Ctrl + Shift + A)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        setShowAdminWeeklyQuiz(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const selectedSubjects = userProfile?.selectedSubjects && userProfile.selectedSubjects.length > 0
    ? userProfile.selectedSubjects
    : ['Reasoning', 'General Knowledge', 'Current Affairs'];

  const targetExamName = userProfile?.targetExam || examPrep || 'RRB NTPC';
  const dailyTargetCount = userProfile?.dailyQuestionTarget || 100;

  useEffect(() => {
    if (userProfile) {
      fetchOrGenerateDailyQuestionSet(userProfile).then(setDailySet);
    }
  }, [userProfile?.targetExam, JSON.stringify(userProfile?.selectedSubjects), userProfile?.dailyQuestionTarget]);

  const subjectDist = calculateSubjectDistribution(selectedSubjects, dailyTargetCount);
  const completedCount = dailySet?.completedCount || 0;
  const progressPercent = Math.min(100, Math.round((completedCount / dailyTargetCount) * 100));

  const handleStartTodaysQuestions = (subjectFilter: string = 'ALL') => {
    setSelectedPracticeSubject(subjectFilter);
    setShowTodaysQuestions(true);
  };

  const handleSaveSubjects = async (newSubjects: string[]) => {
    if (setUserProfile && userProfile) {
      const updated: UserProfile = {
        ...userProfile,
        selectedSubjects: newSubjects
      };
      setUserProfile(updated);
      try {
        localStorage.setItem('edumind_user_profile', JSON.stringify(updated));
      } catch (e) {}

      // Regenerate daily set matching newly selected subjects
      const newSet = await fetchOrGenerateDailyQuestionSet(updated);
      setDailySet(newSet);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-slate-900 text-slate-100 p-3.5 sm:p-5 md:p-6 space-y-4 sm:space-y-5">
      
      {/* ⏰ 10-Minute Prior Alert Realtime Banner */}
      <QuizNotificationAlertBanner
        language={language}
        onOpenQuiz={(quizId) => {
          // Open the active quiz modal
          fetch('/api/weekly-quiz/current')
            .then(res => {
              if (res.ok && (res.headers.get('content-type') || '').includes('application/json')) {
                return res.json();
              }
              return null;
            })
            .then(data => {
              if (data?.quiz) setActiveWeeklyQuizForTaking(data.quiz);
            })
            .catch(() => {});
        }}
      />

      {/* COMPACT & PREMIUM PERSONALIZED LEARNING HUB HEADER */}
      <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-indigo-950 via-indigo-900 to-purple-950 border border-indigo-500/30 p-3.5 sm:p-4.5 md:p-5 shadow-xl">
        {/* Subtle Ambient Backdrops */}
        <div className="absolute top-0 right-1/4 w-60 h-28 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-8 w-40 h-20 bg-purple-500/15 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-3.5 sm:gap-4.5">
          {/* Info & Chips */}
          <div className="space-y-1.5 flex-1 min-w-0">
            
            {/* Top Tag & Badges Row */}
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-[10px] sm:text-[11px] font-bold tracking-wide">
                <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
                <span>{language === 'bn' ? 'ব্যক্তিকেন্দ্রিক এআই লার্নিং হাব' : 'Personalized AI Learning Hub'}</span>
              </div>

              {/* Target Exam Badge (Compact) */}
              <div className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-500/15 border border-amber-400/30 text-amber-200 text-[10px] sm:text-[11px] font-extrabold rounded-md shadow-xs">
                <Target className="w-3 h-3 text-amber-300" />
                <span className="truncate max-w-[130px] sm:max-w-none">{targetExamName}</span>
              </div>

              {/* Edit Subjects Pill Button */}
              {onOpenOnboarding && (
                <button
                  onClick={onOpenOnboarding}
                  className="px-2 py-0.5 bg-indigo-600/30 hover:bg-indigo-600/60 text-indigo-200 hover:text-white border border-indigo-400/40 text-[10px] sm:text-[11px] font-bold rounded-md flex items-center gap-1 cursor-pointer transition-all active:scale-95 ml-auto sm:ml-0"
                  title={language === 'bn' ? 'বিষয় ও পরীক্ষা পরিবর্তন' : 'Edit Subjects'}
                >
                  <Edit3 className="w-2.5 h-2.5" />
                  <span>{language === 'bn' ? 'এডিট বিষয়' : 'Edit Subjects'}</span>
                </button>
              )}
            </div>
            
            {/* Welcome Title */}
            <h1 className="text-base sm:text-lg md:text-xl font-black text-white font-display tracking-tight leading-tight">
              {language === 'bn' ? `শুভদিন, ${userProfile?.name || 'শিক্ষার্থী'}! 👋` : `Welcome back, ${userProfile?.name || 'Learner'}! 👋`}
            </h1>
            
            {/* Description: Compact 1-2 lines */}
            <p className="text-[11px] sm:text-xs text-indigo-200/90 leading-snug">
              {language === 'bn' 
                ? `আপনার নির্বাচিত বিষয়সমূহ থেকে আজ ${dailyTargetCount} টি প্রশ্নের টার্গেট সেট করা হয়েছে।` 
                : `Target set for ${dailyTargetCount} personalized questions today based strictly on your selected subjects.`}
            </p>

            {/* Selected Subjects Chips (Compact multi-fit wrap) */}
            <div className="flex flex-wrap items-center gap-1 sm:gap-1.5 pt-0.5">
              {selectedSubjects.map(sub => (
                <span 
                  key={sub} 
                  className="px-2 py-0.5 bg-slate-950/60 hover:bg-slate-950 border border-indigo-500/25 hover:border-indigo-400/40 text-indigo-200 text-[10px] sm:text-[11px] font-medium rounded-md transition-colors"
                >
                  • {sub}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 🔥 STANDALONE TODAY'S DAILY TARGET CARD */}
      <DailyTargetCard
        language={language}
        completedCount={completedCount}
        dailyTargetCount={dailyTargetCount}
        progressPercent={progressPercent}
        onStartQuestions={handleStartTodaysQuestions}
      />

      {/* 🏆 WEEKLY QUIZ CHALLENGE SECTION */}
      <WeeklyQuizCard
        refreshKey={quizKey}
        language={language}
        userProfile={userProfile}
        onJoinQuiz={(q) => setActiveWeeklyQuizForTaking(q)}
        onViewLeaderboard={(q) => setActiveWeeklyQuizForLeaderboard(q)}
        onViewResult={(q, sub) => setActiveWeeklyQuizForResult({ quiz: q, submission: sub })}
        onOpenAdmin={() => setShowAdminWeeklyQuiz(true)}
      />

      {/* QUICK FEATURE NAVIGATION GRID */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
        {[
          { 
            id: 'examprep', 
            title: language === 'bn' ? 'ডেইলি কুইজ' : 'Daily Quiz', 
            sub: language === 'bn' ? '১০০ প্রশ্ন সেট' : '100 Qs Set', 
            icon: Zap, 
            color: 'from-amber-500 to-orange-600' 
          },
          { 
            id: 'examprep', 
            title: language === 'bn' ? 'ভুল খাতা' : 'My Mistakes', 
            sub: language === 'bn' ? 'ভুল উত্তর রিভিউ' : 'Review Errors', 
            icon: AlertCircle, 
            color: 'from-rose-500 to-pink-600' 
          },
          { 
            id: 'examprep', 
            title: language === 'bn' ? 'রিভিশন' : 'Smart Revision', 
            sub: language === 'bn' ? 'স্মার্ট স্পেসড লার্নিং' : 'Spaced Practice', 
            icon: RotateCcw, 
            color: 'from-emerald-500 to-teal-600' 
          },
          { 
            id: 'saved', 
            title: language === 'bn' ? 'বুকমার্কস' : 'Bookmarks', 
            sub: language === 'bn' ? 'সংরক্ষিত বিষয়' : 'Saved Questions', 
            icon: Bookmark, 
            color: 'from-blue-500 to-indigo-600' 
          },
          { 
            id: 'classroom', 
            title: language === 'bn' ? 'এআই লার্নিং হাব' : 'AI Learning Hub', 
            sub: language === 'bn' ? 'সিলেবাস ও বিষয়ভিত্তিক পড়া' : 'Syllabus & Lessons', 
            icon: BookOpen, 
            color: 'from-purple-500 to-indigo-600' 
          },
          { 
            id: 'planner', 
            title: language === 'bn' ? 'স্টাডি প্ল্যান' : 'Study Plan', 
            sub: language === 'bn' ? 'এআই টাইমটেবল' : 'AI Timetable', 
            icon: Calendar, 
            color: 'from-violet-500 to-fuchsia-600' 
          }
        ].map(item => {
          const Icon = item.icon;
          return (
            <button
              key={item.title}
              onClick={() => onNavigate(item.id)}
              className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-slate-600 rounded-2xl p-4 text-left transition-all hover:scale-[1.02] cursor-pointer group flex flex-col justify-between"
            >
              <div className={`p-2.5 rounded-xl bg-gradient-to-tr ${item.color} text-white w-fit mb-2 shadow-md group-hover:scale-110 transition-transform`}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <div className="font-extrabold text-xs text-white">{item.title}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">{item.sub}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* ADMIN SHORTCUT & PLATFORM FOOTER */}
      <div className="pt-4 flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-800">
        <span>{language === 'bn' ? 'StudySkill AI • সর্বভারতীয় ও রাজ্যভিত্তিক পরীক্ষা প্রস্তুতি প্ল্যাটফর্ম' : 'StudySkill AI • Comprehensive Exam & Quiz Platform'}</span>
        <div className="flex items-center gap-2">
          {isAdminUser && (
            <button
              onClick={() => setShowAdminWeeklyQuiz(true)}
              className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin Portal</span>
            </button>
          )}
          <button
            onClick={() => setShowAdminWeeklyQuiz(true)}
            className="text-slate-700 hover:text-amber-500 transition-colors p-1 cursor-pointer"
            title="Admin Login (Shortcut: Ctrl + Shift + A)"
          >
            <Lock className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* SUBJECT SELECTION MODAL */}
      {showSubjectModal && (
        <SubjectSelectionModal
          language={language}
          selectedSubjects={selectedSubjects}
          onSave={handleSaveSubjects}
          onClose={() => setShowSubjectModal(false)}
        />
      )}

      {/* TODAY'S QUESTIONS LEARNING MODAL */}
      {showTodaysQuestions && dailySet && (
        <TodaysQuestionsModal
          language={language}
          dailySet={dailySet}
          userProfile={userProfile}
          setUserProfile={setUserProfile}
          initialSubjectFilter={selectedPracticeSubject}
          onClose={() => setShowTodaysQuestions(false)}
          onUpdateProgress={(updated) => setDailySet(updated)}
        />
      )}

      {/* 🏆 WEEKLY QUIZ ACTIVE TEST MODAL */}
      {activeWeeklyQuizForTaking && (
        <WeeklyQuizModal
          quiz={activeWeeklyQuizForTaking}
          language={language}
          userProfile={userProfile}
          onClose={() => {
            setActiveWeeklyQuizForTaking(null);
            setQuizKey(prev => prev + 1);
          }}
          onViewLeaderboard={(q) => {
            setActiveWeeklyQuizForTaking(null);
            setActiveWeeklyQuizForLeaderboard(q);
          }}
        />
      )}

      {/* 🏆 WEEKLY QUIZ RESULT REVIEW MODAL */}
      {activeWeeklyQuizForResult && (
        <WeeklyQuizModal
          quiz={activeWeeklyQuizForResult.quiz}
          language={language}
          userProfile={userProfile}
          initialSubmission={activeWeeklyQuizForResult.submission}
          onClose={() => {
            setActiveWeeklyQuizForResult(null);
            setQuizKey(prev => prev + 1);
          }}
          onViewLeaderboard={(q) => {
            setActiveWeeklyQuizForResult(null);
            setActiveWeeklyQuizForLeaderboard(q);
          }}
        />
      )}

      {/* 🏆 WEEKLY QUIZ LEADERBOARD MODAL */}
      {activeWeeklyQuizForLeaderboard && (
        <WeeklyQuizLeaderboardModal
          quiz={activeWeeklyQuizForLeaderboard}
          language={language}
          userProfile={userProfile}
          onClose={() => setActiveWeeklyQuizForLeaderboard(null)}
          onJoinQuiz={() => {
            const q = activeWeeklyQuizForLeaderboard;
            setActiveWeeklyQuizForLeaderboard(null);
            setActiveWeeklyQuizForTaking(q);
          }}
        />
      )}

      {/* 🛡️ ADMIN WEEKLY QUIZ & PRIZE MANAGEMENT MODAL */}
      {showAdminWeeklyQuiz && (
        <AdminWeeklyQuizModal
          language={language}
          onClose={() => setShowAdminWeeklyQuiz(false)}
          onQuizUpdated={() => setQuizKey(prev => prev + 1)}
        />
      )}

    </div>
  );
}
