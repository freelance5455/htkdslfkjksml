import React from 'react';
import { UserProfile, Workout, WeeklyPlanDay, RecoveryCheckIn, WorkoutType } from '../types';
import {
  Play,
  Flame,
  Calendar,
  Timer,
  TrendingUp,
  MessageSquare,
  ShieldCheck,
  ChevronRight,
  Activity,
  Award,
} from 'lucide-react';

interface DashboardProps {
  profile: UserProfile;
  weeklyPlan: WeeklyPlanDay[];
  recentWorkouts: Workout[];
  latestRecovery?: RecoveryCheckIn;
  onStartRun: (type?: WorkoutType) => void;
  onOpenCoach: () => void;
  onOpenRecovery: () => void;
  onNavigateToPlan: () => void;
  onNavigateToAnalytics: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  profile,
  weeklyPlan,
  recentWorkouts,
  latestRecovery,
  onStartRun,
  onOpenCoach,
  onOpenRecovery,
  onNavigateToPlan,
  onNavigateToAnalytics,
}) => {
  // Find today's day of week
  const daysMap = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  const currentDayIndex = new Date().getDay();
  const todayDayName = daysMap[currentDayIndex];

  const todayWorkout = weeklyPlan.find((d) => d.dayName === todayDayName) || weeklyPlan[0];

  // Weekly stats
  const completedThisWeek = weeklyPlan.filter((d) => d.completed).length;
  const weeklyDistance = recentWorkouts
    .slice(0, 7)
    .reduce((sum, w) => sum + (w.distanceKm || 0), 0);

  return (
    <div className="space-y-4 pb-24">
      {/* 1600m Mission Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-zinc-900 via-zinc-950 to-black border border-zinc-800 p-5 shadow-2xl">
        {/* Glow ambient background accent */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-[#00FF66]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00FF66] animate-pulse" />
            <span className="text-xs font-black uppercase tracking-widest text-[#00FF66]">
              1600M MISSION
            </span>
          </div>
          <span className="text-[11px] font-bold text-zinc-400 bg-black/60 px-2.5 py-1 rounded-full border border-zinc-800">
            Baseline: {profile.isBaselineVerified ? 'Verified' : 'Unverified'}
          </span>
        </div>

        {/* 1600m Target Metric Comparison */}
        <div className="flex items-end justify-between my-2">
          <div>
            <span className="text-xs text-zinc-400 font-medium">Target Time</span>
            <div className="font-mono-numbers text-4xl sm:text-5xl font-black text-white tracking-tight">
              {profile.target1600m}{' '}
              <span className="text-sm font-bold text-[#00FF66]">SUB 4:50</span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs text-zinc-400 font-medium">Current Baseline</span>
            <div className="font-mono-numbers text-2xl font-bold text-zinc-400">
              ~{profile.currentPb1600m}
            </div>
          </div>
        </div>

        {/* Lap Pace Requirement */}
        <div className="mt-3 pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs">
          <span className="text-zinc-400">Required 400m Split:</span>
          <span className="font-mono-numbers font-bold text-[#00FF66]">
            1:12.5 / lap (72.5s)
          </span>
        </div>
      </div>

      {/* Prominent Primary "START RUN" Button */}
      <button
        onClick={() => onStartRun()}
        className="w-full py-4 rounded-2xl bg-[#00FF66] text-black font-athletic font-black text-xl tracking-wider uppercase flex items-center justify-center gap-2.5 hover:bg-[#10B981] active:scale-[0.98] transition shadow-xl glow-neon"
      >
        <Play className="w-6 h-6 fill-current" />
        <span>START RUN NOW</span>
      </button>

      {/* Today's Training Plan Card */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#00FF66]" />
            <h2 className="font-athletic text-base font-extrabold uppercase text-white tracking-wide">
              Today's Workout &bull; {todayWorkout.dayName}
            </h2>
          </div>
          <span
            className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${
              todayWorkout.intensity === 'high'
                ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                : todayWorkout.intensity === 'moderate'
                ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                : 'bg-[#00FF66]/15 text-[#00FF66] border-[#00FF66]/30'
            }`}
          >
            {todayWorkout.intensity} intensity
          </span>
        </div>

        <h3 className="text-base font-bold text-white mt-1">{todayWorkout.title}</h3>
        <p className="text-xs text-zinc-300 mt-1 leading-relaxed">{todayWorkout.mainWorkout}</p>

        <div className="mt-4 pt-3 border-t border-zinc-800/80 flex items-center gap-2">
          <button
            onClick={() => onStartRun(todayWorkout.workoutType)}
            className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs uppercase tracking-wide flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <Play className="w-3.5 h-3.5 fill-[#00FF66] text-[#00FF66]" />
            <span>Start Today's Session</span>
          </button>
          <button
            onClick={onNavigateToPlan}
            className="px-3 py-2.5 rounded-xl bg-black border border-zinc-800 text-zinc-400 hover:text-white text-xs font-semibold"
          >
            Full Week
          </button>
        </div>
      </div>

      {/* Quick Stats Grid: Distance, Workouts Completed, Consistency */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center gap-2 text-zinc-400 mb-1">
            <Activity className="w-4 h-4 text-[#00FF66]" />
            <span className="text-xs font-semibold uppercase">Weekly Distance</span>
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="font-mono-numbers text-3xl font-black text-white">
              {weeklyDistance.toFixed(1)}
            </span>
            <span className="text-xs font-bold text-zinc-400">/ {profile.weeklyVolumeKm} KM</span>
          </div>
          {/* Progress bar */}
          <div className="w-full h-1.5 bg-black rounded-full overflow-hidden mt-2">
            <div
              className="h-full bg-[#00FF66]"
              style={{
                width: `${Math.min(100, (weeklyDistance / (profile.weeklyVolumeKm || 25)) * 100)}%`,
              }}
            />
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center gap-2 text-zinc-400 mb-1">
            <Award className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-semibold uppercase">Completed</span>
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="font-mono-numbers text-3xl font-black text-white">
              {completedThisWeek}
            </span>
            <span className="text-xs font-bold text-zinc-400">/ 7 Days</span>
          </div>
          <span className="text-[10px] text-[#00FF66] font-semibold mt-1 block">
            {Math.round((completedThisWeek / 7) * 100)}% Consistency
          </span>
        </div>
      </div>

      {/* Coach Jaat Quick Prompt Card */}
      <div
        onClick={onOpenCoach}
        className="bg-gradient-to-r from-zinc-900 to-black border border-zinc-800 hover:border-[#00FF66]/50 rounded-2xl p-4 cursor-pointer transition shadow-xl group"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-black border border-[#00FF66]/40 flex items-center justify-center text-[#00FF66] group-hover:scale-105 transition">
              <Flame className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-athletic text-sm font-black text-white uppercase">
                  Coach Jaat
                </span>
                <span className="text-[10px] bg-[#00FF66]/15 text-[#00FF66] font-bold px-1.5 py-0.5 rounded">
                  AI ASSISTANT
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                "Sleep kaisa tha? Aaj ka workout discuss karein?"
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-zinc-400 group-hover:text-[#00FF66] transition" />
        </div>
      </div>

      {/* Recovery Status Card */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-black border border-zinc-800 flex items-center justify-center text-amber-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="font-athletic text-xs font-bold uppercase text-zinc-400">
              Recovery Check-In
            </span>
            <p className="text-xs font-bold text-white mt-0.5">
              {latestRecovery
                ? `Sleep ${latestRecovery.sleepHours}h · Soreness ${latestRecovery.sorenessScore}/10`
                : 'No check-in recorded for today'}
            </p>
          </div>
        </div>
        <button
          onClick={onOpenRecovery}
          className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold transition"
        >
          Check In
        </button>
      </div>

      {/* Recent Workouts List Preview */}
      {recentWorkouts.length > 0 && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-athletic text-sm uppercase tracking-wider font-bold text-white">
              Recent Workouts
            </h3>
            <button
              onClick={onNavigateToAnalytics}
              className="text-xs text-[#00FF66] font-semibold hover:underline"
            >
              View All
            </button>
          </div>
          <div className="divide-y divide-zinc-800 text-xs">
            {recentWorkouts.slice(0, 3).map((w) => (
              <div key={w.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">{w.title}</span>
                  <span className="text-[10px] text-zinc-400">
                    {w.date} &bull; {w.workoutType.toUpperCase()}
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-mono-numbers font-black text-white block">
                    {w.distanceKm} KM · {w.durationFormatted}
                  </span>
                  <span className="text-[10px] text-[#00FF66] font-mono-numbers">
                    {w.avgPace} /km
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
