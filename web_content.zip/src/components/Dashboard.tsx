import React from 'react';
import { ActiveTab, StudentProfile, SavedHistoryItem } from '../types';
import {
  Camera,
  FileText,
  BookMarked,
  SpellCheck,
  ArrowRight,
  Sparkles,
  Flame,
  Award,
  BookOpen,
  CheckCircle2,
  Clock,
  Compass,
  Lightbulb
} from 'lucide-react';

interface DashboardProps {
  profile: StudentProfile;
  setActiveTab: (tab: ActiveTab) => void;
  recentHistory: SavedHistoryItem[];
  onOpenProfile: () => void;
  onOpenTimer: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  profile,
  setActiveTab,
  recentHistory,
  onOpenProfile,
  onOpenTimer,
}) => {
  const getGradeTips = (grade: string) => {
    if (grade.includes('1') || grade.includes('2') || grade.includes('3') || grade.includes('4') || grade.includes('5')) {
      return {
        quote: "Break big homework questions into small steps! Draw a picture if math feels tricky.",
        highlight: "Elementary Focus: Visual analogies & foundational sentence building."
      };
    }
    if (grade.includes('6') || grade.includes('7') || grade.includes('8')) {
      return {
        quote: "Always underline what the question is asking for before doing calculations or writing your claim.",
        highlight: "Middle School Focus: Strong topic sentences & structured evidence."
      };
    }
    if (grade.includes('College')) {
      return {
        quote: "Focus on synthesizing conflicting perspectives and articulating nuanced theoretical insights.",
        highlight: "Higher Ed Focus: Academic synthesis, rigorous methodology & peer-review level clarity."
      };
    }
    return {
      quote: "Strong thesis statements make essays write themselves. Anchor every body paragraph with a clear reason.",
      highlight: "High School Focus: Analytical rigor, rhetorical devices & AP-level depth."
    };
  };

  const tip = getGradeTips(profile.grade);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Hero Welcome Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-blue-700 via-indigo-700 to-violet-800 p-6 sm:p-10 text-white shadow-xl overflow-hidden">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 bg-white/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 -mb-16 w-60 h-60 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md border border-white/20 text-xs font-semibold text-blue-100">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Personalized for {profile.schoolName}</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
              Ready to crush your studies, {profile.name}? {profile.avatar}
            </h1>
            <p className="text-blue-100 text-sm sm:text-base leading-relaxed">
              Every solution, paragraph, essay, and grammar suggestion is tuned precisely for{' '}
              <span className="font-bold underline decoration-amber-300 underline-offset-4 text-white">
                {profile.grade}
              </span>
              . No email or password needed—just pure, fast learning!
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => setActiveTab('snap-solve')}
                className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold text-xs uppercase tracking-wider transition shadow-lg shadow-amber-400/25 flex items-center gap-2 cursor-pointer"
              >
                <Camera className="w-4 h-4" /> Snap & Solve Now
              </button>
              <button
                onClick={onOpenTimer}
                className="px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 backdrop-blur-md text-white font-semibold text-xs transition border border-white/20 flex items-center gap-2 cursor-pointer"
              >
                <Clock className="w-4 h-4" /> Start Focus Session
              </button>
              <button
                onClick={onOpenProfile}
                className="text-xs text-blue-200 hover:text-white underline underline-offset-2 transition"
              >
                Change grade or school
              </button>
            </div>
          </div>

          {/* Quick Streak & Stats Card */}
          <div className="bg-white/10 backdrop-blur-md border border-white/20 p-5 rounded-2xl flex flex-col gap-3 min-w-[220px]">
            <div className="flex items-center justify-between border-b border-white/15 pb-2">
              <span className="text-xs text-blue-100 font-medium">Daily Streak</span>
              <div className="flex items-center gap-1 text-amber-300 font-bold text-sm">
                <Flame className="w-4 h-4 fill-amber-300" />
                <span>{profile.studyStreakDays} Day{profile.studyStreakDays > 1 ? 's' : ''}</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 text-center pt-1">
              <div className="p-2 bg-white/5 rounded-xl">
                <span className="block text-2xl font-black">{profile.solvedProblemsCount}</span>
                <span className="text-[10px] text-blue-200 uppercase font-semibold">Problems Solved</span>
              </div>
              <div className="p-2 bg-white/5 rounded-xl">
                <span className="block text-2xl font-black">
                  {profile.writtenParagraphsCount + profile.writtenEssaysCount}
                </span>
                <span className="text-[10px] text-blue-200 uppercase font-semibold">Written Works</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Grade Level Coach Tip */}
      <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 sm:p-5 flex items-start gap-4 shadow-2xs">
        <div className="p-2 bg-amber-100 text-amber-800 rounded-xl mt-0.5">
          <Lightbulb className="w-5 h-5" />
        </div>
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-900">
              Study Coach Insight • {profile.grade}
            </span>
          </div>
          <p className="text-sm text-slate-800 font-medium italic">
            "{tip.quote}"
          </p>
          <p className="text-xs text-slate-600">
            {tip.highlight}
          </p>
        </div>
      </div>

      {/* Primary Study Tools Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Compass className="w-5 h-5 text-blue-600" />
            Your AI Study Tools
          </h2>
          <span className="text-xs text-slate-500 font-medium">All calibrated to {profile.grade}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Tool 1: Snap & Solve */}
          <div
            onClick={() => setActiveTab('snap-solve')}
            className="group relative bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:shadow-xl hover:border-blue-400/70 transition-all duration-200 flex flex-col justify-between cursor-pointer"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-500 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-blue-500/25 mb-4 group-hover:scale-110 transition">
                <Camera className="w-6 h-6" />
              </div>
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition">
                  Snap & Solve
                </h3>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-blue-50 text-blue-700 rounded-full">
                  Vision AI
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed mt-2">
                Snap or upload photos of math equations, science diagrams, or history questions. Get step-by-step answers & concept breakdowns.
              </p>
            </div>
            <div className="pt-5 flex items-center justify-between text-xs font-bold text-blue-600">
              <span>Start solving</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
            </div>
          </div>

          {/* Tool 2: Paragraph Writing */}
          <div
            onClick={() => setActiveTab('paragraph')}
            className="group relative bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:shadow-xl hover:border-violet-400/70 transition-all duration-200 flex flex-col justify-between cursor-pointer"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-violet-500 to-purple-600 text-white flex items-center justify-center shadow-md shadow-violet-500/25 mb-4 group-hover:scale-110 transition">
                <FileText className="w-6 h-6" />
              </div>
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-violet-600 transition">
                  Paragraph Writing
                </h3>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-violet-50 text-violet-700 rounded-full">
                  Topic & Word Count
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed mt-2">
                Type any topic and target length. Instant cohesive paragraph with clear topic sentences, transition words, and grade-tuned vocabulary.
              </p>
            </div>
            <div className="pt-5 flex items-center justify-between text-xs font-bold text-violet-600">
              <span>Write paragraph</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
            </div>
          </div>

          {/* Tool 3: Essay Writing */}
          <div
            onClick={() => setActiveTab('essay')}
            className="group relative bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:shadow-xl hover:border-emerald-400/70 transition-all duration-200 flex flex-col justify-between cursor-pointer"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-md shadow-emerald-500/25 mb-4 group-hover:scale-110 transition">
                <BookMarked className="w-6 h-6" />
              </div>
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-emerald-600 transition">
                  Essay Writing
                </h3>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-full">
                  Full Essays
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed mt-2">
                Type your essay topic and word count. Generates hook, thesis statement, structured outline, in-depth body paragraphs, and works cited.
              </p>
            </div>
            <div className="pt-5 flex items-center justify-between text-xs font-bold text-emerald-600">
              <span>Compose essay</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
            </div>
          </div>

          {/* Tool 4: Grammar Checker */}
          <div
            onClick={() => setActiveTab('grammar')}
            className="group relative bg-white rounded-3xl p-6 border border-slate-200 shadow-xs hover:shadow-xl hover:border-amber-400/70 transition-all duration-200 flex flex-col justify-between cursor-pointer"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 text-white flex items-center justify-center shadow-md shadow-amber-500/25 mb-4 group-hover:scale-110 transition">
                <SpellCheck className="w-6 h-6" />
              </div>
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-amber-600 transition">
                  Grammar Checker
                </h3>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-amber-50 text-amber-700 rounded-full">
                  Real-time
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed mt-2">
                Real-time feedback on grammar, spelling, clarity, and tone. Offers 1-click fixes and advanced vocabulary upgrades suited to {profile.grade}.
              </p>
            </div>
            <div className="pt-5 flex items-center justify-between text-xs font-bold text-amber-600">
              <span>Check writing</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Notebook / Activity Section */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-blue-600" />
            Your Study Notebook & History
          </h3>
          <button
            onClick={() => setActiveTab('history')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 transition"
          >
            View all notebook items →
          </button>
        </div>

        {recentHistory.length === 0 ? (
          <div className="text-center py-10 px-4 border-2 border-dashed border-slate-100 rounded-2xl">
            <Award className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-700">No saved study items yet</p>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Whenever you snap a problem, write a paragraph, generate an essay, or check grammar, it will be automatically saved here in your notebook!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {recentHistory.slice(0, 6).map((item) => (
              <div
                key={item.id}
                onClick={() => setActiveTab('history')}
                className="p-3.5 rounded-2xl border border-slate-100 bg-slate-50 hover:bg-white hover:border-blue-200 hover:shadow-xs transition cursor-pointer text-left"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-100 text-blue-700">
                    {item.type}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {new Date(item.timestamp).toLocaleDateString()}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-slate-800 truncate">{item.title}</h4>
                <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  Saved for {item.gradeWhenCreated}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
