import React, { useState, useEffect } from 'react';
import { BusinessProfile } from '../types/business';
import { StorageService } from '../db/storage';
import { FirebaseSyncBanner } from './FirebaseSyncBanner';
import { AudioVoiceTranscriber } from './AudioVoiceTranscriber';
import { QuickReportCard } from './QuickReportCard';
import {
  Search,
  Clock,
  Calendar,
  TrendingUp,
  DollarSign,
  Package,
  AlertCircle,
  Wallet,
  PlusCircle,
  ShoppingCart,
  RotateCcw,
  BarChart3,
  Receipt,
  AlertTriangle,
  ArrowRight,
  Phone,
  MessageCircle,
  CreditCard,
  Layers,
  FileText,
  BadgeAlert,
  ChevronRight,
  Sparkles,
  Bot,
  MapPin,
  Radio,
} from 'lucide-react';

interface DashboardProps {
  profile: BusinessProfile;
  lang: 'bn' | 'en';
  onNavigate: (view: string, data?: any) => void;
  onOpenSearch: (query: string) => void;
  onOpenAI: (tab?: 'chat' | 'search' | 'maps' | 'live') => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  profile,
  lang,
  onNavigate,
  onOpenSearch,
  onOpenAI,
}) => {
  const [metrics, setMetrics] = useState(StorageService.getDashboardMetrics());
  const [stockAlerts, setStockAlerts] = useState(StorageService.getStockAlertProducts());
  const [dueAlerts, setDueAlerts] = useState(StorageService.getDueCustomers());
  const [searchQuery, setSearchQuery] = useState('');
  const [currentTimeStr, setCurrentTimeStr] = useState('');
  const [currentDateStr, setCurrentDateStr] = useState('');

  // Live ticking clock & date
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTimeStr(
        now.toLocaleTimeString(lang === 'bn' ? 'bn-BD' : 'en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
      setCurrentDateStr(
        now.toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [lang]);

  // Refresh metrics when dashboard is active
  useEffect(() => {
    setMetrics(StorageService.getDashboardMetrics());
    setStockAlerts(StorageService.getStockAlertProducts());
    setDueAlerts(StorageService.getDueCustomers());
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onOpenSearch(searchQuery.trim());
    }
  };

  const currency = profile.currency || '৳';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Firebase Authentication & Cloud Sync Banner */}
      <FirebaseSyncBanner lang={lang} />

      {/* Top Header / Business Bar */}
      <header className="bg-white border-b border-slate-200/80 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
            {/* Business Logo & Name */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center overflow-hidden shrink-0 shadow-xs">
                {profile.businessLogo ? (
                  <img
                    src={profile.businessLogo}
                    alt="Logo"
                    className="w-full h-full object-contain p-1"
                  />
                ) : (
                  <Package className="w-6 h-6 text-indigo-600" />
                )}
              </div>
              <div>
                <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight leading-tight">
                  {profile.businessName}
                </h1>
                <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
                  <span>{profile.ownerName || 'Zahed Ahmed'}</span>
                  <span>•</span>
                  <span>{profile.phone}</span>
                </div>
              </div>
            </div>

            {/* Live Clock & Calendar */}
            <div className="flex items-center justify-between sm:justify-end gap-3 text-xs bg-slate-50 sm:bg-transparent px-3 py-1.5 sm:p-0 rounded-xl">
              <div className="flex items-center gap-1.5 text-slate-600">
                <Calendar className="w-4 h-4 text-indigo-600" />
                <span className="font-medium">{currentDateStr}</span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-50/80 border border-indigo-100/80 text-indigo-700 font-mono font-semibold text-xs shadow-2xs">
                <Clock className="w-3.5 h-3.5" />
                <span>{currentTimeStr}</span>
              </div>
            </div>
          </div>

          {/* Big Global Search Bar with Microphone Audio Transcriber (gemini-3.5-transcribe) */}
          <form onSubmit={handleSearchSubmit} className="mt-3.5 relative flex items-center">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                lang === 'bn'
                  ? 'ব্র্যান্ড, মডেল, পণ্য, কাস্টমার, চালান নম্বর খুঁজুন (মুখেও বলতে পারেন)...'
                  : 'Search brand, model, product, customer, invoice...'
              }
              className="w-full pl-11 pr-32 py-3 rounded-2xl bg-slate-100/90 hover:bg-slate-100 focus:bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 text-sm font-medium text-slate-900 shadow-inner transition-all"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
              <AudioVoiceTranscriber
                lang={lang}
                onTranscribeComplete={(text) => {
                  setSearchQuery(text);
                  onOpenSearch(text);
                }}
              />
              <button
                type="submit"
                className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors cursor-pointer shadow-xs"
              >
                {lang === 'bn' ? 'খুঁজুন' : 'Search'}
              </button>
            </div>
          </form>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-5 space-y-6">
        {/* Real Summary Cards (7 Cards) */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-600" />
              {lang === 'bn' ? 'ব্যবসায়িক হিসাব ও সারসংক্ষেপ' : 'Business Summary & Metrics'}
            </h2>
            <span className="text-[11px] font-medium text-slate-400">
              {lang === 'bn' ? 'রিয়েল-টাইম হিসাব' : 'Real-time calculation'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-3">
            {/* 1. Today's Profit */}
            <div className="bg-white rounded-2xl p-4 border border-emerald-100 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2 font-bold">
                <TrendingUp className="w-4 h-4" />
              </div>
              <p className="text-xs font-semibold text-slate-500">
                {lang === 'bn' ? 'আজকের লাভ' : "Today's Profit"}
              </p>
              <h3 className="text-lg font-extrabold text-emerald-600 mt-1">
                {currency} {metrics.todayProfit.toLocaleString()}
              </h3>
              <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-50/50 rounded-bl-full pointer-events-none -mr-2 -mt-2 group-hover:scale-110 transition-transform" />
            </div>

            {/* 2. Total Profit */}
            <div className="bg-white rounded-2xl p-4 border border-blue-100 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
              <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-2 font-bold">
                <DollarSign className="w-4 h-4" />
              </div>
              <p className="text-xs font-semibold text-slate-500">
                {lang === 'bn' ? 'মোট লাভ' : 'Total Profit'}
              </p>
              <h3 className="text-lg font-extrabold text-blue-600 mt-1">
                {currency} {metrics.totalProfit.toLocaleString()}
              </h3>
              <div className="absolute top-0 right-0 w-16 h-16 bg-blue-50/50 rounded-bl-full pointer-events-none -mr-2 -mt-2 group-hover:scale-110 transition-transform" />
            </div>

            {/* 3. Today's Sales */}
            <div className="bg-white rounded-2xl p-4 border border-indigo-100 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
              <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-2 font-bold">
                <ShoppingCart className="w-4 h-4" />
              </div>
              <p className="text-xs font-semibold text-slate-500">
                {lang === 'bn' ? 'আজকের সেল' : "Today's Sales"}
              </p>
              <h3 className="text-lg font-extrabold text-indigo-600 mt-1">
                {currency} {metrics.todaySales.toLocaleString()}
              </h3>
              <div className="absolute top-0 right-0 w-16 h-16 bg-indigo-50/50 rounded-bl-full pointer-events-none -mr-2 -mt-2 group-hover:scale-110 transition-transform" />
            </div>

            {/* 4. Total Sales */}
            <div className="bg-white rounded-2xl p-4 border border-violet-100 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
              <div className="w-8 h-8 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center mb-2 font-bold">
                <BarChart3 className="w-4 h-4" />
              </div>
              <p className="text-xs font-semibold text-slate-500">
                {lang === 'bn' ? 'টোটাল সেল' : 'Total Sales'}
              </p>
              <h3 className="text-lg font-extrabold text-violet-600 mt-1">
                {currency} {metrics.totalSales.toLocaleString()}
              </h3>
              <div className="absolute top-0 right-0 w-16 h-16 bg-violet-50/50 rounded-bl-full pointer-events-none -mr-2 -mt-2 group-hover:scale-110 transition-transform" />
            </div>

            {/* 5. Total Stock */}
            <div
              onClick={() => onNavigate('products')}
              className="bg-white rounded-2xl p-4 border border-teal-100 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group cursor-pointer"
            >
              <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center mb-2 font-bold">
                <Package className="w-4 h-4" />
              </div>
              <p className="text-xs font-semibold text-slate-500">
                {lang === 'bn' ? 'টোটাল স্টক' : 'Total Stock'}
              </p>
              <h3 className="text-lg font-extrabold text-teal-700 mt-1">
                {metrics.totalStockQty}{' '}
                <span className="text-xs font-normal text-slate-500">
                  {lang === 'bn' ? 'পিস' : 'pcs'}
                </span>
              </h3>
              <p className="text-[10px] text-slate-400 mt-0.5">
                মূল্য: {currency} {metrics.totalStockValue.toLocaleString()}
              </p>
            </div>

            {/* 6. Total Due */}
            <div
              onClick={() => onNavigate('due_alerts')}
              className="bg-white rounded-2xl p-4 border border-amber-200 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group cursor-pointer bg-gradient-to-br from-white to-amber-50/40"
            >
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-2 font-bold">
                <AlertCircle className="w-4 h-4" />
              </div>
              <p className="text-xs font-semibold text-slate-600">
                {lang === 'bn' ? 'মোট বাকি' : 'Total Due'}
              </p>
              <h3 className="text-lg font-extrabold text-amber-700 mt-1">
                {currency} {metrics.totalDue.toLocaleString()}
              </h3>
              <div className="absolute top-0 right-0 w-16 h-16 bg-amber-100/40 rounded-bl-full pointer-events-none -mr-2 -mt-2 group-hover:scale-110 transition-transform" />
            </div>

            {/* 7. Cash Balance */}
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group col-span-2 sm:col-span-1">
              <div className="w-8 h-8 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center mb-2 font-bold">
                <Wallet className="w-4 h-4" />
              </div>
              <p className="text-xs font-semibold text-slate-500">
                {lang === 'bn' ? 'ক্যাশ ব্যালেন্স' : 'Cash Balance'}
              </p>
              <h3 className="text-lg font-extrabold text-slate-800 mt-1">
                {currency} {metrics.cashBalance.toLocaleString()}
              </h3>
              <div className="absolute top-0 right-0 w-16 h-16 bg-slate-100/60 rounded-bl-full pointer-events-none -mr-2 -mt-2 group-hover:scale-110 transition-transform" />
            </div>
          </div>
        </div>

        {/* Quick Report Summary Dashboard Card (Top 3 Best-Selling Products for Current Month) */}
        <QuickReportCard
          lang={lang}
          currency={currency}
          onNavigate={onNavigate}
          onRefreshMetrics={() => {
            setMetrics(StorageService.getDashboardMetrics());
            setStockAlerts(StorageService.getStockAlertProducts());
            setDueAlerts(StorageService.getDueCustomers());
          }}
        />

        {/* Quick Main Action Cards (Colorful, Touch-Friendly Grid) */}
        <div>
          <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-blue-600" />
            {lang === 'bn' ? 'প্রধান কার্যক্রমসমূহ' : 'Main Actions'}
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5">
            {/* 1. Stock Add / Products */}
            <button
              onClick={() => onNavigate('products')}
              className="p-4 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-md shadow-blue-500/20 hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all flex flex-col justify-between text-left group cursor-pointer min-h-[110px]"
            >
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <PlusCircle className="w-6 h-6 text-white" />
              </div>
              <div className="mt-3">
                <span className="text-sm font-bold block leading-tight">
                  {lang === 'bn' ? 'পণ্য যোগ করুন / স্টক' : 'Stock Add / Products'}
                </span>
                <span className="text-xs text-blue-100 block mt-0.5">
                  {lang === 'bn' ? 'নতুন পার্টস ও মজুদ বৃদ্ধি' : 'Add products & manage stock'}
                </span>
              </div>
            </button>

            {/* 2. New Sale */}
            <button
              onClick={() => onNavigate('sales')}
              className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-600 text-white shadow-md shadow-emerald-500/20 hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all flex flex-col justify-between text-left group cursor-pointer min-h-[110px]"
            >
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <ShoppingCart className="w-6 h-6 text-white" />
              </div>
              <div className="mt-3">
                <span className="text-sm font-bold block leading-tight">
                  {lang === 'bn' ? 'বিক্রয় / Sales POS' : 'New Sale / POS'}
                </span>
                <span className="text-xs text-emerald-100 block mt-0.5">
                  {lang === 'bn' ? 'ইনভয়েস তৈরি ও সেল' : 'Create bill & checkout'}
                </span>
              </div>
            </button>

            {/* 3. Returns */}
            <button
              onClick={() => onNavigate('returns')}
              className="p-4 rounded-2xl bg-gradient-to-br from-rose-500 to-rose-600 text-white shadow-md shadow-rose-500/20 hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all flex flex-col justify-between text-left group cursor-pointer min-h-[110px]"
            >
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <RotateCcw className="w-6 h-6 text-white" />
              </div>
              <div className="mt-3">
                <span className="text-sm font-bold block leading-tight">
                  {lang === 'bn' ? 'রিটার্ন / Return' : 'Return Management'}
                </span>
                <span className="text-xs text-rose-100 block mt-0.5">
                  {lang === 'bn' ? 'পণ্য ফেরত ও হিসাব সমন্বয়' : 'Process returns & adjust profit'}
                </span>
              </div>
            </button>

            {/* 4. Product-wise Profit */}
            <button
              onClick={() => onNavigate('product_profit')}
              className="p-4 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-white shadow-md shadow-indigo-500/20 hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all flex flex-col justify-between text-left group cursor-pointer min-h-[110px]"
            >
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div className="mt-3">
                <span className="text-sm font-bold block leading-tight">
                  {lang === 'bn' ? 'পণ্যভিত্তিক লাভ' : 'Product-wise Profit'}
                </span>
                <span className="text-xs text-indigo-100 block mt-0.5">
                  {lang === 'bn' ? 'প্রতিটি LCD পার্টসের লাভ' : 'Itemized margin analytics'}
                </span>
              </div>
            </button>

            {/* 5. Stock Alert */}
            <button
              onClick={() => onNavigate('stock_alerts')}
              className="p-4 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 text-white shadow-md shadow-amber-500/20 hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all flex flex-col justify-between text-left group cursor-pointer min-h-[110px] relative"
            >
              {stockAlerts.totalAlerts > 0 && (
                <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-red-600 text-white text-[11px] font-extrabold animate-bounce shadow-sm">
                  {stockAlerts.totalAlerts}
                </span>
              )}
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-white" />
              </div>
              <div className="mt-3">
                <span className="text-sm font-bold block leading-tight">
                  {lang === 'bn' ? 'স্টক অ্যালার্ট' : 'Stock Alert'}
                </span>
                <span className="text-xs text-amber-100 block mt-0.5">
                  {stockAlerts.stockOut.length} {lang === 'bn' ? 'স্টক শেষ' : 'Stock Out'},{' '}
                  {stockAlerts.limitedStock.length} {lang === 'bn' ? 'সীমিত' : 'Low'}
                </span>
              </div>
            </button>

            {/* 6. Transactions */}
            <button
              onClick={() => onNavigate('transactions')}
              className="p-4 rounded-2xl bg-gradient-to-br from-violet-500 to-violet-600 text-white shadow-md shadow-violet-500/20 hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all flex flex-col justify-between text-left group cursor-pointer min-h-[110px]"
            >
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <div className="mt-3">
                <span className="text-sm font-bold block leading-tight">
                  {lang === 'bn' ? 'সম্পত্তিক লেনদেন' : 'Transactions Log'}
                </span>
                <span className="text-xs text-violet-100 block mt-0.5">
                  {lang === 'bn' ? 'সব ধরণের আর্থিক খতিয়ান' : 'Complete financial history'}
                </span>
              </div>
            </button>

            {/* 7. Due Alert */}
            <button
              onClick={() => onNavigate('due_alerts')}
              className="p-4 rounded-2xl bg-gradient-to-br from-orange-500 to-orange-600 text-white shadow-md shadow-orange-500/20 hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all flex flex-col justify-between text-left group cursor-pointer min-h-[110px] relative"
            >
              {dueAlerts.length > 0 && (
                <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-white text-orange-700 text-[11px] font-extrabold shadow-sm">
                  {dueAlerts.length}
                </span>
              )}
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <BadgeAlert className="w-6 h-6 text-white" />
              </div>
              <div className="mt-3">
                <span className="text-sm font-bold block leading-tight">
                  {lang === 'bn' ? 'বাকি আদায়ের অ্যালার্ট' : 'Due Collection Alert'}
                </span>
                <span className="text-xs text-orange-100 block mt-0.5">
                  {dueAlerts.length} {lang === 'bn' ? 'জন কাস্টমারের বাকি' : 'customers overdue'}
                </span>
              </div>
            </button>

            {/* 8. Expenses */}
            <button
              onClick={() => onNavigate('expenses')}
              className="p-4 rounded-2xl bg-gradient-to-br from-slate-700 to-slate-800 text-white shadow-md shadow-slate-700/20 hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all flex flex-col justify-between text-left group cursor-pointer min-h-[110px]"
            >
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Receipt className="w-6 h-6 text-white" />
              </div>
              <div className="mt-3">
                <span className="text-sm font-bold block leading-tight">
                  {lang === 'bn' ? 'খরচ / Expenses' : 'Expense Management'}
                </span>
                <span className="text-xs text-slate-300 block mt-0.5">
                  {lang === 'bn' ? 'দোকান ভাড়া, বিল ও খরচ' : 'Daily shop expenses'}
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* Gemini AI Intelligence Cards (Chat, Search Grounding, Maps Grounding, Live Audio) */}
        <div>
          <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
            <span>{lang === 'bn' ? 'স্মার্ট এআই টুলস (Gemini AI Intelligence)' : 'Gemini AI Intelligence'}</span>
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* 1. Gemini Chatbot */}
            <button
              onClick={() => onOpenAI('chat')}
              className="p-3.5 rounded-2xl bg-white border border-indigo-200 hover:border-indigo-400 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold mb-2 group-hover:scale-105 transition-transform">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 block leading-tight">এআই চ্যাটবট</span>
                <span className="text-[11px] text-slate-500 mt-0.5 block">পার্টস ও ব্যবসা পরামর্শ</span>
              </div>
            </button>

            {/* 2. Google Search Grounding */}
            <button
              onClick={() => onOpenAI('search')}
              className="p-3.5 rounded-2xl bg-white border border-blue-200 hover:border-blue-400 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold mb-2 group-hover:scale-105 transition-transform">
                <Search className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 block leading-tight">মার্কেট সার্চ</span>
                <span className="text-[11px] text-slate-500 mt-0.5 block">লাইভ গুগল সার্চ রেট</span>
              </div>
            </button>

            {/* 3. Google Maps Grounding */}
            <button
              onClick={() => onOpenAI('maps')}
              className="p-3.5 rounded-2xl bg-white border border-emerald-200 hover:border-emerald-400 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold mb-2 group-hover:scale-105 transition-transform">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 block leading-tight">ম্যাপস ও কুরিয়ার</span>
                <span className="text-[11px] text-slate-500 mt-0.5 block">লোকেশন ও পরিবহন</span>
              </div>
            </button>

            {/* 4. Live Voice (gemini-3.8-live) */}
            <button
              onClick={() => onOpenAI('live')}
              className="p-3.5 rounded-2xl bg-gradient-to-br from-rose-50 to-rose-100 border border-rose-200 hover:border-rose-400 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold mb-2 shadow-xs group-hover:scale-105 transition-transform">
                <Radio className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <span className="text-xs font-bold text-rose-900 block leading-tight">লাইভ ভয়েস</span>
                <span className="text-[11px] text-rose-700 mt-0.5 block">মুখে সরাসরি কথা বলুন</span>
              </div>
            </button>
          </div>
        </div>

        {/* 4. STOCK ALERT SECTION (Highlighted on Dashboard) */}
        {stockAlerts.totalAlerts > 0 && (
          <div className="bg-white rounded-3xl p-5 border border-amber-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">
                    {lang === 'bn' ? 'স্টক অ্যালার্ট তালিকা' : 'Stock Alert Overview'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {lang === 'bn'
                      ? 'মজুদ শেষ বা কমে যাওয়া পার্টস অবিলম্বে রিস্টক করুন'
                      : 'Re-stock depleted or limited inventory items'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => onNavigate('stock_alerts')}
                className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 cursor-pointer"
              >
                <span>{lang === 'bn' ? 'সব অ্যালার্ট দেখুন' : 'View All'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {/* Show top 3 stock out / limited stock items */}
              {[...stockAlerts.stockOut, ...stockAlerts.limitedStock].slice(0, 3).map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-3"
                >
                  <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                    {item.frontPhoto ? (
                      <img src={item.frontPhoto} alt={item.name} className="w-full h-full object-cover" />
                    ) : (
                      <Package className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-800 truncate">
                        {item.brand} {item.modelNumber}
                      </span>
                      {item.stockQuantity === 0 ? (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-700 shrink-0">
                          🔴 Stock Out
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 shrink-0">
                          🟠 {item.stockQuantity} pcs
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">{item.name}</p>
                    <p className="text-[11px] font-medium text-slate-700 mt-1">
                      ক্রয়: {currency} {item.purchasePrice} | বিক্রয়: {currency} {item.retailPrice}
                    </p>
                  </div>
                  <button
                    onClick={() => onNavigate('products', { openStockAdd: item.id })}
                    className="px-2.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shrink-0 cursor-pointer shadow-xs"
                  >
                    + স্টক
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 11. DUE COLLECTION ALERT (Highlighted on Dashboard) */}
        {dueAlerts.length > 0 && (
          <div className="bg-white rounded-3xl p-5 border border-orange-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-orange-500 text-white flex items-center justify-center font-bold">
                  <BadgeAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">
                    {lang === 'bn' ? 'বাকি আদায়ের অ্যালার্ট' : 'Due Collection Alerts'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {lang === 'bn'
                      ? 'যেসব কাস্টমারের নিকট টাকা পাওনা রয়েছে সরাসরি কল বা মেসেজ করুন'
                      : 'Follow up with customers having outstanding dues'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => onNavigate('due_alerts')}
                className="text-xs font-bold text-orange-700 hover:text-orange-800 flex items-center gap-1 px-3 py-1.5 rounded-xl bg-orange-50 border border-orange-200 cursor-pointer"
              >
                <span>{lang === 'bn' ? 'সকল বাকি দেখুন' : 'View All'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {dueAlerts.slice(0, 3).map((alert) => (
                <div
                  key={alert.customer.id}
                  className="p-4 rounded-2xl border border-orange-100 bg-orange-50/40 flex items-center justify-between gap-3"
                >
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-slate-900 text-sm truncate">
                      {alert.customer.name}
                    </h4>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <Phone className="w-3 h-3" />
                      <span>{alert.customer.phone}</span>
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-xs font-extrabold text-orange-700 bg-white px-2 py-0.5 rounded-md border border-orange-200">
                        বাকি: {currency} {alert.dueAmount.toLocaleString()}
                      </span>
                      {alert.overdueDays > 0 && (
                        <span className="text-[10px] text-slate-500 font-medium">
                          {alert.overdueDays} দিন আগে
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <a
                      href={`tel:${alert.customer.phone}`}
                      className="p-2 rounded-xl bg-white border border-slate-200 text-blue-600 hover:bg-blue-50 transition-colors shadow-2xs"
                      title="Call"
                    >
                      <Phone className="w-4 h-4" />
                    </a>
                    <a
                      href={`https://wa.me/${alert.customer.phone.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-xl bg-white border border-slate-200 text-emerald-600 hover:bg-emerald-50 transition-colors shadow-2xs"
                      title="WhatsApp"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </a>
                    <button
                      onClick={() => onNavigate('due_alerts', { customerId: alert.customer.id })}
                      className="px-2.5 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs shadow-xs cursor-pointer"
                    >
                      {lang === 'bn' ? 'আদায়' : 'Collect'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Sales & Invoice History Quick Link Banner */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 flex items-center justify-between gap-4 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-slate-900 text-sm">
                {lang === 'bn' ? 'বিক্রয় ও ইনভয়েস হিস্টোরি' : 'Sales & Invoice History'}
              </h4>
              <p className="text-xs text-slate-500">
                {lang === 'bn'
                  ? 'সব বিক্রয় রেকর্ড দেখুন, প্রিন্ট করুন বা সংশোধন করুন'
                  : 'View, reprint or adjust past customer invoices'}
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('sales_history')}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <span>{lang === 'bn' ? 'ইনভয়েস তালিকা' : 'View Invoices'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Floating AI Assistant Trigger */}
        <div className="fixed bottom-20 right-4 sm:right-6 z-30">
          <button
            onClick={() => onOpenAI('chat')}
            className="flex items-center gap-2 py-3 px-4 rounded-full bg-gradient-to-r from-blue-600 via-indigo-600 to-indigo-700 text-white font-bold text-xs shadow-xl shadow-indigo-600/30 hover:scale-105 active:scale-95 transition-all cursor-pointer border border-white/20"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{lang === 'bn' ? 'এআই সহকারী' : 'AI Assistant'}</span>
          </button>
        </div>
      </main>
    </div>
  );
};
