import React from "react";
import { BookOpen, Music, Swords, Sparkles, ChevronLeft } from "lucide-react";
import { GenerationMode } from "../types";

interface DashboardProps {
  currentMode: GenerationMode;
  onSelectMode: (mode: GenerationMode) => void;
}

interface OptionItem {
  id: GenerationMode;
  titleUrdu: string;
  titleEn: string;
  subtitle: string;
  badge: string;
  icon: React.ReactNode;
  gradient: string;
  borderAccent: string;
}

export const Dashboard: React.FC<DashboardProps> = ({
  currentMode,
  onSelectMode
}) => {
  const options: OptionItem[] = [
    {
      id: "ghazal_shayari",
      titleUrdu: "غزل و شاعری",
      titleEn: "Ghazal & Shayari",
      subtitle: "۲ سطری شعر، ۴ سطری قطعہ، یا مکمل روایتی غزل تخلیق کریں",
      badge: "غزل و شعر",
      icon: <BookOpen className="w-6 h-6 text-amber-400" />,
      gradient: "from-emerald-950 via-stone-900 to-stone-950",
      borderAccent: "border-amber-500/40"
    },
    {
      id: "song_lyrics",
      titleUrdu: "نغمہ نگاری و ریپ",
      titleEn: "Song & Rap Lyrics",
      subtitle: "مکھڑا، انترہ اور کورس کے ساتھ صوفی، پاپ، کلاسیکل یا ریپ لیرکس",
      badge: "نغمہ و گیت",
      icon: <Music className="w-6 h-6 text-emerald-400" />,
      gradient: "from-stone-900 via-teal-950/50 to-stone-950",
      borderAccent: "border-teal-500/40"
    },
    {
      id: "bait_bazi",
      titleUrdu: "بیت بازی و مقابلہ",
      titleEn: "Poetry Competition (Bait Bazi)",
      subtitle: "مخصوص حرف (ن، م، ش وغیرہ) سے شروع ہونے والے فتح مند مقابلے کے اشعار",
      badge: "بیت بازی",
      icon: <Swords className="w-6 h-6 text-amber-300" />,
      gradient: "from-stone-900 via-amber-950/40 to-stone-950",
      borderAccent: "border-amber-600/40"
    },
    {
      id: "rhyme_meter",
      titleUrdu: "ردیف و قافیہ مددگار",
      titleEn: "Rhyme & Meter Helper",
      subtitle: "نامکمل شعر مکمل کریں اور موزوں ہم قافیہ الفاظ دریافت کریں",
      badge: "اصلاح و ردیف",
      icon: <Sparkles className="w-6 h-6 text-emerald-300" />,
      gradient: "from-stone-900 via-emerald-950/50 to-stone-950",
      borderAccent: "border-emerald-600/40"
    }
  ];

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3 px-1">
        <h2 className="text-sm font-semibold font-urdu-sans text-amber-200/90 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-amber-400" />
          شعبہ منتخب کیجیے (Choose Category):
        </h2>
        <span className="text-[11px] font-ui text-stone-400">4 Core AI Modes</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {options.map((opt) => {
          const isSelected = currentMode === opt.id;
          return (
            <button
              key={opt.id}
              onClick={() => onSelectMode(opt.id)}
              id={`mode-button-${opt.id}`}
              className={`group text-right p-4 rounded-2xl border transition-all duration-200 relative overflow-hidden bg-gradient-to-br ${opt.gradient} ${
                isSelected
                  ? `ring-2 ring-amber-400/80 shadow-lg shadow-emerald-950/60 ${opt.borderAccent}`
                  : "border-stone-800 hover:border-stone-700 hover:bg-stone-900/80"
              }`}
            >
              {/* Subtle top indicator bar */}
              {isSelected && (
                <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-amber-400 via-emerald-400 to-amber-500" />
              )}

              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="p-2.5 rounded-xl bg-stone-900/80 border border-stone-700/60 shadow-inner">
                  {opt.icon}
                </div>

                <span
                  className={`text-[11px] font-urdu-sans px-2 py-0.5 rounded-full border ${
                    isSelected
                      ? "bg-amber-500/20 border-amber-400/40 text-amber-300"
                      : "bg-stone-800/80 border-stone-700/60 text-stone-400"
                  }`}
                >
                  {opt.badge}
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold font-urdu-title text-amber-100 group-hover:text-amber-300 transition-colors flex items-center justify-between">
                  <span>{opt.titleUrdu}</span>
                  <ChevronLeft
                    className={`w-4 h-4 transition-transform text-amber-400 ${
                      isSelected ? "translate-x-1" : "opacity-40 group-hover:opacity-100"
                    }`}
                  />
                </h3>
                <p className="text-[11px] font-ui text-stone-400 tracking-wide font-medium mt-0.5">
                  {opt.titleEn}
                </p>
                <p className="text-xs font-urdu-sans text-stone-300/80 mt-1.5 leading-relaxed">
                  {opt.subtitle}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
