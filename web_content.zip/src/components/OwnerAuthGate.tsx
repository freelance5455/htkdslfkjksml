import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  KeyRound, 
  UserCheck, 
  Eye, 
  EyeOff, 
  Sparkles, 
  ArrowLeft, 
  ShieldAlert, 
  CheckCircle2, 
  Crown,
  LogOut,
  HelpCircle
} from 'lucide-react';
import { 
  verifyOwnerCredentials, 
  checkIsOwnerAuthenticated, 
  lockOwnerVault 
} from '../lib/ownerSecurity';
import { SecurityQuestionGate } from './SecurityQuestionGate';

interface OwnerAuthGateProps {
  children: React.ReactNode;
  onExitToSanctuary: () => void;
}

export const OwnerAuthGate: React.FC<OwnerAuthGateProps> = ({
  children,
  onExitToSanctuary,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => checkIsOwnerAuthenticated());
  const [authStep, setAuthStep] = useState<'credentials' | 'security_questions'>('credentials');
  
  const [ownerName, setOwnerName] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [loginSuccess, setLoginSuccess] = useState<boolean>(false);

  const handleCredentialsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsSubmitting(true);

    setTimeout(() => {
      const isValid = verifyOwnerCredentials(ownerName, password);
      if (isValid) {
        if (typeof navigator !== 'undefined' && navigator.vibrate) {
          navigator.vibrate([30, 50, 30]);
        }
        setIsSubmitting(false);
        setAuthStep('security_questions');
      } else {
        // Log unauthorized attempt into secure local storage
        try {
          const attempt = {
            id: `ATTEMPT-${Date.now()}`,
            timestamp: new Date().toISOString(),
            gate: 'Owner Tab Credentials Gate',
            details: `Unauthorized login attempt with identifier: "${ownerName.slice(0, 15)}"`,
            ipNode: '127.0.0.1:3000',
            userAgent: typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 50) : 'Unknown',
            status: 'DENIED'
          };
          const logs = JSON.parse(localStorage.getItem('jm_owner_unauthorized_attempts_log') || '[]');
          logs.unshift(attempt);
          localStorage.setItem('jm_owner_unauthorized_attempts_log', JSON.stringify(logs.slice(0, 50)));
          window.dispatchEvent(new CustomEvent('jm_security_audit_updated'));
        } catch (err) {}

        setErrorMessage('Access Denied: Invalid Owner Name or Sacred Password. Please check your credentials.');
        setIsSubmitting(false);
      }
    }, 400);
  };

  const handleLogout = () => {
    lockOwnerVault();
    setIsAuthenticated(false);
    setAuthStep('credentials');
    setOwnerName('');
    setPassword('');
    onExitToSanctuary();
  };

  if (isAuthenticated) {
    return (
      <div className="space-y-4">
        {/* Prophet Active Session Header Bar */}
        <div className="bg-gradient-to-r from-amber-950/80 via-slate-950 to-amber-950/80 border border-amber-500/40 rounded-2xl p-3.5 shadow-xl backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between gap-3 text-left">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-md">
              <Crown className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h4 className="text-xs font-bold font-serif text-amber-100 uppercase tracking-wider">
                  Prophet JUHNKRIX SYNVAGORD
                </h4>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-mono bg-amber-500/20 text-amber-300 border border-amber-400/30 flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Authenticated Vault Active (2-Step Security Verified)</span>
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Private Admin Console unlocked via Secure Domain Routing.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
            <button
              onClick={handleLogout}
              className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-rose-950/70 text-slate-300 hover:text-rose-300 border border-slate-700 hover:border-rose-500/40 text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-md active:scale-95"
              title="Lock Owner Vault and return to sanctuary"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Lock Vault & Exit</span>
            </button>
          </div>
        </div>

        {/* The Full Owner Dashboard */}
        {children}
      </div>
    );
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-slate-950/95 border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-2xl text-left space-y-6 relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header Badge */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 via-amber-600/10 to-transparent border border-amber-400/40 flex items-center justify-center mx-auto text-amber-400 shadow-xl shadow-amber-500/10">
            <ShieldCheck className="w-8 h-8 text-amber-400" />
          </div>
          <div className="space-y-1">
            <span className="px-3 py-0.5 rounded-full text-[10px] font-mono uppercase tracking-widest bg-amber-500/20 text-amber-300 border border-amber-400/30">
              {authStep === 'credentials' ? 'Step 1: Owner Credentials' : 'Step 2: Security Questions'}
            </span>
            <h2 className="text-xl sm:text-2xl font-bold font-serif text-amber-100">
              JUHNKRIX MUSIKA
            </h2>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              {authStep === 'credentials' 
                ? 'Private administrative sanctuary portal for Prophet JUHNKRIX SYNVAGORD.' 
                : 'Second Layer Security: Answer your sacred profile questions to unlock the vault.'}
            </p>
          </div>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="p-3.5 rounded-2xl bg-rose-950/60 border border-rose-500/50 flex items-start space-x-2.5 text-rose-200 text-xs animate-shake">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Success Animation */}
        {loginSuccess && (
          <div className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/50 flex items-center space-x-2.5 text-emerald-200 text-xs animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-bold">Security Verification Passed! Unlocking Owner Sanctuary Vault...</span>
          </div>
        )}

        {/* STEP 1: CREDENTIALS */}
        {authStep === 'credentials' && (
          <form onSubmit={handleCredentialsSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-amber-300/90 uppercase tracking-wider flex items-center space-x-1.5">
                <UserCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>Owner Name</span>
              </label>
              <input
                type="text"
                required
                autoFocus
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                placeholder="Please enter your name"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-900/90 border border-amber-500/30 text-amber-100 placeholder-slate-500 text-sm focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/25 transition-all font-mono"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-amber-300/90 uppercase tracking-wider flex items-center space-x-1.5">
                <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                <span>Owner Password</span>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••••••"
                  className="w-full px-4 py-2.5 pr-11 rounded-xl bg-slate-900/90 border border-amber-500/30 text-amber-100 placeholder-slate-500 text-sm focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/25 transition-all font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-amber-300 p-1 transition-colors"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="pt-2 space-y-2.5">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/20 hover:brightness-110 active:scale-[0.99] transition-all flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? (
                  <span>Verifying Step 1 Credentials...</span>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>Proceed to Security Questions</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={onExitToSanctuary}
                className="w-full py-2.5 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs font-medium border border-slate-800 transition-colors flex items-center justify-center space-x-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Public Sanctuary</span>
              </button>
            </div>
          </form>
        )}

        {/* STEP 2: SECURITY QUESTIONS */}
        {authStep === 'security_questions' && (
          <SecurityQuestionGate 
            onSuccess={() => {
              if (typeof navigator !== 'undefined' && navigator.vibrate) {
                navigator.vibrate([30, 50, 30, 50, 80]);
              }
              setLoginSuccess(true);
              setTimeout(() => {
                setIsAuthenticated(true);
                setIsSubmitting(false);
              }, 600);
            }}
            onBack={() => setAuthStep('credentials')}
          />
        )}

        <div className="pt-2 border-t border-amber-500/10 text-center">
          <p className="text-[10px] text-slate-500 font-mono">
            Proprietary Prophetic Gospel Architecture &copy; JUHNKRIX MUSIKA
          </p>
        </div>
      </div>
    </div>
  );
};
