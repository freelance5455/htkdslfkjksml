import { useApp } from "@/lib/store";
import { BUTTONS } from "@/lib/defaults";
import { Btn, Card, Slider, Toggle } from "./UI";
import LayoutEditor from "./LayoutEditor";

export default function TouchPanel() {
  const { settings, set, layout, setLayout, enabledButtons, toggleButton, resetLayout } = useApp();

  return (
    <div className="space-y-4">
      <Card
        title="Overlay de toque"
        icon="🎮"
        desc="Ative, desative e redimensione os botões virtuais do seu touch."
      >
        <div className="grid grid-cols-2 gap-2">
          {BUTTONS.map((b) => (
            <Toggle
              key={b.id}
              icon={b.icon}
              label={b.label}
              checked={enabledButtons.includes(b.id)}
              onChange={() => toggleButton(b.id)}
            />
          ))}
        </div>
      </Card>

      <Card title="Tamanho e opacidade" icon="📐" desc="Ajustes que combinam com a sua ergonomia de toque.">
        <div className="space-y-4">
          <Slider
            label="Tamanho dos botões"
            value={settings.buttonSize}
            min={60}
            max={180}
            onChange={(v) => set("buttonSize", v)}
            accent="lime"
          />
          <Slider
            label="Tamanho do joystick"
            value={settings.joystickSize}
            min={60}
            max={180}
            onChange={(v) => set("joystickSize", v)}
            accent="cyan"
          />
          <Slider
            label="Opacidade do overlay"
            value={settings.opacity}
            min={20}
            max={100}
            onChange={(v) => set("opacity", v)}
            accent="amber"
          />
        </div>
      </Card>

      <Card
        title="Posicionamento"
        icon="📲"
        desc="Arraste os elementos no preview para definir onde cada botão fica na tela."
        action={
          <Btn variant="ghost" onClick={resetLayout}>
            Padrão
          </Btn>
        }
      >
        <LayoutEditor
          layout={layout}
          setLayout={setLayout}
          enabled={enabledButtons}
          buttonSize={settings.buttonSize}
          joystickSize={settings.joystickSize}
          opacity={settings.opacity}
        />
        <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
          As posições são salvas automaticamente no seu dispositivo e reaproveitadas no Treino.
        </p>
      </Card>
    </div>
  );
}
