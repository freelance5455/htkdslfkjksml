import React, { useMemo, useState } from 'react';
import { Volume2, VolumeX, Pause, Play, Eye, Cpu, Map as MapIcon } from 'lucide-react';
import {
  AUTOMATED_LEVELS,
  CameraMode,
  GamePhase,
  HYPERCARS,
  LevelConfig,
  LiveTelemetry,
  NetworkMode,
  VehicleCustomization,
} from '../types/game';

interface TopTelemetryBarProps {
  gamePhase: GamePhase;
  levelIndex: number;
  customization: VehicleCustomization;
  telemetry: LiveTelemetry;
  networkMode: NetworkMode;
  roomCode: string;
  remotePeerCount: number;
  cameraMode: CameraMode;
  autoDrive: boolean;
  isMuted: boolean;
  onToggleMute: () => void;
  onCycleCamera: () => void;
  onToggleAutoDrive: () => void;
  onTogglePause: () => void;
  onReturnToTitle: () => void;
}

function formatRaceTime(ms: number): string {
  const totalSec = Math.max(0, ms / 1000);
  const mins = Math.floor(totalSec / 60);
  const secs = Math.floor(totalSec % 60);
  const tenths = Math.floor((totalSec * 10) % 10);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${tenths}`;
}

/**
 * Computes a normalized 2D SVG polyline & sampling lookup for a circuit's waypoints
 */
function buildCircuitMiniMapGeometry(level: LevelConfig, width = 136, height = 94, pad = 12) {
  const pts = level.waypoints.map(([x, , z]) => ({ x, z }));
  const n = pts.length;
  const sampled: Array<{ x: number; z: number }> = [];
  const totalSamples = 80;

  for (let s = 0; s < totalSamples; s++) {
    const t = (s / totalSamples) * n;
    const idx = Math.floor(t);
    const frac = t - idx;

    const p0 = pts[(idx - 1 + n) % n];
    const p1 = pts[idx % n];
    const p2 = pts[(idx + 1) % n];
    const p3 = pts[(idx + 2) % n];

    // Catmull-Rom spline interpolation in 2D (X, Z)
    const f2 = frac * frac;
    const f3 = f2 * frac;
    const x =
      0.5 *
      (2 * p1.x +
        (-p0.x + p2.x) * frac +
        (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * f2 +
        (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * f3);
    const z =
      0.5 *
      (2 * p1.z +
        (-p0.z + p2.z) * frac +
        (2 * p0.z - 5 * p1.z + 4 * p2.z - p3.z) * f2 +
        (-p0.z + 3 * p1.z - 3 * p2.z + p3.z) * f3);

    sampled.push({ x, z });
  }

  let minX = Infinity;
  let maxX = -Infinity;
  let minZ = Infinity;
  let maxZ = -Infinity;
  for (const p of sampled) {
    if (p.x < minX) minX = p.x;
    if (p.x > maxX) maxX = p.x;
    if (p.z < minZ) minZ = p.z;
    if (p.z > maxZ) maxZ = p.z;
  }

  const spanX = Math.max(1, maxX - minX);
  const spanZ = Math.max(1, maxZ - minZ);
  const drawW = width - pad * 2;
  const drawH = height - pad * 2;
  const scale = Math.min(drawW / spanX, drawH / spanZ);
  const offsetX = pad + (drawW - spanX * scale) * 0.5;
  const offsetY = pad + (drawH - spanZ * scale) * 0.5;

  const normPoints = sampled.map((p) => ({
    x: Number((offsetX + (p.x - minX) * scale).toFixed(1)),
    y: Number((offsetY + (p.z - minZ) * scale).toFixed(1)),
  }));

  const pathData =
    normPoints.map((pt, i) => `${i === 0 ? 'M' : 'L'}${pt.x},${pt.y}`).join(' ') + ' Z';

  function samplePointAtProgress(progress: number) {
    const wrapped = ((progress % 1) + 1) % 1;
    const fIdx = wrapped * normPoints.length;
    const i0 = Math.floor(fIdx) % normPoints.length;
    const i1 = (i0 + 1) % normPoints.length;
    const alpha = fIdx - Math.floor(fIdx);
    return {
      x: normPoints[i0].x + (normPoints[i1].x - normPoints[i0].x) * alpha,
      y: normPoints[i0].y + (normPoints[i1].y - normPoints[i0].y) * alpha,
    };
  }

  return {
    pathData,
    startPt: normPoints[0] || { x: width / 2, y: height / 2 },
    samplePointAtProgress,
  };
}

export const TopTelemetryBar: React.FC<TopTelemetryBarProps> = ({
  gamePhase,
  levelIndex,
  customization,
  telemetry,
  networkMode,
  roomCode,
  remotePeerCount,
  cameraMode,
  autoDrive,
  isMuted,
  onToggleMute,
  onCycleCamera,
  onToggleAutoDrive,
  onTogglePause,
  onReturnToTitle,
}) => {
  const [showMiniMap, setShowMiniMap] = useState<boolean>(true);
  const level = AUTOMATED_LEVELS[levelIndex] || AUTOMATED_LEVELS[0];
  const car = HYPERCARS.find((c) => c.id === customization.carId) || HYPERCARS[0];
  const rpmPercent = Math.min(100, Math.max(8, Math.round((telemetry.rpm / 9000) * 100)));

  // Compact mode automatically activates during active racing / countdown
  const isCompactRaceMode = gamePhase === 'playing' || gamePhase === 'countdown';

  const mapGeo = useMemo(() => buildCircuitMiniMapGeometry(level, 144, 98, 12), [level]);
  const p1MapPos = mapGeo.samplePointAtProgress(telemetry.trackProgress || 0);

  return (
    <>
      {/* Top Telemetry Bar: Compact Pill Strip during Race, Full Bar on Title/Pause */}
      <div
        className={`fixed top-3 left-1/2 -translate-x-1/2 z-20 pointer-events-none transition-all duration-200 ${
          isCompactRaceMode ? 'w-[min(670px,92vw)]' : 'w-[min(920px,94vw)]'
        }`}
      >
        <div
          className={`pointer-events-auto flex flex-wrap items-center justify-between gap-2 rounded-xl bg-[#090d16]/90 border border-white/12 shadow-2xl transition-all duration-200 ${
            isCompactRaceMode ? 'px-3 py-1.5' : 'px-4 py-2.5'
          }`}
        >
          {/* Left: Spec & Level Identity (Condensed when race starts) */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onReturnToTitle}
              className="text-left group focus:outline-none cursor-pointer"
              title="Return to Title Showroom"
            >
              <div
                className={`font-display font-bold tracking-wider text-white group-hover:text-amber-400 transition-colors whitespace-nowrap ${
                  isCompactRaceMode ? 'text-xs' : 'text-sm'
                }`}
              >
                APEX HORIZON
              </div>
              {!isCompactRaceMode && (
                <div className="text-[11px] text-slate-400 whitespace-nowrap">
                  {level.name} <span aria-hidden="true">·</span> {car.name}
                </div>
              )}
            </button>

            {!isCompactRaceMode && (
              <>
                <span className="hidden sm:inline-block h-6 w-px bg-white/10" />
                <div className="hidden sm:flex items-center gap-2 text-xs text-slate-300 whitespace-nowrap">
                  <span className="text-amber-400 font-medium">
                    {networkMode === 'multiplayer' ? `Room ${roomCode}` : 'Offline Grid'}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-tabular">
                    {networkMode === 'multiplayer'
                      ? `${remotePeerCount + 1} Connected`
                      : `${telemetry.totalRacers} Cars`}
                  </span>
                </div>
              </>
            )}
          </div>

          {/* Center: Live Racing Telemetry Cluster */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Position, Lap & Time */}
            <div className="flex items-center gap-2.5 text-xs">
              <div>
                <span className="text-slate-400 mr-1 text-[10px]">POS</span>
                <span
                  className={`font-display font-bold text-amber-400 font-mono-tabular ${
                    isCompactRaceMode ? 'text-sm' : 'text-base'
                  }`}
                >
                  {telemetry.position}
                </span>
                <span className="text-slate-400 font-mono-tabular text-[11px]">
                  /{telemetry.totalRacers}
                </span>
              </div>
              <span className="text-slate-600" aria-hidden="true">
                /
              </span>
              <div>
                <span className="text-slate-400 mr-1 text-[10px]">LAP</span>
                <span
                  className={`font-display font-bold text-white font-mono-tabular ${
                    isCompactRaceMode ? 'text-sm' : 'text-base'
                  }`}
                >
                  {telemetry.lap}
                </span>
                <span className="text-slate-400 font-mono-tabular text-[11px]">
                  /{telemetry.totalLaps}
                </span>
              </div>
              <span className="hidden sm:inline text-slate-600" aria-hidden="true">
                /
              </span>
              <div className="hidden sm:block">
                <span className="text-slate-400 mr-1 text-[10px]">TIME</span>
                <span className="font-mono-tabular text-xs font-semibold text-slate-100">
                  {formatRaceTime(telemetry.elapsedMs)}
                </span>
              </div>
            </div>

            {/* Digital Speedometer, Gear & Nitro Bar */}
            <div className="flex items-center gap-2.5 pl-2.5 border-l border-white/10">
              <div className="text-right">
                <div className="flex items-baseline gap-1 justify-end">
                  <span
                    className={`font-display font-bold tracking-tight text-white font-mono-tabular ${
                      isCompactRaceMode ? 'text-lg' : 'text-xl sm:text-2xl'
                    }`}
                  >
                    {telemetry.speedKmh}
                  </span>
                  <span className="text-[9px] font-semibold text-slate-400">KM/H</span>
                </div>
                <div
                  className={`${
                    isCompactRaceMode ? 'w-16 h-1' : 'w-24 h-1.5'
                  } bg-slate-800 rounded-sm overflow-hidden mt-0.5`}
                >
                  <div
                    className={`h-full transition-transform duration-75 origin-left ${
                      rpmPercent > 85
                        ? 'bg-red-500'
                        : rpmPercent > 65
                        ? 'bg-amber-400'
                        : 'bg-cyan-400'
                    }`}
                    style={{ transform: `scaleX(${rpmPercent / 100})` }}
                  />
                </div>
              </div>

              {/* Gear Readout */}
              <div
                className={`${
                  isCompactRaceMode ? 'w-6 h-6' : 'w-8 h-8'
                } rounded-lg bg-slate-900 border border-white/15 flex flex-col items-center justify-center`}
              >
                {!isCompactRaceMode && (
                  <span className="text-[8px] text-slate-400 leading-none">GEAR</span>
                )}
                <span
                  className={`font-display font-bold text-amber-400 font-mono-tabular leading-tight ${
                    isCompactRaceMode ? 'text-xs' : 'text-sm'
                  }`}
                >
                  {telemetry.speedKmh < 2 ? 'N' : telemetry.gear}
                </span>
              </div>

              {/* Nitro Gauge */}
              <div className={`hidden sm:flex flex-col ${isCompactRaceMode ? 'w-14' : 'w-20'}`}>
                <div className="flex justify-between text-[9px] text-slate-400 mb-0.5">
                  <span className={telemetry.isNitroActive ? 'text-cyan-400 font-semibold' : ''}>
                    NITRO
                  </span>
                  <span className="font-mono-tabular text-slate-200">{telemetry.nitroAmount}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-sm overflow-hidden">
                  <div
                    className="h-full bg-cyan-400 transition-transform duration-75 origin-left"
                    style={{ transform: `scaleX(${telemetry.nitroAmount / 100})` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right: Quick Action Affordances */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setShowMiniMap((prev) => !prev)}
              className={`px-2 py-1 rounded-lg text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer whitespace-nowrap ${
                showMiniMap
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                  : 'bg-slate-800/90 text-slate-400 hover:text-white'
              }`}
              title="Toggle Circuit Radar Mini-Map"
            >
              <MapIcon className="w-3.5 h-3.5" />
              {!isCompactRaceMode && <span className="hidden md:inline">Map</span>}
            </button>

            <button
              onClick={onToggleAutoDrive}
              className={`px-2 py-1 rounded-lg text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer whitespace-nowrap ${
                autoDrive
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'bg-slate-800/90 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
              title="Toggle Automated AI Pilot"
            >
              <Cpu className="w-3.5 h-3.5" />
              {!isCompactRaceMode && (
                <span className="hidden md:inline">{autoDrive ? 'AI On' : 'Manual'}</span>
              )}
            </button>

            <button
              onClick={onCycleCamera}
              className="px-2 py-1 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer whitespace-nowrap"
              title="Cycle Camera View (C)"
            >
              <Eye className="w-3.5 h-3.5 text-cyan-400" />
              {!isCompactRaceMode && (
                <span className="hidden sm:inline capitalize">{cameraMode}</span>
              )}
            </button>

            <button
              onClick={onToggleMute}
              className="p-1 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
              title={isMuted ? 'Unmute Audio (M)' : 'Mute Audio (M)'}
              aria-label={isMuted ? 'Unmute Audio' : 'Mute Audio'}
            >
              {isMuted ? (
                <VolumeX className="w-3.5 h-3.5 text-red-400" />
              ) : (
                <Volume2 className="w-3.5 h-3.5 text-slate-200" />
              )}
            </button>

            {(gamePhase === 'playing' || gamePhase === 'paused') && (
              <button
                onClick={onTogglePause}
                className="px-2 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer whitespace-nowrap"
                title="Pause / Resume Race (Esc)"
              >
                {gamePhase === 'paused' ? (
                  <>
                    <Play className="w-3 h-3 fill-current" />
                    <span>Resume</span>
                  </>
                ) : (
                  <>
                    <Pause className="w-3 h-3" />
                    <span>Pause</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Live GPS Circuit Radar Mini-Map (Top-Right Corner) */}
      {showMiniMap && (
        <aside
          aria-label="Live Circuit Map"
          className="fixed top-3 right-3 z-20 pointer-events-auto rounded-xl bg-[#090d16]/90 border border-white/12 px-2.5 py-2 shadow-2xl hidden sm:flex flex-col items-center"
        >
          <div className="w-full flex items-center justify-between text-[10px] text-slate-300 mb-1 px-0.5">
            <span className="font-semibold text-white truncate max-w-[95px]">
              {level.name.replace(/^\d+\.\s*/, '')}
            </span>
            <span className="font-mono-tabular text-amber-400">
              {Math.round((telemetry.trackProgress || 0) * 100)}%
            </span>
          </div>

          <svg
            width="144"
            height="98"
            viewBox="0 0 144 98"
            className="overflow-visible"
            role="img"
            aria-label={`Track map for ${level.name}`}
          >
            {/* Outer Track Border */}
            <path
              d={mapGeo.pathData}
              fill="none"
              stroke="#0f172a"
              strokeWidth="7"
              strokeLinejoin="round"
              strokeLinecap="round"
            />
            {/* Inner Asphalt Ribbon */}
            <path
              d={mapGeo.pathData}
              fill="none"
              stroke="#475569"
              strokeWidth="3.5"
              strokeLinejoin="round"
              strokeLinecap="round"
            />

            {/* Start / Finish Checkered Line Marker */}
            <circle
              cx={mapGeo.startPt.x}
              cy={mapGeo.startPt.y}
              r="3.8"
              fill="#F8FAFC"
              stroke="#090D16"
              strokeWidth="1.5"
            />

            {/* Rival AI & Online Peer Dots */}
            {telemetry.standings
              .filter((s) => s.id !== 'local-p1')
              .map((racer) => {
                const pt = mapGeo.samplePointAtProgress(racer.progress % 1);
                return (
                  <circle
                    key={racer.id}
                    cx={pt.x}
                    cy={pt.y}
                    r="3.2"
                    fill={racer.paintHex || '#38bdf8'}
                    stroke="#090d16"
                    strokeWidth="1"
                  />
                );
              })}

            {/* Local Player (P1) Highlight Beacon */}
            <circle
              cx={p1MapPos.x}
              cy={p1MapPos.y}
              r="6.5"
              fill="none"
              stroke="#F59E0B"
              strokeWidth="1.5"
              strokeOpacity="0.7"
            />
            <circle
              cx={p1MapPos.x}
              cy={p1MapPos.y}
              r="4.2"
              fill={customization.paintHex || '#F59E0B'}
              stroke="#FFFFFF"
              strokeWidth="1.5"
            />
          </svg>
        </aside>
      )}
    </>
  );
};
