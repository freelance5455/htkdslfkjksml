import React, { useState } from 'react';
import { WORLDS } from '../data/levels';
import { SaveData } from '../types/game';
import { X, Star, Lock } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface LevelSelectModalProps {
  saveData: SaveData;
  onSelectLevel: (levelNum: number) => void;
  onClose: () => void;
}

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  saveData,
  onSelectLevel,
  onClose
}) => {
  const [selectedWorldIdx, setSelectedWorldIdx] = useState<number>(1);

  // Determine levels belonging to selected world
  let startLevel = 1;
  let endLevel = 10;
  if (selectedWorldIdx === 2) {
    startLevel = 11;
    endLevel = 25;
  } else if (selectedWorldIdx === 3) {
    startLevel = 26;
    endLevel = 50;
  } else if (selectedWorldIdx === 4) {
    startLevel = 51;
    endLevel = 75;
  } else if (selectedWorldIdx === 5) {
    startLevel = 76;
    endLevel = 100;
  }

  const levelNumbers: number[] = [];
  for (let i = startLevel; i <= endLevel; i++) {
    levelNumbers.push(i);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md select-none animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              SELECT LEVEL
            </h2>
            <p className="text-xs text-slate-400">
              Classic campaign · 5 Worlds · 100 Puzzles
            </p>
          </div>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onClose();
            }}
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* World Tabs */}
        <div className="flex items-center gap-1.5 py-3 overflow-x-auto no-scrollbar">
          {WORLDS.map((w) => {
            const isSelected = selectedWorldIdx === w.index;
            return (
              <button
                key={w.index}
                onClick={() => {
                  soundEngine.playNodeSelect(w.index);
                  setSelectedWorldIdx(w.index);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                  isSelected
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                    : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                W{w.index}: {w.title}
              </button>
            );
          })}
        </div>

        {/* Level Tiles Grid */}
        <div className="flex-1 overflow-y-auto py-3 pr-1 grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 gap-2.5">
          {levelNumbers.map((num) => {
            const progress = saveData.levelProgress[num];
            const isCompleted = progress?.completed;
            const stars = progress?.stars || 0;
            // Level 1 is always unlocked; other levels unlocked if previous level completed
            const isUnlocked = num === 1 || Boolean(saveData.levelProgress[num - 1]?.completed);

            return (
              <button
                key={num}
                onClick={() => {
                  if (isUnlocked) {
                    soundEngine.playNodeSelect(2);
                    onSelectLevel(num);
                  }
                }}
                disabled={!isUnlocked}
                className={`aspect-square rounded-2xl flex flex-col items-center justify-center p-2 border transition-all ${
                  !isUnlocked
                    ? 'bg-slate-950/40 border-slate-800/40 text-slate-600 cursor-not-allowed'
                    : isCompleted
                    ? 'bg-slate-800/90 border-cyan-500/30 hover:border-cyan-400 text-white shadow-md hover:scale-105 active:scale-95'
                    : 'bg-slate-900 border-slate-700 hover:border-slate-500 text-white hover:scale-105 active:scale-95'
                }`}
              >
                {!isUnlocked ? (
                  <Lock className="w-5 h-5 text-slate-600 mb-1" />
                ) : (
                  <span className="font-mono text-base font-black tracking-tight mb-1">
                    {num}
                  </span>
                )}

                {/* Stars display */}
                {isUnlocked && (
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3].map((s) => (
                      <Star
                        key={s}
                        className={`w-2.5 h-2.5 ${
                          s <= stars
                            ? 'fill-amber-400 text-yellow-300'
                            : 'fill-slate-800 text-slate-700'
                        }`}
                      />
                    ))}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
