import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  X,
  Star,
  Lock,
  Trophy,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Infinity as InfinityIcon,
  Search,
  Zap,
} from 'lucide-react';
import { LevelProgress } from '../types/game';
import { sound } from '../utils/audio';
import { AdMobBanner } from './AdMobBanner';

interface LevelSelectModalProps {
  unlockedLevel: number;
  levelProgress: Record<number, LevelProgress>;
  currentPlayingLevel: number;
  onSelectLevel: (level: number) => void;
  onClose: () => void;
}

const PAGE_SIZE = 40;

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  unlockedLevel,
  levelProgress,
  currentPlayingLevel,
  onSelectLevel,
  onClose,
}) => {
  // Automatically open page of current active/unlocked level
  const targetLevel = currentPlayingLevel || unlockedLevel || 1;
  const initialPage = Math.floor((targetLevel - 1) / PAGE_SIZE);
  const [currentPage, setCurrentPage] = useState(initialPage);
  const [searchLevelInput, setSearchLevelInput] = useState('');

  const startLevel = currentPage * PAGE_SIZE + 1;
  const endLevel = (currentPage + 1) * PAGE_SIZE;
  const isUnlimitedPage = startLevel > 200;

  // Total stars collected
  const totalStars = (Object.values(levelProgress) as LevelProgress[]).reduce(
    (acc, curr) => acc + (curr?.stars || 0),
    0
  );

  const handleJumpToLevel = (lvl: number) => {
    if (lvl < 1) lvl = 1;
    const targetPage = Math.floor((lvl - 1) / PAGE_SIZE);
    setCurrentPage(targetPage);
    sound.playClick();
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(searchLevelInput.trim(), 10);
    if (!isNaN(parsed) && parsed >= 1) {
      handleJumpToLevel(parsed);
      setSearchLevelInput('');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 select-none">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="crystal-card w-full max-w-md h-[92vh] rounded-3xl p-4 flex flex-col shadow-[0_0_60px_rgba(0,0,0,0.7)] relative overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-2.5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-400 drop-shadow-[0_0_6px_rgba(250,204,21,0.8)]" />
            <h2 className="text-lg font-black text-white tracking-wide flex items-center gap-1.5">
              <span>SELECT LEVEL</span>
              <span className="text-[10px] text-fuchsia-400 bg-fuchsia-950/80 px-2 py-0.5 rounded-full border border-fuchsia-500/40 flex items-center gap-1">
                <InfinityIcon className="w-3 h-3" />
                <span>Endless (1–10,000+)</span>
              </span>
            </h2>
          </div>

          <div className="flex items-center gap-2">
            {/* Total Stars Pill */}
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-yellow-500/20 border border-yellow-500/50 text-yellow-400 text-xs font-black shadow-[0_0_10px_rgba(250,204,21,0.3)]">
              <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
              <span>{totalStars}</span>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="crystal-button p-1.5 rounded-full text-slate-300 hover:text-white border-white/10 active:scale-95"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Range Selector Tabs: 1-200, 201-1000, 1001-5000, 5001-10000+ */}
        <div className="grid grid-cols-4 gap-1 my-2">
          <button
            onClick={() => handleJumpToLevel(1)}
            className={`py-1.5 px-1 rounded-xl text-[10.5px] font-black transition-all text-center ${
              currentPage <= 4
                ? 'bg-cyan-500/25 border border-cyan-400/70 text-cyan-200 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                : 'bg-slate-900/50 border border-white/5 text-slate-400 hover:text-slate-200'
            }`}
          >
            1–200
          </button>
          <button
            onClick={() => handleJumpToLevel(201)}
            className={`py-1.5 px-1 rounded-xl text-[10.5px] font-black transition-all text-center ${
              currentPage >= 5 && currentPage <= 24
                ? 'bg-fuchsia-500/30 border border-fuchsia-400/70 text-fuchsia-200 shadow-[0_0_12px_rgba(217,70,239,0.3)]'
                : 'bg-slate-900/50 border border-white/5 text-slate-400 hover:text-slate-200'
            }`}
          >
            201–1K
          </button>
          <button
            onClick={() => handleJumpToLevel(1001)}
            className={`py-1.5 px-1 rounded-xl text-[10.5px] font-black transition-all text-center ${
              currentPage >= 25 && currentPage <= 124
                ? 'bg-amber-500/30 border border-amber-400/70 text-amber-200 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                : 'bg-slate-900/50 border border-white/5 text-slate-400 hover:text-slate-200'
            }`}
          >
            1K–5K
          </button>
          <button
            onClick={() => handleJumpToLevel(5001)}
            className={`py-1.5 px-1 rounded-xl text-[10.5px] font-black transition-all text-center ${
              currentPage >= 125
                ? 'bg-emerald-500/30 border border-emerald-400/70 text-emerald-200 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                : 'bg-slate-900/50 border border-white/5 text-slate-400 hover:text-slate-200'
            }`}
          >
            5K–10K+
          </button>
        </div>

        {/* Search / Jump to Specific Level Direct Input */}
        <form onSubmit={handleSearchSubmit} className="flex items-center gap-1.5 mb-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="number"
              min="1"
              max="999999"
              value={searchLevelInput}
              onChange={(e) => setSearchLevelInput(e.target.value)}
              placeholder="Jump to Level (e.g. 500, 2500, 8000...)"
              className="w-full bg-slate-950/60 border border-white/10 rounded-xl pl-8 pr-2.5 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400/60"
            />
          </div>
          <button
            type="submit"
            className="crystal-button px-3 py-1.5 rounded-xl text-xs font-black text-cyan-300 border-cyan-500/40 hover:border-cyan-400 active:scale-95 transition-all"
          >
            Go
          </button>
        </form>

        {/* Page Switcher with Fast Skip (+10, -10) and Infinite Next */}
        <div className="flex items-center justify-between mb-2 px-1">
          <div className="flex items-center gap-1">
            <button
              disabled={currentPage < 10}
              onClick={() => {
                sound.playClick();
                setCurrentPage((p) => Math.max(0, p - 10));
              }}
              title="Jump back 10 pages (-400 levels)"
              className="crystal-button p-1.5 rounded-xl text-slate-300 disabled:opacity-20 active:scale-95 transition-all"
            >
              <ChevronsLeft className="w-3.5 h-3.5" />
            </button>
            <button
              disabled={currentPage === 0}
              onClick={() => {
                sound.playClick();
                setCurrentPage((p) => Math.max(0, p - 1));
              }}
              className="crystal-button p-1.5 rounded-xl text-slate-200 disabled:opacity-20 active:scale-95 transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            {isUnlimitedPage && (
              <InfinityIcon className="w-3.5 h-3.5 text-fuchsia-400 animate-pulse" />
            )}
            <span
              className={`text-[11px] font-black uppercase tracking-wider px-3 py-1 rounded-full border ${
                isUnlimitedPage
                  ? 'text-fuchsia-300 bg-fuchsia-950/70 border-fuchsia-500/40 shadow-[0_0_10px_rgba(217,70,239,0.3)]'
                  : 'text-cyan-300 bg-cyan-950/60 border-cyan-500/30'
              }`}
            >
              {isUnlimitedPage
                ? `Unlimited ${startLevel} – ${endLevel}`
                : `Levels ${startLevel} – ${endLevel}`}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => {
                sound.playClick();
                setCurrentPage((p) => p + 1);
              }}
              className="crystal-button p-1.5 rounded-xl text-slate-200 active:scale-95 transition-all"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setCurrentPage((p) => p + 10);
              }}
              title="Jump forward 10 pages (+400 levels)"
              className="crystal-button p-1.5 rounded-xl text-slate-300 active:scale-95 transition-all"
            >
              <ChevronsRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 40 Levels Grid */}
        <div className="flex-1 overflow-y-auto grid grid-cols-5 gap-2 p-1 custom-scrollbar">
          {Array.from({ length: PAGE_SIZE }, (_, idx) => {
            const levelNum = startLevel + idx;
            const isUnlocked = levelNum <= unlockedLevel;
            const isPlaying = levelNum === currentPlayingLevel;
            const progress = levelProgress[levelNum];
            const stars = progress?.stars || 0;
            const isMilestone = levelNum % 50 === 0 || levelNum === 200 || levelNum === 500 || levelNum === 1000 || levelNum === 5000 || levelNum === 8000;
            const isUnlimited = levelNum > 200;

            return (
              <button
                key={levelNum}
                disabled={!isUnlocked}
                onClick={() => {
                  sound.playClick();
                  onSelectLevel(levelNum);
                }}
                className={`relative aspect-square rounded-2xl border flex flex-col items-center justify-center transition-all ${
                  !isUnlocked
                    ? 'bg-slate-950/50 border-white/5 text-slate-600 cursor-not-allowed'
                    : isPlaying
                    ? isUnlimited
                      ? 'bg-fuchsia-500 text-slate-950 border-fuchsia-200 font-black shadow-[0_0_20px_rgba(217,70,239,0.9)] scale-105 ring-2 ring-fuchsia-300'
                      : 'bg-cyan-500 text-slate-950 border-cyan-200 font-black shadow-[0_0_20px_rgba(6,182,212,0.8)] scale-105 ring-2 ring-cyan-300'
                    : isUnlimited
                    ? stars > 0
                      ? 'crystal-button border-fuchsia-400/40 text-fuchsia-100 hover:border-fuchsia-300 active:scale-95 shadow-md'
                      : 'crystal-button border-fuchsia-500/30 text-fuchsia-200 hover:border-fuchsia-400 active:scale-95 shadow-sm'
                    : stars > 0
                    ? 'crystal-button border-white/20 text-white hover:border-cyan-400 active:scale-95 shadow-md'
                    : 'crystal-button border-cyan-500/40 text-cyan-200 hover:border-cyan-300 active:scale-95 shadow-sm'
                }`}
              >
                {/* Milestone Badge */}
                {isMilestone && isUnlocked && (
                  <span className="absolute -top-1.5 -right-1.5 p-0.5 rounded-full bg-amber-400 text-slate-950 text-[8px] shadow-[0_0_6px_rgba(251,191,36,0.8)]">
                    <Sparkles className="w-2.5 h-2.5" />
                  </span>
                )}

                {/* Level Number */}
                <span className={`font-black tracking-tight leading-tight ${levelNum >= 1000 ? 'text-[11px]' : 'text-sm'}`}>
                  {levelNum}
                </span>

                {/* Lock or Stars */}
                {!isUnlocked ? (
                  <Lock className="w-3.5 h-3.5 text-slate-600 mt-0.5" />
                ) : (
                  <div className="flex items-center gap-0.5 mt-0.5">
                    {[1, 2, 3].map((s) => (
                      <Star
                        key={s}
                        className={`w-2 h-2 ${
                          s <= stars
                            ? isPlaying
                              ? 'text-slate-950 fill-slate-950'
                              : 'text-yellow-400 fill-yellow-400 drop-shadow-[0_0_4px_rgba(250,204,21,0.8)]'
                            : 'text-slate-600 fill-transparent'
                        }`}
                      />
                    ))}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* AdMob Adaptive Banner */}
        <AdMobBanner className="pt-1.5" />
      </motion.div>
    </div>
  );
};

