import React, { useState } from 'react';
import { Difficulty, LevelProgress } from '../types/game';
import { X, Search, Lock, Star, ChevronRight } from 'lucide-react';

interface LevelSelectModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUnlockedLevel: number;
  completedLevels: Record<number, LevelProgress>;
  onSelectLevel: (levelId: number) => void;
}

const TIERS: { difficulty: Difficulty; start: number; end: number; description: string }[] = [
  { difficulty: 'Beginner', start: 1, end: 10, description: '10–40 arrows · 1–2 min target playtime' },
  { difficulty: 'Intermediate', start: 11, end: 100, description: '30–80 arrows · 2–3 min target playtime' },
  { difficulty: 'Advanced', start: 101, end: 500, description: '70–120 arrows · 3–4 min target playtime' },
  { difficulty: 'Master', start: 501, end: 800, description: '100–160 arrows · 4–5 min target playtime' },
  { difficulty: 'Ultimate', start: 801, end: 1000, description: '160–200 arrows · 5+ min ultimate challenge' },
];

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  isOpen,
  onClose,
  currentUnlockedLevel,
  completedLevels,
  onSelectLevel,
}) => {
  const [selectedTier, setSelectedTier] = useState<Difficulty>('Beginner');
  const [jumpInput, setJumpInput] = useState('');
  const [allowAnyLevel, setAllowAnyLevel] = useState(false);

  if (!isOpen) return null;

  const currentTierInfo = TIERS.find((t) => t.difficulty === selectedTier) || TIERS[0];
  const levelsCount = currentTierInfo.end - currentTierInfo.start + 1;

  const handleJumpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const target = parseInt(jumpInput, 10);
    if (!isNaN(target) && target >= 1 && target <= 1000) {
      if (allowAnyLevel || target <= currentUnlockedLevel) {
        onSelectLevel(target);
        onClose();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-[#0c0c0c] border border-[#262626] rounded-2xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#202020] bg-[#121212]">
          <div>
            <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
              LEVEL SELECT
              <span className="text-xs font-mono text-neutral-400 font-normal">
                (1 - 1000)
              </span>
            </h2>
            <p className="text-xs text-neutral-400">
              {Object.keys(completedLevels).length} of 1000 completed
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tier Selector */}
        <div className="flex border-b border-[#202020] overflow-x-auto p-1.5 bg-[#0e0e0e] gap-1">
          {TIERS.map((tier) => (
            <button
              key={tier.difficulty}
              onClick={() => setSelectedTier(tier.difficulty)}
              className={`
                px-3 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 cursor-pointer
                ${selectedTier === tier.difficulty ? 'bg-white text-black font-bold shadow-sm' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'}
              `}
            >
              <span>{tier.difficulty}</span>
              <span className="opacity-70 text-[10px] font-mono">
                {tier.start}-{tier.end}
              </span>
            </button>
          ))}
        </div>

        {/* Jump to Level input bar */}
        <div className="flex items-center justify-between gap-3 px-6 py-3 bg-[#111111] border-b border-[#202020]">
          <form onSubmit={handleJumpSubmit} className="flex items-center gap-2 flex-1">
            <Search className="w-4 h-4 text-neutral-500" />
            <input
              type="number"
              min={1}
              max={1000}
              placeholder="Jump to level (1 - 1000)..."
              value={jumpInput}
              onChange={(e) => setJumpInput(e.target.value)}
              className="bg-transparent text-sm text-white focus:outline-none placeholder:text-neutral-600 w-44 font-mono"
            />
            <button
              type="submit"
              className="text-xs px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-white rounded font-mono"
            >
              Go
            </button>
          </form>

          <label className="flex items-center gap-2 text-xs text-neutral-400 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={allowAnyLevel}
              onChange={(e) => setAllowAnyLevel(e.target.checked)}
              className="accent-white rounded"
            />
            <span>Unlock all 1000</span>
          </label>
        </div>

        {/* Levels Grid */}
        <div className="p-6 overflow-y-auto flex-1">
          <div className="mb-4">
            <p className="text-xs text-neutral-400">{currentTierInfo.description}</p>
          </div>

          <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-8 gap-2.5">
            {Array.from({ length: levelsCount }).map((_, i) => {
              const levelId = currentTierInfo.start + i;
              const isUnlocked = allowAnyLevel || levelId <= currentUnlockedLevel;
              const progress = completedLevels[levelId];
              const isCurrent = levelId === currentUnlockedLevel;

              return (
                <button
                  key={levelId}
                  disabled={!isUnlocked}
                  onClick={() => {
                    onSelectLevel(levelId);
                    onClose();
                  }}
                  className={`
                    relative aspect-square rounded-xl flex flex-col items-center justify-center p-1.5 transition-all
                    ${isUnlocked ? 'cursor-pointer active:scale-95' : 'cursor-not-allowed opacity-35'}
                    ${
                      isCurrent
                        ? 'border-2 border-white bg-neutral-900 shadow-[0_0_12px_rgba(255,255,255,0.2)]'
                        : isUnlocked
                          ? 'border border-[#262626] bg-[#161616] hover:bg-[#222222] hover:border-neutral-500'
                          : 'border border-[#1c1c1c] bg-[#101010]'
                    }
                  `}
                >
                  {isUnlocked ? (
                    <>
                      <span className="text-sm font-bold font-mono text-white">
                        {levelId}
                      </span>
                      {progress && (
                        <div className="flex items-center gap-0.5 mt-0.5">
                          {Array.from({ length: 3 }).map((_, s) => (
                            <Star
                              key={s}
                              className={`w-2.5 h-2.5 ${
                                s < progress.stars
                                  ? 'fill-white text-white'
                                  : 'text-neutral-700'
                              }`}
                            />
                          ))}
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="flex flex-col items-center">
                      <Lock className="w-3.5 h-3.5 text-neutral-600 mb-1" />
                      <span className="text-[10px] font-mono text-neutral-600">
                        {levelId}
                      </span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
