import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Star, Lock } from 'lucide-react';
import { WorldInfo, PlayerStats } from '../types';
import { BannerAd } from './BannerAd';

interface LevelSelectModalProps {
  world: WorldInfo;
  stats: PlayerStats;
  onSelectLevel: (levelNum: number) => void;
  onBack: () => void;
}

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  world,
  stats,
  onSelectLevel,
  onBack,
}) => {
  const [startLevel, endLevel] = world.levelRange;
  const levelsCount = endLevel - startLevel + 1;

  // Level is unlocked if it's <= highestUnlockedLevel
  const highestUnlocked = stats.highestUnlockedLevel || 1;
  const isLevelUnlocked = (num: number) => {
    return num <= highestUnlocked;
  };

  return (
    <div className="w-full h-full flex flex-col bg-slate-50 dark:bg-slate-900 select-none overflow-hidden justify-between">
      {/* Top Bar */}
      <div className="px-5 pt-4 pb-3 flex items-center justify-between border-b border-slate-200/80 dark:border-slate-800 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md shrink-0">
        <button
          id="btn-level-select-back"
          type="button"
          onClick={onBack}
          className="w-10 h-10 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200 active:scale-95 transition border border-slate-200 dark:border-slate-700"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            World {world.id}
          </span>
          <h2 className="text-lg font-black text-slate-800 dark:text-white tracking-tight">
            {world.name}
          </h2>
        </div>

        <div className="w-10" />
      </div>

      {/* 20-Level Grid (4 columns x 5 rows) */}
      <div className="flex-1 overflow-y-auto p-5 pb-6">
        <div className="grid grid-cols-4 gap-3 max-w-sm mx-auto">
          {Array.from({ length: levelsCount }).map((_, index) => {
            const levelNum = startLevel + index;
            const unlocked = isLevelUnlocked(levelNum);
            const levelResult = stats.completedLevels ? stats.completedLevels[levelNum] : undefined;
            const stars = levelResult ? levelResult.stars : 0;

            return (
              <motion.button
                key={levelNum}
                id={`btn-level-${levelNum}`}
                type="button"
                disabled={!unlocked}
                onClick={() => onSelectLevel(levelNum)}
                whileTap={unlocked ? { scale: 0.92 } : {}}
                className={`aspect-square rounded-2xl flex flex-col items-center justify-center border transition relative shadow-sm ${
                  unlocked
                    ? 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-sky-400 cursor-pointer'
                    : 'bg-slate-100/60 dark:bg-slate-800/40 border-slate-200/40 dark:border-slate-800/40 cursor-not-allowed opacity-60'
                }`}
              >
                {unlocked ? (
                  <>
                    <span className="text-base font-black text-slate-800 dark:text-white">
                      {levelNum}
                    </span>
                    {/* Stars row */}
                    <div className="flex items-center gap-0.5 mt-1">
                      {[1, 2, 3].map((s) => (
                        <Star
                          key={s}
                          className={`w-3 h-3 ${
                            s <= stars
                              ? 'text-amber-400 fill-amber-400'
                              : 'text-slate-300 dark:text-slate-600'
                          }`}
                        />
                      ))}
                    </div>
                  </>
                ) : (
                  <Lock className="w-5 h-5 text-slate-400" />
                )}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Real AdMob Horizontal Banner Ad docked at absolute bottom */}
      <BannerAd />
    </div>
  );
};
