import React, { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { UILanguage } from '../types/pdf';
import { UI_COPY } from '../utils/i18n';

interface SignatureModalProps {
  isOpen: boolean;
  lang: UILanguage;
  onClose: () => void;
  onInsertSignature: (dataUrl: string, aspectRatio: number) => void;
}

const INK_COLORS = ['#0f172a', '#1d4ed8', '#991b1b'];

export const SignatureModal: React.FC<SignatureModalProps> = ({
  isOpen,
  lang,
  onClose,
  onInsertSignature,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [inkColor, setInkColor] = useState('#0f172a');
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasStrokes, setHasStrokes] = useState(false);
  const lastPosRef = useRef<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setHasStrokes(false);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx?.clearRect(0, 0, canvas.width, canvas.height);
  }, [isOpen]);

  if (!isOpen) return null;
  const t = UI_COPY[lang];

  const getCoords = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    const pos = getCoords(e);
    lastPosRef.current = pos;
    setIsDrawing(true);
    setHasStrokes(true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !lastPosRef.current) return;
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    const pos = getCoords(e);
    ctx.strokeStyle = inkColor;
    ctx.lineWidth = 4.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(lastPosRef.current.x, lastPosRef.current.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    lastPosRef.current = pos;
  };

  const handlePointerUp = () => {
    setIsDrawing(false);
    lastPosRef.current = null;
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.getContext('2d')?.clearRect(0, 0, canvas.width, canvas.height);
    setHasStrokes(false);
  };

  const handleInsert = () => {
    const canvas = canvasRef.current;
    if (!canvas || !hasStrokes) return;
    const dataUrl = canvas.toDataURL('image/png');
    onInsertSignature(dataUrl, canvas.width / canvas.height);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-[1px] flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white border border-slate-200 rounded-xl w-full max-w-lg shadow-lg overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              {t.signatureTitle}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.signatureDesc}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            data-tooltip={t.close}
            aria-label={t.close}
            className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">
              {t.inkColor}
            </span>
            <div className="flex items-center gap-2">
              {INK_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setInkColor(c)}
                  style={{ backgroundColor: c }}
                  className={`w-6 h-6 rounded-full border-2 cursor-pointer ${
                    inkColor === c ? 'border-blue-600 scale-110' : 'border-white shadow-xs'
                  }`}
                />
              ))}
            </div>
          </div>

          <canvas
            ref={canvasRef}
            width={880}
            height={300}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            className="w-full h-44 bg-[#FAFAFB] border border-slate-200 rounded-lg touch-none cursor-crosshair"
          />
        </div>

        <div className="px-5 py-3 border-t border-slate-200 bg-[#FAFAFB] flex items-center justify-between">
          <button
            type="button"
            onClick={handleClear}
            className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
          >
            {t.clearSignature}
          </button>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg cursor-pointer"
            >
              {t.close}
            </button>
            <button
              type="button"
              disabled={!hasStrokes}
              onClick={handleInsert}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-40 rounded-lg cursor-pointer"
            >
              {t.insertSignature}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
