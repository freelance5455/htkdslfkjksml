import React, { useState, useRef, useEffect } from 'react';
import { useVideo } from '../context/VideoContext';
import { VideoItem } from '../types/video';
import {
  Play,
  Info,
  Volume2,
  VolumeX,
  Plus,
  Check,
  Sparkles,
} from 'lucide-react';

interface BillboardHeroProps {
  featuredVideo?: VideoItem;
}

export const BillboardHero: React.FC<BillboardHeroProps> = ({ featuredVideo }) => {
  const {
    videos,
    setActiveVideo,
    setDetailVideo,
    setYoutubeVideo,
    myList,
    toggleMyList,
    language,
  } = useVideo();

  // If not explicitly provided, choose first high-impact video
  const hero = featuredVideo || videos[0];
  const [isMuted, setIsMuted] = useState(true);
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const isInMyList = hero ? myList.includes(hero.id) : false;

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isMuted;
    }
  }, [isMuted]);

  if (!hero) {
    return (
      <div className="relative h-[65vh] lg:h-[75vh] w-full bg-zinc-900 animate-pulse flex items-center justify-center">
        <span className="text-zinc-600 font-bold text-xl">Loading Featured Title...</span>
      </div>
    );
  }

  const toggleSound = () => {
    setIsMuted(!isMuted);
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
    }
  };

  return (
    <div className="relative h-[70vh] sm:h-[80vh] lg:h-[88vh] w-full select-none overflow-hidden bg-[#141414]">
      {/* Background Video Trailer or Cinematic Image */}
      <div className="absolute inset-0 w-full h-full">
        {hero.trailerUrl || hero.videoUrl ? (
          <video
            ref={videoRef}
            src={hero.trailerUrl || hero.videoUrl}
            poster={hero.backdropUrl || hero.thumbnailUrl}
            autoPlay
            muted
            loop
            playsInline
            onLoadedData={() => setIsVideoLoaded(true)}
            className={`w-full h-full object-cover object-center transition-opacity duration-1000 ${
              isVideoLoaded ? 'opacity-90' : 'opacity-70'
            }`}
          />
        ) : (
          <img
            src={hero.backdropUrl || hero.thumbnailUrl}
            alt={hero.title}
            className="w-full h-full object-cover object-center"
          />
        )}

        {/* Netflix Gradients: Vignette, bottom fade, top nav fade */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/40 to-transparent w-full lg:w-3/5" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/20 to-transparent" />
        <div className="absolute top-0 inset-x-0 h-32 bg-gradient-to-b from-black/80 to-transparent" />
      </div>

      {/* Hero Content Overlay */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-end pb-24 sm:pb-28 lg:pb-36 z-10">
        <div className="max-w-2xl space-y-4">
          {/* Netflix Originals / CineStream Badge */}
          <div className="flex items-center space-x-2">
            <span className="bg-[#E50914] text-white text-[11px] font-black tracking-widest px-1.5 py-0.5 rounded-xs uppercase shadow-sm">
              CINESTREAM
            </span>
            <span className="text-zinc-300 text-xs font-semibold tracking-wider uppercase">
              {hero.category.toUpperCase()} • {hero.quality}
            </span>
            {hero.isUploaded && (
              <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-1.5 py-0.5 rounded">
                COMMUNITY UPLOAD
              </span>
            )}
          </div>

          {/* Hero Title */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white drop-shadow-xl leading-tight">
            {hero.title}
          </h1>

          {/* Metadata badges */}
          <div className="flex items-center space-x-3 text-xs sm:text-sm font-semibold text-zinc-300">
            <span className="text-emerald-400 font-bold">{hero.matchScore}% Match</span>
            <span>{hero.releaseYear}</span>
            <span className="px-1.5 py-0.5 border border-zinc-500 text-zinc-300 rounded text-[11px]">
              {hero.rating}
            </span>
            <span className="border border-white/30 px-1 rounded text-[10px] uppercase font-bold text-white">
              {hero.quality}
            </span>
            <span className="text-zinc-400">
              {hero.tags.slice(0, 3).join(' • ')}
            </span>
          </div>

          {/* Synopsis */}
          <p className="text-zinc-200 text-xs sm:text-sm lg:text-base leading-relaxed line-clamp-3 sm:line-clamp-4 drop-shadow">
            {hero.description}
          </p>

          {/* Action Buttons */}
          <div className="flex items-center space-x-3 sm:space-x-4 pt-2">
            {/* Play Button */}
            <button
              onClick={() => setActiveVideo(hero)}
              className="flex items-center space-x-2 px-5 sm:px-7 py-2 sm:py-2.5 rounded bg-white hover:bg-zinc-200 text-black font-bold text-sm sm:text-base transition-all transform hover:scale-105 active:scale-95 shadow-lg shadow-white/20 cursor-pointer"
            >
              <Play className="w-5 h-5 fill-black" />
              <span>{language === 'ur' ? 'ابھی چلائیں' : 'Play'}</span>
            </button>

            {/* YouTube View Button */}
            <button
              onClick={() => setYoutubeVideo(hero)}
              className="flex items-center space-x-2 px-4 sm:px-5 py-2 sm:py-2.5 rounded bg-red-600/30 hover:bg-red-600/50 border border-red-500/40 text-red-300 hover:text-white font-semibold text-sm sm:text-base backdrop-blur-sm transition-all transform hover:scale-105 active:scale-95 cursor-pointer"
              title="Watch with comments & sidebar like YouTube"
            >
              <div className="w-4 h-4 rounded-xs bg-[#E50914] flex items-center justify-center">
                <Play className="w-2.5 h-2.5 fill-white text-white ml-0.5" />
              </div>
              <span className="hidden sm:inline">{language === 'ur' ? 'یوٹیوب موڈ' : 'YouTube Mode'}</span>
            </button>

            {/* More Info Button */}
            <button
              onClick={() => setDetailVideo(hero)}
              className="flex items-center space-x-2 px-4 sm:px-6 py-2 sm:py-2.5 rounded bg-zinc-600/70 hover:bg-zinc-600/90 text-white font-semibold text-sm sm:text-base backdrop-blur-sm transition-all transform hover:scale-105 active:scale-95 cursor-pointer"
            >
              <Info className="w-5 h-5" />
              <span>{language === 'ur' ? 'مزید معلومات' : 'More Info'}</span>
            </button>

            {/* Add to My List Toggle */}
            <button
              onClick={() => toggleMyList(hero.id)}
              className="p-2 sm:p-2.5 rounded-full border-2 border-white/40 hover:border-white bg-black/40 hover:bg-black/60 text-white transition-all transform hover:scale-110 active:scale-95 cursor-pointer"
              title={isInMyList ? 'Remove from My List' : 'Add to My List'}
            >
              {isInMyList ? <Check className="w-5 h-5 text-emerald-400" /> : <Plus className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Right Controls: Mute toggle & Maturity rating badge */}
      <div className="absolute right-4 sm:right-8 lg:right-12 bottom-24 sm:bottom-28 lg:bottom-36 flex items-center space-x-3 z-10">
        <button
          onClick={toggleSound}
          className="p-2.5 rounded-full border border-white/30 bg-black/60 hover:bg-black/80 text-white transition-colors cursor-pointer"
          title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
        >
          {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
        </button>

        <div className="bg-black/60 border-l-4 border-red-600 px-3 py-1 text-xs font-bold text-white tracking-wider backdrop-blur-sm">
          {hero.rating}
        </div>
      </div>
    </div>
  );
};
