import React from 'react';
import { History, Play, Download, Trash2, RotateCcw, Clock, Volume2, ArrowUpRight } from 'lucide-react';
import { HistoryItem } from '../types/tts';

interface HistoryDrawerProps {
  history: HistoryItem[];
  onPlayItem: (item: HistoryItem) => void;
  onDownloadItem: (item: HistoryItem) => void;
  onUseText: (text: string) => void;
  onDeleteItem: (id: string) => void;
  onClearHistory: () => void;
  currentlyPlayingId?: string | null;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  history,
  onPlayItem,
  onDownloadItem,
  onUseText,
  onDeleteItem,
  onClearHistory,
  currentlyPlayingId,
}) => {
  const formatDate = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' - ' + d.toLocaleDateString();
    } catch {
      return iso;
    }
  };

  return (
    <div className="w-full bg-[#101522] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/40">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800/80">
        <div>
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <History className="w-4 h-4 text-cyan-400" />
            <span>ఉత్పత్తి చరిత్ర</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              Audio History ({history.length})
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            మీరు రూపొందించిన గత ఆడియో ఫైల్స్ మరియు స్క్రిప్ట్‌లు
          </p>
        </div>

        {history.length > 0 && (
          <button
            type="button"
            onClick={onClearHistory}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 transition-all cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>చరిత్రను తొలగించు (Clear All)</span>
          </button>
        )}
      </div>

      {/* History Items List */}
      {history.length === 0 ? (
        <div className="p-8 text-center rounded-xl bg-slate-900/40 border border-dashed border-slate-800">
          <History className="w-8 h-8 text-slate-600 mx-auto mb-2" />
          <p className="text-sm font-medium text-slate-400">గత ఆడియో ఉత్పత్తి రికార్డులు ఏవీ లేవు.</p>
          <p className="text-xs text-slate-500 mt-1">
            మీరు వాయిస్ జనరేట్ చేసిన వెంటనే ఆడియో ఇక్కడ కనిపిస్తుంది మరియు సేవ్ అవుతుంది.
          </p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-slate-800">
          {history.map((item) => {
            const isPlaying = currentlyPlayingId === item.id;
            return (
              <div
                key={item.id}
                className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 transition-all group"
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex-1">
                    <p className="text-xs font-telugu text-slate-200 line-clamp-2 leading-relaxed">
                      "{item.textSnippet}"
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {/* Play */}
                    <button
                      type="button"
                      onClick={() => onPlayItem(item)}
                      className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                        isPlaying
                          ? 'bg-cyan-500 text-slate-950 font-bold'
                          : 'bg-cyan-500/15 text-cyan-300 hover:bg-cyan-500/25 border border-cyan-500/30'
                      }`}
                      title="Play generated audio"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span className="hidden sm:inline">ప్లే</span>
                    </button>

                    {/* Download */}
                    <button
                      type="button"
                      onClick={() => onDownloadItem(item)}
                      className="p-1.5 rounded-lg bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25 border border-emerald-500/30 transition-all cursor-pointer"
                      title="Download MP3"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>

                    {/* Re-use text */}
                    <button
                      type="button"
                      onClick={() => onUseText(item.fullText || item.textSnippet)}
                      className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-cyan-300 hover:bg-slate-700 transition-all cursor-pointer"
                      title="Load this text into editor"
                    >
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete */}
                    <button
                      type="button"
                      onClick={() => onDeleteItem(item.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                      title="Delete from history"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Metadata row */}
                <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 gap-2 pt-2 border-t border-slate-800/60">
                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-slate-300">{item.voiceName}</span>
                    <span>•</span>
                    <span className="text-cyan-400">{item.narrationStyle}</span>
                    <span>•</span>
                    <span className="font-mono text-slate-400">{item.durationSec.toFixed(1)}s</span>
                  </div>

                  <div className="flex items-center gap-1 font-mono text-slate-500">
                    <Clock className="w-3 h-3" />
                    <span>{formatDate(item.createdAt)}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
