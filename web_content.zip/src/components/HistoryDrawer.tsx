import React from 'react';
import { 
  History, 
  Play, 
  Download, 
  Share2, 
  Trash2, 
  Clock, 
  Wifi, 
  WifiOff, 
  FileAudio,
  ArrowRight
} from 'lucide-react';
import { AudioGeneration, ExportFormat, CloudStorageProvider } from '../types/tts';
import { downloadBlob } from '../utils/audioEncoder';
import { Cloud, HardDrive } from 'lucide-react';

interface HistoryDrawerProps {
  history: AudioGeneration[];
  onPlayItem: (item: AudioGeneration) => void;
  onDeleteItem: (id: string) => void;
  onClearHistory: () => void;
  onOpenShare: (item: AudioGeneration) => void;
  onExportItem: (item: AudioGeneration, format: ExportFormat) => void;
  onClose: () => void;
  onSaveToCloud?: (item: AudioGeneration, provider: CloudStorageProvider) => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  history,
  onPlayItem,
  onDeleteItem,
  onClearHistory,
  onOpenShare,
  onExportItem,
  onClose,
  onSaveToCloud,
}) => {
  return (
    <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-5 shadow-xl space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-violet-600/10 text-violet-600 dark:text-violet-400">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-zinc-900 dark:text-white">
              Generation History ({history.length})
            </h3>
            <p className="text-xs text-zinc-400">
              Cached locally for instant offline replay &amp; export
            </p>
          </div>
        </div>

        {history.length > 0 && (
          <button
            onClick={onClearHistory}
            className="text-xs text-red-500 hover:text-red-600 font-medium flex items-center gap-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear All
          </button>
        )}
      </div>

      {/* History Items List */}
      {history.length === 0 ? (
        <div className="text-center py-12 space-y-2">
          <FileAudio className="w-10 h-10 text-zinc-300 dark:text-zinc-700 mx-auto" />
          <h4 className="text-sm font-bold text-zinc-700 dark:text-zinc-300">
            No voice generations yet
          </h4>
          <p className="text-xs text-zinc-400 max-w-sm mx-auto">
            Type text in the studio and click &quot;Generate &amp; Play&quot; to synthesize audio. Your recent creations will appear here.
          </p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
          {history.map((item) => (
            <div
              key={item.id}
              className="p-3.5 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-950/40 hover:border-zinc-300 dark:hover:border-zinc-700 transition-all space-y-2 group"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-zinc-900 dark:text-white">
                      {item.personaName}
                    </span>
                    <span className="text-[10px] text-zinc-500">· {item.languageName}</span>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full flex items-center gap-0.5 ${
                        item.engine === 'neural'
                          ? 'bg-violet-500/10 text-violet-500'
                          : 'bg-emerald-500/10 text-emerald-500'
                      }`}
                    >
                      {item.engine === 'neural' ? <Wifi className="w-2.5 h-2.5" /> : <WifiOff className="w-2.5 h-2.5" />}
                      {item.engine === 'neural' ? 'Neural' : 'Offline'}
                    </span>
                  </div>
                  <div className="text-[10px] text-zinc-400 flex items-center gap-2 mt-0.5">
                    <span>{new Date(item.createdAt).toLocaleTimeString()}</span>
                    <span>·</span>
                    <span>{item.duration.toFixed(1)}s</span>
                    <span>·</span>
                    <span>{item.speed}x speed</span>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteItem(item.id)}
                  className="opacity-0 group-hover:opacity-100 p-1 text-zinc-400 hover:text-red-500 transition-all"
                  title="Delete item"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Text snippet */}
              <p className="text-xs text-zinc-600 dark:text-zinc-300 line-clamp-2 italic">
                &quot;{item.text}&quot;
              </p>

              {/* Action Toolbar */}
              <div className="flex items-center justify-between pt-1 border-t border-zinc-200/60 dark:border-zinc-800/60">
                <button
                  onClick={() => onPlayItem(item)}
                  className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-violet-600 text-white flex items-center gap-1.5 hover:bg-violet-500 shadow-sm transition-all"
                >
                  <Play className="w-3 h-3" />
                  Load &amp; Play
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onExportItem(item, 'wav')}
                    className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-200 dark:hover:bg-zinc-800 text-[11px] font-semibold flex items-center gap-1"
                    title="Export WAV"
                  >
                    <Download className="w-3 h-3 text-violet-500" />
                    WAV
                  </button>

                  <button
                    onClick={() => onExportItem(item, 'mp3')}
                    className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-200 dark:hover:bg-zinc-800 text-[11px] font-semibold flex items-center gap-1"
                    title="Export MP3"
                  >
                    <Download className="w-3 h-3 text-cyan-500" />
                    MP3
                  </button>

                  {onSaveToCloud && (
                    <button
                      onClick={() => onSaveToCloud(item, 'google-drive')}
                      className="p-1.5 rounded-lg text-cyan-600 dark:text-cyan-400 hover:bg-cyan-50 dark:hover:bg-cyan-950/40 text-[11px] font-semibold flex items-center gap-1"
                      title="Save to Google Drive"
                    >
                      <Cloud className="w-3 h-3" />
                      <span className="hidden sm:inline">Drive</span>
                    </button>
                  )}

                  <button
                    onClick={() => onOpenShare(item)}
                    className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-200 dark:hover:bg-zinc-800"
                    title="Share to social channels"
                  >
                    <Share2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
