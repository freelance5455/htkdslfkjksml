import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, Download, ArrowUpRight, Copy, Check, Clock, Sparkles, Filter } from 'lucide-react';
import { historyStorage, HistoryItem } from '../services/historyStorage';
import { audioService } from '../services/audioService';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onRecallExpression: (expr: string) => void;
  onShowToast: (text: string, type?: 'success' | 'info' | 'error') => void;
  onHistoryUpdated: () => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  onRecallExpression,
  onShowToast,
  onHistoryUpdated,
}) => {
  const [filter, setFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const allItems = historyStorage.getAll();
  const filteredItems = filter === 'all' ? allItems : allItems.filter((i) => i.type === filter);

  const handleRecall = (item: HistoryItem) => {
    audioService.playKeyClick();
    // Prefer recallable expression or numeric result
    const val = item.numericResult !== undefined ? item.numericResult.toString() : item.result;
    onRecallExpression(val);
    onShowToast(`Recalled ${val} into calculator!`, 'success');
    onClose();
  };

  const handleCopy = (item: HistoryItem) => {
    audioService.playKeyClick();
    const txt = `${item.expression} = ${item.result}`;
    if (navigator?.clipboard) {
      navigator.clipboard.writeText(txt);
      setCopiedId(item.id);
      onShowToast('Copied to clipboard', 'info');
      setTimeout(() => setCopiedId(null), 1500);
    }
  };

  const handleDelete = (id: string) => {
    audioService.playClearSound();
    historyStorage.delete(id);
    onHistoryUpdated();
    onShowToast('Entry deleted', 'info');
  };

  const handleClearAll = () => {
    audioService.playClearSound();
    historyStorage.clear();
    onHistoryUpdated();
    onShowToast('History tape cleared', 'info');
  };

  const handleExport = () => {
    audioService.playKeyClick();
    const content = historyStorage.exportToText();
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `VIP_Calculator_Tape_${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    onShowToast('History tape exported!', 'success');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40"
          />

          {/* Drawer Slide-Up */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto h-[85vh] sm:h-[80vh] rounded-t-3xl bg-[#0c0e17] border-t border-x border-amber-500/30 z-50 flex flex-col shadow-2xl overflow-hidden"
          >
            {/* Header Handle */}
            <div className="w-12 h-1.5 bg-zinc-700/60 rounded-full mx-auto mt-3 mb-1" />

            {/* Drawer Title Bar */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <h3 className="font-vip text-sm font-bold text-amber-200 uppercase tracking-wider">
                  VIP Calculation Tape
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-400/30">
                  {filteredItems.length} records
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                {allItems.length > 0 && (
                  <>
                    <button
                      onClick={handleExport}
                      className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 hover:text-amber-300 transition"
                      title="Export Tape as Text File"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleClearAll}
                      className="p-1.5 rounded-lg bg-zinc-900 hover:bg-rose-950/40 border border-zinc-700 hover:border-rose-500/40 text-zinc-300 hover:text-rose-400 transition"
                      title="Clear All History"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </>
                )}
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-400 hover:text-zinc-200 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 px-4 py-2 border-b border-zinc-800/80 overflow-x-auto text-[11px] font-mono">
              {[
                { id: 'all', label: 'All' },
                { id: 'standard', label: 'Standard' },
                { id: 'scientific', label: 'Scientific' },
                { id: 'ai', label: 'AI Solver' },
                { id: 'finance', label: 'Finance' },
                { id: 'formula', label: 'Formulas' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFilter(f.id)}
                  className={`px-2.5 py-1 rounded-lg border transition ${
                    filter === f.id
                      ? 'bg-amber-500/20 text-amber-300 border-amber-400/40 font-bold'
                      : 'bg-zinc-900/60 text-zinc-400 border-zinc-800'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Tape Items Scroll List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
              {filteredItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 text-center text-zinc-500 font-mono text-xs">
                  <Sparkles className="w-8 h-8 text-amber-500/20 mb-2" />
                  <p>No calculation history recorded yet.</p>
                  <p className="text-[10px] text-zinc-600 mt-1">
                    Calculate equations or solve formulas to see them appear here.
                  </p>
                </div>
              ) : (
                filteredItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-2xl bg-gradient-to-b from-[#131622] to-[#0d0f17] border border-amber-500/20 hover:border-amber-400/40 transition shadow-md flex flex-col space-y-1.5 group"
                  >
                    <div className="flex items-center justify-between text-[10px] font-mono text-zinc-400">
                      <div className="flex items-center gap-1.5">
                        <span className="px-1.5 py-0.2 rounded bg-zinc-800 text-amber-300 uppercase font-bold text-[9px]">
                          {item.type}
                        </span>
                        {item.title && <span className="text-zinc-300">{item.title}</span>}
                      </div>
                      <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>

                    <div className="font-mono text-xs text-zinc-400 break-all">
                      {item.expression}
                    </div>

                    <div className="flex items-baseline justify-between pt-1">
                      <div className="font-mono text-base font-bold text-amber-300 break-all">
                        = {item.result}
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleCopy(item)}
                          className="p-1 rounded-md bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 transition"
                          title="Copy"
                        >
                          {copiedId === item.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          onClick={() => handleRecall(item)}
                          className="px-2 py-1 rounded-md bg-amber-500/15 hover:bg-amber-500/30 border border-amber-400/30 text-[10px] font-mono text-amber-300 flex items-center gap-1 transition"
                          title="Import into Calculator"
                        >
                          <span>Recall</span>
                          <ArrowUpRight className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleDelete(item.id)}
                          className="p-1 rounded-md bg-zinc-900 hover:bg-rose-950/40 text-zinc-500 hover:text-rose-400 transition"
                          title="Delete"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
