import React from 'react';
import { GeneratedAudioItem } from '../types/voice';
import {
  X,
  Play,
  Pause,
  Download,
  Copy,
  Trash2,
  Clock,
  Volume2,
  FileText,
} from 'lucide-react';
import { triggerAudioDownload } from '../utils/audioSynthesizer';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  history: GeneratedAudioItem[];
  currentlyPlayingId: string | null;
  onPlayItem: (item: GeneratedAudioItem) => void;
  onLoadScript: (text: string) => void;
  onClearHistory: () => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  history,
  currentlyPlayingId,
  onPlayItem,
  onLoadScript,
  onClearHistory,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md bg-gray-950/95 border-l border-gray-800 h-full p-6 flex flex-col gap-4 shadow-2xl relative">
        {/* Drawer Header */}
        <div className="flex items-center justify-between border-b border-gray-800 pb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-gray-100">Generation History</h3>
            <span className="text-xs bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded-full font-mono">
              {history.length}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                onClick={onClearHistory}
                className="text-xs text-red-400 hover:text-red-300 p-1.5 rounded-lg hover:bg-red-950/40 transition cursor-pointer"
                title="Clear History"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white p-1.5 rounded-lg hover:bg-gray-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col gap-3 pr-1">
          {history.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-gray-500 text-xs">
              <Volume2 className="w-10 h-10 text-gray-700 mb-2" />
              <p className="text-gray-300 font-medium mb-1">No generations yet</p>
              <p className="text-gray-500 text-[11px]">
                Your generated speech audio files will appear here for easy playback and download.
              </p>
            </div>
          ) : (
            history.map((item) => {
              const isPlaying = currentlyPlayingId === item.id;
              const dateStr = new Date(item.timestamp).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={item.id}
                  className={`p-3.5 rounded-xl border transition flex flex-col gap-2.5 ${
                    isPlaying
                      ? 'bg-indigo-950/40 border-indigo-500/60 shadow-md ring-1 ring-indigo-500/20'
                      : 'bg-gray-900/60 border-gray-800/80 hover:border-gray-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-6 h-6 rounded-lg bg-gradient-to-tr ${item.voice.avatarBg} flex items-center justify-center text-white text-[10px] font-bold`}
                      >
                        {item.voice.avatarLetter}
                      </div>
                      <span className="text-xs font-semibold text-gray-200">
                        {item.voice.name}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-gray-800 text-indigo-300">
                        {item.mood}
                      </span>
                    </div>

                    <span className="text-[10px] font-mono text-gray-500">{dateStr}</span>
                  </div>

                  <p className="text-xs text-gray-300 line-clamp-2 leading-relaxed bg-gray-950/40 p-2 rounded-lg border border-gray-800/50">
                    &quot;{item.text}&quot;
                  </p>

                  <div className="flex items-center justify-between pt-1 text-xs">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onPlayItem(item)}
                        className={`px-2.5 py-1 rounded-lg flex items-center gap-1.5 font-medium transition cursor-pointer ${
                          isPlaying
                            ? 'bg-indigo-600 text-white'
                            : 'bg-gray-800 hover:bg-gray-700 text-gray-200'
                        }`}
                      >
                        {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                        <span>{isPlaying ? 'Pause' : 'Play'}</span>
                      </button>

                      <button
                        onClick={() => onLoadScript(item.text)}
                        className="p-1.5 rounded-lg bg-gray-800/80 hover:bg-gray-700 text-gray-300 hover:text-white transition cursor-pointer"
                        title="Load script into editor"
                      >
                        <FileText className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <button
                      onClick={() =>
                        triggerAudioDownload(
                          item.audioUrl,
                          `sonicvoice_${item.voice.name.toLowerCase().replace(/\s+/g, '_')}_${Date.now()}`
                        )
                      }
                      className="p-1.5 rounded-lg bg-gray-800/80 hover:bg-gray-700 text-gray-300 hover:text-white transition cursor-pointer flex items-center gap-1"
                      title="Download WAV"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span className="text-[11px]">WAV</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
