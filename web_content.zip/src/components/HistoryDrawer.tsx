import React from 'react';
import { HistoryItem, Language, NumeralSystem } from '../types/calculator';
import { formatDisplayValue } from '../utils/math';
import { Trash2, X, Copy, RotateCcw } from 'lucide-react';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  history: HistoryItem[];
  onSelectHistory: (item: HistoryItem) => void;
  onClearHistory: () => void;
  language: Language;
  numeralSystem: NumeralSystem;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  history,
  onSelectHistory,
  onClearHistory,
  language,
  numeralSystem,
}) => {
  const isUrdu = language === 'ur';

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        aria-label={isUrdu ? 'حسابی تاریخچہ' : 'Calculation History'}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>{isUrdu ? 'حسابی تاریخچہ' : 'Calculation History'}</span>
            </h2>
            <span className="text-xs text-slate-400 font-mono">
              ({formatDisplayValue(String(history.length), numeralSystem)})
            </span>
          </div>

          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                type="button"
                onClick={onClearHistory}
                className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-950/50 transition-colors flex items-center gap-1.5 focus-visible:ring-2 focus-visible:ring-rose-500"
                title={isUrdu ? 'تاریخچہ صاف کریں' : 'Clear History'}
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isUrdu ? 'صاف کریں' : 'Clear'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
              aria-label={isUrdu ? 'بند کریں' : 'Close'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 divide-y divide-slate-800/40">
          {history.length === 0 ? (
            <div className="py-12 text-center text-slate-500">
              <RotateCcw className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p className="text-sm font-medium">
                {isUrdu ? 'ابھی کوئی سابقہ حسابی عمل موجود نہیں' : 'No calculations yet'}
              </p>
              <p className="text-xs text-slate-600 mt-1">
                {isUrdu ? 'حساب کرنے کے بعد یہاں محفوظ ہو جائے گا' : 'Calculations will appear here'}
              </p>
            </div>
          ) : (
            history.map((item) => {
              const formattedExp = formatDisplayValue(item.expression, numeralSystem);
              const formattedRes = formatDisplayValue(item.result, numeralSystem);
              return (
                <div
                  key={item.id}
                  className="pt-2.5 first:pt-0 group flex flex-col gap-1 rounded-xl p-2.5 hover:bg-slate-800/60 transition-colors cursor-pointer"
                  onClick={() => {
                    onSelectHistory(item);
                    onClose();
                  }}
                  title={isUrdu ? 'دوبارہ استعمال کرنے کے لیے کلک کریں' : 'Click to reuse'}
                >
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span 
                      className="font-mono truncate max-w-[240px]" 
                      dir={numeralSystem === 'eastern' ? 'rtl' : 'ltr'}
                    >
                      {formattedExp} =
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span
                      className="text-lg font-bold font-mono text-amber-400 tracking-tight"
                      dir={numeralSystem === 'eastern' ? 'rtl' : 'ltr'}
                    >
                      {formattedRes}
                    </span>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigator.clipboard.writeText(item.result);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-700/80 transition-all text-xs flex items-center gap-1"
                      title={isUrdu ? 'نتیجہ کاپی کریں' : 'Copy result'}
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/50 text-xs text-slate-400 text-center">
          {isUrdu 
            ? 'کسی بھی اندراج پر کلک کر کے اسے دوبارہ کیلکولیٹر میں لائیں'
            : 'Click any entry to load it back into the calculator'}
        </div>
      </div>
    </div>
  );
};
