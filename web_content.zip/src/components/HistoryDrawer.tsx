import React, { useMemo, useState } from 'react';
import {
  Check,
  MessageSquare,
  Pencil,
  Phone,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import type { HistorySession } from '../types';

interface HistoryDrawerProps {
  open: boolean;
  onClose: () => void;
  activeSessionId: string;
  sessions: HistorySession[];
  onNewChat: () => void;
  onSelectSession: (session: HistorySession) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  onDeleteSession: (id: string) => void;
  onClearAll: () => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  open,
  onClose,
  activeSessionId,
  sessions,
  onNewChat,
  onSelectSession,
  onRenameSession,
  onDeleteSession,
  onClearAll,
}) => {
  const [query, setQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  const filteredSessions = useMemo(() => {
    const q = query.trim().toLowerCase();
    return sessions.filter((s) => {
      if (!q) return true;
      return (
        s.title.toLowerCase().includes(q) ||
        s.language.toLowerCase().includes(q) ||
        s.messages.some((m) => m.text.toLowerCase().includes(q))
      );
    });
  }, [sessions, query]);

  if (!open) return null;

  const startRename = (s: HistorySession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(s.id);
    setEditingTitle(s.title);
  };

  const commitRename = (id: string) => {
    const trimmed = editingTitle.trim();
    if (trimmed) {
      onRenameSession(id, trimmed);
    }
    setEditingId(null);
    setEditingTitle('');
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      <div
        className="fixed inset-0 bg-black/75"
        onClick={onClose}
        aria-hidden="true"
      />

      <aside className="relative z-10 w-[300px] sm:w-[320px] max-w-[88vw] h-full bg-zinc-950 border-r border-zinc-800 flex flex-col">
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-zinc-800">
          <span className="text-sm font-semibold text-zinc-100">History</span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                onNewChat();
                onClose();
              }}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-xs font-medium text-zinc-100 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 cursor-pointer"
              aria-label="Close history drawer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="p-3 border-b border-zinc-800">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search history..."
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-zinc-800 bg-black text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filteredSessions.length === 0 ? (
            <div className="px-3 py-8 text-center">
              <p className="text-xs font-medium text-zinc-400">No saved history yet</p>
              <p className="text-[11px] text-zinc-600 mt-1">
                Start chatting or calling and your history will appear here.
              </p>
            </div>
          ) : (
            filteredSessions.map((session) => {
              const isActive = session.id === activeSessionId;
              const isEditing = editingId === session.id;

              return (
                <div
                  key={session.id}
                  className={`rounded-lg px-2.5 py-2 transition-colors ${
                    isActive
                      ? 'bg-zinc-800/90 text-white'
                      : 'text-zinc-300 hover:bg-zinc-900'
                  }`}
                >
                  {isEditing ? (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        commitRename(session.id);
                      }}
                      className="flex items-center gap-1.5"
                    >
                      <input
                        type="text"
                        autoFocus
                        value={editingTitle}
                        onChange={(e) => setEditingTitle(e.target.value)}
                        onBlur={() => commitRename(session.id)}
                        onKeyDown={(e) => {
                          if (e.key === 'Escape') {
                            setEditingId(null);
                          }
                        }}
                        className="flex-1 min-w-0 px-2 py-1 text-xs rounded bg-black border border-blue-500 text-white focus:outline-none"
                      />
                      <button
                        type="submit"
                        className="p-1 rounded bg-blue-600 text-white hover:bg-blue-700 cursor-pointer shrink-0"
                        aria-label="Save name"
                      >
                        <Check className="w-3 h-3" />
                      </button>
                    </form>
                  ) : (
                    <div className="flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          onSelectSession(session);
                          onClose();
                        }}
                        className="flex-1 min-w-0 text-left flex items-start gap-2 cursor-pointer"
                      >
                        {session.type === 'call' ? (
                          <Phone className="w-3.5 h-3.5 text-blue-400 mt-0.5 shrink-0" />
                        ) : (
                          <MessageSquare className="w-3.5 h-3.5 text-zinc-400 mt-0.5 shrink-0" />
                        )}
                        <div className="min-w-0">
                          <p className="text-xs font-medium truncate">{session.title}</p>
                          <p className="text-[11px] text-zinc-500 tabular-nums mt-0.5">
                            {new Date(session.updatedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </button>

                      <div className="flex items-center gap-0.5 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => startRename(session, e)}
                          className="p-1.5 rounded text-zinc-400 hover:text-white hover:bg-zinc-800 cursor-pointer"
                          title="Rename"
                          aria-label="Rename history item"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteSession(session.id);
                          }}
                          className="p-1.5 rounded text-zinc-400 hover:text-red-400 hover:bg-zinc-800 cursor-pointer"
                          title="Delete"
                          aria-label="Delete history item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer: Clear All only (no Settings link in History) */}
        {sessions.length > 0 && (
          <div className="p-3 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClearAll}
              className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg border border-zinc-800 text-xs font-medium text-zinc-400 hover:text-red-400 hover:border-red-900/60 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All History</span>
            </button>
          </div>
        )}
      </aside>
    </div>
  );
};
