import React, { useState, useEffect, useMemo } from 'react';
import {
  Sun,
  Sunrise,
  Sunset,
  Clock,
  Sliders,
  MapPin,
} from 'lucide-react';
import { LocationPreset, UserSettings, ZmanCategory, ZmanItem } from '../types';
import { calculateZmanim } from '../services/hebrewCalendarService';

interface ZmanimPanelProps {
  date: Date;
  location: LocationPreset;
  settings: UserSettings;
  onUpdateSettings?: (newSettings: Partial<UserSettings>) => void;
  compact?: boolean;
}

export const ZmanimPanel: React.FC<ZmanimPanelProps> = ({
  date,
  location,
  settings,
  onUpdateSettings,
}) => {
  const [viewMode, setViewMode] = useState<'daily' | 'weekly'>('daily');
  const [selectedCategory, setSelectedCategory] = useState<ZmanCategory | 'all'>('all');
  const [showSettings, setShowSettings] = useState(false);
  const [expandedZmanInfo, setExpandedZmanInfo] = useState<string | null>(null);

  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const zmanimData = calculateZmanim(date, location, {
    candleLightingOffset: settings.candleLightingOffset,
    havdalahOpinion: settings.havdalahOpinion,
  });

  const filteredItems =
    selectedCategory === 'all'
      ? zmanimData.items
      : zmanimData.items.filter((z) => z.category === selectedCategory);

  const isToday =
    currentTime.getFullYear() === date.getFullYear() &&
    currentTime.getMonth() === date.getMonth() &&
    currentTime.getDate() === date.getDate();

  const weekDaysDates = useMemo(() => {
    const dayOfWeek = date.getDay(); // 0 = Sunday
    const startOfWeek = new Date(date);
    startOfWeek.setDate(date.getDate() - dayOfWeek);
    const dates: Date[] = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(startOfWeek);
      d.setDate(startOfWeek.getDate() + i);
      dates.push(d);
    }
    return dates;
  }, [date]);

  const weeklyZmanim = useMemo(() => {
    return weekDaysDates.map((dayDate) => {
      const data = calculateZmanim(dayDate, location, {
        candleLightingOffset: settings.candleLightingOffset,
        havdalahOpinion: settings.havdalahOpinion,
      });
      return {
        date: dayDate,
        data,
      };
    });
  }, [weekDaysDates, location, settings.candleLightingOffset, settings.havdalahOpinion]);


  return (
    <div className="bg-[#1A1A1A] p-6 rounded-2xl border border-[#2A2A2A] shadow-xl flex flex-col">
      {/* Header matching Elegant Dark */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6">
        <div>
          <span className="text-xs font-bold text-[#555555] uppercase tracking-[0.2em] block">
            {viewMode === 'daily' ? "Today's Zmanim" : "Weekly Zmanim"}
          </span>
          <span className="text-xs text-[#888888] font-hebrew mt-0.5 block" dir="rtl">
            {viewMode === 'daily' ? 'זמני היום לפי ההלכה' : 'זמני השבוע לפי ההלכה'}
          </span>
        </div>

        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          {/* Segmented Daily/Weekly selector */}
          <div className="flex bg-[#121212] rounded-lg p-1 border border-[#2A2A2A]">
            <button
              onClick={() => setViewMode('daily')}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${
                viewMode === 'daily'
                  ? 'bg-[#2A2A2A] text-[#C5A267] shadow-xs font-semibold'
                  : 'text-[#666666] hover:text-[#888888]'
              }`}
            >
              Daily
            </button>
            <button
              onClick={() => setViewMode('weekly')}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${
                viewMode === 'weekly'
                  ? 'bg-[#2A2A2A] text-[#C5A267] shadow-xs font-semibold'
                  : 'text-[#666666] hover:text-[#888888]'
              }`}
            >
              Weekly
            </button>
          </div>

          <span className="text-xs text-[#C5A267] font-medium px-2.5 py-1 rounded-md bg-[#252525] border border-[#3A3A3A] flex items-center gap-1">
            <MapPin className="w-3 h-3 text-[#C5A267]" />
            {location.name}
          </span>

          {onUpdateSettings && (
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-1.5 rounded-md border border-[#2A2A2A] bg-[#161616] hover:bg-[#252525] text-[#888888] hover:text-[#EAEAEA] transition-colors text-xs flex items-center gap-1"
              title="Configure Halachic Opinions"
            >
              <Sliders className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Halachic Preferences Settings Drawer */}
      {showSettings && onUpdateSettings && (
        <div className="p-4 mb-4 rounded-xl bg-[#161616] border border-[#2A2A2A] animate-in fade-in duration-150">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-medium text-[#888888] mb-1">
                Candle Lighting Offset
              </label>
              <select
                value={settings.candleLightingOffset}
                onChange={(e) =>
                  onUpdateSettings({ candleLightingOffset: parseInt(e.target.value, 10) })
                }
                className="w-full px-2.5 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
              >
                <option value={18}>18 minutes (Standard Diaspora)</option>
                <option value={20}>20 minutes (Tel Aviv / Haifa)</option>
                <option value={24}>24 minutes</option>
                <option value={30}>30 minutes (Safed)</option>
                <option value={40}>40 minutes (Jerusalem)</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-[#888888] mb-1">
                Havdalah Calculation
              </label>
              <select
                value={settings.havdalahOpinion}
                onChange={(e) =>
                  onUpdateSettings({
                    havdalahOpinion: e.target.value as UserSettings['havdalahOpinion'],
                  })
                }
                className="w-full px-2.5 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
              >
                <option value="8.5">8.5° below horizon (3 medium stars)</option>
                <option value="42">42 minutes after sunset</option>
                <option value="50">50 minutes after sunset</option>
                <option value="72">72 minutes (Rabbeinu Tam)</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {viewMode === 'weekly' ? (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs" dir={settings.language === 'he' ? 'rtl' : 'ltr'}>
            <thead>
              <tr className="border-b border-[#2A2A2A] text-[#555555]">
                <th className={`py-2 pr-2 font-bold uppercase tracking-wider min-w-[70px] ${settings.language === 'he' ? 'text-right' : 'text-left'}`}>
                  {settings.language === 'he' ? 'יום' : 'Day'}
                </th>
                <th className="py-2 px-1 font-bold uppercase tracking-wider text-center">
                  {settings.language === 'he' ? 'נץ החמה' : 'Netz'}
                </th>
                <th className="py-2 px-1 font-bold uppercase tracking-wider text-center">
                  {settings.language === 'he' ? 'שמע (גר"א)' : 'Shma (GRA)'}
                </th>
                <th className="py-2 px-1 font-bold uppercase tracking-wider text-center">
                  {settings.language === 'he' ? 'תפילה (גר"א)' : 'Tefilah (GRA)'}
                </th>
                <th className="py-2 px-1 font-bold uppercase tracking-wider text-center">
                  {settings.language === 'he' ? 'חצות' : 'Chatzot'}
                </th>
                <th className={`py-2 pl-1 font-bold uppercase tracking-wider text-center`}>
                  {settings.language === 'he' ? 'שקיעה' : 'Shkiah'}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A2A2A]/40">
              {weeklyZmanim.map(({ date: dayDate, data }) => {
                const isSelectedDay =
                  dayDate.getDate() === date.getDate() &&
                  dayDate.getMonth() === date.getMonth() &&
                  dayDate.getFullYear() === date.getFullYear();

                const dayOfWeekStr = dayDate.toLocaleDateString(settings.language === 'he' ? 'he-IL' : 'en-US', { weekday: 'short' });
                const dayNum = dayDate.getDate();

                const sunriseStr = data.items.find((z) => z.id === 'sunrise')?.formattedTime || '--:--';
                const shmaStr = data.items.find((z) => z.id === 'shma_gra')?.formattedTime || '--:--';
                const tefilahStr = data.items.find((z) => z.id === 'tfilla_gra')?.formattedTime || '--:--';
                const chatzotStr = data.items.find((z) => z.id === 'chatzot')?.formattedTime || '--:--';
                const sunsetStr = data.items.find((z) => z.id === 'sunset')?.formattedTime || '--:--';

                return (
                  <tr
                    key={dayDate.toISOString()}
                    className={`hover:bg-[#1C1C1C] transition-colors ${
                      isSelectedDay ? 'bg-[#222222] font-semibold text-[#C5A267]' : 'text-[#888888]'
                    }`}
                  >
                    <td className={`py-3 pr-2 font-serif-hebrew ${settings.language === 'he' ? 'text-right' : 'text-left'}`}>
                      <span className="block font-bold">{dayOfWeekStr}</span>
                      <span className="text-[10px] text-[#555555]">{dayNum}</span>
                    </td>
                    <td className="py-3 px-1 text-center font-mono">{sunriseStr}</td>
                    <td className="py-3 px-1 text-center font-mono">{shmaStr}</td>
                    <td className="py-3 px-1 text-center font-mono">{tefilahStr}</td>
                    <td className="py-3 px-1 text-center font-mono">{chatzotStr}</td>
                    <td className="py-3 pl-1 text-center font-mono">{sunsetStr}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <>
          {/* Solar Progress Bar Arc */}
          <div className="mb-6 p-3.5 rounded-xl bg-[#161616] border border-[#2A2A2A]">
            <div className="flex items-center justify-between text-xs mb-2">
              <div className="flex items-center gap-1 text-[#888888]">
                <Sunrise className="w-3.5 h-3.5 text-[#C5A267]" />
                <span>Netz: <strong className="text-[#EAEAEA] font-mono">{formatSimple(zmanimData.sunrise)}</strong></span>
              </div>
              {zmanimData.nextZman && isToday && (
                <div className="text-[11px] px-2 py-0.5 rounded-md bg-[#252525] border border-[#3A3A3A] text-[#C5A267] font-semibold flex items-center gap-1">
                  <Clock className="w-3 h-3 animate-pulse" />
                  <span>{zmanimData.nextZman.hebrewTitle} {zmanimData.nextZman.timeRemaining}</span>
                </div>
              )}
              <div className="flex items-center gap-1 text-[#888888]">
                <Sunset className="w-3.5 h-3.5 text-[#C5A267]" />
                <span>Shkiah: <strong className="text-[#EAEAEA] font-mono">{formatSimple(zmanimData.sunset)}</strong></span>
              </div>
            </div>

            <div className="w-full h-1.5 bg-[#252525] rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#C5A267]/70 via-[#C5A267] to-[#FCD34D] transition-all duration-1000"
                style={{ width: `${zmanimData.solarProgress}%` }}
              />
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1 mb-4 pb-2 border-b border-[#2A2A2A] overflow-x-auto">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'morning', label: 'Morning' },
                { id: 'afternoon', label: 'Mincha' },
                { id: 'night', label: 'Evening' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedCategory(tab.id as any)}
                className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                  selectedCategory === tab.id
                    ? 'bg-[#2A2A2A] text-[#C5A267] border border-[#3A3A3A]'
                    : 'text-[#666666] hover:text-[#888888]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Zmanim Table Rows matching Elegant Dark specifications */}
          <div className="space-y-3">
            {filteredItems.map((z) => {
              const isNext = isToday && z.isNext;
              const isPassed = isToday && z.isPassed;

              return (
                <div
                  key={z.id}
                  onClick={() => setExpandedZmanInfo(expandedZmanInfo === z.id ? null : z.id)}
                  className={`flex justify-between items-center text-sm py-2 px-2.5 rounded-lg transition-colors cursor-pointer ${
                    isNext
                      ? 'font-bold text-[#C5A267] bg-[#222222] border-l-2 border-[#C5A267]'
                      : isPassed
                      ? 'text-[#555555] hover:bg-[#161616]'
                      : 'text-[#888888] hover:bg-[#161616] hover:text-[#D1D1D1]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={isNext ? 'text-[#C5A267]' : 'text-[#888888]'}>
                      {z.title}
                    </span>
                    <span className="text-xs text-[#555555] font-hebrew" dir="rtl">
                      ({z.hebrewTitle})
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`font-mono ${isNext ? 'text-[#C5A267]' : 'text-[#EAEAEA]'}`}>
                      {z.formattedTime}
                    </span>
                    {isNext && z.timeRemaining && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#C5A267] text-[#0F0F0F] font-bold font-mono">
                        {z.timeRemaining}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
};

function formatSimple(d: Date | null | undefined): string {
  if (!d) return '--:--';
  return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true });
}
