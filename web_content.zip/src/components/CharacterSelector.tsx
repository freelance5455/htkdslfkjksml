import React from 'react';
import { VoiceGender } from '../types';
import { User, Sparkles } from 'lucide-react';

interface CharacterSelectorProps {
  gender: VoiceGender;
  onSelectGender: (gender: VoiceGender) => void;
  disabled?: boolean;
}

export const CharacterSelector: React.FC<CharacterSelectorProps> = ({
  gender,
  onSelectGender,
  disabled,
}) => {
  return (
    <div className="w-full max-w-sm mx-auto px-4 mt-1 mb-2">
      <div className="flex items-center justify-between p-1 bg-slate-100/90 rounded-2xl border border-slate-200">
        {/* Female Character Option */}
        <button
          onClick={() => onSelectGender('female')}
          disabled={disabled}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            gender === 'female'
              ? 'bg-white text-rose-700 shadow-xs border border-rose-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <div
            className={`w-6 h-6 rounded-full flex items-center justify-center ${
              gender === 'female' ? 'bg-rose-100 text-rose-600' : 'bg-slate-200 text-slate-500'
            }`}
          >
            👩
          </div>
          <div className="text-left">
            <span className="block leading-tight">Female</span>
            <span className="text-[10px] text-slate-400 font-normal">Kore Voice</span>
          </div>
        </button>

        {/* Male Character Option */}
        <button
          onClick={() => onSelectGender('male')}
          disabled={disabled}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            gender === 'male'
              ? 'bg-white text-indigo-700 shadow-xs border border-indigo-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <div
            className={`w-6 h-6 rounded-full flex items-center justify-center ${
              gender === 'male' ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-200 text-slate-500'
            }`}
          >
            👨
          </div>
          <div className="text-left">
            <span className="block leading-tight">Male</span>
            <span className="text-[10px] text-slate-400 font-normal">Puck Voice</span>
          </div>
        </button>
      </div>
    </div>
  );
};
