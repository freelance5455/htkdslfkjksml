import React, { useState } from 'react';
import { JobPosting } from '../types/job';
import { INDIA_STATES_AND_UTS } from '../data/indiaLocations';
import { JobCard } from './JobCard';
import { useTheme } from '../context/ThemeContext';
import {
  Compass,
  MapPin,
  CheckCircle2,
  LocateFixed
} from 'lucide-react';

interface JobsNearMeProps {
  jobs: JobPosting[];
  savedJobIds: string[];
  onToggleSave: (jobId: string) => void;
  onOpenDetail: (job: JobPosting) => void;
  onReportJob?: (job: JobPosting) => void;
}

// Major hubs with preset coordinates for instant testing
const POPULAR_HUBS = [
  { name: 'Delhi NCR', state: 'Delhi (NCT)', district: 'New Delhi', lat: 28.6139, lng: 77.2090 },
  { name: 'Mumbai MMR', state: 'Maharashtra', district: 'Mumbai City', lat: 18.9220, lng: 72.8347 },
  { name: 'Bengaluru Tech Corridor', state: 'Karnataka', district: 'Bengaluru Urban', lat: 12.9716, lng: 77.5946 },
  { name: 'Hyderabad & Cyberabad', state: 'Telangana', district: 'Hyderabad', lat: 17.3850, lng: 78.4867 },
  { name: 'Pune Industrial Belt', state: 'Maharashtra', district: 'Pune', lat: 18.5204, lng: 73.8567 },
  { name: 'Lucknow & Awadh', state: 'Uttar Pradesh', district: 'Lucknow', lat: 26.8467, lng: 80.9462 },
  { name: 'Kolkata Metropolitan', state: 'West Bengal', district: 'Kolkata', lat: 22.5726, lng: 88.3639 },
  { name: 'Patna & Bihar Central', state: 'Bihar', district: 'Patna', lat: 25.5941, lng: 85.1376 },
  { name: 'Ahmedabad & Gandhinagar', state: 'Gujarat', district: 'Ahmedabad', lat: 23.0225, lng: 72.5714 }
];

export const JobsNearMe: React.FC<JobsNearMeProps> = ({
  jobs,
  savedJobIds,
  onToggleSave,
  onOpenDetail,
  onReportJob
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const [activeLocationName, setActiveLocationName] = useState<string>('Delhi NCR');
  const [activeState, setActiveState] = useState<string>('Delhi (NCT)');
  const [activeDistrict, setActiveDistrict] = useState<string>('New Delhi');
  const [isDetecting, setIsDetecting] = useState(false);
  const [detectionSuccess, setDetectionSuccess] = useState(false);
  const [searchRadiusKm, setSearchRadiusKm] = useState(150);

  // Calculate distance between two lat/lng in km (Haversine Formula)
  const getDistanceFromLatLonInKm = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Radius of earth in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const handleDetectGPS = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by this browser.');
      return;
    }

    setIsDetecting(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setIsDetecting(false);
        const { latitude, longitude } = position.coords;

        let closestState = INDIA_STATES_AND_UTS[0];
        let minDistance = Infinity;

        INDIA_STATES_AND_UTS.forEach((state) => {
          if (state.coordinates) {
            const dist = getDistanceFromLatLonInKm(
              latitude,
              longitude,
              state.coordinates.lat,
              state.coordinates.lng
            );
            if (dist < minDistance) {
              minDistance = dist;
              closestState = state;
            }
          }
        });

        setActiveLocationName(`${closestState.name} (GPS Detected)`);
        setActiveState(closestState.name);
        setActiveDistrict(closestState.districts[0] || 'All');
        setDetectionSuccess(true);
        setTimeout(() => setDetectionSuccess(false), 4000);
      },
      () => {
        setIsDetecting(false);
        // Graceful fallback to prominent state
        setActiveLocationName('Delhi NCR (Default Fallback)');
        setActiveState('Delhi (NCT)');
        setActiveDistrict('New Delhi');
      },
      { timeout: 8000 }
    );
  };

  // Filter jobs by current location selection
  const nearbyJobs = jobs.filter((job) => {
    const isSameDistrict = job.district.toLowerCase() === activeDistrict.toLowerCase();
    const isSameState = job.state.toLowerCase() === activeState.toLowerCase();
    return isSameDistrict || isSameState;
  });

  return (
    <div
      className={`flex-1 flex flex-col p-3 sm:p-5 space-y-4 transition-colors ${
        isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Header Banner */}
      <div
        className={`border p-4 rounded-2xl shadow-sm transition-colors ${
          isDark
            ? 'bg-gradient-to-r from-emerald-950/50 via-slate-900 to-slate-900 border-emerald-800/40 text-white'
            : 'bg-gradient-to-r from-emerald-50 via-white to-white border-emerald-200 text-slate-900'
        }`}
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${
                isDark
                  ? 'bg-emerald-600/20 border-emerald-500/30 text-emerald-400'
                  : 'bg-emerald-100 border-emerald-200 text-emerald-600'
              }`}
            >
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h1
                className={`text-base font-bold flex items-center gap-2 ${
                  isDark ? 'text-white' : 'text-slate-900'
                }`}
              >
                <span>Jobs Near Me</span>
                <span
                  className={`px-2 py-0.5 text-[9px] font-bold rounded-full border ${
                    isDark
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-emerald-100 text-emerald-800 border-emerald-200'
                  }`}
                >
                  GPS & Regional
                </span>
              </h1>
              <p className={`text-xs mt-0.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                Targeting vacancies within your district and neighboring regions
              </p>
            </div>
          </div>

          {/* GPS Auto-Detect Button */}
          <button
            id="btn-detect-gps"
            onClick={handleDetectGPS}
            disabled={isDetecting}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-900/30 transition-all active:scale-95 disabled:opacity-50 shrink-0"
          >
            <LocateFixed className={`w-4 h-4 ${isDetecting ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">
              {isDetecting ? 'Detecting...' : 'Detect GPS'}
            </span>
          </button>
        </div>

        {detectionSuccess && (
          <div
            className={`mt-3 p-2 rounded-xl text-xs flex items-center gap-2 border ${
              isDark
                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                : 'bg-emerald-50 border-emerald-200 text-emerald-800'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>GPS location detected! Showing nearest state vacancies.</span>
          </div>
        )}
      </div>

      {/* Quick Regional Hub Selectors */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span
            className={`text-xs font-bold uppercase tracking-wider ${
              isDark ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            Quick Hub Select
          </span>
          <span className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Current: <strong className={isDark ? 'text-emerald-400' : 'text-emerald-600'}>{activeLocationName}</strong>
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none -mx-1 px-1">
          {POPULAR_HUBS.map((hub) => {
            const isSelected = activeState === hub.state && activeDistrict === hub.district;
            return (
              <button
                key={hub.name}
                id={`btn-hub-${hub.name.replace(/\s+/g, '-').toLowerCase()}`}
                onClick={() => {
                  setActiveLocationName(hub.name);
                  setActiveState(hub.state);
                  setActiveDistrict(hub.district);
                }}
                className={`whitespace-nowrap px-3 py-1.5 rounded-xl text-xs font-medium border transition-all shrink-0 ${
                  isSelected
                    ? isDark
                      ? 'bg-emerald-600/30 border-emerald-500 text-emerald-200 shadow-sm font-semibold'
                      : 'bg-emerald-600 text-white border-emerald-600 shadow-sm font-semibold'
                    : isDark
                    ? 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100 shadow-sm'
                }`}
              >
                📍 {hub.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Location Info & Radius filter */}
      <div
        className={`p-3 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs border transition-colors ${
          isDark
            ? 'bg-slate-900 border-slate-800'
            : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex items-center gap-2">
          <MapPin className={`w-4 h-4 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`} />
          <span className={isDark ? 'text-slate-300' : 'text-slate-700'}>
            Showing openings in <strong className={isDark ? 'text-white' : 'text-slate-900'}>{activeDistrict}</strong>, {activeState}
          </span>
        </div>
        <div className={`flex items-center gap-2 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          <span>Search Radius:</span>
          <select
            value={searchRadiusKm}
            onChange={(e) => setSearchRadiusKm(Number(e.target.value))}
            className={`px-2 py-1 rounded-lg text-xs border ${
              isDark
                ? 'bg-slate-950 border-slate-800 text-slate-200'
                : 'bg-slate-50 border-slate-200 text-slate-800'
            }`}
          >
            <option value={50}>50 km</option>
            <option value={150}>150 km</option>
            <option value={300}>300 km</option>
            <option value={1000}>Entire State</option>
          </select>
        </div>
      </div>

      {/* Job listings near me */}
      <div className="space-y-3">
        {nearbyJobs.length > 0 ? (
          nearbyJobs.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              isSaved={savedJobIds.includes(job.id)}
              onToggleSave={onToggleSave}
              onOpenDetail={onOpenDetail}
              onReportJob={onReportJob}
            />
          ))
        ) : (
          <div
            className={`rounded-2xl p-8 text-center space-y-2 border transition-colors ${
              isDark
                ? 'bg-slate-900 border-slate-800'
                : 'bg-white border-slate-200 shadow-sm'
            }`}
          >
            <Compass className={`w-8 h-8 mx-auto ${isDark ? 'text-slate-500' : 'text-slate-400'}`} />
            <h3 className={`text-sm font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
              No Direct Local Openings
            </h3>
            <p className={`text-xs max-w-sm mx-auto ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              No specific openings mapped directly to {activeDistrict} at this moment. You can view all-India government postings or expand the search radius!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
