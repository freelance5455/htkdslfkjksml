import React, { useState } from 'react';
import { CreditCard, TrendingUp, Receipt, DollarSign, ArrowUpRight, Percent, Calendar } from 'lucide-react';
import { audioService } from '../services/audioService';
import { historyStorage } from '../services/historyStorage';

interface FinanceSuiteViewProps {
  onShowToast: (text: string, type?: 'success' | 'info' | 'error') => void;
  onSendToCalculator: (val: string) => void;
}

type FinanceTab = 'emi' | 'compound' | 'gst' | 'margin';

export const FinanceSuiteView: React.FC<FinanceSuiteViewProps> = ({
  onShowToast,
  onSendToCalculator,
}) => {
  const [activeTab, setActiveTab] = useState<FinanceTab>('emi');

  // --- 1. Loan EMI State ---
  const [loanPrincipal, setLoanPrincipal] = useState<number>(250000);
  const [loanRate, setLoanRate] = useState<number>(6.5);
  const [loanYears, setLoanYears] = useState<number>(15);

  // EMI Formula: E = P * r * (1+r)^n / ((1+r)^n - 1)
  const monthlyRate = loanRate / 12 / 100;
  const totalMonths = loanYears * 12;
  const emi =
    monthlyRate === 0
      ? loanPrincipal / totalMonths
      : (loanPrincipal * monthlyRate * Math.pow(1 + monthlyRate, totalMonths)) /
        (Math.pow(1 + monthlyRate, totalMonths) - 1);
  const totalLoanAmount = emi * totalMonths;
  const totalInterest = totalLoanAmount - loanPrincipal;

  // --- 2. Compound Interest State ---
  const [compPrincipal, setCompPrincipal] = useState<number>(10000);
  const [compRate, setCompRate] = useState<number>(8.0);
  const [compYears, setCompYears] = useState<number>(5);
  const [compFreq, setCompFreq] = useState<number>(12); // 12=monthly, 4=quarterly, 1=annually, 365=daily

  // A = P(1 + r/n)^(nt)
  const compMaturity =
    compPrincipal * Math.pow(1 + compRate / 100 / compFreq, compFreq * compYears);
  const compTotalInterest = compMaturity - compPrincipal;

  // --- 3. GST / Tax State ---
  const [taxAmountInput, setTaxAmountInput] = useState<number>(450);
  const [taxRateInput, setTaxRateInput] = useState<number>(18);
  const [taxOperation, setTaxOperation] = useState<'add' | 'remove'>('add');

  let netPrice = taxAmountInput;
  let taxCharged = 0;
  let grossPrice = taxAmountInput;

  if (taxOperation === 'add') {
    // Net to Gross: Gross = Net + (Net * rate / 100)
    netPrice = taxAmountInput;
    taxCharged = (netPrice * taxRateInput) / 100;
    grossPrice = netPrice + taxCharged;
  } else {
    // Gross to Net: Net = Gross / (1 + rate / 100)
    grossPrice = taxAmountInput;
    netPrice = grossPrice / (1 + taxRateInput / 100);
    taxCharged = grossPrice - netPrice;
  }

  // --- 4. Profit Margin & Markup State ---
  const [costPrice, setCostPrice] = useState<number>(45);
  const [sellingPrice, setSellingPrice] = useState<number>(75);

  const grossProfit = sellingPrice - costPrice;
  const marginPercent = sellingPrice > 0 ? (grossProfit / sellingPrice) * 100 : 0;
  const markupPercent = costPrice > 0 ? (grossProfit / costPrice) * 100 : 0;

  const handleTabChange = (tab: FinanceTab) => {
    audioService.playKeyClick();
    setActiveTab(tab);
  };

  const handleSendVal = (val: number, label: string) => {
    audioService.playKeyClick();
    const formatted = val.toFixed(2);
    onSendToCalculator(formatted);
    historyStorage.add({
      type: 'finance',
      title: label,
      expression: `${label}`,
      result: `$${formatted}`,
      numericResult: Number(formatted),
    });
    onShowToast(`Sent $${formatted} to Calculator!`, 'success');
  };

  return (
    <div className="flex flex-col h-full w-full max-w-md mx-auto p-3.5 space-y-3.5 overflow-y-auto">
      {/* Sub-Tabs */}
      <div className="grid grid-cols-4 gap-1 p-1 bg-[#0a0c12] rounded-xl border border-zinc-800 text-[11px] font-mono">
        <button
          onClick={() => handleTabChange('emi')}
          className={`py-2 rounded-lg transition font-medium text-center ${
            activeTab === 'emi'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-sm font-bold'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Loan EMI
        </button>
        <button
          onClick={() => handleTabChange('compound')}
          className={`py-2 rounded-lg transition font-medium text-center ${
            activeTab === 'compound'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-sm font-bold'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Growth
        </button>
        <button
          onClick={() => handleTabChange('gst')}
          className={`py-2 rounded-lg transition font-medium text-center ${
            activeTab === 'gst'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-sm font-bold'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          GST / Tax
        </button>
        <button
          onClick={() => handleTabChange('margin')}
          className={`py-2 rounded-lg transition font-medium text-center ${
            activeTab === 'margin'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-sm font-bold'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Margin
        </button>
      </div>

      {/* 1. Loan EMI View */}
      {activeTab === 'emi' && (
        <div className="space-y-3">
          <div className="rounded-2xl bg-[#0f111a] border border-amber-500/20 p-4 space-y-3">
            <h4 className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <CreditCard className="w-4 h-4 text-amber-400" />
              <span>Loan & Mortgage EMI Calculator</span>
            </h4>

            {/* Principal */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Principal Amount:</span>
                <span className="text-amber-200 font-bold">${loanPrincipal.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="5000"
                max="2000000"
                step="5000"
                value={loanPrincipal}
                onChange={(e) => setLoanPrincipal(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
              <div className="flex gap-1.5 mt-1.5">
                {[50000, 150000, 300000, 500000].map((val) => (
                  <button
                    key={val}
                    onClick={() => setLoanPrincipal(val)}
                    className="flex-1 py-1 rounded bg-zinc-900 border border-zinc-800 text-[10px] font-mono text-zinc-300 hover:text-amber-300"
                  >
                    ${val / 1000}k
                  </button>
                ))}
              </div>
            </div>

            {/* Interest Rate */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Annual Interest Rate (%):</span>
                <span className="text-amber-200 font-bold">{loanRate}%</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="20.0"
                step="0.25"
                value={loanRate}
                onChange={(e) => setLoanRate(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>

            {/* Tenure */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Tenure (Years):</span>
                <span className="text-amber-200 font-bold">{loanYears} Years ({loanYears * 12} mo)</span>
              </div>
              <div className="flex gap-2">
                {[5, 10, 15, 20, 30].map((yr) => (
                  <button
                    key={yr}
                    onClick={() => setLoanYears(yr)}
                    className={`flex-1 py-1 rounded-lg border text-xs font-mono transition ${
                      loanYears === yr
                        ? 'bg-amber-500/25 border-amber-400 text-amber-200 font-bold'
                        : 'bg-zinc-900/80 border-zinc-800 text-zinc-400'
                    }`}
                  >
                    {yr}y
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* EMI Results Card */}
          <div className="rounded-2xl bg-gradient-to-br from-[#161a29] to-[#0c0e17] border border-amber-500/30 p-4 space-y-3 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-zinc-400 uppercase">Monthly Payment (EMI)</span>
                <div className="text-2xl sm:text-3xl font-mono font-bold gold-gradient-text">
                  ${emi.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              </div>
              <button
                onClick={() => handleSendVal(emi, 'Monthly EMI')}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/30 border border-amber-400/40 text-xs font-mono text-amber-300 flex items-center gap-1 transition"
              >
                <span>To Calc</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800 text-xs font-mono">
              <div className="p-2.5 rounded-xl bg-[#090b10] border border-zinc-800">
                <span className="text-zinc-400 text-[10px] block">Total Interest</span>
                <span className="text-rose-400 font-semibold">
                  ${totalInterest.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#090b10] border border-zinc-800">
                <span className="text-zinc-400 text-[10px] block">Total Payment (P + I)</span>
                <span className="text-amber-200 font-semibold">
                  ${totalLoanAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Compound Interest View */}
      {activeTab === 'compound' && (
        <div className="space-y-3">
          <div className="rounded-2xl bg-[#0f111a] border border-amber-500/20 p-4 space-y-3">
            <h4 className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <span>Compound Wealth Growth</span>
            </h4>

            {/* Principal */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Initial Deposit (P):</span>
                <span className="text-amber-200 font-bold">${compPrincipal.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="500"
                max="500000"
                step="500"
                value={compPrincipal}
                onChange={(e) => setCompPrincipal(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>

            {/* Return Rate */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Annual Return (r):</span>
                <span className="text-amber-200 font-bold">{compRate}%</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="30.0"
                step="0.5"
                value={compRate}
                onChange={(e) => setCompRate(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>

            {/* Compounding Frequency */}
            <div>
              <span className="text-zinc-400 text-xs font-mono block mb-1">Compounding Frequency:</span>
              <div className="grid grid-cols-4 gap-1 text-xs font-mono">
                {[
                  { label: 'Annually', freq: 1 },
                  { label: 'Quarterly', freq: 4 },
                  { label: 'Monthly', freq: 12 },
                  { label: 'Daily', freq: 365 },
                ].map((item) => (
                  <button
                    key={item.freq}
                    onClick={() => setCompFreq(item.freq)}
                    className={`py-1.5 rounded-lg border text-center transition ${
                      compFreq === item.freq
                        ? 'bg-amber-500/25 border-amber-400 text-amber-200 font-bold'
                        : 'bg-zinc-900/80 border-zinc-800 text-zinc-400'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Maturity Card */}
          <div className="rounded-2xl bg-gradient-to-br from-[#161a29] to-[#0c0e17] border border-amber-500/30 p-4 space-y-3 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-zinc-400 uppercase">
                  Future Portfolio Value ({compYears} Years)
                </span>
                <div className="text-2xl sm:text-3xl font-mono font-bold gold-gradient-text">
                  ${compMaturity.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              </div>
              <button
                onClick={() => handleSendVal(compMaturity, 'Compound Maturity')}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/30 border border-amber-400/40 text-xs font-mono text-amber-300 flex items-center gap-1 transition"
              >
                <span>To Calc</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800 text-xs font-mono">
              <div className="p-2.5 rounded-xl bg-[#090b10] border border-zinc-800">
                <span className="text-zinc-400 text-[10px] block">Principal Invested</span>
                <span className="text-zinc-200 font-semibold">${compPrincipal.toLocaleString()}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#090b10] border border-zinc-800">
                <span className="text-zinc-400 text-[10px] block">Compound Interest</span>
                <span className="text-emerald-400 font-semibold">
                  +${compTotalInterest.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. GST / Tax Calculator */}
      {activeTab === 'gst' && (
        <div className="space-y-3">
          <div className="rounded-2xl bg-[#0f111a] border border-amber-500/20 p-4 space-y-3">
            <h4 className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <Receipt className="w-4 h-4 text-amber-400" />
              <span>GST & Sales Tax Calculator</span>
            </h4>

            {/* Instant Mode Toggle: + Add Tax / - Remove Tax */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  audioService.playKeyClick();
                  setTaxOperation('add');
                }}
                className={`py-2 rounded-xl text-xs font-mono font-bold transition border flex items-center justify-center gap-1.5 ${
                  taxOperation === 'add'
                    ? 'bg-amber-500/25 border-amber-400 text-amber-200 shadow-[0_0_12px_rgba(245,158,11,0.2)]'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                }`}
              >
                <span>+ Add Tax (Net → Gross)</span>
              </button>
              <button
                onClick={() => {
                  audioService.playKeyClick();
                  setTaxOperation('remove');
                }}
                className={`py-2 rounded-xl text-xs font-mono font-bold transition border flex items-center justify-center gap-1.5 ${
                  taxOperation === 'remove'
                    ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 shadow-[0_0_12px_rgba(6,182,212,0.2)]'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                }`}
              >
                <span>− Remove Tax (Gross → Net)</span>
              </button>
            </div>

            {/* Amount Input */}
            <div>
              <span className="text-zinc-400 text-xs font-mono block mb-1">
                {taxOperation === 'add' ? 'Net Base Amount ($):' : 'Gross Total Amount ($):'}
              </span>
              <input
                type="number"
                value={taxAmountInput}
                onChange={(e) => setTaxAmountInput(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0a0c12] border border-zinc-800 text-sm font-mono text-amber-200 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Tax Rate Presets */}
            <div>
              <span className="text-zinc-400 text-xs font-mono block mb-1">Tax Rate (%):</span>
              <div className="grid grid-cols-5 gap-1.5">
                {[5, 12, 18, 20, 28].map((rate) => (
                  <button
                    key={rate}
                    onClick={() => setTaxRateInput(rate)}
                    className={`py-1.5 rounded-lg border text-xs font-mono font-semibold transition ${
                      taxRateInput === rate
                        ? 'bg-amber-400 text-black border-amber-300'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-300'
                    }`}
                  >
                    {rate}%
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Tax Result Breakdown Card */}
          <div className="rounded-2xl bg-gradient-to-br from-[#161a29] to-[#0c0e17] border border-amber-500/30 p-4 space-y-3 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-zinc-400 uppercase">
                  {taxOperation === 'add' ? 'Gross Invoice Outlay' : 'Net Pre-Tax Base'}
                </span>
                <div className="text-2xl sm:text-3xl font-mono font-bold gold-gradient-text">
                  ${(taxOperation === 'add' ? grossPrice : netPrice).toFixed(2)}
                </div>
              </div>
              <button
                onClick={() =>
                  handleSendVal(
                    taxOperation === 'add' ? grossPrice : netPrice,
                    taxOperation === 'add' ? 'Gross Amount' : 'Net Amount'
                  )
                }
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/30 border border-amber-400/40 text-xs font-mono text-amber-300 flex items-center gap-1 transition"
              >
                <span>To Calc</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800 text-xs font-mono">
              <div className="p-2.5 rounded-xl bg-[#090b10] border border-zinc-800">
                <span className="text-zinc-400 text-[10px] block">Net Base</span>
                <span className="text-zinc-200 font-semibold">${netPrice.toFixed(2)}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#090b10] border border-zinc-800">
                <span className="text-zinc-400 text-[10px] block">Tax Component ({taxRateInput}%)</span>
                <span className="text-cyan-400 font-semibold">${taxCharged.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Profit Margin & Markup */}
      {activeTab === 'margin' && (
        <div className="space-y-3">
          <div className="rounded-2xl bg-[#0f111a] border border-amber-500/20 p-4 space-y-3">
            <h4 className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>Profit Margin & Markup Analysis</span>
            </h4>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-zinc-400 text-xs font-mono block mb-1">Cost Price ($):</span>
                <input
                  type="number"
                  value={costPrice}
                  onChange={(e) => setCostPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full px-3 py-2 rounded-xl bg-[#0a0c12] border border-zinc-800 text-sm font-mono text-zinc-100 focus:outline-none focus:border-amber-400"
                />
              </div>
              <div>
                <span className="text-zinc-400 text-xs font-mono block mb-1">Selling Price ($):</span>
                <input
                  type="number"
                  value={sellingPrice}
                  onChange={(e) => setSellingPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full px-3 py-2 rounded-xl bg-[#0a0c12] border border-zinc-800 text-sm font-mono text-zinc-100 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          </div>

          {/* Margin Results Card */}
          <div className="rounded-2xl bg-gradient-to-br from-[#161a29] to-[#0c0e17] border border-amber-500/30 p-4 space-y-3 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-zinc-400 uppercase">Gross Profit</span>
                <div className="text-2xl sm:text-3xl font-mono font-bold text-emerald-400">
                  ${grossProfit.toFixed(2)}
                </div>
              </div>
              <button
                onClick={() => handleSendVal(grossProfit, 'Gross Profit')}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/30 border border-amber-400/40 text-xs font-mono text-amber-300 flex items-center gap-1 transition"
              >
                <span>To Calc</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800 text-xs font-mono">
              <div className="p-2.5 rounded-xl bg-[#090b10] border border-zinc-800">
                <span className="text-zinc-400 text-[10px] block">Profit Margin (%)</span>
                <span className="text-amber-300 font-semibold text-sm">
                  {marginPercent.toFixed(2)}%
                </span>
                <span className="text-[9px] text-zinc-500 block">Profit ÷ Selling Price</span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#090b10] border border-zinc-800">
                <span className="text-zinc-400 text-[10px] block">Markup (%)</span>
                <span className="text-cyan-300 font-semibold text-sm">
                  {markupPercent.toFixed(2)}%
                </span>
                <span className="text-[9px] text-zinc-500 block">Profit ÷ Cost Price</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
