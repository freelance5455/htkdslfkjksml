"use client";

import dynamic from "next/dynamic";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useCalculator } from "@/lib/useCalculator";
import { KEY_MAP, PAD_LAYOUT, type KeyTone } from "@/lib/calc-keys";
import type { ScreenData } from "@/lib/calculator";

const Calculator3D = dynamic(() => import("@/components/Calculator3D"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center">
      <div className="h-[75%] w-[40%] max-w-[240px] animate-pulse rounded-[2.5rem] bg-[radial-gradient(ellipse_at_center,rgba(139,92,246,0.35),transparent_70%)]" />
    </div>
  ),
});

const BODY_COLORS = [
  { name: "Midnight Black", hex: "#1c1d22", accent: "#8b5cf6" },
  { name: "Blossom Pink", hex: "#f2c4cf", accent: "#ec4899" },
  { name: "Arctic White", hex: "#e8eaef", accent: "#38bdf8" },
  { name: "Nebula Purple", hex: "#3a1d6b", accent: "#c084fc" },
  { name: "Ocean Blue", hex: "#1d3766", accent: "#22d3ee" },
];

/* ---------------------------------------------------------- LCD replica */

function LcdDisplay({ screen }: { screen: ScreenData }) {
  const chars = Array.from(screen.expression);
  const cur = screen.cursor;
  const before = cur === null ? chars.join("") : chars.slice(0, cur).join("");
  const after = cur === null ? "" : chars.slice(cur).join("");
  return (
    <div className="rounded-2xl border-[6px] border-[#0b0c0f] bg-gradient-to-b from-[#d6dfcd] to-[#b7c3ad] p-3 font-mono text-[#1a211c] shadow-[inset_0_6px_14px_rgba(0,0,0,0.25)]">
      <div className="flex items-center gap-1.5 text-[11px] font-bold">
        {screen.shift && <span className="bg-[#1a211c] px-1 text-[#d6dfcd]">S</span>}
        <span className="bg-[#1a211c] px-1 text-[#d6dfcd]">{screen.angle === "DEG" ? "D" : "R"}</span>
        <span>Math</span>
        {screen.fraction && <span>a/b</span>}
        <span className="ml-auto">▲▼</span>
      </div>
      {screen.error ? (
        <div className="py-3 text-center">
          <p className="text-2xl font-bold">{screen.error}</p>
          <p className="mt-1 text-[11px]">[AC] :Cancel  [◀][▶] :Goto</p>
        </div>
      ) : (
        <>
          <p className="mt-1 min-h-[1.9rem] break-all text-xl leading-snug">
            {before}
            {cur !== null && <span className="animate-pulse font-black">|</span>}
            {after}
          </p>
          <p className="min-h-[2.75rem] truncate text-right text-4xl font-bold">{screen.result ?? ""}</p>
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------- touch keypad */

const TONE_CLASS: Record<KeyTone, string> = {
  base: "bg-gradient-to-b from-[#34363e] to-[#26282e] text-white",
  func: "bg-gradient-to-b from-[#2b2d33] to-[#202227] text-slate-200 text-[13px]",
  nav: "bg-gradient-to-b from-[#2f3137] to-[#23252a] text-slate-200 text-[11px]",
  shift: "bg-gradient-to-b from-amber-300 to-amber-500 text-amber-950 text-[10px]",
  danger: "bg-gradient-to-b from-[#34363e] to-[#26282e] text-rose-300",
  exe: "bg-gradient-to-br from-purple-500 to-blue-600 text-white shadow-[0_0_18px_rgba(139,92,246,0.55)] text-sm",
};

function PadKey({
  id,
  onKey,
  pressed,
  shift,
  size,
}: {
  id: string;
  onKey: (id: string) => void;
  pressed: boolean;
  shift: boolean;
  size: "nav" | "func" | "main";
}) {
  const def = KEY_MAP[id];
  if (!def) return null;
  const active = id === "shift" && shift;
  const sizeClass =
    size === "main"
      ? "h-12 rounded-[1.1rem] text-xl sm:h-14"
      : size === "func"
        ? "h-9 rounded-full"
        : "h-10 rounded-full";
  return (
    <div className="flex flex-col items-center gap-0.5">
      <span
        className={`h-3.5 text-[10px] font-bold leading-none transition ${
          def.shiftLabel ? (shift ? "text-amber-300" : "text-amber-400/70") : "text-transparent"
        }`}
      >
        {def.shiftLabel ?? "·"}
      </span>
      <button
        onPointerDown={(e) => {
          e.preventDefault();
          onKey(id);
        }}
        aria-label={def.label}
        className={`w-full select-none border border-white/10 font-bold shadow-[inset_0_-3px_0_rgba(0,0,0,0.45),0_2px_6px_rgba(0,0,0,0.4)] transition-all duration-100 active:translate-y-0.5 active:scale-95 ${sizeClass} ${TONE_CLASS[def.tone]} ${
          pressed ? "translate-y-0.5 scale-95 ring-2 ring-purple-400" : ""
        } ${active ? "ring-2 ring-amber-300 brightness-125" : ""} ${shift && def.shiftLabel ? "opacity-80" : ""}`}
      >
        {def.label}
      </button>
    </div>
  );
}

function KeyPad({ onKey, pressedId, shift }: { onKey: (id: string) => void; pressedId: string | null; shift: boolean }) {
  return (
    <div className="space-y-2">
      <div className="grid grid-cols-6 gap-1.5">
        {PAD_LAYOUT.nav1.map((id) => (
          <PadKey key={id} id={id} onKey={onKey} pressed={pressedId === id} shift={shift} size="nav" />
        ))}
      </div>
      <div className="mx-auto grid max-w-[85%] grid-cols-5 gap-1.5">
        {PAD_LAYOUT.nav2.map((id) => (
          <PadKey key={id} id={id} onKey={onKey} pressed={pressedId === id} shift={shift} size="nav" />
        ))}
      </div>
      {PAD_LAYOUT.func.map((row, i) => (
        <div key={i} className="grid grid-cols-6 gap-1.5">
          {row.map((id) => (
            <PadKey key={id} id={id} onKey={onKey} pressed={pressedId === id} shift={shift} size="func" />
          ))}
        </div>
      ))}
      <div className="h-1" />
      {PAD_LAYOUT.main.map((row, i) => (
        <div key={i} className="grid grid-cols-5 gap-2">
          {row.map((id) => (
            <PadKey key={id} id={id} onKey={onKey} pressed={pressedId === id} shift={shift} size="main" />
          ))}
        </div>
      ))}
    </div>
  );
}

/* --------------------------------------------------------------- section */

export default function CalculatorSection() {
  const { screen, history, pressKey, dispatch, clearHistory, pressedId } = useCalculator({ keyboard: true });
  const [body, setBody] = useState(BODY_COLORS[0]);

  return (
    <section id="calculator" className="relative py-24">
      <div className="mx-auto max-w-7xl px-4">
        <div className="mb-12 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-purple-400">Interactive 3D Scientific Calculator</p>
          <h2 className="mt-3 font-display text-4xl font-bold text-white md:text-5xl">
            CALCORA <span className="text-gradient">ClassPro</span> CW
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-slate-400">
            Inspired by the classic ClassWiz design. Real scientific maths: sin, cos, tan, log, ln, √, xʸ, n!, π, e,
            brackets, Ans, SHIFT functions, DEG/RAD and fraction ⇔ decimal. Tap the 3D keys or use the touch pad.
          </p>
        </div>

        <div className="grid items-start gap-8 lg:grid-cols-[1fr_420px]">
          {/* 3D calculator */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass relative overflow-hidden rounded-3xl"
          >
            <div className="absolute left-4 top-4 z-10 flex flex-wrap gap-2">
              {BODY_COLORS.map((c) => (
                <button
                  key={c.name}
                  onClick={() => setBody(c)}
                  title={c.name}
                  aria-label={c.name}
                  className={`h-8 w-8 rounded-full border-2 transition ${
                    body.name === c.name ? "scale-110 border-purple-300 shadow-[0_0_16px_rgba(168,85,247,0.7)]" : "border-white/25 hover:border-white/60"
                  }`}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
            </div>
            <p className="absolute right-4 top-5 z-10 hidden text-xs font-semibold text-slate-400 sm:block">{body.name}</p>
            <div className="h-[78svh] min-h-[560px] w-full lg:h-[820px]">
              <Calculator3D
                screen={screen}
                onKey={pressKey}
                pressedId={pressedId}
                bodyColor={body.hex}
                accent={body.accent}
                sway={0.18}
                cameraZ={14.2}
              />
            </div>
          </motion.div>

          {/* LCD + keypad + history */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="rounded-[2rem] border border-white/10 bg-gradient-to-b from-[#1d1e23] to-[#121317] p-4 shadow-[0_0_60px_rgba(139,92,246,0.18)]"
            >
              <div className="mb-3 flex items-center justify-between px-1">
                <span className="font-display text-sm font-black tracking-wider text-white">CALCORA</span>
                <span className="h-4 w-20 rounded-sm bg-gradient-to-r from-[#3a2620] to-[#160c0a]" />
              </div>
              <LcdDisplay screen={screen} />
              <p className="mb-3 mt-2 text-right text-[10px] italic tracking-[0.35em] text-slate-500">CLASSPRO</p>
              <KeyPad onKey={pressKey} pressedId={pressedId} shift={screen.shift} />
              <p className="mt-4 text-center text-[11px] text-slate-500">
                ⌨️ Keyboard: 0-9 + − * / ^ ( ) · Enter = EXE · Backspace = ⌫ · Esc = AC · s c t l n r p
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 backdrop-blur-xl"
            >
              <div className="mb-3 flex items-center justify-between">
                <h3 className="flex items-center gap-2 font-display text-lg text-white">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-purple-400" /> History
                </h3>
                {history.length > 0 && (
                  <button
                    onClick={clearHistory}
                    className="rounded-lg border border-white/10 px-2.5 py-1 text-xs text-slate-400 transition hover:border-red-400/40 hover:text-red-300"
                  >
                    Clear
                  </button>
                )}
              </div>
              <div className="max-h-72 space-y-2 overflow-y-auto pr-1">
                <AnimatePresence initial={false}>
                  {history.length === 0 && (
                    <p className="py-6 text-center text-sm text-slate-500">No calculations yet. Try sin(30) or √2÷2!</p>
                  )}
                  {history.map((h, i) => (
                    <motion.button
                      key={`${h.expr}-${h.result}-${history.length - i}`}
                      initial={{ opacity: 0, x: -16 }}
                      animate={{ opacity: 1, x: 0 }}
                      onClick={() => dispatch({ type: "recall", index: i })}
                      className="block w-full rounded-xl border border-white/5 bg-black/30 p-3 text-left transition hover:border-purple-400/40"
                    >
                      <p className="truncate font-mono text-xs text-slate-400">{h.expr}</p>
                      <p className="mt-0.5 text-right font-mono text-lg font-bold text-purple-300">= {h.result}</p>
                    </motion.button>
                  ))}
                </AnimatePresence>
              </div>
              <p className="mt-3 text-[11px] text-slate-500">Tap an entry (or press ▲▼) to recall it.</p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
