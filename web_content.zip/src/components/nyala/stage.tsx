import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  ArrowLeft,
  Crown,
  Flame,
  Flower2,
  Heart,
  Mic,
  MicOff,
  MonitorUp,
  Pin,
  Rocket,
  Send,
  Sparkles,
  SwitchCamera,
  Swords,
  Users,
  Video,
  VideoOff,
  type LucideIcon,
} from "lucide-react";
import { FILTERS, GIFTS, type FilterId, type GiftIcon } from "@/lib/live/catalog";
import {
  addHearts,
  cashOut,
  endRoom,
  joinBattle,
  pinNote,
  pulseRoom,
  sendChat,
  sendGift,
  startBattle,
  toggleFollow,
} from "@/lib/live/functions";
import { makePeerId } from "@/lib/live/ids";
import { StageLink, type LinkState } from "@/lib/live/media-room";
import type { BattleView, ChatLine, LiveRoom, Wallet } from "@/lib/live/types";
import { useLens } from "@/components/nyala/use-lens";
import { Splash } from "@/components/nyala/nyala-gate";

const GIFT_ICONS: Record<GiftIcon, LucideIcon> = {
  flame: Flame,
  flower: Flower2,
  crown: Crown,
  rocket: Rocket,
  spark: Sparkles,
};

function mergeLines(prev: ChatLine[], incoming: ChatLine[]) {
  const map = new Map(prev.map((line) => [line.id, line]));
  for (const line of incoming) map.set(line.id, line);
  return [...map.values()].sort((a, b) => a.id - b.id).slice(-80);
}

function Wave({ stream }: { stream: MediaStream | null }) {
  const [levels, setLevels] = useState<number[]>(() => Array.from({ length: 12 }, () => 8));
  useEffect(() => {
    const audio = stream?.getAudioTracks()[0];
    if (!stream || !audio) return;
    const ctx = new AudioContext();
    const source = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 64;
    source.connect(analyser);
    const bins = new Uint8Array(analyser.frequencyBinCount);
    let raf = 0;
    const tick = () => {
      analyser.getByteFrequencyData(bins);
      setLevels(Array.from(bins.slice(2, 14), (value) => Math.max(8, Math.round((value / 255) * 100))));
      raf = requestAnimationFrame(tick);
    };
    void ctx.resume().then(tick).catch(() => {});
    return () => {
      cancelAnimationFrame(raf);
      void ctx.close();
    };
  }, [stream]);
  return (
    <div className="flex h-36 items-end justify-center gap-1.5" aria-hidden="true">
      {levels.map((level, index) => (
        <span key={index} className="w-2 rounded-full bg-brass" style={{ height: `${level}%` }} />
      ))}
    </div>
  );
}

export function Stage({ roomId, userId, hintName }: { roomId: string; userId: string; hintName: string }) {
  const navigate = useNavigate();
  const peerId = useMemo(() => makePeerId(), []);
  const linkRef = useRef<StageLink | null>(null);
  const afterRef = useRef(0);
  const sentHearts = useRef(0);
  const heartSeen = useRef<number | null>(null);
  const heartQueue = useRef(0);
  const scroller = useRef<HTMLDivElement>(null);
  const [room, setRoom] = useState<LiveRoom | null>(null);
  const [missing, setMissing] = useState(false);
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [following, setFollowing] = useState(false);
  const [lines, setLines] = useState<ChatLine[]>([]);
  const [battle, setBattle] = useState<BattleView | null>(null);
  const [draft, setDraft] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const [hearts, setHearts] = useState<{ id: number; x: number }[]>([]);
  const [giftPop, setGiftPop] = useState<{ id: number; name: string; from: string; icon: GiftIcon } | null>(null);
  const [linkState, setLinkState] = useState<LinkState>("idle");
  const [blocked, setBlocked] = useState(false);
  const [remote, setRemote] = useState<MediaStream | null>(null);
  const [needTap, setNeedTap] = useState(false);
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [filterId, setFilterId] = useState<FilterId>("jernih");
  const [nonce, setNonce] = useState(0);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [muted, setMuted] = useState(false);
  const [camOff, setCamOff] = useState(false);
  const [voice, setVoice] = useState<MediaStream | null>(null);
  const [duelCode, setDuelCode] = useState("");
  const remoteRef = useRef<HTMLVideoElement>(null);
  const seenGifts = useRef(new Set<number>());

  const isHost = room?.hostId === userId;
  const live = Boolean(room?.live);
  const videoHost = Boolean(isHost && live && room?.mode === "video");

  const publish = (stream: MediaStream) => {
    const name = wallet?.displayName || hintName || "Nyala";
    if (!linkRef.current) {
      const link = new StageLink({
        room: roomId,
        selfId: peerId,
        name,
        role: "host",
        hostPeer: peerId,
        localStream: stream,
        onRemote: () => {},
        onState: setLinkState,
      });
      linkRef.current = link;
      void link.start();
    } else {
      linkRef.current.replaceStream(stream);
    }
  };
  const publishRef = useRef(publish);
  publishRef.current = publish;

  const lens = useLens({
    enabled: videoHost,
    facing,
    filterId,
    nonce,
    screenStream,
    onStream: (stream) => publishRef.current(stream),
  });

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    let stop = false;
    const tick = async () => {
      try {
        const result = await pulseRoom({
          data: { roomId, afterId: afterRef.current, peerId, displayName: hintName },
        });
        if (stop || !result.ok) return;
        setWallet(result.data.me);
        setFollowing(result.data.following);
        setBattle(result.data.battle);
        if (!result.data.room) {
          setMissing(true);
          setRoom(null);
          return;
        }
        setMissing(false);
        setRoom(result.data.room);
        if (result.data.messages.length) {
          afterRef.current = result.data.messages[result.data.messages.length - 1]?.id ?? afterRef.current;
          setLines((prev) => mergeLines(prev, result.data.messages));
        }
        setError("");
      } catch {
        if (!stop) setError("Putus dari server awan. Mencoba lagi…");
      }
    };
    void tick();
    const timer = setInterval(() => void tick(), 2000);
    return () => {
      stop = true;
      clearInterval(timer);
    };
  }, [roomId, peerId, hintName]);

  useEffect(() => {
    if (!room || isHost || !live || !room.hostPeer) return;
    const link = new StageLink({
      room: roomId,
      selfId: peerId,
      name: wallet?.displayName || hintName || "Penonton",
      role: "viewer",
      hostPeer: room.hostPeer,
      localStream: null,
      onRemote: setRemote,
      onState: setLinkState,
    });
    linkRef.current = link;
    void link.start();
    return () => {
      link.stop();
      if (linkRef.current === link) linkRef.current = null;
      setRemote(null);
    };
  }, [isHost, live, room?.hostPeer, roomId, peerId, hintName]);

  useEffect(() => {
    if (!isHost || room?.mode !== "voice" || !live) return;
    let dead = false;
    let stream: MediaStream | null = null;
    navigator.mediaDevices
      .getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false })
      .then((next) => {
        if (dead) {
          next.getTracks().forEach((track) => track.stop());
          return;
        }
        stream = next;
        setVoice(next);
        publishRef.current(next);
      })
      .catch(() => setError("Mikrofon ditolak."));
    return () => {
      dead = true;
      stream?.getTracks().forEach((track) => track.stop());
      setVoice(null);
    };
  }, [isHost, room?.mode, live]);

  useEffect(() => {
    return () => {
      linkRef.current?.stop();
      screenStream?.getTracks().forEach((track) => track.stop());
    };
    // Screen tracks are stopped on unmount only.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    linkRef.current?.setName(wallet?.displayName || hintName || "Nyala");
  }, [wallet?.displayName, hintName]);

  useEffect(() => {
    const audio = lens.cam?.getAudioTracks()[0];
    if (audio) audio.enabled = !muted;
    const mic = voice?.getAudioTracks()[0];
    if (mic) mic.enabled = !muted;
  }, [muted, lens.cam, voice]);

  useEffect(() => {
    const video = lens.cam?.getVideoTracks()[0];
    if (video) video.enabled = !camOff;
  }, [camOff, lens.cam]);

  useEffect(() => {
    const el = remoteRef.current;
    if (!el) return;
    el.srcObject = remote;
    if (!remote) return;
    void el.play().then(() => setNeedTap(false)).catch(() => setNeedTap(true));
  }, [remote]);

  useEffect(() => {
    const node = scroller.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [lines.length]);

  useEffect(() => {
    const fresh = lines.filter((line) => line.kind === "gift" && !seenGifts.current.has(line.id));
    if (!fresh.length) return;
    const last = fresh[fresh.length - 1];
    if (!last) return;
    for (const line of fresh) seenGifts.current.add(line.id);
    const gift = GIFTS.find((item) => item.id === last.giftId);
    setGiftPop({ id: last.id, name: last.body, from: last.name, icon: gift?.icon ?? "spark" });
    const timer = setTimeout(() => setGiftPop(null), 2400);
    return () => clearTimeout(timer);
  }, [lines]);

  useEffect(() => {
    if (!room) return;
    const delta = room.hearts;
    const mine = sentHearts.current;
    sentHearts.current = 0;
    const others = Math.max(0, delta - (heartSeen.current ?? delta) - mine);
    heartSeen.current = delta;
    if (others > 0) spawnHearts(Math.min(4, others));
  }, [room?.hearts]);

  function spawnHearts(count: number) {
    setHearts((prev) => {
      const next = [...prev];
      for (let i = 0; i < count; i += 1) {
        next.push({ id: Date.now() + i + Math.random(), x: 18 + Math.random() * 64 });
      }
      return next.slice(-14);
    });
  }

  function tapHeart() {
    if (!live) return;
    spawnHearts(1);
    heartQueue.current += 1;
    window.setTimeout(() => {
      const count = heartQueue.current;
      if (!count) return;
      heartQueue.current = 0;
      void addHearts({ data: { roomId, count } })
        .then((result) => {
          if (result.ok) sentHearts.current += count;
        })
        .catch(() => {});
    }, 500);
  }

  async function submitChat() {
    const body = draft.trim();
    if (!body) return;
    setDraft("");
    try {
      const result = await sendChat({ data: { roomId, body } });
      if (!result.ok) {
        setError(result.error);
        setDraft(body);
        return;
      }
      afterRef.current = Math.max(afterRef.current, result.data.id);
      setLines((prev) => mergeLines(prev, [result.data]));
    } catch {
      setError("Pesan gagal terkirim.");
      setDraft(body);
    }
  }

  async function give(giftId: string) {
    try {
      const result = await sendGift({ data: { roomId, giftId } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setWallet(result.data.me);
      afterRef.current = Math.max(afterRef.current, result.data.message.id);
      setLines((prev) => mergeLines(prev, [result.data.message]));
      setError("");
    } catch {
      setError("Hadiah gagal terkirim.");
    }
  }

  async function shareScreen() {
    try {
      const next = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
      const track = next.getVideoTracks()[0];
      track?.addEventListener("ended", () => setScreenStream(null), { once: true });
      setScreenStream((current) => {
        current?.getTracks().forEach((item) => item.stop());
        return next;
      });
    } catch {
      setError("Berbagi layar dibatalkan.");
    }
  }

  async function stopShow() {
    try {
      await endRoom({ data: { roomId } });
    } catch {
      // Leaving the room still returns the viewer home.
    }
    linkRef.current?.stop();
    await navigate({ to: "/" });
  }

  useEffect(() => {
    if (isHost || linkState === "connected" || !room?.hostPeer) {
      setBlocked(false);
      return;
    }
    const timer = setTimeout(() => setBlocked(true), 14000);
    return () => clearTimeout(timer);
  }, [isHost, linkState, room?.hostPeer]);

  if (!room && !missing && !error) return <Splash label="Membuka panggung…" />;
  if (missing || !room) {
    return (
      <main className="grid min-h-dvh place-items-center bg-ink px-6 text-center">
        <div>
          <h1 className="font-display text-4xl">Ruang tidak ada</h1>
          <p className="mt-2 text-sm text-mute">{error || "Kode siaran ini tidak ditemukan di server."}</p>
          <button type="button" onClick={() => void navigate({ to: "/" })} className="mt-6 h-12 rounded-full bg-cream px-5 text-sm font-semibold text-ink">
            Ke lobi
          </button>
        </div>
      </main>
    );
  }

  const PopIcon = giftPop ? GIFT_ICONS[giftPop.icon] : Sparkles;
  const remain = battle ? Math.max(0, battle.endsAt * 1000 - now) : 0;
  const totalScore = (battle?.scoreA ?? 0) + (battle?.scoreB ?? 0);
  const leftPct = totalScore === 0 ? 50 : Math.round(((battle?.scoreA ?? 0) / totalScore) * 100);
  const status = !live
    ? "Siaran selesai"
    : isHost
      ? linkState === "connected"
        ? "Penonton tersambung langsung"
        : "Kamu sedang siaran"
      : linkState === "connected"
        ? room.mode === "voice"
          ? "Suara langsung tersambung"
          : "Gambar langsung tersambung"
        : blocked
          ? "Video tidak tembus dari jaringan ini. Obrolan dan hadiah tetap lewat server."
          : room.hostPeer
            ? "Menyambungkan siaran langsung…"
            : "Menunggu kreator menyalakan perangkat…";

  return (
    <main className="flex h-dvh flex-col bg-ink text-cream md:flex-row">
      <section className="relative min-h-0 flex-1 bg-stage">
        {videoHost ? (
          <>
            <video ref={lens.videoRef} playsInline muted autoPlay className="pointer-events-none absolute size-px opacity-0" />
            <canvas ref={lens.canvasRef} className="absolute inset-0 h-full w-full object-cover" />
          </>
        ) : null}
        {!isHost && room.mode === "video" ? (
          <video ref={remoteRef} playsInline autoPlay className="absolute inset-0 h-full w-full object-cover" />
        ) : null}
        {room.mode === "voice" || (!isHost && !remote && room.mode === "video") ? (
          <div className="absolute inset-0 grid place-items-center px-6">
            <div className="w-full max-w-sm text-center">
              <p className="font-display text-5xl">{room.hostName.slice(0, 1).toUpperCase()}</p>
              <div className="mt-6">
                <Wave stream={isHost ? voice : remote} />
              </div>
            </div>
          </div>
        ) : null}
        {screenStream && videoHost ? (
          <p className="absolute bottom-4 left-4 rounded-full bg-ink/80 px-3 py-1 text-xs">Layar dibagikan</p>
        ) : null}
        <header className="absolute inset-x-0 top-0 flex items-start justify-between gap-3 bg-gradient-to-b from-ink/80 to-transparent p-3">
          <div className="min-w-0">
            <button type="button" onClick={() => void navigate({ to: "/" })} className="inline-flex h-11 items-center gap-2 text-sm">
              <ArrowLeft className="size-4" aria-hidden="true" />
              Lobi
            </button>
            <h1 className="truncate font-display text-2xl">{room.title}</h1>
            <p className="truncate text-sm text-cream">
              {room.hostName}
              <span className="text-mute"> · {room.topic}</span>
            </p>
          </div>
          <div className="flex shrink-0 flex-col items-end gap-2">
            <span className="inline-flex h-9 items-center gap-2 rounded-full bg-ink/70 px-3 text-xs tabular-nums">
              <Users className="size-3.5" aria-hidden="true" />
              {room.viewerCount}
              {live ? <span className="live-dot size-2 rounded-full bg-ember" /> : null}
            </span>
            {!isHost && live ? (
              <button
                type="button"
                onClick={() =>
                  void toggleFollow({ data: { hostId: room.hostId } }).then((result) => {
                    if (result.ok) setFollowing(result.data.following);
                    else setError(result.error);
                  })
                }
                className="h-10 rounded-full bg-cream px-3 text-sm font-semibold text-ink"
              >
                {following ? "Mengikuti" : "Ikuti"}
              </button>
            ) : null}
          </div>
        </header>
        {room.pinned ? (
          <p className="absolute inset-x-3 top-28 flex items-start gap-2 rounded-2xl bg-ink/75 px-3 py-2 text-sm">
            <Pin className="mt-0.5 size-4 shrink-0 text-brass" aria-hidden="true" />
            {room.pinned}
          </p>
        ) : null}
        {battle && remain > 0 ? (
          <div className="absolute inset-x-3 bottom-16 rounded-2xl bg-ink/80 p-3">
            <div className="flex items-center justify-between text-xs">
              <span>{battle.nameA}</span>
              <span className="tabular-nums text-brass">{Math.ceil(remain / 1000)} dtk</span>
              <span>{battle.nameB ?? "Menunggu lawan"}</span>
            </div>
            <div className="mt-2 flex h-2 overflow-hidden rounded-full bg-panel">
              <span className="bg-ember" style={{ width: `${leftPct}%` }} />
              <span className="flex-1 bg-brass" />
            </div>
            <p className="mt-1 text-center text-xs tabular-nums">
              {battle.scoreA} — {battle.scoreB}
              {isHost && !battle.roomB ? ` · kode ${battle.id}` : ""}
            </p>
          </div>
        ) : null}
        <p className="absolute inset-x-3 bottom-3 text-xs text-cream/90">{lens.error || status}</p>
        {hearts.map((heart) => (
          <span key={heart.id} className="heart-float pointer-events-none absolute bottom-24 text-ember" style={{ left: `${heart.x}%` }}>
            <Heart className="size-7 fill-ember" aria-hidden="true" />
          </span>
        ))}
        {giftPop ? (
          <div className="gift-pop pointer-events-none absolute inset-0 grid place-items-center">
            <div className="rounded-3xl bg-ink/85 px-6 py-5 text-center">
              <PopIcon className="mx-auto size-10 text-brass" aria-hidden="true" />
              <p className="mt-2 font-display text-3xl">{giftPop.name}</p>
              <p className="text-sm text-mute">{giftPop.from}</p>
            </div>
          </div>
        ) : null}
        {needTap ? (
          <button
            type="button"
            onClick={() => void remoteRef.current?.play().then(() => setNeedTap(false)).catch(() => {})}
            className="absolute bottom-16 left-1/2 h-11 -translate-x-1/2 rounded-full bg-cream px-4 text-sm font-semibold text-ink"
          >
            Ketuk untuk dengar
          </button>
        ) : null}
        {live ? (
          <button
            type="button"
            onClick={tapHeart}
            aria-label="Kirim hati"
            className="absolute bottom-12 right-3 grid size-14 place-items-center rounded-full bg-ember text-cream"
          >
            <Heart className="size-6 fill-cream" />
          </button>
        ) : null}
      </section>

      <aside className="flex max-h-[48dvh] min-h-0 w-full flex-col border-line bg-ink md:h-dvh md:max-h-none md:w-96 md:border-l">
        <div ref={scroller} role="log" aria-label="Obrolan" className="min-h-0 flex-1 space-y-2 overflow-y-auto px-3 py-3">
          {lines.map((line) =>
            line.kind === "system" ? (
              <p key={line.id} className="text-center text-xs text-mute">{line.body}</p>
            ) : line.kind === "gift" ? (
              <p key={line.id} className="text-sm text-brass">
                <span className="font-semibold">{line.name}</span> mengirim {line.body}
              </p>
            ) : (
              <p key={line.id} className="text-sm">
                <span className="font-semibold text-brass">{line.name}</span>{" "}
                <span className="text-cream">{line.body}</span>
              </p>
            ),
          )}
        </div>
        {error ? <p className="px-3 text-xs text-ember">{error}</p> : null}
        <form
          onSubmit={(event) => {
            event.preventDefault();
            void submitChat();
          }}
          className="flex gap-2 px-3"
        >
          <input
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            disabled={!live}
            maxLength={200}
            placeholder={live ? "Tulis pesan…" : "Siaran selesai"}
            className="h-12 min-w-0 flex-1 rounded-full border border-line bg-stage px-4 text-base outline-none"
          />
          <button type="submit" disabled={!live} aria-label="Kirim" className="grid size-12 place-items-center rounded-full bg-cream text-ink disabled:opacity-40">
            <Send className="size-4" />
          </button>
        </form>
        <div className="mt-2 flex gap-2 overflow-x-auto px-3 pb-2">
          {GIFTS.map((gift) => {
            const Icon = GIFT_ICONS[gift.icon];
            return (
              <button
                key={gift.id}
                type="button"
                disabled={!live}
                onClick={() => void give(gift.id)}
                className="flex h-16 w-24 shrink-0 flex-col items-center justify-center rounded-2xl border border-line bg-stage text-xs disabled:opacity-40"
              >
                <Icon className="size-4 text-brass" aria-hidden="true" />
                <span className="mt-1">{gift.name}</span>
                <span className="tabular-nums text-mute">{gift.coins}</span>
              </button>
            );
          })}
        </div>
        <div className="flex items-center justify-between gap-2 px-3 pb-2 text-xs text-mute">
          <span className="tabular-nums">Koin {wallet?.coins ?? "…"} · hasil {wallet?.earned ?? 0}</span>
          <button
            type="button"
            disabled={!wallet || wallet.earned <= 0}
            onClick={() =>
              void cashOut().then((result) => {
                if (result.ok) setWallet(result.data);
                else setError(result.error);
              })
            }
            className="h-8 rounded-full px-2 text-brass disabled:opacity-40"
          >
            Tukar
          </button>
          <button
            type="button"
            onClick={() => {
              void navigator.clipboard.writeText(window.location.href).then(
                () => setCopied(true),
                () => setCopied(false),
              );
            }}
            className="h-8 rounded-full px-2"
          >
            {copied ? "Tautan disalin" : "Salin tautan"}
          </button>
        </div>
        {isHost && live ? (
          <div className="space-y-2 border-t border-line px-3 py-3">
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={() => setMuted((value) => !value)} className="grid size-11 place-items-center rounded-full bg-panel" aria-label={muted ? "Hidupkan mic" : "Bisukan mic"}>
                {muted ? <MicOff className="size-4" /> : <Mic className="size-4" />}
              </button>
              {room.mode === "video" ? (
                <>
                  <button type="button" onClick={() => setCamOff((value) => !value)} className="grid size-11 place-items-center rounded-full bg-panel" aria-label="Kamera">
                    {camOff ? <VideoOff className="size-4" /> : <Video className="size-4" />}
                  </button>
                  <button type="button" onClick={() => setFacing((value) => (value === "user" ? "environment" : "user"))} className="grid size-11 place-items-center rounded-full bg-panel" aria-label="Balik kamera">
                    <SwitchCamera className="size-4" />
                  </button>
                  <button type="button" onClick={() => void shareScreen()} className="grid size-11 place-items-center rounded-full bg-panel" aria-label="Bagikan layar">
                    <MonitorUp className="size-4" />
                  </button>
                </>
              ) : null}
              <button type="button" onClick={() => void stopShow()} className="h-11 rounded-full bg-ember px-4 text-sm font-semibold">
                Akhiri
              </button>
            </div>
            {room.mode === "video" ? (
              <div className="flex gap-2 overflow-x-auto">
                {FILTERS.map((filter) => (
                  <button
                    key={filter.id}
                    type="button"
                    onClick={() => setFilterId(filter.id)}
                    className={
                      filterId === filter.id
                        ? "h-9 shrink-0 rounded-full bg-brass px-3 text-xs font-semibold text-ink"
                        : "h-9 shrink-0 rounded-full border border-line px-3 text-xs"
                    }
                  >
                    {filter.label}
                  </button>
                ))}
                <button type="button" onClick={() => setNonce((value) => value + 1)} className="h-9 shrink-0 rounded-full border border-line px-3 text-xs">
                  Ulangi kamera
                </button>
              </div>
            ) : null}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() =>
                  void startBattle({ data: { roomId } }).then((result) => {
                    if (!result.ok) setError(result.error);
                  })
                }
                className="inline-flex h-10 items-center gap-1 rounded-full border border-line px-3 text-xs"
              >
                <Swords className="size-3.5" aria-hidden="true" />
                Duel 90 dtk
              </button>
              <input
                value={duelCode}
                onChange={(event) => setDuelCode(event.target.value)}
                placeholder="Kode lawan"
                className="h-10 min-w-0 flex-1 rounded-full border border-line bg-stage px-3 text-sm"
              />
              <button
                type="button"
                onClick={() =>
                  void joinBattle({ data: { roomId, code: duelCode } }).then((result) => {
                    if (!result.ok) setError(result.error);
                  })
                }
                className="h-10 rounded-full bg-panel px-3 text-xs"
              >
                Gabung
              </button>
            </div>
            <form
              className="flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                void pinNote({ data: { roomId, text: note } }).then((result) => {
                  if (!result.ok) setError(result.error);
                  else setRoom((current) => (current ? { ...current, pinned: result.data.pinned } : current));
                });
              }}
            >
              <input
                value={note}
                onChange={(event) => setNote(event.target.value)}
                placeholder="Sematkan pengumuman"
                maxLength={120}
                className="h-10 min-w-0 flex-1 rounded-full border border-line bg-stage px-3 text-sm"
              />
              <button type="submit" className="h-10 rounded-full px-3 text-xs text-brass">
                Sematkan
              </button>
            </form>
          </div>
        ) : null}
        {!live ? (
          <button type="button" onClick={() => void navigate({ to: "/" })} className="m-3 h-12 rounded-full bg-cream text-sm font-semibold text-ink">
            Kembali ke lobi
          </button>
        ) : null}
      </aside>
    </main>
  );
}
