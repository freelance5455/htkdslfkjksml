import { useState, type FormEvent } from "react";
import { authClient, GROK_PROVIDERS, signIn } from "@/lib/auth/client";

function friendly(message: string | undefined, fallback: string) {
  const text = message ?? "";
  if (/already exists/i.test(text)) return "Email ini sudah terdaftar. Masuk saja.";
  if (/invalid email/i.test(text)) return "Email tidak valid.";
  if (/too short|password/i.test(text)) return "Kata sandi minimal 8 karakter.";
  if (/invalid email or password|invalid credentials/i.test(text)) return "Email atau kata sandi salah.";
  return text || fallback;
}

export function AuthPanel({ next }: { next: string }) {
  const [mode, setMode] = useState<"masuk" | "daftar">("daftar");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    if (password.length < 8) {
      setError("Kata sandi minimal 8 karakter.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "daftar") {
        if (name.trim().length < 2) {
          setError("Nama minimal 2 huruf.");
          setBusy(false);
          return;
        }
        const result = await authClient.signUp.email({
          email: email.trim(),
          password,
          name: name.trim(),
        });
        if (result.error) setError(friendly(result.error.message, "Daftar gagal."));
      } else {
        const result = await authClient.signIn.email({
          email: email.trim(),
          password,
        });
        if (result.error) setError(friendly(result.error.message, "Masuk gagal."));
      }
    } catch {
      setError("Server masuk sedang tidak menjawab.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="w-full max-w-sm rounded-3xl border border-line bg-stage p-5">
      <div className="grid grid-cols-2 gap-2 rounded-full bg-ink p-1">
        {(["daftar", "masuk"] as const).map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => {
              setMode(item);
              setError("");
            }}
            className={
              mode === item
                ? "h-11 rounded-full bg-cream text-sm font-semibold text-ink"
                : "h-11 rounded-full text-sm font-semibold text-mute"
            }
          >
            {item === "daftar" ? "Daftar" : "Masuk"}
          </button>
        ))}
      </div>
      <form onSubmit={(event) => void submit(event)} className="mt-4 space-y-3">
        {mode === "daftar" ? (
          <label className="block text-sm text-mute">
            Nama panggung
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              autoComplete="nickname"
              maxLength={32}
              className="mt-1 h-12 w-full rounded-2xl border border-line bg-ink px-3 text-base text-cream outline-none focus-visible:outline-2 focus-visible:outline-brass"
            />
          </label>
        ) : null}
        <label className="block text-sm text-mute">
          Email
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            autoComplete="email"
            required
            className="mt-1 h-12 w-full rounded-2xl border border-line bg-ink px-3 text-base text-cream outline-none focus-visible:outline-2 focus-visible:outline-brass"
          />
        </label>
        <label className="block text-sm text-mute">
          Kata sandi
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            autoComplete={mode === "daftar" ? "new-password" : "current-password"}
            required
            minLength={8}
            className="mt-1 h-12 w-full rounded-2xl border border-line bg-ink px-3 text-base text-cream outline-none focus-visible:outline-2 focus-visible:outline-brass"
          />
        </label>
        {error ? <p className="text-sm text-ember">{error}</p> : null}
        <button
          type="submit"
          disabled={busy}
          className="h-12 w-full rounded-full bg-ember text-sm font-semibold text-cream disabled:opacity-60"
        >
          {busy ? "Sebentar…" : mode === "daftar" ? "Buat akun & masuk" : "Masuk"}
        </button>
      </form>
      <p className="my-4 text-center text-xs tracking-wide text-mute">atau lanjut dengan</p>
      <div className="space-y-2">
        {GROK_PROVIDERS.map((provider) => (
          <button
            key={provider.providerId}
            type="button"
            onClick={() => signIn(provider.providerId, { callbackURL: next })}
            className="h-12 w-full rounded-full border border-line bg-panel text-sm font-semibold text-cream"
          >
            Lanjut dengan {provider.label}
          </button>
        ))}
      </div>
    </div>
  );
}
