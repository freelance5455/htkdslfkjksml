import { Radio, Gift, Swords, Mic, MonitorUp, Heart } from "lucide-react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { AuthPanel } from "@/components/nyala/auth-panel";
import { Lobby } from "@/components/nyala/lobby";
import { Stage } from "@/components/nyala/stage";

const FEATURES = [
  { icon: Radio, title: "Kamera langsung", body: "Depan, belakang, atau bagikan layar. Filter terlihat ke penonton." },
  { icon: Mic, title: "Ruang suara", body: "Siaran audio dengan gelombang dari mikrofonmu yang asli." },
  { icon: Heart, title: "Hati & obrolan", body: "Pesan dan hati tersimpan di server awan, bukan cuma di layar ini." },
  { icon: Gift, title: "Hadiah & koin", body: "Kirim hadiah, koin berkurang, hasil kreator bertambah, lalu bisa ditukar." },
  { icon: Swords, title: "Duel 90 detik", body: "Buka kode duel. Skor naik dari hadiah sungguhan, bukan angka palsu." },
  { icon: MonitorUp, title: "Penonton jarak jauh", body: "Gambar antar perangkat lewat sambungan langsung. Obrolan tetap lewat server." },
];

export function Splash({ label }: { label: string }) {
  return (
    <main className="grid min-h-dvh place-items-center bg-ink px-6">
      <div className="text-center">
        <p className="font-display text-5xl text-cream">NYALA</p>
        <p className="mt-2 text-sm text-mute">{label}</p>
      </div>
    </main>
  );
}

export function NyalaGate({ roomId }: { roomId?: string }) {
  const { user, isPending } = useCurrentUserState();
  const next = roomId ? `/s/${roomId}` : "/";

  if (isPending) return <Splash label="Menyalakan panggung…" />;
  if (!user) {
    return (
      <main className="min-h-dvh bg-ink text-cream">
        <div className="mx-auto grid max-w-5xl gap-10 px-5 py-10 md:grid-cols-[1.1fr_0.9fr] md:items-center md:py-16">
          <section>
            <p className="text-xs font-semibold tracking-[0.22em] text-brass">SIARAN LANGSUNG</p>
            <h1 className="mt-3 font-display text-5xl leading-none text-cream md:text-6xl">NYALA</h1>
            <p className="mt-4 max-w-md text-lg text-cream">
              Panggung yang benar-benar hidup. Kamera, suara, obrolan, hadiah, dan duel.
            </p>
            <p className="mt-3 max-w-md text-sm text-mute">
              Koin, pesan, dan daftar siaran disimpan di server awan — bukan di komputer kamu.
              Gambar penonton mengalir langsung antar perangkat.
            </p>
            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {FEATURES.map((feature) => (
                <li key={feature.title} className="rounded-2xl border border-line bg-stage p-4">
                  <feature.icon className="size-5 text-brass" aria-hidden="true" />
                  <p className="mt-3 font-semibold">{feature.title}</p>
                  <p className="mt-1 text-sm text-mute">{feature.body}</p>
                </li>
              ))}
            </ul>
          </section>
          <section className="md:justify-self-end">
            <AuthPanel next={next} />
          </section>
        </div>
      </main>
    );
  }

  if (roomId) return <Stage roomId={roomId} userId={user.id} hintName={user.displayName ?? ""} />;
  return <Lobby userId={user.id} hintName={user.displayName ?? ""} />;
}
