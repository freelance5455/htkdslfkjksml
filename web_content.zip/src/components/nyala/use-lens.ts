import { useEffect, useRef, useState } from "react";
import { FILTERS, type FilterId } from "@/lib/live/catalog";

function ink(): string {
  if (typeof document === "undefined") return "#14110f";
  const value = getComputedStyle(document.documentElement).getPropertyValue("--color-ink").trim();
  return value || "#14110f";
}

export function useLens(opts: {
  enabled: boolean;
  facing: "user" | "environment";
  filterId: FilterId;
  nonce: number;
  screenStream: MediaStream | null;
  onStream: (stream: MediaStream) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const onStream = useRef(opts.onStream);
  const filterRef = useRef(opts.filterId);
  const facingRef = useRef(opts.facing);
  const screenRef = useRef(opts.screenStream);
  onStream.current = opts.onStream;
  filterRef.current = opts.filterId;
  facingRef.current = opts.facing;
  screenRef.current = opts.screenStream;
  const paintedRef = useRef<MediaStream | null>(null);
  const [cam, setCam] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!opts.enabled) return;
    let dead = false;
    let stream: MediaStream | null = null;
    setError(null);
    navigator.mediaDevices
      .getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
        video: { facingMode: opts.facing, width: { ideal: 1280 }, height: { ideal: 720 } },
      })
      .then((next) => {
        if (dead) {
          next.getTracks().forEach((track) => track.stop());
          return;
        }
        stream = next;
        setCam(next);
      })
      .catch(() => {
        if (!dead) setError("Kamera atau mikrofon ditolak. Izinkan akses, lalu coba lagi.");
      });
    return () => {
      dead = true;
      stream?.getTracks().forEach((track) => track.stop());
      setCam(null);
    };
  }, [opts.enabled, opts.facing, opts.nonce]);

  useEffect(() => {
    if (!cam || !opts.enabled) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    video.srcObject = cam;
    void video.play().catch(() => {});
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    const draw = () => {
      const w = 640;
      const h = 480;
      if (canvas.width !== w) canvas.width = w;
      if (canvas.height !== h) canvas.height = h;
      ctx.save();
      ctx.filter = "none";
      ctx.fillStyle = ink();
      ctx.fillRect(0, 0, w, h);
      const track = cam.getVideoTracks()[0];
      if (!screenRef.current && track?.enabled && video.readyState >= 2) {
        const filter = FILTERS.find((item) => item.id === filterRef.current)?.css ?? "none";
        ctx.filter = filter;
        if (facingRef.current === "user") {
          ctx.translate(w, 0);
          ctx.scale(-1, 1);
        }
        ctx.drawImage(video, 0, 0, w, h);
      }
      ctx.restore();
      raf = requestAnimationFrame(draw);
    };
    draw();
    const painted = canvas.captureStream(24);
    paintedRef.current = painted;
    const audio = cam.getAudioTracks()[0];
    if (audio) painted.addTrack(audio);
    if (!screenRef.current) onStream.current(painted);
    return () => {
      cancelAnimationFrame(raf);
      painted.getVideoTracks().forEach((track) => track.stop());
    };
  }, [cam, opts.enabled]);

  useEffect(() => {
    if (!opts.enabled) return;
    if (!opts.screenStream) {
      if (paintedRef.current) onStream.current(paintedRef.current);
      return;
    }
    const mixed = new MediaStream();
    const video = opts.screenStream.getVideoTracks()[0];
    if (video) mixed.addTrack(video);
    const audio = cam?.getAudioTracks()[0];
    if (audio) mixed.addTrack(audio);
    onStream.current(mixed);
  }, [opts.screenStream, opts.enabled, cam]);

  return { videoRef, canvasRef, cam, error };
}
