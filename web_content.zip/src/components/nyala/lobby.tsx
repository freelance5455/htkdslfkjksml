import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Heart, Radio, Users } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { TOPICS } from "@/lib/live/catalog";
import {
  cashOut,
  claimDaily,
  createRoom,
  lobbyState,
  saveProfile,
} from "@/lib/live/functions";
import type { LobbyData, RoomCard, RoomMode, Wallet } from "@/lib/live/types";

type Tab = "siaran" | "ikuti" | "papan";

function RoomGrid({
  rooms,
  mine,
  empty,
  onOpen,
}: {
  rooms: RoomCard[];
  mine: string;
  empty: string;
  onOpen: (id: string) => void;
}) {
  if (!rooms.length) {
    return <p className="rounded-2xl border border-dashed border-line px-4 py-8 text-center text-sm text-mute">{empty}</p>;
  }
  return (
    <ul className="grid gap-3 sm:grid-cols-2">
      {rooms.map((room) => (
        <li key={room.id}>
          <button
            type="button"
            onClick={() => onOpen(room.id)}
            className="w-full rounded-2xl border border-line bg-stage p-4 text-left"
          >
            <div className="flex items-center justify-between gap-3">
              <span className="inline-flex items-center gap-2 text-xs font-semibold tracking-wide text-ember">
                <span className="live-dot size-2 rounded-full bg-ember" aria-hidden="true" />
                LANGSUNG
              </span>
              <span className="text-xs text-mute">{room.mode === "voice" ? "Suara" : "Video"}</span>
            </div>
            <p className="mt-3 font-display text-2xl leading-tight">{room.title}</p>
            <p className="mt-1 text-sm text-cream">
              {room.hostName}
              {room.hostId === mine ? " · panggungmu" : ""}
            </p>
            <p className="mt-3 flex flex-wrap gap-3 text-xs text-mute">
              <span>{room.topic}</span>
              <span className="inline-flex items-center gap-1 tabular-nums">
                <Users className="size-3.5" aria-hidden="true" />
                {room.viewers}
              </span>
              <span className="inline-flex items-center gap-1 tabular-nums">
                <Heart className="size-3.5" aria-hidden="true" />
                {room.hearts}
              </span>
              <span className="tabular-nums text-brass">{room.giftsValue} koin</span>
            </p>
          </button>
        </li>
      ))}
    </ul>
  );
}

export function Lobby({ userId, hintName }: { userId: string; hintName: string }) {
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("siaran");
  const [data, setData] = useState<LobbyData | null>(null);
  const [error, setError] = useState("");
  const [composer, setComposer] = useState(false);
  const [title, setTitle] = useState("");
  const [topic, setTopic] = useState<(typeof TOPICS)[number]>("Ngobrol");
  const [mode, setMode] = useState<RoomMode>("video");
  const [busy, setBusy] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [draftName, setDraftName] = useState("");
  const [draftBio, setDraftBio] = useState("");

  useEffect(() => {
    let stop = false;
    const load = async () => {
      try {
        const result = await lobbyState({ data: { displayName: hintName } });
        if (stop || !result.ok) return;
        setData(result.data);
        setError("");
      } catch {
        if (!stop) setError("Server awan belum menjawab. Coba lagi sebentar.");
      }
    };
    void load();
    const timer = setInterval(() => void load(), 4000);
    return () => {
      stop = true;
      clearInterval(timer);
    };
  }, [hintName]);

  function openProfile() {
    setDraftName(data?.me.displayName ?? "");
    setDraftBio(data?.me.bio ?? "");
    setProfileOpen(true);
  }

  async function goLive() {
    setBusy(true);
    setError("");
    try {
      const result = await createRoom({ data: { title, topic, mode } });
      if (!result.ok) {
        setError(result.error);
        setBusy(false);
        return;
      }
      await navigate({ to: "/s/$roomId", params: { roomId: result.data.id } });
    } catch {
      setError("Gagal membuka siaran.");
      setBusy(false);
    }
  }

  async function runWallet(action: () => Promise<{ ok: true; data: Wallet } | { ok: false; error: string }>) {
    const result = await action();
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setData((current) => (current ? { ...current, me: result.data } : current));
    setError("");
  }

  const rooms = tab === "ikuti" ? (data?.following ?? []) : tab === "papan" ? (data?.board ?? []) : (data?.live ?? []);
  const empty =
    tab === "ikuti"
      ? "Belum ada yang kamu ikuti sedang siaran."
      : tab === "papan"
        ? "Papan masih sepi. Hadiah di panggung yang mengisi urutan ini."
        : "Belum ada siaran. Jadilah yang pertama menyalakan panggung.";

  return (
    <main className="min-h-dvh bg-ink text-cream">
      <header className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-4">
        <div>
          <p className="font-display text-3xl leading-none">NYALA</p>
          <p className="mt-1 text-xs text-mute">Server awan aktif · data bukan di perangkat ini</p>
        </div>
        <div className="flex items-center gap-2">
          <button type="button" onClick={openProfile} className="h-11 rounded-full bg-panel px-3 text-left">
            <span className="block text-xs text-mute">Koin</span>
            <span className="block text-sm font-semibold tabular-nums text-brass">{data?.me.coins ?? "…"}</span>
          </button>
          <div className="rounded-full bg-cream px-2 py-1 text-ink">
            <UserButton />
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-5xl px-4 pb-16">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div className="flex gap-2">
            {(
              [
                ["siaran", "Siaran"],
                ["ikuti", "Diikuti"],
                ["papan", "Terpanas"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                className={
                  tab === id
                    ? "h-11 rounded-full bg-cream px-4 text-sm font-semibold text-ink"
                    : "h-11 rounded-full px-4 text-sm font-semibold text-mute"
                }
              >
                {label}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => setComposer(true)}
            className="inline-flex h-12 items-center gap-2 rounded-full bg-ember px-5 text-sm font-semibold text-cream"
          >
            <Radio className="size-4" aria-hidden="true" />
            Mulai siaran
          </button>
        </div>

        {error ? <p className="mt-4 text-sm text-ember">{error}</p> : null}

        <div className="mt-5">
          {data ? (
            <RoomGrid rooms={rooms} mine={userId} empty={empty} onOpen={(id) => void navigate({ to: "/s/$roomId", params: { roomId: id } })} />
          ) : (
            <p className="text-sm text-mute">Mengambil daftar siaran dari server…</p>
          )}
        </div>
      </div>

      {composer ? (
        <div className="fixed inset-0 z-20 grid place-items-end bg-ink/80 p-4 sm:place-items-center">
          <div className="w-full max-w-md rounded-3xl border border-line bg-stage p-5">
            <h2 className="font-display text-3xl">Nyalakan panggung</h2>
            <p className="mt-1 text-sm text-mute">Kamera diminta setelah ruang tercipta di server.</p>
            <label className="mt-4 block text-sm text-mute">
              Judul
              <input
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                maxLength={60}
                placeholder="Ngobrol santai malam ini"
                className="mt-1 h-12 w-full rounded-2xl border border-line bg-ink px-3 text-base text-cream outline-none"
              />
            </label>
            <div className="mt-3 flex flex-wrap gap-2">
              {TOPICS.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setTopic(item)}
                  className={
                    topic === item
                      ? "h-10 rounded-full bg-brass px-3 text-sm font-semibold text-ink"
                      : "h-10 rounded-full border border-line px-3 text-sm text-cream"
                  }
                >
                  {item}
                </button>
              ))}
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              {(["video", "voice"] as const).map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setMode(item)}
                  className={
                    mode === item
                      ? "h-11 rounded-2xl bg-cream text-sm font-semibold text-ink"
                      : "h-11 rounded-2xl border border-line text-sm text-mute"
                  }
                >
                  {item === "video" ? "Video" : "Suara saja"}
                </button>
              ))}
            </div>
            <div className="mt-5 flex gap-2">
              <button type="button" onClick={() => setComposer(false)} className="h-12 flex-1 rounded-full border border-line text-sm">
                Batal
              </button>
              <button
                type="button"
                disabled={busy}
                onClick={() => void goLive()}
                className="h-12 flex-1 rounded-full bg-ember text-sm font-semibold text-cream disabled:opacity-60"
              >
                {busy ? "Membuka…" : "Siaran sekarang"}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {profileOpen && data ? (
        <div className="fixed inset-0 z-20 grid place-items-end bg-ink/80 p-4 sm:place-items-center">
          <div className="w-full max-w-md rounded-3xl border border-line bg-stage p-5">
            <h2 className="font-display text-3xl">Profil</h2>
            <p className="mt-1 text-sm tabular-nums text-mute">
              {data.me.followers} pengikut · {data.me.following} mengikuti · hasil {data.me.earned}
            </p>
            <label className="mt-4 block text-sm text-mute">
              Nama
              <input
                value={draftName}
                onChange={(event) => setDraftName(event.target.value)}
                maxLength={32}
                className="mt-1 h-12 w-full rounded-2xl border border-line bg-ink px-3 text-base text-cream outline-none"
              />
            </label>
            <label className="mt-3 block text-sm text-mute">
              Bio
              <textarea
                value={draftBio}
                onChange={(event) => setDraftBio(event.target.value)}
                maxLength={140}
                rows={3}
                className="mt-1 w-full rounded-2xl border border-line bg-ink px-3 py-2 text-base text-cream outline-none"
              />
            </label>
            <div className="mt-4 grid gap-2">
              <button
                type="button"
                onClick={() =>
                  void runWallet(async () => {
                    const saved = await saveProfile({ data: { displayName: draftName, bio: draftBio } });
                    return saved;
                  })
                }
                className="h-11 rounded-full bg-cream text-sm font-semibold text-ink"
              >
                Simpan profil
              </button>
              <button
                type="button"
                disabled={data.me.claimedToday}
                onClick={() => void runWallet(() => claimDaily())}
                className="h-11 rounded-full border border-line text-sm font-semibold disabled:opacity-50"
              >
                {data.me.claimedToday ? "Koin harian sudah diambil" : "Ambil 120 koin harian"}
              </button>
              <button
                type="button"
                disabled={data.me.earned <= 0}
                onClick={() => void runWallet(() => cashOut())}
                className="h-11 rounded-full border border-brass text-sm font-semibold text-brass disabled:opacity-50"
              >
                Tukar hasil ke koin
              </button>
              <button type="button" onClick={() => setProfileOpen(false)} className="h-11 text-sm text-mute">
                Tutup
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  );
}
