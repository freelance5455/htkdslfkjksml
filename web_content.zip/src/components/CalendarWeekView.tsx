import React from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Flame,
  Cake,
  Sparkles,
  BookOpen,
  Plus,
} from 'lucide-react';
import { CalendarDay, HebrewEvent, LocationPreset, UserSettings } from '../types';
import {
  getWeekDays,
  calculateZmanim,
} from '../services/hebrewCalendarService';
import { getTranslations } from '../services/i18n';

interface CalendarWeekViewProps {
  currentDate: Date;
  onDateChange?: (date: Date) => void;
  days?: CalendarDay[];
  selectedDay?: CalendarDay | null;
  selectedDate?: Date;
  onSelectDay: (day: CalendarDay) => void;
  location: LocationPreset;
  events?: HebrewEvent[];
  onOpenAddEvent: (defaultDate?: CalendarDay) => void;
  settings?: UserSettings;
}

export const CalendarWeekView: React.FC<CalendarWeekViewProps> = ({
  currentDate,
  onDateChange,
  days: propDays,
  selectedDay,
  selectedDate,
  onSelectDay,
  location,
  events = [],
  onOpenAddEvent,
  settings,
}) => {
  const t = getTranslations(settings?.language || 'en');
  const isRtl = (settings?.language || 'en') === 'he';

  const weekDays = propDays || getWeekDays(currentDate, location, events);

  const prevWeek = () => {
    if (onDateChange) {
      const d = new Date(currentDate);
      d.setDate(d.getDate() - 7);
      onDateChange(d);
    }
  };

  const nextWeek = () => {
    if (onDateChange) {
      const d = new Date(currentDate);
      d.setDate(d.getDate() + 7);
      onDateChange(d);
    }
  };

  const prevMonth = () => {
    if (onDateChange) {
      const d = new Date(currentDate);
      d.setMonth(d.getMonth() - 1);
      onDateChange(d);
    }
  };

  const nextMonth = () => {
    if (onDateChange) {
      const d = new Date(currentDate);
      d.setMonth(d.getMonth() + 1);
      onDateChange(d);
    }
  };

  const prevYear = () => {
    if (onDateChange) {
      const d = new Date(currentDate);
      d.setFullYear(d.getFullYear() - 1);
      onDateChange(d);
    }
  };

  const nextYear = () => {
    if (onDateChange) {
      const d = new Date(currentDate);
      d.setFullYear(d.getFullYear() + 1);
      onDateChange(d);
    }
  };

  const goToToday = () => {
    if (onDateChange) {
      onDateChange(new Date());
    }
  };

  const startDay = weekDays[0] || {
    gregorianDate: currentDate,
    hebrewDateStrHe: '',
  };
  const endDay = weekDays[6] || startDay;

  const weekHeading = `${startDay.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', {
    month: 'short',
    day: 'numeric',
  })} – ${endDay.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })}`;

  const hebrewWeekHeading = `${startDay.hebrewDateStrHe} – ${endDay.hebrewDateStrHe}`;

  const touchStartX = React.useRef<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diffX = touchStartX.current - touchEndX;
    const minSwipeDistance = 50;

    if (Math.abs(diffX) > minSwipeDistance) {
      if (diffX > 0) {
        nextWeek();
      } else {
        prevWeek();
      }
    }
    touchStartX.current = null;
  };

  return (
    <div 
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className="bg-[#121212] rounded-xl border border-[#2A2A2A] shadow-2xl overflow-hidden select-none touch-pan-y"
    >
      {/* Week Navigation Header */}
      <div className="p-6 border-b border-[#2A2A2A] bg-[#161616] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-serif font-medium text-[#C5A267] tracking-tight font-serif-hebrew" dir="rtl">
            {hebrewWeekHeading}
          </h2>
          <p className="text-sm font-medium text-[#888888] mt-0.5">
            {weekHeading}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={goToToday}
            className="px-4 py-1.5 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] hover:bg-[#252525] text-xs sm:text-sm font-medium text-[#D1D1D1] transition-colors"
          >
            {t.today}
          </button>
          <div className="flex flex-wrap items-center gap-2 bg-[#1A1A1A] p-1 rounded-xl border border-[#2A2A2A]">
            {/* Week Nav */}
            <div className="flex items-center gap-1 border-r border-[#2A2A2A] pr-1.5">
              <span className="text-[10px] uppercase font-bold text-[#666666] tracking-wider px-1">{isRtl ? 'שבוע' : 'Week'}</span>
              <button
                onClick={prevWeek}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={t.previousWeek}
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={nextWeek}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={t.nextWeek}
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Month Nav */}
            <div className="flex items-center gap-1 border-r border-[#2A2A2A] pr-1.5">
              <span className="text-[10px] uppercase font-bold text-[#666666] tracking-wider px-1">{isRtl ? 'חודש' : 'Month'}</span>
              <button
                onClick={prevMonth}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={t.previousMonth}
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={nextMonth}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={t.nextMonth}
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Year Nav */}
            <div className="flex items-center gap-1">
              <span className="text-[10px] uppercase font-bold text-[#666666] tracking-wider px-1">{isRtl ? 'שנה' : 'Year'}</span>
              <button
                onClick={prevYear}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={isRtl ? 'שנה קודמת' : 'Previous Year'}
              >
                <ChevronsLeft className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={nextYear}
                className="p-1 rounded-md hover:bg-[#2A2A2A] text-[#888888] hover:text-[#EAEAEA] transition-colors"
                title={isRtl ? 'שנה הבאה' : 'Next Year'}
              >
                <ChevronsRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
          <button
            id="add-event-week-btn"
            onClick={() => onOpenAddEvent(selectedDay || undefined)}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs sm:text-sm font-bold shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addEvent}</span>
          </button>
        </div>
      </div>

      {/* Week Columns Grid */}
      <div className="grid grid-cols-1 md:grid-cols-7 divide-y md:divide-y-0 md:divide-x divide-[#2A2A2A] bg-[#121212]">
        {weekDays.map((day) => {
          const isSelected =
            (selectedDay && selectedDay.dateKey === day.dateKey) ||
            (selectedDate &&
              selectedDate.getFullYear() === day.gregorianDate.getFullYear() &&
              selectedDate.getMonth() === day.gregorianDate.getMonth() &&
              selectedDate.getDate() === day.gregorianDate.getDate());

          const dayZmanim = calculateZmanim(day.gregorianDate, location);
          const isShabbat = day.isShabbat;
          const isErevShabbat = day.isErevShabbat;

          return (
            <div
              key={day.dateKey}
              onClick={() => onSelectDay(day)}
              className={`p-4 flex flex-col justify-between transition-colors cursor-pointer select-none min-h-[340px] ${
                day.isToday
                  ? 'bg-[#1A1A1A]'
                  : isShabbat
                  ? 'bg-[#151515]'
                  : 'bg-[#121212]'
              } ${
                isSelected
                  ? 'ring-2 ring-[#C5A267] ring-inset bg-[#1E1E1E]'
                  : 'hover:bg-[#181818]'
              }`}
            >
              {/* Day Header */}
              <div className="border-b border-[#2A2A2A] pb-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#555555]">
                    {day.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', { weekday: 'short' })}
                  </span>
                  <span
                    className={`text-xs font-mono ${
                      day.isToday
                        ? 'px-2 py-0.5 rounded-sm bg-[#C5A267] text-[#0F0F0F] font-bold'
                        : 'text-[#666666]'
                    }`}
                  >
                    {day.gregorianDate.getDate()}
                  </span>
                </div>

                <div className="mt-2 flex items-baseline justify-between">
                  <span className="text-xl font-serif-hebrew font-bold text-[#EAEAEA]" dir="rtl">
                    {day.hebrewDayLetters} {day.hebrewMonthNameHe}
                  </span>
                </div>
                <div className="text-[11px] text-[#888888] font-hebrew" dir="rtl">
                  {day.hebrewDateStrHe}
                </div>
              </div>

              {/* Holidays, Parasha & Events List */}
              <div className="py-3 flex-1 flex flex-col gap-1.5 overflow-hidden">
                {day.holidays.map((h, hIdx) => (
                  <div
                    key={hIdx}
                    className="p-1.5 rounded-xs text-[11px] font-medium bg-[#251f14] text-[#FCD34D] border-l-2 border-[#FCD34D] truncate"
                  >
                    {h.name}
                  </div>
                ))}

                {isShabbat && day.parasha && (
                  <div className="p-1.5 rounded-xs text-[11px] font-medium bg-[#16202e] text-blue-300 border-l-2 border-blue-400 flex items-center gap-1">
                    <BookOpen className="w-3 h-3 text-blue-400 shrink-0" />
                    <span className="truncate">{day.parasha.name}</span>
                  </div>
                )}

                {day.events.map((ev) => (
                  <div
                    key={ev.id}
                    className="p-1.5 rounded-xs text-[11px] font-medium bg-[#1A1A1A] text-[#D1D1D1] border-l-2 truncate flex items-center gap-1.5"
                    style={{ borderLeftColor: ev.color || '#C5A267' }}
                  >
                    {ev.type === 'yahrzeit' ? (
                      <Flame className="w-3 h-3 text-blue-400 shrink-0" />
                    ) : ev.type === 'birthday' ? (
                      <Cake className="w-3 h-3 text-[#C5A267] shrink-0" />
                    ) : (
                      <Sparkles className="w-3 h-3 text-emerald-400 shrink-0" />
                    )}
                    <span className="truncate">{ev.displayTitle || ev.title}</span>
                  </div>
                ))}
              </div>

              {/* Key Zmanim Snippet for the day */}
              <div className="pt-3 border-t border-[#2A2A2A] text-[11px] space-y-1">
                {isErevShabbat && day.candleLighting && (
                  <div className="flex justify-between font-bold text-[#FCD34D] bg-[#251f14] px-1.5 py-1 rounded-sm">
                    <span>🕯️ {t.candleLighting}</span>
                    <span className="font-mono">{day.candleLighting}</span>
                  </div>
                )}
                {isShabbat && day.havdalah && (
                  <div className="flex justify-between font-bold text-blue-300 bg-[#16202e] px-1.5 py-1 rounded-sm">
                    <span>🍷 {t.havdalah}</span>
                    <span className="font-mono">{day.havdalah}</span>
                  </div>
                )}
                <div className="flex justify-between text-[#888888] text-[10px]">
                  <span>{isRtl ? 'נץ החמה' : 'Sunrise (Netz)'}</span>
                  <span className="font-mono text-[#D1D1D1]">
                    {dayZmanim.items.find((z) => z.id === 'sunrise')?.formattedTime}
                  </span>
                </div>
                <div className="flex justify-between text-[#888888] text-[10px]">
                  <span>{isRtl ? 'שקיעת החמה' : 'Sunset (Shkiah)'}</span>
                  <span className="font-mono text-[#D1D1D1]">
                    {dayZmanim.items.find((z) => z.id === 'sunset')?.formattedTime}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
