import { useEffect, useState } from "react";
import { getFormulaById, searchFormulas } from "../data";
import { useAppState } from "../state/AppState";
import Visualizer from "./visuals/Visualizer";

export default function FormulaDetail({ id }: { id: string }) {
  const formula = getFormulaById(id);
  const { navigate, isFavorite, toggleFavorite, addRecent } = useAppState();
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});

  useEffect(() => {
    if (formula) addRecent(formula.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!formula) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <p className="text-slate-500">Formula not found.</p>
        <button onClick={() => navigate({ name: "home" })} className="mt-4 text-indigo-600 underline">
          Go home
        </button>
      </div>
    );
  }

  const related = searchFormulas(formula.topic)
    .filter((f) => f.id !== formula.id && f.classLevel === formula.classLevel)
    .slice(0, 4);
  const fav = isFavorite(formula.id);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <div className="mb-4 flex flex-wrap items-center gap-2 text-sm text-slate-400 dark:text-slate-500">
        <button onClick={() => navigate({ name: "class", classLevel: formula.classLevel, subject: formula.subject })} className="hover:text-indigo-500">
          Class {formula.classLevel} · {formula.subject}
        </button>
        <span>/</span>
        <span>{formula.chapter}</span>
        <span>/</span>
        <span className="text-slate-600 dark:text-slate-300">{formula.topic}</span>
      </div>

      <div className="animate-fade-in rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:p-8">
        <div className="flex items-start justify-between gap-3">
          <h1 className="text-2xl font-extrabold text-slate-800 dark:text-slate-100 sm:text-3xl">{formula.name}</h1>
          <button
            onClick={() => toggleFavorite(formula.id)}
            className={`shrink-0 rounded-xl border px-3 py-2 text-sm font-medium transition ${
              fav
                ? "border-amber-300 bg-amber-50 text-amber-600 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-400"
                : "border-slate-200 text-slate-500 hover:border-slate-300 dark:border-slate-700 dark:text-slate-400"
            }`}
          >
            {fav ? "★ Saved" : "☆ Save"}
          </button>
        </div>

        {formula.board && (
          <div className="mt-2 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-700 dark:bg-amber-500/10 dark:text-amber-300">
            📘 {formula.board}
          </div>
        )}

        <div className="mt-5 overflow-x-auto rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-600 p-6 text-center shadow-inner">
          <div className="font-mono text-xl font-semibold text-white sm:text-2xl">{formula.expression}</div>
        </div>

        <Section title="Variables">
          <div className="grid gap-2 sm:grid-cols-2">
            {formula.variables.map((v) => (
              <div key={v.symbol} className="flex items-start gap-2 rounded-lg bg-slate-50 px-3 py-2 text-sm dark:bg-slate-800/60">
                <span className="font-mono font-semibold text-indigo-600 dark:text-indigo-400">{v.symbol}</span>
                <span className="text-slate-600 dark:text-slate-300">
                  — {v.meaning}
                  {v.unit ? <span className="text-slate-400 dark:text-slate-500"> ({v.unit})</span> : null}
                </span>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Visual & Live Calculation">
          <Visualizer formula={formula} />
        </Section>

        <Section title="Explanation">
          <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-300">{formula.explanation}</p>
        </Section>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 dark:border-emerald-500/20 dark:bg-emerald-500/10">
            <div className="mb-1 text-xs font-bold uppercase tracking-wide text-emerald-600 dark:text-emerald-400">✓ Worked Example</div>
            <p className="text-sm text-emerald-800 dark:text-emerald-200">{formula.example}</p>
          </div>
          <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 dark:border-rose-500/20 dark:bg-rose-500/10">
            <div className="mb-1 text-xs font-bold uppercase tracking-wide text-rose-600 dark:text-rose-400">⚠ Common Mistake</div>
            <p className="text-sm text-rose-800 dark:text-rose-200">{formula.commonMistake}</p>
          </div>
        </div>

        <Section title="Quick Practice">
          <div className="space-y-2">
            {formula.practice.map((p, i) => (
              <div key={i} className="rounded-xl border border-slate-200 p-3 text-sm dark:border-slate-700">
                <div className="flex items-start justify-between gap-3">
                  <p className="text-slate-700 dark:text-slate-200">
                    <span className="mr-1 font-semibold text-indigo-500">Q{i + 1}.</span>
                    {p.question}
                  </p>
                  <button
                    onClick={() => setRevealed((r) => ({ ...r, [i]: !r[i] }))}
                    className="shrink-0 rounded-md bg-indigo-50 px-2 py-1 text-xs font-medium text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-500/10 dark:text-indigo-300"
                  >
                    {revealed[i] ? "Hide" : "Reveal"}
                  </button>
                </div>
                {revealed[i] && <p className="mt-2 rounded-lg bg-slate-50 px-3 py-2 text-slate-600 dark:bg-slate-800/60 dark:text-slate-300">{p.answer}</p>}
              </div>
            ))}
          </div>
        </Section>
      </div>

      {related.length > 0 && (
        <div className="mt-8">
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500">Related Formulas</h3>
          <div className="grid gap-3 sm:grid-cols-2">
            {related.map((f) => (
              <button
                key={f.id}
                onClick={() => navigate({ name: "formula", id: f.id })}
                className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-left text-sm shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="font-medium text-slate-700 dark:text-slate-200">{f.name}</div>
                <div className="font-mono text-xs text-indigo-500">{f.expression}</div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-6">
      <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">{title}</h2>
      {children}
    </div>
  );
}
