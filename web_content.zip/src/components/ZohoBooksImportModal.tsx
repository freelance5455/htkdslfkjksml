import React, { useState } from 'react';
import { Upload, RefreshCw, CheckCircle2, AlertTriangle, FileSpreadsheet, Download, Check, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ZOHO_SAMPLE_RECORDS } from '../data/mockData';
import { Client, ClientInput } from '../types';

interface ZohoBooksImportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface StagedRecord {
  id: string;
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  gstin: string;
  industry: string;
  zohoContactId: string;
  isDuplicate: boolean;
  duplicateReason?: string;
  selected: boolean;
  action: 'create' | 'update' | 'skip';
}

export const ZohoBooksImportModal: React.FC<ZohoBooksImportModalProps> = ({ isOpen, onClose }) => {
  const { clients, importZohoClients } = useApp();
  const [importSource, setImportSource] = useState<'api' | 'csv'>('api');
  const [step, setStep] = useState<'upload' | 'review' | 'done'>('upload');
  const [stagedRecords, setStagedRecords] = useState<StagedRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [importSummary, setImportSummary] = useState<{ added: number; updated: number }>({ added: 0, updated: 0 });

  if (!isOpen) return null;

  // Process raw records through duplicate detection
  const processRecordsForReview = (rawList: typeof ZOHO_SAMPLE_RECORDS) => {
    const analyzed: StagedRecord[] = rawList.map((rec, idx) => {
      // Check for duplicate in existing clients
      const emailMatch = clients.find(c => c.email.toLowerCase() === rec.email.toLowerCase());
      const gstinMatch = rec.gstin ? clients.find(c => c.gstin.toLowerCase() === rec.gstin.toLowerCase()) : null;
      const nameMatch = clients.find(c => c.companyName.toLowerCase() === rec.companyName.toLowerCase());

      let isDup = false;
      let reason = '';

      if (emailMatch) {
        isDup = true;
        reason = `Matches existing email (${emailMatch.email})`;
      } else if (gstinMatch) {
        isDup = true;
        reason = `Matches existing GSTIN (${gstinMatch.gstin})`;
      } else if (nameMatch) {
        isDup = true;
        reason = `Matches existing company name "${nameMatch.companyName}"`;
      }

      return {
        id: `staged-${idx}`,
        ...rec,
        isDuplicate: isDup,
        duplicateReason: reason,
        selected: true,
        action: isDup ? 'update' : 'create'
      };
    });

    setStagedRecords(analyzed);
    setStep('review');
  };

  const handleFetchFromZoho = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      processRecordsForReview(ZOHO_SAMPLE_RECORDS);
    }, 600);
  };

  const handleCsvUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Simulate CSV parsing
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      processRecordsForReview(ZOHO_SAMPLE_RECORDS);
    }, 400);
  };

  const handleDownloadSampleCsv = () => {
    const headers = 'Company Name,Contact Person,Email,Phone,Address,City,GSTIN,Industry,Zoho Contact ID\n';
    const rows = ZOHO_SAMPLE_RECORDS.map(r => 
      `"${r.companyName}","${r.contactPerson}","${r.email}","${r.phone}","${r.address}","${r.city}","${r.gstin}","${r.industry}","${r.zohoContactId}"`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'zoho_books_clients_template.csv';
    link.click();
    URL.revokeObjectURL(url);
  };

  const toggleSelect = (id: string) => {
    setStagedRecords(prev => prev.map(r => r.id === id ? { ...r, selected: !r.selected } : r));
  };

  const handleActionChange = (id: string, action: 'create' | 'update' | 'skip') => {
    setStagedRecords(prev => prev.map(r => r.id === id ? { ...r, action } : r));
  };

  const executeImport = () => {
    const selected = stagedRecords.filter(r => r.selected && r.action !== 'skip');
    const toImport: ClientInput[] = selected.map(r => ({
      companyName: r.companyName,
      contactPerson: r.contactPerson,
      email: r.email,
      phone: r.phone,
      address: r.address,
      city: r.city,
      gstin: r.gstin,
      industry: r.industry,
      zohoContactId: r.zohoContactId,
      notes: `Imported via Zoho Books Sync on ${new Date().toLocaleDateString('en-IN')}`
    }));

    const result = importZohoClients(toImport, true);
    setImportSummary(result);
    setStep('done');
  };

  const resetModal = () => {
    setStep('upload');
    setStagedRecords([]);
    onClose();
  };

  const duplicateCount = stagedRecords.filter(r => r.isDuplicate).length;
  const newCount = stagedRecords.filter(r => !r.isDuplicate).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden flex flex-col max-h-[95vh] sm:max-h-[90vh]">
        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div>
            <h3 className="text-sm sm:text-base font-semibold text-slate-900 flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-red-600 shrink-0" />
              <span>Import Client Data from Zoho Books</span>
            </h3>
            <p className="text-[11px] sm:text-xs text-slate-500 mt-0.5">
              Sync contact records with automated duplicate detection & conflict resolution
            </p>
          </div>
          <button
            onClick={resetModal}
            className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer text-sm font-semibold shrink-0"
            aria-label="Close modal"
          >
            ✕
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1">
          {step === 'upload' && (
            <div className="space-y-6">
              {/* Method Tabs */}
              <div className="flex border-b border-slate-200">
                <button
                  type="button"
                  onClick={() => setImportSource('api')}
                  className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors cursor-pointer ${
                    importSource === 'api'
                      ? 'border-red-600 text-red-600'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Direct Zoho Books API (Connected)
                </button>
                <button
                  type="button"
                  onClick={() => setImportSource('csv')}
                  className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors cursor-pointer ${
                    importSource === 'csv'
                      ? 'border-red-600 text-red-600'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Upload CSV / Excel Export
                </button>
              </div>

              {importSource === 'api' ? (
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h4 className="text-sm font-semibold text-slate-900">Zoho Books India Organization</h4>
                      <p className="text-xs text-slate-600 mt-1">
                        Connected to <span className="font-medium text-slate-800">Phoenix Fire Safety Equipments Pvt. Ltd. (Org ID: 820194812)</span>
                      </p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Fetches active customer master records, GSTINs, and billing addresses directly.
                      </p>
                    </div>
                    <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-2 py-1 rounded border border-emerald-200 shrink-0">
                      OAuth Token Active
                    </span>
                  </div>

                  <div className="mt-5 pt-4 border-t border-slate-200 flex items-center justify-between">
                    <span className="text-xs text-slate-500">5 pending customer records ready to verify</span>
                    <button
                      type="button"
                      disabled={isLoading}
                      onClick={handleFetchFromZoho}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-sm transition-all"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                      <span>{isLoading ? 'Fetching Contacts...' : 'Fetch & Analyze Records'}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:border-red-400 transition-colors">
                    <Upload className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm font-medium text-slate-700">Drop your Zoho Books customer CSV here</p>
                    <p className="text-xs text-slate-500 mt-1">Supports standard Zoho Books .csv or .xlsx exports</p>
                    <input
                      type="file"
                      accept=".csv, .xlsx, .xls"
                      onChange={handleCsvUpload}
                      className="mt-4 text-xs file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-slate-900 file:text-white hover:file:bg-slate-800 cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 pt-2">
                    <span>Need the standard template format?</span>
                    <button
                      type="button"
                      onClick={handleDownloadSampleCsv}
                      className="text-red-600 hover:text-red-700 font-medium flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Sample CSV Template</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {step === 'review' && (
            <div className="space-y-5">
              {/* Summary Stats Strip */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-xs text-slate-500">Total Scanned</span>
                  <p className="text-lg font-bold text-slate-900 font-mono tabular-nums">{stagedRecords.length}</p>
                </div>
                <div className="bg-emerald-50 p-3 rounded-lg border border-emerald-200">
                  <span className="text-xs text-emerald-700">New Clients</span>
                  <p className="text-lg font-bold text-emerald-800 font-mono tabular-nums">{newCount}</p>
                </div>
                <div className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                  <span className="text-xs text-amber-800">Duplicate Conflicts</span>
                  <p className="text-lg font-bold text-amber-900 font-mono tabular-nums">{duplicateCount}</p>
                </div>
              </div>

              {/* Records Review Table */}
              <div className="border border-slate-200 rounded-lg overflow-x-auto">
                <table className="w-full text-xs text-left min-w-[540px]">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="p-3 w-8">
                        <input
                          type="checkbox"
                          checked={stagedRecords.every(r => r.selected)}
                          onChange={(e) => setStagedRecords(prev => prev.map(r => ({ ...r, selected: e.target.checked })))}
                          className="rounded text-red-600"
                        />
                      </th>
                      <th className="p-3">Company & Contact</th>
                      <th className="p-3">GSTIN / City</th>
                      <th className="p-3">Status & Conflict</th>
                      <th className="p-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {stagedRecords.map((rec) => (
                      <tr key={rec.id} className={rec.isDuplicate ? 'bg-amber-50/40' : 'bg-white'}>
                        <td className="p-3">
                          <input
                            type="checkbox"
                            checked={rec.selected}
                            onChange={() => toggleSelect(rec.id)}
                            className="rounded text-red-600"
                          />
                        </td>
                        <td className="p-3">
                          <p className="font-semibold text-slate-900">{rec.companyName}</p>
                          <p className="text-slate-500">{rec.contactPerson} · {rec.email}</p>
                        </td>
                        <td className="p-3 font-mono">
                          <span className="text-slate-800">{rec.gstin || 'N/A'}</span>
                          <p className="text-slate-500 font-sans">{rec.city}</p>
                        </td>
                        <td className="p-3">
                          {rec.isDuplicate ? (
                            <span className="text-amber-800 flex items-center gap-1 font-medium">
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                              <span>{rec.duplicateReason}</span>
                            </span>
                          ) : (
                            <span className="text-emerald-700 flex items-center gap-1 font-medium">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              <span>Ready for Import</span>
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-right">
                          {rec.isDuplicate ? (
                            <select
                              value={rec.action}
                              onChange={(e) => handleActionChange(rec.id, e.target.value as any)}
                              className="text-xs bg-white border border-slate-300 rounded px-2 py-1 text-slate-800"
                            >
                              <option value="update">Update Existing</option>
                              <option value="skip">Skip Record</option>
                            </select>
                          ) : (
                            <span className="text-slate-600 font-medium">New Record</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {step === 'done' && (
            <div className="py-8 text-center space-y-4">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <Check className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-slate-900">Zoho Books Import Successful!</h4>
                <p className="text-sm text-slate-600 mt-1">
                  Successfully imported <span className="font-semibold text-slate-900 font-mono">{importSummary.added}</span> new client records and updated <span className="font-semibold text-slate-900 font-mono">{importSummary.updated}</span> existing accounts.
                </p>
              </div>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                All contacts are now available for project assignment and client portal communication.
              </p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          {step === 'upload' && (
            <>
              <button
                type="button"
                onClick={resetModal}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
              <span className="text-xs text-slate-400">Step 1 of 2</span>
            </>
          )}

          {step === 'review' && (
            <>
              <button
                type="button"
                onClick={() => setStep('upload')}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Back
              </button>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={resetModal}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={executeImport}
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-sm transition-all"
                >
                  Confirm & Commit Import ({stagedRecords.filter(r => r.selected && r.action !== 'skip').length})
                </button>
              </div>
            </>
          )}

          {step === 'done' && (
            <div className="w-full flex justify-end">
              <button
                type="button"
                onClick={resetModal}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-sm transition-all"
              >
                Done
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
