import React, { useState, useEffect, useRef } from 'react';
import { Chapter, Manhwa, Comment } from '../types';
import { useAuth } from '../context/AuthContext';
import { SmartImage } from './SmartImage';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  addDoc,
  doc,
  updateDoc,
  increment
} from 'firebase/firestore';
import {
  ArrowRight,
  ChevronRight,
  ChevronLeft,
  Maximize2,
  ZoomIn,
  ZoomOut,
  Play,
  Square,
  MessageSquare,
  Send,
  Eye,
  Sliders,
  Sparkles,
  Type,
  Sun,
  Moon
} from 'lucide-react';

interface ChapterReaderProps {
  manhwa: Manhwa;
  chapter: Chapter;
  allChapters: Chapter[];
  onSelectChapter: (ch: Chapter) => void;
  onClose: () => void;
}

export const ChapterReader: React.FC<ChapterReaderProps> = ({
  manhwa,
  chapter,
  allChapters,
  onSelectChapter,
  onClose
}) => {
  const { user } = useAuth();
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [readingMode, setReadingMode] = useState<'vertical' | 'single'>('vertical');
  const [currentPageIndex, setCurrentPageIndex] = useState<number>(0);
  const [isAutoScrolling, setIsAutoScrolling] = useState<boolean>(false);
  const [autoScrollSpeed, setAutoScrollSpeed] = useState<number>(2);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState<string>('');
  const [isSubmittingComment, setIsSubmittingComment] = useState<boolean>(false);
  const [showControls, setShowControls] = useState<boolean>(true);

  // Novel Reader Settings
  const [novelFontSize, setNovelFontSize] = useState<number>(18);
  const [novelTheme, setNovelTheme] = useState<'dark' | 'sepia' | 'pitch'>('dark');

  const containerRef = useRef<HTMLDivElement>(null);

  const isNovel = manhwa.type === 'novel';

  // Sort chapters numerically
  const sortedChapters = [...allChapters].sort((a, b) => a.chapterNumber - b.chapterNumber);
  const currentIndex = sortedChapters.findIndex((c) => c.id === chapter.id);
  const prevChapter = currentIndex > 0 ? sortedChapters[currentIndex - 1] : null;
  const nextChapter = currentIndex < sortedChapters.length - 1 ? sortedChapters[currentIndex + 1] : null;

  // Increment view counter
  useEffect(() => {
    const recordView = async () => {
      try {
        const chRef = doc(db, 'chapters', chapter.id);
        await updateDoc(chRef, {
          views: increment(1),
          updatedAt: new Date().toISOString()
        });

        const manhwaRef = doc(db, 'manhwas', manhwa.id);
        await updateDoc(manhwaRef, {
          views: increment(1),
          updatedAt: new Date().toISOString()
        });
      } catch (err) {
        // Silent view counter update error
      }
    };

    recordView();
  }, [chapter.id]);

  // Load comments in real-time
  useEffect(() => {
    const q = query(
      collection(db, 'comments'),
      where('chapterId', '==', chapter.id),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const loaded: Comment[] = [];
        snapshot.forEach((docSnap) => {
          loaded.push({ id: docSnap.id, ...(docSnap.data() as Omit<Comment, 'id'>) });
        });
        setComments(loaded);
      },
      (error) => {
        console.warn('Comments query issue:', error);
      }
    );

    return () => unsubscribe();
  }, [chapter.id]);

  // Auto-scroll loop
  useEffect(() => {
    let animId: number;
    if (isAutoScrolling && readingMode === 'vertical') {
      const scrollLoop = () => {
        if (containerRef.current) {
          containerRef.current.scrollTop += autoScrollSpeed;
        } else {
          window.scrollBy(0, autoScrollSpeed);
        }
        animId = requestAnimationFrame(scrollLoop);
      };
      animId = requestAnimationFrame(scrollLoop);
    }
    return () => cancelAnimationFrame(animId);
  }, [isAutoScrolling, autoScrollSpeed, readingMode]);

  // Add Comment
  const handlePostComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !user) return;

    setIsSubmittingComment(true);
    try {
      const commentPayload = {
        chapterId: chapter.id,
        manhwaId: manhwa.id,
        userId: user.uid,
        userName: user.displayName || 'قارئ مانهوا',
        userAvatar: user.photoURL || '',
        content: newComment.trim(),
        createdAt: new Date().toISOString()
      };

      await addDoc(collection(db, 'comments'), commentPayload);
      setNewComment('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'comments');
    } finally {
      setIsSubmittingComment(false);
    }
  };

  return (
    <div className={`fixed inset-0 z-50 flex flex-col overflow-hidden transition-colors ${
      isNovel
        ? novelTheme === 'sepia'
          ? 'bg-[#1e1b18] text-[#e6d8c3]'
          : novelTheme === 'pitch'
          ? 'bg-black text-gray-200'
          : 'bg-[#0d121f] text-gray-100'
        : 'bg-[#070a13] text-gray-100'
    }`}>
      
      {/* Top Reading Navigation Bar */}
      <header
        className={`bg-[#0d121f]/95 backdrop-blur-md border-b border-purple-900/30 px-4 py-2.5 flex items-center justify-between transition-all duration-300 ${
          showControls ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors text-xs font-bold"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة للعمل</span>
          </button>
          
          <div className="hidden sm:flex flex-col">
            <span className="text-xs font-bold text-white truncate max-w-xs">{manhwa.title}</span>
            <span className="text-[11px] text-purple-400 font-semibold">
              {isNovel ? 'فصل/حلقة' : 'الفصل'} {chapter.chapterNumber} {chapter.title ? `- ${chapter.title}` : ''}
            </span>
          </div>
        </div>

        {/* Chapter Selection & Prev/Next */}
        <div className="flex items-center gap-2">
          <button
            disabled={!prevChapter}
            onClick={() => prevChapter && onSelectChapter(prevChapter)}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="الفصل السابق"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <select
            value={chapter.id}
            onChange={(e) => {
              const selected = allChapters.find((c) => c.id === e.target.value);
              if (selected) onSelectChapter(selected);
            }}
            className="bg-[#151b2d] border border-white/10 text-xs font-bold text-gray-200 px-3 py-1.5 rounded-lg outline-none focus:border-purple-500"
          >
            {sortedChapters.map((c) => (
              <option key={c.id} value={c.id}>
                {isNovel ? 'فصل/حلقة' : 'الفصل'} {c.chapterNumber} {c.title ? `(${c.title})` : ''}
              </option>
            ))}
          </select>

          <button
            disabled={!nextChapter}
            onClick={() => nextChapter && onSelectChapter(nextChapter)}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="الفصل التالي"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        {/* Reading Controls */}
        <div className="flex items-center gap-2">
          {isNovel ? (
            /* Novel Controls: Text Size & Themes */
            <div className="flex items-center gap-2 bg-[#151b2d] px-2 py-1 rounded-xl border border-white/10">
              <button
                onClick={() => setNovelFontSize((s) => Math.max(14, s - 2))}
                className="px-2 py-0.5 text-xs font-bold text-gray-300 hover:text-white"
                title="تصغير الخط"
              >
                أ-
              </button>
              <span className="text-[11px] font-mono text-purple-300">{novelFontSize}px</span>
              <button
                onClick={() => setNovelFontSize((s) => Math.min(32, s + 2))}
                className="px-2 py-0.5 text-xs font-bold text-gray-300 hover:text-white"
                title="تكبير الخط"
              >
                أ+
              </button>

              <button
                onClick={() => setNovelTheme((t) => (t === 'dark' ? 'sepia' : t === 'sepia' ? 'pitch' : 'dark'))}
                className="p-1 text-purple-300 hover:text-white"
                title="تغيير مظهر القراءة"
              >
                <Sun className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            /* Visual Webtoon Controls: Zoom & Auto Scroll */
            <>
              <div className="hidden md:flex items-center bg-[#151b2d] rounded-lg border border-white/5 px-1 py-0.5">
                <button
                  onClick={() => setZoomLevel((prev) => Math.max(prev - 10, 60))}
                  className="p-1 text-gray-400 hover:text-white"
                  title="تصغير"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span className="text-[11px] font-mono text-purple-300 px-1">{zoomLevel}%</span>
                <button
                  onClick={() => setZoomLevel((prev) => Math.min(prev + 10, 150))}
                  className="p-1 text-gray-400 hover:text-white"
                  title="تكبير"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                onClick={() => setIsAutoScrolling(!isAutoScrolling)}
                className={`hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                  isAutoScrolling
                    ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/30'
                    : 'bg-white/5 text-gray-300 border-white/5 hover:bg-white/10'
                }`}
                title="تمرير تلقائي"
              >
                {isAutoScrolling ? <Square className="w-3 h-3 fill-current" /> : <Play className="w-3 h-3" />}
                <span>تمرير</span>
              </button>
            </>
          )}

          <button
            onClick={() => setShowControls(false)}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300"
            title="إخفاء الشريط"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Floating reveal button */}
      {!showControls && (
        <button
          onClick={() => setShowControls(true)}
          className="fixed top-3 right-3 z-50 p-2.5 bg-purple-600/90 text-white rounded-full shadow-lg shadow-purple-900/50 hover:bg-purple-500 backdrop-blur"
          title="إظهار القائمة"
        >
          <Sliders className="w-4 h-4" />
        </button>
      )}

      {/* Main Reader Canvas */}
      <main
        ref={containerRef}
        className="flex-1 overflow-y-auto no-scrollbar relative flex flex-col items-center select-none"
      >
        <div
          style={{ width: isNovel ? '100%' : `${zoomLevel}%`, maxWidth: isNovel ? '800px' : '1000px' }}
          className="transition-all duration-150 mx-auto px-4"
        >
          {isNovel ? (
            /* Novel Text Chapter Content */
            <div className="py-8">
              <h1 className="text-xl sm:text-2xl font-bold mb-6 text-center text-purple-400">
                الفصل {chapter.chapterNumber} {chapter.title ? `- ${chapter.title}` : ''}
              </h1>

              <div
                style={{ fontSize: `${novelFontSize}px`, lineHeight: '1.9' }}
                className="font-serif whitespace-pre-wrap text-justify selection:bg-purple-600 selection:text-white"
              >
                {chapter.novelContent || (
                  <div className="text-center py-16 text-gray-400">
                    لا يوجد نص مسجل لهذا الفصل حتى الآن.
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* Webtoon Image Pages */
            chapter.pages && chapter.pages.length > 0 ? (
              readingMode === 'vertical' ? (
                <div className="flex flex-col">
                  {chapter.pages.map((pageUrl, idx) => (
                    <div key={idx} className="relative w-full bg-[#0b0f19]">
                      <SmartImage
                        src={pageUrl}
                        alt={`الصفحة ${idx + 1}`}
                        fallbackText={`الصفحة ${idx + 1}`}
                        className="webtoon-image w-full h-auto object-contain block select-none"
                        loading={idx < 4 ? 'eager' : 'lazy'}
                      />
                      <div className="absolute bottom-1 right-2 bg-black/60 backdrop-blur-sm text-[10px] font-mono px-2 py-0.5 rounded text-gray-300">
                        {idx + 1} / {chapter.pages.length}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center py-6 min-h-[80vh] justify-center">
                  <SmartImage
                    src={chapter.pages[currentPageIndex]}
                    alt={`الصفحة ${currentPageIndex + 1}`}
                    fallbackText={`الصفحة ${currentPageIndex + 1}`}
                    className="max-h-[85vh] w-auto rounded-lg shadow-2xl object-contain"
                    loading="eager"
                  />
                  <div className="flex items-center gap-4 mt-4">
                    <button
                      disabled={currentPageIndex === 0}
                      onClick={() => setCurrentPageIndex((p) => Math.max(p - 1, 0))}
                      className="px-4 py-2 bg-[#171f33] rounded-lg text-xs font-bold disabled:opacity-30"
                    >
                      السابق
                    </button>
                    <span className="text-xs font-mono text-purple-400">
                      {currentPageIndex + 1} من {chapter.pages.length}
                    </span>
                    <button
                      disabled={currentPageIndex === chapter.pages.length - 1}
                      onClick={() => setCurrentPageIndex((p) => Math.min(p + 1, chapter.pages.length - 1))}
                      className="px-4 py-2 bg-[#171f33] rounded-lg text-xs font-bold disabled:opacity-30"
                    >
                      التالي
                    </button>
                  </div>
                </div>
              )
            ) : (
              <div className="py-24 text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-purple-900/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                  <Sparkles className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">لا توجد صفحات في هذا الفصل بعد</h3>
                <p className="text-xs text-gray-400">يقوم فريق النشر حالياً برفع صفحات هذا الفصل.</p>
              </div>
            )
          )}

          {/* Chapter Bottom Navigation */}
          <div className="my-8 px-4 py-6 bg-[#0f1526] rounded-2xl border border-purple-900/40 flex flex-col items-center gap-4 text-center">
            <h4 className="text-base font-bold text-white">
              وصلت إلى نهاية {isNovel ? 'فصل الرواية' : 'الفصل'} {chapter.chapterNumber}
            </h4>
            <div className="flex items-center gap-3">
              {prevChapter && (
                <button
                  onClick={() => onSelectChapter(prevChapter)}
                  className="px-4 py-2 rounded-xl bg-[#171f33] hover:bg-[#202b46] text-xs font-bold text-gray-200 transition-colors"
                >
                  الفصل السابق ({prevChapter.chapterNumber})
                </button>
              )}
              {nextChapter ? (
                <button
                  onClick={() => onSelectChapter(nextChapter)}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-xs font-bold text-white shadow-lg shadow-purple-700/30 transition-transform hover:scale-105"
                >
                  الانتقال إلى الفصل التالي ({nextChapter.chapterNumber})
                </button>
              ) : (
                <div className="text-xs text-purple-400 font-semibold px-4 py-2 bg-purple-950/40 rounded-xl border border-purple-800/40">
                  🎉 أنت تشاهد أحدث فصل متوفر حتى الآن!
                </div>
              )}
            </div>
          </div>

          {/* Comments Section */}
          <section className="mb-16 px-4 py-6 bg-[#0d121f] rounded-2xl border border-white/5">
            <div className="flex items-center gap-2 mb-6">
              <MessageSquare className="w-5 h-5 text-purple-400" />
              <h3 className="text-base font-bold text-white">التعليقات والمناقشة ({comments.length})</h3>
            </div>

            {user ? (
              <form onSubmit={handlePostComment} className="flex gap-2 mb-6">
                <input
                  type="text"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="شارك رأيك وتوقعاتك حول أحداث هذا الفصل..."
                  className="flex-1 bg-[#151b2d] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-gray-100 placeholder-gray-500 outline-none focus:border-purple-500"
                />
                <button
                  type="submit"
                  disabled={isSubmittingComment || !newComment.trim()}
                  className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md shadow-purple-900/40"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>إرسال</span>
                </button>
              </form>
            ) : (
              <div className="p-4 mb-6 rounded-xl bg-[#151b2d]/60 border border-purple-500/20 text-center">
                <span className="text-xs text-gray-300">سجل الدخول لتتمكن من كتابة تعليقاتك على الفصل</span>
              </div>
            )}

            <div className="space-y-3">
              {comments.length === 0 ? (
                <div className="text-center py-6 text-xs text-gray-500">
                  كن أول من يعلق على هذا الفصل!
                </div>
              ) : (
                comments.map((comment) => (
                  <div key={comment.id} className="p-3.5 bg-[#141a2a] rounded-xl border border-white/5 flex gap-3">
                    {comment.userAvatar ? (
                      <img
                        src={comment.userAvatar}
                        alt={comment.userName}
                        className="w-8 h-8 rounded-full object-cover border border-purple-500/30"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-purple-700 text-white font-bold text-xs flex items-center justify-center">
                        {comment.userName[0]?.toUpperCase() || 'U'}
                      </div>
                    )}
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-purple-300">{comment.userName}</span>
                        <span className="text-[10px] text-gray-500">
                          {new Date(comment.createdAt).toLocaleDateString('ar-EG')}
                        </span>
                      </div>
                      <p className="text-xs text-gray-200 leading-relaxed">{comment.content}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>

        </div>
      </main>

    </div>
  );
};
