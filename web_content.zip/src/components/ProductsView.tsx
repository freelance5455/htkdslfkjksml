import React, { useMemo, useRef, useState } from 'react';
import { Check, Sparkles } from 'lucide-react';
import { ALL_UNITS, fmtQty, getCategoryTemplate } from '../categoryTemplates';
import type { Product, ReportPayload, StoreData } from '../types';
import { findProductByBarcodeOrSku, fmtInt, fmtMoney, uid } from '../utils';
import { BarcodeLabelSheet } from './BarcodeSVG';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { Icon } from './Icon';
import { ConfirmModal, CustomSelect, Modal, SmartComboField, ToggleSwitch } from './SharedUI';
import { SheetPrintPreviewModal, SheetPreviewTarget } from './SheetPrintPreview';

const roundQty = (n: number) => Math.max(0, Math.round(n * 1000) / 1000);

interface ProductsViewProps {
  data: StoreData;
  t: Record<string, string>;
  onSaveProduct: (prod: Product, isEdit: boolean) => void;
  onDeleteProduct: (id: string) => void;
  onPrintLabels: (payload: { items: Product[]; showPrice: boolean; showStore: boolean }) => void;
  onPrintReport: (report: ReportPayload) => void;
  notify: (msg: string, type?: 'success' | 'error') => void;
}

export const ProductsView: React.FC<ProductsViewProps> = ({
  data,
  t,
  onSaveProduct,
  onDeleteProduct,
  onPrintLabels,
  onPrintReport,
  notify,
}) => {
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('all');
  const [subCatFilter, setSubCatFilter] = useState('all');
  const [brandFilter, setBrandFilter] = useState('all');
  const [stockFilter, setStockFilter] = useState<'all' | 'low' | 'out'>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [labelModal, setLabelModal] = useState<Product[] | null>(null);
  const [labelQty, setLabelQty] = useState<string | number>(6);
  const [showPrice, setShowPrice] = useState(true);
  const [showStore, setShowStore] = useState(true);
  const [scanTarget, setScanTarget] = useState<'search' | 'form' | null>(null);
  const [sheetPreview, setSheetPreview] = useState<SheetPreviewTarget | null>(null);
  const nameInputRef = useRef<HTMLInputElement>(null);

  const defaultCatName = data.categories[0]?.name || 'Mobile & Gadgets';
  const emptyForm = {
    name: '',
    sku: '',
    barcode: '',
    category: defaultCatName,
    subCategory: '',
    brand: '',
    model: '',
    variantSpec: '',
    unit: getCategoryTemplate(defaultCatName, data.categories).defaultUnit,
    purchasePrice: '',
    sellingPrice: '',
    quantity: '',
    minStock: String(data.settings.defaultLowStockLimit),
    supplier: '',
    notes: '',
  };
  const [form, setForm] = useState(emptyForm);

  const openAdd = (prefillBarcode = '') => {
    setEditing(null);
    const catName = catFilter !== 'all' ? catFilter : data.categories[0]?.name || 'Mobile & Gadgets';
    const tmpl = getCategoryTemplate(catName, data.categories);
    setForm({
      ...emptyForm,
      category: catName,
      subCategory: subCatFilter !== 'all' ? subCatFilter : '',
      brand: brandFilter !== 'all' ? brandFilter : '',
      unit: tmpl.defaultUnit,
      barcode: prefillBarcode,
    });
    setModalOpen(true);
    setTimeout(() => nameInputRef.current?.focus(), 80);
  };

  const openEdit = (p: Product) => {
    setEditing(p);
    const tmpl = getCategoryTemplate(p.category, data.categories);
    setForm({
      name: p.name,
      sku: p.sku,
      barcode: p.barcode,
      category: p.category,
      subCategory: p.subCategory || '',
      brand: p.brand || '',
      model: p.model || '',
      variantSpec: p.variantSpec || '',
      unit: p.unit || tmpl.defaultUnit || 'pcs',
      purchasePrice: String(p.purchasePrice),
      sellingPrice: String(p.sellingPrice),
      quantity: String(p.quantity),
      minStock: String(p.minStock ?? data.settings.defaultLowStockLimit),
      supplier: p.supplier,
      notes: p.notes,
    });
    setModalOpen(true);
  };

  const activeTemplate = useMemo(
    () => getCategoryTemplate(form.category, data.categories),
    [form.category, data.categories]
  );

  const modelSuggestions = useMemo(() => {
    const brandModels =
      form.brand && activeTemplate.modelsByBrand?.[form.brand]
        ? activeTemplate.modelsByBrand[form.brand]
        : [];
    return Array.from(new Set([...brandModels, ...activeTemplate.genericModels]));
  }, [form.brand, activeTemplate]);

  const unitOptions = useMemo(() => {
    const ordered = Array.from(new Set([...activeTemplate.units, ...ALL_UNITS]));
    return ordered.map((u) => ({ value: u, label: u }));
  }, [activeTemplate.units]);

  const catSubFilters = useMemo(() => {
    if (catFilter === 'all') return [];
    const set = new Set<string>();
    data.products.forEach((p) => {
      if (p.category === catFilter && p.subCategory?.trim()) set.add(p.subCategory.trim());
    });
    return Array.from(set);
  }, [data.products, catFilter]);

  const catBrandFilters = useMemo(() => {
    if (catFilter === 'all') return [];
    const set = new Set<string>();
    data.products.forEach((p) => {
      if (p.category !== catFilter) return;
      if (subCatFilter !== 'all' && p.subCategory !== subCatFilter) return;
      if (p.brand?.trim()) set.add(p.brand.trim());
    });
    return Array.from(set);
  }, [data.products, catFilter, subCatFilter]);

  const duplicateBarcode = useMemo(() => {
    const b = (form.barcode || '').trim();
    if (!b) return false;
    return data.products.some((p) => p.barcode === b && p.id !== editing?.id);
  }, [form.barcode, data.products, editing]);

  const summary = useMemo(() => {
    const lowCount = data.products.filter((p) => p.quantity > 0 && p.quantity <= (p.minStock ?? data.settings.defaultLowStockLimit)).length;
    const outCount = data.products.filter((p) => p.quantity === 0).length;
    const totalUnits = roundQty(data.products.reduce((s, p) => s + p.quantity, 0));
    const totalCost = data.products.reduce((s, p) => s + p.quantity * p.purchasePrice, 0);
    return { lowCount, outCount, totalUnits, totalCost };
  }, [data.products, data.settings.defaultLowStockLimit]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return data.products.filter((p) => {
      const matchCat = catFilter === 'all' || p.category === catFilter;
      const matchSubCat = catFilter === 'all' || subCatFilter === 'all' || p.subCategory === subCatFilter;
      const matchBrand = catFilter === 'all' || brandFilter === 'all' || p.brand === brandFilter;
      const isLow = p.quantity <= (p.minStock ?? data.settings.defaultLowStockLimit);
      const matchStock =
        stockFilter === 'all' ||
        (stockFilter === 'low' && isLow) ||
        (stockFilter === 'out' && p.quantity === 0);
      const matchQ =
        !q ||
        p.name.toLowerCase().includes(q) ||
        (p.sku || '').toLowerCase().includes(q) ||
        (p.barcode || '').toLowerCase().includes(q) ||
        (p.brand || '').toLowerCase().includes(q) ||
        (p.subCategory || '').toLowerCase().includes(q) ||
        (p.model || '').toLowerCase().includes(q) ||
        (p.variantSpec || '').toLowerCase().includes(q);
      return matchCat && matchSubCat && matchBrand && matchStock && matchQ;
    });
  }, [data.products, search, catFilter, subCatFilter, brandFilter, stockFilter, data.settings.defaultLowStockLimit]);

  const autoFillProductName = () => {
    const parts = [form.brand, form.model, form.subCategory, form.variantSpec].map((s) => s.trim()).filter(Boolean);
    if (parts.length === 0) {
      notify('Pick a Brand, Type, or Model first to auto-fill name', 'error');
      return;
    }
    setForm((prev) => ({ ...prev, name: parts.join(' ') }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const fallbackName = [form.brand, form.model, form.subCategory].map((s) => s.trim()).filter(Boolean).join(' ');
    const resolvedName = form.name.trim() || fallbackName;
    if (!resolvedName || form.purchasePrice === '' || form.sellingPrice === '' || form.quantity === '') {
      notify(t.fillRequiredFields, 'error');
      return;
    }
    const payload: Product = {
      id: editing ? editing.id : uid(),
      name: resolvedName,
      sku: form.sku.trim(),
      barcode: form.barcode.trim(),
      category: form.category,
      subCategory: form.subCategory.trim(),
      brand: form.brand.trim(),
      model: form.model.trim(),
      variantSpec: form.variantSpec.trim(),
      unit: form.unit || activeTemplate.defaultUnit || 'pcs',
      purchasePrice: Number(form.purchasePrice || 0),
      sellingPrice: Number(form.sellingPrice || 0),
      quantity: roundQty(parseFloat(form.quantity || '0') || 0),
      minStock: Math.max(0, parseFloat(form.minStock || String(data.settings.defaultLowStockLimit)) || 0),
      supplier: form.supplier.trim(),
      notes: form.notes.trim(),
    };
    onSaveProduct(payload, !!editing);
    setModalOpen(false);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const openSingleLabel = (p: Product) => {
    if (!p.barcode && !p.sku) {
      notify(t.noBarcodeSet, 'error');
      return;
    }
    setLabelQty(6);
    setLabelModal([p]);
  };

  const openBulkLabels = () => {
    const prods = data.products.filter((p) => selectedIds.includes(p.id) && (p.barcode || p.sku));
    if (prods.length === 0) {
      notify(t.noBarcodeSet, 'error');
      return;
    }
    setLabelQty(2);
    setLabelModal(prods);
  };

  const previewLabels = useMemo(() => {
    if (!labelModal) return [];
    const out: Product[] = [];
    const cnt = Math.max(1, Math.min(60, parseInt(String(labelQty || '1'), 10)));
    labelModal.forEach((p) => {
      for (let i = 0; i < cnt; i++) out.push(p);
    });
    return out;
  }, [labelModal, labelQty]);

  const catFilterOptions = useMemo(
    () => [{ value: 'all', label: t.allCategories }, ...data.categories.map((c) => ({ value: c.name, label: c.name }))],
    [data.categories, t.allCategories]
  );

  const catFormOptions = useMemo(() => data.categories.map((c) => ({ value: c.name, label: c.name })), [data.categories]);

  const inputClass =
    'w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition';

  return (
    <div className="space-y-4">
      {/* Compact Inventory Snapshot Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 tabular-nums">
        <div className="bg-white rounded-2xl border border-slate-200/90 px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.totalProducts}</p>
          <p className="text-xl font-extrabold text-slate-900 mt-0.5">{data.products.length}</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200/90 px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.units} in Stock</p>
          <p className="text-xl font-extrabold text-indigo-600 mt-0.5">{summary.totalUnits}</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200/90 px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.stockValue}</p>
          <p className="text-xl font-extrabold text-slate-900 mt-0.5">{fmtMoney(summary.totalCost)}</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200/90 px-4 py-3.5">
          <p className="text-xs font-medium text-slate-500">{t.lowStockItems}</p>
          <p className={`text-xl font-extrabold mt-0.5 ${summary.lowCount + summary.outCount > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
            {summary.lowCount + summary.outCount}
          </p>
        </div>
      </div>

      {/* Filter & Actions Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
          <div className="flex flex-col sm:flex-row gap-3 flex-1">
            <div className="flex gap-2 flex-1">
              <div className="relative flex-1">
                <Icon name="search" className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder={t.searchProducts}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition"
                />
              </div>
              <button
                type="button"
                onClick={() => setScanTarget('search')}
                className="btn-dark px-3.5 py-2.5 text-xs shrink-0"
                title={t.scanBarcode}
              >
                <Icon name="barcode" className="w-4 h-4" />
                <span>Scan</span>
              </button>
            </div>
            <CustomSelect
              value={catFilter}
              onChange={(val) => {
                setCatFilter(val);
                setSubCatFilter('all');
                setBrandFilter('all');
              }}
              options={catFilterOptions}
              searchable
              className="sm:w-56"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {selectedIds.length > 0 && (
              <button type="button" onClick={openBulkLabels} className="btn-dark px-3.5 py-2.5 text-sm">
                <Icon name="barcode" className="w-4 h-4" />
                <span>
                  {t.printSelectedLabels} ({selectedIds.length})
                </span>
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                const totalUnits = roundQty(filtered.reduce((s, p) => s + p.quantity, 0));
                const totalCost = filtered.reduce((s, p) => s + p.quantity * p.purchasePrice, 0);
                const totalRetail = filtered.reduce((s, p) => s + p.quantity * p.sellingPrice, 0);
                const isCat = catFilter !== 'all';
                setSheetPreview({
                  kind: 'report',
                  report: {
                    title: isCat ? `${catFilter} — Product List Sheet` : 'Product Stock List Sheet',
                    sheetBanner: `${isCat ? catFilter : 'All Categories'} Product List (${filtered.length} products · ${totalUnits} units)`,
                    subtitle: `${isCat ? catFilter : t.allCategories} · ${filtered.length} products`,
                    summaryCards: [
                      { label: 'Total Products', value: fmtInt(filtered.length) },
                      { label: 'Total Units', value: fmtQty(totalUnits) },
                      { label: 'Stock Cost Value', value: fmtMoney(totalCost) },
                      { label: 'Stock Retail Value', value: fmtMoney(totalRetail) },
                    ],
                    headers: ['SL #', t.productName, t.barcode, t.category, t.quantity, t.purchasePrice, t.sellingPrice, t.costValue, t.retailValue],
                    rows: filtered.map((p, idx) => [
                      idx + 1,
                      p.name + (p.model ? ` (${p.model})` : ''),
                      p.barcode || p.sku || '-',
                      [p.category, p.subCategory, p.brand].filter(Boolean).join(' · '),
                      fmtQty(p.quantity, p.unit),
                      p.purchasePrice.toFixed(2),
                      p.sellingPrice.toFixed(2),
                      (p.quantity * p.purchasePrice).toFixed(2),
                      (p.quantity * p.sellingPrice).toFixed(2),
                    ]),
                    totalsRow: ['', 'GRAND TOTAL', '', `${filtered.length} items`, totalUnits, '-', '-', totalCost.toFixed(2), totalRetail.toFixed(2)],
                  },
                });
              }}
              className="btn-secondary px-3.5 py-2.5 text-sm"
            >
              <Icon name="print" className="w-4 h-4" />
              <span>{t.printStatement}</span>
            </button>
            <button type="button" onClick={() => openAdd('')} className="btn-primary px-4 py-2.5 text-sm">
              <Icon name="plus" className="w-4 h-4" />
              <span>{t.addProduct}</span>
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          {(
            [
              ['all', `${t.all} (${data.products.length})`],
              ['low', `${t.lowStock} (${summary.lowCount + summary.outCount})`],
              ['out', `${t.outOfStock} (${summary.outCount})`],
            ] as const
          ).map(([id, label]) => (
            <button
              type="button"
              key={id}
              onClick={() => setStockFilter(id)}
              className={`option-chip ${stockFilter === id ? 'option-chip-active' : ''}`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Sub-Category & Brand Drilldown Pills when a category is selected */}
        {catFilter !== 'all' && (catSubFilters.length > 0 || catBrandFilters.length > 0) && (
          <div className="pt-2 border-t border-slate-100 space-y-2">
            {catSubFilters.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[11px] font-bold text-slate-500 mr-1">Type:</span>
                <button
                  type="button"
                  onClick={() => {
                    setSubCatFilter('all');
                    setBrandFilter('all');
                  }}
                  className={`option-chip text-[11px] ${subCatFilter === 'all' ? 'option-chip-active' : ''}`}
                >
                  All
                </button>
                {catSubFilters.map((sc) => (
                  <button
                    type="button"
                    key={sc}
                    onClick={() => {
                      setSubCatFilter(sc);
                      setBrandFilter('all');
                    }}
                    className={`option-chip text-[11px] ${subCatFilter === sc ? 'option-chip-active' : ''}`}
                  >
                    {sc}
                  </button>
                ))}
              </div>
            )}
            {catBrandFilters.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[11px] font-bold text-slate-500 mr-1">Brand:</span>
                <button
                  type="button"
                  onClick={() => setBrandFilter('all')}
                  className={`option-chip text-[11px] ${brandFilter === 'all' ? 'option-chip-active' : ''}`}
                >
                  All
                </button>
                {catBrandFilters.map((br) => (
                  <button
                    type="button"
                    key={br}
                    onClick={() => setBrandFilter(br)}
                    className={`option-chip text-[11px] ${brandFilter === br ? 'option-chip-active' : ''}`}
                  >
                    {br}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Product Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left tabular-nums">
            <thead className="bg-slate-50 text-slate-600 text-xs font-semibold border-b border-slate-200">
              <tr>
                <th className="px-3 py-3 w-10 whitespace-nowrap">
                  <button
                    type="button"
                    aria-label="Select all products"
                    onClick={() => {
                      const allSelected = filtered.length > 0 && filtered.every((p) => selectedIds.includes(p.id));
                      setSelectedIds(allSelected ? [] : filtered.map((p) => p.id));
                    }}
                    className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                      filtered.length > 0 && filtered.every((p) => selectedIds.includes(p.id))
                        ? 'bg-blue-600 border-blue-600 text-white'
                        : 'bg-white border-slate-300 text-transparent'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                  </button>
                </th>
                <th className="px-4 py-3 whitespace-nowrap">{t.productName}</th>
                <th className="px-4 py-3 whitespace-nowrap">
                  {t.category} / {t.modelVariant}
                </th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.purchasePrice}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.sellingPrice}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.profitMargin}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.quantity}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.stockValue}</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-12 px-4">
                    <p className="text-slate-500 text-sm mb-3">{t.noData}</p>
                    <button
                      type="button"
                      onClick={() => openAdd(search.trim())}
                      className="btn-primary px-4 py-2 text-xs"
                    >
                      <Icon name="plus" className="w-4 h-4" />
                      <span>{search.trim() ? `${t.addProduct} (${search.trim()})` : t.addProduct}</span>
                    </button>
                  </td>
                </tr>
              ) : (
                filtered.map((p) => {
                  const margin = p.sellingPrice > 0 ? (((p.sellingPrice - p.purchasePrice) / p.sellingPrice) * 100).toFixed(1) : '0.0';
                  const isLow = p.quantity <= (p.minStock ?? data.settings.defaultLowStockLimit);
                  const isChecked = selectedIds.includes(p.id);
                  return (
                    <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-3 py-3">
                        <button
                          type="button"
                          aria-label={`Select ${p.name}`}
                          onClick={() => toggleSelect(p.id)}
                          className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                            isChecked ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white border-slate-300 text-transparent'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                        </button>
                      </td>
                      <td className="px-4 py-3 min-w-[190px]">
                        <p className="font-bold text-slate-800">{p.name}</p>
                        <p className="text-xs font-mono text-slate-400">
                          SKU: {p.sku || '-'} {p.barcode ? `· ${p.barcode}` : ''}
                        </p>
                      </td>
                      <td className="px-4 py-3 text-slate-600 whitespace-nowrap">
                        <p className="font-medium text-slate-700">
                          {p.category}
                          {p.subCategory ? <span className="text-slate-400"> · {p.subCategory}</span> : null}
                        </p>
                        {(p.brand || p.model || p.variantSpec) && (
                          <p className="text-[11px] text-slate-400 truncate max-w-[230px]">
                            {[p.brand, p.model, p.variantSpec].filter(Boolean).join(' · ')}
                          </p>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">{fmtMoney(p.purchasePrice)}</td>
                      <td className="px-4 py-3 text-right font-semibold whitespace-nowrap">{fmtMoney(p.sellingPrice)}</td>
                      <td className="px-4 py-3 text-right text-emerald-600 font-semibold whitespace-nowrap">{margin}%</td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-md text-xs font-bold ${
                            p.quantity === 0
                              ? 'bg-rose-50 text-rose-700'
                              : isLow
                              ? 'bg-amber-50 text-amber-700'
                              : 'bg-emerald-50 text-emerald-700'
                          }`}
                        >
                          {fmtQty(p.quantity, p.unit)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right font-medium whitespace-nowrap">{fmtMoney(p.quantity * p.purchasePrice)}</td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <div className="inline-flex gap-1">
                          <button
                            type="button"
                            onClick={() => openSingleLabel(p)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                            title={t.printLabels}
                          >
                            <Icon name="barcode" className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => openEdit(p)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50"
                            title={t.edit}
                          >
                            <Icon name="edit" className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTarget(p)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50"
                            title={t.delete}
                          >
                            <Icon name="trash" className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Product Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? t.editProduct : t.addProduct} maxWidth="max-w-2xl">
        <form noValidate onSubmit={handleSubmit} className="space-y-4">
          {duplicateBarcode && (
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold">
              {t.duplicateBarcodeWarning}
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.category} *</label>
              <CustomSelect
                value={form.category}
                onChange={(val) => {
                  const tmpl = getCategoryTemplate(val, data.categories);
                  setForm((prev) => ({
                    ...prev,
                    category: val,
                    subCategory: '',
                    brand: '',
                    model: '',
                    variantSpec: '',
                    unit: editing ? prev.unit : tmpl.defaultUnit,
                  }));
                }}
                options={catFormOptions}
                searchable
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">Unit</label>
              <CustomSelect
                value={form.unit}
                onChange={(val) => setForm({ ...form, unit: val })}
                options={unitOptions}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{activeTemplate.subCategoryLabel}</label>
              <SmartComboField
                value={form.subCategory}
                onChange={(val) => setForm({ ...form, subCategory: val })}
                suggestions={activeTemplate.subCategories}
                placeholder="Tap or type 2 letters..."
                quickChipsCount={3}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{activeTemplate.brandLabel}</label>
              <SmartComboField
                value={form.brand}
                onChange={(val) => setForm({ ...form, brand: val })}
                suggestions={activeTemplate.brands}
                placeholder="e.g. Samsung, Apple, Frutika..."
                quickChipsCount={4}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{activeTemplate.modelLabel}</label>
              <SmartComboField
                value={form.model}
                onChange={(val) => setForm({ ...form, model: val })}
                suggestions={modelSuggestions}
                placeholder="Tap or type model / weight..."
                quickChipsCount={4}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{activeTemplate.variantLabel}</label>
              <SmartComboField
                value={form.variantSpec}
                onChange={(val) => setForm({ ...form, variantSpec: val })}
                suggestions={activeTemplate.variants}
                placeholder="Color, flavor, material..."
                quickChipsCount={3}
              />
            </div>

            <div className="sm:col-span-2">
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <label className="block text-xs font-semibold text-slate-600">{t.productName} *</label>
                <button
                  type="button"
                  onClick={autoFillProductName}
                  className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:underline"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Auto-fill Name from Selection</span>
                </button>
              </div>
              <input
                ref={nameInputRef}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Enter product name..."
                className={inputClass}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.sku}</label>
              <input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} className={`${inputClass} font-mono`} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.barcode}</label>
              <div className="flex gap-1.5">
                <input
                  value={form.barcode}
                  onChange={(e) => setForm({ ...form, barcode: e.target.value })}
                  placeholder="Scan or enter barcode..."
                  className="flex-1 min-w-0 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                />
                <button
                  type="button"
                  onClick={() => setScanTarget('form')}
                  className="btn-dark px-3.5 py-2.5 text-xs shrink-0"
                  title={t.scanBarcode}
                >
                  <Icon name="barcode" className="w-4 h-4" />
                  <span>Scan</span>
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.purchasePrice} *</label>
              <input
                type="number"
                step="0.01"
                value={form.purchasePrice}
                onChange={(e) => setForm({ ...form, purchasePrice: e.target.value })}
                className={`${inputClass} tabular-nums`}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.sellingPrice} *</label>
              <input
                type="number"
                step="0.01"
                value={form.sellingPrice}
                onChange={(e) => setForm({ ...form, sellingPrice: e.target.value })}
                className={`${inputClass} tabular-nums`}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                {t.quantity} ({form.unit || 'pcs'}) *
              </label>
              <input
                type="number"
                step="any"
                min="0"
                value={form.quantity}
                onChange={(e) => setForm({ ...form, quantity: e.target.value })}
                className={`${inputClass} tabular-nums`}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.minStock}</label>
              <input
                type="number"
                step="any"
                min="0"
                value={form.minStock}
                onChange={(e) => setForm({ ...form, minStock: e.target.value })}
                className={`${inputClass} tabular-nums`}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.supplier}</label>
              <input value={form.supplier} onChange={(e) => setForm({ ...form, supplier: e.target.value })} className={inputClass} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.notes}</label>
              <input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className={inputClass} />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button type="button" onClick={() => setModalOpen(false)} className="btn-secondary px-4 py-2.5 text-sm">
              {t.cancel}
            </button>
            <button type="submit" className="btn-primary px-5 py-2.5 text-sm">
              {t.save}
            </button>
          </div>
        </form>
      </Modal>

      {/* In-app Delete Confirmation Modal */}
      <ConfirmModal
        open={!!deleteTarget}
        title={t.deleteProduct}
        message={`${t.confirmDelete} (${deleteTarget?.name || ''})`}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) onDeleteProduct(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />

      {/* Barcode Label Print Preview Modal */}
      <Modal open={!!labelModal} onClose={() => setLabelModal(null)} title={t.printLabels} maxWidth="max-w-3xl">
        {labelModal && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-4 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-700">{t.labelCount}:</span>
                <input
                  type="number"
                  min="1"
                  max="60"
                  value={labelQty}
                  onChange={(e) => setLabelQty(e.target.value)}
                  className="w-16 rounded-lg border border-slate-200 px-2 py-1 text-center font-bold bg-white tabular-nums"
                />
              </div>
              <div className="inline-flex items-center gap-2 font-semibold text-slate-700">
                <ToggleSwitch checked={showPrice} onChange={setShowPrice} label={t.showPriceOnLabel} />
                <span>{t.showPriceOnLabel}</span>
              </div>
              <div className="inline-flex items-center gap-2 font-semibold text-slate-700">
                <ToggleSwitch checked={showStore} onChange={setShowStore} label={t.showStoreOnLabel} />
                <span>{t.showStoreOnLabel}</span>
              </div>
            </div>

            <div className="max-h-80 overflow-y-auto custom-scrollbar border border-slate-200 rounded-xl bg-slate-100 p-2">
              <BarcodeLabelSheet items={previewLabels} settings={data.settings} showPrice={showPrice} showStore={showStore} />
            </div>

            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setLabelModal(null)} className="btn-secondary px-4 py-2 text-sm">
                {t.close}
              </button>
              <button
                type="button"
                onClick={() => onPrintLabels({ items: previewLabels, showPrice, showStore })}
                className="btn-primary px-5 py-2 text-sm"
              >
                <Icon name="print" className="w-4 h-4" />
                <span>{t.print}</span>
              </button>
            </div>
          </div>
        )}
      </Modal>

      <BarcodeScannerModal
        open={!!scanTarget}
        onClose={() => setScanTarget(null)}
        onDetected={(code) => {
          if (scanTarget === 'form') {
            setForm((prev) => ({ ...prev, barcode: code }));
            notify(`Barcode added: ${code}`);
            if (!form.name.trim()) {
              setTimeout(() => nameInputRef.current?.focus(), 80);
            }
          } else {
            const matched = findProductByBarcodeOrSku(data.products, code);
            if (matched) {
              setSearch(matched.barcode || matched.name);
              notify(`Found: ${matched.name}`);
            } else {
              setSearch(code);
              openAdd(code);
              notify(`New barcode "${code}" — enter Product Name to save.`);
            }
          }
        }}
        title={t.scanBarcode}
        t={t}
        products={scanTarget === 'search' ? data.products : []}
      />

      <SheetPrintPreviewModal
        target={sheetPreview}
        settings={data.settings}
        onClose={() => setSheetPreview(null)}
        onTriggerNativePrint={(target) => {
          if (target.kind === 'report') onPrintReport(target.report);
        }}
      />
    </div>
  );
};
