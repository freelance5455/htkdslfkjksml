import { ArrowRightIcon, SparklesIcon, CheckIcon } from "./icons";

export function FinalCTA() {
  return (
    <section className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="reveal-scale relative overflow-hidden rounded-3xl border border-white/10">
          {/* Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-brand-700 via-brand-800 to-ink-950" />
          <div className="absolute inset-0 mesh-gradient opacity-60" />
          <div className="pointer-events-none absolute -top-24 -right-24 h-72 w-72 rounded-full bg-fuchsia-500/30 blur-[100px] animate-pulse-glow" />
          <div className="pointer-events-none absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-violet-400/20 blur-[100px]" />
          <div className="pointer-events-none absolute inset-0 grid-bg opacity-30" />

          <div className="relative px-6 py-16 text-center sm:px-12 sm:py-20 lg:py-24">
            <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-medium text-brand-100 backdrop-blur-sm">
              <SparklesIcon size={12} />
              14-day free trial · No card required
            </div>

            <h2 className="mx-auto mt-6 max-w-2xl text-3xl font-semibold tracking-tight text-white sm:text-4xl lg:text-5xl">
              Stop managing chaos.
              <br />
              <span className="text-brand-200">Start cascading clarity.</span>
            </h2>

            <p className="mx-auto mt-5 max-w-xl text-base text-brand-100/70 sm:text-lg">
              Join thousands of ops leaders who reclaimed their calendars and
              gave their teams a unfair advantage. Your first workflow is one
              prompt away.
            </p>

            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <button
                type="button"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-7 py-3.5 text-sm font-semibold text-ink-950 shadow-xl shadow-black/20 transition-all duration-300 hover:-translate-y-0.5 hover:bg-brand-50 sm:w-auto"
              >
                Start free trial
                <ArrowRightIcon size={16} />
              </button>
              <button
                type="button"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-white/25 bg-white/10 px-7 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition-all duration-300 hover:bg-white/15 sm:w-auto"
              >
                Book a demo
              </button>
            </div>

            <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-brand-100/60">
              {["Setup in minutes", "Cancel anytime", "Migrate free"].map(
                (item) => (
                  <span key={item} className="inline-flex items-center gap-1.5">
                    <CheckIcon size={14} className="text-brand-300" />
                    {item}
                  </span>
                )
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
