import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  ShieldAlert, 
  ShieldCheck, 
  Search, 
  Filter, 
  Download, 
  Trash2, 
  Ban, 
  CheckCircle2, 
  AlertTriangle, 
  Eye, 
  Copy, 
  HardDrive, 
  Cloud, 
  Phone, 
  Mail, 
  MapPin, 
  Key, 
  UserCheck, 
  UserX, 
  Bell, 
  X,
  Sparkles,
  RefreshCw,
  Wallet
} from 'lucide-react';
import { membersRegistryService, RegisteredMemberRecord } from '../lib/membersRegistryService';

interface RegisteredMembersViewProps {
  onShowToast?: (msg: string) => void;
}

export const RegisteredMembersView: React.FC<RegisteredMembersViewProps> = ({ onShowToast }) => {
  const [members, setMembers] = useState<RegisteredMemberRecord[]>(() => membersRegistryService.getAllMembers());
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTier, setSelectedTier] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedMember, setSelectedMember] = useState<RegisteredMemberRecord | null>(null);
  const [banModalMember, setBanModalMember] = useState<RegisteredMemberRecord | null>(null);
  const [banReasonInput, setBanReasonInput] = useState<string>('Suspicious high-frequency transactions suspected of money laundering or botnet automation.');
  const [notifications, setNotifications] = useState<any[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('jm_owner_member_notifications') || '[]');
    } catch {
      return [];
    }
  });

  const [auditLogs, setAuditLogs] = useState<any[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('jm_admin_audit_action_logs') || '[]');
    } catch {
      return [];
    }
  });

  const logAdminAction = (action: string, targetName: string, details: string) => {
    const newLog = {
      id: `log-${Date.now()}`,
      action,
      targetName,
      details,
      timestamp: new Date().toLocaleString()
    };
    const updated = [newLog, ...auditLogs];
    setAuditLogs(updated);
    try {
      localStorage.setItem('jm_admin_audit_action_logs', JSON.stringify(updated.slice(0, 100)));
    } catch {
      // ignore
    }
  };

  const showToast = (msg: string) => {
    if (onShowToast) onShowToast(msg);
  };

  useEffect(() => {
    const handleUpdate = () => {
      setMembers(membersRegistryService.getAllMembers());
      try {
        setNotifications(JSON.parse(localStorage.getItem('jm_owner_member_notifications') || '[]'));
        setAuditLogs(JSON.parse(localStorage.getItem('jm_admin_audit_action_logs') || '[]'));
      } catch {
        // ignore
      }
    };

    const unsubscribe = membersRegistryService.subscribe(handleUpdate);
    window.addEventListener('juhnkrix_members_updated', handleUpdate);
    window.addEventListener('juhnkrix_new_member_notification', handleUpdate);

    return () => {
      unsubscribe();
      window.removeEventListener('juhnkrix_members_updated', handleUpdate);
      window.removeEventListener('juhnkrix_new_member_notification', handleUpdate);
    };
  }, []);

  const filteredMembers = useMemo(() => {
    return members.filter(m => {
      const matchesSearch = !searchQuery.trim() || 
        m.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.phoneNumber.includes(searchQuery) ||
        (m.jmcWalletAddress && m.jmcWalletAddress.toLowerCase().includes(searchQuery.toLowerCase())) ||
        m.id.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesTier = selectedTier === 'ALL' || m.membershipTier === selectedTier;
      const matchesStatus = selectedStatus === 'ALL' || m.status === selectedStatus;

      return matchesSearch && matchesTier && matchesStatus;
    });
  }, [members, searchQuery, selectedTier, selectedStatus]);

  const stats = useMemo(() => {
    return {
      total: members.length,
      approved: members.filter(m => m.status === 'APPROVED').length,
      banned: members.filter(m => m.status === 'BANNED').length,
      activeWallets: members.filter(m => m.walletStatus === 'ACTIVE').length,
      unreadNotifs: notifications.filter(n => !n.isRead).length
    };
  }, [members, notifications]);

  const handleBanConfirm = () => {
    if (!banModalMember) return;
    membersRegistryService.banMember(banModalMember.id, banReasonInput);
    logAdminAction('BAN_MEMBER', banModalMember.fullName, `Banned for: ${banReasonInput}`);
    setBanModalMember(null);
    showToast(`✓ Member ${banModalMember.fullName} banned and blocked from using app & wallet.`);
  };

  const handleUnban = (member: RegisteredMemberRecord) => {
    membersRegistryService.unbanMember(member.id);
    logAdminAction('UNBAN_MEMBER', member.fullName, 'Account reinstated and verified by Prophet JUHNKRIX');
    showToast(`✓ Member ${member.fullName} reinstated & verified by Prophet JUHNKRIX SYNVAGORD.`);
  };

  const handleDelete = (member: RegisteredMemberRecord) => {
    if (confirm(`Are you sure you want to permanently delete member ${member.fullName} (${member.email})?`)) {
      membersRegistryService.deleteMember(member.id);
      logAdminAction('DELETE_MEMBER', member.fullName, `Permanently deleted member ID ${member.id}`);
      showToast(`✓ Member record deleted permanently from unlimited built-in storage.`);
    }
  };

  const handleClearNotifications = () => {
    localStorage.removeItem('jm_owner_member_notifications');
    setNotifications([]);
    showToast('✓ Notification history cleared.');
  };

  return (
    <div className="space-y-6">
      {/* Main Header Card */}
      <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-950/80 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden space-y-6">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center space-x-3.5">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border-2 border-amber-400/50 shadow-xl shadow-amber-500/20 shrink-0">
              <Users className="w-8 h-8 text-amber-400" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black font-serif text-amber-100">
                  REGISTERED MEMBERS INFORMATIONS DATA
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  Unlimited Built-in Storage
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
                  Cloudflare Synced
                </span>
              </div>
              <p className="text-xs text-slate-300 max-w-3xl mt-1 leading-relaxed">
                Exclusive to Prophet JUHNKRIX SYNVAGORD. Real-time registry of all registered believers, personal contact information, 
                JMC wallet links, and anti-fraud / anti-money laundering (AML) enforcement machine. 
                Data is stored both in the unlimited built-in storage (online/offline) and synced to <span className="text-amber-300 font-mono">juhnkrixmusika.pages.dev</span>.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                const data = localStorage.getItem('REGISTERED_MEMBERS_INFORMATIONS_DATA') || JSON.stringify(membersRegistryService.getAllMembers(), null, 2);
                const blob = new Blob([data], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `REGISTERED_MEMBERS_INFORMATIONS_DATA_${Date.now()}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                logAdminAction('EXPORT_MEMBER_DATA', 'All Members', 'Exported REGISTERED_MEMBERS_INFORMATIONS_DATA backup JSON');
                showToast('✓ Export Member Data (REGISTERED_MEMBERS_INFORMATIONS_DATA) downloaded successfully!');
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-black flex items-center space-x-1.5 shadow-lg shadow-amber-500/20 transition-all"
            >
              <Download className="w-3.5 h-3.5 text-slate-950" />
              <span>Export Member Data</span>
            </button>
            <button
              onClick={() => {
                membersRegistryService.exportMembersJson();
                showToast('✓ Registered members database exported as JSON!');
              }}
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>Export JSON</span>
            </button>
            <button
              onClick={() => {
                membersRegistryService.exportMembersCsv();
                showToast('✓ Registered members database exported as CSV!');
              }}
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* 4 Stat Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 relative z-10">
          <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20">
            <span className="text-[10px] text-slate-400 font-mono block">TOTAL REGISTERED</span>
            <span className="text-2xl font-black text-amber-200 font-mono mt-0.5 block">
              {stats.total.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-500">Global Believers</span>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-emerald-500/20">
            <span className="text-[10px] text-slate-400 font-mono block">ACTIVE JMC WALLETS</span>
            <span className="text-2xl font-black text-emerald-300 font-mono mt-0.5 block">
              {stats.activeWallets.toLocaleString()}
            </span>
            <span className="text-[10px] text-emerald-400">Mining & Trade Ready</span>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-blue-500/20">
            <span className="text-[10px] text-slate-400 font-mono block">VERIFIED & APPROVED</span>
            <span className="text-2xl font-black text-blue-300 font-mono mt-0.5 block">
              {stats.approved.toLocaleString()}
            </span>
            <span className="text-[10px] text-blue-400">Good Standing</span>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-rose-500/20">
            <span className="text-[10px] text-slate-400 font-mono block">BANNED / FRAUD FLAGS</span>
            <span className="text-2xl font-black text-rose-300 font-mono mt-0.5 block">
              {stats.banned}
            </span>
            <span className="text-[10px] text-rose-400">AML Protected</span>
          </div>
        </div>
      </div>

      {/* Notifications Drawer (If Any New Members) */}
      {notifications.length > 0 && (
        <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-2">
            <div className="flex items-center space-x-2 text-xs font-bold text-amber-300">
              <Bell className="w-4 h-4 text-amber-400 animate-bounce" />
              <span>RECENT MEMBERSHIP REGISTRATION NOTIFICATIONS ({notifications.length})</span>
            </div>
            <button
              onClick={handleClearNotifications}
              className="text-[10px] text-slate-400 hover:text-white underline font-mono"
            >
              Clear Notifications
            </button>
          </div>
          <div className="space-y-1.5 max-h-32 overflow-y-auto font-mono text-[11px]">
            {notifications.slice(0, 5).map((n: any, idx: number) => (
              <div key={idx} className="bg-slate-950 p-2 rounded-xl flex items-center justify-between text-slate-300">
                <span className="truncate mr-2">🔔 {n.message}</span>
                <span className="text-slate-500 text-[10px] shrink-0">{n.timestamp}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Search & Filter Controls */}
      <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-amber-400/70 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search member name, email, phone, wallet..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedTier}
            onChange={(e) => setSelectedTier(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-amber-200 focus:outline-none"
          >
            <option value="ALL">All Tiers</option>
            <option value="Sanctuary Elder">Sanctuary Elder</option>
            <option value="Prophetic Partner">Prophetic Partner</option>
            <option value="Anointed Member">Anointed Member</option>
            <option value="Global Believer">Global Believer</option>
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-amber-200 focus:outline-none"
          >
            <option value="ALL">All Statuses</option>
            <option value="APPROVED">Approved Only</option>
            <option value="BANNED">Banned / Flagged</option>
          </select>
        </div>
      </div>

      {/* Members Registry Table */}
      <div className="bg-slate-950 border border-amber-500/30 rounded-3xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-900/90 text-amber-300 font-bold border-b border-amber-500/20 text-[10px] uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Member ID & Reg Date</th>
                <th className="py-3 px-4">Full Name & Tier</th>
                <th className="py-3 px-4">Contact (Email & Phone)</th>
                <th className="py-3 px-4">JMC Wallet Address</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Owner Authority Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200 text-[11px]">
              {filteredMembers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No registered members matching your filter criteria.
                  </td>
                </tr>
              ) : (
                filteredMembers.map((member) => (
                  <tr key={member.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-amber-300">{member.id}</div>
                      <div className="text-[10px] text-slate-400">{member.registeredAt}</div>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-bold text-amber-100 font-sans">{member.fullName}</div>
                      <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-bold border mt-0.5 ${
                        member.membershipTier === 'Sanctuary Elder' ? 'bg-amber-500/20 text-amber-300 border-amber-400/40' :
                        member.membershipTier === 'Prophetic Partner' ? 'bg-purple-500/20 text-purple-300 border-purple-400/40' :
                        'bg-blue-500/20 text-blue-300 border-blue-400/40'
                      }`}>
                        {member.membershipTier}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-1 text-slate-300">
                        <Mail className="w-3 h-3 text-slate-500" />
                        <span className="truncate max-w-[150px]">{member.email}</span>
                      </div>
                      <div className="flex items-center space-x-1 text-emerald-300 text-[10px] mt-0.5">
                        <Phone className="w-3 h-3 text-slate-500" />
                        <span>{member.phoneNumber}</span>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      {member.jmcWalletAddress ? (
                        <div className="flex items-center space-x-1">
                          <code className="text-indigo-300 font-mono text-[10px] truncate max-w-[140px]" title={member.jmcWalletAddress}>
                            {member.jmcWalletAddress}
                          </code>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(member.jmcWalletAddress || '');
                              showToast('✓ Member wallet address copied!');
                            }}
                            className="p-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-400"
                            title="Copy Wallet"
                          >
                            <Copy className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-500 font-sans italic">Not Created Yet</span>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      {member.status === 'BANNED' ? (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
                          <Ban className="w-3 h-3 text-rose-400" />
                          <span>BANNED</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>APPROVED</span>
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end space-x-1.5">
                        <button
                          onClick={() => setSelectedMember(member)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/20 text-[10px]"
                          title="View Full Member Dossier"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {member.status === 'BANNED' ? (
                          <button
                            onClick={() => handleUnban(member)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold"
                            title="Unban and Restore Member"
                          >
                            Unban
                          </button>
                        ) : (
                          <button
                            onClick={() => {
                              setBanModalMember(member);
                              setBanReasonInput('Suspicious automated transaction velocity / Fraud prevention');
                            }}
                            className="px-2.5 py-1 rounded-lg bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-500/40 text-[10px] font-bold"
                            title="Ban Member (Fraud / Money Laundering)"
                          >
                            Ban Member
                          </button>
                        )}

                        <button
                          onClick={() => handleDelete(member)}
                          className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-rose-400 border border-rose-500/20"
                          title="Permanently Delete Member Record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MEMBER DOSSIER MODAL */}
      <AnimatePresence>
        {selectedMember && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5"
            >
              <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
                <div className="flex items-center space-x-2.5">
                  <UserCheck className="w-5 h-5 text-amber-400" />
                  <h3 className="text-base font-bold text-amber-100 font-serif">
                    Member Registration Dossier
                  </h3>
                </div>
                <button onClick={() => setSelectedMember(null)} className="text-slate-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3 font-mono text-xs">
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Member ID:</span>
                  <span className="font-bold text-amber-300">{selectedMember.id}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Full Name:</span>
                  <span className="font-bold text-white font-sans">{selectedMember.fullName}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Email Address:</span>
                  <span className="text-amber-200">{selectedMember.email}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Phone Number:</span>
                  <span className="text-emerald-300">{selectedMember.phoneNumber}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Country:</span>
                  <span className="text-slate-200">{selectedMember.country}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Membership Tier:</span>
                  <span className="text-purple-300 font-bold">{selectedMember.membershipTier}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">JMC Wallet Address:</span>
                  <span className="text-indigo-300 break-all text-[11px]">
                    {selectedMember.jmcWalletAddress || 'None (Not Created)'}
                  </span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Device Hardware Fingerprint:</span>
                  <span className="text-slate-300 text-[10px]">{selectedMember.deviceFingerprint}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Registered At:</span>
                  <span className="text-slate-300">{selectedMember.registeredAt}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Security / Fraud Flag:</span>
                  <span className={selectedMember.fraudFlag ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>
                    {selectedMember.fraudFlag ? 'FLAGGED (AML Alert)' : 'CLEAN (Approved)'}
                  </span>
                </div>
              </div>

              {selectedMember.banReason && (
                <div className="p-3 bg-rose-950/40 border border-rose-500/40 rounded-xl text-xs text-rose-200 space-y-1">
                  <strong className="block font-bold">Ban Reason Logged by Owner:</strong>
                  <p>{selectedMember.banReason}</p>
                </div>
              )}

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setSelectedMember(null)}
                  className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
                >
                  Close Dossier
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* BAN CONFIRMATION MODAL */}
      <AnimatePresence>
        {banModalMember && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border-2 border-rose-500/50 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4"
            >
              <div className="flex items-center space-x-3 text-rose-300 border-b border-rose-500/20 pb-3">
                <ShieldAlert className="w-6 h-6 text-rose-400" />
                <h3 className="text-base font-bold font-serif">
                  Ban Member for Fraud / Money Laundering
                </h3>
              </div>

              <p className="text-xs text-slate-300">
                You are about to ban <strong>{banModalMember.fullName}</strong> ({banModalMember.email}). 
                This will lock their JMC Wallet and revoke all sanctuary app access.
              </p>

              <div>
                <label className="text-xs text-rose-300 font-bold block mb-1">
                  Reason for Ban / Investigation Log:
                </label>
                <textarea
                  rows={3}
                  value={banReasonInput}
                  onChange={(e) => setBanReasonInput(e.target.value)}
                  className="w-full bg-slate-950 border border-rose-500/30 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-rose-400 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={handleBanConfirm}
                  className="py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase shadow-lg shadow-rose-600/30"
                >
                  Confirm Ban & Block
                </button>
                <button
                  onClick={() => setBanModalMember(null)}
                  className="py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Admin Action Audit Accountability Log Panel */}
      <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 space-y-4 shadow-xl mt-8">
        <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-300">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>ADMINISTRATIVE ACTION AUDIT LOG ({auditLogs.length})</span>
          </div>
          <button
            onClick={() => {
              localStorage.removeItem('jm_admin_audit_action_logs');
              setAuditLogs([]);
              showToast('✓ Admin audit logs cleared.');
            }}
            className="text-[10px] text-slate-400 hover:text-white underline font-mono"
          >
            Clear Audit Logs
          </button>
        </div>

        {auditLogs.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-500 font-mono">
            No sensitive administrative actions logged yet. Actions like banning, unbanning, deleting members, or exporting data are recorded here automatically.
          </div>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto font-mono text-xs">
            {auditLogs.map((log: any) => (
              <div key={log.id} className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                      {log.action}
                    </span>
                    <span className="text-white font-bold">{log.targetName}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{log.details}</div>
                </div>
                <div className="text-[10px] text-slate-500 shrink-0">
                  {log.timestamp}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
