import React from 'react';
import { Phone, PhoneOff, Mic, MicOff, Square } from 'lucide-react';

interface CallControlsProps {
  isCallActive: boolean;
  isMuted: boolean;
  isSpeaking: boolean;
  onStartCall: () => void;
  onEndCall: () => void;
  onToggleMute: () => void;
  onInterrupt: () => void;
}

export const CallControls: React.FC<CallControlsProps> = ({
  isCallActive,
  isMuted,
  isSpeaking,
  onStartCall,
  onEndCall,
  onToggleMute,
  onInterrupt,
}) => {
  return (
    <div className="flex flex-col items-center justify-center w-full max-w-sm mx-auto px-4 my-2 space-y-3">
      {/* Primary Call Action Buttons */}
      <div className="flex items-center justify-center gap-4 w-full">
        {!isCallActive ? (
          /* Start Call Button (Green) */
          <button
            onClick={onStartCall}
            className="flex-1 flex items-center justify-center gap-2.5 py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-base shadow-lg shadow-emerald-500/25 transition-all cursor-pointer"
          >
            <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center">
              <Phone className="w-4 h-4 fill-current" />
            </div>
            <span>Start Call</span>
          </button>
        ) : (
          /* End / Cut Call Button (Red) */
          <button
            onClick={onEndCall}
            className="flex-1 flex items-center justify-center gap-2.5 py-4 px-6 rounded-2xl bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold text-base shadow-lg shadow-red-500/25 transition-all cursor-pointer animate-in fade-in"
          >
            <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center">
              <PhoneOff className="w-4 h-4" />
            </div>
            <span>End Call</span>
          </button>
        )}
      </div>

      {/* Secondary Controls (Mute & Interrupt) */}
      <div className="flex items-center justify-center gap-3 w-full">
        {/* Mute Assistant / Mic button */}
        <button
          onClick={onToggleMute}
          disabled={!isCallActive}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
            !isCallActive
              ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400 border-slate-200'
              : isMuted
              ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
              : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 shadow-2xs'
          }`}
        >
          {isMuted ? <MicOff className="w-4 h-4 text-white" /> : <Mic className="w-4 h-4 text-slate-600" />}
          <span>{isMuted ? 'Unmute' : 'Mute'}</span>
        </button>

        {/* Interrupt button (active when assistant is speaking) */}
        {isCallActive && isSpeaking && (
          <button
            onClick={onInterrupt}
            className="flex-1 flex items-center justify-center gap-1.5 py-3 px-4 rounded-xl bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 text-xs font-bold transition-all cursor-pointer shadow-2xs animate-pulse"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>Interrupt</span>
          </button>
        )}
      </div>
    </div>
  );
};
