import React from 'react';
import { Check, Wrench, X } from 'lucide-react';
import {
  PAINT_COLORS,
  type BikeCustomization,
  type BikeModelType,
  type ExhaustType,
  type HandlebarType,
  type PlayerProgress,
  type TailBarType,
  type TireType,
} from '../game/types';

interface WorkshopModalProps {
  open: boolean;
  progress: PlayerProgress;
  onClose: () => void;
  onBuyModel: (model: BikeModelType, price: number) => void;
  onBuyColor: (colorId: string, price: number) => void;
  onBuyPart: (
    category: 'tire' | 'exhaust' | 'handlebar' | 'tailBar',
    id: string,
    price: number
  ) => void;
  onUpgradeStat: (
    stat: keyof Pick<
      BikeCustomization,
      'motorLevel' | 'gearRatioLevel' | 'brakeLevel' | 'suspensionLevel'
    >,
    price: number
  ) => void;
}

const BIKE_MODEL_OPTIONS: Array<{ id: BikeModelType; name: string; desc: string; price: number }> = [
  { id: 'cg_titan_160', name: 'CG 160 Titan', desc: 'Abas esportivas, farol angular e visual urbano 160cc', price: 0 },
  { id: 'cg_fan_160', name: 'CG 160 Fan / Start', desc: 'Estilo montadinha clássico com farol redondo cromado', price: 0 },
  { id: 'bros_160', name: 'NXR 160 Bros', desc: 'Paralama alto trail + protetor de motor para morro e asfalto', price: 450 },
];

const TIRE_OPTIONS: Array<{ id: TireType; name: string; desc: string; price: number }> = [
  { id: 'urbano', name: 'Original Urbano', desc: 'Equilíbrio no asfalto seco e molhado', price: 0 },
  { id: 'slick', name: 'Slick Street', desc: '+12% aderência no sol, -15% na chuva', price: 400 },
  { id: 'misto', name: 'Misto / Cravo Morro', desc: '+18% tração na chuva e subidas da favela', price: 480 },
];

const EXHAUST_OPTIONS: Array<{ id: ExhaustType; name: string; desc: string; price: number }> = [
  { id: 'original', name: 'Original 160', desc: 'Ronco clássico silencioso', price: 0 },
  { id: 'dore', name: 'Dore Cromado', desc: 'Grave esportivo e visual cromado', price: 520 },
  { id: 'trioval', name: 'Fortuna Tri-Oval', desc: 'Estalo médio encorpado', price: 650 },
  { id: 'direto', name: 'Só o Cano (Direto)', desc: 'Pipoco máximo no corte de 140 km/h', price: 780 },
];

const HANDLEBAR_OPTIONS: Array<{ id: HandlebarType; name: string; desc: string; price: number }> = [
  { id: 'original', name: 'Guidão Original', desc: 'Conforto urbano padrão', price: 0 },
  { id: 'esportivo', name: 'Guidão Baixo', desc: 'Postura agressiva nas curvas', price: 320 },
  { id: 'oxxy', name: 'Oxxy Dourado Grau', desc: 'Largo com travessa para controle no grau', price: 540 },
];

const TAILBAR_OPTIONS: Array<{ id: TailBarType; name: string; desc: string; price: number }> = [
  { id: 'original', name: 'Rabeta Limpa', desc: 'Sem suporte traseiro', price: 0 },
  { id: 'alca_grau', name: 'Alça de Grau Cromada', desc: 'Visual clássico de projeto grau', price: 280 },
];

export const WorkshopModal: React.FC<WorkshopModalProps> = ({
  open,
  progress,
  onClose,
  onBuyModel,
  onBuyColor,
  onBuyPart,
  onUpgradeStat,
}) => {
  if (!open) return null;

  const c = progress.customization;

  const upgradeRows: Array<{
    key: keyof Pick<
      BikeCustomization,
      'motorLevel' | 'gearRatioLevel' | 'brakeLevel' | 'suspensionLevel'
    >;
    label: string;
    detail: string;
    level: number;
  }> = [
    {
      key: 'motorLevel',
      label: 'Preparação Motor 160cc',
      detail: 'Mais torque em baixa/média rotação (máxima mantida em 140 km/h)',
      level: c.motorLevel,
    },
    {
      key: 'gearRatioLevel',
      label: 'Relação / Coroa de Grau',
      detail: 'Arrancada mais forte e subida de frente facilitada',
      level: c.gearRatioLevel,
    },
    {
      key: 'brakeLevel',
      label: 'Freio a Disco Esportivo',
      detail: 'Frenagem precisa e modulação fina no ponto de equilíbrio',
      level: c.brakeLevel,
    },
    {
      key: 'suspensionLevel',
      label: 'Suspensão Reforçada',
      detail: 'Estabilidade nos morros da favela e retorno suave do grau',
      level: c.suspensionLevel,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3">
      <div className="w-full max-w-4xl max-h-[88vh] flex flex-col bg-neutral-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <Wrench className="w-5 h-5 text-amber-400" />
            <h2 className="font-display text-lg font-bold text-white">Oficina 160 · Customização e Upgrades</h2>
          </div>
          <div className="flex items-center gap-4">
            <span className="font-mono-tabular text-sm font-semibold text-emerald-400">
              Saldo: R$ {progress.money.toLocaleString('pt-BR')}
            </span>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
              aria-label="Fechar Oficina"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* 160cc Bike Models */}
          <section>
            <div className="flex items-baseline justify-between mb-2.5">
              <h3 className="text-sm font-semibold text-neutral-100">Modelos Moto 160</h3>
              <span className="text-xs text-neutral-400">Escolha o chassi e estilo da sua 160cc</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {BIKE_MODEL_OPTIONS.map((m) => {
                const owned = (progress.ownedModels ?? ['cg_titan_160', 'cg_fan_160']).includes(m.id);
                const equipped = (c.bikeModel ?? 'cg_titan_160') === m.id;
                const canAfford = progress.money >= m.price;
                return (
                  <button
                    key={m.id}
                    type="button"
                    disabled={!owned && !canAfford}
                    onClick={() => onBuyModel(m.id, owned ? 0 : m.price)}
                    className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                      equipped
                        ? 'border-amber-400 bg-amber-400/10'
                        : 'border-white/10 bg-neutral-800/70 hover:bg-neutral-800 disabled:opacity-45'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-white">{m.name}</span>
                      <span className="text-[11px] font-mono-tabular text-amber-300">
                        {equipped ? 'Equipada' : owned ? 'Usar' : `R$ ${m.price}`}
                      </span>
                    </div>
                    <div className="text-[11px] text-neutral-400 mt-1">{m.desc}</div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Paint Colors */}
          <section>
            <div className="flex items-baseline justify-between mb-2.5">
              <h3 className="text-sm font-semibold text-neutral-100">Pintura da Moto</h3>
              <span className="text-xs text-neutral-400">Aplicação imediata no tanque e carenagem</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {PAINT_COLORS.map((opt) => {
                const owned = progress.ownedColors.includes(opt.id);
                const equipped = c.colorId === opt.id;
                const canAfford = progress.money >= opt.price;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    disabled={!owned && !canAfford}
                    onClick={() => onBuyColor(opt.id, owned ? 0 : opt.price)}
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left transition-colors cursor-pointer ${
                      equipped
                        ? 'border-amber-400 bg-amber-400/10'
                        : 'border-white/10 bg-neutral-800/70 hover:bg-neutral-800 disabled:opacity-45'
                    }`}
                  >
                    <span
                      className="w-6 h-6 rounded-md border border-white/25 shrink-0"
                      style={{ backgroundColor: opt.hex }}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium text-white truncate">{opt.name}</div>
                      <div className="text-[11px] font-mono-tabular text-neutral-400">
                        {equipped ? 'Equipada' : owned ? 'Disponível' : `R$ ${opt.price}`}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Performance Upgrades */}
          <section>
            <div className="flex items-baseline justify-between mb-2.5">
              <h3 className="text-sm font-semibold text-neutral-100">Upgrades de Performance</h3>
              <span className="text-xs text-neutral-400">Aceleração e controle · Limite máximo 140 km/h</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {upgradeRows.map((row) => {
                const isMax = row.level >= 3;
                const nextPrice = row.level * 450;
                const canAfford = progress.money >= nextPrice;
                return (
                  <div
                    key={row.key}
                    className="flex items-center justify-between gap-3 p-3 rounded-xl border border-white/10 bg-neutral-800/60"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white">
                        {row.label} · Nível {row.level}/3
                      </div>
                      <p className="text-[11px] text-neutral-400 mt-0.5">{row.detail}</p>
                    </div>
                    <button
                      type="button"
                      disabled={isMax || !canAfford}
                      onClick={() => onUpgradeStat(row.key, nextPrice)}
                      className="px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 bg-amber-500 text-neutral-950 hover:bg-amber-400 disabled:bg-neutral-700 disabled:text-neutral-400 transition-colors cursor-pointer"
                    >
                      {isMax ? 'Máximo' : `R$ ${nextPrice}`}
                    </button>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Parts Grid: Tires, Exhaust, Handlebar, TailBar */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <section>
              <h3 className="text-sm font-semibold text-neutral-100 mb-2">Pneus</h3>
              <div className="space-y-2">
                {TIRE_OPTIONS.map((t) => {
                  const owned = progress.ownedTires.includes(t.id);
                  const eq = c.tire === t.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      disabled={!owned && progress.money < t.price}
                      onClick={() => onBuyPart('tire', t.id, owned ? 0 : t.price)}
                      className={`w-full flex items-center justify-between gap-2 p-2.5 rounded-xl border text-left transition-colors cursor-pointer ${
                        eq
                          ? 'border-amber-400 bg-amber-400/10'
                          : 'border-white/10 bg-neutral-800/60 hover:bg-neutral-800 disabled:opacity-45'
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-white">{t.name}</div>
                        <div className="text-[11px] text-neutral-400">{t.desc}</div>
                      </div>
                      <span className="text-xs font-mono-tabular text-amber-300 shrink-0">
                        {eq ? <Check className="w-4 h-4 text-emerald-400" /> : owned ? 'Usar' : `R$ ${t.price}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </section>

            <section>
              <h3 className="text-sm font-semibold text-neutral-100 mb-2">Escapamento</h3>
              <div className="space-y-2">
                {EXHAUST_OPTIONS.map((ex) => {
                  const owned = progress.ownedExhausts.includes(ex.id);
                  const eq = c.exhaust === ex.id;
                  return (
                    <button
                      key={ex.id}
                      type="button"
                      disabled={!owned && progress.money < ex.price}
                      onClick={() => onBuyPart('exhaust', ex.id, owned ? 0 : ex.price)}
                      className={`w-full flex items-center justify-between gap-2 p-2.5 rounded-xl border text-left transition-colors cursor-pointer ${
                        eq
                          ? 'border-amber-400 bg-amber-400/10'
                          : 'border-white/10 bg-neutral-800/60 hover:bg-neutral-800 disabled:opacity-45'
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-white">{ex.name}</div>
                        <div className="text-[11px] text-neutral-400">{ex.desc}</div>
                      </div>
                      <span className="text-xs font-mono-tabular text-amber-300 shrink-0">
                        {eq ? <Check className="w-4 h-4 text-emerald-400" /> : owned ? 'Usar' : `R$ ${ex.price}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </section>

            <section>
              <h3 className="text-sm font-semibold text-neutral-100 mb-2">Guidão</h3>
              <div className="space-y-2">
                {HANDLEBAR_OPTIONS.map((hb) => {
                  const owned = progress.ownedHandlebars.includes(hb.id);
                  const eq = c.handlebar === hb.id;
                  return (
                    <button
                      key={hb.id}
                      type="button"
                      disabled={!owned && progress.money < hb.price}
                      onClick={() => onBuyPart('handlebar', hb.id, owned ? 0 : hb.price)}
                      className={`w-full flex items-center justify-between gap-2 p-2.5 rounded-xl border text-left transition-colors cursor-pointer ${
                        eq
                          ? 'border-amber-400 bg-amber-400/10'
                          : 'border-white/10 bg-neutral-800/60 hover:bg-neutral-800 disabled:opacity-45'
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-white">{hb.name}</div>
                        <div className="text-[11px] text-neutral-400">{hb.desc}</div>
                      </div>
                      <span className="text-xs font-mono-tabular text-amber-300 shrink-0">
                        {eq ? <Check className="w-4 h-4 text-emerald-400" /> : owned ? 'Usar' : `R$ ${hb.price}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </section>

            <section>
              <h3 className="text-sm font-semibold text-neutral-100 mb-2">Traseira / Alça de Grau</h3>
              <div className="space-y-2">
                {TAILBAR_OPTIONS.map((tb) => {
                  const owned = progress.ownedTailBars.includes(tb.id);
                  const eq = c.tailBar === tb.id;
                  return (
                    <button
                      key={tb.id}
                      type="button"
                      disabled={!owned && progress.money < tb.price}
                      onClick={() => onBuyPart('tailBar', tb.id, owned ? 0 : tb.price)}
                      className={`w-full flex items-center justify-between gap-2 p-2.5 rounded-xl border text-left transition-colors cursor-pointer ${
                        eq
                          ? 'border-amber-400 bg-amber-400/10'
                          : 'border-white/10 bg-neutral-800/60 hover:bg-neutral-800 disabled:opacity-45'
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-white">{tb.name}</div>
                        <div className="text-[11px] text-neutral-400">{tb.desc}</div>
                      </div>
                      <span className="text-xs font-mono-tabular text-amber-300 shrink-0">
                        {eq ? <Check className="w-4 h-4 text-emerald-400" /> : owned ? 'Usar' : `R$ ${tb.price}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};
