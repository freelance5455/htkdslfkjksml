import React, { useState } from 'react';
import {
  X,
  Clock,
  Dumbbell,
  Play,
  Layers,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
  CheckCircle2,
  Eye,
  Sparkles,
  Edit
} from 'lucide-react';
import { CustomRoutine, Exercise } from '../types';
import { MuscleMapCharacter } from './MuscleMapCharacter';

interface RoutinePreviewModalProps {
  routine: CustomRoutine | null;
  exercises: Exercise[];
  onClose: () => void;
  onStartWorkout: (routine: CustomRoutine) => void;
  onEditRoutine?: (routine: CustomRoutine) => void;
}

export const RoutinePreviewModal: React.FC<RoutinePreviewModalProps> = ({
  routine,
  exercises,
  onClose,
  onStartWorkout,
  onEditRoutine
}) => {
  const [focusedExerciseId, setFocusedExerciseId] = useState<string | null>(null);
  const [expandedInstructionIndex, setExpandedInstructionIndex] = useState<number | null>(null);

  if (!routine) return null;

  const routineExerciseDefs = routine.exercises
    .map((item) => exercises.find((e) => e.id === item.exerciseId))
    .filter((e): e is Exercise => Boolean(e));

  const focusedExObj = focusedExerciseId
    ? exercises.find((e) => e.id === focusedExerciseId) || null
    : null;

  const totalSets = routine.exercises.reduce((sum, item) => sum + item.setsCount, 0);

  const uniqueEquipment = Array.from(
    new Set(
      routineExerciseDefs.map((e) =>
        e.equipment === 'none' ? 'Bodyweight' : e.equipment
      )
    )
  );

  return (
    <div
      className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex flex-col justify-end sm:justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-[#12151c] border-t sm:border border-cyan-500/30 rounded-t-3xl sm:rounded-3xl w-full max-w-lg mx-auto max-h-[90vh] flex flex-col overflow-hidden shadow-2xl shadow-cyan-950/40 animate-in slide-in-from-bottom duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-start justify-between gap-3 bg-[#0f1218]">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950/40 border border-cyan-500/30 px-2.5 py-0.5 rounded-full mb-1.5">
              <Eye className="w-3 h-3" />
              <span>Routine Preview (Read-Only)</span>
            </div>
            <h3 className="text-lg font-extrabold text-white leading-tight">{routine.name}</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">{routine.description}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white bg-neutral-900 border border-neutral-800 hover:bg-neutral-800 transition-colors shrink-0"
            title="Close Preview"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Routine Metrics Bar */}
        <div className="grid grid-cols-3 gap-2 px-4 py-3 bg-neutral-900/70 border-b border-neutral-800 text-center">
          <div>
            <div className="text-base font-extrabold text-white font-mono">
              {routine.exercises.length}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">Exercises</div>
          </div>
          <div className="border-x border-neutral-800">
            <div className="text-base font-extrabold text-cyan-400 font-mono">{totalSets}</div>
            <div className="text-[10px] text-slate-400 font-medium">Total Sets</div>
          </div>
          <div>
            <div className="text-base font-extrabold text-white font-mono">
              ~{routine.estimatedDurationMin}m
            </div>
            <div className="text-[10px] text-slate-400 font-medium">Est. Duration</div>
          </div>
        </div>

        {/* Scrollable Routine Details */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Equipment Needed Pills */}
          {uniqueEquipment.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mr-1">
                Equipment:
              </span>
              {uniqueEquipment.map((eq) => (
                <span
                  key={eq}
                  className="text-[11px] capitalize font-medium text-slate-200 bg-neutral-900 border border-neutral-800 px-2.5 py-0.5 rounded-lg"
                >
                  {eq}
                </span>
              ))}
            </div>
          )}

          {/* Target Muscle Map */}
          <div>
            {focusedExObj && (
              <div className="flex justify-end mb-1.5">
                <button
                  type="button"
                  onClick={() => setFocusedExerciseId(null)}
                  className="text-[11px] font-semibold text-cyan-400 hover:text-cyan-300"
                >
                  Reset to Full Routine Muscle Map
                </button>
              </div>
            )}
            <MuscleMapCharacter
              exercise={focusedExObj}
              exercises={focusedExObj ? undefined : routineExerciseDefs}
              size="sm"
              title={
                focusedExObj
                  ? `Exercise Focus: ${focusedExObj.name}`
                  : 'Full Routine Muscle Coverage'
              }
              subtitle="Tap any exercise card below to highlight its specific target muscles"
            />
          </div>

          {/* Exercise Breakdown List */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Workout Plan Breakdown ({routine.exercises.length} Exercises)
              </span>
              <span className="text-[11px] text-slate-500">Tap for cues & muscles</span>
            </div>

            {routine.exercises.map((item, idx) => {
              const exDef = exercises.find((e) => e.id === item.exerciseId);
              const isHold = exDef?.isHold || false;
              const isFocused = focusedExerciseId === item.exerciseId;
              const isInstructionsOpen = expandedInstructionIndex === idx;

              return (
                <div
                  key={`${item.exerciseId}_${idx}`}
                  className={`rounded-2xl border transition-all overflow-hidden ${
                    isFocused
                      ? 'bg-cyan-950/20 border-cyan-500/50 shadow-sm shadow-cyan-500/10'
                      : 'bg-neutral-900/70 border-neutral-800/90 hover:border-neutral-700'
                  }`}
                >
                  <div
                    onClick={() =>
                      setFocusedExerciseId((prev) =>
                        prev === item.exerciseId ? null : item.exerciseId
                      )
                    }
                    className="p-3.5 cursor-pointer flex items-start justify-between gap-3"
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-7 h-7 rounded-xl font-mono text-xs font-extrabold flex items-center justify-center shrink-0 mt-0.5 ${
                          isFocused
                            ? 'bg-cyan-500 text-neutral-950'
                            : 'bg-neutral-800 text-cyan-400 border border-neutral-700'
                        }`}
                      >
                        {idx + 1}
                      </div>

                      <div>
                        <div className="flex items-center flex-wrap gap-1.5 mb-1">
                          <span className="text-sm font-bold text-white">
                            {exDef?.name || item.exerciseId}
                          </span>
                          {exDef?.category && (
                            <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                              {exDef.category}
                            </span>
                          )}
                          {exDef?.difficulty && (
                            <span className="text-[10px] font-medium capitalize px-2 py-0.5 rounded-md bg-neutral-800 text-slate-300">
                              {exDef.difficulty}
                            </span>
                          )}
                        </div>

                        {/* Prescription Pills: Sets × Reps/Hold & Rest */}
                        <div className="flex items-center flex-wrap gap-2 text-xs text-slate-300 font-mono mt-1">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-neutral-950/90 border border-neutral-800 text-cyan-300 font-bold">
                            <Layers className="w-3 h-3 text-cyan-400" />
                            {item.setsCount} sets ×{' '}
                            {isHold
                              ? `${item.defaultHoldSec || exDef?.defaultHoldSec || 30}s hold`
                              : `${item.defaultReps || exDef?.defaultReps || 10} reps`}
                          </span>

                          {item.defaultSetType && item.defaultSetType !== 'normal' && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-purple-500/15 border border-purple-500/40 text-purple-300 text-[10px] font-extrabold uppercase tracking-wider">
                              {item.defaultSetType === 'dropset'
                                ? 'Drop Set'
                                : item.defaultSetType === 'superset'
                                ? 'Superset'
                                : item.defaultSetType === 'restpause'
                                ? 'Rest-Pause'
                                : item.defaultSetType === 'amrap'
                                ? 'AMRAP'
                                : item.defaultSetType === 'tempo'
                                ? 'Slow Tempo'
                                : item.defaultSetType === 'cluster'
                                ? 'Cluster Set'
                                : 'Warm-Up'}
                            </span>
                          )}

                          {item.targetWeightKg && item.targetWeightKg > 0 ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 font-bold">
                              +{item.targetWeightKg}kg
                            </span>
                          ) : null}

                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-neutral-950/90 border border-neutral-800 text-slate-400">
                            <Clock className="w-3 h-3 text-slate-400" />
                            {item.restTimeSec}s rest
                          </span>
                        </div>

                        {/* Target Muscles */}
                        {exDef?.targetMuscles && exDef.targetMuscles.length > 0 && (
                          <div className="text-[11px] text-slate-400 mt-1.5">
                            <span className="text-slate-500">Targets: </span>
                            <span className="text-slate-300">
                              {exDef.targetMuscles.join(', ')}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {exDef && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setExpandedInstructionIndex((prev) => (prev === idx ? null : idx));
                        }}
                        className="px-2 py-1 rounded-lg bg-neutral-800/80 hover:bg-neutral-800 text-[10px] font-semibold text-slate-300 hover:text-cyan-400 flex items-center gap-1 shrink-0 transition-colors"
                        title="Toggle Form Instructions"
                      >
                        <span>Form</span>
                        {isInstructionsOpen ? (
                          <ChevronUp className="w-3 h-3" />
                        ) : (
                          <ChevronDown className="w-3 h-3" />
                        )}
                      </button>
                    )}
                  </div>

                  {/* Expandable Exercise Description & Step-by-Step Instructions */}
                  {isInstructionsOpen && exDef && (
                    <div className="px-3.5 pb-3.5 pt-2 border-t border-neutral-800/80 bg-neutral-950/60 space-y-2 text-xs animate-in fade-in duration-150">
                      <p className="text-slate-300 leading-relaxed">{exDef.description}</p>
                      {exDef.instructions && exDef.instructions.length > 0 && (
                        <div className="space-y-1">
                          <div className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">
                            Execution Cues:
                          </div>
                          <ul className="space-y-1 text-[11px] text-slate-300">
                            {exDef.instructions.map((step, sIdx) => (
                              <li key={sIdx} className="flex items-start gap-1.5">
                                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                                <span>{step}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {exDef.safetyNote && (
                        <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-2 text-[11px] text-amber-200">
                          <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                          <span>{exDef.safetyNote}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-neutral-800 bg-[#0f1218] flex items-center gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="py-2.5 px-3 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-slate-300 font-semibold text-xs rounded-xl transition-colors"
          >
            Close
          </button>
          {onEditRoutine && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onEditRoutine(routine);
              }}
              className="flex-1 py-2.5 bg-neutral-900 hover:bg-neutral-800 border border-cyan-500/40 text-cyan-400 hover:text-cyan-300 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 active:scale-95"
            >
              <Edit className="w-3.5 h-3.5" />
              <span>Edit & Overload</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              onClose();
              onStartWorkout(routine);
            }}
            className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-md shadow-cyan-500/20 active:scale-95 transition-all flex items-center justify-center gap-1.5"
          >
            <Play className="w-3.5 h-3.5 fill-neutral-950" />
            <span>Start Session</span>
          </button>
        </div>
      </div>
    </div>
  );
};

interface RoutineInlinePreviewProps {
  routine: CustomRoutine;
  exercises: Exercise[];
  focusedExerciseId?: string | null;
  onSelectExercise?: (exerciseId: string) => void;
}

export const RoutineInlinePreview: React.FC<RoutineInlinePreviewProps> = ({
  routine,
  exercises,
  focusedExerciseId,
  onSelectExercise
}) => {
  const totalSets = routine.exercises.reduce((sum, item) => sum + item.setsCount, 0);

  return (
    <div className="mt-3 pt-3 border-t border-neutral-800/80 space-y-2 animate-in fade-in duration-200">
      <div className="flex items-center justify-between text-[11px] text-slate-400 px-0.5">
        <span className="font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
          <Sparkles className="w-3 h-3" />
          <span>Routine Breakdown ({totalSets} Total Sets)</span>
        </span>
        <span className="font-mono text-[10px] text-slate-500">Sets × Reps · Rest</span>
      </div>

      <div className="space-y-1.5">
        {routine.exercises.map((item, idx) => {
          const exDef = exercises.find((e) => e.id === item.exerciseId);
          const isHold = exDef?.isHold || false;
          const isSelected = focusedExerciseId === item.exerciseId;

          return (
            <div
              key={`${item.exerciseId}_${idx}`}
              onClick={() => onSelectExercise && onSelectExercise(item.exerciseId)}
              className={`p-2.5 rounded-xl border transition-all flex items-center justify-between gap-2 ${
                onSelectExercise ? 'cursor-pointer' : ''
              } ${
                isSelected
                  ? 'bg-cyan-950/30 border-cyan-500/50'
                  : 'bg-neutral-900/80 border-neutral-800/90 hover:border-neutral-700'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-5 h-5 rounded-lg bg-neutral-800 text-cyan-400 font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                  {idx + 1}
                </span>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white truncate">
                    {exDef?.name || item.exerciseId}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">
                    {exDef?.targetMuscles?.slice(0, 2).join(', ') || exDef?.category || 'Calisthenics'}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0 font-mono text-[11px]">
                <span className="px-2 py-0.5 rounded-md bg-neutral-950 border border-neutral-800 text-cyan-300 font-bold">
                  {item.setsCount} ×{' '}
                  {isHold
                    ? `${item.defaultHoldSec || exDef?.defaultHoldSec || 30}s`
                    : `${item.defaultReps || exDef?.defaultReps || 10}`}
                </span>
                <span className="px-1.5 py-0.5 rounded-md bg-neutral-950/70 border border-neutral-800/80 text-slate-400 text-[10px]">
                  {item.restTimeSec}s rest
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
