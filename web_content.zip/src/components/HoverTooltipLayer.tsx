import React, { useEffect, useState } from 'react';

interface TooltipState {
  text: string;
  x: number;
  y: number;
  placement: 'bottom' | 'top';
}

export const HoverTooltipLayer: React.FC = () => {
  const [tip, setTip] = useState<TooltipState | null>(null);

  useEffect(() => {
    let activeTarget: HTMLElement | null = null;

    const showForElement = (el: HTMLElement | null) => {
      if (!el) {
        activeTarget = null;
        setTip(null);
        return;
      }
      const label = el.getAttribute('data-tooltip');
      if (!label) {
        activeTarget = null;
        setTip(null);
        return;
      }
      activeTarget = el;
      const rect = el.getBoundingClientRect();
      const centerX = Math.max(56, Math.min(window.innerWidth - 56, rect.left + rect.width / 2));
      const preferTop = rect.bottom + 34 > window.innerHeight;
      setTip({
        text: label,
        x: centerX,
        y: preferTop ? Math.max(8, rect.top - 6) : rect.bottom + 6,
        placement: preferTop ? 'top' : 'bottom',
      });
    };

    const onPointerOver = (e: PointerEvent) => {
      if (e.pointerType === 'touch') return;
      const target = (e.target as HTMLElement | null)?.closest('[data-tooltip]') as HTMLElement | null;
      if (target !== activeTarget) {
        showForElement(target);
      }
    };

    const onPointerOut = (e: PointerEvent) => {
      if (!activeTarget) return;
      const related = e.relatedTarget as HTMLElement | null;
      if (!related || !activeTarget.contains(related)) {
        const nextTipTarget = related?.closest('[data-tooltip]') as HTMLElement | null;
        showForElement(nextTipTarget);
      }
    };

    const hideAll = () => {
      activeTarget = null;
      setTip(null);
    };

    document.addEventListener('pointerover', onPointerOver, true);
    document.addEventListener('pointerout', onPointerOut, true);
    document.addEventListener('pointerdown', hideAll, true);
    window.addEventListener('scroll', hideAll, true);
    window.addEventListener('blur', hideAll);

    return () => {
      document.removeEventListener('pointerover', onPointerOver, true);
      document.removeEventListener('pointerout', onPointerOut, true);
      document.removeEventListener('pointerdown', hideAll, true);
      window.removeEventListener('scroll', hideAll, true);
      window.removeEventListener('blur', hideAll);
    };
  }, []);

  if (!tip) return null;

  return (
    <div
      role="tooltip"
      style={{
        left: `${tip.x}px`,
        top: `${tip.y}px`,
      }}
      className={`fixed z-[120] -translate-x-1/2 ${
        tip.placement === 'top' ? '-translate-y-full' : ''
      } px-2 py-1 text-[11px] font-medium text-white bg-slate-900/95 rounded-md shadow-md pointer-events-none whitespace-nowrap`}
    >
      {tip.text}
    </div>
  );
};
