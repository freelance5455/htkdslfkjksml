import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Sparkles, X, Tv, ExternalLink, ShieldCheck, ArrowRight, Play } from 'lucide-react';
import { AdReward, AdType, adManager } from '../services/adManager';

interface AdModalProps {
  type: AdType;
  reward: AdReward | null;
  onComplete: (success: boolean) => void;
}

export const AdModal: React.FC<AdModalProps> = ({ type, reward, onComplete }) => {
  const initialDuration = type === 'rewarded' ? 5 : type === 'app_open' ? 3 : 3;
  const [secondsRemaining, setSecondsRemaining] = useState(initialDuration);

  // Unit ID mapping based on ad type
  const unitId =
    type === 'app_open'
      ? adManager.config.appOpenUnitId
      : type === 'rewarded'
      ? adManager.config.rewardedUnitId
      : adManager.config.interstitialUnitId;

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [type]);

  const canClose = secondsRemaining === 0;

  const getAdTitle = () => {
    switch (type) {
      case 'app_open':
        return 'Google AdMob App Open';
      case 'interstitial':
        return 'Google AdMob Interstitial';
      case 'rewarded':
        return 'Google AdMob Rewarded Video';
    }
  };

  const getRewardLabel = () => {
    if (!reward) return null;
    if (reward.type === 'time_extension') return `+${reward.amount}s Time Extension`;
    if (reward.type === 'coins') return `+${reward.amount} Coins`;
    if (reward.type === 'hint') return `+${reward.amount} Free Hints`;
    if (reward.type === 'undo') return `+${reward.amount} Free Undos`;
    return `+${reward.amount} ${reward.type}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md select-none">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-6 flex flex-col items-center text-center text-white relative overflow-hidden"
      >
        {/* AdMob Test Unit Header */}
        <div className="w-full flex items-center justify-between text-[11px] text-slate-400 mb-3 pb-2 border-b border-slate-800">
          <div className="flex items-center gap-1.5">
            <span className="px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 font-black text-[9px] uppercase">
              Ad
            </span>
            <span className="font-mono text-[10px] text-slate-300">
              {getAdTitle()}
            </span>
          </div>

          <div className="flex items-center gap-1 text-sky-400 font-bold text-xs">
            {secondsRemaining > 0 ? (
              <span>{secondsRemaining}s</span>
            ) : (
              <span className="text-emerald-400 font-bold">Ready</span>
            )}
          </div>
        </div>

        {/* Video / Creative Showcase Canvas */}
        <div className="w-full aspect-video rounded-2xl bg-slate-950 border border-slate-800 flex flex-col items-center justify-center p-4 relative mb-4 shadow-inner overflow-hidden">
          {/* Animated sponsor background shimmer */}
          <div className="absolute inset-0 bg-gradient-to-tr from-sky-900/20 via-indigo-900/30 to-purple-900/20 pointer-events-none" />

          <div className="w-12 h-12 rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center mb-2 animate-pulse border border-sky-500/30 z-10">
            {type === 'rewarded' ? <Tv className="w-6 h-6" /> : <Play className="w-6 h-6 fill-current translate-x-0.5" />}
          </div>

          <span className="text-sm font-black text-slate-100 z-10">
            {type === 'app_open'
              ? 'Welcome to ArrowScape'
              : type === 'rewarded'
              ? 'Sponsor Video Ad'
              : 'Level Complete Intermission'}
          </span>
          <span className="text-[11px] text-slate-400 mt-0.5 z-10">
            Test AdMob Unit: <code className="text-sky-300 font-mono">{unitId.split('/')[1]}</code>
          </span>

          {secondsRemaining > 0 && (
            <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-black/70 border border-slate-700 text-[10px] font-bold text-amber-300">
              Ad ends in {secondsRemaining}s
            </div>
          )}
        </div>

        {/* Reward badge if Rewarded Ad */}
        {reward && (
          <div className="w-full px-4 py-2.5 rounded-2xl bg-amber-950/40 border border-amber-800/60 flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
            <span className="text-xs font-black text-amber-300 tracking-wide">
              REWARD: {getRewardLabel()}
            </span>
          </div>
        )}

        {/* Primary Action Button */}
        <button
          id="btn-ad-action"
          type="button"
          disabled={!canClose}
          onClick={() => onComplete(true)}
          className={`w-full h-12 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition active:scale-98 tracking-wide ${
            canClose
              ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/30 cursor-pointer hover:from-emerald-600 hover:to-teal-700'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
          }`}
        >
          {canClose ? (
            type === 'rewarded' ? (
              <>
                <span>COLLECT REWARD & RETURN</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : (
              <>
                <span>CONTINUE TO APP</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )
          ) : (
            <span>PLEASE WAIT ({secondsRemaining}s)</span>
          )}
        </button>

        {/* Optional Skip for Rewarded Ad without reward */}
        {type === 'rewarded' && secondsRemaining > 0 && (
          <button
            id="btn-ad-skip"
            type="button"
            onClick={() => onComplete(false)}
            className="mt-3 text-xs text-slate-500 hover:text-slate-400 underline"
          >
            Skip Ad (Forfeit Reward)
          </button>
        )}

        {/* Quick Skip for App Open after initial second */}
        {type === 'app_open' && secondsRemaining <= 1 && (
          <button
            type="button"
            onClick={() => onComplete(true)}
            className="mt-2 text-xs text-slate-400 hover:text-white"
          >
            Skip to Game
          </button>
        )}

        {/* Compliance Footer */}
        <div className="flex items-center gap-1 text-[9px] text-slate-500 mt-3">
          <ShieldCheck className="w-3 h-3 text-emerald-500" />
          <span>Google Mobile Ads SDK • AdMob Ready</span>
        </div>
      </motion.div>
    </div>
  );
};
