import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Wrench, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';

interface SplashViewProps {
  onFinalizar: () => void;
}

export const SplashView: React.FC<SplashViewProps> = ({ onFinalizar }) => {
  const [animacionCompletada, setAnimacionCompletada] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimacionCompletada(true);
    }, 2400);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-b from-slate-900 via-slate-950 to-black text-white p-6 overflow-hidden select-none">
      {/* Luces y ambiente de taller mecánico */}
      <div className="absolute top-0 inset-x-0 h-96 bg-radial from-amber-500/15 via-transparent to-transparent pointer-events-none" />
      <div className="absolute -top-32 -right-32 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Cabecera de marca */}
      <div className="w-full flex items-center justify-between pt-4 z-10">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800/80 border border-slate-700/60 backdrop-blur-md">
          <Wrench className="text-amber-400" size={16} />
          <span className="text-xs font-semibold tracking-wider text-slate-300 uppercase">Taller Mecánico</span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-amber-400/90 font-mono">
          <Sparkles size={14} />
          <span>v2.5 PRO</span>
        </div>
      </div>

      {/* Centro: Animación del coche */}
      <div className="w-full max-w-lg flex flex-col items-center my-auto relative z-10">
        <div className="relative w-full flex flex-col items-center">
          {/* Coche animado cruzando a la pantalla con entrada suave */}
          <motion.div
            initial={{ x: '-120%', opacity: 0, scale: 0.75 }}
            animate={{ x: 0, opacity: 1, scale: 1 }}
            transition={{
              type: 'spring',
              stiffness: 70,
              damping: 14,
              mass: 1.2,
              duration: 1.4,
            }}
            className="w-full max-w-sm px-4"
          >
            <div className="relative group">
              {/* Sombra realista bajo el coche */}
              <div className="absolute -bottom-3 inset-x-6 h-6 bg-black/60 rounded-full blur-md" />
              <img
                src="/carro.png"
                alt="Registro de Autos - Taller"
                className="w-full h-auto object-contain drop-shadow-[0_15px_25px_rgba(0,0,0,0.8)] filter brightness-105"
              />
            </div>
          </motion.div>

          {/* Línea de carretera animada */}
          <div className="w-full max-w-xs h-1 mt-2 bg-slate-800 rounded-full overflow-hidden relative">
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: '100%' }}
              transition={{ repeat: Infinity, duration: 1.2, ease: 'linear' }}
              className="w-1/3 h-full bg-amber-400"
            />
          </div>
        </div>

        {/* Textos principales */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.7 }}
          className="text-center mt-8 space-y-2 px-4"
        >
          <h1 className="text-3xl md:text-4xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            Registro de Autos
          </h1>
          <p className="text-sm md:text-base text-slate-400 max-w-xs mx-auto font-medium">
            Galería y cámara fotográfica para organización vehicular por carpetas
          </p>
        </motion.div>
      </div>

      {/* Pie y botón de entrada */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="w-full max-w-xs flex flex-col items-center gap-4 pb-4 z-10"
      >
        <button
          onClick={onFinalizar}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-base shadow-lg shadow-amber-500/25 active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>{animacionCompletada ? 'Comenzar Registro' : 'Entrar a la Galería'}</span>
          <ArrowRight size={18} />
        </button>

        <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
          <ShieldCheck size={14} className="text-emerald-400" />
          <span>Almacenamiento local privado seguro</span>
        </div>
      </motion.div>
    </div>
  );
};
