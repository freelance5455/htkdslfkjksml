import React from "react";
import {
  X,
  FileText,
  Download,
  Copy,
  Check,
  Binary,
  Image as ImageIcon,
  FileCode,
  Sparkles,
  Eye,
  Plus,
  Link,
  ExternalLink,
  ShieldCheck,
  Layers,
  Lock,
  Unlock,
  KeyRound,
  Youtube,
  AlertCircle,
  CheckCircle2,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  RefreshCw
} from "lucide-react";
import { Attachment } from "../types";
import { extractStringsAndLinks, carveEmbeddedData, ExtractedLink, CarvedAsset } from "../utils/universalParser";
import { isColorNoteFile, decryptColorNoteBackupApi, ColorNoteItem } from "../utils/colorNoteParser";
import { idbGetAttachment } from "../utils/idbStorage";

interface FileContentViewerModalProps {
  attachment: Attachment | null;
  onClose: () => void;
  onAppendToNote?: (textToAppend: string) => void;
}

export const FileContentViewerModal: React.FC<FileContentViewerModalProps> = ({
  attachment,
  onClose,
  onAppendToNote,
}) => {
  const [copied, setCopied] = React.useState(false);
  const [isExtractingOcr, setIsExtractingOcr] = React.useState(false);
  const [ocrText, setOcrText] = React.useState<string | null>(null);
  const [activeTab, setActiveTab] = React.useState<"content" | "hex" | "colornote" | "links" | "carved">("content");

  // Dynamically resolve data from attachment prop or IndexedDB if stripped for localStorage quota safety
  const [dataPayload, setDataPayload] = React.useState<string>(attachment?.data || "");

  React.useEffect(() => {
    if (attachment?.data) {
      setDataPayload(attachment.data);
    } else if (attachment?.id) {
      idbGetAttachment(attachment.id).then((saved) => {
        if (saved?.data) {
          setDataPayload(saved.data);
        }
      });
    }
  }, [attachment]);

  // ColorNote state
  const [cnPassword, setCnPassword] = React.useState<string>("0000");
  const [isCnDecrypting, setIsCnDecrypting] = React.useState<boolean>(false);
  const [cnNotes, setCnNotes] = React.useState<ColorNoteItem[]>([]);
  const [cnError, setCnError] = React.useState<string | null>(null);
  const [cnSuccess, setCnSuccess] = React.useState<string | null>(null);
  const [showCnFallbackGuide, setShowCnFallbackGuide] = React.useState<boolean>(false);

  if (!attachment) return null;

  const fileName = attachment.name || "Dosya";
  const fileExt = fileName.split(".").pop()?.toLowerCase() || "";
  const mime = attachment.mime || "";

  const isImage = mime.startsWith("image/") || ["png", "jpg", "jpeg", "gif", "webp", "svg", "bmp"].includes(fileExt);
  const isAudio = mime.startsWith("audio/") || ["mp3", "wav", "ogg", "m4a"].includes(fileExt);
  const isVideo = mime.startsWith("video/") || ["mp4", "webm", "mkv"].includes(fileExt);
  const isPdf = mime.includes("pdf") || fileExt === "pdf";
  const isBin = fileExt === "bin" || fileExt === "dat" || mime === "application/octet-stream";

  // ColorNote Detection
  const isColorNote = React.useMemo(() => {
    if (!attachment) return false;
    if (isColorNoteFile(null, fileName)) return true;
    if (mime === "application/x-colornote-backup") return true;
    if (dataPayload) {
      try {
        const base64Str = dataPayload.includes(";base64,") ? dataPayload.split(";base64,")[1] : dataPayload;
        const binaryPrefix = atob(base64Str.slice(0, 48));
        if (binaryPrefix.slice(0, 4) === "NOTE" || binaryPrefix.includes("NOTE")) return true;
      } catch {}
    }
    return false;
  }, [attachment, fileName, mime, dataPayload]);

  // ColorNote Decryption Handler
  const handleDecryptColorNote = async (pwdToUse?: string) => {
    if (!dataPayload) return;
    const pwd = pwdToUse !== undefined ? pwdToUse : cnPassword;
    setIsCnDecrypting(true);
    setCnError(null);
    setCnSuccess(null);

    try {
      const res = await decryptColorNoteBackupApi(dataPayload, pwd);
      if (res.success && res.notes && res.notes.length > 0) {
        setCnNotes(res.notes);
        setCnSuccess(`✓ ${res.notes.length} adet ColorNote notu başarıyla çözüldü!`);
        setActiveTab("colornote");
      } else {
        setCnError(res.message || "Şifre çözülemedi. ColorNote master şifrenizi kontrol ediniz.");
        setShowCnFallbackGuide(true);
      }
    } catch (err: any) {
      setCnError(err.message || "Bağlantı hatası oluştu.");
      setShowCnFallbackGuide(true);
    } finally {
      setIsCnDecrypting(false);
    }
  };

  // Attempt automatic decryption with default "0000" if ColorNote detected
  React.useEffect(() => {
    if (isColorNote && dataPayload && cnNotes.length === 0) {
      handleDecryptColorNote("0000");
    }
  }, [isColorNote, dataPayload]);

  // Base64 helper decoding
  const getDecodedText = (): string => {
    try {
      if (!dataPayload) return "";
      const base64Str = dataPayload.includes(";base64,")
        ? dataPayload.split(";base64,")[1]
        : dataPayload;
      const binaryStr = atob(base64Str);
      const bytes = new Uint8Array(binaryStr.length);
      for (let i = 0; i < binaryStr.length; i++) {
        bytes[i] = binaryStr.charCodeAt(i);
      }
      const decoder = new TextDecoder("utf-8");
      return decoder.decode(bytes);
    } catch {
      return "Dosya metin olarak ayrıştırılamadı (İkili / Binary veri).";
    }
  };

  // Hex representation generator for BIN files
  const getHexDump = (): { offset: string; hex: string; ascii: string }[] => {
    try {
      if (!dataPayload) return [];
      const base64Str = dataPayload.includes(";base64,")
        ? dataPayload.split(";base64,")[1]
        : dataPayload;
      const binaryStr = atob(base64Str);
      const rows: { offset: string; hex: string; ascii: string }[] = [];
      const maxBytes = Math.min(binaryStr.length, 1024); // Show first 1KB

      for (let i = 0; i < maxBytes; i += 16) {
        const chunk = binaryStr.slice(i, i + 16);
        const hexArr: string[] = [];
        let asciiStr = "";

        for (let j = 0; j < chunk.length; j++) {
          const code = chunk.charCodeAt(j);
          hexArr.push(code.toString(16).padStart(2, "0").toUpperCase());
          asciiStr += code >= 32 && code <= 126 ? chunk[j] : ".";
        }

        const offsetStr = i.toString(16).padStart(6, "0").toUpperCase();
        rows.push({
          offset: offsetStr,
          hex: hexArr.join(" ").padEnd(47, " "),
          ascii: asciiStr,
        });
      }

      return rows;
    } catch {
      return [];
    }
  };

  const { extractedStrings, extractedLinks, carvedImages } = React.useMemo(() => {
    if (!dataPayload) return { extractedStrings: [], extractedLinks: [], carvedImages: [] };
    try {
      const base64Str = dataPayload.includes(";base64,")
        ? dataPayload.split(";base64,")[1]
        : dataPayload;
      const binaryStr = atob(base64Str);
      const bytes = new Uint8Array(binaryStr.length);
      for (let i = 0; i < binaryStr.length; i++) {
        bytes[i] = binaryStr.charCodeAt(i);
      }
      const { strings, links } = extractStringsAndLinks(bytes);
      const carved = carveEmbeddedData(bytes);
      return { extractedStrings: strings, extractedLinks: links, carvedImages: carved };
    } catch {
      return { extractedStrings: [], extractedLinks: [], carvedImages: [] };
    }
  }, [dataPayload]);

  const textContent = getDecodedText();
  const hexRows = getHexDump();

  // Run OCR if image
  const handleRunOcr = async () => {
    if (!isImage || !dataPayload) return;
    setIsExtractingOcr(true);
    setOcrText(null);

    try {
      const response = await fetch("/api/gemini/ocr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: dataPayload,
          mimeType: attachment.mime,
        }),
      });

      const resData = await response.json();
      if (resData.text) {
        setOcrText(resData.text);
      } else {
        setOcrText("Görselde herhangi bir okunan metin bulunamadı.");
      }
    } catch (err) {
      setOcrText("Görsel okunurken bir hata oluştu.");
    } finally {
      setIsExtractingOcr(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl max-h-[90vh] flex flex-col bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2.5 rounded-2xl bg-teal-50 dark:bg-teal-950/80 text-teal-600 dark:text-teal-400 border border-teal-200 dark:border-teal-800 shrink-0">
              {isImage ? (
                <ImageIcon className="w-5 h-5" />
              ) : isBin ? (
                <Binary className="w-5 h-5 text-amber-500" />
              ) : (
                <FileText className="w-5 h-5" />
              )}
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                {fileName}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <span>{formatFileSize(attachment.size)}</span>
                <span>•</span>
                <span className="uppercase font-mono font-semibold">{fileExt || "DOSYA"}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={dataPayload || attachment.data}
              download={fileName}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors"
              title="Dosyayı İndir"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">İndir</span>
            </a>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Binary / BIN file view toggle */}
        {(isBin || isColorNote || extractedLinks.length > 0 || carvedImages.length > 0) && (
          <div className="flex items-center gap-1.5 px-5 py-2 bg-slate-100/70 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-xs font-bold overflow-x-auto">
            <button
              onClick={() => setActiveTab("content")}
              className={`px-3 py-1 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === "content"
                  ? "bg-teal-600 text-white shadow-sm"
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              Metin / ASCII Görünümü
            </button>
            {(isColorNote || isBin) && (
              <button
                onClick={() => setActiveTab("colornote")}
                className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                  activeTab === "colornote"
                    ? "bg-amber-600 text-white shadow-sm"
                    : "text-amber-700 dark:text-amber-300 bg-amber-100/70 dark:bg-amber-950/40 hover:bg-amber-200 dark:hover:bg-amber-900"
                }`}
              >
                <Unlock className="w-3.5 h-3.5" />
                <span>ColorNote Çözücü {cnNotes.length > 0 ? `(${cnNotes.length})` : ""}</span>
              </button>
            )}
            {isBin && (
              <button
                onClick={() => setActiveTab("hex")}
                className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                  activeTab === "hex"
                    ? "bg-slate-700 text-white shadow-sm"
                    : "text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                }`}
              >
                <Binary className="w-3.5 h-3.5" />
                <span>Hex / İkili Döküm</span>
              </button>
            )}
            {extractedLinks.length > 0 && (
              <button
                onClick={() => setActiveTab("links")}
                className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                  activeTab === "links"
                    ? "bg-blue-600 text-white shadow-sm"
                    : "text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                }`}
              >
                <Link className="w-3.5 h-3.5" />
                <span>Bağlantılar ({extractedLinks.length})</span>
              </button>
            )}
            {carvedImages.length > 0 && (
              <button
                onClick={() => setActiveTab("carved")}
                className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                  activeTab === "carved"
                    ? "bg-rose-600 text-white shadow-sm"
                    : "text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Gömülü Medyalar ({carvedImages.length})</span>
              </button>
            )}
          </div>
        )}

        {/* Content Viewer Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* IMAGE PREVIEW */}
          {isImage && (
            <div className="flex flex-col items-center gap-4">
              <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 max-h-[50vh] overflow-hidden flex items-center justify-center">
                <img
                  src={dataPayload || attachment.data}
                  alt={fileName}
                  className="max-h-[45vh] w-auto object-contain rounded-xl"
                />
              </div>

              {/* OCR Extractor Button */}
              <div className="w-full flex flex-col items-center gap-2">
                <button
                  onClick={handleRunOcr}
                  disabled={isExtractingOcr}
                  className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white rounded-2xl text-xs font-extrabold shadow-md active:scale-95 transition-all disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4 animate-spin-slow" />
                  <span>{isExtractingOcr ? "Görsel Metni Okunuyor (OCR)..." : "Görseldeki Yazıyı Oku & Nota Ekle (OCR)"}</span>
                </button>

                {ocrText && (
                  <div className="w-full mt-3 p-4 bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-2xl">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-extrabold text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5" /> Tespit Edilen Metin:
                      </span>
                      {onAppendToNote && (
                        <button
                          onClick={() => {
                            onAppendToNote(`\n\n📷 **Görsel Metni (${fileName}):**\n${ocrText}`);
                            onClose();
                          }}
                          className="flex items-center gap-1 px-3 py-1 bg-teal-600 text-white rounded-xl text-xs font-bold hover:bg-teal-500"
                        >
                          <Plus className="w-3.5 h-3.5" /> Nota Ekle
                        </button>
                      )}
                    </div>
                    <p className="text-xs font-mono text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed select-all">
                      {ocrText}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* AUDIO PREVIEW */}
          {isAudio && (
            <div className="p-6 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col items-center gap-3">
              <audio controls src={dataPayload || attachment.data} className="w-full max-w-md" />
            </div>
          )}

          {/* VIDEO PREVIEW */}
          {isVideo && (
            <div className="p-2 bg-black rounded-2xl overflow-hidden flex items-center justify-center">
              <video controls src={dataPayload || attachment.data} className="max-h-[50vh] w-full" />
            </div>
          )}

          {/* PDF PREVIEW */}
          {isPdf && (
            <div className="h-[60vh] rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700">
              <iframe src={dataPayload || attachment.data} className="w-full h-full" title={fileName} />
            </div>
          )}

          {/* HEX DUMP VIEW FOR BIN FILES */}
          {activeTab === "hex" && (
            <div className="font-mono text-xs bg-slate-950 text-emerald-400 p-4 rounded-2xl overflow-x-auto max-h-[55vh] border border-slate-800 space-y-1">
              <div className="text-slate-500 pb-2 border-b border-slate-800 flex justify-between font-bold">
                <span>OFFSET  00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F</span>
                <span>ASCII DÖKÜM</span>
              </div>
              {hexRows.map((row, idx) => (
                <div key={idx} className="flex justify-between gap-4 hover:bg-slate-900/80 px-1 py-0.5 rounded">
                  <span className="text-slate-400 shrink-0">{row.offset}:</span>
                  <span className="text-amber-300 font-bold shrink-0">{row.hex}</span>
                  <span className="text-emerald-300 shrink-0">{row.ascii}</span>
                </div>
              ))}
            </div>
          )}

          {/* LINKS VIEW */}
          {(activeTab as string) === "links" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                  Dosyadan Çıkarılan Tıklanabilir Bağlantı Kartları ({extractedLinks.length}):
                </span>
                {onAppendToNote && (
                  <button
                    onClick={() => {
                      const linkText = extractedLinks.map((l) => `• [${l.domain}](${l.url})`).join("\n");
                      onAppendToNote(`\n\n🔗 **${fileName} Bağlantıları:**\n${linkText}`);
                      onClose();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Nota Ekle</span>
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto p-1">
                {extractedLinks.map((link, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col justify-between gap-2 shadow-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 uppercase">
                        {link.type}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400 truncate max-w-[120px]">
                        {link.domain}
                      </span>
                    </div>
                    <a
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline break-all flex items-center gap-1"
                    >
                      <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{link.url}</span>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CARVED IMAGES VIEW */}
          {(activeTab as string) === "carved" && (
            <div className="space-y-3">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                Gömülü Ayrıştırılan Medyalar & Görseller ({carvedImages.length}):
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[50vh] overflow-y-auto p-1">
                {carvedImages.map((carved) => (
                  <div
                    key={carved.id}
                    className="p-2 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col items-center gap-2"
                  >
                    <img
                      src={carved.dataUrl}
                      alt={carved.name}
                      className="h-28 w-auto object-contain rounded-xl"
                    />
                    <div className="w-full text-center">
                      <span className="block text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate">
                        {carved.name}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {(carved.size / 1024).toFixed(1)} KB
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* COLORNOTE DECRYPTOR VIEW */}
          {activeTab === "colornote" && (
            <div className="space-y-4">
              {/* Info banner */}
              <div className="p-4 rounded-2xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300 flex items-center justify-center font-bold text-lg shrink-0">
                    📝
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-amber-950 dark:text-amber-200">
                      ColorNote AES-128 Şifreli Yedekleme Ayrıştırıcı
                    </h4>
                    <p className="text-[11px] text-amber-800/80 dark:text-amber-300/80 mt-0.5">
                      ColorNote yedek dosyaları (.bin) AES-128 şifrelemesi ile korunur. Varsayılan parola <span className="font-mono font-bold">0000</span>'dır.
                    </p>
                  </div>
                </div>

                <div className="shrink-0">
                  {cnNotes.length > 0 ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      <Unlock className="w-3.5 h-3.5" /> Çözüldü ({cnNotes.length})
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-xl bg-amber-200 text-amber-900 dark:bg-amber-900 dark:text-amber-200">
                      <Lock className="w-3.5 h-3.5" /> Şifreli
                    </span>
                  )}
                </div>
              </div>

              {/* Password Bar */}
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-amber-500" />
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Master Parola:
                  </span>
                  <input
                    type="password"
                    value={cnPassword}
                    onChange={(e) => setCnPassword(e.target.value)}
                    placeholder="0000"
                    className="w-28 text-xs font-mono px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                  />
                  <button
                    onClick={() => handleDecryptColorNote()}
                    disabled={isCnDecrypting}
                    className="flex items-center gap-1.5 px-3 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition-all disabled:opacity-50"
                  >
                    {isCnDecrypting ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Çözülüyor...</span>
                      </>
                    ) : (
                      <>
                        <Unlock className="w-3.5 h-3.5" />
                        <span>Şifreyi Çöz</span>
                      </>
                    )}
                  </button>
                </div>

                {cnNotes.length > 0 && onAppendToNote && (
                  <button
                    onClick={() => {
                      const allText = cnNotes
                        .map((n, i) => {
                          let body = `### ${i + 1}. ${n.title} [${n.colorName}]\n${n.content}`;
                          if (n.links && n.links.length > 0) {
                            body += `\n**Bağlantılar:**\n` + n.links.map((l) => `• [${l.domain}](${l.url})`).join("\n");
                          }
                          return body;
                        })
                        .join("\n\n---\n\n");
                      onAppendToNote(`\n\n📁 **ColorNote Çözülen Notlar (${cnNotes.length} Not):**\n\n${allText}`);
                      onClose();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-xs transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Tüm Notları Bu Nota Ekle ({cnNotes.length})</span>
                  </button>
                )}
              </div>

              {/* Status messages */}
              {cnError && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-500" />
                  <div>
                    <strong className="block">Şifre Çözme Hatası:</strong>
                    {cnError}
                  </div>
                </div>
              )}

              {cnSuccess && (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-500" />
                  <span className="font-bold">{cnSuccess}</span>
                </div>
              )}

              {/* Decrypted Notes Cards Grid */}
              {cnNotes.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto p-1">
                  {cnNotes.map((note, idx) => (
                    <div
                      key={note.id || idx}
                      className="p-3.5 rounded-2xl bg-white dark:bg-slate-850/80 border border-slate-200 dark:border-slate-700 flex flex-col justify-between gap-2 shadow-xs"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {note.title}
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-semibold">
                            {note.colorName}
                          </span>
                        </div>

                        <div className="text-[11px] text-slate-600 dark:text-slate-300 whitespace-pre-wrap line-clamp-4 font-sans">
                          {note.content || "(Boş not)"}
                        </div>

                        {/* YouTube / Web Links */}
                        {note.links && note.links.length > 0 && (
                          <div className="mt-2 space-y-1">
                            {note.links.map((link, lIdx) => (
                              <div
                                key={lIdx}
                                className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 text-[10px] flex items-center gap-1.5"
                              >
                                {link.isYouTube ? (
                                  <Youtube className="w-3.5 h-3.5 text-red-500 shrink-0" />
                                ) : (
                                  <ExternalLink className="w-3 h-3 text-blue-500 shrink-0" />
                                )}
                                <a
                                  href={link.url}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="truncate text-blue-600 dark:text-blue-400 hover:underline"
                                >
                                  {link.url}
                                </a>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
                        <span>{new Date(note.createdDate).toLocaleDateString("tr-TR")}</span>
                        {onAppendToNote && (
                          <button
                            onClick={() => {
                              onAppendToNote(`\n\n📌 **${note.title}:**\n${note.content}`);
                              onClose();
                            }}
                            className="text-teal-600 dark:text-teal-400 font-bold hover:underline"
                          >
                            Bu Notu Ekle +
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Fallback Accordion Guide */}
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-50/50 dark:bg-slate-800/30">
                <button
                  onClick={() => setShowCnFallbackGuide(!showCnFallbackGuide)}
                  className="w-full p-2.5 flex items-center justify-between text-left text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <HelpCircle className="w-3.5 h-3.5 text-amber-500" />
                    <span>Şifre çözülemezse ne yapılmalı? (ColorNote Export As Text Rehberi)</span>
                  </div>
                  {showCnFallbackGuide ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>

                {showCnFallbackGuide && (
                  <div className="p-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-400 space-y-1.5 bg-white dark:bg-slate-900">
                    <p>ColorNote uygulamasında şifresiz aktarım yapmak için:</p>
                    <ol className="list-decimal list-inside space-y-1">
                      <li>ColorNote uygulamasını açıp <strong>Ayarlar &gt; Yedekleme</strong> yolunu izleyin.</li>
                      <li>Notları <strong>"Metin Olarak Dışa Aktar"</strong> (Export as Text) seçeneği ile kaydedin.</li>
                      <li>Kaydedilen <code>.txt</code> dosyasını doğrudan uygulamamıza yükleyin.</li>
                    </ol>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TEXT / CODE / GENERAL CONTENT VIEW */}
          {(!isImage && !isAudio && !isVideo && !isPdf && (!isBin || activeTab === "content")) && (
            <div className="space-y-3">
              {/* If ColorNote detected and in content view, show a direct callout button */}
              {isColorNote && cnNotes.length === 0 && (
                <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-xs text-amber-900 dark:text-amber-200">
                    <Unlock className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Bu dosya ColorNote AES-128 şifreli yedeğidir. Anlamsız karakterler yerine notları açmak ister misiniz?</span>
                  </div>
                  <button
                    onClick={() => setActiveTab("colornote")}
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold shrink-0 shadow-xs"
                  >
                    ColorNote Şifresini Çöz
                  </button>
                </div>
              )}

              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                  Dosya İçerik Önizlemesi ({fileName}):
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(textContent)}
                    className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? "Kopyalandı" : "Metni Kopyala"}</span>
                  </button>

                  {onAppendToNote && (
                    <button
                      onClick={() => {
                        onAppendToNote(`\n\n📄 **${fileName} Dosya İçeriği:**\n\`\`\`\n${textContent}\n\`\`\``);
                        onClose();
                      }}
                      className="flex items-center gap-1.5 px-3 py-1 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Nota Ekle</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-2xl max-h-[50vh] overflow-y-auto">
                <pre className="text-xs font-mono text-slate-800 dark:text-slate-200 whitespace-pre-wrap break-words leading-relaxed">
                  {textContent || "İçerik boş veya okunamadı."}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80 flex items-center justify-between">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Tüm dosya türleri Notlar bölümünde açılabilir ve düzenlenebilir.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-xl text-xs font-bold transition-colors"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
};
