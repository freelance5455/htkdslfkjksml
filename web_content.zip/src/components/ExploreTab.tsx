import React, { useState } from 'react';
import { Search, Heart, MessageSquare, Sparkles, Filter } from 'lucide-react';
import { Character, GenderTag } from '../types';

interface ExploreTabProps {
  characters: Character[];
  onSelectCharacter: (char: Character) => void;
  onToggleLike: (id: string) => void;
}

export const ExploreTab: React.FC<ExploreTabProps> = ({
  characters,
  onSelectCharacter,
  onToggleLike,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<GenderTag>('Female');

  const categories: { key: GenderTag; label: string }[] = [
    { key: 'Female', label: 'Female' },
    { key: 'Male', label: 'Male' },
    { key: 'OC', label: 'OC' },
    { key: 'المجموعات', label: 'المجموعات' },
    { key: 'موصى به', label: 'موصى به' },
    { key: 'الكل', label: 'الكل' },
  ];

  const filteredCharacters = characters.filter((char) => {
    const matchesSearch =
      char.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (char.nameAr && char.nameAr.includes(searchQuery)) ||
      char.description.toLowerCase().includes(searchQuery.toLowerCase());

    if (selectedCategory === 'الكل') return matchesSearch;
    if (selectedCategory === 'موصى به') return matchesSearch;
    if (selectedCategory === 'المجموعات') return matchesSearch && char.category === 'Group';

    return matchesSearch && char.category === selectedCategory;
  });

  return (
    <div className="pb-24 pt-2 px-4 max-w-lg mx-auto">
      {/* Search Input matching Screenshot 1 */}
      <div className="relative mb-4">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="بحث..."
          className="w-full bg-slate-800/90 border border-slate-700/80 rounded-2xl py-3 pl-4 pr-11 text-white text-sm placeholder-slate-400 focus:outline-none focus:border-pink-500 focus:ring-1 focus:ring-pink-500 transition-all text-right dir-rtl shadow-inner"
        />
        <Search className="w-5 h-5 text-slate-400 absolute right-3.5 top-3.5 pointer-events-none" />
      </div>

      {/* Category Filter Pills Horizontal Scroll */}
      <div className="flex items-center space-x-2 space-x-reverse overflow-x-auto no-scrollbar mb-5 py-1">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.key;
          return (
            <button
              key={cat.key}
              onClick={() => setSelectedCategory(cat.key)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all shadow-sm ${
                isSelected
                  ? 'bg-slate-100 text-slate-900 border border-white font-bold shadow-pink-500/10'
                  : 'bg-slate-800/80 text-slate-300 border border-slate-700/60 hover:bg-slate-700/80'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Characters Cards Grid - 2 Column Layout matching Screenshots */}
      <div className="grid grid-cols-2 gap-3.5">
        {filteredCharacters.map((char) => (
          <div
            key={char.id}
            onClick={() => onSelectCharacter(char)}
            className="group relative bg-slate-800/90 border border-slate-700/70 rounded-2xl overflow-hidden hover:border-pink-500/50 transition-all cursor-pointer shadow-lg hover:shadow-pink-500/10 flex flex-col justify-between"
          >
            {/* Top Image Banner */}
            <div className="relative aspect-[4/4.5] w-full overflow-hidden bg-slate-900">
              <img
                src={char.avatar}
                alt={char.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

              {/* Private Tag badge if private */}
              {char.isPrivate && (
                <span className="absolute top-2 left-2 bg-pink-600/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-full border border-pink-400/30 backdrop-blur-sm">
                  خاص
                </span>
              )}
            </div>

            {/* Character Info Card Body */}
            <div className="p-3 flex flex-col justify-between flex-1">
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-pink-300 transition-colors line-clamp-1">
                  {char.nameAr || char.name}
                </h3>
                <p className="text-[11px] text-slate-300 mt-1 line-clamp-2 leading-relaxed">
                  {char.description}
                </p>
              </div>

              {/* Card Footer Metrics matching Screenshot 1 (e.g. 116 ❤️ 366.9K 💬) */}
              <div className="flex items-center justify-between text-slate-400 text-[11px] mt-3 pt-2 border-t border-slate-700/40">
                <div className="flex items-center space-x-1 space-x-reverse">
                  <span className="font-semibold text-slate-200">{char.likesCount}</span>
                  <Heart
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleLike(char.id);
                    }}
                    className="w-3.5 h-3.5 text-pink-500 fill-pink-500/80 hover:scale-125 transition-transform"
                  />
                </div>

                <div className="flex items-center space-x-1 space-x-reverse">
                  <span className="font-semibold text-slate-200">{char.chatsCount}</span>
                  <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredCharacters.length === 0 && (
        <div className="text-center py-12 px-4">
          <Sparkles className="w-10 h-10 text-pink-400/50 mx-auto mb-3 animate-bounce" />
          <p className="text-slate-300 font-medium text-sm">
            لا توجد شخصيات مطابقة للبحث حالياً
          </p>
          <p className="text-slate-400 text-xs mt-1">
            جرب البحث عن اسم آخر أو استخدم زر الإضافة لإنشاء شخصيتك الخاصة!
          </p>
        </div>
      )}
    </div>
  );
};
