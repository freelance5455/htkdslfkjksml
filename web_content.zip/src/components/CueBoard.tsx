import React, { useState } from 'react';
import { Disc, Flame, Volume2, Zap, Radio, Sliders, Play, Pause } from 'lucide-react';
import { audioCues } from '../utils/audioCueEngine';

export const CueBoard: React.FC = () => {
  const [activeCue, setActiveCue] = useState<string | null>(null);
  const [jogRotation, setJogRotation] = useState(0);
  const [isBeatActive, setIsBeatActive] = useState(false);

  const triggerCue = (cueName: string, action: () => void) => {
    setActiveCue(cueName);
    action();
    setTimeout(() => {
      setActiveCue((prev) => (prev === cueName ? null : prev));
    }, 400);
  };

  const handleJogScratch = () => {
    setJogRotation((prev) => prev + 45);
    triggerCue('SCRATCH', () => audioCues.playScratch());
  };

  const handleToggleBeat = () => {
    const active = audioCues.toggleAfrobeatLoop((status) => {
      setIsBeatActive(status);
    });
    setIsBeatActive(active);
  };

  return (
    <section className="py-12 px-4 max-w-5xl mx-auto">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-widest bg-cyan-950/50 px-3 py-1 rounded-full border border-cyan-800/40 mb-2">
          <Zap className="w-3.5 h-3.5 text-yellow-400" />
          Interactive Cross DJ Pro Deck
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">
          Test "The Cue King" Live Soundboard
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-lg mx-auto mt-1">
          Tap the hot cue pads below to feel the exact party transitions DJ Evan Pro UG drops on TikTok LIVE and Kampala dancefloors!
        </p>
      </div>

      {/* Virtual Cross DJ Console */}
      <div className="bg-[#0e0a1a] border-2 border-purple-500/40 rounded-2xl p-4 sm:p-6 shadow-[0_0_40px_rgba(147,51,234,0.2)]">
        {/* Top Deck Info Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-5 border-b border-purple-900/40 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-mono font-bold text-white tracking-wider">DECK A: KAMPALA BANGERZ</span>
            <span className="text-purple-400 font-mono">114.0 BPM</span>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <span className="text-slate-400 font-mono">PITCH:</span>
              <span className="text-cyan-400 font-mono font-bold">+1.8%</span>
            </div>
            <button
              onClick={handleToggleBeat}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold border transition-colors ${
                isBeatActive
                  ? 'bg-rose-600 text-white border-rose-400'
                  : 'bg-purple-900/60 text-purple-200 border-purple-600 hover:bg-purple-800'
              }`}
            >
              {isBeatActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isBeatActive ? 'STOP BACKGROUND BEAT' : 'START LIVE BEAT'}</span>
            </button>
          </div>
        </div>

        {/* Center Grid: Jog Wheel + Hot Cue Pads */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          {/* Turntable Jog Wheel */}
          <div className="md:col-span-5 flex flex-col items-center justify-center p-3 bg-black/60 rounded-xl border border-purple-900/50">
            <p className="text-[11px] font-mono text-purple-300 uppercase tracking-widest mb-3 flex items-center gap-1">
              <Disc className="w-3.5 h-3.5 text-cyan-400" />
              Touch / Click Platter to Scratch
            </p>

            <button
              onClick={handleJogScratch}
              className="relative w-44 h-44 sm:w-52 sm:h-52 rounded-full bg-gradient-to-tr from-slate-950 via-purple-950 to-slate-900 border-4 border-purple-600/60 shadow-2xl flex items-center justify-center cursor-pointer active:scale-95 transition-transform group overflow-hidden"
              style={{
                transform: `rotate(${jogRotation}deg)`,
                transition: 'transform 0.15s ease-out',
              }}
              title="Click or drag to scratch like DJ Evan Pro!"
            >
              {/* Vinyl Grooves */}
              <div className="absolute inset-2 rounded-full border border-purple-800/40 opacity-70 pointer-events-none" />
              <div className="absolute inset-5 rounded-full border border-purple-700/30 opacity-60 pointer-events-none" />
              <div className="absolute inset-8 rounded-full border border-purple-600/30 opacity-50 pointer-events-none" />
              <div className="absolute inset-12 rounded-full border border-cyan-500/20 opacity-40 pointer-events-none" />

              {/* Center Vinyl Label */}
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-600 via-pink-600 to-cyan-500 flex flex-col items-center justify-center text-center p-1 text-white shadow-lg pointer-events-none">
                <span className="text-[9px] font-black tracking-tighter">CROSS DJ</span>
                <span className="text-[8px] font-bold text-yellow-300">CUE KING</span>
                <div className="w-3 h-3 rounded-full bg-black border border-white mt-0.5" />
              </div>

              {/* Vinyl Marker Needle Indicator */}
              <div className="absolute top-2 w-1.5 h-6 bg-cyan-400 rounded-full shadow-[0_0_8px_#06b6d4]" />
            </button>

            <div className="flex items-center gap-2 mt-3 text-[11px] text-slate-400">
              <span className="text-yellow-400 font-bold">WIKKA-WIKKA!</span>
              <span>Tap disc for instant cue scratch</span>
            </div>
          </div>

          {/* 6 Hot Cue Performance Pads */}
          <div className="md:col-span-7">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono font-bold text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-purple-400" />
                HOT CUE PERFORMANCE PADS
              </span>
              <span className="text-[11px] text-emerald-400 font-mono">100% REALTIME AUDIO</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {/* Cue 1: Air Horn */}
              <button
                onClick={() => triggerCue('AIRHORN', () => audioCues.playAirHorn())}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between h-24 transition-all active:scale-95 ${
                  activeCue === 'AIRHORN'
                    ? 'bg-amber-500 border-amber-300 text-black shadow-[0_0_20px_#f59e0b]'
                    : 'bg-purple-950/40 border-purple-500/40 text-purple-200 hover:bg-purple-900/50 hover:border-purple-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold bg-amber-400/20 text-amber-300 px-1.5 py-0.5 rounded">
                    CUE 1
                  </span>
                  <Volume2 className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <div className="text-sm font-black uppercase tracking-tight">Air Horn</div>
                  <div className="text-[10px] opacity-75">Reggae Dancehall Blast</div>
                </div>
              </button>

              {/* Cue 2: Stutter Scratch */}
              <button
                onClick={() => triggerCue('SCRATCH', () => audioCues.playScratch())}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between h-24 transition-all active:scale-95 ${
                  activeCue === 'SCRATCH'
                    ? 'bg-cyan-500 border-cyan-300 text-black shadow-[0_0_20px_#06b6d4]'
                    : 'bg-purple-950/40 border-purple-500/40 text-purple-200 hover:bg-purple-900/50 hover:border-purple-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold bg-cyan-400/20 text-cyan-300 px-1.5 py-0.5 rounded">
                    CUE 2
                  </span>
                  <Disc className="w-4 h-4 text-cyan-400" />
                </div>
                <div>
                  <div className="text-sm font-black uppercase tracking-tight">Cross Scratch</div>
                  <div className="text-[10px] opacity-75">Precision Stutter</div>
                </div>
              </button>

              {/* Cue 3: 808 Sub Drop */}
              <button
                onClick={() => triggerCue('808', () => audioCues.play808Drop())}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between h-24 transition-all active:scale-95 ${
                  activeCue === '808'
                    ? 'bg-purple-500 border-purple-300 text-white shadow-[0_0_20px_#a855f7]'
                    : 'bg-purple-950/40 border-purple-500/40 text-purple-200 hover:bg-purple-900/50 hover:border-purple-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold bg-purple-400/20 text-purple-300 px-1.5 py-0.5 rounded">
                    CUE 3
                  </span>
                  <Flame className="w-4 h-4 text-purple-400" />
                </div>
                <div>
                  <div className="text-sm font-black uppercase tracking-tight">808 Sub Drop</div>
                  <div className="text-[10px] opacity-75">Chest-Shaking Bass</div>
                </div>
              </button>

              {/* Cue 4: Kampala Siren */}
              <button
                onClick={() => triggerCue('SIREN', () => audioCues.playSiren())}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between h-24 transition-all active:scale-95 ${
                  activeCue === 'SIREN'
                    ? 'bg-rose-500 border-rose-300 text-white shadow-[0_0_20px_#f43f5e]'
                    : 'bg-purple-950/40 border-purple-500/40 text-purple-200 hover:bg-purple-900/50 hover:border-purple-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold bg-rose-400/20 text-rose-300 px-1.5 py-0.5 rounded">
                    CUE 4
                  </span>
                  <Radio className="w-4 h-4 text-rose-400" />
                </div>
                <div>
                  <div className="text-sm font-black uppercase tracking-tight">Club Siren</div>
                  <div className="text-[10px] opacity-75">Kampala Rave Alarm</div>
                </div>
              </button>

              {/* Cue 5: Laser Zap */}
              <button
                onClick={() => triggerCue('LASER', () => audioCues.playLaser())}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between h-24 transition-all active:scale-95 ${
                  activeCue === 'LASER'
                    ? 'bg-yellow-400 border-yellow-200 text-black shadow-[0_0_20px_#facc15]'
                    : 'bg-purple-950/40 border-purple-500/40 text-purple-200 hover:bg-purple-900/50 hover:border-purple-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold bg-yellow-400/20 text-yellow-300 px-1.5 py-0.5 rounded">
                    CUE 5
                  </span>
                  <Zap className="w-4 h-4 text-yellow-400" />
                </div>
                <div>
                  <div className="text-sm font-black uppercase tracking-tight">Laser Shot</div>
                  <div className="text-[10px] opacity-75">DJ Gunshot Drop</div>
                </div>
              </button>

              {/* Cue 6: Rewind / Wheel Up */}
              <button
                onClick={() => triggerCue('REWIND', () => audioCues.playRewind())}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between h-24 transition-all active:scale-95 ${
                  activeCue === 'REWIND'
                    ? 'bg-emerald-500 border-emerald-300 text-white shadow-[0_0_20px_#10b981]'
                    : 'bg-purple-950/40 border-purple-500/40 text-purple-200 hover:bg-purple-900/50 hover:border-purple-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold bg-emerald-400/20 text-emerald-300 px-1.5 py-0.5 rounded">
                    CUE 6
                  </span>
                  <Sliders className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <div className="text-sm font-black uppercase tracking-tight">Wheel Up!</div>
                  <div className="text-[10px] opacity-75">Backspin Rewind</div>
                </div>
              </button>
            </div>

            {/* Micro Quote Banner */}
            <div className="mt-4 p-2.5 rounded-lg bg-purple-950/30 border border-purple-800/40 flex items-center justify-between text-xs">
              <span className="text-slate-300">
                Want these live drops at your party?
              </span>
              <a
                href="https://wa.me/256742094651?text=Hey%20Evan!%20I%20tested%20your%20soundboard%20on%20your%20website%20and%20I%20love%20the%20vibes.%20I%20want%20to%20hire%20you%20for%20my%20event."
                target="_blank"
                rel="noopener noreferrer"
                className="text-cyan-400 hover:text-cyan-300 font-bold underline flex items-center gap-1"
              >
                Book The Cue King Now &rarr;
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
