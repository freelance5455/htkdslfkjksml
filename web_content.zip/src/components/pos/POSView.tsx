// Supermarket POS Cashier Checkout Terminal
import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { dbStore } from '../../server/services/dbStore';
import { Product, CartItem, PaymentMethod, Customer, Sale } from '../../types';
import {
  ShoppingCart,
  Barcode,
  Search,
  Plus,
  Minus,
  Trash2,
  User,
  CreditCard,
  DollarSign,
  Smartphone,
  Printer,
  X,
  CheckCircle2,
  AlertCircle,
  PauseCircle,
  RotateCcw,
} from 'lucide-react';

export const POSView: React.FC = () => {
  const { currentBranch, currentUser } = useAuth();
  const settings = dbStore.getSettings();
  const products = dbStore.getProducts();
  const customers = dbStore.getCustomers();
  const categories = dbStore.getCategories();

  const [cart, setCart] = useState<CartItem[]>([]);
  const [barcodeInput, setBarcodeInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  // Held Carts
  const [heldCarts, setHeldCarts] = useState<{ id: string; time: string; items: CartItem[] }[]>([]);

  // Payment Modal
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CASH');
  const [amountTendered, setAmountTendered] = useState<number>(0);
  const [completedSale, setCompletedSale] = useState<Sale | null>(null);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);

  const barcodeInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    barcodeInputRef.current?.focus();
  }, []);

  // Quick category filtered products
  const displayedProducts = products.filter((p) => {
    const matchesCategory = selectedCategory === 'ALL' || p.categoryId === selectedCategory;
    if (!matchesCategory) return false;
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return p.name.toLowerCase().includes(q) || p.barcode.includes(q) || p.sku.toLowerCase().includes(q);
  });

  // Calculate totals
  const subtotal = Number(cart.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0).toFixed(2));
  const discountTotal = Number(
    cart.reduce((sum, item) => sum + item.discountAmount * item.quantity, 0).toFixed(2)
  );
  const taxTotal = Number(
    cart
      .reduce((sum, item) => {
        const taxable = Math.max(0, item.quantity * item.unitPrice - item.discountAmount * item.quantity);
        return sum + (taxable * (item.product.taxRate || 0)) / 100;
      }, 0)
      .toFixed(2)
  );
  const grandTotal = Number((subtotal - discountTotal + taxTotal).toFixed(2));

  // Add Product to Cart
  const addToCart = (product: Product) => {
    const existing = cart.find((item) => item.product.id === product.id);
    if (existing) {
      setCart(
        cart.map((item) =>
          item.product.id === product.id
            ? {
                ...item,
                quantity: item.quantity + 1,
                lineTotal: Number(((item.quantity + 1) * item.unitPrice).toFixed(2)),
              }
            : item
        )
      );
    } else {
      setCart([
        ...cart,
        {
          product,
          quantity: 1,
          unitPrice: product.sellingPrice,
          discountAmount: 0,
          taxAmount: Number(((product.sellingPrice * (product.taxRate || 0)) / 100).toFixed(2)),
          lineTotal: product.sellingPrice,
        },
      ]);
    }
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(
      cart
        .map((item) => {
          if (item.product.id === productId) {
            const nextQty = item.quantity + delta;
            if (nextQty <= 0) return null;
            return {
              ...item,
              quantity: nextQty,
              lineTotal: Number((nextQty * item.unitPrice).toFixed(2)),
            };
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
    setSelectedCustomer(null);
    setCheckoutError(null);
  };

  // Barcode Scanner Submission
  const handleBarcodeScan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!barcodeInput.trim()) return;

    const matched = dbStore.getProductByBarcode(barcodeInput.trim());
    if (matched) {
      addToCart(matched);
      setBarcodeInput('');
    } else {
      alert(`No product found with barcode "${barcodeInput}"`);
    }
  };

  // Hold / Recall Cart
  const handleHoldCart = () => {
    if (cart.length === 0) return;
    setHeldCarts([
      ...heldCarts,
      {
        id: `hold-${Date.now()}`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        items: [...cart],
      },
    ]);
    clearCart();
  };

  const handleRecallCart = (holdId: string) => {
    const held = heldCarts.find((h) => h.id === holdId);
    if (held) {
      setCart(held.items);
      setHeldCarts(heldCarts.filter((h) => h.id !== holdId));
    }
  };

  // Initiate Checkout
  const handleOpenCheckout = () => {
    if (cart.length === 0) return;
    setAmountTendered(grandTotal);
    setPaymentMethod('CASH');
    setCheckoutError(null);
    setIsCheckoutOpen(true);
  };

  // Complete Sale
  const handleCompleteSale = () => {
    if (!currentUser) return;
    setCheckoutError(null);

    try {
      const sale = dbStore.commitSaleTransaction(
        currentBranch.id,
        currentUser.id,
        currentUser.name,
        cart.map((item) => ({
          product: item.product,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          discountAmount: item.discountAmount,
        })),
        paymentMethod,
        amountTendered,
        selectedCustomer?.id,
        `POS terminal checkout at ${currentBranch.name}`
      );

      setCompletedSale(sale);
      setCart([]);
      setSelectedCustomer(null);
    } catch (err: any) {
      setCheckoutError(err.message || 'Transaction failed');
    }
  };

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col lg:flex-row overflow-hidden bg-slate-950">
      {/* Left Product Catalog & Quick Pick */}
      <div className="flex-1 flex flex-col border-r border-slate-800 overflow-hidden">
        {/* Barcode & Search Bar */}
        <div className="p-3 bg-slate-900 border-b border-slate-800 flex flex-col sm:flex-row gap-2">
          {/* Hardware Barcode Scanner Form */}
          <form onSubmit={handleBarcodeScan} className="flex-1 relative">
            <Barcode className="w-4 h-4 text-emerald-400 absolute left-3 top-2.5" />
            <input
              ref={barcodeInputRef}
              type="text"
              placeholder="Scan barcode or press Enter..."
              value={barcodeInput}
              onChange={(e) => setBarcodeInput(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </form>

          {/* Product text search */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search catalog items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Category Pills */}
        <div className="px-3 py-2 bg-slate-900/60 border-b border-slate-800 flex gap-1.5 overflow-x-auto select-none shrink-0">
          <button
            onClick={() => setSelectedCategory('ALL')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
              selectedCategory === 'ALL'
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            All Aisles
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === c.id
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        <div className="flex-1 p-3 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-2.5">
          {displayedProducts.map((p) => {
            const stock = dbStore.getStockForProduct(p.id, currentBranch.id);
            const isOutOfStock = stock <= 0;

            return (
              <button
                key={p.id}
                onClick={() => addToCart(p)}
                disabled={isOutOfStock}
                className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all group ${
                  isOutOfStock
                    ? 'bg-slate-900/40 border-slate-800/50 opacity-40 cursor-not-allowed'
                    : 'bg-slate-900 hover:bg-slate-850 border-slate-800 hover:border-emerald-500/50 shadow-xs'
                }`}
              >
                <div>
                  <div className="font-semibold text-xs text-slate-200 line-clamp-2 group-hover:text-emerald-400 transition-colors">
                    {p.name}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono mt-1">Barcode: {p.barcode}</div>
                </div>

                <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-800/80">
                  <div className="font-bold text-xs text-emerald-400 font-mono">
                    {settings.currency} {p.sellingPrice.toFixed(2)}
                  </div>
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                      stock <= p.reorderLevel
                        ? 'bg-amber-950 text-amber-300'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {stock} {p.unit}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Right Cart & Register Panel */}
      <div className="w-full lg:w-96 flex flex-col bg-slate-900 shrink-0">
        {/* Cart Header */}
        <div className="p-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-sm text-slate-100">Current Cart</span>
            <span className="text-xs text-slate-400 font-mono">({cart.length} items)</span>
          </div>

          <div className="flex items-center gap-1.5">
            {heldCarts.length > 0 && (
              <button
                onClick={() => handleRecallCart(heldCarts[0].id)}
                className="px-2 py-1 rounded bg-amber-950 text-amber-300 text-[10px] font-bold border border-amber-800"
                title="Recall held order"
              >
                Recall ({heldCarts.length})
              </button>
            )}
            <button
              onClick={clearCart}
              disabled={cart.length === 0}
              className="p-1.5 text-slate-400 hover:text-rose-400 rounded transition-colors disabled:opacity-30"
              title="Clear Cart"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Customer Loyalty Selector */}
        <div className="p-2.5 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 flex-1">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedCustomer?.id || ''}
              onChange={(e) => {
                const c = customers.find((cust) => cust.id === e.target.value);
                setSelectedCustomer(c || null);
              }}
              className="bg-transparent text-slate-200 text-xs focus:outline-none w-full cursor-pointer truncate"
            >
              <option value="" className="bg-slate-900 text-slate-400">
                Walk-in Customer (General)
              </option>
              {customers.map((c) => (
                <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                  {c.name} ({c.loyaltyPoints} pts)
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/80 p-2">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-500 text-xs text-center p-6">
              <ShoppingCart className="w-8 h-8 mb-2 opacity-30 text-emerald-400" />
              <span>Cart is empty. Scan a barcode or tap an item on the left to begin.</span>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.product.id} className="py-2.5 px-2 flex items-center justify-between text-xs">
                <div className="flex-1 pr-2">
                  <div className="font-semibold text-slate-200 truncate">{item.product.name}</div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    {settings.currency} {item.unitPrice.toFixed(2)} × {item.quantity}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center border border-slate-700 rounded-lg bg-slate-800">
                    <button
                      onClick={() => updateQuantity(item.product.id, -1)}
                      className="p-1 text-slate-300 hover:text-white"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="px-2 font-mono font-bold text-xs text-white">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.product.id, 1)}
                      className="p-1 text-slate-300 hover:text-white"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="font-mono font-bold text-emerald-400 w-16 text-right">
                    {settings.currency} {item.lineTotal.toFixed(2)}
                  </div>

                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="text-slate-500 hover:text-rose-400 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Cart Totals & Checkout Button */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 space-y-2 text-xs">
          <div className="flex justify-between text-slate-400">
            <span>Subtotal</span>
            <span className="font-mono">
              {settings.currency} {subtotal.toFixed(2)}
            </span>
          </div>

          {discountTotal > 0 && (
            <div className="flex justify-between text-amber-400">
              <span>Discount</span>
              <span className="font-mono">
                -{settings.currency} {discountTotal.toFixed(2)}
              </span>
            </div>
          )}

          <div className="flex justify-between text-slate-400">
            <span>Tax ({settings.taxRateDefault}% VAT)</span>
            <span className="font-mono">
              {settings.currency} {taxTotal.toFixed(2)}
            </span>
          </div>

          <div className="pt-2 border-t border-slate-800 flex justify-between items-baseline">
            <span className="font-bold text-sm text-slate-200">Grand Total</span>
            <span className="font-mono font-extrabold text-lg text-emerald-400">
              {settings.currency} {grandTotal.toFixed(2)}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={handleHoldCart}
              disabled={cart.length === 0}
              className="flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 py-2 rounded-lg font-semibold transition-colors disabled:opacity-40"
            >
              <PauseCircle className="w-3.5 h-3.5" />
              Hold Order
            </button>
            <button
              onClick={handleOpenCheckout}
              disabled={cart.length === 0}
              className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white py-2 rounded-lg font-bold shadow-md shadow-emerald-900/40 transition-colors disabled:opacity-40"
            >
              <CreditCard className="w-3.5 h-3.5" />
              Pay ({settings.currency} {grandTotal.toFixed(2)})
            </button>
          </div>
        </div>
      </div>

      {/* Payment Checkout Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-bold text-slate-100">POS Payment Tender & Receipt</h2>
              </div>
              <button
                onClick={() => setIsCheckoutOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {checkoutError && (
                <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{checkoutError}</span>
                </div>
              )}

              {/* Total Summary */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-400">Total Payable Amount</div>
                  <div className="text-2xl font-mono font-black text-emerald-400">
                    {settings.currency} {grandTotal.toFixed(2)}
                  </div>
                </div>
                {selectedCustomer && (
                  <div className="text-right text-xs">
                    <div className="font-semibold text-slate-200">{selectedCustomer.name}</div>
                    <div className="text-emerald-400 font-mono">
                      +{(Math.floor(grandTotal / 50))} loyalty pts
                    </div>
                  </div>
                )}
              </div>

              {/* Payment Methods */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Payment Method</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['CASH', 'CARD', 'MOBILE_PAYMENT'] as PaymentMethod[]).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => {
                        setPaymentMethod(m);
                        if (m !== 'CASH') setAmountTendered(grandTotal);
                      }}
                      className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1.5 transition-colors ${
                        paymentMethod === m
                          ? 'bg-emerald-600 text-white border-emerald-500 shadow-sm'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                      }`}
                    >
                      {m === 'CASH' && <DollarSign className="w-4 h-4" />}
                      {m === 'CARD' && <CreditCard className="w-4 h-4" />}
                      {m === 'MOBILE_PAYMENT' && <Smartphone className="w-4 h-4" />}
                      <span>{m.replace('_', ' ')}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Tendered Input (if cash) */}
              {paymentMethod === 'CASH' && (
                <div className="space-y-2">
                  <label className="block text-xs font-semibold text-slate-300">
                    Cash Amount Received ({settings.currency})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={amountTendered}
                    onChange={(e) => setAmountTendered(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
                  />

                  {/* Quick Cash Buttons */}
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setAmountTendered(grandTotal)}
                      className="flex-1 py-1 text-xs bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300"
                    >
                      Exact
                    </button>
                    {[50, 100, 200, 500].map((extra) => (
                      <button
                        key={extra}
                        type="button"
                        onClick={() => setAmountTendered(Math.ceil(grandTotal / extra) * extra)}
                        className="flex-1 py-1 text-xs bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 font-mono"
                      >
                        +{extra}
                      </button>
                    ))}
                  </div>

                  {/* Change Given Display */}
                  <div className="bg-slate-800/60 p-3 rounded-lg flex items-center justify-between text-xs">
                    <span className="text-slate-400">Change Due to Customer:</span>
                    <span className="font-mono font-bold text-sm text-cyan-400">
                      {settings.currency} {Math.max(0, amountTendered - grandTotal).toFixed(2)}
                    </span>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCheckoutOpen(false)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                >
                  Back to Cart
                </button>
                <button
                  type="button"
                  onClick={handleCompleteSale}
                  className="px-6 py-2.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg shadow-lg shadow-emerald-900/40"
                >
                  Complete Checkout & Print Receipt
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Thermal Receipt Print Dialog */}
      {completedSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-xs p-4">
          <div className="bg-white text-slate-900 rounded-xl w-full max-w-sm overflow-hidden shadow-2xl p-6 font-mono text-xs space-y-4">
            <div className="text-center border-b pb-3 border-slate-300">
              <div className="font-bold text-base tracking-wider">{settings.businessName}</div>
              <div className="text-[10px] text-slate-600">{settings.address}</div>
              <div className="text-[10px] text-slate-600">Tel: {settings.phone}</div>
              <div className="text-[10px] text-slate-600 mt-1">Branch: {currentBranch.name}</div>
            </div>

            <div className="text-[10px] text-slate-600 space-y-0.5 border-b pb-2 border-slate-300">
              <div>Receipt #: {completedSale.receiptNumber}</div>
              <div>Date: {new Date(completedSale.createdAt).toLocaleString()}</div>
              <div>Cashier: {completedSale.cashierName}</div>
              {completedSale.customerName && <div>Customer: {completedSale.customerName}</div>}
            </div>

            <div className="divide-y divide-dashed divide-slate-300">
              {completedSale.items.map((item, idx) => (
                <div key={idx} className="py-1 flex justify-between">
                  <div>
                    <div>{item.productName}</div>
                    <div className="text-[10px] text-slate-500">
                      {item.quantity} × {item.unitPrice.toFixed(2)}
                    </div>
                  </div>
                  <div className="font-bold">
                    {settings.currency} {item.totalPrice.toFixed(2)}
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-slate-300 pt-2 space-y-1">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>
                  {settings.currency} {completedSale.subtotal.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Tax</span>
                <span>
                  {settings.currency} {completedSale.taxTotal.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between font-bold text-sm border-t border-slate-900 pt-1">
                <span>TOTAL</span>
                <span>
                  {settings.currency} {completedSale.grandTotal.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-[10px] text-slate-600">
                <span>Paid ({completedSale.paymentMethod})</span>
                <span>
                  {settings.currency} {completedSale.amountTendered.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-[10px] text-slate-600">
                <span>Change Given</span>
                <span>
                  {settings.currency} {completedSale.changeGiven.toFixed(2)}
                </span>
              </div>
            </div>

            <div className="text-center text-[10px] text-slate-500 pt-2 border-t border-slate-300">
              {settings.receiptFooter}
            </div>

            <div className="pt-3 flex gap-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 rounded bg-slate-800 text-white font-sans text-xs font-semibold flex items-center justify-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" />
                Print (80mm)
              </button>
              <button
                onClick={() => {
                  setCompletedSale(null);
                  setIsCheckoutOpen(false);
                }}
                className="flex-1 py-2 rounded bg-emerald-600 text-white font-sans text-xs font-semibold"
              >
                New Customer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
