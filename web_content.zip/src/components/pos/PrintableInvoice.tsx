import React, { useState } from 'react';
import { Printer, X, FileText, CheckCircle, Receipt } from 'lucide-react';
import { Invoice, StoreSettings } from '../../types';

interface Props {
  invoice: Invoice;
  settings: StoreSettings;
  onClose: () => void;
}

export const PrintableInvoice: React.FC<Props> = ({ invoice, settings, onClose }) => {
  const [printMode, setPrintMode] = useState<'thermal' | 'a4'>('thermal');

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 overflow-y-auto no-print">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[95vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <CheckCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-lg">معاينة وطباعة الفاتورة</h3>
              <p className="text-xs text-slate-400">رقم الفاتورة: {invoice.invoiceNumber}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Format toggle */}
            <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-700 text-xs">
              <button
                onClick={() => setPrintMode('thermal')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition font-medium ${
                  printMode === 'thermal'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" />
                حراري (80mm)
              </button>
              <button
                onClick={() => setPrintMode('a4')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition font-medium ${
                  printMode === 'a4'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                فاتورة A4
              </button>
            </div>

            <button
              onClick={handlePrint}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg shadow-emerald-600/20 transition"
            >
              <Printer className="w-4 h-4" />
              طباعة (F9)
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Invoice Preview Container */}
        <div className="p-6 overflow-y-auto bg-slate-950/60 flex justify-center">
          {printMode === 'thermal' ? (
            /* 80mm Thermal Receipt Layout */
            <div
              id="printable-receipt"
              className="w-[320px] bg-white text-slate-900 p-4 shadow-xl border border-slate-200 font-mono text-xs rounded-sm select-text"
              dir="rtl"
            >
              {/* Header */}
              <div className="text-center pb-3 border-b border-dashed border-slate-400">
                <h2 className="text-base font-black tracking-tight">{settings.storeName}</h2>
                {settings.storeNameEn && (
                  <p className="text-[10px] text-slate-600">{settings.storeNameEn}</p>
                )}
                <p className="text-[11px] text-slate-700 mt-1">{settings.address}</p>
                <p className="text-[11px] text-slate-700">هاتف: {settings.phone}</p>
                <div className="mt-1.5 inline-block bg-slate-100 px-2 py-0.5 rounded border border-slate-300 font-bold text-[10px]">
                  فاتورة ضريبية مبسطة
                </div>
                <p className="text-[10px] text-slate-600 mt-1">الرقم الضريبي: {settings.taxNumber}</p>
              </div>

              {/* Invoice Meta */}
              <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">رقم الفاتورة:</span>
                  <span className="font-bold">{invoice.invoiceNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">التاريخ والوقت:</span>
                  <span>{new Date(invoice.date).toLocaleString('ar-SA')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">الكاشير:</span>
                  <span>{invoice.cashierName}</span>
                </div>
                {invoice.customerName && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">العميل:</span>
                    <span className="font-semibold">{invoice.customerName}</span>
                  </div>
                )}
              </div>

              {/* Items Table */}
              <div className="py-2.5 border-b border-dashed border-slate-400">
                <table className="w-full text-[11px]">
                  <thead>
                    <tr className="border-b border-slate-300 text-slate-600 font-bold">
                      <th className="text-right py-1">الصنف</th>
                      <th className="text-center py-1">الكمية</th>
                      <th className="text-center py-1">السعر</th>
                      <th className="text-left py-1">الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {invoice.items.map((item, idx) => {
                      const itemTotal =
                        item.quantity *
                        item.product.sellingPrice *
                        (1 - item.discountPercent / 100);
                      return (
                        <tr key={idx} className="py-1">
                          <td className="py-1 text-right font-medium">
                            {item.product.name}
                            {item.discountPercent > 0 && (
                              <span className="block text-[9px] text-red-600">
                                خصم {item.discountPercent}%
                              </span>
                            )}
                          </td>
                          <td className="py-1 text-center font-bold">{item.quantity}</td>
                          <td className="py-1 text-center font-mono">
                            {item.product.sellingPrice.toFixed(2)}
                          </td>
                          <td className="py-1 text-left font-bold font-mono">
                            {itemTotal.toFixed(2)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Totals */}
              <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-600">المجموع قبل الضريبة:</span>
                  <span className="font-mono">{invoice.subtotal.toFixed(2)} {settings.currency}</span>
                </div>
                {invoice.discountAmount > 0 && (
                  <div className="flex justify-between text-red-600">
                    <span>إجمالي الخصم:</span>
                    <span className="font-mono">-{invoice.discountAmount.toFixed(2)} {settings.currency}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>ضريبة القيمة المضافة ({invoice.taxRate}%):</span>
                  <span className="font-mono">{invoice.taxAmount.toFixed(2)} {settings.currency}</span>
                </div>
                <div className="flex justify-between text-sm font-black pt-1.5 border-t border-slate-300">
                  <span>المبلغ الإجمالي النهائي:</span>
                  <span className="font-mono text-base">{invoice.grandTotal.toFixed(2)} {settings.currency}</span>
                </div>
              </div>

              {/* Payment Info */}
              <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">طريقة الدفع:</span>
                  <span className="font-bold">
                    {invoice.paymentMethod === 'cash' && 'نقداً (كاش)'}
                    {invoice.paymentMethod === 'card' && 'شبكة / مدى / بطاقة'}
                    {invoice.paymentMethod === 'debt' && 'آجل (ذمم)'}
                    {invoice.paymentMethod === 'split' && 'دفع متعدد'}
                  </span>
                </div>
                {invoice.paymentMethod === 'cash' && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-slate-500">المبلغ المدفوع:</span>
                      <span className="font-mono">{invoice.amountPaid.toFixed(2)} {settings.currency}</span>
                    </div>
                    <div className="flex justify-between font-bold text-emerald-700">
                      <span>الباقي للعميل:</span>
                      <span className="font-mono">{invoice.changeAmount.toFixed(2)} {settings.currency}</span>
                    </div>
                  </>
                )}
              </div>

              {/* ZATCA QR Code Representation */}
              <div className="pt-3 pb-1 text-center flex flex-col items-center">
                <div className="w-24 h-24 bg-white p-1 border-2 border-slate-900 rounded flex items-center justify-center">
                  <div className="grid grid-cols-6 gap-0.5 w-full h-full p-0.5 bg-slate-900">
                    {Array.from({ length: 36 }).map((_, i) => (
                      <div
                        key={i}
                        className={`w-full h-full ${
                          (i % 2 === 0 || i % 5 === 0 || i < 6 || i > 30)
                            ? 'bg-white'
                            : 'bg-slate-900'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <span className="text-[9px] text-slate-500 mt-1">امسح للتحقق من الفاتورة الضريبية</span>
                <p className="text-[10px] text-slate-700 mt-2 leading-relaxed text-center">
                  {settings.receiptFooter}
                </p>
              </div>
            </div>
          ) : (
            /* Official A4 Tax Invoice */
            <div
              id="printable-receipt"
              className="w-full max-w-xl bg-white text-slate-900 p-8 shadow-xl border border-slate-200 font-sans text-sm rounded-lg select-text"
              dir="rtl"
            >
              {/* Header */}
              <div className="flex justify-between items-start pb-6 border-b-2 border-slate-900">
                <div>
                  <h1 className="text-2xl font-black text-slate-900">{settings.storeName}</h1>
                  <p className="text-xs text-slate-500 font-medium">{settings.storeNameEn}</p>
                  <p className="text-xs text-slate-600 mt-2">{settings.address}</p>
                  <p className="text-xs text-slate-600">هاتف: {settings.phone}</p>
                  <p className="text-xs font-semibold text-slate-800">
                    الرقم الضريبي: {settings.taxNumber}
                  </p>
                  {settings.commercialReg && (
                    <p className="text-xs text-slate-600">سجل تجاري: {settings.commercialReg}</p>
                  )}
                </div>
                <div className="text-left">
                  <span className="inline-block px-3 py-1 bg-slate-900 text-white text-xs font-bold rounded-md">
                    فاتورة ضريبية
                  </span>
                  <div className="mt-3 text-right space-y-1 text-xs">
                    <p>
                      <span className="text-slate-500">رقم الفاتورة:</span>{' '}
                      <strong className="font-mono">{invoice.invoiceNumber}</strong>
                    </p>
                    <p>
                      <span className="text-slate-500">التاريخ:</span>{' '}
                      <span>{new Date(invoice.date).toLocaleDateString('ar-SA')}</span>
                    </p>
                    <p>
                      <span className="text-slate-500">الكاشير:</span> {invoice.cashierName}
                    </p>
                  </div>
                </div>
              </div>

              {/* Bill To */}
              <div className="py-4 border-b border-slate-200 grid grid-cols-2 gap-4 text-xs">
                <div>
                  <h4 className="font-bold text-slate-700 mb-1">بيانات العميل:</h4>
                  <p className="text-slate-900 font-semibold">{invoice.customerName || 'عميل نقدي'}</p>
                  {invoice.customerPhone && (
                    <p className="text-slate-600">هاتف: {invoice.customerPhone}</p>
                  )}
                </div>
                <div className="text-left">
                  <h4 className="font-bold text-slate-700 mb-1">حالة السداد:</h4>
                  <span
                    className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold ${
                      invoice.status === 'paid'
                        ? 'bg-emerald-100 text-emerald-800'
                        : invoice.status === 'pending'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {invoice.status === 'paid' ? 'تم الدفع بالكامل' : invoice.status === 'pending' ? 'مستحقة / آجل' : 'مرتجعة'}
                  </span>
                </div>
              </div>

              {/* Items Table */}
              <div className="my-6">
                <table className="w-full text-xs">
                  <thead className="bg-slate-100 border-y border-slate-300">
                    <tr>
                      <th className="p-2.5 text-right font-bold text-slate-700">#</th>
                      <th className="p-2.5 text-right font-bold text-slate-700">بيان الصنف</th>
                      <th className="p-2.5 text-center font-bold text-slate-700">الكمية</th>
                      <th className="p-2.5 text-center font-bold text-slate-700">سعر الوحدة</th>
                      <th className="p-2.5 text-center font-bold text-slate-700">الخصم</th>
                      <th className="p-2.5 text-left font-bold text-slate-700">الإجمالي (شامل)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {invoice.items.map((item, idx) => {
                      const itemTotal =
                        item.quantity *
                        item.product.sellingPrice *
                        (1 - item.discountPercent / 100);
                      return (
                        <tr key={idx} className="hover:bg-slate-50/50">
                          <td className="p-2.5 text-slate-500">{idx + 1}</td>
                          <td className="p-2.5 font-medium text-slate-900">
                            {item.product.name}
                            <span className="block text-[10px] text-slate-500 font-mono">
                              باركود: {item.product.barcode}
                            </span>
                          </td>
                          <td className="p-2.5 text-center font-bold">{item.quantity}</td>
                          <td className="p-2.5 text-center font-mono">
                            {item.product.sellingPrice.toFixed(2)}
                          </td>
                          <td className="p-2.5 text-center text-red-600 font-mono">
                            {item.discountPercent > 0 ? `${item.discountPercent}%` : '-'}
                          </td>
                          <td className="p-2.5 text-left font-bold font-mono">
                            {itemTotal.toFixed(2)} {settings.currency}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Totals Breakdown */}
              <div className="flex justify-end pt-4 border-t border-slate-200">
                <div className="w-64 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>المجموع الفرعي:</span>
                    <span className="font-mono font-medium">{invoice.subtotal.toFixed(2)} {settings.currency}</span>
                  </div>
                  {invoice.discountAmount > 0 && (
                    <div className="flex justify-between text-red-600">
                      <span>إجمالي الخصم:</span>
                      <span className="font-mono font-medium">-{invoice.discountAmount.toFixed(2)} {settings.currency}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-600">
                    <span>ضريبة القيمة المضافة ({invoice.taxRate}%):</span>
                    <span className="font-mono font-medium">{invoice.taxAmount.toFixed(2)} {settings.currency}</span>
                  </div>
                  <div className="flex justify-between text-base font-black pt-2 border-t-2 border-slate-900 text-slate-950">
                    <span>المجموع الإجمالي:</span>
                    <span className="font-mono">{invoice.grandTotal.toFixed(2)} {settings.currency}</span>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="mt-8 pt-4 border-t border-slate-200 text-center text-xs text-slate-500">
                <p>{settings.receiptFooter}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
