import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, Plus, Minus, Trash2, ShoppingCart, CreditCard, 
  Banknote, User, AlertCircle, Sparkles, X, Check, 
  ArrowRight, Percent, Barcode, DollarSign
} from 'lucide-react';
import { Product, CartItem, PaymentMethod, Customer, StoreSettings, Invoice } from '../../types';

interface Props {
  products: Product[];
  customers: Customer[];
  settings: StoreSettings;
  onCompleteSale: (invoiceData: Omit<Invoice, 'id' | 'invoiceNumber'>) => void;
  onOpenAiAssistant: () => void;
  onOpenShortcuts: () => void;
}

export const PosCheckout: React.FC<Props> = ({
  products,
  customers,
  settings,
  onCompleteSale,
  onOpenAiAssistant,
  onOpenShortcuts,
}) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('الكل');
  const [overallDiscountPercent, setOverallDiscountPercent] = useState<number>(0);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isDiscountModalOpen, setIsDiscountModalOpen] = useState(false);
  
  // Payment states
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [cashGiven, setCashGiven] = useState<string>('');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [customCustomerName, setCustomCustomerName] = useState('');
  const [customCustomerPhone, setCustomCustomerPhone] = useState('');
  const [notes, setNotes] = useState('');

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Extract categories
  const categories = ['الكل', ...Array.from(new Set(products.map((p) => p.category)))];

  // Calculations
  const subtotal = cart.reduce((sum, item) => {
    const itemPrice = item.product.sellingPrice * (1 - item.discountPercent / 100);
    return sum + itemPrice * item.quantity;
  }, 0);

  const overallDiscountAmount = (subtotal * overallDiscountPercent) / 100;
  const netSubtotal = subtotal - overallDiscountAmount;
  const taxRate = settings.enableVat ? settings.vatRate : 0;
  const taxAmount = (netSubtotal * taxRate) / 100;
  const grandTotal = netSubtotal + taxAmount;

  const cashGivenNum = parseFloat(cashGiven) || 0;
  const changeAmount = Math.max(0, cashGivenNum - grandTotal);

  // Keyboard shortcut handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F1') {
        e.preventDefault();
        setCart([]);
      } else if (e.key === 'F2') {
        e.preventDefault();
        if (cart.length > 0) {
          setIsPaymentModalOpen(true);
        }
      } else if (e.key === 'F3') {
        e.preventDefault();
        searchInputRef.current?.focus();
        searchInputRef.current?.select();
      } else if (e.key === 'F4') {
        e.preventDefault();
        setIsDiscountModalOpen(true);
      } else if (e.key === 'Escape') {
        setIsPaymentModalOpen(false);
        setIsDiscountModalOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [cart]);

  // Set default cash when opening payment modal
  useEffect(() => {
    if (isPaymentModalOpen && paymentMethod === 'cash') {
      setCashGiven(grandTotal.toFixed(2));
    }
  }, [isPaymentModalOpen, paymentMethod, grandTotal]);

  // Handle Add to Cart
  const handleAddToCart = (product: Product) => {
    if (product.stock <= 0) {
      alert(`عذراً، الصنف "${product.name}" نفد من المخزون!`);
      return;
    }

    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) {
          alert(`لا يمكنك إضافة كمية أكبر من المتوفر بالمخزون (${product.stock} ${product.unit})`);
          return prev;
        }
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1, discountPercent: 0 }];
    });
  };

  // Barcode / Search Enter key handler
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      e.preventDefault();
      // Match exact barcode first, or first item
      const exactMatch = products.find(
        (p) => p.barcode.toLowerCase() === searchQuery.trim().toLowerCase()
      );
      if (exactMatch) {
        handleAddToCart(exactMatch);
        setSearchQuery('');
        return;
      }

      // Filtered match
      const filtered = filteredProducts;
      if (filtered.length > 0) {
        handleAddToCart(filtered[0]);
        setSearchQuery('');
      }
    }
  };

  // Quantity updates
  const updateQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            if (newQty > item.product.stock) {
              alert(`الكمية القصوى المتوفرة بالمخزون هي ${item.product.stock}`);
              return item;
            }
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const removeItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  // Filter products
  const filteredProducts = products.filter((p) => {
    const matchesCategory =
      selectedCategory === 'الكل' || p.category === selectedCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      p.name.toLowerCase().includes(q) ||
      p.barcode.toLowerCase().includes(q) ||
      (p.nameEn && p.nameEn.toLowerCase().includes(q));
    return matchesCategory && matchesSearch;
  });

  // Handle Checkout submission
  const handleFinalizeSale = () => {
    if (cart.length === 0) return;

    if (paymentMethod === 'debt' && !selectedCustomerId && !customCustomerName) {
      alert('الرجاء اختيار العميل أو إدخال اسمه لتسجيل الفاتورة الآجلة في حسابه');
      return;
    }

    const selectedCust = customers.find((c) => c.id === selectedCustomerId);
    const custName = selectedCust ? selectedCust.name : customCustomerName || 'عميل نقدي';
    const custPhone = selectedCust ? selectedCust.phone : customCustomerPhone || '';

    const invoiceData: Omit<Invoice, 'id' | 'invoiceNumber'> = {
      date: new Date().toISOString(),
      items: [...cart],
      subtotal: Number(netSubtotal.toFixed(2)),
      taxRate: taxRate,
      taxAmount: Number(taxAmount.toFixed(2)),
      discountAmount: Number(overallDiscountAmount.toFixed(2)),
      grandTotal: Number(grandTotal.toFixed(2)),
      paymentMethod,
      amountPaid: paymentMethod === 'cash' ? cashGivenNum : grandTotal,
      changeAmount: paymentMethod === 'cash' ? changeAmount : 0,
      customerName: custName,
      customerPhone: custPhone,
      customerId: selectedCustomerId || undefined,
      cashierName: settings.cashierName || 'كاشير رئيسي',
      status: paymentMethod === 'debt' ? 'pending' : 'paid',
      notes,
    };

    onCompleteSale(invoiceData);
    setCart([]);
    setIsPaymentModalOpen(false);
    setCashGiven('');
    setNotes('');
    setCustomCustomerName('');
    setCustomCustomerPhone('');
    setSelectedCustomerId('');
    setOverallDiscountPercent(0);
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-slate-950">
      {/* Product Catalog & Search (Right side in RTL) */}
      <div className="flex-1 flex flex-col border-b md:border-b-0 md:border-l border-slate-800 overflow-hidden">
        {/* Top search & quick filters */}
        <div className="p-4 bg-slate-900 border-b border-slate-800 space-y-3">
          <div className="flex items-center gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleSearchKeyDown}
                placeholder="امسح الباركود بجهاز المسح أو ابحث بالاسم (F3)... ثم اضغط Enter"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pr-10 pl-24 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition shadow-inner font-mono"
              />
              <div className="absolute left-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1 text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                <Barcode className="w-3 h-3 text-blue-400" />
                <span>قارئ باركود</span>
              </div>
            </div>

            <button
              onClick={onOpenAiAssistant}
              className="flex items-center gap-1.5 px-3.5 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-indigo-600/20 transition shrink-0"
              title="المساعد الذكي للمبيعات والمخزون"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span className="hidden sm:inline">المساعد الذكي</span>
            </button>

            <button
              onClick={onOpenShortcuts}
              className="px-3 py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white rounded-xl text-xs font-mono border border-slate-700 transition shrink-0"
              title="اختصارات الكيبورد"
            >
              ⌨️ F1-F9
            </button>
          </div>

          {/* Categories bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-750 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
            {filteredProducts.map((product) => {
              const isLowStock = product.stock <= product.minStock && product.stock > 0;
              const isOutOfStock = product.stock <= 0;

              return (
                <button
                  key={product.id}
                  onClick={() => handleAddToCart(product)}
                  disabled={isOutOfStock}
                  className={`group relative flex flex-col justify-between text-right p-3.5 rounded-xl border transition duration-150 active:scale-[0.98] ${
                    isOutOfStock
                      ? 'bg-slate-900/40 border-slate-800 opacity-60 cursor-not-allowed'
                      : 'bg-slate-900 border-slate-800 hover:border-blue-500/50 hover:bg-slate-850 hover:shadow-lg hover:shadow-blue-500/5'
                  }`}
                >
                  <div>
                    <div className="flex justify-between items-start mb-1.5">
                      <span className="text-[10px] font-mono text-slate-500 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                        {product.barcode}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          isOutOfStock
                            ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                            : isLowStock
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}
                      >
                        {isOutOfStock
                          ? 'نفد'
                          : `${product.stock} ${product.unit}`}
                      </span>
                    </div>

                    <h4 className="font-bold text-slate-200 text-xs sm:text-sm line-clamp-2 group-hover:text-blue-400 transition">
                      {product.name}
                    </h4>
                    {product.nameEn && (
                      <p className="text-[10px] text-slate-500 truncate mt-0.5">
                        {product.nameEn}
                      </p>
                    )}
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                    <span className="text-xs text-slate-400">{product.category}</span>
                    <span className="text-sm font-black font-mono text-emerald-400">
                      {product.sellingPrice.toFixed(2)}{' '}
                      <small className="text-[10px] font-normal text-slate-400">
                        {settings.currency}
                      </small>
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {filteredProducts.length === 0 && (
            <div className="h-64 flex flex-col items-center justify-center text-slate-500">
              <Search className="w-10 h-10 mb-2 stroke-1 opacity-50" />
              <p className="text-sm">لم يتم العثور على أي منتج مطابق للبحث</p>
              <p className="text-xs text-slate-600 mt-1">تأكد من رقم الباركود أو الاسم</p>
            </div>
          )}
        </div>
      </div>

      {/* Cart & Checkout Panel (Left side in RTL) */}
      <div className="w-full md:w-96 lg:w-[420px] bg-slate-900 flex flex-col shrink-0">
        {/* Cart Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-blue-600/10 text-blue-400">
              <ShoppingCart className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">سلة الفاتورة الحالية</h3>
              <p className="text-[11px] text-slate-400">
                {cart.reduce((s, i) => s + i.quantity, 0)} أصناف محددة
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsDiscountModalOpen(true)}
              className={`p-2 rounded-lg text-xs font-semibold flex items-center gap-1 transition ${
                overallDiscountPercent > 0
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  : 'bg-slate-800 text-slate-300 hover:text-white border border-slate-700'
              }`}
              title="خصم عام على الفاتورة (F4)"
            >
              <Percent className="w-3.5 h-3.5" />
              {overallDiscountPercent > 0 ? `${overallDiscountPercent}%` : 'خصم (F4)'}
            </button>

            <button
              onClick={() => setCart([])}
              disabled={cart.length === 0}
              className="p-2 text-slate-400 hover:text-red-400 rounded-lg hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-transparent transition"
              title="تفريغ السلة (F1)"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Cart Item List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/80 p-2">
          {cart.map((item) => {
            const itemTotal =
              item.quantity *
              item.product.sellingPrice *
              (1 - item.discountPercent / 100);

            return (
              <div
                key={item.product.id}
                className="p-3 hover:bg-slate-850/50 rounded-xl transition flex items-center justify-between gap-2"
              >
                <div className="flex-1 min-w-0">
                  <h5 className="font-semibold text-xs text-white truncate">
                    {item.product.name}
                  </h5>
                  <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                    <span className="font-mono">
                      {item.product.sellingPrice.toFixed(2)} {settings.currency}
                    </span>
                    {item.discountPercent > 0 && (
                      <span className="text-red-400 text-[10px]">
                        (خصم {item.discountPercent}%)
                      </span>
                    )}
                  </div>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800">
                  <button
                    onClick={() => updateQuantity(item.product.id, -1)}
                    className="w-6 h-6 flex items-center justify-center rounded text-slate-400 hover:text-white hover:bg-slate-800 transition"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="w-7 text-center font-bold font-mono text-xs text-blue-400">
                    {item.quantity}
                  </span>
                  <button
                    onClick={() => updateQuantity(item.product.id, 1)}
                    className="w-6 h-6 flex items-center justify-center rounded text-slate-400 hover:text-white hover:bg-slate-800 transition"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>

                {/* Total per row */}
                <div className="text-left font-mono font-bold text-xs text-emerald-400 w-20">
                  {itemTotal.toFixed(2)}{' '}
                  <span className="text-[10px] text-slate-500">{settings.currency}</span>
                </div>

                <button
                  onClick={() => removeItem(item.product.id)}
                  className="text-slate-500 hover:text-red-400 p-1 transition"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}

          {cart.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-slate-500 p-6 text-center">
              <div className="w-12 h-12 rounded-2xl bg-slate-800/80 flex items-center justify-center mb-3 text-slate-600">
                <ShoppingCart className="w-6 h-6 stroke-1" />
              </div>
              <p className="text-sm font-medium text-slate-400">السلة فارغة حالياً</p>
              <p className="text-xs text-slate-600 mt-1">
                اختر صنفاً من القائمة أو امسح الباركود مباشرة للبدء
              </p>
            </div>
          )}
        </div>

        {/* Invoice Summary Box */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 space-y-2 text-xs">
          <div className="flex justify-between text-slate-400">
            <span>المجموع قبل الضريبة:</span>
            <span className="font-mono">{subtotal.toFixed(2)} {settings.currency}</span>
          </div>

          {overallDiscountPercent > 0 && (
            <div className="flex justify-between text-red-400">
              <span>خصم الفاتورة ({overallDiscountPercent}%):</span>
              <span className="font-mono">-{overallDiscountAmount.toFixed(2)} {settings.currency}</span>
            </div>
          )}

          {settings.enableVat && (
            <div className="flex justify-between text-slate-400">
              <span>ضريبة القيمة المضافة ({settings.vatRate}%):</span>
              <span className="font-mono">{taxAmount.toFixed(2)} {settings.currency}</span>
            </div>
          )}

          <div className="pt-2 border-t border-slate-800 flex justify-between items-baseline">
            <span className="text-sm font-bold text-white">المجموع النهائي:</span>
            <div className="text-right">
              <span className="text-2xl font-black font-mono text-emerald-400">
                {grandTotal.toFixed(2)}
              </span>{' '}
              <span className="text-xs font-bold text-slate-400">{settings.currency}</span>
            </div>
          </div>

          {/* Quick Pay Action Button */}
          <button
            onClick={() => setIsPaymentModalOpen(true)}
            disabled={cart.length === 0}
            className="w-full mt-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-40 disabled:pointer-events-none text-white font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 transition active:scale-[0.99] text-base"
          >
            <span>الدفع وإنهاء الفاتورة</span>
            <kbd className="px-2 py-0.5 text-xs bg-emerald-700/50 rounded font-mono">F2</kbd>
            <ArrowRight className="w-4 h-4 rtl:rotate-180" />
          </button>
        </div>
      </div>

      {/* Payment Modal */}
      {isPaymentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 flex flex-col max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <h3 className="font-bold text-lg text-white">إتمام عملية الدفع</h3>
                <p className="text-xs text-slate-400">اختر طريقة الدفع ومبلغ العميل</p>
              </div>
              <button
                onClick={() => setIsPaymentModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Total Display */}
            <div className="my-4 p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-xs text-slate-400 font-medium">المبلغ المطلوب سداده</span>
              <div className="text-3xl font-black font-mono text-emerald-400 mt-1">
                {grandTotal.toFixed(2)}{' '}
                <span className="text-sm font-normal text-slate-400">{settings.currency}</span>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              <button
                type="button"
                onClick={() => setPaymentMethod('cash')}
                className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border text-xs font-bold transition ${
                  paymentMethod === 'cash'
                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300'
                    : 'bg-slate-800/80 border-slate-750 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <Banknote className="w-5 h-5" />
                <span>نقدي (كاش)</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border text-xs font-bold transition ${
                  paymentMethod === 'card'
                    ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                    : 'bg-slate-800/80 border-slate-750 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <CreditCard className="w-5 h-5" />
                <span>شبكة / بطاقة</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('debt')}
                className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border text-xs font-bold transition ${
                  paymentMethod === 'debt'
                    ? 'bg-amber-600/20 border-amber-500 text-amber-300'
                    : 'bg-slate-800/80 border-slate-750 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <User className="w-5 h-5" />
                <span>آجل (ذمم)</span>
              </button>
            </div>

            {/* Method-specific fields */}
            {paymentMethod === 'cash' && (
              <div className="space-y-3 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                <label className="block text-xs font-bold text-slate-300">
                  المبلغ المستلم من العميل:
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    value={cashGiven}
                    onChange={(e) => setCashGiven(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-lg font-mono font-bold text-white focus:outline-none focus:border-emerald-500"
                    placeholder="0.00"
                  />
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-bold">
                    {settings.currency}
                  </span>
                </div>

                {/* Quick cash pills */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {[
                    grandTotal,
                    Math.ceil(grandTotal / 10) * 10,
                    Math.ceil(grandTotal / 50) * 50 || 50,
                    100,
                    200,
                    500,
                  ]
                    .filter((v, i, a) => v >= grandTotal && a.indexOf(v) === i)
                    .map((val) => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => setCashGiven(val.toFixed(2))}
                        className="px-2.5 py-1 text-xs font-mono bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg text-slate-200 transition"
                      >
                        {val.toFixed(0)} {settings.currency}
                      </button>
                    ))}
                </div>

                {/* Change amount */}
                <div className="flex justify-between items-center pt-2 border-t border-slate-800 text-sm">
                  <span className="text-slate-400">المبلغ المتبقي للعميل (الباقي):</span>
                  <span className="font-black font-mono text-emerald-400 text-lg">
                    {changeAmount.toFixed(2)} {settings.currency}
                  </span>
                </div>
              </div>
            )}

            {paymentMethod === 'debt' && (
              <div className="space-y-3 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                <label className="block text-xs font-bold text-slate-300">
                  اختيار العميل لتسجيل المديونية:
                </label>
                <select
                  value={selectedCustomerId}
                  onChange={(e) => setSelectedCustomerId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="">-- اختر من قائمة العملاء المسجلين --</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.phone}) - رصيد سابق: {c.balance.toFixed(2)} {settings.currency}
                    </option>
                  ))}
                </select>

                <div className="text-[11px] text-slate-400 text-center my-1">- أو عميل جديد -</div>

                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={customCustomerName}
                    onChange={(e) => setCustomCustomerName(e.target.value)}
                    placeholder="اسم العميل الجديد"
                    className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                  <input
                    type="text"
                    value={customCustomerPhone}
                    onChange={(e) => setCustomCustomerPhone(e.target.value)}
                    placeholder="رقم الهاتف"
                    className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            )}

            {/* Optional notes */}
            <div className="mt-3">
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="ملاحظات إضافية على الفاتورة (اختياري)"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Final Action Buttons */}
            <div className="mt-6 flex gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsPaymentModalOpen(false)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-bold transition"
              >
                إلغاء (Esc)
              </button>
              <button
                type="button"
                onClick={handleFinalizeSale}
                className="flex-2 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-bold shadow-lg shadow-emerald-600/20 transition flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>تأكيد وطباعة الفاتورة</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Discount Modal */}
      {isDiscountModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-5 text-slate-100">
            <h3 className="font-bold text-base text-white mb-2">خصم عام على الفاتورة</h3>
            <p className="text-xs text-slate-400 mb-4">حدد نسبة الخصم المئوية لتطبيقها على إجمالي الأصناف</p>

            <div className="relative mb-4">
              <input
                type="number"
                min="0"
                max="100"
                value={overallDiscountPercent}
                onChange={(e) => setOverallDiscountPercent(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-lg font-mono font-bold text-white focus:outline-none focus:border-amber-500"
              />
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">
                %
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2 mb-5">
              {[5, 10, 15, 20].map((pct) => (
                <button
                  key={pct}
                  type="button"
                  onClick={() => setOverallDiscountPercent(pct)}
                  className="py-1.5 text-xs font-bold font-mono bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg text-slate-200 transition"
                >
                  {pct}%
                </button>
              ))}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setOverallDiscountPercent(0)}
                className="flex-1 py-2 text-xs font-medium bg-slate-800 text-slate-400 hover:text-white rounded-xl transition"
              >
                إلغاء الخصم
              </button>
              <button
                type="button"
                onClick={() => setIsDiscountModalOpen(false)}
                className="flex-1 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition shadow-md shadow-blue-600/20"
              >
                تطبيق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
