import React, { useState } from 'react';
import { FileItem } from '../types';
import { FileCode, FileText, Eye, Pin, X } from 'lucide-react';

interface TabBarProps {
  openTabs: string[];
  activeTabId: string | null;
  files: FileItem[];
  pinnedTabs: string[];
  onSelectTab: (id: string) => void;
  onCloseTab: (id: string) => void;
  onPinTab: (id: string) => void;
  onReorderTabs: (newTabs: string[]) => void;
}

export const TabBar: React.FC<TabBarProps> = ({
  openTabs,
  activeTabId,
  files,
  pinnedTabs,
  onSelectTab,
  onCloseTab,
  onPinTab,
  onReorderTabs,
}) => {
  const [draggedTab, setDraggedTab] = useState<string | null>(null);

  const handleDragStart = (e: React.DragEvent, id: string) => {
    setDraggedTab(id);
    e.dataTransfer.setData('text/plain', id);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    const sourceId = e.dataTransfer.getData('text/plain') || draggedTab;
    if (!sourceId || sourceId === targetId) return;

    const sourceIdx = openTabs.indexOf(sourceId);
    const targetIdx = openTabs.indexOf(targetId);
    if (sourceIdx === -1 || targetIdx === -1) return;

    const updated = [...openTabs];
    const [moved] = updated.splice(sourceIdx, 1);
    updated.splice(targetIdx, 0, moved);

    onReorderTabs(updated);
    setDraggedTab(null);
  };

  const getTabLabel = (id: string) => {
    if (id === '__PREVIEW__') return 'Preview 👁';
    const file = files.find((f) => f.id === id);
    return file?.name || 'Untitled';
  };

  const getTabIcon = (id: string) => {
    if (id === '__PREVIEW__') {
      return <Eye className="w-3.5 h-3.5 text-[#359efe] shrink-0" />;
    }
    const file = files.find((f) => f.id === id);
    const ext = file?.name.split('.').pop()?.toLowerCase() || '';
    if (ext === 'html') return <FileCode className="w-3.5 h-3.5 text-orange-400 shrink-0" />;
    if (ext === 'css') return <FileText className="w-3.5 h-3.5 text-blue-400 shrink-0" />;
    return <FileCode className="w-3.5 h-3.5 text-[#359efe] shrink-0" />;
  };

  const uniqueOpenTabs = Array.from(new Set(openTabs));

  return (
    <div className="h-9 bg-[#181920] border-b border-[#262833] flex items-center justify-between px-2 shrink-0 select-none overflow-x-auto no-scrollbar">
      {/* Draggable Tab Items */}
      <div className="flex items-center space-x-0.5 overflow-x-auto no-scrollbar">
        {uniqueOpenTabs.map((tabId) => {
          const isActive = activeTabId === tabId;
          const isPinned = pinnedTabs.includes(tabId);
          const isPreview = tabId === '__PREVIEW__';

          return (
            <div
              key={tabId}
              draggable={true}
              onDragStart={(e) => handleDragStart(e, tabId)}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, tabId)}
              onClick={() => onSelectTab(tabId)}
              onMouseDown={(e) => {
                if (e.button === 1) {
                  e.stopPropagation();
                  onCloseTab(tabId);
                }
              }}
              className={`flex items-center space-x-2 px-3 py-1.5 text-xs font-mono border-r border-[#262833] cursor-grab active:cursor-grabbing transition-colors shrink-0 group select-none ${
                isActive
                  ? 'bg-[#1c1d24] text-slate-100 font-semibold border-t-2 border-t-[#359efe]'
                  : 'bg-[#14151b] text-slate-400 hover:text-slate-200 hover:bg-[#191b22]'
              } ${draggedTab === tabId ? 'opacity-50' : ''}`}
            >
              {getTabIcon(tabId)}
              <span className="truncate max-w-[130px]">{getTabLabel(tabId)}</span>

              {/* Pin button */}
              {!isPreview && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onPinTab(tabId);
                  }}
                  className={`p-0.5 hover:text-white transition-opacity ${
                    isPinned ? 'text-amber-400 opacity-100' : 'opacity-0 group-hover:opacity-60'
                  }`}
                  title={isPinned ? 'Unpin Tab' : 'Pin Tab'}
                >
                  <Pin className="w-3 h-3" />
                </button>
              )}

              {/* Close button */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseTab(tabId);
                }}
                className="p-0.5 rounded text-slate-400 hover:text-red-400 hover:bg-[#2e3140] transition-all cursor-pointer"
                title="Close Tab"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Right Dropdown File Selector */}
      <div className="flex items-center space-x-1.5 shrink-0 pl-2 pr-1 border-l theme-border">
        <FileCode className="w-3.5 h-3.5 text-[#359efe] shrink-0" />
        <select
          value={activeTabId || ''}
          onChange={(e) => {
            if (e.target.value) onSelectTab(e.target.value);
          }}
          className="bg-transparent text-xs font-mono font-semibold theme-text-main outline-none cursor-pointer max-w-[160px] truncate hover:opacity-80"
          title="Select file from dropdown list"
        >
          <optgroup label="Opened / Active">
            {openTabs.map((tid) => (
              <option key={tid} value={tid} className="theme-bg-main theme-text-main">
                {tid === '__PREVIEW__' ? '👁 Live Preview' : getTabLabel(tid)}
              </option>
            ))}
          </optgroup>
          <optgroup label="All Workspace Files">
            {files
              .filter((f) => !f.isFolder)
              .map((f) => (
                <option key={f.id} value={f.id} className="theme-bg-main theme-text-main">
                  {f.name}
                </option>
              ))}
          </optgroup>
        </select>
      </div>
    </div>
  );
};
