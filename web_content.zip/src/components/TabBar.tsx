"use client";
import type { Tab } from "@/lib/store";
import { Favicon, Icon, IconButton } from "./ui";

export function TabBar({
  tabs,
  activeId,
  onSelect,
  onClose,
  onNew,
  onNewIncognito,
}: {
  tabs: Tab[];
  activeId: string;
  onSelect: (id: string) => void;
  onClose: (id: string) => void;
  onNew: () => void;
  onNewIncognito: () => void;
}) {
  return (
    <div className="flex h-9 items-end gap-0.5 overflow-x-auto px-1 no-scrollbar">
      {tabs.map((t) => {
        const active = t.id === activeId;
        return (
          <div
            key={t.id}
            role="tab"
            aria-selected={active}
            onClick={() => onSelect(t.id)}
            onAuxClick={(e) => e.button === 1 && onClose(t.id)}
            className={`group relative flex h-8 min-w-[110px] max-w-[200px] flex-1 cursor-pointer select-none items-center gap-2 rounded-t-xl px-3 text-xs transition
              ${active ? "bg-white shadow-sm dark:bg-white/10" : "text-slate-500 hover:bg-black/5 dark:text-slate-400 dark:hover:bg-white/5"}
              ${t.incognito ? "italic" : ""}`}
            title={t.url}
          >
            {t.loading ? (
              <span className="h-3.5 w-3.5 shrink-0 animate-spin rounded-full border-2 border-slate-300 border-t-[var(--accent)]" />
            ) : t.incognito ? (
              <Icon name="incognito" size={14} className="shrink-0 text-violet-500" />
            ) : (
              <Favicon src={t.favicon} title={t.title} size={14} />
            )}
            <span className={`min-w-0 flex-1 truncate ${t.sleeping ? "opacity-50" : ""}`}>{t.title || "Новая вкладка"}</span>
            <button
              type="button"
              aria-label="Закрыть вкладку"
              onClick={(e) => {
                e.stopPropagation();
                onClose(t.id);
              }}
              className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/20 ${active ? "" : "opacity-0 group-hover:opacity-100"}`}
            >
              <Icon name="close" size={11} />
            </button>
          </div>
        );
      })}
      <IconButton icon="plus" label="Новая вкладка (Ctrl+T)" onClick={onNew} className="!h-8 !w-8" size={16} />
      <IconButton icon="incognito" label="Новая приватная вкладка" onClick={onNewIncognito} className="!h-8 !w-8 hidden sm:inline-flex" size={16} />
    </div>
  );
}
