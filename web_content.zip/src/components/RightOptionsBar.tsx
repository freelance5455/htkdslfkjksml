import React, { useState } from 'react';
import {
  X,
  SlidersHorizontal,
  Bot,
  Gamepad2,
  BarChart3,
  Smartphone,
  Volume2,
  VolumeX,
  Sun,
  Moon,
  Flame,
  Zap,
  RotateCcw,
  BookOpen,
  User,
  Download,
  Check,
  ChevronRight,
  Sparkles,
  Shield,
  Layers,
  ArrowRight
} from 'lucide-react';
import { UserProfile, UserProgressData } from '../types';
import { sound } from '../services/sound';

export interface HeaderCustomization {
  showGame: boolean;
  showChat: boolean;
  showAnalytics: boolean;
  showApk: boolean;
  showSound: boolean;
  showTheme: boolean;
}

interface RightOptionsBarProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  progress: UserProgressData;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onToggleTheme: () => void;
  onOpenProfile: () => void;
  onOpenGame: () => void;
  onOpenChat: () => void;
  onOpenStreak: () => void;
  onOpenAnalytics: () => void;
  onOpenApkModal: () => void;
  onOpenBlitz: () => void;
  onOpenSrsDrill: () => void;
  onExportBackup?: () => void;
  headerConfig: HeaderCustomization;
  onUpdateHeaderConfig: (newConfig: HeaderCustomization) => void;
}

export const RightOptionsBar: React.FC<RightOptionsBarProps> = ({
  isOpen,
  onClose,
  profile,
  progress,
  soundEnabled,
  onToggleSound,
  onToggleTheme,
  onOpenProfile,
  onOpenGame,
  onOpenChat,
  onOpenStreak,
  onOpenAnalytics,
  onOpenApkModal,
  onOpenBlitz,
  onOpenSrsDrill,
  onExportBackup,
  headerConfig,
  onUpdateHeaderConfig,
}) => {
  const [showConfigSettings, setShowConfigSettings] = useState(false);

  if (!isOpen) return null;

  const avatarLetter = (profile.name?.charAt(0) || 'A').toUpperCase();

  const toggleHeaderOption = (key: keyof HeaderCustomization) => {
    const updated = { ...headerConfig, [key]: !headerConfig[key] };
    onUpdateHeaderConfig(updated);
    sound.flip();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-in fade-in duration-200">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity"
        aria-hidden="true"
      />

      {/* Right Drawer Panel */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div
          className="w-screen max-w-sm sm:max-w-md bg-white dark:bg-[#0f172a] border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col h-full transform transition-all ease-in-out duration-300 animate-in slide-in-from-right text-slate-800 dark:text-slate-100"
          role="dialog"
          aria-modal="true"
          aria-labelledby="right-bar-title"
        >
          {/* Drawer Header */}
          <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-900/50">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black shadow-sm">
                <SlidersHorizontal className="w-4 h-4" />
              </div>
              <div>
                <h2 id="right-bar-title" className="text-sm sm:text-base font-black text-slate-900 dark:text-white leading-tight">
                  Quick Tools & Options
                </h2>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Adjustable actions and tools
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-all cursor-pointer"
              aria-label="Close Options Menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Body - Scrollable */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 smooth-scroll text-left">
            
            {/* User Mini Profile Card */}
            <div
              onClick={() => {
                onClose();
                onOpenProfile();
              }}
              className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800/80 dark:to-slate-800/40 border border-slate-200 dark:border-slate-700/80 hover:border-emerald-500 transition-all cursor-pointer group flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 text-white font-black text-base flex items-center justify-center shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform shrink-0">
                  {avatarLetter}
                </div>
                <div>
                  <div className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                    <span>{profile.name}</span>
                    <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                      Active
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate max-w-[180px]">
                    {profile.targetExam}
                  </p>
                  <div className="flex items-center gap-2 mt-1 text-[11px] font-bold">
                    <span className="text-amber-600 dark:text-amber-400 flex items-center gap-0.5">
                      <Flame className="w-3 h-3 fill-current" /> {profile.streak} Days
                    </span>
                    <span className="text-slate-300 dark:text-slate-700">·</span>
                    <span className="text-blue-600 dark:text-blue-400 flex items-center gap-0.5">
                      <Zap className="w-3 h-3 fill-current" /> {profile.xp} XP
                    </span>
                  </div>
                </div>
              </div>

              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-500 group-hover:translate-x-0.5 transition-all" />
            </div>

            {/* Quick Modes & Interactive Learning Tools */}
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 px-1 block">
                Modes & Study Accelerators
              </span>

              <div className="grid grid-cols-1 gap-2">
                
                {/* 1. Mastery & Review Analytics */}
                <button
                  onClick={() => {
                    onClose();
                    onOpenAnalytics();
                  }}
                  className="w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 hover:border-blue-400 hover:bg-blue-50/40 dark:hover:bg-blue-950/20 transition-all flex items-center justify-between text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <BarChart3 className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                        Mastery & Review Analytics
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">
                        {progress.mastered.length} Mastered · Words to Review Queue
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-all" />
                </button>

                {/* 2. Professor Cadre AI Mentor */}
                <button
                  onClick={() => {
                    onClose();
                    onOpenChat();
                  }}
                  className="w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 hover:border-indigo-400 hover:bg-indigo-50/40 dark:hover:bg-indigo-950/20 transition-all flex items-center justify-between text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <Bot className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                        Professor Cadre AI Mentor
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">
                        Gemini Flash Lexical Grounding & Dialogue
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-all" />
                </button>

                {/* 3. Cadre Runner 3D Arena */}
                <button
                  onClick={() => {
                    onClose();
                    onOpenGame();
                  }}
                  className="w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 hover:border-purple-400 hover:bg-purple-50/40 dark:hover:bg-purple-950/20 transition-all flex items-center justify-between text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <Gamepad2 className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                        Cadre Runner 3D Arena
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">
                        Interactive Three.js Vocabulary Sprint Game
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-all" />
                </button>

                {/* 4. Word Blitz 30s Rapid Match */}
                <button
                  onClick={() => {
                    onClose();
                    onOpenBlitz();
                  }}
                  className="w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 hover:border-amber-400 hover:bg-amber-50/40 dark:hover:bg-amber-950/20 transition-all flex items-center justify-between text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900 dark:text-white group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
                        Word Blitz (30-Sec Match)
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">
                        Fast-paced Bengali & English pair matching
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-all" />
                </button>

                {/* 5. Ebbinghaus Spaced Repetition Drill */}
                <button
                  onClick={() => {
                    onClose();
                    onOpenSrsDrill();
                  }}
                  className="w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 hover:border-teal-400 hover:bg-teal-50/40 dark:hover:bg-teal-950/20 transition-all flex items-center justify-between text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-teal-100 dark:bg-teal-950 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <RotateCcw className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                        Ebbinghaus Spaced Drill
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">
                        Memory consolidation & forgetting curve review
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-all" />
                </button>

                {/* 6. Daily Streak & Calendar */}
                <button
                  onClick={() => {
                    onClose();
                    onOpenStreak();
                  }}
                  className="w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 hover:border-orange-400 hover:bg-orange-50/40 dark:hover:bg-orange-950/20 transition-all flex items-center justify-between text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-orange-100 dark:bg-orange-950 text-orange-600 dark:text-orange-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      <Flame className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900 dark:text-white group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors">
                        Daily Streak & Freezes
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">
                        {profile.streak} Day Record · {profile.streakFreezes ?? 2} Freezes Armed
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-all" />
                </button>

              </div>
            </div>

            {/* Quick Device Toggles */}
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 px-1 block">
                Quick Preferences
              </span>

              <div className="grid grid-cols-2 gap-2">
                {/* Audio Toggle */}
                <button
                  onClick={() => {
                    onToggleSound();
                    sound.flip();
                  }}
                  className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 hover:border-slate-300 dark:hover:border-slate-600 flex flex-col justify-between text-left transition-all cursor-pointer"
                >
                  <div className="flex items-center justify-between w-full mb-1">
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Audio FX
                    </span>
                    {soundEnabled ? (
                      <Volume2 className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <VolumeX className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium">
                    {soundEnabled ? 'Enabled' : 'Muted'}
                  </span>
                </button>

                {/* Night Mode Toggle */}
                <button
                  onClick={() => {
                    onToggleTheme();
                    sound.flip();
                  }}
                  className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 hover:border-slate-300 dark:hover:border-slate-600 flex flex-col justify-between text-left transition-all cursor-pointer"
                >
                  <div className="flex items-center justify-between w-full mb-1">
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Appearance
                    </span>
                    {profile.theme === 'dark' ? (
                      <Moon className="w-4 h-4 text-amber-400" />
                    ) : (
                      <Sun className="w-4 h-4 text-amber-500" />
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium capitalize">
                    {profile.theme || 'Light'} Mode
                  </span>
                </button>
              </div>

              {/* Install Android APK Banner */}
              <button
                onClick={() => {
                  onClose();
                  onOpenApkModal();
                }}
                className="w-full p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/70 hover:border-emerald-400 transition-all flex items-center justify-between text-left group cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-black text-emerald-950 dark:text-emerald-200">
                      Download & Install Android APK
                    </div>
                    <div className="text-[10px] text-emerald-700/80 dark:text-emerald-300/80">
                      100% Offline Google WebAPK package
                    </div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-emerald-600 dark:text-emerald-400 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>

            {/* Adjustable Header Layout Preferences */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3">
              <button
                onClick={() => setShowConfigSettings(!showConfigSettings)}
                className="w-full flex items-center justify-between text-left cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-500" />
                  <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
                    Adjust Top Header Bar
                  </span>
                </div>
                <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400">
                  {showConfigSettings ? 'Hide' : 'Customize'}
                </span>
              </button>

              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                Control which quick buttons appear in the top bar vs keeping them tucked away here.
              </p>

              {showConfigSettings && (
                <div className="space-y-2 pt-1 border-t border-slate-200 dark:border-slate-700 animate-in fade-in">
                  
                  {[
                    { key: 'showGame' as const, label: '3D Cadre Runner', icon: Gamepad2 },
                    { key: 'showChat' as const, label: 'Professor Cadre AI', icon: Bot },
                    { key: 'showAnalytics' as const, label: 'Mastery Analytics', icon: BarChart3 },
                    { key: 'showApk' as const, label: 'Android APK Center', icon: Smartphone },
                    { key: 'showSound' as const, label: 'Sound FX Toggle', icon: Volume2 },
                    { key: 'showTheme' as const, label: 'Night/Light Toggle', icon: Sun },
                  ].map((item) => {
                    const isChecked = !!headerConfig[item.key];
                    const Icon = item.icon;

                    return (
                      <div
                        key={item.key}
                        onClick={() => toggleHeaderOption(item.key)}
                        className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700/60 cursor-pointer transition-all"
                      >
                        <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                          <Icon className="w-3.5 h-3.5 text-slate-400" />
                          <span>{item.label}</span>
                        </div>
                        <div
                          className={`w-5 h-5 rounded-md flex items-center justify-center transition-all ${
                            isChecked
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-200 dark:bg-slate-700 text-transparent'
                          }`}
                        >
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      </div>
                    );
                  })}

                  <div className="pt-1 text-[10px] text-slate-400 text-right">
                    Saved automatically to local device
                  </div>
                </div>
              )}
            </div>

            {/* Quiet Footer */}
            <div className="pt-2 text-center text-[10px] text-slate-400 dark:text-slate-500 space-y-1">
              <div>VocabMuse Cognitive Lexical Hub</div>
              <div>By Md. Jahid Hasan, SUST · Offline PWA</div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
