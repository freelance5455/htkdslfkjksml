import React, { useState } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import {
  ClimbingStyle,
  ClimbOutcome,
  WallAngle,
  BOULDERING_GRADES,
  ROPED_GRADES,
  ClimbEntry
} from '../types/climbing';
import {
  PlusCircle,
  Building,
  CheckCircle2,
  Calendar,
  Compass,
  FileText,
  Layers,
  ArrowLeft
} from 'lucide-react';
import { ClubManagerModal } from './ClubManagerModal';

interface ClimbLogFormProps {
  onClimbLogged?: (climb: ClimbEntry) => void;
  onNavigateToDashboard?: () => void;
  onNavigateToHistory?: () => void;
}

export const ClimbLogForm: React.FC<ClimbLogFormProps> = ({
  onClimbLogged,
  onNavigateToDashboard,
  onNavigateToHistory
}) => {
  const { clubs, addClimb, profile } = useClimbing();

  // Form State
  const [date, setDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [routeName, setRouteName] = useState<string>('');
  const [style, setStyle] = useState<ClimbingStyle>('Top Rope');
  const [grade, setGrade] = useState<string>('6a');
  const [wallAngle, setWallAngle] = useState<WallAngle>('Vertical');
  const [outcome, setOutcome] = useState<ClimbOutcome>('Redpoint');
  const [clubId, setClubId] = useState<string>(() => clubs[0]?.id || 'club-castle-london');
  const [notes, setNotes] = useState<string>('');
  const [attemptsCount, setAttemptsCount] = useState<number>(1);

  // UI state
  const [isClubModalOpen, setIsClubModalOpen] = useState(false);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);

  // Update grade options when style changes
  const handleStyleChange = (newStyle: ClimbingStyle) => {
    setStyle(newStyle);
    if (newStyle === 'Bouldering') {
      if (!BOULDERING_GRADES.includes(grade as any)) {
        setGrade('V3');
      }
    } else {
      if (!ROPED_GRADES.includes(grade as any)) {
        setGrade('6a');
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!routeName.trim()) return;

    const newClimb = addClimb({
      date,
      routeName: routeName.trim(),
      style,
      grade,
      wallAngle,
      outcome,
      clubId,
      notes: notes.trim(),
      attemptsCount
    });

    if (onClimbLogged) {
      onClimbLogged(newClimb);
    }

    // Show brief popup message for exactly 1 second, then navigate back to dashboard
    setShowSuccessPopup(true);

    setTimeout(() => {
      setShowSuccessPopup(false);
      if (onNavigateToDashboard) {
        onNavigateToDashboard();
      }
    }, 1000);
  };

  const selectedClub = clubs.find(c => c.id === clubId);

  return (
    <div className="max-w-3xl mx-auto space-y-4 w-full max-w-full overflow-hidden relative">
      {/* 1-Second Success Popup Modal */}
      {showSuccessPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-emerald-500 rounded-2xl p-6 shadow-2xl flex flex-col items-center justify-center text-center space-y-3 max-w-xs w-full animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-7 h-7 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                Climb successfully logged
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono">
                Returning to Dashboard...
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Main Logging Card */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        {/* Card Header */}
        <div className="px-4 sm:px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {onNavigateToDashboard && (
              <button
                type="button"
                onClick={onNavigateToDashboard}
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                title="Back to Dashboard"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <span className="text-[11px] font-semibold text-orange-600 uppercase tracking-wider">Candidate Logbook</span>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">Log Indoor Ascent</h2>
            </div>
          </div>
          {profile.candidateName && (
            <div className="text-xs text-slate-500 dark:text-slate-400 font-mono hidden sm:block">
              Climber: <span className="font-semibold text-slate-700 dark:text-slate-300">{profile.candidateName}</span>
            </div>
          )}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5">
          {/* Section 1: Session & Route Context */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Date */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Date of Ascent *</span>
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono text-slate-900 dark:text-white"
              />
            </div>

            {/* Route Name */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-slate-400" />
                <span>Route Name / Bouldering Problem *</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Purple Arête, Orange Wave, Boulder #12"
                value={routeName}
                onChange={e => setRouteName(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Section 2: Club / Location with Database Lookup */}
          <div className="p-3.5 sm:p-4 bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5 text-orange-600" />
                <span>Climbing Centre / Club Location *</span>
              </label>
              <button
                type="button"
                onClick={() => setIsClubModalOpen(true)}
                className="text-[11px] font-semibold text-orange-600 dark:text-orange-400 hover:underline"
              >
                + Add / Manage Centres
              </button>
            </div>

            <select
              aria-label="Select Climbing Centre"
              value={clubId}
              onChange={e => setClubId(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium text-slate-800 dark:text-slate-200"
            >
              {clubs.map(club => (
                <option key={club.id} value={club.id}>
                  {club.name} {club.location ? `(${club.location.split(',')[0]})` : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Section 3: Style & Grade */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Style Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Climbing Style *</label>
              <div className="grid grid-cols-2 gap-1.5">
                {(['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'] as ClimbingStyle[]).map(s => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => handleStyleChange(s)}
                    className={`py-2 px-2 text-xs font-semibold rounded-lg border text-center transition-all ${
                      style === s
                        ? 'bg-orange-600 text-white border-orange-600 shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Grade Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                <span>Grade ({style === 'Bouldering' ? 'V-Scale' : 'French Sport'}) *</span>
                <span className="text-[11px] text-slate-500 font-mono">Current: {grade}</span>
              </label>
              <select
                aria-label="Select Grade"
                value={grade}
                onChange={e => setGrade(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono font-bold text-slate-900 dark:text-white"
              >
                {style === 'Bouldering' ? (
                  BOULDERING_GRADES.map(g => (
                    <option key={g} value={g}>{g}</option>
                  ))
                ) : (
                  ROPED_GRADES.map(g => (
                    <option key={g} value={g}>{g}</option>
                  ))
                )}
              </select>
            </div>
          </div>

          {/* Section 4: Wall Angle & Outcome */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Wall Angle */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-slate-400" />
                <span>Wall Angle *</span>
              </label>
              <div className="grid grid-cols-4 gap-1">
                {(['Slab', 'Vertical', 'Overhang', 'Roof'] as WallAngle[]).map(angle => (
                  <button
                    key={angle}
                    type="button"
                    onClick={() => setWallAngle(angle)}
                    className={`py-2 px-1 text-[11px] font-semibold rounded-lg border text-center transition-all ${
                      wallAngle === angle
                        ? 'bg-orange-600 text-white border-orange-600 shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {angle}
                  </button>
                ))}
              </div>
            </div>

            {/* Outcome */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Outcome *</label>
              <div className="grid grid-cols-4 gap-1">
                {(['Onsite', 'Flash', 'Redpoint', 'Attempt'] as ClimbOutcome[]).map(out => (
                  <button
                    key={out}
                    type="button"
                    onClick={() => setOutcome(out)}
                    className={`py-2 px-1 text-[11px] font-semibold rounded-lg border text-center transition-all ${
                      outcome === out
                        ? out === 'Onsite'
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : out === 'Flash'
                          ? 'bg-orange-600 text-white border-orange-600'
                          : out === 'Redpoint'
                          ? 'bg-amber-600 text-white border-amber-600'
                          : 'bg-slate-700 text-white border-slate-700'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {out}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Section 5: Attempts & Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Attempts</label>
              <input
                type="number"
                min="1"
                max="50"
                value={attemptsCount}
                onChange={e => setAttemptsCount(Math.max(1, parseInt(e.target.value, 10) || 1))}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono tabular-nums text-slate-900 dark:text-white"
              />
            </div>

            <div className="sm:col-span-2 space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-slate-400" />
                <span>Notes, Beta & Personal Reflections</span>
              </label>
              <textarea
                rows={2}
                placeholder="Key moves, footwork beta, tactical rests, instructor feedback..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
            {onNavigateToDashboard && (
              <button
                type="button"
                onClick={onNavigateToDashboard}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-xl shadow-xs transition-colors cursor-pointer ml-auto"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Log Climb</span>
            </button>
          </div>
        </form>
      </div>

      {/* Club Manager Modal */}
      <ClubManagerModal
        isOpen={isClubModalOpen}
        onClose={() => setIsClubModalOpen(false)}
        onSelectClub={id => setClubId(id)}
      />
    </div>
  );
};
