import React, { useState } from 'react';
import { ClassInfo, Language, Student } from '../types';
import { translations } from '../utils/translations';
import {
  Award,
  GraduationCap,
  Calendar,
  Clock,
  Printer,
  Sparkles,
  ShieldCheck,
  Star,
  Download
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface GraduatesViewProps {
  students: Student[];
  classes: ClassInfo[];
  lang: Language;
}

export const GraduatesView: React.FC<GraduatesViewProps> = ({
  students,
  classes,
  lang,
}) => {
  const t = translations[lang];

  const classMap = new Map<string, ClassInfo>();
  classes.forEach((c) => classMap.set(c.id, c));

  const graduates = students.filter((s) => s.isGraduated);
  const [selectedStudentForCert, setSelectedStudentForCert] = useState<Student | null>(null);

  const handleOpenCertificate = (student: Student) => {
    setSelectedStudentForCert(student);
    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.5 }
    });
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-600 via-emerald-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-black text-amber-300 bg-amber-400/20 px-3 py-1 rounded-full mb-2 border border-amber-400/40">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Alumni Hall of Fame & Advanced Diploma Graduates</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            {t.navGraduates} - Rahbar English Center
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            {lang === 'ps'
              ? 'هغه ویاړلي زده کوونکي چې د رهبر انګلیسي مرکز څخه فارغ شوي دي، د فراغت دقیق نېټه او وخت یې دلته درج شوی او رسمي سند ورکول کیږي.'
              : lang === 'ur'
              ? 'رہبر انگلش سینٹر سے فارغ التحصیل طلباء کی مکمل تفصیلات: فراغت کی تاریخ اور مقررہ وقت کے ساتھ مستند تعلیمی اسناد۔'
              : 'Honoring students who successfully completed their English diploma. Graduation date and precise ceremony time are officially recorded.'}
          </p>
        </div>

        <div className="bg-slate-900/80 backdrop-blur px-5 py-3 rounded-2xl border border-amber-400/30 text-center shrink-0">
          <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider block">
            {t.graduatedAlumni}
          </span>
          <span className="text-3xl font-black text-white">
            {graduates.length}
          </span>
        </div>
      </div>

      {/* Graduates Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {graduates.length === 0 ? (
          <div className="col-span-full bg-white p-12 text-center rounded-3xl border border-slate-200">
            <GraduationCap className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-700">No graduated students recorded yet</h3>
            <p className="text-xs text-slate-500 mt-1">You can graduate students from the Student Directory tab.</p>
          </div>
        ) : (
          graduates.map((grad) => {
            const gradClass = classMap.get(grad.classId);
            return (
              <div
                key={grad.id}
                className="bg-white rounded-3xl border border-amber-200 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col justify-between group relative"
              >
                {/* Gold Top Accent */}
                <div className="h-2 bg-gradient-to-r from-amber-400 via-emerald-600 to-amber-500" />

                <div className="p-6 space-y-4">
                  {/* Photo & Badge */}
                  <div className="flex items-start gap-4">
                    <div className="relative">
                      <img
                        src={grad.photoUrl}
                        alt={grad.name}
                        className="w-16 h-16 rounded-2xl object-cover ring-2 ring-amber-400 shadow-md bg-slate-100"
                      />
                      <span className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 p-1 rounded-full shadow">
                        <GraduationCap className="w-3.5 h-3.5" />
                      </span>
                    </div>

                    <div className="flex-1 min-w-0">
                      <span className="text-[11px] font-extrabold text-emerald-700 uppercase tracking-wider block truncate">
                        {gradClass?.nameEn || 'Senior Advanced Diploma'}
                      </span>
                      <h3 className="text-base font-black text-slate-900 truncate">
                        {grad.name}
                      </h3>
                      <p className="text-xs text-slate-500 truncate">
                        {t.fatherName}: {grad.fatherName}
                      </p>

                      {grad.position && grad.position !== 'None' && (
                        <div className="mt-1 inline-flex items-center gap-1 bg-amber-50 text-amber-900 border border-amber-300 px-2 py-0.5 rounded-lg text-[10px] font-extrabold">
                          <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                          <span>{grad.position}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Date and Time Box */}
                  <div className="bg-amber-50/70 border border-amber-200/80 p-3 rounded-2xl space-y-1.5 text-xs text-amber-950">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-slate-600 font-semibold">
                        <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                        {t.graduationDate}:
                      </span>
                      <span className="font-extrabold text-slate-900">{grad.graduationDate || '2026-10-28'}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-slate-600 font-semibold">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        {t.graduationTime}:
                      </span>
                      <span className="font-extrabold text-slate-900">{grad.graduationTime || '11:30 AM'}</span>
                    </div>
                  </div>

                  {grad.graduationRemarks && (
                    <p className="text-[11px] text-slate-600 italic bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      "{grad.graduationRemarks}"
                    </p>
                  )}
                </div>

                {/* Footer Action */}
                <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-400">
                    Verified by Rahbar Center
                  </span>

                  <button
                    onClick={() => handleOpenCertificate(grad)}
                    className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs transition shadow-sm"
                  >
                    <Award className="w-3.5 h-3.5" />
                    <span>{t.viewCertificate}</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Official Graduation Certificate Modal (Printable) */}
      {selectedStudentForCert && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-8 shadow-2xl border-4 border-amber-400 my-8 space-y-6 text-slate-900 relative">
            <div className="no-print absolute top-4 right-4 flex items-center gap-2">
              <button
                onClick={() => window.print()}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-xl text-xs shadow flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Certificate</span>
              </button>
              <button
                onClick={() => setSelectedStudentForCert(null)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold p-1"
              >
                ✕
              </button>
            </div>

            {/* Certificate Header */}
            <div className="text-center space-y-2 border-b-2 border-amber-300 pb-5">
              <div className="inline-block bg-amber-100 text-amber-900 border border-amber-300 px-4 py-1 rounded-full text-xs font-black tracking-widest uppercase">
                Certificate of Graduation & Distinction
              </div>
              <h2 className="text-3xl font-black text-emerald-900 tracking-wide uppercase">
                RAHBAR ENGLISH CENTER
              </h2>
              <p className="text-xs font-bold text-slate-600 tracking-widest uppercase">
                Trat, Pishin, Balochistan, Pakistan
              </p>
            </div>

            {/* Certificate Body */}
            <div className="text-center space-y-4 py-4">
              <p className="text-xs text-slate-500 uppercase tracking-widest font-semibold">
                This is to officially certify that
              </p>

              <div className="flex flex-col items-center justify-center gap-2">
                <img
                  src={selectedStudentForCert.photoUrl}
                  alt={selectedStudentForCert.name}
                  className="w-20 h-20 rounded-2xl object-cover ring-4 ring-amber-400 shadow-md"
                />
                <h3 className="text-2xl font-black text-slate-900 tracking-tight underline decoration-amber-400 decoration-2 underline-offset-4">
                  {selectedStudentForCert.name}
                </h3>
                <p className="text-xs font-bold text-slate-600">
                  Son / Daughter of: <strong>{selectedStudentForCert.fatherName}</strong>
                </p>
              </div>

              <p className="text-xs text-slate-700 max-w-lg mx-auto leading-relaxed">
                has successfully completed the comprehensive English Language & Grammar Diploma at{' '}
                <strong>Rahbar English Center</strong> with exemplary conduct, dedication, and speaking proficiency.
              </p>

              {selectedStudentForCert.position && selectedStudentForCert.position !== 'None' && (
                <div className="inline-flex items-center gap-1.5 bg-amber-50 border border-amber-300 px-4 py-1 rounded-xl text-xs font-black text-amber-900">
                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span>Awarded: {selectedStudentForCert.position}</span>
                </div>
              )}

              {/* Date and Time Record */}
              <div className="grid grid-cols-2 gap-4 max-w-md mx-auto bg-slate-50 p-3 rounded-2xl border border-slate-200 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">
                    Graduation Date
                  </span>
                  <span className="font-extrabold text-slate-900">
                    {selectedStudentForCert.graduationDate || '2026-10-28'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">
                    Graduation Ceremony Time
                  </span>
                  <span className="font-extrabold text-slate-900">
                    {selectedStudentForCert.graduationTime || '11:30 AM'}
                  </span>
                </div>
              </div>
            </div>

            {/* Signatures */}
            <div className="pt-8 border-t-2 border-amber-300 flex justify-between items-end text-xs font-bold text-slate-800">
              <div className="text-center">
                <div className="w-36 border-b border-slate-900 mb-1" />
                <span>Senior Instructor</span>
              </div>

              <div className="w-16 h-16 rounded-full border-2 border-amber-500 bg-amber-50 flex items-center justify-center text-[10px] text-amber-900 font-black text-center p-1 leading-tight shadow-sm">
                OFFICIAL SEAL
              </div>

              <div className="text-center">
                <div className="w-36 border-b border-slate-900 mb-1" />
                <span>Sir Habibullah Rahbar<br /><span className="text-[10px] text-slate-500 font-normal">Director, Rahbar English Center</span></span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
