import React, { useState, useRef, useEffect } from 'react';
import { Voice } from '../types/voice';
import {
  X,
  Fingerprint,
  Mic,
  Square,
  Play,
  Pause,
  Upload,
  CheckCircle2,
  Sparkles,
  Volume2,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import { formatTime } from '../utils/audioSynthesizer';

interface VoiceCloningModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVoiceCloned: (clonedVoice: Voice) => void;
}

export const VoiceCloningModal: React.FC<VoiceCloningModalProps> = ({
  isOpen,
  onClose,
  onVoiceCloned,
}) => {
  const [cloneName, setCloneName] = useState('');
  const [cloneGender, setCloneGender] = useState<'Male' | 'Female'>('Male');
  const [baseEngine, setBaseEngine] = useState<'Puck' | 'Kore' | 'Fenrir' | 'Zephyr'>('Puck');
  const [sampleMode, setSampleMode] = useState<'mic' | 'upload'>('mic');
  const [customStyle, setCustomStyle] = useState('Natural conversational Hindi accent with warm friendly cadence');

  // Mic recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [isPlayingRecorded, setIsPlayingRecorded] = useState(false);
  const [micVolume, setMicVolume] = useState(0);
  const [recordError, setRecordError] = useState<string | null>(null);

  // File upload state
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [isAnalyzingAudio, setIsAnalyzingAudio] = useState(false);
  const [analysisStats, setAnalysisStats] = useState<{
    pitchHz: number;
    timbre: string;
    clarity: string;
  } | null>(null);

  // Submitting state
  const [isCloning, setIsCloning] = useState(false);

  // Refs for audio handling
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const recordedAudioElRef = useRef<HTMLAudioElement | null>(null);

  // Reset when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      stopRecordingAndStream();
    }
  }, [isOpen]);

  const stopRecordingAndStream = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
    }
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((track) => track.stop());
      audioStreamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    setIsRecording(false);
  };

  const startMicRecording = async () => {
    setRecordError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;

      // Setup audio analyzer for volume meter
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const checkVolume = () => {
        if (!audioStreamRef.current) return;
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
        const avg = sum / dataArray.length;
        setMicVolume(Math.min(100, Math.round((avg / 128) * 100)));
        requestAnimationFrame(checkVolume);
      };
      checkVolume();

      // Setup recorder
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(audioBlob);
        setRecordedAudioUrl(url);
        // Run simulated acoustic analysis
        runAcousticAnalysis('Live Mic Recording');
      };

      mediaRecorder.start(200);
      setIsRecording(true);
      setRecordSeconds(0);

      timerRef.current = window.setInterval(() => {
        setRecordSeconds((prev) => {
          if (prev >= 15) {
            stopMicRecording();
            return 15;
          }
          return prev + 1;
        });
      }, 1000);
    } catch (err: any) {
      console.error('Mic access error:', err);
      setRecordError(err.message || 'Microphone access denied or unavailable.');
    }
  };

  const stopMicRecording = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((t) => t.stop());
      audioStreamRef.current = null;
    }
    setIsRecording(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    const fileUrl = URL.createObjectURL(file);
    setRecordedAudioUrl(fileUrl);
    runAcousticAnalysis(file.name);
  };

  const runAcousticAnalysis = (sourceLabel: string) => {
    setIsAnalyzingAudio(true);
    setAnalysisStats(null);
    setTimeout(() => {
      setIsAnalyzingAudio(false);
      setAnalysisStats({
        pitchHz: cloneGender === 'Female' ? 218 : 134,
        timbre: cloneGender === 'Female' ? 'Warm Bright Resonant' : 'Rich Low Baritone',
        clarity: '99.4%',
      });
    }, 900);
  };

  const togglePlaybackRecorded = () => {
    if (!recordedAudioUrl) return;
    if (!recordedAudioElRef.current) {
      const audio = new Audio(recordedAudioUrl);
      recordedAudioElRef.current = audio;
      audio.onended = () => setIsPlayingRecorded(false);
    }

    if (isPlayingRecorded) {
      recordedAudioElRef.current.pause();
      setIsPlayingRecorded(false);
    } else {
      recordedAudioElRef.current.play();
      setIsPlayingRecorded(true);
    }
  };

  const handleCreateClone = () => {
    if (!cloneName.trim()) {
      alert('Please enter a voice title / name');
      return;
    }

    setIsCloning(true);
    setTimeout(() => {
      const newVoice: Voice = {
        id: `cloned-${Date.now()}`,
        name: cloneName.trim(),
        gender: cloneGender,
        category: 'cloned',
        accent: 'Personal Custom Cloned Accent',
        language: 'Hindi, Hinglish & English',
        description: `Custom neural cloned voice. Style: ${customStyle}`,
        tag: '🧬 Cloned AI',
        avatarLetter: cloneName.trim().slice(0, 2).toUpperCase(),
        avatarBg: 'from-violet-600 via-purple-600 to-indigo-700',
        baseGeminiVoice: baseEngine,
        isCloned: true,
        clonedAudioUrl: recordedAudioUrl || undefined,
        clonedDirective: customStyle,
        samplePhrase: `नमस्ते, यह मेरी क्लोन की गई नई AI आवाज़ ${cloneName.trim()} है।`,
      };

      onVoiceCloned(newVoice);
      setIsCloning(false);
      onClose();
    }, 1200);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="glass-panel w-full max-w-xl rounded-2xl p-6 shadow-2xl border border-gray-800 flex flex-col gap-5 relative max-h-[90vh] overflow-y-auto custom-scrollbar">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white p-1 rounded-lg transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 border-b border-gray-800 pb-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-violet-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Fingerprint className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-base font-bold text-gray-100 flex items-center gap-2">
              AI Voice Cloning Studio
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-violet-950 text-violet-300 border border-violet-800/60">
                Cartesia Zero-Shot
              </span>
            </h3>
            <p className="text-xs text-gray-400">
              Apni aawaaz record karein ya sample upload karke instant clone karein
            </p>
          </div>
        </div>

        {/* Step 1: Voice Details */}
        <div className="flex flex-col gap-3">
          <div>
            <label className="block text-xs font-medium text-gray-300 mb-1">
              Clone Voice Title (Naam)
            </label>
            <input
              type="text"
              value={cloneName}
              onChange={(e) => setCloneName(e.target.value)}
              placeholder="e.g. My Personal Voice / Rahul's Voice / Meera"
              className="w-full bg-gray-900 border border-gray-700 rounded-xl px-3.5 py-2 text-sm text-gray-200 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-300 mb-1">
                Gender (लिंग)
              </label>
              <select
                value={cloneGender}
                onChange={(e) => {
                  const g = e.target.value as 'Male' | 'Female';
                  setCloneGender(g);
                  if (g === 'Female') setBaseEngine('Kore');
                  else setBaseEngine('Puck');
                }}
                className="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-sm text-gray-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="Male">Male (पुरुष)</option>
                <option value="Female">Female (महिला)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-300 mb-1">
                Target Base Engine
              </label>
              <select
                value={baseEngine}
                onChange={(e) => setBaseEngine(e.target.value as any)}
                className="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-sm text-gray-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="Puck">Rohan (Indian Male Base - Puck)</option>
                <option value="Kore">Ananya (Indian Female Base - Kore)</option>
                <option value="Fenrir">Kabir (Deep Baritone Base - Fenrir)</option>
                <option value="Zephyr">Diya (Soft Gentle Base - Zephyr)</option>
              </select>
            </div>
          </div>

          {/* Step 2: Audio Source (Mic vs Upload) */}
          <div className="pt-2">
            <label className="block text-xs font-medium text-gray-300 mb-2">
              Voice Sample Source (Bol kar ya file dekar aawaaz sikhayein)
            </label>

            <div className="grid grid-cols-2 gap-3">
              {/* Record Mic Button */}
              <button
                type="button"
                onClick={() => {
                  setSampleMode('mic');
                  if (!isRecording) startMicRecording();
                  else stopMicRecording();
                }}
                className={`p-4 rounded-xl border flex flex-col items-center gap-2 text-center transition cursor-pointer ${
                  sampleMode === 'mic'
                    ? 'bg-gray-900 border-indigo-500 ring-1 ring-indigo-500/40'
                    : 'bg-gray-900/60 border-gray-700 hover:border-gray-600'
                }`}
              >
                <div
                  className={`w-11 h-11 rounded-full flex items-center justify-center transition ${
                    isRecording
                      ? 'bg-red-950 text-red-400 border border-red-600 animate-pulse'
                      : 'bg-indigo-950 border border-indigo-800/60 text-indigo-400'
                  }`}
                >
                  {isRecording ? <Square className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </div>
                <div className="text-left flex flex-col items-center">
                  <span className="text-xs font-semibold text-gray-200">
                    {isRecording ? `Recording (${formatTime(recordSeconds)})` : 'Live Mic Record'}
                  </span>
                  <span className="text-[10px] text-gray-400">
                    {isRecording ? 'Click to Stop' : '(Bol kar sample dein)'}
                  </span>
                </div>
              </button>

              {/* File Upload Button */}
              <label
                className={`p-4 rounded-xl border flex flex-col items-center gap-2 text-center transition cursor-pointer ${
                  sampleMode === 'upload'
                    ? 'bg-gray-900 border-purple-500 ring-1 ring-purple-500/40'
                    : 'bg-gray-900/60 border-gray-700 hover:border-gray-600'
                }`}
              >
                <div className="w-11 h-11 rounded-full bg-purple-950 border border-purple-800/60 flex items-center justify-center text-purple-400">
                  <Upload className="w-5 h-5" />
                </div>
                <div className="text-left flex flex-col items-center">
                  <span className="text-xs font-semibold text-gray-200">Audio Upload</span>
                  <span className="text-[10px] text-gray-400">(.MP3, .WAV, .M4A)</span>
                </div>
                <input
                  type="file"
                  accept="audio/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Error Message if Mic fails */}
            {recordError && (
              <div className="mt-2 text-xs text-amber-400 bg-amber-950/40 border border-amber-800/50 p-2.5 rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{recordError} (You can also upload an audio file instead)</span>
              </div>
            )}

            {/* Live Volume Meter while recording */}
            {isRecording && (
              <div className="mt-3 bg-gray-900/90 p-3 rounded-xl border border-red-900/40 flex flex-col gap-2">
                <div className="flex justify-between text-xs text-gray-300">
                  <span className="flex items-center gap-1.5 text-red-400">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                    Recording Live Sample...
                  </span>
                  <span className="font-mono text-gray-400">{recordSeconds}/15s</span>
                </div>
                {/* Level Meter Bar */}
                <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 via-amber-500 to-red-500 transition-all duration-75"
                    style={{ width: `${Math.max(5, micVolume)}%` }}
                  />
                </div>
                <p className="text-[11px] text-gray-400 italic">
                  Suggested sample script: &quot;नमस्ते, यह मेरी असली आवाज़ है। मैं SonicVoice AI में अपना वॉइस क्लोन तैयार कर रहा हूँ।&quot;
                </p>
              </div>
            )}

            {/* Preview recorded/uploaded audio */}
            {recordedAudioUrl && !isRecording && (
              <div className="mt-3 bg-indigo-950/30 border border-indigo-800/40 p-3 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-indigo-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>
                    Audio sample ready: {uploadedFileName || `${recordSeconds}s mic capture`}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={togglePlaybackRecorded}
                  className="px-2.5 py-1 text-xs bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg flex items-center gap-1 cursor-pointer"
                >
                  {isPlayingRecorded ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                  <span>{isPlayingRecorded ? 'Pause' : 'Play Sample'}</span>
                </button>
              </div>
            )}

            {/* Acoustic Analysis Feedback */}
            {isAnalyzingAudio && (
              <div className="mt-2 text-xs text-indigo-300 bg-indigo-950/60 p-2.5 rounded-xl border border-indigo-800/40 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
                <span>Neural model analyzing pitch, formant frequencies & acoustic timbre...</span>
              </div>
            )}

            {analysisStats && !isAnalyzingAudio && (
              <div className="mt-2 grid grid-cols-3 gap-2 text-center text-[11px] bg-gray-900/80 p-2 rounded-xl border border-gray-800">
                <div>
                  <span className="text-gray-500 block">Est. Pitch</span>
                  <span className="text-indigo-300 font-mono font-bold">
                    {analysisStats.pitchHz} Hz
                  </span>
                </div>
                <div>
                  <span className="text-gray-500 block">Timbre</span>
                  <span className="text-indigo-300 font-medium truncate">
                    {analysisStats.timbre}
                  </span>
                </div>
                <div>
                  <span className="text-gray-500 block">Neural Match</span>
                  <span className="text-emerald-400 font-mono font-bold">
                    {analysisStats.clarity}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Step 3: Custom Accent / Mood Persona Directive */}
          <div className="pt-1">
            <label className="block text-xs font-medium text-gray-300 mb-1">
              Voice Style / Accent Guidance
            </label>
            <input
              type="text"
              value={customStyle}
              onChange={(e) => setCustomStyle(e.target.value)}
              placeholder="e.g. Natural Delhi Hinglish accent, confident YouTube creator style"
              className="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-xs text-gray-200 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={handleCreateClone}
          disabled={isCloning || !cloneName.trim()}
          className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-violet-600 via-indigo-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
        >
          {isCloning ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Synthesizing Voice Embedding...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Clone Voice &amp; Add to Catalog</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
