import { useState } from "react";
import { GROUP_ORDER, groupOf } from "@/lib/treino/catalog";
import type { Db, PrFilter } from "@/lib/treino/types";
import { cn } from "@/lib/utils";
import { ExerciseThumb } from "./thumb";

export function Prs({ prs }: { prs: Db["prs"] }) {
  const [filter, setFilter] = useState<PrFilter>("Academia");
  const by: Record<string, { name: string; place: string; group: string; w: number; r: number }[]> = {};

  Object.entries(prs).forEach(([key, value]) => {
    const split = key.lastIndexOf("|");
    const name = split >= 0 ? key.slice(0, split) : key;
    const place = split >= 0 ? key.slice(split + 1) : "";
    if (filter !== "Todos" && place !== filter) return;
    const group = groupOf(name);
    (by[group] ||= []).push({ name, place, group, w: value.w, r: value.r });
  });

  const groups = [...GROUP_ORDER, "Outros"].filter((group) => by[group]?.length);

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        {(["Academia", "Casa", "Todos"] as const).map((item) => (
          <button
            key={item}
            type="button"
            className={cn(
              "min-h-11 rounded-full border px-4 text-sm",
              filter === item ? "border-fg bg-fg font-semibold text-ink" : "border-line bg-surface text-fg",
            )}
            onClick={() => setFilter(item)}
          >
            {item}
          </button>
        ))}
      </div>
      {groups.length === 0 ? (
        <div className="rounded-2xl border border-line bg-surface p-4 text-sm text-muted">Nenhum PR nesse filtro.</div>
      ) : (
        groups.map((group) => (
          <section key={group}>
            <h2 className="mb-2 font-display text-lg tracking-wide text-fg">{group}</h2>
            <div className="space-y-2">
              {by[group].map((pr) => (
                <article key={`${pr.name}|${pr.place}`} className="flex items-center gap-3 rounded-2xl border border-line bg-surface p-3">
                  <ExerciseThumb name={pr.name} group={pr.group} />
                  <div className="min-w-0">
                    <strong className="block">{pr.name}</strong>
                    <span className="mr-2 inline-block rounded-full bg-inset px-2 py-0.5 text-xs">{pr.place}</span>
                    <p className="font-bold text-ok">
                      {pr.w} kg{pr.r ? ` × ${pr.r}` : ""}
                    </p>
                  </div>
                </article>
              ))}
            </div>
          </section>
        ))
      )}
    </div>
  );
}
