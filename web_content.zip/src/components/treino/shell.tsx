import { useEffect, useState } from "react";
import { ChartColumn, Dumbbell, History, Save, Trophy } from "lucide-react";
import { Toaster, toast } from "sonner";
import { emptyDb, loadDb, persistDb } from "@/lib/treino/storage";
import type { Db, Place, Session, TabId, WorkoutExercise } from "@/lib/treino/types";
import { cn } from "@/lib/utils";
import { Backup } from "./backup";
import { HistoryView } from "./history";
import { NewWorkout } from "./new-workout";
import { Progress } from "./progress";
import { Prs } from "./prs";

const TABS: { id: TabId; label: string; icon: typeof Dumbbell }[] = [
  { id: "novo", label: "Treino", icon: Dumbbell },
  { id: "hist", label: "Histórico", icon: History },
  { id: "prog", label: "Semana", icon: ChartColumn },
  { id: "prs", label: "PRs", icon: Trophy },
  { id: "backup", label: "Salvar", icon: Save },
];

export function Shell() {
  const [tab, setTab] = useState<TabId>("novo");
  const [db, setDb] = useState<Db>(emptyDb);
  const [draft, setDraft] = useState<WorkoutExercise[]>([]);

  useEffect(() => {
    setDb(loadDb());
  }, []);

  function commit(next: Db) {
    setDb(next);
    persistDb(next);
  }

  function saveWorkout(meta: { date: string; place: Place; duration: number; water: number }) {
    const session: Session = {
      id: Date.now(),
      date: meta.date,
      place: meta.place,
      duration: meta.duration,
      water: meta.water,
      exercises: draft,
    };
    const prs = { ...db.prs };
    session.exercises.forEach((item) => {
      if (!item.sets?.length) return;
      const best = Math.max(...item.sets.map((set) => Number(set.kg) || 0));
      const reps = item.sets.find((set) => set.kg === best)?.reps || 0;
      const key = `${item.name}|${session.place}`;
      const old = prs[key];
      if (!old || best > old.w) prs[key] = { w: best, r: reps, date: session.date };
    });
    commit({ sessions: [session, ...db.sessions], prs });
    setDraft([]);
    toast.success("Treino salvo.");
    setTab("hist");
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <Toaster theme="dark" position="top-center" />
      <header className="sticky top-0 z-10 border-b border-line bg-bg/90 px-4 py-4 backdrop-blur">
        <div className="mx-auto max-w-lg">
          <p className="font-display text-3xl leading-none tracking-wide">
            LVCXS <span className="text-blue">GRINDAS</span>
          </p>
          <p className="mt-1 text-sm text-muted">Academia e casa · o progresso fica neste aparelho</p>
        </div>
      </header>
      <main className="mx-auto max-w-lg px-4 pt-4 pb-nav">
        <div className={tab === "novo" ? "" : "hidden"}>
          <NewWorkout draft={draft} onChange={setDraft} onSave={saveWorkout} />
        </div>
        <div className={tab === "hist" ? "" : "hidden"}>
          <HistoryView
            sessions={db.sessions}
            onDelete={(id) => commit({ ...db, sessions: db.sessions.filter((session) => session.id !== id) })}
          />
        </div>
        <div className={tab === "prog" ? "" : "hidden"}>
          <Progress sessions={db.sessions} />
        </div>
        <div className={tab === "prs" ? "" : "hidden"}>
          <Prs prs={db.prs} />
        </div>
        <div className={tab === "backup" ? "" : "hidden"}>
          <Backup db={db} onImport={commit} />
        </div>
      </main>
      <nav className="nav-safe fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface/95 backdrop-blur">
        <div className="mx-auto grid max-w-lg grid-cols-5">
          {TABS.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                className={cn(
                  "flex min-h-16 flex-col items-center justify-center gap-1 text-xs",
                  active ? "font-bold text-fg" : "text-muted",
                )}
                onClick={() => setTab(item.id)}
              >
                <Icon className={cn("size-5", active && "text-blue")} aria-hidden />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
