import { workedGroups } from "@/lib/treino/stats";
import type { Session } from "@/lib/treino/types";

function mark(on: boolean) {
  return on ? "var(--color-blue)" : "var(--color-story-muted)";
}

export function BodyArt({ session }: { session: Session }) {
  const groups = workedGroups(session);
  const torso = mark(groups.has("Peito") || groups.has("Costas") || groups.has("Ombros"));
  const arms = mark(groups.has("Bíceps") || groups.has("Tríceps") || groups.has("Ombros"));
  const legs = mark(groups.has("Pernas"));
  return (
    <svg viewBox="0 0 80 150" className="h-36 w-20" aria-hidden>
      <circle cx="40" cy="16" r="10" fill="#d7dde6" />
      <path d="M28 30 h24 l6 28 h-36z" fill={torso} />
      <path d="M22 34 h8 l2 24 h-8z" fill={arms} />
      <path d="M50 34 h8 l-2 24 h-8z" fill={arms} />
      <path d="M30 60 h8 l2 42 h-10z" fill={legs} />
      <path d="M42 60 h8 l0 42 h-10z" fill={legs} />
      <ellipse cx="40" cy="58" rx="8" ry="5" fill={legs} />
    </svg>
  );
}

export function MoodFace({ times }: { times: number }) {
  const mood = times >= 3 ? "happy" : times === 2 ? "neutral" : "angry";
  return (
    <svg viewBox="0 0 96 96" className="size-20 shrink-0" aria-hidden>
      <ellipse cx="48" cy="70" rx="22" ry="10" fill="#1b1b1b" />
      <path
        d="M18 46 q2-28 30-30 q28-2 32 30 q2 24-10 34 q-12 8-22 8 q-16 0-24-10 q-8-10-6-32z"
        fill="#2b2b2b"
      />
      <path d="M24 42 q10-24 28-22 q16 2 20 16 q-8-8-20-6 q-14 1-20 12z" fill="#3a3a3a" />
      <ellipse cx="48" cy="52" rx="20" ry="22" fill="#f3d2c3" />
      <ellipse cx="40" cy="54" rx="6" ry="7" fill="#fff" />
      <ellipse cx="56" cy="54" rx="6" ry="7" fill="#fff" />
      <ellipse cx="41" cy="55" rx="3" ry="3.4" fill="#5b4636" />
      <ellipse cx="57" cy="55" rx="3" ry="3.4" fill="#5b4636" />
      <circle cx="42" cy="54" r="1" fill="#fff" />
      <circle cx="58" cy="54" r="1" fill="#fff" />
      {mood === "angry" ? (
        <>
          <path d="M34 40 l10 4" stroke="#3a2a2a" strokeWidth="1.8" />
          <path d="M62 40 l-10 4" stroke="#3a2a2a" strokeWidth="1.8" />
          <path d="M40 64 q8-7 16 0" stroke="#c45b6a" fill="none" strokeWidth="1.6" />
        </>
      ) : (
        <>
          <path d="M34 40 q6-4 12 0" stroke="#3a2a2a" fill="none" strokeWidth="1.5" />
          <path d="M50 40 q6-4 12 0" stroke="#3a2a2a" fill="none" strokeWidth="1.5" />
          {mood === "happy" ? (
            <path d="M40 58 q8 8 16 0" stroke="#c45b6a" fill="#e7a0ad" fillOpacity="0.45" strokeWidth="1.6" />
          ) : (
            <path d="M42 60 h12" stroke="#c45b6a" strokeWidth="1.6" />
          )}
        </>
      )}
      <ellipse cx="32" cy="60" rx="3" ry="1.6" fill="#f0a0a8" opacity="0.7" />
      <ellipse cx="64" cy="60" rx="3" ry="1.6" fill="#f0a0a8" opacity="0.7" />
    </svg>
  );
}
