import { useState } from "react";
import { toast } from "sonner";
import type { Db } from "@/lib/treino/types";
import { normalizeDb } from "@/lib/treino/storage";
import { controlClass } from "./field";

export function Backup({ db, onImport }: { db: Db; onImport: (db: Db) => void }) {
  const payload = JSON.stringify(db);
  const [override, setOverride] = useState<string | null>(null);
  const text = override ?? payload;

  async function copy() {
    const next = JSON.stringify(db);
    setOverride(next);
    try {
      await navigator.clipboard.writeText(next);
      toast.success("Progresso copiado.");
    } catch {
      toast.error("Selecione o texto e copie manualmente.");
    }
  }

  function download() {
    const blob = new Blob([JSON.stringify(db)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "treino-lucas-progresso.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function loadText() {
    try {
      const data = normalizeDb(JSON.parse(text));
      if (!data) throw new Error("invalido");
      onImport(data);
      setOverride(null);
      toast.success("Progresso carregado.");
    } catch {
      toast.error("Texto inválido.");
    }
  }

  return (
    <section className="rounded-2xl border border-line bg-surface p-4">
      <strong>Salvar progresso</strong>
      <p className="mt-2 text-sm text-muted">
        O treino fica neste aparelho. Copie o texto ou baixe o arquivo pra não perder. Pra recuperar, cole aqui ou
        escolha o arquivo.
      </p>
      <button type="button" className="mt-4 min-h-12 w-full rounded-xl bg-fg font-bold text-ink" onClick={copy}>
        Copiar progresso
      </button>
      <button
        type="button"
        className="mt-2 min-h-12 w-full rounded-xl border border-line font-semibold"
        onClick={download}
      >
        Baixar arquivo
      </button>
      <label className="mt-4 block text-xs text-muted">
        Cole aqui pra recuperar
        <textarea
          className={`${controlClass} mt-1 min-h-36 py-3`}
          rows={6}
          placeholder="Cole o progresso salvo"
          value={text}
          onChange={(e) => setOverride(e.target.value)}
        />
      </label>
      <button type="button" className="mt-3 min-h-12 w-full rounded-xl bg-fg font-bold text-ink" onClick={loadText}>
        Carregar texto
      </button>
      <label className="mt-4 block text-xs text-muted">
        Ou escolha o arquivo
        <input
          className={`${controlClass} mt-1 py-2`}
          type="file"
          accept="application/json,.json"
          onChange={(ev) => {
            const file = ev.target.files?.[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = () => {
              try {
                const data = normalizeDb(JSON.parse(String(reader.result)));
                if (!data) throw new Error("arquivo inválido");
                onImport(data);
                setOverride(null);
                toast.success("Progresso carregado.");
              } catch {
                toast.error("Não consegui ler esse arquivo.");
              }
            };
            reader.readAsText(file);
          }}
        />
      </label>
    </section>
  );
}
