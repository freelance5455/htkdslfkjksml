import { GROUPS } from "@/lib/treino/catalog";
import { maxFor, num, toneFor, weekBounds, ymd, type Tone } from "@/lib/treino/stats";
import type { Session } from "@/lib/treino/types";
import { cn } from "@/lib/utils";
import { MoodFace } from "./figures";

const TONE_TEXT: Record<Tone, string> = {
  danger: "text-danger",
  warn: "text-warn",
  blue: "text-blue",
};
const TONE_BG: Record<Tone, string> = {
  danger: "bg-danger",
  warn: "bg-warn",
  blue: "bg-blue",
};

export function Progress({ sessions }: { sessions: Session[] }) {
  const now = new Date();
  const { monday, sunday } = weekBounds(now);
  const start = ymd(monday);
  const end = ymd(sunday);
  const counts: Record<string, number> = {};
  Object.keys(GROUPS).forEach((group) => {
    counts[group] = 0;
  });
  const trained: Record<string, boolean> = {};
  const repSum: Record<string, number> = {};
  const repN: Record<string, number> = {};
  const byEx: Record<string, { group: string; name: string; reps: number; n: number }> = {};

  sessions.forEach((session) => {
    if (session.date < start || session.date > end) return;
    trained[session.date] = true;
    (session.exercises || []).forEach((exercise) => {
      const group = exercise.group && counts[exercise.group] !== undefined ? exercise.group : "Outros";
      if (counts[group] === undefined) counts[group] = 0;
      counts[group] += (exercise.sets || []).length;
      if (exercise.group === "Cardio") return;
      (exercise.sets || []).forEach((set) => {
        repSum[exercise.group] = (repSum[exercise.group] || 0) + num(set.reps);
        repN[exercise.group] = (repN[exercise.group] || 0) + 1;
        const key = `${exercise.group}|${exercise.name}`;
        byEx[key] = byEx[key] || { group: exercise.group, name: exercise.name, reps: 0, n: 0 };
        byEx[key].reps += num(set.reps);
        byEx[key].n += 1;
      });
    });
  });

  const labels = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  const sundayStart = new Date(monday);
  sundayStart.setDate(monday.getDate() - 1);
  const days = labels.map((lab, i) => {
    const d = new Date(sundayStart);
    d.setDate(sundayStart.getDate() + i);
    return { lab, date: d.getDate(), on: !!trained[ymd(d)] };
  });

  const bars = Object.keys(GROUPS)
    .filter((group) => group !== "Cardio")
    .map((group) => {
      const max = maxFor(group);
      const raw = counts[group] || 0;
      const n = Math.min(raw, max);
      const pct = Math.round((n / max) * 100);
      const tone = toneFor(raw, max, group);
      const avg = repN[group] ? Math.round(repSum[group] / repN[group]) : 0;
      const lines = Object.values(byEx).filter((item) => item.group === group);
      return { group, raw, pct, tone, avg, max, lines };
    });

  const cardio = sessions
    .filter((session) => session.date >= start && session.date <= end)
    .flatMap((session) => (session.exercises || []).filter((exercise) => exercise.group === "Cardio"));
  const waters = sessions
    .filter((session) => session.date >= start && session.date <= end && session.water)
    .map((session) => num(session.water));
  const waterAvg = waters.length ? waters.reduce((a, b) => a + b, 0) / waters.length : 0;
  const waterPct = Math.max(0, Math.min(100, ((waterAvg - 1) / 2) * 100));
  const times = Object.keys(trained).length;
  const mood = times >= 3 ? "Semana boa" : times === 2 ? "Na média" : "Bora treinar";

  return (
    <div className="space-y-3">
      <section className="rounded-2xl border border-line bg-surface p-4">
        <p className="text-sm text-muted">
          Semana {start.split("-").reverse().join("/")} a {end.split("-").reverse().join("/")} · zera na segunda
        </p>
        <div className="mt-3 grid grid-cols-7 gap-1.5">
          {days.map((day) => (
            <div
              key={day.lab}
              className={cn(
                "rounded-xl border px-1 py-2 text-center",
                day.on ? "border-blue bg-blue text-fg" : "border-line bg-inset text-muted",
              )}
            >
              <b className="block text-xs">{day.lab}</b>
              <span className="text-sm">{day.date}</span>
            </div>
          ))}
        </div>
        <div className="mt-4 flex items-center gap-3">
          <MoodFace times={times} />
          <div>
            <strong>{mood}</strong>
            <p className="text-sm text-muted">{times} treino(s) nesta semana</p>
          </div>
        </div>
      </section>

      {bars.map((bar) => (
        <section key={bar.group} className="rounded-2xl border border-line bg-surface p-4">
          <div className="flex items-center justify-between">
            <strong>{bar.group}</strong>
            <span className={cn("font-bold", TONE_TEXT[bar.tone])}>{bar.raw} séries</span>
          </div>
          <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-inset">
            <div className={cn("h-full rounded-full", TONE_BG[bar.tone])} style={{ width: `${bar.pct}%` }} />
          </div>
          <p className="mt-2 text-sm text-muted">
            Meta {bar.max} · média {bar.avg} reps por série
          </p>
          <p className="text-sm text-muted">
            {bar.lines.length
              ? bar.lines.map((line) => `${line.name}: ${Math.round(line.reps / line.n)} reps/série`).join(" · ")
              : "Sem séries nesta semana"}
          </p>
        </section>
      ))}

      <section className="rounded-2xl border border-line bg-surface p-4">
        <div className="flex items-center justify-between">
          <strong>Água por treino</strong>
          <span className="font-bold text-blue">{waterAvg ? waterAvg.toFixed(1) : "0"} L</span>
        </div>
        <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-inset">
          <div className="h-full rounded-full bg-blue" style={{ width: `${waterPct}%` }} />
        </div>
        <p className="mt-2 text-sm text-muted">Média da semana · escala de 1 a 3 litros</p>
      </section>

      <section className="rounded-2xl border border-line bg-surface p-4">
        <strong>Cardio</strong>
        <div className="mt-1 text-sm text-muted">
          {cardio.length ? (
            cardio.map((item, index) => (
              <p key={`${item.name}-${index}`}>
                {item.name}: {item.minutes || 0} min · {item.kcal || 0} kcal
              </p>
            ))
          ) : (
            <p>Nenhum cardio nesta semana</p>
          )}
        </div>
      </section>
    </div>
  );
}
