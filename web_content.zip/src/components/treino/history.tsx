import { useState, type ReactNode } from "react";
import { Skull, X } from "lucide-react";
import { dayTitle, formatDate, formatDuration, formatKg, seriesOf, volumeOf } from "@/lib/treino/stats";
import type { Session } from "@/lib/treino/types";
import { BodyArt } from "./figures";

function ShareCard({ children }: { children: ReactNode }) {
  return (
    <article className="w-10/12 shrink-0 snap-center rounded-3xl bg-story px-4 py-5 text-fg">{children}</article>
  );
}

function CardTitle({ title }: { title: string }) {
  return (
    <h2 className="mb-3 flex items-center gap-2 font-display text-3xl font-semibold tracking-wide">
      {title}
      <Skull className="size-6 text-blue" aria-hidden />
    </h2>
  );
}

function Foot({ right }: { right?: string }) {
  return (
    <div className="mt-5 flex items-end justify-between text-sm text-story-muted">
      <b className="font-display text-base tracking-widest text-fg">LVCXS</b>
      <span>{right ?? "@lvcxs777"}</span>
    </div>
  );
}

export function HistoryView({ sessions, onDelete }: { sessions: Session[]; onDelete: (id: number) => void }) {
  const [openId, setOpenId] = useState<number | null>(null);
  const [confirm, setConfirm] = useState(false);
  const open = sessions.find((session) => session.id === openId);

  if (!sessions.length) {
    return (
      <div className="rounded-2xl border border-line bg-surface p-4 text-sm text-muted">Nenhum treino salvo ainda.</div>
    );
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted">Deslize o card. Toque pra abrir o treino.</p>
      {sessions.map((session) => {
        const title = dayTitle(session);
        const vol = formatKg(volumeOf(session));
        const series = seriesOf(session);
        const mins = formatDuration(session.duration || 0);
        return (
          <div
            key={session.id}
            className="flex w-full snap-x snap-mandatory gap-3 overflow-x-auto pb-1 text-left"
            onClick={() => {
              setOpenId(session.id);
              setConfirm(false);
            }}
          >
            <ShareCard>
              <CardTitle title={title} />
              {(session.exercises || []).map((exercise, index) => (
                <p key={`${exercise.name}-${index}`} className="my-1.5 flex gap-2 text-sm">
                  <span className="w-8 shrink-0 font-extrabold text-blue">
                    {exercise.group === "Cardio" ? `${exercise.minutes || 0}m` : `${(exercise.sets || []).length}x`}
                  </span>
                  <span>{exercise.name}</span>
                </p>
              ))}
              <Foot />
            </ShareCard>
            <ShareCard>
              <h2 className="mb-2 flex items-center justify-center gap-2 text-center font-display text-3xl font-semibold tracking-wide">
                {title}
                <Skull className="size-6 text-blue" aria-hidden />
              </h2>
              <div className="flex justify-center gap-4">
                <BodyArt session={session} />
                <BodyArt session={session} />
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                <Stat value={mins} label="Duração" />
                <Stat value={`${vol} kg`} label="Volume" />
                <Stat value={String(series)} label="Séries" />
              </div>
              <Foot />
            </ShareCard>
            <ShareCard>
              <CardTitle title={title} />
              <div className="grid grid-cols-2 gap-3">
                <Stat value={mins} label="Duração" flip />
                <Stat value={`${vol} kg`} label="Volume" flip />
                <Stat value={String((session.exercises || []).length)} label="Exercícios" flip />
                <Stat value={String(series)} label="Séries" flip />
              </div>
              <Foot right={`${formatDate(session.date)} · ${session.place}`} />
            </ShareCard>
          </div>
        );
      })}

      {open && (
        <div className="fixed inset-0 z-30 overflow-auto bg-bg/95 p-4 pb-nav">
          <div className="mx-auto max-w-lg">
            <div className="mb-3 flex items-center justify-between gap-3">
              <strong>
                {dayTitle(open)} · {formatDate(open.date)}
              </strong>
              <button type="button" className="grid size-11 place-items-center" aria-label="Fechar" onClick={() => setOpenId(null)}>
                <X />
              </button>
            </div>
            <p className="mb-3 text-sm text-muted">
              {open.place} · {open.duration || 0} min · {open.water || 0} L · volume {formatKg(volumeOf(open))} kg
            </p>
            <div className="space-y-3">
              {(open.exercises || []).map((exercise, index) => (
                <div key={`${exercise.name}-${index}`} className="rounded-2xl border border-line bg-surface p-4">
                  <strong>{exercise.name}</strong>
                  <p className="mt-1 whitespace-pre-line text-sm text-muted">
                    {exercise.group === "Cardio"
                      ? `${exercise.minutes || 0} min · ${exercise.kcal || 0} kcal`
                      : (exercise.sets || []).map((set, i) => `Série ${i + 1}: ${set.kg} kg x ${set.reps}`).join("\n")}
                  </p>
                </div>
              ))}
            </div>
            <button
              type="button"
              className="mt-4 min-h-11 rounded-full border border-line px-4 text-sm text-danger"
              onClick={() => {
                if (!confirm) {
                  setConfirm(true);
                  return;
                }
                onDelete(open.id);
                setOpenId(null);
              }}
            >
              {confirm ? "Confirmar exclusão" : "Apagar treino"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ value, label, flip }: { value: string; label: string; flip?: boolean }) {
  return (
    <div>
      {flip ? (
        <>
          <b className="block font-display text-2xl font-semibold">{value}</b>
          <span className="text-sm text-story-muted">{label}</span>
        </>
      ) : (
        <>
          <span className="text-sm text-story-muted">{label}</span>
          <b className="block font-display text-2xl font-semibold">{value}</b>
        </>
      )}
    </div>
  );
}
