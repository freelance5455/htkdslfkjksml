import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Dumbbell, House, Plus, X } from "lucide-react";
import { GROUPS, GROUP_ORDER } from "@/lib/treino/catalog";
import { exerciseLine, todayLocal } from "@/lib/treino/stats";
import type { Place, WorkoutExercise } from "@/lib/treino/types";
import { cn } from "@/lib/utils";
import { Card, controlClass, Field } from "./field";
import { ExerciseThumb } from "./thumb";

type SetDraft = { kg: string; reps: string };

function blankSets(place: Place): SetDraft[] {
  const count = place === "Casa" ? 2 : 3;
  return Array.from({ length: count }, () => ({ kg: "", reps: "" }));
}

export function NewWorkout({
  draft,
  onChange,
  onSave,
}: {
  draft: WorkoutExercise[];
  onChange: (next: WorkoutExercise[]) => void;
  onSave: (meta: { date: string; place: Place; duration: number; water: number }) => void;
}) {
  const [date, setDate] = useState("");
  useEffect(() => {
    setDate((current) => current || todayLocal());
  }, []);
  const [place, setPlace] = useState<Place>("Academia");
  const [duration, setDuration] = useState("");
  const [water, setWater] = useState("");
  const [group, setGroup] = useState(GROUP_ORDER[0] ?? "Pernas");
  const [name, setName] = useState("");
  const [open, setOpen] = useState(false);
  const [sets, setSets] = useState<SetDraft[]>(() => blankSets("Academia"));
  const [cardioType, setCardioType] = useState("Esteira");
  const [cardioMin, setCardioMin] = useState("");
  const [cardioKcal, setCardioKcal] = useState("");

  const cardio = group === "Cardio";
  const suggestions = useMemo(() => {
    const q = name.trim().toLowerCase();
    return (GROUPS[group] || []).filter((item) => !q || item.toLowerCase().includes(q)).slice(0, 8);
  }, [group, name]);

  function changePlace(next: Place) {
    setPlace(next);
    if (next !== place) setSets(blankSets(next));
  }

  function changeKg(index: number, value: string) {
    setSets((prev) => prev.map((set, i) => (i >= index ? { ...set, kg: value } : set)));
  }

  function addExercise() {
    if (cardio) {
      const minutes = Number(cardioMin || 0);
      const kcal = Number(cardioKcal || 0);
      if (!minutes && !kcal) {
        toast.error("Informe tempo ou calorias.");
        return;
      }
      onChange([...draft, { group: "Cardio", name: cardioType, minutes, kcal, sets: [] }]);
      setCardioMin("");
      setCardioKcal("");
      return;
    }
    const exercise = name.trim();
    if (!exercise) {
      toast.error("Informe o exercício.");
      return;
    }
    const parsed = sets
      .map((set) => ({ kg: Number(set.kg || 0), reps: Number(set.reps || 0) }))
      .filter((set) => set.kg || set.reps);
    if (!parsed.length) {
      toast.error("Adicione ao menos uma série.");
      return;
    }
    onChange([...draft, { group, name: exercise, sets: parsed }]);
    setName("");
    setSets(blankSets(place));
  }

  return (
    <div className="space-y-3">
      <Card>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Data">
            <input className={controlClass} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <div>
            <span className="mb-1 block text-xs font-medium text-muted">Local</span>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  ["Academia", Dumbbell],
                  ["Casa", House],
                ] as const
              ).map(([label, Icon]) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => changePlace(label)}
                  className={cn(
                    "flex min-h-11 items-center justify-center gap-1 rounded-xl border text-sm",
                    place === label ? "border-fg bg-fg font-semibold text-ink" : "border-line bg-inset text-fg",
                  )}
                >
                  <Icon className="size-4" aria-hidden />
                  {label}
                </button>
              ))}
            </div>
          </div>
          <Field label="Duração (min)">
            <input
              className={controlClass}
              inputMode="numeric"
              type="number"
              placeholder="70"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
            />
          </Field>
          <Field label="Água (L)">
            <input
              className={controlClass}
              inputMode="decimal"
              type="number"
              step="0.1"
              placeholder="2"
              value={water}
              onChange={(e) => setWater(e.target.value)}
            />
          </Field>
        </div>
      </Card>

      <Card>
        <Field label="Grupo muscular">
          <select
            className={controlClass}
            value={group}
            onChange={(e) => {
              setGroup(e.target.value);
              setName("");
              setOpen(false);
            }}
          >
            {GROUP_ORDER.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </Field>

        {cardio ? (
          <div className="mt-3 space-y-3">
            <Field label="Tipo de cardio">
              <select className={controlClass} value={cardioType} onChange={(e) => setCardioType(e.target.value)}>
                <option>Esteira</option>
                <option>Bicicleta</option>
              </select>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Tempo (min)">
                <input
                  className={controlClass}
                  type="number"
                  placeholder="15"
                  value={cardioMin}
                  onChange={(e) => setCardioMin(e.target.value)}
                />
              </Field>
              <Field label="Calorias">
                <input
                  className={controlClass}
                  type="number"
                  placeholder="95"
                  value={cardioKcal}
                  onChange={(e) => setCardioKcal(e.target.value)}
                />
              </Field>
            </div>
          </div>
        ) : (
          <>
            <div className="relative mt-3">
              <Field label="Exercício">
                <input
                  className={controlClass}
                  autoComplete="off"
                  placeholder="Comece a digitar o exercício"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    setOpen(true);
                  }}
                  onFocus={() => setOpen(true)}
                  onBlur={() => setOpen(false)}
                />
              </Field>
              {open && suggestions.length > 0 && (
                <div className="absolute inset-x-0 top-full z-20 mt-1 max-h-72 overflow-auto rounded-2xl border border-line bg-inset shadow-xl">
                  {suggestions.map((item) => (
                    <button
                      key={item}
                      type="button"
                      className="flex w-full items-center gap-3 border-b border-line px-2 py-2 text-left last:border-b-0"
                      onMouseDown={(e) => {
                        e.preventDefault();
                        setName(item);
                        setOpen(false);
                      }}
                    >
                      <ExerciseThumb name={item} group={group} />
                      <span>
                        <span className="block text-sm font-semibold">{item}</span>
                        <span className="text-xs text-muted">{group}</span>
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="mt-3 space-y-2">
              {sets.map((set, index) => (
                <div key={index} className="flex items-center gap-2">
                  <span className="w-16 shrink-0 text-sm text-muted">Série {index + 1}</span>
                  <input
                    className={controlClass}
                    type="number"
                    step="0.5"
                    inputMode="decimal"
                    placeholder="kg"
                    value={set.kg}
                    onChange={(e) => changeKg(index, e.target.value)}
                  />
                  <input
                    className={controlClass}
                    type="number"
                    inputMode="numeric"
                    placeholder="reps"
                    value={set.reps}
                    onChange={(e) =>
                      setSets((prev) => prev.map((row, i) => (i === index ? { ...row, reps: e.target.value } : row)))
                    }
                  />
                  <button
                    type="button"
                    className="grid size-11 shrink-0 place-items-center text-xl text-danger"
                    aria-label={`Remover série ${index + 1}`}
                    onClick={() => setSets((prev) => prev.filter((_, i) => i !== index))}
                  >
                    <X className="size-5" />
                  </button>
                </div>
              ))}
            </div>
            <button
              type="button"
              className="mt-3 inline-flex min-h-11 items-center gap-1 rounded-full border border-line px-4 text-sm"
              onClick={() => setSets((prev) => [...prev, { kg: prev.at(-1)?.kg ?? "", reps: "" }])}
            >
              <Plus className="size-4" /> série
            </button>
          </>
        )}

        <button
          type="button"
          className="mt-4 min-h-12 w-full rounded-xl bg-fg text-base font-bold text-ink"
          onClick={addExercise}
        >
          Adicionar exercício
        </button>
      </Card>

      <Card>
        <div className="mb-2 flex items-center justify-between">
          <strong>Exercícios deste treino</strong>
          <span className="text-sm text-muted">{draft.length === 1 ? "1 exercício" : `${draft.length} exercícios`}</span>
        </div>
        {draft.length === 0 ? (
          <p className="text-sm text-muted">Nenhum exercício ainda.</p>
        ) : (
          <ul>
            {draft.map((exercise, index) => (
              <li key={`${exercise.name}-${index}`} className="flex items-center gap-3 border-t border-line py-3">
                <ExerciseThumb name={exercise.name} group={exercise.group} />
                <div className="min-w-0 flex-1">
                  <strong className="block truncate">{exercise.name}</strong>
                  <p className="text-sm text-muted">
                    {exercise.group === "Cardio" ? exerciseLine(exercise) : `${exercise.group} · ${exerciseLine(exercise)}`}
                  </p>
                </div>
                <button
                  type="button"
                  className="grid size-11 place-items-center text-danger"
                  aria-label={`Remover ${exercise.name}`}
                  onClick={() => onChange(draft.filter((_, i) => i !== index))}
                >
                  <X className="size-5" />
                </button>
              </li>
            ))}
          </ul>
        )}
        <button
          type="button"
          className="mt-3 min-h-12 w-full rounded-xl bg-fg text-base font-bold text-ink"
          onClick={() => {
            if (!draft.length) {
              toast.error("Adicione exercícios antes de salvar.");
              return;
            }
            if (!date) {
              toast.error("Informe a data.");
              return;
            }
            onSave({
              date,
              place,
              duration: Number(duration || 0),
              water: Number(water || 0),
            });
          }}
        >
          Salvar treino
        </button>
      </Card>
    </div>
  );
}
