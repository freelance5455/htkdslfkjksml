import { thumbSrc } from "@/lib/treino/catalog";
import { cn } from "@/lib/utils";
import { Bike, Dumbbell, PersonStanding } from "lucide-react";

export function ExerciseThumb({
  name,
  group,
  className,
}: {
  name: string;
  group: string;
  className?: string;
}) {
  const src = thumbSrc(name);
  return (
    <span
      className={cn(
        "grid h-16 w-20 shrink-0 place-items-center overflow-hidden rounded-lg bg-fg text-ink",
        className,
      )}
    >
      {src ? (
        <img src={src} alt="" className="h-full w-full object-cover" />
      ) : group === "Cardio" && name === "Bicicleta" ? (
        <Bike className="size-7" aria-hidden />
      ) : group === "Cardio" ? (
        <PersonStanding className="size-7" aria-hidden />
      ) : (
        <Dumbbell className="size-6" aria-hidden />
      )}
    </span>
  );
}
