"use client";

import React, { useState } from "react";
import {
  Cpu,
  ShieldAlert,
  CheckCircle2,
  RefreshCw,
  Sliders,
  AlertOctagon,
} from "lucide-react";

export interface EvaluatorLogRecord {
  id: number;
  symbol: string;
  signalSide: string;
  entryPrice: number;
  exitPrice: number;
  outcome: string;
  pnlPct: number;
  rootCauseCode: string;
  hebrewDiagnosis: string;
  adxValue: number;
  rsiValue: number;
  volumeRatio: number;
  actionTaken: string;
  createdAt: string;
}

interface EvaluatorAgentPanelProps {
  logs: EvaluatorLogRecord[];
  rollingWinRatePct: number;
  strictMode: boolean;
  minConfluenceThreshold: number;
  onRunManualAudit: () => Promise<void>;
}

export function EvaluatorAgentPanel({
  logs,
  rollingWinRatePct,
  strictMode,
  minConfluenceThreshold,
  onRunManualAudit,
}: EvaluatorAgentPanelProps) {
  const [auditing, setAuditing] = useState(false);
  const safeLogs = Array.isArray(logs) ? logs : [];

  return (
    <div
      dir="rtl"
      className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5 shadow-lg"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#222B3A] pb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#3B82F6]/15 text-[#3B82F6]">
            <Cpu className="h-6 w-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-[#F1F5F9]">
                יומן אבחונים וסריקה עצמית (Evaluator-Optimizer Agent)
              </h3>
              <span
                className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                  strictMode
                    ? "bg-[#F59E0B]/20 text-[#F59E0B]"
                    : "bg-[#00E676]/20 text-[#00E676]"
                }`}
              >
                {strictMode
                  ? "מצב הידוק אוטומטי מופעל (Strict > 80%)"
                  : "כיול אופטימלי פעיל (Win-Rate > 75%)"}
              </span>
            </div>
            <p className="text-xs text-[#94A3B8]">
              מבקר רקע אוטונומי הבודק כל אות 5 דקות מול מחירי סגירה בבורסה, מאבחן
              כישלונות (ADX נמוך / נפח חלש) ומהדק כללי קונפלואנס אוטומטית.
            </p>
          </div>
        </div>

        <button
          type="button"
          disabled={auditing}
          onClick={async () => {
            setAuditing(true);
            await onRunManualAudit();
            setAuditing(false);
          }}
          className="inline-flex items-center gap-2 rounded-lg bg-[#3B82F6] px-4 py-2 text-xs font-bold text-white transition hover:bg-[#2563EB]"
        >
          <RefreshCw className={`h-4 w-4 ${auditing ? "animate-spin" : ""}`} />
          <span>הרץ ביקורת סוכן (Post-Mortem Audit)</span>
        </button>
      </div>

      {/* 3 Adaptive Metrics Bar */}
      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
          <span className="text-xs text-[#94A3B8]">
            אחוז הצלחה מתגלגל (30 עסקאות אחרונות)
          </span>
          <div className="mt-1 flex items-baseline gap-2">
            <span
              className={`font-mono text-2xl font-extrabold ${
                rollingWinRatePct >= 75 ? "text-[#00E676]" : "text-[#F59E0B]"
              }`}
            >
              {rollingWinRatePct}%
            </span>
            <span className="text-[11px] text-[#64748B]">(סף יעד: 75.0%)</span>
          </div>
        </div>

        <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
          <span className="text-xs text-[#94A3B8]">
            סף קונפלואנס מינימלי נוכחי לאישור אות
          </span>
          <div className="mt-1 flex items-center gap-2">
            <Sliders className="h-4 w-4 text-[#3B82F6]" />
            <span className="font-mono text-2xl font-extrabold text-[#F1F5F9]">
              {minConfluenceThreshold}%
            </span>
          </div>
        </div>

        <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
          <span className="text-xs text-[#94A3B8]">מסנני הגנה אקטיביים</span>
          <div className="mt-1 text-xs font-bold text-[#00E676]">
            סינון דשדוש ADX(14) &gt; 20 • יחס נפח &gt; 0.85x
          </div>
          <span className="text-[11px] text-[#64748B]">
            מונע פריצות שווא בנפח נמוך
          </span>
        </div>
      </div>

      {/* Diagnostic Logs List */}
      <div className="mt-4 space-y-2.5">
        {safeLogs.slice(0, 6).map((log) => {
          const isLoss = log.outcome === "LOSS";
          return (
            <div
              key={log.id}
              className={`rounded-lg border p-3.5 text-xs transition ${
                isLoss
                  ? "border-[#FF3B69]/40 bg-[#FF3B69]/5"
                  : "border-[#222B3A] bg-[#0B0E14]"
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  {isLoss ? (
                    <AlertOctagon className="h-4 w-4 text-[#FF3B69]" />
                  ) : (
                    <CheckCircle2 className="h-4 w-4 text-[#00E676]" />
                  )}
                  <span className="font-mono font-bold text-[#F1F5F9]">
                    {log.symbol} ({log.signalSide})
                  </span>
                  <span
                    className={`rounded px-2 py-0.5 font-mono text-[11px] font-bold ${
                      isLoss
                        ? "bg-[#FF3B69]/20 text-[#FF3B69]"
                        : "bg-[#00E676]/20 text-[#00E676]"
                    }`}
                  >
                    {log.pnlPct >= 0 ? "+" : ""}
                    {log.pnlPct}%
                  </span>
                  <span className="font-semibold text-[#F1F5F9]">
                    {log.hebrewDiagnosis}
                  </span>
                </div>

                <div className="flex items-center gap-3 font-mono text-[11px] text-[#94A3B8]">
                  <span>ADX: {log.adxValue}</span>
                  <span>RSI: {log.rsiValue}</span>
                  <span>Vol: {log.volumeRatio}x</span>
                </div>
              </div>

              <div className="mt-2 flex items-center justify-between border-t border-[#222B3A]/60 pt-1.5 text-[11px] text-[#94A3B8]">
                <span>
                  <strong className="text-[#3B82F6]">תיקון אדפטיבי:</strong>{" "}
                  {log.actionTaken}
                </span>
                <span className="font-mono text-[10px] text-[#64748B]">
                  כניסה ${log.entryPrice} ← יציאה ${log.exitPrice}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
