import { useMemo, useState } from "react";
import { SHOPS, ZONES, waLink, zoneLabel } from "../data/shops";
import { IMG } from "../media";
import { useStore } from "../store";
import type { Shop } from "../types";
import { IconArrow, IconWA } from "./Icons";

export function mark(shop: Shop) {
  const id = shop.id;
  if (id.includes("kfc")) return { logo: IMG.logoKfc };
  if (id.includes("mcdonald")) return { logo: IMG.logoMcd };
  if (id.includes("nandos")) return { logo: IMG.logoNandos };
  if (id.includes("debonairs")) return { logo: IMG.logoDebonairs };
  if (id.includes("chicken-licken")) return { logo: IMG.logoLicken };
  if (id.includes("kennys")) return { logo: IMG.logoKennys };
  if (id.includes("the-thrive")) return { logo: IMG.logoThrive };
  if (id.includes("burger-king")) return { bg: "#0033A0", fg: "#F5EB3A", t: "BK" };
  if (id.includes("steers")) return { bg: "#C8102E", fg: "#fff", t: "S" };
  if (id.includes("hungry-lion")) return { bg: "#E87722", fg: "#fff", t: "HL" };
  if (id.includes("fishaways")) return { bg: "#0077C8", fg: "#fff", t: "F" };
  if (id.includes("burger-buzz")) return { bg: "#6B2D1A", fg: "#F2B84B", t: "BB" };
  if (id.includes("kalawas")) return { bg: "#1F8A4C", fg: "#fff", t: "K" };
  if (id.includes("tops")) return { bg: "#7A1F2B", fg: "#fff", t: "T" };
  if (id.includes("shoprite")) return { logo: IMG.logoShoprite };
  if (id.includes("roots")) return { logo: IMG.logoRoots };
  if (id.includes("boxer")) return { logo: IMG.logoBoxer };
  if (id.includes("dikoteng")) return { bg: "#C62828", fg: "#fff", t: "D" };
  if (id.includes("dijong")) return { bg: "#6A1B9A", fg: "#fff", t: "D" };
  if (id.includes("crispy")) return { bg: "#EF6C00", fg: "#fff", t: "C" };
  if (id.includes("the-munch")) return { bg: "#111", fg: "#FF6A00", t: "M" };
  if (id.includes("decent")) return { bg: "#4E342E", fg: "#fff", t: "D" };
  if (id.includes("drr-pizza")) return { bg: "#B71C1C", fg: "#fff", t: "P" };
  if (id.includes("bra-willas")) return { bg: "#1F8A4C", fg: "#fff", t: "B" };
  if (id.includes("kota-king")) return { bg: "#F9A825", fg: "#111", t: "K" };
  if (id.includes("freedoms")) return { bg: "#1565C0", fg: "#fff", t: "F" };
  if (id.includes("lazis")) return { bg: "#4E342E", fg: "#fff", t: "L" };
  if (id.includes("laundry-plug")) return { bg: "#0277BD", fg: "#fff", t: "LP" };
  if (id.includes("km-laundry")) return { bg: "#00695C", fg: "#fff", t: "KM" };
  if (id.includes("galitos")) return { logo: IMG.logoGalitos };
  if (id.includes("clicks")) return { logo: IMG.logoClicks };
  if (id.includes("local-choice")) return { logo: IMG.logoLocalChoice };
  if (id.includes("capitec-cash")) return { logo: IMG.logoCapitec };
  if (id.includes("fnb-cash")) return { logo: IMG.logoFnb };
  if (id.includes("absa-cash")) return { logo: IMG.logoAbsa };
  if (id.includes("standard-bank")) return { logo: IMG.logoStandard };
  if (id.includes("nedbank")) return { logo: IMG.logoNedbank };
  return { bg: "#1F8A4C", fg: "#fff", t: shop.name.replace(/[^A-Za-z]/g, "").slice(0, 1).toUpperCase() };
}

function Tile({ shop }: { shop: Shop }) {
  const { openShop } = useStore();
  const b = mark(shop);
  const label = shop.name.length > 14 ? `${shop.name.slice(0, 13)}…` : shop.name;
  return (
    <button onClick={() => openShop(shop)} className="press group relative aspect-[1.15/1] w-full overflow-hidden rounded-[22px] text-left shadow-[0_8px_24px_rgba(0,0,0,0.12)]">
      <img src={shop.image} alt={shop.name} className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-black/5" />
      <div className="absolute bottom-3 left-2.5 right-2 flex items-center gap-2">
        {"logo" in b && b.logo ? (
          <img src={b.logo} alt="" className="h-11 w-11 shrink-0 rounded-full border-[3px] border-white bg-white object-cover shadow-md" />
        ) : (
          <span
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full border-[3px] border-white text-[13px] font-black shadow-md"
            style={{ background: "bg" in b ? b.bg : "#1F8A4C", color: "fg" in b ? b.fg : "#fff" }}
          >
            {"t" in b ? b.t : ""}
          </span>
        )}
        <span className="min-w-0">
          <span className="block truncate text-[15px] font-extrabold leading-tight text-white drop-shadow">{label}</span>
          <span className="block text-[12px] font-medium text-white/80">Tap to order</span>
        </span>
      </div>
    </button>
  );
}

export function ExpressHome() {
  const { setModal, category } = useStore();
  const [zone, setZone] = useState<"all" | Shop["zone"]>("all");

  const list = useMemo(() => {
    return SHOPS.filter((s) => {
      if (zone !== "all" && s.zone !== zone) return false;
      if (category !== "all" && s.category !== category) return false;
      return true;
    });
  }, [zone, category]);

  return (
    <section id="home" className="min-h-screen bg-white pb-24">
      <div className="fixed top-0 left-0 right-0 z-50 bg-white px-4 pb-3 pt-[max(14px,env(safe-area-inset-top))] shadow-[0_1px_0_rgba(0,0,0,0.06)]">
        <div className="mx-auto flex max-w-[980px] items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-full bg-[#1F8A4C] text-lg font-black text-white">T</span>
            <span className="text-[22px] font-extrabold tracking-tight text-[#111]">TurfBuddy</span>
          </div>
          <a
            href={waLink("Hi TurfBuddy, I want to place an order.")}
            target="_blank"
            rel="noreferrer"
            className="flex h-10 items-center gap-1 rounded-full bg-[#1F8A4C] px-4 text-[14px] font-bold text-white press"
          >
            Order Now <IconArrow className="h-4 w-4" />
          </a>
        </div>
        <div className="mx-auto mt-3 flex max-w-[980px] gap-2 overflow-x-auto hide-scroll">
          {[{ id: "all" as const, label: "All" }, ...ZONES.map((z) => ({ id: z.id, label: z.label }))].map((z) => (
            <button
              key={z.id}
              onClick={() => setZone(z.id)}
              className={`shrink-0 rounded-full px-3.5 py-1.5 text-[12px] font-bold ${
                zone === z.id ? "bg-[#1F8A4C] text-white" : "bg-[#f2f2f2] text-[#444]"
              }`}
            >
              {z.label}
            </button>
          ))}
          <button onClick={() => setModal("search")} className="shrink-0 rounded-full bg-[#f2f2f2] px-3.5 py-1.5 text-[12px] font-bold text-[#444]">
            Search
          </button>
        </div>
      </div>

      <div id="restaurants" className="mx-auto grid max-w-[980px] grid-cols-2 gap-3 px-3 pt-[148px] sm:grid-cols-3 lg:grid-cols-4">
        {list.map((s) => (
          <Tile key={s.id} shop={s} />
        ))}
      </div>

      {!list.length && <p className="px-6 py-16 text-center text-sm text-[#888]">No shops in this area.</p>}

      <p className="mx-auto mt-6 max-w-[980px] px-4 text-center text-[11px] text-[#9a9a9a]">
        {list.length} places · {zone === "all" ? "All areas" : zoneLabel(zone as Shop["zone"])} · Tap a card to order
      </p>
    </section>
  );
}

export function ExpressWA() {
  return (
    <a
      href={waLink("Hi TurfBuddy, I want to place an order.")}
      target="_blank"
      rel="noreferrer"
      className="fixed bottom-20 right-4 z-40 grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-[0_10px_28px_rgba(37,211,102,0.45)] press md:bottom-6"
      aria-label="WhatsApp"
    >
      <IconWA className="h-7 w-7" />
    </a>
  );
}
