import React, { useState } from 'react';
import { 
  Share2, 
  Send, 
  Copy, 
  ExternalLink, 
  Mail, 
  Phone, 
  MessageCircle, 
  Video, 
  Globe, 
  CheckCircle2, 
  Sparkles, 
  RefreshCw, 
  Flame, 
  Layers, 
  Radio, 
  Music, 
  Check, 
  Youtube, 
  Instagram, 
  Facebook, 
  Twitter,
  Coins
} from 'lucide-react';
import { socialBroadcastEngine, BroadcastUpdateItem } from '../lib/socialBroadcastEngine';
import { offlineCache } from '../lib/offlineCache';
import { updateSocialMetadata } from '../lib/seoHelper';

interface GlobalSocialBroadcastEngineProps {
  onShowToast?: (msg: string) => void;
}

export const GlobalSocialBroadcastEngine: React.FC<GlobalSocialBroadcastEngineProps> = ({ onShowToast }) => {
  const uploadedMedia = offlineCache.getUploadedMedia();

  // Active Update to broadcast
  const [selectedUpdate, setSelectedUpdate] = useState<BroadcastUpdateItem>(() => {
    if (uploadedMedia.length > 0) {
      const first = uploadedMedia[0];
      return {
        id: first.id,
        type: first.type === 'video' ? 'sermon' : 'track',
        title: first.title,
        description: first.description,
        speakerOrArtist: first.artistOrProphet,
        url: 'https://juhnkrixmusika.pages.dev',
        tags: first.tags || ['prophetic', 'worship', '528hz']
      };
    }
    return {
      id: 'default-update',
      type: 'track',
      title: '528Hz Prophetic Atmosphere of Glory',
      description: 'Divine breakthrough encounter drenching you in apostolic power and healing frequencies.',
      speakerOrArtist: 'Prophet JUHNKRIX SYNVAGORD',
      url: 'https://juhnkrixmusika.pages.dev',
      tags: ['prophetic', 'worship', '528hz', 'glory', 'juhnkrixmusika']
    };
  });

  const [customTitle, setCustomTitle] = useState(selectedUpdate.title);
  const [customDescription, setCustomDescription] = useState(selectedUpdate.description);
  const [customTags, setCustomTags] = useState((selectedUpdate.tags || []).join(', '));

  // Dispatch Log State
  const [isDispatching, setIsDispatching] = useState<boolean>(false);
  const [dispatchLogs, setDispatchLogs] = useState<string[]>([
    `[BROADCASTER ENGINE] Standby. Linked to Prophet JUHNKRIX SYNVAGORD (${socialBroadcastEngine.ownerEmail}).`,
    `[OFFICIAL CONTACTS] Phone lines configured: ${socialBroadcastEngine.ownerPhone1} | ${socialBroadcastEngine.ownerPhone2}.`,
    `[GLOBAL DOMAIN] Deep link target: ${socialBroadcastEngine.officialDomain}`
  ]);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const activeItem: BroadcastUpdateItem = {
    ...selectedUpdate,
    title: customTitle,
    description: customDescription,
    tags: customTags.split(',').map(s => s.trim().replace(/^#/, '')).filter(Boolean)
  };

  const fullBroadcastMessage = socialBroadcastEngine.generateBroadcastMessage(activeItem);

  const handleCopyText = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
    if (onShowToast) onShowToast(`✓ Copied ${key} message template!`);
  };

  const handleTriggerBroadcastAll = async () => {
    setIsDispatching(true);
    await socialBroadcastEngine.dispatchMultiPlatformSync(activeItem, (msg) => {
      setDispatchLogs(prev => [msg, ...prev.slice(0, 15)]);
    });
    setIsDispatching(false);
    if (onShowToast) onShowToast('✓ Broadcasted update across all social media endpoints!');
  };

  const handleShareAction = (action: () => void) => {
    updateSocialMetadata(
      activeItem.title,
      activeItem.description,
      'https://juhnkrixmusika.pages.dev/icon-512.png',
      activeItem.url || socialBroadcastEngine.officialDomain
    );
    action();
  };

  const platforms = [
    {
      id: 'whatsapp',
      name: 'WhatsApp (Instant Share)',
      desc: 'Opens formatted broadcast to WhatsApp status, groups & contacts',
      color: 'from-emerald-600 to-green-700',
      badge: 'Direct API',
      action: () => handleShareAction(() => window.open(socialBroadcastEngine.getWhatsAppShareUrl(activeItem), '_blank')),
      copyText: fullBroadcastMessage
    },
    {
      id: 'facebook',
      name: 'Facebook (Feed & Stories)',
      desc: 'Shares official update directly to Facebook feed with deep link preview',
      color: 'from-blue-600 to-indigo-700',
      badge: 'Feed & Stories',
      action: () => handleShareAction(() => window.open(socialBroadcastEngine.getFacebookShareUrl(activeItem), '_blank')),
      copyText: fullBroadcastMessage
    },
    {
      id: 'twitter',
      name: 'Twitter / X (Intent Post)',
      desc: 'Fires viral tweet with tagged hashtags (#prophetic, #528hz, #juhnkrixmusika)',
      color: 'from-sky-500 to-blue-600',
      badge: 'Tweet Intent',
      action: () => handleShareAction(() => window.open(socialBroadcastEngine.getTwitterShareUrl(activeItem), '_blank')),
      copyText: `🔥 ${activeItem.title} - Stream on JUHNKRIX MUSIKA APP! ${activeItem.url}`
    },
    {
      id: 'telegram',
      name: 'Telegram (Channel Broadcast)',
      desc: 'Posts formatted broadcast to Telegram channels, prayer groups and bots',
      color: 'from-cyan-500 to-blue-600',
      badge: 'Channel Forward',
      action: () => handleShareAction(() => window.open(socialBroadcastEngine.getTelegramShareUrl(activeItem), '_blank')),
      copyText: fullBroadcastMessage
    },
    {
      id: 'youtube',
      name: 'YouTube Community Tab',
      desc: 'Pre-formatted Community post with timestamps, phone lines & link-in-description',
      color: 'from-red-600 to-rose-700',
      badge: 'Community Post',
      action: () => handleShareAction(() => handleCopyText('YouTube', socialBroadcastEngine.getYouTubeCommunityPost(activeItem))),
      copyText: socialBroadcastEngine.getYouTubeCommunityPost(activeItem)
    },
    {
      id: 'tiktok',
      name: 'TikTok (Reels & Sounds)',
      desc: 'Generates viral short-video captions, hashtags and sound description',
      color: 'from-pink-600 to-purple-700',
      badge: 'Viral Caption',
      action: () => handleShareAction(() => handleCopyText('TikTok', socialBroadcastEngine.getTikTokCaption(activeItem))),
      copyText: socialBroadcastEngine.getTikTokCaption(activeItem)
    },
    {
      id: 'instagram',
      name: 'Instagram (Bio & Stories)',
      desc: 'Optimized for Instagram captions, broadcast channel notes & Story link stickers',
      color: 'from-purple-600 to-pink-600',
      badge: 'Story Link',
      action: () => handleShareAction(() => handleCopyText('Instagram', fullBroadcastMessage)),
      copyText: fullBroadcastMessage
    },
    {
      id: 'email',
      name: 'Official Email Broadcast',
      desc: `Direct mailto dispatcher routing from ${socialBroadcastEngine.ownerEmail}`,
      color: 'from-amber-600 to-yellow-600',
      badge: socialBroadcastEngine.ownerEmail,
      action: () => handleShareAction(() => window.open(socialBroadcastEngine.getEmailBroadcastUrl(activeItem), '_blank')),
      copyText: fullBroadcastMessage
    },
    {
      id: 'sms',
      name: 'SMS Altar Prayer Line',
      desc: `Quick SMS text linked to ${socialBroadcastEngine.ownerPhone1} / ${socialBroadcastEngine.ownerPhone2}`,
      color: 'from-slate-700 to-slate-900',
      badge: 'Direct SMS',
      action: () => handleShareAction(() => window.open(socialBroadcastEngine.getSmsBroadcastUrl(activeItem), '_blank')),
      copyText: `JUHNKRIX MUSIKA UPDATE: ${activeItem.title} - Stream now at ${activeItem.url}`
    }
  ];

  return (
    <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 space-y-8 shadow-2xl">
      {/* Top Banner with Prophet Account Binding */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 border-b border-amber-500/20 pb-6">
        <div className="space-y-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>Multi-Platform Auto-Sharing & Broadcast Engine</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-serif text-amber-100">
            Global Social Media & Internet Broadcast Machine
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
            Automatically sends and broadcasts JUHNKRIX MUSIKA app music tracks, video sermons, devotionals, and updates across 
            <strong> Facebook, Instagram, WhatsApp, TikTok, YouTube, Telegram, Twitter/X, and Email</strong>.
          </p>
        </div>

        {/* Prophet Credentials Badge */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-1.5 font-mono text-xs shadow-xl">
          <div className="text-[10px] text-amber-400 uppercase font-bold tracking-wider">
            Verified Ministry Account Credentials:
          </div>
          <div className="flex items-center space-x-2 text-slate-200">
            <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="text-amber-300 font-bold">{socialBroadcastEngine.ownerEmail}</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-300 text-[11px]">
            <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>{socialBroadcastEngine.ownerPhone1} • {socialBroadcastEngine.ownerPhone2}</span>
          </div>
          <div className="flex items-center space-x-2 text-slate-400 text-[10px]">
            <Globe className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="text-emerald-300">{socialBroadcastEngine.officialDomain}</span>
          </div>
        </div>
      </div>

      {/* AUTOMATIC JM-CRYPTO STAMP NOTIFICATION BROADCAST BANNER */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/80 via-slate-950 to-amber-950/50 border-2 border-amber-500/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-start space-x-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-400 flex-shrink-0">
            <Coins className="w-5 h-5 text-amber-400" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase bg-amber-500 text-slate-950">
                AUTO-STAMP INCLUDED
              </span>
              <span className="text-xs font-bold text-amber-200 font-serif">
                JM-CRYPTO MINER & WEB3 APP PROMOTION ATTACHED
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              Every broadcast post automatically includes the official stamp notification: 
              <span className="text-amber-300 font-bold ml-1">"DO YOU KNOW THAT JUHNKRIX MUSIKA IS BEYOND MUSIC? YOU CAN ABSOLUTELY MINE REAL CRYPTO CURRENCY... juhnkrixmusika.pages.dev"</span> ensuring all friends and followers on Facebook, WhatsApp, Twitter/X, TikTok, and Instagram instantly see the promotion.
            </p>
          </div>
        </div>
        <a
          href="https://juhnkrixmusika.pages.dev"
          target="_blank"
          rel="noopener noreferrer"
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow transition-all hover:scale-105 flex items-center space-x-1.5 flex-shrink-0"
        >
          <span>juhnkrixmusika.pages.dev</span>
          <ExternalLink className="w-3.5 h-3.5 text-slate-950" />
        </a>
      </div>

      {/* Broadcast Content Composer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-950/80 p-6 rounded-2xl border border-amber-500/20 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
            <h3 className="text-sm font-bold text-amber-200 flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Select or Customize App Update to Broadcast</span>
            </h3>
            {uploadedMedia.length > 0 && (
              <span className="text-[10px] font-mono text-slate-400">
                {uploadedMedia.length} Uploaded Items Available
              </span>
            )}
          </div>

          {/* Quick Select from existing media */}
          {uploadedMedia.length > 0 && (
            <div>
              <label className="text-[10px] font-semibold text-slate-400 block mb-1">
                Pick from Inbuilt Vault (Auto-populates fields):
              </label>
              <select
                onChange={(e) => {
                  const item = uploadedMedia.find(m => m.id === e.target.value);
                  if (item) {
                    setSelectedUpdate({
                      id: item.id,
                      type: item.type === 'video' ? 'sermon' : 'track',
                      title: item.title,
                      description: item.description,
                      speakerOrArtist: item.artistOrProphet,
                      url: 'https://juhnkrixmusika.pages.dev',
                      tags: item.tags || ['prophetic', 'worship']
                    });
                    setCustomTitle(item.title);
                    setCustomDescription(item.description);
                    setCustomTags((item.tags || []).join(', '));
                  }
                }}
                className="w-full bg-slate-900 text-amber-200 border border-amber-500/30 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-400 font-mono"
              >
                {uploadedMedia.map(m => (
                  <option key={m.id} value={m.id}>
                    [{m.type.toUpperCase()}] {m.title} — {m.artistOrProphet}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="space-y-3">
            <div>
              <label className="text-[11px] font-bold text-amber-300 block mb-1">Update Title</label>
              <input
                type="text"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2 text-xs font-bold focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-amber-300 block mb-1">Prophetic Decree / Description</label>
              <textarea
                rows={2}
                value={customDescription}
                onChange={(e) => setCustomDescription(e.target.value)}
                className="w-full bg-slate-900 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-amber-300 block mb-1">Searchable Hashtags & Keywords</label>
              <input
                type="text"
                value={customTags}
                onChange={(e) => setCustomTags(e.target.value)}
                placeholder="prophetic, worship, 528hz, healing, altar"
                className="w-full bg-slate-900 text-amber-200 border border-amber-500/30 rounded-xl px-3.5 py-2 text-xs font-mono focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Action Row */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
            <button
              onClick={handleTriggerBroadcastAll}
              disabled={isDispatching}
              className={`w-full sm:w-auto px-6 py-3 rounded-xl font-extrabold text-xs flex items-center justify-center space-x-2 transition-all shadow-xl ${
                isDispatching
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-400 hover:scale-105 text-slate-950 border border-amber-300'
              }`}
            >
              <Send className="w-4 h-4 text-slate-950" />
              <span>{isDispatching ? 'Broadcasting Across Internet...' : '⚡ Broadcast to All World Platforms Now'}</span>
            </button>
            <button
              onClick={() => handleCopyText('Master', fullBroadcastMessage)}
              className="w-full sm:w-auto px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold flex items-center justify-center space-x-2 transition-all"
            >
              <Copy className="w-4 h-4" />
              <span>{copiedKey === 'Master' ? 'Copied Master!' : 'Copy Master Post'}</span>
            </button>
          </div>
        </div>

        {/* Live Broadcast Dispatcher Logs */}
        <div className="bg-slate-950/80 p-5 rounded-2xl border border-amber-500/20 space-y-3 flex flex-col justify-between shadow-xl">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-amber-400 uppercase tracking-wider font-bold">
                Broadcast Dispatch Monitor
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </div>
            <div className="space-y-1.5 overflow-y-auto max-h-60 pr-1 font-mono text-[10px]">
              {dispatchLogs.map((log, idx) => (
                <div key={idx} className="p-1.5 rounded bg-slate-900/60 border border-amber-500/10 text-slate-300 leading-tight">
                  {log}
                </div>
              ))}
            </div>
          </div>

          <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/20 text-center text-[10px] font-mono text-amber-300">
            Auto-Sync active across all world social platforms
          </div>
        </div>
      </div>

      {/* Grid of All World Social Media Platforms with 1-Click Triggers */}
      <div className="space-y-4 pt-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-amber-200 flex items-center space-x-2">
            <Globe className="w-4 h-4 text-amber-400" />
            <span>Connected World Platforms & Direct Sharing Portals ({platforms.length})</span>
          </h3>
          <span className="text-[10px] font-mono text-slate-400">Click to share instantly or copy formatted copy</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {platforms.map(p => (
            <div
              key={p.id}
              className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 space-y-3 flex flex-col justify-between hover:border-amber-400/50 transition-all shadow-lg"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-100">{p.name}</span>
                  <span className="text-[9px] font-mono bg-amber-500/10 text-amber-300 px-2 py-0.5 rounded border border-amber-500/20">
                    {p.badge}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">{p.desc}</p>
              </div>

              <div className="flex items-center space-x-2 pt-2 border-t border-amber-500/10">
                <button
                  onClick={p.action}
                  className="flex-1 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all shadow"
                >
                  <Share2 className="w-3.5 h-3.5 text-slate-950" />
                  <span>Share / Open</span>
                </button>
                <button
                  onClick={() => handleCopyText(p.name, p.copyText)}
                  className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs transition-all"
                  title={`Copy ${p.name} template`}
                >
                  {copiedKey === p.name ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
