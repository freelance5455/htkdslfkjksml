import React, { useId } from 'react';
import { AssistantState } from '../types/jarvis';
import { Mic, Volume2, Cpu, AlertTriangle, Moon, Radio } from 'lucide-react';

interface ArcReactorProps {
  state: AssistantState;
  onToggleListen: () => void;
  interimTranscript?: string;
  languageLabel?: string;
  isMicAvailable: boolean;
  isHandsFreeActive: boolean;
  isBargeInNotice?: boolean;
}

export const ArcReactor: React.FC<ArcReactorProps> = ({
  state,
  onToggleListen,
  interimTranscript,
  languageLabel = 'AUTO',
  isMicAvailable,
  isHandsFreeActive,
  isBargeInNotice = false,
}) => {
  const gradientId = useId();

  // Primary status label
  const getStatusText = () => {
    if (isBargeInNotice) {
      return languageLabel === 'BN'
        ? 'থেমেছি • আপনার কথা শুনছি'
        : 'INTERRUPTED • LISTENING TO YOU';
    }

    switch (state) {
      case 'sleeping':
        return isHandsFreeActive
          ? languageLabel === 'BN'
            ? "স্ট্যান্ডবাই • জাগাতে 'জার্ভিস' বলুন"
            : "STANDBY • SAY 'JARVIS' TO WAKE"
          : languageLabel === 'BN'
          ? 'স্ট্যান্ডবাই • স্পর্শ করে জাগান'
          : 'STANDBY • TAP TO WAKE';
      case 'listening':
        return languageLabel === 'BN'
          ? 'আপনার নির্দেশের অপেক্ষায়...'
          : 'LISTENING FOR COMMAND...';
      case 'thinking':
        return languageLabel === 'BN'
          ? 'জেমিনির মাধ্যমে ভাবছি...'
          : 'PROCESSING WITH GEMINI...';
      case 'speaking':
        return languageLabel === 'BN'
          ? 'বলছি • থামাতে স্পর্শ বা কথা বলুন'
          : 'SPEAKING • TAP OR TALK TO INTERRUPT';
      case 'error':
        return languageLabel === 'BN' ? 'সিস্টেম অ্যালার্ট' : 'SYSTEM ALERT';
      default:
        return 'STANDBY';
    }
  };

  // Sub-status guidance
  const getSubStatus = () => {
    if (isBargeInNotice) {
      return languageLabel === 'BN'
        ? 'বার্জ-ইন সক্রিয় • নির্দেশনা বলুন'
        : 'BARGE-IN ENGAGED • SPEAK COMMAND';
    }

    switch (state) {
      case 'sleeping':
        return languageLabel === 'BN'
          ? "জাগাতে: 'জার্ভিস' • থামাতে: 'এখন থামো'"
          : "WAKE: 'JARVIS' • STOP: 'STOP NOW'";
      case 'listening':
        return isHandsFreeActive
          ? languageLabel === 'BN'
            ? 'কন্টিনিউয়াস ভয়েস মোড চালু'
            : 'CONTINUOUS HANDS-FREE ACTIVE'
          : languageLabel === 'BN'
          ? 'অডিও সেন্সর চালু'
          : 'AUDIO SENSOR RECEIVING';
      case 'thinking':
        return languageLabel === 'BN'
          ? 'নিউরাল মেট্রিক্স কম্পিউটিং'
          : 'NEURAL MATRIX COMPUTING';
      case 'speaking':
        return languageLabel === 'BN'
          ? 'থামাতে "এখন থামো" বা "জার্ভিস" বলুন'
          : 'SAY "STOP NOW" OR TAP TO CUT OFF';
      case 'error':
        return languageLabel === 'BN'
          ? 'অনুমতি ও সেন্সর পরীক্ষা করুন'
          : 'CHECK PERMISSIONS / SENSORS';
      default:
        return 'ALL SYSTEMS NOMINAL';
    }
  };

  return (
    <div className="relative flex flex-col items-center justify-center select-none w-full max-w-sm mx-auto px-4">
      {/* Hands-Free Mode Indicator Badge */}
      <div className="mb-2">
        <div
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono border transition-all ${
            isHandsFreeActive
              ? 'bg-cyan-950/80 border-cyan-400/60 text-cyan-200 shadow-[0_0_12px_rgba(0,240,255,0.25)]'
              : 'bg-slate-900/60 border-slate-700/50 text-slate-400'
          }`}
        >
          <Radio
            className={`w-3.5 h-3.5 ${
              isHandsFreeActive ? 'text-cyan-400 animate-pulse' : 'text-slate-500'
            }`}
          />
          <span className="font-semibold tracking-wider">
            {isHandsFreeActive ? 'HANDS-FREE: ACTIVE' : 'PUSH-TO-TALK MODE'}
          </span>
        </div>
      </div>

      {/* Outer Glow Halo */}
      <div
        className={`absolute w-72 h-72 sm:w-84 sm:h-84 rounded-full blur-3xl pointer-events-none transition-all duration-700 ${
          state === 'listening'
            ? 'bg-cyan-500/35 scale-110'
            : state === 'speaking'
            ? 'bg-blue-500/35 scale-105'
            : state === 'thinking'
            ? 'bg-sky-400/25 scale-100'
            : state === 'error'
            ? 'bg-amber-500/20 scale-95'
            : 'bg-cyan-950/20 scale-85 opacity-60'
        }`}
      />

      {/* Ripple Rings when in active Listening state */}
      {state === 'listening' && (
        <>
          <div className="absolute w-64 h-64 sm:w-72 sm:h-72 rounded-full border border-cyan-400/40 animate-ping pointer-events-none" />
          <div className="absolute w-72 h-72 sm:w-80 sm:h-80 rounded-full border border-cyan-300/25 animate-pulse pointer-events-none" />
        </>
      )}

      {/* Main Interactive Arc Reactor Unit */}
      <button
        onClick={onToggleListen}
        type="button"
        aria-label="Toggle voice listening"
        className="relative group w-60 h-60 sm:w-72 sm:h-72 rounded-full flex items-center justify-center p-2 cursor-pointer focus:outline-none transition-transform active:scale-95 touch-manipulation"
      >
        {/* SVG Arc Reactor Construction */}
        <svg
          viewBox="0 0 280 280"
          className="w-full h-full drop-shadow-[0_0_20px_rgba(0,240,255,0.4)]"
        >
          <defs>
            <radialGradient id={`${gradientId}-core`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity={state === 'sleeping' ? 0.7 : 1} />
              <stop offset="35%" stopColor="#38bdf8" stopOpacity={state === 'sleeping' ? 0.5 : 0.9} />
              <stop offset="70%" stopColor="#0284c7" stopOpacity={state === 'sleeping' ? 0.4 : 0.7} />
              <stop offset="100%" stopColor="#030712" stopOpacity="0.4" />
            </radialGradient>

            <linearGradient id={`${gradientId}-ring`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00f0ff" />
              <stop offset="50%" stopColor="#0284c7" />
              <stop offset="100%" stopColor="#00f0ff" />
            </linearGradient>

            <filter id={`${gradientId}-glow`} x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Outer Housing Ring */}
          <circle
            cx="140"
            cy="140"
            r="134"
            fill="none"
            stroke="rgba(0, 240, 255, 0.2)"
            strokeWidth="2"
            strokeDasharray="4 8"
          />

          {/* Rotating Telemetry Ring Outer */}
          <g
            className={`${
              state === 'thinking'
                ? 'animate-spin-medium'
                : state === 'listening' || state === 'speaking'
                ? 'animate-spin-slow'
                : 'animate-spin-slow opacity-40'
            } origin-center`}
          >
            <circle
              cx="140"
              cy="140"
              r="126"
              fill="none"
              stroke={`url(#${gradientId}-ring)`}
              strokeWidth="2.5"
              strokeDasharray="60 30 15 30 90 20"
              filter={`url(#${gradientId}-glow)`}
            />
            {/* Cardinal Tick Marks */}
            <line x1="140" y1="8" x2="140" y2="18" stroke="#00f0ff" strokeWidth="2.5" />
            <line x1="140" y1="262" x2="140" y2="272" stroke="#00f0ff" strokeWidth="2.5" />
            <line x1="8" y1="140" x2="18" y2="140" stroke="#00f0ff" strokeWidth="2.5" />
            <line x1="262" y1="140" x2="272" y2="140" stroke="#00f0ff" strokeWidth="2.5" />
          </g>

          {/* Counter-rotating Segmented Ring */}
          <g
            className={`${
              state === 'thinking'
                ? 'animate-spin-reverse'
                : 'animate-spin-reverse opacity-60'
            } origin-center`}
          >
            <circle
              cx="140"
              cy="140"
              r="112"
              fill="none"
              stroke="rgba(56, 189, 248, 0.5)"
              strokeWidth="4"
              strokeDasharray="18 10"
            />
          </g>

          {/* Hexagonal / 10-Segmented Inductor Coils (Arc Reactor design) */}
          <g>
            {[0, 36, 72, 108, 144, 180, 216, 252, 288, 324].map((angle, index) => {
              const rad = (angle * Math.PI) / 180;
              const x1 = 140 + Math.cos(rad) * 80;
              const y1 = 140 + Math.sin(rad) * 80;
              const x2 = 140 + Math.cos(rad) * 102;
              const y2 = 140 + Math.sin(rad) * 102;
              const active =
                state === 'listening' ||
                state === 'speaking' ||
                (state === 'thinking' && index % 2 === 0);

              return (
                <line
                  key={angle}
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke={active ? '#00f0ff' : 'rgba(0, 240, 255, 0.25)'}
                  strokeWidth={active ? '5' : '3.5'}
                  strokeLinecap="round"
                  className="transition-all duration-300"
                />
              );
            })}
          </g>

          {/* Inner Glowing Torus */}
          <circle
            cx="140"
            cy="140"
            r="72"
            fill="none"
            stroke="rgba(0, 240, 255, 0.4)"
            strokeWidth="3"
            filter={`url(#${gradientId}-glow)`}
          />

          {/* Inner Accent Ring with dynamic rotation */}
          <g className={`${state === 'speaking' ? 'animate-spin-medium' : ''} origin-center`}>
            <circle
              cx="140"
              cy="140"
              r="62"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="1.5"
              strokeDasharray="12 8 4 8"
            />
          </g>

          {/* High Energy Central Core Crystal */}
          <circle
            cx="140"
            cy="140"
            r={state === 'listening' ? 52 : state === 'speaking' ? 48 : 42}
            fill={`url(#${gradientId}-core)`}
            className="transition-all duration-300"
            filter={`url(#${gradientId}-glow)`}
          />

          {/* Core Triangular / Hex Geometry Overlay */}
          <polygon
            points="140,105 170,158 110,158"
            fill="none"
            stroke="rgba(255, 255, 255, 0.85)"
            strokeWidth="2"
            className={`${
              state === 'thinking' ? 'animate-spin-slow' : ''
            } origin-center transition-all`}
          />
          <polygon
            points="140,175 110,122 170,122"
            fill="none"
            stroke="rgba(0, 240, 255, 0.7)"
            strokeWidth="1.5"
            className={`${
              state === 'thinking' ? 'animate-spin-reverse' : ''
            } origin-center transition-all`}
          />
        </svg>

        {/* Central Icon Indicator in Center of Core */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          {state === 'sleeping' ? (
            <div className="flex flex-col items-center">
              <Moon className="w-8 h-8 text-cyan-900 group-hover:scale-110 transition-transform drop-shadow" />
            </div>
          ) : state === 'listening' ? (
            <div className="flex flex-col items-center">
              <Mic className="w-8 h-8 text-slate-900 animate-pulse drop-shadow" />
            </div>
          ) : state === 'speaking' ? (
            <div className="flex flex-col items-center">
              <Volume2 className="w-8 h-8 text-slate-900 animate-bounce drop-shadow" />
            </div>
          ) : state === 'thinking' ? (
            <Cpu className="w-8 h-8 text-slate-900 animate-spin drop-shadow" />
          ) : (
            <AlertTriangle className="w-8 h-8 text-amber-900 drop-shadow" />
          )}
        </div>
      </button>

      {/* Futuristic Status Readout */}
      <div className="mt-4 text-center">
        <div className="flex items-center justify-center gap-2">
          <span
            className={`w-2.5 h-2.5 rounded-full ${
              state === 'listening'
                ? 'bg-cyan-400 animate-ping'
                : state === 'speaking'
                ? 'bg-blue-400 animate-pulse'
                : state === 'thinking'
                ? 'bg-sky-400 animate-spin'
                : state === 'sleeping'
                ? 'bg-cyan-800'
                : 'bg-amber-400'
            }`}
          />
          <h2
            className={`text-sm sm:text-base font-bold font-tech tracking-wider uppercase transition-colors ${
              state === 'listening'
                ? 'text-cyan-300 glow-text-cyan'
                : state === 'speaking'
                ? 'text-blue-300 glow-text-blue'
                : state === 'thinking'
                ? 'text-sky-300'
                : state === 'sleeping'
                ? 'text-cyan-400/80'
                : 'text-amber-400'
            }`}
          >
            {getStatusText()}
          </h2>
        </div>

        <p className="text-xs text-cyan-400/70 font-mono mt-1 tracking-widest uppercase">
          {getSubStatus()} • LANG: {languageLabel}
        </p>
      </div>

      {/* Live Interim Speech Recognition Transcript Bubble */}
      {interimTranscript && (
        <div className="mt-3 px-4 py-2 rounded-full border border-cyan-400/40 bg-cyan-950/70 backdrop-blur-md max-w-xs text-center shadow-lg shadow-cyan-500/10 animate-fade-in">
          <p className="text-xs text-cyan-200 font-medium italic truncate">
            "{interimTranscript}"
          </p>
        </div>
      )}

      {/* Mic Warning for mobile users if not supported */}
      {!isMicAvailable && (
        <div className="mt-3 px-3 py-1.5 rounded-lg border border-amber-500/30 bg-amber-950/40 text-amber-300 text-xs text-center">
          Speech recognition requires Chrome on Android or compatible browser
        </div>
      )}
    </div>
  );
};
