interface ArcReactorProps {
  status: 'idle' | 'thinking' | 'streaming' | 'listening' | 'speaking' | 'error';
  memoryCount: number;
  openTaskCount: number;
  voiceLabel?: string;
  compact?: boolean;
}

export function ArcReactor({
  status,
  memoryCount,
  openTaskCount,
  voiceLabel,
  compact = false,
}: ArcReactorProps) {
  const isBusy = status === 'thinking' || status === 'streaming' || status === 'listening' || status === 'speaking';
  const isError = status === 'error';

  const statusLabel =
    status === 'listening'
      ? 'Listening'
      : status === 'speaking'
        ? 'Speaking'
        : status === 'thinking'
          ? 'Thinking'
          : status === 'streaming'
            ? 'Responding'
            : status === 'error'
              ? 'Connection Issue'
              : 'Online';

  if (compact) {
    return (
      <div
        className="flex items-center gap-3"
        data-testid="arc-reactor"
        data-reactor-status={status}
      >
        <div className="relative flex h-10 w-10 shrink-0 items-center justify-center">
          <svg
            viewBox="0 0 100 100"
            className="h-10 w-10"
            aria-hidden="true"
          >
            <circle
              cx="50"
              cy="50"
              r="44"
              fill="none"
              stroke={isError ? '#F43F5E' : '#F59E0B'}
              strokeOpacity="0.45"
              strokeWidth="2"
              strokeDasharray="16 8 4 8"
              className={`origin-center ${isBusy ? 'animate-reactor-active' : 'animate-reactor-slow'}`}
            />
            <circle
              cx="50"
              cy="50"
              r="34"
              fill="none"
              stroke={isError ? '#FB7185' : '#38BDF8'}
              strokeOpacity="0.85"
              strokeWidth="2.5"
              strokeDasharray="24 10"
              className={`origin-center ${isBusy ? 'animate-reactor-active-reverse' : 'animate-reactor-reverse'}`}
            />
            <circle
              cx="50"
              cy="50"
              r="18"
              fill={isError ? 'rgba(244,63,94,0.22)' : 'rgba(56,189,248,0.2)'}
              stroke={isError ? '#FDA4AF' : '#7DD3FC'}
              strokeWidth="2"
            />
            <circle
              cx="50"
              cy="50"
              r="6"
              fill={isError ? '#FDA4AF' : '#E0F2FE'}
            />
          </svg>
        </div>

        <div className="min-w-0">
          <div className="flex items-center gap-2 text-xs font-medium text-slate-200">
            <span className={isBusy ? 'text-sky-300' : isError ? 'text-rose-300' : 'text-slate-100'}>
              {statusLabel}
            </span>
            <span aria-hidden="true" className="text-slate-600">
              ·
            </span>
            <span className="font-mono text-amber-300/90 tabular-nums">
              {memoryCount} memories
            </span>
            {openTaskCount > 0 && (
              <>
                <span aria-hidden="true" className="text-slate-600 hidden sm:inline">
                  ·
                </span>
                <span className="hidden font-mono text-slate-400 tabular-nums sm:inline">
                  {openTaskCount} open tasks
                </span>
              </>
            )}
          </div>
          <p className="truncate text-xs text-slate-400">
            {status === 'listening'
              ? 'Listening on built-in mic · Tap Stop anytime'
              : status === 'speaking'
                ? 'Speaking reply aloud · Tap Stop to interrupt'
                : isBusy
                  ? 'Streaming response progressively…'
                  : voiceLabel
                    ? `${voiceLabel} · Enter to send or tap Talk`
                    : 'Press Enter to send · Shift+Enter for new line'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="flex flex-col items-center text-center"
      data-testid="arc-reactor"
      data-reactor-status={status}
    >
      <div className="relative flex h-40 w-40 items-center justify-center">
        {/* Subtle ambient radial aura using pure CSS gradient */}
        <div
          aria-hidden="true"
          className={`pointer-events-none absolute inset-2 rounded-full transition-opacity duration-300 ${
            isBusy ? 'opacity-90' : 'opacity-55'
          }`}
          style={{
            background: isError
              ? 'radial-gradient(circle, rgba(244,63,94,0.24) 0%, rgba(5,7,11,0) 72%)'
              : 'radial-gradient(circle, rgba(56,189,248,0.22) 0%, rgba(245,158,11,0.08) 45%, rgba(5,7,11,0) 74%)',
          }}
        />

        <svg viewBox="0 0 200 200" className="relative h-40 w-40" aria-hidden="true">
          {/* Outer Gold Stark Gimbal Ring */}
          <circle
            cx="100"
            cy="100"
            r="90"
            fill="none"
            stroke="#F59E0B"
            strokeOpacity="0.42"
            strokeWidth="2"
            strokeDasharray="28 12 6 12"
            className={`origin-center ${isBusy ? 'animate-reactor-active' : 'animate-reactor-slow'}`}
          />

          {/* Outer Precision Tick Ring */}
          <circle
            cx="100"
            cy="100"
            r="80"
            fill="none"
            stroke="#38BDF8"
            strokeOpacity="0.22"
            strokeWidth="1"
          />

          {/* Segmented Arc Reactor Ring */}
          <circle
            cx="100"
            cy="100"
            r="66"
            fill="none"
            stroke={isError ? '#FB7185' : '#38BDF8'}
            strokeOpacity="0.88"
            strokeWidth="4"
            strokeDasharray="32 14"
            className={`origin-center ${isBusy ? 'animate-reactor-active-reverse' : 'animate-reactor-reverse'}`}
          />

          {/* Inner Gold Accent Collar */}
          <circle
            cx="100"
            cy="100"
            r="50"
            fill="none"
            stroke="#FBBF24"
            strokeOpacity="0.55"
            strokeWidth="1.5"
            strokeDasharray="12 10"
            className={`origin-center ${isBusy ? 'animate-reactor-active' : 'animate-reactor-slow'}`}
          />

          {/* Reactor Core Triangle Geometry */}
          <polygon
            points="100,66 130,118 70,118"
            fill="none"
            stroke="#7DD3FC"
            strokeOpacity="0.55"
            strokeWidth="1.5"
          />

          {/* Central Energy Core */}
          <circle
            cx="100"
            cy="100"
            r="26"
            fill={isError ? 'rgba(244,63,94,0.18)' : 'rgba(14,165,233,0.18)'}
            stroke={isError ? '#FDA4AF' : '#7DD3FC'}
            strokeWidth="2.5"
          />
          <circle
            cx="100"
            cy="100"
            r="10"
            fill={isError ? '#FDA4AF' : '#E0F2FE'}
          />
        </svg>
      </div>

      <div className="mt-2 flex items-center gap-2 text-xs font-medium text-slate-300">
        <span className={isBusy ? 'text-sky-300' : 'text-amber-300'}>{statusLabel}</span>
        <span aria-hidden="true" className="text-slate-600">
          ·
        </span>
        <span className="font-mono text-slate-300 tabular-nums">
          {memoryCount} saved {memoryCount === 1 ? 'memory' : 'memories'}
        </span>
        {openTaskCount > 0 && (
          <>
            <span aria-hidden="true" className="text-slate-600">
              ·
            </span>
            <span className="font-mono text-sky-300 tabular-nums">
              {openTaskCount} open {openTaskCount === 1 ? 'task' : 'tasks'}
            </span>
          </>
        )}
      </div>
    </div>
  );
}
