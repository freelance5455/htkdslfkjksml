import React, { useState, useEffect } from 'react';
import { TrendingHashtag, TrendingTopic } from '../../types';
import { api, ANGOLA_PROVINCES } from '../../services/api';
import { Flame, Hash, MapPin, Newspaper, Users, ArrowUpRight, TrendingUp } from 'lucide-react';

interface TrendsViewProps {
  onHashtagClick: (tag: string) => void;
}

export const TrendsView: React.FC<TrendsViewProps> = ({ onHashtagClick }) => {
  const [hashtags, setHashtags] = useState<TrendingHashtag[]>([]);
  const [topics, setTopics] = useState<TrendingTopic[]>([]);
  const [selectedProvince, setSelectedProvince] = useState('Todas');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchTrends = async () => {
      try {
        setIsLoading(true);
        const res = await api.getTrends(selectedProvince !== 'Todas' ? selectedProvince : undefined);
        setHashtags(res.trendingHashtags || []);
        setTopics(res.trendingTopics || []);
      } catch (err) {
        console.error('Erro ao obter tendências:', err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchTrends();
  }, [selectedProvince]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-red-600/20 text-red-500 flex items-center justify-center">
              <Flame className="w-5 h-5 fill-red-500/20" />
            </span>
            <h1 className="text-2xl font-bold text-white font-display">Angola Agora 🇦🇴</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Os assuntos mais falados, acontecimentos e hashtags em alta nas 18 províncias de Angola.
          </p>
        </div>

        {/* Province Filter */}
        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 self-start sm:self-auto">
          <MapPin className="w-4 h-4 text-amber-500 shrink-0" />
          <select
            value={selectedProvince}
            onChange={(e) => setSelectedProvince(e.target.value)}
            className="bg-transparent text-xs text-white focus:outline-none"
          >
            {ANGOLA_PROVINCES.map((p) => (
              <option key={p} value={p} className="bg-slate-900 text-white">
                {p === 'Todas' ? 'Todas as Províncias' : p}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

        {/* LEFT COLUMN: Trending Topics & News (7 cols) */}
        <section className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5">
              <Newspaper className="w-4 h-4 text-amber-400" />
              <span>Assuntos do Momento em Angola</span>
            </h2>
            <span className="text-[11px] text-slate-400">Atualizado em tempo real</span>
          </div>

          <div className="space-y-3">
            {topics.map((topic) => (
              <div
                key={topic.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 sm:p-5 transition-all shadow-sm group"
              >
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                  <span className="font-semibold text-amber-400">{topic.category}</span>
                  <span className="flex items-center gap-1 text-slate-500">
                    <MapPin className="w-3 h-3 text-amber-500" />
                    {topic.province} · {topic.timeAgo}
                  </span>
                </div>

                <h3 className="font-bold text-sm sm:text-base text-white group-hover:text-amber-400 transition-colors leading-snug">
                  {topic.title}
                </h3>

                <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <span className="text-slate-300 font-medium">Fonte: {topic.source}</span>
                  <span className="text-amber-400/90 font-mono text-[11px] flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" />
                    {topic.readers}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* RIGHT COLUMN: Trending Hashtags Leaderboard (5 cols) */}
        <section className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-red-500" />
              <span>Hashtags em Alta</span>
            </h2>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 divide-y divide-slate-800/60 shadow-sm">
            {hashtags.map((item, idx) => (
              <button
                key={item.tag}
                onClick={() => onHashtagClick(item.tag)}
                className="w-full py-3.5 flex items-center justify-between text-left hover:bg-slate-950/60 px-2 rounded-xl transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 text-center text-xs font-bold text-slate-500 font-mono">
                    #{idx + 1}
                  </span>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">
                      {item.category}
                    </span>
                    <p className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors">
                      #{item.tag}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-mono text-slate-300 block">
                    {item.count.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-500">publicações</span>
                </div>
              </button>
            ))}
          </div>
        </section>

      </div>

    </div>
  );
};
