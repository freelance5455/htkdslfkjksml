import React, { useState } from 'react';
import {
  DoorClosed,
  BookOpen,
  FileSpreadsheet,
  Tv,
  Wifi,
  WifiOff,
  Volume2,
  VolumeX,
  QrCode,
  Settings,
  Users,
  Church,
} from 'lucide-react';
import { useChurch } from '../context/ChurchContext';
import { TabletRole } from '../types';
import { QRCodeModal } from './QRCodeModal';
import { ServiceSettingsModal } from './ServiceSettingsModal';
import { PWAInstallButton } from './PWAInstallButton';

export const ChurchHeader: React.FC = () => {
  const {
    role,
    setRole,
    service,
    visitors,
    connectionStatus,
    isAudioEnabled,
    setIsAudioEnabled,
    unreadCountForAltar,
  } = useChurch();

  const [isQrOpen, setIsQrOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const pendingCount = visitors.filter((v) => v.status === 'pending').length;
  const presentedCount = visitors.filter((v) => v.status === 'presented').length;

  const roleConfigs: { id: TabletRole; label: string; icon: React.ReactNode; desc: string }[] = [
    {
      id: 'reception',
      label: 'Porta / Recepção',
      icon: <DoorClosed className="h-5 w-5" />,
      desc: 'Cadastrar visitantes',
    },
    {
      id: 'altar',
      label: 'Altar / Dirigente',
      icon: <BookOpen className="h-5 w-5" />,
      desc: 'Leitura no Púlpito',
    },
    {
      id: 'secretary',
      label: 'Secretaria',
      icon: <FileSpreadsheet className="h-5 w-5" />,
      desc: 'WhatsApp & Relatório',
    },
    {
      id: 'presentation',
      label: 'Telão / Mídia',
      icon: <Tv className="h-5 w-5" />,
      desc: 'Projeção Datashow',
    },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 bg-neutral-950/95 backdrop-blur-md border-b border-neutral-800 text-white select-none">
        {/* Top bar with Church name & Status */}
        <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
          {/* Church & Service info */}
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 text-neutral-950 font-black shadow-md shadow-amber-600/20">
              <Church className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold tracking-tight text-white line-clamp-1">
                  {service.churchName || 'Elo Igreja'}
                </h1>
                <span className="hidden sm:inline-block rounded-md bg-amber-500/10 px-2 py-0.5 text-[11px] font-semibold text-amber-400 border border-amber-500/20">
                  {service.title}
                </span>
              </div>
              <p className="text-xs text-neutral-400 flex items-center gap-2">
                <span>Dirigente: <strong className="text-neutral-300">{service.leaderName || 'Pastor'}</strong></span>
                <span className="text-neutral-600">•</span>
                <span className="text-amber-400 font-medium">
                  {visitors.length} {visitors.length === 1 ? 'visitante' : 'visitantes'} hoje
                </span>
              </p>
            </div>
          </div>

          {/* Real-time Status Badge & Utility Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Live Sync Status */}
            <div
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition ${
                connectionStatus === 'connected'
                  ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/30'
                  : connectionStatus === 'connecting'
                  ? 'bg-amber-950/60 text-amber-300 border-amber-500/30 animate-pulse'
                  : 'bg-rose-950/60 text-rose-300 border-rose-500/30'
              }`}
              title={
                connectionStatus === 'connected'
                  ? 'Sincronizado em tempo real com o outro tablet'
                  : 'Reconectando sincronização...'
              }
            >
              {connectionStatus === 'connected' ? (
                <>
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <span className="hidden sm:inline">Tempo Real Ativo</span>
                  <span className="sm:hidden">Ao Vivo</span>
                </>
              ) : (
                <>
                  <WifiOff className="h-3.5 w-3.5" />
                  <span>Reconectando</span>
                </>
              )}
            </div>

            {/* Audio Toggle */}
            <button
              onClick={() => setIsAudioEnabled(!isAudioEnabled)}
              title={isAudioEnabled ? 'Sons de notificação ativados' : 'Sons silenciados'}
              className={`flex items-center justify-center h-9 w-9 rounded-xl border transition ${
                isAudioEnabled
                  ? 'bg-neutral-800 border-neutral-700 text-amber-400 hover:bg-neutral-700'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-neutral-300'
              }`}
            >
              {isAudioEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </button>

            {/* Download / Install App Button */}
            <PWAInstallButton />

            {/* Connect another tablet QR button */}
            <button
              onClick={() => setIsQrOpen(true)}
              className="flex items-center gap-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 px-3 py-1.5 text-xs font-semibold text-neutral-200 transition"
              title="Abrir QR Code para o outro tablet"
            >
              <QrCode className="h-4 w-4 text-amber-400" />
              <span className="hidden md:inline">Conectar Outro Tablet</span>
            </button>

            {/* Service Settings */}
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="flex items-center justify-center h-9 w-9 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-300 transition"
              title="Configurações do Culto"
            >
              <Settings className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Big Touch-Friendly Mode Navigation specifically built for tablets */}
        <div className="bg-neutral-900/90 border-t border-neutral-800/80 px-2 sm:px-4 py-1.5">
          <div className="max-w-7xl mx-auto flex items-center justify-between sm:justify-start gap-1 sm:gap-3 overflow-x-auto no-scrollbar">
            {roleConfigs.map((cfg) => {
              const isActive = role === cfg.id;
              const hasUnread = cfg.id === 'altar' && unreadCountForAltar > 0;
              const countBadge =
                cfg.id === 'altar' && pendingCount > 0 ? pendingCount : null;

              return (
                <button
                  key={cfg.id}
                  onClick={() => setRole(cfg.id)}
                  className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 ${
                    isActive
                      ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                      : 'text-neutral-300 hover:bg-neutral-800 hover:text-white'
                  }`}
                >
                  {cfg.icon}
                  <span>{cfg.label}</span>

                  {/* Badge for altar when visitors are waiting */}
                  {countBadge !== null && (
                    <span
                      className={`ml-1 px-1.5 py-0.5 rounded-full text-[11px] font-bold ${
                        isActive
                          ? 'bg-neutral-950 text-amber-400'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}
                    >
                      {countBadge}
                    </span>
                  )}

                  {/* Red pulsing dot if new visitor just arrived */}
                  {hasUnread && !isActive && (
                    <span className="absolute -top-1 -right-1 flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Modals */}
      <QRCodeModal isOpen={isQrOpen} onClose={() => setIsQrOpen(false)} />
      <ServiceSettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
    </>
  );
};
