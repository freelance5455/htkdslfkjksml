import React, { useState } from 'react';
import { WALLPAPER_PRESETS, DEFAULT_WALLPAPER, fileToBase64 } from '../utils/helpers';
import { Image, Upload, Check, RefreshCw, X } from 'lucide-react';
import { playAppSound } from '../utils/audio';

interface WallpaperModalProps {
  currentWallpaper: string;
  currentOverlayOpacity: number;
  onSave: (url: string, opacity: number) => void;
  onClose: () => void;
}

export const WallpaperModal: React.FC<WallpaperModalProps> = ({
  currentWallpaper,
  currentOverlayOpacity,
  onSave,
  onClose
}) => {
  const [selectedUrl, setSelectedUrl] = useState<string>(currentWallpaper || DEFAULT_WALLPAPER);
  const [customInputUrl, setCustomInputUrl] = useState<string>('');
  const [overlayOpacity, setOverlayOpacity] = useState<number>(currentOverlayOpacity || 0.82);
  const [isUploading, setIsUploading] = useState<boolean>(false);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    try {
      const base64 = await fileToBase64(file);
      setSelectedUrl(base64);
      playAppSound('click');
    } catch (err) {
      console.error(err);
    } finally {
      setIsUploading(false);
    }
  };

  const handleApply = () => {
    playAppSound('click');
    onSave(selectedUrl, overlayOpacity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[99999] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-lg glass-panel-heavy rounded-2xl border border-white/10 p-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2 text-[#00a884]">
            <Image className="w-5 h-5 text-[#25d366]" />
            <h3 className="font-bold text-base text-white">تخصيص خلفية التطبيق والمحادثات</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Preview Card */}
        <div className="relative w-full h-36 rounded-xl overflow-hidden border border-white/15 mb-4 shadow-inner">
          <div
            className="absolute inset-0 bg-cover bg-center transition-all duration-300"
            style={{ backgroundImage: `url('${selectedUrl}')` }}
          />
          <div
            className="absolute inset-0 transition-opacity"
            style={{ backgroundColor: `rgba(11, 20, 26, ${overlayOpacity})` }}
          />
          <div className="relative z-10 h-full flex flex-col justify-center items-center text-center p-3">
            <span className="text-xs px-2.5 py-1 rounded-full bg-[#00a884]/30 border border-[#25d366] text-[#25d366] font-semibold mb-1">
              معاينة الخلفية الحية
            </span>
            <p className="text-sm font-bold text-white drop-shadow">عالم عاصف الفاخر 👑</p>
            <p className="text-[11px] text-gray-300">الوضوح متوازن تماماً مع القراءة والتصميم</p>
          </div>
        </div>

        {/* Darkness/Overlay slider */}
        <div className="mb-4 bg-black/30 p-3 rounded-xl border border-white/5">
          <div className="flex justify-between items-center text-xs mb-1.5">
            <span className="text-gray-300 font-medium">مستوى تظليل الخلفية (التباين)</span>
            <span className="text-[#25d366] font-bold">{Math.round(overlayOpacity * 100)}%</span>
          </div>
          <input
            type="range"
            min="0.4"
            max="0.95"
            step="0.05"
            value={overlayOpacity}
            onChange={(e) => setOverlayOpacity(parseFloat(e.target.value))}
            className="w-full accent-[#25d366] cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-gray-400 mt-1">
            <span>خلفية أفتح وأكثر وضوحاً</span>
            <span>تظليل أغمق لقراءة أسهل</span>
          </div>
        </div>

        {/* Upload Custom Wallpaper Button */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-gray-300 block mb-1.5">
            رفع صورة خاصة من جهازك:
          </label>
          <label className="flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl border border-dashed border-[#25d366]/60 bg-[#00a884]/10 hover:bg-[#00a884]/20 text-[#25d366] text-xs font-bold cursor-pointer transition">
            <Upload className="w-4 h-4" />
            <span>{isUploading ? 'جارِ معالجة الصورة...' : 'اختر صورة من هاتفك أو جهازك 📷'}</span>
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
          </label>
        </div>

        {/* Or enter direct URL */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-gray-300 block mb-1">
            أو رابط صورة مباشرة (URL):
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="https://example.com/image.jpg"
              value={customInputUrl}
              onChange={(e) => setCustomInputUrl(e.target.value)}
              className="flex-1 glass-input rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#25d366]"
            />
            <button
              onClick={() => {
                if (customInputUrl.trim()) {
                  setSelectedUrl(customInputUrl.trim());
                  playAppSound('click');
                }
              }}
              className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white"
            >
              تطبيق
            </button>
          </div>
        </div>

        {/* Presets Grid */}
        <div className="mb-5">
          <label className="text-xs font-semibold text-gray-300 block mb-2">
            تشكيلة الخلفيات الملكية الجاهزة:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {WALLPAPER_PRESETS.map((preset) => {
              const isSelected = selectedUrl === preset.url;
              return (
                <div
                  key={preset.id}
                  onClick={() => {
                    setSelectedUrl(preset.url);
                    playAppSound('click');
                  }}
                  className={`group relative h-20 rounded-xl overflow-hidden cursor-pointer border transition-all ${
                    isSelected
                      ? 'border-[#25d366] ring-2 ring-[#25d366]/40 scale-[1.02]'
                      : 'border-white/10 hover:border-white/30'
                  }`}
                >
                  <img
                    src={preset.thumbnail}
                    alt={preset.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent p-1.5 flex flex-col justify-end">
                    <span className="text-[11px] font-bold text-white leading-tight truncate">
                      {preset.name}
                    </span>
                  </div>
                  {isSelected && (
                    <div className="absolute top-1.5 left-1.5 bg-[#25d366] text-black p-0.5 rounded-full shadow">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-2 border-t border-white/10">
          <button
            onClick={handleApply}
            className="flex-1 py-2.5 px-4 rounded-xl bg-[#25d366] hover:bg-[#20ba59] text-black font-extrabold text-sm transition shadow-lg shadow-[#25d366]/20"
          >
            حفظ وتطبيق الخلفية ✦
          </button>
          <button
            onClick={() => {
              setSelectedUrl(DEFAULT_WALLPAPER);
              setOverlayOpacity(0.82);
              playAppSound('click');
            }}
            title="إعادة تعيين إلى الأصل"
            className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 transition"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
