import React, { useEffect, useRef } from 'react';

interface ArcReactorProps {
  isListening: boolean;
  isSpeaking: boolean;
  onReactorClick: () => void;
  statusText?: string;
}

export const ArcReactorVisualizer: React.FC<ArcReactorProps> = ({
  isListening,
  isSpeaking,
  onReactorClick,
  statusText = 'ONLINE // READY',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let angle = 0;
    let pulse = 0;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;
      const baseRadius = Math.min(width, height) * 0.38;

      ctx.clearRect(0, 0, width, height);

      // Speed adjustments based on state
      const rotSpeed = isListening ? 0.04 : isSpeaking ? 0.06 : 0.015;
      angle += rotSpeed;
      pulse += isSpeaking ? 0.15 : isListening ? 0.08 : 0.03;

      const dynamicRadius = baseRadius + Math.sin(pulse) * (isSpeaking ? 6 : isListening ? 4 : 2);

      // 1. Ambient Glow
      const glowGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        dynamicRadius * 0.2,
        centerX,
        centerY,
        dynamicRadius * 1.3
      );
      if (isListening) {
        glowGrad.addColorStop(0, 'rgba(56, 189, 248, 0.4)');
        glowGrad.addColorStop(0.6, 'rgba(6, 182, 212, 0.15)');
        glowGrad.addColorStop(1, 'rgba(3, 7, 18, 0)');
      } else if (isSpeaking) {
        glowGrad.addColorStop(0, 'rgba(245, 158, 11, 0.45)');
        glowGrad.addColorStop(0.6, 'rgba(56, 189, 248, 0.25)');
        glowGrad.addColorStop(1, 'rgba(3, 7, 18, 0)');
      } else {
        glowGrad.addColorStop(0, 'rgba(6, 182, 212, 0.3)');
        glowGrad.addColorStop(0.6, 'rgba(14, 116, 144, 0.1)');
        glowGrad.addColorStop(1, 'rgba(3, 7, 18, 0)');
      }
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, dynamicRadius * 1.3, 0, Math.PI * 2);
      ctx.fill();

      // 2. Outer Segmented Ring
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(angle);

      ctx.strokeStyle = isSpeaking ? '#38bdf8' : '#0891b2';
      ctx.lineWidth = 3;
      ctx.setLineDash([12, 8]);
      ctx.beginPath();
      ctx.arc(0, 0, dynamicRadius, 0, Math.PI * 2);
      ctx.stroke();

      // 3. Middle Counter-Rotating Ring with Coils
      ctx.rotate(-angle * 1.8);
      ctx.setLineDash([]);
      ctx.strokeStyle = isListening ? '#67e8f9' : '#06b6d4';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(0, 0, dynamicRadius * 0.78, 0, Math.PI * 2);
      ctx.stroke();

      // Reactor Coils (8 segments)
      const segments = 8;
      for (let i = 0; i < segments; i++) {
        const segAngle = (i * 2 * Math.PI) / segments;
        ctx.save();
        ctx.rotate(segAngle);
        ctx.fillStyle = isSpeaking ? '#fde047' : '#38bdf8';
        ctx.fillRect(-3, dynamicRadius * 0.72, 6, dynamicRadius * 0.18);
        ctx.restore();
      }
      ctx.restore();

      // 4. Inner Ring with Glow
      ctx.strokeStyle = isSpeaking ? '#fbbf24' : '#38bdf8';
      ctx.lineWidth = 5;
      ctx.shadowColor = isSpeaking ? '#f59e0b' : '#38bdf8';
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.arc(centerX, centerY, dynamicRadius * 0.52, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0; // reset

      // 5. Central Triangle Prism / Core
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(isSpeaking ? angle * 2 : angle * 0.8);

      const triSize = dynamicRadius * 0.32;
      ctx.beginPath();
      ctx.moveTo(0, -triSize);
      ctx.lineTo(triSize * 0.866, triSize * 0.5);
      ctx.lineTo(-triSize * 0.866, triSize * 0.5);
      ctx.closePath();

      ctx.strokeStyle = isSpeaking ? '#fef08a' : '#e0f2fe';
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.fillStyle = isSpeaking ? 'rgba(251, 191, 36, 0.4)' : 'rgba(56, 189, 248, 0.3)';
      ctx.fill();
      ctx.restore();

      // 6. Central High-Intensity Fusion Dot
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = '#ffffff';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 5 + (isSpeaking ? 3 : 0), 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isListening, isSpeaking]);

  return (
    <div className="relative flex flex-col items-center justify-center p-3 select-none">
      {/* Reactor Canvas with Interactive Touch */}
      <div
        onClick={onReactorClick}
        role="button"
        tabIndex={0}
        aria-label="Toggle Jarvis voice listening"
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onReactorClick();
          }
        }}
        className="relative cursor-pointer transition-transform duration-300 hover:scale-105 active:scale-95 group focus:outline-none focus:ring-2 focus:ring-cyan-400 rounded-full"
      >
        <canvas
          ref={canvasRef}
          width={280}
          height={280}
          className="w-36 h-36 sm:w-48 sm:h-48 filter drop-shadow-[0_0_20px_rgba(6,182,212,0.5)]"
        />

        {/* Ambient Ring Wave */}
        <div
          className={`absolute inset-0 rounded-full border border-cyan-500/30 transition-all pointer-events-none ${
            isListening ? 'animate-ping border-cyan-400/60' : isSpeaking ? 'animate-pulse border-amber-400/50' : ''
          }`}
        />

        {/* Center Prompt Icon */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity">
          <span className="text-[10px] uppercase tracking-widest font-mono-code text-cyan-300 bg-gray-950/80 px-2 py-0.5 rounded border border-cyan-500/40">
            {isListening ? 'Listening' : 'Tap to Speak'}
          </span>
        </div>
      </div>

      {/* Telemetry Status Readout */}
      <div className="mt-2 text-center">
        <div className="flex items-center justify-center gap-2">
          <span
            className={`w-2 h-2 rounded-full ${
              isSpeaking
                ? 'bg-amber-400 animate-pulse'
                : isListening
                ? 'bg-cyan-400 animate-ping'
                : 'bg-emerald-400'
            }`}
          />
          <span className="font-orbitron text-xs font-bold tracking-widest uppercase text-cyan-300">
            {isSpeaking ? 'JARVIS SPEAKING' : isListening ? 'LISTENING // AUDIO DETECTED' : statusText}
          </span>
        </div>
        <p className="text-[11px] font-mono-code text-slate-400 mt-0.5">
          STARK MOBILE OS v4.2 // SECURITY: ENCRYPTED
        </p>
      </div>
    </div>
  );
};
