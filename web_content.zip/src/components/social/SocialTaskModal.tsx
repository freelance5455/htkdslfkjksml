import React, { useState, useEffect } from 'react';
import { 
  X, 
  Send, 
  ExternalLink, 
  CheckCircle2, 
  Sparkles, 
  Clock, 
  ShieldCheck, 
  ArrowRight,
  Share2,
  Users,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { SocialTaskItem } from '../../types';

interface SocialTaskModalProps {
  task: SocialTaskItem | null;
  isOpen: boolean;
  onClose: () => void;
  onCompleted?: (taskId: string, coins: number) => void;
  onNextTask?: () => void;
}

export const SocialTaskModal: React.FC<SocialTaskModalProps> = ({
  task,
  isOpen,
  onClose,
  onCompleted,
  onNextTask,
}) => {
  const { currentUser, adjustUserCoins } = useApp();

  const [step, setStep] = useState<'action' | 'verify' | 'success'>('action');
  const [visitedLink, setVisitedLink] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(8);
  const [userHandle, setUserHandle] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen && task) {
      setStep('action');
      setVisitedLink(false);
      setTimerSeconds(8);
      setUserHandle(currentUser?.name ? `@${currentUser.name.toLowerCase().replace(/\s+/g, '')}` : '');
      setIsSubmitting(false);
    }
  }, [isOpen, task, currentUser]);

  // Countdown timer once link is visited
  useEffect(() => {
    if (!isOpen || !visitedLink || step !== 'action') return;

    if (timerSeconds <= 0) {
      setStep('verify');
      return;
    }

    const interval = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev <= 1) {
          setStep('verify');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, visitedLink, step, timerSeconds]);

  if (!isOpen || !task) return null;

  const handleOpenLink = () => {
    setVisitedLink(true);
    window.open(task.targetUrl, '_blank', 'noopener,noreferrer');
  };

  const handleConfirmTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setIsSubmitting(true);
    const reward = task.rewardCoins;

    adjustUserCoins(
      currentUser.id,
      reward,
      `Social Task: ${task.title}`
    );

    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.65 }
    });

    if (onCompleted) {
      onCompleted(task.id, reward);
    }

    setStep('success');
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative max-h-[92vh] flex flex-col overflow-y-auto space-y-4"
        role="dialog"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-1 pr-6">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-sky-500/20 text-sky-400 border border-sky-500/30">
              {task.platform} Task
            </span>
            <span className="text-xs font-black text-amber-400">
              +{task.rewardCoins} Coins (₹{(task.rewardCoins / 100).toFixed(2)})
            </span>
          </div>

          <h2 className="text-sm font-black text-white line-clamp-2">
            {task.title}
          </h2>
          <p className="text-[11px] font-mono text-slate-400">
            {task.handle} • {task.membersCount}
          </p>
        </div>

        {/* Step Indicator */}
        <div className="grid grid-cols-2 gap-2 text-center text-xs font-bold pt-1">
          <div className={`p-2 rounded-xl border transition-all ${
            step === 'action' 
              ? 'bg-sky-500/20 text-sky-400 border-sky-500/40' 
              : 'bg-slate-950 text-slate-400 border-slate-800'
          }`}>
            <span>1. Open Channel</span>
          </div>
          <div className={`p-2 rounded-xl border transition-all ${
            step === 'verify' || step === 'success'
              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40' 
              : 'bg-slate-950 text-slate-400 border-slate-800'
          }`}>
            <span>2. Confirm & Claim</span>
          </div>
        </div>

        {/* STEP 1: Launch Social URL & Verification Timer */}
        {step === 'action' && (
          <div className="space-y-4 pt-1">
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <span className="font-bold text-slate-300 block">Instructions:</span>
              <p className="text-slate-400 leading-relaxed text-[11px]">
                {task.instructions}
              </p>
              <div className="flex items-center gap-1.5 text-emerald-400 font-semibold text-[11px] pt-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Instant verification after visiting channel.</span>
              </div>
            </div>

            {visitedLink ? (
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-center">
                <div className="flex items-center justify-center gap-2 text-xs text-slate-300 font-semibold">
                  <Clock className="w-4 h-4 text-sky-400 animate-spin" />
                  <span>Verifying social engagement... {timerSeconds}s</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-sky-500 to-emerald-400 rounded-full transition-all duration-300"
                    style={{ width: `${Math.round(((8 - timerSeconds) / 8) * 100)}%` }}
                  />
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleOpenLink}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-black text-xs shadow-md shadow-sky-600/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Open {task.platform.toUpperCase()} & Follow</span>
              </button>
            )}
          </div>
        )}

        {/* STEP 2: Verify & Claim */}
        {step === 'verify' && (
          <form onSubmit={handleConfirmTask} className="space-y-3.5 pt-1">
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Channel visit verified! Submit your profile handle to claim reward.</span>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300 block">
                Your {task.platform} Username / Handle
              </label>
              <input
                type="text"
                required
                value={userHandle}
                onChange={(e) => setUserHandle(e.target.value)}
                placeholder="@your_username"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Claim +{task.rewardCoins} Coins</span>
            </button>
          </form>
        )}

        {/* STEP 3: Success */}
        {step === 'success' && (
          <div className="text-center space-y-3 py-2">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Task Verified & Rewarded
              </span>
              <h3 className="text-base font-black text-white pt-1">
                +{task.rewardCoins} Coins Credited!
              </h3>
              <p className="text-xs text-slate-400">
                Your {task.platform} task reward has been transferred to your wallet balance.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              {onNextTask && (
                <button
                  type="button"
                  onClick={onNextTask}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-xs hover:opacity-90 cursor-pointer shadow-md flex items-center justify-center gap-1.5"
                >
                  <span>Next Task</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl border border-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-800 cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
