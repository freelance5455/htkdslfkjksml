import React, { useState, useEffect } from 'react';
import { 
  Share2, 
  Send, 
  Search, 
  CheckCircle2, 
  Sparkles, 
  RefreshCw, 
  ArrowRight,
  ExternalLink,
  Users,
  Globe
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { SocialTaskItem } from '../../types';
import { getSocialCatalog, SOCIAL_PLATFORMS_LIST, TOTAL_SOCIAL_CATALOG_COUNT } from '../../services/socialLibrary';
import { SocialTaskModal } from './SocialTaskModal';

export const SocialTasksSection: React.FC = () => {
  const { currentUser } = useApp();

  const [platformFilter, setPlatformFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [page, setPage] = useState<number>(1);
  const [tasksList, setTasksList] = useState<SocialTaskItem[]>([]);
  const [hasMore, setHasMore] = useState<boolean>(true);

  // Active modal
  const [activeTask, setActiveTask] = useState<SocialTaskItem | null>(null);

  // Completed task IDs (persisted locally)
  const [completedIds, setCompletedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_completed_social_tasks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    const { tasks, hasMore: more } = getSocialCatalog(1, 10, platformFilter, searchQuery);
    setTasksList(tasks);
    setPage(1);
    setHasMore(more);
  }, [platformFilter, searchQuery]);

  const handleLoadMore = () => {
    const nextPage = page + 1;
    const { tasks: newBatch, hasMore: more } = getSocialCatalog(nextPage, 10, platformFilter, searchQuery);
    setTasksList((prev) => [...prev, ...newBatch]);
    setPage(nextPage);
    setHasMore(more);
  };

  const handleTaskCompleted = (taskId: string, coins: number) => {
    setCompletedIds((prev) => {
      const updated = Array.from(new Set([...prev, taskId]));
      localStorage.setItem('taskearn_completed_social_tasks', JSON.stringify(updated));
      return updated;
    });
  };

  const handleNextTask = () => {
    if (!activeTask) return;
    const currentIndex = tasksList.findIndex((t) => t.id === activeTask.id);
    if (currentIndex >= 0 && currentIndex + 1 < tasksList.length) {
      setActiveTask(tasksList[currentIndex + 1]);
    } else {
      setActiveTask(null);
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'telegram':
        return <Send className="w-4 h-4 text-sky-400" />;
      case 'youtube':
        return <Globe className="w-4 h-4 text-red-400" />;
      case 'discord':
        return <Users className="w-4 h-4 text-indigo-400" />;
      default:
        return <Share2 className="w-4 h-4 text-emerald-400" />;
    }
  };

  return (
    <div className="space-y-4">
      {/* 10,000+ Social Tasks Header Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-sky-950/80 via-slate-900 to-indigo-950/80 border border-sky-800/60 shadow-lg space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-md shadow-sky-600/30">
                <Share2 className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-white">
                Social Tasks & Follows
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-sky-500/20 text-sky-300 border border-sky-500/30">
                10,000+ Tasks
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Join Telegram channels, follow on Instagram & X, and subscribe to YouTube to claim +30 to +120 Coins!
            </p>
          </div>

          <div className="p-2.5 rounded-2xl bg-black/40 border border-slate-800 flex items-center gap-3 shrink-0">
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold">Tasks Available</span>
              <span className="text-sm font-black text-amber-400">10,600+</span>
            </div>
            <div className="w-px h-6 bg-slate-800" />
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold">Joined Today</span>
              <span className="text-sm font-black text-emerald-400">{completedIds.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Platform Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {SOCIAL_PLATFORMS_LIST.map((item) => (
          <button
            key={item.id}
            onClick={() => setPlatformFilter(item.id)}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition-all cursor-pointer ${
              platformFilter === item.id
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search 10,000+ social tasks, channels, or platforms..."
          className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900/70 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
        />
      </div>

      {/* Social Tasks List */}
      <div className="space-y-3">
        {tasksList.map((task) => {
          const isDone = completedIds.includes(task.id);

          return (
            <div
              key={task.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs ${
                isDone
                  ? 'bg-slate-900/40 border-slate-800/60 opacity-80'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Task Info Left */}
              <div className="flex items-center gap-3.5 min-w-0 flex-1">
                <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${task.iconBg}`}>
                  {getPlatformIcon(task.platform)}
                </div>

                <div className="space-y-0.5 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                      {task.platform}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {task.handle}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white truncate">
                    {task.title}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {task.membersCount} • {task.actionType.toUpperCase()}
                  </p>
                </div>
              </div>

              {/* Reward & Action Right */}
              <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/80">
                <div className="text-left sm:text-right">
                  <span className="text-xs font-black text-amber-400 block">
                    +{task.rewardCoins} Coins
                  </span>
                  <span className="text-[10px] text-emerald-400 font-semibold block">
                    ₹{(task.rewardCoins / 100).toFixed(2)}
                  </span>
                </div>

                {isDone ? (
                  <button
                    onClick={() => setActiveTask(task)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 text-emerald-400 text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Completed</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setActiveTask(task)}
                    className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-black text-xs shadow-xs active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <span>Complete</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Load More Button */}
      {hasMore && (
        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={handleLoadMore}
            className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 font-bold text-xs shadow-xs active:scale-95 transition-all cursor-pointer inline-flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
            <span>Load More from 10,000+ Social Library</span>
          </button>
        </div>
      )}

      {/* Social Task Verification Modal */}
      <SocialTaskModal
        task={activeTask}
        isOpen={!!activeTask}
        onClose={() => setActiveTask(null)}
        onCompleted={handleTaskCompleted}
        onNextTask={handleNextTask}
      />
    </div>
  );
};
