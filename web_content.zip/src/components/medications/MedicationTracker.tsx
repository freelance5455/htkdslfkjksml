import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Pill,
  Plus,
  Trash2,
  Edit2,
  Clock,
  CheckCircle2,
  AlertCircle,
  Calendar,
  RotateCcw,
  Sparkles,
  TrendingUp,
  Check,
  X,
  FileText,
} from 'lucide-react';
import { DoseStatus, Medication, TimingRule } from '../../types';
import { formatTime24to12 } from '../../utils/prayerCalculator';

export const MedicationTracker: React.FC = () => {
  const {
    medications,
    addMedication,
    updateMedication,
    deleteMedication,
    medicationLogs,
    logMedicationDose,
    currentTime,
  } = useApp();

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingMed, setEditingMed] = useState<Medication | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [dosage, setDosage] = useState('');
  const [frequency, setFrequency] = useState(1);
  const [times, setTimes] = useState<string[]>(['09:00']);
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [timingRule, setTimingRule] = useState<TimingRule>('after_food');
  const [instructions, setInstructions] = useState('');
  const [medColor, setMedColor] = useState('#0284C7');

  const todayStr = useMemo(() => currentTime.toISOString().split('T')[0], [currentTime]);

  const handleOpenAdd = () => {
    setEditingMed(null);
    setName('');
    setDosage('قرص واحد (500 ملغ)');
    setFrequency(1);
    setTimes(['09:00']);
    setStartDate(todayStr);
    setEndDate(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
    setTimingRule('after_food');
    setInstructions('');
    setMedColor('#0284C7');
    setShowAddModal(true);
  };

  const handleOpenEdit = (med: Medication) => {
    setEditingMed(med);
    setName(med.name);
    setDosage(med.dosage);
    setFrequency(med.frequencyTimesPerDay);
    setTimes(med.times);
    setStartDate(med.startDate);
    setEndDate(med.endDate);
    setTimingRule(med.timingRule);
    setInstructions(med.instructions || '');
    setMedColor(med.color || '#0284C7');
    setShowAddModal(true);
  };

  const handleFrequencyChange = (freq: number) => {
    setFrequency(freq);
    const newTimes: string[] = [];
    if (freq === 1) newTimes.push('09:00');
    else if (freq === 2) newTimes.push('09:00', '21:00');
    else if (freq === 3) newTimes.push('08:00', '14:00', '20:00');
    else if (freq === 4) newTimes.push('06:00', '12:00', '18:00', '24:00');
    setTimes(newTimes);
  };

  const handleTimeChange = (index: number, val: string) => {
    const updated = [...times];
    updated[index] = val;
    setTimes(updated);
  };

  const handleSaveMedication = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingMed) {
      updateMedication(editingMed.id, {
        name: name.trim(),
        dosage: dosage.trim(),
        frequencyTimesPerDay: frequency,
        times,
        startDate,
        endDate,
        timingRule,
        instructions: instructions.trim(),
        color: medColor,
      });
    } else {
      addMedication({
        name: name.trim(),
        dosage: dosage.trim(),
        frequencyTimesPerDay: frequency,
        times,
        startDate,
        endDate,
        timingRule,
        instructions: instructions.trim(),
        color: medColor,
        active: true,
      });
    }

    setShowAddModal(false);
  };

  // Helper rule label
  const getRuleLabel = (rule: TimingRule) => {
    switch (rule) {
      case 'before_food':
        return 'قبل الطعام بـ 30 دقيقة';
      case 'after_food':
        return 'بعد الطعام مباشرة';
      case 'with_food':
        return 'أثناء تناول الطعام';
      case 'fasting':
        return 'على الريق صباحاً';
    }
  };

  // Weekly compliance
  const weeklyCompliance = useMemo(() => {
    const activeMeds = medications.filter((m) => m.active);
    const totalDosesExpectedPerDay = activeMeds.reduce((acc, m) => acc + m.times.length, 0);
    const totalWeeklyExpected = totalDosesExpectedPerDay * 7;

    const takenLast7Days = medicationLogs.filter((l) => l.status === 'taken').length;
    const rate = totalWeeklyExpected > 0 ? Math.min(100, Math.round((takenLast7Days / totalWeeklyExpected) * 100)) : 100;
    return { takenLast7Days, totalWeeklyExpected, rate };
  }, [medications, medicationLogs]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-[#180d15] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Pill className="w-5 h-5 text-rose-500" />
            <h2 className="text-xl font-bold text-slate-900 dark:text-rose-50">
              متتبع الأدوية ومواعيد العلاج
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-rose-200/70 mt-1">
            جدولة الجرعات والتنبيهات بدقة، تسجيل الأخذ، ومتابعة الالتزام الطبي اليومي والأسبوعي
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة دواء جديد</span>
        </button>
      </div>

      {/* Weekly Compliance & Status Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-[#180d15] p-4 rounded-2xl border border-rose-100 dark:border-rose-950/60">
          <div className="text-xs font-semibold text-slate-500 dark:text-rose-200/70 mb-1">
            الأدوية النشطة حالياً
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-rose-100">
            {medications.filter((m) => m.active).length} أدوية
          </div>
        </div>

        <div className="bg-white dark:bg-[#180d15] p-4 rounded-2xl border border-rose-100 dark:border-rose-950/60">
          <div className="text-xs font-semibold text-slate-500 dark:text-rose-200/70 mb-1">
            نسبة الالتزام بالعلاج
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400">
              {weeklyCompliance.rate}%
            </span>
            <span className="text-xs text-rose-400/80">انتظام ممتاز</span>
          </div>
        </div>

        <div className="bg-white dark:bg-[#180d15] p-4 rounded-2xl border border-rose-100 dark:border-rose-950/60">
          <div className="text-xs font-semibold text-slate-500 dark:text-rose-200/70 mb-1">
            الجرعات المأخوذة هذا الأسبوع
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-rose-100">
            {weeklyCompliance.takenLast7Days} جرعة
          </div>
        </div>
      </div>

      {/* Today's Schedule Dose Tracker */}
      <div className="bg-white dark:bg-[#180d15] rounded-2xl border border-rose-100 dark:border-rose-950/60 p-5 transition-colors shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-rose-50 dark:border-rose-950/50 mb-4">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-rose-50">
              جرعات اليوم المطلوب تناولها ({todayStr})
            </h3>
            <p className="text-xs text-slate-500 dark:text-rose-200/70">
              سجّل كل جرعة فور تناولها أو قم بتأجيل التنبيه عند الحاجة
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {medications.filter((m) => m.active).length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              لا توجد أدوية مجدولة حالياً. اضغط "إضافة دواء جديد" لإدخال وصفتك الطبية.
            </div>
          ) : (
            medications
              .filter((m) => m.active)
              .flatMap((med) =>
                med.times.map((t) => {
                  const log = medicationLogs.find(
                    (l) => l.medicationId === med.id && l.scheduledDate === todayStr && l.scheduledTime === t
                  );
                  return { med, time: t, log };
                })
              )
              .sort((a, b) => a.time.localeCompare(b.time))
              .map(({ med, time, log }, idx) => {
                const isTaken = log?.status === 'taken';
                const isSnoozed = log?.status === 'snoozed';
                const isMissed = log?.status === 'missed';

                return (
                  <div
                    key={`${med.id}_${time}_${idx}`}
                    className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all ${
                      isTaken
                        ? 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200/60 dark:border-rose-900/40 opacity-75'
                        : isSnoozed
                        ? 'bg-pink-50/50 dark:bg-pink-950/20 border-pink-300 dark:border-pink-800'
                        : 'bg-white dark:bg-[#1a0f18] border-rose-100 dark:border-rose-950/60'
                    }`}
                  >
                    <div className="flex items-start sm:items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 text-white font-bold shadow-xs"
                        style={{ backgroundColor: med.color || '#E11D48' }}
                      >
                        <Pill className="w-5 h-5" />
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-sm text-slate-900 dark:text-rose-100">
                            {med.name}
                          </h4>
                          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border border-rose-100 dark:border-rose-900/40">
                            {med.dosage}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-rose-200/70 mt-1">
                          <span className="font-mono tabular-nums font-bold text-slate-800 dark:text-rose-200">
                            {formatTime24to12(time)}
                          </span>
                          <span>·</span>
                          <span className="text-rose-600 dark:text-rose-400 font-medium">
                            {getRuleLabel(med.timingRule)}
                          </span>
                          {med.instructions && (
                            <>
                              <span>·</span>
                              <span className="truncate max-w-[200px]">{med.instructions}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 self-end sm:self-auto">
                      {isTaken ? (
                        <span className="px-3 py-1.5 rounded-lg bg-rose-100 text-rose-800 dark:bg-rose-950/70 dark:text-rose-300 font-semibold text-xs flex items-center gap-1.5 border border-rose-200 dark:border-rose-900/50">
                          <Check className="w-3.5 h-3.5" />
                          <span>تم تناول الجرعة {log.loggedAt}</span>
                        </span>
                      ) : (
                        <>
                          <button
                            onClick={() => logMedicationDose(med.id, time, 'taken')}
                            className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-colors flex items-center gap-1 shadow-xs"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>أخذت الجرعة</span>
                          </button>

                          <button
                            onClick={() =>
                              logMedicationDose(med.id, time, 'snoozed', 'تأجيل 15 دقيقة')
                            }
                            className="px-2.5 py-1.5 rounded-xl border border-rose-200 dark:border-rose-900/60 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-700 dark:text-rose-200 text-xs transition-colors flex items-center gap-1"
                          >
                            <Clock className="w-3.5 h-3.5" />
                            <span>تأجيل 15د</span>
                          </button>

                          <button
                            onClick={() => logMedicationDose(med.id, time, 'missed', 'تفويت الجرعة')}
                            className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 transition-colors"
                            title="تفويت الجرعة"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })
          )}
        </div>
      </div>

      {/* Medications List (All prescriptions) */}
      <div className="bg-white dark:bg-[#180d15] rounded-2xl border border-rose-100 dark:border-rose-950/60 p-5 transition-colors shadow-xs">
        <h3 className="font-bold text-base text-slate-900 dark:text-rose-50 mb-4 pb-2 border-b border-rose-50 dark:border-rose-950/50">
          قائمة الوصفات والعلاجات المسجلة
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {medications.map((med) => (
            <div
              key={med.id}
              className="p-4 rounded-2xl border border-rose-100 dark:border-rose-950/60 bg-rose-50/20 dark:bg-[#1c0f1b]/60 space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: med.color || '#E11D48' }}
                    />
                    <h4 className="font-bold text-sm text-slate-900 dark:text-rose-100">{med.name}</h4>
                  </div>
                  <div className="text-xs text-slate-500 dark:text-rose-200/70 mt-1">
                    الجرعة: {med.dosage} · {med.frequencyTimesPerDay} مرة يومياً
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(med)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-300"
                    title="تعديل"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`هل أنت متأكد من حذف ${med.name}؟`)) {
                        deleteMedication(med.id);
                      }
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600"
                    title="حذف"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="text-xs text-slate-600 dark:text-rose-200/80 space-y-1">
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-rose-400" />
                  <span>المواعيد: {med.times.map((t) => formatTime24to12(t)).join(' ، ')}</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileText className="w-3.5 h-3.5 text-rose-400" />
                  <span>التعليمات: {getRuleLabel(med.timingRule)}</span>
                </div>
                {med.instructions && (
                  <div className="text-[11px] text-slate-600 dark:text-rose-300/80 italic bg-white dark:bg-[#140b11] p-2 rounded-lg border border-rose-100 dark:border-rose-950/60">
                    "{med.instructions}"
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add / Edit Medication Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-[#180d15] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-rose-100 dark:border-rose-950/80 max-h-[90vh] overflow-y-auto">
            <h3 className="font-bold text-base text-slate-900 dark:text-rose-50 mb-4">
              {editingMed ? 'تعديل بيانات الدواء' : 'إضافة دواء أو مكمل غذائي جديد'}
            </h3>

            <form onSubmit={handleSaveMedication} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                  اسم الدواء أو العلاج *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: باراسيتامول / فيتامين سي"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100 focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    الجرعة المحددة
                  </label>
                  <input
                    type="text"
                    required
                    value={dosage}
                    onChange={(e) => setDosage(e.target.value)}
                    placeholder="قرص 500 ملغ"
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    عدد مرات التناول يومياً
                  </label>
                  <select
                    value={frequency}
                    onChange={(e) => handleFrequencyChange(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
                  >
                    <option value={1}>مرة واحدة يومياً</option>
                    <option value={2}>مرتان يومياً (كل 12 ساعة)</option>
                    <option value={3}>3 مرات يومياً (كل 8 ساعات)</option>
                    <option value={4}>4 مرات يومياً (كل 6 ساعات)</option>
                  </select>
                </div>
              </div>

              {/* Exact times */}
              <div>
                <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                  مواعيد التناول الدقيقة ({times.length} مواعيد)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {times.map((t, idx) => (
                    <input
                      key={idx}
                      type="time"
                      value={t}
                      onChange={(e) => handleTimeChange(idx, e.target.value)}
                      className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100 font-mono"
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                  توقيت الأخذ بالنسبة للطعام
                </label>
                <select
                  value={timingRule}
                  onChange={(e) => setTimingRule(e.target.value as TimingRule)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
                >
                  <option value="after_food">بعد الطعام مباشرة (لحماية المعدة)</option>
                  <option value="before_food">قبل الطعام بـ 30 دقيقة</option>
                  <option value="with_food">أثناء تناول وجبة الطعام</option>
                  <option value="fasting">على الريق صباحاً</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    تاريخ بداية العلاج
                  </label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                    تاريخ نهاية العلاج
                  </label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-rose-200 mb-1">
                  إرشادات الطبيب أو الصيدلي
                </label>
                <textarea
                  rows={2}
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  placeholder="مثال: شرب كوب ماء كامل، وتجنب الشاي والقهوة لمدة ساعتين"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-rose-900/60 bg-white dark:bg-[#12080f] text-slate-900 dark:text-rose-100"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-rose-100 dark:border-rose-950/60">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-slate-600 dark:text-rose-300"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs"
                >
                  {editingMed ? 'حفظ التعديلات' : 'إضافة الدواء'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
