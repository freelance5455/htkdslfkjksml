import { useMemo, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import {
  Activity, ArrowUpRight, Check, ChevronDown, CircleGauge, Database, ExternalLink, EyeOff,
  Gauge, Globe2, Layers3, LockKeyhole, Radio, RefreshCw, ShieldCheck, Smartphone, Wifi,
} from "lucide-react";
import { COUNTRY_NAMES, PROXY_SOURCES } from "../data/sources";
import type { ProxyRecord } from "../types";
import { Brand } from "./Brand";

const reveal = {
  initial: { opacity: 0, y: 45 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, amount: 0.2 },
  transition: { duration: 0.75, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
};

export function CatalogInsights({ proxies }: { proxies: ProxyRecord[] }) {
  const stats = useMemo(() => {
    const countries = new Map<string, number>();
    const types = { faketls: 0, secure: 0, classic: 0 };
    const latency = { fast: 0, medium: 0, slow: 0, unknown: 0 };
    proxies.forEach((proxy) => {
      if (proxy.country) countries.set(proxy.country, (countries.get(proxy.country) ?? 0) + 1);
      types[proxy.type] += 1;
      if (proxy.latency === null) latency.unknown += 1;
      else if (proxy.latency <= 100) latency.fast += 1;
      else if (proxy.latency <= 250) latency.medium += 1;
      else latency.slow += 1;
    });
    return {
      countries: [...countries.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6),
      types,
      latency,
      knownPing: proxies.filter((proxy) => proxy.latency !== null).length,
    };
  }, [proxies]);
  if (!proxies.length) return null;
  const maxCountry = stats.countries[0]?.[1] ?? 1;
  const latencyItems = [
    { label: "До 100 мс", value: stats.latency.fast, color: "bg-[#5b9e68]" },
    { label: "101–250 мс", value: stats.latency.medium, color: "bg-[#b18a42]" },
    { label: "Более 250 мс", value: stats.latency.slow, color: "bg-[#b36b5e]" },
    { label: "RTT не указан", value: stats.latency.unknown, color: "bg-ink/20" },
  ];
  return (
    <motion.section {...reveal} className="mt-20 border-t border-ink/10 pt-14" aria-label="Аналитика каталога">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><div className="section-kicker text-ink/35"><Activity size={13} />Срез текущего каталога</div><h2 className="mt-3 font-display text-3xl font-semibold tracking-[-0.05em] sm:text-4xl">Не просто список. Картина сети.</h2></div><p className="max-w-sm text-xs leading-5 text-ink/40">Диаграммы пересчитываются из всех загруженных записей с учётом включённых источников. Это не измерения с вашего устройства.</p></div>
      <div className="mt-8 grid gap-4 lg:grid-cols-[1.25fr_.75fr]">
        <div className="rounded-[26px] border border-ink/[0.08] bg-white p-6 sm:p-8">
          <div className="flex items-center justify-between"><h3 className="inline-flex items-center gap-2 text-sm font-semibold"><Globe2 size={16} className="text-ink/35" />География серверов</h3><span className="text-[10px] text-ink/35">Топ {stats.countries.length} по числу записей</span></div>
          <div className="mt-7 space-y-4">{stats.countries.map(([code, count], index) => <div key={code} className="grid grid-cols-[90px_1fr_42px] items-center gap-3 sm:grid-cols-[130px_1fr_48px]"><div className="truncate text-[11px] text-ink/55"><span className="mr-2 font-mono text-[9px] text-ink/30">{code}</span>{COUNTRY_NAMES[code] ?? code}</div><div className="h-2 overflow-hidden rounded-full bg-ink/[0.05]"><motion.div initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 0.8, delay: index * 0.07 }} className="h-full origin-left rounded-full bg-ink" style={{ width: `${(count / maxCountry) * 100}%` }} /></div><div className="text-right font-mono text-[10px] text-ink/45">{count}</div></div>)}</div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
          <div className="rounded-[26px] border border-ink/[0.08] bg-white p-6"><h3 className="inline-flex items-center gap-2 text-sm font-semibold"><Layers3 size={16} className="text-ink/35" />Типы защиты</h3><div className="mt-5 flex h-3 overflow-hidden rounded-full bg-ink/5">{(["faketls", "secure", "classic"] as const).map((type) => <div key={type} className={type === "faketls" ? "bg-[#72a85b]" : type === "secure" ? "bg-[#527a6d]" : "bg-ink/25"} style={{ width: `${(stats.types[type] / proxies.length) * 100}%` }} />)}</div><div className="mt-5 space-y-2.5">{[["Fake-TLS · ee", stats.types.faketls, "bg-[#72a85b]"], ["Random padding · dd", stats.types.secure, "bg-[#527a6d]"], ["Classic · 16 байт", stats.types.classic, "bg-ink/25"]].map(([label, value, color]) => <div key={String(label)} className="flex items-center text-[10px]"><span className={`mr-2 h-2 w-2 rounded-full ${color}`} /><span className="text-ink/45">{label}</span><span className="ml-auto font-mono text-ink/65">{value}</span></div>)}</div></div>
          <div className="rounded-[26px] bg-ink p-6 text-white"><h3 className="inline-flex items-center gap-2 text-sm font-semibold"><Gauge size={16} className="text-accent" />Задержка источников</h3><div className="mt-5 space-y-3">{latencyItems.map((item) => <div key={item.label} className="flex items-center gap-3"><span className={`h-1.5 w-1.5 rounded-full ${item.color}`} /><span className="text-[10px] text-white/40">{item.label}</span><span className="ml-auto font-mono text-[10px] text-white/75">{item.value}</span></div>)}</div><p className="mt-5 border-t border-white/10 pt-4 text-[9px] leading-4 text-white/30">RTT измерен на серверах каталогов и может отличаться от задержки в вашей сети.</p></div>
        </div>
      </div>
    </motion.section>
  );
}

const scoreFactors = [
  { title: "MTProto-ответ", detail: "до 32 баллов", x: -400, y: -155, rotate: -7 },
  { title: "Низкий RTT", detail: "до 23 баллов", x: 400, y: -155, rotate: 7 },
  { title: "Uptime", detail: "до 20 баллов", x: -325, y: 155, rotate: 5 },
  { title: "Перекрёстная проверка", detail: "до 10 баллов", x: 325, y: 155, rotate: -5 },
  { title: "Fake-TLS + порт 443", detail: "до 10 баллов", x: 0, y: -225, rotate: 2 },
];

export function MethodSection() {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const coreScale = useTransform(scrollYProgress, [0.25, 0.58, 0.8], [0.65, 0.85, 1.08]);
  const coreOpacity = useTransform(scrollYProgress, [0.25, 0.5], [0.2, 1]);
  const number = useTransform(scrollYProgress, [0.38, 0.72], [0, 100]);
  const rounded = useTransform(number, (value) => String(Math.round(value)).padStart(2, "0"));

  return (
    <section id="method" className="relative overflow-hidden bg-ink py-24 text-white sm:py-32">
      <div className="hero-grid absolute inset-0 opacity-25" />
      <div className="relative mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12">
        <motion.div {...reveal} className="grid gap-8 lg:grid-cols-[1fr_.65fr] lg:items-end">
          <div><div className="section-kicker text-white/35"><CircleGauge size={13} />Методика MT/Rank</div><h2 className="mt-5 max-w-3xl font-display text-[clamp(2.8rem,5.5vw,5.8rem)] font-medium leading-[0.95] tracking-[-0.065em]">Лучший — не значит<br /><span className="text-accent">первый в списке.</span></h2></div>
          <p className="max-w-md text-sm leading-7 text-white/45 lg:justify-self-end">Каждая запись получает объяснимую оценку. Алгоритм не прячет компромиссы: быстрый сервер с нестабильной историей может уступить маршруту с несколькими независимыми подтверждениями.</p>
        </motion.div>

        <div ref={ref} className={`relative mt-16 hidden h-[1050px] ${reduced ? "" : "lg:block"}`}>
          <div className="sticky top-[12vh] h-[680px] overflow-hidden rounded-[36px] border border-white/[0.08] bg-white/[0.025]">
            <div className="absolute left-8 top-7 text-[10px] font-bold uppercase tracking-[0.18em] text-white/30">Сигналы → единая оценка</div>
            <div className="absolute right-8 top-7 font-mono text-[10px] text-white/20">SCROLL TO CALCULATE</div>
            <motion.div style={{ scale: reduced ? 1 : coreScale, opacity: coreOpacity, x: "-50%", y: "-50%" }} className="absolute left-1/2 top-1/2 grid h-64 w-64 place-items-center rounded-full border border-accent/30 bg-accent/[0.06] shadow-[0_0_100px_rgba(192,255,114,.08)]">
              <div className="absolute inset-5 rounded-full border border-dashed border-accent/20" />
              <div className="text-center"><div className="text-[9px] font-bold uppercase tracking-[0.2em] text-accent/55">MT/Rank</div><div className="mt-1 flex items-baseline justify-center font-display text-7xl font-medium tracking-[-0.08em] text-accent"><motion.span>{rounded}</motion.span><span className="ml-2 text-sm tracking-normal text-accent/35">/100</span></div><div className="mt-2 text-[9px] text-white/30">взвешенный результат</div></div>
            </motion.div>
            {scoreFactors.map((factor, index) => <ScoreFactor key={factor.title} factor={factor} progress={scrollYProgress} reduced={Boolean(reduced)} index={index} />)}
            <div className="absolute inset-x-8 bottom-7 flex items-center justify-between border-t border-white/[0.07] pt-5 text-[10px] text-white/25"><span>Максимум ограничен 100 баллами</span><span>Формула открыта ниже</span></div>
          </div>
        </div>

        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {[
            { icon: ShieldCheck, title: "Доказательство работы", text: "Ответ Telegram DC даёт 32 балла, handshake — 25, только открытый TCP-порт — 16.", value: "32 / 25 / 16" },
            { icon: Gauge, title: "Задержка", text: "До 60 мс приносит 23 балла; после 700 мс бонус за скорость обнуляется.", value: "0—23" },
            { icon: Activity, title: "Стабильность", text: "Uptime источника даёт до 20 баллов. Если истории нет, мы не додумываем её.", value: "0—20" },
            { icon: Database, title: "Совпадение каталогов", text: "Каждое дополнительное независимое подтверждение добавляет 5, максимум 10.", value: "0—10" },
            { icon: Wifi, title: "Устойчивость маршрута", text: "Fake-TLS, порт 443, свежая проверка и доступность из РФ дают отдельные бонусы.", value: "0—20" },
          ].map((item, index) => <motion.div key={item.title} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.07 }} className="rounded-2xl border border-white/[0.08] bg-white/[0.025] p-5"><div className="flex items-center justify-between"><item.icon size={17} className="text-accent" /><span className="font-mono text-[9px] text-white/25">{item.value}</span></div><h3 className="mt-6 text-xs font-semibold">{item.title}</h3><p className="mt-2 text-[10px] leading-5 text-white/35">{item.text}</p></motion.div>)}
        </div>
        <p className="mt-6 max-w-3xl text-[10px] leading-5 text-white/25">Оценка помогает сортировке, но не гарантирует доступность именно у вашего оператора. Публичные прокси могут перестать работать в любой момент — обновите каталог и попробуйте следующий маршрут.</p>
      </div>
    </section>
  );
}

function ScoreFactor({ factor, progress, reduced, index }: { factor: typeof scoreFactors[number]; progress: ReturnType<typeof useScroll>["scrollYProgress"]; reduced: boolean; index: number }) {
  const x = useTransform(progress, [0.25, 0.72], [reduced ? 0 : factor.x, 0]);
  const y = useTransform(progress, [0.25, 0.72], [reduced ? 0 : factor.y, 0]);
  const rotate = useTransform(progress, [0.25, 0.72], [reduced ? 0 : factor.rotate, 0]);
  const scale = useTransform(progress, [0.45, 0.75], [1, 0.55]);
  const opacity = useTransform(progress, [0.58, 0.76], [1, 0]);
  return <motion.div style={{ x, y, rotate, scale: reduced ? 1 : scale, opacity: reduced ? 1 : opacity }} className="absolute left-1/2 top-1/2 -ml-[110px] -mt-[50px] flex h-[100px] w-[220px] flex-col justify-center rounded-2xl border border-white/10 bg-[#14221d] p-5 shadow-xl"><div className="flex items-center gap-2"><span className="grid h-5 w-5 place-items-center rounded-full border border-accent/25 font-mono text-[8px] text-accent">{index + 1}</span><h3 className="text-xs font-semibold text-white/80">{factor.title}</h3></div><div className="mt-2 pl-7 font-mono text-[9px] text-accent/50">{factor.detail}</div></motion.div>;
}

const guides = {
  android: {
    label: "Android", icon: Smartphone, title: "Telegram для Android",
    steps: ["Нажмите «Подключить» у выбранного прокси и подтвердите открытие в Telegram.", "В карточке MTProto нажмите «Подключить прокси».", "Для ручной настройки откройте Настройки → Данные и память → Прокси.", "Включите «Использовать прокси». Рядом с полем поиска появится значок щита."],
    note: "Добавьте два–три маршрута: если текущий перестанет отвечать, переключиться можно в разделе «Прокси» без повторного ввода данных.",
  },
  ios: {
    label: "iPhone / iPad", icon: Smartphone, title: "Telegram для iOS",
    steps: ["Откройте proxy-ссылку из каталога в Telegram.", "На экране с адресом сервера нажмите «Подключить прокси».", "Ручной путь: Настройки → Данные и память → Прокси → Добавить прокси → MTProto.", "Активируйте добавленный сервер. Статус соединения виден наверху списка чатов."],
    note: "Если iOS открывает ссылку в браузере, скопируйте её в «Избранное» Telegram и нажмите уже внутри приложения.",
  },
  desktop: {
    label: "Desktop", icon: Globe2, title: "Telegram Desktop",
    steps: ["Нажмите «Открыть Telegram» в окне подключения на этой странице.", "Подтвердите добавление MTProto-прокси в диалоге Telegram Desktop.", "Вручную: Настройки → Продвинутые настройки → Тип соединения → Настройки прокси.", "Выберите MTProto, вставьте сервер, порт и секрет из «Паспорта маршрута», затем сохраните."],
    note: "Если кнопка не реагирует, используйте вариант «Через t.me» или скопируйте конфигурацию и добавьте её вручную.",
  },
};

type GuideKey = keyof typeof guides;

export function GuideSection() {
  const [active, setActive] = useState<GuideKey>("android");
  const guide = guides[active];
  return (
    <section id="guide" className="bg-[#f3f5ef] py-24 text-ink sm:py-32">
      <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12">
        <motion.div {...reveal} className="grid gap-8 lg:grid-cols-[.8fr_1.2fr]">
          <div><div className="section-kicker text-ink/35"><Radio size={13} />Подключение</div><h2 className="mt-5 font-display text-[clamp(2.7rem,5vw,5rem)] font-medium leading-[0.98] tracking-[-0.06em]">От ссылки<br />до связи —<br /><span className="text-ink/30">меньше минуты.</span></h2><p className="mt-6 max-w-sm text-sm leading-6 text-ink/45">Никаких сторонних приложений и сертификатов. Используются штатные MTProto-настройки официального Telegram.</p><a href="https://telegram.org/apps" target="_blank" rel="noreferrer" className="mt-7 inline-flex items-center gap-2 border-b border-ink/20 pb-1 text-xs font-semibold text-ink/60 hover:border-ink">Официальные приложения Telegram<ExternalLink size={13} /></a></div>
          <div className="overflow-hidden rounded-[30px] border border-ink/[0.08] bg-white shadow-[0_25px_80px_rgba(21,36,29,.06)]">
            <div className="flex border-b border-ink/[0.08] p-2">{(Object.keys(guides) as GuideKey[]).map((key) => <button key={key} onClick={() => setActive(key)} className={`relative flex-1 rounded-full px-3 py-3 text-[11px] font-semibold transition-colors ${active === key ? "text-white" : "text-ink/40 hover:text-ink"}`}>{active === key && <motion.span layoutId="guide-tab" className="absolute inset-0 rounded-full bg-ink" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}<span className="relative">{guides[key].label}</span></button>)}</div>
            <AnimatePresence mode="wait">
              <motion.div key={active} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -15 }} transition={{ duration: 0.25 }} className="p-6 sm:p-9">
                <div className="flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-xl bg-[#eaf5e2] text-[#477c3b]"><guide.icon size={19} /></span><h3 className="font-display text-xl font-semibold tracking-tight">{guide.title}</h3></div>
                <ol className="mt-8 space-y-6">{guide.steps.map((step, index) => <li key={step} className="relative flex gap-4"><span className="relative z-10 grid h-8 w-8 shrink-0 place-items-center rounded-full border border-ink/10 bg-white font-mono text-[10px] font-semibold">{index + 1}</span>{index < guide.steps.length - 1 && <span className="absolute left-4 top-8 h-[calc(100%+4px)] w-px bg-ink/[0.08]" />}<p className="pt-1 text-xs leading-6 text-ink/60">{step}</p></li>)}</ol>
                <div className="mt-8 flex gap-3 rounded-2xl bg-[#f1f6eb] p-4 text-[11px] leading-5 text-[#4b6643]"><Check size={16} className="mt-0.5 shrink-0" />{guide.note}</div>
              </motion.div>
            </AnimatePresence>
          </div>
        </motion.div>
        <SecurityNotes />
        <FaqSection />
      </div>
    </section>
  );
}

function SecurityNotes() {
  return <motion.div {...reveal} className="mt-24 grid overflow-hidden rounded-[30px] bg-ink text-white lg:grid-cols-[.75fr_1.25fr]"><div className="border-b border-white/10 p-7 sm:p-10 lg:border-b-0 lg:border-r"><LockKeyhole size={28} className="text-accent" /><h3 className="mt-8 font-display text-3xl font-medium tracking-[-0.05em]">Прокси — не VPN.<br />И это нормально.</h3><p className="mt-4 text-xs leading-6 text-white/40">MTProto перенаправляет только соединения Telegram. Остальные приложения продолжают использовать ваше обычное подключение.</p></div><div className="grid sm:grid-cols-2">{[
    { icon: EyeOff, title: "Что видит оператор", text: "IP-адрес, время и объём соединения, технические метаданные. Не доверяете владельцу публичного сервера — не используйте его." },
    { icon: ShieldCheck, title: "Что защищает протокол", text: "Прокси не получает ключи MTProto-шифрования Telegram. Тем не менее это не делает публичный сервер полностью безопасным или анонимным." },
    { icon: RefreshCw, title: "Если связь пропала", text: "Обновите список и выберите другой маршрут. Блокировки зависят от страны, оператора и даже типа сети." },
    { icon: Database, title: "Что хранит MT/Radar", text: "Настройки, избранное и свои записи — локально в браузере. У приложения нет аккаунтов и собственной аналитики подключений." },
  ].map((item) => <div key={item.title} className="border-b border-white/[0.07] p-7 last:border-b-0 sm:odd:border-r sm:[&:nth-last-child(2)]:border-b-0"><item.icon size={17} className="text-accent/70" /><h4 className="mt-5 text-xs font-semibold">{item.title}</h4><p className="mt-2 text-[10px] leading-5 text-white/35">{item.text}</p></div>)}</div></motion.div>;
}

const faqs = [
  { q: "Вы действительно проверяете каждый прокси из моего браузера?", a: "Нет, и интерфейс прямо показывает это. Основной каталог загружает результаты серверных проверок открытых источников: ответ Telegram DC, MTProto handshake или доступность TCP-порта. Обычный браузер не может открыть произвольный TCP-сокет. Для собственной живой проверки можно настроить свой HTTPS checker API в настройках." },
  { q: "Что означает RTT рядом с прокси?", a: "Это время ответа, измеренное сервером конкретного источника, а не вашим устройством. Если маршрут подтверждён несколькими каталогами, показывается лучшее доступное значение с именем источника в деталях. Реальная задержка зависит от вашего оператора и местоположения." },
  { q: "Чем Fake-TLS отличается от Classic?", a: "Classic использует 16-байтовый секрет. Префикс dd включает рандомизированное дополнение пакетов, а ee обозначает Fake-TLS: трафик маскируется под TLS-соединение с заданным доменом. Для сетей с фильтрацией обычно стоит начинать с Fake-TLS на порту 443." },
  { q: "Почему прокси из списка всё равно не подключается?", a: "Проверка источника могла произойти раньше, сервер мог перегрузиться, а ваш оператор — заблокировать его адрес или домен. Обновите каталог, отсортируйте по свежим и попробуйте несколько записей. Статус «проверен» является результатом на указанное время, а не гарантией." },
  { q: "Можно экспортировать несколько прокси сразу?", a: "Да. Настройте фильтры и нажмите «Экспорт»: TXT содержит готовые t.me-ссылки, JSON сохраняет технические метаданные, CSV удобен для таблиц. Экспортируются все записи, соответствующие текущему фильтру, а не только видимая страница." },
  { q: "Нужно ли платить или создавать аккаунт?", a: "Нет. MT/Radar — клиентский каталог открытых данных без регистрации. Сами публичные прокси также предоставляются их владельцами бесплатно; проект не продаёт трафик и не управляет этими серверами." },
];

function FaqSection() {
  const [open, setOpen] = useState(0);
  return <motion.div {...reveal} id="faq" className="mt-24 grid gap-8 lg:grid-cols-[.65fr_1.35fr]"><div><div className="section-kicker text-ink/35">FAQ</div><h2 className="mt-4 font-display text-4xl font-semibold tracking-[-0.05em]">Без мелкого<br />шрифта.</h2><p className="mt-4 max-w-xs text-xs leading-5 text-ink/40">Важные ограничения технологии и каталога — до подключения, а не после.</p></div><div className="border-t border-ink/10">{faqs.map((item, index) => <div key={item.q} className="border-b border-ink/10"><button onClick={() => setOpen(open === index ? -1 : index)} className="flex w-full items-center justify-between gap-5 py-6 text-left"><span className="text-sm font-semibold text-ink/75">{item.q}</span><span className={`grid h-8 w-8 shrink-0 place-items-center rounded-full border border-ink/10 transition-transform ${open === index ? "rotate-180 bg-ink text-white" : "text-ink/40"}`}><ChevronDown size={15} /></span></button><AnimatePresence initial={false}>{open === index && <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3 }} className="overflow-hidden"><p className="max-w-2xl pb-6 pr-10 text-xs leading-6 text-ink/50">{item.a}</p></motion.div>}</AnimatePresence></div>)}</div></motion.div>;
}

export function Footer() {
  return <footer className="bg-[#f3f5ef] pb-8 pt-10 text-ink"><div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12"><div className="flex flex-col gap-8 border-t border-ink/10 pt-8 sm:flex-row sm:items-end sm:justify-between"><div><Brand /><p className="mt-4 max-w-md text-[10px] leading-5 text-ink/35">Независимый агрегатор открытых MTProto-каталогов. Не является продуктом Telegram и не управляет перечисленными прокси-серверами.</p></div><div className="flex flex-wrap gap-x-5 gap-y-2 text-[10px] text-ink/40"><a href="#catalog" className="hover:text-ink">Каталог</a><a href="#method" className="hover:text-ink">Методика</a><a href="#guide" className="hover:text-ink">Инструкция</a>{PROXY_SOURCES.slice(0, 2).map((source) => <a key={source.id} href={source.homepage} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 hover:text-ink">{source.shortName}<ArrowUpRight size={10} /></a>)}</div></div><div className="mt-8 flex flex-col gap-2 text-[9px] text-ink/25 sm:flex-row sm:justify-between"><span>MT/Radar · 2026</span><span>Данные принадлежат их источникам · Проверяйте перед использованием</span></div></div></footer>;
}
