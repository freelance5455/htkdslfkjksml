import React, { useState } from 'react';
import { Star, ShieldCheck, ThumbsUp, MessageSquare, CheckCircle2, User } from 'lucide-react';
import { soundManager } from '../utils/soundEffects';

interface Review {
  id: string;
  author: string;
  country: string;
  rating: number;
  text: string;
  date: string;
  verifiedQuotex: boolean;
  profit: string;
}

const INITIAL_REVIEWS: Review[] = [
  {
    id: 'r1',
    author: 'Kawsar Ahmed',
    country: 'BD',
    rating: 5,
    text: 'The 99% single sniper bot is incredible on USD/BDT OTC and USD/INR OTC! Waited for the candle close countdown and won 8 out of 8 trades in a row.',
    date: '10 minutes ago',
    verifiedQuotex: true,
    profit: '+$640.00',
  },
  {
    id: 'r2',
    author: 'Alexandre Silva',
    country: 'BR',
    rating: 5,
    text: 'Photo Analysis mode with AI Vision read my Quotex mobile screenshot in 2 seconds. The Bollinger band bounce signal on EUR/USD was exact.',
    date: '45 minutes ago',
    verifiedQuotex: true,
    profit: '+$390.00',
  },
  {
    id: 'r3',
    author: 'Rahul Sharma',
    country: 'IN',
    rating: 5,
    text: 'Axiler Quantum v2.4.7 is by far the cleanest Quotex signal bot. The candle countdown (Place trade in 41s) gives plenty of time to click CALL or PUT at exact 00 seconds.',
    date: '2 hours ago',
    verifiedQuotex: true,
    profit: '+$1,120.00',
  },
  {
    id: 'r4',
    author: 'Elena Rostova',
    country: 'RU',
    rating: 5,
    text: 'Configured custom RSI 25/75 with EMA 7/14 cross. High win rate today on OTC pairs. 1-step martingale recovered the single draw.',
    date: '3 hours ago',
    verifiedQuotex: true,
    profit: '+$515.00',
  },
];

export const ReviewsView: React.FC = () => {
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [newReviewText, setNewReviewText] = useState('');
  const [authorName, setAuthorName] = useState('');
  const [userRating, setUserRating] = useState(5);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewText.trim()) return;

    const newRev: Review = {
      id: `rev-${Date.now()}`,
      author: authorName.trim() || 'Verified Elite Trader',
      country: 'GLOBAL',
      rating: userRating,
      text: newReviewText.trim(),
      date: 'Just now',
      verifiedQuotex: true,
      profit: '+$210.00',
    };

    setReviews([newRev, ...reviews]);
    setNewReviewText('');
    setSubmitted(true);
    soundManager.playTradeWon();
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <div className="w-full max-w-lg mx-auto flex flex-col items-center px-3 py-3 space-y-4">
      {/* Title Banner */}
      <div className="w-full text-center">
        <h2 className="text-lg font-black text-slate-100 tracking-tight uppercase">
          COMMUNITY & TRADER REVIEWS
        </h2>
        <p className="text-xs text-zinc-400 mt-0.5">
          Real performance feedback from active Quotex binary options traders
        </p>
      </div>

      {/* Aggregate Score Card */}
      <div className="w-full bg-[#180710] border border-[#3b1223] rounded-2xl p-4 flex items-center justify-between shadow-lg">
        <div>
          <div className="flex items-center gap-1.5">
            <span className="text-3xl font-black font-mono text-amber-300">4.9</span>
            <div className="flex text-amber-400">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
          </div>
          <p className="text-[11px] text-zinc-400 mt-1">
            Based on 5,452 signals evaluated today
          </p>
        </div>

        <div className="text-right">
          <div className="text-xl font-black font-mono text-emerald-400 tabular-nums">
            96.8%
          </div>
          <span className="text-[10px] text-zinc-500 font-bold uppercase">
            99% Sniper Win Rate
          </span>
        </div>
      </div>

      {/* Write a Review Box */}
      <form
        onSubmit={handleSubmit}
        className="w-full bg-[#15050e] border border-[#300e1b] rounded-xl p-3.5 space-y-2.5 shadow-inner"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-200">Share Your Quotex Session</span>
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setUserRating(star)}
                className="focus:outline-none"
              >
                <Star
                  className={`w-3.5 h-3.5 ${
                    star <= userRating ? 'text-amber-400 fill-amber-400' : 'text-zinc-600'
                  }`}
                />
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <input
            type="text"
            placeholder="Your trader name"
            value={authorName}
            onChange={(e) => setAuthorName(e.target.value)}
            className="w-full bg-[#10040a] border border-[#2b0d19] rounded-lg px-2.5 py-1.5 text-xs text-white placeholder:text-zinc-600 outline-none"
          />
        </div>

        <textarea
          rows={2}
          placeholder="Share your signal results, pair used, or win streak..."
          value={newReviewText}
          onChange={(e) => setNewReviewText(e.target.value)}
          className="w-full bg-[#10040a] border border-[#2b0d19] rounded-lg px-2.5 py-1.5 text-xs text-white placeholder:text-zinc-600 outline-none resize-none"
        />

        <div className="flex items-center justify-between">
          {submitted ? (
            <span className="text-[11px] text-emerald-400 flex items-center gap-1 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Review posted!</span>
            </span>
          ) : (
            <span className="text-[10px] text-zinc-500">Verified Quotex ID check</span>
          )}

          <button
            type="submit"
            className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold transition-all shadow-md active:scale-95"
          >
            Post Review
          </button>
        </div>
      </form>

      {/* Reviews List */}
      <div className="w-full space-y-2.5">
        {reviews.map((rev) => (
          <div
            key={rev.id}
            className="w-full bg-[#16060f] border border-[#2d0d1a] rounded-xl p-3 shadow-sm space-y-1.5"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-zinc-800 flex items-center justify-center text-[10px] font-bold text-zinc-300">
                  {rev.author.substring(0, 1)}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-100">{rev.author}</span>
                    {rev.verifiedQuotex && (
                      <span className="text-[9px] font-bold text-emerald-400 bg-emerald-950/80 px-1 rounded border border-emerald-800/40">
                        VERIFIED TRADER
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-zinc-500 font-mono">{rev.date}</div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs font-mono font-bold text-emerald-400">{rev.profit}</div>
                <div className="flex text-amber-400 justify-end">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-amber-400" />
                  ))}
                </div>
              </div>
            </div>

            <p className="text-xs text-zinc-300 leading-relaxed font-normal pt-1">
              "{rev.text}"
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
