import React, { useState } from 'react';
import { ExternalLink, Gift, Sparkles } from 'lucide-react';
import { openExternalOfferLink, MONETAG_DIRECT_LINK } from '../utils/externalLinks';
import { soundEngine } from '../services/soundEngine';

interface ExploreOffersButtonProps {
  className?: string;
  variant?: 'home' | 'gameover';
}

export const ExploreOffersButton: React.FC<ExploreOffersButtonProps> = ({
  className = '',
  variant = 'home',
}) => {
  const [clicked, setClicked] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    soundEngine.playClick();
    setClicked(true);
    setTimeout(() => setClicked(false), 800);
    openExternalOfferLink(MONETAG_DIRECT_LINK);
  };

  if (variant === 'gameover') {
    return (
      <div className={`w-full pt-1 pb-1 flex flex-col items-center ${className}`}>
        <button
          onClick={handleClick}
          type="button"
          aria-label="Explore external partner offers"
          className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500/10 via-amber-400/15 to-orange-500/10 hover:from-amber-500/20 hover:to-orange-500/20 border border-amber-400/40 text-amber-300 transition-all duration-150 active:scale-[0.98] shadow-sm flex items-center justify-between group"
        >
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-amber-400/20 flex items-center justify-center text-amber-300">
              <Gift className="w-3.5 h-3.5" />
            </div>
            <div className="text-left">
              <span className="font-bold text-xs tracking-wide text-white block">
                Explore Offers
              </span>
              <span className="text-[10px] text-amber-300/80 block">
                Sponsored partner deals
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1 text-[11px] font-semibold text-amber-300 group-hover:text-amber-200">
            <span>Visit</span>
            <ExternalLink className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </button>
      </div>
    );
  }

  // Home Screen layout: cleanly separated from primary game buttons
  return (
    <div className={`w-full ${className}`}>
      <button
        onClick={handleClick}
        type="button"
        aria-label="Explore external partner offers"
        className="w-full py-2.5 px-3.5 rounded-xl bg-[#12192e]/90 hover:bg-[#182342] border border-amber-500/35 hover:border-amber-400/50 text-slate-200 transition-all duration-150 active:scale-[0.98] shadow-md flex items-center justify-between group"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="text-left">
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-xs sm:text-sm text-white font-display">
                Explore Offers
              </span>
              <span className="text-[9px] font-semibold px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 uppercase tracking-wider">
                Ad
              </span>
            </div>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              Check out external deals &amp; specials
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1 text-xs font-semibold text-amber-400 group-hover:text-amber-300">
          <ExternalLink className="w-4 h-4 group-hover:scale-110 transition-transform" />
        </div>
      </button>
    </div>
  );
};
