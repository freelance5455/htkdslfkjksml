import React, { useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { 
  Sparkles, 
  Award, 
  Flame, 
  Coins, 
  Share2, 
  CheckCircle2, 
  X, 
  Zap, 
  ArrowRight,
  ShieldCheck,
  TrendingUp
} from 'lucide-react';

export interface MilestoneData {
  id: string;
  title: string;
  subtitle: string;
  category: 'reward' | 'hashrate' | 'block' | 'nonce';
  rewardJMC: number;
  fiatUSD: number;
  fiatNGN: number;
  levelBadge: string;
  icon?: string;
}

interface JMCRewardCelebrationProps {
  milestone: MilestoneData | null;
  onClose: () => void;
  onClaim?: () => void;
}

export const fireConfettiCelebration = () => {
  // Burst 1: Golden & Amber Fountain
  confetti({
    particleCount: 80,
    spread: 70,
    origin: { y: 0.6 },
    colors: ['#F59E0B', '#FBBF24', '#FCD34D', '#10B981', '#3B82F6', '#8B5CF6']
  });

  // Burst 2: Staggered stars from both sides
  setTimeout(() => {
    confetti({
      particleCount: 50,
      angle: 60,
      spread: 55,
      origin: { x: 0.1, y: 0.7 },
      colors: ['#F59E0B', '#FDE047', '#34D399', '#60A5FA']
    });
    confetti({
      particleCount: 50,
      angle: 120,
      spread: 55,
      origin: { x: 0.9, y: 0.7 },
      colors: ['#F59E0B', '#FDE047', '#34D399', '#60A5FA']
    });
  }, 250);

  // Trigger gentle mobile haptic feedback if supported
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate([100, 50, 100, 50, 200]);
    } catch {
      // ignore
    }
  }
};

export const JMCRewardCelebration: React.FC<JMCRewardCelebrationProps> = ({
  milestone,
  onClose,
  onClaim
}) => {
  const triggerCelebration = useCallback(() => {
    if (milestone) {
      fireConfettiCelebration();
    }
  }, [milestone]);

  useEffect(() => {
    if (milestone) {
      triggerCelebration();
    }
  }, [milestone, triggerCelebration]);

  if (!milestone) return null;

  const handleShareMilestone = async () => {
    const text = `🎉 I just unlocked the "${milestone.title}" milestone on JUHNKRIX MUSIKA JMCrypto Mining! (+${milestone.rewardJMC.toFixed(4)} JMC / $${milestone.fiatUSD.toLocaleString()} USD). Mine decentralized JMC with me: https://juhnkrixmusika.pages.dev`;
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: 'JUHNKRIX MUSIKA - JMC Milestone Unlocked!',
          text,
          url: 'https://juhnkrixmusika.pages.dev'
        });
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          navigator.clipboard.writeText(text);
        }
      }
    } else if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(text);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
        {/* Pulsating Backdrop Glow */}
        <div className="absolute w-[500px] h-[500px] bg-gradient-to-tr from-amber-500/20 via-yellow-500/15 to-emerald-500/20 rounded-full blur-3xl pointer-events-none animate-pulse" />

        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.85, y: -20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative max-w-lg w-full bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border-2 border-amber-400/80 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(245,158,11,0.35)] space-y-6 text-center overflow-hidden"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800/80 text-slate-400 hover:text-amber-300 border border-amber-500/20 transition-colors cursor-pointer"
            title="Dismiss Celebration"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Top Sparkling Badge */}
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-amber-500/20 via-yellow-500/30 to-amber-500/20 border border-amber-400/50 text-amber-300 text-xs font-black uppercase tracking-wider shadow-inner">
            <Sparkles className="w-4 h-4 text-amber-400 animate-spin-slow" />
            <span>{milestone.levelBadge}</span>
          </div>

          {/* Icon Trophy Centerpiece */}
          <div className="relative mx-auto w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center">
            {/* Spinning decorative halo */}
            <div className="absolute inset-0 rounded-3xl bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-600 opacity-30 blur-lg animate-pulse" />
            <div className="relative w-full h-full rounded-3xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 flex items-center justify-center shadow-xl border-2 border-amber-200">
              <Award className="w-14 h-14 sm:w-16 sm:h-16 text-slate-950 drop-shadow-md" />
            </div>
          </div>

          {/* Title & Celebration Pitch */}
          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl font-black font-serif tracking-tight bg-gradient-to-r from-amber-100 via-yellow-200 to-amber-400 bg-clip-text text-transparent">
              {milestone.title}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-sm mx-auto leading-relaxed">
              {milestone.subtitle}
            </p>
          </div>

          {/* Reward Value Showcase Box */}
          <div className="bg-slate-950/90 border-2 border-amber-500/40 rounded-2xl p-4 sm:p-5 space-y-2 shadow-inner">
            <div className="text-[11px] font-bold text-amber-300/80 uppercase tracking-wider flex items-center justify-center space-x-1">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>Milestone Mining Reward</span>
            </div>
            <div className="text-3xl sm:text-4xl font-black font-mono text-amber-300 tracking-tight">
              +{milestone.rewardJMC.toFixed(4)} <span className="text-xl font-bold text-amber-400">JMC</span>
            </div>
            <div className="flex items-center justify-center space-x-2 text-xs font-bold text-emerald-400 pt-1 border-t border-slate-800">
              <span>≈ ${(milestone.fiatUSD).toLocaleString()} USD</span>
              <span className="text-slate-500">•</span>
              <span className="text-amber-200">₦{(milestone.fiatNGN).toLocaleString()} NGN</span>
            </div>
          </div>

          {/* 50/50 Proof & Security Note */}
          <div className="flex items-center justify-center space-x-4 text-[11px] text-slate-400 font-mono">
            <div className="flex items-center space-x-1 text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>50% User Device Share</span>
            </div>
            <div className="flex items-center space-x-1 text-blue-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Hardware-Bound Proof</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <button
              onClick={() => {
                if (onClaim) onClaim();
                onClose();
              }}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/30 transition-all hover:scale-102 active:scale-95 cursor-pointer"
            >
              <span>Claim & Continue Mining</span>
              <ArrowRight className="w-4 h-4 text-slate-950" />
            </button>

            <button
              onClick={handleShareMilestone}
              className="w-full py-3.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-200 border border-amber-500/40 font-bold text-xs flex items-center justify-center space-x-2 transition-all hover:scale-102 active:scale-95 cursor-pointer shadow-md"
            >
              <Share2 className="w-4 h-4 text-amber-400" />
              <span>Share Milestone</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
