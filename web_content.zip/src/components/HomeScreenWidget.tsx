import React, { useState } from 'react';
import {
  X,
  Smartphone,
  Check,
  Pin,
  ExternalLink,
  Download,
  Layers,
  Sparkles,
  ArrowRight,
  Maximize2,
  Clock,
} from 'lucide-react';
import { CalendarDay, LocationPreset, UserSettings, ZmanItem } from '../types';
import { calculateZmanim, UpcomingHolidayCountdown } from '../services/hebrewCalendarService';
import { getDailyVerseForDate } from '../services/dailyVerseService';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HomeScreenWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  todayDay: CalendarDay;
  location: LocationPreset;
  nextZman: ZmanItem | null;
  nextHoliday?: UpcomingHolidayCountdown | null;
  settings?: UserSettings;
  floatingPinned: boolean;
  onToggleFloating: () => void;
  onOpenStandaloneWidget?: () => void;
}

export const HomeScreenWidget: React.FC<HomeScreenWidgetProps> = ({
  isOpen,
  onClose,
  todayDay,
  location,
  nextZman,
  nextHoliday,
  settings,
  floatingPinned,
  onToggleFloating,
  onOpenStandaloneWidget,
}) => {
  const [activeTab, setActiveTab] = useState<'preview' | 'instructions'>('preview');
  const [selectedWidgetSize, setSelectedWidgetSize] = useState<'small' | 'medium' | 'large'>('medium');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();

  const isRtl = settings?.language === 'he';
  const zmanimData = calculateZmanim(todayDay.gregorianDate, location);
  const dailyVerse = getDailyVerseForDate(todayDay.gregorianDate);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.origin + '?mode=widget');
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleLaunchStandalone = () => {
    if (onOpenStandaloneWidget) {
      onOpenStandaloneWidget();
    } else {
      window.location.href = window.location.origin + '?mode=widget';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-[#121212] rounded-2xl max-w-2xl w-full border border-[#2A2A2A] shadow-2xl overflow-hidden my-6 flex flex-col text-[#D1D1D1]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#2A2A2A] flex items-center justify-between bg-[#161616]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#252525] to-[#1A1A1A] border border-[#3A3A3A] text-[#C5A267] flex items-center justify-center text-lg shadow-sm">
              <Smartphone className="w-5 h-5 text-[#C5A267]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-[#EAEAEA]">
                  {isRtl ? 'וידג׳ט למסך הבית של הטלפון' : 'Phone Home Screen Widget'}
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#C5A267]/15 text-[#C5A267] border border-[#C5A267]/30">
                  {isRtl ? 'הוספה ישירה' : 'Add Widget'}
                </span>
              </div>
              <p className="text-xs text-[#888888]">
                {isRtl
                  ? 'הוסף יישומון למסך הבית בלחיצה ארוכה (Long Press -> Add Widgets)'
                  : 'Add to home screen by long-pressing home screen -> Add Widgets'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#888888] hover:text-[#EAEAEA] hover:bg-[#252525] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#2A2A2A] bg-[#141414] px-4 pt-2 gap-2">
          <button
            onClick={() => setActiveTab('preview')}
            className={`pb-2.5 px-3 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-all ${
              activeTab === 'preview'
                ? 'border-[#C5A267] text-[#C5A267]'
                : 'border-transparent text-[#888888] hover:text-[#D1D1D1]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{isRtl ? 'תצוגה מקדימה וגדלים' : 'Preview & Sizes'}</span>
          </button>
          <button
            onClick={() => setActiveTab('instructions')}
            className={`pb-2.5 px-3 text-xs font-semibold flex items-center gap-1.5 border-b-2 transition-all ${
              activeTab === 'instructions'
                ? 'border-[#C5A267] text-[#C5A267]'
                : 'border-transparent text-[#888888] hover:text-[#D1D1D1]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isRtl ? 'מדריך הוספה במסך הבית' : 'Home Screen Setup Guide'}</span>
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-5 overflow-y-auto max-h-[75vh]">
          {/* Main Action Banner: Install / Add to Home Screen */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-[#1C1812] via-[#171717] to-[#141414] border border-[#C5A267]/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#C5A267]/20 border border-[#C5A267]/40 text-[#C5A267] flex items-center justify-center shrink-0">
                <Download className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">
                  {isInstalled
                    ? isRtl ? 'האפליקציה מותקנת במכשיר ✓' : 'App Installed on Device ✓'
                    : isRtl ? '1. התקן את האפליקציה במכשיר' : '1. Install App to Device'}
                </h4>
                <p className="text-[11px] text-[#A0A0A0] mt-0.5">
                  {isRtl
                    ? 'לאחר ההתקנה, בצע לחיצה ארוכה על מסך הבית ובחר "יישומונים" (Widgets).'
                    : 'After installing, long-press on your phone home screen and choose "Widgets".'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
              {isInstallable && !isInstalled && (
                <button
                  id="install-pwa-modal-btn"
                  onClick={install}
                  className="px-4 py-2 rounded-lg bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold flex items-center gap-1.5 shadow-sm transition-transform active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>{isRtl ? 'התקן כעת' : 'Install Now'}</span>
                </button>
              )}

              {isIOS && !isInstalled && (
                <button
                  onClick={() => setActiveTab('instructions')}
                  className="px-3 py-1.5 rounded-lg border border-[#C5A267]/60 text-[#C5A267] hover:bg-[#C5A267]/10 text-xs font-semibold"
                >
                  {isRtl ? 'הוראות ל-iOS' : 'iOS Guide'}
                </button>
              )}

              <button
                onClick={handleLaunchStandalone}
                className="px-3 py-2 rounded-lg border border-[#3A3A3A] bg-[#222222] hover:bg-[#2A2A2A] text-[#D1D1D1] text-xs font-medium flex items-center gap-1.5 transition-colors"
                title={isRtl ? 'פתח מסך וידג׳ט ייעודי' : 'Open standalone widget view'}
              >
                <Maximize2 className="w-3.5 h-3.5 text-[#C5A267]" />
                <span>{isRtl ? 'מצב וידג׳ט מלא' : 'Widget View'}</span>
              </button>
            </div>
          </div>

          {activeTab === 'preview' ? (
            <>
              {/* Widget Size Selector Tabs */}
              <div className="flex items-center justify-center gap-2">
                {[
                  { id: 'small', label: isRtl ? 'קומפקטי (2x2)' : 'Compact (2x2)', desc: isRtl ? 'חג וזמן' : 'Holiday & Zman' },
                  { id: 'medium', label: isRtl ? 'קלאסי (4x2)' : 'Classic (4x2)', desc: isRtl ? 'תאריך מלא' : 'Full Date & Times' },
                  { id: 'large', label: isRtl ? 'מורחב (4x4)' : 'Expanded (4x4)', desc: isRtl ? 'לוח ופסוק' : 'Dashboard & Verse' },
                ].map((size) => (
                  <button
                    key={size.id}
                    onClick={() => setSelectedWidgetSize(size.id as any)}
                    className={`flex-1 px-3 py-2 rounded-xl text-xs font-semibold transition-all border text-center ${
                      selectedWidgetSize === size.id
                        ? 'bg-[#C5A267] text-[#0F0F0F] border-[#C5A267] shadow-sm'
                        : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:bg-[#252525] hover:text-[#EAEAEA]'
                    }`}
                  >
                    <div>{size.label}</div>
                    <div className="text-[10px] opacity-75">{size.desc}</div>
                  </button>
                ))}
              </div>

              {/* Simulated Mobile Home Screen Frame */}
              <div className="p-4 sm:p-6 rounded-2xl bg-gradient-to-b from-[#090B10] via-[#0E1015] to-[#0A0B0E] border border-[#2A2A2A] flex flex-col items-center justify-center relative overflow-hidden shadow-inner min-h-[260px]">
                {/* Simulated Phone Wallpaper Background Elements */}
                <div className="absolute top-2 left-4 text-[10px] font-mono text-[#555555]">9:41</div>
                <div className="absolute top-2 right-4 flex items-center gap-1 text-[10px] text-[#555555]">
                  <span>5G</span>
                  <span>100%</span>
                </div>

                {/* 1. Compact Widget (2x2) */}
                {selectedWidgetSize === 'small' && (
                  <div className="w-64 bg-[#1E1E1E]/95 backdrop-blur-md rounded-[26px] p-4.5 border border-[#3A3A3A] shadow-2xl relative flex flex-col justify-between my-2">
                    <div className="flex justify-between items-start mb-2.5">
                      <div className="w-7 h-7 rounded-lg overflow-hidden border border-[#C5A267]/40 bg-[#161616] flex items-center justify-center shrink-0">
                        <img
                          src="/app-icon.jpg"
                          alt="לוחות בה"
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            const target = e.currentTarget;
                            target.style.display = 'none';
                            if (target.parentElement) {
                              target.parentElement.innerHTML = '<div class="w-full h-full bg-[#C5A267] flex items-center justify-center text-[#0F0F0F] font-bold font-serif-hebrew text-[10px]">בה</div>';
                            }
                          }}
                        />
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] text-[#C5A267] font-bold uppercase tracking-wider">{isRtl ? location.nameHe || location.name : location.name.split(' ')[0]}</p>
                        <p className="text-[8px] text-[#888888]">{location.country}</p>
                      </div>
                    </div>

                    <div className="my-1">
                      <p className="text-lg font-serif text-white font-bold" dir="rtl">{todayDay.hebrewDayLetters} {todayDay.hebrewMonthNameHe}</p>
                      <p className="text-[10px] text-[#888888] mt-0.5">{todayDay.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</p>
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-[#333333] space-y-1.5 text-xs">
                      {nextHoliday && (
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-1.5 truncate">
                            <span className="text-xs">🍯</span>
                            <span className="text-[10px] font-bold text-[#E5C287] font-serif-hebrew truncate" dir="rtl">{nextHoliday.nameHe}</span>
                          </div>
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#C5A267]/20 text-[#E5C287] font-bold shrink-0">
                            {nextHoliday.daysRemaining === 0 ? (isRtl ? 'היום' : 'Today') : `${nextHoliday.daysRemaining}d`}
                          </span>
                        </div>
                      )}

                      {nextZman && (
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-1.5 truncate">
                            <span className="text-xs">⏳</span>
                            <span className="text-[10px] font-bold text-[#C5A267] font-serif-hebrew truncate" dir="rtl">{nextZman.hebrewTitle}</span>
                          </div>
                          <span className="text-[10px] font-mono font-bold text-white shrink-0">{nextZman.formattedTime}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* 2. Medium Widget (4x2) */}
                {selectedWidgetSize === 'medium' && (
                  <div className="w-full max-w-sm bg-[#1E1E1E]/95 backdrop-blur-md rounded-[28px] p-5 border border-[#3A3A3A] shadow-2xl relative my-2">
                    <div className="flex justify-between items-start mb-2.5">
                      <div className="w-9 h-9 rounded-xl overflow-hidden border border-[#C5A267]/40 bg-[#161616] flex items-center justify-center shrink-0">
                        <img
                          src="/app-icon.jpg"
                          alt="לוחות בה"
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            const target = e.currentTarget;
                            target.style.display = 'none';
                            if (target.parentElement) {
                              target.parentElement.innerHTML = '<div class="w-full h-full bg-[#C5A267] flex items-center justify-center text-[#0F0F0F] font-bold font-serif-hebrew text-xs">בה</div>';
                            }
                          }}
                        />
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-[#C5A267] font-bold uppercase tracking-wider">{isRtl ? location.nameHe || location.name : location.name}</p>
                        <p className="text-[9px] text-[#888888]">{location.country}</p>
                      </div>
                    </div>

                    <p className="text-2xl font-serif text-white font-bold" dir="rtl">
                      {todayDay.hebrewDayLetters} {todayDay.hebrewMonthNameHe} {todayDay.hebrewYearLetters}
                    </p>
                    <p className="text-xs text-[#888888] mt-0.5">
                      {todayDay.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', {
                        weekday: 'long',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </p>

                    <div className="mt-3.5 pt-2.5 border-t border-[#333333] space-y-2">
                      {nextHoliday && (
                        <div className="flex justify-between items-center text-xs">
                          <div className="flex items-center gap-2 truncate">
                            <span className="text-sm">🍯</span>
                            <div className="truncate">
                              <span className="text-[8px] text-[#888888] uppercase tracking-wider block">
                                {isRtl ? 'החג הקרוב' : 'UPCOMING HOLIDAY'}
                              </span>
                              <span className="text-xs font-bold text-[#E5C287] font-serif-hebrew" dir="rtl">
                                {nextHoliday.nameHe}
                              </span>
                            </div>
                          </div>
                          <span className="px-2 py-0.5 rounded bg-[#C5A267] text-[#0F0F0F] font-bold text-[11px] font-mono shrink-0">
                            {nextHoliday.daysRemaining === 0 ? (isRtl ? 'היום!' : 'Today!') : `${nextHoliday.daysRemaining} ${nextHoliday.daysRemaining === 1 ? (isRtl ? 'יום' : 'day') : (isRtl ? 'ימים' : 'days')}`}
                          </span>
                        </div>
                      )}

                      {nextZman && (
                        <div className="flex justify-between items-center text-xs pt-1.5 border-t border-[#2A2A2A]">
                          <div className="flex items-center gap-2 truncate">
                            <span className="text-sm">⏳</span>
                            <div className="truncate">
                              <span className="text-[8px] text-[#888888] uppercase tracking-wider block">
                                {isRtl ? 'הזמן הבא' : 'NEXT ZMAN'}
                              </span>
                              <span className="text-xs font-bold text-[#C5A267] font-serif-hebrew" dir="rtl">
                                {nextZman.hebrewTitle}
                              </span>
                            </div>
                          </div>
                          <span className="text-xs font-mono text-white font-bold shrink-0">
                            {nextZman.formattedTime}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* 3. Large Widget (4x4) */}
                {selectedWidgetSize === 'large' && (
                  <div className="w-full max-w-sm bg-[#1E1E1E]/95 backdrop-blur-md rounded-[30px] p-5 border border-[#3A3A3A] shadow-2xl relative space-y-3 my-2">
                    <div className="flex justify-between items-start">
                      <div className="w-9 h-9 rounded-xl overflow-hidden border border-[#C5A267]/40 bg-[#161616] flex items-center justify-center shrink-0">
                        <img
                          src="/app-icon.jpg"
                          alt="לוחות בה"
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            const target = e.currentTarget;
                            target.style.display = 'none';
                            if (target.parentElement) {
                              target.parentElement.innerHTML = '<div class="w-full h-full bg-[#C5A267] flex items-center justify-center text-[#0F0F0F] font-bold font-serif-hebrew text-xs">בה</div>';
                            }
                          }}
                        />
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-[#C5A267] font-bold uppercase">{isRtl ? location.nameHe || location.name : location.name}</p>
                        <p className="text-[9px] text-[#888888] font-hebrew" dir="rtl">{todayDay.hebrewDateStrHe}</p>
                      </div>
                    </div>

                    <div>
                      <p className="text-2xl font-serif text-white font-bold" dir="rtl">
                        {todayDay.hebrewDateStrHe}
                      </p>
                      <p className="text-[11px] text-[#888888] mt-0.5">
                        {todayDay.gregorianDate.toLocaleDateString(isRtl ? 'he-IL' : 'en-US', {
                          weekday: 'long',
                          month: 'long',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </p>
                    </div>

                    <div className="p-2.5 rounded-xl bg-[#141414] border border-[#2A2A2A] space-y-1.5">
                      {nextHoliday && (
                        <div className="flex justify-between items-center text-xs">
                          <div className="flex items-center gap-1.5 truncate">
                            <span>🍯</span>
                            <span className="font-bold text-[#E5C287] font-serif-hebrew truncate" dir="rtl">{nextHoliday.nameHe}</span>
                          </div>
                          <span className="px-1.5 py-0.5 rounded bg-[#C5A267]/20 text-[#E5C287] font-bold text-[10px] font-mono shrink-0">
                            {nextHoliday.daysRemaining === 0 ? (isRtl ? 'היום' : 'Today') : `עוד ${nextHoliday.daysRemaining} יום`}
                          </span>
                        </div>
                      )}

                      {nextZman && (
                        <div className="flex justify-between items-center text-xs pt-1.5 border-t border-[#222222]">
                          <div className="flex items-center gap-1.5 truncate">
                            <span>⏳</span>
                            <span className="font-bold text-[#C5A267] font-serif-hebrew truncate" dir="rtl">{nextZman.hebrewTitle}</span>
                          </div>
                          <span className="font-mono text-white font-bold text-xs shrink-0">{nextZman.formattedTime}</span>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-2 rounded-xl bg-[#141414] border border-[#2A2A2A]">
                        <span className="text-[9px] text-[#888888] font-bold uppercase">{isRtl ? 'הנץ החמה' : 'Sunrise'}</span>
                        <p className="text-xs font-mono text-[#EAEAEA] font-bold">
                          {zmanimData.items.find(z => z.id === 'sunrise')?.formattedTime}
                        </p>
                      </div>
                      <div className="p-2 rounded-xl bg-[#141414] border border-[#2A2A2A]">
                        <span className="text-[9px] text-[#888888] font-bold uppercase">{isRtl ? 'שקיעת החמה' : 'Sunset'}</span>
                        <p className="text-xs font-mono text-[#EAEAEA] font-bold">
                          {zmanimData.items.find(z => z.id === 'sunset')?.formattedTime}
                        </p>
                      </div>
                    </div>

                    <div className="p-2 rounded-xl bg-[#141414] border border-[#2A2A2A] text-xs">
                      <p className="text-[11px] font-serif text-[#C5A267] text-right font-bold" dir="rtl">
                        {dailyVerse.hebrew}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            /* Tab: Step-by-Step Instructions */
            <div className="space-y-4 text-xs">
              {/* Android Method 1: Home Screen Long Press */}
              <div className="p-4 rounded-xl bg-[#161616] border border-[#2A2A2A] space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-[#C5A267] text-[#0F0F0F] font-bold flex items-center justify-center text-xs">1</span>
                  <h4 className="font-bold text-sm text-white">
                    {isRtl ? 'הוספת יישומון (Widget) בלחיצה ארוכה על מסך הבית:' : 'Add Widget via Home Screen Long-Press:'}
                  </h4>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-[#A0A0A0]">
                  <div className="p-3 rounded-lg bg-[#1D1D1D] border border-[#2C2C2C] space-y-1">
                    <p className="font-bold text-[#EAEAEA]">{isRtl ? 'שלב א׳: לחיצה ארוכה' : 'Step 1: Long Press'}</p>
                    <p>{isRtl ? 'לחץ לחיצה ארוכה על שטח ריק במסך הבית של הטלפון.' : 'Long-press any empty area on your phone home screen.'}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-[#1D1D1D] border border-[#2C2C2C] space-y-1">
                    <p className="font-bold text-[#EAEAEA]">{isRtl ? 'שלב ב׳: בחר "יישומונים"' : 'Step 2: Tap "Widgets"'}</p>
                    <p>{isRtl ? 'בחר בתפריט "יישומונים" (Widgets / Add apps) וחפש "Hebrew Calendar".' : 'Select "Widgets" (Add apps) and find "Hebrew Calendar".'}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-[#1D1D1D] border border-[#2C2C2C] space-y-1">
                    <p className="font-bold text-[#EAEAEA]">{isRtl ? 'שלב ג׳: גרור למסך' : 'Step 3: Drag & Drop'}</p>
                    <p>{isRtl ? 'בחר את גודל הווידג׳ט (2x2, 4x2, 4x4) וגרור אותו למיקום הרצוי.' : 'Pick your preferred widget size (2x2, 4x2, 4x4) and drag to place.'}</p>
                  </div>
                </div>
              </div>

              {/* Android/iOS Method 2: App Icon Long Press (App Shortcuts) */}
              <div className="p-4 rounded-xl bg-[#161616] border border-[#2A2A2A] space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-[#3B82F6] text-white font-bold flex items-center justify-center text-xs">2</span>
                  <h4 className="font-bold text-sm text-white">
                    {isRtl ? 'קיצורי דרך מהירים בלחיצה ארוכה על סמל האפליקציה (App Icon):' : 'App Shortcuts via App Icon Long-Press:'}
                  </h4>
                </div>
                <p className="text-[11px] text-[#A0A0A0]">
                  {isRtl
                    ? 'לאחר התקנת האפליקציה, לחיצה ארוכה על סמל האפליקציה במסך הבית פותחת תפריט פעולות מהיר:'
                    : 'Once installed, long-pressing the app icon opens direct home shortcuts:'}
                </p>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-2.5 rounded-lg bg-[#1D1D1D] border border-[#2C2C2C] flex items-center gap-2">
                    <Clock className="w-4 h-4 text-blue-400 shrink-0" />
                    <div>
                      <strong className="text-white block">{isRtl ? 'זמני היום והתאריך' : 'Today & Zmanim'}</strong>
                      <span className="text-[10px] text-[#888888]">{isRtl ? 'גישה מידית לזמני ההלכה' : 'Direct prayer times'}</span>
                    </div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#1D1D1D] border border-[#2C2C2C] flex items-center gap-2">
                    <span className="text-base shrink-0">🍯</span>
                    <div>
                      <strong className="text-white block">{isRtl ? 'החג הקרוב' : 'Holiday Countdown'}</strong>
                      <span className="text-[10px] text-[#888888]">{isRtl ? 'ספירה לאחור לחג הבא' : 'Days until next holiday'}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* iOS Safari Guide */}
              <div className="p-4 rounded-xl bg-[#161616] border border-[#2A2A2A] space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-[#888888] text-white font-bold flex items-center justify-center text-xs">3</span>
                  <h4 className="font-bold text-sm text-white">
                    {isRtl ? 'התקנה והוספה ב-iPhone / iPad (iOS Safari):' : 'Install on iPhone / iPad (iOS Safari):'}
                  </h4>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-[#A0A0A0] text-[11px] leading-relaxed">
                  <li>{isRtl ? 'פתח את האפליקציה בדפדפן Safari.' : 'Open this app in Safari.'}</li>
                  <li>{isRtl ? 'לחץ על כפתור השיתוף (Share) בסרגל התחתון.' : 'Tap the Share icon on the bottom toolbar.'}</li>
                  <li>{isRtl ? 'גלול ובחר "הוסף למסך הבית" (Add to Home Screen).' : 'Scroll and select "Add to Home Screen".'}</li>
                  <li>{isRtl ? 'סמל האפליקציה והווידג׳ט יופיעו ישירות במסך הבית שלך!' : 'The app and widget shortcut will appear directly on your home screen!'}</li>
                </ol>
              </div>
            </div>
          )}

          {/* Quick Actions Footer */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-[#2A2A2A]">
            <button
              onClick={onToggleFloating}
              className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                floatingPinned
                  ? 'border-[#C5A267] bg-[#252525] text-[#C5A267] font-bold'
                  : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:bg-[#252525] hover:text-[#EAEAEA]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Pin className="w-4 h-4 text-[#C5A267]" />
                <div className="text-left text-xs">
                  <div className="font-bold">
                    {floatingPinned 
                      ? (isRtl ? 'וידג׳ט צף מוצמד' : 'Floating Widget Pinned') 
                      : (isRtl ? 'הצמד וידג׳ט צף למסך' : 'Pin Floating Screen Widget')}
                  </div>
                  <div className="text-[10px] opacity-75">
                    {isRtl ? 'נשאר בפינת המסך בזמן גלישה' : 'Stays on screen while browsing'}
                  </div>
                </div>
              </div>
              <span className="text-xs font-bold">{floatingPinned ? 'ON' : 'OFF'}</span>
            </button>

            {onOpenStandaloneWidget && (
              <button
                onClick={() => {
                  onClose();
                  onOpenStandaloneWidget();
                }}
                className="p-3 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:bg-[#252525] hover:text-[#EAEAEA] transition-colors flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <Maximize2 className="w-4 h-4 text-[#C5A267]" />
                  <div className="text-left">
                    <div className="font-bold">{isRtl ? 'הפעל תצוגת וידג׳ט מלאה' : 'Launch Fullscreen Widget'}</div>
                    <div className="text-[10px] text-[#666666]">{isRtl ? 'פתח מסך וידג׳ט ייעודי' : 'Open dedicated widget view'}</div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-[#888888]" />
              </button>
            )}

            <button
              onClick={handleCopyLink}
              className="p-3 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-[#888888] hover:bg-[#252525] hover:text-[#EAEAEA] transition-colors flex items-center justify-between text-xs"
            >
              <div className="flex items-center gap-2.5">
                <Smartphone className="w-4 h-4 text-[#C5A267]" />
                <div className="text-left">
                  <div className="font-bold">{isRtl ? 'העתק קישור ישיר לווידג׳ט' : 'Copy Direct Widget Link'}</div>
                  <div className="text-[10px] text-[#666666]">{isRtl ? 'הוסף לסימניות מסך הבית' : 'Save as standalone widget'}</div>
                </div>
              </div>
              {copiedUrl ? <Check className="w-4 h-4 text-[#C5A267]" /> : <ExternalLink className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 sm:p-4 border-t border-[#2A2A2A] bg-[#161616] flex items-center justify-between">
          <div className="text-[11px] text-[#888888] flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>{isRtl ? 'תומך ב-Android, iOS ו-PWA' : 'Supports Android, iOS & PWA Widgets'}</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold shadow-sm transition-colors"
          >
            {isRtl ? 'סיום' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
};

export const FloatingQuickWidget: React.FC<{
  todayDay: CalendarDay;
  nextZman: ZmanItem | null;
  nextHoliday?: UpcomingHolidayCountdown | null;
  settings?: UserSettings;
  location: LocationPreset;
  onOpenApp: () => void;
  onClose: () => void;
}> = ({ todayDay, nextZman, nextHoliday, settings, location, onOpenApp, onClose }) => {
  const isRtl = settings?.language === 'he';

  return (
    <div className="fixed bottom-5 right-5 z-40 animate-in slide-in-from-bottom-5 duration-200">
      <div className="w-64 p-4 rounded-2xl bg-[#1A1A1A]/95 border border-[#3A3A3A] shadow-2xl backdrop-blur-md flex flex-col gap-2 relative group select-none text-[#D1D1D1]">
        <button
          onClick={onClose}
          className="absolute -top-2 -left-2 w-5 h-5 rounded-full bg-[#2A2A2A] text-white flex items-center justify-center text-[10px] opacity-0 group-hover:opacity-100 transition-opacity shadow-md hover:bg-[#3A3A3A]"
          title="Dismiss Floating Widget"
        >
          ×
        </button>

        <div className="flex items-center justify-between cursor-pointer" onClick={onOpenApp}>
          <div>
            <div className="text-base font-bold font-serif text-[#C5A267] leading-none" dir="rtl">
              {todayDay.hebrewDateStrHe}
            </div>
            {!isRtl && (
              <div className="text-[10px] text-[#888888] font-hebrew mt-0.5">
                {todayDay.hebrewDateStr}
              </div>
            )}
          </div>
          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#252525] text-[#C5A267] border border-[#3A3A3A]">
            {isRtl ? location.nameHe || location.name : location.name.split(' ')[0]}
          </span>
        </div>

        {/* 2-Line Overview: Holiday on top, Next Zman on bottom */}
        <div className="space-y-1.5 mt-1">
          {nextHoliday && (
            <div
              className="p-1.5 rounded-lg bg-[#222222] border border-[#333333] text-[10px] flex items-center justify-between cursor-pointer"
              onClick={onOpenApp}
            >
              <div className="flex items-center gap-1.5 truncate">
                <span>🍯</span>
                <span className="truncate text-[#E5C287] font-serif-hebrew font-bold" dir="rtl">{nextHoliday.nameHe}</span>
              </div>
              <span className="font-mono text-[#C5A267] font-bold shrink-0 ml-1">
                {nextHoliday.daysRemaining === 0 ? (isRtl ? 'היום' : 'Today') : `${nextHoliday.daysRemaining}d`}
              </span>
            </div>
          )}

          {nextZman && (
            <div
              className="p-1.5 rounded-lg bg-[#222222] border border-[#2A2A2A] text-[10px] flex items-center justify-between cursor-pointer"
              onClick={onOpenApp}
            >
              <div className="flex items-center gap-1.5 truncate">
                <span>⏳</span>
                <span className="truncate text-[#888888] font-serif-hebrew" dir="rtl">{nextZman.hebrewTitle}</span>
              </div>
              <span className="font-mono font-bold text-[#C5A267] shrink-0 ml-1">{nextZman.formattedTime}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

