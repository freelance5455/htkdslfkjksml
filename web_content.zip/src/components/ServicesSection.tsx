import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Laptop, 
  Terminal, 
  Video, 
  HardDrive, 
  Printer, 
  Network, 
  Clock, 
  Home, 
  ArrowRight,
  Wrench,
  CheckCircle2
} from 'lucide-react';
import { ServiceItem } from '../types';

export const ServicesSection: React.FC = () => {
  const { services, language, t, openServiceModal } = useApp();

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Laptop': return <Laptop className="w-6 h-6 text-blue-400" />;
      case 'Terminal': return <Terminal className="w-6 h-6 text-emerald-400" />;
      case 'Video': return <Video className="w-6 h-6 text-sky-400" />;
      case 'HardDrive': return <HardDrive className="w-6 h-6 text-purple-400" />;
      case 'Printer': return <Printer className="w-6 h-6 text-amber-400" />;
      case 'Network': return <Network className="w-6 h-6 text-indigo-400" />;
      default: return <Wrench className="w-6 h-6 text-blue-400" />;
    }
  };

  return (
    <section id="services" className="py-14 sm:py-16 bg-slate-950 border-b border-slate-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12 space-y-2.5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
            <Wrench className="w-3.5 h-3.5" />
            <span>{t.servicesSection.badge}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t.servicesSection.title}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
            {t.servicesSection.subtitle}
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((service: ServiceItem) => (
            <div
              key={service.id}
              className="p-5 sm:p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 shadow-md hover:shadow-blue-500/5 transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Icon & Home Service Tag */}
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 group-hover:border-blue-500/40 transition">
                    {getServiceIcon(service.icon)}
                  </div>
                  {service.homeServiceAvailable && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
                      <Home className="w-3 h-3" />
                      <span>{language === 'hi' ? 'घर बैठे सुविधा' : 'Home Service'}</span>
                    </span>
                  )}
                </div>

                <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-blue-400 transition mb-2">
                  {service.name[language] || service.name.en}
                </h3>

                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-4">
                  {service.description[language] || service.description.en}
                </p>
              </div>

              {/* Bottom Meta & Action */}
              <div className="pt-4 border-t border-slate-800/80 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-blue-400" />
                    <span>{service.estimatedTime[language] || service.estimatedTime.en}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 mr-1">{t.servicesSection.startingFrom}:</span>
                    <span className="font-bold text-white text-sm">₹{service.startingPrice}</span>
                  </div>
                </div>

                <button
                  onClick={() => openServiceModal(service)}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-blue-600 text-slate-200 hover:text-white font-semibold text-xs sm:text-sm transition flex items-center justify-center gap-2 group-hover:bg-blue-600 group-hover:text-white shadow-sm"
                >
                  <span>{t.servicesSection.bookNow}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
