import React from 'react';
import { Code2, PenTool, Box, MessageSquare, Cpu, Globe, Sparkles, Shield, ArrowRight } from 'lucide-react';
import { useData } from '../context/DataContext.tsx';
import { ServiceItem } from '../types/index.ts';

interface ServicesSectionProps {
  onSelectCategory: (category: string) => void;
}

const iconMap: Record<string, React.ElementType> = {
  Code2,
  PenTool,
  Box,
  MessageSquare,
  Cpu,
  Globe,
  Sparkles,
  Shield
};

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectCategory }) => {
  const { data } = useData();

  if (data.settings.sectionVisibility?.services === false) {
    return null;
  }

  const defaultServices: ServiceItem[] = [
    {
      id: 'web',
      name: 'Website Development',
      category: 'web',
      iconName: 'Code2',
      points: [
        'Modern, responsive websites.',
        'Custom web experiences and business websites.'
      ],
      displayOrder: 1,
      published: true
    },
    {
      id: 'design',
      name: 'Graphic Design',
      category: 'design',
      iconName: 'PenTool',
      points: [
        'Branding, graphics, social media assets.',
        'Creative design systems and visual collateral.'
      ],
      displayOrder: 2,
      published: true
    },
    {
      id: 'minecraft',
      name: 'Minecraft Development',
      category: 'minecraft',
      iconName: 'Box',
      points: [
        'Minecraft plugins and server systems.',
        'Custom architectures and player experiences.'
      ],
      displayOrder: 3,
      published: true
    },
    {
      id: 'discord',
      name: 'Discord Solutions',
      category: 'discord',
      iconName: 'MessageSquare',
      points: [
        'Discord bots and server automations.',
        'Setup services and community management tools.'
      ],
      displayOrder: 4,
      published: true
    }
  ];

  const sourceServices: ServiceItem[] = (data.services && data.services.length > 0)
    ? data.services
    : defaultServices;

  const activeServices = sourceServices
    .filter((s) => s.published !== false)
    .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));

  return (
    <section id="services" className="py-12 sm:py-16 max-w-[1120px] mx-auto px-4 sm:px-6">
      <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-14">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase bg-cyan-950/60 px-3.5 py-1 rounded-full border border-cyan-500/30">
          {data?.settings?.servicesEyebrow && data.settings.servicesEyebrow !== 'WHAT WE DO'
            ? data.settings.servicesEyebrow
            : 'OUR PROJECTS'}
        </span>
        <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-4 mb-4 font-['Plus_Jakarta_Sans']">
          {data.settings.servicesHeading || 'Four Ways to Build. One Cubix Studio.'}
        </h2>
        <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
          {data.settings.servicesDescription ||
            'Choose a category to explore the work behind Cubix Studio. Each card opens a dedicated projects page where the portfolio can grow over time.'}
        </p>
      </div>

      {/* Dynamic clickable service cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {activeServices.map((service) => {
          const Icon = (service.iconName && iconMap[service.iconName]) || Code2;
          const projectCount = data.projects.filter((p) => p.category === service.category || p.category === service.id).length;

          return (
            <button
              key={service.id}
              onClick={() => onSelectCategory(service.category || service.id)}
              className="p-6 rounded-2xl bg-gradient-to-b from-[#081528] to-[#040c17] border border-cyan-500/20 hover:border-cyan-400/50 text-left transition-all duration-200 hover:-translate-y-1 shadow-[0_10px_30px_rgba(0,0,0,0.4)] flex flex-col justify-between aspect-auto sm:aspect-square group cursor-pointer"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[11px] font-mono text-cyan-300/80 bg-cyan-950/40 px-2 py-0.5 rounded-md border border-cyan-500/20">
                    {projectCount} {projectCount === 1 ? 'Project' : 'Projects'}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors mb-2.5">
                  {service.name}
                </h3>

                {service.points && service.points.length > 0 && (
                  <ul className="space-y-1.5 text-xs text-slate-300/90 leading-relaxed">
                    {service.points.map((pt, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-cyan-400 font-bold">•</span>
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 group-hover:text-cyan-300 pt-4 border-t border-white/5 mt-4">
                <span>View projects</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
};
