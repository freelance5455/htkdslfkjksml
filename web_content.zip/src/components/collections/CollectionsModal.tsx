import React, { useState } from 'react';
import { Collection, Book } from '../../types';
import { CoverImage } from '../common/CoverImage';
import {
  Folder,
  Plus,
  Trash2,
  Edit2,
  X,
  BookOpen,
  Check,
} from 'lucide-react';

interface CollectionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  collections: Collection[];
  books: Book[];
  onSaveCollection: (col: Collection) => void;
  onDeleteCollection: (colId: string) => void;
  onToggleBookInCollection: (bookId: string, colId: string) => void;
  onOpenBookDetail: (book: Book) => void;
}

export const CollectionsModal: React.FC<CollectionsModalProps> = ({
  isOpen,
  onClose,
  collections,
  books,
  onSaveCollection,
  onDeleteCollection,
  onToggleBookInCollection,
  onOpenBookDetail,
}) => {
  if (!isOpen) return null;

  const [selectedColId, setSelectedColId] = useState<string>(collections[0]?.id || '');
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newColName, setNewColName] = useState('');
  const [newColDesc, setNewColDesc] = useState('');
  const [editingColId, setEditingColId] = useState<string | null>(null);
  const [editColName, setEditColName] = useState('');

  const activeCollection = collections.find((c) => c.id === selectedColId);
  const booksInActiveCol = activeCollection
    ? books.filter((b) => b.collections?.includes(activeCollection.id))
    : [];

  const handleCreateCollection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newColName.trim()) return;

    const newCol: Collection = {
      id: 'col-' + Date.now(),
      name: newColName.trim(),
      description: newColDesc.trim() || undefined,
      createdAt: new Date().toISOString(),
      color: '#71717a',
    };

    onSaveCollection(newCol);
    setSelectedColId(newCol.id);
    setNewColName('');
    setNewColDesc('');
    setIsCreatingNew(false);
  };

  const handleSaveEdit = (col: Collection) => {
    if (!editColName.trim()) return;
    onSaveCollection({ ...col, name: editColName.trim() });
    setEditingColId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div className="w-full max-w-3xl glass-panel rounded-3xl p-5 sm:p-8 border border-white/15 shadow-2xl flex flex-col justify-between max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-white/[0.06] border border-white/10 flex items-center justify-center text-zinc-300">
              <Folder className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white font-['Syne']">
                Colecciones Personalizadas
              </h2>
              <p className="text-xs text-slate-400">
                Organiza tus libros por temáticas, proyectos o antologías
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Collections Manager Body */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4 flex-1 overflow-hidden">
          {/* Left Column: Collection List */}
          <div className="space-y-3 border-r border-white/10 pr-0 md:pr-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Colecciones ({collections.length})
              </span>
              <button
                onClick={() => setIsCreatingNew(true)}
                className="p-1 rounded-lg bg-white/[0.05] hover:bg-white/15 text-white flex items-center gap-1 text-xs"
                title="Nueva colección"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Crear</span>
              </button>
            </div>

            {/* Create Collection Form */}
            {isCreatingNew && (
              <form onSubmit={handleCreateCollection} className="p-3 rounded-xl bg-white/[0.04] border border-white/20 space-y-2 animate-fadeIn">
                <input
                  type="text"
                  value={newColName}
                  onChange={(e) => setNewColName(e.target.value)}
                  placeholder="Nombre de la colección..."
                  required
                  className="w-full bg-slate-900 border border-white/15 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none"
                  autoFocus
                />
                <div className="flex items-center justify-end gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsCreatingNew(false)}
                    className="px-2.5 py-1 text-[11px] text-slate-400 hover:text-white"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-3 py-1 bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-[11px] rounded-lg"
                  >
                    Guardar
                  </button>
                </div>
              </form>
            )}

            {/* Collection Items */}
            <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
              {collections.map((col) => {
                const count = books.filter((b) => b.collections?.includes(col.id)).length;
                const isSelected = selectedColId === col.id;

                return (
                  <div
                    key={col.id}
                    onClick={() => setSelectedColId(col.id)}
                    className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-white/15 border-white/30 text-white shadow-sm'
                        : 'bg-white/[0.03] border-white/05 text-slate-300 hover:bg-white/[0.07]'
                    }`}
                  >
                    <div className="min-w-0 pr-2">
                      {editingColId === col.id ? (
                        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="text"
                            value={editColName}
                            onChange={(e) => setEditColName(e.target.value)}
                            className="bg-slate-900 border border-white/20 rounded px-1.5 py-0.5 text-xs text-white"
                            autoFocus
                          />
                          <button
                            onClick={() => handleSaveEdit(col)}
                            className="p-1 text-white hover:text-zinc-300"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <h4 className="text-xs font-semibold truncate">{col.name}</h4>
                          <span className="text-[10px] text-slate-400 block tabular-nums">
                            {count} {count === 1 ? 'libro' : 'libros'}
                          </span>
                        </>
                      )}
                    </div>

                    <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => {
                          setEditingColId(col.id);
                          setEditColName(col.name);
                        }}
                        className="p-1 hover:text-white text-slate-400 transition-colors"
                        title="Editar nombre"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => onDeleteCollection(col.id)}
                        className="p-1 hover:text-zinc-200 text-slate-400 transition-colors"
                        title="Eliminar colección (los libros no se eliminan)"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Books in Selected Collection */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-white">
                {activeCollection ? `Libros en "${activeCollection.name}"` : 'Selecciona una colección'}
              </span>
              <span className="text-xs text-slate-400">
                {booksInActiveCol.length} {booksInActiveCol.length === 1 ? 'libro' : 'libros'}
              </span>
            </div>

            {booksInActiveCol.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                Esta colección no tiene libros agregados todavía.
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-80 overflow-y-auto pr-1">
                {booksInActiveCol.map((b) => (
                  <div
                    key={b.id}
                    onClick={() => {
                      onClose();
                      onOpenBookDetail(b);
                    }}
                    className="glass-panel-subtle rounded-xl p-2.5 border border-white/10 hover:border-white/20 transition-all cursor-pointer group"
                  >
                    <CoverImage
                      url={b.coverUrl}
                      title={b.title}
                      author={b.author}
                      className="rounded-lg shadow-md"
                    />
                    <div className="mt-2">
                      <p className="text-xs font-semibold text-white truncate group-hover:text-zinc-200">
                        {b.title}
                      </p>
                      <p className="text-[10px] text-slate-400 truncate">{b.author}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
