import React, { useState, useEffect, useRef } from 'react';
import {
  Cloud,
  RefreshCw,
  LogOut,
  Mail,
  Trash2,
  Download,
  Image as ImageIcon,
  Film,
  FileText,
  AlertCircle,
  KeyRound,
  CheckCircle2,
  ShieldCheck,
  ArrowLeft,
} from 'lucide-react';
import {
  getUserSession,
  saveUserSession,
  getBackupState,
  saveBackupState,
  getLocalPhotos,
  getLocalVideos,
  getLocalNotes,
  saveLocalPhotos,
  saveLocalVideos,
  saveLocalNotes,
  getRecycleBin,
  saveRecycleBin,
  getMasterPin,
  setMasterPin,
  getVideoBlob,
  saveVideoBlob,
  blobToDataUrl,
  dataUrlToBlob,
  UserSession,
  CloudBackupState,
} from '../lib/storage';
import {
  supabase,
  BUCKET_NAME,
  sendSupabaseOtp,
  verifySupabaseOtp,
  checkEmailConfirmedStatus,
  backupToSupabase,
  restoreFromSupabase,
  getRealCloudStorageUsage,
  deleteFromCloudMedia,
  listRealCloudMediaFromStorage,
  SUPABASE_RLS_FIX_SQL,
  CloudStorageUsage,
} from '../lib/supabase';
import {
  openWhatsAppDirect,
  getWhatsAppHelpMessage,
  validateRealGmail,
} from '../lib/whatsapp';
import { DeleteConfirmModal } from './DeleteConfirmModal';
import { Toast } from './Toast';

interface LoginSettingProps {
  onBack: () => void;
  onOpenVault?: () => void;
  onGoHome?: () => void;
}

// Helper to clean and format username (strip numbers like 54, 63 etc)
export function formatCleanUsername(rawName?: string, email?: string): string {
  let source = (rawName || '').trim();
  if (!source && email) {
    source = email.split('@')[0] || '';
  }
  if (!source) return 'User';

  const lower = source.toLowerCase();
  if (lower.includes('saleemzakhme') || lower.includes('saleemzakhmi')) {
    return 'Saleem Zakhme';
  }

  // Remove numbers/digits (e.g. saleem54 -> saleem, ali63 -> ali)
  let clean = source.replace(/\d+/g, '');
  // Replace symbols/dots/underscores with spaces
  clean = clean.replace(/[._\-+]+/g, ' ').trim();

  if (!clean) return 'User';

  return clean
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

const PENDING_OTP_KEY = 'pending_otp_session_v1';

function getPendingOtpSession(): { email: string; otpSent: boolean } {
  try {
    const raw = localStorage.getItem(PENDING_OTP_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed?.otpSent && parsed?.email && Date.now() - (parsed.timestamp || 0) < 30 * 60 * 1000) {
        return { email: parsed.email, otpSent: true };
      }
    }
  } catch {}
  return { email: '', otpSent: false };
}

export const LoginSetting: React.FC<LoginSettingProps> = ({ onBack, onOpenVault, onGoHome }) => {
  const [session, setSession] = useState<UserSession>(getUserSession());
  const [backupState, setBackupState] = useState<CloudBackupState>(getBackupState());
  const [autoBackupEnabled, setAutoBackupEnabled] = useState<boolean>(backupState.autoBackup ?? false);
  const [lastBackupTime, setLastBackupTime] = useState<string>(backupState.lastBackupDate || 'Never');

  // Loading indicators
  const [isBackingUp, setIsBackingUp] = useState<boolean>(false);
  const [isRestoring, setIsRestoring] = useState<boolean>(false);
  const [isSendingOtp, setIsSendingOtp] = useState<boolean>(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState<boolean>(false);

  // Email confirmation state
  const [isEmailConfirmed, setIsEmailConfirmed] = useState<boolean>(true);

  // Cloud media viewer modal
  const [showCloudMedia, setShowCloudMedia] = useState<boolean>(false);
  const [cloudCategory, setCloudCategory] = useState<'photos' | 'videos' | 'notes'>('photos');
  const [cloudMediaData, setCloudMediaData] = useState<{ photos: any[]; videos: any[]; notes: any[] }>({
    photos: [],
    videos: [],
    notes: [],
  });

  // Real Supabase storage meter: 80 MB limit
  const [storageUsage, setStorageUsage] = useState<CloudStorageUsage>({
    usedBytes: 0,
    usedMB: '0.00',
    totalMB: '80.00',
    freeMB: '80.00',
    isFull: false,
    fileCount: 0,
    photosBytes: 0,
    photosMB: '0.00',
    photosMaxMB: '20.00',
    videosBytes: 0,
    videosMB: '0.00',
    videosMaxMB: '40.00',
    notesBytes: 0,
    notesMB: '0.00',
    notesMaxMB: '20.00',
    isPhotosFull: false,
    isVideosFull: false,
    isNotesFull: false,
  });

  const [hasWarnedFullOnce, setHasWarnedFullOnce] = useState<boolean>(false);

  // Supabase OTP Login States with persistence when user leaves to check Gmail
  const initialPending = getPendingOtpSession();
  const [showLoginForm, setShowLoginForm] = useState<boolean>(!session.isLoggedIn || initialPending.otpSent);
  const [loginEmail, setLoginEmail] = useState<string>(initialPending.email);
  const [loginOtpToken, setLoginOtpToken] = useState<string>('');
  const [otpSent, setOtpSent] = useState<boolean>(initialPending.otpSent);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [storageRlsNotice, setStorageRlsNotice] = useState<string | null>(null);
  const [backupProgress, setBackupProgress] = useState<{ percent: number; text: string } | null>(null);
  const [restoreProgress, setRestoreProgress] = useState<{ percent: number; text: string } | null>(null);
  const [showSqlModal, setShowSqlModal] = useState<boolean>(false);
  const [sqlCopied, setSqlCopied] = useState<boolean>(false);

  // 2-second Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Delete modal for Cloud Media items: exactly 2 buttons Cancel & Delete
  const [cloudDeleteModal, setCloudDeleteModal] = useState<{
    isOpen: boolean;
    type: 'photo' | 'video' | 'note';
    item: any;
    title?: string;
  }>({
    isOpen: false,
    type: 'photo',
    item: null,
  });

  const emailInputRef = useRef<HTMLInputElement>(null);
  const otpInputRef = useRef<HTMLInputElement>(null);
  const otpAutoVerifyTimerRef = useRef<any>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  // Check email confirmation status from Supabase
  const checkEmailConfirmation = async (email: string) => {
    if (!email) return;
    try {
      const confirmed = await checkEmailConfirmedStatus(email);
      setIsEmailConfirmed(confirmed);
    } catch {
      setIsEmailConfirmed(false);
    }
  };

  // Fetch real cloud storage meter from Supabase
  const refreshStorageMeter = async (email: string) => {
    if (!email) return;
    try {
      const usage = await getRealCloudStorageUsage(email);
      setStorageUsage(usage);
    } catch (err) {
      console.warn('Could not refresh storage meter:', err);
    }
  };

  // Initial load
  useEffect(() => {
    const curSession = getUserSession();
    setSession(curSession);
    const bState = getBackupState();
    setBackupState(bState);
    setAutoBackupEnabled(bState.autoBackup ?? false);
    setLastBackupTime(bState.lastBackupDate || 'Never');

    if (curSession.email) {
      refreshStorageMeter(curSession.email);
      checkEmailConfirmation(curSession.email);
    }
  }, []);

  // Auto focus OTP box when opened
  useEffect(() => {
    if (otpSent && otpInputRef.current) {
      otpInputRef.current.focus();
    }
  }, [otpSent]);

  // Auto Backup toggle quietly WITHOUT popup
  const handleToggleAutoBackup = async () => {
    const nextVal = !autoBackupEnabled;
    setAutoBackupEnabled(nextVal);
    const updated = {
      ...backupState,
      autoBackup: nextVal,
      backupOwnerEmail: session.email,
    };
    setBackupState(updated);
    saveBackupState(updated);

    // If turned ON and user is logged in with verified email, run automatic backup immediately!
    if (nextVal && session.email && isEmailConfirmed) {
      const p = getLocalPhotos();
      const v = getLocalVideos();
      const n = getLocalNotes();
      const r = getRecycleBin();
      const pin = getMasterPin();

      const videosWithPayload = await Promise.all(
        v.map(async (item) => {
          try {
            const blob = await getVideoBlob(item.id);
            if (blob) {
              const dataUrl = await blobToDataUrl(blob);
              return { ...item, url: dataUrl };
            }
          } catch {}
          return item;
        })
      );

      await backupToSupabase(session.email, {
        photos: p,
        videos: videosWithPayload,
        notes: n,
        recycleBin: r,
        calc_password: pin,
      });
      await refreshStorageMeter(session.email);
    }
  };

  // REAL Supabase Cloud Backup (80 MB limit enforced)
  const handleBackup = async () => {
    if (!session.email) {
      showToast('Pehle Gmail se login karein.');
      return;
    }

    if (!isEmailConfirmed) {
      showToast('Email par bheja gaya link verify karein');
      return;
    }

    // 80 MB storage check
    if (storageUsage.isFull) {
      if (!hasWarnedFullOnce) {
        setHasWarnedFullOnce(true);
        showToast('Your cloud storage is full (80 MB)');
      } else {
        showToast(
          'Your cloud storage is full (80 MB). If you want more storage, please contact the admin. Extra storage is paid.'
        );
      }
      return;
    }

    setIsBackingUp(true);
    setBackupProgress({ percent: 5, text: 'Preparing media files...' });
    try {
      const p = getLocalPhotos();
      const v = getLocalVideos();
      const n = getLocalNotes();
      const r = getRecycleBin();
      const pin = getMasterPin();

      // Read real video blobs from IndexedDB and bundle as data URLs for full cloud restore
      const videosWithPayload = await Promise.all(
        v.map(async (item) => {
          try {
            const blob = await getVideoBlob(item.id);
            if (blob) {
              const dataUrl = await blobToDataUrl(blob);
              return { ...item, url: dataUrl };
            }
          } catch {}
          return item;
        })
      );

      const res = await backupToSupabase(
        session.email,
        {
          photos: p,
          videos: videosWithPayload,
          notes: n,
          recycleBin: r,
          calc_password: pin,
        },
        (prog) => {
          setBackupProgress({ percent: prog.percent, text: prog.text });
        }
      );

      if (res.success) {
        if (res.timestamp) {
          setLastBackupTime(res.timestamp);
          const updated = {
            ...backupState,
            lastBackupDate: res.timestamp,
            backupOwnerEmail: session.email,
          };
          setBackupState(updated);
          saveBackupState(updated);
        }
        if ((res as any).storageRlsBlocked) {
          setStorageRlsNotice(res.message);
        } else {
          setStorageRlsNotice(null);
        }
        showToast(res.message);
        await refreshStorageMeter(session.email);
      } else {
        showToast(res.message);
      }
    } catch (err: any) {
      showToast(err.message || 'Backup failed');
    } finally {
      setIsBackingUp(false);
      setTimeout(() => setBackupProgress(null), 2000);
    }
  };

  // REAL Supabase Cloud Restore
  const handleRestore = async () => {
    if (!session.email) {
      showToast('Pehle Gmail se login karein.');
      return;
    }

    if (!isEmailConfirmed) {
      showToast('Email par bheja gaya link verify karein');
      return;
    }

    setIsRestoring(true);
    setRestoreProgress({ percent: 5, text: 'Connecting to Supabase...' });
    try {
      const res = await restoreFromSupabase(session.email, (prog) => {
        setRestoreProgress({ percent: prog.percent, text: prog.text });
      });
      if (res.success && res.data) {
        const d = res.data;
        if (Array.isArray(d.photos)) {
          saveLocalPhotos(d.photos);
        }
        if (Array.isArray(d.videos)) {
          saveLocalVideos(d.videos);
          // Restore video Blobs to IndexedDB for offline playing
          for (const vid of d.videos) {
            try {
              if (vid._downloadedBlob) {
                await saveVideoBlob(vid.id, vid._downloadedBlob);
              } else if (vid.url && vid.url.startsWith('data:')) {
                const blob = dataUrlToBlob(vid.url);
                await saveVideoBlob(vid.id, blob);
              }
            } catch (vErr) {
              console.warn('Video blob restore note:', vErr);
            }
          }
        }
        if (Array.isArray(d.notes)) {
          saveLocalNotes(d.notes);
        }
        if (Array.isArray(d.recycleBin)) {
          saveRecycleBin(d.recycleBin);
        }
        if (d.calc_password) {
          setMasterPin(d.calc_password);
        }
        if (d.backed_up_at) {
          const dateStr = new Date(d.backed_up_at).toLocaleString();
          setLastBackupTime(dateStr);
          const updated = {
            ...backupState,
            lastBackupDate: dateStr,
            backupOwnerEmail: session.email,
          };
          setBackupState(updated);
          saveBackupState(updated);
        }
        showToast('Cloud backup Supabase se kamyabi se bahal (restore) ho gaya!');
        await refreshStorageMeter(session.email);
      } else {
        showToast(res.message);
      }
    } catch (err: any) {
      showToast(err.message || 'Restore failed');
    } finally {
      setIsRestoring(false);
      setTimeout(() => setRestoreProgress(null), 2000);
    }
  };

  // Show Cloud Media - loads real Supabase Storage bucket data
  const handleOpenCloudMedia = async () => {
    setShowCloudMedia(true);
    if (!session.email) return;
    try {
      const res = await listRealCloudMediaFromStorage(session.email);
      setCloudMediaData({
        photos: res.photos || [],
        videos: res.videos || [],
        notes: res.notes || [],
      });
    } catch (err) {
      console.warn('Error loading cloud media:', err);
    }
  };

  // Delete item from real Supabase storage in "Show Cloud Media"
  const handleConfirmCloudDelete = async () => {
    if (!cloudDeleteModal.item || !session.email) return;
    const { type, item } = cloudDeleteModal;

    const res = await deleteFromCloudMedia(session.email, type, item.id, item.storagePath);
    if (res.success) {
      if (type === 'photo') {
        setCloudMediaData((prev) => ({
          ...prev,
          photos: prev.photos.filter((p) => p.id !== item.id),
        }));
      } else if (type === 'video') {
        setCloudMediaData((prev) => ({
          ...prev,
          videos: prev.videos.filter((v) => v.id !== item.id),
        }));
      } else if (type === 'note') {
        setCloudMediaData((prev) => ({
          ...prev,
          notes: prev.notes.filter((n) => n.id !== item.id),
        }));
      }
      showToast('Item deleted from Cloud Storage');
      await refreshStorageMeter(session.email);
    } else {
      showToast(res.message);
    }
    setCloudDeleteModal({ isOpen: false, type: 'photo', item: null });
  };

  // Download single real file from Supabase Storage
  const handleDownloadCloudItem = async (item: any) => {
    try {
      showToast(`Downloading ${item.name || 'file'}...`);
      let blob: Blob | null = null;
      if (item.storagePath) {
        const { data: b, error } = await supabase.storage.from(BUCKET_NAME).download(item.storagePath);
        if (!error && b) blob = b;
      }
      if (!blob && item.url) {
        if (item.url.startsWith('data:')) {
          blob = dataUrlToBlob(item.url);
        } else {
          const res = await fetch(item.url);
          blob = await res.blob();
        }
      }
      if (blob) {
        const downloadUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = item.name || 'cloud_file';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(downloadUrl);
        showToast(`${item.name || 'File'} downloaded!`);
      } else {
        showToast('Download failed from Supabase');
      }
    } catch (err: any) {
      showToast('Download failed: ' + (err.message || 'error'));
    }
  };

  // Send OTP with strict validation BEFORE calling supabase.auth
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const email = loginEmail.trim().toLowerCase();

    // Strict validation: ...@gmail.com and blocks test, fake, abc, asdf, temp, 123, xyz
    const emailValidation = validateRealGmail(email);
    if (!emailValidation.valid) {
      const errMsg = emailValidation.error || 'Nakli ya Ghalat Email! Apna Asli Gmail likhen';
      setLoginError(errMsg);
      showToast(errMsg);
      return;
    }

    setIsSendingOtp(true);
    try {
      const res = await sendSupabaseOtp(email);
      if (res.success) {
        setOtpSent(true);
        localStorage.setItem(
          PENDING_OTP_KEY,
          JSON.stringify({
            email,
            otpSent: true,
            timestamp: Date.now(),
          })
        );
        showToast(res.message);
      } else {
        setLoginError(res.message);
        showToast(res.message);
      }
    } catch (err: any) {
      setLoginError(err.message || 'OTP send failed');
    } finally {
      setIsSendingOtp(false);
    }
  };

  // Verify OTP Token from Gmail
  const triggerVerifyWithToken = async (tokenToVerify: string) => {
    const email = loginEmail.trim().toLowerCase();
    const token = tokenToVerify.trim();

    if (!token) return;

    setIsVerifyingOtp(true);
    setLoginError(null);
    try {
      const res = await verifySupabaseOtp(email, token);
      if (res.success) {
        localStorage.removeItem(PENDING_OTP_KEY);
        const isConfirmed = res.emailConfirmed ?? true;
        setIsEmailConfirmed(isConfirmed);

        const cleanUsername = formatCleanUsername('', email);
        const newSession: UserSession = {
          isLoggedIn: true,
          username: cleanUsername,
          email,
          connected: true,
          loginMethod: 'supabase-otp',
        };
        saveUserSession(newSession);
        setSession(newSession);
        setShowLoginForm(false);
        setOtpSent(false);

        if (!isConfirmed) {
          showToast('Email par bheja gaya link verify karein');
        } else {
          showToast('Login successful!');
          // REAL automatic restore right after login
          restoreFromSupabase(email).then(async (restoreRes) => {
            if (restoreRes?.data) {
              const d = restoreRes.data;
              if (Array.isArray(d.photos)) saveLocalPhotos(d.photos);
              if (Array.isArray(d.videos)) {
                saveLocalVideos(d.videos);
                for (const vid of d.videos) {
                  try {
                    if (vid.url && vid.url.startsWith('data:')) {
                      const blob = dataUrlToBlob(vid.url);
                      await saveVideoBlob(vid.id, blob);
                    }
                  } catch {}
                }
              }
              if (Array.isArray(d.notes)) saveLocalNotes(d.notes);
              if (Array.isArray(d.recycleBin)) saveRecycleBin(d.recycleBin);
              if (d.calc_password) setMasterPin(d.calc_password);
              if (d.backed_up_at) {
                const dateStr = new Date(d.backed_up_at).toLocaleString();
                setLastBackupTime(dateStr);
                const updated = {
                  ...backupState,
                  lastBackupDate: dateStr,
                  backupOwnerEmail: email,
                };
                setBackupState(updated);
                saveBackupState(updated);
              }
            }
            refreshStorageMeter(email);
          });
        }

        // Navigate to Home screen!
        setTimeout(() => {
          if (onGoHome) {
            onGoHome();
          } else {
            onBack();
          }
        }, 600);
      } else {
        setLoginError(res.message);
      }
    } catch (err: any) {
      setLoginError(err.message || 'OTP verification failed');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginOtpToken.trim()) {
      setLoginError('OTP code darj karein!');
      showToast('OTP code darj karein!');
      return;
    }
    await triggerVerifyWithToken(loginOtpToken);
  };

  const handleOtpInputChange = (val: string) => {
    // If copied text from Gmail has spaces or text like "123 456" or "Code: 842913"
    const sixDigitMatch = val.match(/\b\d{6}\b/) || val.match(/\d{6}/);
    const clean = sixDigitMatch ? sixDigitMatch[0] : val.replace(/[^0-9a-zA-Z]/g, '').slice(0, 6);
    setLoginOtpToken(clean);
    setLoginError(null);

    if (otpAutoVerifyTimerRef.current) {
      clearTimeout(otpAutoVerifyTimerRef.current);
      otpAutoVerifyTimerRef.current = null;
    }

    // Automatically trigger verification when user finishes typing or pasting 6-digit OTP
    if (clean.length === 6) {
      otpAutoVerifyTimerRef.current = setTimeout(() => {
        triggerVerifyWithToken(clean);
      }, 250);
    } else if (clean.length === 4) {
      // Keep support for 4-digit codes just in case
      otpAutoVerifyTimerRef.current = setTimeout(() => {
        triggerVerifyWithToken(clean);
      }, 400);
    }
  };

  const handleSignOut = () => {
    localStorage.removeItem(PENDING_OTP_KEY);
    const emptySession: UserSession = {
      isLoggedIn: false,
      username: '',
      email: '',
      connected: false,
    };
    saveUserSession(emptySession);
    setSession(emptySession);
    localStorage.removeItem('current_user_email');
    setLoginEmail('');
    setLoginOtpToken('');
    setOtpSent(false);
    setShowLoginForm(false);
    showToast('Signed out successfully');
  };

  // Percentage for storage meter (out of 80 MB)
  const percentUsed = Math.min(
    100,
    Math.max(storageUsage.usedBytes > 0 ? 1.5 : 0.5, (storageUsage.usedBytes / (80 * 1024 * 1024)) * 100)
  );

  return (
    <div className="w-full h-full max-w-xl mx-auto flex flex-col justify-between px-4 sm:px-6 py-4 select-none bg-[#0c1422] text-white relative overflow-y-auto">
      {/* 2-Second Toast */}
      <Toast message={toastMessage} onClose={() => setToastMessage(null)} />

      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 pt-1 shrink-0">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">Calculator Pro</h1>
          <p className="text-xs sm:text-sm text-slate-400 font-normal mt-0.5">Login & Cloud Backup</p>
        </div>
        <button
          onClick={onBack}
          className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-4 py-1.5 rounded-xl text-sm transition shadow-md cursor-pointer"
        >
          Back
        </button>
      </div>

      {session.isLoggedIn ? (
        /* Logged In View */
        <div className="flex-1 flex flex-col justify-start space-y-3 pb-2 animate-in fade-in">
          {/* User Account Card */}
          <div className="bg-[#152033] border border-[#24354f] rounded-2xl p-4 shadow-xl space-y-3">
            <div>
              <div className="flex items-center justify-between">
                <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                  {formatCleanUsername(session.username, session.email)}
                </h2>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 font-mono">{session.email}</p>
            </div>

            {/* Unverified email warning */}
            {!isEmailConfirmed && (
              <div className="bg-amber-950/80 border border-amber-500 text-amber-200 text-xs px-3.5 py-2.5 rounded-xl flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="font-semibold">Email par bheja gaya link verify karein (Backup & Restore band hai)</span>
              </div>
            )}

            {/* Storage RLS notice if bucket blocked file upload */}
            {storageRlsNotice && (
              <div className="bg-amber-950/80 border border-amber-500/80 rounded-xl p-3 text-xs text-amber-200 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <span className="font-bold flex items-center gap-1.5 text-amber-300">
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                    Supabase Storage Notice
                  </span>
                  <button
                    type="button"
                    onClick={() => setStorageRlsNotice(null)}
                    className="text-amber-400 hover:text-white text-xs font-bold px-1"
                  >
                    ✕
                  </button>
                </div>
                <p className="text-[11px] leading-relaxed text-amber-200">
                  Data database (sl_backups) mein mahfooz ho gaya hai! Supabase Storage &apos;sl-calculator&apos; bucket mein files dekhne ke liye:
                </p>
                <div className="bg-[#080d16] p-2 rounded-lg border border-amber-800/60 font-mono text-[10px] text-amber-300 leading-normal">
                  1. Supabase Dashboard &gt; Storage &gt; Buckets<br />
                  2. sl-calculator ke 3 dots (...) &gt; Edit bucket<br />
                  3. <b>&quot;Public bucket&quot; ko ON karein</b> &gt; Save
                </div>
              </div>
            )}

            <div className="border-t border-[#24354f]" />

            {/* Auto Backup Toggle (Quiet, NO popup) */}
            <div className="flex items-center justify-between py-0.5">
              <div className="pr-3">
                <div className="text-sm font-semibold text-white">Auto Backup</div>
                <div className="text-[11px] text-slate-400 leading-snug">
                  Data save/change hone par automatic Supabase backup (80 MB limit).
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={autoBackupEnabled}
                onClick={handleToggleAutoBackup}
                className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  autoBackupEnabled ? 'bg-[#16a34a]' : 'bg-slate-600'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                    autoBackupEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="border-t border-[#24354f]" />

            {/* Last backup time (Real cloud upload time) */}
            <div className="flex items-center justify-between py-0.5">
              <div>
                <span className="text-[11px] text-slate-400 font-medium block">Last Backup</span>
                <span className="text-xs sm:text-sm font-bold text-white tracking-wide mt-0.5 block font-sans">
                  {lastBackupTime}
                </span>
              </div>
            </div>

            <div className="border-t border-[#24354f]" />

            {/* Real 80 MB Storage Meter */}
            <div className="space-y-1.5 pt-0.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium flex items-center gap-1.5">
                  <Cloud className="w-3.5 h-3.5 text-sky-400" />
                  <span>Cloud Storage</span>
                </span>
                {/* Exact display e.g. 12.45 MB / 80 MB */}
                <span className="font-semibold text-slate-200 text-xs font-mono">
                  {storageUsage.usedMB} MB <span className="text-slate-400 font-normal">/ {storageUsage.totalMB} MB</span>
                </span>
              </div>

              {/* Visual meter bar */}
              <div className="w-full h-2.5 bg-[#0c1422] rounded-full overflow-hidden border border-[#2b3e5e]">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    storageUsage.isFull
                      ? 'bg-red-500'
                      : 'bg-gradient-to-r from-blue-500 via-sky-400 to-emerald-400'
                  }`}
                  style={{ width: `${percentUsed}%` }}
                />
              </div>

              {/* Free space display e.g. 67.55 MB free space */}
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>
                  Free Space: <b className="text-emerald-400 font-semibold">{storageUsage.freeMB} MB free space</b>
                </span>
                <button
                  type="button"
                  onClick={() => refreshStorageMeter(session.email)}
                  className="text-sky-400 hover:text-sky-300 font-semibold text-[10px] flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Refresh</span>
                </button>
              </div>

              {/* Category Breakdown: Photos max 20 MB, Videos max 40 MB, Notes max 20 MB */}
              <div className="grid grid-cols-3 gap-1.5 pt-1">
                <div className="bg-[#0c1422] p-2 rounded-xl border border-[#23354d] text-center">
                  <span className="text-[10px] text-amber-400 block font-semibold">Photos</span>
                  <span className="text-[11px] text-slate-100 font-mono font-bold block">{storageUsage.photosMB || '0.00'} MB</span>
                  <span className="text-[9px] text-slate-400 block">max 20 MB</span>
                </div>
                <div className="bg-[#0c1422] p-2 rounded-xl border border-[#23354d] text-center">
                  <span className="text-[10px] text-cyan-400 block font-semibold">Videos</span>
                  <span className="text-[11px] text-slate-100 font-mono font-bold block">{storageUsage.videosMB || '0.00'} MB</span>
                  <span className="text-[9px] text-slate-400 block">max 40 MB</span>
                </div>
                <div className="bg-[#0c1422] p-2 rounded-xl border border-[#23354d] text-center">
                  <span className="text-[10px] text-emerald-400 block font-semibold">Notes</span>
                  <span className="text-[11px] text-slate-100 font-mono font-bold block">{storageUsage.notesMB || '0.00'} MB</span>
                  <span className="text-[9px] text-slate-400 block">max 20 MB</span>
                </div>
              </div>

              {/* Warning if 80 MB full or category full */}
              {storageUsage.isFull ? (
                <div className="mt-2 bg-red-950/80 border border-red-500 text-red-200 text-xs px-3 py-2 rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span className="font-semibold">Your cloud storage is full (80 MB)</span>
                </div>
              ) : storageUsage.isPhotosFull ? (
                <div className="mt-2 bg-amber-950/80 border border-amber-500 text-amber-200 text-xs px-3 py-1.5 rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="font-semibold">Photos storage limit (20 MB) full</span>
                </div>
              ) : storageUsage.isVideosFull ? (
                <div className="mt-2 bg-cyan-950/80 border border-cyan-500 text-cyan-200 text-xs px-3 py-1.5 rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span className="font-semibold">Videos storage limit (40 MB) full</span>
                </div>
              ) : storageUsage.isNotesFull ? (
                <div className="mt-2 bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-xs px-3 py-1.5 rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="font-semibold">Notes storage limit (20 MB) full</span>
                </div>
              ) : null}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-1">
            {/* Show Cloud Media Button */}
            <button
              onClick={handleOpenCloudMedia}
              className="w-full h-11 sm:h-12 bg-[#f97316] hover:bg-[#ea580c] active:scale-[0.99] text-white font-bold rounded-xl text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Cloud className="w-4 h-4" />
              <span>Show Cloud Media</span>
            </button>

            {/* Backup Button: Disabled when email not confirmed! */}
            <div className="space-y-1">
              <button
                onClick={handleBackup}
                disabled={isBackingUp || !isEmailConfirmed}
                className={`w-full h-11 sm:h-12 text-white font-bold rounded-xl text-sm shadow-md transition flex flex-col items-center justify-center cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                  !isEmailConfirmed
                    ? 'bg-slate-700'
                    : 'bg-[#16a34a] hover:bg-[#15803d] active:scale-[0.99]'
                }`}
                title={!isEmailConfirmed ? 'Email par bheja gaya link verify karein' : 'Backup to Supabase'}
              >
                {isBackingUp ? (
                  <div className="flex items-center gap-2 text-xs">
                    <RefreshCw className="w-4 h-4 animate-spin shrink-0" />
                    <span>{backupProgress ? backupProgress.text : 'Backing up to Supabase...'}</span>
                  </div>
                ) : (
                  <span>Backup</span>
                )}
              </button>
              {isBackingUp && backupProgress && (
                <div className="w-full bg-[#0a1b12] h-1.5 rounded-full overflow-hidden border border-emerald-500/40">
                  <div
                    className="bg-emerald-400 h-full transition-all duration-300"
                    style={{ width: `${backupProgress.percent}%` }}
                  />
                </div>
              )}
            </div>

            {/* Restore Button: Disabled when email not confirmed! */}
            <div className="space-y-1">
              <button
                onClick={handleRestore}
                disabled={isRestoring || !isEmailConfirmed}
                className={`w-full h-11 sm:h-12 text-white font-bold rounded-xl text-sm shadow-md transition flex flex-col items-center justify-center cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                  !isEmailConfirmed
                    ? 'bg-slate-700'
                    : 'bg-[#0284c7] hover:bg-[#0369a1] active:scale-[0.99]'
                }`}
                title={!isEmailConfirmed ? 'Email par bheja gaya link verify karein' : 'Restore from Supabase'}
              >
                {isRestoring ? (
                  <div className="flex items-center gap-2 text-xs">
                    <RefreshCw className="w-4 h-4 animate-spin shrink-0" />
                    <span>{restoreProgress ? restoreProgress.text : 'Restoring Media...'}</span>
                  </div>
                ) : (
                  <span>Restore</span>
                )}
              </button>
              {isRestoring && restoreProgress && (
                <div className="w-full bg-[#081b2c] h-1.5 rounded-full overflow-hidden border border-sky-500/40">
                  <div
                    className="bg-sky-400 h-full transition-all duration-300"
                    style={{ width: `${restoreProgress.percent}%` }}
                  />
                </div>
              )}
            </div>

            {/* Sign Out Button */}
            <button
              onClick={handleSignOut}
              className="w-full h-11 sm:h-12 bg-[#ef4444] hover:bg-[#dc2626] active:scale-[0.99] text-white font-bold rounded-xl text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      ) : (
        /* Logged Out / Supabase OTP Login View */
        <div className="flex-1 flex flex-col justify-start">
          {showLoginForm ? (
            <div className="space-y-4 animate-in fade-in zoom-in-95 duration-150">
              {!otpSent ? (
                /* Step 1: Enter Gmail and search/send OTP */
                <div className="bg-[#152033] border border-[#24354f] rounded-2xl p-5 shadow-2xl relative space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-[#24354f]">
                    <div className="flex items-center gap-2 text-cyan-400">
                      <Mail className="w-5 h-5 text-sky-400" />
                      <span className="font-bold text-base text-white">Gmail Login (OTP)</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        localStorage.removeItem(PENDING_OTP_KEY);
                        setShowLoginForm(false);
                        setLoginError(null);
                      }}
                      className="text-slate-400 hover:text-white p-1 cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>

                  <form onSubmit={handleSendOtp} className="space-y-3.5">
                    <div>
                      <label className="text-xs text-slate-300 font-semibold block mb-1.5">
                        Apna Asli Gmail Darj Karein:
                      </label>
                      <input
                        ref={emailInputRef}
                        type="email"
                        value={loginEmail}
                        onChange={(e) => {
                          setLoginEmail(e.target.value);
                          setLoginError(null);
                        }}
                        placeholder="example@gmail.com"
                        autoComplete="email"
                        autoFocus
                        className="w-full h-12 px-4 bg-[#0d1624] border border-[#2a3c57] focus:border-[#3b82f6] rounded-xl text-white text-sm placeholder-slate-500 outline-none transition font-sans"
                      />
                      <p className="text-[11px] text-slate-400 mt-1.5 pl-1 leading-snug">
                        Sirf asli Gmail (@gmail.com) manzoor hai. Nakli emails block hain.
                      </p>
                    </div>

                    {loginError && (
                      <div className="bg-red-950/60 border border-red-500/80 p-2.5 rounded-xl flex items-center gap-2 text-xs text-red-300 font-medium animate-in fade-in">
                        <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                        <span>{loginError}</span>
                      </div>
                    )}

                    <div className="flex items-center gap-2.5 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          localStorage.removeItem(PENDING_OTP_KEY);
                          setShowLoginForm(false);
                          setLoginError(null);
                        }}
                        className="w-1/3 h-12 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-sm transition cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isSendingOtp}
                        className="flex-1 h-12 bg-[#1c74e9] hover:bg-[#1563ca] active:scale-[0.98] text-white font-bold rounded-xl text-sm transition shadow-lg flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
                      >
                        {isSendingOtp ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            <span>Searching & Sending OTP...</span>
                          </>
                        ) : (
                          <>
                            <KeyRound className="w-4 h-4" />
                            <span>Send OTP to Gmail</span>
                          </>
                        )}
                      </button>
                    </div>
                  </form>
                </div>
              ) : (
                /* Step 2: Dedicated "Verification Your OTP" Box as requested! */
                <div className="bg-[#152033] border-2 border-emerald-500/80 rounded-2xl p-5 sm:p-6 shadow-2xl relative space-y-4 animate-in zoom-in-95 duration-200">
                  {/* Dedicated Header: Verification Your OTP */}
                  <div className="text-center space-y-1.5 pb-2 border-b border-[#24354f]">
                    <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto mb-1 shadow-md shadow-emerald-500/20">
                      <ShieldCheck className="w-7 h-7" />
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-white tracking-wide">
                      Verification Your OTP
                    </h3>
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0d1624] border border-[#2a3c57] text-xs font-mono text-emerald-300 max-w-full truncate">
                      <Mail className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span className="truncate">{loginEmail}</span>
                    </div>
                  </div>

                  {/* Message requested by user:
                      "aapki email mein OTP receive ho chuki hai vah OTP ko Yahan dalen" */}
                  <div className="bg-[#0c1422] p-3.5 rounded-xl border border-emerald-800/40 text-xs text-slate-200 leading-relaxed text-center font-medium">
                    <p className="text-emerald-400 font-bold mb-0.5">
                      Aapki email mein OTP receive ho chuki hai!
                    </p>
                    <p className="text-slate-300">
                      Wo OTP yahan darj karein taake login successful ho sake.
                    </p>
                  </div>

                  <form onSubmit={handleVerifyOtp} className="space-y-4">
                    <div>
                      <label className="text-xs text-slate-300 font-semibold block text-center mb-2">
                        Enter 6-Digit OTP Code (e.g. 842913):
                      </label>
                      <input
                        ref={otpInputRef}
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        maxLength={6}
                        value={loginOtpToken}
                        onChange={(e) => handleOtpInputChange(e.target.value)}
                        onPaste={(e) => {
                          e.preventDefault();
                          const pasted = e.clipboardData.getData('text');
                          handleOtpInputChange(pasted);
                        }}
                        placeholder="• • • • • •"
                        autoFocus
                        className="w-full h-14 px-4 bg-[#0d1624] border-2 border-emerald-500/60 focus:border-emerald-400 rounded-xl text-white text-2xl font-bold tracking-[0.5em] font-mono placeholder-slate-600 outline-none transition text-center shadow-inner"
                      />
                    </div>

                    {loginError && (
                      <div className="bg-red-950/60 border border-red-500/80 p-2.5 rounded-xl flex items-center justify-center gap-2 text-xs text-red-300 font-medium animate-in fade-in text-center">
                        <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                        <span>{loginError}</span>
                      </div>
                    )}

                    <div className="flex flex-col gap-2.5 pt-1">
                      <button
                        type="submit"
                        disabled={isVerifyingOtp}
                        className="w-full h-13 bg-[#16a34a] hover:bg-[#15803d] active:scale-[0.98] text-white font-bold rounded-xl text-base transition shadow-lg shadow-green-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
                      >
                        {isVerifyingOtp ? (
                          <>
                            <RefreshCw className="w-5 h-5 animate-spin" />
                            <span>Verifying OTP...</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-5 h-5" />
                            <span>Verify & Login Successful</span>
                          </>
                        )}
                      </button>

                      <div className="flex items-center justify-between pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            localStorage.removeItem(PENDING_OTP_KEY);
                            setOtpSent(false);
                            setLoginOtpToken('');
                            setLoginError(null);
                          }}
                          className="text-xs text-sky-400 hover:text-sky-300 font-semibold flex items-center gap-1 cursor-pointer py-1"
                        >
                          <ArrowLeft className="w-3.5 h-3.5" />
                          <span>Change Gmail</span>
                        </button>

                        <button
                          type="button"
                          disabled={isSendingOtp}
                          onClick={handleSendOtp}
                          className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 cursor-pointer py-1 disabled:opacity-60"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${isSendingOtp ? 'animate-spin' : ''}`} />
                          <span>Resend OTP</span>
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-[#152033]/80 border border-[#24354f] rounded-2xl p-4 sm:p-5 shadow-2xl">
              <button
                type="button"
                onClick={() => {
                  setShowLoginForm(true);
                  setLoginError(null);
                }}
                className="w-full h-14 bg-[#1c74e9] hover:bg-[#1563ca] active:scale-[0.98] text-white font-bold rounded-2xl text-base shadow-lg transition flex items-center justify-center gap-2.5 cursor-pointer"
              >
                <Mail className="w-5 h-5 text-white" />
                <span className="tracking-wide">Login with Gmail (OTP)</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Show Cloud Media Modal */}
      {showCloudMedia && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none"
          onClick={() => setShowCloudMedia(false)}
        >
          <div
            className="bg-[#152033] border border-[#2b3e5e] w-full max-w-lg rounded-2xl p-4 sm:p-5 shadow-2xl space-y-3 max-h-[88vh] flex flex-col text-white animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Bar */}
            <div className="flex items-center justify-between border-b border-[#24354f] pb-3">
              <div className="flex items-center gap-2 text-amber-400">
                <Cloud className="w-6 h-6" />
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white">Supabase Cloud Media</h3>
                  <p className="text-xs text-slate-400">
                    Storage: {storageUsage.usedMB} MB / {storageUsage.totalMB} MB ({storageUsage.freeMB} MB free)
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowCloudMedia(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Category Tabs */}
            <div className="flex gap-2 border-b border-[#24354f] pb-2">
              <button
                onClick={() => setCloudCategory('photos')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  cloudCategory === 'photos'
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-[#0c1422] text-slate-300 hover:bg-[#1a283e]'
                }`}
              >
                <ImageIcon className="w-4 h-4" />
                <span>Photos ({cloudMediaData.photos.length})</span>
              </button>
              <button
                onClick={() => setCloudCategory('videos')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  cloudCategory === 'videos'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'bg-[#0c1422] text-slate-300 hover:bg-[#1a283e]'
                }`}
              >
                <Film className="w-4 h-4" />
                <span>Videos ({cloudMediaData.videos.length})</span>
              </button>
              <button
                onClick={() => setCloudCategory('notes')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  cloudCategory === 'notes'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-[#0c1422] text-slate-300 hover:bg-[#1a283e]'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>Notes ({cloudMediaData.notes.length})</span>
              </button>
            </div>

            {/* Items List (Square compact 2 columns side-by-side) */}
            <div className="flex-1 overflow-y-auto py-2">
              {cloudCategory === 'photos' && (
                <div>
                  {cloudMediaData.photos.length === 0 ? (
                    <p className="text-center text-xs text-slate-400 py-8">No photos in Supabase Cloud.</p>
                  ) : (
                    <div className="grid grid-cols-2 gap-2.5">
                      {cloudMediaData.photos.map((item) => (
                        <div
                          key={item.id}
                          className="aspect-square rounded-xl overflow-hidden bg-slate-900 border border-[#23354d] relative group"
                        >
                          <img src={item.url} alt={item.name} className="w-full h-full object-cover" />
                          <button
                            type="button"
                            title="Download file from Supabase"
                            onClick={() => handleDownloadCloudItem(item)}
                            className="absolute top-1.5 left-1.5 w-7 h-7 bg-sky-600 hover:bg-sky-500 active:scale-90 text-white rounded-lg flex items-center justify-center shadow-md transition cursor-pointer z-10"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            title="Delete from Supabase Cloud"
                            onClick={() =>
                              setCloudDeleteModal({
                                isOpen: true,
                                type: 'photo',
                                item,
                                title: item.name,
                              })
                            }
                            className="absolute top-1.5 right-1.5 w-7 h-7 bg-red-600 hover:bg-red-500 active:scale-90 text-white rounded-lg flex items-center justify-center shadow-md transition cursor-pointer z-10"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          <div className="absolute inset-x-0 bottom-0 bg-black/75 p-1 text-[10px] truncate text-slate-200">
                            {item.name}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {cloudCategory === 'videos' && (
                <div>
                  {cloudMediaData.videos.length === 0 ? (
                    <p className="text-center text-xs text-slate-400 py-8">No videos in Supabase Cloud.</p>
                  ) : (
                    <div className="grid grid-cols-2 gap-2.5">
                      {cloudMediaData.videos.map((item) => (
                        <div
                          key={item.id}
                          className="aspect-square rounded-xl overflow-hidden bg-slate-900 border border-[#23354d] relative group"
                        >
                          <video
                            src={`${item.url}#t=0.1`}
                            preload="metadata"
                            className="w-full h-full object-cover"
                          />
                          <button
                            type="button"
                            title="Download video from Supabase"
                            onClick={() => handleDownloadCloudItem(item)}
                            className="absolute top-1.5 left-1.5 w-7 h-7 bg-sky-600 hover:bg-sky-500 active:scale-90 text-white rounded-lg flex items-center justify-center shadow-md transition cursor-pointer z-10"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            title="Delete from Supabase Cloud"
                            onClick={() =>
                              setCloudDeleteModal({
                                isOpen: true,
                                type: 'video',
                                item,
                                title: item.name,
                              })
                            }
                            className="absolute top-1.5 right-1.5 w-7 h-7 bg-red-600 hover:bg-red-500 active:scale-90 text-white rounded-lg flex items-center justify-center shadow-md transition cursor-pointer z-10"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          <div className="absolute inset-x-0 bottom-0 bg-black/75 p-1 text-[10px] truncate text-slate-200">
                            {item.name}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {cloudCategory === 'notes' && (
                <div className="grid grid-cols-2 gap-2.5">
                  {cloudMediaData.notes.length === 0 ? (
                    <p className="col-span-2 text-center text-xs text-slate-400 py-8">No notes in Supabase Cloud.</p>
                  ) : (
                    cloudMediaData.notes.map((item) => (
                      <div
                        key={item.id}
                        className="p-3 bg-[#0c1422] border border-[#23354d] rounded-xl flex flex-col justify-between relative group min-h-[110px]"
                      >
                        <div className="flex-1 min-w-0 pr-6">
                          <h4 className="text-xs font-bold text-emerald-400 truncate">{item.title}</h4>
                          <p className="text-xs text-slate-300 mt-1 line-clamp-2">{item.content}</p>
                        </div>
                        <span className="text-[10px] text-slate-500 mt-1 block">{item.date}</span>
                        <button
                          type="button"
                          title="Delete from Supabase Cloud"
                          onClick={() =>
                            setCloudDeleteModal({
                              isOpen: true,
                              type: 'note',
                              item,
                              title: item.title,
                            })
                          }
                          className="absolute top-2 right-2 w-6 h-6 bg-red-600/30 hover:bg-red-600 active:scale-95 text-red-400 hover:text-white rounded-md flex items-center justify-center transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation for Cloud Media */}
      <DeleteConfirmModal
        isOpen={cloudDeleteModal.isOpen}
        title={cloudDeleteModal.title}
        isPermanent={true}
        onCancel={() => setCloudDeleteModal({ isOpen: false, type: 'photo', item: null })}
        onConfirm={handleConfirmCloudDelete}
      />

      {/* Supabase SQL Editor Fix Modal */}
      {showSqlModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 animate-fade-in">
          <div className="bg-[#0f172a] border border-[#2b3e5e] rounded-2xl w-full max-w-lg p-4 space-y-3 max-h-[88vh] flex flex-col shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#24354f] pb-2.5">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-sky-400" />
                <h3 className="text-sm font-bold text-white">Supabase SQL Editor Fix</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSqlModal(false)}
                className="text-slate-400 hover:text-white text-base font-bold px-1.5 py-0.5 rounded cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              Run this complete SQL script in your <b>Supabase Dashboard &gt; SQL Editor &gt; New query</b> to fix RLS permissions for bucket <code className="text-sky-300 font-mono">sl-calculator</code> and table <code className="text-amber-300 font-mono">sl_backups</code>:
            </p>

            <div className="bg-[#080d16] border border-[#1e293b] rounded-xl p-3 overflow-y-auto flex-1 font-mono text-[10px] text-slate-300 select-all whitespace-pre leading-relaxed max-h-[45vh]">
              {SUPABASE_RLS_FIX_SQL}
            </div>

            <div className="flex items-center gap-2 pt-1 border-t border-[#24354f]">
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(SUPABASE_RLS_FIX_SQL);
                  setSqlCopied(true);
                  showToast('SQL Code Copied to Clipboard!');
                  setTimeout(() => setSqlCopied(false), 2500);
                }}
                className="flex-1 h-10 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.99] text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{sqlCopied ? 'SQL Copied to Clipboard!' : 'Copy SQL Code'}</span>
              </button>
              <button
                type="button"
                onClick={() => setShowSqlModal(false)}
                className="h-10 px-4 bg-slate-700 hover:bg-slate-600 text-slate-200 font-semibold rounded-xl text-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
