import React, { useState, useRef, useEffect } from "react";
import {
  Bold,
  Italic,
  Underline,
  List,
  ListOrdered,
  Heading1,
  Heading2,
  Heading3,
  Quote,
  Code,
  Link,
  Image as ImageIcon,
  Palette,
  Type,
  Network,
  Sparkles,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Strikethrough
} from "lucide-react";
import { Dropdown, DropdownItem } from "./Dropdown";

export interface FontOption {
  label: string;
  value: string;
  category: "sans-serif" | "serif" | "monospace" | "handwriting";
}

export const MS_WORD_FONTS: FontOption[] = [
  // Sans-Serif
  { label: "Calibri", value: "Calibri, sans-serif", category: "sans-serif" },
  { label: "Arial", value: "Arial, Helvetica, sans-serif", category: "sans-serif" },
  { label: "Segoe UI", value: '"Segoe UI", Tahoma, Geneva, Verdana, sans-serif', category: "sans-serif" },
  { label: "Helvetica", value: "Helvetica, Arial, sans-serif", category: "sans-serif" },
  { label: "Tahoma", value: "Tahoma, Geneva, Verdana, sans-serif", category: "sans-serif" },
  { label: "Trebuchet MS", value: '"Trebuchet MS", sans-serif', category: "sans-serif" },
  { label: "Verdana", value: "Verdana, Geneva, sans-serif", category: "sans-serif" },
  { label: "Inter", value: "Inter, sans-serif", category: "sans-serif" },
  { label: "Roboto", value: "Roboto, sans-serif", category: "sans-serif" },

  // Serif
  { label: "Times New Roman", value: '"Times New Roman", Times, serif', category: "serif" },
  { label: "Georgia", value: "Georgia, serif", category: "serif" },
  { label: "Cambria", value: "Cambria, serif", category: "serif" },
  { label: "Garamond", value: "Garamond, serif", category: "serif" },
  { label: "Palatino Linotype", value: '"Palatino Linotype", "Book Antiqua", Palatino, serif', category: "serif" },
  { label: "Bodoni MT", value: '"Bodoni MT", Didot, serif', category: "serif" },

  // Monospace
  { label: "Courier New", value: '"Courier New", Courier, monospace', category: "monospace" },
  { label: "Consolas", value: "Consolas, monaco, monospace", category: "monospace" },
  { label: "Monaco", value: "Monaco, monospace", category: "monospace" },

  // Decorative / Handwriting
  { label: "Comic Sans MS", value: '"Comic Sans MS", cursive, sans-serif', category: "handwriting" },
  { label: "Impact", value: "Impact, Charcoal, sans-serif", category: "handwriting" },
  { label: "Caveat", value: "Caveat, cursive", category: "handwriting" },
  { label: "Dancing Script", value: '"Dancing Script", cursive', category: "handwriting" },
  { label: "Pacifico", value: "Pacifico, cursive", category: "handwriting" },
];

export const FONT_SIZE_OPTIONS = [
  { label: "Küçük (12px)", value: "12px" },
  { label: "Normal (14px)", value: "14px" },
  { label: "Orta (16px)", value: "16px" },
  { label: "Büyük (20px)", value: "20px" },
  { label: "Dev (24px)", value: "24px" },
  { label: "Başlık (32px)", value: "32px" },
];

interface ToolbarProps {
  onCommand?: (command: string, value?: string) => void;
  selectedFont?: string;
  selectedFontSize?: string;
  onFontChange?: (fontValue: string) => void;
  onFontSizeChange?: (sizeValue: string) => void;
  onGenerateMindMap?: () => void;
  hasAudioVideoMedia?: boolean;
  onGenerateAudioVideoMindMap?: () => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  onCommand,
  selectedFont = "Calibri, sans-serif",
  selectedFontSize = "14px",
  onFontChange,
  onFontSizeChange,
  onGenerateMindMap,
  hasAudioVideoMedia = false,
  onGenerateAudioVideoMindMap,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  const handleExecute = (cmd: string, val?: string) => {
    if (onCommand) onCommand(cmd, val);
  };

  const dropdownFontItems: DropdownItem<string>[] = MS_WORD_FONTS.map((font) => ({
    label: font.label,
    value: font.value,
    fontFamily: font.value,
    category: font.category,
  }));

  const dropdownSizeItems: DropdownItem<string>[] = FONT_SIZE_OPTIONS.map((opt) => ({
    label: opt.label,
    value: opt.value,
  }));

  return (
    <div
      ref={containerRef}
      className="relative z-10 w-full p-2 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-2 overflow-x-auto scrollbar-none transition-all"
    >
      <div className="flex items-center gap-1.5 shrink-0 flex-wrap sm:flex-nowrap">
        {/* MS Word Font Picker Dropdown */}
        <Dropdown<string>
          items={dropdownFontItems}
          selectedValue={selectedFont}
          onSelect={(val) => {
            if (onFontChange) onFontChange(val);
            handleExecute("fontName", val);
          }}
          icon={<Type className="w-3.5 h-3.5 text-slate-500" />}
          placeholder="Font Seç"
          menuWidth="w-64"
          renderPreview={true}
        />

        {/* Font Size Picker Dropdown */}
        <Dropdown<string>
          items={dropdownSizeItems}
          selectedValue={selectedFontSize}
          onSelect={(val) => {
            if (onFontSizeChange) onFontSizeChange(val);
            handleExecute("fontSize", val);
          }}
          placeholder="Boyut"
          menuWidth="w-40"
        />

        <div className="w-px h-5 bg-slate-200 dark:bg-slate-800 my-auto mx-1" />

        {/* Formatting Action Buttons */}
        <button
          type="button"
          onClick={() => handleExecute("bold")}
          className="p-1.5 sm:p-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="Kalın (Bold)"
        >
          <Bold className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => handleExecute("italic")}
          className="p-1.5 sm:p-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="İtalik (Italic)"
        >
          <Italic className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => handleExecute("underline")}
          className="p-1.5 sm:p-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="Altı Çizili (Underline)"
        >
          <Underline className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => handleExecute("strikeThrough")}
          className="p-1.5 sm:p-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="Üstü Çizili (Strikethrough)"
        >
          <Strikethrough className="w-4 h-4" />
        </button>

        <div className="w-px h-5 bg-slate-200 dark:bg-slate-800 my-auto mx-1" />

        <button
          type="button"
          onClick={() => handleExecute("insertUnorderedList")}
          className="p-1.5 sm:p-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="Maddeli Liste"
        >
          <List className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => handleExecute("insertOrderedList")}
          className="p-1.5 sm:p-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="Numaralı Liste"
        >
          <ListOrdered className="w-4 h-4" />
        </button>

        <div className="w-px h-5 bg-slate-200 dark:bg-slate-800 my-auto mx-1" />

        <button
          type="button"
          onClick={() => handleExecute("justifyLeft")}
          className="p-1.5 sm:p-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="Sola Hizala"
        >
          <AlignLeft className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => handleExecute("justifyCenter")}
          className="p-1.5 sm:p-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="Ortala"
        >
          <AlignCenter className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => handleExecute("justifyRight")}
          className="p-1.5 sm:p-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="Sağa Hizala"
        >
          <AlignRight className="w-4 h-4" />
        </button>
      </div>

      {/* Right Side Inline MindMap Action */}
      {onGenerateMindMap && (
        <div className="shrink-0 flex items-center gap-1.5">
          <button
            type="button"
            onClick={onGenerateMindMap}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-bold shadow-md hover:from-purple-500 hover:to-indigo-500 transition-all cursor-pointer"
            title="Metin İçeriğini Zihin Haritasına Dönüştür"
          >
            <Network className="w-4 h-4" />
            <span className="hidden sm:inline">Zihin Haritası</span>
            <Sparkles className="w-3 h-3 text-purple-200" />
          </button>

          {hasAudioVideoMedia && onGenerateAudioVideoMindMap && (
            <button
              type="button"
              onClick={onGenerateAudioVideoMindMap}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 text-xs font-bold border border-purple-200 dark:border-purple-800 hover:bg-purple-200 dark:hover:bg-purple-900 transition-all cursor-pointer"
              title="Medya İçeriğinden Zihin Haritası Üret"
            >
              <span>🎙️ Medya</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
