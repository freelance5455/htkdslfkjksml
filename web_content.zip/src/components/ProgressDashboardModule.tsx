import React, { useMemo } from 'react';
import {
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  Flame,
  Target,
  Zap,
  Award,
  BookOpen,
} from 'lucide-react';
import type { LearningAnalytics, PracticeAttempt, StudyProgressRecord } from '../types';
import { KANJI_DATA } from '../utils/japaneseData';
import { computeWeakTopics } from '../utils/rajuEngine';

interface ProgressDashboardProps {
  xp: number;
  level: number;
  analytics: LearningAnalytics;
  attempts: PracticeAttempt[];
  studyProgress: StudyProgressRecord[];
  onStartWeakRevision: (topic: string) => void;
  onOpenKanji: () => void;
}

export const ProgressDashboardModule: React.FC<ProgressDashboardProps> = ({
  xp,
  level,
  analytics,
  attempts,
  studyProgress,
  onStartWeakRevision,
  onOpenKanji,
}) => {
  const solvedTotal = attempts.length;
  const correctTotal = attempts.filter((a) => a.isCorrect).length;
  const incorrectTotal = solvedTotal - correctTotal;
  const accuracy = solvedTotal > 0 ? Math.round((correctTotal / solvedTotal) * 100) : 0;

  const weakTopics = useMemo(() => computeWeakTopics(attempts), [attempts]);

  const jlptLevels: Array<'N5' | 'N4' | 'N3' | 'N2' | 'N1'> = ['N5', 'N4', 'N3', 'N2', 'N1'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-cyan-400" />
            Learning Progress & Mastery Dashboard
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Track daily learning time, question accuracy, Kanji & vocabulary mastery, JLPT N5–N1 progress, streak, and personalized revision recommendations.
          </p>
        </div>

        <div className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-400/40 text-amber-200 text-xs font-bold flex items-center gap-2">
          <Flame className="w-4 h-4 text-orange-400" />
          <span>{analytics.streakDays} Day Learning Streak</span>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Daily Learning Time</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-extrabold text-white font-mono tabular-nums">
            {analytics.dailyMinutes} min
          </p>
          <p className="text-[11px] text-cyan-300">Active study & practice timer</p>
        </div>

        <div className="p-4 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Questions Solved</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-extrabold text-white font-mono tabular-nums">
            {solvedTotal}
          </p>
          <p className="text-[11px] text-emerald-300">
            {correctTotal} Correct · <span className="text-rose-300">{incorrectTotal} Incorrect</span> ({accuracy}%)
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Kanji Mastered</span>
            <Award className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-2xl font-extrabold text-white font-mono tabular-nums">
            {analytics.masteredKanji.length} / {KANJI_DATA.length}
          </p>
          <button type="button" onClick={onOpenKanji} className="text-[11px] text-purple-300 hover:underline">
            Practice Kanji Cards →
          </button>
        </div>

        <div className="p-4 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Vocabulary Learned</span>
            <BookOpen className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-extrabold text-white font-mono tabular-nums">
            {analytics.learnedVocabCount}
          </p>
          <p className="text-[11px] text-amber-300">Lv.{level} · {xp.toLocaleString()} XP</p>
        </div>
      </div>

      {/* JLPT Level Progress & Weak Topics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* JLPT N5-N1 Breakdown (6 cols) */}
        <div className="lg:col-span-6 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <h3 className="text-base font-bold text-white">JLPT Level Progress (N5 → N1)</h3>
          <div className="space-y-3">
            {jlptLevels.map((lvl) => {
              const totalInLevel = KANJI_DATA.filter((k) => k.jlpt === lvl).length;
              const masteredInLevel = KANJI_DATA.filter(
                (k) => k.jlpt === lvl && analytics.masteredKanji.includes(k.kanji)
              ).length;
              const pct = totalInLevel > 0 ? Math.round((masteredInLevel / totalInLevel) * 100) : 0;
              return (
                <div key={lvl} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-cyan-300">JLPT {lvl}</span>
                    <span className="font-mono text-slate-300 tabular-nums">
                      {masteredInLevel} / {totalInLevel} Kanji ({pct}%)
                    </span>
                  </div>
                  <div className="h-2.5 rounded-full bg-[#060919] border border-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-400 to-purple-500 transition-all duration-300"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Weak Topics & Revision Recommendations (6 cols) */}
        <div className="lg:col-span-6 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Target className="w-4 h-4 text-amber-400" />
            Weak Topics & Revision Recommendations
          </h3>

          {weakTopics.length === 0 ? (
            <div className="p-6 rounded-xl bg-[#060919] border border-slate-800 text-center space-y-2">
              <p className="text-sm text-slate-300">No practice attempts recorded yet</p>
              <p className="text-xs text-slate-400">
                Solve questions in the Smart Question Generator to automatically detect weak concepts and unlock targeted revision sets.
              </p>
              <button
                type="button"
                onClick={() => onStartWeakRevision('Japanese Kanji & Particles')}
                className="mt-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold"
              >
                Start First Practice Set
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {weakTopics.map((wt) => (
                <div
                  key={wt.topic}
                  className="p-3.5 rounded-xl bg-[#060919] border border-slate-800 flex items-center justify-between gap-3"
                >
                  <div>
                    <p className="text-sm font-semibold text-white">{wt.topic}</p>
                    <p className="text-xs text-slate-400 font-mono tabular-nums mt-0.5">
                      {wt.correctCount}/{wt.totalAttempts} correct ·{' '}
                      <span className={wt.isWeak ? 'text-rose-300 font-bold' : 'text-emerald-300'}>
                        {wt.accuracyPercent}% accuracy
                      </span>
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onStartWeakRevision(wt.topic)}
                    className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white text-xs font-semibold flex items-center gap-1 shrink-0"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    Revise
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Recent Practice History & Study Logs */}
      <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-3">
        <h3 className="text-base font-bold text-white">Recent Practice & Assessment History</h3>
        {attempts.length === 0 && studyProgress.length === 0 ? (
          <p className="text-xs text-slate-400 py-4">
            Complete questions or Study Assistant quizzes to see your detailed score history here.
          </p>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {attempts.slice(0, 12).map((att) => (
              <div
                key={att.id}
                className="p-3 rounded-xl bg-[#060919] border border-slate-800 flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-2.5 min-w-0">
                  {att.isCorrect ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <div className="min-w-0">
                    <p className="font-semibold text-white truncate">{att.questionText}</p>
                    <p className="text-slate-400 mt-0.5">
                      {att.topic} · {att.conceptTag} · {att.difficulty}
                    </p>
                  </div>
                </div>
                <span className="text-[11px] font-mono text-slate-400 shrink-0">
                  {att.timestamp.slice(11, 16) || 'Now'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
