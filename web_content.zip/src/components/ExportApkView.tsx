import React, { useState } from 'react';
import { 
  Download, 
  Smartphone, 
  CheckCircle2, 
  FileCode, 
  Layers, 
  FolderArchive, 
  ExternalLink, 
  Copy, 
  Check, 
  Terminal, 
  ShieldCheck,
  PackageCheck,
  FileText,
  AlertCircle
} from 'lucide-react';

export const ExportApkView: React.FC = () => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'capacitor' | 'pwabuilder' | 'files'>('capacitor');

  const copyText = (txt: string, id: string) => {
    navigator.clipboard?.writeText(txt);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const handleDownloadZip = () => {
    setIsDownloading(true);
    setDownloadSuccess(false);

    // Create invisible anchor to trigger direct download from public directory
    const link = document.createElement('a');
    link.href = '/sewora-ecommerce-app.zip';
    link.download = 'sewora-ecommerce-app.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setIsDownloading(false);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 5000);
    }, 1200);
  };

  const fileManifest = [
    { name: 'src/App.tsx', type: 'Source', desc: 'Main app controller, state, bottom tabs, router' },
    { name: 'src/main.tsx', type: 'Source', desc: 'React 19 entry point' },
    { name: 'src/index.css', type: 'Style', desc: 'Tailwind CSS v4 design tokens, custom scrollbars' },
    { name: 'src/components/HomeScreen.tsx', type: 'Component', desc: 'Promo carousel, flash sale timer, recommendation feed' },
    { name: 'src/components/ProductDetailScreen.tsx', type: 'Component', desc: 'PDP gallery, variants, reviews, shipping estimator' },
    { name: 'src/components/CartScreen.tsx', type: 'Component', desc: 'Multi-vendor cart, vouchers, subtotal calculator' },
    { name: 'src/components/CheckoutScreen.tsx', type: 'Component', desc: 'Address selector, Card, COD, Wallets, BNPL' },
    { name: 'src/components/CategoryScreen.tsx', type: 'Component', desc: 'Faceted filters, category rail, search matching' },
    { name: 'src/components/AccountScreen.tsx', type: 'Component', desc: 'Order status buckets, Sewora Coins, VIP profile' },
    { name: 'src/components/VendorStoreScreen.tsx', type: 'Component', desc: 'Official mall storefront, follower toggle, vouchers' },
    { name: 'src/components/SellerChatDrawer.tsx', type: 'Component', desc: 'Interactive live instant chat simulation' },
    { name: 'src/components/MobileFrame.tsx', type: 'Component', desc: 'Phone chassis frame with status bar' },
    { name: 'src/data/mockData.ts', type: 'Data', desc: 'Catalog products, vendors, addresses, reviews' },
    { name: 'src/types/ecommerce.ts', type: 'Types', desc: 'TypeScript interfaces and data contracts' },
    { name: 'src/assets/images/*.jpg', type: 'Assets', desc: 'High-res 3D campaign banner & sneaker product photo' },
    { name: 'public/manifest.json', type: 'Android / PWA', desc: 'Web App Manifest configured for Android APK' },
    { name: 'public/icon.svg', type: 'Assets', desc: 'High-resolution vector launcher icon' },
    { name: 'capacitor.config.json', type: 'Android Config', desc: 'Pre-configured Capacitor Android package config' },
    { name: 'README-ANDROID-BUILD.md', type: 'Docs', desc: 'Step-by-step guide to compile into Android APK / AAB' },
    { name: 'package.json', type: 'Config', desc: 'Dependencies and build scripts' },
    { name: 'vite.config.ts', type: 'Config', desc: 'Vite compiler setup' }
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
      {/* Top Banner Card */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-3xl p-6 md:p-8 border border-slate-700 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-[#FF6600]/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="bg-[#FF6600] text-white text-[11px] font-black px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                <PackageCheck className="w-3.5 h-3.5" />
                <span>EXPORT READY</span>
              </span>
              <span className="text-xs text-slate-300 font-medium">All Assets & Code Bundled</span>
            </div>

            <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white">
              Download Sewora Android App Package
            </h1>
            <p className="text-xs md:text-sm text-slate-300 max-w-xl leading-relaxed">
              Your entire project is compiled and packaged into a single, clean ZIP archive containing 
              all source codes, product data, CSS, high-res assets, PWA manifest, and Capacitor 
              Android build configuration.
            </p>
          </div>

          <div className="shrink-0 flex flex-col items-start md:items-end gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={isDownloading}
              className="bg-[#FF6600] hover:bg-orange-500 text-white font-extrabold text-sm px-6 py-3.5 rounded-2xl shadow-xl hover:shadow-orange-500/30 active:scale-95 transition-all flex items-center gap-2.5 cursor-pointer"
            >
              {isDownloading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Preparing Download...</span>
                </>
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  <span>Download Complete ZIP (1.5 MB)</span>
                </>
              )}
            </button>

            {downloadSuccess && (
              <div className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>Downloaded sewora-ecommerce-app.zip!</span>
              </div>
            )}
            <span className="text-[11px] text-slate-400 font-mono">Format: .ZIP · Compatible with Android Studio</span>
          </div>
        </div>
      </div>

      {/* Checklist Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4" />
            <span>Source Code</span>
          </div>
          <p className="text-[11px] text-slate-500">100% React 19 + TypeScript components included.</p>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4" />
            <span>Images & Icons</span>
          </div>
          <p className="text-[11px] text-slate-500">High-res 3D banner, sneakers & vector launcher icon.</p>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4" />
            <span>Capacitor Android</span>
          </div>
          <p className="text-[11px] text-slate-500">Configured with app ID: <code>com.sewora.app</code>.</p>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4" />
            <span>PWA & Manifest</span>
          </div>
          <p className="text-[11px] text-slate-500">Full standalone display & portrait orientation.</p>
        </div>
      </div>

      {/* Conversion Methods Tabs */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h2 className="text-base font-black text-slate-900">How to Convert into Android APK</h2>
            <p className="text-xs text-slate-500">Choose your preferred build method below:</p>
          </div>

          <div className="flex gap-1 bg-slate-100 p-1 rounded-xl text-xs font-bold">
            <button
              onClick={() => setActiveTab('capacitor')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'capacitor' ? 'bg-white text-[#FF6600] shadow-xs' : 'text-slate-600'
              }`}
            >
              1. Capacitor (Android Studio)
            </button>
            <button
              onClick={() => setActiveTab('pwabuilder')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'pwabuilder' ? 'bg-white text-[#FF6600] shadow-xs' : 'text-slate-600'
              }`}
            >
              2. PWABuilder (No-Code Online)
            </button>
            <button
              onClick={() => setActiveTab('files')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'files' ? 'bg-white text-[#FF6600] shadow-xs' : 'text-slate-600'
              }`}
            >
              3. File Manifest ({fileManifest.length})
            </button>
          </div>
        </div>

        {/* Tab 1: Capacitor Method */}
        {activeTab === 'capacitor' && (
          <div className="space-y-4 pt-1">
            <div className="p-3 bg-orange-50/60 border border-orange-200/80 rounded-2xl text-xs text-slate-700 leading-relaxed">
              <strong>Recommended for native Android APK:</strong> Capacitor wraps your Vite web app 
              into a native Android Studio project. <code className="bg-white px-1.5 py-0.5 rounded border border-orange-200">capacitor.config.json</code> is already pre-configured in your ZIP!
            </div>

            <div className="space-y-3">
              {[
                {
                  step: 'Step 1: Unzip and Install Dependencies',
                  cmd: 'cd sewora-ecommerce-app\nnpm install',
                  note: 'Extract the downloaded ZIP and run npm install in your terminal.'
                },
                {
                  step: 'Step 2: Add Capacitor Android Platform & Build',
                  cmd: 'npm install @capacitor/core @capacitor/cli @capacitor/android\nnpm run build\nnpx cap add android',
                  note: 'Compiles the web assets into dist/ and initializes the native Android workspace.'
                },
                {
                  step: 'Step 3: Sync & Open in Android Studio',
                  cmd: 'npx cap sync android\nnpx cap open android',
                  note: 'Launches Android Studio automatically where you can click "Build APK".'
                }
              ].map((s, idx) => (
                <div key={idx} className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-slate-900">{s.step}</span>
                    <button
                      onClick={() => copyText(s.cmd, 'cmd-' + idx)}
                      className="text-xs text-slate-600 hover:text-slate-900 flex items-center gap-1 font-semibold"
                    >
                      {copiedCmd === 'cmd-' + idx ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-600">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Commands</span>
                        </>
                      )}
                    </button>
                  </div>
                  <pre className="bg-slate-900 text-slate-100 p-3 rounded-xl font-mono text-xs overflow-x-auto select-all">
                    {s.cmd}
                  </pre>
                  <p className="text-[11px] text-slate-500 italic">{s.note}</p>
                </div>
              ))}
            </div>

            <div className="p-3 bg-slate-900 text-slate-200 rounded-2xl text-xs space-y-1">
              <div className="font-bold text-white flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-[#FF6600]" />
                <span>To Build Release APK in Android Studio:</span>
              </div>
              <p className="text-slate-400">
                In Android Studio, click <strong>Build</strong> → <strong>Build Bundle(s) / APK(s)</strong> → <strong>Build APK(s)</strong>. 
                Your APK file will be generated in <code className="text-orange-300">android/app/build/outputs/apk/debug/app-debug.apk</code>.
              </p>
            </div>
          </div>
        )}

        {/* Tab 2: PWABuilder No-Code */}
        {activeTab === 'pwabuilder' && (
          <div className="space-y-4 pt-1">
            <div className="p-3 bg-blue-50/60 border border-blue-200/80 rounded-2xl text-xs text-slate-700 leading-relaxed">
              <strong>100% No-Code Online Generator:</strong> PWABuilder (maintained by Microsoft) 
              converts progressive web apps into Google Play Store APK/AAB packages directly in your web browser.
            </div>

            <div className="space-y-3 text-xs text-slate-700">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <span className="font-black text-slate-900">Step 1: Host Your App</span>
                <p className="text-slate-600">
                  Deploy the project or use the preview URL: 
                  <code className="block mt-1 p-2 bg-white rounded border border-slate-200 font-mono text-slate-800 break-all">
                    {window.location.origin}
                  </code>
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <span className="font-black text-slate-900">Step 2: Enter URL on PWABuilder</span>
                <p className="text-slate-600">
                  Visit <a href="https://www.pwabuilder.com" target="_blank" rel="noreferrer" className="text-[#FF6600] font-bold underline inline-flex items-center gap-1">pwabuilder.com <ExternalLink className="w-3 h-3" /></a> and paste your URL.
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <span className="font-black text-slate-900">Step 3: Generate Android Package</span>
                <p className="text-slate-600">
                  Click <strong>Package for Store</strong> → select <strong>Android</strong> → download your signed APK & Google Play AAB bundle!
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: File Manifest */}
        {activeTab === 'files' && (
          <div className="space-y-3 pt-1">
            <p className="text-xs text-slate-500">
              The following {fileManifest.length} files are packed in <code className="font-bold text-slate-800">sewora-ecommerce-app.zip</code>:
            </p>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-slate-50 max-h-[380px] overflow-y-auto">
              {fileManifest.map((f, i) => (
                <div key={i} className="p-2.5 flex items-center justify-between text-xs hover:bg-white transition-colors">
                  <div className="flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-slate-400 shrink-0" />
                    <span className="font-mono font-bold text-slate-800">{f.name}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[11px] text-slate-500 truncate max-w-xs hidden sm:inline-block">
                      {f.desc}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-700 shrink-0">
                      {f.type}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
