import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowUp,
  FileArchive,
  FileCode2,
  FolderPlus,
  ImagePlus,
  Plus,
  Square,
  X,
} from 'lucide-react';
import type { AttachmentItem, WorkspaceFile } from '../types/mycode';
import { extractTextFilesFromZip } from '../utils/workspaceStore';

interface FloatingInputBarProps {
  value: string;
  onChange: (val: string) => void;
  onSend: () => void;
  onStop: () => void;
  isGenerating: boolean;
  attachments: AttachmentItem[];
  onAddAttachments: (items: AttachmentItem[]) => void;
  onRemoveAttachment: (id: string) => void;
  onImportZipToWorkspace: (files: Array<{ path: string; content: string; language: string }>) => void;
  workspaceFiles: Record<string, WorkspaceFile>;
  desktopView: boolean;
}

function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ''));
    reader.onerror = () => reject(reader.error);
    reader.readAsText(file);
  });
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ''));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export function FloatingInputBar({
  value,
  onChange,
  onSend,
  onStop,
  isGenerating,
  attachments,
  onAddAttachments,
  onRemoveAttachment,
  onImportZipToWorkspace,
  workspaceFiles,
  desktopView,
}: FloatingInputBarProps) {
  const [sheetOpen, setSheetOpen] = useState(false);
  const [sheetError, setSheetError] = useState<string | null>(null);
  const [showWorkspacePicker, setShowWorkspacePicker] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const codeInputRef = useRef<HTMLInputElement>(null);
  const zipInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    const maxHeight = desktopView ? 140 : 160;
    el.style.height = `${Math.min(el.scrollHeight, maxHeight)}px`;
  }, [value, desktopView]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isGenerating && (value.trim() || attachments.length > 0)) {
        onSend();
      }
    }
  };

  const handleCodeFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    if (files.length === 0) return;

    setSheetError(null);
    try {
      const created: AttachmentItem[] = [];
      for (const file of files) {
        const text = await readFileAsText(file);
        created.push({
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          name: file.name,
          mimeType: file.type || 'text/plain',
          size: file.size,
          kind: 'text',
          content: text,
        });
      }
      onAddAttachments(created);
      setSheetOpen(false);
    } catch {
      setSheetError('Could not read the selected file.');
    }
  };

  const handleImageFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    if (files.length === 0) return;

    setSheetError(null);
    try {
      const created: AttachmentItem[] = [];
      for (const file of files) {
        const dataUrl = await readFileAsDataUrl(file);
        const commaIdx = dataUrl.indexOf(',');
        const base64 = commaIdx !== -1 ? dataUrl.slice(commaIdx + 1) : dataUrl;
        created.push({
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          name: file.name,
          mimeType: file.type || 'image/png',
          size: file.size,
          kind: 'image',
          content: base64,
          previewUrl: dataUrl,
        });
      }
      onAddAttachments(created);
      setSheetOpen(false);
    } catch {
      setSheetError('Could not read the selected image.');
    }
  };

  const handleZipSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setSheetError(null);
    try {
      const extracted = await extractTextFilesFromZip(file);
      if (extracted.length === 0) {
        setSheetError('No readable code or text files found inside this ZIP archive.');
        return;
      }
      onImportZipToWorkspace(extracted);
      const summaryContent = extracted
        .slice(0, 12)
        .map((f) => `--- ${f.path} ---\n${f.content}`)
        .join('\n\n');
      onAddAttachments([
        {
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          name: `${file.name} (${extracted.length} files)`,
          mimeType: 'application/zip',
          size: file.size,
          kind: 'text',
          content: summaryContent,
        },
      ]);
      setSheetOpen(false);
    } catch {
      setSheetError('Failed to extract ZIP archive. Make sure it is a valid .zip file.');
    }
  };

  const handleAttachWorkspaceFile = (wf: WorkspaceFile) => {
    onAddAttachments([
      {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        name: wf.path,
        mimeType: 'text/plain',
        size: wf.content.length,
        kind: 'text',
        content: wf.content,
      },
    ]);
    setShowWorkspacePicker(false);
    setSheetOpen(false);
  };

  const canSend = Boolean(value.trim() || attachments.length > 0);
  const workspaceList = Object.values(workspaceFiles).sort((a, b) => a.path.localeCompare(b.path));

  return (
    <>
      <div
        className={`sticky bottom-0 z-20 w-full bg-gradient-to-t from-white via-white to-white/0 ${
          desktopView ? 'px-4 pb-3 pt-2' : 'px-3 sm:px-4 pb-3 sm:pb-5 pt-2'
        }`}
      >
        <div
          className={`mx-auto w-full rounded-2xl border border-[#E5E7EB] bg-white shadow-[0_8px_28px_rgba(17,24,39,0.06)] transition-shadow focus-within:border-[#9CA3AF] ${
            desktopView ? 'max-w-none' : 'max-w-3xl'
          }`}
        >
          {/* Removable attachment chips */}
          {attachments.length > 0 && (
            <div className="flex flex-wrap gap-1.5 px-3 pt-3 pb-1">
              {attachments.map((att) => (
                <span
                  key={att.id}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5E7EB] bg-[#F9FAFB] px-2.5 py-1 text-[12px] text-[#111827]"
                >
                  {att.kind === 'image' && att.previewUrl ? (
                    <img
                      src={att.previewUrl}
                      alt={att.name}
                      referrerPolicy="no-referrer"
                      className="h-4 w-4 rounded object-cover"
                    />
                  ) : (
                    <FileCode2 className="h-3.5 w-3.5 text-[#6B7280]" />
                  )}
                  <span className="max-w-[140px] truncate font-mono text-[11px]">{att.name}</span>
                  <button
                    type="button"
                    onClick={() => onRemoveAttachment(att.id)}
                    aria-label={`Remove ${att.name}`}
                    className="ml-0.5 rounded p-0.5 text-[#6B7280] hover:bg-[#E5E7EB] hover:text-[#111827] transition-colors"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))}
            </div>
          )}

          <div className={`flex items-end gap-2 ${desktopView ? 'p-1.5' : 'p-2'}`}>
            {/* Left: "+" Attachment Button */}
            <button
              type="button"
              onClick={() => {
                setSheetError(null);
                setShowWorkspacePicker(false);
                setSheetOpen(true);
              }}
              aria-label="Attach files or images"
              className={`inline-flex shrink-0 items-center justify-center rounded-xl text-[#374151] hover:bg-[#F3F4F6] hover:text-[#111827] transition-colors focus-visible:outline-2 focus-visible:outline-[#111827] ${
                desktopView ? 'h-9 w-9' : 'h-11 w-11'
              }`}
            >
              <Plus className="h-5 w-5" />
            </button>

            {/* Center: Auto-expanding text input */}
            <textarea
              ref={textareaRef}
              rows={1}
              value={value}
              onChange={(e) => onChange(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask MyCode to build or edit code..."
              aria-label="Prompt input"
              className={`flex-1 resize-none bg-transparent text-[#111827] placeholder:text-[#9CA3AF] focus:outline-none ${
                desktopView
                  ? 'py-2 text-[13px] leading-5'
                  : 'py-2.5 text-[15px] leading-6'
              }`}
            />

            {/* Right: Solid black circular Send / Stop button */}
            {isGenerating ? (
              <button
                type="button"
                onClick={onStop}
                aria-label="Stop generation"
                className={`inline-flex shrink-0 items-center justify-center rounded-full bg-black text-white hover:bg-[#1F2937] active:scale-95 transition-all ${
                  desktopView ? 'h-9 w-9' : 'h-10 w-10'
                }`}
              >
                <Square className="h-3.5 w-3.5 fill-white" />
              </button>
            ) : (
              <button
                type="button"
                onClick={onSend}
                disabled={!canSend}
                aria-label="Send prompt"
                className={`inline-flex shrink-0 items-center justify-center rounded-full bg-black text-white transition-all ${
                  canSend
                    ? 'hover:bg-[#1F2937] active:scale-95 opacity-100'
                    : 'opacity-25 cursor-not-allowed'
                } ${desktopView ? 'h-9 w-9' : 'h-10 w-10'}`}
              >
                <ArrowUp className="h-4.5 w-4.5 stroke-[2.25]" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Hidden file inputs */}
      <input
        ref={codeInputRef}
        type="file"
        multiple
        accept=".txt,.md,.js,.jsx,.ts,.tsx,.py,.html,.htm,.css,.scss,.json,.xml,.svg,.yaml,.yml,.sql,.sh,.bash,.java,.kt,.go,.rs,.c,.cpp,.h,.cs,.rb,.php,.swift,.dart,.env,.csv"
        className="hidden"
        onChange={handleCodeFilesSelected}
      />
      <input
        ref={zipInputRef}
        type="file"
        accept=".zip,application/zip"
        className="hidden"
        onChange={handleZipSelected}
      />
      <input
        ref={imageInputRef}
        type="file"
        multiple
        accept="image/*"
        className="hidden"
        onChange={handleImageFilesSelected}
      />

      {/* Attachment Bottom Sheet */}
      {sheetOpen && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-[2px]"
          onClick={() => setSheetOpen(false)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Attach to prompt"
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-[#E5E7EB] bg-white p-5 shadow-2xl"
          >
            <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-[#E5E7EB] sm:hidden" />

            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-[15px] font-semibold text-[#111827]">
                {showWorkspacePicker ? 'Attach Workspace File' : 'Attach Files'}
              </h3>
              <button
                type="button"
                onClick={() => setSheetOpen(false)}
                aria-label="Close attachment sheet"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#111827]"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {sheetError && (
              <div className="mb-3 rounded-xl border border-[#FECACA] bg-[#FEF2F2] px-3 py-2 text-[12px] text-[#991B1B]">
                {sheetError}
              </div>
            )}

            {showWorkspacePicker ? (
              <div className="space-y-1.5 max-h-64 overflow-y-auto">
                {workspaceList.map((wf) => (
                  <button
                    key={wf.path}
                    type="button"
                    onClick={() => handleAttachWorkspaceFile(wf)}
                    className="w-full flex items-center justify-between rounded-xl border border-[#E5E7EB] px-3.5 py-3 text-left hover:bg-[#F9FAFB] transition-colors"
                  >
                    <span className="font-mono text-[13px] text-[#111827] truncate">
                      {wf.path}
                    </span>
                    <span className="text-[11px] text-[#6B7280] ml-2 shrink-0">
                      {wf.language}
                    </span>
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setShowWorkspacePicker(false)}
                  className="mt-2 w-full rounded-xl border border-[#E5E7EB] py-2.5 text-[13px] font-medium text-[#4B5563] hover:bg-[#F9FAFB]"
                >
                  Back
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => codeInputRef.current?.click()}
                  className="w-full min-h-[52px] flex items-center gap-3 rounded-xl border border-[#E5E7EB] bg-white px-4 py-3 text-left hover:bg-[#F9FAFB] transition-colors"
                >
                  <FileCode2 className="h-5 w-5 text-[#111827] shrink-0" />
                  <div>
                    <div className="text-[14px] font-medium text-[#111827]">
                      Code or Text Files
                    </div>
                    <div className="text-[12px] text-[#6B7280]">
                      Python, JS, TS, HTML, CSS, JSON, Markdown
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => zipInputRef.current?.click()}
                  className="w-full min-h-[52px] flex items-center gap-3 rounded-xl border border-[#E5E7EB] bg-white px-4 py-3 text-left hover:bg-[#F9FAFB] transition-colors"
                >
                  <FileArchive className="h-5 w-5 text-[#111827] shrink-0" />
                  <div>
                    <div className="text-[14px] font-medium text-[#111827]">
                      ZIP Project Archive
                    </div>
                    <div className="text-[12px] text-[#6B7280]">
                      Extracts files into workspace and attaches context
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => imageInputRef.current?.click()}
                  className="w-full min-h-[52px] flex items-center gap-3 rounded-xl border border-[#E5E7EB] bg-white px-4 py-3 text-left hover:bg-[#F9FAFB] transition-colors"
                >
                  <ImagePlus className="h-5 w-5 text-[#111827] shrink-0" />
                  <div>
                    <div className="text-[14px] font-medium text-[#111827]">Images</div>
                    <div className="text-[12px] text-[#6B7280]">
                      UI screenshots, diagrams, or error photos
                    </div>
                  </div>
                </button>

                {workspaceList.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowWorkspacePicker(true)}
                    className="w-full min-h-[52px] flex items-center gap-3 rounded-xl border border-[#E5E7EB] bg-white px-4 py-3 text-left hover:bg-[#F9FAFB] transition-colors"
                  >
                    <FolderPlus className="h-5 w-5 text-[#111827] shrink-0" />
                    <div>
                      <div className="text-[14px] font-medium text-[#111827]">
                        From Workspace ({workspaceList.length})
                      </div>
                      <div className="text-[12px] text-[#6B7280]">
                        Reference an existing file in this project
                      </div>
                    </div>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
