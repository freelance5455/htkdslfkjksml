"use client";

import { useEffect, useState } from "react";
import type { EntryDTO, MemberDTO, MovieDTO } from "@/lib/types";
import { formatAvg, getPalette } from "@/lib/palette";
import { Stars } from "@/components/stars";
import { PosterImage } from "@/components/poster";

export type FriendMark = { member: MemberDTO; entry: EntryDTO };

type CardProps = {
  movie: MovieDTO;
  myEntry?: EntryDTO;
  friends: FriendMark[];
  index?: number;
  onOpen: () => void;
  onRate: (rating: number) => void;
  onToggleWatchlist: () => void;
  onToggleFavorite: () => void;
  pending?: boolean;
};

export function PosterCard({
  movie,
  myEntry,
  friends,
  index = 0,
  onOpen,
  onRate,
  onToggleWatchlist,
  onToggleFavorite,
  pending = false,
}: CardProps) {
  const palette = getPalette(movie.palette);
  const friendRatings = friends.filter((f) => (f.entry.rating ?? 0) > 0);
  const friendAvg =
    friendRatings.length > 0
      ? friendRatings.reduce((sum, f) => sum + (f.entry.rating ?? 0), 0) / friendRatings.length
      : null;

  return (
    <article
      className={`group animate-rise relative ${pending ? "opacity-60" : ""}`}
      style={{ animationDelay: `${Math.min(index, 24) * 22}ms` }}
    >
      <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-black/50 shadow-[0_14px_30px_-20px_rgba(0,0,0,0.9)] transition duration-300 ease-out group-hover:-translate-y-1.5 group-hover:border-white/30 group-hover:shadow-[0_26px_45px_-22px_rgba(230,36,41,0.55)]">
        <div className="relative aspect-[2/3] w-full">
          <PosterImage
            src={movie.posterUrl}
            palette={movie.palette}
            alt={movie.title}
            className="absolute inset-0 h-full w-full"
            width={400}
            eager={index < 6}
          />

          <button
            type="button"
            onClick={onOpen}
            aria-label={`Apri ${movie.title}`}
            className="absolute inset-0 z-10 cursor-pointer"
          />

          <div className="pointer-events-none absolute inset-0 z-20 bg-gradient-to-t from-black via-black/25 to-black/10" />

          <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-1 p-2">
            <span className="rounded-md bg-black/70 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white/85 backdrop-blur-sm">
              {movie.saga === "MCU" ? `Fase ${movie.phase}` : movie.saga}
            </span>
            <div className="flex flex-col items-end gap-1">
              {movie.upcoming ? (
                <span className="rounded bg-mv-gold px-1.5 py-0.5 text-[9px] font-black uppercase text-black">
                  In arrivo
                </span>
              ) : null}
              {myEntry?.favorite ? (
                <span className="grid h-5 w-5 place-items-center rounded-full bg-mv-red text-[10px] text-white shadow">
                  ♥
                </span>
              ) : null}
              {myEntry?.status === "watched" ? (
                <span className="grid h-5 w-5 place-items-center rounded-full bg-emerald-500 text-[10px] font-bold text-white shadow">
                  ✓
                </span>
              ) : null}
            </div>
          </div>

          <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 p-2.5">
            <h3 className="font-display text-[13px] leading-[1.12] text-white drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
              {movie.title}
            </h3>
            <p className="mt-0.5 text-[10px] font-medium text-white/65">
              {movie.year}
              {movie.runtime > 0 ? ` · ${movie.runtime} min` : ""}
            </p>
          </div>

          <div className="pointer-events-none absolute inset-0 z-30 flex flex-col items-center justify-center gap-1.5 bg-black/60 opacity-0 backdrop-blur-[2px] transition duration-300 group-hover:opacity-100 group-focus-within:opacity-100">
            <button
              type="button"
              onClick={onToggleWatchlist}
              className={`pointer-events-auto flex w-[78%] cursor-pointer items-center justify-center gap-1.5 rounded-lg px-2 py-1.5 text-[10px] font-black uppercase tracking-wide transition active:scale-95 ${
                myEntry?.status === "watchlist"
                  ? "bg-mv-gold text-black"
                  : "bg-white/15 text-white hover:bg-white/25"
              }`}
            >
              🔖 {myEntry?.status === "watchlist" ? "In watchlist" : "Watchlist"}
            </button>
            <button
              type="button"
              onClick={onToggleFavorite}
              className={`pointer-events-auto flex w-[78%] cursor-pointer items-center justify-center gap-1.5 rounded-lg px-2 py-1.5 text-[10px] font-black uppercase tracking-wide transition active:scale-95 ${
                myEntry?.favorite ? "bg-mv-red text-white" : "bg-white/15 text-white hover:bg-white/25"
              }`}
            >
              ♥ Preferito
            </button>
            <span className="mt-0.5 text-[9px] font-bold uppercase tracking-widest text-white/60">
              Tocca per i dettagli
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between gap-1 px-2 py-1.5">
          <Stars value={myEntry?.rating ?? 0} onChange={onRate} size="sm" />
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onToggleWatchlist}
              aria-label="Watchlist"
              className={`grid h-6 w-6 cursor-pointer place-items-center rounded-md border text-[11px] transition active:scale-90 ${
                myEntry?.status === "watchlist"
                  ? "border-mv-gold/70 bg-mv-gold/20 text-mv-gold"
                  : "border-white/10 bg-white/5 text-white/45 hover:text-white"
              }`}
            >
              🔖
            </button>
            <button
              type="button"
              onClick={onToggleFavorite}
              aria-label="Preferito"
              className={`grid h-6 w-6 cursor-pointer place-items-center rounded-md border text-[11px] transition active:scale-90 ${
                myEntry?.favorite
                  ? "border-mv-red/70 bg-mv-red/25 text-mv-red"
                  : "border-white/10 bg-white/5 text-white/45 hover:text-white"
              }`}
            >
              ♥
            </button>
          </div>
        </div>
      </div>

      <div className="mt-1 flex min-h-[16px] items-center gap-1.5 px-0.5">
        {friends.length > 0 ? (
          <>
            <div className="flex -space-x-1.5">
              {friends.slice(0, 4).map((friend) => (
                <span
                  key={friend.member.id}
                  title={`${friend.member.name}${friend.entry.rating ? ` · ${friend.entry.rating}★` : ""}`}
                  className="grid h-4.5 w-4.5 place-items-center rounded-full border border-black/70 text-[9px]"
                  style={{ backgroundColor: `${friend.member.color}33`, color: friend.member.color }}
                >
                  {friend.member.avatar}
                </span>
              ))}
            </div>
            <span className="text-[9px] font-semibold text-mv-gold/90">
              {friendAvg !== null ? `★ ${formatAvg(friendAvg)}` : "watchlist"}
            </span>
          </>
        ) : (
          <span className="text-[9px] text-white/20">—</span>
        )}
      </div>
    </article>
  );
}

type ModalProps = {
  movie: MovieDTO;
  myEntry?: EntryDTO;
  friends: FriendMark[];
  onClose: () => void;
  onSave: (patch: {
    status?: "watched" | "watchlist";
    rating?: number | null;
    review?: string | null;
    favorite?: boolean;
  }) => Promise<void>;
  onRemove: () => Promise<void>;
  pending?: boolean;
};

export function MovieModal({ movie, myEntry, friends, onClose, onSave, onRemove, pending = false }: ModalProps) {
  const palette = getPalette(movie.palette);
  const [review, setReview] = useState(myEntry?.review ?? "");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setReview(myEntry?.review ?? "");
  }, [myEntry?.review, movie.id]);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handler);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const rated = friends.filter((f) => (f.entry.rating ?? 0) > 0);
  const friendAvg =
    rated.length > 0 ? rated.reduce((sum, f) => sum + (f.entry.rating ?? 0), 0) / rated.length : null;

  async function persist(patch: Parameters<ModalProps["onSave"]>[0]) {
    setSaving(true);
    try {
      await onSave(patch);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div
      className="animate-fade fixed inset-0 z-50 flex items-end justify-center overflow-y-auto bg-black/80 backdrop-blur-sm sm:items-center sm:p-6"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="animate-slide-up relative w-full max-w-3xl overflow-hidden rounded-t-3xl border border-white/12 bg-mv-panel shadow-2xl sm:rounded-3xl"
        onClick={(event) => event.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute right-3 top-3 z-30 grid h-8 w-8 cursor-pointer place-items-center rounded-full bg-black/60 text-white/80 backdrop-blur transition hover:bg-black/90 hover:text-white"
          aria-label="Chiudi"
        >
          ✕
        </button>

        <div className="relative flex gap-4 p-4 sm:p-5" style={{ background: `linear-gradient(135deg, ${palette.from}44, transparent 70%)` }}>
          <div className="w-24 shrink-0 sm:w-36">
            <PosterImage
              src={movie.posterUrl}
              palette={movie.palette}
              alt={movie.title}
              className="aspect-[2/3] w-full rounded-xl border border-white/15 shadow-xl"
              width={400}
              eager
            />
          </div>
          <div className="min-w-0 flex-1 pr-6">
            <div className="flex flex-wrap items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest text-white/75">
              <span className="rounded bg-black/50 px-1.5 py-0.5">
                {movie.saga === "MCU" ? `Fase ${movie.phase}` : movie.saga}
              </span>
              <span className="rounded bg-black/50 px-1.5 py-0.5">{movie.year}</span>
              {movie.runtime > 0 ? (
                <span className="rounded bg-black/50 px-1.5 py-0.5">{movie.runtime} min</span>
              ) : null}
              {movie.upcoming ? (
                <span className="rounded bg-mv-gold px-1.5 py-0.5 text-black">In arrivo</span>
              ) : null}
            </div>
            <h2 className="mt-1.5 font-display text-2xl leading-none text-white sm:text-3xl">{movie.title}</h2>
            <p className="mt-1.5 line-clamp-3 text-xs leading-relaxed text-white/70 sm:line-clamp-none sm:text-sm">
              {movie.synopsis}
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Il tuo voto</span>
              <Stars value={myEntry?.rating ?? 0} size="md" onChange={(rating) => persist({ rating })} />
            </div>
          </div>
        </div>

        <div className="space-y-4 border-t border-white/8 p-4 sm:p-5">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={saving || pending}
              onClick={() => persist({ status: "watched" })}
              className={`cursor-pointer rounded-xl border px-3 py-2 text-[11px] font-bold uppercase tracking-wide transition active:scale-95 disabled:opacity-50 ${
                myEntry?.status === "watched"
                  ? "border-emerald-400/50 bg-emerald-400/15 text-emerald-300"
                  : "border-white/15 bg-white/5 text-white/70 hover:border-white/35"
              }`}
            >
              ✓ Visto
            </button>
            <button
              type="button"
              disabled={saving || pending}
              onClick={() => persist({ status: "watchlist" })}
              className={`cursor-pointer rounded-xl border px-3 py-2 text-[11px] font-bold uppercase tracking-wide transition active:scale-95 disabled:opacity-50 ${
                myEntry?.status === "watchlist"
                  ? "border-mv-gold/60 bg-mv-gold/15 text-mv-gold"
                  : "border-white/15 bg-white/5 text-white/70 hover:border-white/35"
              }`}
            >
              🔖 Watchlist
            </button>
            <button
              type="button"
              disabled={saving || pending}
              onClick={() => persist({ favorite: !myEntry?.favorite })}
              className={`cursor-pointer rounded-xl border px-3 py-2 text-[11px] font-bold uppercase tracking-wide transition active:scale-95 disabled:opacity-50 ${
                myEntry?.favorite
                  ? "border-mv-red/60 bg-mv-red/20 text-mv-red"
                  : "border-white/15 bg-white/5 text-white/70 hover:border-white/35"
              }`}
            >
              ♥ Preferito
            </button>
            {myEntry ? (
              <button
                type="button"
                disabled={saving || pending}
                onClick={async () => {
                  setSaving(true);
                  try {
                    await onRemove();
                    onClose();
                  } finally {
                    setSaving(false);
                  }
                }}
                className="ml-auto cursor-pointer rounded-xl border border-white/10 px-3 py-2 text-[11px] font-bold uppercase tracking-wide text-white/45 transition hover:border-mv-red/60 hover:text-mv-red disabled:opacity-50"
              >
                Rimuovi
              </button>
            ) : null}
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase tracking-widest text-white/40" htmlFor="review">
              La tua recensione
            </label>
            <textarea
              id="review"
              value={review}
              onChange={(event) => setReview(event.target.value)}
              rows={2}
              maxLength={600}
              placeholder="Cosa ne pensi? Una scena, un personaggio, un voto..."
              className="mt-1 w-full resize-none rounded-xl border border-white/10 bg-black/40 p-3 text-sm text-white placeholder:text-white/25 transition focus:border-mv-red/60 focus:outline-none"
            />
            <div className="mt-1.5 flex items-center justify-between gap-2">
              <span className="text-[10px] text-white/30">{review.length}/600</span>
              <button
                type="button"
                disabled={saving || pending}
                onClick={() => persist({ review })}
                className="cursor-pointer rounded-xl bg-mv-red px-4 py-2 text-[11px] font-black uppercase tracking-widest text-white transition hover:bg-mv-red-dark active:scale-95 disabled:opacity-50"
              >
                {saving ? "Salvo..." : "Salva recensione"}
              </button>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">
                Cosa ne pensano gli altri
              </p>
              {friendAvg !== null ? (
                <span className="text-[11px] font-bold text-mv-gold">media ★ {formatAvg(friendAvg)}</span>
              ) : null}
            </div>
            <div className="mt-2 space-y-1.5">
              {friends.length === 0 ? (
                <p className="rounded-xl border border-dashed border-white/10 p-3 text-xs text-white/35">
                  Nessun amico ha ancora segnato questo film. Tocca a te!
                </p>
              ) : (
                friends.map((friend) => (
                  <div
                    key={friend.member.id}
                    className="flex items-start gap-2.5 rounded-xl border border-white/8 bg-white/[0.03] p-2.5"
                  >
                    <span
                      className="grid h-7 w-7 shrink-0 place-items-center rounded-full text-xs"
                      style={{ backgroundColor: `${friend.member.color}26`, color: friend.member.color }}
                    >
                      {friend.member.avatar}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[11px] font-bold text-white">{friend.member.name}</span>
                        <Stars value={friend.entry.rating ?? 0} size="sm" readOnly />
                        {friend.entry.favorite ? <span className="text-[9px] text-mv-red">♥</span> : null}
                        {friend.entry.status === "watchlist" ? (
                          <span className="rounded bg-white/10 px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wide text-white/60">
                            watchlist
                          </span>
                        ) : null}
                      </div>
                      {friend.entry.review ? (
                        <p className="mt-0.5 text-[11px] leading-relaxed text-white/60">“{friend.entry.review}”</p>
                      ) : null}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
