import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Palmtree, 
  Sun, 
  MapPin, 
  ShieldAlert, 
  Send, 
  ArrowLeft, 
  ArrowRight,
  Sparkles,
  Crown
} from 'lucide-react';

export const HealingDestinationsSection: React.FC = () => {
  const { language, setCurrentView, openRequestModalForService, healingDestinations } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <section className="py-20 bg-black text-white border-b border-[#D4AF37]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 bg-zinc-900 text-amber-300 text-xs font-bold px-3.5 py-1.5 rounded-full mb-3 border border-[#D4AF37]/40 shadow-sm">
              <Sun className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{isAr ? 'الاستشفاء الطبيعي بمصر' : 'Natural Healing Sanctuaries'}</span>
            </div>
            <h2 className="text-3xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent">
              {isAr ? 'وجهات السياحة العلاجية والاستشفاء البيئي' : 'Curative Sanctuaries & Climatotherapy'}
            </h2>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">
              {isAr ? 'سيوة، أسوان، وسفاجا: برامج طبيعية معززة للصحة تحت إشراف طبي متخصص' : 'Complementary wellness modalities supervised by physicians'}
            </p>
          </div>

          <button
            onClick={() => {
              setCurrentView('tourism');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2 text-xs sm:text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors self-start md:self-auto"
          >
            <span>{isAr ? 'عرض تفاصيل كل الوجهات' : 'Explore all sanctuaries'}</span>
            <ArrowIcon className="w-4 h-4 text-[#D4AF37]" />
          </button>
        </div>

        {/* Advisory alert in Black & Gold */}
        <div className="bg-zinc-950/90 border border-[#D4AF37]/40 rounded-2xl p-4 flex items-start gap-3 text-xs text-amber-200/95 shadow-md">
          <ShieldAlert className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
          <div>
            <strong className="font-bold text-amber-300">{isAr ? 'تنويه طبي هام:' : 'Medical Transparency Notice:'}</strong>{' '}
            {isAr
              ? 'الأنشطة الاستشفائية البيئية والطبيعية هي برامج داعمة ومكملة لصحة الجسم والراحة النفسية، ولا تعد بديلاً عن الرعاية السريرية أو الأدوية الطبية المقررة.'
              : 'Natural environmental wellness therapies are supportive holistic modalities and never a replacement for clinical treatment or prescribed medication.'}
          </div>
        </div>

        {/* 3 Destinations Cards in Black & Gold */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {healingDestinations.map(dest => (
            <div 
              key={dest.id}
              className="bg-zinc-950/90 rounded-3xl border border-zinc-800 hover:border-[#D4AF37] overflow-hidden shadow-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.2)] transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={dest.imageUrl} 
                    alt={isAr ? dest.nameAr : dest.nameEn}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
                  <div className="absolute bottom-3 right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto text-white">
                    <span className="text-[11px] text-amber-300 font-semibold block">{dest.governorate}</span>
                    <h3 className="text-base font-bold text-white">{isAr ? dest.nameAr : dest.nameEn}</h3>
                  </div>
                </div>

                <div className="p-5 space-y-3">
                  <p className="text-xs text-zinc-400 leading-relaxed">
                    {isAr ? dest.climateBenefitAr : dest.climateBenefitEn}
                  </p>

                  <div className="text-[11px] text-amber-400 font-medium">
                    {isAr ? `الموسم المناسب: ${dest.seasonAr}` : `Prime Season: ${dest.seasonEn}`}
                  </div>
                </div>
              </div>

              <div className="p-5 pt-0">
                <button
                  onClick={() => openRequestModalForService('medical_tourism')}
                  className="w-full py-2.5 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20"
                >
                  <Send className="w-3.5 h-3.5 text-black" />
                  <span>{isAr ? 'طلب تنسيق برنامج استشفائي' : 'Request Program'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
