import { useEffect, useRef, useState } from "react";
import { ArrowUp, Menu, Mic, MicOff, Plus, Square, Volume2, X } from "lucide-react";
import { WakeEar, type Ear } from "@/lib/charlie/wake-ear";
import { MessageBody, SourceList } from "@/components/charlie/message-body";
import { apiUrl } from "@/lib/charlie/api-url";
import { useCharlie } from "@/lib/charlie/store";
import { DEFAULT_PROFILE, VOICES, type Citation, type Phase } from "@/lib/charlie/types";

const STARTERS = [
  {
    title: "Catch me up",
    text: "Catch me up on today's news like a friend would — a few things that actually matter.",
  },
  {
    title: "Help me decide",
    text: "Help me think something through. Start by asking what I'm stuck on.",
  },
  {
    title: "Worth knowing",
    text: "What's one thing worth knowing right now?",
  },
  {
    title: "Know me",
    text: "I want you to know me. Ask one good question.",
  },
];

function greeting(date = new Date()): string {
  const hour = date.getHours();
  if (hour < 5) return "Still up";
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

function speakable(text: string): string {
  return text
    .replace(/\[\[\d+\]\]\([^)]+\)/g, "")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/[*_`#>]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 700);
}

export function CharlieFrame() {
  return (
    <main className="flex min-h-dvh flex-col bg-canvas text-foreground">
      <header className="flex items-center gap-3 border-b border-line px-4 py-3">
        <Mark />
        <div>
          <p className="font-display text-xl leading-none">Charlie</p>
          <p className="text-sm text-muted">Best friend. Live web.</p>
        </div>
      </header>
      <div className="mx-auto flex w-full max-w-2xl flex-1 flex-col justify-center px-5 py-10">
        <p className="text-sm text-muted">Charlie</p>
        <h1 className="mt-2 font-display text-4xl font-medium tracking-tight text-balance">A friend who looks things up.</h1>
        <p className="mt-3 max-w-md text-muted">Ask anything. If it lives on the internet, Charlie will go find it.</p>
      </div>
    </main>
  );
}

function Mark({ live = false }: { live?: boolean }) {
  return (
    <div className="relative grid size-11 shrink-0 place-items-center" aria-hidden="true">
      <span className={`absolute inset-0 rounded-full border border-line ${live ? "presence-ring presence-live" : "presence-ring"}`} />
      <span className="absolute inset-1.5 rounded-full border border-line" />
      <span className="font-display text-lg leading-none">C</span>
    </div>
  );
}

export function CharlieApp() {
  const profile = useCharlie((s) => s.profile);
  const threads = useCharlie((s) => s.threads);
  const activeId = useCharlie((s) => s.activeId);
  const phase = useCharlie((s) => s.phase);
  const error = useCharlie((s) => s.error);
  const setProfile = useCharlie((s) => s.setProfile);
  const newThread = useCharlie((s) => s.newThread);
  const selectThread = useCharlie((s) => s.selectThread);
  const deleteThread = useCharlie((s) => s.deleteThread);
  const [draft, setDraft] = useState("");
  const [menu, setMenu] = useState(false);
  const [ear, setEar] = useState<Ear>("off");
  const [confirmForget, setConfirmForget] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioUrl = useRef<string | null>(null);
  const earRef = useRef<WakeEar | null>(null);
  const askRef = useRef<(text: string) => Promise<void>>(async () => {});

  const thread = threads.find((item) => item.id === activeId) ?? threads[0];

  useEffect(() => {
    useCharlie.getState().ensure();
    const saved = useCharlie.getState().profile;
    if (!VOICES.some((voice) => voice.id === saved.voiceId)) {
      useCharlie.getState().setProfile({ voiceId: "leo" });
    }
  }, []);

  useEffect(() => {
    const node = scroller.current;
    if (!node) return;
    node.scrollTop = node.scrollHeight;
  }, [thread?.messages, phase]);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
      audioRef.current?.pause();
      if (audioUrl.current) URL.revokeObjectURL(audioUrl.current);
      earRef.current?.stop();
    };
  }, []);

  useEffect(() => {
    const earEngine = new WakeEar(
      (text) => void askRef.current(text),
      setEar,
      () => useCharlie.getState().setError("Allow the microphone, then tap the mic so Charlie can wait for its name."),
    );
    earRef.current = earEngine;
    return () => {
      earEngine.stop();
      earRef.current = null;
    };
  }, []);

  useEffect(() => {
    const engine = earRef.current;
    if (!engine) return;
    if (profile.handsFree && phase === "idle") engine.arm(false);
    else engine.stop();
  }, [profile.handsFree, phase]);

  useEffect(() => {
    if (!menu) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenu(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menu]);

  async function speak(text: string) {
    const clean = speakable(text);
    if (!clean) return;
    const voiceId = useCharlie.getState().profile.voiceId;
    const res = await fetch(apiUrl("/api/speak"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: clean, voiceId }),
    });
    if (!res.ok) {
      useCharlie.getState().setError("Charlie couldn't speak just now.");
      return;
    }
    const blob = await res.blob();
    if (audioUrl.current) URL.revokeObjectURL(audioUrl.current);
    const url = URL.createObjectURL(blob);
    audioUrl.current = url;
    audioRef.current?.pause();
    const audio = new Audio(url);
    audioRef.current = audio;
    await new Promise<void>((resolve) => {
      audio.onended = () => resolve();
      audio.onerror = () => resolve();
      void audio.play().catch(() => {
        useCharlie.getState().setError("Tap hear on the reply if the browser blocked the voice.");
        resolve();
      });
    });
  }

  async function ask(raw: string) {
    const text = raw.trim();
    const state = useCharlie.getState();
    if (!text || state.phase !== "idle") return;
    earRef.current?.stop();
    setDraft("");
    state.setError(null);
    const threadId = state.ensure();
    const current = useCharlie.getState().threads.find((item) => item.id === threadId);
    const history = [...(current?.messages ?? []).slice(-11), { role: "user" as const, content: text }];
    const userId = crypto.randomUUID();
    const assistantId = crypto.randomUUID();
    const now = Date.now();
    state.pushMessages(threadId, [
      { id: userId, role: "user", content: text, createdAt: now },
      { id: assistantId, role: "assistant", content: "", createdAt: now },
    ]);
    state.setPhase("thinking");
    const controller = new AbortController();
    abortRef.current = controller;
    let full = "";
    let citations: Citation[] = [];
    let raf = 0;
    const paint = (next: string, nextCitations?: Citation[]) => {
      cancelAnimationFrame(raf);
      useCharlie.getState().patchMessage(threadId, assistantId, next, nextCitations);
    };
    try {
      const profileNow = useCharlie.getState().profile;
      const res = await fetch(apiUrl("/api/chat"), {
        method: "POST",
        signal: controller.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: threadId,
          profile: { name: profileNow.name, notes: profileNow.notes },
          messages: history,
        }),
      });
      const type = res.headers.get("content-type") ?? "";
      if (!res.ok || !res.body || !type.includes("text/event-stream")) {
        const body = (await res.json().catch(() => null)) as { error?: string } | null;
        throw new Error(body?.error || "Charlie couldn't answer.");
      }
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const blocks = buffer.split(/\r?\n\r?\n/);
        buffer = blocks.pop() ?? "";
        for (const block of blocks) {
          let event = "message";
          const data: string[] = [];
          for (const line of block.split(/\r?\n/)) {
            if (line.startsWith("event:")) event = line.slice(6).trim();
            else if (line.startsWith("data:")) data.push(line.slice(5).trim());
          }
          if (!data.length) continue;
          const payload = JSON.parse(data.join("\n")) as {
            text?: string;
            phase?: Phase;
            message?: string;
            citations?: Citation[];
          };
          if (event === "status" && (payload.phase === "thinking" || payload.phase === "searching")) {
            useCharlie.getState().setPhase(payload.phase);
          } else if (event === "delta" && payload.text) {
            full += payload.text;
            const snapshot = full;
            if (!raf) {
              raf = requestAnimationFrame(() => {
                raf = 0;
                paint(snapshot);
              });
            }
          } else if (event === "error" && payload.message) {
            useCharlie.getState().setError(payload.message);
          } else if (event === "done") {
            if (typeof payload.text === "string" && payload.text) full = payload.text;
            citations = payload.citations ?? [];
          }
        }
      }
      cancelAnimationFrame(raf);
      if (!full.trim()) {
        useCharlie.getState().dropMessage(threadId, assistantId);
        useCharlie.getState().setError("Charlie didn't have an answer. Try once more.");
      } else {
        paint(full, citations);
        if (useCharlie.getState().profile.speak) await speak(full);
      }
    } catch (err) {
      cancelAnimationFrame(raf);
      if (err instanceof DOMException && err.name === "AbortError") {
        if (!full.trim()) useCharlie.getState().dropMessage(threadId, assistantId);
        else paint(full, citations);
      } else {
        if (!full.trim()) useCharlie.getState().dropMessage(threadId, assistantId);
        else paint(full, citations);
        useCharlie.getState().setError(err instanceof Error ? err.message : "Charlie couldn't answer.");
      }
    } finally {
      useCharlie.getState().setPhase("idle");
      abortRef.current = null;
    }
  }

  askRef.current = ask;

  function stop() {
    abortRef.current?.abort();
    earRef.current?.stop();
  }

  function toggleVoice() {
    const live = profile.handsFree && ear !== "off";
    if (live) {
      setProfile({ handsFree: false });
      earRef.current?.stop();
      return;
    }
    setProfile({ handsFree: true, speak: true });
    earRef.current?.arm(true);
  }

  function forget() {
    if (!confirmForget) {
      setConfirmForget(true);
      return;
    }
    useCharlie.setState({ profile: DEFAULT_PROFILE, threads: [], activeId: "", error: null, phase: "idle" });
    useCharlie.getState().ensure();
    setConfirmForget(false);
    setMenu(false);
  }

  const busy = phase !== "idle";
  const hearing = ear === "hearing";
  const voiceLive = profile.handsFree && ear !== "off";
  const hello = profile.name.trim() ? `${greeting()}, ${profile.name.trim()}.` : `${greeting()}.`;
  const status = phase === "searching"
    ? "Looking that up"
    : phase === "thinking"
      ? "Thinking"
      : hearing
        ? "Listening"
        : profile.handsFree
          ? "Say Charlie"
          : "Here";

  return (
    <div className="flex min-h-dvh bg-canvas text-foreground">
      {menu ? (
        <button
          type="button"
          className="fixed inset-0 z-20 bg-canvas/80 lg:hidden"
          aria-label="Close menu"
          onClick={() => setMenu(false)}
        />
      ) : null}
      <aside
        className={`fixed inset-y-0 left-0 z-30 flex w-full max-w-80 flex-col border-r border-line bg-panel motion-safe:transition-transform motion-safe:duration-300 ${
          menu ? "translate-x-0" : "-translate-x-full"
        } lg:static lg:z-auto lg:translate-x-0`}
      >
        <div className="flex items-center gap-3 px-4 py-4">
          <Mark live={busy || hearing} />
          <div className="min-w-0 flex-1">
            <p className="font-display text-2xl leading-none">Charlie</p>
            <p className="mt-1 text-sm text-muted">Best friend. Live web.</p>
          </div>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-lg text-muted lg:hidden"
            aria-label="Close menu"
            onClick={() => setMenu(false)}
          >
            <X className="size-5" />
          </button>
        </div>
        <div className="px-4">
          <button
            type="button"
            onClick={() => {
              if (!busy) newThread();
              setMenu(false);
            }}
            className="flex min-h-11 w-full items-center justify-center gap-2 rounded-lg bg-accent px-3 text-sm font-medium text-accent-ink"
          >
            <Plus className="size-4" />
            New chat
          </button>
        </div>
        <div className="mt-4 min-h-0 flex-1 overflow-y-auto px-2">
          <p className="px-2 pb-2 text-sm text-faint">Chats</p>
          <ul className="space-y-1">
            {threads.map((item) => {
              const selected = item.id === thread?.id;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => {
                      selectThread(item.id);
                      setMenu(false);
                    }}
                    className={`flex min-h-11 w-full items-center rounded-lg px-3 text-left text-sm ${
                      selected ? "bg-wash text-foreground" : "text-muted hover:bg-wash hover:text-foreground"
                    }`}
                  >
                    <span className="truncate">{item.title}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
        <div className="space-y-3 border-t border-line p-4">
          <label className="block text-sm text-muted" htmlFor="charlie-name">
            What should Charlie call you?
            <input
              id="charlie-name"
              value={profile.name}
              maxLength={80}
              onChange={(event) => setProfile({ name: event.target.value })}
              placeholder="Your name"
              className="mt-1 min-h-11 w-full rounded-lg border border-line bg-canvas px-3 text-foreground placeholder:text-faint"
            />
          </label>
          <label className="block text-sm text-muted" htmlFor="charlie-notes">
            Remember this
            <textarea
              id="charlie-notes"
              value={profile.notes}
              maxLength={1200}
              rows={3}
              onChange={(event) => setProfile({ notes: event.target.value })}
              placeholder="The small stuff. The big stuff."
              className="mt-1 w-full resize-none rounded-lg border border-line bg-canvas px-3 py-2 text-foreground placeholder:text-faint"
            />
          </label>
          <div>
            <p className="text-sm text-muted">Voice</p>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {VOICES.map((voice) => {
                const on = profile.voiceId === voice.id;
                return (
                  <button
                    key={voice.id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => setProfile({ voiceId: voice.id })}
                    className={`min-h-11 rounded-lg border px-2 text-left ${
                      on ? "border-accent bg-wash text-foreground" : "border-line text-muted"
                    }`}
                  >
                    <span className="block text-sm font-medium">{voice.label}</span>
                    <span className="block text-sm text-faint">{voice.hint}</span>
                  </button>
                );
              })}
            </div>
          </div>
          <button
            type="button"
            aria-pressed={profile.speak}
            onClick={() => setProfile({ speak: !profile.speak })}
            className={`flex min-h-11 w-full items-center justify-between rounded-lg border px-3 text-sm ${
              profile.speak ? "border-accent bg-accent text-accent-ink" : "border-line text-muted"
            }`}
          >
            Speak replies
            <span>{profile.speak ? "On" : "Off"}</span>
          </button>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => thread && deleteThread(thread.id)}
              className="min-h-11 flex-1 rounded-lg border border-line px-2 text-sm text-muted"
            >
              Delete chat
            </button>
            <button
              type="button"
              onClick={forget}
              className="min-h-11 flex-1 rounded-lg border border-line px-2 text-sm text-danger"
            >
              {confirmForget ? "Yes, forget" : "Forget me"}
            </button>
          </div>
          <p className="text-sm text-faint">Kept on this device only.</p>
        </div>
      </aside>

      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-3 border-b border-line px-3 py-2 lg:px-6">
          <button
            type="button"
            className="grid size-11 place-items-center rounded-lg lg:hidden"
            aria-label="Open menu"
            onClick={() => setMenu(true)}
          >
            <Menu className="size-5" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-xl leading-none">{thread?.title ?? "Charlie"}</p>
            <p className="mt-1 text-sm text-muted" aria-live="polite">
              {busy || hearing ? <span className="shimmer-text">{status}</span> : status}
            </p>
          </div>
          <div className="hidden lg:block">
            <Mark live={busy || hearing} />
          </div>
        </header>

        <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto">
          <div className="mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 py-8">
            {!thread?.messages.length ? (
              <div className="py-8">
                <p className="text-sm text-muted">Charlie</p>
                <h1 className="mt-2 font-display text-4xl font-medium tracking-tight text-balance">{hello}</h1>
                <p className="mt-3 max-w-md text-pretty text-muted">
                  Say Charlie, then talk. It answers out loud and stops when you go quiet.
                </p>
                <div className="mt-8 grid gap-2 sm:grid-cols-2">
                  {STARTERS.map((starter) => (
                    <button
                      key={starter.title}
                      type="button"
                      disabled={busy}
                      onClick={() => void ask(starter.text)}
                      className="min-h-11 rounded-xl border border-line bg-panel px-4 py-3 text-left text-sm hover:bg-wash disabled:opacity-50"
                    >
                      {starter.title}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              thread.messages.map((message) =>
                message.role === "user" ? (
                  <div key={message.id} className="flex justify-end">
                    <p className="max-w-xl rounded-xl bg-wash px-4 py-3 text-pretty">{message.content}</p>
                  </div>
                ) : (
                  <article key={message.id} className="max-w-2xl">
                    {message.content ? (
                      <MessageBody text={message.content} />
                    ) : busy ? (
                      <p className="shimmer-text text-sm">{status}</p>
                    ) : null}
                    {message.citations ? <SourceList citations={message.citations} /> : null}
                    {message.content ? (
                      <button
                        type="button"
                        onClick={() => void speak(message.content)}
                        className="mt-3 inline-flex min-h-11 items-center gap-2 rounded-lg px-2 text-sm text-muted hover:text-foreground"
                      >
                        <Volume2 className="size-4" />
                        Hear this
                      </button>
                    ) : null}
                  </article>
                ),
              )
            )}
          </div>
        </div>

        <div className="border-t border-line px-3 py-3 lg:px-6">
          <div className="mx-auto w-full max-w-2xl">
            {error ? (
              <div className="mb-2 flex items-start justify-between gap-3 rounded-lg border border-line bg-panel px-3 py-2 text-sm text-danger">
                <p>{error}</p>
                <button type="button" className="min-h-11 shrink-0 text-muted" onClick={() => useCharlie.getState().setError(null)}>
                  Dismiss
                </button>
              </div>
            ) : null}
            <form
              className="flex items-end gap-2 rounded-xl border border-line bg-panel p-2"
              onSubmit={(event) => {
                event.preventDefault();
                void ask(draft);
              }}
            >
              <label className="sr-only" htmlFor="charlie-draft">
                Message Charlie
              </label>
              <textarea
                id="charlie-draft"
                value={draft}
                rows={1}
                maxLength={4000}
                disabled={hearing}
                placeholder={hearing ? "Listening…" : profile.handsFree ? "Say Charlie, or type" : "Talk to Charlie"}
                onChange={(event) => setDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    void ask(draft);
                  }
                }}
                className="max-h-40 min-h-11 flex-1 resize-none bg-transparent px-2 py-2 text-foreground placeholder:text-faint"
              />
              <button
                type="button"
                onClick={toggleVoice}
                aria-pressed={voiceLive}
                aria-label={voiceLive ? "Mute voice" : "Turn voice on"}
                className={`grid size-11 shrink-0 place-items-center rounded-lg border border-line ${
                  voiceLive ? "bg-accent text-accent-ink" : "text-muted"
                }`}
              >
                {voiceLive ? <Mic className="size-5" /> : <MicOff className="size-5" />}
              </button>
              {busy && !hearing ? (
                <button
                  type="button"
                  onClick={stop}
                  aria-label="Stop"
                  className="grid size-11 shrink-0 place-items-center rounded-lg bg-accent text-accent-ink"
                >
                  <Square className="size-4" />
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={!draft.trim() || hearing}
                  aria-label="Send"
                  className="grid size-11 shrink-0 place-items-center rounded-lg bg-accent text-accent-ink disabled:opacity-40"
                >
                  <ArrowUp className="size-5" />
                </button>
              )}
            </form>
            {profile.handsFree ? (
              <p className="mt-2 text-sm text-faint">
                {voiceLive
                  ? "Say Charlie, then talk. It stops when you go quiet."
                  : "Tap the mic once so Charlie can wait for its name."}
              </p>
            ) : null}
          </div>
        </div>
      </main>
    </div>
  );
}
