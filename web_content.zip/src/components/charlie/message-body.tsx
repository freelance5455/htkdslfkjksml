import type { ReactNode } from "react";
import type { Citation } from "@/lib/charlie/types";

type Block =
  | { kind: "p"; text: string }
  | { kind: "h"; text: string }
  | { kind: "ul"; items: string[] }
  | { kind: "ol"; items: string[] }
  | { kind: "code"; text: string };

function parseBlocks(source: string): Block[] {
  const lines = source.replace(/\r\n/g, "\n").split("\n");
  const blocks: Block[] = [];
  let paragraph: string[] = [];
  let list: { ordered: boolean; items: string[] } | null = null;
  let code: string[] | null = null;

  const flushParagraph = () => {
    if (!paragraph.length) return;
    blocks.push({ kind: "p", text: paragraph.join(" ") });
    paragraph = [];
  };
  const flushList = () => {
    if (!list) return;
    blocks.push(list.ordered ? { kind: "ol", items: list.items } : { kind: "ul", items: list.items });
    list = null;
  };

  for (const line of lines) {
    if (code) {
      if (line.trim().startsWith("```")) {
        blocks.push({ kind: "code", text: code.join("\n") });
        code = null;
      } else {
        code.push(line);
      }
      continue;
    }
    if (line.trim().startsWith("```")) {
      flushParagraph();
      flushList();
      code = [];
      continue;
    }
    const heading = /^(#{1,3})\s+(.+)$/.exec(line.trim());
    if (heading) {
      flushParagraph();
      flushList();
      blocks.push({ kind: "h", text: heading[2] });
      continue;
    }
    const bullet = /^[-*]\s+(.+)$/.exec(line.trim());
    const ordered = /^\d+[.)]\s+(.+)$/.exec(line.trim());
    if (bullet || ordered) {
      flushParagraph();
      const item = (bullet ?? ordered)![1];
      const isOrdered = Boolean(ordered);
      if (!list || list.ordered !== isOrdered) {
        flushList();
        list = { ordered: isOrdered, items: [item] };
      } else {
        list.items.push(item);
      }
      continue;
    }
    if (!line.trim()) {
      flushParagraph();
      flushList();
      continue;
    }
    flushList();
    paragraph.push(line.trim());
  }
  if (code) blocks.push({ kind: "code", text: code.join("\n") });
  flushParagraph();
  flushList();
  return blocks;
}

function inline(text: string, key: string): ReactNode[] {
  const re =
    /\[\[(\d+)\]\]\((https?:\/\/[^)\s]+)\)|\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)|\*\*([^*]+)\*\*|`([^`]+)`|\*([^*]+)\*/g;
  const nodes: ReactNode[] = [];
  let last = 0;
  let match: RegExpExecArray | null;
  let i = 0;
  while ((match = re.exec(text))) {
    if (match.index > last) nodes.push(text.slice(last, match.index));
    const id = `${key}-${i++}`;
    if (match[1] && match[2]) {
      nodes.push(
        <a key={id} href={match[2]} target="_blank" rel="noreferrer" className="text-muted underline underline-offset-2">
          {match[1]}
        </a>,
      );
    } else if (match[3] && match[4]) {
      nodes.push(
        <a key={id} href={match[4]} target="_blank" rel="noreferrer" className="underline underline-offset-2">
          {match[3]}
        </a>,
      );
    } else if (match[5]) {
      nodes.push(
        <strong key={id} className="font-medium">
          {match[5]}
        </strong>,
      );
    } else if (match[6]) {
      nodes.push(
        <code key={id} className="rounded-sm bg-wash px-1 font-mono text-sm">
          {match[6]}
        </code>,
      );
    } else if (match[7]) {
      nodes.push(
        <em key={id} className="italic">
          {match[7]}
        </em>,
      );
    }
    last = match.index + match[0].length;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return nodes;
}

export function MessageBody({ text }: { text: string }) {
  const blocks = parseBlocks(text);
  return (
    <div className="space-y-3 text-pretty">
      {blocks.map((block, index) => {
        const key = `b${index}`;
        if (block.kind === "h") {
          return (
            <h3 key={key} className="font-display text-lg font-medium tracking-tight text-balance">
              {inline(block.text, key)}
            </h3>
          );
        }
        if (block.kind === "ul" || block.kind === "ol") {
          const Tag = block.kind === "ol" ? "ol" : "ul";
          return (
            <Tag key={key} className={block.kind === "ol" ? "list-decimal space-y-1 pl-5" : "list-disc space-y-1 pl-5"}>
              {block.items.map((item, itemIndex) => (
                <li key={`${key}-${itemIndex}`}>{inline(item, `${key}-${itemIndex}`)}</li>
              ))}
            </Tag>
          );
        }
        if (block.kind === "code") {
          return (
            <pre key={key} className="overflow-x-auto rounded-lg bg-wash p-3 text-sm text-foreground">
              <code>{block.text}</code>
            </pre>
          );
        }
        return <p key={key}>{inline(block.text, key)}</p>;
      })}
    </div>
  );
}

export function SourceList({ citations }: { citations: Citation[] }) {
  if (!citations.length) return null;
  return (
    <ul className="mt-3 flex flex-wrap gap-2">
      {citations.map((citation) => (
        <li key={citation.url}>
          <a
            href={citation.url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex min-h-11 max-w-full items-center rounded-lg border border-line px-3 text-sm text-muted hover:text-foreground"
          >
            <span className="truncate">{citation.label}</span>
          </a>
        </li>
      ))}
    </ul>
  );
}
