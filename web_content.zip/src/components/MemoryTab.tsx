import React, { useState } from 'react';
import {
  Brain,
  Plus,
  Trash2,
  Sparkles,
  Clock,
  Briefcase,
  Target,
  Heart,
  Sliders,
  CheckCircle2,
  Lightbulb
} from 'lucide-react';
import { UserMemory, SupportedLanguage } from '../types';

interface MemoryTabProps {
  memories: UserMemory[];
  onAddMemory: (category: UserMemory['category'], fact: string) => void;
  onDeleteMemory: (id: string) => void;
  language: SupportedLanguage;
}

export const MemoryTab: React.FC<MemoryTabProps> = ({
  memories,
  onAddMemory,
  onDeleteMemory,
  language,
}) => {
  const [newFact, setNewFact] = useState('');
  const [newCategory, setNewCategory] = useState<UserMemory['category']>('Routine');
  const [activeFilter, setActiveFilter] = useState<string>('ALL');

  const handleAdd = () => {
    if (!newFact.trim()) return;
    onAddMemory(newCategory, newFact.trim());
    setNewFact('');
  };

  const getCategoryIcon = (category: UserMemory['category']) => {
    switch (category) {
      case 'Routine':
        return <Clock className="w-3.5 h-3.5 text-cyan-400" />;
      case 'Work':
        return <Briefcase className="w-3.5 h-3.5 text-blue-400" />;
      case 'Goal':
        return <Target className="w-3.5 h-3.5 text-emerald-400" />;
      case 'Preference':
        return <Sliders className="w-3.5 h-3.5 text-purple-400" />;
      case 'Personal':
        return <Heart className="w-3.5 h-3.5 text-rose-400" />;
      default:
        return <Brain className="w-3.5 h-3.5 text-cyan-400" />;
    }
  };

  const filteredMemories =
    activeFilter === 'ALL'
      ? memories
      : memories.filter((m) => m.category === activeFilter);

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div className="bg-gradient-to-r from-cyan-950/60 via-slate-900 to-purple-950/40 border border-cyan-500/30 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-500 text-slate-950 flex items-center justify-center font-bold shadow-lg shadow-cyan-500/20">
            <Brain className="w-6 h-6 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white">DOST Mind & Memory Core</h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/40">
                {memories.length} Active Memories
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'roman_urdu'
                ? 'DOST aap ke baray mein sab kuch yaad rakhta hai: Routine, crypto habits, aur daily life.'
                : 'DOST remembers everything about you: routines, preferences, goals, and habits.'}
            </p>
          </div>
        </div>
      </div>

      {/* Auto-Memory Intelligence Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 flex items-start gap-3 text-xs">
        <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-semibold text-slate-200 block">Automatic Learning:</span>
          <p className="text-slate-400 leading-relaxed text-[11px]">
            Jab bhi aap chat ya voice mein apna koi mamool, pasand, ya routine batayenge (maslan: <em>"Main subah 9 baje office jata hoon"</em> ya <em>"Mujhe Bitcoin scalping pasand hai"</em>), DOST AI usko khud apne mind mein store kar leta hai.
          </p>
        </div>
      </div>

      {/* Add New Memory Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>DOST Ko Apne Baare Mein Batayein (Teach DOST)</span>
        </h3>

        <div className="flex gap-2">
          <select
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value as UserMemory['category'])}
            className="bg-slate-950 border border-slate-800 text-xs rounded-xl px-2.5 py-2 text-cyan-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="Routine">Daily Routine</option>
            <option value="Preference">Preference / Habit</option>
            <option value="Goal">Goal / Ambition</option>
            <option value="Work">Work / Study</option>
            <option value="Personal">Personal Life</option>
          </select>

          <input
            type="text"
            placeholder={
              language === 'roman_urdu'
                ? 'Misaal: Main roz raat 12 baje crypto chart dekhta hoon...'
                : 'Example: I prefer trading Solana with 2% risk...'
            }
            value={newFact}
            onChange={(e) => setNewFact(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          />

          <button
            onClick={handleAdd}
            disabled={!newFact.trim()}
            className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-md shadow-cyan-500/20"
          >
            <Plus className="w-3.5 h-3.5" /> Yaad Rakho
          </button>
        </div>
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs">
        {['ALL', 'Routine', 'Preference', 'Goal', 'Work', 'Personal'].map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveFilter(cat)}
            className={`px-3 py-1 rounded-full whitespace-nowrap transition-colors ${
              activeFilter === cat
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Stored Memory List */}
      <div className="space-y-2">
        {filteredMemories.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-xs">
            <Brain className="w-8 h-8 mx-auto mb-2 text-slate-700" />
            <span>Abhi is category mein koi memory nahi hai. Upar se add karein.</span>
          </div>
        ) : (
          filteredMemories.map((mem) => (
            <div
              key={mem.id}
              className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-xl p-3 flex items-start justify-between gap-3 text-xs transition-all"
            >
              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-lg bg-slate-950 flex items-center justify-center shrink-0 border border-slate-800">
                  {getCategoryIcon(mem.category)}
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">
                      {mem.category}
                    </span>
                    <span className="text-[10px] text-slate-500">
                      Learned: {new Date(mem.learnedAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-slate-200 text-xs leading-relaxed font-medium">{mem.fact}</p>
                </div>
              </div>

              <button
                onClick={() => onDeleteMemory(mem.id)}
                className="text-slate-600 hover:text-red-400 p-1 transition-colors"
                title="Forget this memory"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
