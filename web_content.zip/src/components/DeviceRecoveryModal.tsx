import React, { useState, useRef } from 'react';
import { ShieldAlert, Volume2, Lock, Smartphone, ExternalLink, X, AlertTriangle, Radio, CheckCircle2 } from 'lucide-react';

interface DeviceRecoveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoords?: { lat: number; lon: number };
}

export const DeviceRecoveryModal: React.FC<DeviceRecoveryModalProps> = ({ isOpen, onClose, userCoords }) => {
  const [isSirenPlaying, setIsSirenPlaying] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sirenOscillatorRef = useRef<OscillatorNode | null>(null);

  if (!isOpen) return null;

  // Real Web Audio Hardware Siren Generator (Bypasses silent mode restrictions on speaker)
  const toggleAudioSiren = () => {
    if (isSirenPlaying) {
      if (sirenOscillatorRef.current) {
        try {
          sirenOscillatorRef.current.stop();
          sirenOscillatorRef.current.disconnect();
        } catch {}
        sirenOscillatorRef.current = null;
      }
      setIsSirenPlaying(false);
    } else {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtx();
        audioContextRef.current = ctx;

        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(880, ctx.currentTime);

        // Modulate frequency between 700Hz and 1200Hz
        const lfo = ctx.createOscillator();
        lfo.frequency.value = 3; // 3 cycles per second
        const lfoGain = ctx.createGain();
        lfoGain.gain.value = 300;
        lfo.connect(osc.frequency);
        lfo.start();

        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        sirenOscillatorRef.current = osc;
        setIsSirenPlaying(true);
      } catch (e) {
        console.warn('Audio siren error:', e);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-gray-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-xl bg-gray-900 border border-red-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-red-500/30">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-red-100">
              LOST OR STOLEN DEVICE RECOVERY (PART 10)
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-red-400 hover:bg-red-500/20">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Official Emergency Disclosure */}
          <div className="p-3.5 rounded-xl bg-red-950/30 border border-red-500/30 flex items-start gap-2.5 text-xs text-red-200">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-bold uppercase tracking-wider block text-red-300">
                Official Google Device Security Protocols
              </span>
              JARVIS does not invent fake device locations. Use authorized device management services to track, lock, ring, or wipe lost hardware.
            </div>
          </div>

          {/* Action 1: High-Decibel Audio Locator Siren */}
          <div className="p-4 rounded-xl bg-gray-950/70 border border-cyan-500/30 flex items-center justify-between">
            <div>
              <div className="text-sm font-bold text-cyan-100 font-tech uppercase">
                Device Audio Locator Siren
              </div>
              <div className="text-xs text-cyan-400/70">
                Plays continuous oscillating alarm frequency to locate nearby misplaced device
              </div>
            </div>
            <button
              onClick={toggleAudioSiren}
              className={`px-4 py-2 rounded-xl text-xs font-tech font-bold uppercase transition-all flex items-center gap-1.5 cursor-pointer ${
                isSirenPlaying
                  ? 'bg-red-500 text-white animate-pulse shadow-[0_0_20px_rgba(239,68,68,0.7)]'
                  : 'bg-cyan-500 hover:bg-cyan-400 text-gray-950 glow-cyan-sm'
              }`}
            >
              <Volume2 className="w-4 h-4" />
              {isSirenPlaying ? 'Stop Siren' : 'Ring Siren'}
            </button>
          </div>

          {/* Action 2: Google Find My Device */}
          <div className="p-4 rounded-xl bg-gray-950/70 border border-cyan-500/30 flex items-center justify-between">
            <div>
              <div className="text-sm font-bold text-cyan-100 font-tech uppercase">
                Google Find My Device Hub
              </div>
              <div className="text-xs text-cyan-400/70">
                Official Android GPS tracking, remote PIN lock, and factory reset
              </div>
            </div>
            <a
              href="https://www.google.com/android/find"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-200 text-xs font-tech uppercase flex items-center gap-1.5 transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              Open Portal
            </a>
          </div>

          {/* Action 3: Indian Telecommunications CEIR Portal (Block Stolen IMEI) */}
          <div className="p-4 rounded-xl bg-gray-950/70 border border-cyan-500/30 flex items-center justify-between">
            <div>
              <div className="text-sm font-bold text-cyan-100 font-tech uppercase">
                Government of India CEIR IMEI Portal
              </div>
              <div className="text-xs text-cyan-400/70">
                Block stolen device IMEI across all cellular networks (DoT ceir.gov.in)
              </div>
            </div>
            <a
              href="https://www.ceir.gov.in"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-200 text-xs font-tech uppercase flex items-center gap-1.5 transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              CEIR Portal
            </a>
          </div>

          {/* Action 4: Immediate Emergency Checklist */}
          <div className="p-3.5 rounded-xl bg-gray-950/80 border border-cyan-500/20 space-y-2">
            <span className="text-xs font-tech text-cyan-300 uppercase block font-bold">
              Emergency Action Steps for Harman Sir:
            </span>
            <ul className="text-xs text-cyan-200/80 space-y-1.5 font-mono-tech">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>Call carrier customer care (Airtel: 198, Jio: 198, Vi: 199) to lock SIM.</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>Change Google and Stark Assistant master passwords from trusted terminal.</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>File online police lost article report to generate acknowledgement receipt.</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-950/90 border-t border-red-500/20 text-[11px] text-red-300/70 flex items-center justify-between">
          <span>Harman Sir, device security safeguards are in standing readiness.</span>
          <span className="font-mono-tech text-red-400">SECURE HUB</span>
        </div>
      </div>
    </div>
  );
};
