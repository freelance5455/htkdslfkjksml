import React from 'react';
import { X, Trophy, Clock } from 'lucide-react';
import { HighScoreRecord } from '../types/game';

interface HighScoresModalProps {
  scores: HighScoreRecord[];
  onClose: () => void;
  onClear: () => void;
}

export const HighScoresModal: React.FC<HighScoresModalProps> = ({
  scores,
  onClose,
  onClear,
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 10);
    return `${mins}m ${secs}.${ms}s`;
  };

  return (
    <div className="absolute inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl text-left space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center space-x-2">
            <Trophy className="w-6 h-6 text-yellow-400" />
            <span>High Scores & Escapes</span>
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {scores.length === 0 ? (
          <div className="py-8 text-center text-slate-400 space-y-2">
            <span className="text-3xl block">🐔💨</span>
            <p className="font-semibold text-sm">No recorded escapes yet!</p>
            <p className="text-xs text-slate-500">Reach the central portal to record your high score.</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {scores.map((record, idx) => (
              <div
                key={record.id || idx}
                className={`p-3 rounded-xl border flex items-center justify-between ${
                  idx === 0
                    ? 'bg-amber-500/10 border-amber-500/40 text-amber-200'
                    : 'bg-slate-800/50 border-slate-700 text-slate-300'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <span
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                      idx === 0
                        ? 'bg-yellow-400 text-slate-950'
                        : idx === 1
                        ? 'bg-slate-300 text-slate-950'
                        : idx === 2
                        ? 'bg-amber-700 text-white'
                        : 'bg-slate-700 text-slate-300'
                    }`}
                  >
                    {idx + 1}
                  </span>
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="font-mono-num font-bold text-sm text-white">
                        {record.score.toLocaleString()} pts
                      </span>
                      <span className="text-[10px] uppercase font-extrabold px-1.5 py-0.2 rounded-sm bg-slate-800 text-slate-400">
                        {record.difficulty}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 flex items-center space-x-1 mt-0.5">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>{formatTime(record.timeSeconds)}</span>
                      <span>•</span>
                      <span>{record.date}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-center space-x-2 pt-2">
          {scores.length > 0 && (
            <button
              onClick={onClear}
              className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-400 hover:text-red-400 transition"
            >
              Clear Records
            </button>
          )}
          <button
            onClick={onClose}
            className="flex-1 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
