import React from 'react';
import { ArrowRight, Tag } from 'lucide-react';
import { useScrollReveal } from '../../hooks/useScrollReveal';
import { useTouchCarousel } from '../../hooks/useTouchCarousel';

export interface OfferCardData {
  id: string;
  badge: string;
  title: string;
  subtitle: string;
  ctaText: string;
  categoryTarget: string;
  image: string;
}

export const TOP_OFFER_CARDS: OfferCardData[] = [
  {
    id: 'offer-1',
    badge: 'Min. 50% OFF',
    title: 'Footwear Mania',
    subtitle: 'Sandals & chappals',
    ctaText: 'Grab Deal',
    categoryTarget: 'Men',
    image: 'https://images.unsplash.com/photo-1607522370275-f14206abe5d3?w=500&auto=format&fit=crop&q=80',
  },
  {
    id: 'offer-2',
    badge: 'Special Offers',
    title: 'Urban Backpacks',
    subtitle: 'Laptop & travel bags',
    ctaText: 'Shop 40% Off',
    categoryTarget: 'Bags',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&auto=format&fit=crop&q=80',
  },
  {
    id: 'offer-3',
    badge: 'Limited Time Deal',
    title: 'Comfy Slippers',
    subtitle: 'Everyday cloud foam',
    ctaText: 'View Deals',
    categoryTarget: 'Men',
    image: 'https://images.unsplash.com/photo-1603487742131-4160ec999306?w=500&auto=format&fit=crop&q=80',
  },
  {
    id: 'offer-4',
    badge: 'Extra Discount',
    title: 'Women Chic Edit',
    subtitle: 'Sandals & handbags',
    ctaText: 'Explore Now',
    categoryTarget: 'Women',
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=500&auto=format&fit=crop&q=80',
  },
];

interface TopOffersProps {
  onSelectOffer: (categoryTarget: string) => void;
}

export const TopOffers: React.FC<TopOffersProps> = ({ onSelectOffer }) => {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });
  const { containerRef, isDragging } = useTouchCarousel();

  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2 sm:py-3">
      <div
        className={`bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 border border-[#EAEAEA] shadow-2xs relative transition-all duration-500 ease-out ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
        }`}
      >
        {/* Section Header */}
        <div className="flex items-center justify-between mb-3 sm:mb-4">
          <div className="flex items-center gap-2">
            <div className="w-2 h-5 bg-[#FFD400] rounded-full" />
            <div>
              <h2 className="text-base sm:text-lg md:text-xl font-black text-[#111111] tracking-tight leading-tight">
                Top Offers & Deals
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1 text-[11px] font-bold text-[#666666]">
            <Tag className="w-3.5 h-3.5 text-[#000000]" />
            <span>Limited Stock</span>
          </div>
        </div>

        {/* Horizontally scrollable promotional cards */}
        <div
          ref={containerRef}
          className="flex gap-3 sm:gap-4 overflow-x-auto scrollbar-none scroll-smooth py-1 px-0.5 carousel-touch-container"
          style={{
            WebkitOverflowScrolling: 'touch',
            touchAction: 'pan-x pan-y pinch-zoom',
            overscrollBehaviorX: 'auto',
            overscrollBehaviorY: 'auto',
          }}
        >
          {TOP_OFFER_CARDS.map((card) => (
            <div
              key={card.id}
              onClick={() => {
                if (!isDragging.current) onSelectOffer(card.categoryTarget);
              }}
              className="group relative flex-shrink-0 w-[170px] xs:w-[190px] sm:w-[240px] rounded-xl sm:rounded-2xl bg-white border border-[#EAEAEA] hover:border-[#000000] p-3 cursor-pointer select-none transition-colors duration-200 flex flex-col justify-between carousel-card-touch"
              style={{
                touchAction: 'pan-y pinch-zoom',
              }}
            >
              <div>
                {/* Yellow Brand Offer Badge */}
                <div className="inline-flex items-center px-2 py-0.5 rounded bg-[#FFD400] text-[#000000] text-[10px] font-black tracking-wide uppercase shadow-2xs mb-2">
                  {card.badge}
                </div>

                {/* Product Image */}
                <div
                  className="w-full h-[115px] sm:h-[135px] rounded-lg sm:rounded-xl overflow-hidden bg-[#FAFAFA] my-1.5 flex items-center justify-center border border-[#EAEAEA]"
                  style={{ touchAction: 'pan-y pinch-zoom' }}
                >
                  <img
                    src={card.image}
                    alt={card.title}
                    draggable={false}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300 pointer-events-none select-none"
                    style={{ touchAction: 'pan-y pinch-zoom' }}
                    loading="lazy"
                  />
                </div>
              </div>

              {/* Title, Subtitle & CTA */}
              <div className="mt-1">
                <h3 className="font-black text-xs sm:text-sm tracking-tight truncate leading-tight text-[#111111]">
                  {card.title}
                </h3>
                <p className="text-[11px] text-[#666666] truncate mt-0.5">
                  {card.subtitle}
                </p>
                <div className="mt-2 flex items-center gap-1 text-[11px] font-black text-[#000000] group-hover:text-[#FFC800]">
                  <span>{card.ctaText}</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform text-[#FFD400]" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TopOffers;
