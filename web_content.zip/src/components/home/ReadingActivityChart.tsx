/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { ReadingSession } from '../../types';
import { BarChart2 } from 'lucide-react';

interface ReadingActivityChartProps {
  sessions: ReadingSession[];
}

export const ReadingActivityChart: React.FC<ReadingActivityChartProps> = ({ sessions }) => {
  const [rangeDays, setRangeDays] = useState<7 | 14>(7);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  // Compute daily totals for the past N days based on real session records
  const chartData = useMemo(() => {
    const days: { dateStr: string; label: string; weekday: string; pages: number; minutes: number }[] = [];
    const today = new Date();

    for (let i = rangeDays - 1; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const isoDate = d.toISOString().slice(0, 10);

      // Find all sessions on this exact day
      const daySessions = sessions.filter((s) => s.date === isoDate);
      const dayPages = daySessions.reduce((acc, s) => acc + (s.pagesRead || 0), 0);
      const dayMinutes = daySessions.reduce((acc, s) => acc + (s.durationMinutes || 0), 0);

      const weekday = new Intl.DateTimeFormat('es-ES', { weekday: 'short' }).format(d);
      const dayNum = d.getDate();

      days.push({
        dateStr: isoDate,
        label: `${dayNum} ${new Intl.DateTimeFormat('es-ES', { month: 'short' }).format(d)}`,
        weekday: weekday.charAt(0).toUpperCase() + weekday.slice(1, 3),
        pages: dayPages,
        minutes: dayMinutes,
      });
    }

    return days;
  }, [sessions, rangeDays]);

  const maxPages = useMemo(() => {
    const max = Math.max(...chartData.map((d) => d.pages), 10);
    return Math.ceil(max / 10) * 10;
  }, [chartData]);

  const totalPagesInRange = useMemo(() => {
    return chartData.reduce((acc, d) => acc + d.pages, 0);
  }, [chartData]);

  const totalMinutesInRange = useMemo(() => {
    return chartData.reduce((acc, d) => acc + d.minutes, 0);
  }, [chartData]);

  return (
    <div className="glass-panel rounded-2xl p-4 sm:p-5 border border-white/[0.08] space-y-4">
      {/* Header with Range Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-zinc-300" />
          <h3 className="text-xs font-bold tracking-wider uppercase text-zinc-400">
            Actividad de Lectura
          </h3>
          <span className="text-[11px] font-mono text-white/90 bg-white/10 px-2 py-0.5 rounded-lg border border-white/10 font-semibold">
            {totalPagesInRange} págs · {totalMinutesInRange} min
          </span>
        </div>

        <div className="flex items-center gap-1 self-start sm:self-auto bg-white/[0.04] p-0.5 rounded-xl border border-white/10 text-xs">
          <button
            type="button"
            onClick={() => setRangeDays(7)}
            className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
              rangeDays === 7 ? 'bg-white/20 text-white shadow-sm' : 'text-zinc-400 hover:text-white'
            }`}
          >
            7 días
          </button>
          <button
            type="button"
            onClick={() => setRangeDays(14)}
            className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
              rangeDays === 14 ? 'bg-white/20 text-white shadow-sm' : 'text-zinc-400 hover:text-white'
            }`}
          >
            14 días
          </button>
        </div>
      </div>

      {/* Visual Chart Canvas */}
      <div className="relative pt-2">
        {/* Subtle grid lines */}
        <div className="absolute inset-x-0 top-2 bottom-8 flex flex-col justify-between pointer-events-none opacity-15">
          <div className="border-b border-white border-dashed w-full" />
          <div className="border-b border-white border-dashed w-full" />
          <div className="border-b border-white border-dashed w-full" />
        </div>

        {/* Bars Container */}
        <div className="relative h-40 flex items-end justify-between gap-1.5 sm:gap-2 px-1 pb-6">
          {chartData.map((d, idx) => {
            const heightPercent = maxPages > 0 ? Math.round((d.pages / maxPages) * 100) : 0;
            const isHovered = hoveredIndex === idx;
            const hasActivity = d.pages > 0;

            return (
              <div
                key={d.dateStr}
                className="flex-1 flex flex-col items-center h-full justify-end group cursor-pointer relative"
                onMouseEnter={() => setHoveredIndex(idx)}
                onMouseLeave={() => setHoveredIndex(null)}
                onTouchStart={() => setHoveredIndex(idx)}
              >
                {/* Floating tooltip */}
                {isHovered && (
                  <div className="absolute -top-12 z-20 px-2.5 py-1 rounded-xl glass-panel border border-white/20 text-[10px] text-white whitespace-nowrap shadow-xl animate-fadeIn pointer-events-none text-center">
                    <span className="font-bold block">{d.label}</span>
                    <span className="text-zinc-300 font-mono">
                      {d.pages} {d.pages === 1 ? 'pág' : 'págs'} · {d.minutes}m
                    </span>
                  </div>
                )}

                {/* Bar */}
                <div className="w-full max-w-[28px] h-full flex items-end">
                  <div
                    className={`w-full rounded-t-lg transition-all duration-300 ${
                      hasActivity
                        ? isHovered
                          ? 'bg-gradient-to-t from-zinc-200 to-white shadow-[0_0_12px_rgba(255,255,255,0.5)]'
                          : 'bg-gradient-to-t from-white/20 to-white/80 group-hover:from-white/30 group-hover:to-white'
                        : 'bg-white/[0.04] h-1.5 rounded-full'
                    }`}
                    style={{
                      height: hasActivity ? `${Math.max(12, heightPercent)}%` : '4px',
                    }}
                  />
                </div>

                {/* X-axis Label */}
                <span
                  className={`text-[9.5px] sm:text-[10px] mt-2 transition-colors truncate max-w-full text-center ${
                    isHovered ? 'text-white font-bold' : hasActivity ? 'text-zinc-300' : 'text-zinc-500'
                  }`}
                >
                  {rangeDays === 14 && idx % 2 !== 0 ? '' : d.weekday}
                </span>
              </div>
            );
          })}
        </div>

        {/* Bottom baseline caption */}
        <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-1 border-t border-white/[0.06] px-1 font-mono">
          <span>0 págs</span>
          <span>Máx: {maxPages} págs/día</span>
        </div>
      </div>
    </div>
  );
};
