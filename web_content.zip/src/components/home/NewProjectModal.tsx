import React, { useState, useRef } from 'react';
import { X, Youtube, Instagram, Film, Smartphone, Sparkles, Video, Camera, Music, Upload, Monitor } from 'lucide-react';
import { Language, translations } from '../../i18n/translations';
import { AspectRatioType, Project, Track, Clip } from '../../types/editor';
import { generateSampleVideoCanvas, BUILTIN_FILTERS } from '../../services/sampleMedia';

interface NewProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onCreateProject: (project: Project) => void;
}

export const NewProjectModal: React.FC<NewProjectModalProps> = ({
  isOpen,
  onClose,
  language,
  onCreateProject,
}) => {
  const [projectName, setProjectName] = useState('My Clipora Project');
  const [aspectRatio, setAspectRatio] = useState<AspectRatioType>('9:16');
  const [customW, setCustomW] = useState(1080);
  const [customH, setCustomH] = useState(1920);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isRecordingCamera, setIsRecordingCamera] = useState(false);
  const [isGeneratingSample, setIsGeneratingSample] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraVideoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const cameraChunksRef = useRef<Blob[]>([]);

  if (!isOpen) return null;
  const t = translations[language];

  const presets = [
    { ratio: '9:16' as AspectRatioType, name: '9:16 Reels / Shorts / TikTok', icon: Smartphone, platform: 'Reels / Shorts' },
    { ratio: '16:9' as AspectRatioType, name: '16:9 YouTube / Landscape', icon: Youtube, platform: 'YouTube' },
    { ratio: '1:1' as AspectRatioType, name: '1:1 Square Post', icon: Instagram, platform: 'Instagram' },
    { ratio: '4:5' as AspectRatioType, name: '4:5 Portrait Feed', icon: Instagram, platform: 'IG Feed' },
    { ratio: '4:3' as AspectRatioType, name: '4:3 Classic TV', icon: Film, platform: 'Classic' },
    { ratio: 'custom' as AspectRatioType, name: 'Custom Resolution', icon: Monitor, platform: 'Custom' },
  ];

  // Helper to create empty track skeleton
  const createBaseTracks = (): Track[] => [
    { id: 'track_main_video', name: 'Main Video', type: 'video', locked: false, visible: true, muted: false, volume: 1.0 },
    { id: 'track_overlay_pip', name: 'Overlay / PIP', type: 'overlay', locked: false, visible: true, muted: false, volume: 1.0 },
    { id: 'track_text_1', name: 'Titles & Text', type: 'text', locked: false, visible: true, muted: false, volume: 1.0 },
    { id: 'track_stickers_1', name: 'Stickers & Badges', type: 'sticker', locked: false, visible: true, muted: false, volume: 1.0 },
    { id: 'track_audio_bgm', name: 'Audio & Music', type: 'audio', locked: false, visible: true, muted: false, volume: 1.0 },
  ];

  const handleCreateEmpty = () => {
    const project: Project = {
      id: `project_${Date.now()}`,
      name: projectName.trim() || 'Untitled Project',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      aspectRatio,
      customWidth: aspectRatio === 'custom' ? customW : undefined,
      customHeight: aspectRatio === 'custom' ? customH : undefined,
      duration: 5.0,
      fps: 30,
      background: { type: 'color', color: '#000000' },
      tracks: createBaseTracks(),
      clips: [],
    };
    onCreateProject(project);
    onClose();
  };

  const handleStartWithSample = async () => {
    setIsGeneratingSample(true);
    try {
      const vidBlob = await generateSampleVideoCanvas(
        aspectRatio === '9:16' ? 360 : 640,
        aspectRatio === '9:16' ? 640 : 360,
        'nature',
        5
      );
      const vidUrl = URL.createObjectURL(vidBlob);

      const defaultClip: Clip = {
        id: `clip_${Date.now()}`,
        trackId: 'track_main_video',
        trackType: 'video',
        name: 'Nature Horizon',
        type: 'video',
        sourceUrl: vidUrl,
        blob: vidBlob,
        start: 0,
        duration: 5,
        sourceStart: 0,
        sourceDuration: 5,
        speed: 1.0,
        reverse: false,
        x: 0,
        y: 0,
        scale: 1.0,
        rotation: 0,
        opacity: 1.0,
        flipH: false,
        flipV: false,
        blendMode: 'normal',
        volume: 1.0,
        muted: false,
        fadeIn: 0.3,
        fadeOut: 0.3,
        adjustments: {
          brightness: 0,
          contrast: 10,
          saturation: 15,
          exposure: 0,
          highlights: 0,
          shadows: 0,
          temperature: 5,
          tint: 0,
          sharpness: 20,
          vignette: 10,
          grain: 0,
          hue: 0,
        },
        filter: BUILTIN_FILTERS[0],
        effects: [],
        mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
        chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
        keyframes: [],
      };

      const project: Project = {
        id: `project_${Date.now()}`,
        name: projectName.trim() || 'New Sample Project',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        aspectRatio,
        duration: 5.0,
        fps: 30,
        background: { type: 'color', color: '#000000' },
        tracks: createBaseTracks(),
        clips: [defaultClip],
      };

      onCreateProject(project);
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingSample(false);
    }
  };

  const handleDeviceFilesUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const clips: Clip[] = [];
    let currentStart = 0;

    Array.from(files).forEach((file, index) => {
      const url = URL.createObjectURL(file);
      const isVideo = file.type.startsWith('video');
      const isAudio = file.type.startsWith('audio');
      const isImage = file.type.startsWith('image');
      const duration = isImage ? 4 : 5;

      const trackId = isAudio ? 'track_audio_bgm' : 'track_main_video';
      const trackType = isAudio ? 'audio' : 'video';

      clips.push({
        id: `clip_${Date.now()}_${index}`,
        trackId,
        trackType,
        name: file.name.substring(0, 20),
        type: isVideo ? 'video' : isImage ? 'image' : 'audio',
        sourceUrl: url,
        blob: file,
        start: currentStart,
        duration,
        sourceStart: 0,
        sourceDuration: duration,
        speed: 1.0,
        reverse: false,
        x: 0,
        y: 0,
        scale: 1.0,
        rotation: 0,
        opacity: 1.0,
        flipH: false,
        flipV: false,
        blendMode: 'normal',
        volume: 1.0,
        muted: false,
        fadeIn: 0,
        fadeOut: 0,
        adjustments: {
          brightness: 0,
          contrast: 0,
          saturation: 0,
          exposure: 0,
          highlights: 0,
          shadows: 0,
          temperature: 0,
          tint: 0,
          sharpness: 0,
          vignette: 0,
          grain: 0,
          hue: 0,
        },
        effects: [],
        mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
        chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
        keyframes: [],
      });

      if (!isAudio) {
        currentStart += duration;
      }
    });

    const project: Project = {
      id: `project_${Date.now()}`,
      name: projectName.trim() || 'My Media Project',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      aspectRatio,
      duration: Math.max(5, currentStart),
      fps: 30,
      background: { type: 'color', color: '#000000' },
      tracks: createBaseTracks(),
      clips,
    };

    onCreateProject(project);
    onClose();
  };

  // Camera capture modal helpers
  const startCamera = async () => {
    setCameraError(null);
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' },
        audio: true,
      });
      if (cameraVideoRef.current) {
        cameraVideoRef.current.srcObject = stream;
        cameraVideoRef.current.play();
      }
    } catch (e) {
      setCameraError(language === 'hi' ? 'कैमरा या माइक्रोफ़ोन शुरू करने में असमर्थ। कृपया अनुमति दें।' : 'Could not access camera/microphone.');
      setIsCameraActive(false);
    }
  };

  const startCameraRecording = () => {
    if (!cameraVideoRef.current || !cameraVideoRef.current.srcObject) return;
    const stream = cameraVideoRef.current.srcObject as MediaStream;
    cameraChunksRef.current = [];
    const rec = new MediaRecorder(stream);
    rec.ondataavailable = (e) => {
      if (e.data.size > 0) cameraChunksRef.current.push(e.data);
    };
    rec.start();
    mediaRecorderRef.current = rec;
    setIsRecordingCamera(true);
  };

  const stopCameraRecording = () => {
    if (!mediaRecorderRef.current) return;
    mediaRecorderRef.current.onstop = () => {
      const blob = new Blob(cameraChunksRef.current, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      
      // Stop stream tracks
      if (cameraVideoRef.current && cameraVideoRef.current.srcObject) {
        (cameraVideoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      }
      setIsCameraActive(false);
      setIsRecordingCamera(false);

      const recordedClip: Clip = {
        id: `clip_cam_${Date.now()}`,
        trackId: 'track_main_video',
        trackType: 'video',
        name: 'Camera Recording',
        type: 'video',
        sourceUrl: url,
        blob,
        start: 0,
        duration: 5,
        sourceStart: 0,
        sourceDuration: 5,
        speed: 1.0,
        reverse: false,
        x: 0,
        y: 0,
        scale: 1.0,
        rotation: 0,
        opacity: 1.0,
        flipH: false,
        flipV: false,
        blendMode: 'normal',
        volume: 1.0,
        muted: false,
        fadeIn: 0,
        fadeOut: 0,
        adjustments: {
          brightness: 0,
          contrast: 0,
          saturation: 0,
          exposure: 0,
          highlights: 0,
          shadows: 0,
          temperature: 0,
          tint: 0,
          sharpness: 0,
          vignette: 0,
          grain: 0,
          hue: 0,
        },
        effects: [],
        mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
        chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
        keyframes: [],
      };

      const project: Project = {
        id: `project_${Date.now()}`,
        name: 'Camera Project',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        aspectRatio,
        duration: 5,
        fps: 30,
        background: { type: 'color', color: '#000000' },
        tracks: createBaseTracks(),
        clips: [recordedClip],
      };

      onCreateProject(project);
      onClose();
    };

    mediaRecorderRef.current.stop();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl p-5 sm:p-6 text-white shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div>
            <h2 className="text-lg font-bold">{t.newProject}</h2>
            <p className="text-xs text-neutral-400">{t.selectFormat}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {cameraError && (
          <div className="mt-3 p-2.5 rounded-xl bg-red-950/80 border border-red-800 text-xs text-red-300">
            {cameraError}
          </div>
        )}

        {isCameraActive ? (
          <div className="py-4">
            <div className="relative rounded-xl overflow-hidden bg-black aspect-video mb-3 flex items-center justify-center">
              <video ref={cameraVideoRef} className="w-full h-full object-cover" autoPlay playsInline muted />
              {isRecordingCamera && (
                <div className="absolute top-3 left-3 flex items-center gap-2 px-2.5 py-1 rounded-full bg-red-600/90 text-white text-xs font-bold animate-pulse">
                  <div className="w-2 h-2 rounded-full bg-white" />
                  <span>REC</span>
                </div>
              )}
            </div>
            <div className="flex items-center justify-center gap-3">
              {!isRecordingCamera ? (
                <button
                  onClick={startCameraRecording}
                  className="py-2.5 px-6 rounded-xl bg-red-600 hover:bg-red-500 font-bold text-xs flex items-center gap-2"
                >
                  <Camera className="w-4 h-4" />
                  <span>{language === 'hi' ? 'रिकॉर्डिंग शुरू करें' : 'Start Recording'}</span>
                </button>
              ) : (
                <button
                  onClick={stopCameraRecording}
                  className="py-2.5 px-6 rounded-xl bg-neutral-100 hover:bg-white text-black font-bold text-xs"
                >
                  {language === 'hi' ? 'रिकॉर्डिंग समाप्त और इम्पोर्ट' : 'Stop & Import to Timeline'}
                </button>
              )}
              <button
                onClick={() => {
                  if (cameraVideoRef.current?.srcObject) {
                    (cameraVideoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
                  }
                  setIsCameraActive(false);
                }}
                className="py-2.5 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold"
              >
                {t.cancelExport}
              </button>
            </div>
          </div>
        ) : (
          <div className="py-4 space-y-4">
            {/* Project Name */}
            <div>
              <label className="text-xs font-semibold text-neutral-300 block mb-1.5">
                {language === 'hi' ? 'प्रोजेक्ट का नाम' : 'Project Title'}
              </label>
              <input
                type="text"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
                placeholder="My Clipora Video"
              />
            </div>

            {/* Aspect Ratio Cards */}
            <div>
              <label className="text-xs font-semibold text-neutral-300 block mb-2">
                {t.aspectRatio}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {presets.map((item) => {
                  const Icon = item.icon;
                  const isSelected = aspectRatio === item.ratio;
                  return (
                    <button
                      key={item.ratio}
                      type="button"
                      onClick={() => setAspectRatio(item.ratio)}
                      className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                        isSelected
                          ? 'border-amber-400 bg-amber-500/15 text-white ring-1 ring-amber-400/40'
                          : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-400' : 'text-neutral-400'}`} />
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300">
                          {item.ratio}
                        </span>
                      </div>
                      <span className="text-xs font-bold text-neutral-200 line-clamp-1">{item.platform}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Custom dimensions if chosen */}
            {aspectRatio === 'custom' && (
              <div className="grid grid-cols-2 gap-2 bg-neutral-950 p-3 rounded-xl border border-neutral-800">
                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1">Width (px)</label>
                  <input
                    type="number"
                    value={customW}
                    onChange={(e) => setCustomW(Number(e.target.value))}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded px-2 py-1 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1">Height (px)</label>
                  <input
                    type="number"
                    value={customH}
                    onChange={(e) => setCustomH(Number(e.target.value))}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded px-2 py-1 text-xs text-white"
                  />
                </div>
              </div>
            )}

            {/* Hidden file input for multi-media import */}
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="video/*,image/*,audio/*"
              className="hidden"
              onChange={handleDeviceFilesUpload}
            />

            {/* Actions Grid */}
            <div className="pt-2 border-t border-neutral-800 space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="py-3 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors border border-neutral-700/60"
                >
                  <Upload className="w-4 h-4 text-amber-400" />
                  <span>{t.uploadLocal}</span>
                </button>
                <button
                  onClick={startCamera}
                  className="py-3 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors border border-neutral-700/60"
                >
                  <Camera className="w-4 h-4 text-red-400" />
                  <span>{t.recordCamera}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleStartWithSample}
                  disabled={isGeneratingSample}
                  className="py-3 px-3 rounded-xl bg-neutral-800/90 hover:bg-neutral-700 text-amber-300 font-semibold text-xs flex items-center justify-center gap-2 transition-colors border border-amber-500/30"
                >
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>{isGeneratingSample ? 'Preparing...' : t.sampleMedia}</span>
                </button>
                <button
                  onClick={handleCreateEmpty}
                  className="py-3 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
                >
                  <Film className="w-4 h-4 stroke-[2.5]" />
                  <span>{language === 'hi' ? 'खाली टाइमलाइन खोलें' : 'Open Timeline'}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
