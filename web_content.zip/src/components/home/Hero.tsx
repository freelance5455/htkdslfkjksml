import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { HERO_SLIDES } from '../../data/products';

interface HeroProps {
  onCtaClick?: (categoryTarget: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onCtaClick }) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);

  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);
  const touchCurrentX = useRef<number | null>(null);
  const isHorizontalSwipe = useRef<boolean | null>(null);

  const mouseStartX = useRef<number | null>(null);
  const isMouseDragging = useRef(false);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const minSwipeDistance = 40;
  const totalSlides = HERO_SLIDES.length;

  const resetAutoSlideTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    if (!isPaused && !isDragging) {
      timerRef.current = setInterval(() => {
        setCurrentSlideIndex((prev) => (prev + 1) % totalSlides);
      }, 4500);
    }
  }, [isPaused, isDragging, totalSlides]);

  useEffect(() => {
    resetAutoSlideTimer();
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [resetAutoSlideTimer]);

  const goToSlide = (newIndex: number) => {
    const validIndex = (newIndex + totalSlides) % totalSlides;
    setCurrentSlideIndex(validIndex);
    setDragOffset(0);
    resetAutoSlideTimer();
  };

  const handlePrev = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    goToSlide(currentSlideIndex - 1);
  };

  const handleNext = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    goToSlide(currentSlideIndex + 1);
  };

  // Touch Swipe Handling with vertical scroll detection
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
    touchStartY.current = e.targetTouches[0].clientY;
    touchCurrentX.current = e.targetTouches[0].clientX;
    isHorizontalSwipe.current = null;
    setIsPaused(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchStartX.current === null || touchStartY.current === null) return;
    const currentX = e.targetTouches[0].clientX;
    const currentY = e.targetTouches[0].clientY;
    touchCurrentX.current = currentX;

    const diffX = currentX - touchStartX.current;
    const diffY = currentY - touchStartY.current;

    // Detect gesture axis lock
    if (isHorizontalSwipe.current === null) {
      if (Math.abs(diffX) > 8 || Math.abs(diffY) > 8) {
        isHorizontalSwipe.current = Math.abs(diffX) > Math.abs(diffY);
      }
    }

    if (isHorizontalSwipe.current === true) {
      setIsDragging(true);
      setDragOffset(diffX * 0.7);
    }
  };

  const handleTouchEnd = () => {
    setIsPaused(false);
    setIsDragging(false);

    if (isHorizontalSwipe.current === true && touchStartX.current !== null && touchCurrentX.current !== null) {
      const distance = touchStartX.current - touchCurrentX.current;
      if (distance > minSwipeDistance) {
        handleNext();
      } else if (distance < -minSwipeDistance) {
        handlePrev();
      } else {
        setDragOffset(0);
        resetAutoSlideTimer();
      }
    } else {
      setDragOffset(0);
      resetAutoSlideTimer();
    }

    touchStartX.current = null;
    touchStartY.current = null;
    touchCurrentX.current = null;
    isHorizontalSwipe.current = null;
  };

  // Mouse Drag Handling for Desktop
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    mouseStartX.current = e.clientX;
    isMouseDragging.current = true;
    setIsPaused(true);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDragging.current || mouseStartX.current === null) return;
    const diffX = e.clientX - mouseStartX.current;
    if (Math.abs(diffX) > 5) {
      setIsDragging(true);
      setDragOffset(diffX * 0.7);
    }
  };

  const handleMouseUp = () => {
    if (!isMouseDragging.current) return;
    const currentDrag = dragOffset;
    isMouseDragging.current = false;
    setIsDragging(false);
    setIsPaused(false);

    if (currentDrag < -minSwipeDistance) {
      handleNext();
    } else if (currentDrag > minSwipeDistance) {
      handlePrev();
    } else {
      setDragOffset(0);
      resetAutoSlideTimer();
    }
    mouseStartX.current = null;
  };

  const handleContainerClick = () => {
    if (Math.abs(dragOffset) > 10) {
      setDragOffset(0);
      return;
    }
    onCtaClick?.(currentSlide.categoryTarget);
  };

  const currentSlide = HERO_SLIDES[currentSlideIndex];

  return (
    <section className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-1 pb-1">
      <div
        onClick={handleContainerClick}
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => {
          if (isMouseDragging.current) {
            handleMouseUp();
          }
          setIsPaused(false);
          resetAutoSlideTimer();
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className="group relative w-full aspect-[2/1] sm:aspect-[2.3/1] md:aspect-[2.6/1] lg:aspect-[2.9/1] max-h-[360px] overflow-hidden rounded-[18px] sm:rounded-[24px] cursor-pointer select-none bg-black shadow-xs border border-[#EAEAEA]"
      >
        {/* Horizontal Slider Track */}
        <div
          className="flex w-full h-full will-change-transform"
          style={{
            transform: `translateX(calc(-${currentSlideIndex * 100}% + ${dragOffset}px))`,
            transition: isDragging
              ? 'none'
              : 'transform 450ms cubic-bezier(0.22, 1, 0.36, 1)',
          }}
        >
          {HERO_SLIDES.map((slide, idx) => (
            <div
              key={slide.id}
              className="w-full h-full flex-shrink-0 relative overflow-hidden bg-neutral-900"
            >
              <img
                src={slide.image}
                alt={`Slide ${idx + 1}`}
                referrerPolicy="no-referrer"
                draggable={false}
                className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-[1.01]"
                loading={idx === 0 ? 'eager' : 'lazy'}
              />
            </div>
          ))}
        </div>

        {/* Desktop Controls */}
        <button
          onClick={handlePrev}
          className="hidden sm:flex absolute left-3 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-white/90 hover:bg-[#FFD400] text-[#000000] shadow-md backdrop-blur-xs items-center justify-center transition-all cursor-pointer opacity-0 group-hover:opacity-100"
          aria-label="Previous slide"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button
          onClick={handleNext}
          className="hidden sm:flex absolute right-3 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-white/90 hover:bg-[#FFD400] text-[#000000] shadow-md backdrop-blur-xs items-center justify-center transition-all cursor-pointer opacity-0 group-hover:opacity-100"
          aria-label="Next slide"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Yellow Brand Bottom Slider Indicators */}
      <nav
        aria-label="Banner pagination"
        className="flex justify-center items-center gap-1.5 sm:gap-2 mt-2.5 sm:mt-3 select-none"
      >
        {HERO_SLIDES.map((slide, idx) => {
          const isActive = idx === currentSlideIndex;
          return (
            <button
              key={slide.id}
              onClick={(e) => {
                e.stopPropagation();
                goToSlide(idx);
              }}
              className="group relative flex items-center justify-center py-2 px-0.5 sm:px-1 cursor-pointer focus:outline-hidden"
              aria-label={`Go to slide ${idx + 1}`}
              aria-current={isActive ? 'true' : 'false'}
            >
              <span
                className={`block rounded-full ${
                  isActive
                    ? 'w-6 sm:w-7 h-[5px] bg-[#FFD400] opacity-100 shadow-2xs'
                    : 'w-[7px] sm:w-[8px] h-[5px] bg-[#EAEAEA] hover:bg-neutral-300 opacity-80 group-hover:opacity-100'
                }`}
                style={{
                  transition:
                    'width 400ms cubic-bezier(0.22, 1, 0.36, 1), background-color 400ms cubic-bezier(0.22, 1, 0.36, 1)',
                  willChange: 'width, background-color',
                }}
              />
            </button>
          );
        })}
      </nav>
    </section>
  );
};

export default Hero;
