import { useState } from 'react';
import {
  Bell,
  Search,
  Plane,
  Building2,
  FileCheck,
  Car,
  HeartHandshake,
  Crown,
  Sparkles,
  Shield,
  Compass,
  ArrowRight,
  ArrowLeft,
  Calendar,
  CheckCircle,
  ExternalLink,
  ChevronRight,
  ChevronLeft,
  Luggage,
  Smartphone,
} from 'lucide-react';
import { UserProfile, TravelTrip, Language, Currency } from '../../types';
import { translations } from '../../i18n/translations';
import { ThreeGlobe } from '../globe/ThreeGlobe';

interface HomeScreenProps {
  user: UserProfile;
  upcomingTrip: TravelTrip;
  unreadNotificationsCount: number;
  language: Language;
  currency: Currency;
  onNavigateTab: (tab: string) => void;
  onOpenNotifications: () => void;
  onOpenProfile: () => void;
  onOpenGuardian: () => void;
  onOpenAndroidApk?: () => void;
}

export function HomeScreen({
  user,
  upcomingTrip,
  unreadNotificationsCount,
  language,
  currency,
  onNavigateTab,
  onOpenNotifications,
  onOpenProfile,
  onOpenGuardian,
  onOpenAndroidApk,
}: HomeScreenProps) {
  const [searchInput, setSearchInput] = useState('');
  const t = translations[language];
  const isRTL = language === 'ar';

  const servicesList = [
    { id: 'flights', title: t.services.flights, icon: <Plane className="w-5 h-5 text-cyan-400" />, tab: 'flights', glow: 'from-blue-600/30 to-cyan-500/20' },
    { id: 'hotels', title: t.services.hotels, icon: <Building2 className="w-5 h-5 text-blue-400" />, tab: 'hotels', glow: 'from-indigo-600/30 to-blue-500/20' },
    { id: 'visas', title: t.services.visas, icon: <FileCheck className="w-5 h-5 text-emerald-400" />, tab: 'visa', glow: 'from-emerald-600/30 to-cyan-500/20' },
    { id: 'cars', title: t.services.carRental, icon: <Car className="w-5 h-5 text-amber-400" />, tab: 'explore', glow: 'from-amber-600/30 to-orange-500/20' },
    { id: 'omra', title: t.services.religious, icon: <Crown className="w-5 h-5 text-emerald-300" />, tab: 'explore', glow: 'from-emerald-700/30 to-teal-500/20' },
    { id: 'honeymoon', title: t.services.honeymoon, icon: <Sparkles className="w-5 h-5 text-pink-400" />, tab: 'explore', glow: 'from-pink-600/30 to-rose-500/20' },
    { id: 'vip', title: t.services.vip, icon: <Crown className="w-5 h-5 text-amber-300" />, tab: 'agency', glow: 'from-amber-500/30 to-yellow-500/20' },
    { id: 'packing', title: language === 'ar' ? 'مساعد الأمتعة الذكي' : 'Smart Packing', icon: <Luggage className="w-5 h-5 text-cyan-300" />, tab: 'packing', glow: 'from-cyan-600/30 to-blue-500/20' },
    { id: 'insurance', title: t.services.insurance, icon: <Shield className="w-5 h-5 text-blue-300" />, tab: 'wallet', glow: 'from-blue-700/30 to-indigo-500/20' },
    { id: 'airportAssist', title: t.services.airportAssist, icon: <Plane className="w-5 h-5 text-cyan-400" />, tab: 'ar', glow: 'from-cyan-700/30 to-blue-500/20' },
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onNavigateTab('flights');
    }
  };

  return (
    <div className="space-y-6 pb-24">
      {/* 1. TOP HEADER: USER GREETING, AVATAR & NOTIFICATIONS */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenProfile}
            className="relative w-12 h-12 rounded-2xl overflow-hidden border-2 border-cyan-400/50 p-0.5 shadow-[0_0_15px_rgba(0,240,255,0.3)] hover:scale-105 transition-transform"
          >
            <img
              src={user.avatarUrl}
              alt={user.fullName}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-xl"
            />
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-400 font-medium">{t.welcomeUser}</span>
              <p className="text-sm font-bold text-white truncate max-w-[170px]">{user.fullName.split(' ')[0]}</p>
            </div>
            <p className="text-[11px] text-cyan-300 font-semibold flex items-center gap-1">
              <span>{t.upcomingTripNear}</span>
            </p>
          </div>
        </div>

        {/* Notification Bell */}
        <button
          onClick={onOpenNotifications}
          className="relative w-11 h-11 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-400/40 text-slate-200 hover:text-white flex items-center justify-center transition-colors"
          aria-label="Open notifications"
        >
          <Bell className="w-5 h-5 text-cyan-400" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-cyan-500 text-slate-950 font-black text-[10px] flex items-center justify-center shadow-[0_0_10px_#00f0ff]">
              {unreadNotificationsCount}
            </span>
          )}
        </button>
      </div>

      {/* Download & Install on Phone Banner */}
      {onOpenAndroidApk && (
        <div className="relative overflow-hidden p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-[#071330] to-[#040816] border border-emerald-500/40 shadow-[0_0_25px_rgba(16,185,129,0.2)] flex items-center justify-between gap-3 animate-fadeIn">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-400/40 shrink-0">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-black text-white">
                {isRTL ? 'تحميل وتثبيت التطبيق على هاتفك (APK)' : 'Install Full App on Your Phone (APK)'}
              </p>
              <p className="text-[10px] text-emerald-300">
                {isRTL ? 'تطبيق أندرويد متكامل يعمل بدون إنترنت مع مسار الرحلات' : 'Standalone offline mobile app for Android & iOS'}
              </p>
            </div>
          </div>
          <button
            onClick={onOpenAndroidApk}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-black text-[11px] shadow-[0_0_15px_rgba(16,185,129,0.4)] hover:brightness-110 active:scale-95 transition-all shrink-0 cursor-pointer"
          >
            {isRTL ? 'تثبيت الآن' : 'Install Now'}
          </button>
        </div>
      )}

      {/* 2. 3D WORLD GLOBE & ATMOSPHERE */}
      <div className="relative rounded-3xl overflow-hidden glass-panel-elevated border border-cyan-500/25 p-2">
        <ThreeGlobe />
        <div className="absolute top-4 left-4 rtl:left-auto rtl:right-4 z-10 pointer-events-none">
          <span className="text-[10px] font-mono font-bold tracking-widest text-cyan-400 uppercase bg-black/50 px-2.5 py-1 rounded-full border border-cyan-500/30 backdrop-blur-sm">
            TAKI-GO Interactive Orbit
          </span>
        </div>
      </div>

      {/* 3. SMART SEARCH BOX */}
      <div className="glass-panel rounded-3xl p-4 border border-cyan-500/20 space-y-3">
        <form onSubmit={handleSearchSubmit} className="relative">
          <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#060c20] border border-slate-800 focus-within:border-cyan-400 shadow-inner">
            <Search className="w-4 h-4 text-cyan-400 mx-2 shrink-0" />
            <input
              type="text"
              value={searchInput}
              onChange={e => setSearchInput(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="flex-1 bg-transparent py-2 text-xs md:text-sm text-white placeholder-slate-500 outline-none"
            />
            <button
              type="submit"
              className="h-9 px-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold text-xs shrink-0 hover:brightness-110 active:scale-95 transition-all"
            >
              {language === 'ar' ? 'بحث' : 'Search'}
            </button>
          </div>
        </form>

        {/* Quick Filter Categories */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: t.quickFilters.flights, tab: 'flights' },
            { label: t.quickFilters.hotels, tab: 'hotels' },
            { label: t.quickFilters.visas, tab: 'visa' },
            { label: t.quickFilters.cars, tab: 'explore' },
          ].map((item, idx) => (
            <button
              key={idx}
              onClick={() => onNavigateTab(item.tab)}
              className="py-1.5 px-2 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-cyan-400/40 text-[11px] font-medium text-slate-300 hover:text-white transition-colors truncate text-center"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* 4. UPCOMING TRIP HIGHLIGHT CARD */}
      <div className="glass-panel-elevated rounded-3xl p-5 border border-cyan-400/30 text-white space-y-3 relative overflow-hidden">
        {/* Glow corner */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <Plane className="w-4 h-4 text-cyan-400" />
            <h2 className="text-xs font-bold text-white">{t.upcomingTripTitle}</h2>
          </div>
          <button
            onClick={onOpenGuardian}
            className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-300 bg-emerald-950/70 border border-emerald-500/40 px-2.5 py-0.5 rounded-full shadow-[0_0_12px_rgba(16,185,129,0.25)]"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span>{t.smartGuardianBadge}</span>
          </button>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-black text-white">{upcomingTrip.destinationCity}</h3>
            <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              <span>{upcomingTrip.startDate}</span>
            </p>
          </div>

          <div className="text-left rtl:text-right">
            <span className="text-[10px] text-slate-400 block">{t.flight}</span>
            <span className="text-xs font-mono font-bold text-cyan-300">{upcomingTrip.flightInfo.flightNumber}</span>
          </div>
        </div>

        {/* Quick action bar */}
        <div className="pt-2 flex items-center justify-between text-xs gap-2">
          <button
            onClick={() => onNavigateTab('trips')}
            className="text-cyan-400 font-bold flex items-center gap-1 hover:underline"
          >
            <span>{t.viewDetails}</span>
            {isRTL ? <ArrowLeft className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateTab('packing')}
              className="px-3 py-1.5 rounded-xl bg-cyan-500/15 border border-cyan-400/40 hover:bg-cyan-500/25 text-[11px] font-bold text-cyan-300 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Luggage className="w-3.5 h-3.5" />
              <span>{language === 'ar' ? 'حزم الحقيبة' : 'Pack Bag'}</span>
            </button>
            <button
              onClick={() => onNavigateTab('wallet')}
              className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-400/40 text-[11px] font-bold text-white transition-colors"
            >
              {t.boardingPass}
            </button>
          </div>
        </div>
      </div>

      {/* 5. SERVICES GRID */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white">{t.servicesTitle}</h2>
          <span className="text-[10px] text-cyan-400 font-mono">10 Services</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {servicesList.map(service => (
            <button
              key={service.id}
              onClick={() => onNavigateTab(service.tab)}
              className="p-3.5 rounded-2xl glass-panel hover:border-cyan-400/50 transition-all text-center flex flex-col items-center justify-center gap-2 group active:scale-[0.98]"
            >
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${service.glow} flex items-center justify-center border border-white/5 group-hover:scale-110 transition-transform`}>
                {service.icon}
              </div>
              <span className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors line-clamp-1">
                {service.title}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
