import React, { useState, useRef } from 'react';
import {
  Film,
  Plus,
  Play,
  Trash2,
  Copy,
  Clock,
  Layers,
  Sparkles,
  Settings,
  Code,
  FolderOpen,
  HelpCircle,
  X
} from 'lucide-react';
import { Project } from '../../types/editor';
import { formatTimeShort } from '../../utils/time';
import { createNewProject, deleteProject, saveProject } from '../../services/storage';
import { generateSampleVideo, processUploadedVideo } from '../../utils/sampleGenerator';

interface HomeScreenProps {
  projects: Project[];
  onOpenProject: (project: Project) => void;
  onRefreshProjects: () => void;
  onOpenAndroidCode: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  projects,
  onOpenProject,
  onRefreshProjects,
  onOpenAndroidCode,
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [loadingText, setLoadingText] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Quick Start with 3 Sample Clips
  const handleQuickStartSample = async () => {
    setIsCreating(true);
    setLoadingText('Generating high-definition sample clips...');

    try {
      const clip1 = await generateSampleVideo('Golden Sunset Bay', 'sunset', 4);
      setLoadingText('Generating cyberpunk city clip...');
      const clip2 = await generateSampleVideo('Neo Cyber Grid', 'cyberpunk', 4);
      setLoadingText('Generating skate action clip...');
      const clip3 = await generateSampleVideo('Skatepark Ramp Action', 'skate', 4);

      const project = createNewProject('CutPro Showcase Demo');
      project.mediaMap[clip1.id] = clip1;
      project.mediaMap[clip2.id] = clip2;
      project.mediaMap[clip3.id] = clip3;

      project.clips = [
        {
          id: `clip-1-${Date.now()}`,
          mediaId: clip1.id,
          sourceIn: 0.5,
          sourceOut: 3.8,
          timelineStart: 0,
          speed: 1.0,
          volume: 1.0,
          color: '#38bdf8',
        },
        {
          id: `clip-2-${Date.now()}`,
          mediaId: clip2.id,
          sourceIn: 0.2,
          sourceOut: 3.5,
          timelineStart: 3.3,
          speed: 1.0,
          volume: 1.0,
          color: '#f43f5e',
        },
        {
          id: `clip-3-${Date.now()}`,
          mediaId: clip3.id,
          sourceIn: 0.5,
          sourceOut: 3.9,
          timelineStart: 6.6,
          speed: 1.0,
          volume: 1.0,
          color: '#fbbf24',
        },
      ];

      saveProject(project);
      onRefreshProjects();
      onOpenProject(project);
    } catch (err) {
      console.error(err);
    } finally {
      setIsCreating(false);
      setLoadingText('');
    }
  };

  // Import videos from user's device
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsCreating(true);
    setLoadingText(`Importing ${files.length} video${files.length > 1 ? 's' : ''}...`);

    try {
      const project = createNewProject(`Project ${projects.length + 1}`);
      let currentTimelineOffset = 0;

      for (let i = 0; i < files.length; i++) {
        setLoadingText(`Analyzing media metadata ${i + 1}/${files.length}...`);
        const media = await processUploadedVideo(files[i]);
        project.mediaMap[media.id] = media;

        project.clips.push({
          id: `clip-${i}-${Date.now()}`,
          mediaId: media.id,
          sourceIn: 0,
          sourceOut: media.duration,
          timelineStart: currentTimelineOffset,
          speed: 1.0,
          volume: 1.0,
          color: ['#00E5FF', '#FF4A5A', '#A855F7', '#22C55E'][i % 4],
        });

        currentTimelineOffset += media.duration;
      }

      saveProject(project);
      onRefreshProjects();
      onOpenProject(project);
    } catch (err) {
      console.error(err);
      alert('Error importing videos. Please make sure the files are valid video formats (MP4, WebM, MOV).');
    } finally {
      setIsCreating(false);
      setLoadingText('');
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleCreateEmptyProject = () => {
    const project = createNewProject(`Project ${projects.length + 1}`);
    saveProject(project);
    onRefreshProjects();
    onOpenProject(project);
  };

  const handleDeleteProject = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm('Delete this project?')) {
      deleteProject(id);
      onRefreshProjects();
    }
  };

  const handleDuplicateProject = (e: React.MouseEvent, project: Project) => {
    e.stopPropagation();
    const dup: Project = {
      ...project,
      id: `cutpro_${Date.now()}_copy`,
      name: `${project.name} (Copy)`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    saveProject(dup);
    onRefreshProjects();
  };

  return (
    <div className="min-h-screen bg-[#0B0E14] text-[#F0F3F6] flex flex-col">
      {/* Hidden file input for native media import */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/webm,video/quicktime,video/*"
        multiple
        className="hidden"
        onChange={handleFileSelect}
      />

      {/* Top Header */}
      <header className="h-16 px-6 border-b border-[#1F242D] flex items-center justify-between bg-[#161B22]/80 backdrop-blur-md sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#FF4A5A] to-[#00E5FF] p-0.5 flex items-center justify-center shadow-lg shadow-[#FF4A5A]/20">
            <div className="w-full h-full bg-[#0B0E14] rounded-[10px] flex items-center justify-center">
              <Film className="w-5 h-5 text-[#00E5FF]" />
            </div>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              CutPro
              <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded bg-[#00E5FF]/10 text-[#00E5FF] border border-[#00E5FF]/20">
                PRO
              </span>
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenAndroidCode}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-[#1F242D] hover:bg-[#2A313D] border border-white/10 rounded-xl transition-all shadow-sm"
            title="Inspect Android Kotlin Code & Download APK Studio Bundle"
          >
            <Code className="w-4 h-4 text-[#00E5FF]" />
            <span className="hidden sm:inline">Android Kotlin Code</span>
          </button>

          <button
            onClick={() => setShowSettings(true)}
            className="w-10 h-10 flex items-center justify-center rounded-xl bg-[#1F242D] text-[#8B949E] hover:text-white hover:bg-[#2A313D] transition-colors"
            title="Editor Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 flex flex-col gap-8">
        {/* Hero Banner / Action Section */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-[#161B22] via-[#12161E] to-[#0B0E14] border border-[#1F242D] p-6 sm:p-10 shadow-2xl">
          <div className="relative z-10 max-w-2xl flex flex-col gap-3">
            <div className="inline-flex items-center gap-2 text-xs font-medium text-[#00E5FF]">
              <Sparkles className="w-4 h-4 text-[#00E5FF]" />
              <span>Android Media3 & Jetpack Compose Architecture</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
              Pro Video Editor & Slideshow Maker
            </h2>
            <p className="text-sm sm:text-base text-[#8B949E] leading-relaxed">
              Import, trim with precision start/end handles, split clips at any timestamp, reorder, merge, and export high-definition MP4 videos directly on device.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-3">
              {/* Primary Coral-Red New Project Button */}
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isCreating}
                className="flex items-center gap-2.5 px-6 py-3.5 bg-[#FF4A5A] hover:bg-[#ff3b4c] active:scale-[0.98] text-white font-semibold text-sm rounded-2xl shadow-lg shadow-[#FF4A5A]/30 transition-all cursor-pointer"
              >
                <Plus className="w-5 h-5 stroke-[2.5]" />
                <span>New Project (Import Videos)</span>
              </button>

              {/* Instant Sample Clip Project Button */}
              <button
                onClick={handleQuickStartSample}
                disabled={isCreating}
                className="flex items-center gap-2 px-5 py-3.5 bg-[#1F242D] hover:bg-[#262C37] active:scale-[0.98] text-[#00E5FF] border border-[#00E5FF]/20 font-semibold text-sm rounded-2xl transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Quick Start (Sample Clips)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Loading Overlay */}
        {isCreating && (
          <div className="p-6 rounded-2xl bg-[#161B22] border border-[#00E5FF]/30 flex items-center gap-4">
            <div className="w-6 h-6 border-2 border-[#00E5FF] border-t-transparent rounded-full animate-spin shrink-0" />
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-white">{loadingText}</span>
              <span className="text-xs text-[#8B949E]">Initializing media engine & decoding frames</span>
            </div>
          </div>
        )}

        {/* Recent Projects Section */}
        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FolderOpen className="w-5 h-5 text-[#00E5FF]" />
              <h3 className="text-lg font-bold text-white tracking-tight">Recent Projects</h3>
            </div>
            <span className="text-xs text-[#8B949E] font-medium">
              {projects.length} {projects.length === 1 ? 'Project' : 'Projects'} Saved
            </span>
          </div>

          {projects.length === 0 ? (
            <div className="border border-dashed border-[#1F242D] rounded-3xl p-12 flex flex-col items-center justify-center text-center gap-4 bg-[#161B22]/40">
              <div className="w-16 h-16 rounded-2xl bg-[#1F242D] flex items-center justify-center text-[#8B949E]">
                <Film className="w-8 h-8" />
              </div>
              <div className="flex flex-col gap-1 max-w-sm">
                <h4 className="text-base font-semibold text-white">No projects yet</h4>
                <p className="text-xs text-[#8B949E]">
                  Tap &quot;New Project&quot; to pick videos from your phone or try &quot;Quick Start&quot; with pre-loaded sample clips.
                </p>
              </div>
              <div className="flex items-center gap-3 mt-2">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 text-xs font-semibold bg-[#FF4A5A] text-white rounded-xl hover:bg-[#ff3b4c] transition-colors"
                >
                  Import From Phone
                </button>
                <button
                  onClick={handleQuickStartSample}
                  className="px-4 py-2 text-xs font-semibold bg-[#1F242D] text-[#00E5FF] rounded-xl hover:bg-[#2A313D] transition-colors"
                >
                  Load Sample Project
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {projects.map((proj) => {
                // Compute total project duration
                const totalDur = proj.clips.reduce(
                  (acc, c) => acc + (c.sourceOut - c.sourceIn) / (c.speed || 1.0),
                  0
                );
                const firstMedia = proj.clips[0] ? proj.mediaMap[proj.clips[0].mediaId] : null;

                return (
                  <div
                    key={proj.id}
                    onClick={() => onOpenProject(proj)}
                    className="group relative rounded-2xl bg-[#161B22] border border-[#1F242D] hover:border-[#00E5FF]/40 p-4 transition-all duration-200 cursor-pointer flex flex-col gap-3 shadow-lg hover:shadow-cyan-950/20"
                  >
                    {/* Thumbnail preview */}
                    <div className="relative aspect-video w-full rounded-xl bg-black overflow-hidden flex items-center justify-center">
                      {firstMedia?.thumbnailUrl ? (
                        <img
                          src={firstMedia.thumbnailUrl}
                          alt={proj.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <div className="flex items-center justify-center text-[#8B949E]">
                          <Film className="w-8 h-8 opacity-40" />
                        </div>
                      )}

                      {/* Duration pill badge */}
                      <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded-md bg-black/80 backdrop-blur-md text-[11px] font-mono font-semibold text-white">
                        {formatTimeShort(totalDur)}
                      </div>

                      {/* Play overlay icon */}
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <div className="w-10 h-10 rounded-full bg-[#00E5FF] text-black flex items-center justify-center shadow-lg">
                          <Play className="w-5 h-5 fill-current ml-0.5" />
                        </div>
                      </div>
                    </div>

                    {/* Metadata & Actions */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex flex-col min-w-0">
                        <h4 className="text-sm font-bold text-white truncate group-hover:text-[#00E5FF] transition-colors">
                          {proj.name}
                        </h4>
                        <div className="flex items-center gap-3 text-xs text-[#8B949E] mt-1">
                          <span className="flex items-center gap-1 font-mono">
                            <Clock className="w-3.5 h-3.5" />
                            {new Date(proj.updatedAt).toLocaleDateString()}
                          </span>
                          <span>·</span>
                          <span className="flex items-center gap-1">
                            <Layers className="w-3.5 h-3.5" />
                            {proj.clips.length} {proj.clips.length === 1 ? 'clip' : 'clips'}
                          </span>
                        </div>
                      </div>

                      {/* Row actions */}
                      <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                        <button
                          onClick={(e) => handleDuplicateProject(e, proj)}
                          className="p-1.5 rounded-lg hover:bg-[#1F242D] text-[#8B949E] hover:text-white transition-colors"
                          title="Duplicate Project"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => handleDeleteProject(e, proj.id)}
                          className="p-1.5 rounded-lg hover:bg-[#FF4A5A]/20 text-[#8B949E] hover:text-[#FF4A5A] transition-colors"
                          title="Delete Project"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Feature Highlights Grid */}
        <section className="border-t border-[#1F242D] pt-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-[#161B22]/50 border border-[#1F242D] flex flex-col gap-2">
              <span className="text-xs font-semibold text-[#00E5FF] uppercase tracking-wider">01. Import & Preview</span>
              <p className="text-xs text-[#8B949E]">
                Native Android Photo Picker and Storage Access Framework integration with responsive ExoPlayer timeline scrubbing.
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-[#161B22]/50 border border-[#1F242D] flex flex-col gap-2">
              <span className="text-xs font-semibold text-[#FF4A5A] uppercase tracking-wider">02. Trim & Split</span>
              <p className="text-xs text-[#8B949E]">
                Nondestructive precision start/end handles with millisecond nudgers and instant playhead slice cutting.
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-[#161B22]/50 border border-[#1F242D] flex flex-col gap-2">
              <span className="text-xs font-semibold text-[#22C55E] uppercase tracking-wider">03. Merge & MP4 Export</span>
              <p className="text-xs text-[#8B949E]">
                Media3 Transformer hardware rendering pipeline concatenating video frames and mixing audio into playable MP4 files.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#161B22] border border-[#1F242D] rounded-3xl p-6 flex flex-col gap-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1F242D] pb-3">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#00E5FF]" />
                <h3 className="text-base font-bold text-white">CutPro Settings</h3>
              </div>
              <button
                onClick={() => setShowSettings(false)}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-[#8B949E] hover:text-white hover:bg-[#1F242D]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-col gap-4 text-xs text-[#8B949E]">
              <div className="flex justify-between items-center py-2 border-b border-[#1F242D]/50">
                <span className="text-white font-medium">Application Version</span>
                <span className="font-mono text-[#00E5FF]">v1.0.0 (Phase 1 Build)</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-[#1F242D]/50">
                <span className="text-white font-medium">Package Identifier</span>
                <span className="font-mono">com.cutpro.videoeditor</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-[#1F242D]/50">
                <span className="text-white font-medium">Video Processing Engine</span>
                <span className="text-white">AndroidX Media3 Transformer</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-[#1F242D]/50">
                <span className="text-white font-medium">Local Database</span>
                <span className="text-white">Room Persistence (SQLite)</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-[#1F242D]/50">
                <span className="text-white font-medium">Default Resolution</span>
                <span className="text-white">1080p Full HD (60fps)</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setShowSettings(false)}
                className="w-full py-2.5 bg-[#1F242D] hover:bg-[#2A313D] text-white font-semibold rounded-xl text-xs transition-colors"
              >
                Close Settings
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
