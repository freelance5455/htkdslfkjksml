import React from 'react';
import { useMusic } from '../../context/MusicContext';
import { CoverArt } from '../common/CoverArt';
import { SongCard } from '../cards/SongCard';
import { MusicListItem } from '../cards/MusicListItem';
import { PlaylistCard } from '../cards/PlaylistCard';
import { ArtistCard } from '../cards/ArtistCard';
import { GENRE_CATEGORIES } from '../../data/musicData';
import { Play, Pause, Heart, Sparkles, ChevronRight, Flame } from 'lucide-react';

export const HomeScreen: React.FC = () => {
  const {
    songs,
    playlists,
    artists,
    currentSong,
    isPlaying,
    playSong,
    togglePlayPause,
    likedSongIds,
    toggleLikeSong,
    setSelectedPlaylistId,
    setActiveTab,
    addSearchHistory
  } = useMusic();

  // Featured Hero Track (Midnight Horizon)
  const heroTrack = songs[0];
  const isHeroPlaying = currentSong?.id === heroTrack.id && isPlaying;
  const isHeroLiked = likedSongIds.includes(heroTrack.id);

  // Trending ranked list (Top 5 songs by play count)
  const trendingSongs = [...songs].sort((a, b) => b.playCount - a.playCount).slice(0, 5);

  // Recently played (first 6 songs)
  const recentlyPlayed = songs.slice(0, 6);

  // Made for you playlists
  const madeForYou = playlists.slice(0, 4);

  // New releases (last 4 songs)
  const newReleases = songs.slice(6, 12);

  const handleGenreClick = (genreId: string) => {
    addSearchHistory(genreId);
    setActiveTab('search');
  };

  return (
    <div className="space-y-7 pb-24 pt-2">
      {/* Hero Section: Large Featured Music Card */}
      <section className="relative overflow-hidden rounded-3xl mx-1 shadow-2xl transition-all">
        {/* Ambient gradient backplate */}
        <div
          className="absolute inset-0 transition-all duration-700 opacity-80"
          style={{
            background: `linear-gradient(135deg, ${heroTrack.colorTheme.from} 0%, #111422 65%, ${heroTrack.colorTheme.to} 100%)`
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0b0c10] via-black/40 to-transparent" />

        <div className="relative z-10 p-5 sm:p-7 flex flex-col sm:flex-row items-center gap-5 sm:gap-7">
          {/* Large Hero Artwork */}
          <div className="relative shrink-0 w-44 h-44 sm:w-48 sm:h-48 rounded-2xl overflow-hidden shadow-2xl ring-1 ring-white/20 group">
            <CoverArt
              artKey={heroTrack.albumArt}
              title={heroTrack.title}
              artist={heroTrack.artist}
              colorTheme={heroTrack.colorTheme}
              size="lg"
              className="w-full h-full"
            />
            <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
          </div>

          {/* Hero Meta & Call to Actions */}
          <div className="flex-1 text-center sm:text-left min-w-0">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-[11px] font-semibold text-purple-200 mb-2.5">
              <Sparkles className="w-3.5 h-3.5 text-pink-400" />
              <span>FEATURED RELEASE OF THE WEEK</span>
            </div>

            <h2 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight leading-tight line-clamp-2">
              {heroTrack.title}
            </h2>

            <p className="text-sm sm:text-base text-slate-300 font-medium mt-1 truncate">
              {heroTrack.artist} · <span className="text-purple-300">{heroTrack.album}</span>
            </p>

            <p className="text-xs text-slate-400 mt-2 line-clamp-2 max-w-md hidden sm:block">
              Immerse yourself in retro-futuristic synthesizers and nocturnal sonic momentum.
            </p>

            {/* CTAs */}
            <div className="flex items-center justify-center sm:justify-start gap-3 mt-4 pt-1">
              <button
                onClick={() => {
                  if (currentSong?.id === heroTrack.id) {
                    togglePlayPause();
                  } else {
                    playSong(heroTrack);
                  }
                }}
                className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white text-black font-bold text-xs sm:text-sm hover:bg-slate-100 active:scale-95 shadow-lg shadow-white/10 transition-all"
              >
                {isHeroPlaying ? (
                  <>
                    <Pause className="w-4 h-4 fill-black" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-black ml-0.5" />
                    <span>Play Now</span>
                  </>
                )}
              </button>

              <button
                onClick={() => toggleLikeSong(heroTrack.id)}
                aria-label={isHeroLiked ? 'Unlike' : 'Favorite'}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-white font-medium text-xs sm:text-sm backdrop-blur-md border border-white/15 transition-all"
              >
                <Heart
                  className={`w-4 h-4 ${
                    isHeroLiked ? 'fill-pink-500 text-pink-500' : 'text-white'
                  }`}
                />
                <span className="hidden sm:inline">
                  {isHeroLiked ? 'Favorited' : 'Favorite'}
                </span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Recently Played */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="font-display font-bold text-base sm:text-lg text-white tracking-tight">
              Recently Played
            </h3>
            <p className="text-xs text-slate-400">Pick up right where you left off</p>
          </div>
        </div>

        <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar px-1">
          {recentlyPlayed.map((song) => (
            <SongCard key={song.id} song={song} contextQueue={songs} />
          ))}
        </div>
      </section>

      {/* Trending Now */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center">
              <Flame className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base sm:text-lg text-white tracking-tight">
                Trending Now
              </h3>
              <p className="text-xs text-slate-400">Top chartbusters this week</p>
            </div>
          </div>
        </div>

        <div className="space-y-1.5 bg-white/[0.02] p-2 rounded-3xl border border-white/[0.04]">
          {trendingSongs.map((song, idx) => (
            <MusicListItem
              key={song.id}
              song={song}
              rank={idx + 1}
              showRank={true}
              contextQueue={trendingSongs}
            />
          ))}
        </div>
      </section>

      {/* Made For You */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="font-display font-bold text-base sm:text-lg text-white tracking-tight">
              Made For You
            </h3>
            <p className="text-xs text-slate-400">Handcrafted playlists for Sahanur</p>
          </div>
        </div>

        <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar px-1">
          {madeForYou.map((playlist) => (
            <PlaylistCard
              key={playlist.id}
              playlist={playlist}
              onClick={() => setSelectedPlaylistId(playlist.id)}
            />
          ))}
        </div>
      </section>

      {/* New Releases (Horizontal Wide Cards) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="font-display font-bold text-base sm:text-lg text-white tracking-tight">
              New Releases
            </h3>
            <p className="text-xs text-slate-400">Fresh beats and newly dropped tracks</p>
          </div>
        </div>

        <div className="flex items-center gap-3.5 overflow-x-auto pb-2 no-scrollbar px-1">
          {newReleases.map((song) => (
            <SongCard key={song.id} song={song} size="wide" contextQueue={newReleases} />
          ))}
        </div>
      </section>

      {/* Popular Artists (Circular Profiles) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="font-display font-bold text-base sm:text-lg text-white tracking-tight">
              Popular Artists
            </h3>
            <p className="text-xs text-slate-400">Voices shaping contemporary sounds</p>
          </div>
        </div>

        <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar px-1">
          {artists.map((artist) => (
            <ArtistCard key={artist.id} artist={artist} />
          ))}
        </div>
      </section>

      {/* Mood & Genre (Category Cards) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="font-display font-bold text-base sm:text-lg text-white tracking-tight">
              Mood & Genre
            </h3>
            <p className="text-xs text-slate-400">Explore music tailored to your vibe</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5 px-1">
          {GENRE_CATEGORIES.map((genre) => (
            <button
              key={genre.id}
              onClick={() => handleGenreClick(genre.id)}
              className={`relative overflow-hidden p-3.5 rounded-2xl bg-gradient-to-br ${genre.color} text-left shadow-md hover:scale-[1.02] active:scale-95 transition-all duration-200 group border border-white/10`}
            >
              <div className="relative z-10">
                <span className="font-display font-bold text-sm sm:text-base text-white block">
                  {genre.label}
                </span>
                <span className="text-[10px] text-white/70 mt-0.5 block">Explore</span>
              </div>
              <div className="absolute -bottom-2 -right-2 w-12 h-12 rounded-full bg-white/10 blur-sm group-hover:scale-125 transition-transform" />
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};
