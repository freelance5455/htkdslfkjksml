import React, { useState } from 'react';
import {
  Film,
  Plus,
  Video,
  Sparkles,
  Download,
  Settings,
  FolderOpen,
  MoreVertical,
  Copy,
  Trash2,
  Edit2,
  Play,
  ArrowRight,
  Share2,
  Sliders,
  Check,
  Cpu,
} from 'lucide-react';
import { Language, translations } from '../../i18n/translations';
import { Project, UserSubscription } from '../../types/editor';
import { createSampleProject } from '../../services/sampleMedia';

interface HomeScreenProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  projects: Project[];
  subscription: UserSubscription;
  onOpenPremium: () => void;
  onOpenNewProjectModal: () => void;
  onOpenTemplatesModal: () => void;
  onOpenExportedGallery: () => void;
  onOpenSettingsModal: () => void;
  onSelectProject: (project: Project) => void;
  onDeleteProject: (id: string) => void;
  onDuplicateProject: (project: Project) => void;
  onRenameProject: (id: string, newName: string) => void;
  onCreateProject: (project: Project) => void;
  onOpenShare: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  language,
  onLanguageChange,
  projects,
  subscription,
  onOpenPremium,
  onOpenNewProjectModal,
  onOpenTemplatesModal,
  onOpenExportedGallery,
  onOpenSettingsModal,
  onSelectProject,
  onDeleteProject,
  onDuplicateProject,
  onRenameProject,
  onCreateProject,
  onOpenShare,
}) => {
  const [activeTab, setActiveTab] = useState<'recent' | 'drafts'>('recent');
  const [projectMenuId, setProjectMenuId] = useState<string | null>(null);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [isQuickSampleLoading, setIsQuickSampleLoading] = useState(false);

  const t = translations[language];

  const handleQuickDemo = async () => {
    setIsQuickSampleLoading(true);
    try {
      const demo = await createSampleProject();
      onCreateProject(demo);
    } catch (e) {
      console.error(e);
    } finally {
      setIsQuickSampleLoading(false);
    }
  };

  const handleStartRename = (project: Project) => {
    setRenamingId(project.id);
    setRenameValue(project.name);
    setProjectMenuId(null);
  };

  const handleSaveRename = (id: string) => {
    if (renameValue.trim()) {
      onRenameProject(id, renameValue.trim());
    }
    setRenamingId(null);
  };

  const filteredProjects = activeTab === 'recent'
    ? projects
    : projects.filter(p => p.clips.length === 0 || p.duration < 10);

  // Compute total duration of all projects
  const totalTimelineDuration = projects.reduce((acc, p) => acc + (p.duration || 0), 0);

  return (
    <div className="min-h-screen bg-[#09090b] text-neutral-100 flex flex-col font-sans selection:bg-amber-500 selection:text-black">
      {/* Studio Header Bar */}
      <div className="w-full bg-[#111114]/90 backdrop-blur-xl border-b border-white/[0.06] px-4 sm:px-8 py-5">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/25 ring-1 ring-white/20">
                <Film className="w-5 h-5 text-black stroke-[2.5]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight bg-gradient-to-r from-neutral-100 via-neutral-200 to-neutral-400 bg-clip-text text-transparent">
                    CLIPORA STUDIO
                  </h1>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-400/10 text-amber-300 border border-amber-400/30 font-bold">
                    PRO 4K
                  </span>
                </div>
                <p className="text-xs text-neutral-400 mt-0.5">
                  {language === 'hi'
                    ? 'प्रोफेशनल नॉन-एआई वीडियो एडिटर • मल्टी-ट्रैक टाइमलाइन व 60 FPS एक्सपोर्ट'
                    : 'Professional Local Video Editing Suite • Multi-track Timeline & 60 FPS'}
                </p>
              </div>
            </div>
          </div>

          {/* Quick Studio Bar Nav Actions */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onOpenShare}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-white/10 hover:border-amber-400/40 text-xs font-semibold text-neutral-300 hover:text-white transition-all shadow-sm"
              title="Share App & APK"
            >
              <Share2 className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'hi' ? 'APK व शेयर' : 'Share / APK'}</span>
            </button>
            <button
              onClick={onOpenTemplatesModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-white/10 hover:border-amber-400/40 text-xs font-semibold text-neutral-300 hover:text-white transition-all shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'hi' ? '20 टेम्पलेट्स' : '20 Templates'}</span>
            </button>
            <button
              onClick={onOpenExportedGallery}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-white/10 text-xs font-semibold text-neutral-300 hover:text-white transition-all shadow-sm"
            >
              <Download className="w-3.5 h-3.5 text-orange-400" />
              <span>{t.exported}</span>
            </button>
            <button
              onClick={onOpenSettingsModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-white/10 text-xs font-semibold text-neutral-300 hover:text-white transition-all shadow-sm"
            >
              <Settings className="w-3.5 h-3.5 text-neutral-400" />
              <span>{t.settings}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Studio Body Container */}
      <div className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-8 py-6 space-y-6">
        
        {/* Studio Hardware & Engine Status Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#111114] border border-white/[0.06] rounded-xl p-3 text-xs">
          <div className="flex items-center gap-2.5 px-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/15 flex items-center justify-center text-amber-400 shrink-0">
              <Film className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-[10px] text-neutral-500 font-mono uppercase">{language === 'hi' ? 'कुल प्रोजेक्ट्स' : 'Active Projects'}</p>
              <p className="text-xs font-bold text-neutral-200">{projects.length} {language === 'hi' ? 'प्रोजेक्ट्स' : 'Projects'}</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 px-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/15 flex items-center justify-center text-emerald-400 shrink-0">
              <Cpu className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-[10px] text-neutral-500 font-mono uppercase">{language === 'hi' ? 'रेंडर इंजन' : 'Render Engine'}</p>
              <p className="text-xs font-bold text-neutral-200">Hardware 60 FPS</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 px-2">
            <div className="w-7 h-7 rounded-lg bg-blue-500/15 flex items-center justify-center text-blue-400 shrink-0">
              <Video className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-[10px] text-neutral-500 font-mono uppercase">{language === 'hi' ? 'टाइमलाइन कुल समय' : 'Total Master Time'}</p>
              <p className="text-xs font-bold text-neutral-200">{Math.round(totalTimelineDuration)}s</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 px-2">
            <div className="w-7 h-7 rounded-lg bg-purple-500/15 flex items-center justify-center text-purple-400 shrink-0">
              <Sliders className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-[10px] text-neutral-500 font-mono uppercase">{language === 'hi' ? 'एक्सपोर्ट फॉर्मेट' : 'Export Format'}</p>
              <p className="text-xs font-bold text-neutral-200">MP4 / WebM 4K</p>
            </div>
          </div>
        </div>

        {/* 4 Professional Launch Tiles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Tile 1: New Project */}
          <button
            onClick={onOpenNewProjectModal}
            className="group relative p-4 rounded-xl bg-gradient-to-br from-amber-500/20 via-amber-500/10 to-transparent border border-amber-500/40 hover:border-amber-400 flex flex-col justify-between text-left transition-all hover:-translate-y-0.5 shadow-lg shadow-black/40 min-h-[135px]"
          >
            <div className="w-9 h-9 rounded-lg bg-amber-400 text-black flex items-center justify-center shadow-md shadow-amber-400/30 group-hover:scale-105 transition-transform">
              <Plus className="w-5 h-5 stroke-[3]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
                  {t.newProject}
                </h3>
                <ArrowRight className="w-3.5 h-3.5 text-amber-400 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
              </div>
              <p className="text-[11px] text-neutral-400 mt-1 line-clamp-1">
                {language === 'hi' ? '16:9, 9:16, 1:1, 4:5 मल्टी-लेयर टाइमलाइन' : 'Create 16:9, 9:16, 1:1, 4:5 multi-track project'}
              </p>
            </div>
          </button>

          {/* Tile 2: 20 Cinematic Templates */}
          <button
            onClick={onOpenTemplatesModal}
            className="group p-4 rounded-xl bg-[#111114] border border-white/[0.08] hover:border-amber-500/40 flex flex-col justify-between text-left transition-all hover:-translate-y-0.5 shadow-md shadow-black/40 min-h-[135px]"
          >
            <div className="w-9 h-9 rounded-lg bg-neutral-800 flex items-center justify-center text-amber-400 group-hover:bg-amber-400 group-hover:text-black transition-colors">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
                {language === 'hi' ? '20 सिनेमैटिक टेम्पलेट्स' : '20 Cinematic Templates'}
              </h3>
              <p className="text-[11px] text-neutral-400 mt-1 line-clamp-1">
                {language === 'hi' ? 'हॉलीवुड, रील्स, ट्रैवल, विंटेज व साइबरपंक' : 'Hollywood, Reels, Travel, Vintage & Cyberpunk'}
              </p>
            </div>
          </button>

          {/* Tile 3: Exported Gallery */}
          <button
            onClick={onOpenExportedGallery}
            className="group p-4 rounded-xl bg-[#111114] border border-white/[0.08] hover:border-white/20 flex flex-col justify-between text-left transition-all hover:-translate-y-0.5 shadow-md shadow-black/40 min-h-[135px]"
          >
            <div className="w-9 h-9 rounded-lg bg-neutral-800 flex items-center justify-center text-orange-400 group-hover:bg-orange-500 group-hover:text-white transition-colors">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white group-hover:text-neutral-200 transition-colors">
                {language === 'hi' ? 'एक्सपोर्टेड वीडियो गैलरी' : 'Exported Video Gallery'}
              </h3>
              <p className="text-[11px] text-neutral-400 mt-1 line-clamp-1">
                {language === 'hi' ? 'डिवाइस में डाउनलोड की गई वीडियो' : 'View & share finished video exports'}
              </p>
            </div>
          </button>

          {/* Tile 4: Instant Hollywood Demo Project */}
          <button
            onClick={handleQuickDemo}
            disabled={isQuickSampleLoading}
            className="group p-4 rounded-xl bg-[#111114] border border-white/[0.08] hover:border-white/20 flex flex-col justify-between text-left transition-all hover:-translate-y-0.5 shadow-md shadow-black/40 min-h-[135px]"
          >
            <div className="w-9 h-9 rounded-lg bg-neutral-800 flex items-center justify-center text-cyan-400 group-hover:bg-cyan-500 group-hover:text-black transition-colors">
              <Play className="w-4 h-4 ml-0.5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white group-hover:text-neutral-200 transition-colors">
                {language === 'hi' ? 'डेमो प्रोजेक्ट लोड करें' : 'Load Demo Project'}
              </h3>
              <p className="text-[11px] text-neutral-400 mt-1 line-clamp-1">
                {language === 'hi' ? 'रेडी-टू-एडिट 4K सैंपल प्रोजेक्ट' : 'Pre-configured color grade & multi-layer timeline'}
              </p>
            </div>
          </button>
        </div>

        {/* Projects Section */}
        <div className="space-y-4 pt-2">
          {/* Section Tab Bar */}
          <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
            <div className="flex items-center gap-4 text-xs font-bold">
              <button
                onClick={() => setActiveTab('recent')}
                className={`pb-2 border-b-2 transition-colors ${
                  activeTab === 'recent'
                    ? 'border-amber-400 text-amber-400'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200'
                }`}
              >
                {language === 'hi' ? 'हालिया प्रोजेक्ट्स' : 'Recent Projects'} ({projects.length})
              </button>
              <button
                onClick={() => setActiveTab('drafts')}
                className={`pb-2 border-b-2 transition-colors ${
                  activeTab === 'drafts'
                    ? 'border-amber-400 text-amber-400'
                    : 'border-transparent text-neutral-400 hover:text-neutral-200'
                }`}
              >
                {language === 'hi' ? 'ड्राफ्ट्स' : 'Drafts'}
              </button>
            </div>

            <button
              onClick={onOpenNewProjectModal}
              className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>{t.newProject}</span>
            </button>
          </div>

          {/* Project Cards Grid */}
          <div>
            {filteredProjects.length === 0 ? (
              <div className="text-center py-16 bg-[#111114] rounded-xl border border-white/[0.06]">
                <FolderOpen className="w-12 h-12 text-neutral-600 mx-auto mb-3 opacity-50" />
                <h4 className="text-sm font-bold text-neutral-300">
                  {language === 'hi' ? 'कोई प्रोजेक्ट नहीं मिला' : 'No projects yet'}
                </h4>
                <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
                  {language === 'hi'
                    ? 'नया प्रोजेक्ट शुरू करें या 20 सिनेमैटिक टेम्पलेट्स में से कोई एक चुनें'
                    : 'Create a new project or start with one of 20 cinematic master templates.'}
                </p>
                <div className="flex items-center justify-center gap-3 mt-4">
                  <button
                    onClick={onOpenNewProjectModal}
                    className="py-2 px-4 rounded-lg bg-amber-400 text-black text-xs font-bold hover:bg-amber-300 transition-colors shadow-sm"
                  >
                    + {t.newProject}
                  </button>
                  <button
                    onClick={onOpenTemplatesModal}
                    className="py-2 px-4 rounded-lg bg-neutral-800 text-neutral-200 text-xs font-semibold hover:bg-neutral-700 transition-colors border border-white/10"
                  >
                    {language === 'hi' ? 'टेम्पलेट्स देखें' : 'Browse Templates'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredProjects.map((proj) => {
                  const isRenaming = renamingId === proj.id;
                  const clipCount = proj.clips.length;
                  const videoClips = proj.clips.filter(c => c.type === 'video');

                  return (
                    <div
                      key={proj.id}
                      onClick={() => onSelectProject(proj)}
                      className="group bg-[#111114] border border-white/[0.08] hover:border-amber-400/50 rounded-xl p-3.5 flex flex-col justify-between transition-all hover:shadow-xl hover:shadow-black/60 cursor-pointer"
                    >
                      <div>
                        {/* Project Thumbnail Preview Box */}
                        <div className="h-32 rounded-lg bg-gradient-to-br from-neutral-900 via-neutral-800 to-black relative overflow-hidden flex flex-col justify-between p-2.5 border border-white/5 shadow-inner">
                          {/* Top Badges */}
                          <div className="flex items-center justify-between z-10">
                            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-amber-300 border border-white/10">
                              {proj.aspectRatio}
                            </span>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-neutral-300">
                              {proj.duration.toFixed(1)}s
                            </span>
                          </div>

                          {/* Hover Play Target Icon */}
                          <div className="absolute inset-0 m-auto w-10 h-10 rounded-full bg-amber-400 text-black flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all scale-75 group-hover:scale-100 shadow-xl shadow-amber-400/40 z-10">
                            <Play className="w-4 h-4 fill-black ml-0.5" />
                          </div>

                          {/* Bottom info strip on thumbnail */}
                          <div className="flex items-center justify-between text-[9px] font-mono text-neutral-400 z-10">
                            <span>{clipCount} {clipCount === 1 ? 'Clip' : 'Clips'}</span>
                            <span>{proj.fps || 30} FPS</span>
                          </div>
                        </div>

                        {/* Project Title and Metadata */}
                        <div className="mt-3">
                          {isRenaming ? (
                            <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                              <input
                                type="text"
                                value={renameValue}
                                autoFocus
                                onChange={(e) => setRenameValue(e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && handleSaveRename(proj.id)}
                                className="w-full bg-neutral-950 border border-amber-400 text-xs text-white rounded px-2 py-1 outline-none font-bold"
                              />
                              <button
                                onClick={() => handleSaveRename(proj.id)}
                                className="p-1 rounded bg-amber-400 text-black"
                              >
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center justify-between">
                              <h4 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors truncate">
                                {proj.name}
                              </h4>
                              <div className="relative" onClick={(e) => e.stopPropagation()}>
                                <button
                                  onClick={() => setProjectMenuId(projectMenuId === proj.id ? null : proj.id)}
                                  className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white"
                                >
                                  <MoreVertical className="w-4 h-4" />
                                </button>

                                {/* Dropdown Menu */}
                                {projectMenuId === proj.id && (
                                  <div className="absolute right-0 top-6 w-36 bg-[#18181c] border border-white/10 rounded-xl shadow-2xl z-30 py-1 text-xs">
                                    <button
                                      onClick={() => handleStartRename(proj)}
                                      className="w-full px-3 py-1.5 text-left hover:bg-neutral-800 flex items-center gap-2 text-neutral-300 hover:text-white"
                                    >
                                      <Edit2 className="w-3.5 h-3.5" />
                                      <span>{language === 'hi' ? 'नाम बदलें' : 'Rename'}</span>
                                    </button>
                                    <button
                                      onClick={() => {
                                        onDuplicateProject(proj);
                                        setProjectMenuId(null);
                                      }}
                                      className="w-full px-3 py-1.5 text-left hover:bg-neutral-800 flex items-center gap-2 text-neutral-300 hover:text-white"
                                    >
                                      <Copy className="w-3.5 h-3.5" />
                                      <span>{language === 'hi' ? 'डुप्लीकेट' : 'Duplicate'}</span>
                                    </button>
                                    <div className="my-1 border-t border-white/5" />
                                    <button
                                      onClick={() => {
                                        onDeleteProject(proj.id);
                                        setProjectMenuId(null);
                                      }}
                                      className="w-full px-3 py-1.5 text-left hover:bg-red-950/60 flex items-center gap-2 text-red-400 hover:text-red-300"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                      <span>{language === 'hi' ? 'डिलीट करें' : 'Delete'}</span>
                                    </button>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                          <div className="flex items-center gap-2 text-[11px] text-neutral-500 mt-1">
                            <span>{new Date(proj.updatedAt || proj.createdAt).toLocaleDateString()}</span>
                            <span>•</span>
                            <span>{proj.tracks.length} Tracks</span>
                          </div>
                        </div>
                      </div>

                      {/* Card Footer Launch Button */}
                      <div className="mt-3 pt-2.5 border-t border-white/[0.05] flex items-center justify-between text-xs text-neutral-400">
                        <span className="text-[10px] font-mono text-amber-400/80">READY TO EDIT</span>
                        <div className="flex items-center gap-1 text-amber-400 group-hover:translate-x-0.5 transition-transform font-bold text-[11px]">
                          <span>{language === 'hi' ? 'एडिटर खोलें' : 'Open Studio'}</span>
                          <ArrowRight className="w-3 h-3" />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
