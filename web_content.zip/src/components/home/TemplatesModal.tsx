import React, { useState, useMemo } from 'react';
import { X, Sparkles, Film, Smartphone, Search, Check, Play, Loader2, Video } from 'lucide-react';
import { Language, translations } from '../../i18n/translations';
import { Project } from '../../types/editor';
import { VIDEO_TEMPLATES, buildProjectFromTemplate, VideoTemplateDef } from '../../services/templatesCatalog';

interface TemplatesModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onSelectTemplate: (project: Project) => void;
}

export const TemplatesModal: React.FC<TemplatesModalProps> = ({
  isOpen,
  onClose,
  language,
  onSelectTemplate,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [loadingTemplateId, setLoadingTemplateId] = useState<string | null>(null);

  if (!isOpen) return null;
  const t = translations[language];

  const categories = [
    { id: 'all', label: language === 'hi' ? 'सभी (20)' : 'All (20)' },
    { id: 'Cinematic', label: language === 'hi' ? 'सिनेमैटिक 🎬' : 'Cinematic 🎬' },
    { id: 'Reels & Shorts', label: language === 'hi' ? 'रील्स & शॉर्ट्स 📱' : 'Reels & Shorts 📱' },
    { id: 'Travel & Nature', label: language === 'hi' ? 'ट्रैवल & नेचर 🌴' : 'Travel & Nature 🌴' },
    { id: 'Lifestyle & Fashion', label: language === 'hi' ? 'फैशन & वेडिंग 💍' : 'Fashion & Wedding 💍' },
    { id: 'Vlog & Tech', label: language === 'hi' ? 'व्लॉग & टेक 🎙️' : 'Vlog & Tech 🎙️' },
    { id: 'Aesthetic & Vintage', label: language === 'hi' ? 'विंटेज & लो-फाई 📼' : 'Vintage & Lofi 📼' },
    { id: 'Sports & Gaming', label: language === 'hi' ? 'स्पोर्ट्स & गेमिंग ⚡' : 'Sports & Gaming ⚡' },
  ];

  const filteredTemplates = useMemo(() => {
    return VIDEO_TEMPLATES.filter((tpl) => {
      const matchesCategory = selectedCategory === 'all' || tpl.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q ||
        tpl.titleEn.toLowerCase().includes(q) ||
        tpl.titleHi.toLowerCase().includes(q) ||
        tpl.descEn.toLowerCase().includes(q) ||
        tpl.descHi.toLowerCase().includes(q) ||
        tpl.badge.toLowerCase().includes(q);

      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  const handleApplyTemplate = async (templateId: string) => {
    setLoadingTemplateId(templateId);
    try {
      const project = await buildProjectFromTemplate(templateId, language);
      onSelectTemplate(project);
      onClose();
    } catch (e) {
      console.error('Failed to instantiate template', e);
    } finally {
      setLoadingTemplateId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-white">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between shrink-0 bg-neutral-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Sparkles className="w-5 h-5 text-black" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold">
                  {language === 'hi' ? '20 प्रो सिनेमैटिक वीडियो टेम्पलेट्स' : '20 Pro Cinematic Video Templates'}
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                  PRO GRADE
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                {language === 'hi'
                  ? 'हॉलीवुड, रील्स, ट्रैवल, साइबरपंक, विंटेज व फैशन के 20 रेडी-टू-एडिट मास्टर टेम्पलेट्स'
                  : 'Hollywood, Reels, Travel, Cyberpunk, Vintage & Fashion ready-to-edit master templates'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar & Categories */}
        <div className="p-3 sm:p-4 bg-neutral-900/90 border-b border-neutral-800 shrink-0 space-y-3">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                language === 'hi'
                  ? 'टेम्पलेट खोजें (उदा. हॉलीवुड, रील्स, ट्रैवल, नियॉन, विंटेज, जिम)...'
                  : 'Search templates (e.g. Hollywood, Reels, Travel, Neon, Vintage, Gym)...'
              }
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-10 pr-4 py-2 text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors"
            />
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-full whitespace-nowrap font-semibold transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-amber-400 text-black font-bold shadow-md shadow-amber-400/25'
                    : 'bg-neutral-950 text-neutral-400 hover:text-white hover:bg-neutral-800 border border-neutral-800/80'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Templates Grid Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {filteredTemplates.length === 0 ? (
            <div className="py-16 text-center text-neutral-500">
              <Video className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm font-semibold">
                {language === 'hi' ? 'कोई टेम्पलेट नहीं मिला' : 'No templates match your search'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredTemplates.map((tpl) => {
                const isLoading = loadingTemplateId === tpl.id;
                const isVertical = tpl.ratio === '9:16';
                const isSquare = tpl.ratio === '1:1';

                return (
                  <div
                    key={tpl.id}
                    className="group bg-neutral-950/80 border border-neutral-800/90 hover:border-amber-500/50 rounded-2xl p-4 flex flex-col justify-between transition-all hover:shadow-xl hover:shadow-black/50 hover:-translate-y-0.5"
                  >
                    <div>
                      {/* Visual Header Banner */}
                      <div className={`h-28 rounded-xl bg-gradient-to-br ${tpl.gradient} relative overflow-hidden flex flex-col justify-between p-3 shadow-inner`}>
                        <div className="flex items-center justify-between z-10">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md text-amber-300 font-bold border border-white/10">
                            {tpl.badge}
                          </span>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-white font-bold border border-white/10">
                              {tpl.ratio}
                            </span>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-black/60 text-neutral-300">
                              {tpl.duration}s
                            </span>
                          </div>
                        </div>

                        {/* Title Watermark Overlay */}
                        <div className="z-10">
                          <p className="text-[11px] font-extrabold tracking-wider text-white drop-shadow-md truncate uppercase">
                            {tpl.headlineEn}
                          </p>
                        </div>

                        {/* Background stylistic geometric circle */}
                        <div className="absolute -bottom-6 -right-6 w-24 h-24 rounded-full bg-white/10 blur-xl pointer-events-none" />
                      </div>

                      {/* Template Details */}
                      <div className="mt-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-1">
                            {language === 'hi' ? tpl.titleHi : tpl.titleEn}
                          </h4>
                        </div>
                        <p className="text-[11px] text-neutral-400 mt-1 line-clamp-2 leading-relaxed">
                          {language === 'hi' ? tpl.descHi : tpl.descEn}
                        </p>
                      </div>
                    </div>

                    {/* Action Button */}
                    <div className="mt-4 pt-3 border-t border-neutral-900 flex items-center justify-between">
                      <span className="text-[10px] text-neutral-500 font-mono">
                        {tpl.category}
                      </span>
                      <button
                        onClick={() => handleApplyTemplate(tpl.id)}
                        disabled={isLoading || loadingTemplateId !== null}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-black font-bold text-xs transition-all shadow-md shadow-amber-500/20 disabled:opacity-50"
                      >
                        {isLoading ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            <span>{language === 'hi' ? 'लोडिंग...' : 'Loading...'}</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3 h-3 fill-black" />
                            <span>{language === 'hi' ? 'एडिट करें' : 'Use Template'}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 sm:p-4 bg-neutral-950 border-t border-neutral-800 text-xs text-neutral-500 flex items-center justify-between shrink-0">
          <span>
            {language === 'hi'
              ? '✨ 20 प्रीमियम सिनेमैटिक टेम्पलेट्स — सभी क्लिप्स, टाइटल्स व बीजीएम 100% कस्टमाइज़ेबल हैं'
              : '✨ 20 Pro Cinematic Templates — All clips, titles, effects & audio are 100% customizable'}
          </span>
          <button
            onClick={onClose}
            className="px-3 py-1 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          >
            {language === 'hi' ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
