import React from 'react';
import { useScrollReveal } from '../../hooks/useScrollReveal';

const PROMO_IMAGE = 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1200&auto=format&fit=crop&q=80';

interface PromoBannerProps {
  onExplore?: () => void;
}

export const PromoBanner: React.FC<PromoBannerProps> = ({ onExplore }) => {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });

  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2 sm:py-3">
      <div
        onClick={onExplore}
        className={`relative w-full h-[140px] sm:h-[180px] md:h-[220px] overflow-hidden rounded-2xl sm:rounded-3xl shadow-2xs hover:shadow-xs transition-all duration-500 ease-out cursor-pointer select-none bg-slate-100 border border-[#EAEAEA] ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
        }`}
      >
        <img
          src={PROMO_IMAGE}
          alt="OMAZIFY Collection"
          className="w-full h-full block object-cover object-center transition-transform duration-500 ease-out hover:scale-[1.01]"
          loading="lazy"
        />
      </div>
    </section>
  );
};

export default PromoBanner;
