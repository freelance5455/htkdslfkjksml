import { AlertCircle, CheckCircle2, Timer, Truck } from "lucide-react";

export default function MetricsBand({ stats }) {
  const cards = [
    {
      label: "Waiting on the team",
      value: stats.open,
      caption: "Newly reported, not yet picked up",
      icon: AlertCircle,
      tint: "#d99a2b",
    },
    {
      label: "Being cleaned up",
      value: stats.inProgress,
      caption: "Crews working on site",
      icon: Truck,
      tint: "#2f7d95",
    },
    {
      label: "Resolved",
      value: stats.resolved,
      caption: `${stats.resolvedRate}% of everything reported`,
      icon: CheckCircle2,
      tint: "#16653f",
    },
    {
      label: "Average close time",
      value: stats.avgDays ?? "—",
      suffix: stats.avgDays ? "days" : "",
      caption: "From report to cleared spot",
      icon: Timer,
      tint: "#7b6cb0",
    },
  ];

  return (
    <section className="mx-auto max-w-6xl px-5 pt-10 lg:px-8">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map((card) => (
          <div
            key={card.label}
            className="rounded-2xl border border-border bg-card p-4 transition-colors hover:border-primary/25 sm:p-5"
          >
            <span
              className="flex h-8 w-8 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${card.tint}1a` }}
            >
              <card.icon className="h-4 w-4" style={{ color: card.tint }} />
            </span>
            <p className="mt-4 flex items-baseline gap-1.5">
              <span className="font-display text-3xl font-semibold leading-none tabular-nums">
                {card.value}
              </span>
              {card.suffix && (
                <span className="text-[11px] text-muted-foreground">{card.suffix}</span>
              )}
            </p>
            <p className="mt-2 text-[11px] font-medium uppercase tracking-[0.1em] text-foreground/70">
              {card.label}
            </p>
            <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{card.caption}</p>
          </div>
        ))}
      </div>
    </section>
  );
}