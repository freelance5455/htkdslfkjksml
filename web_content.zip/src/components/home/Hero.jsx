import { Link } from "react-router-dom";
import { ArrowRight, ArrowUpRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Hero({ stats }) {
  const peak = Math.max(1, ...stats.weekly.map((w) => w.count));

  return (
    <section className="relative overflow-hidden border-b border-border/60">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(115%_85%_at_88%_-10%,hsl(var(--accent))_0%,transparent_58%)]" />
      <div className="pointer-events-none absolute -left-24 top-24 h-72 w-72 rounded-full bg-[#E9DFC9]/40 blur-3xl" />

      <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-5 py-14 lg:grid-cols-[1.08fr_0.92fr] lg:px-8 lg:py-20">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1.5 text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
            <Sparkles className="h-3 w-3 text-primary" />
            Coimbatore&apos;s neighbourhood waste watch
          </span>

          <h1 className="text-balance mt-6 font-display text-[2.5rem] font-semibold leading-[1.05] tracking-tight sm:text-[3.4rem]">
            A cleaner Coimbatore
            <br className="hidden sm:block" /> starts with one report.
          </h1>

          <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-muted-foreground">
            Flag dumped garbage, stagnant water, improper waste disposal or e-waste. Every
            report lands on the public board, and the municipal team updates it as the work
            gets done.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Button asChild size="lg" className="rounded-full px-6">
              <Link to="/report">
                Report an issue
                <ArrowUpRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="rounded-full bg-transparent px-6">
              <a href="#board">
                See what&apos;s reported
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>

          <p className="mt-5 text-xs text-muted-foreground">
            {stats.total} issues on the board · {stats.resolvedRate}% resolved so far
          </p>
        </div>

        <div className="relative">
          <div className="rounded-[26px] border border-border bg-card p-6 soft-ring">
            <div className="flex items-center justify-between">
              <p className="font-display text-sm font-semibold">Live board pulse</p>
              <span className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary/60" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-primary" />
                </span>
                updating
              </span>
            </div>

            <div className="mt-5 flex items-end gap-3">
              <span className="font-display text-5xl font-semibold leading-none">{stats.open}</span>
              <span className="pb-1 text-xs leading-snug text-muted-foreground">
                open reports
                <br />
                waiting on the team
              </span>
            </div>

            <div className="mt-6 flex h-24 items-end gap-2">
              {stats.weekly.map((week) => (
                <div key={week.label} className="flex flex-1 flex-col items-center gap-2">
                  <div
                    className="w-full rounded-md bg-primary/15 transition-all"
                    style={{ height: `${Math.max(8, (week.count / peak) * 84)}px` }}
                  >
                    <div
                      className="h-full w-full rounded-md bg-primary/70"
                      style={{ opacity: 0.35 + (week.count / peak) * 0.65 }}
                    />
                  </div>
                  <span className="text-[9px] text-muted-foreground">{week.label}</span>
                </div>
              ))}
            </div>

            <div className="mt-6 grid grid-cols-3 gap-2 border-t border-border/70 pt-5">
              {[
                { label: "Reported", value: stats.open, color: "#d99a2b" },
                { label: "Cleaning", value: stats.inProgress, color: "#2f7d95" },
                { label: "Resolved", value: stats.resolved, color: "#16653f" },
              ].map((item) => (
                <div key={item.label}>
                  <span className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.1em] text-muted-foreground">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: item.color }} />
                    {item.label}
                  </span>
                  <p className="mt-1 font-display text-lg font-semibold tabular-nums">{item.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}