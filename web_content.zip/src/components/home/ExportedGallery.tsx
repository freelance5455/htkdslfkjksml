import React, { useState } from 'react';
import { Play, Download, Trash2, X, Film, Calendar, Clock, HardDrive } from 'lucide-react';
import { Language, translations } from '../../i18n/translations';
import { ExportedProjectRecord } from '../../types/editor';

interface ExportedGalleryProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  records: ExportedProjectRecord[];
  onDeleteRecord: (id: string) => void;
}

export const ExportedGallery: React.FC<ExportedGalleryProps> = ({
  isOpen,
  onClose,
  language,
  records,
  onDeleteRecord,
}) => {
  const [playingRecord, setPlayingRecord] = useState<ExportedProjectRecord | null>(null);

  if (!isOpen) return null;
  const t = translations[language];

  const formatBytes = (bytes: number) => {
    if (!bytes || bytes === 0) return '0 MB';
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl p-5 sm:p-6 text-white shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center">
              <Film className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-bold">{t.exported}</h2>
              <p className="text-xs text-neutral-400">
                {records.length} {language === 'hi' ? 'सहेजे गए वीडियो' : 'rendered videos'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player Modal Overlay */}
        {playingRecord && (
          <div className="my-3 p-3 bg-neutral-950 rounded-xl border border-neutral-800 flex flex-col items-center">
            <div className="w-full flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-amber-400 truncate">{playingRecord.projectName}</span>
              <button
                onClick={() => setPlayingRecord(null)}
                className="text-xs text-neutral-400 hover:text-white"
              >
                {t.close}
              </button>
            </div>
            <video
              src={playingRecord.videoUrl}
              controls
              autoPlay
              className="max-h-64 rounded-lg bg-black object-contain w-full"
            />
          </div>
        )}

        {/* Records list */}
        <div className="flex-1 overflow-y-auto py-4 space-y-3 pr-1">
          {records.length === 0 ? (
            <div className="text-center py-12 text-neutral-500">
              <Film className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm font-medium">
                {language === 'hi' ? 'अभी तक कोई एक्सपोर्ट किया गया वीडियो नहीं है।' : 'No exported videos yet.'}
              </p>
              <p className="text-xs text-neutral-600 mt-1">
                {language === 'hi' ? 'एडिटर में एक्सपोर्ट दबाकर वीडियो बनाएं।' : 'Render and export your edits to view and download them here.'}
              </p>
            </div>
          ) : (
            records.map((rec) => (
              <div
                key={rec.id}
                className="bg-neutral-950/70 border border-neutral-800/80 hover:border-neutral-700 rounded-xl p-3.5 flex items-center justify-between gap-3 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <button
                    onClick={() => setPlayingRecord(rec)}
                    className="w-12 h-12 rounded-lg bg-neutral-800 hover:bg-amber-500 hover:text-black flex items-center justify-center shrink-0 transition-colors text-amber-400"
                    title="Play Preview"
                  >
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </button>

                  <div className="min-w-0">
                    <h3 className="text-xs sm:text-sm font-bold text-white truncate mb-1">
                      {rec.projectName}
                    </h3>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-neutral-400 font-mono">
                      <span className="flex items-center gap-1">
                        <HardDrive className="w-3 h-3 text-neutral-500" />
                        {formatBytes(rec.fileSize)}
                      </span>
                      <span>{rec.resolution}</span>
                      <span>{rec.fps} FPS</span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-neutral-500" />
                        {new Date(rec.timestamp).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <a
                    href={rec.videoUrl}
                    download={`${rec.projectName.replace(/\s+/g, '_')}_clipora.mp4`}
                    className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-amber-400 transition-colors"
                    title={t.downloadVideo}
                  >
                    <Download className="w-4 h-4" />
                  </a>
                  <button
                    onClick={() => onDeleteRecord(rec.id)}
                    className="p-2 rounded-lg bg-neutral-800 hover:bg-red-950/50 text-neutral-400 hover:text-red-400 transition-colors"
                    title={t.delete}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
