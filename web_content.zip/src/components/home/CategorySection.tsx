import React from 'react';
import {
  Shirt, ShoppingBag, Watch, Smartphone, Home,
  Sparkles, ShoppingCart, Grid, ArrowRight,
  Footprints, Layers
} from 'lucide-react';
import { useScrollReveal } from '../../hooks/useScrollReveal';

interface CategorySectionProps {
  onSelectCategory: (categoryName: string) => void;
  onViewAll: () => void;
}

interface CategoryTile {
  id: string;
  name: string;
  targetCategory: string;
  icon: React.ComponentType<{ className?: string }>;
  isViewAll?: boolean;
}

const CATEGORY_ITEMS: CategoryTile[] = [
  { id: 'fashion', name: 'Fashion', targetCategory: 'Men', icon: Shirt },
  { id: 'shoes', name: 'Shoes & Sneakers', targetCategory: 'Men', icon: Footprints },
  { id: 'slippers', name: 'Slippers & Sandals', targetCategory: 'Men', icon: Layers },
  { id: 'bags', name: 'Bags', targetCategory: 'Bags', icon: ShoppingBag },
  { id: 'watches', name: 'Watches', targetCategory: 'Watches', icon: Watch },
  { id: 'electronics', name: 'Electronics', targetCategory: 'Accessories', icon: Smartphone },
  { id: 'home', name: 'Home & Kitchen', targetCategory: 'Accessories', icon: Home },
  { id: 'beauty', name: 'Beauty & Care', targetCategory: 'Women', icon: Sparkles },
  { id: 'grocery', name: 'Grocery', targetCategory: 'Accessories', icon: ShoppingCart },
  { id: 'more', name: 'More Categories', targetCategory: 'all', icon: Grid, isViewAll: true },
];

export const CategorySection: React.FC<CategorySectionProps> = ({
  onSelectCategory,
  onViewAll,
}) => {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });

  const handleCategoryClick = (item: CategoryTile) => {
    if (item.isViewAll) {
      onViewAll();
    } else {
      onSelectCategory(item.targetCategory);
    }
  };

  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-3 sm:py-5">
      {/* Header */}
      <div
        className={`flex items-center justify-between mb-3 sm:mb-4 transition-all duration-500 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
        }`}
      >
        <div className="flex items-center gap-2">
          <div className="w-2 h-5 bg-[#FFD400] rounded-full" />
          <div>
            <h2 className="text-base sm:text-lg md:text-xl font-black text-[#111111] tracking-tight leading-tight">
              Shop by Category
            </h2>
          </div>
        </div>

        <button
          onClick={onViewAll}
          className="inline-flex items-center gap-1 text-xs font-bold text-[#111111] hover:text-[#000000] cursor-pointer"
        >
          <span>All Categories</span>
          <ArrowRight className="w-3.5 h-3.5 text-[#FFD400]" />
        </button>
      </div>

      {/* Grid of evenly spaced category tiles */}
      <div className="grid grid-cols-5 sm:grid-cols-5 md:grid-cols-10 gap-2 sm:gap-2.5">
        {CATEGORY_ITEMS.map((cat) => {
          const IconComponent = cat.icon;
          return (
            <button
              key={cat.id}
              onClick={() => handleCategoryClick(cat)}
              className="group flex flex-col items-center justify-center p-2 sm:p-2.5 bg-white hover:bg-[#FFF9DB] border border-[#EAEAEA] hover:border-[#FFD400] rounded-xl sm:rounded-2xl transition-all duration-200 cursor-pointer shadow-2xs active:scale-95 text-center"
              title={cat.name}
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#FAFAFA] group-hover:bg-[#FFD400] flex items-center justify-center transition-colors mb-1.5 flex-shrink-0">
                <IconComponent className="w-5 h-5 text-[#111111] group-hover:text-[#000000] stroke-[1.8]" />
              </div>
              <span className="text-[10px] sm:text-[11px] font-bold text-[#111111] group-hover:text-[#000000] line-clamp-2 leading-tight">
                {cat.name}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
};

export default CategorySection;
