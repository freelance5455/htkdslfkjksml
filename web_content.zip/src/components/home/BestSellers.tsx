import React from 'react';
import { ArrowRight, SlidersHorizontal, LayoutGrid } from 'lucide-react';
import { Product } from '../../types';
import { ProductCard } from '../shop/ProductCard';
import { useScrollReveal } from '../../hooks/useScrollReveal';

interface BestSellersProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  wishlistIds: Set<string>;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
  onViewAll: () => void;
}

export const BestSellers: React.FC<BestSellersProps> = ({
  products,
  onSelectProduct,
  onAddToCart,
  wishlistIds,
  onToggleWishlist,
  onViewAll,
}) => {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });
  const bestsellers = products.filter((p) => p.isBestseller).slice(0, 5);

  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-3 sm:py-5">
      <div
        className={`bg-white rounded-2xl sm:rounded-3xl border border-[#EAEAEA] p-4 sm:p-6 shadow-2xs transition-all duration-700 ease-out ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-1.5 text-[10px] sm:text-xs font-black tracking-wider text-[#666666] uppercase">
              <span className="w-2 h-2 rounded-full bg-[#FFD400]" />
              <span>TOP TRENDING • CASH ON DELIVERY</span>
            </div>
            <h2 className="text-lg sm:text-2xl font-black text-[#111111] tracking-tight mt-0.5">
              Best Sellers
            </h2>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={onViewAll}
              title="Filter and browse options"
              aria-label="Filter and browse options"
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-[#FAFAFA] hover:bg-[#FFD400] text-[#111111] hover:text-[#000000] border border-[#EAEAEA] flex items-center justify-center cursor-pointer transition-colors shadow-2xs"
            >
              <SlidersHorizontal className="w-4 h-4" />
            </button>
            <button
              onClick={onViewAll}
              title="Switch product grid view"
              aria-label="Switch product grid view"
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-white hover:bg-[#FFF9DB] text-[#111111] border border-[#EAEAEA] flex items-center justify-center cursor-pointer transition-colors shadow-2xs"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={onViewAll}
              className="group ml-1 inline-flex items-center gap-1 text-xs sm:text-sm font-black text-[#111111] hover:text-[#000000] cursor-pointer"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#FFD400] transition-transform duration-200 group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
          {bestsellers.map((product, idx) => (
            <div
              key={product.id}
              style={{ transitionDelay: `${idx * 75}ms` }}
              className="h-full"
            >
              <ProductCard
                product={product}
                onSelect={onSelectProduct}
                onAddToCart={onAddToCart}
                isWishlisted={wishlistIds.has(product.id)}
                onToggleWishlist={onToggleWishlist}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BestSellers;
