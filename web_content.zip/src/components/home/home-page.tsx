import { Link } from "@tanstack/react-router";
import {
  ClipboardPaste,
  Code2,
  Eye,
  FolderOpen,
  Rocket,
  Smartphone,
} from "lucide-react";
import { NijoMark } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";

const FEATURES = [
  {
    icon: Smartphone,
    title: "Mobile first",
    text: "Built for thumbs, keyboards, and small screens — not a shrunk desktop IDE.",
  },
  {
    icon: Eye,
    title: "Live preview",
    text: "HTML, CSS, and JavaScript render in a sandboxed frame you can rotate between devices.",
  },
  {
    icon: Code2,
    title: "Multiple languages",
    text: "Syntax highlighting and auto-detect for web, mobile, and general-purpose languages.",
  },
  {
    icon: FolderOpen,
    title: "Open files",
    text: "Load a single file or unzip a whole project from your phone storage.",
  },
  {
    icon: ClipboardPaste,
    title: "Paste and run",
    text: "Drop in a snippet, tap Run, and read the result without a laptop.",
  },
  {
    icon: Rocket,
    title: "Code anywhere",
    text: "Install NIJO to your home screen and keep editing when the network drops.",
  },
];

export function HomePage() {
  return (
    <div className="relative min-h-dvh bg-bg text-fg">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-64 nijo-hero-wash" />
      <header className="relative mx-auto flex max-w-5xl items-center justify-between px-5 pb-4 pt-[max(1.25rem,env(safe-area-inset-top))]">
        <div className="flex items-center gap-3">
          <NijoMark className="size-10" />
          <div>
            <p className="text-sm font-medium tracking-tight">NIJO MOBILE</p>
            <p className="text-xs text-muted">Bouzidi Softworks</p>
          </div>
        </div>
        <Button asChild size="sm" variant="secondary">
          <Link to="/workspace">Open</Link>
        </Button>
      </header>

      <main className="relative mx-auto max-w-5xl px-5 pb-16">
        <section className="stagger-in max-w-xl pt-6 md:pt-16">
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-primary">NIJO MOBILE</p>
          <h1 className="mt-3 text-4xl font-medium tracking-tight md:text-6xl">
            Code Anywhere.
            <br />
            Build Anywhere.
          </h1>
          <p className="mt-4 max-w-md text-base leading-relaxed text-muted">
            A powerful mobile coding workspace that lets you write, paste, upload, preview and test
            your code directly from your phone.
          </p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg" className="w-full sm:w-auto">
              <Link to="/workspace">Start coding</Link>
            </Button>
            <Button asChild size="lg" variant="secondary" className="w-full sm:w-auto">
              <Link to="/workspace" search={{ intent: "open" }}>
                Open file
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="w-full sm:w-auto">
              <Link to="/workspace" search={{ intent: "paste" }}>
                Paste code
              </Link>
            </Button>
          </div>
        </section>

        <section className="mt-12 overflow-hidden rounded-xl bg-elevated p-4 shadow-nijo md:mt-16 md:p-6">
          <div className="rounded-lg bg-bg px-3 py-3 font-mono text-xs leading-relaxed text-muted">
            <div className="mb-3 flex items-center gap-1.5">
              <span className="size-2 rounded-full bg-danger/80" />
              <span className="size-2 rounded-full bg-warning/80" />
              <span className="size-2 rounded-full bg-success/80" />
              <span className="ml-2 text-xs uppercase tracking-[0.14em]">index.html</span>
            </div>
            <pre className="overflow-x-auto text-xs text-fg">
{`<h1>Hello World</h1>
<button>Run a line of JS</button>`}
            </pre>
            <p className="mt-3 text-xs text-success">Preview ready · Total: 150</p>
          </div>
        </section>

        <section className="mt-12 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((feature) => (
            <article key={feature.title} className="rounded-xl bg-elevated p-4 shadow-nijo">
              <feature.icon className="size-5 text-primary" />
              <h2 className="mt-3 text-base font-medium tracking-tight">{feature.title}</h2>
              <p className="mt-1 text-sm leading-relaxed text-muted">{feature.text}</p>
            </article>
          ))}
        </section>
      </main>

      <footer className="border-t border-border px-5 py-8 text-center">
        <p className="text-sm text-muted">Developed by Bouzidi Softworks</p>
        <p className="mt-1 text-xs text-subtle">NIJO MOBILE · Code Anywhere. Build Anywhere.</p>
      </footer>
    </div>
  );
}
