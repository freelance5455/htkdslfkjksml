import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Product } from '../../types';
import { ProductCard } from '../shop/ProductCard';
import { useScrollReveal } from '../../hooks/useScrollReveal';
import { useLanguage } from '../../context/LanguageContext';

interface ProductSectionProps {
  title: string;
  tag?: string;
  subtitle?: string;
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  wishlistIds: Set<string>;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
  onViewAll?: () => void;
  variant?: 'white' | 'mauve' | 'tinted' | 'accent' | 'warm';
  limit?: number;
}

export const ProductSection: React.FC<ProductSectionProps> = ({
  title,
  tag,
  subtitle,
  products,
  onSelectProduct,
  onAddToCart,
  wishlistIds,
  onToggleWishlist,
  onViewAll,
  variant = 'white',
  limit = 4,
}) => {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });
  const { t } = useLanguage();
  const displayedProducts = products.slice(0, limit);

  const containerStyles = {
    white: 'bg-white border border-[#EAEAEA] shadow-2xs',
    mauve: 'bg-white border border-[#EAEAEA] shadow-2xs',
    tinted: 'bg-white border border-[#EAEAEA] shadow-2xs',
    accent: 'bg-white border border-[#EAEAEA] shadow-2xs',
    warm: 'bg-[#FAFAFA] border border-[#EAEAEA] shadow-2xs',
  }[variant];

  if (displayedProducts.length === 0) return null;

  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2 sm:py-3">
      <div
        className={`rounded-2xl sm:rounded-3xl p-4 sm:p-5 transition-all duration-500 ease-out ${containerStyles} ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-3.5">
          <div>
            {tag && (
              <div className="flex items-center gap-1.5 text-[#666666] font-black text-[10px] uppercase tracking-wider">
                <Sparkles className="w-3 h-3 text-[#FFD400]" />
                <span>{tag}</span>
              </div>
            )}
            <h2 className="text-base sm:text-xl font-black text-[#111111] tracking-tight mt-0.5">
              {title}
            </h2>
            {subtitle && (
              <p className="text-xs text-[#666666] mt-0.5">{subtitle}</p>
            )}
          </div>

          {onViewAll && (
            <button
              onClick={onViewAll}
              className="group inline-flex items-center gap-1 text-xs font-black text-[#111111] hover:text-[#000000] cursor-pointer"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#FFD400] group-hover:translate-x-0.5 transition-transform" />
            </button>
          )}
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-4">
          {displayedProducts.map((product) => (
            <div key={product.id} className="h-full">
              <ProductCard
                product={product}
                onSelect={onSelectProduct}
                onAddToCart={onAddToCart}
                isWishlisted={wishlistIds.has(product.id)}
                onToggleWishlist={onToggleWishlist}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductSection;
