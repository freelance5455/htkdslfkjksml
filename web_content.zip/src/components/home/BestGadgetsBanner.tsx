import React from 'react';
import { useScrollReveal } from '../../hooks/useScrollReveal';

interface BestGadgetsBannerProps {
  onExplore?: () => void;
}

export const BestGadgetsBanner: React.FC<BestGadgetsBannerProps> = ({ onExplore }) => {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });

  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5">
      <div
        onClick={onExplore}
        className={`relative w-full aspect-[3/1] max-h-[360px] overflow-hidden rounded-2xl sm:rounded-3xl shadow-2xs hover:shadow-xs transition-all duration-500 ease-out cursor-pointer select-none border border-[#EAEAEA] bg-black ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
        }`}
      >
        <img
          src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=1200&auto=format&fit=crop&q=80"
          alt="Best Gadgets & Lifestyle Accessories"
          className="w-full h-full block object-cover object-center transition-transform duration-500 ease-out hover:scale-[1.01]"
          loading="lazy"
        />
      </div>
    </section>
  );
};

export default BestGadgetsBanner;
