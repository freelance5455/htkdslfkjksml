import React, { useState } from 'react';
import { Book } from '../../types';
import { Users, BookOpen, Sparkles } from 'lucide-react';

interface TopAuthorsDonutChartProps {
  books: Book[];
}

export const TopAuthorsDonutChart: React.FC<TopAuthorsDonutChartProps> = ({ books }) => {
  const [hoveredAuthor, setHoveredAuthor] = useState<string | null>(null);

  // Compute author stats from real book library
  const authorData = React.useMemo(() => {
    const stats: Record<string, { name: string; booksCount: number; pagesRead: number }> = {};

    books.forEach((book) => {
      const author = book.author?.trim() || 'Autor Desconocido';
      if (!stats[author]) {
        stats[author] = { name: author, booksCount: 0, pagesRead: 0 };
      }
      // Weight finished books and pages read
      if (book.status === 'TERMINADO') {
        stats[author].booksCount += 1;
        stats[author].pagesRead += book.totalPages || book.pagesRead || 0;
      } else if (book.pagesRead > 0) {
        stats[author].booksCount += Number((book.pagesRead / (book.totalPages || 300)).toFixed(1));
        stats[author].pagesRead += book.pagesRead;
      } else {
        // In library but unread
        stats[author].booksCount += 0.2;
      }
    });

    const list = Object.values(stats)
      .filter((a) => a.pagesRead > 0 || a.booksCount >= 0.5)
      .sort((a, b) => b.pagesRead - a.pagesRead || b.booksCount - a.booksCount);

    if (list.length === 0) return [];

    const totalPages = list.reduce((sum, item) => sum + item.pagesRead, 0) || 1;
    const top4 = list.slice(0, 4);
    const others = list.slice(4);
    const othersPages = others.reduce((sum, item) => sum + item.pagesRead, 0);
    const othersBooks = others.reduce((sum, item) => sum + Math.round(item.booksCount), 0);

    const palette = ['#06b6d4', '#a855f7', '#f59e0b', '#10b981', '#ec4899'];

    const result = top4.map((author, idx) => ({
      name: author.name,
      pagesRead: author.pagesRead,
      booksCount: Math.max(1, Math.round(author.booksCount)),
      percentage: Math.max(1, Math.round((author.pagesRead / totalPages) * 100)),
      color: palette[idx % palette.length],
    }));

    if (othersPages > 0) {
      result.push({
        name: 'Otros autores',
        pagesRead: othersPages,
        booksCount: othersBooks || 1,
        percentage: Math.max(1, Math.round((othersPages / totalPages) * 100)),
        color: '#71717a',
      });
    }

    return result;
  }, [books]);

  if (authorData.length === 0) {
    return (
      <div className="glass-panel rounded-3xl p-5 border border-white/[0.08] flex flex-col justify-between h-full space-y-3">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-cyan-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-300">
            Autores más leídos
          </h3>
        </div>
        <p className="text-xs text-zinc-400 italic py-6 text-center">
          Añade o lee libros en tu biblioteca para ver aquí la distribución gráfica de tus autores favoritos.
        </p>
      </div>
    );
  }

  // SVG Geometry for donut
  const size = 140;
  const strokeWidth = 16;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  let accumulatedPercent = 0;

  const activeItem =
    authorData.find((a) => a.name === hoveredAuthor) || authorData[0];

  return (
    <div className="glass-panel rounded-3xl p-5 border border-white/[0.08] flex flex-col justify-between h-full space-y-4 shadow-xl relative overflow-hidden group">
      {/* Background ambient glow matching top author */}
      <div
        className="absolute -top-16 -right-16 w-36 h-36 rounded-full blur-3xl opacity-20 pointer-events-none transition-colors duration-500"
        style={{ backgroundColor: activeItem.color }}
      />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className="w-7 h-7 rounded-xl flex items-center justify-center border shadow-sm transition-colors"
            style={{
              backgroundColor: `${activeItem.color}20`,
              borderColor: `${activeItem.color}50`,
              color: activeItem.color,
            }}
          >
            <Users className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-white">
              Autores más leídos
            </h3>
            <span className="text-[10px] text-zinc-400 block font-mono">
              Proporción real de lectura
            </span>
          </div>
        </div>
        <span
          className="text-[10px] font-bold px-2 py-0.5 rounded-full border shadow-sm"
          style={{
            backgroundColor: `${activeItem.color}15`,
            borderColor: `${activeItem.color}40`,
            color: activeItem.color,
          }}
        >
          {activeItem.percentage}%
        </span>
      </div>

      {/* Donut and Legend Body */}
      <div className="flex flex-col sm:flex-row items-center gap-5 justify-between">
        {/* SVG Donut Circle */}
        <div className="relative shrink-0 flex items-center justify-center">
          <svg width={size} height={size} className="transform -rotate-90">
            {/* Background ring */}
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              stroke="rgba(255, 255, 255, 0.06)"
              strokeWidth={strokeWidth}
              fill="transparent"
            />
            {/* Segments */}
            {authorData.map((item) => {
              const strokeDasharray = `${(item.percentage / 100) * circumference} ${circumference}`;
              const strokeDashoffset = -((accumulatedPercent / 100) * circumference);
              accumulatedPercent += item.percentage;
              const isHovered = hoveredAuthor === item.name;

              return (
                <circle
                  key={item.name}
                  cx={size / 2}
                  cy={size / 2}
                  r={radius}
                  stroke={item.color}
                  strokeWidth={isHovered ? strokeWidth + 3 : strokeWidth}
                  strokeDasharray={strokeDasharray}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  fill="transparent"
                  className="transition-all duration-300 cursor-pointer"
                  style={{
                    filter: isHovered ? `drop-shadow(0 0 6px ${item.color})` : undefined,
                    opacity: hoveredAuthor && !isHovered ? 0.45 : 1,
                  }}
                  onMouseEnter={() => setHoveredAuthor(item.name)}
                  onMouseLeave={() => setHoveredAuthor(null)}
                />
              );
            })}
          </svg>

          {/* Center Donut Info */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none px-2">
            <span className="text-[10px] text-zinc-400 uppercase font-semibold tracking-tighter truncate max-w-[80px]">
              {activeItem.name.split(' ')[0]}
            </span>
            <span
              className="text-lg font-black font-mono leading-none tracking-tight"
              style={{ color: activeItem.color }}
            >
              {activeItem.percentage}%
            </span>
            <span className="text-[9px] text-zinc-500 font-mono mt-0.5">
              {activeItem.pagesRead.toLocaleString()} pág
            </span>
          </div>
        </div>

        {/* Legend */}
        <div className="flex-1 w-full space-y-2 min-w-0">
          {authorData.map((item) => {
            const isHovered = hoveredAuthor === item.name;
            return (
              <div
                key={item.name}
                onMouseEnter={() => setHoveredAuthor(item.name)}
                onMouseLeave={() => setHoveredAuthor(null)}
                className={`p-1.5 px-2 rounded-xl transition-all cursor-pointer flex items-center justify-between gap-2 border ${
                  isHovered
                    ? 'bg-white/[0.08] border-white/20 translate-x-1'
                    : 'border-transparent hover:bg-white/[0.03]'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0 shadow-sm"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-xs font-semibold text-white truncate">
                    {item.name}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 shrink-0 text-right font-mono">
                  <span className="text-xs font-bold text-white">
                    {item.percentage}%
                  </span>
                  <span className="text-[10px] text-zinc-400">
                    ({item.booksCount} {item.booksCount === 1 ? 'lib' : 'libs'})
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
