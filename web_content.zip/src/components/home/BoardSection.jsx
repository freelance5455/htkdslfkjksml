import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Plus } from "lucide-react";
import CityMap from "@/components/CityMap";
import ReportCard from "@/components/ReportCard";
import { CATEGORIES, STATUSES } from "@/lib/reportStats";
import { cn } from "@/lib/utils";

const statusFilters = [{ value: "all", label: "Any status" }, ...STATUSES];

export default function BoardSection({ reports }) {
  const [category, setCategory] = useState("all");
  const [status, setStatus] = useState("all");

  const filtered = useMemo(
    () =>
      reports.filter(
        (report) =>
          (category === "all" || report.category === category) &&
          (status === "all" || report.status === status)
      ),
    [reports, category, status]
  );

  return (
    <section id="board" className="mx-auto max-w-6xl scroll-mt-20 px-5 pt-16 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-primary">
            The live board
          </p>
          <h2 className="mt-2 font-display text-2xl font-semibold tracking-tight sm:text-3xl">
            Where issues are cropping up
          </h2>
          <p className="mt-2 max-w-md text-sm text-muted-foreground">
            Pins follow the filters below — tap one to open its report.
          </p>
        </div>
        <span className="rounded-full border border-border bg-card px-3 py-1.5 text-xs text-muted-foreground">
          {filtered.length} of {reports.length} reports
        </span>
      </div>

      <div className="mt-6 rounded-2xl border border-border bg-card p-2">
        <CityMap reports={filtered} />
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        <button
          onClick={() => setCategory("all")}
          className={cn(
            "rounded-full border px-3 py-1.5 text-xs transition-colors",
            category === "all"
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border bg-card text-muted-foreground hover:text-foreground"
          )}
        >
          All categories
        </button>
        {CATEGORIES.map((item) => (
          <button
            key={item.value}
            onClick={() => setCategory(item.value)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-xs transition-colors",
              category === item.value
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-muted-foreground hover:text-foreground"
            )}
          >
            {item.label}
          </button>
        ))}
        <span className="mx-1 hidden h-4 w-px bg-border sm:block" />
        {statusFilters.map((item) => (
          <button
            key={item.value}
            onClick={() => setStatus(item.value)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-xs transition-colors",
              status === item.value
                ? "border-foreground/20 bg-secondary text-foreground"
                : "border-border bg-card text-muted-foreground hover:text-foreground"
            )}
          >
            {item.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-dashed border-border bg-card/60 p-12 text-center">
          <p className="font-display text-lg font-semibold">Nothing here yet</p>
          <p className="mt-1 text-sm text-muted-foreground">
            No reports match these filters. Try a different combination.
          </p>
        </div>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((report) => (
            <ReportCard key={report.id} report={report} />
          ))}
        </div>
      )}

      <div className="mt-8 flex flex-col items-start justify-between gap-4 rounded-2xl border border-border bg-secondary/50 p-6 sm:flex-row sm:items-center">
        <div>
          <p className="font-display text-lg font-semibold">Spotted something nearby?</p>
          <p className="mt-1 text-sm text-muted-foreground">
            A photo and a pin is all it takes — the city team sees it straight away.
          </p>
        </div>
        <Link
          to="/report"
          className="inline-flex items-center gap-1.5 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
        >
          <Plus className="h-4 w-4" />
          Report an issue
        </Link>
      </div>
    </section>
  );
}