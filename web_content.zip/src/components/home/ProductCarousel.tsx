import React, { useRef } from 'react';
import { Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';
import { Product } from '../../types';
import { ProductCard } from '../shop/ProductCard';
import { useScrollReveal } from '../../hooks/useScrollReveal';
import { useTouchCarousel } from '../../hooks/useTouchCarousel';

interface ProductCarouselProps {
  title?: string;
  tag?: string;
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  wishlistIds: Set<string>;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
}

export const ProductCarousel: React.FC<ProductCarouselProps> = ({
  title = 'Popular Products',
  tag = 'FEATURED • CASH ON DELIVERY',
  products,
  onSelectProduct,
  onAddToCart,
  wishlistIds,
  onToggleWishlist,
}) => {
  const { ref: sectionRef, isVisible } = useScrollReveal({ threshold: 0.1 });
  const { containerRef, isDragging } = useTouchCarousel();

  const scroll = (direction: 'left' | 'right') => {
    if (containerRef.current) {
      const scrollDistance = containerRef.current.clientWidth * 0.75;
      containerRef.current.scrollBy({
        left: direction === 'left' ? -scrollDistance : scrollDistance,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section ref={sectionRef} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2 sm:py-3">
      <div
        className={`bg-white rounded-2xl sm:rounded-3xl border border-[#EAEAEA] p-4 sm:p-5 shadow-2xs transition-all duration-500 ease-out relative ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
        }`}
      >
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2">
            <div className="w-2 h-5 bg-[#FFD400] rounded-full" />
            <div>
              <div className="flex items-center gap-1.5 text-[#000000] font-black text-[10px] tracking-wider uppercase">
                <Sparkles className="w-3 h-3 text-[#FFD400]" />
                <span>{tag}</span>
              </div>
              <h2 className="text-base sm:text-xl font-black text-[#111111] tracking-tight mt-0.5">
                {title}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => scroll('left')}
              className="w-8 h-8 rounded-full bg-[#FAFAFA] hover:bg-[#FFD400] text-[#111111] hover:text-[#000000] border border-[#EAEAEA] flex items-center justify-center cursor-pointer transition-colors"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="w-8 h-8 rounded-full bg-[#FAFAFA] hover:bg-[#FFD400] text-[#111111] hover:text-[#000000] border border-[#EAEAEA] flex items-center justify-center cursor-pointer transition-colors"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="relative w-full py-1">
          <div
            ref={containerRef}
            className="flex gap-2 sm:gap-3 overflow-x-auto snap-x snap-proximity scroll-smooth scrollbar-none py-1 px-0.5 select-none carousel-touch-container"
            style={{
              WebkitOverflowScrolling: 'touch',
              touchAction: 'pan-x pan-y pinch-zoom',
              overscrollBehaviorX: 'auto',
              overscrollBehaviorY: 'auto',
            }}
          >
            {products.map((product) => (
              <div
                key={product.id}
                className="flex-[0_0_52%] sm:flex-[0_0_32%] md:flex-[0_0_24%] min-w-[155px] max-w-[220px] snap-start h-auto flex flex-col"
              >
                <ProductCard
                  product={product}
                  onSelect={(p) => {
                    if (!isDragging.current) onSelectProduct(p);
                  }}
                  onAddToCart={onAddToCart}
                  isWishlisted={wishlistIds.has(product.id)}
                  onToggleWishlist={onToggleWishlist}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductCarousel;
