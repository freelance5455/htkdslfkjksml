import React from 'react';
import { useScrollReveal } from '../../hooks/useScrollReveal';
import { useLanguage } from '../../context/LanguageContext';
import { Sparkles, ChevronRight } from 'lucide-react';

interface SpotlightItem {
  id: string;
  name: string;
  category: string;
  image: string;
  tagline: string;
}

const SPOTLIGHT_ITEMS: SpotlightItem[] = [
  {
    id: 'spotlight-1',
    name: 'Audio Gear',
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80',
    tagline: 'Noise-Cancelling',
  },
  {
    id: 'spotlight-2',
    name: 'Smart Watches',
    category: 'Watches',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80',
    tagline: 'AMOLED Displays',
  },
  {
    id: 'spotlight-3',
    name: 'Kicks & Sneakers',
    category: 'Sneakers',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=80',
    tagline: 'Streetwear Style',
  },
];

interface BrandsInSpotlightProps {
  onSelectCategory?: (category: string) => void;
  onViewAll?: () => void;
}

export const BrandsInSpotlight: React.FC<BrandsInSpotlightProps> = ({
  onSelectCategory,
  onViewAll,
}) => {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });
  const { t } = useLanguage();

  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5">
      <div
        className={`bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 border border-[#EAEAEA] shadow-2xs transition-all duration-500 ease-out relative overflow-hidden ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
        }`}
      >
        {/* Header Strip */}
        <div className="flex items-center justify-between mb-3 relative z-10">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#000000] text-[#FFD400] flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-[#111111] tracking-tight">
                Brands in Spotlight
              </h2>
              <p className="text-[11px] text-[#666666] font-medium">
                Curated premium collections
              </p>
            </div>
          </div>
          <button
            onClick={onViewAll}
            className="text-xs font-black text-[#111111] hover:text-[#000000] flex items-center gap-0.5 cursor-pointer"
          >
            <span>View All</span>
            <ChevronRight className="w-3.5 h-3.5 text-[#FFD400]" />
          </button>
        </div>

        {/* 3-Column Grid Cards */}
        <div className="grid grid-cols-3 gap-2.5 sm:gap-4 relative z-10">
          {SPOTLIGHT_ITEMS.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectCategory?.(item.category)}
              className="group cursor-pointer select-none rounded-xl sm:rounded-2xl bg-white border border-[#EAEAEA] hover:border-[#000000] shadow-2xs hover:shadow-xs transition-all duration-200 flex flex-col overflow-hidden"
              style={{ touchAction: 'pan-y pinch-zoom' }}
            >
              <div className="relative w-full aspect-[4/5] p-2.5 sm:p-3 flex items-center justify-center overflow-hidden bg-slate-50/50">
                <img
                  src={item.image}
                  alt={item.name}
                  draggable={false}
                  className="w-full h-full object-contain object-center transition-transform duration-300 ease-out group-hover:scale-105 pointer-events-none select-none"
                  style={{ touchAction: 'pan-y pinch-zoom' }}
                  loading="lazy"
                />
              </div>
              <div className="px-2 py-2 sm:px-3 text-center border-t border-[#EAEAEA] bg-white">
                <h4 className="text-[11px] sm:text-xs font-bold text-[#111111] truncate leading-snug">
                  {item.name}
                </h4>
                <p className="text-[10px] text-[#666666] font-semibold truncate mt-0.5">
                  {item.tagline}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BrandsInSpotlight;
