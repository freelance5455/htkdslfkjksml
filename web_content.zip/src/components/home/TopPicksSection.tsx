import React from 'react';
import { Product } from '../../types';
import { PRODUCTS, getProductById } from '../../data/products';
import { useScrollReveal } from '../../hooks/useScrollReveal';
import { useAuth } from '../../context/AuthContext';
import { useTouchCarousel } from '../../hooks/useTouchCarousel';
import { Sparkles, ChevronRight, Star } from 'lucide-react';

interface TopPicksSectionProps {
  onSelectProduct: (product: Product) => void;
  onAddToCart?: (product: Product, e: React.MouseEvent) => void;
}

interface TopPickItem {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  rating?: number;
  image: string;
  category: Product['category'];
  actionLabel?: string;
  matchedProductId?: string;
}

const TOP_PICKS_LIST: TopPickItem[] = [
  {
    id: 'top-smart-chashma',
    name: 'Smart Aviator Sunglasses',
    price: 799,
    originalPrice: 1499,
    discount: 46,
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=600&auto=format&fit=crop&q=80',
    category: 'Accessories',
    actionLabel: '₹799',
    matchedProductId: 'prod-sunglasses-1',
  },
  {
    id: 'top-slippers-chappals',
    name: 'Everyday Comfort Slides',
    price: 394,
    originalPrice: 799,
    discount: 50,
    rating: 4.5,
    image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&auto=format&fit=crop&q=80',
    category: 'Men',
    actionLabel: '₹394',
    matchedProductId: 'prod-chappal-comfort',
  },
  {
    id: 'top-beach-slides',
    name: 'Lightweight Beach Slides',
    price: 172,
    originalPrice: 999,
    discount: 82,
    rating: 4.4,
    image: 'https://images.unsplash.com/photo-1603487742131-4160ec999306?w=600&auto=format&fit=crop&q=80',
    category: 'Men',
    actionLabel: '₹172',
    matchedProductId: 'prod-8',
  },
  {
    id: 'top-sandals-leather',
    name: 'Classic Leather Sandals',
    price: 899,
    originalPrice: 1499,
    discount: 40,
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1607522370275-f14206abe5d3?w=600&auto=format&fit=crop&q=80',
    category: 'Men',
    actionLabel: '₹899',
    matchedProductId: 'prod-sandals-leather',
  },
  {
    id: 'top-running-shoes',
    name: 'Pro Speed Running Shoes',
    price: 1199,
    originalPrice: 1999,
    discount: 40,
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=80',
    category: 'Men',
    actionLabel: '₹1199',
    matchedProductId: 'prod-1',
  },
  {
    id: 'top-women-sneakers',
    name: 'Chic Urban Sneakers',
    price: 1299,
    originalPrice: 1999,
    discount: 35,
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=600&auto=format&fit=crop&q=80',
    category: 'Women',
    actionLabel: '₹1299',
    matchedProductId: 'prod-2',
  },
  {
    id: 'top-crossbody-bag',
    name: 'Crossbody Sling Bag',
    price: 799,
    originalPrice: 1299,
    discount: 38,
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=600&auto=format&fit=crop&q=80',
    category: 'Bags',
    actionLabel: '₹799',
    matchedProductId: 'prod-sling-1',
  },
  {
    id: 'top-smart-watch',
    name: 'FitPulse Smart Watch',
    price: 1699,
    originalPrice: 2999,
    discount: 43,
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=600&auto=format&fit=crop&q=80',
    category: 'Accessories',
    actionLabel: '₹1699',
    matchedProductId: 'prod-smart-pulse',
  },
  {
    id: 'top-laptop-backpack',
    name: 'Urban Tech Laptop Backpack',
    price: 1499,
    originalPrice: 1999,
    discount: 25,
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&auto=format&fit=crop&q=80',
    category: 'Bags',
    actionLabel: '₹1499',
    matchedProductId: 'prod-4',
  },
];

export const TopPicksSection: React.FC<TopPicksSectionProps> = ({
  onSelectProduct,
}) => {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });
  const { user } = useAuth();
  const { containerRef, isDragging } = useTouchCarousel();

  const handleClickItem = (item: TopPickItem) => {
    if (isDragging.current) return;
    if (item.matchedProductId) {
      const found = getProductById(item.matchedProductId);
      if (found) {
        onSelectProduct(found);
        return;
      }
    }
    const fallbackProduct: Product = {
      id: item.id,
      name: item.name,
      category: item.category,
      subcategory: 'Top Picks',
      brand: 'OMAZIFY Selection',
      description: `${item.name} - Premium quality, high durability and contemporary styling. 100% Cash on Delivery eligible.`,
      images: [item.image],
      price: item.price,
      originalPrice: item.originalPrice || Math.round(item.price * 1.5),
      discount: item.discount || 30,
      rating: item.rating || 4.8,
      reviewsCount: 420,
      stock: 45,
      gender: 'Unisex',
      sizes: ['Standard'],
      colors: [{ name: 'Black', hex: '#111111' }],
      keywords: ['top picks', item.name.toLowerCase()],
      countryOfOrigin: 'India',
      manufacturer: 'OMAZIFY Verified Partner',
      packerDetails: 'OMAZIFY Logistics Network',
      netQuantity: '1 Unit',
      specifications: {
        'Payment Mode': 'Cash on Delivery (COD) Available',
        'Quality Assurance': '100% Genuine Guaranteed',
      },
      isFeatured: true,
      isBestseller: true,
    };
    onSelectProduct(fallbackProduct);
  };

  const displayName = user?.name ? user.name.split(' ')[0] : 'Shopper';

  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2 sm:py-3">
      <div
        className={`bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 border border-[#EAEAEA] shadow-2xs transition-all duration-500 ease-out relative ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
        }`}
      >
        {/* Section Header */}
        <div className="flex items-center justify-between mb-3 sm:mb-4">
          <div className="flex items-center gap-2">
            <div className="w-2 h-5 bg-[#FFD400] rounded-full" />
            <h2 className="text-base sm:text-lg md:text-xl font-black text-[#111111] tracking-tight">
              {displayName}, Top Picks for You
            </h2>
          </div>
          <span className="text-xs font-bold text-[#666666] hover:text-[#000000] cursor-pointer flex items-center gap-0.5">
            <span>Explore All</span>
            <ChevronRight className="w-4 h-4 text-[#FFD400]" />
          </span>
        </div>

        {/* Horizontal Scrolling Product Carousel */}
        <div
          ref={containerRef}
          className="flex gap-2.5 sm:gap-3.5 overflow-x-auto scroll-smooth snap-x snap-proximity py-1 px-0.5 -mx-0.5 scrollbar-none carousel-touch-container"
          style={{
            WebkitOverflowScrolling: 'touch',
            touchAction: 'pan-x pan-y pinch-zoom',
            overscrollBehaviorX: 'auto',
            overscrollBehaviorY: 'auto',
          }}
        >
          {TOP_PICKS_LIST.map((item) => (
            <div
              key={item.id}
              onClick={() => handleClickItem(item)}
              className="w-[124px] min-w-[124px] sm:w-[155px] sm:min-w-[155px] md:w-[175px] md:min-w-[175px] snap-start shrink-0 bg-white rounded-xl sm:rounded-2xl p-2.5 border border-[#EAEAEA] hover:border-[#000000] transition-colors duration-200 flex flex-col justify-between cursor-pointer select-none group carousel-card-touch"
              style={{
                touchAction: 'pan-y pinch-zoom',
              }}
            >
              {/* Product Image */}
              <div>
                <div
                  className="relative w-full aspect-square rounded-lg sm:rounded-xl overflow-hidden bg-[#FAFAFA] mb-2 border border-[#EAEAEA]/60"
                  style={{ touchAction: 'pan-y pinch-zoom' }}
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    draggable={false}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300 pointer-events-none select-none"
                    loading="lazy"
                    style={{ touchAction: 'pan-y pinch-zoom' }}
                  />

                  {/* Brand Yellow Discount Badge */}
                  {item.discount && item.discount > 0 ? (
                    <span className="absolute top-1.5 left-1.5 bg-[#FFD400] text-[#000000] text-[10px] font-black px-1.5 py-0.5 rounded shadow-2xs">
                      {item.discount}% OFF
                    </span>
                  ) : null}
                </div>

                {/* Rating if present */}
                {item.rating && (
                  <div className="flex items-center gap-1 mb-1">
                    <span className="inline-flex items-center gap-0.5 text-[10px] font-black text-[#111111] bg-[#FFF9DB] border border-[#FFD400]/40 px-1.5 py-0.2 rounded">
                      <Star className="w-2.5 h-2.5 fill-[#FFD400] text-[#FFD400]" />
                      <span>{item.rating.toFixed(1)}</span>
                    </span>
                  </div>
                )}

                {/* Title */}
                <p className="text-xs sm:text-sm font-semibold text-[#111111] line-clamp-1 group-hover:text-[#000000]">
                  {item.name}
                </p>
              </div>

              {/* Price Row */}
              <div className="mt-2 pt-1 border-t border-[#EAEAEA]/70">
                <div className="flex items-baseline gap-1.5 flex-wrap">
                  <span className="text-xs sm:text-sm font-black text-[#111111]">
                    ₹{item.price.toLocaleString()}
                  </span>
                  {item.originalPrice && item.originalPrice > item.price && (
                    <span className="text-[10px] sm:text-xs text-[#666666] line-through">
                      ₹{item.originalPrice.toLocaleString()}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TopPicksSection;
