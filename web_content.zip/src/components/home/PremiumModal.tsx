import React from 'react';
import { X, Crown, CheckCircle2, Sparkles, ShieldCheck } from 'lucide-react';
import { Language } from '../../i18n/translations';
import { UserSubscription } from '../../types/editor';

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  subscription: UserSubscription;
  onSubscriptionUpdated?: (sub: UserSubscription) => void;
}

export const PremiumModal: React.FC<PremiumModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#111114] border border-white/10 rounded-2xl p-5 sm:p-6 text-white shadow-2xl overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/10 blur-3xl pointer-events-none rounded-full" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Badge */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 via-amber-500 to-orange-500 flex items-center justify-center text-black shadow-lg shadow-amber-500/20">
            <Crown className="w-6 h-6 fill-black" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">
              {language === 'hi' ? 'क्लिपोरा प्रो — 100% मुफ़्त' : 'Clipora Pro — 100% Free'}
            </h3>
            <p className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'सभी फीचर्स पूरी तरह अनलॉक हैं' : 'All Features Fully Unlocked'}</span>
            </p>
          </div>
        </div>

        {/* Value Proposition without any payment */}
        <div className="space-y-3 py-3 border-y border-white/[0.08] text-xs">
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-neutral-200">
                {language === 'hi' ? 'कोई वॉटरमार्क नहीं (No Watermark)' : 'Zero Watermark Guarantee'}
              </p>
              <p className="text-neutral-400 text-[11px]">
                {language === 'hi' ? 'आपकी वीडियो बिना किसी लोगो या वॉटरमार्क के एक्सपोर्ट होगी।' : 'Export crystal clean videos with zero branding or watermarks.'}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-neutral-200">
                {language === 'hi' ? '4K अल्ट्रा एचडी और 60 FPS' : '4K Ultra HD & 60 FPS'}
              </p>
              <p className="text-neutral-400 text-[11px]">
                {language === 'hi' ? 'फुल रेजोल्यूशन और अधिकतम फ्रेम रेट सपोर्ट।' : 'Export master videos up to 4K Ultra HD at butter-smooth 60 FPS.'}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-neutral-200">
                {language === 'hi' ? '20 प्रो सिनेमैटिक टेम्पलेट्स' : '20 Pro Cinematic Templates'}
              </p>
              <p className="text-neutral-400 text-[11px]">
                {language === 'hi' ? 'हॉलीवुड, रील्स, ट्रैवल, विंटेज व साइबरपंक टेम्पलेट्स अनलॉक।' : 'All 20 master templates unlocked with one-click timeline loading.'}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-neutral-200">
                {language === 'hi' ? 'कोई पेमेंट नहीं — 100% फ्री' : 'No ₹25 Payment — Forever Free'}
              </p>
              <p className="text-neutral-400 text-[11px]">
                {language === 'hi' ? 'कमलेश मीणा द्वारा सभी क्रिएटर्स के लिए पूरी तरह मुफ़्त।' : 'Developed for creators with zero subscriptions, paywalls, or hidden charges.'}
              </p>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-5">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-xs shadow-lg shadow-amber-400/20 active:scale-95 transition-all text-center"
          >
            {language === 'hi' ? 'एडिटिंग जारी रखें (जारी रखें)' : 'Continue Editing (Free)'}
          </button>
        </div>
      </div>
    </div>
  );
};
