import React, { useState } from 'react';
import {
  X,
  Share2,
  Download,
  Smartphone,
  Copy,
  Check,
  QrCode,
  Sparkles,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  MessageCircle,
  AlertTriangle,
  FolderArchive,
} from 'lucide-react';
import { Language, translations } from '../../i18n/translations';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { apkBuilder, ApkBuildProgress } from '../../services/apkBuilder';

interface ShareAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const ShareAppModal: React.FC<ShareAppModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'apk' | 'web2apk' | 'pwa' | 'share'>('apk');
  const [isBuildingApk, setIsBuildingApk] = useState(false);
  const [isBuildingZip, setIsBuildingZip] = useState(false);
  const [apkProgress, setApkProgress] = useState<ApkBuildProgress | null>(null);
  const [zipProgress, setZipProgress] = useState<ApkBuildProgress | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);

  if (!isOpen) return null;
  const t = translations[language];

  const appUrl = window.location.origin;
  const shareText = language === 'hi'
    ? 'क्लिपोरा (Clipora) - 100% नॉन-एआई प्रोफेशनल वीडियो एडिटर ऐप (कमलेश मीणा द्वारा विकसित)। अभी आज़माएं या डाउनलोड करें:'
    : 'Clipora - Professional Non-AI Video Editor developed by Kamlesh Meena. Edit videos locally with 4K export:';

  const handleDownloadApk = async () => {
    setIsBuildingApk(true);
    setApkProgress({ step: 'Starting build...', percent: 10 });
    try {
      const apkBlob = await apkBuilder.buildApk((prog) => {
        setApkProgress(prog);
      });
      apkBuilder.downloadApk(apkBlob, 'Clipora_v2.0_release.apk');
    } catch (e) {
      console.error('APK build error', e);
    } finally {
      setIsBuildingApk(false);
      setApkProgress(null);
    }
  };

  const handleDownloadWeb2ApkZip = async () => {
    setIsBuildingZip(true);
    setZipProgress({ step: 'Compiling Web2APK Offline Bundle...', percent: 15 });
    try {
      const zipBlob = await apkBuilder.buildWeb2ApkZip((prog) => {
        setZipProgress(prog);
      });
      apkBuilder.downloadBlob(zipBlob, 'clipora_web2apk_ready.zip');
    } catch (e) {
      console.error('ZIP build error', e);
    } finally {
      setIsBuildingZip(false);
      setZipProgress(null);
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Clipora - Professional Video Editor',
          text: shareText,
          url: appUrl,
        });
      } catch (err) {}
    } else {
      handleCopyLink();
    }
  };

  const handleWhatsAppShare = () => {
    const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareText} ${appUrl}`)}`;
    window.open(waUrl, '_blank');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#111114] border border-white/10 rounded-2xl p-5 sm:p-6 text-white shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-black shadow-lg shadow-amber-500/20">
              <Share2 className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">
                {language === 'hi' ? 'ऐप इंस्टॉल व APK डाउनलोड' : 'Install & Download Clipora'}
              </h2>
              <p className="text-xs text-neutral-400">
                {language === 'hi' ? 'कमलेश मीणा द्वारा विकसित' : 'By Kamlesh Meena'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-white/[0.08] mt-3 text-xs font-bold">
          <button
            onClick={() => setActiveTab('apk')}
            className={`flex-1 pb-2.5 text-center border-b-2 flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'apk'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>{language === 'hi' ? 'APK डाउनलोड' : 'Download APK'}</span>
          </button>
          
          <button
            onClick={() => setActiveTab('web2apk')}
            className={`flex-1 pb-2.5 text-center border-b-2 flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'web2apk'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <FolderArchive className="w-4 h-4" />
            <span>{language === 'hi' ? 'Web2APK ज़िप' : 'Web2APK ZIP'}</span>
          </button>

          <button
            onClick={() => setActiveTab('pwa')}
            className={`flex-1 pb-2.5 text-center border-b-2 flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'pwa'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>{language === 'hi' ? 'डायरेक्ट इंस्टॉल' : 'Direct Install'}</span>
          </button>

          <button
            onClick={() => setActiveTab('share')}
            className={`flex-1 pb-2.5 text-center border-b-2 flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'share'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Share2 className="w-4 h-4" />
            <span>{language === 'hi' ? 'शेयर' : 'Share'}</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
          
          {/* TAB 1: APK Download */}
          {activeTab === 'apk' && (
            <div className="space-y-4">
              {/* App Package Card */}
              <div className="p-4 rounded-xl bg-neutral-950/80 border border-white/[0.08] flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img
                    src="/pwa-192x192.png"
                    alt="Clipora App Icon"
                    className="w-14 h-14 rounded-xl border border-neutral-700 object-cover shadow-md"
                  />
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <span>Clipora — Video Editor</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
                        v2.0.4
                      </span>
                    </h3>
                    <p className="text-xs text-neutral-400 font-mono mt-0.5">
                      com.kamleshmeena.clipora.apk
                    </p>
                    <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>{language === 'hi' ? '100% सुरक्षित • नो वॉटरमार्क • 100% फ्री' : '100% Safe • No Watermark • Free'}</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Progress indicator during APK generation */}
              {isBuildingApk && apkProgress && (
                <div className="p-3.5 rounded-xl bg-neutral-950 border border-amber-500/40 space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold text-neutral-300">
                    <span className="flex items-center gap-2">
                      <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                      <span>{apkProgress.step}</span>
                    </span>
                    <span className="text-amber-400 font-mono">{apkProgress.percent}%</span>
                  </div>
                  <div className="w-full bg-neutral-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-200"
                      style={{ width: `${apkProgress.percent}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Download APK Action Button */}
              <button
                onClick={handleDownloadApk}
                disabled={isBuildingApk}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-sm shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 active:scale-[0.99] transition-all disabled:opacity-50"
              >
                {isBuildingApk ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-black" />
                    <span>{language === 'hi' ? 'APK तैयार हो रहा है...' : 'Packaging APK...'}</span>
                  </>
                ) : (
                  <>
                    <Download className="w-5 h-5 stroke-[2.5]" />
                    <span>{language === 'hi' ? 'APK फ़ाइल डाउनलोड करें (.apk)' : 'Download APK File (.apk)'}</span>
                  </>
                )}
              </button>

              {/* How to install on Android guide */}
              <div className="p-3.5 rounded-xl bg-neutral-950/60 border border-white/[0.08] space-y-2 text-xs text-neutral-300">
                <p className="font-bold text-amber-400">
                  {language === 'hi' ? 'एंड्रॉइड फोन में इंस्टॉल करने का तरीका:' : 'How to install on Android:'}
                </p>
                <ol className="list-decimal list-inside space-y-1 text-neutral-400 text-[11px] leading-relaxed">
                  <li>
                    {language === 'hi'
                      ? 'ऊपर दिए गए बटन से Clipora_v2.0_release.apk डाउनलोड करें।'
                      : 'Download Clipora_v2.0_release.apk from the button above.'}
                  </li>
                  <li>
                    {language === 'hi'
                      ? 'डाउनलोड होने के बाद फ़ाइल पर क्लिक करें और "Install" पर टैप करें।'
                      : 'Tap the downloaded file and select Install.'}
                  </li>
                  <li>
                    {language === 'hi'
                      ? 'यदि "Unknown Sources" की अनुमति मांगे तो Settings में जाकर "Allow from this source" चालू करें।'
                      : 'Enable "Allow from this source" in Android settings if prompted.'}
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 2: Web2APK ZIP (Fixes the exact error from screenshot!) */}
          {activeTab === 'web2apk' && (
            <div className="space-y-4">
              {/* Error Explanation Card */}
              <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/40 space-y-2 text-xs">
                <div className="flex items-center gap-2 text-amber-400 font-bold">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{language === 'hi' ? 'Webpage Not Available एरर का कारण व समाधान:' : 'Fix for ERR_HTTP_RESPONSE_CODE_FAILURE:'}</span>
                </div>
                <p className="text-[11px] text-neutral-300 leading-relaxed">
                  {language === 'hi'
                    ? 'जब आप कच्चा सोर्स कोड (source zip) लेकर Website 2 APK Builder में डालते हैं, तो उसमें कम्पाइल्ड Javascript और web/index.html नहीं होता। इसलिए Android WebView "ERR_HTTP_RESPONSE_CODE_FAILURE" दिखाता है।'
                    : 'Raw source ZIPs lack compiled JavaScript and the expected web/index.html folder structure. Android WebView cannot execute raw TypeScript files!'}
                </p>
                <p className="text-[11px] text-emerald-400 font-bold">
                  {language === 'hi'
                    ? '✓ समाधान: नीचे दिए बटन से "Web2APK Ready ZIP" डाउनलोड करें। इसमें web/index.html और कम्पाइल्ड कोड पहले से सही फॉर्मेट में तैयार है।'
                    : '✓ Solution: Download this pre-compiled Web2APK Ready ZIP. It includes web/index.html and relative-path scripts!'}
                </p>
              </div>

              {/* Progress indicator during ZIP generation */}
              {isBuildingZip && zipProgress && (
                <div className="p-3.5 rounded-xl bg-neutral-950 border border-amber-500/40 space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold text-neutral-300">
                    <span className="flex items-center gap-2">
                      <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                      <span>{zipProgress.step}</span>
                    </span>
                    <span className="text-amber-400 font-mono">{zipProgress.percent}%</span>
                  </div>
                  <div className="w-full bg-neutral-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-200"
                      style={{ width: `${zipProgress.percent}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Download Web2APK Ready ZIP Button */}
              <button
                onClick={handleDownloadWeb2ApkZip}
                disabled={isBuildingZip}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-teal-400 text-black font-extrabold text-sm shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2 active:scale-[0.99] transition-all disabled:opacity-50"
              >
                {isBuildingZip ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-black" />
                    <span>{language === 'hi' ? 'ज़िप तैयार हो रही है...' : 'Building ZIP...'}</span>
                  </>
                ) : (
                  <>
                    <FolderArchive className="w-5 h-5 stroke-[2.5]" />
                    <span>{language === 'hi' ? 'Web2APK रेडी ज़िप डाउनलोड करें (.zip)' : 'Download Web2APK Ready ZIP (.zip)'}</span>
                  </>
                )}
              </button>

              {/* Step-by-step for Website 2 APK Builder */}
              <div className="p-3.5 rounded-xl bg-neutral-950/60 border border-white/[0.08] space-y-2 text-xs text-neutral-300">
                <p className="font-bold text-amber-400">
                  {language === 'hi' ? 'Website 2 APK Builder में कैसे इस्तेमाल करें:' : 'How to use in Website 2 APK Builder:'}
                </p>
                <ol className="list-decimal list-inside space-y-1.5 text-neutral-400 text-[11px] leading-relaxed">
                  <li>
                    {language === 'hi'
                      ? 'ऊपर दिए बटन से clipora_web2apk_ready.zip डाउनलोड करें और अपने कम्प्यूटर पर अनज़िप (Extract) करें।'
                      : 'Download clipora_web2apk_ready.zip and extract it on your computer.'}
                  </li>
                  <li>
                    {language === 'hi'
                      ? 'Website 2 APK Builder खोलें और "Select Directory" में अनज़िप किए गए फोल्डर को चुनें।'
                      : 'Open Website 2 APK Builder and select the extracted folder.'}
                  </li>
                  <li>
                    {language === 'hi'
                      ? 'App Title में "Clipora" और Package Name में "com.kamleshmeena.clipora" लिखें।'
                      : 'Set App Title to "Clipora" and Package Name to "com.kamleshmeena.clipora".'}
                  </li>
                  <li>
                    {language === 'hi'
                      ? '"Generate APK" पर क्लिक करें। बनने वाली APK फोन में बिना किसी एरर के तुरंत चलेगी!'
                      : 'Click Generate APK. Your app will load without any error!'}
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 3: Direct 1-Tap PWA Install */}
          {activeTab === 'pwa' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-neutral-950/80 border border-white/[0.08] space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                  <Smartphone className="w-4 h-4" />
                  <span>{language === 'hi' ? 'सबसे आसान: 1-क्लिक डायरेक्ट ऐप इंस्टॉल' : 'Easiest Method: Direct 1-Click Install'}</span>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  {language === 'hi'
                    ? 'किसी भी कंवर्टर या पीसी की जरूरत नहीं! आप क्लिपोरा को अपने एंड्रॉइड फोन में सीधे एक असली फुलस्क्रीन ऐप की तरह 2 सेकंड में इंस्टॉल कर सकते हैं।'
                    : 'No APK converter or PC needed! Install Clipora directly to your Android device in 2 seconds as a full-screen standalone application.'}
                </p>
              </div>

              {isInstalled ? (
                <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-800 text-center space-y-1">
                  <Check className="w-6 h-6 text-emerald-400 mx-auto" />
                  <p className="text-xs font-bold text-emerald-300">
                    {language === 'hi' ? 'क्लिपोरा पहले से आपके फोन में इंस्टॉल है!' : 'Clipora is installed on this device!'}
                  </p>
                </div>
              ) : isInstallable ? (
                <button
                  onClick={install}
                  className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2 active:scale-95 transition-all"
                >
                  <Smartphone className="w-5 h-5 stroke-[2.5]" />
                  <span>{language === 'hi' ? 'फोन पर तुरंत इंस्टॉल करें (1-Tap)' : 'Install App to Home Screen'}</span>
                </button>
              ) : (
                <div className="p-4 rounded-xl bg-neutral-950/80 border border-white/[0.08] text-xs text-neutral-300 space-y-2">
                  <p className="font-bold text-amber-400">
                    {language === 'hi' ? 'क्रोम (Chrome) से सीधा इंस्टॉल करने का तरीका:' : 'Direct Chrome Install:'}
                  </p>
                  <ol className="list-decimal list-inside space-y-1 text-neutral-400 text-[11px] leading-relaxed">
                    <li>
                      {language === 'hi'
                        ? 'अपने फोन के Chrome ब्राउज़र में इस लिंक को खोलें।'
                        : 'Open this website in Google Chrome on your phone.'}
                    </li>
                    <li>
                      {language === 'hi'
                        ? 'ऊपर दाईं ओर 3-डॉट मेनू (⋮) पर टैप करें।'
                        : 'Tap the top-right 3-dots menu (⋮).'}
                    </li>
                    <li>
                      {language === 'hi'
                        ? '"Install app" (ऐप इंस्टॉल करें) या "Add to Home screen" चुनें।'
                        : 'Select "Install app" or "Add to Home screen".'}
                    </li>
                    <li>
                      {language === 'hi'
                        ? 'क्लिपोरा सीधे आपके ऐप ड्रॉअर में बिना किसी एरर के आ जाएगी!'
                        : 'Clipora will be added to your apps drawer with full icon & offline mode!'}
                    </li>
                  </ol>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: Share App */}
          {activeTab === 'share' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={handleWhatsAppShare}
                  className="py-3 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-md shadow-emerald-600/20"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp पर शेयर</span>
                </button>
                <button
                  onClick={handleNativeShare}
                  className="py-3 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-md shadow-amber-500/20"
                >
                  <Share2 className="w-4 h-4" />
                  <span>अन्य ऐप्स पर शेयर</span>
                </button>
              </div>

              {/* Copy Link Input */}
              <div className="bg-neutral-950 p-3 rounded-xl border border-white/[0.08] space-y-1.5">
                <label className="text-[11px] text-neutral-400 font-semibold block">
                  {language === 'hi' ? 'ऐप लिंक कॉपी करें:' : 'Shareable App Link:'}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={appUrl}
                    className="flex-1 bg-[#18181c] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 outline-none font-mono truncate"
                  />
                  <button
                    onClick={handleCopyLink}
                    className="py-1.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs flex items-center gap-1.5 shrink-0 transition-colors"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{isCopied ? (language === 'hi' ? 'कॉपी हुआ' : 'Copied!') : (language === 'hi' ? 'कॉपी' : 'Copy')}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between text-xs text-neutral-500">
          <span>Clipora v2.0.4 • 100% Free Non-AI Editor</span>
          <button
            onClick={onClose}
            className="px-3 py-1 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          >
            {language === 'hi' ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
