import React, { useState, useEffect } from 'react';
import { X, Globe, Cpu, HardDrive, Shield, Info, Trash2, CheckCircle2 } from 'lucide-react';
import { Language, translations } from '../../i18n/translations';
import { inspectDeviceHardware, DeviceCapability } from '../../services/deviceCapability';
import { storageService, StorageStats } from '../../services/storage';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  previewProxyQuality: 'full' | 'half' | 'quarter';
  onPreviewProxyQualityChange: (quality: 'full' | 'half' | 'quarter') => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  language,
  onLanguageChange,
  previewProxyQuality,
  onPreviewProxyQualityChange,
}) => {
  const [hardware, setHardware] = useState<DeviceCapability | null>(null);
  const [stats, setStats] = useState<StorageStats | null>(null);
  const [cacheMessage, setCacheMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setHardware(inspectDeviceHardware());
      storageService.getStorageStats().then(setStats);
    }
  }, [isOpen]);

  if (!isOpen) return null;
  const t = translations[language];

  const handleClearCache = async () => {
    await storageService.clearCache();
    const updated = await storageService.getStorageStats();
    setStats(updated);
    setCacheMessage(t.cacheCleared);
    setTimeout(() => setCacheMessage(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-2xl p-5 sm:p-6 text-white shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-neutral-800 flex items-center justify-center">
              <Info className="w-4 h-4 text-amber-400" />
            </div>
            <h2 className="text-lg font-bold">{t.settings} & {t.helpAbout}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto py-4 space-y-5 pr-1">
          {/* Language Selection */}
          <div className="bg-neutral-950/70 p-3.5 rounded-xl border border-neutral-800/80">
            <div className="flex items-center gap-2 text-xs font-semibold text-neutral-300 mb-2">
              <Globe className="w-4 h-4 text-amber-400" />
              <span>{t.language}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onLanguageChange('en')}
                className={`py-2 px-3 rounded-lg text-xs font-medium border flex items-center justify-center gap-2 transition-colors ${
                  language === 'en'
                    ? 'border-amber-400 bg-amber-500/10 text-amber-300'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400'
                }`}
              >
                <span>English</span>
                {language === 'en' && <CheckCircle2 className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => onLanguageChange('hi')}
                className={`py-2 px-3 rounded-lg text-xs font-medium border flex items-center justify-center gap-2 transition-colors ${
                  language === 'hi'
                    ? 'border-amber-400 bg-amber-500/10 text-amber-300'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400'
                }`}
              >
                <span>हिन्दी (Hindi)</span>
                {language === 'hi' && <CheckCircle2 className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Preview Performance Proxy */}
          <div className="bg-neutral-950/70 p-3.5 rounded-xl border border-neutral-800/80">
            <div className="flex items-center gap-2 text-xs font-semibold text-neutral-300 mb-1">
              <Cpu className="w-4 h-4 text-amber-400" />
              <span>{t.previewQuality}</span>
            </div>
            <p className="text-[11px] text-neutral-400 mb-2.5">
              {language === 'hi'
                ? 'संपादन के दौरान सहज प्लेबैक के लिए प्रीव्यू क्वालिटी समायोजित करें (अंतिम एक्सपोर्ट प्रभावित नहीं होगा)।'
                : 'Adjust live editing viewport quality for ultra-smooth playback. Does not affect final export.'}
            </p>
            <div className="grid grid-cols-3 gap-2">
              {(['full', 'half', 'quarter'] as const).map((q) => (
                <button
                  key={q}
                  onClick={() => onPreviewProxyQualityChange(q)}
                  className={`py-2 px-2 rounded-lg text-[11px] font-medium border text-center transition-all ${
                    previewProxyQuality === q
                      ? 'border-amber-400 bg-amber-500/15 text-white font-bold'
                      : 'border-neutral-800 bg-neutral-900 text-neutral-400'
                  }`}
                >
                  {q === 'full' ? '100% Full' : q === 'half' ? '50% Half' : '25% Low'}
                </button>
              ))}
            </div>
          </div>

          {/* Hardware Capabilities & 8K Readiness */}
          {hardware && (
            <div className="bg-neutral-950/70 p-3.5 rounded-xl border border-neutral-800/80">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-neutral-300">
                  <Cpu className="w-4 h-4 text-emerald-400" />
                  <span>{language === 'hi' ? 'हार्डवेयर क्षमता विश्लेषण' : 'Hardware Capability Analysis'}</span>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                  hardware.supports8K ? 'bg-purple-900/50 text-purple-300 border border-purple-700' : 'bg-blue-900/50 text-blue-300 border border-blue-700'
                }`}>
                  {hardware.supports8K ? '8K Ready' : '4K Ready'}
                </span>
              </div>
              <div className="space-y-1 text-[11px] text-neutral-300 font-mono">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Max Texture Buffer:</span>
                  <span>{hardware.maxTextureSize}px</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">CPU Concurrency:</span>
                  <span>{hardware.hardwareConcurrency} Cores</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">GPU Device:</span>
                  <span className="truncate max-w-[200px]">{hardware.gpuRenderer}</span>
                </div>
              </div>
              <p className="mt-2 text-[10px] text-amber-300/90 bg-amber-950/30 p-2 rounded border border-amber-900/40">
                {language === 'hi' ? hardware.notes.hi : hardware.notes.en}
              </p>
            </div>
          )}

          {/* Local Storage & Cache */}
          {stats && (
            <div className="bg-neutral-950/70 p-3.5 rounded-xl border border-neutral-800/80">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-neutral-300">
                  <HardDrive className="w-4 h-4 text-amber-400" />
                  <span>{t.storageUsed}</span>
                </div>
                <span className="text-xs font-mono text-neutral-300">
                  ≈ {(stats.estimatedBytesUsed / (1024 * 1024)).toFixed(1)} MB
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-neutral-400 mb-3">
                <span>{stats.projectCount} {language === 'hi' ? 'प्रोजेक्ट्स' : 'Projects'} • {stats.exportCount} {language === 'hi' ? 'एक्सपोर्ट' : 'Exports'}</span>
              </div>
              {cacheMessage && (
                <p className="text-[11px] text-emerald-400 mb-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{cacheMessage}</span>
                </p>
              )}
              <button
                onClick={handleClearCache}
                className="w-full py-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-red-400 hover:text-red-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t.clearCache}</span>
              </button>
            </div>
          )}

          {/* Privacy & Permissions Policy */}
          <div className="bg-neutral-950/70 p-3.5 rounded-xl border border-neutral-800/80">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 mb-1.5">
              <Shield className="w-4 h-4" />
              <span>{t.privacyTitle}</span>
            </div>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              {t.privacyDesc}
            </p>
          </div>

          {/* About & Developer Credits */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-neutral-950 to-neutral-900 border border-neutral-800 text-center">
            <h3 className="text-base font-extrabold text-white tracking-wide">
              CLIPORA
            </h3>
            <p className="text-xs text-amber-400 font-medium">
              {t.tagline}
            </p>
            <div className="my-2 h-[1px] bg-neutral-800 w-24 mx-auto" />
            <p className="text-xs font-semibold text-neutral-200">
              {language === 'hi' ? 'डेवलपर: कमलेश मीणा' : 'Developer: Kamlesh Meena'}
            </p>
            <p className="text-[10px] text-neutral-500 mt-1">
              Strict Non-AI Native Media Processing Engine • Version 2.0.4
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
