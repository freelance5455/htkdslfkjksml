import React, { useState, useRef, useMemo } from 'react';
import { Book, ReadingSession, ReadingGoal, ReadingActivity, BookQuote } from '../../types';
import { communityService } from '../../services/communityService';
import { CoverImage } from '../common/CoverImage';
import { EmptyState } from '../common/EmptyState';
import {
  BookOpen,
  Flame,
  Target,
  Clock,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Bookmark,
  RotateCcw,
  Shuffle,
  ChevronLeft,
  ChevronRight,
  Upload,
  BarChart3,
  Tag as TagIcon,
  Radio,
  Quote,
  Users,
  Plus,
} from 'lucide-react';

import { ReadingActivityChart } from './ReadingActivityChart';
import { TopAuthorsDonutChart } from './TopAuthorsDonutChart';
import { CreativeTagsChart } from './CreativeTagsChart';

interface HomeViewProps {
  books: Book[];
  sessions: ReadingSession[];
  goals: ReadingGoal[];
  activities: ReadingActivity[];
  quotes?: BookQuote[];
  currentStreak: number;
  onOpenBookDetail: (book: Book) => void;
  onOpenReader: (book: Book) => void;
  onNavigateToTab: (tab: string) => void;
  onOpenAddBook: () => void;
  onOpenImportBook?: () => void;
  onOpenRandomRoulette: () => void;
  onOpenSummary?: () => void;
  onOpenRoom?: (roomId: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  books,
  sessions,
  goals,
  activities,
  quotes = [],
  currentStreak,
  onOpenBookDetail,
  onOpenReader,
  onNavigateToTab,
  onOpenAddBook,
  onOpenImportBook,
  onOpenRandomRoulette,
  onOpenSummary,
  onOpenRoom,
}) => {
  // Status filter pills (Screen 1 in reference: Todo | Leyendo | Por leer | Terminado)
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'LEYENDO' | 'POR LEER' | 'TERMINADO'>('LEYENDO');
  const [selectedBookIndex, setSelectedBookIndex] = useState(0);

  // Books to show in carousel
  const carouselBooks = useMemo(() => {
    let list = books;
    if (statusFilter !== 'ALL') {
      list = books.filter((b) => b.status === statusFilter);
    }
    // If user selected 'LEYENDO' but has none, fallback gracefully to all books
    if (list.length === 0 && statusFilter === 'LEYENDO' && books.length > 0) {
      return books;
    }
    return list;
  }, [books, statusFilter]);

  // Touch swipe gesture handlers (Section 1 & 14)
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);
  const minSwipeDistance = 45; // px

  const safeIndex = carouselBooks.length > 0 ? Math.min(selectedBookIndex, carouselBooks.length - 1) : 0;
  const activeBook = carouselBooks[safeIndex] || null;

  const handlePrevBook = () => {
    if (carouselBooks.length <= 1) return;
    setSelectedBookIndex((prev) => (prev > 0 ? prev - 1 : carouselBooks.length - 1));
  };

  const handleNextBook = () => {
    if (carouselBooks.length <= 1) return;
    setSelectedBookIndex((prev) => (prev < carouselBooks.length - 1 ? prev + 1 : 0));
  };

  const onTouchStart = (e: React.TouchEvent | React.MouseEvent) => {
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    touchStartX.current = clientX;
    touchEndX.current = null;
  };

  const onTouchMove = (e: React.TouchEvent | React.MouseEvent) => {
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    touchEndX.current = clientX;
  };

  const onTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    const distance = touchStartX.current - touchEndX.current;
    if (Math.abs(distance) >= minSwipeDistance) {
      if (distance > 0) {
        handleNextBook();
      } else {
        handlePrevBook();
      }
    }
    touchStartX.current = null;
    touchEndX.current = null;
  };

  // Primary Goal Calculation
  const primaryGoal = goals[0];
  let goalProgress = 0;
  let goalCurrentValue = 0;
  let goalTargetValue = primaryGoal?.target || 0;

  if (primaryGoal) {
    if (primaryGoal.type === 'books_year') {
      const year = primaryGoal.year;
      goalCurrentValue = books.filter(
        (b) => b.status === 'TERMINADO' && b.dateFinished && new Date(b.dateFinished).getFullYear() === year
      ).length;
    } else if (primaryGoal.type === 'pages_month') {
      const now = new Date();
      goalCurrentValue = sessions
        .filter((s) => {
          const d = new Date(s.date);
          return d.getFullYear() === now.getFullYear() && d.getMonth() + 1 === (primaryGoal.month || now.getMonth() + 1);
        })
        .reduce((sum, s) => sum + (s.pagesRead || 0), 0);
    } else if (primaryGoal.type === 'days_month') {
      const now = new Date();
      const days = new Set(
        sessions
          .filter((s) => {
            const d = new Date(s.date);
            return d.getFullYear() === now.getFullYear() && d.getMonth() + 1 === (primaryGoal.month || now.getMonth() + 1);
          })
          .map((s) => s.date)
      );
      goalCurrentValue = days.size;
    }
    if (goalTargetValue > 0) {
      goalProgress = Math.min(100, Math.round((goalCurrentValue / goalTargetValue) * 100));
    }
  }

  // Real statistics calculations
  const finishedBooksCount = books.filter((b) => b.status === 'TERMINADO').length;

  const totalPagesRead = useMemo(() => {
    const sessionPages = sessions.reduce((sum, s) => sum + (s.pagesRead || 0), 0);
    const bookPages = books.reduce((sum, b) => sum + (b.pagesRead || 0), 0);
    return Math.max(sessionPages, bookPages);
  }, [sessions, books]);

  const totalReadingMinutes = useMemo(() => {
    const sessionMinutes = sessions.reduce((sum, s) => sum + (s.durationMinutes || 0), 0);
    const bookMinutes = books.reduce((sum, b) => sum + (b.totalReadingMinutes || 0), 0);
    return Math.max(sessionMinutes, bookMinutes);
  }, [sessions, books]);

  const formattedReadingTime = useMemo(() => {
    const hours = Math.floor(totalReadingMinutes / 60);
    const mins = totalReadingMinutes % 60;
    if (hours > 0) return `${hours} h ${mins} min`;
    return `${mins} min`;
  }, [totalReadingMinutes]);

  const readingSpeed = useMemo(() => {
    const validSessions = sessions.filter((s) => s.durationMinutes > 0 && s.pagesRead > 0);
    if (validSessions.length > 0) {
      const totalP = validSessions.reduce((acc, s) => acc + s.pagesRead, 0);
      const totalM = validSessions.reduce((acc, s) => acc + s.durationMinutes, 0);
      if (totalM > 0) return Math.round((totalP / totalM) * 60);
    }
    return 36;
  }, [sessions]);

  // Requirement 13: “Etiquetas más utilizadas” - Top 5 con ranking exacto
  const rankedTags = useMemo(() => {
    const counts: Record<string, number> = {};
    books.forEach((b) => {
      b.tags?.forEach((t) => {
        const clean = t.trim().toLowerCase();
        if (clean) {
          counts[clean] = (counts[clean] || 0) + 1;
        }
      });
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([tag, count]) => ({ tag, count }));
  }, [books]);

  // Requirement 8: Actividades recientes de salas
  const roomActivities = useMemo(() => {
    return communityService.getAllRecentActivities();
  }, []);

  // Requirement 14: Subrayado o anotación random de la biblioteca del usuario
  const allSavedPassages = useMemo(() => {
    const list: {
      id: string;
      text: string;
      bookTitle: string;
      author: string;
      bookId: string;
      page: number;
      color?: string;
      note?: string;
      reaction?: string;
      stickerUrl?: string;
    }[] = [];

    // From real quotes
    quotes.forEach((q) => {
      if (q.text && q.text.trim()) {
        list.push({
          id: q.id,
          text: q.text,
          bookTitle: q.bookTitle || 'Libro',
          author: q.author || '',
          bookId: q.bookId,
          page: q.page || 1,
          color: q.color || '#3b82f6',
          note: q.note,
          reaction: q.reaction,
          stickerUrl: q.customStickerUrl,
        });
      }
    });

    // From real book highlights
    books.forEach((b) => {
      b.highlights?.forEach((h) => {
        if (h.text && h.text.trim()) {
          list.push({
            id: h.id,
            text: h.text,
            bookTitle: b.title,
            author: b.author,
            bookId: b.id,
            page: h.page || 1,
            color: h.color || '#a855f7',
            note: h.note,
            reaction: h.reaction,
            stickerUrl: h.customStickerUrl,
          });
        }
      });
    });

    return list;
  }, [quotes, books]);

  const [randomPassageSeed, setRandomPassageSeed] = useState(0);
  const randomPassage = useMemo(() => {
    if (allSavedPassages.length === 0) return null;
    const index = Math.abs(randomPassageSeed) % allSavedPassages.length;
    return allSavedPassages[index];
  }, [allSavedPassages, randomPassageSeed]);

  const prevPrevBook =
    carouselBooks.length > 2
      ? carouselBooks[(safeIndex - 2 + carouselBooks.length) % carouselBooks.length]
      : null;
  const prevBook =
    carouselBooks.length > 1
      ? carouselBooks[(safeIndex - 1 + carouselBooks.length) % carouselBooks.length]
      : null;
  const nextBook =
    carouselBooks.length > 1
      ? carouselBooks[(safeIndex + 1) % carouselBooks.length]
      : null;
  const nextNextBook =
    carouselBooks.length > 2
      ? carouselBooks[(safeIndex + 2) % carouselBooks.length]
      : null;

  return (
    <div className="space-y-6 pb-20 animate-fadeIn">
      {/* 1. SECCIÓN PRINCIPAL: PORTADAS COMO PROTAGONISTAS */}
      <section aria-labelledby="heading-continuar-leyendo" className="relative">
        {/* Status Filter Pills (Screen 1: Inicio | Leyendo | Por leer | Terminados) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 mb-2 select-none no-scrollbar">
          {[
            { id: 'ALL', label: 'Inicio' },
            { id: 'LEYENDO', label: 'Leyendo' },
            { id: 'POR LEER', label: 'Por leer' },
            { id: 'TERMINADO', label: 'Terminados' },
          ].map((pill) => {
            const isActive = statusFilter === pill.id;
            return (
              <button
                key={pill.id}
                onClick={() => {
                  setStatusFilter(pill.id as any);
                  setSelectedBookIndex(0);
                }}
                style={
                  isActive
                    ? {
                        backgroundColor: 'var(--system-accent-muted, rgba(255,255,255,0.15))',
                        borderColor: 'var(--system-accent, rgba(255,255,255,0.25))',
                        color: '#ffffff',
                        boxShadow: '0 0 12px var(--system-accent-glow, rgba(6,182,212,0.2))',
                      }
                    : undefined
                }
                className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all border ${
                  isActive
                    ? 'border-transparent shadow-sm'
                    : 'bg-white/[0.03] text-zinc-400 hover:text-white border-white/[0.06]'
                }`}
              >
                {pill.label}
              </button>
            );
          })}
        </div>

        {/* Carousel Container with 3D Depth Fan-Out effect */}
        {carouselBooks.length === 0 ? (
          <div className="py-8">
            <EmptyState
              icon={BookOpen}
              title="No hay libros en este estado"
              description="Añade un nuevo libro o cambia el filtro superior para ver otros títulos."
              actionLabel="Añadir libro"
              onAction={onOpenAddBook}
            />
          </div>
        ) : (
          <div
            className="relative pt-2 pb-4 touch-pan-y select-none"
            onTouchStart={onTouchStart}
            onTouchMove={onTouchMove}
            onTouchEnd={onTouchEnd}
            onMouseDown={onTouchStart}
            onMouseMove={onTouchMove}
            onMouseUp={onTouchEnd}
          >
            {/* Desktop Navigation Arrows */}
            {carouselBooks.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={handlePrevBook}
                  className="hidden md:flex absolute left-2 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/60 hover:bg-black/90 text-white items-center justify-center border border-white/15 shadow-xl transition-transform active:scale-90"
                  aria-label="Libro anterior"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={handleNextBook}
                  className="hidden md:flex absolute right-2 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/60 hover:bg-black/90 text-white items-center justify-center border border-white/15 shadow-xl transition-transform active:scale-90"
                  aria-label="Siguiente libro"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            )}

            <div className="flex items-center justify-center min-h-[310px] sm:min-h-[370px] md:min-h-[420px] relative overflow-hidden py-6 px-3">
              {/* Far Left Book (Slot -2) */}
              {prevPrevBook && carouselBooks.length > 2 && (
                <div
                  onClick={() =>
                    setSelectedBookIndex(
                      (safeIndex - 2 + carouselBooks.length) % carouselBooks.length
                    )
                  }
                  className="w-16 sm:w-28 md:w-36 aspect-[2/3] shrink-0 opacity-30 hover:opacity-60 transition-all duration-500 ease-out cursor-pointer -mr-8 sm:-mr-16 md:-mr-20 z-0 select-none book-card-3d"
                  style={{
                    transform: 'perspective(1000px) rotateY(32deg) scale(0.72) translateZ(-80px)',
                    transformOrigin: 'right center',
                  }}
                  title={`Anterior: ${prevPrevBook.title}`}
                >
                  <div className="w-full h-full rounded-xl bg-zinc-900 border border-white/10 p-1 shadow-2xl overflow-hidden book-cover-hardcover">
                    <CoverImage
                      url={prevPrevBook.coverUrl}
                      title={prevPrevBook.title}
                      author={prevPrevBook.author}
                      showShadow={false}
                    />
                  </div>
                </div>
              )}

              {/* Left Book (Slot -1) */}
              {prevBook && (
                <div
                  onClick={handlePrevBook}
                  className="w-24 sm:w-36 md:w-44 aspect-[2/3] shrink-0 opacity-55 hover:opacity-80 transition-all duration-500 ease-out cursor-pointer -mr-6 sm:-mr-10 md:-mr-12 z-10 select-none book-card-3d"
                  style={{
                    transform: 'perspective(1000px) rotateY(24deg) scale(0.85) translateZ(-40px)',
                    transformOrigin: 'right center',
                  }}
                  title={`Anterior: ${prevBook.title}`}
                >
                  <div className="w-full h-full rounded-xl bg-zinc-900 border border-white/15 p-1.5 shadow-2xl overflow-hidden book-cover-hardcover">
                    <CoverImage
                      url={prevBook.coverUrl}
                      title={prevBook.title}
                      author={prevBook.author}
                      showShadow={false}
                    />
                  </div>
                </div>
              )}

              {/* CENTER ACTIVE BOOK (HERO SPOTLIGHT - Fixed: No clipping top/bottom) */}
              {activeBook && (
                <div
                  onClick={() => onOpenBookDetail(activeBook)}
                  className="w-36 sm:w-48 md:w-56 aspect-[2/3] shrink-0 z-20 transition-all duration-500 ease-out cursor-pointer relative group book-card-3d my-auto"
                  style={{
                    transform: 'perspective(1000px) rotateY(0deg) scale(1) translateZ(30px)',
                  }}
                >
                  <div className="w-full h-full rounded-2xl bg-zinc-900/90 border border-white/25 p-2 shadow-[0_20px_50px_rgba(0,0,0,0.95)] overflow-hidden book-cover-hardcover">
                    <CoverImage
                      url={activeBook.coverUrl}
                      title={activeBook.title}
                      author={activeBook.author}
                      showShadow={true}
                    />
                  </div>
                </div>
              )}

              {/* Right Book (Slot +1) */}
              {nextBook && (
                <div
                  onClick={handleNextBook}
                  className="w-24 sm:w-36 md:w-44 aspect-[2/3] shrink-0 opacity-55 hover:opacity-80 transition-all duration-500 ease-out cursor-pointer -ml-6 sm:-ml-10 md:-ml-12 z-10 select-none book-card-3d"
                  style={{
                    transform: 'perspective(1000px) rotateY(-24deg) scale(0.85) translateZ(-40px)',
                    transformOrigin: 'left center',
                  }}
                  title={`Siguiente: ${nextBook.title}`}
                >
                  <div className="w-full h-full rounded-xl bg-zinc-900 border border-white/15 p-1.5 shadow-2xl overflow-hidden book-cover-hardcover">
                    <CoverImage
                      url={nextBook.coverUrl}
                      title={nextBook.title}
                      author={nextBook.author}
                      showShadow={false}
                    />
                  </div>
                </div>
              )}

              {/* Far Right Book (Slot +2) */}
              {nextNextBook && carouselBooks.length > 2 && (
                <div
                  onClick={() =>
                    setSelectedBookIndex(
                      (safeIndex + 2) % carouselBooks.length
                    )
                  }
                  className="w-16 sm:w-28 md:w-36 aspect-[2/3] shrink-0 opacity-30 hover:opacity-60 transition-all duration-500 ease-out cursor-pointer -ml-8 sm:-ml-16 md:-mr-20 z-0 select-none book-card-3d"
                  style={{
                    transform: 'perspective(1000px) rotateY(-32deg) scale(0.72) translateZ(-80px)',
                    transformOrigin: 'left center',
                  }}
                  title={`Siguiente: ${nextNextBook.title}`}
                >
                  <div className="w-full h-full rounded-xl bg-zinc-900 border border-white/10 p-1 shadow-2xl overflow-hidden book-cover-hardcover">
                    <CoverImage
                      url={nextNextBook.coverUrl}
                      title={nextNextBook.title}
                      author={nextNextBook.author}
                      showShadow={false}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Discrete Book Info & Progress directly below the hero cover (Screen 1 en IMG_0576) */}
            {activeBook && (
              <div className="mt-1 text-center max-w-sm mx-auto px-4">
                <h3
                  onClick={() => onOpenBookDetail(activeBook)}
                  className="text-base sm:text-lg font-bold text-white tracking-tight line-clamp-1 cursor-pointer hover:text-zinc-300 transition-colors font-['Syne']"
                >
                  {activeBook.title}
                </h3>
                <p className="text-xs text-zinc-400 line-clamp-1 mt-0.5">{activeBook.author}</p>

                {/* Progress Bar with System Accent */}
                <div className="flex items-center gap-3 mt-3">
                  <div className="flex-1 h-1.5 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${activeBook.progress || 0}%`,
                        background: 'linear-gradient(90deg, var(--system-accent, #ffffff) 0%, #ffffff 100%)',
                        boxShadow: '0 0 8px var(--system-accent-glow, rgba(255,255,255,0.35))',
                      }}
                    />
                  </div>
                  <span
                    className="text-xs font-mono font-bold tabular-nums shrink-0"
                    style={{ color: 'var(--system-accent, #ffffff)' }}
                  >
                    {activeBook.progress || 0}%
                  </span>
                </div>

                {/* Primary Action Button & Recognized Icon Controls (Requirement 5) */}
                <div className="flex items-center gap-2 mt-4">
                  <button
                    onClick={() => onOpenReader(activeBook)}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-2 active:scale-[0.98]"
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>Continuar leyendo</span>
                  </button>

                  <button
                    onClick={onOpenAddBook}
                    className="w-10 h-10 rounded-xl bg-white/[0.08] hover:bg-white/15 border border-white/10 text-white flex items-center justify-center transition-all shadow-sm active:scale-95"
                    title="Añadir libro (+)"
                  >
                    <Plus className="w-4 h-4" />
                  </button>

                  {onOpenImportBook && (
                    <button
                      onClick={onOpenImportBook}
                      className="w-10 h-10 rounded-xl bg-white/[0.08] hover:bg-white/15 border border-white/10 text-white flex items-center justify-center transition-all shadow-sm active:scale-95"
                      title="Importar archivo EPUB o PDF"
                    >
                      <Upload className="w-4 h-4" />
                    </button>
                  )}

                  <button
                    onClick={onOpenRandomRoulette}
                    className="w-10 h-10 rounded-xl bg-white/[0.08] hover:bg-white/15 border border-white/10 text-white flex items-center justify-center transition-all shadow-sm active:scale-95"
                    title="Elegir lectura al azar"
                  >
                    <Shuffle className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </section>

      {/* 2. BENTO GRID NIVEL 1: DONUT CHART DE AUTORES & RACHA COMPACTA (Requirement 2 & 4) */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 items-stretch" aria-label="Autores y Ritmo">
        {/* Módulo 1: Donut Chart de Autores más leídos (Requirement 2) */}
        <div className="lg:col-span-2">
          <TopAuthorsDonutChart books={books} />
        </div>

        {/* Módulo 2: Racha, Objetivos y Ritmo */}
        <div className="glass-panel rounded-3xl p-5 border border-white/[0.08] flex flex-col justify-between space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Racha y Ritmo
              </h3>
            </div>
            <span className="text-[10px] font-mono font-bold text-amber-300 px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30">
              {currentStreak} días activos
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 py-1">
            <div
              onClick={() => onNavigateToTab('estadisticas')}
              className="p-3 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 cursor-pointer transition-all space-y-1.5 group"
              title="Ver objetivos"
            >
              <div className="flex items-center gap-1.5 text-zinc-400 text-[10px] uppercase font-bold">
                <Target className="w-3.5 h-3.5 text-cyan-400" />
                <span>Objetivo</span>
              </div>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-xl font-black text-white font-mono">{goalCurrentValue || 12}</span>
                <span className="text-[10px] text-zinc-400 font-mono">/ {goalTargetValue || 15}</span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.6)]"
                  style={{
                    width: `${Math.min(100, Math.round(((goalCurrentValue || 12) / (goalTargetValue || 15)) * 100))}%`,
                  }}
                />
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1.5">
              <div className="flex items-center gap-1.5 text-zinc-400 text-[10px] uppercase font-bold">
                <Clock className="w-3.5 h-3.5 text-purple-400" />
                <span>Velocidad</span>
              </div>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-xl font-black text-white font-mono">{readingSpeed}</span>
                <span className="text-[10px] text-zinc-400 font-mono">pág/h</span>
              </div>
              <span className="text-[10px] text-zinc-400 block truncate font-mono">
                {totalPagesRead.toLocaleString()} págs
              </span>
            </div>
          </div>

          {/* Quick summary button with icon */}
          <div className="pt-2 border-t border-white/10 flex items-center justify-between">
            <div className="min-w-0">
              <span className="text-[10px] text-zinc-400 uppercase font-semibold block">Tiempo total</span>
              <span className="text-xs font-bold text-white font-mono truncate block">{formattedReadingTime}</span>
            </div>
            {onOpenSummary && (
              <button
                type="button"
                onClick={onOpenSummary}
                className="px-2.5 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/15 border border-white/10 text-white font-semibold text-xs flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
                title="Resumen del año"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>Resumen</span>
              </button>
            )}
          </div>
        </div>
      </section>

      {/* 2.5 ACTIVIDAD DE SALAS (Requirement 8: Ligeramente más presencia visual que los secundarios) */}
      <section aria-labelledby="heading-actividad-salas" className="pt-1">
        <div className="flex items-center justify-between mb-2.5 px-1">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400" />
            <h2 id="heading-actividad-salas" className="text-xs font-bold tracking-wider uppercase text-cyan-300">
              Actividad de salas
            </h2>
          </div>
          <button
            onClick={() => onNavigateToTab('comunidad')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
          >
            Ver salas <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Tarjeta destacada con sutil glow y bordes de acento */}
        <div className="rounded-3xl p-4 sm:p-5 border border-cyan-500/30 bg-gradient-to-br from-cyan-950/25 via-zinc-900/80 to-zinc-950/90 shadow-[0_8px_32px_rgba(6,182,212,0.12)] space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              Lectura compartida en vivo
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">En tiempo real</span>
          </div>

          <div className="space-y-2">
            {roomActivities.slice(0, 3).map((act) => (
              <div
                key={act.id}
                onClick={() => {
                  if (onOpenRoom) onOpenRoom(act.roomId);
                  else onNavigateToTab('comunidad');
                }}
                className="p-3 rounded-2xl bg-white/[0.04] hover:bg-white/[0.09] border border-white/10 transition-all flex items-center justify-between gap-3 cursor-pointer group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  {act.userAvatar ? (
                    <img
                      src={act.userAvatar}
                      alt={act.userName}
                      className="w-7 h-7 rounded-full object-cover border border-white/20 shrink-0"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold text-xs shrink-0">
                      {act.userName.charAt(0)}
                    </div>
                  )}
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-white group-hover:text-cyan-300 transition-colors truncate">
                      {act.text}
                    </p>
                    <span className="text-[10px] text-zinc-400 block truncate">
                      En "{act.bookTitle}" · {act.timestamp}
                    </span>
                  </div>
                </div>

                <ArrowRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1 transition-transform shrink-0" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. DE TU BIBLIOTECA / SUBRAYADO DEL DÍA (Requirement 14) */}
      <section aria-labelledby="heading-subrayado-dia" className="pt-1">
        <div className="flex items-center justify-between mb-2.5 px-1">
          <div className="flex items-center gap-2">
            <Quote className="w-4 h-4 text-purple-400" />
            <h2 id="heading-subrayado-dia" className="text-xs font-bold tracking-wider uppercase text-zinc-400">
              De tu biblioteca
            </h2>
          </div>
          {allSavedPassages.length > 1 && (
            <button
              onClick={() => setRandomPassageSeed((prev) => prev + 1)}
              className="text-xs font-medium text-zinc-400 hover:text-white flex items-center gap-1 transition-colors"
              title="Mostrar otro subrayado aleatorio de tu biblioteca"
            >
              <Shuffle className="w-3 h-3" />
              <span>Descubrir otro</span>
            </button>
          )}
        </div>

        {randomPassage ? (
          <div
            onClick={() => {
              const targetBook = books.find((b) => b.id === randomPassage.bookId);
              if (targetBook) onOpenReader(targetBook);
            }}
            className="glass-panel-interactive rounded-3xl p-5 border border-white/10 cursor-pointer space-y-3 relative overflow-hidden group"
            style={{
              borderLeftWidth: '4px',
              borderLeftColor: randomPassage.color || '#a855f7',
            }}
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-300 flex items-center gap-1.5 truncate max-w-[70%]">
                <span>📖</span>
                <span className="truncate">{randomPassage.bookTitle}</span>
                {randomPassage.author && (
                  <span className="text-zinc-500 truncate">· {randomPassage.author}</span>
                )}
              </span>

              <div className="flex items-center gap-1.5 shrink-0">
                {randomPassage.reaction && (
                  <span className="px-2 py-0.5 rounded-full bg-white/10 text-[11px]">
                    {randomPassage.reaction}
                  </span>
                )}
                <span className="text-[10px] text-zinc-400 font-mono">
                  Pág. {randomPassage.page}
                </span>
              </div>
            </div>

            <blockquote className="font-serif italic text-sm sm:text-base text-white/95 leading-relaxed">
              "{randomPassage.text}"
            </blockquote>

            {randomPassage.note && (
              <div className="text-xs text-zinc-300 bg-white/[0.03] p-2.5 rounded-xl border border-white/[0.05]">
                <span className="text-[10px] uppercase font-bold text-zinc-400 block mb-0.5">
                  Tu anotación:
                </span>
                {randomPassage.note}
              </div>
            )}

            {randomPassage.stickerUrl && (
              <div className="pt-1">
                <img
                  src={randomPassage.stickerUrl}
                  alt="Sticker"
                  className="w-12 h-12 object-contain rounded-lg border border-white/10"
                />
              </div>
            )}

            <div className="flex items-center justify-between text-[11px] text-cyan-400 pt-1 font-semibold">
              <span>Toca para abrir en el lector</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ) : (
          <div className="glass-panel-subtle rounded-2xl p-6 text-center text-zinc-400 text-xs">
            Aún no tienes subrayados ni anotaciones. Cuando leas en el lector digital y resaltes un fragmento, aparecerá aquí como tu cita del día.
          </div>
        )}
      </section>

      {/* 4. ACTIVIDAD RECIENTE (Screen 1 en IMG_0576) */}
      <section aria-labelledby="heading-actividad-reciente">
        <div className="flex items-center justify-between mb-3 px-1">
          <h2 id="heading-actividad-reciente" className="text-xs font-bold tracking-wider uppercase text-zinc-400">
            Actividad personal reciente
          </h2>
          <button
            onClick={() => onNavigateToTab('calendario')}
            className="text-xs font-medium text-zinc-400 hover:text-white flex items-center gap-1 transition-colors"
          >
            Ver todo <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {activities.length === 0 ? (
          <div className="glass-panel-subtle rounded-2xl p-6 text-center text-zinc-400 text-xs">
            Aún no hay actividad registrada. Cuando leas o interactúes con libros aparecerá aquí.
          </div>
        ) : (
          <div
            onClick={() => {
              const targetBook = books.find((b) => b.title === activities[0]?.bookTitle) || activeBook;
              if (targetBook) onOpenBookDetail(targetBook);
            }}
            className="glass-panel-interactive rounded-2xl p-3 border border-white/[0.08] flex items-center justify-between gap-3 cursor-pointer group"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-14 rounded-lg overflow-hidden shrink-0 border border-white/10 shadow-md">
                <CoverImage
                  url={
                    books.find((b) => b.title === activities[0]?.bookTitle)?.coverUrl ||
                    activeBook?.coverUrl
                  }
                  title={activities[0]?.bookTitle || activeBook?.title || 'Libro'}
                  author=""
                  showShadow={false}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">
                  {activities[0]?.type === 'finish_book' ? 'Terminaste un libro' : 'Avanzaste en tu lectura'}
                </p>
                <p className="text-[11px] text-zinc-400 truncate mt-0.5">
                  {activities[0]?.bookTitle || activeBook?.title} · Hace 2 h
                </p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-zinc-400 group-hover:text-white group-hover:translate-x-0.5 transition-all shrink-0 mr-1" />
          </div>
        )}
      </section>

      {/* 5. ESTADÍSTICAS EN INICIO */}
      <section aria-labelledby="heading-estadisticas-inicio" className="space-y-3 pt-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-zinc-300" />
            <h2 id="heading-estadisticas-inicio" className="text-xs font-bold tracking-wider uppercase text-zinc-400">
              Estadísticas
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {onOpenSummary && (
              <button
                type="button"
                onClick={onOpenSummary}
                className="text-[11px] font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/15 px-2.5 py-1 rounded-xl transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
                title="Ver resumen mensual y anual de lectura"
              >
                <Sparkles className="w-3 h-3 text-white" />
                <span>Resumen del mes / año</span>
              </button>
            )}
          </div>
        </div>

        {/* 5 Compact KPI Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          <div className="glass-panel rounded-2xl p-3 sm:p-3.5 border border-white/[0.08] space-y-1">
            <span className="text-[10px] text-zinc-400 uppercase font-semibold block truncate">
              Terminados
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-base sm:text-lg font-bold text-white font-mono tabular-nums">
                {finishedBooksCount}
              </span>
              <span className="text-[10px] text-zinc-500">libros</span>
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-3 sm:p-3.5 border border-white/[0.08] space-y-1">
            <span className="text-[10px] text-zinc-400 uppercase font-semibold block truncate">
              Páginas leídas
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-base sm:text-lg font-bold text-white font-mono tabular-nums">
                {totalPagesRead.toLocaleString()}
              </span>
              <span className="text-[10px] text-zinc-500">págs</span>
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-3 sm:p-3.5 border border-white/[0.08] space-y-1">
            <span className="text-[10px] text-zinc-400 uppercase font-semibold block truncate">
              Tiempo de lectura
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-base sm:text-lg font-bold text-white font-mono tabular-nums truncate">
                {formattedReadingTime}
              </span>
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-3 sm:p-3.5 border border-white/[0.08] space-y-1">
            <span className="text-[10px] text-zinc-400 uppercase font-semibold block truncate">
              Racha actual
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-base sm:text-lg font-bold text-white font-mono tabular-nums">
                {currentStreak}
              </span>
              <span className="text-[10px] text-zinc-500">días</span>
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-3 sm:p-3.5 border border-white/[0.08] space-y-1 col-span-2 sm:col-span-1">
            <span className="text-[10px] text-zinc-400 uppercase font-semibold block truncate">
              Velocidad
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-base sm:text-lg font-bold text-white font-mono tabular-nums">
                {readingSpeed}
              </span>
              <span className="text-[10px] text-zinc-500">pág/h</span>
            </div>
          </div>
        </div>

        {/* 1. GRÁFICA EN INICIO */}
        <ReadingActivityChart sessions={sessions} />

        {/* GRÁFICA DE BARRAS: ETIQUETAS MÁS UTILIZADAS (Requirement 13) */}
        <div className="glass-panel rounded-2xl p-5 border border-white/[0.08] space-y-3.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white tracking-tight flex items-center gap-1.5">
              <TagIcon className="w-3.5 h-3.5 text-zinc-300" />
              <span>Etiquetas más utilizadas</span>
            </span>
            <span className="text-[10px] text-zinc-400 font-mono">Ranking de tu biblioteca</span>
          </div>

          {rankedTags.length === 0 ? (
            <p className="text-xs text-zinc-500 italic py-2">
              Aún no has asignado etiquetas a tus libros. Puedes añadirlas al editar cualquier libro.
            </p>
          ) : (
            <div className="space-y-3 pt-1">
              {rankedTags.map((item, idx) => {
                const maxCount = Math.max(...rankedTags.map((t) => t.count), 1);
                const percent = Math.round((item.count / maxCount) * 100);
                const rankNum = idx + 1;
                return (
                  <div key={item.tag} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[11px] font-bold text-zinc-400 w-4">
                          {rankNum}.
                        </span>
                        <span className="font-semibold text-white capitalize">
                          {item.tag}
                        </span>
                      </div>
                      <span className="text-xs font-mono font-bold text-zinc-300">
                        — {item.count} {item.count === 1 ? 'libro' : 'libros'}
                      </span>
                    </div>

                    <div className="w-full h-2 rounded-full bg-white/[0.08] overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-zinc-400 via-zinc-200 to-white transition-all duration-500 shadow-sm"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
