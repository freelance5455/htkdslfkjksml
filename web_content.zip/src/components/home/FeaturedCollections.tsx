import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { useScrollReveal } from '../../hooks/useScrollReveal';

export interface FeaturedCollectionItem {
  id: string;
  title: string;
  categoryTarget: string;
  image: string;
}

export const FEATURED_COLLECTIONS: FeaturedCollectionItem[] = [
  {
    id: 'col-1',
    title: 'Red High-Top Sneakers',
    categoryTarget: 'Men',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=700&auto=format&fit=crop&q=80',
  },
  {
    id: 'col-2',
    title: 'Urban Travel Backpacks',
    categoryTarget: 'Bags',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700&auto=format&fit=crop&q=80',
  },
  {
    id: 'col-3',
    title: 'Women Slip-ons & Slides',
    categoryTarget: 'Women',
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=700&auto=format&fit=crop&q=80',
  },
];

interface FeaturedCollectionsProps {
  onSelectCollection: (categoryTarget: string) => void;
}

export const FeaturedCollections: React.FC<FeaturedCollectionsProps> = ({
  onSelectCollection,
}) => {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });

  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5">
      {/* Header */}
      <div
        className={`flex items-center justify-between mb-3 transition-all duration-500 ease-out ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
        }`}
      >
        <div>
          <div className="flex items-center gap-1.5 text-[#666666] font-black text-[10px] uppercase tracking-wider">
            <Sparkles className="w-3 h-3 text-[#FFD400]" />
            <span>ORIGINAL LABELS</span>
          </div>
          <h2 className="text-base sm:text-xl font-black text-[#111111] tracking-tight mt-0.5">
            Featured Collections
          </h2>
        </div>
        <button
          onClick={() => onSelectCollection('All')}
          className="text-xs font-black text-[#111111] hover:text-[#000000] cursor-pointer"
        >
          View All
        </button>
      </div>

      {/* 3-Column Responsive Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
        {FEATURED_COLLECTIONS.map((item) => (
          <div
            key={item.id}
            onClick={() => onSelectCollection(item.categoryTarget)}
            className="group relative rounded-2xl overflow-hidden cursor-pointer select-none bg-white border border-[#EAEAEA] hover:border-[#000000] shadow-2xs hover:shadow-xs transition-all duration-200 flex flex-col"
            style={{ touchAction: 'pan-y pinch-zoom' }}
          >
            {/* Banner Image */}
            <div className="relative w-full h-[145px] sm:h-[160px] md:h-[180px] overflow-hidden bg-slate-50">
              <img
                src={item.image}
                alt={item.title}
                draggable={false}
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out pointer-events-none select-none"
                style={{ touchAction: 'pan-y pinch-zoom' }}
                loading="lazy"
              />
            </div>
            {/* Bottom Bar */}
            <div className="px-3.5 py-2.5 bg-white flex items-center justify-between border-t border-[#EAEAEA]">
              <div className="flex flex-col min-w-0 pr-2">
                <span className="text-xs sm:text-[13px] font-bold text-[#111111] leading-snug truncate">
                  {item.title}
                </span>
                <span className="text-[10px] text-[#666666] font-semibold mt-0.5">
                  Cash on Delivery Available
                </span>
              </div>
              <span className="inline-flex items-center gap-1 text-xs font-black text-[#000000] group-hover:text-[#FFC800] flex-shrink-0">
                <span>Explore</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#FFD400] group-hover:translate-x-0.5 transition-transform" />
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default FeaturedCollections;
