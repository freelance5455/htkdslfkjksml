import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import VolumeChart from "@/components/charts/VolumeChart";
import CategoryDonut from "@/components/charts/CategoryDonut";

export default function PulseSection({ stats, categoryData }) {
  return (
    <section className="mx-auto max-w-6xl px-5 pt-16 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-primary">
            City pulse
          </p>
          <h2 className="mt-2 font-display text-2xl font-semibold tracking-tight sm:text-3xl">
            What the last eight weeks look like
          </h2>
        </div>
        <Link
          to="/insights"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
        >
          Full insights
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[1.35fr_1fr]">
        <div className="rounded-2xl border border-border bg-card p-5 sm:p-6">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">
            Reports raised per week
          </p>
          <p className="mt-1 font-display text-lg font-semibold">
            {stats.total} reports, {stats.resolved} cleared
          </p>
          <div className="mt-3">
            <VolumeChart data={stats.weekly} />
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-5 sm:p-6">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">
            Where the reports come from
          </p>
          <p className="mt-1 font-display text-lg font-semibold">By category</p>
          <div className="mt-4">
            <CategoryDonut data={categoryData} height={168} />
          </div>
        </div>
      </div>
    </section>
  );
}