import React from 'react';
import { Tag as TagIcon, Sparkles, Award } from 'lucide-react';

interface CreativeTagsChartProps {
  tags: { tag: string; count: number }[];
}

export const CreativeTagsChart: React.FC<CreativeTagsChartProps> = ({ tags }) => {
  if (tags.length === 0) {
    return (
      <div className="glass-panel rounded-3xl p-5 border border-white/[0.08] space-y-3">
        <div className="flex items-center gap-2">
          <TagIcon className="w-4 h-4 text-purple-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-white">
            Etiquetas más utilizadas
          </h3>
        </div>
        <p className="text-xs text-zinc-400 italic py-4 text-center">
          Aún no tienes etiquetas en tus libros. Añádelas al editar o catalogar cualquier título.
        </p>
      </div>
    );
  }

  const maxCount = Math.max(...tags.map((t) => t.count), 1);
  const totalTagged = tags.reduce((acc, t) => acc + t.count, 0);

  const top1 = tags[0];
  const runnersUp = tags.slice(1, 5);

  const rankAccents = [
    { badge: 'bg-amber-500/20 text-amber-300 border-amber-500/40', bar: 'from-amber-400 via-amber-200 to-white' },
    { badge: 'bg-zinc-400/20 text-zinc-200 border-zinc-400/40', bar: 'from-cyan-400 via-cyan-200 to-white' },
    { badge: 'bg-amber-700/20 text-amber-200 border-amber-700/40', bar: 'from-purple-400 via-purple-200 to-white' },
    { badge: 'bg-white/10 text-zinc-300 border-white/20', bar: 'from-emerald-400 via-emerald-200 to-white' },
    { badge: 'bg-white/10 text-zinc-300 border-white/20', bar: 'from-pink-400 via-pink-200 to-white' },
  ];

  return (
    <div className="glass-panel rounded-3xl p-5 sm:p-6 border border-white/[0.08] space-y-4 shadow-xl relative overflow-hidden flex flex-col justify-between">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-1/4 w-48 h-48 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-purple-500/15 border border-purple-500/30 text-purple-300 flex items-center justify-center">
            <TagIcon className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-white">
              Etiquetas más utilizadas
            </h3>
            <span className="text-[10px] text-zinc-400 block font-mono">
              Composición temática de tu colección
            </span>
          </div>
        </div>

        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/[0.05] border border-white/10 text-zinc-300">
          {tags.length} etiquetas activas
        </span>
      </div>

      {/* Top 1 Premier Featured Showcase Card */}
      {top1 && (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-white/[0.03] to-transparent border border-amber-500/30 relative overflow-hidden shadow-md">
          <div className="flex items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-2 min-w-0">
              <span className="px-2 py-0.5 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 font-black text-[10px] font-mono flex items-center gap-1 shadow-sm">
                <Award className="w-3 h-3 text-amber-300" />
                #1 TOP
              </span>
              <span className="text-sm font-bold text-white capitalize truncate font-['Syne']">
                {top1.tag}
              </span>
            </div>
            <span className="text-xs font-mono font-bold text-amber-300 shrink-0">
              {top1.count} {top1.count === 1 ? 'libro' : 'libros'}
            </span>
          </div>

          {/* Stepped Creative Capsule Progress Bar */}
          <div className="relative h-3 w-full rounded-full bg-black/40 border border-white/10 p-0.5 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-500 via-amber-300 to-white transition-all duration-700 shadow-[0_0_12px_rgba(245,158,11,0.5)]"
              style={{ width: '100%' }}
            />
          </div>
        </div>
      )}

      {/* Tiered Grid of other Ranked Tags */}
      {runnersUp.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
          {runnersUp.map((item, idx) => {
            const rankIndex = idx + 1; // 1 to 4 (representing #2 to #5)
            const style = rankAccents[rankIndex] || rankAccents[rankAccents.length - 1];
            const percent = Math.max(12, Math.round((item.count / maxCount) * 100));

            return (
              <div
                key={item.tag}
                className="p-3 rounded-2xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/[0.08] transition-all space-y-2 group"
              >
                <div className="flex items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className={`w-5 h-5 rounded-lg border flex items-center justify-center font-mono font-bold text-[10px] shrink-0 ${style.badge}`}>
                      #{rankIndex + 1}
                    </span>
                    <span className="font-semibold text-zinc-100 capitalize truncate text-xs">
                      {item.tag}
                    </span>
                  </div>
                  <span className="font-mono text-xs font-bold text-zinc-300 shrink-0">
                    {item.count}
                  </span>
                </div>

                {/* Sleek Notched Capsule Bar */}
                <div className="w-full h-2 rounded-full bg-white/[0.06] overflow-hidden p-[1px]">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${style.bar} transition-all duration-600 shadow-sm`}
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
