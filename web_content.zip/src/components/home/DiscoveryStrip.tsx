import React from 'react';
import { useLanguage } from '../../context/LanguageContext';

export interface DiscoveryItem {
  id: string;
  label: string;
  categoryTarget?: string;
  isOffer?: boolean;
}

export const DISCOVERY_ITEMS: DiscoveryItem[] = [
  { id: 'for-you', label: 'For You', categoryTarget: 'All' },
  { id: 'fashion', label: 'Fashion', categoryTarget: 'Women' },
  { id: 'footwear', label: 'Footwear', categoryTarget: 'Men' },
  { id: 'bags', label: 'Bags', categoryTarget: 'Bags' },
  { id: 'kids', label: 'Kids', categoryTarget: 'Kids' },
  { id: 'new-arrivals', label: 'New Arrivals', categoryTarget: 'All' },
  { id: 'offers', label: 'Offers', categoryTarget: 'All', isOffer: true },
];

interface DiscoveryStripProps {
  activeId: string;
  onSelect: (item: DiscoveryItem) => void;
}

export const DiscoveryStrip: React.FC<DiscoveryStripProps> = ({
  activeId,
  onSelect,
}) => {
  const { t } = useLanguage();

  const getTranslatedLabel = (id: string, defaultLabel: string) => {
    switch (id) {
      case 'for-you': return t('forYou');
      case 'footwear': return t('footwear');
      case 'bags': return t('bags');
      case 'kids': return t('kids');
      case 'new-arrivals': return t('newArrivals');
      case 'offers': return t('offers');
      default: return defaultLabel;
    }
  };

  return (
    <div className="w-full bg-white border-b border-[#EAEAEA] shadow-2xs h-[46px] sm:h-[50px] flex items-center">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 w-full">
        <div
          className="flex items-center gap-2 sm:gap-2.5 overflow-x-auto scrollbar-none py-1 carousel-touch-container"
          style={{
            WebkitOverflowScrolling: 'touch',
            touchAction: 'pan-x pan-y pinch-zoom',
            overscrollBehaviorX: 'auto',
          }}
        >
          {DISCOVERY_ITEMS.map((item) => {
            const isActive = activeId === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelect(item)}
                style={{ touchAction: 'pan-y pinch-zoom' }}
                className={`relative px-3.5 py-1.5 rounded-full text-xs whitespace-nowrap transition-all duration-150 cursor-pointer select-none flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#000000] text-[#FFD400] font-black shadow-xs'
                    : 'bg-[#FAFAFA] hover:bg-[#FFF9DB] text-[#666666] hover:text-[#000000] border border-[#EAEAEA] font-bold'
                }`}
              >
                {item.isOffer && (
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      isActive ? 'bg-[#FFD400]' : 'bg-[#000000]'
                    } animate-pulse`}
                  />
                )}
                <span>{getTranslatedLabel(item.id, item.label)}</span>
                {isActive && (
                  <span className="sr-only">(Active)</span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default DiscoveryStrip;
