import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Smartphone,
  Battery,
  BatteryCharging,
  HardDrive,
  Cpu,
  Wifi,
  WifiOff,
  RefreshCw,
  Calculator,
  QrCode,
  KeyRound,
  FileText,
  Clock,
  ArrowRight,
  ShieldAlert,
  Share2,
} from 'lucide-react';
import { generateDeviceReport } from '../../utils/deviceDiagnostics';

export const HomeDashboard: React.FC = () => {
  const { deviceSpecs, refreshDeviceSpecs, isLoadingSpecs, setCurrentTab, triggerHaptic, showToast, settings } =
    useApp();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const isUr = settings.language === 'ur';

  const handleShareReport = async () => {
    triggerHaptic();
    if (!deviceSpecs) return;
    const report = generateDeviceReport(deviceSpecs);
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Pocket Toolkit Device Report',
          text: report,
        });
        showToast('Report shared', 'success');
        return;
      } catch {}
    }
    // Fallback to clipboard
    try {
      await navigator.clipboard.writeText(report);
      showToast('Device report copied to clipboard', 'success');
    } catch {
      showToast('Could not copy report', 'warning');
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Live Date, Time & Refresh Header */}
      <div className="flex items-center justify-between bg-emerald-50/80 dark:bg-emerald-950/20 p-3.5 rounded-2xl border border-emerald-600/15">
        <div>
          <div className="text-xl font-bold tracking-tight text-neutral-800 dark:text-neutral-100 flex items-center gap-2">
            <Clock className="w-5 h-5 text-[#006C4C] dark:text-[#89F8C7]" />
            <span>
              {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
          </div>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            {currentTime.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' })}
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleShareReport}
            title="Share Device Report"
            className="p-2.5 rounded-xl bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-50 active:scale-95 transition-all shadow-xs"
          >
            <Share2 className="w-4 h-4 text-[#006C4C] dark:text-[#89F8C7]" />
          </button>
          <button
            onClick={() => {
              triggerHaptic();
              refreshDeviceSpecs();
              showToast('Hardware readings refreshed', 'info');
            }}
            disabled={isLoadingSpecs}
            title="Refresh Readings"
            className="p-2.5 rounded-xl bg-[#006C4C] text-white hover:bg-[#004D36] active:scale-95 transition-all shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isLoadingSpecs ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Primary Device Summary Card */}
      {settings.dashboardCards.device && (
        <div className="bg-white dark:bg-[#1B221E] rounded-2xl p-4 border border-emerald-900/10 dark:border-emerald-800/30 shadow-xs">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-neutral-100 dark:border-neutral-800">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center text-[#006C4C] dark:text-[#89F8C7]">
                <Smartphone className="w-4 h-4" />
              </div>
              <h2 className="font-semibold text-sm text-neutral-900 dark:text-neutral-100">
                {isUr ? 'ڈیوائس اور سسٹم معلومات' : 'Device & System Status'}
              </h2>
            </div>
            <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/50 text-[#006C4C] dark:text-[#89F8C7]">
              Verified API
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div className="bg-neutral-50 dark:bg-neutral-800/50 p-2.5 rounded-xl">
              <span className="text-neutral-500 dark:text-neutral-400 block text-[10px] uppercase font-semibold">
                Platform / OS
              </span>
              <span className="font-semibold text-neutral-800 dark:text-neutral-200 mt-0.5 block truncate">
                {deviceSpecs?.osName || 'Android'} ({deviceSpecs?.osVersion || 'Native'})
              </span>
            </div>

            <div className="bg-neutral-50 dark:bg-neutral-800/50 p-2.5 rounded-xl">
              <span className="text-neutral-500 dark:text-neutral-400 block text-[10px] uppercase font-semibold">
                Screen Resolution
              </span>
              <span className="font-semibold text-neutral-800 dark:text-neutral-200 mt-0.5 block truncate">
                {deviceSpecs?.screenResolution} @ {deviceSpecs?.devicePixelRatio}x DPR
              </span>
            </div>

            <div className="bg-neutral-50 dark:bg-neutral-800/50 p-2.5 rounded-xl">
              <span className="text-neutral-500 dark:text-neutral-400 block text-[10px] uppercase font-semibold">
                CPU Logical Cores
              </span>
              <span className="font-semibold text-neutral-800 dark:text-neutral-200 mt-0.5 block">
                {deviceSpecs?.logicalCores || 'Multi-Core'} Cores
              </span>
            </div>

            <div className="bg-neutral-50 dark:bg-neutral-800/50 p-2.5 rounded-xl">
              <span className="text-neutral-500 dark:text-neutral-400 block text-[10px] uppercase font-semibold">
                Architecture
              </span>
              <span className="font-semibold text-neutral-800 dark:text-neutral-200 mt-0.5 block truncate">
                {deviceSpecs?.platform || 'ARM64 / Compatible'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Grid: Battery & Storage */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Battery Card */}
        {settings.dashboardCards.battery && (
          <div className="bg-white dark:bg-[#1B221E] rounded-2xl p-4 border border-emerald-900/10 dark:border-emerald-800/30 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                {deviceSpecs?.batteryCharging ? (
                  <BatteryCharging className="w-5 h-5 text-emerald-600 dark:text-emerald-400 animate-pulse" />
                ) : (
                  <Battery className="w-5 h-5 text-[#006C4C] dark:text-[#89F8C7]" />
                )}
                <span className="font-semibold text-sm text-neutral-800 dark:text-neutral-100">
                  {isUr ? 'بیٹری کی حالت' : 'Battery Status'}
                </span>
              </div>
              <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
                {deviceSpecs?.batteryLevel !== undefined ? `${deviceSpecs.batteryLevel}%` : 'Standard API'}
              </span>
            </div>

            {/* Battery bar */}
            <div className="w-full bg-neutral-100 dark:bg-neutral-800 rounded-full h-2.5 overflow-hidden my-2">
              <div
                className="bg-[#006C4C] dark:bg-[#89F8C7] h-full rounded-full transition-all duration-500"
                style={{ width: `${deviceSpecs?.batteryLevel ?? 75}%` }}
              ></div>
            </div>

            <div className="text-[11px] text-neutral-500 dark:text-neutral-400 flex items-center justify-between pt-1">
              <span>{deviceSpecs?.batteryCharging ? 'Currently Charging' : 'Discharging / Running on Battery'}</span>
              <span>{deviceSpecs?.batterySupported ? 'Direct HW Sensor' : 'Standard Sandbox'}</span>
            </div>
          </div>
        )}

        {/* Storage Card */}
        {settings.dashboardCards.storage && (
          <div className="bg-white dark:bg-[#1B221E] rounded-2xl p-4 border border-emerald-900/10 dark:border-emerald-800/30 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <HardDrive className="w-5 h-5 text-[#006C4C] dark:text-[#89F8C7]" />
                <span className="font-semibold text-sm text-neutral-800 dark:text-neutral-100">
                  {isUr ? 'اسٹوریج' : 'Storage Space'}
                </span>
              </div>
              <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
                {deviceSpecs?.storagePercent !== undefined
                  ? `${deviceSpecs.storagePercent}% Used`
                  : deviceSpecs?.storageQuotaMb
                  ? `${((deviceSpecs.storageQuotaMb - (deviceSpecs.storageUsageMb || 0)) / 1024).toFixed(1)} GB Free`
                  : 'Accessible'}
              </span>
            </div>

            {/* Storage bar */}
            <div className="w-full bg-neutral-100 dark:bg-neutral-800 rounded-full h-2.5 overflow-hidden my-2">
              <div
                className="bg-emerald-600 dark:bg-emerald-400 h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.max(5, deviceSpecs?.storagePercent || 18)}%` }}
              ></div>
            </div>

            <div className="text-[11px] text-neutral-500 dark:text-neutral-400 flex items-center justify-between pt-1">
              <span>
                {deviceSpecs?.storageUsageMb ? `${deviceSpecs.storageUsageMb} MB used by app` : 'Local sandbox clean'}
              </span>
              <button
                onClick={() => {
                  triggerHaptic();
                  setCurrentTab('phonecare');
                }}
                className="text-[#006C4C] dark:text-[#89F8C7] font-semibold hover:underline"
              >
                Manage &rarr;
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Grid: RAM & Network */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* RAM Card */}
        {settings.dashboardCards.memory && (
          <div className="bg-white dark:bg-[#1B221E] rounded-2xl p-4 border border-emerald-900/10 dark:border-emerald-800/30 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <Cpu className="w-5 h-5 text-[#006C4C] dark:text-[#89F8C7]" />
                <span className="font-semibold text-sm text-neutral-800 dark:text-neutral-100">
                  {isUr ? 'ریم اور کارکردگی' : 'Memory & RAM'}
                </span>
              </div>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300">
                {deviceSpecs?.deviceMemoryGb ? `${deviceSpecs.deviceMemoryGb} GB Device RAM` : 'Auto-Managed'}
              </span>
            </div>
            <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
              Android manages application memory automatically via Linux kernel OOM heuristics. No background process killers needed.
            </p>
          </div>
        )}

        {/* Network & SIM Card */}
        {settings.dashboardCards.network && (
          <div className="bg-white dark:bg-[#1B221E] rounded-2xl p-4 border border-emerald-900/10 dark:border-emerald-800/30 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                {deviceSpecs?.online ? (
                  <Wifi className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <WifiOff className="w-5 h-5 text-rose-500" />
                )}
                <span className="font-semibold text-sm text-neutral-800 dark:text-neutral-100">
                  {isUr ? 'نیٹ ورک کی صورتحال' : 'Network & Connectivity'}
                </span>
              </div>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  deviceSpecs?.online
                    ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300'
                    : 'bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300'
                }`}
              >
                {deviceSpecs?.online ? 'Connected' : 'Offline'}
              </span>
            </div>
            <div className="text-xs text-neutral-600 dark:text-neutral-300 space-y-1">
              <div className="flex justify-between">
                <span>Transport Link:</span>
                <span className="font-medium text-neutral-900 dark:text-neutral-100 capitalize">
                  {deviceSpecs?.effectiveType || 'Standard Link'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Carrier State:</span>
                <span className="font-medium text-neutral-500 dark:text-neutral-400">
                  Secured by Android Privacy Rules
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick Launch Utilities */}
      {settings.dashboardCards.shortcuts && (
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              {isUr ? 'فوری ٹولز' : 'Frequently Used Utilities'}
            </h2>
            <button
              onClick={() => {
                triggerHaptic();
                setCurrentTab('tools');
              }}
              className="text-xs text-[#006C4C] dark:text-[#89F8C7] font-semibold flex items-center gap-1 hover:underline"
            >
              <span>{isUr ? 'تمام ٹولز' : 'View all'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <button
              onClick={() => {
                triggerHaptic();
                setCurrentTab('calculator');
              }}
              className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-white dark:bg-[#1B221E] border border-neutral-200/80 dark:border-neutral-800 hover:border-[#006C4C] dark:hover:border-[#89F8C7] transition-all shadow-xs group"
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-[#006C4C] dark:text-[#89F8C7] flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <Calculator className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 text-center">
                {isUr ? 'کیلکولیٹر' : 'Scientific Calc'}
              </span>
              <span className="text-[10px] text-neutral-400 mt-0.5">Offline Math</span>
            </button>

            <button
              onClick={() => {
                triggerHaptic();
                setCurrentTab('tools');
              }}
              className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-white dark:bg-[#1B221E] border border-neutral-200/80 dark:border-neutral-800 hover:border-[#006C4C] dark:hover:border-[#89F8C7] transition-all shadow-xs group"
            >
              <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <RefreshCw className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 text-center">
                {isUr ? 'یونٹ کنورٹر' : 'Unit Converter'}
              </span>
              <span className="text-[10px] text-neutral-400 mt-0.5">9 Categories</span>
            </button>

            <button
              onClick={() => {
                triggerHaptic();
                setCurrentTab('tools');
              }}
              className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-white dark:bg-[#1B221E] border border-neutral-200/80 dark:border-neutral-800 hover:border-[#006C4C] dark:hover:border-[#89F8C7] transition-all shadow-xs group"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <KeyRound className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 text-center">
                {isUr ? 'پاس ورڈ جنریٹر' : 'Secure Password'}
              </span>
              <span className="text-[10px] text-neutral-400 mt-0.5">CSPRNG</span>
            </button>

            <button
              onClick={() => {
                triggerHaptic();
                setCurrentTab('tools');
              }}
              className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-white dark:bg-[#1B221E] border border-neutral-200/80 dark:border-neutral-800 hover:border-[#006C4C] dark:hover:border-[#89F8C7] transition-all shadow-xs group"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <QrCode className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 text-center">
                {isUr ? 'کیو آر کوڈ' : 'QR Scanner / Gen'}
              </span>
              <span className="text-[10px] text-neutral-400 mt-0.5">Instant Offline</span>
            </button>
          </div>
        </div>
      )}

      {/* Android Native Integrity Guarantee */}
      <div className="p-3.5 rounded-2xl bg-emerald-500/10 dark:bg-emerald-950/30 border border-emerald-600/20 text-neutral-700 dark:text-neutral-300 text-xs flex items-start space-x-2.5">
        <ShieldAlert className="w-4 h-4 text-[#006C4C] dark:text-[#89F8C7] shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong className="text-neutral-900 dark:text-neutral-100">Pocket Toolkit Integrity Guarantee:</strong> All readings reflect authentic system APIs. No simulated or exaggerated device statistics are ever displayed. All user data remains 100% on this device.
        </p>
      </div>
    </div>
  );
};
