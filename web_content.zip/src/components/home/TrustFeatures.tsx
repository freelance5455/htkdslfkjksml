import React from 'react';

export const TrustFeatures: React.FC = () => {
  return null;
};
