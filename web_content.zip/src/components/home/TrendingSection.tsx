import React from 'react';
import { ArrowRight, Flame } from 'lucide-react';
import { Product } from '../../types';
import { ProductCard } from '../shop/ProductCard';
import { useScrollReveal } from '../../hooks/useScrollReveal';
import { useLanguage } from '../../context/LanguageContext';

interface TrendingSectionProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  wishlistIds: Set<string>;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
  onViewAll: () => void;
}

export const TrendingSection: React.FC<TrendingSectionProps> = ({
  products,
  onSelectProduct,
  onAddToCart,
  wishlistIds,
  onToggleWishlist,
  onViewAll,
}) => {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });
  const { t } = useLanguage();

  const trendingProducts = products
    .filter((p) => p.isBestseller || p.isFeatured || p.rating >= 4.5)
    .slice(0, 4);

  return (
    <section ref={ref} className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2 sm:py-3">
      <div
        className={`bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 border border-[#EAEAEA] shadow-2xs transition-all duration-500 ease-out relative overflow-hidden ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
        }`}
      >
        <div className="flex items-center justify-between mb-3.5 relative z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#000000] text-[#FFD400] flex items-center justify-center shadow-xs">
              <Flame className="w-4 h-4 fill-[#FFD400] text-[#FFD400]" />
            </div>
            <div>
              <div className="flex items-center gap-1 text-[#666666] font-bold text-[10px] uppercase tracking-wider">
                <span>HOT DEALS</span>
              </div>
              <h2 className="text-base sm:text-xl font-black text-[#111111] tracking-tight leading-tight">
                Trending Now
              </h2>
            </div>
          </div>

          <button
            onClick={onViewAll}
            className="group inline-flex items-center gap-1 text-xs font-black text-[#111111] hover:text-[#000000] cursor-pointer"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform text-[#FFD400]" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 sm:gap-3 lg:gap-4 relative z-10">
          {trendingProducts.map((product) => (
            <div key={product.id} className="h-full">
              <ProductCard
                product={product}
                onSelect={onSelectProduct}
                onAddToCart={onAddToCart}
                isWishlisted={wishlistIds.has(product.id)}
                onToggleWishlist={onToggleWishlist}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrendingSection;
