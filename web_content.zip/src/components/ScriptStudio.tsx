import React, { useState } from 'react';
import {
  Sparkles,
  Volume2,
  User,
  RotateCcw,
  Check,
  Play,
  Flame,
  Globe,
  Radio,
  Clock,
  Layers,
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { UgcScript, SearchInsights } from '../types';
import { CREATOR_AVATARS, GEMINI_VOICES, CreatorAvatar, VoiceModelOption } from '../data/presets';

interface ScriptStudioProps {
  script: UgcScript;
  insights: SearchInsights;
  voiceName: string;
  avatarType: string;
  onVoiceChange: (voice: string) => void;
  onAvatarChange: (avatarId: string) => void;
  onRegenerateScript: () => void;
  onResynthesizeVoice: (customText?: string) => void;
  isRegenerating: boolean;
  isVoicing: boolean;
  onScriptUpdate: (newScript: UgcScript) => void;
}

export const ScriptStudio: React.FC<ScriptStudioProps> = ({
  script,
  insights,
  voiceName,
  avatarType,
  onVoiceChange,
  onAvatarChange,
  onRegenerateScript,
  onResynthesizeVoice,
  isRegenerating,
  isVoicing,
  onScriptUpdate,
}) => {
  const [activeTab, setActiveTab] = useState<'beats' | 'insights' | 'voices'>('beats');
  const [editingBeat, setEditingBeat] = useState<'hook' | 'demo' | 'cta' | null>(null);

  const selectedAvatar = CREATOR_AVATARS.find((a) => a.id === avatarType) || CREATOR_AVATARS[0];
  const selectedVoice = GEMINI_VOICES.find((v) => v.id === voiceName) || GEMINI_VOICES[0];

  const handleUpdateBeatText = (beatKey: 'hook' | 'demo' | 'cta', newText: string) => {
    const updated = {
      ...script,
      [beatKey]: {
        ...script[beatKey],
        verbal: newText,
      },
      fullScript: `${beatKey === 'hook' ? newText : script.hook.verbal} ${
        beatKey === 'demo' ? newText : script.demo.verbal
      } ${beatKey === 'cta' ? newText : script.cta.verbal}`,
    };
    onScriptUpdate(updated);
  };

  return (
    <div className="w-full glass-panel rounded-3xl p-5 sm:p-6 border border-white/10 shadow-2xl space-y-6">
      {/* Studio Header & Tab Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold font-mono uppercase">
              16S PACING BLUEPRINT
            </span>
            <span className="text-xs text-slate-400">Total duration: 16.0s</span>
          </div>
          <h3 className="text-lg font-bold text-white mt-1">UGC Script & Avatar Studio</h3>
        </div>

        {/* Action button toolbar */}
        <div className="flex items-center gap-2">
          <button
            onClick={onRegenerateScript}
            disabled={isRegenerating}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-semibold text-slate-200 transition-all active:scale-95 disabled:opacity-50"
            title="Generate a brand new script angle"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isRegenerating ? 'animate-spin text-cyan-400' : ''}`} />
            <span>{isRegenerating ? 'Re-writing...' : 'Regenerate Script'}</span>
          </button>

          <button
            onClick={() => onResynthesizeVoice()}
            disabled={isVoicing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-pink-500/20 to-indigo-500/20 hover:from-pink-500/30 hover:to-indigo-500/30 border border-pink-500/30 text-xs font-semibold text-pink-200 transition-all active:scale-95 disabled:opacity-50"
            title="Re-synthesize audio with Gemini TTS"
          >
            <Volume2 className={`w-3.5 h-3.5 ${isVoicing ? 'animate-bounce text-pink-400' : 'text-pink-300'}`} />
            <span>{isVoicing ? 'Voicing...' : 'Re-Voicing (TTS)'}</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-white/[0.06] pb-2">
        <button
          onClick={() => setActiveTab('beats')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
            activeTab === 'beats'
              ? 'bg-white/[0.1] text-cyan-300 border border-cyan-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Script Beats (0-16s)</span>
        </button>

        <button
          onClick={() => setActiveTab('voices')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
            activeTab === 'voices'
              ? 'bg-white/[0.1] text-cyan-300 border border-cyan-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>Creator & Voice Studio</span>
        </button>

        <button
          onClick={() => setActiveTab('insights')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
            activeTab === 'insights'
              ? 'bg-white/[0.1] text-cyan-300 border border-cyan-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>Search Grounding Insights</span>
        </button>
      </div>

      {/* TAB 1: 3-Beat Script Structure */}
      {activeTab === 'beats' && (
        <div className="space-y-4">
          {/* BEAT 1: HOOK (0-3s) */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-rose-500/5 to-transparent border border-amber-500/25 relative overflow-hidden group">
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-mono font-black">
                  0 - 3s
                </span>
                <span className="text-xs font-bold text-amber-200 uppercase tracking-wider flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  Visual & Spoken Hook
                </span>
              </div>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-white/5 text-slate-400 border border-white/10">
                Pattern Interrupt
              </span>
            </div>

            <div className="space-y-2">
              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400 block mb-1">
                  Creator Spoken Narration:
                </label>
                <textarea
                  rows={2}
                  value={script.hook.verbal}
                  onChange={(e) => handleUpdateBeatText('hook', e.target.value)}
                  className="w-full glass-input rounded-xl p-2.5 text-xs text-slate-100 font-medium focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                <div className="p-2 rounded-xl bg-black/30 border border-white/5">
                  <span className="text-[10px] uppercase text-slate-400 font-bold block">Screen Action:</span>
                  <p className="text-slate-300 text-[11px] mt-0.5">{script.hook.visualDirection}</p>
                </div>
                <div className="p-2 rounded-xl bg-black/30 border border-white/5">
                  <span className="text-[10px] uppercase text-amber-400 font-bold block">On-Screen Sticker:</span>
                  <p className="text-white font-extrabold text-[12px] mt-0.5 tracking-wide">
                    {script.hook.overlayText}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* BEAT 2: DEMO (3-12s) */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-500/10 via-indigo-500/5 to-transparent border border-cyan-500/25 relative overflow-hidden group">
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-mono font-black">
                  3 - 12s
                </span>
                <span className="text-xs font-bold text-cyan-200 uppercase tracking-wider flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  Product Demonstration & Benefits
                </span>
              </div>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-white/5 text-slate-400 border border-white/10">
                Problem Solved
              </span>
            </div>

            <div className="space-y-2">
              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400 block mb-1">
                  Creator Spoken Narration:
                </label>
                <textarea
                  rows={3}
                  value={script.demo.verbal}
                  onChange={(e) => handleUpdateBeatText('demo', e.target.value)}
                  className="w-full glass-input rounded-xl p-2.5 text-xs text-slate-100 font-medium focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                <div className="p-2 rounded-xl bg-black/30 border border-white/5">
                  <span className="text-[10px] uppercase text-slate-400 font-bold block">Fast Montage Action:</span>
                  <p className="text-slate-300 text-[11px] mt-0.5">{script.demo.visualDirection}</p>
                </div>
                <div className="p-2 rounded-xl bg-black/30 border border-white/5">
                  <span className="text-[10px] uppercase text-cyan-400 font-bold block">On-Screen Benefit Banner:</span>
                  <p className="text-white font-extrabold text-[12px] mt-0.5 tracking-wide">
                    {script.demo.overlayText}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* BEAT 3: CTA (12-16s) */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-teal-500/5 to-transparent border border-emerald-500/25 relative overflow-hidden group">
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-mono font-black">
                  12 - 16s
                </span>
                <span className="text-xs font-bold text-emerald-200 uppercase tracking-wider flex items-center gap-1">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  Urgency Call-To-Action & Promo Code
                </span>
              </div>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-white/5 text-slate-400 border border-white/10">
                Conversion Trigger
              </span>
            </div>

            <div className="space-y-2">
              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400 block mb-1">
                  Creator Spoken Narration:
                </label>
                <textarea
                  rows={2}
                  value={script.cta.verbal}
                  onChange={(e) => handleUpdateBeatText('cta', e.target.value)}
                  className="w-full glass-input rounded-xl p-2.5 text-xs text-slate-100 font-medium focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                <div className="p-2 rounded-xl bg-black/30 border border-white/5">
                  <span className="text-[10px] uppercase text-slate-400 font-bold block">Closing Gesture:</span>
                  <p className="text-slate-300 text-[11px] mt-0.5">{script.cta.visualDirection}</p>
                </div>
                <div className="p-2 rounded-xl bg-black/30 border border-white/5">
                  <span className="text-[10px] uppercase text-emerald-400 font-bold block">Offer Card / Tap Link:</span>
                  <p className="text-white font-extrabold text-[12px] mt-0.5 tracking-wide">
                    {script.cta.overlayText}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Creator Avatar & Gemini TTS Voices */}
      {activeTab === 'voices' && (
        <div className="space-y-6">
          {/* Avatars */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-1.5">
              <User className="w-4 h-4 text-cyan-400" />
              1. Choose UGC Creator Persona (Overlayed in 9:16 Video)
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {CREATOR_AVATARS.map((avatar) => {
                const isSelected = avatar.id === avatarType;
                return (
                  <button
                    key={avatar.id}
                    type="button"
                    onClick={() => onAvatarChange(avatar.id)}
                    className={`p-3 rounded-2xl border text-left transition-all relative flex flex-col items-center group ${
                      isSelected
                        ? 'bg-gradient-to-b from-cyan-500/20 to-indigo-500/20 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.3)]'
                        : 'bg-white/[0.03] hover:bg-white/[0.07] border-white/10'
                    }`}
                  >
                    <div className="relative mb-2">
                      <img
                        src={avatar.avatarUrl}
                        alt={avatar.name}
                        className="w-14 h-14 rounded-full object-cover border-2 border-white/20 group-hover:scale-105 transition-transform"
                      />
                      {isSelected && (
                        <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-cyan-400 text-black">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </div>
                    <span className="text-xs font-bold text-slate-100 text-center truncate w-full">
                      {avatar.name}
                    </span>
                    <span className="text-[10px] text-slate-400 text-center truncate w-full">
                      {avatar.role}
                    </span>
                    <span className="mt-1 text-[9px] font-mono px-1.5 py-0.2 rounded-full bg-white/10 text-cyan-300">
                      {avatar.badge}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Gemini TTS Voices */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-pink-400" />
                2. Select Gemini TTS Narrator Voice (gemini-3.8-flash-tts)
              </h4>
              <span className="text-[11px] text-slate-400 font-mono">Model: gemini-3.8-flash-tts</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {GEMINI_VOICES.map((voice) => {
                const isSelected = voice.id === voiceName;
                return (
                  <button
                    key={voice.id}
                    type="button"
                    onClick={() => {
                      onVoiceChange(voice.id);
                    }}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                      isSelected
                        ? 'bg-gradient-to-r from-pink-500/20 to-purple-500/20 border-pink-400 shadow-[0_0_15px_rgba(236,72,153,0.3)]'
                        : 'bg-white/[0.03] hover:bg-white/[0.07] border-white/10'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-extrabold text-white flex items-center gap-1.5">
                        <Radio className="w-3.5 h-3.5 text-pink-400" />
                        {voice.name}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/10 text-slate-300">
                        {voice.gender}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 mt-1">{voice.vibe}</p>
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5 text-[10px] text-slate-400 font-mono">
                      <span>Tempo: {voice.tempo}</span>
                      {isSelected ? (
                        <span className="text-pink-300 font-bold flex items-center gap-1">
                          <Check className="w-3 h-3" /> ACTIVE
                        </span>
                      ) : (
                        <span className="text-slate-500">Tap to select</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="mt-4 p-3 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-slate-200">
                  Current Voice: <span className="text-cyan-300 font-bold">{selectedVoice.name}</span> with Avatar{' '}
                  <span className="text-pink-300 font-bold">{selectedAvatar.name}</span>
                </p>
                <p className="text-[11px] text-slate-400">
                  Generates natural vocal inflections, pauses, and expressive creator tone.
                </p>
              </div>
              <button
                type="button"
                onClick={() => onResynthesizeVoice()}
                disabled={isVoicing}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-xs transition-all active:scale-95 flex items-center gap-1.5"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>{isVoicing ? 'Voicing...' : 'Generate Voice Audio'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Search Grounding Insights */}
      {activeTab === 'insights' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-1.5">
                <Globe className="w-4 h-4" />
                Grounded Product Intelligence
              </h4>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                GOOGLE SEARCH VERIFIED
              </span>
            </div>
            <p className="text-sm font-semibold text-slate-100">{insights.oneLiner || insights.productName}</p>
            <p className="text-xs text-slate-400 mt-1">
              Target Audience: <span className="text-slate-200">{insights.targetAudience || 'E-commerce buyers'}</span>
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Key benefits */}
            <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/10">
              <h5 className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5" />
                Key Converting Benefits
              </h5>
              <ul className="space-y-1.5">
                {insights.keyBenefits.map((b, i) => (
                  <li key={i} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Trending Viral Hooks */}
            <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/10">
              <h5 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5" />
                Trending TikTok Hooks Discovered
              </h5>
              <ul className="space-y-1.5">
                {insights.trendingHooks.map((h, i) => (
                  <li key={i} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="text-amber-400 font-bold">"</span>
                    <span className="italic">{h}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Sources if present */}
          {insights.sources && insights.sources.length > 0 && (
            <div className="p-3 rounded-2xl bg-black/30 border border-white/5">
              <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1.5">
                Grounded Web Citations:
              </span>
              <div className="flex flex-wrap gap-2">
                {insights.sources.map((s, idx) => (
                  <a
                    key={idx}
                    href={s.url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-300 text-[11px] truncate max-w-[240px] border border-white/5 transition-colors"
                  >
                    <ExternalLink className="w-3 h-3 shrink-0" />
                    <span className="truncate">{s.title || s.url}</span>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
