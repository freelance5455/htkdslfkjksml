import React, { useState } from 'react';
import { ExternalLink, RefreshCw, ShieldCheck, Copy, Check, Lock } from 'lucide-react';
import { cyberAudio } from '../audio';

export const PlayGameConsole: React.FC = () => {
  const [iframeKey, setIframeKey] = useState(0);
  const [copied, setCopied] = useState(false);
  const officialUrl = 'https://dkwin9.com/#/register?invitationCode=33378743953';
  const invitationCode = '33378743953';

  const handleReload = () => {
    cyberAudio.playClick();
    setIframeKey((k) => k + 1);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(invitationCode);
    cyberAudio.playSuccess();
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col flex-1 w-full max-w-md mx-auto p-3 space-y-3 select-none pb-24 h-full">
      {/* Official Link Bar */}
      <div className="rounded-2xl bg-gradient-to-r from-[#280830] via-[#1a0520] to-[#0a020d] border border-fuchsia-500/40 p-3.5 shadow-[0_4px_20px_rgba(217,70,239,0.2)] flex flex-col space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-fuchsia-400 animate-pulse" />
            <span className="text-xs font-black text-white tracking-wider">OFFICIAL REGISTER PLATFORM</span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleReload}
              className="p-1.5 rounded-lg bg-fuchsia-950/60 hover:bg-fuchsia-900 border border-fuchsia-500/30 text-fuchsia-300 transition cursor-pointer"
              title="Reload Frame"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
            <a
              href={officialUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 bg-gradient-to-r from-fuchsia-600 to-pink-600 hover:from-fuchsia-500 hover:to-pink-500 text-white text-[10px] font-bold px-2.5 py-1.5 rounded-lg transition active:scale-95 shadow-[0_0_10px_rgba(217,70,239,0.4)] decoration-transparent"
            >
              <span>OPEN</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Invitation Code Quick Copy */}
        <div className="flex items-center justify-between bg-black/60 p-2 rounded-xl border border-fuchsia-500/20 text-xs font-mono">
          <span className="text-slate-300">
            INVITATION CODE: <strong className="text-fuchsia-400 font-bold">{invitationCode}</strong>
          </span>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/30 hover:bg-fuchsia-500/40 cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">COPIED</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" />
                <span>COPY</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Frame Container */}
      <div className="flex-1 w-full min-h-[500px] rounded-2xl border border-fuchsia-500/30 bg-black overflow-hidden relative shadow-2xl flex flex-col">
        <div className="w-full bg-[#0a020d] px-3 py-1.5 border-b border-fuchsia-900/40 flex items-center justify-between text-[10px] text-slate-400 font-mono">
          <div className="flex items-center gap-1.5">
            <Lock className="w-3 h-3 text-emerald-400" />
            <span className="truncate max-w-[200px]">https://dkwin9.com/#/register</span>
          </div>
          <span className="text-emerald-400 font-bold">SSL SECURE</span>
        </div>

        <iframe
          key={iframeKey}
          src={officialUrl}
          title="Official Register Platform"
          className="w-full flex-1 border-0 min-h-[460px]"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
        />
      </div>
    </div>
  );
};
export default PlayGameConsole;
