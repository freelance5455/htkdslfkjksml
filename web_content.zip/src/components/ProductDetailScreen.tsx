import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Share2, 
  Heart, 
  Star, 
  Truck, 
  ShieldCheck, 
  MessageSquare, 
  Store, 
  Check, 
  ChevronRight, 
  MapPin, 
  Clock, 
  ThumbsUp,
  Sparkles,
  ShoppingBag,
  Zap,
  MessageCircle
} from 'lucide-react';
import { Product, Vendor } from '../types/ecommerce';
import { VENDORS } from '../data/mockData';

interface ProductDetailScreenProps {
  product: Product;
  onBack: () => void;
  onAddToCart: (product: Product, color: string, size: string, quantity: number) => void;
  onBuyNow: (product: Product, color: string, size: string, quantity: number) => void;
  onOpenChat: (vendor: Vendor) => void;
  onOpenStore: (vendorId: string) => void;
  onOpenWhatsAppOrder?: (product: Product, color: string, size: string, quantity: number) => void;
}

export const ProductDetailScreen: React.FC<ProductDetailScreenProps> = ({
  product,
  onBack,
  onAddToCart,
  onBuyNow,
  onOpenChat,
  onOpenStore,
  onOpenWhatsAppOrder
}) => {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]?.name || '');
  const [selectedSize, setSelectedSize] = useState(product.sizes[0] || '');
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Shipping Fee Estimator State
  const [destinationCity, setDestinationCity] = useState('Colombo');
  const [deliveryType, setDeliveryType] = useState<'standard' | 'express'>('standard');

  const vendor: Vendor = VENDORS[product.vendorId] || {
    id: product.vendorId,
    name: 'Verified Marketplace Seller',
    badge: 'Verified',
    rating: 4.8,
    positiveFeedbackPercent: 96,
    shipOnTimePercent: 97,
    responseTime: '< 1 hour',
    followersCount: '12k',
    joinedYear: 2022,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    banner: '',
    vouchers: []
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleAdd = () => {
    onAddToCart(product, selectedColor, selectedSize, quantity);
    showToast(`Added ${quantity} item(s) to Cart!`);
  };

  const handleBuy = () => {
    onBuyNow(product, selectedColor, selectedSize, quantity);
  };

  // Shipping cost calculation based on city
  const isColombo = destinationCity.toLowerCase().includes('colombo');
  const standardFee = product.freeShipping ? 0 : (isColombo ? 250 : 380);
  const expressFee = isColombo ? 450 : 650;
  const currentShippingFee = deliveryType === 'standard' ? standardFee : expressFee;
  const deliveryEstimate = deliveryType === 'standard' 
    ? (isColombo ? 'Estimated 1–2 Business Days' : 'Estimated 2–4 Business Days') 
    : 'Guaranteed Next Day Delivery (by 6 PM)';

  return (
    <div className="pb-24 bg-slate-100 min-h-screen relative">
      {/* Top Floating App Bar */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md px-3 py-2.5 flex items-center justify-between border-b border-slate-200">
        <button
          onClick={onBack}
          className="p-1.5 rounded-full hover:bg-slate-100 text-slate-700 transition-colors"
          aria-label="Go back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
          Product Details
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              setIsWishlisted(!isWishlisted);
              showToast(isWishlisted ? 'Removed from Wishlist' : 'Saved to Wishlist!');
            }}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-700 transition-colors"
            aria-label="Wishlist"
          >
            <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
          </button>
          <button
            onClick={() => showToast('Share link copied to clipboard!')}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-700 transition-colors"
            aria-label="Share"
          >
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* 1. Multi-Image Carousel */}
      <div className="bg-white">
        <div className="relative aspect-square w-full max-h-[380px] bg-slate-50">
          <img
            src={product.images[selectedImageIndex] || product.images[0]}
            alt={product.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-contain"
          />
          {product.isFlashSale && (
            <div className="absolute top-3 left-3 bg-[#FF6600] text-white text-xs font-black px-2 py-1 rounded shadow-md flex items-center gap-1">
              <span>⚡ FLASH SALE</span>
              <span>-{product.discountPercent}%</span>
            </div>
          )}
          <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur-xs text-white text-[11px] font-semibold px-2 py-0.5 rounded-full">
            {selectedImageIndex + 1} / {product.images.length}
          </div>
        </div>

        {/* Thumbnails */}
        {product.images.length > 1 && (
          <div className="flex gap-2 p-3 overflow-x-auto border-b border-slate-100">
            {product.images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedImageIndex(idx)}
                className={`w-14 h-14 rounded-lg overflow-hidden border-2 shrink-0 transition-all ${
                  selectedImageIndex === idx ? 'border-[#FF6600] ring-2 ring-orange-200' : 'border-slate-200 opacity-70'
                }`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 2. Price Breakdown & Title Box */}
      <div className="bg-white p-3.5 mt-2 border-y border-slate-200">
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-black text-[#FF6600] tabular-nums">
            Rs. {product.price.toLocaleString()}
          </span>
          <span className="text-xs text-slate-400 line-through tabular-nums">
            Rs. {product.originalPrice.toLocaleString()}
          </span>
          <span className="bg-orange-100 text-[#FF6600] text-xs font-bold px-1.5 py-0.5 rounded">
            {product.discountPercent}% OFF
          </span>
        </div>

        {/* Sewora Coins reward tag */}
        <div className="flex items-center gap-1.5 mt-2 text-[11px] text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-md">
          <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>Earn <strong>120 Sewora Coins</strong> with this purchase</span>
        </div>

        <h1 className="text-sm font-bold text-slate-900 mt-2.5 leading-snug">
          {product.title}
        </h1>

        <div className="flex items-center justify-between text-xs text-slate-500 mt-2.5 pt-2.5 border-t border-slate-100">
          <div className="flex items-center gap-1">
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3.5 h-3.5 ${i < Math.floor(product.rating) ? 'fill-amber-400' : 'text-slate-300'}`}
                />
              ))}
            </div>
            <span className="font-bold text-slate-800 ml-1">{product.rating}</span>
            <span className="text-slate-400">({product.reviewCount} reviews)</span>
          </div>
          <span>{product.soldCount} Sold</span>
        </div>
      </div>

      {/* 3. Variant Selector (Color & Size) */}
      <div className="bg-white p-3.5 mt-2 border-y border-slate-200 space-y-3">
        {/* Color Variants */}
        {product.colors && product.colors.length > 0 && (
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-800 mb-2">
              <span>Color Family: <span className="font-bold text-[#FF6600]">{selectedColor}</span></span>
              <span className="text-[11px] text-emerald-600 font-medium">In Stock</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {product.colors.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setSelectedColor(c.name)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                    selectedColor === c.name
                      ? 'border-[#FF6600] bg-orange-50/50 text-[#FF6600] font-bold shadow-xs'
                      : 'border-slate-200 text-slate-700 bg-white hover:border-slate-300'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-black/10 inline-block shrink-0"
                    style={{ backgroundColor: c.hex }}
                  />
                  <span>{c.name}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Size Variants */}
        {product.sizes && product.sizes.length > 0 && (
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-800 mb-2">
              <span>Size: <span className="font-bold text-[#FF6600]">{selectedSize}</span></span>
              <span className="text-[11px] text-slate-400">Size Chart Guide</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSelectedSize(s)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                    selectedSize === s
                      ? 'border-[#FF6600] bg-orange-50/50 text-[#FF6600] shadow-xs'
                      : 'border-slate-200 text-slate-700 bg-white hover:border-slate-300'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Quantity Stepper */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
          <span className="text-xs font-semibold text-slate-800">Quantity:</span>
          <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              disabled={quantity <= 1}
              className="w-8 h-8 flex items-center justify-center font-bold text-slate-600 hover:bg-slate-200 disabled:opacity-40"
            >
              -
            </button>
            <span className="w-10 text-center font-bold text-xs text-slate-800 tabular-nums">
              {quantity}
            </span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="w-8 h-8 flex items-center justify-center font-bold text-slate-600 hover:bg-slate-200"
            >
              +
            </button>
          </div>
        </div>
      </div>

      {/* 4. Interactive Shipping Fee & Delivery Estimator */}
      <div className="bg-white p-3.5 mt-2 border-y border-slate-200 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
            <Truck className="w-4 h-4 text-[#FF6600]" />
            <span>Shipping & Delivery Options</span>
          </div>
          <div className="flex items-center gap-1 text-[11px] text-slate-600">
            <MapPin className="w-3 h-3 text-slate-400" />
            <select
              value={destinationCity}
              onChange={(e) => setDestinationCity(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 text-xs font-semibold text-slate-800 focus:outline-none"
            >
              <option value="Colombo">Deliver to: Colombo</option>
              <option value="Kandy">Deliver to: Kandy</option>
              <option value="Galle">Deliver to: Galle</option>
              <option value="Gampaha">Deliver to: Gampaha</option>
              <option value="Kurunegala">Deliver to: Kurunegala</option>
            </select>
          </div>
        </div>

        {/* Delivery Options Selector */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => setDeliveryType('standard')}
            className={`p-2.5 rounded-xl border text-left transition-all ${
              deliveryType === 'standard'
                ? 'border-[#FF6600] bg-orange-50/40 text-slate-900'
                : 'border-slate-200 bg-white text-slate-700'
            }`}
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold">Standard Delivery</span>
              {standardFee === 0 ? (
                <span className="text-[10px] font-extrabold text-emerald-600 uppercase">FREE</span>
              ) : (
                <span className="font-bold tabular-nums">Rs. {standardFee}</span>
              )}
            </div>
            <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
              <Clock className="w-3 h-3 text-slate-400" />
              <span>{isColombo ? '1–2 Days' : '2–4 Days'}</span>
            </div>
          </button>

          <button
            onClick={() => setDeliveryType('express')}
            className={`p-2.5 rounded-xl border text-left transition-all ${
              deliveryType === 'express'
                ? 'border-[#FF6600] bg-orange-50/40 text-slate-900'
                : 'border-slate-200 bg-white text-slate-700'
            }`}
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold">Express Courier</span>
              <span className="font-bold tabular-nums">Rs. {expressFee}</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-500" />
              <span>Next Day Guarantee</span>
            </div>
          </button>
        </div>

        <p className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded-lg">
          📍 {deliveryEstimate}. Cash on delivery is supported for {destinationCity}.
        </p>
      </div>

      {/* 5. Seller Rating & Store Card */}
      <div className="bg-white p-3.5 mt-2 border-y border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <img
              src={vendor.avatar}
              alt={vendor.name}
              className="w-11 h-11 rounded-full object-cover border border-slate-200"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className="text-xs font-bold text-slate-900">{vendor.name}</h4>
                <span className="bg-[#FF6600] text-white text-[9px] font-black px-1.5 py-0.2 rounded uppercase">
                  {vendor.badge}
                </span>
              </div>
              <p className="text-[10px] text-slate-500">{vendor.followersCount} Followers · Member since {vendor.joinedYear}</p>
            </div>
          </div>

          <button
            onClick={() => onOpenStore(vendor.id)}
            className="text-xs font-bold text-[#FF6600] border border-[#FF6600] px-3 py-1 rounded-lg hover:bg-orange-50 transition-colors"
          >
            Visit Store
          </button>
        </div>

        {/* Vendor Metric Strips */}
        <div className="grid grid-cols-3 gap-2 text-center bg-slate-50 p-2 rounded-xl text-xs">
          <div>
            <div className="font-bold text-slate-900 tabular-nums">{vendor.positiveFeedbackPercent}%</div>
            <div className="text-[10px] text-slate-400">Positive Feedback</div>
          </div>
          <div className="border-x border-slate-200">
            <div className="font-bold text-slate-900 tabular-nums">{vendor.shipOnTimePercent}%</div>
            <div className="text-[10px] text-slate-400">Ship on Time</div>
          </div>
          <div>
            <div className="font-bold text-slate-900">{vendor.responseTime}</div>
            <div className="text-[10px] text-slate-400">Response Rate</div>
          </div>
        </div>
      </div>

      {/* 6. Product Specifications */}
      <div className="bg-white p-3.5 mt-2 border-y border-slate-200">
        <h3 className="text-xs font-bold text-slate-900 mb-2 uppercase tracking-wider">
          Product Details & Specs
        </h3>
        <p className="text-xs text-slate-600 leading-relaxed mb-3">
          {product.description}
        </p>
        <div className="space-y-1.5 border-t border-slate-100 pt-2 text-xs">
          {product.specifications.map((spec, idx) => (
            <div key={idx} className="flex justify-between py-1 border-b border-slate-50">
              <span className="text-slate-400 font-medium">{spec.label}</span>
              <span className="text-slate-800 font-semibold">{spec.value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 7. Customer Reviews & Ratings */}
      <div className="bg-white p-3.5 mt-2 border-y border-slate-200">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Ratings & Reviews ({product.reviewCount})
          </h3>
          <span className="text-xs font-bold text-[#FF6600] flex items-center">
            {product.rating} / 5.0
          </span>
        </div>

        {/* Review list */}
        <div className="space-y-3 mt-3">
          {product.reviews.map((rev) => (
            <div key={rev.id} className="border-b border-slate-100 pb-3 last:border-none">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-slate-800">{rev.author}</span>
                  {rev.verifiedPurchase && (
                    <span className="flex items-center gap-0.5 text-[9px] text-emerald-700 bg-emerald-50 px-1 rounded font-medium">
                      <Check className="w-2.5 h-2.5" /> Verified Purchase
                    </span>
                  )}
                </div>
                <span className="text-[10px] text-slate-400">{rev.date}</span>
              </div>

              <div className="flex text-amber-400 my-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className={`w-3 h-3 ${i < rev.rating ? 'fill-amber-400' : 'text-slate-200'}`} />
                ))}
              </div>

              <div className="text-[10px] text-slate-400 mb-1">
                Variation: {rev.variant}
              </div>

              <p className="text-xs text-slate-700 leading-normal">{rev.comment}</p>

              {rev.photos && rev.photos.length > 0 && (
                <div className="flex gap-2 mt-2">
                  {rev.photos.map((p, i) => (
                    <img key={i} src={p} alt="" className="w-14 h-14 object-cover rounded-md border border-slate-200" />
                  ))}
                </div>
              )}

              <div className="flex items-center gap-1 mt-2 text-[10px] text-slate-400">
                <ThumbsUp className="w-3 h-3" />
                <span>Helpful ({rev.likes})</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white text-xs font-medium px-4 py-2 rounded-full shadow-2xl animate-fade-in flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 8. Sticky Bottom Purchase Module */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 px-3 py-2 flex items-center gap-2 shadow-2xl max-w-md mx-auto md:max-w-none">
        {/* Chat Button */}
        <button
          onClick={() => onOpenChat(vendor)}
          className="flex flex-col items-center justify-center p-1.5 text-slate-600 hover:text-[#FF6600] transition-colors"
          title="Chat with Seller"
        >
          <MessageSquare className="w-5 h-5" />
          <span className="text-[9px] font-semibold mt-0.5">Chat</span>
        </button>

        {/* Store Button */}
        <button
          onClick={() => onOpenStore(vendor.id)}
          className="flex flex-col items-center justify-center p-1.5 text-slate-600 hover:text-[#FF6600] transition-colors"
          title="Seller Store"
        >
          <Store className="w-5 h-5" />
          <span className="text-[9px] font-semibold mt-0.5">Store</span>
        </button>

        {/* WhatsApp Order Button */}
        {onOpenWhatsAppOrder && (
          <button
            onClick={() => onOpenWhatsAppOrder(product, selectedColor, selectedSize, quantity)}
            className="flex flex-col items-center justify-center p-1.5 text-emerald-600 hover:text-emerald-700 transition-colors"
            title="Order via WhatsApp"
          >
            <MessageCircle className="w-5 h-5 fill-[#25D366] text-[#25D366]" />
            <span className="text-[9px] font-bold mt-0.5 text-emerald-700">WhatsApp</span>
          </button>
        )}

        {/* Add to Cart CTA */}
        <button
          onClick={handleAdd}
          className="flex-1 bg-orange-50 text-[#FF6600] border border-[#FF6600] h-10 rounded-xl font-bold text-xs flex items-center justify-center gap-1 hover:bg-orange-100 active:scale-98 transition-all"
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Add to Cart</span>
        </button>

        {/* Buy Now CTA */}
        <button
          onClick={handleBuy}
          className="flex-1 bg-[#FF6600] text-white h-10 rounded-xl font-bold text-xs flex items-center justify-center shadow-md hover:bg-orange-600 active:scale-98 transition-all"
        >
          Buy Now
        </button>
      </div>
    </div>
  );
};
