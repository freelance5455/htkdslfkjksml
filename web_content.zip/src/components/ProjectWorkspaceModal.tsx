import React, { useState } from 'react';
import {
  Archive,
  BookOpen,
  Check,
  Folder,
  FolderPlus,
  MessageSquare,
  Plus,
  RefreshCw,
  Trash2,
  X,
} from 'lucide-react';
import type { ConversationItem, ProjectItem } from '../types.ts';

interface ProjectWorkspaceModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: ProjectItem[];
  conversations: ConversationItem[];
  selectedProjectId: string | null;
  onSelectProject: (projectId: string | null) => void;
  onCreateProject: (name: string, description: string, contextBrief: string) => Promise<void>;
  onUpdateProject: (id: string, updates: Partial<ProjectItem>) => Promise<void>;
  onDeleteProject: (id: string, permanent?: boolean) => Promise<void>;
  onSelectConversation: (convId: string) => void;
  onCreateConversationInProject: (projectId: string, title?: string) => void;
}

export const ProjectWorkspaceModal: React.FC<ProjectWorkspaceModalProps> = ({
  isOpen,
  onClose,
  projects,
  conversations,
  selectedProjectId,
  onSelectProject,
  onCreateProject,
  onUpdateProject,
  onDeleteProject,
  onSelectConversation,
  onCreateConversationInProject,
}) => {
  const [activeTab, setActiveTab] = useState<'PROJECTS' | 'CREATE' | 'TRASH'>('PROJECTS');
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);

  // Form states for creating a project
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [contextBrief, setContextBrief] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Edit states
  const [editName, setEditName] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editBrief, setEditBrief] = useState('');

  if (!isOpen) return null;

  const currentProject = projects.find((p) => p.id === (editingProjectId || selectedProjectId));
  const activeProjects = projects.filter((p) => !p.isTrash && !p.isArchived);
  const archivedProjects = projects.filter((p) => p.isArchived && !p.isTrash);
  const trashProjects = projects.filter((p) => p.isTrash);

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || isSubmitting) return;
    setIsSubmitting(true);
    try {
      await onCreateProject(name.trim(), description.trim(), contextBrief.trim());
      setName('');
      setDescription('');
      setContextBrief('');
      setActiveTab('PROJECTS');
    } catch (err) {
      console.error('Failed to create project:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const startEditing = (p: ProjectItem) => {
    setEditingProjectId(p.id);
    setEditName(p.name);
    setEditDescription(p.description);
    setEditBrief(p.contextBrief || '');
  };

  const handleSaveEdit = async () => {
    if (!editingProjectId || !editName.trim()) return;
    try {
      await onUpdateProject(editingProjectId, {
        name: editName.trim(),
        description: editDescription.trim(),
        contextBrief: editBrief.trim(),
      });
      setEditingProjectId(null);
    } catch (err) {
      console.error('Failed to save project edits:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xl w-full max-w-3xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-100 text-sky-700">
              <Folder className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 font-mono tracking-tight uppercase">
                INTELLIGENT WORKSPACES &amp; PROJECTS
              </h2>
              <p className="text-xs text-slate-500">
                Organize conversations, memory context briefs, and multi-chat sessions
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Workspace Navigation Tabs */}
        <div className="px-5 pt-3 border-b border-slate-200 flex items-center justify-between gap-4">
          <div className="flex gap-1">
            <button
              onClick={() => {
                setActiveTab('PROJECTS');
                setEditingProjectId(null);
              }}
              className={`px-3 py-2 text-xs font-semibold rounded-t-lg border-b-2 transition-all ${
                activeTab === 'PROJECTS'
                  ? 'border-sky-600 text-sky-700 bg-sky-50/50'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              Active Projects ({activeProjects.length})
            </button>
            <button
              onClick={() => {
                setActiveTab('CREATE');
                setEditingProjectId(null);
              }}
              className={`px-3 py-2 text-xs font-semibold rounded-t-lg border-b-2 transition-all flex items-center gap-1.5 ${
                activeTab === 'CREATE'
                  ? 'border-sky-600 text-sky-700 bg-sky-50/50'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Project</span>
            </button>
            <button
              onClick={() => {
                setActiveTab('TRASH');
                setEditingProjectId(null);
              }}
              className={`px-3 py-2 text-xs font-semibold rounded-t-lg border-b-2 transition-all flex items-center gap-1.5 ${
                activeTab === 'TRASH'
                  ? 'border-rose-600 text-rose-700 bg-rose-50/50'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Trash ({trashProjects.length})</span>
            </button>
          </div>

          <div className="text-[11px] font-mono text-slate-400">
            Current Filter:{' '}
            <span className="font-bold text-slate-700">
              {selectedProjectId
                ? projects.find((p) => p.id === selectedProjectId)?.name || 'Custom Project'
                : 'All Projects'}
            </span>
          </div>
        </div>

        {/* Tab Contents */}
        <div className="flex-1 overflow-y-auto p-5">
          {activeTab === 'CREATE' && (
            <form onSubmit={handleCreateSubmit} className="space-y-4 max-w-xl mx-auto py-2">
              <div>
                <label className="block text-xs font-bold font-mono text-slate-700 mb-1">
                  PROJECT NAME *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Quantum Gravity Hinglish Research"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-sky-500"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-bold font-mono text-slate-700 mb-1">
                  PROJECT DESCRIPTION
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Unified quantum geometry investigations with Aaradhy Parmar"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold font-mono text-slate-700 mb-1">
                  LAYERED CONTEXT BRIEF (INJECTED INTO PROMPT ENGINE)
                </label>
                <textarea
                  rows={3}
                  value={contextBrief}
                  onChange={(e) => setContextBrief(e.target.value)}
                  placeholder="Specific rules, assumptions, or project background automatically primed into every prompt in this project..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-sky-500 resize-none font-sans"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  All chats linked to this project inherit this brief as Layer 1 Context.
                </span>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('PROJECTS')}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!name.trim() || isSubmitting}
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? 'Creating...' : 'Create Project'}
                </button>
              </div>
            </form>
          )}

          {activeTab === 'PROJECTS' && (
            <div className="space-y-4">
              {/* Filter banner */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <span className="text-slate-600">
                  Select a project to filter the chat console, or switch to unrestricted view.
                </span>
                <button
                  onClick={() => {
                    onSelectProject(null);
                    onClose();
                  }}
                  className={`px-3 py-1 rounded-lg font-mono font-bold text-[11px] transition-all ${
                    selectedProjectId === null
                      ? 'bg-sky-600 text-white shadow-2xs'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Show All Chats
                </button>
              </div>

              {/* Projects Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {activeProjects.map((p) => {
                  const isSelected = selectedProjectId === p.id;
                  const isEditingThis = editingProjectId === p.id;
                  const projectConvs = conversations.filter((c) => c.projectId === p.id && !c.isTrash);

                  return (
                    <div
                      key={p.id}
                      className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                        isSelected
                          ? 'bg-sky-50/40 border-sky-400 shadow-xs ring-1 ring-sky-300'
                          : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-xs'
                      }`}
                    >
                      {isEditingThis ? (
                        <div className="space-y-2.5">
                          <input
                            type="text"
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            className="w-full px-2 py-1 text-xs border border-sky-400 rounded bg-white font-bold"
                          />
                          <input
                            type="text"
                            value={editDescription}
                            onChange={(e) => setEditDescription(e.target.value)}
                            placeholder="Description"
                            className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white"
                          />
                          <textarea
                            rows={2}
                            value={editBrief}
                            onChange={(e) => setEditBrief(e.target.value)}
                            placeholder="Context brief"
                            className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white resize-none"
                          />
                          <div className="flex gap-2 justify-end pt-1">
                            <button
                              onClick={() => setEditingProjectId(null)}
                              className="px-2.5 py-1 text-xs text-slate-500 hover:text-slate-800"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={handleSaveEdit}
                              className="px-3 py-1 bg-sky-600 text-white rounded text-xs font-bold"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div>
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <Folder className="w-4 h-4 text-sky-600 shrink-0" />
                                <h3 className="font-bold text-sm text-slate-900 leading-tight">
                                  {p.name}
                                </h3>
                              </div>
                              {isSelected && (
                                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-sky-600 text-white font-bold shrink-0">
                                  FILTER ACTIVE
                                </span>
                              )}
                            </div>

                            <p className="text-xs text-slate-500 mt-1.5 line-clamp-2">
                              {p.description || 'No description provided.'}
                            </p>

                            {p.contextBrief && (
                              <div className="mt-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-600 flex items-start gap-1.5">
                                <BookOpen className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                                <span className="line-clamp-2 italic">{p.contextBrief}</span>
                              </div>
                            )}

                            <div className="mt-3 flex items-center justify-between text-[11px] font-mono text-slate-400">
                              <span className="flex items-center gap-1">
                                <MessageSquare className="w-3 h-3" />
                                {projectConvs.length} conversation{projectConvs.length === 1 ? '' : 's'}
                              </span>
                              <span>{new Date(p.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>

                          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => startEditing(p)}
                                className="px-2 py-1 text-xs text-slate-600 hover:text-sky-700 hover:bg-slate-100 rounded"
                              >
                                Edit
                              </button>
                              <button
                                onClick={() => onUpdateProject(p.id, { isArchived: true })}
                                className="px-2 py-1 text-xs text-slate-600 hover:text-amber-700 hover:bg-slate-100 rounded"
                                title="Archive project"
                              >
                                Archive
                              </button>
                              <button
                                onClick={() => onDeleteProject(p.id, false)}
                                className="px-2 py-1 text-xs text-slate-600 hover:text-rose-700 hover:bg-slate-100 rounded"
                                title="Move to Trash"
                              >
                                Trash
                              </button>
                            </div>

                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() => {
                                  onCreateConversationInProject(p.id, `${p.name} - Chat`);
                                  onClose();
                                }}
                                className="px-2.5 py-1 text-xs font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 rounded-lg flex items-center gap-1"
                                title="Create new chat in this project"
                              >
                                <Plus className="w-3 h-3" />
                                <span>New Chat</span>
                              </button>
                              <button
                                onClick={() => {
                                  onSelectProject(isSelected ? null : p.id);
                                  onClose();
                                }}
                                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                                  isSelected
                                    ? 'bg-slate-200 text-slate-800'
                                    : 'bg-sky-600 hover:bg-sky-700 text-white'
                                }`}
                              >
                                {isSelected ? 'Clear Filter' : 'Open Workspace'}
                              </button>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Archived Projects Section if any */}
              {archivedProjects.length > 0 && (
                <div className="mt-6 pt-4 border-t border-slate-200">
                  <h4 className="text-xs font-bold font-mono text-slate-500 uppercase mb-2">
                    ARCHIVED WORKSPACES ({archivedProjects.length})
                  </h4>
                  <div className="space-y-2">
                    {archivedProjects.map((p) => (
                      <div
                        key={p.id}
                        className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-700">{p.name}</span>
                          <span className="text-slate-400 ml-2 font-mono">
                            {p.conversationCount || 0} chats
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onUpdateProject(p.id, { isArchived: false, status: 'ACTIVE' })}
                            className="px-2.5 py-1 text-xs font-bold bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 rounded-lg flex items-center gap-1"
                          >
                            <RefreshCw className="w-3 h-3" />
                            Restore
                          </button>
                          <button
                            onClick={() => onDeleteProject(p.id, false)}
                            className="p-1 text-slate-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'TRASH' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center justify-between">
                <span>
                  Items in trash can be restored or permanently removed from the system.
                </span>
              </div>

              {trashProjects.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs font-mono">
                  Project trash is empty.
                </div>
              ) : (
                <div className="space-y-2">
                  {trashProjects.map((p) => (
                    <div
                      key={p.id}
                      className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-slate-800">{p.name}</span>
                        <p className="text-[11px] text-slate-500">{p.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onUpdateProject(p.id, { isTrash: false, isArchived: false, status: 'ACTIVE' })}
                          className="px-3 py-1 bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 rounded-lg text-xs font-bold flex items-center gap-1"
                        >
                          <RefreshCw className="w-3 h-3" />
                          Restore
                        </button>
                        <button
                          onClick={() => onDeleteProject(p.id, true)}
                          className="px-3 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 rounded-lg text-xs font-bold flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" />
                          Permanent Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
