import { useEffect, useState } from "react";
import {
  courseByCode,
  courses,
  days,
  findFocus,
  lunch,
  periods,
  school,
  sourceNotes,
  type Slot,
} from "@/data/program";

function LessonBody({ slot }: { slot: Slot }) {
  const course = courseByCode(slot.code);
  return (
    <div className="min-w-0">
      <p className="font-semibold leading-snug text-ink">
        {course.name}
        {course.code === "TDE" ? "*" : ""}
      </p>
      <p className="mt-1 text-sm text-muted">{slot.teacher}</p>
      {slot.room ? <p className="mt-1 text-sm text-accent">Derslik {slot.room}</p> : null}
    </div>
  );
}

function EmptyLesson() {
  return <p className="text-sm text-muted">Ders yok</p>;
}

export function DersProgrami() {
  const [today, setToday] = useState<number | null>(null);
  const [focusLabel, setFocusLabel] = useState<string | null>(null);

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setToday(now.getDay());
      const focus = findFocus(now);
      if (!focus) {
        setFocusLabel(null);
        return;
      }
      const course = courseByCode(focus.slot.code);
      const when =
        focus.kind === "now" ? "Şu an" : "Sıradaki ders";
      setFocusLabel(
        `${when}: ${focus.day.name}, ${focus.period.no}. ders, ${focus.period.start}–${focus.period.end}. ${course.name}, ${focus.slot.teacher}.`,
      );
    };
    update();
    const timer = window.setInterval(update, 60_000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="border-b border-line bg-card">
        <div className="mx-auto max-w-7xl px-4 py-8 md:px-8 md:py-10">
          <p className="text-xs font-semibold tracking-widest text-accent uppercase">
            {school.authority}
          </p>
          <p className="mt-2 max-w-3xl font-serif text-3xl leading-tight text-ink md:text-4xl">
            {school.name}
          </p>
          <h1 className="mt-4 text-lg font-semibold text-ink md:text-xl">
            {school.grade} ders programı
          </h1>
          <dl className="mt-6 grid gap-3 sm:grid-cols-3">
            <div className="rounded-lg border border-line bg-quiet px-4 py-3">
              <dt className="text-xs font-medium tracking-wide text-muted uppercase">
                Sınıf öğretmeni
              </dt>
              <dd className="mt-1 font-semibold">{school.homeroom}</dd>
            </div>
            <div className="rounded-lg border border-line bg-quiet px-4 py-3">
              <dt className="text-xs font-medium tracking-wide text-muted uppercase">
                Toplam ders saati
              </dt>
              <dd className="mt-1 font-semibold">{school.totalHours}</dd>
            </div>
            <div className="rounded-lg border border-line bg-quiet px-4 py-3">
              <dt className="text-xs font-medium tracking-wide text-muted uppercase">
                Program tarihi
              </dt>
              <dd className="mt-1 font-semibold">{school.issued}</dd>
            </div>
          </dl>
          {focusLabel ? (
            <p className="mt-5 rounded-lg border border-line bg-accent-soft px-4 py-3 text-sm leading-relaxed text-accent">
              {focusLabel}
            </p>
          ) : null}
        </div>
      </header>

      <nav
        className="no-print sticky top-0 z-10 border-b border-line bg-paper lg:hidden"
        aria-label="Günler"
      >
        <div className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 py-3">
          {days.map((day) => (
            <a
              key={day.id}
              href={`#${day.id}`}
              className="shrink-0 rounded-full border border-line bg-card px-4 py-2 text-sm font-semibold text-ink"
            >
              {day.name}
              {today === day.jsDay ? " · bugün" : ""}
            </a>
          ))}
        </div>
      </nav>

      <main className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-10">
        <section aria-labelledby="hafta-baslik">
          <div className="mb-4 flex items-end justify-between gap-4">
            <h2 id="hafta-baslik" className="font-serif text-2xl text-ink">
              Haftalık program
            </h2>
            <p className="text-sm text-muted">Tam ders adları</p>
          </div>

          <div className="hidden overflow-hidden rounded-xl border border-line bg-card lg:block">
            <table className="w-full border-collapse text-left">
              <caption className="sr-only">
                {school.grade} sınıfının pazartesiden cumaya haftalık ders programı
              </caption>
              <thead>
                <tr className="bg-accent text-card">
                  <th scope="col" className="w-28 px-3 py-3 text-sm font-semibold">
                    Saat
                  </th>
                  {days.map((day) => (
                    <th key={day.id} scope="col" className="px-3 py-3 text-sm font-semibold">
                      {day.name}
                      {today === day.jsDay ? (
                        <span className="mt-1 block text-xs font-medium text-accent-soft">Bugün</span>
                      ) : null}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {periods.map((period, periodIndex) => (
                  <WeekRows key={period.no} periodIndex={periodIndex} today={today} />
                ))}
              </tbody>
            </table>
          </div>

          <div className="space-y-8 lg:hidden">
            {days.map((day) => (
              <section
                key={day.id}
                id={day.id}
                className="scroll-mt-20 overflow-hidden rounded-xl border border-line bg-card"
              >
                <h3 className="border-b border-line bg-accent px-4 py-3 font-semibold text-card">
                  {day.name}
                  {today === day.jsDay ? " · bugün" : ""}
                </h3>
                <ol>
                  {periods.map((period, periodIndex) => {
                    const lesson = day.slots[periodIndex];
                    const showLunch = period.no === lunch.after;
                    return (
                      <li key={period.no}>
                        <div className="grid grid-cols-[5.5rem_1fr] gap-3 border-b border-line px-4 py-3">
                          <div>
                            <p className="text-sm font-semibold tabular-nums">{period.start}</p>
                            <p className="text-xs text-muted tabular-nums">{period.end}</p>
                            <p className="mt-1 text-xs text-muted">{period.no}. ders</p>
                          </div>
                          {lesson ? <LessonBody slot={lesson} /> : <EmptyLesson />}
                        </div>
                        {showLunch ? (
                          <p className="border-b border-line bg-lunch px-4 py-2 text-sm font-medium text-ink">
                            {lunch.label} · {lunch.start}–{lunch.end}
                          </p>
                        ) : null}
                      </li>
                    );
                  })}
                </ol>
              </section>
            ))}
          </div>
        </section>

        <section className="mt-12" aria-labelledby="liste-baslik">
          <h2 id="liste-baslik" className="font-serif text-2xl text-ink">
            Derslerin tam listesi
          </h2>
          <p className="mt-2 max-w-3xl text-sm leading-relaxed text-muted">
            Belgedeki 17 dersin tamamı. Haftalık saatler, yer, öğretmenler ve veli görüşme
            yeri belgede nasıl duruyorsa öyle aktarıldı.
          </p>

          <div className="mt-5 hidden overflow-hidden rounded-xl border border-line bg-card md:block">
            <table className="w-full border-collapse text-left text-sm">
              <thead className="bg-quiet text-muted">
                <tr>
                  <th className="px-3 py-3 font-semibold">No</th>
                  <th className="px-3 py-3 font-semibold">Kod</th>
                  <th className="px-3 py-3 font-semibold">Dersin adı</th>
                  <th className="px-3 py-3 font-semibold">Saat</th>
                  <th className="px-3 py-3 font-semibold">Yer</th>
                  <th className="px-3 py-3 font-semibold">Öğretmen</th>
                  <th className="px-3 py-3 font-semibold">Veli görüşme yeri</th>
                </tr>
              </thead>
              <tbody>
                {courses.map((course) => (
                  <tr key={course.code} className="border-t border-line align-top">
                    <td className="px-3 py-3 tabular-nums">{course.no}</td>
                    <td className="px-3 py-3 whitespace-nowrap text-muted">{course.code}</td>
                    <td className="px-3 py-3 font-semibold">
                      {course.name}
                      {course.code === "TDE" ? "*" : ""}
                    </td>
                    <td className="px-3 py-3 tabular-nums">{course.hours}</td>
                    <td className="px-3 py-3">{course.place || "—"}</td>
                    <td className="px-3 py-3">{course.teachers.join(", ")}</td>
                    <td className="px-3 py-3">{course.parentPlace || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <ol className="mt-5 space-y-3 md:hidden">
            {courses.map((course) => (
              <li key={course.code} className="rounded-xl border border-line bg-card px-4 py-3">
                <p className="text-xs font-medium tracking-wide text-muted uppercase">
                  {course.no}. ders · {course.code} · {course.hours} saat
                </p>
                <p className="mt-1 font-semibold">
                  {course.name}
                  {course.code === "TDE" ? "*" : ""}
                </p>
                <p className="mt-2 text-sm">{course.teachers.join(", ")}</p>
                <p className="mt-1 text-sm text-muted">Yer: {course.place || "belirtilmemiş"}</p>
                <p className="text-sm text-muted">
                  Veli görüşme yeri: {course.parentPlace || "belirtilmemiş"}
                </p>
              </li>
            ))}
          </ol>
        </section>

        <footer className="mt-12 border-t border-line pt-6">
          <p className="max-w-3xl text-sm leading-relaxed">{school.issuedNote}</p>
          <p className="mt-6 font-semibold">{school.principal}</p>
          <p className="text-sm text-muted">{school.principalTitle}</p>
          <h2 className="mt-8 text-sm font-semibold tracking-wide text-muted uppercase">
            Belgeden aynen alınan notlar
          </h2>
          <ul className="mt-3 max-w-3xl space-y-2 text-sm leading-relaxed text-muted">
            {sourceNotes.map((note) => (
              <li key={note}>{note}</li>
            ))}
          </ul>
        </footer>
      </main>
    </div>
  );
}

function WeekRows({ periodIndex, today }: { periodIndex: number; today: number | null }) {
  const period = periods[periodIndex];
  const showLunch = period.no === lunch.after;

  return (
    <>
      <tr className="border-t border-line align-top">
        <th scope="row" className="bg-quiet px-3 py-3">
          <span className="block text-sm font-semibold tabular-nums">{period.start}</span>
          <span className="block text-xs font-medium text-muted tabular-nums">{period.end}</span>
          <span className="mt-1 block text-xs font-medium text-muted">{period.no}. ders</span>
        </th>
        {days.map((day) => {
          const lesson = day.slots[periodIndex];
          const isToday = today === day.jsDay;
          return (
            <td key={day.id} className={isToday ? "bg-accent-soft px-3 py-3" : "px-3 py-3"}>
              {lesson ? <LessonBody slot={lesson} /> : <EmptyLesson />}
            </td>
          );
        })}
      </tr>
      {showLunch ? (
        <tr>
          <td colSpan={6} className="border-t border-line bg-lunch px-3 py-2 text-sm font-medium">
            {lunch.label} · {lunch.start}–{lunch.end}
          </td>
        </tr>
      ) : null}
    </>
  );
}
