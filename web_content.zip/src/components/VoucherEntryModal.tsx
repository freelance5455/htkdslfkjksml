import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Mic,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import {
  Company,
  Ledger,
  StockItem,
  Voucher,
  VoucherType,
  VoucherItemRow,
  VoucherAccountRow,
} from '../types/tally';
import { formatCurrency, formatINR } from '../utils/tallyEngine';
import { triggerHaptic, soundManager } from '../utils/haptics';

interface VoucherEntryModalProps {
  isOpen: boolean;
  initialType?: VoucherType;
  company: Company;
  ledgers: Ledger[];
  stockItems: StockItem[];
  vouchersCount: number;
  onClose: () => void;
  onSaveVoucher: (voucher: Voucher) => void;
}

export const VoucherEntryModal: React.FC<VoucherEntryModalProps> = ({
  isOpen,
  initialType = 'sales',
  company,
  ledgers,
  stockItems,
  vouchersCount,
  onClose,
  onSaveVoucher,
}) => {
  const [voucherType, setVoucherType] = useState<VoucherType>(initialType);
  const [date, setDate] = useState<string>('2026-04-20');
  const [voucherNumber, setVoucherNumber] = useState<string>('');
  const [referenceNo, setReferenceNo] = useState<string>('');
  const [partyLedgerId, setPartyLedgerId] = useState<string>('');
  const [salesPurchaseLedgerId, setSalesPurchaseLedgerId] = useState<string>('');
  const [isInterstate, setIsInterstate] = useState<boolean>(false);
  const [narration, setNarration] = useState<string>('');
  const [showAcceptPrompt, setShowAcceptPrompt] = useState<boolean>(false);

  // Invoice Mode Items
  const [items, setItems] = useState<VoucherItemRow[]>([]);

  // Double-Entry Mode Rows
  const [accountRows, setAccountRows] = useState<VoucherAccountRow[]>([]);

  // Pre-fill next voucher number
  useEffect(() => {
    if (isOpen) {
      setVoucherType(initialType);
      const prefixMap: Record<VoucherType, string> = {
        sales: 'SAL',
        purchase: 'PUR',
        payment: 'PYM',
        receipt: 'RCP',
        contra: 'CNT',
        journal: 'JRN',
        debit_note: 'DBN',
        credit_note: 'CRN',
      };
      const num = String(vouchersCount + 1).padStart(3, '0');
      setVoucherNumber(`${prefixMap[initialType]}-${num}`);

      // Default party selection based on type
      if (initialType === 'sales') {
        const debtor = ledgers.find((l) => l.group === 'Sundry Debtors');
        const salesLed = ledgers.find((l) => l.group === 'Sales Accounts');
        if (debtor) setPartyLedgerId(debtor.id);
        if (salesLed) setSalesPurchaseLedgerId(salesLed.id);

        if (stockItems.length > 0) {
          const item1 = stockItems[0];
          setItems([
            {
              id: 'row_' + Date.now(),
              itemId: item1.id,
              itemName: item1.name,
              qty: 1,
              rate: item1.standardSellingRate,
              unit: item1.unit,
              amount: item1.standardSellingRate,
              gstRate: item1.gstRate,
              hsnCode: item1.hsnCode,
            },
          ]);
        }
      } else if (initialType === 'purchase') {
        const cred = ledgers.find((l) => l.group === 'Sundry Creditors');
        const purLed = ledgers.find((l) => l.group === 'Purchase Accounts');
        if (cred) setPartyLedgerId(cred.id);
        if (purLed) setSalesPurchaseLedgerId(purLed.id);

        if (stockItems.length > 0) {
          const item1 = stockItems[0];
          setItems([
            {
              id: 'row_' + Date.now(),
              itemId: item1.id,
              itemName: item1.name,
              qty: 5,
              rate: item1.openingRate,
              unit: item1.unit,
              amount: item1.openingRate * 5,
              gstRate: item1.gstRate,
              hsnCode: item1.hsnCode,
            },
          ]);
        }
      } else if (initialType === 'payment') {
        const cred = ledgers.find((l) => l.group === 'Sundry Creditors') || ledgers[0];
        const bank = ledgers.find((l) => l.group === 'Bank Accounts') || ledgers[1];
        setAccountRows([
          { id: '1', ledgerId: cred?.id || '', ledgerName: cred?.name || '', type: 'Dr', amount: 5000 },
          { id: '2', ledgerId: bank?.id || '', ledgerName: bank?.name || '', type: 'Cr', amount: 5000 },
        ]);
      } else if (initialType === 'receipt') {
        const debtor = ledgers.find((l) => l.group === 'Sundry Debtors') || ledgers[0];
        const bank = ledgers.find((l) => l.group === 'Bank Accounts') || ledgers[1];
        setAccountRows([
          { id: '1', ledgerId: bank?.id || '', ledgerName: bank?.name || '', type: 'Dr', amount: 10000 },
          { id: '2', ledgerId: debtor?.id || '', ledgerName: debtor?.name || '', type: 'Cr', amount: 10000 },
        ]);
      } else if (initialType === 'contra') {
        const cash = ledgers.find((l) => l.group === 'Cash-in-hand');
        const bank = ledgers.find((l) => l.group === 'Bank Accounts');
        setAccountRows([
          { id: '1', ledgerId: cash?.id || '', ledgerName: cash?.name || '', type: 'Dr', amount: 5000 },
          { id: '2', ledgerId: bank?.id || '', ledgerName: bank?.name || '', type: 'Cr', amount: 5000 },
        ]);
      } else {
        // Journal
        const exp = ledgers.find((l) => l.group === 'Indirect Expenses') || ledgers[0];
        const cred = ledgers.find((l) => l.group === 'Sundry Creditors') || ledgers[1];
        setAccountRows([
          { id: '1', ledgerId: exp?.id || '', ledgerName: exp?.name || '', type: 'Dr', amount: 2500 },
          { id: '2', ledgerId: cred?.id || '', ledgerName: cred?.name || '', type: 'Cr', amount: 2500 },
        ]);
      }

      setShowAcceptPrompt(false);
    }
  }, [isOpen, initialType, vouchersCount]);

  if (!isOpen) return null;

  const isInvoiceMode = voucherType === 'sales' || voucherType === 'purchase';

  // Find party ledger object
  const selectedParty = ledgers.find((l) => l.id === partyLedgerId);

  // Calculations for Invoice mode
  const taxableAmount = items.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
  let totalCGST = 0;
  let totalSGST = 0;
  let totalIGST = 0;

  for (const item of items) {
    const rate = item.gstRate || 0;
    const tax = ((Number(item.amount) || 0) * rate) / 100;
    if (isInterstate) {
      totalIGST += tax;
    } else {
      totalCGST += tax / 2;
      totalSGST += tax / 2;
    }
  }

  const rawTotal = taxableAmount + totalCGST + totalSGST + totalIGST;
  const roundedTotal = Math.round(rawTotal);
  const roundOff = Number((roundedTotal - rawTotal).toFixed(2));

  // Calculations for Double-Entry mode
  const totalDebit = accountRows
    .filter((r) => r.type === 'Dr')
    .reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
  const totalCredit = accountRows
    .filter((r) => r.type === 'Cr')
    .reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
  const isDoubleEntryBalanced = Math.abs(totalDebit - totalCredit) < 0.01 && totalDebit > 0;

  // Change voucher type
  const handleTypeChange = (type: VoucherType) => {
    triggerHaptic('light');
    soundManager.playKeyClick();
    setVoucherType(type);
    const prefixMap: Record<VoucherType, string> = {
      sales: 'SAL',
      purchase: 'PUR',
      payment: 'PYM',
      receipt: 'RCP',
      contra: 'CNT',
      journal: 'JRN',
      debit_note: 'DBN',
      credit_note: 'CRN',
    };
    const num = String(vouchersCount + 1).padStart(3, '0');
    setVoucherNumber(`${prefixMap[type]}-${num}`);

    if (type === 'sales') {
      const debtor = ledgers.find((l) => l.group === 'Sundry Debtors');
      if (debtor) setPartyLedgerId(debtor.id);
      const salesLed = ledgers.find((l) => l.group === 'Sales Accounts');
      if (salesLed) setSalesPurchaseLedgerId(salesLed.id);
    } else if (type === 'purchase') {
      const cred = ledgers.find((l) => l.group === 'Sundry Creditors');
      if (cred) setPartyLedgerId(cred.id);
      const purLed = ledgers.find((l) => l.group === 'Purchase Accounts');
      if (purLed) setSalesPurchaseLedgerId(purLed.id);
    } else if (accountRows.length === 0) {
      setAccountRows([
        { id: '1', ledgerId: ledgers[0]?.id || '', ledgerName: ledgers[0]?.name || '', type: 'Dr', amount: 1000 },
        { id: '2', ledgerId: ledgers[1]?.id || '', ledgerName: ledgers[1]?.name || '', type: 'Cr', amount: 1000 },
      ]);
    }
  };

  // Item row operations
  const handleAddItemRow = () => {
    triggerHaptic('light');
    soundManager.playKeyClick();
    const defaultItem = stockItems[0];
    if (!defaultItem) return;

    const rate = voucherType === 'sales' ? defaultItem.standardSellingRate : defaultItem.openingRate;
    setItems([
      ...items,
      {
        id: 'row_' + Date.now(),
        itemId: defaultItem.id,
        itemName: defaultItem.name,
        qty: 1,
        rate,
        unit: defaultItem.unit,
        amount: rate,
        gstRate: defaultItem.gstRate,
        hsnCode: defaultItem.hsnCode,
      },
    ]);
  };

  const handleUpdateItem = (
    index: number,
    field: keyof VoucherItemRow,
    value: string | number
  ) => {
    const updated = [...items];
    const row = { ...updated[index] };

    if (field === 'itemId') {
      const selected = stockItems.find((s) => s.id === value);
      if (selected) {
        row.itemId = selected.id;
        row.itemName = selected.name;
        row.unit = selected.unit;
        row.gstRate = selected.gstRate;
        row.hsnCode = selected.hsnCode;
        row.rate = voucherType === 'sales' ? selected.standardSellingRate : selected.openingRate;
        row.amount = row.qty * row.rate;
      }
    } else if (field === 'qty') {
      row.qty = Number(value) || 0;
      row.amount = row.qty * row.rate;
    } else if (field === 'rate') {
      row.rate = Number(value) || 0;
      row.amount = row.qty * row.rate;
    }

    updated[index] = row;
    setItems(updated);
  };

  const handleRemoveItem = (index: number) => {
    triggerHaptic('light');
    setItems(items.filter((_, i) => i !== index));
  };

  // Account row operations (Double-Entry)
  const handleAddAccountRow = () => {
    triggerHaptic('light');
    soundManager.playKeyClick();
    const targetType: 'Dr' | 'Cr' = totalDebit > totalCredit ? 'Cr' : 'Dr';
    const diff = Math.abs(totalDebit - totalCredit) || 1000;
    setAccountRows([
      ...accountRows,
      {
        id: 'acc_' + Date.now(),
        ledgerId: ledgers[0]?.id || '',
        ledgerName: ledgers[0]?.name || '',
        type: targetType,
        amount: diff,
      },
    ]);
  };

  const handleUpdateAccountRow = (
    index: number,
    field: keyof VoucherAccountRow,
    value: string | number
  ) => {
    const updated = [...accountRows];
    const row = { ...updated[index] };

    if (field === 'ledgerId') {
      const led = ledgers.find((l) => l.id === value);
      row.ledgerId = String(value);
      row.ledgerName = led?.name || '';
    } else if (field === 'type') {
      row.type = value as 'Dr' | 'Cr';
    } else if (field === 'amount') {
      row.amount = Number(value) || 0;
    }

    updated[index] = row;
    setAccountRows(updated);
  };

  const handleRemoveAccountRow = (index: number) => {
    triggerHaptic('light');
    setAccountRows(accountRows.filter((_, i) => i !== index));
  };

  // Trigger Accept Prompt
  const handlePreSave = () => {
    if (isInvoiceMode) {
      if (items.length === 0 || roundedTotal <= 0) {
        alert('Please add at least one line item with valid amount.');
        return;
      }
    } else {
      if (!isDoubleEntryBalanced) {
        alert(`Debits (${formatCurrency(totalDebit)}) must equal Credits (${formatCurrency(totalCredit)}).`);
        return;
      }
    }

    triggerHaptic('medium');
    soundManager.playKeyClick();
    setShowAcceptPrompt(true);
  };

  // Confirm Save (Yes)
  const handleFinalAccept = () => {
    triggerHaptic('success');
    soundManager.playAcceptChime();

    const selectedPartyLedger = ledgers.find((l) => l.id === partyLedgerId);
    const selectedSalesPurch = ledgers.find((l) => l.id === salesPurchaseLedgerId);

    const newVoucher: Voucher = {
      id: 'vch_' + Date.now(),
      voucherNumber: voucherNumber.trim() || `VCH-${Date.now()}`,
      voucherType,
      date,
      referenceNo: referenceNo.trim() || undefined,
      partyLedgerId: isInvoiceMode ? partyLedgerId : undefined,
      partyLedgerName: isInvoiceMode ? selectedPartyLedger?.name : undefined,
      salesPurchaseLedgerId: isInvoiceMode ? salesPurchaseLedgerId : undefined,
      salesPurchaseLedgerName: isInvoiceMode ? selectedSalesPurch?.name : undefined,
      isInterstate,
      items: isInvoiceMode ? items : undefined,
      taxableAmount: isInvoiceMode ? taxableAmount : 0,
      cgstAmount: isInvoiceMode ? totalCGST : 0,
      sgstAmount: isInvoiceMode ? totalSGST : 0,
      igstAmount: isInvoiceMode ? totalIGST : 0,
      roundOff: isInvoiceMode ? roundOff : 0,
      totalAmount: isInvoiceMode ? roundedTotal : totalDebit,
      rows: !isInvoiceMode ? accountRows : undefined,
      narration: narration.trim() || (isInvoiceMode ? `Being goods billed on ${date}` : `Being transaction recorded on ${date}`),
      createdAt: new Date().toISOString(),
    };

    onSaveVoucher(newVoucher);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="bg-emerald-900 text-white px-4 py-3 flex items-center justify-between shrink-0">
          <div>
            <div className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">
              Accounting Voucher Creation
            </div>
            <div className="text-base font-bold flex items-center gap-2">
              <span>{voucherType.toUpperCase()}</span>
              <span className="text-xs font-mono font-normal text-emerald-200">
                No. {voucherNumber}
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            className="p-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-emerald-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Voucher Type Tabs (Speed Dial) */}
        <div className="px-3 py-2 bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 overflow-x-auto no-scrollbar shrink-0">
          <div className="flex items-center gap-1 min-w-max">
            {(['sales', 'purchase', 'payment', 'receipt', 'contra', 'journal'] as VoucherType[]).map((t) => {
              const labelMap: Record<VoucherType, string> = {
                sales: 'F8: Sales',
                purchase: 'F9: Purchase',
                payment: 'F5: Payment',
                receipt: 'F6: Receipt',
                contra: 'F4: Contra',
                journal: 'F7: Journal',
                debit_note: 'Debit Note',
                credit_note: 'Credit Note',
              };
              const active = voucherType === t;
              return (
                <button
                  key={t}
                  onClick={() => handleTypeChange(t)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                    active
                      ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                      : 'bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {labelMap[t]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs text-slate-800 dark:text-slate-100">
          {/* Top Metadata Row: Date & Ref */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Date (Voucher Date)
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono font-medium focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Reference / PO No.
              </label>
              <input
                type="text"
                placeholder="e.g. PO-8891 / INV-42"
                value={referenceNo}
                onChange={(e) => setReferenceNo(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* INVOICE MODE (Sales / Purchase) */}
          {isInvoiceMode && (
            <>
              {/* Party A/c & Sales Ledger */}
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2.5">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-medium text-slate-600 dark:text-slate-300">
                      Party A/c Name (Buyer / Vendor)
                    </label>
                    {selectedParty && (
                      <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-1.5 py-0.5 rounded">
                        Bal: {formatCurrency(selectedParty.currentBalance)}{' '}
                        {selectedParty.currentBalanceType}
                      </span>
                    )}
                  </div>
                  <select
                    value={partyLedgerId}
                    onChange={(e) => {
                      setPartyLedgerId(e.target.value);
                      const p = ledgers.find((l) => l.id === e.target.value);
                      if (p && p.state && p.state !== company.state) {
                        setIsInterstate(true);
                      } else {
                        setIsInterstate(false);
                      }
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="">-- Select Party Ledger --</option>
                    {ledgers
                      .filter((l) =>
                        ['Sundry Debtors', 'Sundry Creditors', 'Cash-in-hand', 'Bank Accounts'].includes(
                          l.group
                        )
                      )
                      .map((led) => (
                        <option key={led.id} value={led.id}>
                          {led.name} ({led.group})
                        </option>
                      ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                      {voucherType === 'sales' ? 'Sales Ledger' : 'Purchase Ledger'}
                    </label>
                    <select
                      value={salesPurchaseLedgerId}
                      onChange={(e) => setSalesPurchaseLedgerId(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-emerald-500"
                    >
                      {ledgers
                        .filter((l) =>
                          voucherType === 'sales'
                            ? l.group === 'Sales Accounts'
                            : l.group === 'Purchase Accounts'
                        )
                        .map((led) => (
                          <option key={led.id} value={led.id}>
                            {led.name}
                          </option>
                        ))}
                    </select>
                  </div>

                  <div className="flex items-end pb-1">
                    <label className="flex items-center gap-2 cursor-pointer text-[11px] text-slate-600 dark:text-slate-300">
                      <input
                        type="checkbox"
                        checked={isInterstate}
                        onChange={(e) => setIsInterstate(e.target.checked)}
                        className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                      />
                      <span>Interstate (IGST)</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Items Table */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Item Details (Stock Movement)
                  </span>
                  <button
                    onClick={handleAddItemRow}
                    className="flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold hover:underline"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Item</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {items.map((row, index) => (
                    <div
                      key={row.id}
                      className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <select
                          value={row.itemId}
                          onChange={(e) => handleUpdateItem(index, 'itemId', e.target.value)}
                          className="flex-1 px-2 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium"
                        >
                          {stockItems.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name} (Stock: {s.currentQty} {s.unit})
                            </option>
                          ))}
                        </select>
                        <button
                          onClick={() => handleRemoveItem(index)}
                          className="p-1 text-slate-400 hover:text-rose-500 transition-colors"
                          title="Delete row"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="grid grid-cols-4 gap-2 text-center">
                        <div>
                          <label className="text-[10px] text-slate-400">Qty</label>
                          <input
                            type="number"
                            min="1"
                            value={row.qty}
                            onChange={(e) => handleUpdateItem(index, 'qty', e.target.value)}
                            className="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono text-center"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-400">Rate (₹)</label>
                          <input
                            type="number"
                            value={row.rate}
                            onChange={(e) => handleUpdateItem(index, 'rate', e.target.value)}
                            className="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono text-center"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-400">GST %</label>
                          <div className="text-xs font-mono py-1 text-slate-600 dark:text-slate-300">
                            {row.gstRate}%
                          </div>
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-400">Amount</label>
                          <div className="text-xs font-mono font-bold py-1 text-slate-900 dark:text-white tabular-nums">
                            {formatINR(row.amount, false)}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tax Computation Summary */}
              <div className="p-3 rounded-2xl bg-emerald-950/20 dark:bg-emerald-950/40 border border-emerald-300/40 dark:border-emerald-800/40 space-y-1.5 font-mono text-xs">
                <div className="flex justify-between text-slate-600 dark:text-slate-300">
                  <span>Taxable Subtotal:</span>
                  <span className="tabular-nums font-semibold">{formatCurrency(taxableAmount)}</span>
                </div>

                {!isInterstate ? (
                  <>
                    <div className="flex justify-between text-slate-600 dark:text-slate-400 text-[11px]">
                      <span>Output CGST (Central Tax):</span>
                      <span className="tabular-nums">{formatCurrency(totalCGST)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600 dark:text-slate-400 text-[11px]">
                      <span>Output SGST (State Tax):</span>
                      <span className="tabular-nums">{formatCurrency(totalSGST)}</span>
                    </div>
                  </>
                ) : (
                  <div className="flex justify-between text-slate-600 dark:text-slate-400 text-[11px]">
                    <span>Output IGST (Integrated Tax):</span>
                    <span className="tabular-nums">{formatCurrency(totalIGST)}</span>
                  </div>
                )}

                {roundOff !== 0 && (
                  <div className="flex justify-between text-slate-500 text-[10px]">
                    <span>Round Off:</span>
                    <span className="tabular-nums">{roundOff > 0 ? `+${roundOff}` : roundOff}</span>
                  </div>
                )}

                <div className="pt-2 border-t border-emerald-300/40 dark:border-emerald-700/60 flex justify-between text-base font-bold text-emerald-800 dark:text-emerald-300">
                  <span>Total Amount:</span>
                  <span className="tabular-nums">{formatCurrency(roundedTotal)}</span>
                </div>
              </div>
            </>
          )}

          {/* DOUBLE ENTRY MODE (Payment / Receipt / Contra / Journal) */}
          {!isInvoiceMode && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Particulars (Double-Entry Dr/Cr)
                </span>
                <button
                  onClick={handleAddAccountRow}
                  className="flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold hover:underline"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Line</span>
                </button>
              </div>

              <div className="space-y-2">
                {accountRows.map((row, index) => (
                  <div
                    key={row.id}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 flex items-center gap-2"
                  >
                    {/* Dr / Cr toggle */}
                    <button
                      onClick={() =>
                        handleUpdateAccountRow(index, 'type', row.type === 'Dr' ? 'Cr' : 'Dr')
                      }
                      className={`w-10 py-1.5 rounded-lg text-xs font-mono font-bold transition-colors ${
                        row.type === 'Dr'
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                          : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                      }`}
                    >
                      {row.type}
                    </button>

                    {/* Ledger Selector */}
                    <select
                      value={row.ledgerId}
                      onChange={(e) => handleUpdateAccountRow(index, 'ledgerId', e.target.value)}
                      className="flex-1 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium"
                    >
                      {ledgers.map((l) => (
                        <option key={l.id} value={l.id}>
                          {l.name} ({l.group})
                        </option>
                      ))}
                    </select>

                    {/* Amount */}
                    <div className="w-24">
                      <input
                        type="number"
                        value={row.amount}
                        onChange={(e) => handleUpdateAccountRow(index, 'amount', e.target.value)}
                        className="w-full px-2 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono text-right font-semibold"
                        placeholder="0.00"
                      />
                    </div>

                    {accountRows.length > 2 && (
                      <button
                        onClick={() => handleRemoveAccountRow(index)}
                        className="p-1 text-slate-400 hover:text-rose-500 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              {/* Balance Check Banner */}
              <div
                className={`p-3 rounded-xl border flex items-center justify-between text-xs font-mono ${
                  isDoubleEntryBalanced
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 text-emerald-800 dark:text-emerald-300'
                    : 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 text-amber-800 dark:text-amber-300'
                }`}
              >
                <div>
                  <div>Total Dr: {formatCurrency(totalDebit)}</div>
                  <div>Total Cr: {formatCurrency(totalCredit)}</div>
                </div>
                <div className="text-right">
                  {isDoubleEntryBalanced ? (
                    <div className="flex items-center gap-1 font-bold text-emerald-600">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Balanced!</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 font-bold text-amber-600">
                      <AlertCircle className="w-4 h-4" />
                      <span>Diff: {formatCurrency(Math.abs(totalDebit - totalCredit))}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Narration */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                Narration (Note / Description)
              </label>
              <button
                type="button"
                onClick={() => {
                  triggerHaptic('light');
                  setNarration(
                    isInvoiceMode
                      ? `Being goods supplied to ${selectedParty?.name || 'Party'} on credit terms.`
                      : `Being amount adjusted/transferred as per banking records.`
                  );
                }}
                className="text-[10px] text-emerald-600 dark:text-emerald-400 hover:underline"
              >
                Auto-generate
              </button>
            </div>
            <textarea
              rows={2}
              value={narration}
              onChange={(e) => setNarration(e.target.value)}
              placeholder="e.g. Being payment made against Bill #1042..."
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Footer Actions: Save button or Classic Tally Accept Modal */}
        <div className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 shrink-0">
          {!showAcceptPrompt ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 px-4 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 transition-colors"
              >
                Cancel (Esc)
              </button>
              <button
                type="button"
                onClick={handlePreSave}
                className="flex-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-600/20 active:scale-[0.98] transition-all touch-press flex items-center justify-center gap-1.5"
              >
                <span>Save Voucher (Ctrl+A)</span>
              </button>
            </div>
          ) : (
            /* Authentic Tally Accept Prompt */
            <div className="bg-emerald-950 text-white p-3 rounded-2xl border border-emerald-500 flex items-center justify-between animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-300 animate-pulse" />
                <div>
                  <div className="text-xs font-bold text-white">Accept?</div>
                  <div className="text-[10px] text-emerald-300">
                    Post voucher to Day Book & Ledgers
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 font-mono">
                <button
                  onClick={() => setShowAcceptPrompt(false)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-900 hover:bg-emerald-800 text-xs font-bold text-emerald-200 border border-emerald-700 touch-press"
                >
                  No (N)
                </button>
                <button
                  onClick={handleFinalAccept}
                  className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-xs font-extrabold text-slate-950 shadow-md touch-press"
                >
                  Yes (Y)
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
