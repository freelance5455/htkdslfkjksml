import React from 'react';
import { useTheme } from '../context/ThemeContext';

interface AndroidFrameProps {
  children: React.ReactNode;
  activeViewMode?: 'phone' | 'desktop' | 'code';
  onViewModeChange?: (mode: 'phone' | 'desktop' | 'code') => void;
  title?: string;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children }) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <div
      className={`min-h-screen w-full flex flex-col transition-colors duration-200 ${
        isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'
      }`}
    >
      <div
        className={`w-full max-w-4xl mx-auto flex-1 flex flex-col shadow-xl border-x transition-colors duration-200 min-h-screen ${
          isDark
            ? 'bg-slate-950 border-slate-800/80 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {children}
      </div>
    </div>
  );
};
