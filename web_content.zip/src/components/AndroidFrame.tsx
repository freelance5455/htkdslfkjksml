import React from 'react';
import { Smartphone, Monitor, Shield, Flame } from 'lucide-react';

interface AndroidFrameProps {
  children: React.ReactNode;
  isDeviceMode: boolean;
  onToggleDeviceMode: () => void;
  onQuickBurn: () => void;
  toastMessage: string | null;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  isDeviceMode,
  onToggleDeviceMode,
  onQuickBurn,
  toastMessage,
}) => {
  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col items-center justify-center relative font-sans overflow-hidden">
      {/* Background Ambient Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-950/20 via-slate-950 to-slate-950 pointer-events-none" />

      {/* Top Desktop Applet Toolbar */}
      <header className="w-full max-w-4xl px-4 py-2.5 flex items-center justify-between border-b border-slate-800/60 z-20 select-none">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-xl bg-emerald-950 border border-emerald-500/50 flex items-center justify-center text-emerald-400">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold tracking-tight text-white flex items-center gap-1.5">
              <span>Aegis Android Browser</span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/40">
                v4.8 Private
              </span>
            </span>
            <p className="text-[10px] text-slate-400 hidden sm:block">
              Isolated sandboxing • Zero telemetry • Ephemeral memory shredder
            </p>
          </div>
        </div>

        {/* View Switcher & Quick Burn */}
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleDeviceMode}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-slate-500 text-xs font-medium text-slate-300 flex items-center gap-1.5 transition-all shadow-sm"
            title="Toggle Android Device Frame / Fullscreen"
          >
            {isDeviceMode ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Fullscreen View</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Android Frame</span>
              </>
            )}
          </button>

          <button
            onClick={onQuickBurn}
            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-orange-950/60 hover:bg-orange-900/80 border border-orange-700/60 text-orange-400 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 shadow-sm"
            title="Instant Fire Data Burn"
          >
            <Flame className="w-4 h-4 fill-orange-500/20" />
            <span className="hidden sm:inline">Burn Data</span>
          </button>
        </div>
      </header>

      {/* Main Container Area */}
      <main className="flex-1 w-full flex items-center justify-center p-0 sm:p-4 z-10 overflow-hidden">
        {isDeviceMode ? (
          /* Android Phone Mockup Frame */
          <div className="relative w-full max-w-[420px] h-[92vh] max-h-[860px] bg-slate-950 rounded-[44px] border-[10px] border-slate-850 border-slate-900 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] ring-1 ring-slate-700/50 flex flex-col overflow-hidden">
            {/* Phone Top Speaker Grill Notch */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-1 rounded-full bg-slate-800 z-50 pointer-events-none" />

            {/* Inner Phone Screen Content */}
            <div className="flex-1 flex flex-col overflow-hidden relative">
              {children}
            </div>
          </div>
        ) : (
          /* Fullscreen Fluid View */
          <div className="w-full max-w-2xl h-[92vh] max-h-[860px] bg-slate-950 border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
            <div className="flex-1 flex flex-col overflow-hidden relative">
              {children}
            </div>
          </div>
        )}
      </main>

      {/* Android Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-14 z-50 px-4 py-2 rounded-2xl bg-slate-800/95 border border-slate-750 text-slate-100 text-xs font-semibold shadow-2xl backdrop-blur-md animate-bounce flex items-center gap-2">
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
