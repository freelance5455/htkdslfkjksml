import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Wifi, BatteryCharging, Volume2, VolumeX, ShieldCheck, Flame, Sparkles } from 'lucide-react';
import { useGame } from '../context/GameContext';
import { getLevelInfo } from '../data/rewards';
import { sound } from '../utils/sound';

interface AndroidFrameProps {
  children: React.ReactNode;
  activeScreen: string;
  onNavigate: (screen: string) => void;
  onOpenInstallModal: () => void;
  isPhoneFrame: boolean;
  onToggleFrame: () => void;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  activeScreen,
  onNavigate,
  onOpenInstallModal,
  isPhoneFrame,
  onToggleFrame,
}) => {
  const { state, isMuted, toggleMute } = useGame();
  const [currentTime, setCurrentTime] = useState('10:30');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const { currentLevel, progressPercent } = getLevelInfo(state.xp);

  const navItems = [
    { id: 'quest_map', label: 'Quest', emoji: '🗺️' },
    { id: 'quiz', label: 'Q&A Quiz', emoji: '🧠' },
    { id: 'blitz', label: 'Plate Blitz', emoji: '⚡' },
    { id: 'lab', label: 'Food Lab', emoji: '🍽️' },
    { id: 'codex', label: '5 Groups', emoji: '📖' },
    { id: 'shop', label: 'Rewards', emoji: '🏆' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start p-0 sm:p-4 select-none">
      {/* Top Desktop Controls Bar */}
      <header className="w-full max-w-4xl hidden sm:flex items-center justify-between py-2 px-4 mb-2 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <span className="font-bold text-slate-200">NutriQuest Android APK</span>
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[11px]">
            v1.2 Native PWA
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Phone Frame Toggle */}
          <button
            onClick={() => {
              sound.playTap();
              onToggleFrame();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition cursor-pointer"
          >
            {isPhoneFrame ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-cyan-400" />
                <span>Expand View</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Android Phone Frame</span>
              </>
            )}
          </button>

          {/* Install APK Modal Trigger */}
          <button
            onClick={() => {
              sound.playTap();
              onOpenInstallModal();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium transition cursor-pointer shadow-sm shadow-emerald-900/40"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Install APK</span>
          </button>
        </div>
      </header>

      {/* Main Container / Mobile Device Wrapper */}
      <div
        className={`w-full transition-all duration-300 relative flex flex-col ${
          isPhoneFrame
            ? 'max-w-[420px] h-[92vh] sm:h-[840px] max-h-[92vh] rounded-[44px] border-[8px] border-slate-800 bg-slate-900 shadow-2xl shadow-emerald-950/20 ring-1 ring-slate-700/50 overflow-hidden'
            : 'max-w-2xl min-h-[90vh] rounded-3xl sm:border border-slate-800 bg-slate-900 shadow-xl overflow-hidden'
        }`}
      >
        {/* Android Status Bar (Native look) */}
        <div className="w-full bg-slate-950/95 px-5 pt-3 pb-2 flex items-center justify-between text-[11px] font-semibold text-slate-400 border-b border-slate-800/60 z-20 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-slate-200 tracking-tight font-mono">{currentTime}</span>
            <div className="flex items-center gap-1 text-emerald-400">
              <span className="text-[10px] font-black tracking-widest">5G</span>
            </div>
          </div>

          {/* Android Punch-hole Camera */}
          {isPhoneFrame && (
            <div className="w-3.5 h-3.5 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-950/80 ring-1 ring-cyan-500/20" />
            </div>
          )}

          <div className="flex items-center gap-2">
            <Wifi className="w-3 h-3 text-slate-300" />
            <div className="flex items-center gap-1 text-slate-300">
              <span className="text-[10px]">92%</span>
              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
            </div>
          </div>
        </div>

        {/* NutriQuest App Header */}
        <div className="px-4 py-2.5 bg-slate-900/90 backdrop-blur-md border-b border-slate-800/80 flex items-center justify-between gap-2 shrink-0 z-10">
          {/* Level & XP */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white font-black font-display text-sm shadow-md shadow-emerald-900/30">
                {currentLevel.level}
              </div>
              <div className="absolute -bottom-1 -right-1 text-[10px] bg-slate-800 px-1 rounded-full border border-slate-700 text-amber-400 font-bold">
                Lv
              </div>
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white leading-tight">{currentLevel.title}</span>
                <span className="text-[10px] text-slate-400">{state.xp} XP</span>
              </div>
              <div className="w-24 sm:w-28 h-1.5 rounded-full bg-slate-800 mt-1 overflow-hidden border border-slate-700/50">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* Stats Badges: Gems, Streak, Audio & APK Install */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Streak */}
            <div
              className={`flex items-center gap-1 px-2 py-1 rounded-xl border text-xs font-bold transition ${
                state.streak > 0
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-400 animate-pulse-subtle'
                  : 'bg-slate-800/80 border-slate-700 text-slate-400'
              }`}
              title="Consecutive Correct Streak"
            >
              <Flame className={`w-3.5 h-3.5 ${state.streak > 0 ? 'text-amber-400 fill-amber-400' : ''}`} />
              <span>{state.streak}</span>
            </div>

            {/* Gems / Coins */}
            <div className="flex items-center gap-1 px-2 py-1 rounded-xl bg-purple-500/15 border border-purple-500/30 text-purple-300 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>{state.coins}</span>
            </div>

            {/* Audio Toggle */}
            <button
              onClick={() => {
                toggleMute();
              }}
              className="p-1.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
              title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
            </button>

            {/* Mobile install button */}
            <button
              onClick={() => {
                sound.playTap();
                onOpenInstallModal();
              }}
              className="p-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/30 transition cursor-pointer sm:hidden"
              title="Android APK Options"
            >
              <Smartphone className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Scrollable Screen Body */}
        <main className="flex-1 overflow-y-auto overscroll-contain p-3 sm:p-4 pb-20">
          {children}
        </main>

        {/* Bottom Android Navigation Bar */}
        <nav className="absolute bottom-0 inset-x-0 bg-slate-950/95 backdrop-blur-md border-t border-slate-800/80 px-2 pt-1.5 pb-2 flex items-center justify-around z-20">
          {navItems.map((item) => {
            const isActive = activeScreen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  sound.playTap();
                  onNavigate(item.id);
                }}
                className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition cursor-pointer relative ${
                  isActive ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span className="text-lg leading-none mb-0.5">{item.emoji}</span>
                <span className={`text-[10px] tracking-tight ${isActive ? 'font-black text-emerald-400' : 'font-medium'}`}>
                  {item.label}
                </span>
                {isActive && (
                  <span className="absolute -bottom-1 w-5 h-1 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/50" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Android Gesture Bar Pill (Bottom Home indicator) */}
        {isPhoneFrame && (
          <div className="w-full bg-slate-950 pb-1 flex justify-center items-center pointer-events-none">
            <div className="w-28 h-1 rounded-full bg-slate-600/60" />
          </div>
        )}
      </div>
    </div>
  );
};
