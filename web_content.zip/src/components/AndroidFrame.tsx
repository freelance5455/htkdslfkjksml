import React, { useState, useEffect } from 'react';
import { Wifi, Signal, Battery, Smartphone, Maximize2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AndroidFrame: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { deviceMode, setDeviceMode } = useApp();
  const [time, setTime] = useState('');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  if (deviceMode === 'expanded') {
    return <div className="min-h-screen bg-[#07090e] pb-20 md:pb-6">{children}</div>;
  }

  return (
    <div className="min-h-screen bg-[#040508] py-4 sm:py-8 px-2 flex flex-col items-center justify-center">
      {/* Device switch helper strip */}
      <div className="w-full max-w-[430px] flex items-center justify-between text-xs text-slate-400 px-3 mb-2">
        <div className="flex items-center gap-1.5 font-mono text-[11px] text-slate-400">
          <Smartphone className="w-3.5 h-3.5 text-red-500" />
          <span>Android APK Device View</span>
        </div>
        <button
          onClick={() => setDeviceMode('expanded')}
          className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white transition-colors"
        >
          <Maximize2 className="w-3 h-3 text-blue-400" />
          <span>Expand to Desktop</span>
        </button>
      </div>

      {/* Flagship Android Smartphone Bezel */}
      <div className="relative w-full max-w-[420px] h-[880px] bg-[#0b0e14] rounded-[48px] p-3 shadow-2xl border-[6px] border-[#1e2532] shadow-red-950/20 ring-1 ring-slate-800 flex flex-col overflow-hidden">
        {/* Antenna / Frame details */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-28 h-4 bg-[#141923] rounded-b-xl z-50 flex items-center justify-center">
          <div className="w-12 h-1 bg-slate-700 rounded-full" />
        </div>

        {/* Inner Screen */}
        <div className="relative w-full h-full bg-[#080a0f] rounded-[40px] flex flex-col overflow-hidden">
          {/* Android Status Bar */}
          <div className="w-full h-8 px-6 pt-1 flex items-center justify-between text-[11px] font-mono text-slate-300 select-none z-50 bg-[#090b10] border-b border-slate-900/60 shrink-0">
            <span className="font-semibold text-slate-200">{time || '19:10'}</span>

            {/* Front Camera Punch-hole */}
            <div className="w-3.5 h-3.5 rounded-full bg-[#050608] ring-2 ring-[#121620] mx-auto shrink-0" />

            <div className="flex items-center gap-1.5 text-slate-400">
              <Signal className="w-3 h-3 text-slate-300" />
              <Wifi className="w-3 h-3 text-slate-300" />
              <span className="text-[10px] text-slate-400 font-mono">5G</span>
              <Battery className="w-3.5 h-3.5 text-emerald-400" />
            </div>
          </div>

          {/* Applet Scrollable Body */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden relative scrollbar-none pb-16">
            {children}
          </div>

          {/* Android Home Navigation Gesture Bar */}
          <div className="absolute bottom-1 left-0 right-0 h-4 flex items-center justify-center pointer-events-none z-50">
            <div className="w-32 h-1 bg-slate-600/60 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};
