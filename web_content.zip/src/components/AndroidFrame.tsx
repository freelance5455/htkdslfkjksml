import React from 'react';
import { Wifi, Battery, Signal } from 'lucide-react';

interface AndroidFrameProps {
  children: React.ReactNode;
  isPhoneFrame: boolean;
  onToggleFrame: () => void;
  title?: string;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  isPhoneFrame,
  onToggleFrame,
  title = 'APK Analyzer & Recompiler'
}) => {
  // Current local time
  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  if (!isPhoneFrame) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
        {/* Top Desktop Bar */}
        <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur sticky top-0 z-50 px-4 py-3">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <svg className="w-6 h-6 text-slate-950 fill-current" viewBox="0 0 24 24">
                  <path d="M17.523 15.3414c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.551 0 .9993.4482.9993.9993s-.4483.9997-.9993.9997m-11.046 0c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.5511 0 .9994.4482.9994.9993s-.4483.9997-.9994.9997m11.4045-6.02l1.996-3.4572c.1054-.1824.043-.4166-.1395-.522-.182-.1054-.416-.043-.5214.1394l-2.024 3.506c-1.547-.706-3.292-1.1-5.1926-1.1-1.9006 0-3.6455.394-5.1925 1.1l-2.024-3.506c-.1054-.1824-.3394-.2448-.5214-.1394-.1825.1054-.2449.3396-.1395.522l1.996 3.4572C3.3615 10.9855 1.5 14.2818 1.5 18h21c0-3.7182-1.8615-7.0145-4.6185-8.6786" />
                </svg>
              </div>
              <div>
                <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
                  <span>Android Resource Modifier</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-mono">
                    APK & XAPK v3.2
                  </span>
                </h1>
                <p className="text-xs text-slate-400">
                  Game Currency Scanner • Precision Patcher • Digital Signer
                </p>
              </div>
            </div>

            <button
              onClick={onToggleFrame}
              className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 border border-slate-700 flex items-center gap-2 transition"
              title="Switch to Mobile Android Frame"
            >
              <span>📱</span>
              <span>View in Android Phone Frame</span>
            </button>
          </div>
        </header>

        {/* Desktop Container */}
        <main className="flex-1 max-w-5xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col justify-center">
          {children}
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-2 sm:p-6">
      {/* View Switcher Banner */}
      <div className="mb-4 flex items-center justify-between w-full max-w-[440px] px-2 text-xs text-slate-400">
        <span className="flex items-center gap-1.5 font-medium text-slate-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          Simulating Android 15 Device
        </span>
        <button
          onClick={onToggleFrame}
          className="text-xs font-medium text-emerald-400 hover:text-emerald-300 underline underline-offset-4 transition"
        >
          Expand to Desktop Mode ↗
        </button>
      </div>

      {/* Realistic Android Phone Chassis */}
      <div className="w-full max-w-[430px] bg-slate-900 border-[7px] border-slate-700/80 rounded-[44px] shadow-2xl shadow-emerald-950/40 overflow-hidden flex flex-col relative h-[860px] max-h-[92vh]">
        {/* Speaker / Punchhole Camera Notch */}
        <div className="absolute top-0 left-0 right-0 h-8 flex items-center justify-center z-50 pointer-events-none">
          <div className="w-28 h-4 bg-slate-950 rounded-b-xl flex items-center justify-center">
            <div className="w-3.5 h-3.5 rounded-full bg-slate-900 border border-slate-800"></div>
          </div>
        </div>

        {/* Android Status Bar */}
        <div className="h-9 bg-slate-900/95 backdrop-blur px-6 flex items-center justify-between text-[11px] text-slate-300 font-medium select-none z-40 border-b border-slate-800/40">
          <span>{currentTime}</span>
          <div className="flex items-center gap-2">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <Battery className="w-4 h-4 text-emerald-400" />
          </div>
        </div>

        {/* Android App Bar */}
        <div className="bg-slate-900 px-4 py-2.5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M17.523 15.3414c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.551 0 .9993.4482.9993.9993s-.4483.9997-.9993.9997m-11.046 0c-.5511 0-.9993-.4486-.9993-.9997s.4482-.9993.9993-.9993c.5511 0 .9994.4482.9994.9993s-.4483.9997-.9994.9997m11.4045-6.02l1.996-3.4572c.1054-.1824.043-.4166-.1395-.522-.182-.1054-.416-.043-.5214.1394l-2.024 3.506c-1.547-.706-3.292-1.1-5.1926-1.1-1.9006 0-3.6455.394-5.1925 1.1l-2.024-3.506c-.1054-.1824-.3394-.2448-.5214-.1394-.1825.1054-.2449.3396-.1395.522l1.996 3.4572C3.3615 10.9855 1.5 14.2818 1.5 18h21c0-3.7182-1.8615-7.0145-4.6185-8.6786" />
              </svg>
            </div>
            <div>
              <h1 className="text-sm font-bold text-white tracking-tight">{title}</h1>
              <p className="text-[10px] text-slate-400 leading-none">Android Mod & Signer</p>
            </div>
          </div>
          <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded">
            ARM64
          </span>
        </div>

        {/* Scrollable Screen Content */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-950 flex flex-col">
          {children}
        </div>

        {/* Android Navigation Gesture Bar */}
        <div className="h-5 bg-slate-950 flex items-center justify-center select-none">
          <div className="w-32 h-1 bg-slate-600 rounded-full opacity-60"></div>
        </div>
      </div>
    </div>
  );
};
