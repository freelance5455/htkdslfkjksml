/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AndroidStatusBar } from './AndroidStatusBar';
import { PWAInstallButton } from './PWAInstallButton';
import { AndroidApkModal } from './AndroidApkModal';
import { Smartphone, Monitor, Wifi, Download, Bot } from 'lucide-react';

interface AndroidFrameProps {
  children: React.ReactNode;
  activeTabTitle: string;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children, activeTabTitle }) => {
  const [isPhoneFrameMode, setIsPhoneFrameMode] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start p-0 sm:p-4 selection:bg-cyan-500/30">
      {/* Top Desktop Helper Bar (visible on sm+ screens) */}
      <div className="w-full max-w-5xl hidden sm:flex items-center justify-between py-2 px-3 mb-2 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span className="font-semibold text-white">NetPulse Mobile</span>
          <span>·</span>
          <span>Android Network Monitor & Router Controller</span>
        </div>

        <div className="flex items-center gap-2">
          {/* APK Install button */}
          <button
            onClick={() => setIsApkModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/90 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm transition active:scale-95"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Install APK on Phone</span>
          </button>

          {/* Toggle between Phone Simulation Frame and Adaptive Wide View */}
          <button
            onClick={() => setIsPhoneFrameMode(!isPhoneFrameMode)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition"
            title="Toggle Android Device Frame"
          >
            {isPhoneFrameMode ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-cyan-400" />
                <span>Expand View</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                <span>Phone Frame</span>
              </>
            )}
          </button>

          <PWAInstallButton />
        </div>
      </div>

      {/* Main Container: Mobile Phone Frame or Wide Adaptive Container */}
      <div
        className={`w-full transition-all duration-300 relative ${
          isPhoneFrameMode
            ? 'max-w-[420px] rounded-[42px] border-[10px] border-slate-800/95 shadow-2xl bg-[#080c14] overflow-hidden my-4 ring-1 ring-slate-700/50'
            : 'max-w-2xl sm:rounded-3xl sm:border sm:border-slate-800/90 bg-[#080c14] shadow-2xl min-h-screen sm:min-h-[92vh] flex flex-col'
        }`}
      >
        {/* Android Status Bar */}
        <AndroidStatusBar />

        {/* Mobile App Header Bar */}
        <header className="sticky top-0 z-30 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/60 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-md flex items-center justify-center">
              <Wifi className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-extrabold text-white tracking-tight leading-none">
                NetPulse
              </h1>
              <span className="text-[10px] text-cyan-400 font-medium">
                {activeTabTitle}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Direct APK Install Button in Mobile Header */}
            <button
              onClick={() => setIsApkModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600/20 border border-emerald-500/40 hover:bg-emerald-600/30 text-emerald-300 text-xs font-semibold transition active:scale-95"
            >
              <Download className="w-3 h-3 text-emerald-400" />
              <span>Get APK</span>
            </button>

            <div className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span className="hidden xs:inline">QoS Online</span>
            </div>
          </div>
        </header>

        {/* Scrollable Content View */}
        <main className="flex-1 px-3 sm:px-4 pt-2 overflow-y-auto">
          {children}
        </main>
      </div>

      {/* APK & Mobile Installation Modal */}
      <AndroidApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </div>
  );
};
