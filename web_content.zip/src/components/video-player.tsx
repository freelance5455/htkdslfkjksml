import { X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

type YTPlayer = {
  destroy: () => void;
  playVideo: () => void;
  setPlaybackQuality?: (q: string) => void;
  setPlaybackQualityRange?: (min: string, max: string) => void;
};

declare global {
  interface Window {
    YT?: {
      Player: new (
        el: HTMLElement | string,
        opts: {
          videoId: string;
          width?: string | number;
          height?: string | number;
          playerVars?: Record<string, string | number>;
          events?: {
            onReady?: (e: { target: YTPlayer }) => void;
            onStateChange?: (e: { data: number; target: YTPlayer }) => void;
          };
        },
      ) => YTPlayer;
    };
    onYouTubeIframeAPIReady?: () => void;
  }
}

function loadApi(): Promise<NonNullable<Window["YT"]>> {
  if (window.YT?.Player) return Promise.resolve(window.YT);
  return new Promise((resolve, reject) => {
    const existing = document.querySelector('script[src*="youtube.com/iframe_api"]');
    const done = () => {
      if (window.YT?.Player) resolve(window.YT);
      else reject(new Error("player"));
    };
    window.onYouTubeIframeAPIReady = done;
    if (!existing) {
      const tag = document.createElement("script");
      tag.src = "https://www.youtube.com/iframe_api";
      tag.async = true;
      tag.onerror = () => reject(new Error("script"));
      document.head.appendChild(tag);
    }
    const t = window.setInterval(() => {
      if (window.YT?.Player) {
        window.clearInterval(t);
        done();
      }
    }, 80);
    window.setTimeout(() => {
      window.clearInterval(t);
      if (!window.YT?.Player) reject(new Error("timeout"));
    }, 8000);
  });
}

function forceQuality(player: YTPlayer) {
  try {
    player.setPlaybackQualityRange?.("hd2160", "highres");
  } catch {
    /* older players */
  }
  try {
    player.setPlaybackQuality?.("highres");
  } catch {
    /* ignore */
  }
  try {
    player.setPlaybackQuality?.("hd2160");
  } catch {
    /* ignore */
  }
}

export function VideoPlayer({
  videoId,
  title,
  onClose,
}: {
  videoId: string;
  title?: string;
  onClose: () => void;
}) {
  const host = useRef<HTMLDivElement>(null);
  const player = useRef<YTPlayer | null>(null);
  const [fallback, setFallback] = useState(false);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);

    let cancelled = false;
    void (async () => {
      try {
        const YT = await loadApi();
        if (cancelled || !host.current) return;
        player.current = new YT.Player(host.current, {
          videoId,
          width: "100%",
          height: "100%",
          playerVars: {
            autoplay: 1,
            rel: 0,
            modestbranding: 1,
            playsinline: 0,
            fs: 1,
            hd: 1,
            vq: "hd2160",
            controls: 1,
          },
          events: {
            onReady: (e) => {
              forceQuality(e.target);
              try {
                e.target.playVideo();
              } catch {
                /* autoplay may be blocked */
              }
            },
            onStateChange: (e) => {
              if (e.data === 1) forceQuality(e.target);
            },
          },
        });
      } catch {
        if (!cancelled) setFallback(true);
      }
    })();

    return () => {
      cancelled = true;
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
      try {
        player.current?.destroy();
      } catch {
        /* already gone */
      }
      player.current = null;
    };
  }, [onClose, videoId]);

  const enterFs = () => {
    const root = document.getElementById("in-app-video");
    if (!root) return;
    const anyRoot = root as HTMLElement & { webkitRequestFullscreen?: () => void };
    try {
      if (root.requestFullscreen) void root.requestFullscreen();
      else anyRoot.webkitRequestFullscreen?.();
    } catch {
      /* ignore */
    }
  };

  const src = `https://www.youtube.com/embed/${encodeURIComponent(videoId)}?autoplay=1&rel=0&modestbranding=1&playsinline=0&fs=1&vq=hd2160&hd=1`;

  const node = (
    <div
      id="in-app-video"
      className="fixed inset-0 z-[80] flex flex-col"
      style={{ background: "#000000" }}
    >
      <div className="flex items-center justify-between gap-3 px-3 py-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <p className="min-w-0 flex-1 truncate text-sm font-medium">{title || "Video"}</p>
        <button
          type="button"
          className="h-11 shrink-0 rounded-full bg-secondary px-4 text-sm font-medium"
          onClick={enterFs}
        >
          Full screen
        </button>
        <button
          type="button"
          onClick={onClose}
          className="flex size-11 shrink-0 items-center justify-center rounded-full bg-secondary"
          aria-label="Close"
        >
          <X className="size-5" />
        </button>
      </div>
      <div className="relative min-h-0 flex-1" style={{ background: "#000000" }}>
        {fallback ? (
          <iframe
            title={title || "Video"}
            className="absolute inset-0 size-full border-0"
            src={src}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
            allowFullScreen
          />
        ) : (
          <div ref={host} className="absolute inset-0 size-full" />
        )}
      </div>
    </div>
  );

  if (typeof document === "undefined") return null;
  return createPortal(node, document.body);
}
