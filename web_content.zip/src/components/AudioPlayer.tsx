import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Repeat,
  Volume2,
  VolumeX,
  Download,
  CheckCircle2,
  Sparkles,
  FileAudio,
  Copy,
  Check,
} from 'lucide-react';
import { TTSGenerateResult } from '../types/tts';
import { base64ToInt16Array } from '../audio/audioProcessor';
import { encodePcmToWav } from '../audio/mp3Encoder';

interface AudioPlayerProps {
  result: TTSGenerateResult | null;
  isLoading: boolean;
  onRegenerate?: () => void;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ result, isLoading, onRegenerate }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isLooping, setIsLooping] = useState(false);
  const [copiedText, setCopiedText] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<'mp3' | 'wav' | null>(null);

  // Sync audio source when result changes
  useEffect(() => {
    if (result?.audioUrl && audioRef.current) {
      audioRef.current.src = result.audioUrl;
      audioRef.current.playbackRate = playbackRate;
      audioRef.current.loop = isLooping;
      setCurrentTime(0);
      setIsPlaying(false);
    }
  }, [result?.audioUrl]);

  const toggleLoop = () => {
    const next = !isLooping;
    setIsLooping(next);
    if (audioRef.current) {
      audioRef.current.loop = next;
    }
  };

  const skipSeconds = (sec: number) => {
    if (!audioRef.current) return;
    const target = Math.max(0, Math.min(activeDuration, audioRef.current.currentTime + sec));
    audioRef.current.currentTime = target;
    setCurrentTime(target);
  };

  const handleCopyProcessedText = () => {
    if (!result?.processedText) return;
    navigator.clipboard.writeText(result.processedText);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2500);
  };

  const togglePlayPause = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch((e) => console.log('Audio play error:', e));
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      if (!duration || isNaN(duration)) {
        setDuration(audioRef.current.duration || result?.durationSec || 0);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      const d = audioRef.current.duration;
      setDuration(isNaN(d) || !isFinite(d) ? result?.durationSec || 0 : d);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const handleRestart = () => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      setCurrentTime(0);
      audioRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    if (audioRef.current) {
      audioRef.current.volume = newVol;
    }
    if (newVol > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    if (isMuted) {
      audioRef.current.volume = volume || 1;
      setIsMuted(false);
    } else {
      audioRef.current.volume = 0;
      setIsMuted(true);
    }
  };

  const handlePlaybackRateChange = (rate: number) => {
    setPlaybackRate(rate);
    if (audioRef.current) {
      audioRef.current.playbackRate = rate;
    }
  };

  // Actual MP3 Download
  const handleDownloadMp3 = () => {
    if (!result) return;
    const a = document.createElement('a');
    a.href = result.audioUrl;
    // Format: YiuVoice_Telugu_YYYY-MM-DD_HH-MM.mp3
    a.download = result.filename.replace(/\.[^/.]+$/, '') + '.mp3';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    setDownloadSuccess('mp3');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  // Actual WAV Download (creates/downloads authentic WAV)
  const handleDownloadWav = () => {
    if (!result) return;
    let wavUrl = result.audioUrl;

    // If result was MP3, convert/wrap or download as wav
    if (result.format === 'wav') {
      wavUrl = result.audioUrl;
    } else if (result.audioBase64) {
      try {
        const pcmSamples = base64ToInt16Array(result.audioBase64);
        const wavBytes = encodePcmToWav(pcmSamples, 24000, 1);
        const blob = new Blob([wavBytes], { type: 'audio/wav' });
        wavUrl = URL.createObjectURL(blob);
      } catch {
        wavUrl = result.audioUrl;
      }
    }

    const a = document.createElement('a');
    a.href = wavUrl;
    a.download = result.filename.replace(/\.[^/.]+$/, '') + '.wav';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    setDownloadSuccess('wav');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const formatTime = (secs: number) => {
    if (!secs || isNaN(secs)) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const activeDuration = duration > 0 ? duration : result?.durationSec || 0;
  const progressPercent = activeDuration > 0 ? (currentTime / activeDuration) * 100 : 0;

  if (isLoading) {
    return (
      <div className="w-full bg-[#101522] border border-cyan-500/30 rounded-2xl p-6 shadow-2xl shadow-cyan-950/40 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent animate-pulse" />
        <div className="flex flex-col items-center justify-center gap-3 relative z-10">
          <div className="w-12 h-12 rounded-full border-3 border-cyan-400 border-t-transparent animate-spin" />
          <div className="font-bold text-lg text-slate-100">
            Generating your Telugu voice…
          </div>
          <p className="text-xs text-cyan-300 font-telugu">
            మీ తెలుగు గళం రూపొందించబడుతోంది... దయచేసి వేచి ఉండండి.
          </p>
          <div className="flex items-center gap-1 mt-2">
            {[...Array(12)].map((_, i) => (
              <div
                key={i}
                className="w-1.5 bg-cyan-400 rounded-full animate-bounce"
                style={{
                  height: `${12 + (i % 4) * 8}px`,
                  animationDelay: `${i * 80}ms`,
                }}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!result) {
    return null;
  }

  return (
    <div
      id="yiuvoice-audio-player"
      className="w-full bg-[#101522] border border-cyan-500/40 rounded-2xl p-5 sm:p-6 shadow-2xl shadow-cyan-950/40 relative overflow-hidden"
    >
      <audio
        ref={audioRef}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={() => {
          setIsPlaying(false);
          setCurrentTime(0);
        }}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
      />

      {/* Header Banner: Your Telugu Voice Is Ready */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shadow-inner">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-extrabold text-slate-100 tracking-tight">
                Your Telugu Voice Is Ready
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase">
                {result.format.toUpperCase()}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-telugu mt-0.5">
              మీ తెలుగు ఆడియో విజయవంతంగా రూపొందించబడింది • నిడివి:{' '}
              <span className="font-mono text-cyan-300">{formatTime(activeDuration)}</span>
            </p>
          </div>
        </div>

        {/* Live Audio Visualizer Bars Animation */}
        <div className="flex items-end gap-1 h-8 px-3 py-1 bg-slate-900/80 rounded-xl border border-slate-800">
          {[16, 24, 12, 28, 20, 32, 14, 26, 18, 22].map((height, i) => (
            <div
              key={i}
              className={`w-1 rounded-full transition-all duration-150 ${
                isPlaying ? 'bg-cyan-400 animate-pulse' : 'bg-slate-700'
              }`}
              style={{
                height: isPlaying ? `${Math.max(4, (height * (i % 2 === 0 ? 1 : 0.8)))}px` : '4px',
              }}
            />
          ))}
        </div>
      </div>

      {/* Fallback Notice if Quota was Reached */}
      {result.fallbackNote && (
        <div className="mb-4 p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-200 text-xs flex items-center gap-2.5">
          <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
          <span className="leading-relaxed font-telugu">{result.fallbackNote}</span>
        </div>
      )}

      {/* Waveform / Progress Bar Scrubber */}
      <div className="mb-4">
        <div className="relative w-full h-3 bg-slate-900 rounded-full overflow-hidden cursor-pointer border border-slate-800">
          <div
            className="absolute top-0 left-0 bottom-0 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-75"
            style={{ width: `${progressPercent}%` }}
          />
          <input
            id="audio-progress-bar"
            type="range"
            min="0"
            max={activeDuration || 100}
            step="0.05"
            value={currentTime}
            onChange={handleSeek}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
        </div>

        {/* Time Stamp Indicators */}
        <div className="flex justify-between items-center text-xs font-mono text-slate-400 mt-1.5 px-0.5">
          <span id="audio-current-time" className="text-cyan-300 font-semibold">
            {formatTime(currentTime)}
          </span>
          <span id="audio-total-duration">
            {formatTime(activeDuration)}
          </span>
        </div>
      </div>

      {/* Main Playback Controls Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
        {/* Left: Play/Pause/Restart */}
        <div className="flex items-center gap-2.5">
          <button
            id="btn-play-pause"
            type="button"
            onClick={togglePlayPause}
            className="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 flex items-center justify-center shadow-lg shadow-cyan-500/25 transition-all cursor-pointer ring-2 ring-white/10"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-6 h-6 fill-current stroke-[2.5]" />
            ) : (
              <Play className="w-6 h-6 fill-current stroke-[2.5] ml-0.5" />
            )}
          </button>

          <button
            id="btn-restart-audio"
            type="button"
            onClick={handleRestart}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer"
            title="మొదటి నుండి వినండి (Restart)"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Skip -5s */}
          <button
            type="button"
            onClick={() => skipSeconds(-5)}
            className="px-2 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer text-[11px] font-mono font-medium flex items-center gap-0.5"
            title="5 సెకన్లు వెనక్కి (Skip -5s)"
          >
            <span>-5s</span>
          </button>

          {/* Skip +5s */}
          <button
            type="button"
            onClick={() => skipSeconds(5)}
            className="px-2 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer text-[11px] font-mono font-medium flex items-center gap-0.5"
            title="5 సెకన్లు ముందుకు (Skip +5s)"
          >
            <span>+5s</span>
          </button>

          {/* Loop Audio Button */}
          <button
            type="button"
            onClick={toggleLoop}
            className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
              isLooping
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-sm'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-400 border-slate-800'
            }`}
            title={isLooping ? 'లూప్ ఆన్ (Loop Active)' : 'లూప్ చేయండి (Repeat Audio)'}
          >
            <Repeat className="w-4 h-4" />
          </button>

          {/* Speed Selector Pills */}
          <div className="flex items-center bg-slate-900 rounded-xl p-1 border border-slate-800">
            {[0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => (
              <button
                key={rate}
                type="button"
                onClick={() => handlePlaybackRateChange(rate)}
                className={`px-2 py-1 rounded-lg text-xs font-mono font-medium transition-all cursor-pointer ${
                  playbackRate === rate
                    ? 'bg-slate-800 text-cyan-300 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {rate}x
              </button>
            ))}
          </div>
        </div>

        {/* Copy Processed Text button & Volume */}
        <div className="flex items-center gap-2">
          {result.processedText && (
            <button
              type="button"
              onClick={handleCopyProcessedText}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700 text-xs font-medium transition-all cursor-pointer"
              title="టెక్స్ట్ కాపీ చేయండి"
            >
              {copiedText ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">కాపీ అయ్యింది!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>స్క్రిప్ట్ కాపీ</span>
                </>
              )}
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={toggleMute}
            className="text-slate-400 hover:text-slate-200 cursor-pointer"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted || volume === 0 ? (
              <VolumeX className="w-4 h-4 text-red-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            )}
          </button>
          <input
            id="player-volume-slider"
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={isMuted ? 0 : volume}
            onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
            className="w-20 accent-emerald-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
        </div>

        {/* Right: Large Download Buttons (Requirement #10) */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          {/* Large MP3 Download Button */}
          <button
            id="btn-download-mp3"
            type="button"
            onClick={handleDownloadMp3}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 transition-all cursor-pointer ring-1 ring-white/20 active:scale-95"
            title="Download authentic encoded MP3 audio"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>⬇ Download MP3</span>
          </button>

          {/* WAV Download Button */}
          <button
            id="btn-download-wav"
            type="button"
            onClick={handleDownloadWav}
            className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-semibold text-xs border border-slate-800 hover:border-slate-700 transition-all cursor-pointer"
            title="Download uncompressed WAV format"
          >
            <FileAudio className="w-4 h-4 text-cyan-400" />
            <span>WAV</span>
          </button>
        </div>
      </div>

      {/* Download Success Confirmation Toast */}
      {downloadSuccess && (
        <div className="mt-3 p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              {downloadSuccess.toUpperCase()} ఆడియో ఫైల్ విజయవంతంగా డౌన్‌లోడ్ చేయబడింది:
              <strong className="ml-1 font-mono text-white">{result.filename}</strong>
            </span>
          </div>
          <span className="text-[10px] text-emerald-400/80 font-mono">100% Verified</span>
        </div>
      )}
    </div>
  );
};
