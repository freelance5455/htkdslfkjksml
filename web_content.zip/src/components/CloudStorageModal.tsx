import React, { useState, useRef } from 'react';
import { 
  X, 
  Cloud, 
  HardDrive, 
  Box, 
  Check, 
  ExternalLink, 
  FolderCheck, 
  RefreshCw, 
  Download, 
  Clock, 
  Sparkles,
  Play,
  Pause,
  Trash2,
  FileAudio,
  CheckCircle2
} from 'lucide-react';
import { CloudAccount, CloudStorageProvider, CloudUploadRecord, ExportFormat } from '../types/tts';
import { getCachedCloudBlob } from '../utils/cloudStorage';

interface CloudStorageModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: CloudAccount[];
  uploads: CloudUploadRecord[];
  onToggleConnect: (provider: CloudStorageProvider, connected: boolean, email?: string) => void;
  onSaveVoiceToCloud?: (provider: CloudStorageProvider, format: ExportFormat) => void;
  isSavingToCloud?: boolean;
  currentText?: string;
  languageName?: string;
  personaName?: string;
  onDeleteUpload?: (id: string) => void;
  onUploadTestFile?: (provider: CloudStorageProvider) => void;
}

export const CloudStorageModal: React.FC<CloudStorageModalProps> = ({
  isOpen,
  onClose,
  accounts,
  uploads,
  onToggleConnect,
  onSaveVoiceToCloud,
  isSavingToCloud = false,
  currentText,
  languageName,
  personaName,
  onDeleteUpload,
  onUploadTestFile,
}) => {
  const [connectingProvider, setConnectingProvider] = useState<CloudStorageProvider | null>(null);
  const [playingUploadId, setPlayingUploadId] = useState<string | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  if (!isOpen) return null;

  const handleConnect = (provider: CloudStorageProvider, currentConnected: boolean) => {
    setConnectingProvider(provider);
    setTimeout(() => {
      onToggleConnect(provider, !currentConnected);
      setConnectingProvider(null);
    }, 600);
  };

  const getProviderIcon = (provider: CloudStorageProvider) => {
    switch (provider) {
      case 'google-drive':
        return <HardDrive className="w-5 h-5 text-emerald-500" />;
      case 'dropbox':
        return <Box className="w-5 h-5 text-blue-500" />;
      case 'onedrive':
        return <Cloud className="w-5 h-5 text-sky-500" />;
    }
  };

  const getProviderBrandName = (provider: CloudStorageProvider) => {
    switch (provider) {
      case 'google-drive':
        return 'Google Drive';
      case 'dropbox':
        return 'Dropbox';
      case 'onedrive':
        return 'Microsoft OneDrive';
    }
  };

  const handlePlayUpload = (upload: CloudUploadRecord) => {
    if (playingUploadId === upload.id) {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      setPlayingUploadId(null);
      return;
    }

    const audioSource = upload.audioBlobUrl || upload.fileUrl;
    if (!audioSource) return;

    if (!audioPlayerRef.current) {
      audioPlayerRef.current = new Audio();
      audioPlayerRef.current.onended = () => setPlayingUploadId(null);
      audioPlayerRef.current.onerror = () => setPlayingUploadId(null);
    }

    audioPlayerRef.current.src = audioSource;
    audioPlayerRef.current.play().then(() => {
      setPlayingUploadId(upload.id);
    }).catch((e) => {
      console.warn('Could not play audio', e);
      setPlayingUploadId(null);
    });
  };

  const handleDownloadFile = (upload: CloudUploadRecord) => {
    const cachedBlob = getCachedCloudBlob(upload.id);
    if (cachedBlob) {
      const url = URL.createObjectURL(cachedBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = upload.fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } else if (upload.fileUrl) {
      const a = document.createElement('a');
      a.href = upload.fileUrl;
      a.download = upload.fileName;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  const handleSaveCurrent = (provider: CloudStorageProvider, format: ExportFormat = 'mp3') => {
    if (onSaveVoiceToCloud) {
      onSaveVoiceToCloud(provider, format);
    } else if (onUploadTestFile) {
      onUploadTestFile(provider);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-md animate-in fade-in overflow-y-auto">
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl relative space-y-5 animate-in zoom-in-95 my-auto max-h-[92vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-600/10 text-cyan-600 dark:text-cyan-400">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-zinc-900 dark:text-white flex items-center gap-2">
                <span>Cloud Storage Box</span>
                <span className="text-[10px] font-bold uppercase bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <HardDrive className="w-3 h-3 text-emerald-500" /> Google Drive Sync
                </span>
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Directly save and sync synthesized voices to Google Drive &amp; Cloud storage
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if (audioPlayerRef.current) {
                audioPlayerRef.current.pause();
              }
              setPlayingUploadId(null);
              onClose();
            }}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
            title="Close Cloud Storage Box"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section 1: Save Current Studio Voice to Google Drive */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-cyan-500/10 to-violet-500/10 border border-emerald-500/20 dark:border-emerald-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-base">🎙️</span>
              <div>
                <h4 className="text-xs font-bold text-zinc-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  Save Active Studio Voice
                </h4>
                <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                  {personaName || 'Selected Voice'} · {languageName || 'Speech'}
                </p>
              </div>
            </div>

            {currentText && (
              <span className="text-[10px] font-mono text-zinc-400 bg-white/70 dark:bg-zinc-800/70 px-2 py-0.5 rounded-md border border-zinc-200/50 dark:border-zinc-700/50 truncate max-w-[150px]">
                &quot;{currentText}&quot;
              </span>
            )}
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <button
              onClick={() => handleSaveCurrent('google-drive', 'mp3')}
              disabled={isSavingToCloud}
              className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm shadow-emerald-600/30 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSavingToCloud ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Saving to Google Drive...</span>
                </>
              ) : (
                <>
                  <HardDrive className="w-4 h-4" />
                  <span>Save to Google Drive (.MP3)</span>
                </>
              )}
            </button>

            <button
              onClick={() => handleSaveCurrent('google-drive', 'wav')}
              disabled={isSavingToCloud}
              className="w-full py-2.5 px-3 rounded-xl bg-white dark:bg-zinc-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              <HardDrive className="w-4 h-4 text-emerald-500" />
              <span>Save to Google Drive (.WAV Lossless)</span>
            </button>
          </div>

          <div className="flex items-center justify-between text-[11px] text-zinc-500 dark:text-zinc-400 px-1 pt-0.5">
            <span className="flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              Automatically downloads audio file &amp; syncs to your Drive account
            </span>
            <a
              href="https://drive.google.com/drive/my-drive"
              target="_blank"
              rel="noopener noreferrer"
              className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1"
            >
              <span>Open Google Drive</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Section 2: Cloud Storage Providers */}
        <div className="space-y-2.5">
          <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center justify-between">
            <span>Available Cloud Storage Providers</span>
            <span className="text-[10px] text-zinc-500 font-normal">Connect or sync folders</span>
          </h4>

          <div className="grid grid-cols-1 gap-2.5">
            {accounts.map((acc) => {
              const isConnecting = connectingProvider === acc.provider;
              const isGoogleDrive = acc.provider === 'google-drive';

              return (
                <div
                  key={acc.provider}
                  className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isGoogleDrive
                      ? 'border-emerald-500/40 bg-emerald-500/5 dark:bg-emerald-950/20'
                      : acc.connected
                      ? 'border-violet-500/40 bg-violet-500/5 dark:bg-violet-950/20'
                      : 'border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-950/40'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 shadow-xs shrink-0">
                      {getProviderIcon(acc.provider)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="text-sm font-bold text-zinc-900 dark:text-white">
                          {acc.name}
                        </h5>
                        <span className="text-[10px] font-bold text-emerald-600 bg-emerald-500/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Check className="w-3 h-3" /> Ready &amp; Connected
                        </span>
                      </div>
                      <div className="text-xs text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5 mt-0.5">
                        <FolderCheck className="w-3.5 h-3.5 text-zinc-400" />
                        <span>Target: <code className="font-mono text-[11px] text-zinc-700 dark:text-zinc-300">{acc.folderName}</code></span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                    {/* Quick Save Current Voice button */}
                    <button
                      onClick={() => handleSaveCurrent(acc.provider, 'mp3')}
                      disabled={isSavingToCloud}
                      className="px-2.5 py-1.5 text-xs font-bold rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 hover:border-violet-500 text-zinc-800 dark:text-zinc-200 transition-all flex items-center gap-1.5 cursor-pointer"
                      title={`Save current voice to ${acc.name}`}
                    >
                      <Download className="w-3.5 h-3.5 text-violet-500" />
                      <span>Save Voice</span>
                    </button>

                    {/* Open Provider Link */}
                    <a
                      href={
                        acc.provider === 'google-drive'
                          ? 'https://drive.google.com/drive/my-drive'
                          : acc.provider === 'dropbox'
                          ? 'https://www.dropbox.com/home'
                          : 'https://onedrive.live.com'
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1.5 text-xs font-semibold rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-all flex items-center gap-1"
                      title={`Open ${acc.name}`}
                    >
                      <span>Drive</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>

                    {/* Connect / Disconnect */}
                    <button
                      onClick={() => handleConnect(acc.provider, acc.connected)}
                      disabled={isConnecting}
                      className="px-2.5 py-1.5 text-xs font-semibold rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-all cursor-pointer"
                    >
                      {isConnecting ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <span>Synced</span>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Section 3: Recent Cloud Uploads History */}
        <div className="space-y-3 pt-2 border-t border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-zinc-400" />
              <span>Recent Cloud &amp; Drive Uploads ({uploads.length})</span>
            </h4>

            {uploads.length > 0 && (
              <span className="text-[10px] text-zinc-400">
                Tap Play to listen or Download
              </span>
            )}
          </div>

          {uploads.length === 0 ? (
            <div className="text-center py-6 px-4 text-xs text-zinc-400 bg-zinc-50 dark:bg-zinc-950/40 rounded-2xl border border-zinc-200 dark:border-zinc-800 space-y-2">
              <p>No files exported to drive storage yet.</p>
              <button
                onClick={() => handleSaveCurrent('google-drive', 'mp3')}
                disabled={isSavingToCloud}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <HardDrive className="w-3.5 h-3.5" />
                <span>Save Current Voice to Google Drive Now</span>
              </button>
            </div>
          ) : (
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {uploads.map((u) => {
                const isPlaying = playingUploadId === u.id;

                return (
                  <div
                    key={u.id}
                    className="p-3 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50/70 dark:bg-zinc-950/60 flex items-center justify-between gap-2.5 text-xs transition-all hover:border-violet-500/30"
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      {/* Play / Pause button */}
                      <button
                        onClick={() => handlePlayUpload(u)}
                        className={`p-2 rounded-xl transition-all cursor-pointer shrink-0 ${
                          isPlaying
                            ? 'bg-violet-600 text-white shadow-xs'
                            : 'bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 hover:bg-violet-50 dark:hover:bg-violet-950/40'
                        }`}
                        title={isPlaying ? 'Pause Audio' : 'Play Audio'}
                      >
                        {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                      </button>

                      <div className="truncate">
                        <div className="font-bold text-zinc-800 dark:text-zinc-200 truncate flex items-center gap-1.5">
                          <span>{u.fileName}</span>
                          <span className="text-[9px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-extrabold uppercase px-1.5 py-0.2 rounded">
                            {u.fileFormat}
                          </span>
                        </div>
                        <div className="text-[10px] text-zinc-400 flex items-center gap-1.5 mt-0.5">
                          <span>{u.fileSize}</span>
                          <span>·</span>
                          <span>{new Date(u.uploadedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          <span>·</span>
                          <span className="capitalize text-emerald-600 dark:text-emerald-400 font-semibold">
                            {u.provider === 'google-drive' ? 'Google Drive' : u.provider}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* Re-download button */}
                      <button
                        onClick={() => handleDownloadFile(u)}
                        className="p-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-emerald-600 hover:text-white transition-all cursor-pointer"
                        title="Download audio file"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>

                      {/* Open in Drive */}
                      <a
                        href={u.driveUrl || (u.provider === 'google-drive' ? 'https://drive.google.com/drive/my-drive' : u.fileUrl)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-violet-600 hover:text-white transition-all flex items-center gap-1"
                        title={`Open in ${getProviderBrandName(u.provider)}`}
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>

                      {/* Delete */}
                      {onDeleteUpload && (
                        <button
                          onClick={() => onDeleteUpload(u.id)}
                          className="p-1.5 rounded-lg text-zinc-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-all cursor-pointer"
                          title="Remove from history"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
