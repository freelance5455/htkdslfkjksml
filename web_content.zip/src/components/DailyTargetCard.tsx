import React from 'react';
import { Zap, Flame } from 'lucide-react';

interface DailyTargetCardProps {
  language: string;
  completedCount: number;
  dailyTargetCount: number;
  progressPercent: number;
  onStartQuestions: (filter: string) => void;
}

export default function DailyTargetCard({
  language,
  completedCount,
  dailyTargetCount,
  progressPercent,
  onStartQuestions
}: DailyTargetCardProps) {
  const isBn = language === 'bn';

  return (
    <div 
      id="daily-target-highlight-card"
      className="relative overflow-hidden rounded-2xl sm:rounded-[20px] bg-[#0c1022] border border-[#272152] p-3 sm:p-3.5 shadow-xl transition-all duration-300"
    >
      {/* Background ambient glow */}
      <div className="absolute top-0 right-1/4 w-48 h-24 bg-[#8b5cf6]/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-32 h-16 bg-[#6366f1]/10 rounded-full blur-xl pointer-events-none" />

      <div className="relative z-10 flex flex-row items-center gap-3 sm:gap-4">
        {/* Left 3D Target Graphic */}
        <div className="relative shrink-0 flex items-center justify-center">
          <div className="w-12 h-12 sm:w-14 sm:h-14 flex items-center justify-center">
            <svg 
              viewBox="0 0 120 120" 
              className="w-full h-full drop-shadow-[0_4px_12px_rgba(168,85,247,0.4)]"
            >
              <defs>
                {/* Petals / Foliage Gradient */}
                <linearGradient id="leafGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#10b981" />
                  <stop offset="100%" stopColor="#047857" />
                </linearGradient>
                <linearGradient id="purplePetal" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#7c3aed" />
                  <stop offset="100%" stopColor="#4c1d95" />
                </linearGradient>
                <linearGradient id="magentaRing" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ec4899" />
                  <stop offset="100%" stopColor="#be185d" />
                </linearGradient>
                <radialGradient id="targetCenter" cx="38%" cy="38%" r="62%">
                  <stop offset="0%" stopColor="#f43f5e" />
                  <stop offset="70%" stopColor="#e11d48" />
                  <stop offset="100%" stopColor="#881337" />
                </radialGradient>
                <linearGradient id="dartShaft" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#fde047" />
                  <stop offset="100%" stopColor="#eab308" />
                </linearGradient>
              </defs>

              {/* Decorative Green leaves around target */}
              <path d="M22,95 C15,85 18,70 30,75 C24,88 20,92 22,95 Z" fill="url(#leafGrad)" />
              <path d="M30,105 C20,100 22,86 35,88 C30,99 28,103 30,105 Z" fill="#34d399" />
              <path d="M98,90 C106,82 102,68 90,72 C96,84 96,88 98,90 Z" fill="url(#leafGrad)" />

              {/* Isometric 3D Layer Base Outer Shadow */}
              <ellipse cx="60" cy="65" rx="46" ry="46" fill="#1e1338" />

              {/* Outer Deep Purple Fluted Flower Ring */}
              <circle cx="60" cy="60" r="44" fill="url(#purplePetal)" stroke="#a855f7" strokeWidth="2.5" />

              {/* Magenta / Pink Ring */}
              <circle cx="60" cy="60" r="35" fill="url(#magentaRing)" stroke="#f472b6" strokeWidth="1" />

              {/* White Ring */}
              <circle cx="60" cy="60" r="26" fill="#ffffff" />

              {/* Inner Magenta Ring */}
              <circle cx="60" cy="60" r="18" fill="url(#magentaRing)" />

              {/* Center Bullseye */}
              <circle cx="60" cy="60" r="10" fill="url(#targetCenter)" stroke="#ffe4e6" strokeWidth="1" />
              <circle cx="57" cy="57" r="2.5" fill="#ffffff" opacity="0.8" />

              {/* Dart with Golden Shaft, Gold Tip & Blue/Yellow Flights */}
              <g transform="rotate(42 60 60)">
                {/* Shaft */}
                <line x1="60" y1="18" x2="60" y2="58" stroke="url(#dartShaft)" strokeWidth="4" strokeLinecap="round" />
                {/* Arrow head / point in bullseye */}
                <polygon points="60,62 55,52 65,52" fill="#eab308" stroke="#ca8a04" strokeWidth="0.5" />
                {/* Flights / Feathers */}
                <path d="M52,14 L60,24 L68,14 Z" fill="#f43f5e" />
                <path d="M56,18 L60,25 L64,18 Z" fill="#fbbf24" />
              </g>
            </svg>
          </div>
        </div>

        {/* Middle & Right Content */}
        <div className="flex-1 w-full space-y-1.5 min-w-0">
          {/* Top Row: Title + Progress Numbers */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-white font-bold text-xs sm:text-sm tracking-tight truncate">
              <span className="text-sm">🔥</span>
              <span className="truncate">{isBn ? 'আজকের দৈনিক টার্গেট' : "Today's Daily Target"}</span>
            </div>

            <div className="text-right shrink-0">
              <span className="text-sm sm:text-base font-black text-[#a5b4fc] font-mono tracking-tight">
                {completedCount}/{dailyTargetCount}
              </span>
            </div>
          </div>

          {/* Smooth Progress Bar */}
          <div className="w-full bg-[#131b34] rounded-full h-1.5 sm:h-2 p-0.5 overflow-hidden">
            <div 
              className="bg-gradient-to-r from-[#06b6d4] to-[#22d3ee] h-full rounded-full transition-all duration-700 shadow-sm"
              style={{ width: `${Math.min(Math.max(progressPercent, 0), 100)}%` }}
            />
          </div>

          {/* Glowing Green Action Button */}
          <button
            type="button"
            onClick={() => onStartQuestions('ALL')}
            className="w-full py-1.5 sm:py-2 bg-gradient-to-r from-[#10b981] via-[#14b8a6] to-[#059669] hover:from-[#34d399] hover:via-[#2dd4bf] hover:to-[#10b981] text-white font-bold text-xs sm:text-sm rounded-xl shadow-md shadow-emerald-950/50 flex items-center justify-center gap-1.5 cursor-pointer transition-all duration-200 active:scale-[0.99] tracking-wide"
          >
            <span className="text-amber-300 font-bold text-sm">⚡</span>
            <span>{isBn ? 'প্রশ্ন সমাধান শুরু করুন' : "Start Solving Questions"}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
