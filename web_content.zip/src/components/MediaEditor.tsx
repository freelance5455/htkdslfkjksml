import React, { useState, useRef, useEffect } from "react";
import {
  Sliders,
  Scissors,
  Type,
  Film,
  Download,
  Upload,
  Play,
  Square,
  Check,
  RefreshCw,
  Mic,
  MicOff,
  Volume2,
  Trash2,
  Music,
  RotateCcw,
  Sparkles,
  Layers,
} from "lucide-react";
import { generateSampleCanvas } from "../utils/sampleImages";
import { AudioEngine } from "../utils/audioEngine";

interface MediaEditorProps {
  initialImageUrl?: string;
}

const SAMPLE_TEMPLATES = [
  { id: "kolkata", name: "কলকাতা সাইবার", desc: "Futuristic Kolkata cityscape" },
  { id: "himalaya", name: "হিমালয় ভোর", desc: "Golden sunrise peaks" },
  { id: "howrah", name: "ঐতিহাসিক হাওড়া", desc: "Heritage architecture" },
];

const FILTER_PRESETS = [
  { id: "none", label: "স্বাভাবিক (Normal)", css: "none" },
  { id: "cyberpunk", label: "সাইবারপাঙ্ক", css: "contrast(140%) saturate(180%) hue-rotate(190deg)" },
  { id: "golden", label: "গোল্ডেন আওয়ার", css: "sepia(45%) saturate(160%) brightness(105%) contrast(110%)" },
  { id: "noir", label: "কলকাতা নয়ার (B&W)", css: "grayscale(100%) contrast(160%) brightness(95%)" },
  { id: "retro", label: "রেট্রো ফিল্ম", css: "sepia(30%) contrast(120%) saturate(125%) brightness(100%)" },
  { id: "vivid", label: "উজ্জ্বল পপ (Vivid)", css: "saturate(210%) contrast(125%)" },
  { id: "emerald", label: "নিয়ন এমারেল্ড", css: "hue-rotate(90deg) saturate(180%) contrast(120%)" },
  { id: "drama", label: "সিনেমাটিক ড্রামা", css: "contrast(150%) brightness(90%) saturate(130%)" },
];

const BG_REPLACEMENT_OPTIONS = [
  { id: "checker", label: "স্বচ্ছ (Transparent)", color: "transparent" },
  { id: "dark", label: "ডিপ নাইট", color: "#0b0f19" },
  { id: "cyber", label: "নিয়ন সাইবার", gradient: "linear-gradient(135deg, #06b6d4, #3b82f6)" },
  { id: "sunset", label: "সানসেট গোল্ড", gradient: "linear-gradient(135deg, #f97316, #ec4899)" },
  { id: "studio", label: "স্টুডিও ব্ল্যাক", color: "#000000" },
];

export const MediaEditor: React.FC<MediaEditorProps> = ({ initialImageUrl }) => {
  // Safe initial image from local generator if not provided
  const [imageSrc, setImageSrc] = useState<string>(() => {
    return initialImageUrl || generateSampleCanvas("kolkata");
  });

  const [activeTab, setActiveTab] = useState<"filter" | "bgremove" | "caption" | "audio" | "reels">("filter");

  // Filter & manual adjustments
  const [activeFilterPreset, setActiveFilterPreset] = useState("none");
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [blurVal, setBlurVal] = useState(0);
  const [hueRotate, setHueRotate] = useState(0);

  // Background removal state
  const [bgRemoved, setBgRemoved] = useState(false);
  const [bgThreshold, setBgThreshold] = useState(25);
  const [bgReplacement, setBgReplacement] = useState("checker");

  // Caption state
  const [captionText, setCaptionText] = useState("আমার নতুন ভিডিও ক্রিয়েশন ✨");
  const [captionPosition, setCaptionPosition] = useState<"top" | "center" | "bottom">("bottom");
  const [captionColor, setCaptionColor] = useState("#ffffff");
  const [captionBg, setCaptionBg] = useState(true);
  const [watermark, setWatermark] = useState(true);

  // Voice & Audio state (আমার ভয়েস অ্যাড)
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [voiceRecordingSeconds, setVoiceRecordingSeconds] = useState(0);
  const [recordedVoiceUrl, setRecordedVoiceUrl] = useState<string | null>(null);
  const [isPlayingVoice, setIsPlayingVoice] = useState(false);
  const [voiceVolume, setVoiceVolume] = useState(100);
  const [ambientMusicEnabled, setAmbientMusicEnabled] = useState(true);
  const [ttsScript, setTtsScript] = useState("নমস্কার! এই ভিডিওটি দেখুন এবং মতামত জানান।");
  const [isGeneratingTts, setIsGeneratingTts] = useState(false);

  // Reels recording state
  const [isRenderingReel, setIsRenderingReel] = useState(false);
  const [reelProgress, setReelProgress] = useState(0);
  const [exportedVideoUrl, setExportedVideoUrl] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const audioEngineRef = useRef<AudioEngine | null>(null);
  const recordingIntervalRef = useRef<any>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Initialize audio element
  useEffect(() => {
    audioElementRef.current = new Audio();
    audioEngineRef.current = new AudioEngine();
    return () => {
      if (recordingIntervalRef.current) clearInterval(recordingIntervalRef.current);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, []);

  // Update canvas on any visual property change
  useEffect(() => {
    renderCanvas();
  }, [
    imageSrc,
    activeFilterPreset,
    brightness,
    contrast,
    saturation,
    blurVal,
    hueRotate,
    bgRemoved,
    bgThreshold,
    bgReplacement,
    captionText,
    captionPosition,
    captionColor,
    captionBg,
    watermark,
    activeTab,
  ]);

  // Compute combined CSS filter string
  const computeFilterString = () => {
    const preset = FILTER_PRESETS.find((f) => f.id === activeFilterPreset);
    const presetFilter = preset && preset.css !== "none" ? preset.css : "";
    const manualFilter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) blur(${blurVal}px) hue-rotate(${hueRotate}deg)`;
    return presetFilter ? `${presetFilter} ${manualFilter}` : manualFilter;
  };

  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = imageSrc;

    img.onload = () => {
      canvas.width = 800;
      canvas.height = activeTab === "reels" ? 1422 : Math.max(500, Math.floor(800 * (img.height / img.width)));

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Background layer
      if (bgRemoved) {
        if (bgReplacement === "checker") {
          const size = 20;
          for (let x = 0; x < canvas.width; x += size) {
            for (let y = 0; y < canvas.height; y += size) {
              ctx.fillStyle = (x / size + y / size) % 2 === 0 ? "#1e293b" : "#0f172a";
              ctx.fillRect(x, y, size, size);
            }
          }
        } else if (bgReplacement === "dark") {
          ctx.fillStyle = "#0b0f19";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        } else if (bgReplacement === "cyber") {
          const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
          grad.addColorStop(0, "#06b6d4");
          grad.addColorStop(1, "#3b82f6");
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        } else if (bgReplacement === "sunset") {
          const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
          grad.addColorStop(0, "#f97316");
          grad.addColorStop(1, "#ec4899");
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        } else {
          ctx.fillStyle = "#000000";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
      }

      // Draw with filters
      const filterCss = computeFilterString();
      try {
        ctx.filter = filterCss;
      } catch (_) {
        ctx.filter = "none";
      }

      if (activeTab === "reels") {
        // 9:16 vertical layout
        ctx.save();
        ctx.filter = "blur(24px) brightness(0.4)";
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        ctx.restore();

        try {
          ctx.filter = filterCss;
        } catch (_) {}

        const scale = Math.min(canvas.width / img.width, (canvas.height * 0.75) / img.height);
        const nw = img.width * scale;
        const nh = img.height * scale;
        const nx = (canvas.width - nw) / 2;
        const ny = (canvas.height - nh) / 2;
        ctx.drawImage(img, nx, ny, nw, nh);
      } else {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      }

      // If background remove active: execute safe color threshold
      if (bgRemoved) {
        try {
          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const data = imgData.data;
          const r0 = data[0], g0 = data[1], b0 = data[2];
          const threshold = bgThreshold * 2.5;

          for (let i = 0; i < data.length; i += 4) {
            const r = data[i], g = data[i + 1], b = data[i + 2];
            const dist = Math.sqrt((r - r0) ** 2 + (g - g0) ** 2 + (b - b0) ** 2);
            if (dist < threshold) {
              data[i + 3] = 0; // Transparent alpha
            }
          }
          ctx.putImageData(imgData, 0, 0);
        } catch (corsErr) {
          console.warn("Background removal notice (CORS protected image):", corsErr);
        }
      }

      // Reset filter for text
      ctx.filter = "none";

      // Draw Caption
      if (captionText.trim()) {
        const fontSize = Math.max(26, Math.floor(canvas.width * 0.045));
        ctx.font = `bold ${fontSize}px 'Hind Siliguri', 'Plus Jakarta Sans', sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        const textMetrics = ctx.measureText(captionText);
        const padX = 24;
        const padY = 14;
        const boxW = textMetrics.width + padX * 2;
        const boxH = fontSize + padY * 2;

        let py = canvas.height - 85;
        if (captionPosition === "top") py = 85;
        if (captionPosition === "center") py = canvas.height / 2;

        if (captionBg) {
          ctx.fillStyle = "rgba(11, 15, 25, 0.85)";
          ctx.strokeStyle = "rgba(255, 255, 255, 0.15)";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.roundRect
            ? ctx.roundRect((canvas.width - boxW) / 2, py - boxH / 2, boxW, boxH, 16)
            : ctx.fillRect((canvas.width - boxW) / 2, py - boxH / 2, boxW, boxH);
          ctx.fill();
          ctx.stroke();
        }

        ctx.fillStyle = captionColor;
        ctx.fillText(captionText, canvas.width / 2, py);
      }

      // Watermark
      if (watermark) {
        ctx.font = "600 13px 'Plus Jakarta Sans', sans-serif";
        ctx.fillStyle = "rgba(255, 255, 255, 0.6)";
        ctx.textAlign = "right";
        ctx.fillText("Ranabir AI Studio", canvas.width - 24, canvas.height - 24);
      }
    };
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setImageSrc(event.target.result as string);
          setBgRemoved(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownloadImage = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = "ranabir-edited-photo.png";
    a.click();
  };

  const resetAllEffects = () => {
    setActiveFilterPreset("none");
    setBrightness(100);
    setContrast(100);
    setSaturation(100);
    setBlurVal(0);
    setHueRotate(0);
  };

  // --- Voice & Audio Recording Handlers ---
  const handleToggleVoiceRecording = async () => {
    if (isRecordingVoice) {
      // Stop recording
      if (recordingIntervalRef.current) clearInterval(recordingIntervalRef.current);
      if (audioEngineRef.current) {
        try {
          const { url } = await audioEngineRef.current.stopMicRecording();
          setRecordedVoiceUrl(url);
          if (audioElementRef.current) {
            audioElementRef.current.src = url;
          }
        } catch (e) {
          console.error("Failed to stop voice recording:", e);
        }
      }
      setIsRecordingVoice(false);
    } else {
      // Start recording
      setVoiceRecordingSeconds(0);
      setRecordedVoiceUrl(null);
      if (audioEngineRef.current) {
        try {
          await audioEngineRef.current.startMicRecording();
          setIsRecordingVoice(true);
          recordingIntervalRef.current = setInterval(() => {
            setVoiceRecordingSeconds((prev) => prev + 1);
          }, 1000);
        } catch (e) {
          alert("মাইক্রোফোন অ্যাক্সেস করতে অনুমতি প্রয়োজন। অনুগ্রহ করে ব্রাউজার সেটিংসে অনুমতি দিন।");
        }
      }
    }
  };

  const handlePlayVoice = () => {
    if (!recordedVoiceUrl || !audioElementRef.current) return;
    if (isPlayingVoice) {
      audioElementRef.current.pause();
      setIsPlayingVoice(false);
    } else {
      audioElementRef.current.volume = voiceVolume / 100;
      audioElementRef.current.play();
      setIsPlayingVoice(true);
      audioElementRef.current.onended = () => setIsPlayingVoice(false);
    }
  };

  const handleCustomAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setRecordedVoiceUrl(url);
      if (audioElementRef.current) {
        audioElementRef.current.src = url;
      }
    }
  };

  // Generate TTS Voiceover
  const handleGenerateTtsVoice = () => {
    if (!ttsScript.trim() || !window.speechSynthesis) return;
    setIsGeneratingTts(true);

    const utterance = new SpeechSynthesisUtterance(ttsScript);
    const voices = window.speechSynthesis.getVoices();
    const bnVoice = voices.find((v) => v.lang.includes("bn"));
    if (bnVoice) utterance.voice = bnVoice;
    utterance.rate = 1.0;

    utterance.onend = () => {
      setIsGeneratingTts(false);
      setCaptionText(ttsScript);
    };

    window.speechSynthesis.speak(utterance);
  };

  // --- Auto Reel Generator with Voice & Audio Combined ---
  const handleGenerateReelVideo = () => {
    const canvas = canvasRef.current;
    if (!canvas || isRenderingReel) return;

    setIsRenderingReel(true);
    setReelProgress(0);
    setExportedVideoUrl(null);

    setActiveTab("reels");
    renderCanvas();

    // 1. Capture video stream from canvas
    const canvasStream = canvas.captureStream(30);

    // 2. Mix user voice + ambient music into an Audio MediaStream
    const { stream: audioStream, cleanup: cleanupAudio } = AudioEngine.createMixedAudioStream(
      recordedVoiceUrl ? audioElementRef.current : null,
      ambientMusicEnabled,
      0.15
    );

    // 3. Combine video tracks + audio tracks
    const combinedTracks = [
      ...canvasStream.getVideoTracks(),
      ...audioStream.getAudioTracks(),
    ];
    const combinedStream = new MediaStream(combinedTracks);

    let recorder: MediaRecorder;
    try {
      recorder = new MediaRecorder(combinedStream, { mimeType: "video/webm;codecs=vp9,opus" });
    } catch (e) {
      try {
        recorder = new MediaRecorder(combinedStream, { mimeType: "video/webm" });
      } catch (err) {
        recorder = new MediaRecorder(combinedStream);
      }
    }

    const chunks: Blob[] = [];
    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: "video/webm" });
      const videoUrl = URL.createObjectURL(blob);
      setExportedVideoUrl(videoUrl);
      setIsRenderingReel(false);
      setReelProgress(100);
      cleanupAudio();
    };

    // If user has voice recorded, play it during recording so it feeds into the audio destination
    if (recordedVoiceUrl && audioElementRef.current) {
      audioElementRef.current.currentTime = 0;
      audioElementRef.current.volume = voiceVolume / 100;
      audioElementRef.current.play().catch(() => {});
    }

    recorder.start();

    // 4. Smooth motion animation loop over 4.5 seconds
    const duration = 4500;
    const start = performance.now();

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = imageSrc;

    const animateReel = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      setReelProgress(Math.floor(progress * 100));

      const ctx = canvas.getContext("2d");
      if (ctx && img.complete) {
        canvas.width = 720;
        canvas.height = 1280;

        const zoom = 1.0 + progress * 0.18;
        const panY = Math.sin(progress * Math.PI) * 35;

        // Blurred backdrop
        ctx.save();
        ctx.filter = "blur(32px) brightness(0.4)";
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        ctx.restore();

        // Foreground animated image
        ctx.save();
        ctx.translate(canvas.width / 2, canvas.height / 2 + panY);
        ctx.scale(zoom, zoom);

        const filterCss = computeFilterString();
        try {
          ctx.filter = filterCss;
        } catch (_) {}

        const scale = (canvas.width * 0.88) / img.width;
        ctx.drawImage(img, (-img.width * scale) / 2, (-img.height * scale) / 2, img.width * scale, img.height * scale);
        ctx.restore();

        ctx.filter = "none";

        // Caption overlay
        if (captionText.trim()) {
          ctx.font = "bold 34px 'Hind Siliguri', 'Plus Jakarta Sans', sans-serif";
          ctx.textAlign = "center";
          ctx.fillStyle = "#ffffff";
          ctx.shadowColor = "rgba(0,0,0,0.8)";
          ctx.shadowBlur = 12;
          ctx.fillText(captionText, canvas.width / 2, canvas.height - 180);
          ctx.shadowBlur = 0;
        }

        // Reel Badge with audio indicator
        ctx.fillStyle = "rgba(99, 102, 241, 0.9)";
        ctx.beginPath();
        ctx.roundRect
          ? ctx.roundRect(canvas.width / 2 - 95, 80, 190, 40, 20)
          : ctx.fillRect(canvas.width / 2 - 95, 80, 190, 40);
        ctx.fill();
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 14px 'Plus Jakarta Sans', sans-serif";
        ctx.fillText(recordedVoiceUrl ? "🎙️ VOICE REEL" : "RANABIR REEL", canvas.width / 2, 105);
      }

      if (progress < 1) {
        animationFrameRef.current = requestAnimationFrame(animateReel);
      } else {
        recorder.stop();
      }
    };

    animationFrameRef.current = requestAnimationFrame(animateReel);
  };

  return (
    <div className="max-w-4xl mx-auto w-full px-3 sm:px-4 py-4 pb-24">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
            <Film className="w-6 h-6 text-cyan-400" />
            <span>Photo &amp; Video Edit Studio</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            ইফেক্ট, ব্যাকগ্রাউন্ড রিমুভ, ক্যাপশন ও নিজের ভয়েস অ্যাড করে Auto Reel তৈরি করুন।
          </p>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>ছবি আপলোড</span>
          </button>

          <button
            onClick={handleDownloadImage}
            className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-md shadow-indigo-600/30"
          >
            <Download className="w-3.5 h-3.5" />
            <span>ছবি সেভ</span>
          </button>
        </div>
      </div>

      {/* Main Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Canvas Preview Stage (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col items-center justify-center glass-panel-elevated rounded-2xl p-4 border border-white/10 min-h-[420px]">
          <div className="relative max-h-[500px] w-full flex items-center justify-center overflow-hidden rounded-xl bg-black/40">
            <canvas
              ref={canvasRef}
              className="max-h-[480px] max-w-full object-contain rounded-lg shadow-xl"
            />

            {isRenderingReel && (
              <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
                <div className="w-12 h-12 rounded-full border-4 border-cyan-400 border-t-transparent animate-spin mb-4"></div>
                <h4 className="text-base font-bold text-white">Auto Reel ভিডিও ও ভয়েস সিন্থেসিস হচ্ছে...</h4>
                <p className="text-xs text-slate-400 mt-1">ক্যানভাস মোশন ও অডিও ট্র্যাক মার্জ হচ্ছে ({reelProgress}%)</p>
                <div className="w-52 h-2 bg-slate-800 rounded-full mt-3 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 to-indigo-500 transition-all duration-150"
                    style={{ width: `${reelProgress}%` }}
                  ></div>
                </div>
              </div>
            )}
          </div>

          {/* Sample template quick picks (100% CORS-safe) */}
          <div className="mt-3 flex items-center gap-2 overflow-x-auto w-full pt-2 border-t border-white/5 no-scrollbar">
            <span className="text-[11px] text-slate-500 font-medium shrink-0">স্যাম্পল ছবি:</span>
            {SAMPLE_TEMPLATES.map((tmpl) => (
              <button
                key={tmpl.id}
                onClick={() => {
                  setImageSrc(generateSampleCanvas(tmpl.id as any));
                  setBgRemoved(false);
                }}
                className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-white/5 whitespace-nowrap transition-colors"
              >
                {tmpl.name}
              </button>
            ))}
          </div>

          {/* Exported Video Player and Download Banner */}
          {exportedVideoUrl && (
            <div className="mt-4 w-full p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-300 text-xs font-bold">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Reel ভিডিও তৈরি সম্পন্ন! (ভয়েস সংযুক্ত)</span>
                </div>
                <a
                  href={exportedVideoUrl}
                  download="ranabir-voice-reel.webm"
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>ভিডিও ডাউনলোড করুন</span>
                </a>
              </div>

              {/* In-app Video Preview */}
              <div className="aspect-[9/16] max-h-[300px] mx-auto rounded-xl overflow-hidden bg-black/90 shadow-md">
                <video
                  src={exportedVideoUrl}
                  controls
                  autoPlay
                  loop
                  className="w-full h-full object-contain"
                />
              </div>
            </div>
          )}
        </div>

        {/* Tools & Control Panels (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          {/* Tool mode switch tabs */}
          <div className="grid grid-cols-5 gap-1 p-1 rounded-xl glass-panel border border-white/10 text-[11px] font-semibold">
            <button
              onClick={() => setActiveTab("filter")}
              className={`py-2 rounded-lg flex flex-col items-center gap-1 transition-colors ${
                activeTab === "filter" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>ইফেক্ট</span>
            </button>
            <button
              onClick={() => setActiveTab("bgremove")}
              className={`py-2 rounded-lg flex flex-col items-center gap-1 transition-colors ${
                activeTab === "bgremove" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>Bg রিমুভ</span>
            </button>
            <button
              onClick={() => setActiveTab("caption")}
              className={`py-2 rounded-lg flex flex-col items-center gap-1 transition-colors ${
                activeTab === "caption" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              <Type className="w-3.5 h-3.5" />
              <span>ক্যাপশন</span>
            </button>
            <button
              onClick={() => setActiveTab("audio")}
              className={`py-2 rounded-lg flex flex-col items-center gap-1 transition-colors ${
                activeTab === "audio" ? "bg-cyan-600 text-white shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              <Mic className="w-3.5 h-3.5" />
              <span>ভয়েস</span>
            </button>
            <button
              onClick={() => setActiveTab("reels")}
              className={`py-2 rounded-lg flex flex-col items-center gap-1 transition-colors ${
                activeTab === "reels" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              <span>Reels</span>
            </button>
          </div>

          {/* Sub Panel 1: Filter & Visual Adjustments */}
          {activeTab === "filter" && (
            <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 space-y-4 max-h-[500px] overflow-y-auto no-scrollbar">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-indigo-400" />
                  <span>ফিল্টার ও লাইটিং অ্যাডজাস্টমেন্ট</span>
                </h4>
                <button
                  onClick={resetAllEffects}
                  className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>রিসেট</span>
                </button>
              </div>

              {/* Filter Preset Grid */}
              <div className="grid grid-cols-2 gap-2">
                {FILTER_PRESETS.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setActiveFilterPreset(f.id)}
                    className={`p-2 rounded-xl text-xs font-semibold text-left transition-all border ${
                      activeFilterPreset === f.id
                        ? "bg-indigo-600/40 border-indigo-400 text-white shadow"
                        : "bg-slate-800/60 border-white/5 text-slate-300 hover:bg-slate-800"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>

              {/* Manual Tuning Sliders */}
              <div className="space-y-3 pt-2 border-t border-white/5">
                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>ব্রাইটনেস (Brightness):</span>
                    <span>{brightness}%</span>
                  </div>
                  <input
                    type="range"
                    min="40"
                    max="160"
                    value={brightness}
                    onChange={(e) => setBrightness(Number(e.target.value))}
                    className="w-full accent-indigo-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>কনট্রাস্ট (Contrast):</span>
                    <span>{contrast}%</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="200"
                    value={contrast}
                    onChange={(e) => setContrast(Number(e.target.value))}
                    className="w-full accent-indigo-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>রং এর উজ্জ্বলতা (Saturation):</span>
                    <span>{saturation}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="250"
                    value={saturation}
                    onChange={(e) => setSaturation(Number(e.target.value))}
                    className="w-full accent-indigo-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>হিউ কালার শিফট (Hue Shift):</span>
                    <span>{hueRotate}°</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="360"
                    value={hueRotate}
                    onChange={(e) => setHueRotate(Number(e.target.value))}
                    className="w-full accent-cyan-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Sub Panel 2: Background Remove & Replace */}
          {activeTab === "bgremove" && (
            <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 space-y-4">
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Scissors className="w-4 h-4 text-cyan-400" />
                <span>ইন-অ্যাপ ব্যাকগ্রাউন্ড রিমুভার ও রিপ্লেস</span>
              </h4>
              <p className="text-xs text-slate-400">
                এক ক্লিকে ছবির ব্যাকগ্রাউন্ড কাটআউট করুন এবং পছন্দমতো নতুন ব্যাকগ্রাউন্ড সেট করুন।
              </p>

              <button
                onClick={() => setBgRemoved(!bgRemoved)}
                className={`w-full py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 ${
                  bgRemoved
                    ? "bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/20"
                    : "bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-600/20"
                }`}
              >
                <Scissors className="w-4 h-4" />
                <span>{bgRemoved ? "ব্যাকগ্রাউন্ড পুনরায় সক্রিয় করুন" : "ব্যাকগ্রাউন্ড রিমুভ করুন"}</span>
              </button>

              {bgRemoved && (
                <div className="space-y-3 pt-2">
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>কাটআউট সংবেদনশীলতা (Tolerance):</span>
                      <span>{bgThreshold}%</span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="60"
                      value={bgThreshold}
                      onChange={(e) => setBgThreshold(Number(e.target.value))}
                      className="w-full accent-cyan-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 block mb-1.5">নতুন ব্যাকগ্রাউন্ড নির্বাচন করুন:</label>
                    <div className="grid grid-cols-2 gap-2">
                      {BG_REPLACEMENT_OPTIONS.map((opt) => (
                        <button
                          key={opt.id}
                          onClick={() => setBgReplacement(opt.id)}
                          className={`p-2 rounded-xl text-xs font-semibold text-left transition-all border ${
                            bgReplacement === opt.id
                              ? "bg-indigo-600/30 border-indigo-400 text-white"
                              : "bg-slate-800/60 border-white/5 text-slate-300"
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Sub Panel 3: Caption */}
          {activeTab === "caption" && (
            <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 space-y-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Type className="w-4 h-4 text-indigo-400" />
                <span>ক্যাপশন ও স্টাইলিস্ট টেক্সট</span>
              </h4>

              <div>
                <label className="text-xs text-slate-400 block mb-1">ক্যাপশন টেক্সট:</label>
                <input
                  type="text"
                  value={captionText}
                  onChange={(e) => setCaptionText(e.target.value)}
                  placeholder="আপনার ক্যাপশন লিখুন..."
                  className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">পজিশন:</label>
                <div className="grid grid-cols-3 gap-2">
                  {(["top", "center", "bottom"] as const).map((pos) => (
                    <button
                      key={pos}
                      onClick={() => setCaptionPosition(pos)}
                      className={`py-1.5 rounded-lg text-xs font-semibold capitalize ${
                        captionPosition === pos
                          ? "bg-indigo-600 text-white"
                          : "bg-slate-800 text-slate-400 hover:text-white"
                      }`}
                    >
                      {pos === "top" ? "উপরে" : pos === "center" ? "মাঝখানে" : "নিচে"}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-300 pt-2 border-t border-white/5">
                <span>টেক্সট ব্যাকগ্রাউন্ড রিবন:</span>
                <input
                  type="checkbox"
                  checked={captionBg}
                  onChange={(e) => setCaptionBg(e.target.checked)}
                  className="accent-indigo-500 h-4 w-4 rounded"
                />
              </div>

              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Ranabir AI ওয়াটারমার্ক:</span>
                <input
                  type="checkbox"
                  checked={watermark}
                  onChange={(e) => setWatermark(e.target.checked)}
                  className="accent-indigo-500 h-4 w-4 rounded"
                />
              </div>
            </div>
          )}

          {/* Sub Panel 4: Voice & Audio (আমার ভয়েস অ্যাড) */}
          {activeTab === "audio" && (
            <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Mic className="w-4 h-4 text-cyan-400" />
                  <span>আমার ভয়েস ও অডিও যোগ করুন</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  মাইক্রোফোনে আপনার নিজের ভয়েস রেকর্ড করুন অথবা অডিও ফাইল আপলোড করে ভিডিওর সাথে যুক্ত করুন।
                </p>
              </div>

              {/* 1. Live Mic Voice Record Button */}
              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <Mic className="w-3.5 h-3.5 text-cyan-400" />
                    <span>মাইক্রোফোন রেকর্ডিং</span>
                  </span>
                  {isRecordingVoice && (
                    <span className="text-xs font-bold text-rose-400 animate-pulse flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                      <span>রেকর্ডিং হচ্ছে ({voiceRecordingSeconds}s)</span>
                    </span>
                  )}
                </div>

                <button
                  onClick={handleToggleVoiceRecording}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md ${
                    isRecordingVoice
                      ? "bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30"
                      : "bg-cyan-600 hover:bg-cyan-500 text-white shadow-cyan-600/30"
                  }`}
                >
                  {isRecordingVoice ? (
                    <>
                      <Square className="w-3.5 h-3.5 fill-white" />
                      <span>রেকর্ডিং সমাপ্ত করুন</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3.5 h-3.5" />
                      <span>{recordedVoiceUrl ? "আবার ভয়েস রেকর্ড করুন" : "আমার ভয়েস রেকর্ড করুন"}</span>
                    </>
                  )}
                </button>

                {/* Voice Preview & Controls */}
                {recordedVoiceUrl && (
                  <div className="p-2.5 rounded-xl bg-slate-900/80 border border-cyan-500/20 flex items-center justify-between gap-2 text-xs">
                    <button
                      onClick={handlePlayVoice}
                      className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold flex items-center gap-1"
                    >
                      <Play className="w-3.5 h-3.5 fill-slate-950" />
                      <span>{isPlayingVoice ? "থামান" : "ভয়েস শুনুন"}</span>
                    </button>

                    <div className="flex items-center gap-1 text-slate-400 text-[11px]">
                      <Volume2 className="w-3.5 h-3.5" />
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={voiceVolume}
                        onChange={(e) => setVoiceVolume(Number(e.target.value))}
                        className="w-16 accent-cyan-400 h-1 cursor-pointer"
                        title="ভয়েস ভলিউম"
                      />
                    </div>

                    <button
                      onClick={() => setRecordedVoiceUrl(null)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10"
                      title="ভয়েস মুছুন"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* 2. Upload Custom Audio File */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-800/40 border border-white/5 text-xs">
                <span className="text-slate-300">ডিভাইস থেকে অডিও ফাইল আপলোড:</span>
                <input
                  type="file"
                  ref={audioInputRef}
                  onChange={handleCustomAudioUpload}
                  accept="audio/*"
                  className="hidden"
                />
                <button
                  onClick={() => audioInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 font-semibold flex items-center gap-1"
                >
                  <Music className="w-3.5 h-3.5" />
                  <span>অডিও বাছুন</span>
                </button>
              </div>

              {/* 3. Ambient Lo-Fi Background Music Toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-800/40 border border-white/5 text-xs">
                <div>
                  <span className="text-slate-200 font-medium block">সফট ব্যাকগ্রাউন্ড মিউজিক:</span>
                  <span className="text-[10px] text-slate-400">ভিডিওতে মৃদু ব্যাকগ্রাউন্ড সিন্থেসাইজার যুক্ত করবে</span>
                </div>
                <input
                  type="checkbox"
                  checked={ambientMusicEnabled}
                  onChange={(e) => setAmbientMusicEnabled(e.target.checked)}
                  className="accent-indigo-500 h-4 w-4 rounded"
                />
              </div>
            </div>
          )}

          {/* Sub Panel 5: Auto Reels */}
          {activeTab === "reels" && (
            <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Film className="w-4 h-4 text-cyan-400" />
                  <span>Auto Reels Creator (ভয়েস সহ ভিডিও)</span>
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  আপনার ছবিকে 9:16 রিল ফরম্যাটে স্বয়ংক্রিয় কেন-বার্নস জুম মোশন, টেক্সট এবং আপনার নিজের রেকর্ড করা ভয়েস সহ এক্সপোর্ট করুন।
                </p>
              </div>

              {/* Status Indicator */}
              <div className="p-3 rounded-xl bg-slate-800/60 border border-white/5 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">সংযুক্ত ভয়েস ট্র্যাক:</span>
                  <span className={recordedVoiceUrl ? "text-cyan-300 font-bold" : "text-slate-500"}>
                    {recordedVoiceUrl ? "✓ আপনার ভয়েস যুক্ত রয়েছে" : "কোনো ভয়েস নেই (মিউজিক থাকবে)"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">অ্যানিমেশন স্টাইল:</span>
                  <span className="text-slate-300 font-semibold">Ken Burns Cinematic Zoom</span>
                </div>
              </div>

              <button
                onClick={handleGenerateReelVideo}
                disabled={isRenderingReel}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-600/25 transition-all"
              >
                {isRenderingReel ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>ভিডিও ও অডিও সিন্থেসিস হচ্ছে ({reelProgress}%)...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white" />
                    <span>ভয়েস সহ Auto Reel ভিডিও তৈরি করুন</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
