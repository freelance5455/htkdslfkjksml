import React, { useState, useEffect } from 'react';
import {
  Radio,
  Tv,
  DollarSign,
  AlertOctagon,
  FastForward,
  Play,
  Volume2,
  VolumeX,
  TrendingUp,
  Sliders,
  Sparkles,
  Zap,
  Film,
  Eye,
  Grid,
  Calendar,
  CheckCircle,
  Clock,
  ChevronRight,
  RefreshCw,
  CloudRain,
  Compass,
  Crosshair,
  MapPin,
  MessageSquare,
} from 'lucide-react';
import {
  RivalNetwork,
  Sponsor,
  Talent,
  TimeSlotConfig,
  TVProgram,
} from '../types/game';
import { RIVAL_PROGRAMMING, RivalShowInfo } from '../data/rivalBroadcasts';
import { soundFx } from '../utils/audio';

interface MasterControlRoomProps {
  currentSlot: TimeSlotConfig;
  currentProgram: TVProgram | null;
  currentTalent: Talent | null;
  currentSponsor: Sponsor | null;
  nextProgram: TVProgram | null;
  liveIbope: number;
  playerRank: number;
  rivals: RivalNetwork[];
  ratingsHistory: number[];
  clockTime: string;
  isCommercialActive: boolean;
  onTriggerCommercial: () => void;
  onTriggerPlantao: () => void;
  onFastForwardSlot: () => void;
  simSpeed: number;
  onChangeSimSpeed: (speed: number) => void;
  isPaused: boolean;
  onTogglePause: () => void;
  cash: number;
  stationName: string;
  onOpenSchedule: () => void;
  onQuickAssignRerun: () => void;
}

type TunedChannel = 'player' | 'soberana' | 'popular' | 'canal-viva' | 'multiview';

export const MasterControlRoom: React.FC<MasterControlRoomProps> = ({
  currentSlot,
  currentProgram,
  currentTalent,
  currentSponsor,
  nextProgram,
  liveIbope,
  playerRank,
  rivals,
  ratingsHistory,
  clockTime,
  isCommercialActive,
  onTriggerCommercial,
  onTriggerPlantao,
  onFastForwardSlot,
  simSpeed,
  onChangeSimSpeed,
  isPaused,
  onTogglePause,
  cash,
  stationName,
  onOpenSchedule,
  onQuickAssignRerun,
}) => {
  const [tunedChannel, setTunedChannel] = useState<TunedChannel>('player');
  const [commercialCooldown, setCommercialCooldown] = useState(0);
  const [plantaoCooldown, setPlantaoCooldown] = useState(0);
  const [switcherEffect, setSwitcherEffect] = useState(false);
  const [cameraAngle, setCameraAngle] = useState(1);
  const [applauseCooldown, setApplauseCooldown] = useState(false);
  const [dialogueIndex, setDialogueIndex] = useState(0);
  const [paparazziFlash, setPaparazziFlash] = useState(false);
  const [newsMode, setNewsMode] = useState<'bancada' | 'reporter' | 'aguia' | 'radar'>('bancada');
  const [tweetIndex, setTweetIndex] = useState(0);
  const [telemetryAlt, setTelemetryAlt] = useState(410);
  const [telemetrySpeed, setTelemetrySpeed] = useState(148);

  // Cycling subtitles and headlines
  useEffect(() => {
    const interval = setInterval(() => {
      setDialogueIndex((d) => (d + 1) % 8);
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  // Cycling social media tweets for news
  useEffect(() => {
    const interval = setInterval(() => {
      setTweetIndex((t) => (t + 1) % 6);
      setTelemetryAlt(380 + Math.floor(Math.random() * 60));
      setTelemetrySpeed(135 + Math.floor(Math.random() * 30));
    }, 3800);
    return () => clearInterval(interval);
  }, []);

  // Paparazzi flashing effect for fofoca
  useEffect(() => {
    const flashInterval = setInterval(() => {
      setPaparazziFlash(true);
      setTimeout(() => setPaparazziFlash(false), 120);
    }, 2800);
    return () => clearInterval(flashInterval);
  }, []);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (commercialCooldown > 0) {
      timer = setTimeout(() => setCommercialCooldown((c) => c - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [commercialCooldown]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (plantaoCooldown > 0) {
      timer = setTimeout(() => setPlantaoCooldown((c) => c - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [plantaoCooldown]);

  const handleTuneChannel = (channel: TunedChannel) => {
    soundFx.playStaticCut();
    setSwitcherEffect(true);
    setTimeout(() => setSwitcherEffect(false), 180);
    setTunedChannel(channel);
  };

  const handleCommercialClick = () => {
    if (commercialCooldown > 0 || !currentSponsor) return;
    soundFx.playCash();
    setCommercialCooldown(12);
    setSwitcherEffect(true);
    setTimeout(() => setSwitcherEffect(false), 200);
    onTriggerCommercial();
  };

  const handlePlantaoClick = () => {
    if (plantaoCooldown > 0) return;
    soundFx.playPlantao();
    setPlantaoCooldown(30);
    setSwitcherEffect(true);
    setTimeout(() => setSwitcherEffect(false), 300);
    onTriggerPlantao();
  };

  const handleSwitchCamera = () => {
    soundFx.playStaticCut();
    setCameraAngle((a) => (a % 3) + 1);
  };

  const handleTriggerApplause = () => {
    if (applauseCooldown) return;
    soundFx.playApplause();
    setApplauseCooldown(true);
    setTimeout(() => setApplauseCooldown(false), 4000);
  };

  // Soap opera dynamic dialogue lines
  const soapDialogues = [
    '— Você pensou que podia esconder este segredo de mim por tanto tempo?!',
    '— Quem é você para me julgar?! Eu fiz tudo pela nossa família!',
    '— O teste de DNA comprovou a verdade... Você não é filha dele!',
    '— Guarde minhas palavras: você ainda vai rastejar pedindo perdão!',
  ];

  // Real-time dynamic Brazilian breaking news headlines
  const newsHeadlines = [
    'PERSEGUIÇÃO AO VIVO: Águia 13 acompanha cerco policial e bloqueio de pistas na marginal',
    'ALERTA DEFESA CIVIL: Temporal com granizo provoca pontos de alagamento na capital',
    'EXCLUSIVO: Documentos inéditos revelam esquema milionário de fraude em licitações',
    'CAOS NO TRÂNSITO: Engavetamento com três carretas interdita subida da serra',
    'OPERAÇÃO FEDERAL: 24 mandados de prisão cumpridos contra quadrilha de golpes digitais',
    'ECONOMIA EM ALTA: Comércio bate recorde de contratações temporárias para o feriado',
    'RESGATE HEROICO: Bombeiros salvam família ilhada em correnteza após tromba d\'água',
    'CLIMA EXTREMO: Queda histórica de 14 graus em poucas horas surpreende moradores',
  ];

  // Viewer social media comments feed
  const viewerTweets = [
    '@rodrigo_sp: "O helicóptero tá passando aqui em cima do prédio, imagem impecável!"',
    '@marina_tv: "A cobertura ao vivo da Brasilis tá dando de dez na concorrência!"',
    '@ze_caminhoneiro: "Evitem a marginal norte, tá totalmente parado tudo por causa da chuva"',
    '@prof_luciana: "Chuva absurda aqui na zona leste, muita força pras equipes de resgate!"',
    '@carlos_rio: "Excelente trabalho do repórter ao vivo debaixo dessa tempestade!"',
    '@brasilis_fan: "Plantão da Brasilis sempre chega na frente com informação de verdade!"',
  ];

  // Renders the live television monitor content for the PLAYER's own station
  const renderPlayerChannelContent = (compact = false) => {
    if (isCommercialActive && currentSponsor) {
      return (
        <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center relative overflow-hidden bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900">
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-bold text-[9px] tracking-wider uppercase shadow">
            INTERVALO COMERCIAL
          </div>
          <div
            className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center shadow-xl mb-1.5 text-white font-black text-xl border-2 border-white/20 animate-pulse"
            style={{ backgroundColor: currentSponsor.logoColor }}
          >
            {currentSponsor.name.substring(0, 2).toUpperCase()}
          </div>
          <h3 className="text-base sm:text-xl font-black text-white tracking-wide uppercase drop-shadow">
            {currentSponsor.name}
          </h3>
          <p className="text-[11px] text-amber-300 font-semibold mt-0.5">
            {currentSponsor.productType}
          </p>
          <div className="mt-2 px-2.5 py-0.5 rounded-full bg-black/60 border border-white/10 text-[9px] text-slate-300">
            Oferecimento Oficial · {currentSlot.label}
          </div>
        </div>
      );
    }

    if (!currentProgram) {
      // SMPTE Test Pattern Bars
      return (
        <div className="w-full h-full relative overflow-hidden flex flex-col justify-between p-3 bg-slate-950">
          <div className="absolute inset-0 grid grid-cols-7 opacity-85 pointer-events-none">
            <div className="bg-slate-200" />
            <div className="bg-yellow-400" />
            <div className="bg-cyan-400" />
            <div className="bg-emerald-500" />
            <div className="bg-fuchsia-600" />
            <div className="bg-red-600" />
            <div className="bg-blue-700" />
          </div>

          <div className="relative z-10 flex items-center justify-between">
            <span className="px-2 py-0.5 rounded bg-black/90 text-amber-400 font-mono text-[9px] font-bold uppercase tracking-wider border border-amber-400/40">
              SINAL FORA DO AR · SMPTE
            </span>
            <span className="text-[10px] font-mono font-bold text-white bg-black/90 px-1.5 py-0.5 rounded">
              CANAL 13
            </span>
          </div>

          <div className="relative z-10 my-auto mx-auto max-w-xs bg-black/90 border border-slate-700 p-3 rounded-xl text-center shadow-2xl backdrop-blur-sm">
            <div className="w-8 h-8 rounded-full bg-red-600/30 border border-red-500 text-red-400 mx-auto flex items-center justify-center mb-1 animate-pulse">
              <Radio className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-white">Sem Programa Escalado!</h4>
            <p className="text-[10px] text-slate-300 mt-0.5">
              Escale um show ou ative uma reprise rápida para recuperar IBOPE.
            </p>
            <div className="flex items-center justify-center gap-1.5 mt-2.5">
              <button
                onClick={() => {
                  soundFx.playClick();
                  onOpenSchedule();
                }}
                className="px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] uppercase transition-all shadow-md active:scale-95 cursor-pointer"
              >
                Abrir Grade
              </button>
              <button
                onClick={() => {
                  soundFx.playClick();
                  onQuickAssignRerun();
                }}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-[11px] border border-slate-600 active:scale-95 cursor-pointer flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3 text-amber-400" />
                <span>Ativar Reprise</span>
              </button>
            </div>
          </div>

          <div className="relative z-10 text-center font-mono text-[9px] text-white/90 bg-black/80 py-0.5 rounded">
            REDE BRASILIS DE TELEVISÃO · ESTÚDIOS PRINCIPAIS
          </div>
        </div>
      );
    }

    const genre = currentProgram.genre;

    // NOVELA / TELEDRAMATURGIA
    if (genre === 'novela') {
      return (
        <div className="w-full h-full relative overflow-hidden flex flex-col justify-between bg-gradient-to-b from-stone-900 via-amber-950/40 to-stone-950">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-600/20 via-transparent to-transparent pointer-events-none" />
          <div className="relative z-10 flex items-center justify-between p-2">
            <span className="px-1.5 py-0.5 rounded bg-black/75 text-amber-400 font-mono text-[9px] font-bold border border-amber-400/30">
              VALE DA PAIXÃO · CAP. {currentProgram.episodesAired + 1}
            </span>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-mono text-emerald-400 bg-black/75 px-1.5 py-0.5 rounded">
                CAM 0{cameraAngle}
              </span>
              <span className="text-[9px] font-bold text-white bg-red-600 px-1.5 py-0.5 rounded">
                NOVELA
              </span>
            </div>
          </div>

          <div className="relative z-10 flex items-end justify-center gap-3 px-4 flex-1 pb-1">
            <div className="flex flex-col items-center">
              <div className="w-16 h-20 sm:w-20 sm:h-24 rounded-t-full bg-gradient-to-t from-slate-800 to-amber-900/60 border-t-2 border-amber-400/40 relative shadow-2xl flex items-center justify-center">
                <span className="text-2xl sm:text-3xl">🎭</span>
              </div>
              <span className="text-[9px] font-bold text-amber-200 mt-0.5 bg-black/70 px-1 rounded">
                Helena
              </span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-16 h-20 sm:w-20 sm:h-24 rounded-t-full bg-gradient-to-t from-slate-800 to-stone-800 border-t-2 border-slate-400/40 relative shadow-2xl flex items-center justify-center">
                <span className="text-2xl sm:text-3xl">😡</span>
              </div>
              <span className="text-[9px] font-bold text-slate-300 mt-0.5 bg-black/70 px-1 rounded">
                Rodrigo
              </span>
            </div>
          </div>

          <div className="relative z-10 bg-black/85 border-t border-amber-500/30 p-2 text-center backdrop-blur-sm">
            <p className="text-[11px] sm:text-xs text-yellow-300 font-serif italic drop-shadow transition-all">
              {soapDialogues[dialogueIndex]}
            </p>
          </div>
        </div>
      );
    }

    // JORNALISMO / NOTÍCIAS AO VIVO (VIBRANTE & ULTRA REALISTA)
    if (genre === 'jornalismo') {
      return (
        <div className="w-full h-full relative overflow-hidden flex flex-col justify-between bg-slate-950">
          {/* Top News Bug Bar */}
          <div className="relative z-20 flex items-center justify-between p-2 bg-gradient-to-b from-black/90 to-transparent">
            <div className="flex items-center gap-1.5">
              <span className="px-1.5 py-0.5 rounded bg-blue-600 text-white font-black text-[9px] uppercase tracking-wider shadow">
                BRASILIS NOTÍCIAS
              </span>
              <span className="text-[9px] font-mono text-red-400 bg-black/85 px-1.5 py-0.5 rounded flex items-center gap-1 border border-red-500/30">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                AO VIVO
              </span>
              <span className="text-[9px] font-mono font-bold text-amber-300 bg-black/80 px-1 py-0.5 rounded hidden sm:inline">
                {clockTime}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-mono font-bold text-emerald-400 bg-black/85 px-1.5 py-0.5 rounded border border-emerald-500/30">
                {newsMode === 'bancada'
                  ? 'BANCADA CENTRAL'
                  : newsMode === 'reporter'
                  ? 'LINK DE RUA AO VIVO'
                  : newsMode === 'aguia'
                  ? 'HELICÓPTERO ÁGUIA 13'
                  : 'RADAR METEOROLÓGICO'}
              </span>
              <span className="text-[9px] font-mono text-slate-300 bg-black/70 px-1 py-0.5 rounded">
                1080p HD
              </span>
            </div>
          </div>

          {/* MAIN JOURNALISM VIDEO FEED (4 DYNAMIC MODES) */}
          <div className="relative z-10 flex-1 flex items-center justify-center overflow-hidden">
            {/* Mode 1: Bancada do Estúdio com Video Wall Panorâmico */}
            {newsMode === 'bancada' && (
              <div className="w-full h-full relative flex items-center justify-center bg-gradient-to-b from-blue-950 via-slate-900 to-slate-950">
                {/* Background Video Wall: Skyline with blinking city lights */}
                <div className="absolute inset-0 opacity-40 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-600 via-transparent to-transparent pointer-events-none" />
                <div className="absolute inset-x-0 bottom-6 h-28 flex items-end justify-around opacity-30 pointer-events-none">
                  <div className="w-8 h-20 bg-blue-400/30 rounded-t" />
                  <div className="w-12 h-28 bg-blue-300/40 rounded-t relative">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping absolute -top-1 left-5" />
                  </div>
                  <div className="w-10 h-16 bg-blue-500/30 rounded-t" />
                  <div className="w-14 h-24 bg-blue-400/40 rounded-t relative">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping absolute -top-1 left-6" />
                  </div>
                  <div className="w-8 h-18 bg-blue-400/30 rounded-t" />
                </div>

                {/* News Desk & Anchor */}
                <div className="relative z-10 flex flex-col items-center">
                  <div className="relative">
                    <div className="w-20 h-16 sm:w-24 sm:h-20 bg-gradient-to-t from-slate-900 to-slate-800 border-2 border-blue-400/60 rounded-2xl flex items-center justify-center shadow-2xl relative overflow-hidden">
                      <div className="absolute inset-0 bg-blue-500/10" />
                      <span className="text-3xl sm:text-4xl">🎙️</span>
                    </div>
                    {/* Live Mic waveform bug */}
                    <div className="absolute -bottom-1 -right-2 px-1.5 py-0.2 rounded bg-red-600 text-[8px] font-mono font-bold text-white shadow">
                      MIC ON
                    </div>
                  </div>

                  <div className="mt-1 px-3 py-0.5 rounded-full bg-black/85 border border-blue-400/40 text-[10px] text-white font-bold flex items-center gap-1.5 shadow">
                    <span>{currentTalent?.name || 'Âncora Oficial'}</span>
                    <span className="text-blue-400">·</span>
                    <span className="text-[9px] text-slate-300">Estúdio Central</span>
                  </div>
                </div>
              </div>
            )}

            {/* Mode 2: Split-Screen Link ao Vivo (Estúdio + Repórter no Local) */}
            {newsMode === 'reporter' && (
              <div className="w-full h-full grid grid-cols-2 gap-1 p-1 bg-black">
                {/* Left: Anchor Listening */}
                <div className="relative bg-slate-900 rounded-xl overflow-hidden border border-blue-500/50 flex flex-col items-center justify-center">
                  <div className="absolute top-1.5 left-1.5 z-10 px-1.5 py-0.5 rounded bg-black/80 text-[8px] font-bold text-blue-300 uppercase">
                    ESTÚDIO
                  </div>
                  <span className="text-3xl sm:text-4xl">🎙️</span>
                  <span className="text-[9px] font-bold text-white mt-1 bg-black/80 px-2 py-0.5 rounded">
                    {currentTalent?.name?.split(' ')[0] || 'Âncora'}
                  </span>
                </div>

                {/* Right: Field Reporter in Rain with Mic */}
                <div className="relative bg-gradient-to-b from-stone-900 via-slate-900 to-slate-950 rounded-xl overflow-hidden border border-amber-500/60 flex flex-col items-center justify-center">
                  {/* Rain & Siren flash simulation */}
                  <div className="absolute inset-0 bg-blue-500/10 pointer-events-none" />
                  <div className="absolute top-1.5 left-1.5 z-10 px-1.5 py-0.5 rounded bg-red-600 text-white text-[8px] font-black uppercase flex items-center gap-1 shadow">
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                    LINK AO VIVO
                  </div>

                  <div className="relative flex flex-col items-center my-auto">
                    <div className="relative">
                      <span className="text-3xl sm:text-4xl animate-bounce">🌧️</span>
                      <span className="text-3xl sm:text-4xl absolute -bottom-1 -right-2">🎤</span>
                    </div>
                    <span className="text-[9px] font-bold text-yellow-300 mt-1 bg-black/85 px-2 py-0.5 rounded border border-yellow-400/30">
                      Larissa Mendes (Repórter)
                    </span>
                    <span className="text-[8px] font-mono text-slate-300 mt-0.5 bg-black/70 px-1.5 rounded">
                      Praça da Sé · Chuva Forte
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Mode 3: Helicóptero Águia 13 ao Vivo (Aerial Cam with HUD) */}
            {newsMode === 'aguia' && (
              <div className="w-full h-full relative overflow-hidden bg-slate-950 flex flex-col justify-between p-2">
                {/* Aerial City & Highway Traffic Simulation */}
                <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-slate-950 to-stone-900 opacity-90" />
                <div className="absolute inset-0 flex flex-col justify-center items-center pointer-events-none opacity-40">
                  <div className="w-full h-12 bg-stone-800 rotate-12 flex items-center justify-around overflow-hidden">
                    <div className="w-3 h-2 bg-yellow-400 rounded-full animate-ping" />
                    <div className="w-3 h-2 bg-red-500 rounded-full animate-ping" />
                    <div className="w-3 h-2 bg-white rounded-full animate-ping" />
                  </div>
                </div>

                {/* Military / Broadcast HUD Overlay */}
                <div className="absolute inset-0 border border-emerald-500/30 pointer-events-none flex items-center justify-center">
                  <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border border-emerald-400/40 border-dashed flex items-center justify-center">
                    <Crosshair className="w-8 h-8 text-emerald-400/60 animate-spin" />
                  </div>
                </div>

                <div className="relative z-10 flex items-center justify-between text-[9px] font-mono text-emerald-400 bg-black/80 px-2 py-1 rounded border border-emerald-500/40">
                  <div className="flex items-center gap-2">
                    <span className="animate-pulse">🚁 ÁGUIA 13</span>
                    <span>ALT: {telemetryAlt}m</span>
                    <span>VEL: {telemetrySpeed} km/h</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span>GIMBAL 4K</span>
                  </div>
                </div>

                <div className="relative z-10 my-auto text-center">
                  <div className="inline-block bg-black/85 border border-red-500/50 px-3 py-1 rounded-xl text-center shadow-2xl">
                    <div className="text-[10px] font-mono font-bold text-red-400 uppercase tracking-widest flex items-center justify-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                      IMAGENS AÉREAS EXCLUSIVAS
                    </div>
                    <div className="text-xs font-bold text-white mt-0.5">
                      Monitoramento da Marginal Tietê e Vias Expressas
                    </div>
                  </div>
                </div>

                <div className="relative z-10 text-[9px] font-mono text-slate-300 bg-black/80 px-2 py-0.5 rounded flex items-center justify-between">
                  <span>LAT: -23.5505 · LONG: -46.6333</span>
                  <span className="text-emerald-400 font-bold">TRANSMISSÃO ESTÁVEL</span>
                </div>
              </div>
            )}

            {/* Mode 4: Radar Clima & Trânsito */}
            {newsMode === 'radar' && (
              <div className="w-full h-full relative overflow-hidden bg-slate-950 flex flex-col justify-between p-2">
                <div className="relative z-10 flex items-center justify-between text-[9px] font-mono text-blue-300 bg-black/85 px-2 py-1 rounded border border-blue-500/40">
                  <span className="flex items-center gap-1">
                    <CloudRain className="w-3 h-3 text-cyan-400" />
                    RADAR DOPPLER METEOROLÓGICO
                  </span>
                  <span className="text-amber-400 font-bold">TEMPO SEVERO</span>
                </div>

                <div className="relative z-10 my-auto flex items-center justify-around gap-2 px-3">
                  <div className="w-24 h-24 rounded-full border-2 border-cyan-500/50 relative flex items-center justify-center bg-cyan-950/30">
                    <div className="absolute inset-0 rounded-full border border-cyan-400/30 animate-ping" />
                    <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-yellow-500/40 via-red-500/50 to-transparent blur-sm" />
                    <span className="text-xs font-bold text-white relative z-10">SP METRO</span>
                  </div>

                  <div className="flex flex-col gap-1.5 text-xs bg-black/85 p-2 rounded-xl border border-slate-800">
                    <div className="flex items-center gap-1.5 text-cyan-300">
                      <CloudRain className="w-3.5 h-3.5" />
                      <span>Chuva: 62mm / hora</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-amber-300">
                      <TrendingUp className="w-3.5 h-3.5" />
                      <span>Trânsito: 184 km lentidão</span>
                    </div>
                    <div className="text-[10px] text-slate-300 font-mono">
                      Vento: 48 km/h · Rajadas
                    </div>
                  </div>
                </div>

                <div className="relative z-10 text-[9px] font-mono text-center text-yellow-300 bg-black/80 py-0.5 rounded">
                  DEFESA CIVIL: ESTADO DE ALERTA PARA TRANSBORDAMENTO
                </div>
              </div>
            )}
          </div>

          {/* DUAL-TIER NEWS TICKERS (VIEWER TWEETS + BREAKING HEADLINE) */}
          <div className="relative z-20 flex flex-col shadow-2xl">
            {/* Top Micro-Ticker: Viewer Tweets (Voz das Redes) */}
            <div className="bg-slate-950 border-t border-blue-500/40 py-0.5 px-2 flex items-center gap-1.5 text-[9px] text-slate-300">
              <span className="text-sky-400 font-bold shrink-0 flex items-center gap-1">
                <MessageSquare className="w-2.5 h-2.5" />
                #RedeBrasilis:
              </span>
              <span className="truncate text-slate-200 italic font-medium">
                {viewerTweets[tweetIndex]}
              </span>
            </div>

            {/* Bottom Urgent Ticker: Breaking News Headlines */}
            <div className="bg-red-700 text-white flex items-center">
              <span className="bg-black text-amber-400 font-black px-2 py-1 text-[9px] tracking-wider uppercase shrink-0 flex items-center gap-1 animate-pulse">
                <AlertOctagon className="w-3 h-3 text-red-500" />
                URGENTE
              </span>
              <div className="overflow-hidden whitespace-nowrap py-1 px-2 text-[10px] sm:text-xs font-semibold flex-1">
                <span className="animate-marquee inline-block">
                  {newsHeadlines[dialogueIndex]}
                </span>
              </div>
            </div>
          </div>
        </div>
      );
    }

    // REALITY SHOW
    if (genre === 'reality') {
      return (
        <div className="w-full h-full relative overflow-hidden flex flex-col justify-between bg-gradient-to-b from-purple-950 via-slate-900 to-slate-950">
          <div className="relative z-10 flex items-center justify-between p-2">
            <span className="px-1.5 py-0.5 rounded bg-gradient-to-r from-purple-600 to-pink-600 text-white font-black text-[9px] tracking-wider uppercase">
              CASA DOS FAMOSOS · ELIMINAÇÃO
            </span>
            <span className="text-[9px] font-mono text-purple-300 bg-black/80 px-1.5 py-0.5 rounded">
              CAM CASA 0{cameraAngle}
            </span>
          </div>

          <div className="relative z-10 flex items-center justify-center gap-3 my-auto px-4">
            <div className="flex flex-col items-center bg-black/60 p-2 rounded-xl border border-purple-500/40">
              <span className="text-3xl sm:text-4xl">👁️</span>
              <span className="text-[9px] font-bold text-amber-400 mt-1">EM VOTAÇÃO</span>
              <span className="text-xs font-mono font-bold text-white">48.2%</span>
            </div>
            <div className="flex flex-col items-center bg-black/60 p-2 rounded-xl border border-pink-500/40">
              <span className="text-3xl sm:text-4xl">😱</span>
              <span className="text-[9px] font-bold text-pink-400 mt-1">EM VOTAÇÃO</span>
              <span className="text-xs font-mono font-bold text-white">51.8%</span>
            </div>
          </div>

          <div className="relative z-10 bg-black/85 border-t border-purple-500/30 p-1.5 text-center">
            <span className="text-[10px] sm:text-xs text-purple-200 font-bold">
              Votação recorde no portal! Quem deve deixar o confinamento hoje?
            </span>
          </div>
        </div>
      );
    }

    // AUDITÓRIO / GAME SHOW
    if (genre === 'auditorio') {
      return (
        <div className="w-full h-full relative overflow-hidden flex flex-col justify-between bg-gradient-to-b from-yellow-950 via-amber-900/40 to-slate-950">
          <div className="relative z-10 flex items-center justify-between p-2">
            <span className="px-1.5 py-0.5 rounded bg-yellow-500 text-slate-950 font-black text-[9px] tracking-wider uppercase">
              SHOW DE AUDITÓRIO
            </span>
            <span className="text-[9px] font-mono text-yellow-300 bg-black/80 px-1.5 py-0.5 rounded">
              PALCO PRINCIPAL
            </span>
          </div>

          <div className="relative z-10 flex flex-col items-center justify-center my-auto">
            <div className="flex items-center gap-2">
              <span className="text-3xl sm:text-4xl animate-bounce">🕺</span>
              <span className="text-4xl sm:text-5xl">🎤</span>
              <span className="text-3xl sm:text-4xl animate-bounce">💃</span>
            </div>
            <div className="mt-1 px-3 py-0.5 rounded-full bg-black/80 border border-yellow-400/40 text-[10px] text-yellow-300 font-bold">
              {currentTalent?.name || 'Grande Apresentador'}
            </div>
          </div>

          <div className="relative z-10 bg-black/85 border-t border-yellow-500/30 p-1.5 text-center flex items-center justify-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400 animate-spin" />
            <span className="text-[10px] sm:text-xs text-yellow-300 font-bold">
              Quem quer dinheiro?! A caravana do auditório está pegando fogo!
            </span>
          </div>
        </div>
      );
    }

    // DESENHO / ANIME
    if (genre === 'desenho') {
      return (
        <div className="w-full h-full relative overflow-hidden flex flex-col justify-between bg-gradient-to-b from-sky-900 via-indigo-950 to-slate-950">
          <div className="relative z-10 flex items-center justify-between p-2">
            <span className="px-1.5 py-0.5 rounded bg-sky-500 text-slate-950 font-black text-[9px] uppercase tracking-wider">
              CLUBE DA ANIMAÇÃO
            </span>
            <span className="text-[9px] font-mono text-sky-300 bg-black/80 px-1.5 py-0.5 rounded">
              ANIME / CARTOON
            </span>
          </div>

          <div className="relative z-10 flex items-center justify-center gap-4 my-auto">
            <span className="text-4xl sm:text-5xl animate-pulse">⚡</span>
            <span className="text-4xl sm:text-5xl">🥋</span>
            <span className="text-4xl sm:text-5xl animate-spin">🌀</span>
          </div>

          <div className="relative z-10 bg-black/85 border-t border-sky-500/30 p-1.5 text-center">
            <span className="text-[10px] sm:text-xs text-sky-300 font-bold">
              Poder supremo desbloqueado! A batalha decisiva começou!
            </span>
          </div>
        </div>
      );
    }

    // CINEMA / FILME
    if (genre === 'filme') {
      return (
        <div className="w-full h-full relative overflow-hidden flex flex-col justify-between bg-black">
          <div className="h-4 bg-black w-full border-b border-stone-800" />
          <div className="relative z-10 flex items-center justify-center gap-3 my-auto">
            <span className="text-4xl sm:text-5xl">💥</span>
            <span className="text-4xl sm:text-5xl">🚁</span>
            <span className="text-4xl sm:text-5xl">🕶️</span>
          </div>
          <div className="relative z-10 bg-black/90 p-1.5 text-center border-t border-stone-800">
            <span className="text-[10px] sm:text-xs text-amber-300 font-bold uppercase tracking-widest font-mono">
              SESSÃO DE GALA · FILME DE AÇÃO SUPREMA
            </span>
          </div>
          <div className="h-4 bg-black w-full border-t border-stone-800" />
        </div>
      );
    }

    // ESPORTE / FUTEBOL
    return (
      <div className="w-full h-full relative overflow-hidden flex flex-col justify-between bg-gradient-to-b from-emerald-950 via-slate-900 to-slate-950">
        <div className="relative z-10 flex items-center justify-between p-2">
          <span className="px-1.5 py-0.5 rounded bg-emerald-600 text-white font-black text-[9px] uppercase tracking-wider">
            FUTEBOL BRASILIS
          </span>
          <div className="px-2 py-0.5 rounded bg-black/80 border border-emerald-500/40 text-[10px] font-mono font-bold text-white flex items-center gap-2">
            <span>FLA 2</span>
            <span className="text-emerald-400">×</span>
            <span>1 COR</span>
            <span className="text-amber-400 font-mono text-[9px]">78&apos;</span>
          </div>
        </div>

        <div className="relative z-10 flex items-center justify-center gap-4 my-auto">
          <span className="text-4xl sm:text-5xl">⚽</span>
          <span className="text-4xl sm:text-5xl animate-bounce">🥅</span>
        </div>

        <div className="relative z-10 bg-black/85 border-t border-emerald-500/30 p-1.5 text-center">
          <span className="text-[10px] sm:text-xs text-emerald-300 font-bold">
            Bola na trave! A torcida vai à loucura na grande final!
          </span>
        </div>
      </div>
    );
  };

  // Renders competitor TV signal
  const renderRivalChannelContent = (rivalId: 'soberana' | 'popular' | 'canal-viva') => {
    const rival = rivals.find((r) => r.id === rivalId);
    const rivalShow: RivalShowInfo =
      RIVAL_PROGRAMMING[rivalId]?.[currentSlot.id] || {
        title: rival?.currentShow || 'Transmissão Concorrente',
        genre: 'Variedades',
        ratingBase: 12,
        hostName: 'Apresentador Oficial',
        subtitle: 'Líder em audiência nesta faixa horária.',
        sceneType: 'novela_luxo',
      };

    const sceneStyles: Record<string, { bg: string; emoji: string }> = {
      novela_luxo: { bg: 'bg-gradient-to-b from-stone-900 via-amber-950/40 to-stone-950', emoji: '🎭' },
      jornal_globo: { bg: 'bg-gradient-to-b from-blue-950 via-slate-900 to-slate-950', emoji: '🎙️' },
      policial_sensacional: { bg: 'bg-gradient-to-b from-red-950 via-slate-900 to-slate-950', emoji: '🚨' },
      auditorio_povo: { bg: 'bg-gradient-to-b from-yellow-950 via-amber-900/40 to-slate-950', emoji: '🎤' },
      futebol_mesa: { bg: 'bg-gradient-to-b from-emerald-950 via-slate-900 to-slate-950', emoji: '⚽' },
      desenho_retro: { bg: 'bg-gradient-to-b from-sky-900 via-indigo-950 to-slate-950', emoji: '⚡' },
      filme_hollywood: { bg: 'bg-black', emoji: '🎬' },
    };

    const style = sceneStyles[rivalShow.sceneType] || { bg: 'bg-slate-900', emoji: '📺' };

    return (
      <div className={`w-full h-full relative overflow-hidden flex flex-col justify-between p-2.5 ${style.bg}`}>
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: rival?.color || '#fff' }} />
            <span className="px-1.5 py-0.5 rounded bg-black/80 text-white font-bold text-[9px] uppercase tracking-wider">
              {rival?.name || 'CONCORRENTE'}
            </span>
          </div>
          <span className="text-[9px] font-mono font-bold text-amber-300 bg-black/80 px-1.5 py-0.5 rounded">
            IBOPE: {rival?.rating.toFixed(1)} pts
          </span>
        </div>

        <div className="relative z-10 my-auto text-center px-3">
          <div className="text-3xl sm:text-4xl mb-1">{style.emoji}</div>
          <h3 className="text-xs sm:text-sm font-extrabold text-white drop-shadow">
            {rivalShow.title}
          </h3>
          <p className="text-[10px] text-amber-200/90 font-medium mt-0.5">
            Com {rivalShow.hostName}
          </p>
          <div className="mt-1.5 inline-block px-2 py-0.5 rounded-full bg-black/60 border border-white/20 text-[9px] text-slate-200">
            {rivalShow.subtitle}
          </div>
        </div>

        <div className="relative z-10 bg-black/80 py-1 px-2 text-center text-[9px] font-mono text-slate-300 rounded flex items-center justify-between">
          <span>SINAL CONCORRENTE MONITORADO</span>
          <span className="text-amber-400 font-bold">Gênero: {rivalShow.genre}</span>
        </div>
      </div>
    );
  };

  // Multiview Mosaic 4 Screens
  const renderMultiviewMosaic = () => {
    return (
      <div className="w-full h-full grid grid-cols-2 grid-rows-2 gap-1 p-1 bg-black">
        {/* Screen 1: Player */}
        <div
          onClick={() => handleTuneChannel('player')}
          className="relative bg-slate-900 border border-amber-500/50 rounded overflow-hidden cursor-pointer group"
        >
          <div className="absolute top-1 left-1 z-20 px-1 rounded bg-black/80 text-[8px] font-bold text-amber-400">
            13: VOCÊ ({liveIbope.toFixed(1)} pts)
          </div>
          <div className="w-full h-full scale-90 pointer-events-none">
            {renderPlayerChannelContent(true)}
          </div>
        </div>

        {/* Screen 2: Soberana */}
        <div
          onClick={() => handleTuneChannel('soberana')}
          className="relative bg-slate-900 border border-blue-500/50 rounded overflow-hidden cursor-pointer group"
        >
          <div className="absolute top-1 left-1 z-20 px-1 rounded bg-black/80 text-[8px] font-bold text-blue-400">
            04: SOBERANA
          </div>
          <div className="w-full h-full scale-90 pointer-events-none">
            {renderRivalChannelContent('soberana')}
          </div>
        </div>

        {/* Screen 3: Popular */}
        <div
          onClick={() => handleTuneChannel('popular')}
          className="relative bg-slate-900 border border-yellow-500/50 rounded overflow-hidden cursor-pointer group"
        >
          <div className="absolute top-1 left-1 z-20 px-1 rounded bg-black/80 text-[8px] font-bold text-yellow-400">
            07: POPULAR
          </div>
          <div className="w-full h-full scale-90 pointer-events-none">
            {renderRivalChannelContent('popular')}
          </div>
        </div>

        {/* Screen 4: Viva */}
        <div
          onClick={() => handleTuneChannel('canal-viva')}
          className="relative bg-slate-900 border border-emerald-500/50 rounded overflow-hidden cursor-pointer group"
        >
          <div className="absolute top-1 left-1 z-20 px-1 rounded bg-black/80 text-[8px] font-bold text-emerald-400">
            11: VIVA BRASIL
          </div>
          <div className="w-full h-full scale-90 pointer-events-none">
            {renderRivalChannelContent('canal-viva')}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full h-full flex flex-col gap-2.5 select-none pb-4">
      {/* 1. Horizontal Scrollable Channel Tuner (Touch-First Pills) */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 shrink-0">
        <button
          onClick={() => handleTuneChannel('player')}
          className={`min-h-[44px] px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap active:scale-95 ${
            tunedChannel === 'player'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-950/40 ring-2 ring-amber-300'
              : 'bg-slate-900 border border-slate-800 text-slate-300'
          }`}
        >
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
          <span>Canal 13 (Sua TV)</span>
        </button>

        <button
          onClick={() => handleTuneChannel('soberana')}
          className={`min-h-[44px] px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap active:scale-95 ${
            tunedChannel === 'soberana'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-950/40 ring-2 ring-blue-400'
              : 'bg-slate-900 border border-slate-800 text-slate-400'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-blue-500" />
          <span>Canal 04: Soberana</span>
        </button>

        <button
          onClick={() => handleTuneChannel('popular')}
          className={`min-h-[44px] px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap active:scale-95 ${
            tunedChannel === 'popular'
              ? 'bg-yellow-500 text-slate-950 shadow-md shadow-yellow-950/40 ring-2 ring-yellow-300'
              : 'bg-slate-900 border border-slate-800 text-slate-400'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-yellow-400" />
          <span>Canal 07: Popular</span>
        </button>

        <button
          onClick={() => handleTuneChannel('canal-viva')}
          className={`min-h-[44px] px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap active:scale-95 ${
            tunedChannel === 'canal-viva'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40 ring-2 ring-emerald-400'
              : 'bg-slate-900 border border-slate-800 text-slate-400'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span>Canal 11: Viva</span>
        </button>

        <button
          onClick={() => handleTuneChannel('multiview')}
          className={`min-h-[44px] px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 active:scale-95 ${
            tunedChannel === 'multiview'
              ? 'bg-purple-600 text-white shadow-md ring-2 ring-purple-400'
              : 'bg-slate-900 border border-purple-500/40 text-purple-300'
          }`}
        >
          <Grid className="w-3.5 h-3.5" />
          <span>Mosaico 4 Telas</span>
        </button>
      </div>

      {/* 2. Main TV Monitor (16:9 Aspect Video Screen) */}
      <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col shadow-2xl relative shrink-0">
        {/* Monitor Header with Tally Lamp */}
        <div className="bg-slate-950 px-3 py-1.5 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 shadow-[0_0_8px_#ef4444]" />
            <span className="font-bold text-white text-[11px] truncate max-w-[190px]">
              {tunedChannel === 'player'
                ? stationName
                : tunedChannel === 'multiview'
                ? 'MOSAICO MULTIVIEW'
                : `SINTONIA: ${
                    tunedChannel === 'soberana'
                      ? 'REDE SOBERANA'
                      : tunedChannel === 'popular'
                      ? 'TV POPULAR'
                      : 'CANAL VIVA BRASIL'
                  }`}
            </span>
          </div>
          <div className="flex items-center gap-2 font-mono text-[10px] text-slate-400">
            {tunedChannel === 'player' ? (
              <span className="text-emerald-400 font-bold">
                QUALIDADE: {currentProgram?.quality || 0}%
              </span>
            ) : (
              <span className="text-amber-400 font-bold">ESPIÃO</span>
            )}
          </div>
        </div>

        {/* Screen Area with CRT scanline simulation (16:9 ratio) */}
        <div className="relative w-full aspect-video max-h-[260px] sm:max-h-[300px] tv-screen tv-scanlines tv-vignette bg-slate-950">
          {switcherEffect && (
            <div className="absolute inset-0 z-30 bg-white/40 mix-blend-overlay pointer-events-none" />
          )}
          {tunedChannel === 'player' && renderPlayerChannelContent()}
          {tunedChannel === 'soberana' && renderRivalChannelContent('soberana')}
          {tunedChannel === 'popular' && renderRivalChannelContent('popular')}
          {tunedChannel === 'canal-viva' && renderRivalChannelContent('canal-viva')}
          {tunedChannel === 'multiview' && renderMultiviewMosaic()}
        </div>

        {/* Program Info Bar at bottom of Monitor */}
        <div className="bg-slate-950 px-3 py-1.5 border-t border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 truncate max-w-[65%]">
            {tunedChannel === 'player' ? (
              <span className="font-bold text-white text-xs truncate">
                {currentProgram?.title || 'Sem atração no ar'}
              </span>
            ) : (
              <span className="text-slate-300 text-[11px] truncate">
                Acompanhando concorrente
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5 font-mono text-amber-400 font-bold text-xs shrink-0">
            <span className="text-slate-400 text-[10px]">IBOPE:</span>
            <span className="text-sm tabular-nums">{liveIbope.toFixed(1)} pts</span>
          </div>
        </div>
      </div>

      {/* Dynamic Journalism Live Feed Selector Bar (When Journalism is on air) */}
      {currentProgram?.genre === 'jornalismo' && tunedChannel === 'player' && (
        <div className="bg-blue-950/40 border border-blue-500/40 rounded-2xl p-2 flex flex-col gap-1.5 shrink-0">
          <div className="flex items-center justify-between text-[10px] font-bold text-blue-300">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              Controle de Câmeras do Jornalismo:
            </span>
            <span className="text-cyan-400 font-mono">AO VIVO</span>
          </div>

          <div className="grid grid-cols-4 gap-1">
            <button
              onClick={() => {
                soundFx.playStaticCut();
                setNewsMode('bancada');
              }}
              className={`min-h-[40px] px-2 py-1.5 rounded-xl text-[11px] font-bold transition-all flex flex-col items-center justify-center cursor-pointer active:scale-95 ${
                newsMode === 'bancada'
                  ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-400'
                  : 'bg-slate-950 border border-slate-800 text-slate-300'
              }`}
            >
              <span>🎙️ Bancada</span>
            </button>

            <button
              onClick={() => {
                soundFx.playStaticCut();
                setNewsMode('reporter');
              }}
              className={`min-h-[40px] px-2 py-1.5 rounded-xl text-[11px] font-bold transition-all flex flex-col items-center justify-center cursor-pointer active:scale-95 ${
                newsMode === 'reporter'
                  ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-400'
                  : 'bg-slate-950 border border-slate-800 text-slate-300'
              }`}
            >
              <span>🎤 Link Rua</span>
            </button>

            <button
              onClick={() => {
                soundFx.playStaticCut();
                setNewsMode('aguia');
              }}
              className={`min-h-[40px] px-2 py-1.5 rounded-xl text-[11px] font-bold transition-all flex flex-col items-center justify-center cursor-pointer active:scale-95 ${
                newsMode === 'aguia'
                  ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-400'
                  : 'bg-slate-950 border border-slate-800 text-slate-300'
              }`}
            >
              <span>🚁 Águia 13</span>
            </button>

            <button
              onClick={() => {
                soundFx.playStaticCut();
                setNewsMode('radar');
              }}
              className={`min-h-[40px] px-2 py-1.5 rounded-xl text-[11px] font-bold transition-all flex flex-col items-center justify-center cursor-pointer active:scale-95 ${
                newsMode === 'radar'
                  ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-400'
                  : 'bg-slate-950 border border-slate-800 text-slate-300'
              }`}
            >
              <span>🌦️ Radar</span>
            </button>
          </div>
        </div>
      )}

      {/* 3. Thumb-Zone Control Desk (2x2 Big Touch Buttons for Switcher) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2.5 flex flex-col gap-2 shrink-0">
        <div className="flex items-center justify-between text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
          <span className="flex items-center gap-1 text-slate-300">
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            Mesa de Corte & Switcher Técnico
          </span>
          <span className="font-mono text-emerald-400">
            {currentSponsor ? `+R$ ${currentSponsor.payoutPerSlot.toLocaleString('pt-BR')}` : 'Sem Patrocínio'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {/* Button 1: Entrar Comercial */}
          <button
            onClick={handleCommercialClick}
            disabled={commercialCooldown > 0 || !currentSponsor}
            className={`min-h-[50px] p-2 rounded-xl border text-xs font-bold tracking-wide uppercase transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer active:scale-95 ${
              commercialCooldown > 0 || !currentSponsor
                ? 'bg-slate-950 border-slate-800 text-slate-600 cursor-not-allowed opacity-60'
                : 'bg-emerald-950/60 hover:bg-emerald-900 border-emerald-500/60 text-emerald-300 shadow-md shadow-emerald-950/50'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>Entrar Comercial</span>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 font-normal">
              {commercialCooldown > 0
                ? `Aguarde ${commercialCooldown}s`
                : currentSponsor
                ? 'Liberar Break (+R$)'
                : 'Sem patrocinador'}
            </span>
          </button>

          {/* Button 2: Plantão Urgente */}
          <button
            onClick={handlePlantaoClick}
            disabled={plantaoCooldown > 0}
            className={`min-h-[50px] p-2 rounded-xl border text-xs font-bold tracking-wide uppercase transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer active:scale-95 ${
              plantaoCooldown > 0
                ? 'bg-slate-950 border-slate-800 text-slate-600 cursor-not-allowed opacity-60'
                : 'bg-red-950/60 hover:bg-red-900 border-red-500/60 text-red-300 shadow-md shadow-red-950/50 animate-pulse'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <AlertOctagon className="w-4 h-4 text-red-400" />
              <span>Plantão Urgente</span>
            </div>
            <span className="text-[10px] font-mono text-red-400 font-normal">
              {plantaoCooldown > 0 ? `Recarga ${plantaoCooldown}s` : 'Vinheta Clássica (+IBOPE)'}
            </span>
          </button>

          {/* Button 3: Cortar Câmera */}
          <button
            onClick={handleSwitchCamera}
            className="min-h-[50px] p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-700 text-slate-300 active:scale-95 text-xs font-bold tracking-wide uppercase transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer"
          >
            <div className="flex items-center gap-1.5">
              <Tv className="w-4 h-4 text-amber-400" />
              <span>Cortar Câmera</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400 font-normal">
              Ângulo 0{cameraAngle} Ativo
            </span>
          </button>

          {/* Button 4: Soltar Palmas */}
          <button
            onClick={handleTriggerApplause}
            disabled={applauseCooldown}
            className={`min-h-[50px] p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-700 text-slate-300 active:scale-95 text-xs font-bold tracking-wide uppercase transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
              applauseCooldown ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-yellow-400" />
              <span>Soltar Palmas</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400 font-normal">
              {applauseCooldown ? 'Aguarde som...' : 'Calor do Auditório'}
            </span>
          </button>
        </div>
      </div>

      {/* 4. Slot Progress & Advance Speed Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2.5 flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => {
              soundFx.playClick();
              onChangeSimSpeed(1);
            }}
            className={`min-h-[38px] px-2.5 text-xs font-mono font-bold rounded-lg cursor-pointer transition-colors ${
              simSpeed === 1 && !isPaused ? 'bg-amber-500 text-slate-950' : 'text-slate-400'
            }`}
          >
            1x
          </button>
          <button
            onClick={() => {
              soundFx.playClick();
              onChangeSimSpeed(2);
            }}
            className={`min-h-[38px] px-2.5 text-xs font-mono font-bold rounded-lg cursor-pointer transition-colors ${
              simSpeed === 2 && !isPaused ? 'bg-amber-500 text-slate-950' : 'text-slate-400'
            }`}
          >
            2x
          </button>
          <button
            onClick={() => {
              soundFx.playClick();
              onChangeSimSpeed(4);
            }}
            className={`min-h-[38px] px-2.5 text-xs font-mono font-bold rounded-lg cursor-pointer transition-colors ${
              simSpeed === 4 && !isPaused ? 'bg-amber-500 text-slate-950' : 'text-slate-400'
            }`}
          >
            4x
          </button>
        </div>

        <button
          onClick={() => {
            soundFx.playClick();
            onFastForwardSlot();
          }}
          className="min-h-[44px] flex-1 px-3 py-2 rounded-xl bg-blue-600/40 hover:bg-blue-600/60 border border-blue-500/50 text-blue-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
        >
          <FastForward className="w-4 h-4 text-blue-300" />
          <span>Avançar Bloco</span>
        </button>
      </div>

      {/* 5. Real-Time IBOPE Ranking List (Touch to Tune) */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-3 flex flex-col gap-2.5 shadow-xl shrink-0">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-white">IBOPE ao Vivo (Toque para Sintonizar)</h3>
          </div>
          <div className="text-xs font-bold">
            {playerRank === 1 ? (
              <span className="text-emerald-400 font-extrabold">🏆 1º LUGAR</span>
            ) : (
              <span className="text-amber-400">{playerRank}º LUGAR</span>
            )}
          </div>
        </div>

        {/* Player Network Bar */}
        <div
          onClick={() => handleTuneChannel('player')}
          className={`p-2 rounded-xl border transition-all cursor-pointer active:scale-98 ${
            tunedChannel === 'player'
              ? 'bg-amber-500/20 border-amber-400 shadow'
              : 'bg-slate-950/80 border-amber-500/30'
          }`}
        >
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="font-bold text-amber-300 flex items-center gap-1.5">
              <span>{stationName} (Você)</span>
              {tunedChannel === 'player' && (
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500 text-slate-950 font-black">
                  NO AR
                </span>
              )}
            </span>
            <span className="font-mono font-bold text-amber-300 tabular-nums">
              {liveIbope.toFixed(1)} pts
            </span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-500"
              style={{ width: `${Math.min(100, (liveIbope / 35) * 100)}%` }}
            />
          </div>
        </div>

        {/* Rival Networks */}
        {rivals.map((rival) => {
          const channelKey = rival.id as TunedChannel;
          const isTuned = tunedChannel === channelKey;

          return (
            <div
              key={rival.id}
              onClick={() => handleTuneChannel(channelKey)}
              className={`p-2 rounded-xl border transition-all cursor-pointer active:scale-98 ${
                isTuned
                  ? 'border-white bg-slate-950 shadow-md ring-1 ring-white/50'
                  : 'border-slate-800 bg-slate-950/60'
              }`}
            >
              <div className="flex items-center justify-between text-xs mb-1">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: rival.color }} />
                  <span className="text-slate-300 font-medium text-xs">{rival.name}</span>
                  {isTuned && (
                    <span className="text-[9px] px-1 py-0.2 rounded bg-white text-slate-950 font-bold">
                      ASSISTINDO
                    </span>
                  )}
                </div>
                <span className="font-mono text-slate-400 tabular-nums text-xs">
                  {rival.rating.toFixed(1)} pts
                </span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, (rival.rating / 35) * 100)}%`,
                    backgroundColor: rival.color,
                  }}
                />
              </div>
              <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                <span className="truncate max-w-[75%]">{rival.currentShow}</span>
                <span className="text-amber-400/90 text-[9px] font-semibold">Assistir TV &rarr;</span>
              </div>
            </div>
          );
        })}

        {/* PVW: Próxima Atração Compact Card */}
        {nextProgram && (
          <div className="mt-1 p-2 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
            <div>
              <span className="text-[9px] font-bold text-amber-400 uppercase tracking-wider block">
                A Seguir na Grade
              </span>
              <span className="text-white font-semibold truncate block max-w-[200px]">
                {nextProgram.title}
              </span>
            </div>
            <span className="font-mono text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
              Q: {nextProgram.quality}%
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
