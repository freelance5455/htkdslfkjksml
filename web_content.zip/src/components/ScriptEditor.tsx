import React, { useState } from 'react';
import { ScriptScene } from '../data/scriptData';
import {
  Edit3,
  Copy,
  Check,
  RotateCcw,
  Download,
  Mic,
  Clock,
  FileText,
  Sparkles,
} from 'lucide-react';
import { calculateEstimatedDuration, formatTime } from '../utils/scriptUtils';

interface ScriptEditorProps {
  scenes: ScriptScene[];
  onUpdateSceneText: (sceneId: string, newText: string) => void;
  onResetOriginal: () => void;
  onNavigateToTTS: () => void;
}

export const ScriptEditor: React.FC<ScriptEditorProps> = ({
  scenes,
  onUpdateSceneText,
  onResetOriginal,
  onNavigateToTTS,
}) => {
  const [activeTab, setActiveTab] = useState<string>('scene');
  const [selectedSceneId, setSelectedSceneId] = useState<string>(scenes[0].id);
  const [copied, setCopied] = useState<boolean>(false);

  const activeScene = scenes.find((s) => s.id === selectedSceneId) || scenes[0];

  const fullText = scenes
    .map(
      (s) =>
        `### [Scene #${s.order}: ${s.titleBn}]\n${s.textBn}`
    )
    .join('\n\n');

  const totalWords = scenes.reduce(
    (acc, s) => acc + s.textBn.split(/\s+/).filter(Boolean).length,
    0
  );
  const totalDuration = calculateEstimatedDuration(
    scenes.map((s) => s.textBn).join(' ')
  );

  const handleCopyFull = () => {
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadText = () => {
    const blob = new Blob([fullText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Top_5_In_Demand_Skills_2027_Bengali_Script.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 pb-28">
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-slate-900 border border-emerald-800/40 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono mb-2">
              <Edit3 className="w-3.5 h-3.5 text-emerald-400" />
              স্ক্রিপ্ট এডিটর ও কাস্টমাইজেশন
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-bengali">
              ভিডিও চিত্রনাট্য এডিটর ও এক্সপোর্ট
            </h1>
            <p className="mt-1 text-sm text-slate-300 font-bengali">
              ভিডিওর প্রতিটি দৃশ্যের ডায়লগ নিজের পছন্দমতো কাস্টমাইজ করুন এবং সাথে সাথেই সংশোধিত ভয়েসওভার তৈরি করুন।
            </p>
          </div>

          <div className="flex items-center gap-3 font-mono text-xs bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <div>
              <span className="text-slate-400 block text-[10px]">মোট স্ক্রিপ্ট সময়</span>
              <span className="text-emerald-400 font-bold text-sm">
                ~{formatTime(totalDuration)} ({totalWords} শব্দ)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main editor area */}
      <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-4">
        {/* Top controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
          {/* Scene selector pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {scenes.map((s) => (
              <button
                key={s.id}
                onClick={() => setSelectedSceneId(s.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bengali transition cursor-pointer whitespace-nowrap ${
                  selectedSceneId === s.id
                    ? 'bg-emerald-600 text-white font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                #{s.order} {s.titleBn.split(':')[0]}
              </button>
            ))}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyFull}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition cursor-pointer"
              title="Copy All Script"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span className="font-bengali">কপি করুন</span>
            </button>

            <button
              onClick={handleDownloadText}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs transition cursor-pointer"
              title="Download TXT"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="font-mono">.txt ডাউনলোড</span>
            </button>

            <button
              onClick={onResetOriginal}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs transition cursor-pointer"
              title="Reset to Original"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline font-bengali">মূল স্ক্রিপ্টে রিসেট</span>
            </button>
          </div>
        </div>

        {/* Text Area */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-bengali font-bold text-slate-200">
              {activeScene.titleBn}
            </span>
            <span className="font-mono text-emerald-400">
              {activeScene.textBn.split(/\s+/).filter(Boolean).length} শব্দ • ~{formatTime(calculateEstimatedDuration(activeScene.textBn))}
            </span>
          </div>

          <textarea
            value={activeScene.textBn}
            onChange={(e) => onUpdateSceneText(activeScene.id, e.target.value)}
            rows={10}
            className="w-full p-4 rounded-xl bg-slate-950/80 border border-slate-700/80 text-slate-100 font-bengali text-base sm:text-lg leading-relaxed focus:outline-none focus:ring-2 focus:ring-emerald-500 transition resize-y font-medium"
          />
        </div>

        {/* Bottom CTA to trigger TTS on edited text */}
        <div className="flex flex-col sm:flex-row items-center justify-between pt-3 gap-3">
          <p className="text-xs text-slate-400 font-bengali">
            💡 টিপস: আপনি নিজের মতো কিছু লাইন পরিবর্তন করলে তা টেলিপম্পটার এবং ভয়েসওভার মডিউলে তাৎক্ষণিকভাবে আপডেট হয়ে যাবে।
          </p>

          <button
            onClick={onNavigateToTTS}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-lg transition cursor-pointer"
          >
            <Mic className="w-4 h-4" />
            <span className="font-bengali">এডিট করা স্ক্রিপ্ট নিয়ে ভয়েস স্টুডিওতে যান</span>
          </button>
        </div>
      </div>
    </div>
  );
};
