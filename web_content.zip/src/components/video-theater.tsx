import { Maximize, X } from "lucide-react";
import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";

export function VideoTheater({
  videoId,
  title,
  onClose,
}: {
  videoId: string;
  title?: string;
  onClose: () => void;
}) {
  const shell = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(videoId)}?autoplay=1&mute=0&loop=1&playlist=${encodeURIComponent(videoId)}&rel=0&modestbranding=1&playsinline=1&fs=1&vq=hd2160&hd=1&controls=1`;

  return createPortal(
    <div className="fixed inset-0 z-[80] flex flex-col bg-black">
      <div className="flex items-center justify-between gap-3 px-3 py-2">
        <p className="min-w-0 flex-1 truncate text-sm text-white">{title || "Video"}</p>
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-full text-white"
          aria-label="Fullscreen"
          onClick={() => {
            const el = shell.current;
            if (!el) return;
            if (document.fullscreenElement) void document.exitFullscreen();
            else void el.requestFullscreen?.();
          }}
        >
          <Maximize className="size-5" />
        </button>
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-full text-white"
          onClick={onClose}
          aria-label="Close"
        >
          <X className="size-5" />
        </button>
      </div>
      <div ref={shell} className="relative min-h-0 flex-1 bg-black">
        <iframe
          title={title || "Video"}
          className="absolute inset-0 size-full max-w-none border-0"
          src={src}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
          allowFullScreen
        />
      </div>
    </div>,
    document.body,
  );
}
