import React, {useEffect, useRef} from 'react';
import type {RadarBlip} from '../game/types';

interface RadarMinimapProps {
  playerX: number;
  playerZ: number;
  playerHeading: number;
  blips: RadarBlip[];
  wantedLevel: number;
}

const ROAD_LINES = [-120, -60, 0, 60, 120];

export const RadarMinimap: React.FC<RadarMinimapProps> = ({
  playerX,
  playerZ,
  playerHeading,
  blips,
  wantedLevel,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    const scale = 0.44;

    ctx.clearRect(0, 0, w, h);

    // Classic GTA V GPS dark asphalt backdrop with police search tint when wanted
    const sirenPhase = wantedLevel > 0 ? Math.floor(Date.now() / 320) % 2 : -1;
    ctx.fillStyle =
      sirenPhase === 0 ? '#1b1426' : sirenPhase === 1 ? '#121b2d' : '#111822';
    ctx.fillRect(0, 0, w, h);

    const toRadar = (wx: number, wz: number): [number, number] => [
      w / 2 + (wx - playerX) * scale,
      h / 2 + (wz - playerZ) * scale,
    ];

    // Pacific Ocean west strip & Sandy Shores desert north-east tint
    const [beachX] = toRadar(-120, 0);
    if (beachX > 0) {
      ctx.fillStyle = '#0c2742';
      ctx.fillRect(0, 0, Math.min(w, beachX - 18), h);
    }

    // Draw Los Santos arterial road grid
    ctx.strokeStyle = '#3b485b';
    ctx.lineWidth = 4;
    for (const r of ROAD_LINES) {
      const [rx1, rz1] = toRadar(r, -175);
      const [rx2, rz2] = toRadar(r, 175);
      ctx.beginPath();
      ctx.moveTo(rx1, rz1);
      ctx.lineTo(rx2, rz2);
      ctx.stroke();

      const [hx1, hz1] = toRadar(-175, r);
      const [hx2, hz2] = toRadar(175, r);
      ctx.beginPath();
      ctx.moveTo(hx1, hz1);
      ctx.lineTo(hx2, hz2);
      ctx.stroke();
    }

    // GPS guide line to mission objective
    const missionBlip = blips.find((b) => b.kind === 'mission');
    if (missionBlip) {
      const [mx, my] = toRadar(missionBlip.x, missionBlip.z);
      ctx.strokeStyle = 'rgba(250, 204, 21, 0.55)';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 3]);
      ctx.beginPath();
      ctx.moveTo(w / 2, h / 2);
      ctx.lineTo(mx, my);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw blips (clamped to radar edge for distant objectives)
    for (const b of blips) {
      let [bx, by] = toRadar(b.x, b.z);
      if (b.kind === 'mission') {
        bx = Math.max(8, Math.min(w - 8, bx));
        by = Math.max(8, Math.min(h - 8, by));
      }
      ctx.fillStyle = b.color;
      ctx.beginPath();
      ctx.arc(bx, by, b.kind === 'mission' ? 4.8 : 3, 0, Math.PI * 2);
      ctx.fill();
      if (b.kind === 'mission') {
        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = 1.4;
        ctx.stroke();
      }
    }

    // Center player heading arrow
    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.rotate(-playerHeading + Math.PI);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(0, -6.5);
    ctx.lineTo(4.8, 5);
    ctx.lineTo(0, 2.2);
    ctx.lineTo(-4.8, 5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }, [playerX, playerZ, playerHeading, blips, wantedLevel]);

  return (
    <div
      className={`overflow-hidden border-2 bg-[#0b0f14] ${
        wantedLevel > 0 ? 'border-rose-500/80' : 'border-white/25'
      }`}
    >
      <canvas
        ref={canvasRef}
        width={176}
        height={98}
        className="block h-[76px] w-[136px] sm:h-[98px] sm:w-[176px]"
      />
    </div>
  );
};
