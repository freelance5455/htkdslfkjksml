import React from 'react';
import { soundEngine } from '../../services/audioEngine';
import {
  Download,
  FileArchive,
  Smartphone,
  Globe,
  Save,
  CheckCircle2,
  X,
  ExternalLink,
  Sparkles,
  ShieldCheck,
  Share2
} from 'lucide-react';

interface DownloadModalProps {
  onClose: () => void;
  onDownloadOfflineHtml: () => void;
  onDownloadOfflineZip: () => void;
  onExportSaveJson: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({
  onClose,
  onDownloadOfflineHtml,
  onDownloadOfflineZip,
  onExportSaveJson
}) => {
  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/80 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] relative">
        {/* Sticky Header */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-emerald-300">
              <Download className="w-4 h-4 animate-bounce" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b] flex items-center gap-2">
                <span>Download & Play Offline</span>
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                100% offline standalone files, ZIP packages, and mobile home screen installation.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 overflow-y-auto space-y-4 grow text-xs text-[#d1e6dc]">
          {/* PRIMARY METHOD 1: STANDALONE SINGLE HTML GAME */}
          <div className="bg-gradient-to-br from-[#184838] to-[#0f3427] p-4 rounded-2xl border-2 border-[#e2b054] shadow-lg space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#fce18b] font-dao font-bold text-sm">
                <Globe className="w-4 h-4 text-emerald-400" />
                <span>Method 1: Standalone Single HTML Game (Instant Play)</span>
              </div>
              <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-bold">
                RECOMMENDED
              </span>
            </div>

            <p className="text-[11px] text-[#cbe3d7] leading-relaxed">
              Downloads a single, self-contained file named <strong className="text-[#fce18b]">Amazing-Sect-Cultivation-Offline.html</strong> with the entire game engine, styling, and your current sect save state bundled inside.
            </p>

            <div className="bg-[#09261d]/80 p-2.5 rounded-xl border border-[#1b4b3b] space-y-1 text-[10px] text-[#9fc2b2]">
              <div className="flex items-center gap-1.5 text-emerald-300 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Works on Android, iPhone/iPad, Windows, Mac, & Linux.</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-300 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>No internet, no WiFi, no servers, and no app store required!</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-300 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Auto-saves your progress directly in your local browser storage.</span>
              </div>
            </div>

            <button
              onClick={() => {
                soundEngine.playTalisman();
                onDownloadOfflineHtml();
              }}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg hover:brightness-110 active:scale-98 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Download Standalone HTML Game (.html)</span>
            </button>
          </div>

          {/* PRIMARY METHOD 2: COMPRESSED ZIP ARCHIVE */}
          <div className="bg-[#0b281f] p-4 rounded-2xl border border-emerald-500/50 shadow-md space-y-2.5">
            <div className="flex items-center gap-2 text-emerald-300 font-dao font-bold text-sm">
              <FileArchive className="w-4 h-4 text-emerald-400" />
              <span>Method 2: Compressed ZIP Package (.zip)</span>
            </div>

            <p className="text-[11px] text-[#cbe3d7] leading-relaxed">
              Downloads a compressed archive <strong className="text-emerald-300">Amazing-Sect-Cultivation-Offline-Package.zip</strong> containing:
            </p>

            <ul className="list-disc list-inside space-y-1 text-[10px] text-[#9fc2b2] pl-1">
              <li><strong className="text-white">index.html</strong> — The complete standalone offline game.</li>
              <li><strong className="text-white">save_backup.json</strong> — Your raw sect save archive.</li>
              <li><strong className="text-white">README.txt</strong> — Step-by-step instructions.</li>
            </ul>

            <button
              onClick={() => {
                soundEngine.playFanfare();
                onDownloadOfflineZip();
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-[#14532d] hover:bg-[#166534] text-white border border-[#22c55e]/50 font-dao font-bold text-xs flex items-center justify-center gap-2 shadow-md active:scale-98 transition-all"
            >
              <FileArchive className="w-4 h-4" />
              <span>Download Compressed ZIP Package (.zip)</span>
            </button>
          </div>

          {/* METHOD 3: INSTALL TO PHONE HOME SCREEN (PWA / FULL SCREEN APP) */}
          <div className="bg-[#09261d] p-4 rounded-2xl border border-[#1b4b3b] space-y-3">
            <div className="flex items-center gap-2 text-[#fce18b] font-dao font-bold text-sm">
              <Smartphone className="w-4 h-4 text-[#fce18b]" />
              <span>Method 3: Install as App on Phone (Add to Home Screen)</span>
            </div>

            <p className="text-[11px] text-[#cbe3d7] leading-relaxed">
              You can install this game directly onto your Android or iPhone home screen with its own full-screen app icon:
            </p>

            <div className="space-y-2 text-[10px]">
              {/* Android instructions */}
              <div className="bg-[#123d30] p-2.5 rounded-xl border border-emerald-500/30 space-y-1">
                <span className="text-emerald-300 font-bold block flex items-center gap-1">
                  <span>📱 For Android (Chrome / Brave / Samsung Internet):</span>
                </span>
                <ol className="list-decimal list-inside space-y-0.5 text-[#cbe3d7] pl-1">
                  <li>Tap the <strong>three dots (⋮)</strong> menu in the upper-right corner of your browser.</li>
                  <li>Select <strong>&quot;Install app&quot;</strong> or <strong>&quot;Add to Home screen&quot;</strong>.</li>
                  <li>Confirm by tapping <strong>Install</strong>.</li>
                  <li>The game will appear on your phone screen and opens without address bars!</li>
                </ol>
              </div>

              {/* iOS instructions */}
              <div className="bg-[#123d30] p-2.5 rounded-xl border border-cyan-500/30 space-y-1">
                <span className="text-cyan-300 font-bold block flex items-center gap-1">
                  <span>🍏 For iPhone & iPad (Safari):</span>
                </span>
                <ol className="list-decimal list-inside space-y-0.5 text-[#cbe3d7] pl-1">
                  <li>Tap the <strong>Share</strong> button at the bottom of Safari (<Share2 className="w-3 h-3 inline mx-0.5" /> icon).</li>
                  <li>Scroll down and tap <strong>&quot;Add to Home Screen&quot;</strong>.</li>
                  <li>Tap <strong>Add</strong> in the top-right corner.</li>
                </ol>
              </div>
            </div>
          </div>

          {/* BACKUP SAVE DATA */}
          <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] flex justify-between items-center text-xs">
            <div>
              <span className="font-bold text-white block">Export Save File (.json)</span>
              <span className="text-[10px] text-[#9fc2b2]">Keep a copy of your disciples and sect progress.</span>
            </div>
            <button
              onClick={() => {
                soundEngine.playClick();
                onExportSaveJson();
              }}
              className="py-1.5 px-3 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#86efac] border border-[#22c55e]/40 font-bold text-[11px] flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Backup</span>
            </button>
          </div>
        </div>

        {/* Modal Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80] text-[10px]">Play anywhere · Free & Open Immortal Dao</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
