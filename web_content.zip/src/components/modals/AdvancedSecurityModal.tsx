import React, { useState } from 'react';
import {
  X,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Smartphone,
  Laptop,
  Tablet,
  Globe,
  MapPin,
  Clock,
  LogOut,
  AlertTriangle,
  CheckCircle,
  KeyRound,
  Lock,
  SmartphoneNfc,
  Bell,
  RefreshCw,
  Trash2,
  FileText,
  Key,
  Check,
  Eye,
  EyeOff,
  Sparkles,
} from 'lucide-react';
import { UserProfile, RegisteredDevice, LoginHistoryItem } from '../../types';
import { soundFX } from '../../utils/soundEffects';
import { saveUserProfileToFirestore } from '../../utils/firebaseSync';

interface AdvancedSecurityModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpdateUser: (u: UserProfile) => void;
  showNotification?: (msg: string) => void;
}

export const DEFAULT_DEVICES: RegisteredDevice[] = [
  {
    id: 'dev-current',
    deviceName: 'iPhone 15 Pro Max',
    deviceType: 'mobile',
    browser: 'Safari Mobile 18.0',
    os: 'iOS 18.1',
    ipAddress: '192.168.1.104',
    location: 'دبي، الإمارات العربية المتحدة 🇦🇪',
    lastActive: 'الآن (متصل حالياً)',
    isCurrent: true,
  },
  {
    id: 'dev-macbook',
    deviceName: 'MacBook Pro 16" (M3 Max)',
    deviceType: 'desktop',
    browser: 'Google Chrome 129.0',
    os: 'macOS Sonoma 14.6',
    ipAddress: '82.102.18.24',
    location: 'دبي، الإمارات العربية المتحدة 🇦🇪',
    lastActive: 'منذ ساعتين (اليوم 09:30)',
    isCurrent: false,
  },
  {
    id: 'dev-samsung',
    deviceName: 'Samsung Galaxy Tab S9',
    deviceType: 'tablet',
    browser: 'Samsung Internet 24.0',
    os: 'Android 14',
    ipAddress: '185.120.44.12',
    location: 'الرياض، المملكة العربية السعودية 🇸🇦',
    lastActive: 'أمس (18:45)',
    isCurrent: false,
  },
  {
    id: 'dev-suspicious',
    deviceName: 'Linux Terminal / Unknown Agent',
    deviceType: 'desktop',
    browser: 'Headless Firefox 115',
    os: 'Linux x86_64',
    ipAddress: '185.220.101.5',
    location: 'فرانكفورت، ألمانيا 🇩🇪',
    lastActive: 'منذ 3 أيام (03:12 ص)',
    isCurrent: false,
    isSuspicious: true,
    suspicionReason: 'محاولة دخول غير معتادة من خادم وكيل (Proxy / VPN غير معروف)',
  },
];

const DEFAULT_LOGIN_HISTORY: LoginHistoryItem[] = [
  {
    id: 'log-1',
    ipAddress: '192.168.1.104',
    device: 'iPhone 15 Pro Max (Safari)',
    location: 'دبي، الإمارات 🇦🇪',
    timestamp: 'اليوم، 10:15 ص',
    status: 'SUCCESS',
    actionTaken: 'تسجيل دخول ناجح وفتح جلسة آمنة',
  },
  {
    id: 'log-2',
    ipAddress: '82.102.18.24',
    device: 'MacBook Pro (Chrome)',
    location: 'دبي، الإمارات 🇦🇪',
    timestamp: 'اليوم، 09:30 ص',
    status: 'SUCCESS',
    actionTaken: 'تسجيل دخول ناجح',
  },
  {
    id: 'log-3',
    ipAddress: '185.220.101.5',
    device: 'Linux Bot / Proxy',
    location: 'فرانكفورت، ألمانيا 🇩🇪',
    timestamp: 'منذ يومين، 03:12 ص',
    status: 'SUSPICIOUS_BLOCKED',
    actionTaken: 'تم حظر محاولة الدخول المشبوهة وتنبيه النظام',
  },
  {
    id: 'log-4',
    ipAddress: '185.120.44.12',
    device: 'Samsung Galaxy Tab S9',
    location: 'الرياض، السعودية 🇸🇦',
    timestamp: 'أمس، 18:45 م',
    status: 'OTP_CHALLENGED',
    actionTaken: 'تم التحقق بنجاح عبر رمز OTP',
  },
];

export const AdvancedSecurityModal: React.FC<AdvancedSecurityModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateUser,
  showNotification,
}) => {
  const [activeTab, setActiveTab] = useState<'devices' | 'pin' | 'history'>('devices');

  const [devices, setDevices] = useState<RegisteredDevice[]>(
    currentUser.registeredDevices && currentUser.registeredDevices.length > 0
      ? currentUser.registeredDevices
      : DEFAULT_DEVICES
  );

  const [twoFactorEnabled, setTwoFactorEnabled] = useState<boolean>(
    currentUser.twoFactorEnabled ?? true
  );
  const [loginAlertsEnabled, setLoginAlertsEnabled] = useState(true);

  // Financial Security PIN state (اقتراح رقم 3)
  const [pinEnabled, setPinEnabled] = useState<boolean>(currentUser.securityPinEnabled ?? true);
  const [currentPin, setCurrentPin] = useState<string>(currentUser.securityPin || '1234');
  const [newPinInput, setNewPinInput] = useState<string>('');
  const [showPin, setShowPin] = useState(false);
  const [isEditingPin, setIsEditingPin] = useState(false);

  const [loginHistory, setLoginHistory] = useState<LoginHistoryItem[]>(
    currentUser.loginHistory && currentUser.loginHistory.length > 0
      ? currentUser.loginHistory
      : DEFAULT_LOGIN_HISTORY
  );

  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const showFeedback = (msg: string) => {
    setFeedbackMsg(msg);
    setTimeout(() => setFeedbackMsg(null), 3500);
  };

  // Terminate Single Remote Device
  const handleTerminateDevice = (deviceId: string) => {
    soundFX.playButtonClick();
    const targetDev = devices.find((d) => d.id === deviceId);
    if (!targetDev) return;

    const updated = devices.filter((d) => d.id !== deviceId);
    setDevices(updated);

    const updatedUser = { ...currentUser, registeredDevices: updated };
    onUpdateUser(updatedUser);
    saveUserProfileToFirestore(updatedUser);

    showFeedback(`🔒 تم إنهاء الجلسة وتسجيل الخروج بنجاح من جهاز: ${targetDev.deviceName}`);
    if (showNotification) {
      showNotification(`تم تسجيل الخروج عن بُعد من جهاز ${targetDev.deviceName}`);
    }
  };

  // Terminate All Other Devices
  const handleTerminateAllOtherDevices = () => {
    soundFX.playVictoryFanfare();
    const remaining = devices.filter((d) => d.isCurrent);
    setDevices(remaining);

    const updatedUser = { ...currentUser, registeredDevices: remaining };
    onUpdateUser(updatedUser);
    saveUserProfileToFirestore(updatedUser);

    showFeedback('🛡️ تم تسجيل الخروج بنجاح من جميع الأجهزة الأخرى وإلغاء كافة الجلسات النشطة!');
    if (showNotification) {
      showNotification('تم تسجيل الخروج من كافة الأجهزة الأخرى بنجاح');
    }
  };

  // Toggle 2FA
  const handleToggle2FA = () => {
    soundFX.playButtonClick();
    const next = !twoFactorEnabled;
    setTwoFactorEnabled(next);

    const updatedUser = { ...currentUser, twoFactorEnabled: next };
    onUpdateUser(updatedUser);
    saveUserProfileToFirestore(updatedUser);

    showFeedback(
      next
        ? '✅ تم تفعيل المصادقة الثنائية (2FA) - سيتطلب كل تسجيل دخول رمز OTP'
        : '⚠️ تم تعطيل المصادقة الثنائية'
    );
  };

  // Toggle Financial Security PIN (اقتراح رقم 3)
  const handleTogglePin = () => {
    soundFX.playButtonClick();
    const next = !pinEnabled;
    setPinEnabled(next);

    const updatedUser = {
      ...currentUser,
      securityPinEnabled: next,
      securityPin: currentPin,
    };
    onUpdateUser(updatedUser);
    saveUserProfileToFirestore(updatedUser);

    showFeedback(
      next
        ? '🔐 تم تفعيل رمز PIN المالي السري لحماية السحوبات وعمليات الكاشير'
        : '⚠️ تم إيقاف رمز PIN المالي المؤقت'
    );
  };

  // Save New PIN
  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPinInput.length !== 4 && newPinInput.length !== 6) {
      showFeedback('❌ يجب أن يتكون رمز PIN من 4 أو 6 أرقام سرية.');
      return;
    }

    soundFX.playVictoryFanfare();
    setCurrentPin(newPinInput);
    setIsEditingPin(false);
    setNewPinInput('');

    const updatedUser = {
      ...currentUser,
      securityPin: newPinInput,
      securityPinEnabled: true,
    };
    setPinEnabled(true);
    onUpdateUser(updatedUser);
    saveUserProfileToFirestore(updatedUser);

    showFeedback('✅ تم تعيين وتحديث رمز PIN المالي السري بنجاح!');
    if (showNotification) {
      showNotification('تم تحديث رمز PIN المالي السري بنجاح');
    }
  };

  const suspiciousCount = devices.filter((d) => d.isSuspicious).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in select-none">
      <div className="relative w-full max-w-3xl h-[780px] max-h-[92vh] bg-gradient-to-b from-[#082215] via-[#05160d] to-[#020a06] border-2 border-amber-400/80 rounded-3xl overflow-hidden shadow-[0_0_60px_rgba(16,185,129,0.3)] flex flex-col text-right">
        {/* Header */}
        <div className="px-6 py-4 bg-[#061a0e] border-b border-amber-500/30 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center text-white shadow-md">
              <ShieldCheck className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <h3 className="text-base font-black text-amber-200 flex items-center gap-2">
                الأمان المتقدم والأجهزة المسجلة
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                  حماية 256-Bit
                </span>
              </h3>
              <p className="text-xs text-gray-400">
                مراقبة الجلسات المفتوحة، حظر الأجهزة المشبوهة عن بُعد، ورمز PIN المالي
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="p-1.5 rounded-full text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Feedback Alert */}
        {feedbackMsg && (
          <div className="mx-6 mt-3 p-3 bg-emerald-950/90 border border-emerald-400 text-emerald-200 text-xs font-bold rounded-2xl flex items-center gap-2 shadow-lg animate-in fade-in">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{feedbackMsg}</span>
          </div>
        )}

        {/* Sub-header Navigation Tabs */}
        <div className="flex bg-[#040e08] border-b border-amber-950 overflow-x-auto text-xs font-bold p-1 gap-1 shrink-0">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              setActiveTab('devices');
            }}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition-all ${
              activeTab === 'devices'
                ? 'bg-gradient-to-r from-amber-500 to-amber-400 text-black shadow-md'
                : 'text-gray-300 hover:bg-black/40'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>الأجهزة المسجلة ({devices.length})</span>
            {suspiciousCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-red-600 text-white text-[10px] font-black animate-pulse">
                {suspiciousCount} مشبوه
              </span>
            )}
          </button>

          <button
            onClick={() => {
              soundFX.playButtonClick();
              setActiveTab('pin');
            }}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition-all ${
              activeTab === 'pin'
                ? 'bg-gradient-to-r from-amber-500 to-amber-400 text-black shadow-md'
                : 'text-gray-300 hover:bg-black/40'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>رمز PIN المالي السري (اقتراح 3)</span>
          </button>

          <button
            onClick={() => {
              soundFX.playButtonClick();
              setActiveTab('history');
            }}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition-all ${
              activeTab === 'history'
                ? 'bg-gradient-to-r from-amber-500 to-amber-400 text-black shadow-md'
                : 'text-gray-300 hover:bg-black/40'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>سجل الأنشطة والدخول</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6">
          {/* TAB 1: REGISTERED DEVICES */}
          {activeTab === 'devices' && (
            <div className="space-y-6">
              {/* Security Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* Health Score */}
                <div className="p-4 rounded-2xl bg-black/50 border border-emerald-500/30 flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-gray-300">درجة أمان الحساب</span>
                    <Shield className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-2xl font-black text-emerald-300 font-mono">
                    {twoFactorEnabled && pinEnabled ? '98%' : twoFactorEnabled ? '88%' : '72%'}
                  </div>
                  <div className="text-[11px] text-gray-400 mt-1">
                    {twoFactorEnabled && pinEnabled
                      ? 'حماية ملكية فائقة (2FA + PIN نشط)'
                      : 'حماية جيدة (فعّل 2FA وPIN لرفع الأمان)'}
                  </div>
                </div>

                {/* Devices Count */}
                <div className="p-4 rounded-2xl bg-black/50 border border-amber-500/30 flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-gray-300">الأجهزة المسجلة</span>
                    <Smartphone className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="text-2xl font-black text-amber-300 font-mono">
                    {devices.length} أجهزة
                  </div>
                  <div className="text-[11px] text-gray-400 mt-1">
                    1 جهاز متصل حالياً • {devices.length - 1} أجهزة سابقة
                  </div>
                </div>

                {/* Suspicious Alerts */}
                <div
                  className={`p-4 rounded-2xl border flex flex-col justify-between ${
                    suspiciousCount > 0
                      ? 'bg-red-950/40 border-red-500/60 shadow-[0_0_15px_rgba(239,68,68,0.2)]'
                      : 'bg-black/50 border-emerald-500/30'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-gray-300">الأنشطة المشبوهة</span>
                    <AlertTriangle
                      className={`w-4 h-4 ${
                        suspiciousCount > 0 ? 'text-red-400 animate-pulse' : 'text-emerald-400'
                      }`}
                    />
                  </div>
                  <div
                    className={`text-2xl font-black font-mono ${
                      suspiciousCount > 0 ? 'text-red-300' : 'text-emerald-300'
                    }`}
                  >
                    {suspiciousCount > 0 ? `${suspiciousCount} جهاز مشبوه!` : '0 أجهزة مشبوهة'}
                  </div>
                  <div className="text-[11px] text-gray-400 mt-1">
                    {suspiciousCount > 0 ? 'يوصى بتسجيل الخروج الفوري منه' : 'كافة الجلسات آمنة وموثوقة'}
                  </div>
                </div>
              </div>

              {/* Quick Actions Header */}
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-black text-amber-200 flex items-center gap-2">
                  <SmartphoneNfc className="w-4 h-4 text-amber-400" />
                  الأجهزة المسجلة والجلسات النشطة ({devices.length})
                </h4>

                {devices.filter((d) => !d.isCurrent).length > 0 && (
                  <button
                    onClick={handleTerminateAllOtherDevices}
                    className="px-3.5 py-1.5 rounded-xl bg-red-950/70 hover:bg-red-900 border border-red-500/60 text-red-200 text-xs font-black shadow-md transition-all flex items-center gap-1.5"
                  >
                    <LogOut className="w-3.5 h-3.5 rotate-180" />
                    <span>تسجيل الخروج من جميع الأجهزة الأخرى</span>
                  </button>
                )}
              </div>

              {/* Registered Devices List */}
              <div className="space-y-3">
                {devices.map((device) => {
                  const isCurrent = device.isCurrent;
                  const isSuspicious = device.isSuspicious;

                  return (
                    <div
                      key={device.id}
                      className={`p-4 rounded-2xl border transition-all flex flex-wrap items-center justify-between gap-4 ${
                        isCurrent
                          ? 'bg-gradient-to-r from-emerald-950/80 to-[#072415] border-emerald-400/80 shadow-md ring-1 ring-emerald-400/40'
                          : isSuspicious
                          ? 'bg-gradient-to-r from-red-950/70 to-[#2b0808] border-red-500/80 shadow-lg'
                          : 'bg-black/50 border-amber-950 hover:border-amber-500/40'
                      }`}
                    >
                      {/* Device Info */}
                      <div className="flex items-start gap-3.5">
                        <div
                          className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-inner ${
                            isCurrent
                              ? 'bg-emerald-900/80 border border-emerald-400 text-emerald-200'
                              : isSuspicious
                              ? 'bg-red-900/80 border border-red-400 text-red-200 animate-pulse'
                              : 'bg-black/60 border border-amber-950 text-amber-400'
                          }`}
                        >
                          {device.deviceType === 'mobile' ? (
                            <Smartphone className="w-5 h-5" />
                          ) : device.deviceType === 'tablet' ? (
                            <Tablet className="w-5 h-5" />
                          ) : (
                            <Laptop className="w-5 h-5" />
                          )}
                        </div>

                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-black text-white">{device.deviceName}</span>
                            {isCurrent ? (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500 text-black font-black flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-black animate-ping" />
                                هذا الجهاز (النشط الآن)
                              </span>
                            ) : isSuspicious ? (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-500 text-white font-black animate-pulse flex items-center gap-1">
                                <ShieldAlert className="w-3 h-3" />
                                جهاز مشبوه
                              </span>
                            ) : (
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-black/60 text-gray-400 border border-amber-950">
                                مسجل
                              </span>
                            )}
                          </div>

                          <div className="text-xs text-gray-300 flex flex-wrap items-center gap-3">
                            <span className="text-gray-400">
                              {device.browser} • {device.os}
                            </span>
                            <span className="text-gray-500">|</span>
                            <span className="flex items-center gap-1 text-amber-300 font-mono text-[11px]">
                              <Globe className="w-3 h-3 text-amber-400" />
                              {device.ipAddress}
                            </span>
                            <span className="text-gray-500">|</span>
                            <span className="flex items-center gap-1 text-gray-300 text-[11px]">
                              <MapPin className="w-3 h-3 text-emerald-400" />
                              {device.location}
                            </span>
                          </div>

                          <div className="flex items-center gap-1 text-[11px] text-gray-400 mt-1">
                            <Clock className="w-3 h-3 text-gray-500" />
                            <span>آخر نشاط: {device.lastActive}</span>
                          </div>

                          {device.suspicionReason && (
                            <div className="text-[11px] text-red-300 mt-1.5 p-2 rounded-xl bg-red-950/50 border border-red-500/40">
                              ⚠️ {device.suspicionReason}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Remote Action */}
                      <div>
                        {isCurrent ? (
                          <span className="text-xs font-bold text-emerald-400 bg-emerald-950/80 px-3 py-1.5 rounded-xl border border-emerald-500/40 flex items-center gap-1.5">
                            <CheckCircle className="w-4 h-4 text-emerald-400" />
                            <span>جلستك الآمنة الحالية</span>
                          </span>
                        ) : (
                          <button
                            onClick={() => handleTerminateDevice(device.id)}
                            className={`px-3.5 py-2 rounded-xl text-xs font-black shadow-md transition-all flex items-center gap-1.5 ${
                              isSuspicious
                                ? 'bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white shadow-red-500/30'
                                : 'bg-black/60 hover:bg-red-950/60 border border-amber-950 hover:border-red-500/50 text-gray-300 hover:text-red-300'
                            }`}
                          >
                            <LogOut className="w-3.5 h-3.5 rotate-180" />
                            <span>تسجيل الخروج عن بُعد</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* 2FA & Login Alerts Toggles */}
              <div className="p-5 rounded-2xl bg-black/60 border border-amber-500/30 space-y-4">
                <h4 className="text-xs font-black text-amber-200 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-amber-400" />
                  المصادقة الثنائية وتنبيهات الدخول
                </h4>

                {/* 2FA Toggle */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-[#06180e] border border-amber-950">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 font-black">
                      <KeyRound className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">
                        المصادقة الثنائية برمز OTP (Two-Factor Auth)
                      </div>
                      <div className="text-[11px] text-gray-400">
                        إرسال رمز سداسي مؤقت عبر SMS/WhatsApp عند الدخول من متصفح جديد
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handleToggle2FA}
                    className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                      twoFactorEnabled ? 'bg-emerald-500' : 'bg-gray-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                        twoFactorEnabled ? 'translate-x-0' : '-translate-x-6'
                      }`}
                    />
                  </button>
                </div>

                {/* Login Alerts Toggle */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-[#06180e] border border-amber-950">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 font-black">
                      <Bell className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">إشعارات الدخول الفورية (Login Alerts)</div>
                      <div className="text-[11px] text-gray-400">
                        تنبيه فوري عبر التطبيق عند محاولة الدخول من جهاز أو موقع غير مألوف
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      soundFX.playButtonClick();
                      setLoginAlertsEnabled(!loginAlertsEnabled);
                    }}
                    className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                      loginAlertsEnabled ? 'bg-emerald-500' : 'bg-gray-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                        loginAlertsEnabled ? 'translate-x-0' : '-translate-x-6'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: FINANCIAL SECURITY PIN (اقتراح رقم 3) */}
          {activeTab === 'pin' && (
            <div className="space-y-6">
              {/* Highlight Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-emerald-500/20 to-transparent border border-amber-400/60 flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/30 border border-amber-400 flex items-center justify-center text-amber-300 shrink-0">
                  <KeyRound className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-amber-200">
                    رمز PIN المالي السري لحماية المعاملات (اقتراح رقم 3)
                  </h4>
                  <p className="text-xs text-gray-300 mt-0.5">
                    طبقة أمان مخصصة تطلب رمزاً سرياً مكوّناً من 4 أرقام قبل اعتماد أي عملية سحب أموال أو تحويل عبر الكاشير.
                  </p>
                </div>
              </div>

              {/* Status and Toggle */}
              <div className="p-5 rounded-2xl bg-black/60 border border-amber-950 space-y-4">
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#06180e] border border-amber-950">
                  <div>
                    <div className="text-xs font-black text-white flex items-center gap-2">
                      <span>حالة تفعيل حماية PIN المالي:</span>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                          pinEnabled
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-red-500/20 text-red-300 border border-red-500/40'
                        }`}
                      >
                        {pinEnabled ? 'مفعل ويحمي المحفظة ✓' : 'معطل'}
                      </span>
                    </div>
                    <div className="text-[11px] text-gray-400 mt-1">
                      عند التفعيل، لن يتمكن أحد من سحب الرصيد أو تحويل الكوينز دون إدخال الرمز السري.
                    </div>
                  </div>

                  <button
                    onClick={handleTogglePin}
                    className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                      pinEnabled ? 'bg-emerald-500' : 'bg-gray-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                        pinEnabled ? 'translate-x-0' : '-translate-x-6'
                      }`}
                    />
                  </button>
                </div>

                {/* Current PIN Display */}
                <div className="p-4 rounded-xl bg-[#040e08] border border-amber-500/30 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-gray-300">الرمز السري الحالي:</div>
                    <div className="text-lg font-mono font-black text-amber-300 tracking-[0.3em] mt-1">
                      {showPin ? currentPin : '••••'}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowPin(!showPin)}
                      className="px-3 py-1.5 rounded-lg bg-black/50 hover:bg-black/80 border border-amber-950 text-gray-300 text-xs font-bold flex items-center gap-1.5"
                    >
                      {showPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      <span>{showPin ? 'إخفاء' : 'إظهار الرمز'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        soundFX.playButtonClick();
                        setIsEditingPin(!isEditingPin);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400 text-amber-300 text-xs font-bold"
                    >
                      تغيير الرمز السري
                    </button>
                  </div>
                </div>

                {/* Edit PIN Form */}
                {isEditingPin && (
                  <form onSubmit={handleSavePin} className="p-4 rounded-xl bg-black/80 border border-amber-400/60 space-y-3 animate-in fade-in">
                    <div className="text-xs font-black text-amber-200">
                      أدخل رمز PIN الجديد المكوّن من 4 أرقام:
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="password"
                        maxLength={6}
                        required
                        value={newPinInput}
                        onChange={(e) => setNewPinInput(e.target.value.replace(/\D/g, ''))}
                        placeholder="مثال: 5824"
                        className="flex-1 bg-black/70 border border-amber-950 focus:border-amber-400 rounded-xl px-4 py-2.5 text-white font-mono text-center tracking-[0.5em] text-base focus:outline-none"
                      />

                      <button
                        type="submit"
                        disabled={newPinInput.length < 4}
                        className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 text-white font-black text-xs shadow-md disabled:opacity-40"
                      >
                        حفظ وتفعيل
                      </button>

                      <button
                        type="button"
                        onClick={() => setIsEditingPin(false)}
                        className="px-3 py-2.5 rounded-xl bg-gray-800 text-gray-300 text-xs font-bold"
                      >
                        إلغاء
                      </button>
                    </div>
                  </form>
                )}
              </div>

              {/* Protected Operations Explanation */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-black/40 border border-amber-950">
                  <div className="text-xs font-black text-amber-300 mb-1">💰 سحب الأرباح النقدية</div>
                  <div className="text-[11px] text-gray-400">
                    طلب إدخال PIN فوري قبل تأكيد طلب السحب عبر USDT أو الكاشير.
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-black/40 border border-amber-950">
                  <div className="text-xs font-black text-emerald-300 mb-1">💼 تحويلات الكاشير</div>
                  <div className="text-[11px] text-gray-400">
                    حماية معاملات شحن حسابات اللاعبين من خلال مكتب الكاشير.
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-black/40 border border-amber-950">
                  <div className="text-xs font-black text-blue-300 mb-1">🎁 إهداء الكوينز الكبرى</div>
                  <div className="text-[11px] text-gray-400">
                    منع إرسال هدايا ضخمة دون إذن مباشر من صاحب الحساب.
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: LOGIN AUDIT HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-black text-amber-200 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-amber-400" />
                    سجل محاولات وتسجيلات الدخول الأخيرة
                  </h4>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    توثيق كامل لكل جلسة دخول مع تفاصيل الجهاز وعنوان IP والموقع الجغرافي
                  </p>
                </div>

                <button
                  onClick={() => {
                    soundFX.playButtonClick();
                    showFeedback('🔄 تم تحديث سجل الأنشطة بنجاح');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-black/50 border border-amber-950 hover:border-amber-500/40 text-gray-300 text-xs font-bold flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>تحديث</span>
                </button>
              </div>

              <div className="space-y-2.5">
                {loginHistory.map((log) => (
                  <div
                    key={log.id}
                    className="p-3.5 rounded-xl bg-black/50 border border-amber-950 hover:border-amber-500/30 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-white">{log.device}</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            log.status === 'SUCCESS'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : log.status === 'SUSPICIOUS_BLOCKED'
                              ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          }`}
                        >
                          {log.status === 'SUCCESS'
                            ? 'ناجح ✓'
                            : log.status === 'SUSPICIOUS_BLOCKED'
                            ? 'محظور أمنياً ✕'
                            : 'تم التحقق بـ OTP 📱'}
                        </span>
                      </div>

                      <div className="text-[11px] text-gray-400 flex items-center gap-3">
                        <span className="font-mono text-amber-300">{log.ipAddress}</span>
                        <span>•</span>
                        <span>{log.location}</span>
                        <span>•</span>
                        <span>{log.actionTaken}</span>
                      </div>
                    </div>

                    <div className="text-gray-400 text-[11px] font-mono shrink-0">
                      {log.timestamp}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
