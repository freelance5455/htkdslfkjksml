import React, { useMemo, useRef, useState } from 'react';
import { Disciple } from '../../types/cultivation';
import { CULTIVATION_REALMS, formatLargeNumber } from '../../data/realms';
import { formatCalendarDate } from '../../utils/dateUtils';
import { CultivatorAvatar } from '../cultivation/CultivatorAvatar';
import { soundEngine } from '../../services/audioEngine';
import {
  BookOpen,
  Search,
  Skull,
  ShieldCheck,
  Award,
  AlertTriangle,
  Users,
  X,
  ArrowLeft
} from 'lucide-react';

interface LineageArchiveModalProps {
  disciples: Disciple[];
  perishedDisciples: Disciple[];
  initialInspectId?: string | null;
  onClose: () => void;
}

export const LineageArchiveModal: React.FC<LineageArchiveModalProps> = ({
  disciples,
  perishedDisciples,
  initialInspectId = null,
  onClose
}) => {
  const [filterStatus, setFilterStatus] = useState<'All' | 'Active' | 'Perished'>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [inspectedId, setInspectedId] = useState<string | null>(initialInspectId);
  const longPressTimerRef = useRef<number | null>(null);
  const longPressTriggeredRef = useRef<boolean>(false);

  const allRoster = useMemo(() => {
    const map = new Map<string, Disciple>();
    disciples.forEach(d => map.set(d.id, d));
    perishedDisciples.forEach(d => map.set(d.id, { ...d, isPerished: true }));
    return Array.from(map.values());
  }, [disciples, perishedDisciples]);

  const filteredRoster = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return allRoster.filter(d => {
      if (filterStatus === 'Active' && d.isPerished) return false;
      if (filterStatus === 'Perished' && !d.isPerished) return false;
      if (q && !d.name.toLowerCase().includes(q) && !d.rank.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [allRoster, filterStatus, searchQuery]);

  const inspectedDisciple = allRoster.find(d => d.id === inspectedId) || null;

  const resolveNameById = (id?: string): string | null => {
    if (!id) return null;
    return allRoster.find(d => d.id === id)?.name || null;
  };

  const handleRowPointerDown = (discipleId: string) => {
    longPressTriggeredRef.current = false;
    if (longPressTimerRef.current) window.clearTimeout(longPressTimerRef.current);
    longPressTimerRef.current = window.setTimeout(() => {
      longPressTriggeredRef.current = true;
      soundEngine.playTalisman();
      setInspectedId(discipleId);
    }, 480);
  };

  const clearLongPress = () => {
    if (longPressTimerRef.current) {
      window.clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const renderRecordDetail = (d: Disciple) => {
    const realm = CULTIVATION_REALMS[d.currentRealmIndex] || CULTIVATION_REALMS[0];
    const masterName = resolveNameById(d.masterId);
    const parentName = resolveNameById(d.adoptedBy);
    const childNames = (d.adoptedChildrenIds || [])
      .map(cid => resolveNameById(cid))
      .filter((n): n is string => Boolean(n));

    const familyLinks: { label: string; value: string }[] = [];
    if (masterName) familyLinks.push({ label: 'Master', value: masterName });
    if (parentName) familyLinks.push({ label: 'Adoptive Parent', value: parentName });
    if (childNames.length > 0) familyLinks.push({ label: 'Adopted Children', value: childNames.join(', ') });

    d.relations.forEach(r => {
      const targetName = resolveNameById(r.targetId);
      if (!targetName) return;
      if (['Lover', 'Confidant', 'Sworn Sibling', 'Master-Disciple', 'Adoptive Father', 'Adoptive Mother', 'Adoptive Parent', 'Son/Daughter'].includes(r.type)) {
        familyLinks.push({ label: r.type, value: targetName });
      }
    });

    const sins = d.crimesSins || [];
    const biggestContrib = d.biggestContribution || `${formatLargeNumber(d.contribution || 0)} Sect Merit Points Earned`;

    return (
      <div className="space-y-4 animate-fade-in">
        <button
          onClick={() => {
            soundEngine.playClick();
            setInspectedId(null);
          }}
          className="text-xs font-bold text-[#fce18b] hover:text-white flex items-center gap-1.5"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Lineage Archive List</span>
        </button>

        {/* Identity Banner */}
        <div className={`p-4 rounded-2xl border flex items-center gap-3.5 ${
          d.isPerished
            ? 'bg-[#220c10] border-rose-500/50'
            : 'bg-[#09261d] border-[#e2b054]/50'
        }`}>
          <div className="shrink-0">
            <CultivatorAvatar
              gender={d.gender}
              rank={d.rank}
              spiritRoot={d.spiritRoot}
              realmIndex={d.currentRealmIndex}
              appearanceIndex={d.appearanceIndex ?? d.avatarStyle?.appearanceIndex}
              skinTone={d.skinTone ?? d.avatarStyle?.skinTone}
              clothingColor={d.clothingColor ?? d.avatarStyle?.clothingColor}
              hairColor={d.hairColor ?? d.avatarStyle?.hairColor}
              expression={d.expression ?? d.avatarStyle?.expression}
              auraEffect={d.auraEffect ?? d.avatarStyle?.auraEffect}
              mythicalForm={d.mythicalForm ?? d.avatarStyle?.mythicalForm}
              size="md"
            />
          </div>

          <div className="min-w-0 space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h4 className="font-dao font-bold text-base sm:text-lg text-[#fce18b]">{d.name}</h4>
              <span className={`text-[11px] font-bold flex items-center gap-1 ${d.isPerished ? 'text-rose-300' : 'text-emerald-300'}`}>
                {d.isPerished ? <Skull className="w-3.5 h-3.5" /> : <ShieldCheck className="w-3.5 h-3.5" />}
                <span>{d.isPerished ? 'Perished' : 'Active Disciple'}</span>
              </span>
            </div>
            <div className="text-[11px] text-[#d1e6dc]">
              {d.rank} · {d.gender} · {realm.name}
            </div>
            {d.isPerished && (
              <div className="text-[11px] text-rose-300">
                {d.perishedDate ? formatCalendarDate(d.perishedDate) : `Year ${d.perishedYear || '?'}`} · {d.causeOfDeath || 'Perished on the Dao path'}
              </div>
            )}
          </div>
        </div>

        {/* Last Updated Stats */}
        <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-2">
          <div className="text-[11px] font-bold text-[#fce18b] uppercase tracking-wider">Last Recorded Attributes</div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
            <div className="bg-[#0d2e23] p-2 rounded-xl border border-[#1a4938]">
              <div className="text-[#8daea0] text-[10px]">Combat Might</div>
              <div className="font-mono tabular-nums font-bold text-[#38bdf8]">{formatLargeNumber(d.combatPower)}</div>
            </div>
            <div className="bg-[#0d2e23] p-2 rounded-xl border border-[#1a4938]">
              <div className="text-[#8daea0] text-[10px]">Talent &amp; Tier</div>
              <div className="font-mono tabular-nums font-bold text-[#fce18b]">{d.talent} ({d.talentTier})</div>
            </div>
            <div className="bg-[#0d2e23] p-2 rounded-xl border border-[#1a4938]">
              <div className="text-[#8daea0] text-[10px]">Age / Lifespan</div>
              <div className="font-mono tabular-nums font-bold text-emerald-300">{d.age} / {d.lifespan} yrs</div>
            </div>
            <div className="bg-[#0d2e23] p-2 rounded-xl border border-[#1a4938]">
              <div className="text-[#8daea0] text-[10px]">Cultivation Path</div>
              <div className="font-bold text-white truncate">{d.cultivationType || 'Qi Cultivator'}</div>
            </div>
            <div className="bg-[#0d2e23] p-2 rounded-xl border border-[#1a4938]">
              <div className="text-[#8daea0] text-[10px]">Spirit Root</div>
              <div className="font-bold text-[#e2b054] truncate">{d.spiritRoot}</div>
            </div>
            <div className="bg-[#0d2e23] p-2 rounded-xl border border-[#1a4938]">
              <div className="text-[#8daea0] text-[10px]">Physique</div>
              <div className="font-bold text-sky-200 truncate">{d.constitution}</div>
            </div>
          </div>
        </div>

        {/* Family & Master Lineage Links */}
        <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-2">
          <div className="text-[11px] font-bold text-[#fce18b] flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-amber-300" />
            <span>Family, Adoption &amp; Master Lineage</span>
          </div>
          {familyLinks.length === 0 ? (
            <p className="text-[11px] text-[#8daea0] italic">No recorded master, filial, or covenant links yet.</p>
          ) : (
            <div className="space-y-1.5">
              {familyLinks.map((lnk, idx) => (
                <div key={idx} className="flex justify-between items-center bg-[#0d2e23] px-3 py-1.5 rounded-xl border border-[#1b4b3b] text-[11px]">
                  <span className="text-[#9fc2b2]">{lnk.label}</span>
                  <span className="font-bold text-[#fce18b]">{lnk.value}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Biggest Contribution & Crimes / Sins */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="bg-[#09261d] p-3.5 rounded-2xl border border-emerald-500/35 space-y-1.5">
            <div className="text-[11px] font-bold text-emerald-300 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5" />
              <span>Biggest Contribution</span>
            </div>
            <p className="text-[11px] text-[#e8f1eb] leading-relaxed">{biggestContrib}</p>
          </div>

          <div className="bg-[#09261d] p-3.5 rounded-2xl border border-rose-500/35 space-y-1.5">
            <div className="text-[11px] font-bold text-rose-300 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Crimes &amp; Sins Committed</span>
            </div>
            {sins.length === 0 ? (
              <p className="text-[11px] text-[#9fc2b2]">Unblemished Record — Zero Sect Violations</p>
            ) : (
              <ul className="space-y-1 text-[11px] text-rose-200 list-disc pl-4">
                {sins.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <BookOpen className="w-5 h-5 text-[#fce18b] shrink-0" />
            <div className="min-w-0">
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b] truncate">
                Sect Lineage Archive · <span className="font-mono tabular-nums">{allRoster.length}</span> Recorded
              </h3>
              <p className="text-[11px] text-[#9fc2b2] truncate">
                Permanent registry of Active &amp; Perished disciples (Tap or hold name to inspect).
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-3.5 grow text-xs text-[#d1e6dc]">
          {inspectedDisciple ? (
            renderRecordDetail(inspectedDisciple)
          ) : (
            <>
              {/* Filter & Search Bar */}
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="flex items-center gap-1.5">
                  {(['All', 'Active', 'Perished'] as const).map(tab => (
                    <button
                      key={tab}
                      onClick={() => setFilterStatus(tab)}
                      className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition-colors ${
                        filterStatus === tab
                          ? 'bg-[#e2b054] text-[#072018]'
                          : 'bg-[#09261d] text-[#9fc2b2] border border-[#1b4b3b] hover:text-white'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 text-[#7ea091] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search disciple or rank..."
                    className="w-full bg-[#09261d] border border-[#1b4b3b] rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-[#6d8e80] focus:border-[#e2b054] focus:outline-none"
                  />
                </div>
              </div>

              {/* Roster List (Unlimited Capacity) */}
              {filteredRoster.length === 0 ? (
                <div className="p-8 text-center text-[#9fc2b2] bg-[#09261d] rounded-2xl border border-[#1b4b3b]">
                  No recorded disciples match your filter.
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredRoster.map(d => {
                    const realm = CULTIVATION_REALMS[d.currentRealmIndex] || CULTIVATION_REALMS[0];
                    return (
                      <div
                        key={d.id}
                        onPointerDown={() => handleRowPointerDown(d.id)}
                        onPointerUp={clearLongPress}
                        onPointerLeave={clearLongPress}
                        onPointerCancel={clearLongPress}
                        onContextMenu={(e) => e.preventDefault()}
                        onClick={() => {
                          if (longPressTriggeredRef.current) return;
                          soundEngine.playClick();
                          setInspectedId(d.id);
                        }}
                        className={`p-3 rounded-2xl border cursor-pointer transition-colors flex items-center justify-between gap-3 ${
                          d.isPerished
                            ? 'bg-[#210d10] border-rose-500/40 hover:border-rose-400'
                            : 'bg-[#09261d] border-[#1b4b3b] hover:border-[#e2b054]/60'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <CultivatorAvatar
                            gender={d.gender}
                            rank={d.rank}
                            spiritRoot={d.spiritRoot}
                            realmIndex={d.currentRealmIndex}
                            appearanceIndex={d.appearanceIndex ?? d.avatarStyle?.appearanceIndex}
                            skinTone={d.skinTone ?? d.avatarStyle?.skinTone}
                            clothingColor={d.clothingColor ?? d.avatarStyle?.clothingColor}
                            hairColor={d.hairColor ?? d.avatarStyle?.hairColor}
                            expression={d.expression ?? d.avatarStyle?.expression}
                            size="sm"
                          />
                          <div className="min-w-0">
                            <div className="font-dao font-bold text-sm text-[#fce18b] truncate">
                              {d.name}
                            </div>
                            <div className="text-[10px] text-[#a4c5b7] truncate">
                              {d.rank} · {realm.name} · Power <span className="font-mono tabular-nums">{formatLargeNumber(d.combatPower)}</span>
                            </div>
                            {d.isPerished && d.causeOfDeath && (
                              <div className="text-[10px] text-rose-300 truncate">{d.causeOfDeath}</div>
                            )}
                          </div>
                        </div>

                        <div className="text-right shrink-0 space-y-0.5">
                          <div className={`text-[10px] font-bold ${d.isPerished ? 'text-rose-300' : 'text-emerald-300'}`}>
                            {d.isPerished ? 'Perished' : 'Active'}
                          </div>
                          <div className="text-[9px] text-[#7ea091]">Inspect Record</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Unlimited Lineage Registry</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Close Archive
          </button>
        </div>
      </div>
    </div>
  );
};
