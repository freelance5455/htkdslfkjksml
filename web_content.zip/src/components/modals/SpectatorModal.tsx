import React from 'react';
import { X, Eye, Shield, Users, Play } from 'lucide-react';
import { soundFX } from '../../utils/soundEffects';

interface SpectatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onWatchMatch: (matchId: string) => void;
}

export const SpectatorModal: React.FC<SpectatorModalProps> = ({
  isOpen,
  onClose,
  onWatchMatch,
}) => {
  if (!isOpen) return null;

  const liveMatches = [
    {
      id: '#94821',
      game: 'طرنيب سوق 41',
      round: 'الجولة 3 • 41 نقطة',
      players: ['صقر العرب', 'الماستر الملكي', 'البرنس', 'ليلى'],
      score: '18 - 14',
      spectatorsCount: 42,
    },
    {
      id: '#83210',
      game: 'تركس ملكي',
      round: 'المملكة 2: شيخ الكبة',
      players: ['الملك الذهبي', 'الجوكر', 'الأسطورة', 'نجم الليل'],
      score: '-150 / +200',
      spectatorsCount: 29,
    },
    {
      id: '#73918',
      game: 'طرنيب سوق 41',
      round: 'الجولة 5 • شوط الحسم',
      players: ['أبو شهاب', 'النمر', 'الكابتن', 'الذئب'],
      score: '36 - 32',
      spectatorsCount: 88,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="relative w-full max-w-2xl bg-[#07130c] border-2 border-amber-500/50 rounded-2xl shadow-[0_0_40px_rgba(16,185,129,0.3)] overflow-hidden text-right flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0b2416] via-[#123823] to-[#0b2416] border-b border-amber-500/30 p-4 flex items-center justify-between">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="text-gray-400 hover:text-amber-400 p-1 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <span className="text-red-500 animate-pulse font-bold">● مباشر</span>
            <h2 className="text-lg font-bold text-amber-300">مدرج المشاهدة الملكي (المشاهدة المباشرة)</h2>
          </div>
        </div>

        {/* Anti-cheat disclaimer */}
        <div className="p-3 bg-amber-950/30 border-b border-amber-900/40 text-xs text-amber-300 flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            نظام النزاهة: يرى المشاهد الطاولة واللمّات والنتيجة العامة فقط، وتبقى أوراق اللاعبين مخفية تمامًا لمنع الغش والتواطؤ.
          </span>
        </div>

        {/* Live Matches List */}
        <div className="p-6 space-y-3 max-h-[60vh] overflow-y-auto">
          {liveMatches.map((m) => (
            <div
              key={m.id}
              className="p-4 rounded-xl bg-[#05110a] border border-amber-950/80 hover:border-amber-600/60 flex items-center justify-between"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-gray-100">{m.game}</span>
                  <span className="text-xs text-amber-400 font-mono">{m.id}</span>
                </div>
                <div className="text-xs text-gray-400 mt-1">{m.round}</div>
                <div className="text-xs text-emerald-400/90 mt-1 font-semibold">
                  اللاعبون: {m.players.join(' • ')}
                </div>
              </div>

              <div className="flex flex-col items-end gap-2">
                <div className="text-xs text-gray-400 flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5 text-amber-400" />
                  <span>{m.spectatorsCount} مشاهد</span>
                </div>
                <button
                  onClick={() => {
                    soundFX.playButtonClick();
                    onWatchMatch(m.id);
                    onClose();
                  }}
                  className="px-4 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 shadow"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>دخول المشاهدة</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
