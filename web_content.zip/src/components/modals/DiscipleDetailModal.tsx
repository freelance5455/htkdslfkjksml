import React, { useState } from 'react';
import {
  Disciple,
  DiscipleRank,
  Building,
  SectResources,
  EquipmentSlot,
  EquipmentItem
} from '../../types/cultivation';
import { CULTIVATION_REALMS, formatLargeNumber } from '../../data/realms';
import { EQUIPMENT_CATALOG, getAvailableEquipmentsForDisciple } from '../../data/equipment';
import { CONSTITUTION_EFFECTS, TALENT_TIER_DETAILS, SPIRIT_ROOT_DESCRIPTIONS } from '../../data/loreData';
import { CultivatorAvatar } from '../cultivation/CultivatorAvatar';
import { ChampionTitleBadge } from '../cultivation/ChampionTitleBadge';
import { StatDetailModal } from '../cultivation/StatDetailModal';
import { soundEngine } from '../../services/audioEngine';
import {
  Sparkles,
  Zap,
  Star,
  UserX,
  Flame,
  AlertTriangle,
  Award,
  X,
  ShieldCheck,
  CheckCircle2,
  Shirt,
  Sword,
  Gem,
  PawPrint,
  Clock,
  BookOpen,
  Info
} from 'lucide-react';

interface DiscipleDetailModalProps {
  disciple: Disciple | null;
  allDisciples: Disciple[];
  buildings: Building[];
  resources: SectResources;
  hallLevel: number;
  devMode: boolean;
  onClose: () => void;
  onBreakthrough: (disciple: Disciple) => void;
  onAssignBuilding: (discipleId: string, buildingId: string | null) => void;
  onPromoteRank: (discipleId: string, newRank: DiscipleRank) => void;
  onBestowGift: (discipleId: string, giftType: 'wine' | 'qiburst' | 'guidance') => void;
  onDeepenBond: (sourceId: string, targetId: string) => void;
  onMediateGrudge: (sourceId: string, targetId: string) => void;
  onToggleFavorite: (discipleId: string) => void;
  onKickDisciple: (disciple: Disciple) => void;
  onEquipItem: (discipleId: string, slot: EquipmentSlot, item: EquipmentItem | undefined) => void;
}

export const DiscipleDetailModal: React.FC<DiscipleDetailModalProps> = ({
  disciple,
  allDisciples,
  buildings,
  resources,
  hallLevel,
  devMode,
  onClose,
  onBreakthrough,
  onAssignBuilding,
  onPromoteRank,
  onBestowGift,
  onDeepenBond,
  onMediateGrudge,
  onToggleFavorite,
  onKickDisciple,
  onEquipItem
}) => {
  if (!disciple) return null;

  const [activeTab, setActiveTab] = useState<'info' | 'equipment' | 'memories' | 'relations' | 'actions'>('info');
  const [selectedEquipSlot, setSelectedEquipSlot] = useState<EquipmentSlot | null>(null);
  const [inspectStatKey, setInspectStatKey] = useState<string | null>(null);

  const currentRealm = CULTIVATION_REALMS[disciple.currentRealmIndex] || CULTIVATION_REALMS[0];
  const nextRealm = CULTIVATION_REALMS[disciple.currentRealmIndex + 1];
  const isReadyForBreakthrough = disciple.cultivationExp >= disciple.maxExp;

  // Elders count & limits
  const currentEldersCount = allDisciples.filter(d => d.rank === 'Elder').length;
  const currentGrandEldersCount = allDisciples.filter(d => d.rank === 'Grand Elder').length;
  const currentSectLeadersCount = allDisciples.filter(d => d.rank === 'Sect Leader').length;

  const maxEldersAllowed = Math.min(6, 1 + Math.floor(hallLevel / 10));
  const maxGrandEldersAllowed = 1;

  // Strict promotion requirements
  const getPromotionRequirements = (rank: DiscipleRank) => {
    switch (rank) {
      case 'Outer':
        return { minRealmIndex: 0, minContribution: 0, desc: 'Any admitted novice' };
      case 'Inner':
        return { minRealmIndex: 3, minContribution: 50, desc: 'Qi Condensation Layer 4 + 50 Contrib' };
      case 'Direct':
        return { minRealmIndex: 9, minContribution: 250, desc: 'Foundation Establishment + 250 Contrib' };
      case 'Elder':
        return { minRealmIndex: 13, minContribution: 1000, desc: `Golden Core + 1,000 Contrib (Cap: ${maxEldersAllowed})` };
      case 'Grand Elder':
        return { minRealmIndex: 17, minContribution: 3000, desc: 'Nascent Soul + 3,000 Contrib (Limit: 1)' };
      case 'Sect Leader':
        return { minRealmIndex: 21, minContribution: 10000, desc: 'Soul Formation + 10,000 Contrib (From Grand Elder)' };
    }
  };

  const isQiBurstActive = disciple.qiBurstUntil && disciple.qiBurstUntil > Date.now();
  const qiBurstSeconds = isQiBurstActive ? Math.ceil((disciple.qiBurstUntil! - Date.now()) / 1000) : 0;
  const constEffect = CONSTITUTION_EFFECTS[disciple.constitution];

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] relative">
        {/* Sticky Header with Avatar, Name, and Top-Right Close Button */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          {/* Avatar on left, Title strictly beside avatar */}
          <div className="flex items-center gap-3">
            <CultivatorAvatar
              gender={disciple.gender}
              rank={disciple.rank}
              spiritRoot={disciple.spiritRoot}
              realmIndex={disciple.currentRealmIndex}
              isBreakthroughReady={isReadyForBreakthrough}
              appearanceIndex={disciple.appearanceIndex ?? disciple.avatarStyle?.appearanceIndex}
              skinTone={disciple.skinTone ?? disciple.avatarStyle?.skinTone}
              clothingColor={disciple.clothingColor ?? disciple.avatarStyle?.clothingColor}
              hairColor={disciple.hairColor ?? disciple.avatarStyle?.hairColor}
              expression={disciple.expression ?? disciple.avatarStyle?.expression}
              auraEffect={disciple.auraEffect ?? disciple.avatarStyle?.auraEffect}
              mythicalForm={disciple.mythicalForm ?? disciple.avatarStyle?.mythicalForm}
              soulProtected={disciple.soulProtected}
              size="md"
            />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
                  {disciple.name}
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#184838] text-[#86efac] border border-[#22c55e]/40 font-bold">
                  {disciple.rank}
                </span>

                {/* Champion Title Badge placed BESIDE avatar/name with long-press popover support */}
                {disciple.championTitle && (
                  <ChampionTitleBadge title={disciple.championTitle} size="sm" />
                )}

                {disciple.isFavorite && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#ca8a04]/40 text-amber-300 border border-amber-400/40 flex items-center gap-0.5 font-bold">
                    <Star className="w-2.5 h-2.5 fill-current" />
                    <span>Fav</span>
                  </span>
                )}
              </div>

              {/* Age / Lifespan, Path & Emotion clearly displayed */}
              <div className="text-[11px] text-[#a4c5b7] mt-0.5 flex items-center gap-1.5 flex-wrap">
                <span className="text-[#86efac] font-medium">{currentRealm.name}</span>
                <span>·</span>
                <span className="text-sky-300 font-medium">{disciple.cultivationType || 'Qi Cultivator'}</span>
                <span>·</span>
                <span className="text-amber-200">{disciple.emotion || 'Serene'}</span>
                <span>·</span>
                <span
                  onClick={() => setInspectStatKey('Lifespan')}
                  className="cursor-pointer hover:underline text-[#fce18b]"
                >
                  Age {disciple.age}/{disciple.lifespan}
                </span>
                <span>·</span>
                <span
                  onClick={() => setInspectStatKey('Combat Power')}
                  className="text-[#38bdf8] font-mono cursor-pointer hover:underline"
                >
                  Pwr: {disciple.combatPower}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => {
                soundEngine.playClick();
                onToggleFavorite(disciple.id);
              }}
              title={disciple.isFavorite ? "Remove from Favorites" : "Mark as Favorite (Max 3)"}
              className={`p-2 rounded-xl border transition-all min-w-[38px] min-h-[38px] flex items-center justify-center ${
                disciple.isFavorite
                  ? 'bg-[#e2b054] text-[#072018] border-[#fce18b]'
                  : 'bg-[#09261d] text-[#6b8c7e] hover:text-[#fce18b] border-[#1b4b3b]'
              }`}
            >
              <Star className={`w-4 h-4 ${disciple.isFavorite ? 'fill-current' : ''}`} />
            </button>

            <button
              onClick={() => {
                soundEngine.playClick();
                if (window.confirm(`Are you sure you want to banish ${disciple.name} from the sect?`)) {
                  onKickDisciple(disciple);
                  onClose();
                }
              }}
              title="Banish from Sect"
              className="p-2 rounded-xl bg-[#09261d] text-red-400 hover:bg-red-900/50 hover:text-red-200 border border-red-900/30 min-w-[38px] min-h-[38px] flex items-center justify-center transition-all"
            >
              <UserX className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[38px] min-h-[38px] flex items-center justify-center transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 5 Tabs: Stats, Gear, Memories, Bonds, Promote */}
        <div className="grid grid-cols-5 bg-[#09261d] border-b border-[#1b4b3b] text-[10px] sm:text-[11px] font-bold font-dao">
          {[
            { id: 'info' as const, label: 'Stats' },
            { id: 'equipment' as const, label: 'Gear (4)' },
            { id: 'memories' as const, label: 'Memories' },
            { id: 'relations' as const, label: 'Bonds' },
            { id: 'actions' as const, label: 'Promote' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => {
                soundEngine.playClick();
                setActiveTab(tab.id);
                setSelectedEquipSlot(null);
              }}
              className={`py-2.5 text-center transition-all ${
                activeTab === tab.id
                  ? 'bg-[#184838] text-[#fce18b] border-b-2 border-[#e2b054]'
                  : 'text-[#8daea0] hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="p-3.5 sm:p-4 overflow-y-auto space-y-3.5 grow text-xs text-[#d1e6dc]">
          {activeTab === 'info' && (
            <>
              {/* Favorite Prodigy Bonus Banner */}
              {disciple.isFavorite && (
                <div className="p-2.5 rounded-xl bg-amber-950/60 border border-amber-400/50 text-amber-200 flex items-center justify-between text-[11px]">
                  <span className="font-bold flex items-center gap-1.5">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>Favorite Prodigy Blessing</span>
                  </span>
                  <span className="font-mono text-[10px] text-amber-100">
                    +20% Cult · +12% Might · +10% Breakthrough
                  </span>
                </div>
              )}

              {/* Negative Traits / Bottleneck Warning */}
              {disciple.negativeTraits && disciple.negativeTraits.length > 0 && (
                <div className="p-2.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 space-y-1 text-[11px]">
                  <div className="font-bold flex items-center gap-1.5 text-red-300">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Negative Dao-Heart States (-10% Cult each):</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {disciple.negativeTraits.map((tr, i) => (
                      <span key={i} className="px-2 py-0.5 rounded-full bg-red-900/70 border border-red-500/30 text-[10px] font-bold">
                        {tr}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Qi Burst Status Banner */}
              {isQiBurstActive && (
                <div className="p-2.5 rounded-xl bg-cyan-950/70 border border-cyan-400/40 text-cyan-200 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-bold text-cyan-300">
                    <Zap className="w-4 h-4 text-cyan-400 animate-bounce" />
                    <span>Qi Burst Active (+50% Cultivation Speed)</span>
                  </div>
                  <span className="font-mono text-cyan-400 text-[11px] font-bold">
                    {Math.floor(qiBurstSeconds / 60)}m {qiBurstSeconds % 60}s
                  </span>
                </div>
              )}

              {/* Realm & Exp Card */}
              <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-[#fce18b]">Realm Progress</span>
                  <span className="font-mono text-[#86efac]">
                    {formatLargeNumber(disciple.cultivationExp)} / {formatLargeNumber(disciple.maxExp)}
                  </span>
                </div>
                <div className="w-full bg-[#051510] h-2.5 rounded-full overflow-hidden border border-[#1d5543]">
                  <div
                    className="bg-gradient-to-r from-[#15803d] to-[#4ade80] h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (disciple.cultivationExp / disciple.maxExp) * 100)}%` }}
                  />
                </div>

                {isReadyForBreakthrough && nextRealm && (
                  <div className="pt-2 border-t border-[#1b4b3b] flex justify-between items-center">
                    <div>
                      <div className="text-[11px] text-[#86efac] font-bold">
                        Bottleneck Shatter Ready!
                      </div>
                      <div className="text-[10px] text-[#9fc2b2]">
                        Next: {nextRealm.name}
                      </div>
                    </div>
                    <button
                      onClick={() => onBreakthrough(disciple)}
                      className="py-1 px-3.5 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs shadow-md hover:brightness-110 active:scale-95 transition-all"
                    >
                      Attempt Breakthrough
                    </button>
                  </div>
                )}
              </div>

              {/* Aptitude Matrix with Clickable Popovers */}
              <div className="grid grid-cols-2 gap-2">
                <div
                  onClick={() => setInspectStatKey('Spirit Root')}
                  className="bg-[#09261d] p-2.5 rounded-xl border border-[#1b4b3b] cursor-pointer hover:border-[#e2b054]/40"
                >
                  <span className="text-[#9fc2b2] text-[10px] flex items-center justify-between">
                    <span>Spirit Root</span>
                    <Info className="w-3 h-3 text-[#e2b054]" />
                  </span>
                  <span className="font-bold text-white text-[11px] block mt-0.5">{disciple.spiritRoot} ({disciple.spiritRootPurity})</span>
                </div>

                <div
                  onClick={() => setInspectStatKey('Physique')}
                  className="bg-[#09261d] p-2.5 rounded-xl border border-[#1b4b3b] cursor-pointer hover:border-[#e2b054]/40"
                >
                  <span className="text-[#9fc2b2] text-[10px] flex items-center justify-between">
                    <span>Physique / Body</span>
                    <Info className="w-3 h-3 text-[#e2b054]" />
                  </span>
                  <span className="font-bold text-white text-[11px] truncate block mt-0.5">{disciple.constitution}</span>
                </div>

                <div
                  onClick={() => setInspectStatKey('Talent')}
                  className="bg-[#09261d] p-2.5 rounded-xl border border-[#1b4b3b] cursor-pointer hover:border-[#e2b054]/40"
                >
                  <span className="text-[#9fc2b2] text-[10px] flex items-center justify-between">
                    <span>Talent Tier</span>
                    <Info className="w-3 h-3 text-[#e2b054]" />
                  </span>
                  <span className="font-bold text-amber-300 text-[11px] block mt-0.5">{disciple.talentTier || 'Mediocre'} ({disciple.talent}/100)</span>
                </div>

                <div
                  onClick={() => setInspectStatKey('Combat Power')}
                  className="bg-[#09261d] p-2.5 rounded-xl border border-[#1b4b3b] cursor-pointer hover:border-[#e2b054]/40"
                >
                  <span className="text-[#9fc2b2] text-[10px] flex items-center justify-between">
                    <span>Combat Power</span>
                    <Info className="w-3 h-3 text-[#e2b054]" />
                  </span>
                  <span className="font-bold text-[#fce18b] font-mono text-xs block mt-0.5">{formatLargeNumber(disciple.combatPower)}</span>
                </div>
              </div>

              {/* Functional Constitution Traits (Positive & Negative Effects) */}
              {constEffect && (
                <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] space-y-2">
                  <div className="font-bold text-[#fce18b] text-[11px] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#e2b054]" />
                    <span>Physique Affinity: {disciple.constitution}</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px]">
                    <div className="bg-[#123d30] p-2 rounded-xl border border-emerald-500/30">
                      <span className="text-emerald-400 font-bold block mb-1">Dao Gifts (Positive):</span>
                      <ul className="list-disc list-inside space-y-0.5 text-emerald-200">
                        {constEffect.positive.map((p, i) => (
                          <li key={i}>{p}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-[#123d30] p-2 rounded-xl border border-red-500/30">
                      <span className="text-red-400 font-bold block mb-1">Karmic Flaws (Negative):</span>
                      <ul className="list-disc list-inside space-y-0.5 text-red-200">
                        {constEffect.negative.map((n, i) => (
                          <li key={i}>{n}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {/* Loyalty, Morale, Stress Bars */}
              <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] space-y-2">
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px]">
                    <span className="text-[#9fc2b2]">Loyalty</span>
                    <span className="font-mono text-emerald-400">{disciple.loyalty}/100</span>
                  </div>
                  <div className="w-full bg-[#071913] h-1.5 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${disciple.loyalty}%` }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[10px]">
                    <span className="text-[#9fc2b2]">Morale</span>
                    <span className="font-mono text-sky-400">{disciple.morale}/100</span>
                  </div>
                  <div className="w-full bg-[#071913] h-1.5 rounded-full overflow-hidden">
                    <div className="bg-sky-500 h-full rounded-full" style={{ width: `${disciple.morale}%` }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[10px]">
                    <span className="text-[#9fc2b2]">Stress / Inner Demons</span>
                    <span className="font-mono text-rose-400">{disciple.stress}/100</span>
                  </div>
                  <div className="w-full bg-[#071913] h-1.5 rounded-full overflow-hidden">
                    <div className="bg-rose-500 h-full rounded-full" style={{ width: `${disciple.stress}%` }} />
                  </div>
                </div>
              </div>
            </>
          )}

          {/* EQUIPMENT TAB */}
          {activeTab === 'equipment' && (
            <div className="space-y-3">
              <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] space-y-1 text-[11px]">
                <div className="text-[#fce18b] font-bold flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#e2b054]" />
                  <span>4 Martial Equipment Slots</span>
                </div>
                <p className="text-[#9fc2b2]">
                  Gear tiers are strictly restricted by realm prerequisites.
                </p>
              </div>

              {/* 4 Equipment Slot Cards */}
              <div className="grid grid-cols-2 gap-2">
                {[
                  { slot: 'clothing' as const, label: 'Clothing / Robe', icon: <Shirt className="w-4 h-4 text-sky-400" />, item: disciple.equippedItems?.clothing },
                  { slot: 'weapon' as const, label: 'Weapon / Sword', icon: <Sword className="w-4 h-4 text-amber-400" />, item: disciple.equippedItems?.weapon },
                  { slot: 'item' as const, label: 'Item / Talisman', icon: <Gem className="w-4 h-4 text-purple-400" />, item: disciple.equippedItems?.item },
                  { slot: 'companion' as const, label: 'Companion / Beast', icon: <PawPrint className="w-4 h-4 text-emerald-400" />, item: disciple.equippedItems?.companion }
                ].map(({ slot, label, icon, item }) => (
                  <div
                    key={slot}
                    onClick={() => setSelectedEquipSlot(selectedEquipSlot === slot ? null : slot)}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                      selectedEquipSlot === slot
                        ? 'bg-[#184838] border-[#e2b054] shadow-md'
                        : 'bg-[#09261d] border-[#1b4b3b] hover:border-[#276e57]'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#fce18b]">
                      {icon}
                      <span>{label}</span>
                    </div>

                    {item ? (
                      <div className="mt-2 space-y-1">
                        <div className="font-bold text-white text-xs truncate">{item.name}</div>
                        <div className="flex items-center gap-1 text-[9px]">
                          <span className="px-1.5 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-500/40 font-mono">
                            {item.tier}
                          </span>
                          <span className="text-[#86efac]">+{item.combatBonus} Pwr</span>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-3 text-[10px] text-[#6d8e80] italic">
                        Empty Slot (Touch to Equip)
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Gear Selection Drawer */}
              {selectedEquipSlot && (
                <div className="bg-[#072018] p-3 rounded-2xl border-2 border-[#e2b054]/50 space-y-2 animate-scale-up">
                  <div className="flex justify-between items-center text-xs font-bold text-[#fce18b]">
                    <span>Available {selectedEquipSlot.toUpperCase()} Artifacts</span>
                    <button
                      onClick={() => setSelectedEquipSlot(null)}
                      className="text-[#9fc2b2] hover:text-white"
                    >
                      Close
                    </button>
                  </div>

                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {disciple.equippedItems?.[selectedEquipSlot] && (
                      <div
                        onClick={() => {
                          soundEngine.playClick();
                          onEquipItem(disciple.id, selectedEquipSlot, undefined);
                        }}
                        className="p-2 rounded-xl bg-red-950/40 border border-red-800/40 text-red-300 flex justify-between items-center cursor-pointer hover:bg-red-900/40"
                      >
                        <span className="font-bold text-[11px]">Unequip Current Item</span>
                        <span className="text-[10px]">Remove</span>
                      </div>
                    )}

                    {getAvailableEquipmentsForDisciple(disciple.currentRealmIndex, selectedEquipSlot).map(item => {
                      const isEquipped = disciple.equippedItems?.[selectedEquipSlot]?.id === item.id;
                      return (
                        <div
                          key={item.id}
                          onClick={() => {
                            soundEngine.playTalisman();
                            onEquipItem(disciple.id, selectedEquipSlot, item);
                          }}
                          className={`p-2 rounded-xl border flex justify-between items-center cursor-pointer transition-all ${
                            isEquipped
                              ? 'bg-[#184838] border-[#4ade80] shadow-sm'
                              : 'bg-[#09261d] border-[#1b4b3b] hover:border-[#276e57]'
                          }`}
                        >
                          <div>
                            <div className="font-bold text-white text-[11px] flex items-center gap-1.5">
                              <span>{item.name}</span>
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-950/80 text-amber-300 border border-amber-500/30 font-mono">
                                {item.tier}
                              </span>
                            </div>
                            <div className="text-[10px] text-[#9fc2b2]">
                              +{item.combatBonus} Combat · +{item.cultivationRateBonus}% Cultivation
                            </div>
                          </div>

                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg ${
                            isEquipped ? 'bg-emerald-900 text-emerald-300' : 'bg-[#123d30] text-[#fce18b]'
                          }`}>
                            {isEquipped ? 'Equipped' : 'Equip'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* CORE MEMORIES TAB */}
          {activeTab === 'memories' && (
            <div className="space-y-3">
              <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] space-y-1 text-[11px]">
                <div className="text-[#fce18b] font-bold flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-[#e2b054]" />
                  <span>Core Memories & Life Milestones</span>
                </div>
                <p className="text-[#9fc2b2]">
                  Significant experiences dynamically shaping this disciple's Dao heart and personality traits:
                </p>
              </div>

              <div className="space-y-2">
                {(!disciple.coreMemories || disciple.coreMemories.length === 0) ? (
                  <div className="bg-[#09261d] p-4 rounded-xl border border-[#1b4b3b] text-center text-[#9fc2b2] text-[11px]">
                    No major life-altering events recorded yet.
                  </div>
                ) : (
                  disciple.coreMemories.map(mem => (
                    <div
                      key={mem.id}
                      className="bg-[#09261d] p-3 rounded-xl border border-[#1b4b3b] space-y-1 text-xs"
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-white">{mem.event || mem.title || 'Dao Milestone'}</span>
                        <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${
                          mem.impact === 'Positive' ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-500/30' : 'bg-red-900/60 text-red-300 border border-red-500/30'
                        }`}>
                          {mem.impact || 'Neutral'}
                        </span>
                      </div>
                      <div className="text-[10px] text-[#a4c5b7]">
                        Year {mem.year} · Shaping Trait: <strong className="text-[#fce18b]">{mem.traitShaped || mem.traitAcquired || mem.personalityShift || 'Dao Focus'}</strong>
                      </div>
                    </div>
                  ))
                )}

                {/* Biography log */}
                <div className="bg-[#09261d] p-3 rounded-xl border border-[#1b4b3b] space-y-1 text-xs">
                  <span className="font-bold text-[#fce18b] block text-[11px]">Chronicle Biography</span>
                  <div className="space-y-1 text-[10px] text-[#a4c5b7] list-disc pl-3">
                    {disciple.biography.map((bio, i) => (
                      <div key={i}>• {bio}</div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SOCIAL BONDS TAB */}
          {activeTab === 'relations' && (
            <div className="space-y-3">
              <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] space-y-2">
                <span className="font-bold text-[#fce18b] block">Interpersonal Connections (1 Max Bond Per Pair)</span>
                {disciple.relations.length === 0 ? (
                  <p className="text-[#9fc2b2] text-[11px] italic">
                    Tranquil heart. Holds no grudges or active social attachments.
                  </p>
                ) : (
                  <div className="space-y-1.5">
                    {disciple.relations.map(rel => {
                      const target = allDisciples.find(d => d.id === rel.targetId);
                      if (!target) return null;
                      const lv = rel.level || 2;
                      const lvNames: Record<number, string> = {
                        1: 'Unknown',
                        2: 'Acquaintance',
                        3: 'Trusted',
                        4: 'Devoted',
                        5: 'Inseparable'
                      };
                      return (
                        <div key={rel.targetId} className="p-2.5 rounded-xl bg-[#123d30] border border-[#1b4b3b] flex justify-between items-center gap-2">
                          <div>
                            <span className="font-bold text-white">{target.name}</span>
                            <span className="text-[10px] text-[#86efac] ml-2 font-mono">
                              ({rel.type} · Lv {lv}/5 {lvNames[lv] || ''})
                            </span>
                            {rel.grudgeReason && (
                              <p className="text-[10px] text-red-300 mt-0.5">{rel.grudgeReason}</p>
                            )}
                          </div>
                          {rel.jealousy > 0 && (
                            <button
                              onClick={() => onMediateGrudge(disciple.id, rel.targetId)}
                              className="px-2 py-1 rounded-lg bg-red-950 border border-red-800 text-red-300 text-[10px] font-bold shrink-0"
                            >
                              Mediate Feud
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* PROMOTE & BESTOW TAB */}
          {activeTab === 'actions' && (
            <div className="space-y-3.5">
              <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-[#fce18b]">Promotion & Strict Requirements</span>
                  <span className="text-[10px] text-[#9fc2b2]">Current: {disciple.rank}</span>
                </div>

                <div className="space-y-1.5 pt-1">
                  {(['Outer', 'Inner', 'Direct', 'Elder', 'Grand Elder', 'Sect Leader'] as DiscipleRank[]).map(r => {
                    const req = getPromotionRequirements(r);
                    const meetsRealm = disciple.currentRealmIndex >= req.minRealmIndex;
                    const meetsContrib = (disciple.contribution || 0) >= req.minContribution;
                    const isCurrent = disciple.rank === r;

                    let isCapped = false;
                    if (r === 'Elder' && currentEldersCount >= maxEldersAllowed && !isCurrent) isCapped = true;
                    if (r === 'Grand Elder' && currentGrandEldersCount >= maxGrandEldersAllowed && !isCurrent) isCapped = true;
                    if (r === 'Sect Leader' && currentSectLeadersCount >= 1 && !isCurrent) isCapped = true;

                    const qualifies = (meetsRealm && meetsContrib && !isCapped) || devMode;

                    return (
                      <div
                        key={r}
                        className={`p-2.5 rounded-xl border flex justify-between items-center ${
                          isCurrent
                            ? 'bg-[#15803d]/40 border-[#22c55e]/50'
                            : qualifies
                            ? 'bg-[#123d30] border-[#e2b054]/40'
                            : 'bg-[#0b261d] border-[#1b4b3b] opacity-80'
                        }`}
                      >
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-white text-xs">{r}</span>
                            {qualifies && !isCurrent && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-green-900/60 text-green-300 font-bold">
                                Eligible
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-[#a4c5b7] mt-0.5">
                            {req.desc}
                          </div>
                        </div>

                        <button
                          disabled={isCurrent || (!qualifies && !devMode)}
                          onClick={() => {
                            soundEngine.playGong();
                            onPromoteRank(disciple.id, r);
                          }}
                          className={`px-3 py-1.5 rounded-xl font-dao font-bold text-[10px] transition-all ${
                            isCurrent
                              ? 'bg-gray-800 text-gray-500 cursor-default'
                              : qualifies
                              ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-95'
                              : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                          }`}
                        >
                          {isCurrent ? 'Current' : 'Promote'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 3 Bestow Actions */}
              <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] space-y-2.5">
                <span className="font-bold text-[#fce18b]">Bestow Treasures & Guidance</span>
                <div className="space-y-2">
                  <div className="flex justify-between items-center bg-[#123d30] p-2.5 rounded-xl border border-[#1b4b3b]">
                    <div>
                      <div className="font-bold text-white text-[11px]">Spirit Spring Wine</div>
                      <div className="text-[10px] text-[#9fc2b2]">+5 Loyalty · -5 to negative states</div>
                    </div>
                    <button
                      onClick={() => {
                        soundEngine.playTalisman();
                        onBestowGift(disciple.id, 'wine');
                      }}
                      className="px-3 py-1 rounded-lg bg-[#e2b054] text-[#072018] font-bold text-[10px] hover:brightness-110"
                    >
                      Bestow
                    </button>
                  </div>

                  <div className="flex justify-between items-center bg-[#123d30] p-2.5 rounded-xl border border-[#1b4b3b]">
                    <div>
                      <div className="font-bold text-cyan-300 text-[11px]">Bestow Qi Burst</div>
                      <div className="text-[10px] text-[#9fc2b2]">Grants 50% faster cultivation for 5 minutes</div>
                    </div>
                    <button
                      onClick={() => {
                        soundEngine.playCauldronBubble();
                        onBestowGift(disciple.id, 'qiburst');
                      }}
                      className="px-3 py-1 rounded-lg bg-cyan-600 text-white font-bold text-[10px] hover:brightness-110"
                    >
                      Bestow
                    </button>
                  </div>

                  <div className="flex justify-between items-center bg-[#123d30] p-2.5 rounded-xl border border-[#1b4b3b]">
                    <div>
                      <div className="font-bold text-white text-[11px]">Daoist Guidance / Technique</div>
                      <div className="text-[10px] text-[#9fc2b2]">+5 Loyalty · +5 Morale · -5 Stress</div>
                    </div>
                    <button
                      onClick={() => {
                        soundEngine.playClick();
                        onBestowGift(disciple.id, 'guidance');
                      }}
                      className="px-3 py-1 rounded-lg bg-[#15803d] text-white font-bold text-[10px] hover:brightness-110"
                    >
                      Bestow
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Disciple Jade Roster</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Close Scroll
          </button>
        </div>
      </div>

      {/* Popover explaining stat function */}
      {inspectStatKey && (
        <StatDetailModal
          statKey={inspectStatKey}
          onClose={() => setInspectStatKey(null)}
        />
      )}
    </div>
  );
};
