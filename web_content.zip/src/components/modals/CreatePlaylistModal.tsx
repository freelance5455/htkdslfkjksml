import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import { ListMusic, X, Sparkles } from 'lucide-react';

interface CreatePlaylistModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreatePlaylistModal: React.FC<CreatePlaylistModalProps> = ({ isOpen, onClose }) => {
  const { createPlaylist, setSelectedPlaylistId } = useMusic();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedTheme, setSelectedTheme] = useState(0);

  if (!isOpen) return null;

  const colorThemes = [
    { from: '#7928ca', to: '#ff0080', accent: '#a855f7', name: 'Cyber Neon' },
    { from: '#0ea5e9', to: '#ec4899', accent: '#38bdf8', name: 'Bengal Horizon' },
    { from: '#e11d48', to: '#9333ea', accent: '#fb7185', name: 'Bollywood Rose' },
    { from: '#f97316', to: '#e11d48', accent: '#fb923c', name: 'Kinetic Fire' },
    { from: '#059669', to: '#0284c7', accent: '#34d399', name: 'Deep Emerald' }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const theme = colorThemes[selectedTheme];
    const newPl = createPlaylist(title.trim(), description.trim(), theme);
    setTitle('');
    setDescription('');
    onClose();
    setSelectedPlaylistId(newPl.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-[#141622] border border-white/10 p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <ListMusic className="w-4 h-4" />
            </div>
            <h3 className="font-display font-bold text-base text-white">New Playlist</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
          <div>
            <label className="text-[11px] font-semibold text-slate-400 block mb-1">
              Playlist Name *
            </label>
            <input
              type="text"
              autoFocus
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Midnight Chill, Gym Beast..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.06] border border-white/10 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-purple-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-semibold text-slate-400 block mb-1">
              Description (Optional)
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Give your playlist a mood or purpose..."
              className="w-full px-3.5 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-purple-500 resize-none"
            />
          </div>

          <div>
            <label className="text-[11px] font-semibold text-slate-400 block mb-1.5">
              Cover Aura Theme
            </label>
            <div className="flex items-center gap-2">
              {colorThemes.map((thm, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedTheme(idx)}
                  className={`w-9 h-9 rounded-xl transition-all ${
                    selectedTheme === idx
                      ? 'ring-2 ring-white scale-110'
                      : 'opacity-70 hover:opacity-100'
                  }`}
                  style={{
                    background: `linear-gradient(135deg, ${thm.from}, ${thm.to})`
                  }}
                  title={thm.name}
                />
              ))}
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              type="submit"
              className="flex-1 py-2 rounded-xl bg-purple-600 text-white font-semibold text-xs hover:bg-purple-500 transition-colors shadow-md shadow-purple-600/30"
            >
              Create Playlist
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white/10 text-slate-300 text-xs hover:bg-white/20"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
