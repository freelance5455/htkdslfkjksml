import React, { useState } from 'react';
import {
  X,
  Wallet,
  ArrowDownCircle,
  ArrowUpCircle,
  QrCode,
  ShieldCheck,
  CheckCircle,
  Copy,
  Check,
  Building,
  CreditCard,
  UserCheck,
  Clock,
  AlertTriangle,
  Send,
  Lock,
} from 'lucide-react';
import { UserProfile, CashierRequest } from '../../types';
import { soundFX } from '../../utils/soundEffects';

interface RealMoneyWalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  cashierRequests: CashierRequest[];
  onSubmitDeposit: (req: Omit<CashierRequest, 'id' | 'timestamp' | 'status'>) => void;
  onSubmitWithdrawal: (req: Omit<CashierRequest, 'id' | 'timestamp' | 'status'>) => void;
}

export const RealMoneyWalletModal: React.FC<RealMoneyWalletModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  cashierRequests,
  onSubmitDeposit,
  onSubmitWithdrawal,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'deposit' | 'withdraw' | 'history'>('overview');
  const [depositMethod, setDepositMethod] = useState<'USDT_TRC20' | 'CASHIER_DIRECT' | 'DISTRIBUTOR' | 'BANK_TRANSFER'>('USDT_TRC20');
  const [depositAmount, setDepositAmount] = useState(100);
  const [txHashInput, setTxHashInput] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState(50);
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [copiedText, setCopiedText] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const platformUsdtAddress = 'TTabeonaRoyalTreasury99Emerald88xQ7';

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (depositAmount <= 0) return;
    soundFX.playButtonClick();

    onSubmitDeposit({
      playerId: currentUser.id,
      playerName: currentUser.name,
      type: 'DEPOSIT',
      amount: depositAmount,
      currency: 'USD',
      method: depositMethod,
      walletAddressOrAccount: platformUsdtAddress,
      txHashOrReceipt: txHashInput || `TXID_${Date.now()}`,
      notes: `إيداع نقدي حقيقي عبر ${depositMethod}`,
    });

    setFeedbackMsg(`تم تسجيل طلب الإيداع بمبلغ $${depositAmount} USD وإرساله للكاشير للمراجعة الفورية!`);
    setTxHashInput('');
    setTimeout(() => {
      setFeedbackMsg(null);
      setActiveTab('history');
    }, 1800);
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (withdrawAmount > currentUser.realCashBalance) {
      setErrorMsg('⚠️ رصيدك النقدي الحالي أقل من المبلغ المطلوب سحبه!');
      return;
    }
    if (withdrawAmount < 20) {
      setErrorMsg('⚠️ الحد الأدنى للسحب هو $20 USD!');
      return;
    }
    if (!withdrawAddress.trim()) {
      setErrorMsg('⚠️ يرجى إدخال عنوان المحفظة أو الحساب البنكي لتحويل الأرباح!');
      return;
    }

    soundFX.playButtonClick();

    onSubmitWithdrawal({
      playerId: currentUser.id,
      playerName: currentUser.name,
      type: 'WITHDRAWAL',
      amount: withdrawAmount,
      currency: 'USD',
      method: 'USDT_TRC20',
      walletAddressOrAccount: withdrawAddress.trim(),
      notes: `طلب سحب أرباح حقيقي إلى ${withdrawAddress}`,
    });

    setFeedbackMsg(`تم تقديم طلب سحب $${withdrawAmount} USD بنجاح! سيتم التنفيذ فور تدقيق الكاشير.`);
    setWithdrawAddress('');
    setTimeout(() => {
      setFeedbackMsg(null);
      setActiveTab('history');
    }, 1800);
  };

  const userRequests = cashierRequests.filter((r) => r.playerId === currentUser.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="relative w-full max-w-2xl bg-[#07130c] border-2 border-emerald-500/60 rounded-3xl shadow-[0_0_50px_rgba(16,185,129,0.4)] overflow-hidden text-right flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0c2e1b] via-[#13492b] to-[#0c2e1b] border-b border-emerald-500/40 p-4 flex items-center justify-between">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="text-gray-400 hover:text-emerald-300 p-1.5 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h2 className="text-lg font-black text-amber-300 flex items-center gap-2">
              <Wallet className="w-5 h-5 text-emerald-400" />
              المحفظة النقدية الحقيقية (Real Cash USD)
            </h2>
          </div>
        </div>

        {/* Tab Buttons */}
        <div className="grid grid-cols-4 bg-[#040e08] border-b border-amber-950 p-1 text-xs font-bold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-2 text-center rounded-xl transition-all ${
              activeTab === 'overview'
                ? 'bg-emerald-950 text-amber-300 border border-emerald-500/40 shadow'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            الرصيد العام 💵
          </button>
          <button
            onClick={() => setActiveTab('deposit')}
            className={`py-2 text-center rounded-xl transition-all ${
              activeTab === 'deposit'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40 shadow'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            إيداع نقدي 📥
          </button>
          <button
            onClick={() => setActiveTab('withdraw')}
            className={`py-2 text-center rounded-xl transition-all ${
              activeTab === 'withdraw'
                ? 'bg-amber-950 text-amber-300 border border-amber-500/40 shadow'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            سحب أرباح 📤
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-2 text-center rounded-xl transition-all ${
              activeTab === 'history'
                ? 'bg-emerald-950 text-amber-300 border border-emerald-500/40 shadow'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            سجل الكاشير ({userRequests.length})
          </button>
        </div>

        {/* Feedback Message */}
        {feedbackMsg && (
          <div className="m-4 p-3 rounded-xl bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-xs flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{feedbackMsg}</span>
          </div>
        )}

        {/* Error Message */}
        {errorMsg && (
          <div className="m-4 p-3 rounded-xl bg-red-950/80 border border-red-500 text-red-200 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          {/* 1. OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-4">
              {/* Cash Card */}
              <div className="p-6 rounded-2xl bg-gradient-to-br from-[#0c311d] via-[#082214] to-[#04110a] border-2 border-emerald-500/60 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                  <div className="text-xs text-emerald-300 font-bold mb-1 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    الرصيد النقدي الحقيقي المتاح للسحب والرهان
                  </div>
                  <div className="font-mono text-3xl md:text-4xl font-black text-amber-300 tracking-wider">
                    ${currentUser.realCashBalance.toLocaleString()} <span className="text-base text-emerald-400">USD</span>
                  </div>
                  <div className="text-[11px] text-gray-300 mt-2">
                    حساب اللاعب: {currentUser.name} (معرف: {currentUser.id})
                  </div>
                </div>

                <div className="flex flex-col gap-2 w-full md:w-auto">
                  <button
                    onClick={() => setActiveTab('deposit')}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow"
                  >
                    <ArrowDownCircle className="w-4 h-4" />
                    <span>إيداع فوري</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('withdraw')}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 text-black font-black text-xs flex items-center justify-center gap-1.5 shadow"
                  >
                    <ArrowUpCircle className="w-4 h-4" />
                    <span>سحب نقدي</span>
                  </button>
                </div>
              </div>

              {/* Verified Status Banner */}
              <div className="p-3.5 rounded-xl bg-[#05110a] border border-amber-950 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-400" />
                  <span className="text-gray-300">التحقق من الهوية والأهلية (KYC +18):</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-600 font-bold">
                  موثق ومعتمد ✓
                </span>
              </div>

              {/* Fast deposit methods guide */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-center text-xs">
                <div className="p-3 rounded-xl bg-[#05110a] border border-amber-950">
                  <div className="text-xl mb-1">🪙</div>
                  <div className="font-bold text-gray-200">USDT TRC-20</div>
                  <div className="text-[10px] text-gray-400">تحويل فوري 0% رسوم</div>
                </div>
                <div className="p-3 rounded-xl bg-[#05110a] border border-amber-950">
                  <div className="text-xl mb-1">💼</div>
                  <div className="font-bold text-gray-200">كاشير TABEONA</div>
                  <div className="text-[10px] text-gray-400">شحن يدوي مباشر</div>
                </div>
                <div className="p-3 rounded-xl bg-[#05110a] border border-amber-950">
                  <div className="text-xl mb-1">🤝</div>
                  <div className="font-bold text-gray-200">شبكة الموزعين</div>
                  <div className="text-[10px] text-gray-400">دفع محلي في منطقتك</div>
                </div>
                <div className="p-3 rounded-xl bg-[#05110a] border border-amber-950">
                  <div className="text-xl mb-1">🏦</div>
                  <div className="font-bold text-gray-200">حوالة بنكية</div>
                  <div className="text-[10px] text-gray-400">حسابات رسمية</div>
                </div>
              </div>
            </div>
          )}

          {/* 2. DEPOSIT */}
          {activeTab === 'deposit' && (
            <form onSubmit={handleDepositSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-amber-300 mb-1">1. اختر وسيلة الإيداع:</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {[
                    { id: 'USDT_TRC20', label: 'USDT (TRC-20)', icon: '💎' },
                    { id: 'CASHIER_DIRECT', label: 'كاشير مباشر', icon: '💼' },
                    { id: 'DISTRIBUTOR', label: 'موزع معتمد', icon: '🤝' },
                    { id: 'BANK_TRANSFER', label: 'تحويل بنكي', icon: '🏦' },
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setDepositMethod(m.id as any)}
                      className={`p-2.5 rounded-xl border text-center font-bold transition-all ${
                        depositMethod === m.id
                          ? 'bg-emerald-950 border-emerald-400 text-emerald-300 shadow'
                          : 'bg-[#050f0a] border-amber-950 text-gray-400'
                      }`}
                    >
                      <div className="text-lg mb-0.5">{m.icon}</div>
                      <div>{m.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {depositMethod === 'USDT_TRC20' && (
                <div className="p-4 rounded-2xl bg-[#05110a] border border-emerald-500/40 space-y-3">
                  <div className="flex flex-col md:flex-row items-center gap-4">
                    {/* Simulated QR Box */}
                    <div className="w-28 h-28 bg-white p-2 rounded-xl flex items-center justify-center shrink-0 shadow-lg">
                      <div className="w-full h-full border-2 border-black border-dashed flex flex-col items-center justify-center text-black font-black text-center text-[10px]">
                        <QrCode className="w-12 h-12 text-black mb-1" />
                        <span>USDT TRC20</span>
                      </div>
                    </div>

                    <div className="flex-1 space-y-1.5 w-full">
                      <div className="text-gray-300 font-bold">عنوان محفظة الخزينة المركزية:</div>
                      <div className="flex items-center gap-1.5 bg-[#030905] p-2 rounded-lg border border-amber-900/60 font-mono text-emerald-400 text-[11px] break-all">
                        <span className="flex-1">{platformUsdtAddress}</span>
                        <button
                          type="button"
                          onClick={() => handleCopy(platformUsdtAddress)}
                          className="p-1 rounded bg-emerald-900 hover:bg-emerald-800 text-white shrink-0"
                          title="نسخ العنوان"
                        >
                          {copiedText ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      <div className="text-[10px] text-amber-300">
                        ⚠️ أرسل فقط عملة USDT عبر شبكة TRC-20 حصراً لتفادي فقدان الرصيد.
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="block font-bold text-amber-300 mb-1">2. المبلغ المراد إيداعه ($ USD):</label>
                <div className="flex gap-2">
                  {[25, 50, 100, 250, 500].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setDepositAmount(amt)}
                      className={`flex-1 py-2 rounded-lg border font-mono font-bold ${
                        depositAmount === amt
                          ? 'bg-emerald-600 text-white border-emerald-400'
                          : 'bg-[#05110a] border-amber-950 text-gray-300'
                      }`}
                    >
                      ${amt}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-bold text-gray-300 mb-1">
                  3. رمز المعاملة (TXID) أو إشعار التحويل:
                </label>
                <input
                  type="text"
                  value={txHashInput}
                  onChange={(e) => setTxHashInput(e.target.value)}
                  placeholder="أدخل رقم الهاش أو معرّف التحويل لتأكيد المطابقة..."
                  className="w-full bg-[#050f0a] border border-amber-900/70 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 hover:from-emerald-500 text-white font-black rounded-xl text-xs shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-1.5"
              >
                <Send className="w-4 h-4" />
                <span>إرسال إشعار الإيداع للكاشير ($ {depositAmount} USD)</span>
              </button>
            </form>
          )}

          {/* 3. WITHDRAW */}
          {activeTab === 'withdraw' && (
            <form onSubmit={handleWithdrawSubmit} className="space-y-4 text-xs">
              <div className="p-3 bg-amber-950/20 border border-amber-500/30 rounded-xl text-amber-200 leading-relaxed">
                <div className="font-bold flex items-center gap-1 text-amber-300 mb-1">
                  <ShieldCheck className="w-4 h-4" />
                  شروط السحب النقدي المعتمدة:
                </div>
                الحد الأدنى للسحب هو $20 USD. يتم تدقيق وتنفيذ الحوالة عبر الكاشير المعتمد خلال 15 - 30 دقيقة مباشرة إلى محفظة الـ USDT أو الحساب البنكي المعتمد.
              </div>

              <div>
                <label className="block font-bold text-amber-300 mb-1">المبلغ المراد سحبه ($ USD):</label>
                <div className="relative">
                  <input
                    type="number"
                    min={20}
                    max={currentUser.realCashBalance}
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                    className="w-full bg-[#050f0a] border border-amber-900/70 rounded-xl px-3 py-2.5 text-white font-mono text-sm focus:outline-none"
                    required
                  />
                  <span className="absolute left-3 top-3 text-emerald-400 font-bold font-mono">
                    المتاح: ${currentUser.realCashBalance}
                  </span>
                </div>
              </div>

              <div>
                <label className="block font-bold text-amber-300 mb-1">عنوان محفظة الاستلام (USDT TRC-20):</label>
                <input
                  type="text"
                  value={withdrawAddress}
                  onChange={(e) => setWithdrawAddress(e.target.value)}
                  placeholder="مثال: TXYZ99... أو الحساب البنكي المعتمد"
                  className="w-full bg-[#050f0a] border border-amber-900/70 rounded-xl px-3 py-2.5 text-white font-mono text-xs focus:outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={currentUser.realCashBalance < withdrawAmount}
                className="w-full py-3 bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 disabled:opacity-40 hover:from-amber-500 text-black font-black rounded-xl text-xs shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-1.5"
              >
                <ArrowUpCircle className="w-4 h-4" />
                <span>تأكيد طلب سحب $ {withdrawAmount} USD للأرباح</span>
              </button>
            </form>
          )}

          {/* 4. HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-2.5 text-xs">
              {userRequests.length === 0 ? (
                <div className="text-center py-10 text-gray-400">
                  لا توجد طلبات إيداع أو سحب سابقة مسجلة لحسابك.
                </div>
              ) : (
                userRequests.map((req) => (
                  <div
                    key={req.id}
                    className="p-3.5 rounded-xl bg-[#05110a] border border-amber-950 flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-bold px-2 py-0.5 rounded text-[10px] ${
                            req.type === 'DEPOSIT'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-600'
                              : 'bg-amber-950 text-amber-300 border border-amber-600'
                          }`}
                        >
                          {req.type === 'DEPOSIT' ? 'إيداع نقدي' : 'سحب أرباح'}
                        </span>
                        <span className="font-mono text-white font-bold">
                          ${req.amount.toLocaleString()} USD
                        </span>
                      </div>
                      <div className="text-gray-400 text-[11px] mt-1">
                        الوسيلة: {req.method} • {req.timestamp}
                      </div>
                      {req.txHashOrReceipt && (
                        <div className="text-[10px] text-gray-500 font-mono mt-0.5 truncate max-w-xs">
                          الهاش: {req.txHashOrReceipt}
                        </div>
                      )}
                    </div>

                    <div className="text-left">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                          req.status === 'APPROVED'
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-600'
                            : req.status === 'PENDING'
                            ? 'bg-amber-950 text-amber-300 border-amber-600 animate-pulse'
                            : 'bg-red-950 text-red-300 border-red-600'
                        }`}
                      >
                        {req.status === 'APPROVED'
                          ? 'معتمد ومكتمل ✓'
                          : req.status === 'PENDING'
                          ? 'قيد مراجعة الكاشير ⏳'
                          : 'مرفوض ✗'}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
