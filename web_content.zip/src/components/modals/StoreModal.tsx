import React, { useState } from 'react';
import { X, ShoppingCart, Gem, Coins, Crown, Sparkles, Check } from 'lucide-react';
import { UserProfile, SkinItem } from '../../types';
import { soundFX } from '../../utils/soundEffects';

interface StoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onBuyItem: (item: any) => void;
}

export const StoreModal: React.FC<StoreModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onBuyItem,
}) => {
  const [activeTab, setActiveTab] = useState<'coins' | 'gems' | 'skins' | 'vip'>('coins');
  const [successNote, setSuccessNote] = useState<string | null>(null);

  if (!isOpen) return null;

  const coinsPacks = [
    { id: 'cp1', name: 'حقيبة كوينز مبتدئ', amount: 10000, price: '100 جوهرة', icon: '🪙', bonus: '+10%' },
    { id: 'cp2', name: 'صندوق كوينز ملكي', amount: 50000, price: '450 جوهرة', icon: '💰', bonus: '+25%' },
    { id: 'cp3', name: 'خزنة كوينز الأساطير', amount: 200000, price: '1,500 جوهرة', icon: '👑', bonus: '+50%' },
  ];

  const gemsPacks = [
    { id: 'gp1', name: 'حفنة جواهر زمردية', amount: 500, price: '$4.99', icon: '💎', bonus: 'الأكثر شعبية' },
    { id: 'gp2', name: 'صندوق الجواهر الإمبراطوري', amount: 2500, price: '$19.99', icon: '💎💎', bonus: '+30% إضافي' },
    { id: 'gp3', name: 'كنز الزمرد الملكي', amount: 10000, price: '$69.99', icon: '✨💎✨', bonus: '+70% إضافي' },
  ];

  const skinsItems: SkinItem[] = [
    {
      id: 'skin-deck-emerald',
      name: 'ظهر ورق: الزمرد الملكي (Royal Emerald v1)',
      game: 'طرنيب / تركس',
      category: 'card_back',
      rarity: 'Royal',
      priceCoins: 25000,
      previewUrl: '👑 Emerald & Gold Trim',
      status: 'PUBLISHED',
      version: 'v1.0',
    },
    {
      id: 'skin-felt-obsidian',
      name: 'طاولة: الفحم الأسود الفاخر (Obsidian Velvet)',
      game: 'طرنيب',
      category: 'table_felt',
      rarity: 'Legendary',
      priceCoins: 35000,
      previewUrl: '🖤 Deep Matte Gold Accent',
      status: 'PUBLISHED',
      version: 'v1.2',
    },
  ];

  const handleBuy = (item: any) => {
    soundFX.playCoin();
    onBuyItem(item);
    setSuccessNote(`تمت العملية بنجاح! أضيف إلى حسابك.`);
    setTimeout(() => setSuccessNote(null), 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="relative w-full max-w-3xl bg-[#07130c] border-2 border-amber-500/50 rounded-2xl shadow-[0_0_40px_rgba(16,185,129,0.3)] overflow-hidden text-right flex flex-col h-[75vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0b2416] via-[#123823] to-[#0b2416] border-b border-amber-500/30 p-4 flex items-center justify-between">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="text-gray-400 hover:text-amber-400 p-1 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold text-amber-300">متجر TABEONA الملكي</h2>
          </div>
        </div>

        {/* Tab buttons */}
        <div className="grid grid-cols-4 bg-[#050e08] border-b border-amber-950 p-1 text-xs font-bold">
          <button
            onClick={() => setActiveTab('coins')}
            className={`py-2 text-center rounded-lg ${activeTab === 'coins' ? 'bg-amber-950/80 text-amber-300 border border-amber-500/40' : 'text-gray-400'}`}
          >
            الكوينز 🪙
          </button>
          <button
            onClick={() => setActiveTab('gems')}
            className={`py-2 text-center rounded-lg ${activeTab === 'gems' ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40' : 'text-gray-400'}`}
          >
            الجواهر 💎
          </button>
          <button
            onClick={() => setActiveTab('skins')}
            className={`py-2 text-center rounded-lg ${activeTab === 'skins' ? 'bg-purple-950/80 text-purple-300 border border-purple-500/40' : 'text-gray-400'}`}
          >
            السكنات 🎨
          </button>
          <button
            onClick={() => setActiveTab('vip')}
            className={`py-2 text-center rounded-lg ${activeTab === 'vip' ? 'bg-amber-950/80 text-amber-300 border border-amber-500/40' : 'text-gray-400'}`}
          >
            عضوية VIP 👑
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 overflow-y-auto">
          {successNote && (
            <div className="mb-4 p-3 bg-emerald-900/60 border border-emerald-500 text-emerald-200 rounded-xl text-xs flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>{successNote}</span>
            </div>
          )}

          {activeTab === 'coins' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {coinsPacks.map((pack) => (
                <div key={pack.id} className="p-4 rounded-xl bg-[#05110a] border border-amber-950 text-center flex flex-col justify-between">
                  <div className="relative">
                    <span className="text-4xl mb-2 block">{pack.icon}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                      {pack.bonus}
                    </span>
                    <h3 className="font-bold text-sm text-gray-100 mt-2">{pack.name}</h3>
                    <div className="text-xl font-black text-amber-400 mt-1 font-mono">
                      {pack.amount.toLocaleString()} 🪙
                    </div>
                  </div>
                  <button
                    onClick={() => handleBuy(pack)}
                    className="mt-4 py-2 bg-gradient-to-r from-amber-600 to-amber-500 text-black font-extrabold text-xs rounded-xl shadow-md active:scale-95 transition-transform"
                  >
                    شراء بـ {pack.price}
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'gems' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {gemsPacks.map((pack) => (
                <div key={pack.id} className="p-4 rounded-xl bg-[#05110a] border border-emerald-950 text-center flex flex-col justify-between">
                  <div>
                    <span className="text-4xl mb-2 block">{pack.icon}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                      {pack.bonus}
                    </span>
                    <h3 className="font-bold text-sm text-gray-100 mt-2">{pack.name}</h3>
                    <div className="text-xl font-black text-emerald-400 mt-1 font-mono">
                      {pack.amount.toLocaleString()} 💎
                    </div>
                  </div>
                  <button
                    onClick={() => handleBuy(pack)}
                    className="mt-4 py-2 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-md active:scale-95 transition-transform"
                  >
                    شراء مقابل {pack.price}
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'skins' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {skinsItems.map((skin) => (
                <div key={skin.id} className="p-4 rounded-xl bg-[#05110a] border border-amber-950 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded border border-amber-500/40 font-bold">
                        {skin.rarity}
                      </span>
                      <span className="text-[10px] text-gray-400 font-mono">{skin.version}</span>
                    </div>
                    <h3 className="font-bold text-sm text-gray-100">{skin.name}</h3>
                    <p className="text-xs text-gray-400 mt-1">{skin.previewUrl}</p>
                    <div className="text-base font-bold text-amber-400 mt-2">
                      {skin.priceCoins?.toLocaleString()} كوينز
                    </div>
                  </div>
                  <button
                    onClick={() => handleBuy(skin)}
                    className="mt-4 py-2 bg-gradient-to-r from-emerald-700 to-emerald-600 text-white font-bold text-xs rounded-xl active:scale-95 transition-transform"
                  >
                    اقتناء السكن الآن
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'vip' && (
            <div className="p-6 rounded-2xl bg-gradient-to-b from-[#0e2c1c] to-[#06140d] border border-amber-500/40 text-center space-y-4">
              <Crown className="w-12 h-12 text-amber-400 mx-auto animate-bounce" />
              <h3 className="text-xl font-black text-amber-300">عضوية VIP الملكية</h3>
              <p className="text-xs text-gray-300 max-w-md mx-auto leading-relaxed">
                مزايا شكلية حصرية: إطار بروفايل ذهبي متوهج، مؤثرات دخول فاخرة للطاولات، شارات خاصة، ومكافأة يومية مضاعفة. (العضوية لا تمنح أي أفضلية لعب غير عادلة).
              </p>
              <div className="font-mono text-amber-400 font-bold text-lg">999 جوهرة شهريًا</div>
              <button
                onClick={() => handleBuy({ id: 'vip-pass', name: 'VIP Pass', price: 999 })}
                className="px-8 py-2.5 bg-gradient-to-r from-amber-600 to-amber-500 text-black font-black text-sm rounded-xl shadow-lg active:scale-95 transition-transform"
              >
                تفعيل عضوية VIP الآن 👑
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
