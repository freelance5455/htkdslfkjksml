import React from 'react';
import { useMusic } from '../../context/MusicContext';
import { CoverArt } from '../common/CoverArt';
import { MusicListItem } from '../cards/MusicListItem';
import { X, Play, Heart, Check, Users } from 'lucide-react';

export const ArtistDetailModal: React.FC = () => {
  const {
    selectedArtistId,
    setSelectedArtistId,
    artists,
    songs,
    playSong
  } = useMusic();

  if (!selectedArtistId) return null;

  const artist = artists.find((a) => a.id === selectedArtistId);
  if (!artist) return null;

  const artistSongs = songs.filter(
    (s) => s.artistId === artist.id || s.artist.includes(artist.name)
  );

  const handlePlayTop = () => {
    if (artistSongs.length > 0) {
      playSong(artistSongs[0], artistSongs);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0b0c10] text-slate-100 overflow-y-auto animate-in fade-in">
      {/* Background Gradient */}
      <div
        className="absolute inset-0 opacity-40 blur-3xl pointer-events-none"
        style={{
          background: `radial-gradient(circle at 50% 20%, ${artist.colorTheme.from} 0%, ${artist.colorTheme.to} 70%, #000000 100%)`
        }}
      />

      {/* Top Header Row */}
      <div className="relative z-10 flex items-center justify-between p-4 max-w-4xl mx-auto w-full">
        <button
          onClick={() => setSelectedArtistId(null)}
          className="p-2 rounded-full hover:bg-white/10 text-slate-300 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto w-full px-5 pb-8 space-y-6">
        {/* Artist Profile Header */}
        <div className="flex flex-col sm:flex-row items-center sm:items-end gap-5 text-center sm:text-left">
          <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full overflow-hidden shadow-2xl ring-2 ring-white/20">
            <CoverArt
              artKey={artist.image}
              title={artist.name}
              artist={artist.name}
              colorTheme={artist.colorTheme}
              type="artist"
              size="lg"
              className="w-full h-full"
            />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs text-purple-300 font-semibold uppercase tracking-wider">
              <span>Verified Artist</span>
              <Check className="w-3.5 h-3.5 stroke-[3]" />
            </div>

            <h1 className="font-display font-black text-2xl sm:text-4xl text-white tracking-tight leading-tight mt-1 truncate">
              {artist.name}
            </h1>

            <p className="text-xs text-slate-400 mt-1 max-w-lg leading-relaxed">
              {artist.bio}
            </p>

            <div className="flex items-center justify-center sm:justify-start gap-3 mt-3 text-xs text-slate-300">
              <span className="flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-pink-400" />
                <span>{artist.followers} Followers</span>
              </span>
              <span>·</span>
              <span className="text-purple-300">{artist.monthlyListeners} Monthly Listeners</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-center sm:justify-start gap-3 pt-2">
          <button
            onClick={handlePlayTop}
            disabled={artistSongs.length === 0}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-purple-600/30 transition-all active:scale-95"
          >
            <Play className="w-4 h-4 fill-white ml-0.5" />
            <span>Play Discography</span>
          </button>
        </div>

        {/* Top Songs */}
        <div className="space-y-3">
          <h3 className="font-display font-bold text-base text-white px-1">
            Top Releases
          </h3>
          <div className="space-y-1.5 bg-white/[0.02] p-2 rounded-3xl border border-white/[0.04]">
            {artistSongs.map((song, idx) => (
              <MusicListItem
                key={song.id}
                song={song}
                rank={idx + 1}
                showRank={true}
                contextQueue={artistSongs}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
