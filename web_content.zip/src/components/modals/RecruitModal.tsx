import React, { useState, useMemo } from 'react';
import {
  SpiritRootType,
  ConstitutionType,
  SocialBackground,
  TalentTier,
  SkinTone,
  ClothingColor,
  AvatarAuraEffect,
  MythicalFormType,
  DiscipleExpression,
  CultivationPathType,
  SectAlignment
} from '../../types/cultivation';
import { CultivatorAvatar, CUSTOM_HAIR_COLORS, DISCIPLE_EXPRESSIONS } from '../cultivation/CultivatorAvatar';
import { TALENT_TIER_DETAILS, CONSTITUTION_EFFECTS } from '../../data/loreData';
import { soundEngine } from '../../services/audioEngine';
import {
  GraduationCap,
  Sparkles,
  UserCheck,
  RefreshCw,
  X,
  Eye,
  Edit3,
  Zap,
  Crown,
  Compass
} from 'lucide-react';

export interface Candidate {
  id: string;
  name: string;
  gender: 'Male' | 'Female';
  age: number;
  talent: number;
  talentTier: TalentTier;
  temperament: 'Calm' | 'Arrogant' | 'Benevolent' | 'Ruthless' | 'Carefree' | 'Loyal';
  preference: 'Combat' | 'Alchemy' | 'Meditation' | 'Social' | 'Exploration';
  spiritRoot: SpiritRootType;
  spiritRootPurity: string;
  constitution: ConstitutionType;
  background: SocialBackground;
  cultivationType?: CultivationPathType;
  personalAlignment?: SectAlignment;
  appearanceIndex?: number;
  skinTone?: SkinTone;
  clothingColor?: ClothingColor;
  hairColor?: string;
  expression?: DiscipleExpression;
  auraEffect?: AvatarAuraEffect;
  mythicalForm?: MythicalFormType;
  revealedRoot?: boolean;
  revealedHeart?: boolean;
}

interface RecruitModalProps {
  currentCount: number;
  maxCount: number;
  spiritStones: number;
  merit: number;
  devMode?: boolean;
  onClose: () => void;
  onAcceptCandidate: (candidate: Candidate, costStones: number, costMerit: number) => void;
  onRefreshCandidatesCost?: (cost: number) => boolean;
}

const FIRST_NAMES = ['Fang', 'Lin', 'Ye', 'Xiao', 'Gu', 'Chu', 'Mu', 'Bai', 'Wang', 'Song', 'Han', 'Jiang', 'Mo', 'Tang', 'Sima'];
const LAST_NAMES = ['Yuan', 'Dong', 'Chen', 'Yan', 'Qing', 'Feng', 'Xue', 'Mo', 'Li', 'Hao', 'Tian', 'Zun', 'Xuan', 'Yu', 'Zhen'];

const CULTIVATION_PATHS: { id: CultivationPathType; label: string; note: string }[] = [
  { id: 'Qi Cultivator', label: 'Qi Cultivator', note: 'Balanced essence & standard tribulations' },
  { id: 'Body Cultivator', label: 'Body Cultivator', note: 'Pure Flesh Tempering · Bypasses Lightning Tribulations' },
  { id: 'Sword Cultivator', label: 'Sword Cultivator', note: 'High lethal blade strike focus' },
  { id: 'Soul Cultivator', label: 'Soul Cultivator', note: 'Mental array mastery & calm Dao-heart' },
  { id: 'Alchemy Dao', label: 'Alchemy Dao', note: 'Natural cauldron furnace affinity' }
];

const PERSONAL_ALIGNMENTS: SectAlignment[] = [
  'Righteous Orthodox',
  'Cloud Mist Neutral',
  'Buddhic Zen',
  'Imperial Court',
  'Demonic Blood Cult'
];

const SKIN_TONES: { id: SkinTone; swatch: string }[] = [
  { id: 'Fair Jade', swatch: '#fde6d6' },
  { id: 'Warm Honey', swatch: '#f6cba2' },
  { id: 'Sun Bronze', swatch: '#c9844c' }
];

const STANDARD_CLOTHING_COLORS: { id: ClothingColor; label: string; hex: string }[] = [
  { id: 'Azure', label: 'Azure', hex: '#0284c7' },
  { id: 'Gold', label: 'Gold', hex: '#eab308' },
  { id: 'Crimson', label: 'Crimson', hex: '#dc2626' },
  { id: 'Pine', label: 'Pine', hex: '#15803d' },
  { id: 'Ebon', label: 'Ebon', hex: '#18181b' }
];

const SPECIAL_CLOTHING_COLORS: { id: ClothingColor; label: string; hex: string; accent: string }[] = [
  { id: 'Celestial Violet', label: 'Celestial Violet', hex: '#6d28d9', accent: '#f5d0fe' },
  { id: 'Astral Jade', label: 'Astral Jade', hex: '#0d9488', accent: '#fde047' },
  { id: 'Primordial Obsidian', label: 'Obsidian Gold', hex: '#0f172a', accent: '#fbbf24' },
  { id: 'Phoenix Scarlet', label: 'Phoenix Scarlet', hex: '#e11d48', accent: '#fde047' },
  { id: 'Heavenly White', label: 'Heavenly White', hex: '#f8fafc', accent: '#d4af37' }
];

const AURA_EFFECTS: { id: AvatarAuraEffect; label: string; desc: string; badgeColor: string }[] = [
  { id: 'None', label: 'Serene Qi', desc: 'Pure ambient halo', badgeColor: '#64748b' },
  { id: 'Azure Thunder', label: 'Azure Thunder', desc: 'Crackling sky arcs', badgeColor: '#38bdf8' },
  { id: 'Golden Lightning', label: 'Golden Lightning', desc: 'Tribulation bolts', badgeColor: '#facc15' },
  { id: 'Void Sparks', label: 'Void Sparks', desc: 'Abyssal lightning', badgeColor: '#c084fc' },
  { id: 'Celestial Flame', label: 'Celestial Flame', desc: 'Phoenix fire wisps', badgeColor: '#f97316' }
];

const MYTHICAL_FORMS: { id: MythicalFormType; title: string; subtitle: string; appIdx: number; badge: string }[] = [
  {
    id: 'None',
    title: 'Classic Cultivator',
    subtitle: 'Standard Mortal-to-Immortal Style',
    appIdx: 0,
    badge: 'Classic'
  },
  {
    id: 'Thunder Sovereign',
    title: 'Nine-Heavens Thunder Sovereign',
    subtitle: 'Celestial Crown · Astral Silk · Third Eye',
    appIdx: 10,
    badge: 'Mythical I'
  },
  {
    id: 'Immortal Beast',
    title: 'Primordial Dragon-Phoenix',
    subtitle: 'Dragon Horns · Phoenix Plumes · Lotus Sigil',
    appIdx: 11,
    badge: 'Mythical II'
  }
];

function generateRandomCandidate(): Candidate {
  const gender = Math.random() > 0.5 ? 'Male' : 'Female';
  const name = `${FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)]} ${LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)]}`;
  const age = 16 + Math.floor(Math.random() * 11);

  // Strict rarity weights: top-tier Innate/Prodigy are nearly impossible from random mountain trials
  const roll = Math.random();
  let talentTier: TalentTier = 'Mediocre';
  let talentScore = 58;

  if (roll < 0.015) {
    // 1.5% extreme luck Innate
    talentTier = 'Innate';
    talentScore = 92 + Math.floor(Math.random() * 6);
  } else if (roll < 0.105) {
    // 9% Prodigy
    talentTier = 'Prodigy';
    talentScore = 82 + Math.floor(Math.random() * 8);
  } else if (roll < 0.42) {
    // 31.5% Talented
    talentTier = 'Talented';
    talentScore = 70 + Math.floor(Math.random() * 10);
  } else if (roll < 0.80) {
    // 38% Mediocre
    talentTier = 'Mediocre';
    talentScore = 53 + Math.floor(Math.random() * 14);
  } else {
    // 20% Poor / Lazy
    talentTier = Math.random() > 0.35 ? 'Poor' : 'Lazy';
    talentScore = 34 + Math.floor(Math.random() * 17);
  }

  // Spirit root rarity: 86.5% standard five elements, 12% mutated, <1.5% mythic
  const rootRoll = Math.random();
  let root: SpiritRootType = 'Metal';
  if (rootRoll < 0.014) {
    const mythic: SpiritRootType[] = ['Chaos', 'Heavenly', 'Immortal'];
    root = mythic[Math.floor(Math.random() * mythic.length)];
  } else if (rootRoll < 0.135) {
    const mutated: SpiritRootType[] = ['Thunder', 'Ice', 'Wind', 'Yin-Yang'];
    root = mutated[Math.floor(Math.random() * mutated.length)];
  } else {
    const basic: SpiritRootType[] = ['Metal', 'Wood', 'Water', 'Fire', 'Earth'];
    root = basic[Math.floor(Math.random() * basic.length)];
  }

  // ~72% Mortal Bone so special physiques stay scarce outside Custom Creation
  const specialConstitutions: ConstitutionType[] = [
    'Innate Sword Embryo',
    'Ancient Desolate Sacred Physique',
    'Pure Yang Divine Body',
    'Pure Yin Sacred Body',
    'Nine Heavens Phoenix Body',
    'Five Elements Dao Body',
    'Clear Jade Physique',
    'Nether Void Body'
  ];
  const constitution: ConstitutionType = Math.random() < 0.72
    ? 'Mortal Bone'
    : specialConstitutions[Math.floor(Math.random() * specialConstitutions.length)];

  const backgrounds: SocialBackground[] = [
    'Mountain Village Mortal',
    'Wandering Rogue Cultivator',
    'Extinct Clan Orphan',
    'Merchant Guild Heir',
    'Daoist Temple Acolyte',
    'Ancient Aristocrat Prodigy',
    'Imperial Clan Scion'
  ];
  const background = Math.random() < 0.82
    ? backgrounds[Math.floor(Math.random() * 5)]
    : backgrounds[5 + Math.floor(Math.random() * 2)];

  const temperaments: ('Calm' | 'Arrogant' | 'Benevolent' | 'Ruthless' | 'Carefree' | 'Loyal')[] = [
    'Calm', 'Arrogant', 'Benevolent', 'Ruthless', 'Carefree', 'Loyal'
  ];
  const temperament = temperaments[Math.floor(Math.random() * temperaments.length)];

  const preferences: ('Combat' | 'Alchemy' | 'Meditation' | 'Social' | 'Exploration')[] = [
    'Combat', 'Alchemy', 'Meditation', 'Social', 'Exploration'
  ];
  const preference = preferences[Math.floor(Math.random() * preferences.length)];

  const pathRoll = Math.random();
  let cultivationType: CultivationPathType = 'Qi Cultivator';
  if (pathRoll < 0.22) cultivationType = 'Body Cultivator';
  else if (pathRoll < 0.42) cultivationType = 'Sword Cultivator';
  else if (pathRoll < 0.56) cultivationType = 'Soul Cultivator';
  else if (pathRoll < 0.68) cultivationType = 'Alchemy Dao';

  const personalAlignment = PERSONAL_ALIGNMENTS[Math.floor(Math.random() * PERSONAL_ALIGNMENTS.length)];

  return {
    id: 'c_' + Math.random().toString(36).substring(2, 9),
    name,
    gender,
    age,
    talent: talentScore,
    talentTier,
    temperament,
    preference,
    spiritRoot: root,
    spiritRootPurity: ['Chaos', 'Heavenly', 'Immortal'].includes(root)
      ? 'Mythic Dao Root'
      : ['Thunder', 'Ice', 'Wind', 'Yin-Yang'].includes(root)
      ? 'Mutated Divine Root'
      : 'True Root',
    constitution,
    background,
    cultivationType,
    personalAlignment,
    appearanceIndex: Math.floor(Math.random() * 10),
    skinTone: SKIN_TONES[Math.floor(Math.random() * SKIN_TONES.length)].id,
    clothingColor: STANDARD_CLOTHING_COLORS[Math.floor(Math.random() * STANDARD_CLOTHING_COLORS.length)].id,
    expression: DISCIPLE_EXPRESSIONS[Math.floor(Math.random() * DISCIPLE_EXPRESSIONS.length)].id,
    revealedRoot: false,
    revealedHeart: false
  };
}

export const RecruitModal: React.FC<RecruitModalProps> = ({
  currentCount,
  maxCount,
  spiritStones,
  merit,
  devMode = false,
  onClose,
  onAcceptCandidate,
  onRefreshCandidatesCost
}) => {
  const [activeTab, setActiveTab] = useState<'trials' | 'custom'>('trials');
  const [refreshError, setRefreshError] = useState<string | null>(null);

  const TRIAL_COST_STONES = 50;
  const REFRESH_COST_STONES = 25;

  const [candidates, setCandidates] = useState<Candidate[]>([
    generateRandomCandidate(),
    generateRandomCandidate(),
    generateRandomCandidate()
  ]);

  // Custom Disciple Form State
  const [customName, setCustomName] = useState('Ling Tian');
  const [customGender, setCustomGender] = useState<'Male' | 'Female'>('Male');
  const [customAge] = useState(18);
  const [customCultivationType, setCustomCultivationType] = useState<CultivationPathType>('Qi Cultivator');
  const [customPersonalAlignment, setCustomPersonalAlignment] = useState<SectAlignment>('Righteous Orthodox');
  const [customMythicalForm, setCustomMythicalForm] = useState<MythicalFormType>('None');
  const [customAppearanceIndex, setCustomAppearanceIndex] = useState(0);
  const [customSkinTone, setCustomSkinTone] = useState<SkinTone>('Fair Jade');
  const [customClothingColor, setCustomClothingColor] = useState<ClothingColor>('Celestial Violet');
  const [customHairColor, setCustomHairColor] = useState<string>(CUSTOM_HAIR_COLORS[0].id);
  const [customExpression, setCustomExpression] = useState<DiscipleExpression>('Stoic');
  const [customAuraEffect, setCustomAuraEffect] = useState<AvatarAuraEffect>('Azure Thunder');
  const [customRoot, setCustomRoot] = useState<SpiritRootType>('Thunder');
  const [customTalentTier, setCustomTalentTier] = useState<TalentTier>('Prodigy');
  const [customConstitution, setCustomConstitution] = useState<ConstitutionType>('Innate Sword Embryo');
  const [customBackground] = useState<SocialBackground>('Wandering Rogue Cultivator');
  const [customTemperament] = useState<'Calm' | 'Arrogant' | 'Benevolent' | 'Ruthless' | 'Carefree' | 'Loyal'>('Calm');
  const [customPreference] = useState<'Combat' | 'Alchemy' | 'Meditation' | 'Social' | 'Exploration'>('Combat');

  // Dynamic Custom Creation Cost Scaling based on Talent, Root, Physique, Form & FX
  const { customCostStones, customCostMerit } = useMemo(() => {
    let stones = 120;
    let reqMerit = 40;

    if (customTalentTier === 'Mediocre') { stones += 20; reqMerit += 10; }
    else if (customTalentTier === 'Talented') { stones += 80; reqMerit += 40; }
    else if (customTalentTier === 'Prodigy') { stones += 220; reqMerit += 120; }
    else if (customTalentTier === 'Innate') { stones += 500; reqMerit += 300; }

    if (['Chaos', 'Heavenly', 'Immortal'].includes(customRoot)) {
      stones += 350;
      reqMerit += 220;
    } else if (['Thunder', 'Ice', 'Wind', 'Yin-Yang'].includes(customRoot)) {
      stones += 100;
      reqMerit += 50;
    }

    if (customConstitution !== 'Mortal Bone') {
      stones += 150;
      reqMerit += 80;
    }

    if (customMythicalForm !== 'None') {
      stones += 400;
      reqMerit += 250;
    }

    if (customAuraEffect !== 'None') {
      stones += 60;
      reqMerit += 25;
    }

    return { customCostStones: stones, customCostMerit: reqMerit };
  }, [customTalentTier, customRoot, customConstitution, customMythicalForm, customAuraEffect]);

  const refreshCandidates = () => {
    setRefreshError(null);
    if (!devMode && spiritStones < REFRESH_COST_STONES) {
      setRefreshError(`Need ${REFRESH_COST_STONES} Spirit Stones to summon new candidates.`);
      soundEngine.playClick();
      return;
    }
    if (onRefreshCandidatesCost) {
      const ok = onRefreshCandidatesCost(devMode ? 0 : REFRESH_COST_STONES);
      if (!ok) {
        setRefreshError(`Need ${REFRESH_COST_STONES} Spirit Stones to refresh Gate Trials.`);
        return;
      }
    }
    soundEngine.playTalisman();
    setCandidates([
      generateRandomCandidate(),
      generateRandomCandidate(),
      generateRandomCandidate()
    ]);
  };

  const testRoot = (candId: string) => {
    soundEngine.playTalisman();
    setCandidates(prev => prev.map(c => c.id === candId ? { ...c, revealedRoot: true } : c));
  };

  const testHeart = (candId: string) => {
    soundEngine.playGong();
    setCandidates(prev => prev.map(c => c.id === candId ? { ...c, revealedHeart: true } : c));
  };

  const handleSelectMythicalForm = (form: MythicalFormType) => {
    soundEngine.playTalisman();
    setCustomMythicalForm(form);
    if (form === 'Thunder Sovereign') {
      setCustomAppearanceIndex(10);
      setCustomAuraEffect('Golden Lightning');
      setCustomClothingColor('Celestial Violet');
    } else if (form === 'Immortal Beast') {
      setCustomAppearanceIndex(11);
      setCustomAuraEffect('Celestial Flame');
      setCustomClothingColor('Astral Jade');
    } else if (customAppearanceIndex >= 10) {
      setCustomAppearanceIndex(0);
    }
  };

  const handleCreateCustom = () => {
    if (!customName.trim()) return;
    if (!devMode && (spiritStones < customCostStones || merit < customCostMerit)) {
      return;
    }

    soundEngine.playGong();

    let talentScore = 85;
    if (customTalentTier === 'Innate') talentScore = 95;
    else if (customTalentTier === 'Prodigy') talentScore = 86;
    else if (customTalentTier === 'Talented') talentScore = 75;
    else if (customTalentTier === 'Mediocre') talentScore = 60;
    else talentScore = 45;

    const newCand: Candidate = {
      id: 'custom_' + Date.now(),
      name: customName.trim(),
      gender: customGender,
      age: customAge,
      talent: talentScore,
      talentTier: customTalentTier,
      temperament: customTemperament,
      preference: customPreference,
      spiritRoot: customRoot,
      spiritRootPurity: ['Chaos', 'Heavenly', 'Immortal'].includes(customRoot)
        ? 'Mythic Dao Root'
        : ['Thunder', 'Ice', 'Wind', 'Yin-Yang'].includes(customRoot)
        ? 'Mutated Divine Root'
        : 'True Root',
      constitution: customConstitution,
      background: customBackground,
      cultivationType: customCultivationType,
      personalAlignment: customPersonalAlignment,
      appearanceIndex: customMythicalForm === 'Thunder Sovereign' ? 10 : customMythicalForm === 'Immortal Beast' ? 11 : customAppearanceIndex,
      skinTone: customSkinTone,
      clothingColor: customClothingColor,
      hairColor: customHairColor,
      expression: customExpression,
      auraEffect: customAuraEffect,
      mythicalForm: customMythicalForm,
      revealedRoot: true,
      revealedHeart: true
    };

    onAcceptCandidate(newCand, customCostStones, customCostMerit);
  };

  const canAffordTrial = devMode || spiritStones >= TRIAL_COST_STONES;
  const canAffordCustom = devMode || (spiritStones >= customCostStones && merit >= customCostMerit);

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] relative">
        {/* Sticky Header */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-[#fce18b]" />
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
                Hall of Immortal Selection
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                Capacity: <span className="font-mono text-white">{currentCount} / {maxCount}</span> · Stones: <span className="text-amber-300 font-mono">{spiritStones}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-2 bg-[#09261d] border-b border-[#1b4b3b] text-xs font-bold font-dao">
          <button
            onClick={() => setActiveTab('trials')}
            className={`py-2.5 px-2 text-center transition-all min-h-[42px] ${
              activeTab === 'trials'
                ? 'bg-[#184838] text-[#fce18b] border-b-2 border-[#e2b054]'
                : 'text-[#8daea0] hover:text-white'
            }`}
          >
            Gate Trials ({TRIAL_COST_STONES} Stones)
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`py-2.5 px-2 text-center transition-all flex items-center justify-center gap-1.5 min-h-[42px] ${
              activeTab === 'custom'
                ? 'bg-[#184838] text-[#fce18b] border-b-2 border-[#e2b054]'
                : 'text-[#8daea0] hover:text-white'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5 text-[#e2b054]" />
            <span>Custom ({customCostStones}S + {customCostMerit}M)</span>
          </button>
        </div>

        <div className="p-3.5 sm:p-4 overflow-y-auto space-y-4 grow text-xs text-[#d1e6dc]">
          {activeTab === 'trials' ? (
            <>
              <div className="flex justify-between items-center gap-2">
                <span className="text-[11px] text-[#a4c5b7]">
                  Prodigies are ultra-rare at mountain trials; summon higher destiny via Custom Creation.
                </span>
                <button
                  onClick={refreshCandidates}
                  className="px-3 py-1.5 rounded-lg bg-[#09261d] text-[#fce18b] border border-[#e2b054]/40 text-[11px] font-bold flex items-center gap-1.5 hover:bg-[#184838] min-h-[36px] shrink-0"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{devMode ? 'Refresh (Free)' : `Refresh (${REFRESH_COST_STONES}S)`}</span>
                </button>
              </div>

              {refreshError && (
                <div className="p-2 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-[11px]">
                  {refreshError}
                </div>
              )}

              <div className="space-y-3">
                {candidates.map((cand) => (
                  <div
                    key={cand.id}
                    className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-3"
                  >
                    <div className="flex items-center gap-3">
                      <CultivatorAvatar
                        gender={cand.gender}
                        rank="Outer"
                        spiritRoot={cand.spiritRoot}
                        realmIndex={0}
                        appearanceIndex={cand.appearanceIndex}
                        skinTone={cand.skinTone}
                        clothingColor={cand.clothingColor}
                        expression={cand.expression}
                        size="md"
                      />
                      <div className="min-w-0 grow">
                        <div className="flex justify-between items-start gap-2">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <strong className="text-white text-sm font-dao">{cand.name}</strong>
                            <span className="text-[10px] text-[#a4c5b7]">({cand.gender}, Age {cand.age})</span>
                          </div>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#184838] text-[#fce18b] font-bold border border-[#e2b054]/30 whitespace-nowrap">
                            {cand.talentTier}
                          </span>
                        </div>
                        <div className="text-[10px] text-[#fde047] mt-0.5 flex flex-wrap gap-2">
                          <span>Origin: {cand.background}</span>
                          <span>·</span>
                          <span className="text-sky-300">{cand.cultivationType || 'Qi Cultivator'}</span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="bg-[#123d30] p-2 rounded-xl border border-[#1b4b3b]">
                        <div className="text-[10px] text-[#8daea0]">Spirit Root:</div>
                        {cand.revealedRoot ? (
                          <div className="font-bold text-[#86efac]">
                            {cand.spiritRoot} ({cand.spiritRootPurity})
                          </div>
                        ) : (
                          <button
                            onClick={() => testRoot(cand.id)}
                            className="text-[10px] text-[#e2b054] underline hover:text-[#fce18b] flex items-center gap-1 mt-0.5"
                          >
                            <Eye className="w-3 h-3" />
                            <span>Test Root Crystal</span>
                          </button>
                        )}
                      </div>

                      <div className="bg-[#123d30] p-2 rounded-xl border border-[#1b4b3b]">
                        <div className="text-[10px] text-[#8daea0]">Physique &amp; Alignment:</div>
                        {cand.revealedHeart ? (
                          <div className="font-bold text-[#93c5fd] truncate">
                            {cand.constitution} · {cand.personalAlignment || 'Neutral'}
                          </div>
                        ) : (
                          <button
                            onClick={() => testHeart(cand.id)}
                            className="text-[10px] text-[#e2b054] underline hover:text-[#fce18b] flex items-center gap-1 mt-0.5"
                          >
                            <Eye className="w-3 h-3" />
                            <span>Test Heart Trial</span>
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-1 border-t border-[#1b4b3b]">
                      <span className="text-[10px] text-[#9fc2b2]">Fee: {TRIAL_COST_STONES} Spirit Stones</span>
                      <button
                        disabled={currentCount >= maxCount || !canAffordTrial}
                        onClick={() => {
                          soundEngine.playGong();
                          onAcceptCandidate(cand, TRIAL_COST_STONES, 0);
                        }}
                        className={`px-3.5 py-2 rounded-xl font-dao font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all min-h-[38px] ${
                          currentCount >= maxCount || !canAffordTrial
                            ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                            : 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-95'
                        }`}
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>{currentCount >= maxCount ? 'Sect Full' : !canAffordTrial ? 'Lacks Stones' : 'Admit Candidate'}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            /* CUSTOM DISCIPLE CREATION WITH SCALED TIER PRICING & PATH SELECTION */
            <div className="bg-[#09261d] p-3.5 sm:p-4 rounded-2xl border border-[#1b4b3b] space-y-4 animate-fade-in">
              {/* Live Preview Card */}
              <div className="bg-gradient-to-r from-[#071f17] via-[#0e3427] to-[#071f17] p-3 rounded-2xl border border-[#e2b054]/50 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <CultivatorAvatar
                    gender={customGender}
                    rank="Outer"
                    spiritRoot={customRoot}
                    realmIndex={customMythicalForm !== 'None' ? 17 : 0}
                    appearanceIndex={customAppearanceIndex}
                    skinTone={customSkinTone}
                    clothingColor={customClothingColor}
                    hairColor={customHairColor}
                    expression={customExpression}
                    auraEffect={customAuraEffect}
                    mythicalForm={customMythicalForm}
                    size="xl"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h4 className="font-dao font-bold text-sm sm:text-base text-[#fce18b] truncate">
                        {customName || 'Novice Cultivator'}
                      </h4>
                      {customMythicalForm !== 'None' && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-purple-900/80 text-purple-200 border border-purple-400/60 font-bold whitespace-nowrap">
                          {customMythicalForm}
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-[#86efac] mt-0.5">
                      {customRoot} Root · {customTalentTier} · {customCultivationType}
                    </div>
                    <div className="text-[10px] text-[#9fc2b2] mt-0.5">
                      Align: <span className="text-amber-300">{customPersonalAlignment}</span> · Cost:{' '}
                      <span className="text-white font-mono">{customCostStones}S + {customCostMerit}M</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 1. Legendary Mythical Forms */}
              <div className="space-y-1.5">
                <label className="text-[#fce18b] font-bold flex items-center gap-1.5 text-[11px]">
                  <Crown className="w-3.5 h-3.5 text-purple-400" />
                  <span>1. Sovereign Archetype (+400S / +250M for Mythical)</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {MYTHICAL_FORMS.map((mf) => {
                    const isSelected = customMythicalForm === mf.id;
                    return (
                      <button
                        key={mf.id}
                        type="button"
                        onClick={() => handleSelectMythicalForm(mf.id)}
                        className={`p-2 rounded-xl border flex items-center sm:flex-col sm:text-center gap-2.5 text-left transition-all ${
                          isSelected
                            ? 'bg-gradient-to-br from-[#2a174a] to-[#184838] border-[#fce18b] shadow-md'
                            : 'bg-[#123d30] border-[#1b4b3b] hover:border-[#2a6b56]'
                        }`}
                      >
                        <CultivatorAvatar
                          gender={customGender}
                          rank="Outer"
                          spiritRoot={customRoot}
                          realmIndex={mf.id !== 'None' ? 17 : 0}
                          appearanceIndex={mf.id === 'None' ? (customAppearanceIndex < 10 ? customAppearanceIndex : 0) : mf.appIdx}
                          skinTone={customSkinTone}
                          clothingColor={customClothingColor}
                          hairColor={customHairColor}
                          auraEffect={mf.id === 'Thunder Sovereign' ? 'Golden Lightning' : mf.id === 'Immortal Beast' ? 'Celestial Flame' : customAuraEffect}
                          mythicalForm={mf.id}
                          showGenderBadge={false}
                          size="sm"
                        />
                        <div className="min-w-0">
                          <div className="text-[9px] font-mono text-amber-300 font-bold uppercase">{mf.badge}</div>
                          <div className="font-dao font-bold text-[11px] text-white leading-tight">{mf.title}</div>
                          <div className="text-[9px] text-[#9fc2b2] leading-tight mt-0.5">{mf.subtitle}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {customMythicalForm === 'None' && (
                <div className="space-y-1.5">
                  <label className="text-[#fce18b] font-bold block text-[11px]">
                    2. Hairstyle &amp; Crown (10 Classic Designs)
                  </label>
                  <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">
                    {Array.from({ length: 10 }).map((_, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          soundEngine.playClick();
                          setCustomAppearanceIndex(idx);
                        }}
                        className={`p-1 rounded-xl border flex flex-col items-center transition-all ${
                          customAppearanceIndex === idx
                            ? 'bg-[#184838] border-[#e2b054] shadow-xs'
                            : 'bg-[#123d30] border-[#1b4b3b]'
                        }`}
                      >
                        <CultivatorAvatar
                          gender={customGender}
                          rank="Outer"
                          spiritRoot={customRoot}
                          realmIndex={0}
                          appearanceIndex={idx}
                          skinTone={customSkinTone}
                          clothingColor={customClothingColor}
                          hairColor={customHairColor}
                          expression={customExpression}
                          showGenderBadge={false}
                          size="sm"
                        />
                        <span className="text-[9px] mt-0.5 text-white font-mono">#{idx + 1}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Expression Selector */}
              <div className="space-y-1.5">
                <label className="text-[#fce18b] font-bold block text-[11px]">
                  3. Facial Expression &amp; Demeanor
                </label>
                <div className="grid grid-cols-5 gap-1.5">
                  {DISCIPLE_EXPRESSIONS.map(exp => (
                    <button
                      key={exp.id}
                      type="button"
                      onClick={() => {
                        soundEngine.playClick();
                        setCustomExpression(exp.id);
                      }}
                      className={`p-1.5 rounded-xl border text-center transition-all ${
                        customExpression === exp.id
                          ? 'bg-[#184838] border-[#fce18b] text-[#fce18b] shadow-xs'
                          : 'bg-[#123d30] border-[#1b4b3b] text-[#9fc2b2] hover:border-[#2a6b56]'
                      }`}
                    >
                      <div className="text-[10px] font-bold">{exp.label}</div>
                      <div className="text-[8px] opacity-80 truncate">{exp.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Aura Effects */}
              <div className="space-y-1.5">
                <label className="text-[#fce18b] font-bold flex items-center gap-1.5 text-[11px]">
                  <Zap className="w-3.5 h-3.5 text-yellow-300" />
                  <span>Lightning &amp; Aura Effects (+60S / +25M when active)</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                  {AURA_EFFECTS.map(fx => {
                    const active = customAuraEffect === fx.id;
                    return (
                      <button
                        key={fx.id}
                        type="button"
                        onClick={() => {
                          soundEngine.playClick();
                          setCustomAuraEffect(fx.id);
                        }}
                        className={`p-2 rounded-xl border text-left transition-all ${
                          active
                            ? 'bg-[#184838] border-[#fce18b] shadow-sm'
                            : 'bg-[#123d30] border-[#1b4b3b] hover:bg-[#164a3a]'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: fx.badgeColor }} />
                          <span className="text-[10px] font-bold text-white truncate">{fx.label}</span>
                        </div>
                        <div className="text-[9px] text-[#9fc2b2] mt-0.5 truncate">{fx.desc}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Skin & Hair */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[#fce18b] font-bold block text-[11px]">Skin Tone</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {SKIN_TONES.map(tone => (
                      <button
                        key={tone.id}
                        type="button"
                        onClick={() => setCustomSkinTone(tone.id)}
                        className={`py-2 px-1.5 rounded-xl text-[10px] font-bold border flex items-center justify-center gap-1.5 transition-all ${
                          customSkinTone === tone.id
                            ? 'bg-[#184838] border-[#e2b054] text-[#fce18b]'
                            : 'bg-[#123d30] border-[#1b4b3b] text-[#86a89b]'
                        }`}
                      >
                        <span className="w-3 h-3 rounded-full border border-black/30 shrink-0" style={{ backgroundColor: tone.swatch }} />
                        <span className="truncate">{tone.id.split(' ')[1] || tone.id}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[#fce18b] font-bold block text-[11px]">Hair Shade ({CUSTOM_HAIR_COLORS.length} Styles)</label>
                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                    {CUSTOM_HAIR_COLORS.map(hc => (
                      <button
                        key={hc.id}
                        type="button"
                        title={hc.label}
                        onClick={() => setCustomHairColor(hc.id)}
                        className={`p-1.5 rounded-xl border flex flex-col items-center justify-center transition-all ${
                          customHairColor === hc.id
                            ? 'bg-[#184838] border-[#fce18b] scale-105'
                            : 'bg-[#123d30] border-[#1b4b3b]'
                        }`}
                      >
                        <span
                          className="w-5 h-5 rounded-full border border-white/40"
                          style={{ background: `linear-gradient(135deg, ${hc.highlight}, ${hc.main})` }}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Robe Colors */}
              <div className="space-y-2">
                <label className="text-[#fce18b] font-bold block text-[11px]">
                  Robe Colors (5 Classic + 5 Special Legendary Dyes)
                </label>
                <div className="grid grid-cols-5 gap-1.5">
                  {STANDARD_CLOTHING_COLORS.map(c => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setCustomClothingColor(c.id)}
                      className={`p-1.5 rounded-xl border flex flex-col items-center transition-all ${
                        customClothingColor === c.id ? 'border-[#fce18b] ring-1 ring-[#fce18b]/50' : 'border-[#1b4b3b]'
                      }`}
                      style={{ backgroundColor: c.hex + '33' }}
                    >
                      <div className="w-4 h-4 rounded-full border border-white/50" style={{ backgroundColor: c.hex }} />
                      <span className="text-[9px] mt-0.5 text-white font-bold truncate max-w-full">{c.label}</span>
                    </button>
                  ))}
                </div>
                <div className="grid grid-cols-5 gap-1.5">
                  {SPECIAL_CLOTHING_COLORS.map(c => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        soundEngine.playClick();
                        setCustomClothingColor(c.id);
                      }}
                      className={`p-1.5 rounded-xl border flex flex-col items-center transition-all ${
                        customClothingColor === c.id ? 'border-[#fce18b] ring-1 ring-[#fce18b]/70 scale-[1.03]' : 'border-[#e2b054]/30'
                      }`}
                      style={{ background: `linear-gradient(135deg, ${c.hex}55, #09261d)` }}
                    >
                      <div
                        className="w-4 h-4 rounded-full border"
                        style={{ backgroundColor: c.hex, borderColor: c.accent }}
                      />
                      <span className="text-[9px] mt-0.5 text-[#fce18b] font-bold truncate max-w-full">
                        {c.label.split(' ')[1] || c.label}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Identity, Path & Stats Form */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-[#8daea0] block mb-0.5">Disciple Name</label>
                  <input
                    type="text"
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white font-bold"
                  />
                </div>

                <div>
                  <label className="text-[#8daea0] block mb-0.5">Gender</label>
                  <select
                    value={customGender}
                    onChange={(e) => setCustomGender(e.target.value as 'Male' | 'Female')}
                    className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white"
                  >
                    <option value="Male">Male Cultivator</option>
                    <option value="Female">Female Cultivator</option>
                  </select>
                </div>

                <div>
                  <label className="text-[#8daea0] block mb-0.5 flex items-center gap-1">
                    <Compass className="w-3 h-3 text-sky-300" />
                    <span>Cultivation Path</span>
                  </label>
                  <select
                    value={customCultivationType}
                    onChange={(e) => setCustomCultivationType(e.target.value as CultivationPathType)}
                    className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white"
                  >
                    {CULTIVATION_PATHS.map(p => (
                      <option key={p.id} value={p.id}>{p.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[#8daea0] block mb-0.5">Personal Alignment</label>
                  <select
                    value={customPersonalAlignment}
                    onChange={(e) => setCustomPersonalAlignment(e.target.value as SectAlignment)}
                    className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white"
                  >
                    {PERSONAL_ALIGNMENTS.map(a => (
                      <option key={a} value={a}>{a}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[#8daea0] block mb-0.5">Spirit Root (Scales Cost)</label>
                  <select
                    value={customRoot}
                    onChange={(e) => setCustomRoot(e.target.value as SpiritRootType)}
                    className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white font-medium"
                  >
                    {(['Metal', 'Wood', 'Water', 'Fire', 'Earth', 'Thunder', 'Ice', 'Wind', 'Yin-Yang', 'Chaos', 'Heavenly', 'Immortal'] as SpiritRootType[]).map(r => (
                      <option key={r} value={r}>{r} Root</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[#8daea0] block mb-0.5">Talent Tier (Scales Cost)</label>
                  <select
                    value={customTalentTier}
                    onChange={(e) => setCustomTalentTier(e.target.value as TalentTier)}
                    className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white font-medium"
                  >
                    {(['Poor', 'Lazy', 'Mediocre', 'Talented', 'Prodigy', 'Innate'] as TalentTier[]).map(t => (
                      <option key={t} value={t}>{t} ({TALENT_TIER_DETAILS[t]?.cultivationSpeedMultiplier}x)</option>
                    ))}
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="text-[#8daea0] block mb-0.5">Physique / Constitution (+150S/+80M non-Mortal)</label>
                  <select
                    value={customConstitution}
                    onChange={(e) => setCustomConstitution(e.target.value as ConstitutionType)}
                    className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white"
                  >
                    {(Object.keys(CONSTITUTION_EFFECTS) as ConstitutionType[]).map(c => (
                      <option key={c} value={c}>
                        {c} (+{CONSTITUTION_EFFECTS[c].positive[0]} / -{CONSTITUTION_EFFECTS[c].negative[0]})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Path Effect Hint */}
              <div className="px-3 py-2 rounded-xl bg-[#071f17] border border-[#1d5543] text-[10px] text-sky-200">
                <strong>{customCultivationType}:</strong>{' '}
                {CULTIVATION_PATHS.find(p => p.id === customCultivationType)?.note}
              </div>

              {/* Submit Button with Dynamic Cost */}
              <button
                disabled={currentCount >= maxCount || !canAffordCustom || !customName.trim()}
                onClick={handleCreateCustom}
                className={`w-full py-3 rounded-xl font-dao font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all min-h-[44px] ${
                  currentCount >= maxCount || !canAffordCustom || !customName.trim()
                    ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-95'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>
                  {currentCount >= maxCount
                    ? 'Sect Capacity Full'
                    : !canAffordCustom
                    ? `Need ${customCostStones} Stones + ${customCostMerit} Merit`
                    : devMode
                    ? 'Consecrate Custom Disciple (Free · Dev)'
                    : `Consecrate Custom (${customCostStones} Stones + ${customCostMerit} Merit)`}
                </span>
              </button>
            </div>
          )}
        </div>

        {/* Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Immortal Selection Archive</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[40px]"
          >
            Close Selection
          </button>
        </div>
      </div>
    </div>
  );
};

