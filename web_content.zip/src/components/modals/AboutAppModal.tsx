import React from 'react';
import { X, HeartHandshake, Sparkles, CheckCircle2 } from 'lucide-react';

interface AboutAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutAppModal: React.FC<AboutAppModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <HeartHandshake className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-bold text-slate-900">About Mediguide AI</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 hover:text-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="text-center space-y-2 py-2">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 via-teal-500 to-emerald-400 p-0.5 mx-auto shadow-lg shadow-blue-500/20 flex items-center justify-center">
            <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-blue-600" />
            </div>
          </div>
          <h4 className="text-xl font-bold text-slate-900">Mediguide AI v2.4</h4>
          <p className="text-xs text-slate-500 font-medium">Next-Gen Intelligent Healthcare Platform</p>
        </div>

        <div className="space-y-2.5 text-xs text-slate-600">
          <p className="leading-relaxed">
            Mediguide AI is an intelligent mobile healthcare assistant built to simplify prescriptions, medical reports, personalized nutrition, and vitals monitoring.
          </p>

          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80 space-y-1.5">
            <p className="font-bold text-slate-800">Core Highlights (Step 1 UI):</p>
            <div className="space-y-1">
              <p className="flex items-center gap-1.5 text-slate-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" /> MD3 Healthcare Visual Theme
              </p>
              <p className="flex items-center gap-1.5 text-slate-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" /> 8 Comprehensive Feature UI Modules
              </p>
              <p className="flex items-center gap-1.5 text-slate-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" /> Full Interactive Navigation Structure
              </p>
            </div>
          </div>
        </div>

        <div className="pt-2">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-sm hover:bg-blue-700 transition-colors shadow-md shadow-blue-500/20"
          >
            Close Information
          </button>
        </div>
      </div>
    </div>
  );
};
