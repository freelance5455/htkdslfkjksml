import React from 'react';
import { Sparkles, Zap, Trophy, ShieldAlert, X } from 'lucide-react';

interface GameNotificationModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  type?: 'success' | 'tribulation' | 'danger' | 'divine';
  onClose: () => void;
}

export const GameNotificationModal: React.FC<GameNotificationModalProps> = ({
  isOpen,
  title,
  message,
  type = 'success',
  onClose
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className={`bg-[#123d30] border-2 rounded-3xl w-full max-w-sm shadow-2xl p-5 text-center space-y-3.5 relative overflow-hidden ${
        type === 'tribulation'
          ? 'border-yellow-400/80 shadow-[0_0_30px_rgba(250,204,21,0.3)]'
          : type === 'danger'
          ? 'border-red-500/80'
          : 'border-[#e2b054]/60'
      }`}>
        <div className="w-12 h-12 rounded-full mx-auto flex items-center justify-center bg-[#0b261d] border border-[#e2b054]/40 shadow-inner">
          {type === 'tribulation' ? (
            <Zap className="w-6 h-6 text-yellow-400 animate-bounce" />
          ) : type === 'danger' ? (
            <ShieldAlert className="w-6 h-6 text-red-400" />
          ) : (
            <Sparkles className="w-6 h-6 text-[#fce18b] animate-glow" />
          )}
        </div>

        <h3 className="font-dao font-bold text-base sm:text-lg text-[#fce18b]">
          {title}
        </h3>

        <p className="text-xs text-[#d1e6dc] leading-relaxed whitespace-pre-line bg-[#09261d]/80 p-3 rounded-xl border border-[#1b4b3b]">
          {message}
        </p>

        <button
          onClick={onClose}
          className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs sm:text-sm hover:brightness-110 active:scale-95 transition-all shadow-md"
        >
          Acknowledge
        </button>
      </div>
    </div>
  );
};
