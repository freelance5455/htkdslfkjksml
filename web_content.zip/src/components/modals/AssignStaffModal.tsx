import React from 'react';
import { Building, Disciple } from '../../types/cultivation';
import { calculateStaffCompatibility } from '../../data/compatibility';
import { soundEngine } from '../../services/audioEngine';
import { Landmark, Users, X, Check, Sparkles } from 'lucide-react';

interface AssignStaffModalProps {
  building: Building | null;
  disciples: Disciple[];
  onClose: () => void;
  onToggleAssign: (discipleId: string, buildingId: string) => void;
}

export const AssignStaffModal: React.FC<AssignStaffModalProps> = ({
  building,
  disciples,
  onClose,
  onToggleAssign
}) => {
  if (!building) return null;

  const effectiveMaxDisciples = 2 + Math.floor(building.level / 10);

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-[85vh] relative">
        {/* Sticky Header with generous touch target */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2">
            <Landmark className="w-5 h-5 text-[#fce18b]" />
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
                Assign Staff: {building.name}
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                Capacity: {building.assignedDisciples.length} / {effectiveMaxDisciples} (+1 per 10 lvls)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-2 grow text-xs text-[#d1e6dc]">
          {disciples.map((d) => {
            const isAssignedToThis = building.assignedDisciples.includes(d.id);
            const isAssignedElsewhere = !!d.assignedBuildingId && d.assignedBuildingId !== building.id;
            const compat = calculateStaffCompatibility(building, d);

            return (
              <div
                key={d.id}
                onClick={() => {
                  soundEngine.playClick();
                  onToggleAssign(d.id, building.id);
                }}
                className={`p-3 rounded-2xl border flex justify-between items-center cursor-pointer transition-all ${
                  isAssignedToThis
                    ? 'bg-[#184838] border-[#4ade80] shadow-sm'
                    : 'bg-[#09261d] border-[#1b4b3b] hover:border-[#1e5845]'
                }`}
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-white text-xs sm:text-sm font-dao">
                      {d.name}
                    </span>
                    <span className="text-[10px] text-[#86a89b]">
                      ({d.spiritRoot} · {d.preference})
                    </span>
                    {/* Compatibility Badge */}
                    <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold flex items-center gap-0.5 ${
                      compat.percentage >= 80
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                        : compat.percentage >= 60
                        ? 'bg-amber-950 text-amber-300 border border-amber-500/40'
                        : 'bg-gray-800 text-gray-400'
                    }`}>
                      <Sparkles className="w-2.5 h-2.5" />
                      <span>{compat.percentage}% Match</span>
                    </span>
                  </div>

                  <p className="text-[10px] text-[#9fc2b2] leading-snug">
                    {compat.reason} ({compat.yieldMultiplier}x yield)
                  </p>

                  {isAssignedElsewhere && (
                    <div className="text-[10px] text-amber-300/80">
                      Currently assigned elsewhere
                    </div>
                  )}
                </div>

                <div className="shrink-0 ml-2">
                  {isAssignedToThis ? (
                    <div className="w-7 h-7 rounded-full bg-[#15803d] flex items-center justify-center text-white">
                      <Check className="w-4 h-4" />
                    </div>
                  ) : (
                    <div className="w-7 h-7 rounded-full border border-[#276e57] flex items-center justify-center text-[#7ea091]">
                      <Users className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Staff Allocation</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Confirm & Close
          </button>
        </div>
      </div>
    </div>
  );
};
