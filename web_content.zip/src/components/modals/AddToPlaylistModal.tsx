import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import { Song } from '../../types/music';
import { Plus, Check, ListMusic, X } from 'lucide-react';
import { CoverArt } from '../common/CoverArt';

interface AddToPlaylistModalProps {
  song: Song;
  isOpen: boolean;
  onClose: () => void;
}

export const AddToPlaylistModal: React.FC<AddToPlaylistModalProps> = ({ song, isOpen, onClose }) => {
  const { playlists, addSongToPlaylist, removeSongFromPlaylist, createPlaylist } = useMusic();
  const [newTitle, setNewTitle] = useState('');
  const [showCreateInput, setShowCreateInput] = useState(false);

  if (!isOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const pl = createPlaylist(newTitle.trim(), 'Created from Now Playing');
    addSongToPlaylist(pl.id, song.id);
    setNewTitle('');
    setShowCreateInput(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-[#141622] border border-white/[0.1] p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-4 border-b border-white/[0.08]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <ListMusic className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-white">Add to Playlist</h3>
              <p className="text-xs text-slate-400 truncate max-w-[190px]">{song.title}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Create new playlist toggle */}
        {!showCreateInput ? (
          <button
            onClick={() => setShowCreateInput(true)}
            className="w-full mt-4 flex items-center gap-3 p-3 rounded-2xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 text-purple-300 text-xs font-semibold transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Playlist</span>
          </button>
        ) : (
          <form onSubmit={handleCreate} className="mt-4 space-y-2">
            <input
              type="text"
              autoFocus
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="Playlist name..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.06] border border-white/10 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-purple-500"
            />
            <div className="flex gap-2">
              <button
                type="submit"
                className="flex-1 py-1.5 rounded-xl bg-purple-600 text-white text-xs font-semibold hover:bg-purple-500"
              >
                Save & Add
              </button>
              <button
                type="button"
                onClick={() => setShowCreateInput(false)}
                className="px-3 py-1.5 rounded-xl bg-white/10 text-slate-300 text-xs hover:bg-white/20"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        {/* Existing playlists list */}
        <div className="mt-4 max-h-60 overflow-y-auto space-y-1.5 no-scrollbar">
          {playlists.map((pl) => {
            const hasSong = pl.songIds.includes(song.id);

            return (
              <button
                key={pl.id}
                onClick={() => {
                  if (hasSong) {
                    removeSongFromPlaylist(pl.id, song.id);
                  } else {
                    addSongToPlaylist(pl.id, song.id);
                  }
                }}
                className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-all ${
                  hasSong
                    ? 'bg-purple-950/40 border border-purple-500/30 text-white'
                    : 'hover:bg-white/[0.05] text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <CoverArt
                    artKey={pl.cover}
                    colorTheme={pl.colorTheme}
                    size="sm"
                    className="w-8 h-8 rounded-lg"
                  />
                  <div className="truncate">
                    <p className="font-medium text-xs truncate">{pl.title}</p>
                    <p className="text-[10px] text-slate-500">{pl.songIds.length} songs</p>
                  </div>
                </div>

                <div
                  className={`w-5 h-5 rounded-md flex items-center justify-center transition-colors ${
                    hasSong ? 'bg-purple-600 text-white' : 'border border-white/20'
                  }`}
                >
                  {hasSong && <Check className="w-3.5 h-3.5" />}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
