import React, { useState } from 'react';
import { DailyDivinationResult } from '../../types/cultivation';
import { soundEngine } from '../../services/audioEngine';
import { motion, AnimatePresence } from 'framer-motion';
import { Compass, Sparkles, X, RefreshCw, CheckCircle2 } from 'lucide-react';

interface DailyDivinationModalProps {
  todayDateStr: string;
  lastDivination: DailyDivinationResult | null;
  merit: number;
  devMode: boolean;
  onClose: () => void;
  onApplyDivination: (result: DailyDivinationResult, isReroll: boolean) => void;
}

const HEXAGRAM_POOL: Omit<DailyDivinationResult, 'id' | 'dateStr' | 'appliedAt'>[] = [
  {
    hexagramName: 'Qian · Soaring Nine-Dragons',
    omenTier: 'Supreme Auspicious',
    poem: 'Azure clouds part before the Ancestral Peak; spiritual veins surge with unyielding clarity.',
    effectLabel: '+450 Qi & +120 Sect Prestige · All Disciples +25 Exp',
    buffType: 'qi_rain'
  },
  {
    hexagramName: 'Kun · Jade Earth Treasury',
    omenTier: 'Great Fortune',
    poem: 'Deep within the mountain ribs, crystallized essence answers the Sect Master’s mandate.',
    effectLabel: '+350 Spirit Stones & +40 Merit',
    buffType: 'stones_surge'
  },
  {
    hexagramName: 'Li · Immortal Cauldron Miracle',
    omenTier: 'Supreme Auspicious',
    poem: 'Nine-turn crimson embers condense without impurity; alchemy fragrances drift ten thousand li.',
    effectLabel: '+12 Breakthrough Pills & +150 Qi',
    buffType: 'pill_miracle'
  },
  {
    hexagramName: 'Zhen · Heavenly Lightning Tempering',
    omenTier: 'Great Fortune',
    poem: 'Strike through mortal shackles with azure thunder; martial intent sharpens like an unsheathed sword.',
    effectLabel: 'All Disciples +35 Combat Power & +10 Morale',
    buffType: 'combat_awakening'
  },
  {
    hexagramName: 'Dui · Imperial Star Proclamation',
    omenTier: 'Auspicious',
    poem: 'Envoys of neighboring mountains look northward in awe; your sect’s decree resounds far.',
    effectLabel: '+85 Merit (Reputation) & +200 Prestige',
    buffType: 'merit_decree'
  },
  {
    hexagramName: 'Tai · Harmony of Yin & Yang',
    omenTier: 'Supreme Auspicious',
    poem: 'Heaven and earth embrace in tranquil balance; inner demons dissolve and Dao hearts shine.',
    effectLabel: 'All Disciples -35 Stress, +15 Loyalty & +200 Qi',
    buffType: 'tribulation_blessing'
  }
];

export const DailyDivinationModal: React.FC<DailyDivinationModalProps> = ({
  todayDateStr,
  lastDivination,
  merit,
  devMode,
  onClose,
  onApplyDivination
}) => {
  const [isCasting, setIsCasting] = useState(false);

  const alreadyClaimedToday = lastDivination?.dateStr === todayDateStr;
  const REROLL_MERIT_COST = 40;
  const canReroll = devMode || merit >= REROLL_MERIT_COST;

  const handleCastOmen = (isReroll: boolean) => {
    if (isCasting) return;
    if (alreadyClaimedToday && !isReroll) return;
    if (isReroll && !canReroll) return;

    setIsCasting(true);
    soundEngine.playDivinationShake();

    setTimeout(() => {
      const picked = HEXAGRAM_POOL[Math.floor(Math.random() * HEXAGRAM_POOL.length)];
      const result: DailyDivinationResult = {
        ...picked,
        id: 'div_' + Date.now(),
        dateStr: todayDateStr,
        appliedAt: Date.now()
      };
      soundEngine.playFanfare();
      onApplyDivination(result, isReroll);
      setIsCasting(false);
    }, 950);
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 12 }}
        className="bg-[#10362a] border-2 border-[#e2b054]/80 rounded-3xl w-full max-w-md shadow-[0_0_50px_rgba(226,176,84,0.3)] overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-[#081f17] via-[#123d30] to-[#081f17] p-4 border-b border-[#e2b054]/40 flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-400/50 flex items-center justify-center">
              <Compass className="w-5 h-5 text-[#fce18b]" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
                Heavenly Dao Daily Divination
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                Cast the Ancient Bagua Compass to receive today’s celestial omen
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Daily Divination"
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto text-center text-xs text-[#d1e6dc]">
          {/* Animated Taiji Bagua Compass */}
          <div className="flex justify-center py-2">
            <motion.div
              animate={
                isCasting
                  ? { rotate: [0, 360, 720], scale: [1, 1.1, 1] }
                  : { rotate: 0, scale: 1 }
              }
              transition={{ duration: 0.9, ease: 'easeInOut' }}
              className="w-32 h-32 rounded-full bg-gradient-to-br from-[#071f17] to-[#134636] border-2 border-[#e2b054] shadow-[0_0_30px_rgba(226,176,84,0.35)] flex items-center justify-center relative"
            >
              <svg viewBox="0 0 100 100" className="w-24 h-24">
                <circle cx="50" cy="50" r="46" fill="none" stroke="#e2b054" strokeWidth="1.5" strokeDasharray="5 3" />
                <circle cx="50" cy="50" r="36" fill="none" stroke="#34d399" strokeWidth="1" opacity="0.6" />
                {/* Bagua Octagon Lines */}
                <polygon
                  points="50,8 80,20 92,50 80,80 50,92 20,80 8,50 20,20"
                  fill="none"
                  stroke="#fce18b"
                  strokeWidth="1.2"
                  opacity="0.7"
                />
                {/* Center Yin-Yang */}
                <circle cx="50" cy="50" r="20" fill="#0b261d" stroke="#fce18b" strokeWidth="1.5" />
                <path d="M50,30 A20,20 0 0,1 50,70 A10,10 0 0,1 50,50 A10,10 0 0,0 50,30 Z" fill="#fce18b" />
                <circle cx="50" cy="40" r="3" fill="#0b261d" />
                <circle cx="50" cy="60" r="3" fill="#fce18b" />
              </svg>
            </motion.div>
          </div>

          <AnimatePresence mode="wait">
            {isCasting ? (
              <motion.div
                key="casting"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="p-4 rounded-2xl bg-[#09261d] border border-[#e2b054]/50"
              >
                <div className="font-dao font-bold text-sm text-[#fce18b] animate-pulse">
                  Drawing Bamboo Slip from the Star Cylinder...
                </div>
                <p className="text-[11px] text-[#9fc2b2] mt-1">
                  Reading cosmic leyline alignment for {todayDateStr}
                </p>
              </motion.div>
            ) : alreadyClaimedToday && lastDivination ? (
              <motion.div
                key="result"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-[#09261d] p-4 rounded-2xl border border-[#e2b054]/60 space-y-2.5 text-left"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-950 text-amber-300 border border-amber-400/50 font-bold">
                    {lastDivination.omenTier}
                  </span>
                  <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Drawn Today
                  </span>
                </div>
                <h4 className="font-dao font-bold text-base text-[#fce18b]">
                  {lastDivination.hexagramName}
                </h4>
                <p className="text-[11px] text-[#b4d4c5] italic leading-relaxed">
                  "{lastDivination.poem}"
                </p>
                <div className="p-2.5 rounded-xl bg-[#123d30] border border-emerald-500/40 text-emerald-300 font-bold text-xs">
                  Omen Blessing: {lastDivination.effectLabel}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="ready"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-[#09261d] p-4 rounded-2xl border border-[#1b4b3b] space-y-1.5"
              >
                <div className="font-dao font-bold text-sm text-[#fce18b]">
                  Today’s Heavenly Omen Awaits
                </div>
                <p className="text-[11px] text-[#9fc2b2]">
                  Consult the Dao once daily for free to bless your sect with rare Qi, Spirit Stones, Pills, or Martial Enlightenment.
                </p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Action Buttons */}
          {!alreadyClaimedToday ? (
            <button
              disabled={isCasting}
              onClick={() => handleCastOmen(false)}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-sm flex items-center justify-center gap-2 shadow-lg hover:brightness-110 active:scale-98 transition-all min-h-[44px]"
            >
              <Sparkles className="w-4 h-4" />
              <span>Cast Daily Divination (Free)</span>
            </button>
          ) : (
            <button
              disabled={isCasting || !canReroll}
              onClick={() => handleCastOmen(true)}
              className={`w-full py-3 rounded-xl font-dao font-bold text-xs sm:text-sm flex items-center justify-center gap-2 border transition-all min-h-[44px] ${
                canReroll && !isCasting
                  ? 'bg-[#184838] hover:bg-[#1f5946] text-[#fce18b] border-[#e2b054]/60 active:scale-98'
                  : 'bg-gray-800 text-gray-500 border-gray-700 cursor-not-allowed'
              }`}
            >
              <RefreshCw className="w-4 h-4" />
              <span>Re-Cast Heavenly Omen ({devMode ? 'Dev Free' : `${REROLL_MERIT_COST} Merit`})</span>
            </button>
          )}
        </div>

        {/* Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Cosmic Astrology Pavilion</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[40px]"
          >
            Close Compass
          </button>
        </div>
      </motion.div>
    </div>
  );
};
