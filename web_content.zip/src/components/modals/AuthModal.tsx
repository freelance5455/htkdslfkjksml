import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import { Sparkles, X, Mail, Lock, User as UserIcon, Check, AlertCircle } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthOpen, setIsAuthOpen, updateUserProfile } = useMusic();
  const [mode, setMode] = useState<'welcome' | 'login' | 'signup' | 'forgot'>('welcome');

  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isAuthOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!email || !password) {
      setError('Please provide both email and password.');
      return;
    }
    // Simulate authentication
    updateUserProfile(email.split('@')[0], email);
    setSuccessMsg('Logged in successfully!');
    setTimeout(() => {
      setIsAuthOpen(false);
      setSuccessMsg(null);
    }, 1000);
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!name.trim()) {
      setError('Name is required.');
      return;
    }
    if (!email.includes('@')) {
      setError('Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    updateUserProfile(name.trim(), email.trim());
    setSuccessMsg('Account created successfully!');
    setTimeout(() => {
      setIsAuthOpen(false);
      setSuccessMsg(null);
    }, 1000);
  };

  const handleGoogleSignIn = () => {
    updateUserProfile('Sahanur Alam', 'sahanuralam781108@gmail.com');
    setSuccessMsg('Connected with Google!');
    setTimeout(() => {
      setIsAuthOpen(false);
      setSuccessMsg(null);
    }, 1000);
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Please enter your email.');
      return;
    }
    setSuccessMsg('Password reset link sent to your email.');
    setTimeout(() => {
      setMode('login');
      setSuccessMsg(null);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-[#141622] border border-white/10 p-6 shadow-2xl relative overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => setIsAuthOpen(false)}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Status Alerts */}
        {error && (
          <div className="mb-4 p-2.5 rounded-xl bg-red-950/60 border border-red-500/30 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* View: Welcome */}
        {mode === 'welcome' && (
          <div className="text-center py-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 mx-auto flex items-center justify-center text-white font-display font-black text-2xl shadow-xl shadow-purple-600/30 mb-4">
              ME
            </div>
            <h2 className="font-display font-extrabold text-2xl text-white">Music Express</h2>
            <p className="text-xs text-purple-300 font-semibold tracking-wider uppercase mt-1">
              Listen to your world
            </p>
            <p className="text-xs text-slate-400 mt-3 max-w-xs mx-auto">
              Stream millions of songs, synchronized lyrics, offline downloads, and personalized playlists.
            </p>

            <div className="mt-8 space-y-2.5">
              <button
                onClick={() => setMode('signup')}
                className="w-full py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 transition-all active:scale-95"
              >
                Get Started
              </button>

              <button
                onClick={() => setMode('login')}
                className="w-full py-3 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs border border-white/10 transition-all"
              >
                I already have an account
              </button>
            </div>
          </div>
        )}

        {/* View: Login */}
        {mode === 'login' && (
          <div>
            <h3 className="font-display font-bold text-xl text-white">Welcome Back</h3>
            <p className="text-xs text-slate-400 mt-0.5">Sign in to your Music Express account</p>

            <form onSubmit={handleLogin} className="mt-5 space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Email</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-semibold text-slate-400">Password</label>
                  <button
                    type="button"
                    onClick={() => setMode('forgot')}
                    className="text-[11px] text-purple-400 hover:underline"
                  >
                    Forgot?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md shadow-purple-600/30 transition-all active:scale-95"
              >
                Sign In
              </button>
            </form>

            <div className="relative my-4 text-center">
              <span className="text-[11px] text-slate-500 bg-[#141622] px-2 relative z-10">or</span>
              <div className="absolute inset-0 top-1/2 border-t border-white/[0.08]" />
            </div>

            <button
              onClick={handleGoogleSignIn}
              className="w-full py-2.5 rounded-xl bg-white/[0.06] hover:bg-white/10 border border-white/10 text-white font-medium text-xs flex items-center justify-center gap-2 transition-all"
            >
              <span>Continue with Google</span>
            </button>

            <div className="mt-5 text-center text-xs text-slate-400">
              Don&apos;t have an account?{' '}
              <button
                onClick={() => setMode('signup')}
                className="text-purple-400 font-semibold hover:underline"
              >
                Sign Up
              </button>
            </div>
          </div>
        )}

        {/* View: Signup */}
        {mode === 'signup' && (
          <div>
            <h3 className="font-display font-bold text-xl text-white">Create Account</h3>
            <p className="text-xs text-slate-400 mt-0.5">Start listening to premium music</p>

            <form onSubmit={handleSignup} className="mt-4 space-y-2.5">
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Full Name</label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Sahanur Alam"
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Email</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Confirm Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full mt-2 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md shadow-purple-600/30 transition-all active:scale-95"
              >
                Create Account
              </button>
            </form>

            <div className="mt-4 text-center text-xs text-slate-400">
              Already have an account?{' '}
              <button
                onClick={() => setMode('login')}
                className="text-purple-400 font-semibold hover:underline"
              >
                Sign In
              </button>
            </div>
          </div>
        )}

        {/* View: Forgot */}
        {mode === 'forgot' && (
          <div>
            <h3 className="font-display font-bold text-xl text-white">Reset Password</h3>
            <p className="text-xs text-slate-400 mt-0.5">We will send a reset link to your email</p>

            <form onSubmit={handleForgotPassword} className="mt-5 space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full px-3 py-2.5 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md"
              >
                Send Reset Link
              </button>

              <button
                type="button"
                onClick={() => setMode('login')}
                className="w-full py-2 text-xs text-slate-400 hover:text-white"
              >
                Back to Sign In
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
