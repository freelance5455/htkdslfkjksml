import React, { useState } from 'react';
import { 
  Lock, 
  Mail, 
  User, 
  ArrowRight, 
  X, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  Store as StoreIcon, 
  Sparkles,
  KeyRound
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Language, UserRole } from '../../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  initialMode?: 'login' | 'register' | 'change_password';
  requiredRole?: UserRole;
  storeId?: string;
  storeName?: string;
  contextMode?: 'admin' | 'merchant' | 'storefront';
  onSuccess?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  language,
  initialMode = 'login',
  requiredRole,
  storeId,
  storeName,
  contextMode = 'merchant',
  onSuccess
}) => {
  const { 
    currentUser, 
    loginWithEmail, 
    registerWithEmail, 
    loginWithGoogle, 
    resetPassword, 
    changePassword, 
    error, 
    clearError 
  } = useAuth();
  
  const isBn = language === 'bn';
  const isAdminContext = contextMode === 'admin';
  const isStorefrontContext = contextMode === 'storefront';

  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'change_password'>(
    isAdminContext ? 'login' : initialMode
  );
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>(
    isStorefrontContext ? 'CUSTOMER' : (requiredRole || 'MERCHANT')
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Sync mode if initialMode changes
  React.useEffect(() => {
    if (isAdminContext) {
      setMode('login');
    } else {
      setMode(initialMode);
    }
    clearError();
    setSuccessMessage(null);
  }, [initialMode, isAdminContext, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setSuccessMessage(null);
    setIsSubmitting(true);

    try {
      if (mode === 'login') {
        await loginWithEmail(email, password);
        if (onSuccess) onSuccess();
        onClose();
      } else if (mode === 'register') {
        const assignedRole = isStorefrontContext ? 'CUSTOMER' : role;
        await registerWithEmail(
          email, 
          password, 
          name || email.split('@')[0], 
          assignedRole,
          storeId
        );
        if (onSuccess) onSuccess();
        onClose();
      } else if (mode === 'forgot') {
        await resetPassword(email);
        setSuccessMessage(
          isBn
            ? 'পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে!'
            : 'Password reset link sent to your email!'
        );
      } else if (mode === 'change_password') {
        if (newPassword !== confirmNewPassword) {
          throw new Error(isBn ? 'নতুন পাসওয়ার্ড দুটি মিলছে না।' : 'New passwords do not match.');
        }
        if (newPassword.length < 6) {
          throw new Error(isBn ? 'পাসওয়ার্ড অন্তত ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.');
        }
        await changePassword(oldPassword, newPassword);
        setSuccessMessage(
          isBn ? '✓ আপনার পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!' : '✓ Password changed successfully!'
        );
        setOldPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
        setTimeout(() => {
          onClose();
        }, 1800);
      }
    } catch (err: any) {
      // Error handled in AuthContext or local throw
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleLogin = async () => {
    clearError();
    setIsSubmitting(true);
    try {
      await loginWithGoogle();
      if (onSuccess) onSuccess();
      onClose();
    } catch (err) {
      // Error handled
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 to-slate-850 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
              isAdminContext 
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
            }`}>
              {isAdminContext ? <ShieldCheck className="w-5 h-5" /> : mode === 'change_password' ? <KeyRound className="w-5 h-5" /> : <StoreIcon className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {mode === 'change_password' && (isBn ? 'পাসওয়ার্ড পরিবর্তন করুন' : 'Change Password')}
                {mode === 'login' && (
                  isAdminContext 
                    ? (isBn ? 'সুপার অ্যাডমিন লগইন' : 'Super Admin Sign In')
                    : isStorefrontContext
                    ? (isBn ? `${storeName || 'স্টোর'} কাস্টমার লগইন` : `Customer Sign In • ${storeName || 'Store'}`)
                    : (isBn ? 'মার্চেন্ট লগইন' : 'Merchant Sign In')
                )}
                {mode === 'register' && (
                  isStorefrontContext 
                    ? (isBn ? 'নতুন কাস্টমার অ্যাকাউন্ট' : 'Customer Sign Up')
                    : (isBn ? 'নতুন মার্চেন্ট অ্যাকাউন্ট' : 'Create Merchant Account')
                )}
                {mode === 'forgot' && (isBn ? 'পাসওয়ার্ড রিসেট' : 'Reset Password')}
              </h3>
              <p className="text-xs text-slate-400">
                {isAdminContext 
                  ? (isBn ? 'শুধুমাত্র অনুমোদিত প্ল্যাটফর্ম রুট অ্যাডমিনদের জন্য' : 'Authorized Super Admin access only')
                  : isStorefrontContext 
                  ? (isBn ? 'অর্ডার ট্র্যাকিং এবং দ্রুত চেকআউটের জন্য' : 'Track your purchases & instant checkout')
                  : (isBn ? 'আপনার অনলাইন স্টোর তৈরি ও পরিচালনার জন্য' : 'Launch & grow your e-commerce store')}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              clearError();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Quick Admin Helper Hint if Admin Modal */}
          {isAdminContext && mode === 'login' && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
              <div>
                <p className="font-semibold text-white">Root Admin Authorized Access:</p>
                <p className="text-[11px] text-amber-200 font-mono mt-0.5">mdsujatali20@gmail.com</p>
              </div>
            </div>
          )}

          {/* Google Sign In Button */}
          {mode !== 'forgot' && mode !== 'change_password' && (
            <>
              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-semibold text-xs transition-all shadow-sm active:scale-98 disabled:opacity-50"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.35 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>{isBn ? 'গুগল দিয়ে প্রবেশ করুন' : 'Continue with Google'}</span>
              </button>

              <div className="relative flex items-center justify-center my-3">
                <div className="border-t border-slate-800 w-full"></div>
                <span className="bg-slate-900 px-3 text-[11px] text-slate-500 font-medium uppercase tracking-wider">
                  {isBn ? 'অথবা ইমেইল দিয়ে' : 'or with email'}
                </span>
              </div>
            </>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {/* Change Password Mode */}
            {mode === 'change_password' && (
              <>
                <div className="text-xs text-slate-400 mb-2">
                  {isBn 
                    ? `বর্তমান অ্যাকাউন্টের পাসওয়ার্ড পরিবর্তন করুন (${currentUser?.email})` 
                    : `Update your credentials for ${currentUser?.email}`}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'বর্তমান পাসওয়ার্ড' : 'Current Password'}
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      required
                      value={oldPassword}
                      onChange={(e) => setOldPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'নতুন পাসওয়ার্ড' : 'New Password'}
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'নতুন পাসওয়ার্ড নিশ্চিত করুন' : 'Confirm New Password'}
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={confirmNewPassword}
                      onChange={(e) => setConfirmNewPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </>
            )}

            {/* Registration Mode Fields */}
            {mode === 'register' && !isAdminContext && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'আপনার পুরো নাম' : 'Full Name'}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={isBn ? 'যেমন: সুজাত আলী' : 'e.g. Sujat Ali'}
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                {!isStorefrontContext && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {isBn ? 'অ্যাকাউন্টের ধরণ' : 'Account Type'}
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setRole('MERCHANT')}
                        className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                          role === 'MERCHANT'
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            : 'bg-slate-950 text-slate-400 border-slate-800'
                        }`}
                      >
                        <StoreIcon className="w-3.5 h-3.5" />
                        <span>{isBn ? 'মার্চেন্ট / স্টোর' : 'Merchant'}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setRole('CUSTOMER')}
                        className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                          role === 'CUSTOMER'
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            : 'bg-slate-950 text-slate-400 border-slate-800'
                        }`}
                      >
                        <User className="w-3.5 h-3.5" />
                        <span>{isBn ? 'ক্রেতা / কাস্টমার' : 'Customer'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Email Field for Login, Register, Forgot */}
            {mode !== 'change_password' && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ইমেইল অ্যাড্রেস' : 'Email Address'}
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="mdsujatali20@gmail.com"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            )}

            {/* Password Field for Login and Register */}
            {mode !== 'forgot' && mode !== 'change_password' && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    {isBn ? 'পাসওয়ার্ড' : 'Password'}
                  </label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => {
                        clearError();
                        setMode('forgot');
                      }}
                      className="text-[11px] text-emerald-400 hover:underline"
                    >
                      {isBn ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot password?'}
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className={`w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-white font-bold text-xs shadow-md transition-all active:scale-98 disabled:opacity-50 mt-2 ${
                isAdminContext 
                  ? 'bg-amber-600 hover:bg-amber-500 shadow-amber-600/30'
                  : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30'
              }`}
            >
              <span>
                {isSubmitting
                  ? (isBn ? 'প্রসেসিং হচ্ছে...' : 'Processing...')
                  : mode === 'change_password'
                  ? (isBn ? 'পাসওয়ার্ড আপডেট করুন' : 'Update Password')
                  : mode === 'login'
                  ? (isAdminContext ? (isBn ? 'অ্যাডমিন প্রবেশ' : 'Sign In as Admin') : (isBn ? 'লগইন করুন' : 'Sign In'))
                  : mode === 'register'
                  ? (isBn ? 'অ্যাকাউন্ট তৈরি করুন' : 'Create Account')
                  : (isBn ? 'রিসেট লিংক পাঠান' : 'Send Reset Link')}
              </span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Toggle Modes - ONLY for Non-Admin */}
          {!isAdminContext && mode !== 'change_password' && (
            <div className="pt-3 border-t border-slate-800 text-center text-xs text-slate-400">
              {mode === 'login' && (
                <p>
                  {isBn ? 'নতুন ইউজার?' : "Don't have an account?"}{' '}
                  <button
                    type="button"
                    onClick={() => {
                      clearError();
                      setMode('register');
                    }}
                    className="font-bold text-emerald-400 hover:underline"
                  >
                    {isBn ? 'নিবন্ধন করুন' : 'Sign up'}
                  </button>
                </p>
              )}

              {mode === 'register' && (
                <p>
                  {isBn ? 'ইতিমধ্যে অ্যাকাউন্ট আছে?' : 'Already have an account?'}{' '}
                  <button
                    type="button"
                    onClick={() => {
                      clearError();
                      setMode('login');
                    }}
                    className="font-bold text-emerald-400 hover:underline"
                  >
                    {isBn ? 'লগইন করুন' : 'Sign in'}
                  </button>
                </p>
              )}

              {mode === 'forgot' && (
                <button
                  type="button"
                  onClick={() => {
                    clearError();
                    setMode('login');
                  }}
                  className="font-bold text-emerald-400 hover:underline"
                >
                  {isBn ? '← লগইনে ফিরে যান' : '← Back to sign in'}
                </button>
              )}
            </div>
          )}

          {isAdminContext && (
            <div className="pt-3 border-t border-slate-800 text-center text-[11px] text-slate-500">
              {isBn 
                ? '🔒 অ্যাডমিন প্যানেলে পাবলিক রেজিস্ট্রেশন বন্ধ রয়েছে।' 
                : '🔒 Public registration is disabled on the Admin Panel.'}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
