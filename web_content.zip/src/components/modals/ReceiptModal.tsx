import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Printer,
  Download,
  CheckCircle,
  Building2,
  FileCheck,
} from 'lucide-react';

export const ReceiptModal: React.FC = () => {
  const { selectedReceiptOrder, setSelectedReceiptOrder } = useApp();

  if (!selectedReceiptOrder) return null;

  const order = selectedReceiptOrder;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Action Header (hidden during print) */}
        <div className="px-6 py-3.5 bg-slate-900 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2 text-xs font-semibold">
            <FileCheck className="w-4 h-4 text-emerald-400" />
            <span>Digital Invoice & Official Receipt</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={() => setSelectedReceiptOrder(null)}
              className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Body */}
        <div className="p-8 space-y-6 text-slate-800" id="printable-receipt">
          {/* Institution Header */}
          <div className="flex items-start justify-between pb-6 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2.5">
                <img
                  src="/assets/aistudio/1793372617949_97205839.jpg"
                  alt="Store Crest"
                  className="w-9 h-9 rounded-lg object-cover border border-slate-200 shadow-xs"
                />
                <span className="text-xl font-bold tracking-tight text-slate-900">
                  Synapse Campus & Enterprise Store
                </span>
              </div>
              <div className="text-xs text-slate-500 mt-2 space-y-0.5">
                <div>Division of Academic Procurement & Logistics</div>
                <div>100 University Avenue, Science Hall Suite 200</div>
                <div>Tax ID: US-SYN-9844210 · store@synapse.edu</div>
              </div>
            </div>

            <div className="text-right">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Receipt Number
              </div>
              <div className="text-lg font-mono font-bold text-slate-900">{order.id}</div>
              <div className="text-xs text-slate-500 mt-1 font-mono">{order.orderDate}</div>
              <div className="mt-2 inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200">
                <CheckCircle className="w-3 h-3" />
                <span>{order.paymentStatus}</span>
              </div>
            </div>
          </div>

          {/* Customer / Department Info */}
          <div className="grid grid-cols-2 gap-6 text-xs">
            <div>
              <div className="font-bold text-slate-900 uppercase tracking-wider text-[11px] mb-1 text-slate-400">
                Billed & Issued To:
              </div>
              <div className="font-bold text-slate-900">{order.customerName}</div>
              <div className="text-slate-600">{order.customerDepartment}</div>
              <div className="text-slate-500 font-mono text-[11px]">{order.customerEmail}</div>
            </div>
            <div>
              <div className="font-bold text-slate-900 uppercase tracking-wider text-[11px] mb-1 text-slate-400">
                Campus Destination:
              </div>
              <div className="text-slate-700 leading-relaxed">{order.shippingAddress}</div>
              <div className="mt-1 font-semibold text-slate-600">
                Payment Mode:{' '}
                <span className="font-normal text-slate-800">{order.paymentMethod}</span>
              </div>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold text-[11px] uppercase tracking-wider">
                <tr>
                  <th className="py-2.5 px-4">Item & Specification</th>
                  <th className="py-2.5 px-4 text-center">Qty</th>
                  <th className="py-2.5 px-4 text-right">Unit Price</th>
                  <th className="py-2.5 px-4 text-right">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {order.items.map((item, idx) => (
                  <tr key={idx}>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{item.product.title}</div>
                      <div className="font-mono text-[11px] text-slate-400">{item.product.sku}</div>
                    </td>
                    <td className="py-3 px-4 text-center font-mono">{item.quantity}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      ${item.product.price.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-semibold text-slate-900 tabular-nums">
                      ${(item.quantity * item.product.price).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals Calculation Strip */}
          <div className="flex justify-end text-xs">
            <div className="w-64 space-y-2">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums text-slate-900">${order.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Campus Sales / Institutional Tax (8%)</span>
                <span className="font-mono tabular-nums text-slate-900">${order.tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Campus Internal Courier</span>
                <span className="font-mono tabular-nums text-slate-900">
                  {order.shippingFee === 0 ? 'Complimentary' : `$${order.shippingFee.toFixed(2)}`}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-sm text-slate-900">
                <span>Total Amount Paid</span>
                <span className="font-mono tabular-nums text-indigo-700">${order.total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Verification Footer */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-400">
            <div>
              Generated by Synapse Central Fulfillment Engine · Ref: {order.id}-{Date.now().toString().slice(-4)}
            </div>
            <div className="font-mono text-slate-500">
              Authorized Signature: <span className="underline decoration-slate-300">Marcus Holloway</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
