import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import { CoverArt } from '../common/CoverArt';
import { MusicListItem } from '../cards/MusicListItem';
import {
  Play,
  Shuffle,
  ArrowDownToLine,
  Share2,
  Trash2,
  Plus,
  X,
  Check,
  Search,
  ArrowUp,
  ArrowDown
} from 'lucide-react';

export const PlaylistDetailModal: React.FC = () => {
  const {
    selectedPlaylistId,
    setSelectedPlaylistId,
    playlists,
    songs,
    playSong,
    removeSongFromPlaylist,
    addSongToPlaylist,
    deletePlaylist,
    toggleDownloadSong,
    downloadedSongIds
  } = useMusic();

  const [showAddDrawer, setShowAddDrawer] = useState(false);
  const [addSearch, setAddSearch] = useState('');
  const [copied, setCopied] = useState(false);

  if (!selectedPlaylistId) return null;

  const playlist = playlists.find((p) => p.id === selectedPlaylistId);
  if (!playlist) return null;

  const playlistSongs = songs.filter((s) => playlist.songIds.includes(s.id));

  const handlePlayAll = () => {
    if (playlistSongs.length > 0) {
      playSong(playlistSongs[0], playlistSongs);
    }
  };

  const handleShuffle = () => {
    if (playlistSongs.length > 0) {
      const shuffled = [...playlistSongs].sort(() => Math.random() - 0.5);
      playSong(shuffled[0], shuffled);
    }
  };

  const handleDownloadAll = () => {
    playlistSongs.forEach((s) => {
      if (!downloadedSongIds.includes(s.id)) {
        toggleDownloadSong(s.id);
      }
    });
  };

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard?.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const availableSongsToAdd = songs.filter(
    (s) =>
      !playlist.songIds.includes(s.id) &&
      (s.title.toLowerCase().includes(addSearch.toLowerCase()) ||
        s.artist.toLowerCase().includes(addSearch.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0b0c10] text-slate-100 overflow-y-auto animate-in fade-in">
      {/* Background Gradient */}
      <div
        className="absolute inset-0 opacity-40 blur-3xl pointer-events-none"
        style={{
          background: `radial-gradient(circle at 50% 20%, ${playlist.colorTheme.from} 0%, ${playlist.colorTheme.to} 60%, #000000 100%)`
        }}
      />

      {/* Top Header Row */}
      <div className="relative z-10 flex items-center justify-between p-4 max-w-4xl mx-auto w-full">
        <button
          onClick={() => setSelectedPlaylistId(null)}
          className="p-2 rounded-full hover:bg-white/10 text-slate-300 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          {playlist.isCustom && (
            <button
              onClick={() => {
                if (confirm(`Delete playlist "${playlist.title}"?`)) {
                  deletePlaylist(playlist.id);
                  setSelectedPlaylistId(null);
                }
              }}
              title="Delete Playlist"
              className="p-2 rounded-full hover:bg-red-500/20 text-slate-400 hover:text-red-400"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={handleShare}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? 'Link Copied' : 'Share'}</span>
          </button>
        </div>
      </div>

      {/* Playlist Hero Info */}
      <div className="relative z-10 max-w-4xl mx-auto w-full px-5 pb-6">
        <div className="flex flex-col sm:flex-row items-center sm:items-end gap-5 text-center sm:text-left">
          <CoverArt
            artKey={playlist.cover}
            title={playlist.title}
            artist={playlist.creator}
            colorTheme={playlist.colorTheme}
            size="lg"
            className="w-36 h-36 sm:w-44 sm:h-44 rounded-3xl shadow-2xl"
          />

          <div className="flex-1 min-w-0">
            <span className="text-[11px] uppercase tracking-wider font-semibold text-purple-300">
              Playlist
            </span>
            <h1 className="font-display font-black text-2xl sm:text-4xl text-white tracking-tight leading-tight mt-1 truncate">
              {playlist.title}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-lg">
              {playlist.description}
            </p>
            <div className="flex items-center justify-center sm:justify-start gap-2 mt-2 text-xs text-slate-400">
              <span>Created by {playlist.creator}</span>
              <span>·</span>
              <span>{playlistSongs.length} songs</span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 mt-6 pt-3 border-t border-white/10">
          <button
            onClick={handlePlayAll}
            disabled={playlistSongs.length === 0}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold text-xs sm:text-sm shadow-lg shadow-purple-600/30 transition-all active:scale-95"
          >
            <Play className="w-4 h-4 fill-white ml-0.5" />
            <span>Play All</span>
          </button>

          <button
            onClick={handleShuffle}
            disabled={playlistSongs.length === 0}
            className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-white/10 hover:bg-white/20 disabled:opacity-50 text-white font-semibold text-xs sm:text-sm backdrop-blur-md transition-all active:scale-95"
          >
            <Shuffle className="w-4 h-4" />
            <span>Shuffle</span>
          </button>

          <button
            onClick={handleDownloadAll}
            className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm backdrop-blur-md transition-all active:scale-95"
          >
            <ArrowDownToLine className="w-4 h-4" />
            <span>Download All</span>
          </button>

          <button
            onClick={() => setShowAddDrawer(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-full bg-pink-600/20 hover:bg-pink-600/30 text-pink-300 border border-pink-500/30 font-semibold text-xs sm:text-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Songs</span>
          </button>
        </div>

        {/* Track List */}
        <div className="mt-6 space-y-1.5 bg-white/[0.02] p-2 rounded-3xl border border-white/[0.04]">
          {playlistSongs.length === 0 ? (
            <div className="text-center py-14 px-4 text-slate-400">
              <p className="text-sm font-semibold text-slate-200">This playlist is empty</p>
              <p className="text-xs mt-1">Tap &ldquo;Add Songs&rdquo; above to populate this playlist.</p>
            </div>
          ) : (
            playlistSongs.map((song, idx) => (
              <div key={song.id} className="relative group flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <MusicListItem
                    song={song}
                    rank={idx + 1}
                    showRank={true}
                    contextQueue={playlistSongs}
                  />
                </div>
                <button
                  onClick={() => removeSongFromPlaylist(playlist.id, song.id)}
                  title="Remove from playlist"
                  className="p-2 text-slate-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity mr-2"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add Songs Drawer */}
      {showAddDrawer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
          <div className="w-full max-w-md rounded-3xl bg-[#141622] border border-white/10 p-5 shadow-2xl flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
              <h3 className="font-display font-bold text-base text-white">Add Songs to Playlist</h3>
              <button onClick={() => setShowAddDrawer(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-3 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={addSearch}
                onChange={(e) => setAddSearch(e.target.value)}
                placeholder="Search song or artist..."
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="mt-3 flex-1 overflow-y-auto space-y-1.5 no-scrollbar">
              {availableSongsToAdd.length === 0 ? (
                <p className="text-center py-8 text-xs text-slate-500">
                  No additional songs match your search.
                </p>
              ) : (
                availableSongsToAdd.map((s) => (
                  <div
                    key={s.id}
                    className="flex items-center justify-between p-2 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] text-xs"
                  >
                    <div className="min-w-0 pr-2">
                      <p className="font-semibold text-white truncate">{s.title}</p>
                      <p className="text-[11px] text-slate-400 truncate">{s.artist}</p>
                    </div>
                    <button
                      onClick={() => addSongToPlaylist(playlist.id, s.id)}
                      className="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-medium text-[11px] shrink-0"
                    >
                      Add
                    </button>
                  </div>
                ))
              )}
            </div>

            <button
              onClick={() => setShowAddDrawer(false)}
              className="mt-3 w-full py-2 rounded-xl bg-white/10 text-white text-xs font-semibold hover:bg-white/15"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
