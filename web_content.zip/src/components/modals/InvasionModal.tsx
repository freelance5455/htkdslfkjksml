import React, { useState } from 'react';
import { NeighborSect, Disciple, IncursionInvader } from '../../types/cultivation';
import { soundEngine } from '../../services/audioEngine';
import { ShieldAlert, Swords, Landmark, X, Flame, Hammer, UserCheck, ShieldOff } from 'lucide-react';

interface InvasionModalProps {
  invadingSect?: NeighborSect | null;
  monsterInvader?: IncursionInvader | null;
  disciples: Disciple[];
  mountainArrayLevel: number;
  onClose: () => void;
  onVictorySubdueRecruit: () => void;
  onVictoryAssignMineWorker: () => void;
  onVictoryBanish: () => void;
  onDefeatAcknowledgeLosses: (lostStones: number) => void;
  onPayTributePeace: () => void;
}

export const InvasionModal: React.FC<InvasionModalProps> = ({
  invadingSect,
  monsterInvader,
  disciples,
  mountainArrayLevel,
  onClose,
  onVictorySubdueRecruit,
  onVictoryAssignMineWorker,
  onVictoryBanish,
  onDefeatAcknowledgeLosses,
  onPayTributePeace
}) => {
  // Attacker Stats Before
  const attackerName = invadingSect ? invadingSect.name : monsterInvader ? monsterInvader.name : 'Unknown Hostile Marauders';
  const attackerCombatPower = invadingSect ? invadingSect.strength : monsterInvader ? (monsterInvader.threatPower || monsterInvader.combatPowerBefore || 1200) : 1200;
  const attackerHpMax = invadingSect ? 400 : 350;
  const motiveText = invadingSect
    ? `Grudge dispute over border leylines and low sect reputation.`
    : `Ferocious primordial monster awakened from mountain depths.`;

  const totalSectPower = disciples.reduce((acc, d) => acc + d.combatPower, 0);

  // Battle state: 'briefing' -> 'post_battle_victory' -> 'post_battle_defeat'
  const [battleState, setBattleState] = useState<'briefing' | 'post_battle_victory' | 'post_battle_defeat'>('briefing');
  const [attackerHpRemaining, setAttackerHpRemaining] = useState<number>(attackerHpMax);
  const [lostStonesAmount, setLostStonesAmount] = useState<number>(0);

  const handleFight = () => {
    // Array bonus: level * 100 power
    const effectiveDefensePower = totalSectPower + mountainArrayLevel * 100;
    const isVictorious = effectiveDefensePower >= attackerCombatPower;

    if (isVictorious) {
      soundEngine.playFanfare();
      setAttackerHpRemaining(0);
      setBattleState('post_battle_victory');
    } else {
      soundEngine.playThunder();
      const penalty = Math.min(250, Math.floor(attackerCombatPower * 0.2));
      setLostStonesAmount(penalty);
      setBattleState('post_battle_defeat');
    }
  };

  const handleUseArrayThunder = () => {
    soundEngine.playThunder();
    // Guaranteed defense with array lightning
    setAttackerHpRemaining(0);
    setBattleState('post_battle_victory');
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/90 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#1c0808] border-2 border-red-600/80 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#2c0808] via-[#450a0a] to-[#2c0808] p-4 border-b border-red-500/40 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-red-400 animate-pulse" />
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-red-200">
                {invadingSect ? 'Foreign Sect Incursion' : 'Mountain Monster Incursion'}
              </h3>
              <p className="text-[11px] text-red-300/80">
                Perimeter alarm triggered at the mountain gate.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-red-950 text-red-300 hover:text-white border border-red-700 min-w-[40px] min-h-[40px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-4 grow text-xs text-red-100">
          {/* BRIEFING STAGE: BEFORE BATTLE STATS */}
          {battleState === 'briefing' && (
            <>
              {/* Attacker Stats Before */}
              <div className="bg-red-950/70 p-3.5 rounded-2xl border border-red-800/80 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-red-200 text-sm">{attackerName}</span>
                  <span className="font-mono text-red-300 font-bold px-2 py-0.5 rounded bg-red-900 border border-red-700">
                    {attackerCombatPower} Combat Power
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                  <div>
                    <span className="text-red-400/90 block">Initial Vitality (HP):</span>
                    <span className="font-mono text-white font-bold">{attackerHpMax} / {attackerHpMax}</span>
                  </div>
                  <div>
                    <span className="text-red-400/90 block">Threat Classification:</span>
                    <span className="text-amber-300 font-medium">{invadingSect ? 'Hostile Neighbor Sect' : 'Wild Primordial Beast'}</span>
                  </div>
                </div>
                <div className="text-[11px] text-red-300/90 pt-1 border-t border-red-900/60">
                  <span className="font-bold text-red-200">Motive: </span>
                  <span>{motiveText}</span>
                </div>
              </div>

              {/* Sect Defensive Standing */}
              <div className="bg-[#0f241a] p-3 rounded-2xl border border-emerald-600/40 text-emerald-200 space-y-1.5">
                <div className="flex justify-between items-center font-bold">
                  <span>Our Total Defensive Power:</span>
                  <span className="font-mono text-[#fce18b]">{totalSectPower} Power</span>
                </div>
                <div className="flex justify-between items-center text-[11px] text-emerald-300/80">
                  <span>Mountain Defense Array (Level {mountainArrayLevel}):</span>
                  <span className="text-[#86efac]">+{mountainArrayLevel * 100} Array Defense Boost</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-1">
                <button
                  onClick={handleFight}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-red-700 to-rose-600 hover:brightness-110 text-white font-dao font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-all"
                >
                  <Swords className="w-4 h-4" />
                  <span>Mobilize Disciples & Battle the Incursion</span>
                </button>

                <button
                  onClick={handleUseArrayThunder}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#123d30] hover:bg-[#184838] border border-emerald-500/50 text-[#86efac] font-bold text-xs flex items-center justify-center gap-2"
                >
                  <Landmark className="w-4 h-4" />
                  <span>Fire Mountain Array Thunderbolts (Cost: 100 Qi)</span>
                </button>

                {invadingSect && (
                  <button
                    onClick={onPayTributePeace}
                    className="w-full py-2 px-4 rounded-xl bg-amber-950/60 hover:bg-amber-900 border border-amber-600/40 text-amber-200 font-bold text-xs flex items-center justify-center gap-1.5"
                  >
                    <span>Offer 150 Spirit Stones Tribute for Armistice</span>
                  </button>
                )}
              </div>
            </>
          )}

          {/* POST BATTLE STAGE: VICTORY & 3 SUBDUE CHOICES */}
          {battleState === 'post_battle_victory' && (
            <div className="space-y-3.5 animate-scale-up">
              <div className="p-3.5 rounded-2xl bg-emerald-950/70 border border-emerald-500/60 text-emerald-200 space-y-2">
                <div className="font-dao font-bold text-sm text-[#fce18b]">
                  Attacker Stats After Battle: Vanquished & Captured
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-emerald-400 block">Attacker Status:</span>
                    <span className="font-bold text-white">Subdued / Meridian Sealed</span>
                  </div>
                  <div>
                    <span className="text-emerald-400 block">Remaining Vitality:</span>
                    <span className="font-mono text-white font-bold">{attackerHpRemaining} / {attackerHpMax} (0%)</span>
                  </div>
                </div>
              </div>

              <div className="text-xs text-[#d1e6dc] leading-relaxed">
                The attackers have been completely subdued! The Sect Master must now decree their fate:
              </div>

              {/* 3 Subdue Choices */}
              <div className="space-y-2">
                {/* 1. Subdue & Recruit */}
                <button
                  onClick={() => {
                    soundEngine.playGong();
                    onVictorySubdueRecruit();
                    onClose();
                  }}
                  className="w-full p-3 rounded-2xl bg-[#123d30] hover:bg-[#184838] border border-[#e2b054]/50 text-left transition-all"
                >
                  <div className="font-bold text-[#fce18b] text-xs flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4 text-emerald-400" />
                    <span>1. Subdue & Recruit into Sect Ranks</span>
                  </div>
                  <div className="text-[10px] text-[#9fc2b2] mt-0.5">
                    Cleanse their malevolence and admit them as an Outer Disciple with unique combat prowess.
                  </div>
                </button>

                {/* 2. Assign to Mines as Lifetime Worker */}
                <button
                  onClick={() => {
                    soundEngine.playTalisman();
                    onVictoryAssignMineWorker();
                    onClose();
                  }}
                  className="w-full p-3 rounded-2xl bg-[#1c2c20] hover:bg-[#253d2d] border border-amber-500/50 text-left transition-all"
                >
                  <div className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                    <Hammer className="w-4 h-4 text-amber-400" />
                    <span>2. Assign to Mines as Lifetime Worker (+Mine Yield)</span>
                  </div>
                  <div className="text-[10px] text-[#9fc2b2] mt-0.5">
                    Condemn the captured aggressors to perpetual labor in the Spirit Stone Veins (+5 Stones/sec permanently).
                  </div>
                </button>

                {/* 3. Banish Permanently */}
                <button
                  onClick={() => {
                    soundEngine.playClick();
                    onVictoryBanish();
                    onClose();
                  }}
                  className="w-full p-3 rounded-2xl bg-[#221010] hover:bg-[#331515] border border-red-500/50 text-left transition-all"
                >
                  <div className="font-bold text-red-300 text-xs flex items-center gap-1.5">
                    <ShieldOff className="w-4 h-4 text-red-400" />
                    <span>3. Banish Permanently from the Mountain</span>
                  </div>
                  <div className="text-[10px] text-[#9fc2b2] mt-0.5">
                    Sever their spiritual meridians and cast them out (+50 Sect Prestige, +25 Sect Merit).
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* POST BATTLE STAGE: DEFEAT - DISPLAY ONLY SECT LOSSES AND DAMAGES */}
          {battleState === 'post_battle_defeat' && (
            <div className="space-y-3.5 animate-scale-up">
              <div className="p-4 rounded-2xl bg-red-950/80 border-2 border-red-600 text-red-200 space-y-2.5">
                <h4 className="font-dao font-bold text-sm text-red-100 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-red-400" />
                  <span>Sect Losses & Gate Damage Assessment</span>
                </h4>
                <p className="text-[11px] text-red-300/90 leading-relaxed">
                  Our defense was overwhelmed by superior force. Enemy vanguard pillaged outer storage facilities before retreating:
                </p>

                <div className="space-y-1.5 pt-1 text-xs">
                  <div className="flex justify-between items-center text-red-200">
                    <span>Spirit Stones Plundered:</span>
                    <span className="font-mono font-bold text-red-400">-{lostStonesAmount} Stones</span>
                  </div>
                  <div className="flex justify-between items-center text-red-200">
                    <span>Mountain Array Stability:</span>
                    <span className="text-amber-300">Shaken (-10 Qi Array resonance)</span>
                  </div>
                  <div className="flex justify-between items-center text-red-200">
                    <span>Disciples Status:</span>
                    <span className="text-amber-300">Minor injuries sustained, recovering in Herb Nursery</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  onDefeatAcknowledgeLosses(lostStonesAmount);
                  onClose();
                }}
                className="w-full py-2.5 rounded-xl bg-red-900 hover:bg-red-800 text-white font-bold text-xs"
              >
                Acknowledge Damages & Fortify Defenses
              </button>
            </div>
          )}
        </div>

        {/* Modal Bottom Exit Bar */}
        <div className="p-3 bg-[#120606] border-t border-red-900/40 flex justify-between items-center text-xs">
          <span className="text-red-400/80">Mountain Defense Registry</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-red-950 hover:bg-red-900 text-red-200 font-bold text-[11px] border border-red-700/50"
          >
            Close Notice
          </button>
        </div>
      </div>
    </div>
  );
};
