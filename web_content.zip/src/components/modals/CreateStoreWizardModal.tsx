import React, { useState } from 'react';
import { 
  X, 
  Store as StoreIcon, 
  Sparkles, 
  Check, 
  ArrowRight, 
  Palette, 
  Globe, 
  CreditCard, 
  ShoppingBag, 
  ExternalLink,
  ChevronLeft,
  CheckCircle2
} from 'lucide-react';
import { Language, Store, StoreTheme, Product } from '../../types';

interface CreateStoreWizardModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onStoreCreated: (newStore: Store, starterProducts: Product[]) => void;
  onViewStorefront: () => void;
}

const CATEGORIES = [
  { id: 'Fashion & Apparel', nameBn: 'ফ্যাশন ও পোশাক', nameEn: 'Fashion & Apparel', icon: '👔', banner: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=80' },
  { id: 'Electronics & Gadgets', nameBn: 'ইলেকট্রনিক্স ও গ্যাজেট', nameEn: 'Electronics & Gadgets', icon: '⚡', banner: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1200&q=80' },
  { id: 'Grocery & Organic Food', nameBn: 'অর্গানিক ফুড ও গ্রোসারি', nameEn: 'Grocery & Organic Food', icon: '🌿', banner: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1200&q=80' },
  { id: 'Beauty & Skincare', nameBn: 'বিউটি ও স্কিনকেয়ার', nameEn: 'Beauty & Skincare', icon: '✨', banner: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=1200&q=80' },
  { id: 'Home & Lifestyle', nameBn: 'হোম ডেকোর ও লাইফস্টাইল', nameEn: 'Home & Lifestyle', icon: '🏡', banner: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=1200&q=80' },
];

const COLOR_PRESETS = [
  { name: 'Emerald', hex: '#059669', accent: '#10b981' },
  { name: 'Royal Blue', hex: '#2563eb', accent: '#3b82f6' },
  { name: 'Ruby Red', hex: '#e11d48', accent: '#f43f5e' },
  { name: 'Amber Gold', hex: '#d97706', accent: '#f59e0b' },
  { name: 'Deep Purple', hex: '#7c3aed', accent: '#8b5cf6' },
  { name: 'Midnight Slate', hex: '#0f172a', accent: '#334155' },
];

export const CreateStoreWizardModal: React.FC<CreateStoreWizardModalProps> = ({
  isOpen,
  onClose,
  language,
  onStoreCreated,
  onViewStorefront,
}) => {
  if (!isOpen) return null;

  const isBn = language === 'bn';
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);

  // Step 1 Form Data
  const [storeName, setStoreName] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0].id);
  const [subdomain, setSubdomain] = useState('');
  const [phone, setPhone] = useState('+880 1712-345678');

  // Step 2 Theme & Look
  const [selectedColor, setSelectedColor] = useState(COLOR_PRESETS[0]);
  const [headline, setHeadline] = useState('');
  const [headlineBn, setHeadlineBn] = useState('');

  // Step 3 Catalog & Payment
  const [includeStarterProducts, setIncludeStarterProducts] = useState(true);
  const [acceptBkash, setAcceptBkash] = useState(true);
  const [acceptNagad, setAcceptNagad] = useState(true);
  const [acceptCod, setAcceptCod] = useState(true);

  // Step 4 Created Store Result
  const [createdStore, setCreatedStore] = useState<Store | null>(null);

  // Auto-generate subdomain when storeName changes
  const handleStoreNameChange = (val: string) => {
    setStoreName(val);
    const slug = val
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
    setSubdomain(slug || 'mystore');
    setHeadline(`Welcome to ${val || 'Our Store'}`);
    setHeadlineBn(`${val || 'আমাদের স্টোরে'} আপনাকে স্বাগতম`);
  };

  const handleFinishCreation = () => {
    const finalSlug = subdomain.toLowerCase().trim() || 'my-shop';
    const chosenCat = CATEGORIES.find((c) => c.id === category) || CATEGORIES[0];

    const newStoreId = `store-${Date.now()}`;
    const newStore: Store = {
      id: newStoreId,
      name: storeName.trim() || (isBn ? 'আমার নতুন স্টোর' : 'My New Store'),
      slug: finalSlug,
      logo: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=160&q=80',
      category: chosenCat.id,
      currency: 'BDT',
      currencySymbol: '৳',
      status: 'active',
      plan: 'starter',
      createdAt: new Date().toISOString().split('T')[0],
      theme: {
        primaryColor: selectedColor.hex,
        accentColor: selectedColor.accent,
        fontFamily: 'Plus Jakarta Sans',
        announcementText: '🎉 Grand Opening! Use code WELCOME10 for 10% off your first order.',
        announcementTextBn: '🎉 আমাদের নতুন অনলাইন শপে স্বাগতম! প্রথম অর্ডারে পান ১০% ছাড়।',
        showAnnouncement: true,
        heroHeadline: headline || `Welcome to ${storeName}`,
        heroHeadlineBn: headlineBn || `${storeName}-এ স্বাগতম`,
        heroSubheadline: 'Hand-picked premium quality products with nationwide doorstep delivery.',
        heroSubheadlineBn: 'সেরা মানের পণ্য এবং সমগ্র বাংলাদেশে দ্রুততম হোম ডেলিভারি।',
        heroBannerImage: chosenCat.banner,
        layoutStyle: 'modern',
      },
    };

    // Generate 3 sample starter products tailored to this category
    const starterProducts: Product[] = includeStarterProducts
      ? [
          {
            id: `prod-${Date.now()}-1`,
            storeId: newStoreId,
            name: `${newStore.name} Signature Item 1`,
            nameBn: `${newStore.name} সিগনেচার প্রোডাক্ট ১`,
            description: 'Crafted with premium materials for discerning buyers. Best seller.',
            descriptionBn: 'উচ্চমানের উপকরণ ও নিখুঁত ফিনিশিং দিয়ে তৈরি করা বেস্ট সেলার পণ্য।',
            price: 1850,
            compareAtPrice: 2200,
            stock: 45,
            sku: `${finalSlug.toUpperCase().slice(0, 3)}-001`,
            category: chosenCat.id,
            categoryBn: chosenCat.nameBn,
            image: chosenCat.banner,
            isFeatured: true,
            rating: 5.0,
            reviewsCount: 18,
            tags: ['New', 'Featured', 'Best Seller'],
          },
          {
            id: `prod-${Date.now()}-2`,
            storeId: newStoreId,
            name: `${newStore.name} Premium Edition 2`,
            nameBn: `${newStore.name} প্রিমিয়াম কালেকশন ২`,
            description: 'Designed for daily comfort and long-lasting durability.',
            descriptionBn: 'দৈনন্দিন আরাম ও দীর্ঘস্থায়ী ব্যবহারের জন্য বিশেষ কালেকশন।',
            price: 3200,
            compareAtPrice: 3800,
            stock: 30,
            sku: `${finalSlug.toUpperCase().slice(0, 3)}-002`,
            category: chosenCat.id,
            categoryBn: chosenCat.nameBn,
            image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80',
            isFeatured: true,
            rating: 4.8,
            reviewsCount: 11,
            tags: ['Premium', 'Trending'],
          },
          {
            id: `prod-${Date.now()}-3`,
            storeId: newStoreId,
            name: `${newStore.name} Exclusive Gift Pack`,
            nameBn: `${newStore.name} এক্সক্লুসিভ গিফট প্যাক`,
            description: 'Perfect for gifts and special occasions with custom box packaging.',
            descriptionBn: 'উপহার দেওয়া কিংবা বিশেষ মুহূর্তের জন্য প্রিমিয়াম গিফট প্যাক।',
            price: 4500,
            compareAtPrice: 5200,
            stock: 18,
            sku: `${finalSlug.toUpperCase().slice(0, 3)}-003`,
            category: chosenCat.id,
            categoryBn: chosenCat.nameBn,
            image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80',
            isFeatured: false,
            rating: 4.9,
            reviewsCount: 7,
            tags: ['Gift Set', 'Exclusive'],
          },
        ]
      : [];

    setCreatedStore(newStore);
    onStoreCreated(newStore, starterProducts);
    setCurrentStep(4);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl text-white relative my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        {currentStep !== 4 && (
          <button
            onClick={onClose}
            className="absolute top-6 right-6 text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Step Indicator Header (steps 1-3) */}
        {currentStep !== 4 && (
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                <StoreIcon className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-black tracking-tight">
                {isBn ? 'আপনার নিজস্ব অনলাইন ওয়েবসাইট তৈরি করুন' : 'Launch Your Own Online Store'}
              </h2>
            </div>
            <p className="text-xs text-slate-400">
              {isBn 
                ? 'মাত্র ৩টি সহজ ধাপে সম্পূর্ণ রেডিমেড ই-কমার্স স্টোর চালু করুন' 
                : '3 simple steps to your fully functional cloud e-commerce website'}
            </p>

            {/* Stepper Dots */}
            <div className="flex items-center gap-2 mt-4">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex-1 flex items-center gap-2">
                  <div
                    className={`h-1.5 rounded-full flex-1 transition-all ${
                      currentStep >= s ? 'bg-emerald-500' : 'bg-slate-800'
                    }`}
                  />
                  <span
                    className={`text-[10px] font-bold ${
                      currentStep === s ? 'text-emerald-400' : 'text-slate-500'
                    }`}
                  >
                    {s === 1 ? (isBn ? '১. বিবরণ' : '1. Info') : s === 2 ? (isBn ? '২. থিম' : '2. Look') : (isBn ? '৩. পণ্য ও পেমেন্ট' : '3. Launch')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= STEP 1: STORE DETAILS ================= */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                {isBn ? 'আপনার স্টোর বা ব্র্যান্ডের নাম *' : 'Your Store or Brand Name *'}
              </label>
              <input
                id="wizard-store-name-input"
                type="text"
                required
                autoFocus
                placeholder={isBn ? 'যেমন: ঢাকা বুটিক, গ্যাজেট জোন বিডি' : 'e.g. Dhaka Attire, Gadget Lab, Artisan Honey'}
                value={storeName}
                onChange={(e) => handleStoreNameChange(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-800/90 border border-slate-700 text-white placeholder-slate-500 text-sm font-semibold focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                {isBn ? 'বিনামূল্যে ক্লাউড সাবডোমেন (Free Cloud Subdomain)' : 'Free Cloud Subdomain'}
              </label>
              <div className="flex items-center bg-slate-800/90 border border-slate-700 rounded-xl px-3 py-2.5">
                <Globe className="w-4 h-4 text-slate-400 mr-2 shrink-0" />
                <input
                  type="text"
                  value={subdomain}
                  onChange={(e) => setSubdomain(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                  className="bg-transparent text-emerald-400 font-mono text-xs font-bold w-full focus:outline-none"
                  placeholder="your-brand"
                />
                <span className="text-slate-400 text-xs font-mono shrink-0">.shanju.cloud</span>
              </div>
              <p className="text-[11px] text-emerald-400/80 mt-1 flex items-center gap-1">
                <Check className="w-3 h-3" />
                {isBn ? 'সাবডোমেন ও SSL সিকিউরিটি সার্টিফিকেট অন্তর্ভুক্ত' : 'Includes instant SSL certificate & global edge CDN'}
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                {isBn ? 'পণ্যের ক্যাটাগরি বেছে নিন' : 'Choose Your Industry'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {CATEGORIES.map((cat) => (
                  <button
                    type="button"
                    key={cat.id}
                    onClick={() => setCategory(cat.id)}
                    className={`p-2.5 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                      category === cat.id
                        ? 'bg-emerald-500/20 border-emerald-500 text-white font-bold shadow-xs'
                        : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span className="text-base">{cat.icon}</span>
                    <span className="text-xs truncate">{isBn ? cat.nameBn : cat.nameEn}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                {isBn ? 'মার্চেন্ট মোবাইল নম্বর (অর্ডার নোটিফিকেশন)' : 'Merchant Phone (SMS / WhatsApp Alerts)'}
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/90 border border-slate-700 text-slate-200 text-xs focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div className="pt-3 flex justify-end">
              <button
                id="wizard-next-step1-btn"
                type="button"
                disabled={!storeName.trim()}
                onClick={() => setCurrentStep(2)}
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-lg transition-transform active:scale-95"
              >
                <span>{isBn ? 'পরবর্তী: থিম ও রঙ নির্ধারণ' : 'Next: Theme & Colors'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 2: THEME & LOOK ================= */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isBn ? 'আপনার ব্র্যান্ডের প্রধান রঙ পছন্দ করুন' : 'Select Primary Brand Color'}</span>
              </label>
              <div className="grid grid-cols-6 gap-2">
                {COLOR_PRESETS.map((color) => (
                  <button
                    type="button"
                    key={color.name}
                    onClick={() => setSelectedColor(color)}
                    className={`h-11 rounded-xl flex items-center justify-center transition-all ${
                      selectedColor.hex === color.hex
                        ? 'ring-2 ring-white scale-105 shadow-lg'
                        : 'opacity-70 hover:opacity-100'
                    }`}
                    style={{ backgroundColor: color.hex }}
                    title={color.name}
                  >
                    {selectedColor.hex === color.hex && (
                      <Check className="w-5 h-5 text-white stroke-[3]" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                {isBn ? 'ওয়েবসাইটের প্রধান শিরোনাম (Headline)' : 'Main Website Headline'}
              </label>
              <input
                type="text"
                value={isBn ? headlineBn : headline}
                onChange={(e) => {
                  if (isBn) setHeadlineBn(e.target.value);
                  else setHeadline(e.target.value);
                }}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Live Mini Preview Box */}
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-emerald-400" />
                <span>{isBn ? 'লাইভ ওয়েব কার্ড প্রিভিউ' : 'Live Storefront Header Preview'}</span>
              </div>
              <div className="bg-white text-slate-900 rounded-xl p-3 shadow-inner">
                <div 
                  className="py-1 px-2 text-[10px] text-white font-bold text-center rounded mb-2"
                  style={{ backgroundColor: selectedColor.hex }}
                >
                  🎉 Grand Opening Sale — 10% Discount Active
                </div>
                <div className="flex items-center justify-between border-b pb-2">
                  <div className="font-extrabold text-xs text-slate-900">{storeName || 'Your Brand'}</div>
                  <div className="text-[10px] text-slate-500">Cart (0)</div>
                </div>
                <div className="py-4 text-center">
                  <h4 className="font-black text-sm text-slate-900">{isBn ? headlineBn : headline}</h4>
                  <button 
                    type="button"
                    className="mt-2 px-3 py-1 rounded text-[10px] font-bold text-white shadow-xs"
                    style={{ backgroundColor: selectedColor.hex }}
                  >
                    Shop Now
                  </button>
                </div>
              </div>
            </div>

            <div className="pt-3 flex justify-between">
              <button
                type="button"
                onClick={() => setCurrentStep(1)}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-bold"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{isBn ? 'পূর্ববর্তী' : 'Back'}</span>
              </button>

              <button
                id="wizard-next-step2-btn"
                type="button"
                onClick={() => setCurrentStep(3)}
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg transition-transform active:scale-95"
              >
                <span>{isBn ? 'পরবর্তী: ক্যাটালগ ও পেমেন্ট' : 'Next: Catalog & Payments'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 3: CATALOG & PAYMENTS ================= */}
        {currentStep === 3 && (
          <div className="space-y-4">
            {/* Starter Products Toggle */}
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeStarterProducts}
                  onChange={(e) => setIncludeStarterProducts(e.target.checked)}
                  className="mt-1 w-4 h-4 rounded text-emerald-500 focus:ring-emerald-400"
                />
                <div>
                  <div className="text-xs font-bold text-white">
                    {isBn 
                      ? '৩টি ডেমো পণ্য দিয়ে স্টোর শুরু করুন (Pre-populate 3 Starter Products)' 
                      : 'Pre-populate with 3 ready-to-sell starter products'}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {isBn 
                      ? 'আপনার নির্বাচিত ক্যাটাগরি অনুযায়ী ছবি, বিবরণ ও মূল্যসহ পণ্যগুলো স্বয়ংক্রিয়ভাবে যোগ হবে।' 
                      : 'Populates photos, descriptions, and SKU tags matching your industry so your shop is ready to test immediately.'}
                  </div>
                </div>
              </label>
            </div>

            {/* Payment Gateways Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isBn ? 'পেমেন্ট গেটওয়ে সক্রিয় করুন' : 'Enable Instant Payment Gateways'}</span>
              </label>

              <div className="space-y-2">
                <label className="p-3 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded bg-pink-600 text-white font-black text-[10px] flex items-center justify-center">
                      bKash
                    </span>
                    <span className="text-xs font-semibold text-white">bKash Direct Merchant Checkout</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={acceptBkash}
                    onChange={(e) => setAcceptBkash(e.target.checked)}
                    className="w-4 h-4 text-emerald-500 rounded"
                  />
                </label>

                <label className="p-3 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded bg-orange-600 text-white font-black text-[10px] flex items-center justify-center">
                      Nagad
                    </span>
                    <span className="text-xs font-semibold text-white">Nagad Digital Wallet</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={acceptNagad}
                    onChange={(e) => setAcceptNagad(e.target.checked)}
                    className="w-4 h-4 text-emerald-500 rounded"
                  />
                </label>

                <label className="p-3 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded bg-slate-700 text-white font-black text-[10px] flex items-center justify-center">
                      COD
                    </span>
                    <span className="text-xs font-semibold text-white">Cash on Delivery (ক্যাশ অন ডেলিভারি)</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={acceptCod}
                    onChange={(e) => setAcceptCod(e.target.checked)}
                    className="w-4 h-4 text-emerald-500 rounded"
                  />
                </label>
              </div>
            </div>

            <div className="pt-3 flex justify-between">
              <button
                type="button"
                onClick={() => setCurrentStep(2)}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-bold"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{isBn ? 'পূর্ববর্তী' : 'Back'}</span>
              </button>

              <button
                id="wizard-finish-btn"
                type="button"
                onClick={handleFinishCreation}
                className="flex items-center gap-2 px-7 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs shadow-xl shadow-emerald-500/25 transition-transform active:scale-95"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isBn ? 'স্টোর লাইভ করুন! 🚀' : 'Launch My Store Now! 🚀'}</span>
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 4: SUCCESS CELEBRATION ================= */}
        {currentStep === 4 && createdStore && (
          <div className="text-center py-4 space-y-5 animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 mx-auto flex items-center justify-center shadow-lg">
              <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
            </div>

            <div>
              <h3 className="text-2xl font-black text-white tracking-tight">
                {isBn ? '🎉 অভিনন্দন! আপনার ওয়েবসাইট লাইভ হয়েছে!' : '🎉 Congratulations! Your Store is Live!'}
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-sm mx-auto">
                {isBn 
                  ? `আপনার ব্র্যান্ড "${createdStore.name}" এখন ইন্টারনেটে সম্পূর্ণ প্রস্তুত এবং গ্রাহক অর্ডার নেওয়ার জন্য তৈরি।` 
                  : `Your brand "${createdStore.name}" is now provisioned and ready to process live customer orders.`}
              </p>
            </div>

            {/* Subdomain URL Badge */}
            <div className="p-4 bg-slate-800/80 rounded-2xl border border-slate-700 text-left space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-semibold">{isBn ? 'পাবলিক ওয়েবসাইট লিংক:' : 'Public Storefront URL:'}</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  LIVE & ACTIVE
                </span>
              </div>
              <div className="font-mono text-emerald-400 font-bold text-sm truncate flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>https://{createdStore.slug}.shanju.cloud</span>
              </div>
              <div className="text-[11px] text-slate-400 flex items-center gap-2 pt-1 border-t border-slate-700/60">
                <span>✓ {isBn ? 'বিকাশ ও নগদ রেডি' : 'bKash/Nagad ready'}</span>
                <span>•</span>
                <span>✓ {isBn ? 'ক্যাটালগ সংরক্ষিত' : 'Catalog synced'}</span>
                <span>•</span>
                <span>✓ {isBn ? '০% ট্রানজেকশন ফি' : '0% commission'}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <button
                id="wizard-view-storefront-btn"
                onClick={() => {
                  onClose();
                  onViewStorefront();
                }}
                className="flex-1 flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold text-xs shadow-lg transition-transform hover:scale-[1.02]"
              >
                <ExternalLink className="w-4 h-4" />
                <span>{isBn ? 'আমার লাইভ ওয়েবসাইট দেখুন' : 'View My Live Website'}</span>
              </button>

              <button
                id="wizard-open-dashboard-btn"
                onClick={onClose}
                className="py-3.5 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-colors"
              >
                {isBn ? 'মার্চেন্ট ড্যাশবোর্ডে প্রবেশ করুন' : 'Enter Merchant Dashboard'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
