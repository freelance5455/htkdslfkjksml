import React, { useState } from 'react';
import { Song } from '../../types/music';
import { Share2, Copy, Check, MessageSquare, Twitter, Facebook, X } from 'lucide-react';

interface ShareModalProps {
  song: Song;
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ song, isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const shareUrl = `${window.location.origin}/#song=${song.id}`;

  const handleCopy = () => {
    navigator.clipboard?.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-[#141622] border border-white/[0.1] p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-4 border-b border-white/[0.08]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-pink-500/20 text-pink-400 flex items-center justify-center">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-white">Share Music</h3>
              <p className="text-xs text-slate-400 truncate max-w-[190px]">{song.title}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-5 space-y-4">
          {/* Link box */}
          <div className="flex items-center gap-2 p-2 rounded-2xl bg-white/[0.04] border border-white/10">
            <input
              type="text"
              readOnly
              value={shareUrl}
              className="bg-transparent text-xs text-slate-300 w-full px-2 outline-none truncate"
            />
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold flex items-center gap-1 shrink-0 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          {/* Social share options */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleCopy}
              className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/[0.06] transition-all"
            >
              <div className="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <MessageSquare className="w-4 h-4" />
              </div>
              <span className="text-[11px] font-medium text-slate-300">WhatsApp</span>
            </button>

            <button
              onClick={handleCopy}
              className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/[0.06] transition-all"
            >
              <div className="w-9 h-9 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center">
                <Twitter className="w-4 h-4" />
              </div>
              <span className="text-[11px] font-medium text-slate-300">Twitter / X</span>
            </button>

            <button
              onClick={handleCopy}
              className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/[0.06] transition-all"
            >
              <div className="w-9 h-9 rounded-full bg-blue-600/20 text-blue-400 flex items-center justify-center">
                <Facebook className="w-4 h-4" />
              </div>
              <span className="text-[11px] font-medium text-slate-300">Facebook</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
