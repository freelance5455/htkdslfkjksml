import React from 'react';
import { Disciple, SectResources, SpiritRootType } from '../../types/cultivation';
import { CULTIVATION_REALMS } from '../../data/realms';
import { CultivatorAvatar } from '../cultivation/CultivatorAvatar';
import { soundEngine } from '../../services/audioEngine';
import { motion } from 'framer-motion';
import { Flame, ShieldCheck, Sparkles, HeartPulse, X, Clock } from 'lucide-react';

interface SoulLanternModalProps {
  disciples: Disciple[];
  resources: SectResources;
  devMode: boolean;
  onClose: () => void;
  onNourishLantern: (discipleId: string) => void;
  onProtectSoul: (discipleId: string) => void;
  onIgniteGrandResonance: () => void;
}

const getFlameColor = (root: SpiritRootType) => {
  switch (root) {
    case 'Fire': return { outer: '#f97316', inner: '#fef08a', glow: 'rgba(249,115,22,0.55)' };
    case 'Ice': return { outer: '#38bdf8', inner: '#e0f2fe', glow: 'rgba(56,189,248,0.55)' };
    case 'Thunder': return { outer: '#eab308', inner: '#fef9c3', glow: 'rgba(234,179,8,0.6)' };
    case 'Yin-Yang': return { outer: '#a855f7', inner: '#f3e8ff', glow: 'rgba(168,85,247,0.55)' };
    case 'Chaos': return { outer: '#f43f5e', inner: '#ffe4e6', glow: 'rgba(244,63,94,0.6)' };
    case 'Heavenly': return { outer: '#facc15', inner: '#ffffff', glow: 'rgba(250,204,21,0.7)' };
    case 'Immortal': return { outer: '#34d399', inner: '#ecfdf5', glow: 'rgba(52,211,153,0.7)' };
    case 'Wood': return { outer: '#22c55e', inner: '#dcfce7', glow: 'rgba(34,197,94,0.5)' };
    case 'Water': return { outer: '#06b6d4', inner: '#cffafe', glow: 'rgba(6,182,212,0.5)' };
    case 'Metal': return { outer: '#cbd5e1', inner: '#ffffff', glow: 'rgba(203,213,225,0.5)' };
    default: return { outer: '#f59e0b', inner: '#fef3c7', glow: 'rgba(245,158,11,0.55)' };
  }
};

const SoulLanternSvg: React.FC<{ root: SpiritRootType; healthState: 'Radiant' | 'Steady' | 'Flickering'; protectedSeal?: boolean }> = ({
  root,
  healthState,
  protectedSeal
}) => {
  const flame = getFlameColor(root);
  const scale = healthState === 'Radiant' ? 1.08 : healthState === 'Steady' ? 0.95 : 0.72;

  return (
    <div className="relative w-14 h-16 flex items-center justify-center shrink-0">
      <svg viewBox="0 0 64 76" className="w-full h-full overflow-visible">
        <defs>
          <radialGradient id={`lanternGlow_${root}`} cx="50%" cy="55%" r="50%">
            <stop offset="0%" stopColor={flame.outer} stopOpacity="0.45" />
            <stop offset="100%" stopColor={flame.outer} stopOpacity="0" />
          </radialGradient>
        </defs>
        <circle cx="32" cy="40" r="28" fill={`url(#lanternGlow_${root})`} />
        {/* Top Hanging Ring & Roof */}
        <circle cx="32" cy="7" r="3.5" fill="none" stroke="#e2b054" strokeWidth="1.8" />
        <path d="M 16 18 Q 32 10 48 18 L 44 22 L 20 22 Z" fill="#b45309" stroke="#fce18b" strokeWidth="1.2" />
        {/* Jade Glass Lantern Chamber */}
        <path
          d="M 20 22 L 16 48 Q 32 54 48 48 L 44 22 Z"
          fill="rgba(7, 32, 24, 0.78)"
          stroke={protectedSeal ? '#fde047' : '#e2b054'}
          strokeWidth={protectedSeal ? '2' : '1.4'}
        />
        {/* Animated Soul Flame */}
        <g className="animate-lantern-flame" style={{ transform: `scale(${scale})`, transformOrigin: '32px 44px' }}>
          <path
            d="M 32 25 C 37 31, 39 38, 36 43 Q 32 46 28 43 C 25 38, 27 31, 32 25 Z"
            fill={flame.outer}
          />
          <path
            d="M 32 30 C 35 34, 36 39, 34 42 Q 32 44 30 42 C 28 39, 29 34, 32 30 Z"
            fill={flame.inner}
          />
        </g>
        {/* Base Lotus Pedestal & Tassel */}
        <path d="M 18 48 L 46 48 L 42 54 L 22 54 Z" fill="#92400e" stroke="#fce18b" strokeWidth="1.1" />
        <line x1="32" y1="54" x2="32" y2="68" stroke="#ef4444" strokeWidth="2.2" strokeLinecap="round" />
        <circle cx="32" cy="57" r="2.2" fill="#fde047" />
      </svg>
    </div>
  );
};

export const SoulLanternModal: React.FC<SoulLanternModalProps> = ({
  disciples,
  resources,
  devMode,
  onClose,
  onNourishLantern,
  onProtectSoul,
  onIgniteGrandResonance
}) => {
  const NOURISH_QI_COST = 60;
  const PROTECT_STONES_COST = 100;
  const PROTECT_MERIT_COST = 30;
  const RESONANCE_QI_COST = 120;

  const canAffordNourish = devMode || resources.qi >= NOURISH_QI_COST;
  const canAffordProtect = devMode || (resources.spiritStones >= PROTECT_STONES_COST && resources.merit >= PROTECT_MERIT_COST);
  const canAffordResonance = devMode || resources.qi >= RESONANCE_QI_COST;

  const protectedCount = disciples.filter(d => d.soulProtected).length;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 12 }}
        className="bg-[#10362a] border-2 border-[#e2b054]/80 rounded-3xl w-full max-w-xl shadow-[0_0_50px_rgba(226,176,84,0.28)] overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#081f17] via-[#123d30] to-[#081f17] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-400/50 flex items-center justify-center">
              <Flame className="w-5 h-5 text-amber-300 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
                Ancestral Soul Lantern Hall
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                Monitor disciple life-flames, extend lifespan, & inscribe Tribulation Seals ({protectedCount}/{disciples.length} Sealed)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Soul Lantern Hall"
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Grand Sect Resonance Banner */}
        <div className="p-3.5 sm:p-4 space-y-3 overflow-y-auto grow text-xs text-[#d1e6dc]">
          <div className="bg-gradient-to-r from-[#082219] to-[#134232] p-3.5 rounded-2xl border border-[#e2b054]/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="font-dao font-bold text-sm text-[#fce18b] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Grand Sect Soul Resonance</span>
              </div>
              <p className="text-[11px] text-[#a4c5b7]">
                Harmonize all life-lanterns at once: +35% Cultivation Speed for 5 mins, +10 Loyalty, & -15 Stress to every disciple.
              </p>
            </div>
            <button
              disabled={!canAffordResonance || disciples.length === 0}
              onClick={() => {
                soundEngine.playLanternLit();
                onIgniteGrandResonance();
              }}
              className={`px-3.5 py-2.5 rounded-xl font-dao font-bold text-xs whitespace-nowrap min-h-[40px] transition-all shrink-0 ${
                canAffordResonance && disciples.length > 0
                  ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-95 shadow-md'
                  : 'bg-gray-800 text-gray-500 cursor-not-allowed'
              }`}
            >
              Ignite ({devMode ? 'Free' : `${RESONANCE_QI_COST} Qi`})
            </button>
          </div>

          {/* Individual Disciple Lantern Cards */}
          {disciples.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-[#09261d] border border-[#1b4b3b] text-[#8daea0]">
              No disciples currently have soul slips bound to the Ancestral Altar.
            </div>
          ) : (
            <div className="space-y-2.5">
              {disciples.map(d => {
                const realm = CULTIVATION_REALMS[d.currentRealmIndex] || CULTIVATION_REALMS[0];
                const yearsLeft = Math.max(0, d.lifespan - d.age);
                const healthState: 'Radiant' | 'Steady' | 'Flickering' =
                  d.stress >= 60 || yearsLeft <= 15
                    ? 'Flickering'
                    : d.soulProtected || d.morale >= 85
                    ? 'Radiant'
                    : 'Steady';
                const hasResonance = Boolean(d.soulResonanceUntil && d.soulResonanceUntil > Date.now());

                return (
                  <div
                    key={d.id}
                    className="bg-[#09261d] p-3 rounded-2xl border border-[#1d5543] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <SoulLanternSvg
                        root={d.spiritRoot}
                        healthState={healthState}
                        protectedSeal={d.soulProtected}
                      />
                      <CultivatorAvatar
                        gender={d.gender}
                        rank={d.rank}
                        spiritRoot={d.spiritRoot}
                        realmIndex={d.currentRealmIndex}
                        appearanceIndex={d.appearanceIndex ?? d.avatarStyle?.appearanceIndex}
                        skinTone={d.skinTone ?? d.avatarStyle?.skinTone}
                        clothingColor={d.clothingColor ?? d.avatarStyle?.clothingColor}
                        hairColor={d.hairColor ?? d.avatarStyle?.hairColor}
                        auraEffect={d.auraEffect ?? d.avatarStyle?.auraEffect}
                        mythicalForm={d.mythicalForm ?? d.avatarStyle?.mythicalForm}
                        soulProtected={d.soulProtected}
                        showGenderBadge={false}
                        size="sm"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-dao font-bold text-sm text-[#fce18b] truncate">{d.name}</span>
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded-md font-bold ${
                              healthState === 'Radiant'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                                : healthState === 'Steady'
                                ? 'bg-sky-950 text-sky-300 border border-sky-500/40'
                                : 'bg-rose-950 text-rose-300 border border-rose-500/40 animate-pulse'
                            }`}
                          >
                            {healthState} Flame
                          </span>
                          {d.soulProtected && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-amber-950 text-amber-300 border border-amber-400/50 font-bold">
                              Sealed
                            </span>
                          )}
                          {hasResonance && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-purple-950 text-purple-300 border border-purple-400/40 font-bold">
                              Resonance +35%
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-[#9fc2b2] mt-0.5 flex items-center gap-2 flex-wrap">
                          <span>{realm.name}</span>
                          <span>·</span>
                          <span className="inline-flex items-center gap-1 text-sky-300 font-mono">
                            <Clock className="w-3 h-3" />
                            {yearsLeft} yrs left
                          </span>
                          <span>·</span>
                          <span className="text-rose-300 font-mono">Stress: {d.stress}%</span>
                        </div>
                      </div>
                    </div>

                    {/* Lantern Actions */}
                    <div className="flex items-center gap-1.5 shrink-0 justify-end">
                      <button
                        disabled={!canAffordNourish}
                        onClick={() => {
                          soundEngine.playLanternLit();
                          onNourishLantern(d.id);
                        }}
                        className={`px-2.5 py-2 rounded-xl text-[11px] font-bold flex items-center gap-1 border min-h-[38px] transition-all ${
                          canAffordNourish
                            ? 'bg-[#15803d] hover:bg-[#166534] text-white border-[#4ade80]/50 active:scale-95'
                            : 'bg-gray-800 text-gray-500 border-gray-700 cursor-not-allowed'
                        }`}
                      >
                        <HeartPulse className="w-3.5 h-3.5" />
                        <span>Nourish ({devMode ? 'Free' : '60 Qi'})</span>
                      </button>

                      <button
                        disabled={Boolean(d.soulProtected) || !canAffordProtect}
                        onClick={() => {
                          soundEngine.playTalisman();
                          onProtectSoul(d.id);
                        }}
                        className={`px-2.5 py-2 rounded-xl text-[11px] font-bold flex items-center gap-1 border min-h-[38px] transition-all ${
                          d.soulProtected
                            ? 'bg-amber-950/60 text-amber-300 border-amber-500/40 cursor-default'
                            : canAffordProtect
                            ? 'bg-[#184838] hover:bg-[#205c48] text-[#fce18b] border-[#e2b054]/60 active:scale-95'
                            : 'bg-gray-800 text-gray-500 border-gray-700 cursor-not-allowed'
                        }`}
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>{d.soulProtected ? 'Protected' : devMode ? 'Seal Soul' : 'Seal (100S/30M)'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Ancestral Soul Slip Sanctuary</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[40px]"
          >
            Close Sanctuary
          </button>
        </div>
      </motion.div>
    </div>
  );
};
