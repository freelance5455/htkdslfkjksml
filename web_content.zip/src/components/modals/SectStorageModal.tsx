import React, { useState } from 'react';
import { Disciple, StorageItem } from '../../types/cultivation';
import { CULTIVATION_REALMS } from '../../data/realms';
import { soundEngine } from '../../services/audioEngine';
import spiritBladeArt from '../../assets/images/art_spirit_blade_1794844217347.jpg';
import spiritResourcesArt from '../../assets/images/art_spirit_resources_1794844216623.jpg';
import { Package, Sparkles, Sword, X, User } from 'lucide-react';

interface SectStorageModalProps {
  storageItems: StorageItem[];
  disciples: Disciple[];
  onClose: () => void;
  onUseConsumable: (storageId: string, discipleId: string) => void;
  onEquipFromStorage: (storageId: string, discipleId: string) => void;
}

export const SectStorageModal: React.FC<SectStorageModalProps> = ({
  storageItems,
  disciples,
  onClose,
  onUseConsumable,
  onEquipFromStorage
}) => {
  const livingDisciples = disciples.filter(d => !d.isPerished);
  const [filter, setFilter] = useState<'All' | 'Consumables' | 'Equipment'>('All');
  const [selectedDiscipleId, setSelectedDiscipleId] = useState<string>(livingDisciples[0]?.id || '');

  const targetDisciple = livingDisciples.find(d => d.id === selectedDiscipleId) || livingDisciples[0];

  const visibleItems = storageItems.filter(item => {
    if (filter === 'Equipment') return item.type === 'Equipment';
    if (filter === 'Consumables') return item.type !== 'Equipment';
    return true;
  });

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header with Bespoke Art Backdrop */}
        <div className="relative overflow-hidden bg-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center">
          <img
            src={spiritResourcesArt}
            alt="Sect Treasure Vault"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover opacity-20 pointer-events-none"
          />
          <div className="relative z-10 flex items-center gap-2.5 min-w-0">
            <Package className="w-5 h-5 text-[#fce18b] shrink-0" />
            <div className="min-w-0">
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b] truncate">
                Sect Treasure Vault · <span className="font-mono tabular-nums">{storageItems.length}</span> Stored
              </h3>
              <p className="text-[11px] text-[#d1e6dc] truncate">
                Use stored elixirs, manuals, and artifacts or equip relics onto eligible disciples.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="relative z-10 p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Target Disciple Selector & Category Tabs */}
        <div className="bg-[#09261d] p-3 border-b border-[#1b4b3b] space-y-2.5 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <label className="text-[#fce18b] font-bold flex items-center gap-1.5 shrink-0">
              <User className="w-3.5 h-3.5 text-[#e2b054]" />
              <span>Recipient Disciple:</span>
            </label>
            <select
              value={selectedDiscipleId}
              onChange={(e) => setSelectedDiscipleId(e.target.value)}
              className="flex-1 bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white text-xs"
            >
              {livingDisciples.map(d => (
                <option key={d.id} value={d.id}>
                  {d.name} ({CULTIVATION_REALMS[d.currentRealmIndex]?.name || 'Qi'} · {d.rank})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            {(['All', 'Consumables', 'Equipment'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setFilter(tab)}
                className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all ${
                  filter === tab
                    ? 'bg-[#e2b054] text-[#072018]'
                    : 'bg-[#123d30] text-[#9fc2b2] hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Stored Inventory */}
        <div className="p-4 overflow-y-auto space-y-2.5 grow text-xs text-[#d1e6dc]">
          {visibleItems.length === 0 ? (
            <div className="bg-[#09261d] border border-[#1b4b3b] rounded-2xl p-6 text-center space-y-2 text-[#9fc2b2]">
              <img
                src={spiritBladeArt}
                alt="Empty Storage Relic"
                referrerPolicy="no-referrer"
                className="w-16 h-16 rounded-2xl object-cover mx-auto opacity-75 border border-[#e2b054]/40"
              />
              <p className="font-dao font-bold text-sm text-[#fce18b]">Vault Shelf Empty</p>
              <p className="text-[11px]">
                Purchase treasures from Bao&apos;s Immortal Pavilion or earn Prodigy Year-End Ceremony relics to store them here.
              </p>
            </div>
          ) : (
            visibleItems.map(item => {
              const isEquip = item.type === 'Equipment' && Boolean(item.equipSlot);
              const reqRealm = item.minRealmIndex ?? 0;
              const meetsRealm = targetDisciple ? targetDisciple.currentRealmIndex >= reqRealm : false;

              return (
                <div
                  key={item.storageId}
                  className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] flex justify-between items-center gap-3 hover:border-[#e2b054]/50 transition-colors"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-dao font-bold text-white text-xs sm:text-sm truncate">{item.name}</span>
                      <span className="text-[10px] text-amber-300 font-semibold">
                        · {item.tier} · {isEquip ? `Slot: ${item.equipSlot}` : item.type}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#a4c5b7] leading-snug">{item.description}</p>
                    <div className="text-[10px] text-[#86efac]">
                      Effect: {item.effect}
                      {reqRealm > 0 && (
                        <span className={`ml-2 ${meetsRealm ? 'text-sky-300' : 'text-rose-300'}`}>
                          · Requires {CULTIVATION_REALMS[reqRealm]?.name}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="shrink-0">
                    {isEquip ? (
                      <button
                        disabled={!targetDisciple || !meetsRealm}
                        onClick={() => {
                          if (!targetDisciple) return;
                          soundEngine.playTalisman();
                          onEquipFromStorage(item.storageId, targetDisciple.id);
                        }}
                        className={`px-3 py-2 rounded-xl font-dao font-bold text-xs flex items-center gap-1.5 min-h-[38px] ${
                          meetsRealm && targetDisciple
                            ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110'
                            : 'bg-[#0d281f] text-[#6d8e80] border border-[#194536] cursor-not-allowed'
                        }`}
                      >
                        <Sword className="w-3.5 h-3.5" />
                        <span>{meetsRealm ? 'Equip' : 'Low Realm'}</span>
                      </button>
                    ) : (
                      <button
                        disabled={!targetDisciple}
                        onClick={() => {
                          if (!targetDisciple) return;
                          soundEngine.playCauldronBubble();
                          onUseConsumable(item.storageId, targetDisciple.id);
                        }}
                        className="px-3 py-2 rounded-xl bg-[#184838] hover:bg-[#1f5c48] text-[#fce18b] border border-[#e2b054]/50 font-dao font-bold text-xs flex items-center gap-1.5 min-h-[38px]"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Use on {targetDisciple?.name.split(' ')[0] || 'Disciple'}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Tip: Items here can also be gifted in Bonds &amp; Matrix</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Close Vault
          </button>
        </div>
      </div>
    </div>
  );
};
