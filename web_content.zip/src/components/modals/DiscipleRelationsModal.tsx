import React, { useState } from 'react';
import {
  Disciple,
  DiscipleRelation,
  RelationType,
  SectAlignment,
  BondLevel,
  StorageItem
} from '../../types/cultivation';
import { soundEngine } from '../../services/audioEngine';
import {
  Users,
  Flame,
  Sparkles,
  X,
  Wine,
  Unlink,
  ShieldCheck,
  Gift,
  Heart,
  Swords,
  Lock
} from 'lucide-react';

interface DiscipleRelationsModalProps {
  disciples: Disciple[];
  relations: DiscipleRelation[];
  storageItems: StorageItem[];
  currentDateIso: string;
  sectAlignment?: SectAlignment;
  spiritStones?: number;
  devMode?: boolean;
  onClose: () => void;
  onHoldSectFeast: () => void;
  onForgeBond: (disciple1Id: string, disciple2Id: string, bondType: RelationType, success: boolean) => void;
  onGiftStorageToBond: (disciple1Id: string, disciple2Id: string, storageId: string) => { success: boolean; message: string };
  onGoOnDate: (disciple1Id: string, disciple2Id: string) => { success: boolean; message: string };
  onDeployTogether: (disciple1Id: string, disciple2Id: string) => { success: boolean; message: string };
  onResolveGrudge: (disciple1Id: string, disciple2Id: string) => void;
  onOpenLifeDeathArena?: () => void;
  onSeverBond?: (disciple1Id: string, disciple2Id: string) => void;
}

const BOND_LEVEL_LABELS: Record<BondLevel, string> = {
  1: 'Unknown',
  2: 'Acquaintance',
  3: 'Trusted',
  4: 'Devoted',
  5: 'Inseparable'
};

const BOND_XP_THRESHOLDS: Record<BondLevel, number> = {
  1: 100,
  2: 180,
  3: 280,
  4: 420,
  5: 0
};

const POSITIVE_BOND_TYPES: RelationType[] = [
  'Lover',
  'Confidant',
  'Master-Disciple',
  'Adoptive Parent',
  'Adoptive Father',
  'Adoptive Mother',
  'Son/Daughter',
  'Sworn Sibling',
  'Friend'
];

const RANK_WEIGHTS: Record<string, number> = {
  Outer: 1,
  Inner: 2,
  Direct: 3,
  Elder: 4,
  'Grand Elder': 5,
  'Sect Leader': 6
};

export const DiscipleRelationsModal: React.FC<DiscipleRelationsModalProps> = ({
  disciples,
  relations,
  storageItems,
  currentDateIso,
  sectAlignment = 'Cloud Mist Neutral',
  spiritStones = 0,
  devMode = false,
  onClose,
  onHoldSectFeast,
  onForgeBond,
  onGiftStorageToBond,
  onGoOnDate,
  onDeployTogether,
  onResolveGrudge,
  onOpenLifeDeathArena,
  onSeverBond
}) => {
  const living = disciples.filter(d => !d.isPerished);
  const [selectedD1, setSelectedD1] = useState<string>(living[0]?.id || '');
  const [selectedD2, setSelectedD2] = useState<string>(living[1]?.id || (living[0]?.id || ''));
  const [selectedBondType, setSelectedBondType] = useState<RelationType>('Confidant');
  const [selectedGiftStorageId, setSelectedGiftStorageId] = useState<string>(storageItems[0]?.storageId || '');
  const [attemptOutcome, setAttemptOutcome] = useState<{ message: string; success: boolean } | null>(null);

  const disciple1 = living.find(d => d.id === selectedD1);
  const disciple2 = living.find(d => d.id === selectedD2);

  // Look up active pair bond from global relations or embedded disciple.relations
  const existingGlobalRel = disciple1 && disciple2 && disciple1.id !== disciple2.id
    ? relations.find(
        r =>
          ((r.discipleId1 === disciple1.id && r.discipleId2 === disciple2.id) ||
            (r.discipleId1 === disciple2.id && r.discipleId2 === disciple1.id)) &&
          POSITIVE_BOND_TYPES.includes(r.relationType || r.type)
      )
    : undefined;

  const existingEmbedded = disciple1 && disciple2 && disciple1.id !== disciple2.id
    ? disciple1.relations.find(r => r.targetId === disciple2.id && POSITIVE_BOND_TYPES.includes(r.type))
    : undefined;

  const existingBondLevel: BondLevel = ((existingGlobalRel?.bondLevel || existingEmbedded?.level || 1) as BondLevel);
  const bondXp = existingGlobalRel?.xp ?? existingEmbedded?.xp ?? 0;
  const bondXpReq = existingGlobalRel?.xpRequired ?? existingEmbedded?.xpRequired ?? BOND_XP_THRESHOLDS[existingBondLevel] ?? 180;
  const hasPositiveBond = Boolean(existingGlobalRel || existingEmbedded);

  // Strict lineage & hierarchy prerequisites check
  const getRoleEligibility = (bond: RelationType, d1?: Disciple, d2?: Disciple): { valid: boolean; reason?: string; displayLabel: string } => {
    if (!d1 || !d2 || d1.id === d2.id) return { valid: false, reason: 'Select two distinct disciples', displayLabel: bond };
    const r1 = RANK_WEIGHTS[d1.rank] || 1;
    const r2 = RANK_WEIGHTS[d2.rank] || 1;

    if (bond === 'Master-Disciple') {
      const ok = d1.currentRealmIndex > d2.currentRealmIndex || r1 > r2;
      return {
        valid: ok,
        reason: ok ? undefined : `${d1.name} must hold a strictly higher realm or rank than ${d2.name} to become Master`,
        displayLabel: 'Master-Disciple'
      };
    }

    if (bond === 'Adoptive Parent') {
      const roleWord = d1.gender === 'Male' ? 'Adoptive Father' : 'Adoptive Mother';
      const ok = d1.age >= d2.age + 6 || d1.currentRealmIndex >= d2.currentRealmIndex + 2 || r1 > r2;
      return {
        valid: ok,
        reason: ok ? undefined : `${d1.name} must be senior in age (+6 yrs) or realm/rank to adopt as ${roleWord}`,
        displayLabel: `${roleWord} → ${d2.gender === 'Male' ? 'Adopted Son' : 'Adopted Daughter'}`
      };
    }

    if (bond === 'Son/Daughter') {
      const parentWord = d2.gender === 'Male' ? 'Adoptive Father' : 'Adoptive Mother';
      const ok = d2.age >= d1.age + 6 || d2.currentRealmIndex >= d1.currentRealmIndex + 2 || r2 > r1;
      return {
        valid: ok,
        reason: ok ? undefined : `${d2.name} must be senior in age (+6 yrs) or realm/rank to adopt ${d1.name}`,
        displayLabel: `${d1.gender === 'Male' ? 'Adopted Son' : 'Adopted Daughter'} (under ${parentWord})`
      };
    }

    return { valid: true, displayLabel: bond };
  };

  const roleCheck = getRoleEligibility(selectedBondType, disciple1, disciple2);

  const calculateBondAnalysis = (
    d1?: Disciple,
    d2?: Disciple,
    bond?: RelationType
  ): { rate: number; alignNote: string; alignMod: number } => {
    if (!d1 || !d2 || d1.id === d2.id) {
      return { rate: 0, alignNote: 'Select two distinct disciples', alignMod: 0 };
    }

    let baseRate = 70;
    const rankDiff = (RANK_WEIGHTS[d2.rank] || 1) - (RANK_WEIGHTS[d1.rank] || 1);
    if (rankDiff > 0) baseRate -= rankDiff * 14;

    const realmDiff = d2.currentRealmIndex - d1.currentRealmIndex;
    if (realmDiff > 0) baseRate -= Math.min(24, realmDiff * 3);

    const a1 = d1.personalAlignment || sectAlignment;
    const a2 = d2.personalAlignment || sectAlignment;
    let alignMod = 0;
    let alignNote = 'Neutral Dao Resonance';

    if (a1 === a2) {
      alignMod = 12;
      alignNote = `Shared Alignment (${a1}) +12%`;
    } else if (
      (a1 === 'Righteous Orthodox' && a2 === 'Demonic Blood Cult') ||
      (a1 === 'Demonic Blood Cult' && a2 === 'Righteous Orthodox') ||
      (a1 === 'Buddhic Zen' && a2 === 'Demonic Blood Cult') ||
      (a1 === 'Demonic Blood Cult' && a2 === 'Buddhic Zen')
    ) {
      alignMod = -24;
      alignNote = `Clashing Alignments (${a1} vs ${a2}) -24%`;
    } else if (a1 === 'Cloud Mist Neutral' || a2 === 'Cloud Mist Neutral') {
      alignMod = 5;
      alignNote = 'Flexible Mist Affinity +5%';
    }
    baseRate += alignMod;

    if (d1.temperament === d2.temperament || d1.temperament === 'Loyal' || d2.temperament === 'Benevolent') {
      baseRate += 6;
    }

    if (bond === 'Lover' || bond === 'Adoptive Parent') {
      baseRate -= 8;
    }

    return {
      rate: Math.max(10, Math.min(96, Math.round(baseRate))),
      alignNote,
      alignMod
    };
  };

  const { rate: currentSuccessRate, alignNote, alignMod } = calculateBondAnalysis(disciple1, disciple2, selectedBondType);

  const handleAttemptBond = () => {
    if (!disciple1 || !disciple2 || disciple1.id === disciple2.id || hasPositiveBond || !roleCheck.valid) return;

    const roll = Math.random() * 100;
    const isSuccess = roll <= currentSuccessRate;

    const effectiveType: RelationType =
      selectedBondType === 'Adoptive Parent'
        ? disciple1.gender === 'Male'
          ? 'Adoptive Father'
          : 'Adoptive Mother'
        : selectedBondType;

    if (isSuccess) {
      soundEngine.playFanfare();
      setAttemptOutcome({
        message: `Bond Formed! ${disciple1.name} & ${disciple2.name} entered [${effectiveType}] at Lv 1 (Unknown · 0/100 XP). Gift, date, or train together daily to level up!`,
        success: true
      });
      onForgeBond(disciple1.id, disciple2.id, effectiveType, true);
    } else {
      soundEngine.playThunder();
      setAttemptOutcome({
        message: `Bond Rejected! ${disciple2.name} declined ${disciple1.name}'s proposal. Resentment lingered instead.`,
        success: false
      });
      onForgeBond(disciple1.id, disciple2.id, effectiveType, false);
    }
  };

  // Gift & Daily Caps helpers
  const giftedToday = existingGlobalRel?.lastGiftDay === currentDateIso;
  const datedToday = existingGlobalRel?.lastDateDay === currentDateIso;
  const deployedToday = existingGlobalRel?.lastDeployedDay === currentDateIso;
  const assignedSameBuilding = Boolean(
    disciple1?.assignedBuildingId &&
    disciple2?.assignedBuildingId &&
    disciple1.assignedBuildingId === disciple2.assignedBuildingId
  );

  const selectedGiftItem = storageItems.find(i => i.storageId === selectedGiftStorageId) || storageItems[0];
  const giftPreferenceMatches = Boolean(
    selectedGiftItem &&
    disciple2?.preference &&
    selectedGiftItem.preferredPreference &&
    disciple2.preference === selectedGiftItem.preferredPreference
  );

  // Collect all unique grudges
  const allGrudges: { from: Disciple; to: Disciple; jealousy: number; reason?: string }[] = [];
  const seenPairs = new Set<string>();
  relations.forEach(r => {
    const gScore = r.grudge || 0;
    if (gScore > 0) {
      const from = living.find(d => d.id === r.discipleId1);
      const to = living.find(d => d.id === r.discipleId2);
      if (from && to) {
        const key = [from.id, to.id].sort().join('_');
        if (!seenPairs.has(key)) {
          seenPairs.add(key);
          allGrudges.push({ from, to, jealousy: Math.round(gScore), reason: r.grudgeReason });
        }
      }
    }
  });
  living.forEach(d => {
    d.relations.forEach(r => {
      if (r.jealousy > 0 || r.type === 'Grudge' || r.type === 'Rival') {
        const target = living.find(targetD => targetD.id === r.targetId);
        if (target) {
          const key = [d.id, target.id].sort().join('_');
          if (!seenPairs.has(key)) {
            seenPairs.add(key);
            allGrudges.push({ from: d, to: target, jealousy: Math.round(r.jealousy), reason: r.grudgeReason });
          }
        }
      }
    });
  });

  const availableBondTypes: { type: RelationType; label: string; desc: string }[] = [
    { type: 'Lover', label: 'Lover / Dao Companion', desc: '+Cultivation Affinity & Dao protection' },
    { type: 'Confidant', label: 'Soul Confidant', desc: 'Steadies Dao-Heart & calms anxiety' },
    { type: 'Master-Disciple', label: 'Master-Disciple', desc: 'Requires Master higher realm or rank' },
    { type: 'Adoptive Parent', label: 'Adoptive Parent', desc: 'Gender-aware Adoptive Father/Mother' },
    { type: 'Son/Daughter', label: 'Adopted Son/Daughter', desc: 'Filial lineage under elder' },
    { type: 'Sworn Sibling', label: 'Sworn Sibling', desc: 'Blood oath sworn before sect tablets' },
    { type: 'Friend', label: 'Daoist Friend', desc: 'Harmonious sparring & mutual morale' }
  ];

  const canAffordFeast = devMode || spiritStones >= 80;
  const canAffordDate = devMode || spiritStones >= 15;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh] relative">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2 min-w-0">
            <Users className="w-5 h-5 text-[#fce18b] shrink-0" />
            <div className="min-w-0">
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b] truncate">
                Disciple Social Matrix &amp; Karma Bonds
              </h3>
              <p className="text-[11px] text-[#9fc2b2] truncate">
                Lv 1 Unknown → Lv 5 Inseparable via daily gifts, outings &amp; joint tasks.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-4 grow text-xs text-[#d1e6dc]">
          {/* Sect Banquet Action */}
          <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b]">
            <div className="flex justify-between items-center gap-3">
              <div>
                <div className="font-bold text-[#fce18b] text-sm flex items-center gap-1.5">
                  <Wine className="w-4 h-4 text-[#e2b054]" />
                  <span>Grand Sect Banquet</span>
                </div>
                <div className="text-[10px] text-[#9fc2b2]">
                  Costs {devMode ? '0 (Dev)' : '80 Spirit Stones'} · Reduces grudges, stress &amp; warms sect morale.
                </div>
              </div>
              <button
                disabled={!canAffordFeast}
                onClick={() => {
                  soundEngine.playTalisman();
                  onHoldSectFeast();
                }}
                className={`px-3.5 py-2 rounded-xl font-bold text-xs shadow-md shrink-0 min-h-[38px] ${
                  canAffordFeast
                    ? 'bg-gradient-to-r from-[#b45309] to-[#d97706] text-white hover:brightness-110 active:scale-95'
                    : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                }`}
              >
                {canAffordFeast ? 'Host Feast' : 'Need 80 Stones'}
              </button>
            </div>
          </div>

          {/* Forge / Deepen Bond Section */}
          <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-3">
            <h4 className="font-bold font-dao text-sm text-[#fce18b] flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#e2b054]" />
              <span>Bonds, Lineage Adoption &amp; Daily Deepening</span>
            </h4>

            {/* Pair Picker */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="text-[10px] text-[#8daea0] block mb-1">Initiator (Disciple 1)</label>
                <select
                  value={selectedD1}
                  onChange={(e) => {
                    setSelectedD1(e.target.value);
                    setAttemptOutcome(null);
                  }}
                  className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white text-xs"
                >
                  {living.map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.rank} · Age {d.age})</option>
                  ))}
                </select>
                {disciple1 && (
                  <div className="text-[9px] text-[#9fc2b2] mt-1 truncate">
                    {disciple1.gender} · {disciple1.personalAlignment || sectAlignment}
                  </div>
                )}
              </div>

              <div>
                <label className="text-[10px] text-[#8daea0] block mb-1">Peer Target (Disciple 2)</label>
                <select
                  value={selectedD2}
                  onChange={(e) => {
                    setSelectedD2(e.target.value);
                    setAttemptOutcome(null);
                  }}
                  className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white text-xs"
                >
                  {living.filter(d => d.id !== selectedD1).map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.rank} · Age {d.age})</option>
                  ))}
                </select>
                {disciple2 && (
                  <div className="text-[9px] text-[#9fc2b2] mt-1 truncate">
                    {disciple2.gender} · Likes: {disciple2.preference || 'Spirit Herbs'}
                  </div>
                )}
              </div>
            </div>

            {/* Alignment Compatibility Strip */}
            {disciple1 && disciple2 && disciple1.id !== disciple2.id && (
              <div className={`px-2.5 py-1.5 rounded-xl border text-[10px] flex items-center justify-between ${
                alignMod >= 10
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                  : alignMod < 0
                  ? 'bg-red-950/50 border-red-500/40 text-red-200'
                  : 'bg-[#0b261d] border-[#1d5543] text-[#a4c5b7]'
              }`}>
                <span>Alignment Factor:</span>
                <span className="font-bold">{alignNote}</span>
              </div>
            )}

            {/* Existing Active Bond with Bond XP & Daily Actions */}
            {hasPositiveBond && disciple1 && disciple2 ? (
              <div className="p-3 rounded-2xl bg-[#0d3126] border border-[#e2b054]/60 space-y-3">
                <div className="flex justify-between items-start gap-2">
                  <div>
                    <div className="text-[10px] text-[#86efac] font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Active Bond · Stat Bonus: +{existingBondLevel * 2}% Cult, +{existingBondLevel * 3}% Combat</span>
                    </div>
                    <div className="text-sm font-dao font-bold text-[#fce18b] mt-0.5">
                      {existingGlobalRel?.relationType || existingEmbedded?.type} · Lv {existingBondLevel}/5 ({BOND_LEVEL_LABELS[existingBondLevel]})
                    </div>
                  </div>
                  {onSeverBond && (
                    <button
                      onClick={() => {
                        soundEngine.playClick();
                        onSeverBond(disciple1.id, disciple2.id);
                        setAttemptOutcome({
                          message: `Bond severed between ${disciple1.name} and ${disciple2.name}.`,
                          success: false
                        });
                      }}
                      className="px-2 py-1 rounded-lg bg-red-950/70 hover:bg-red-900 border border-red-700/50 text-red-300 font-bold text-[10px] flex items-center gap-1 shrink-0"
                    >
                      <Unlink className="w-3 h-3" />
                      <span>Sever</span>
                    </button>
                  )}
                </div>

                {/* Bond XP Progress Bar */}
                {existingBondLevel < 5 ? (
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] text-[#9fc2b2]">
                      <span>Bond Experience toward Lv {existingBondLevel + 1} ({BOND_LEVEL_LABELS[(existingBondLevel + 1) as BondLevel]})</span>
                      <span className="font-mono tabular-nums text-[#fce18b]">{bondXp} / {bondXpReq} XP</span>
                    </div>
                    <div className="w-full bg-[#061812] h-2 rounded-full overflow-hidden border border-[#1d5543]">
                      <div
                        className="bg-gradient-to-r from-[#e2b054] to-emerald-400 h-full transition-all duration-300"
                        style={{ width: `${Math.min(100, (bondXp / Math.max(1, bondXpReq)) * 100)}%` }}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="py-1.5 px-3 rounded-xl bg-emerald-950/80 border border-emerald-400/50 text-emerald-200 font-dao font-bold text-[11px] text-center">
                    Max Level Attained: Inseparable (5/5 · +10% Cult &amp; +15% Combat)
                  </div>
                )}

                {/* Daily-Capped Deepening Actions (Gift from Storage, Date, Deploy Together) */}
                {existingBondLevel < 5 && (
                  <div className="space-y-2 pt-1 border-t border-[#1b4b3b]">
                    <div className="text-[10px] text-[#9fc2b2] font-bold">Daily Bond Growth Actions (1/day per category):</div>

                    {/* 1. Gift Stored Item */}
                    <div className="bg-[#09261d] p-2.5 rounded-xl border border-[#1b4b3b] space-y-2">
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="font-bold text-[#fce18b] flex items-center gap-1">
                          <Gift className="w-3.5 h-3.5 text-amber-300" />
                          <span>Gift Item from Sect Storage</span>
                        </span>
                        <span className={giftedToday ? 'text-[#6d8e80]' : 'text-emerald-300'}>
                          {giftedToday ? 'Gifted Today (0/1)' : '1 Available Today'}
                        </span>
                      </div>

                      {storageItems.length === 0 ? (
                        <div className="text-[10px] text-[#7ea091] italic">
                          Sect Storage is empty — buy gifts from Bao&apos;s Immortal Pavilion first.
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <select
                            value={selectedGiftStorageId || selectedGiftItem?.storageId || ''}
                            onChange={(e) => setSelectedGiftStorageId(e.target.value)}
                            className="flex-1 bg-[#123d30] border border-[#e2b054]/30 rounded-lg p-1.5 text-[11px] text-white min-w-0"
                          >
                            {storageItems.map(it => (
                              <option key={it.storageId} value={it.storageId}>
                                {it.name} ({it.tier} · +{it.bondXpValue || 25} XP)
                              </option>
                            ))}
                          </select>
                          <button
                            disabled={giftedToday || !selectedGiftItem}
                            onClick={() => {
                              if (!selectedGiftItem) return;
                              soundEngine.playTalisman();
                              const res = onGiftStorageToBond(disciple1.id, disciple2.id, selectedGiftItem.storageId);
                              setAttemptOutcome({ message: res.message, success: res.success });
                            }}
                            className={`px-3 py-1.5 rounded-lg font-bold text-[10px] shrink-0 ${
                              !giftedToday && selectedGiftItem
                                ? 'bg-[#e2b054] text-[#072018] hover:brightness-110'
                                : 'bg-[#0c2c22] text-[#6d8e80] cursor-not-allowed'
                            }`}
                          >
                            Gift {giftPreferenceMatches ? '(1.5x Match!)' : ''}
                          </button>
                        </div>
                      )}
                    </div>

                    {/* 2. Date & Deploy Together */}
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        disabled={datedToday || !canAffordDate}
                        onClick={() => {
                          soundEngine.playClick();
                          const res = onGoOnDate(disciple1.id, disciple2.id);
                          setAttemptOutcome({ message: res.message, success: res.success });
                        }}
                        className={`p-2 rounded-xl border text-left transition-all ${
                          !datedToday && canAffordDate
                            ? 'bg-[#123d30] hover:bg-[#195341] border-rose-400/50 text-rose-100'
                            : 'bg-[#09221a] border-[#193d30] text-[#6d8e80] cursor-not-allowed'
                        }`}
                      >
                        <div className="font-bold text-[10px] flex items-center gap-1">
                          <Heart className="w-3 h-3 text-rose-300" />
                          <span>{datedToday ? 'Outing Used Today' : 'Moonlit Outing (15 Stones)'}</span>
                        </div>
                        <div className="text-[9px] opacity-80">+45~65 XP · Reduces Stress</div>
                      </button>

                      <button
                        disabled={deployedToday}
                        onClick={() => {
                          soundEngine.playSwordSlash();
                          const res = onDeployTogether(disciple1.id, disciple2.id);
                          setAttemptOutcome({ message: res.message, success: res.success });
                        }}
                        className={`p-2 rounded-xl border text-left transition-all ${
                          !deployedToday
                            ? 'bg-[#123d30] hover:bg-[#195341] border-cyan-400/50 text-cyan-100'
                            : 'bg-[#09221a] border-[#193d30] text-[#6d8e80] cursor-not-allowed'
                        }`}
                      >
                        <div className="font-bold text-[10px] flex items-center gap-1">
                          <Swords className="w-3 h-3 text-cyan-300" />
                          <span>{deployedToday ? 'Task Done Today' : 'Deploy Together Drill'}</span>
                        </div>
                        <div className="text-[9px] opacity-80">
                          {assignedSameBuilding ? 'Same Peak Synergy (+75 XP)' : 'Joint Sparring (+50 XP)'}
                        </div>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <>
                <div>
                  <label className="text-[10px] text-[#8daea0] block mb-1">Choose Desired Bond Type</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                    {availableBondTypes.map((item) => {
                      const check = getRoleEligibility(item.type, disciple1, disciple2);
                      return (
                        <button
                          key={item.type}
                          onClick={() => {
                            setSelectedBondType(item.type);
                            setAttemptOutcome(null);
                          }}
                          className={`p-2 rounded-xl text-left border transition-all ${
                            selectedBondType === item.type
                              ? 'bg-[#15803d] text-white border-[#4ade80] shadow-xs'
                              : 'bg-[#123d30] text-[#a4c5b7] border-[#1b4b3b] hover:bg-[#184838]'
                          }`}
                        >
                          <div className="font-bold text-[10px] flex items-center justify-between gap-1">
                            <span className="truncate">{item.label}</span>
                            {!check.valid && disciple1 && disciple2 && disciple1.id !== disciple2.id && (
                              <Lock className="w-2.5 h-2.5 text-amber-300 shrink-0" />
                            )}
                          </div>
                          <div className="text-[8px] opacity-75 truncate">{item.desc}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {!roleCheck.valid && roleCheck.reason && (
                  <div className="p-2.5 rounded-xl bg-amber-950/60 border border-amber-500/50 text-amber-200 text-[10px]">
                    Requirement: {roleCheck.reason}
                  </div>
                )}

                {disciple1 && disciple2 && disciple1.id !== disciple2.id && roleCheck.valid && (
                  <div className="p-2.5 rounded-xl bg-[#0b261d] border border-[#e2b054]/40 flex justify-between items-center text-xs">
                    <div>
                      <span className="text-[#a4c5b7]">Formation Odds: </span>
                      <strong className={`font-mono tabular-nums text-sm ${currentSuccessRate >= 60 ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {currentSuccessRate}%
                      </strong>
                    </div>
                    <span className="text-[10px] text-[#9fc2b2]">
                      {roleCheck.displayLabel}
                    </span>
                  </div>
                )}

                <button
                  disabled={!selectedD1 || !selectedD2 || selectedD1 === selectedD2 || !roleCheck.valid}
                  onClick={handleAttemptBond}
                  className={`w-full py-2.5 rounded-xl font-dao font-bold text-xs transition-all min-h-[40px] ${
                    !selectedD1 || !selectedD2 || selectedD1 === selectedD2 || !roleCheck.valid
                      ? 'bg-[#0d281f] text-[#6d8e80] border border-[#194536] cursor-not-allowed'
                      : 'bg-gradient-to-r from-[#184838] to-[#123d30] text-[#fce18b] border border-[#e2b054]/60 hover:brightness-110 active:scale-98'
                  }`}
                >
                  Seal Chosen {roleCheck.displayLabel} Bond (Starts Lv 1 · Unknown)
                </button>
              </>
            )}

            {/* Outcome Banner */}
            {attemptOutcome && (
              <div className={`p-2.5 rounded-xl border text-xs font-medium animate-scale-up ${
                attemptOutcome.success
                  ? 'bg-emerald-950/70 border-emerald-400 text-emerald-200'
                  : 'bg-red-950/70 border-red-500 text-red-200'
              }`}>
                {attemptOutcome.message}
              </div>
            )}
          </div>

          {/* Active Grudges */}
          <div className="space-y-2">
            <h4 className="font-bold font-dao text-sm text-[#fce18b] flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-red-400" />
              <span>Active Jealousies &amp; Grudges ({allGrudges.length})</span>
            </h4>

            {allGrudges.length === 0 ? (
              <div className="p-4 text-center text-xs text-[#86efac] bg-[#09261d] rounded-xl border border-[#1b4b3b]">
                The sect is in pure harmony! No disciples currently harbor active grudges or toxic jealousy.
              </div>
            ) : (
              <div className="space-y-2">
                {allGrudges.map((g, idx) => {
                  const isMortalFeud = g.jealousy >= 80;
                  return (
                    <div
                      key={idx}
                      className="bg-[#09261d] p-3 rounded-xl border border-red-900/40 space-y-1.5 text-xs"
                    >
                      <div className="flex justify-between items-center gap-2">
                        <div className="min-w-0 truncate">
                          <strong className="text-white">{g.from.name}</strong>
                          <span className="text-red-400 mx-1.5">vs</span>
                          <strong className="text-[#fce18b]">{g.to.name}</strong>
                        </div>
                        <span className={`text-[10px] font-mono tabular-nums font-bold shrink-0 ${isMortalFeud ? 'text-rose-300' : 'text-amber-300'}`}>
                          Grudge {g.jealousy}/100
                        </span>
                      </div>

                      {g.reason && (
                        <div className="text-[10px] text-red-300 italic">
                          &ldquo;{g.reason}&rdquo;
                        </div>
                      )}

                      <div className="flex justify-between items-center pt-1 gap-2">
                        <span className="text-[9px] text-[#9fc2b2]">
                          {isMortalFeud ? '80–100 Mortal Feud · Life-and-Death Arena Eligible' : '1–79 Friction · Peaceful Mediation Recommended'}
                        </span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {isMortalFeud && onOpenLifeDeathArena && (
                            <button
                              onClick={() => {
                                soundEngine.playGong();
                                onClose();
                                onOpenLifeDeathArena();
                              }}
                              className="px-2.5 py-1 rounded-lg bg-rose-900 hover:bg-rose-800 text-rose-100 border border-rose-400/50 text-[10px] font-bold"
                            >
                              Life-and-Death Arena
                            </button>
                          )}
                          <button
                            onClick={() => {
                              soundEngine.playGong();
                              onResolveGrudge(g.from.id, g.to.id);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-[#184838] hover:bg-[#1f5a46] text-[#86efac] border border-[#22c55e]/30 text-[10px] font-bold"
                          >
                            Mediate Feud
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Social Bonds &amp; Karma Matrix</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Close Matrix
          </button>
        </div>
      </div>
    </div>
  );
};
