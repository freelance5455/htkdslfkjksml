import React, { useState } from 'react';
import { Disciple, RelationType, SectAlignment, BondLevel } from '../../types/cultivation';
import { soundEngine } from '../../services/audioEngine';
import { Users, Flame, Sparkles, X, Wine, ArrowUpCircle, Unlink, ShieldCheck } from 'lucide-react';

interface DiscipleRelationsModalProps {
  disciples: Disciple[];
  sectAlignment?: SectAlignment;
  spiritStones?: number;
  devMode?: boolean;
  onClose: () => void;
  onHoldSectFeast: () => void;
  onForgeBond: (disciple1Id: string, disciple2Id: string, bondType: RelationType, success: boolean) => void;
  onResolveGrudge: (disciple1Id: string, disciple2Id: string) => void;
  onUpgradeBond?: (disciple1Id: string, disciple2Id: string) => void;
  onSeverBond?: (disciple1Id: string, disciple2Id: string) => void;
}

const BOND_LEVEL_LABELS: Record<BondLevel, string> = {
  1: 'Unknown',
  2: 'Acquaintance',
  3: 'Trusted',
  4: 'Devoted',
  5: 'Inseparable'
};

const POSITIVE_BOND_TYPES: RelationType[] = [
  'Lover',
  'Confidant',
  'Master-Disciple',
  'Adoptive Parent',
  'Son/Daughter',
  'Sworn Sibling',
  'Friend'
];

export const DiscipleRelationsModal: React.FC<DiscipleRelationsModalProps> = ({
  disciples,
  sectAlignment = 'Cloud Mist Neutral',
  spiritStones = 0,
  devMode = false,
  onClose,
  onHoldSectFeast,
  onForgeBond,
  onResolveGrudge,
  onUpgradeBond,
  onSeverBond
}) => {
  const [selectedD1, setSelectedD1] = useState<string>(disciples[0]?.id || '');
  const [selectedD2, setSelectedD2] = useState<string>(disciples[1]?.id || (disciples[0]?.id || ''));
  const [selectedBondType, setSelectedBondType] = useState<RelationType>('Confidant');
  const [attemptOutcome, setAttemptOutcome] = useState<{ message: string; success: boolean } | null>(null);

  const disciple1 = disciples.find(d => d.id === selectedD1);
  const disciple2 = disciples.find(d => d.id === selectedD2);

  // Check if the chosen pair ALREADY has 1 active positive bond (strict 1-bond-per-pair rule)
  const existingBond = disciple1 && disciple2 && disciple1.id !== disciple2.id
    ? disciple1.relations.find(r => r.targetId === disciple2.id && POSITIVE_BOND_TYPES.includes(r.type))
    : undefined;
  const existingBondLevel: BondLevel = (existingBond?.level as BondLevel) || 2;

  const calculateBondAnalysis = (
    d1?: Disciple,
    d2?: Disciple,
    bond?: RelationType
  ): { rate: number; alignNote: string; alignMod: number } => {
    if (!d1 || !d2 || d1.id === d2.id) {
      return { rate: 0, alignNote: 'Select two distinct disciples', alignMod: 0 };
    }

    let baseRate = 72;

    const rankWeights: Record<string, number> = {
      Outer: 1,
      Inner: 2,
      Direct: 3,
      Elder: 4,
      'Grand Elder': 5,
      'Sect Leader': 6
    };

    const rankDiff = (rankWeights[d2.rank] || 1) - (rankWeights[d1.rank] || 1);
    if (rankDiff > 0) baseRate -= rankDiff * 14;

    const realmDiff = d2.currentRealmIndex - d1.currentRealmIndex;
    if (realmDiff > 0) baseRate -= Math.min(24, realmDiff * 3);

    // Alignment compatibility
    const a1 = d1.personalAlignment || sectAlignment;
    const a2 = d2.personalAlignment || sectAlignment;
    let alignMod = 0;
    let alignNote = 'Neutral Dao Resonance';

    if (a1 === a2) {
      alignMod = 12;
      alignNote = `Shared Alignment (${a1}) +12%`;
    } else if (
      (a1 === 'Righteous Orthodox' && a2 === 'Demonic Blood Cult') ||
      (a1 === 'Demonic Blood Cult' && a2 === 'Righteous Orthodox') ||
      (a1 === 'Buddhic Zen' && a2 === 'Demonic Blood Cult') ||
      (a1 === 'Demonic Blood Cult' && a2 === 'Buddhic Zen')
    ) {
      alignMod = -24;
      alignNote = `Clashing Alignments (${a1} vs ${a2}) -24%`;
    } else if (a1 === 'Cloud Mist Neutral' || a2 === 'Cloud Mist Neutral') {
      alignMod = 5;
      alignNote = 'Flexible Mist Affinity +5%';
    }
    baseRate += alignMod;

    // Temperament & Emotion synergy
    if (
      (d1.temperament === 'Arrogant' && d2.temperament === 'Benevolent') ||
      (d1.temperament === 'Ruthless' && d2.temperament === 'Carefree')
    ) {
      baseRate -= 12;
    } else if (d1.temperament === d2.temperament || d1.temperament === 'Loyal' || d2.temperament === 'Benevolent') {
      baseRate += 6;
    }

    if (d1.emotion === 'Inspired' || d2.emotion === 'Inspired') baseRate += 6;
    if (d1.emotion === 'Anxious' || d2.emotion === 'Envious') baseRate -= 8;

    if (bond === 'Lover' || bond === 'Adoptive Parent') {
      baseRate -= 8;
    }

    return {
      rate: Math.max(10, Math.min(96, Math.round(baseRate))),
      alignNote,
      alignMod
    };
  };

  const { rate: currentSuccessRate, alignNote, alignMod } = calculateBondAnalysis(disciple1, disciple2, selectedBondType);

  // Deepening odds scale downward slightly at higher bond tiers (Lv 4 -> Lv 5 Inseparable)
  const upgradeSuccessRate = Math.max(
    18,
    Math.min(95, currentSuccessRate - (existingBondLevel - 1) * 7)
  );

  const handleAttemptBond = () => {
    if (!disciple1 || !disciple2 || disciple1.id === disciple2.id || existingBond) return;

    const roll = Math.random() * 100;
    const isSuccess = roll <= currentSuccessRate;

    if (isSuccess) {
      soundEngine.playFanfare();
      setAttemptOutcome({
        message: `Success! ${disciple1.name} & ${disciple2.name} formed a [${selectedBondType}] bond at Lv 2 (Acquaintance)!`,
        success: true
      });
      onForgeBond(disciple1.id, disciple2.id, selectedBondType, true);
    } else {
      soundEngine.playThunder();
      setAttemptOutcome({
        message: `Bond Rejected! ${disciple2.name} declined ${disciple1.name}'s proposal. Resentment lingered instead.`,
        success: false
      });
      onForgeBond(disciple1.id, disciple2.id, selectedBondType, false);
    }
  };

  const handleDeepenExistingBond = () => {
    if (!disciple1 || !disciple2 || !existingBond || existingBondLevel >= 5) return;
    const roll = Math.random() * 100;
    const nextLv = Math.min(5, existingBondLevel + 1) as BondLevel;
    if (roll <= upgradeSuccessRate) {
      soundEngine.playFanfare();
      onUpgradeBond?.(disciple1.id, disciple2.id);
      setAttemptOutcome({
        message: `Bond Deepened! ${disciple1.name} & ${disciple2.name} reached Lv ${nextLv}/5 (${BOND_LEVEL_LABELS[nextLv]})!`,
        success: true
      });
    } else {
      soundEngine.playClick();
      setAttemptOutcome({
        message: `The shared meditation ended gently without deepening their bond this time (${upgradeSuccessRate}% chance).`,
        success: false
      });
    }
  };

  // Collect all grudges
  const allGrudges: { from: Disciple; to: Disciple; jealousy: number; reason?: string }[] = [];
  disciples.forEach(d => {
    d.relations.forEach(r => {
      if (r.jealousy > 0 || r.type === 'Grudge' || r.type === 'Rival') {
        const target = disciples.find(targetD => targetD.id === r.targetId);
        if (target) {
          allGrudges.push({ from: d, to: target, jealousy: r.jealousy, reason: r.grudgeReason });
        }
      }
    });
  });

  const availableBondTypes: { type: RelationType; label: string; desc: string }[] = [
    { type: 'Lover', label: 'Lover / Dao Companion', desc: 'Accelerates cultivation & shields Inner Demons' },
    { type: 'Confidant', label: 'Soul Confidant', desc: 'Steadies Dao-Heart & calms anxiety' },
    { type: 'Master-Disciple', label: 'Master / Disciple', desc: 'Senior imparts Qi insights & guidance' },
    { type: 'Adoptive Parent', label: 'Adoptive Parent', desc: 'Guardian protection & fierce loyalty' },
    { type: 'Son/Daughter', label: 'Son / Daughter', desc: 'Lineage inheritance & elder backing' },
    { type: 'Sworn Sibling', label: 'Sworn Sibling', desc: 'Blood oath sworn before sect tablets' },
    { type: 'Friend', label: 'Daoist Friend', desc: 'Harmonious sparring & mutual morale' }
  ];

  const canAffordFeast = devMode || spiritStones >= 80;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh] relative">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-[#fce18b]" />
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
                Disciple Social Matrix &amp; Karma Bonds
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                1 max bond per pair · 5 Bond Tiers (Unknown → Inseparable).
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-4 grow text-xs text-[#d1e6dc]">
          {/* Sect Harmony Action */}
          <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b]">
            <div className="flex justify-between items-center gap-3">
              <div>
                <div className="font-bold text-[#fce18b] text-sm flex items-center gap-1.5">
                  <Wine className="w-4 h-4 text-[#e2b054]" />
                  <span>Grand Sect Banquet</span>
                </div>
                <div className="text-[10px] text-[#9fc2b2]">
                  Costs {devMode ? '0 (Dev)' : '80 Spirit Stones'} · Reduces jealousy, stress &amp; warms relations.
                </div>
              </div>
              <button
                disabled={!canAffordFeast}
                onClick={() => {
                  soundEngine.playTalisman();
                  onHoldSectFeast();
                }}
                className={`px-3.5 py-2 rounded-xl font-bold text-xs shadow-md shrink-0 min-h-[38px] ${
                  canAffordFeast
                    ? 'bg-gradient-to-r from-[#b45309] to-[#d97706] text-white hover:brightness-110 active:scale-95'
                    : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                }`}
              >
                {canAffordFeast ? 'Host Feast' : 'Need 80 Stones'}
              </button>
            </div>
          </div>

          {/* Forge / Upgrade Bond Section */}
          <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-3">
            <h4 className="font-bold font-dao text-sm text-[#fce18b] flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#e2b054]" />
              <span>Chosen Dao Bond (Alignment &amp; Realm Weighted)</span>
            </h4>

            {/* Select Both Disciples */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="text-[10px] text-[#8daea0] block mb-1">Initiator (Disciple 1)</label>
                <select
                  value={selectedD1}
                  onChange={(e) => {
                    setSelectedD1(e.target.value);
                    setAttemptOutcome(null);
                  }}
                  className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white text-xs"
                >
                  {disciples.map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.rank})</option>
                  ))}
                </select>
                {disciple1 && (
                  <div className="text-[9px] text-[#9fc2b2] mt-1">
                    Align: <span className="text-amber-300">{disciple1.personalAlignment || sectAlignment}</span>
                  </div>
                )}
              </div>

              <div>
                <label className="text-[10px] text-[#8daea0] block mb-1">Peer Target (Disciple 2)</label>
                <select
                  value={selectedD2}
                  onChange={(e) => {
                    setSelectedD2(e.target.value);
                    setAttemptOutcome(null);
                  }}
                  className="w-full bg-[#123d30] border border-[#e2b054]/40 rounded-xl p-2 text-white text-xs"
                >
                  {disciples.filter(d => d.id !== selectedD1).map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.rank})</option>
                  ))}
                </select>
                {disciple2 && (
                  <div className="text-[9px] text-[#9fc2b2] mt-1">
                    Align: <span className="text-amber-300">{disciple2.personalAlignment || sectAlignment}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Alignment Compatibility Strip */}
            {disciple1 && disciple2 && disciple1.id !== disciple2.id && (
              <div className={`px-2.5 py-1.5 rounded-xl border text-[10px] flex items-center justify-between ${
                alignMod >= 10
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                  : alignMod < 0
                  ? 'bg-red-950/50 border-red-500/40 text-red-200'
                  : 'bg-[#0b261d] border-[#1d5543] text-[#a4c5b7]'
              }`}>
                <span>Alignment Factor:</span>
                <span className="font-bold">{alignNote}</span>
              </div>
            )}

            {/* Existing Bond Card vs New Bond Selector */}
            {existingBond && disciple1 && disciple2 ? (
              <div className="p-3 rounded-2xl bg-[#0d3126] border border-[#e2b054]/60 space-y-2.5">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="text-[10px] text-[#86efac] font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Active Bond (Max 1 Per Pair)</span>
                    </div>
                    <div className="text-sm font-dao font-bold text-[#fce18b] mt-0.5">
                      {existingBond.type} · Lv {existingBondLevel}/5 ({BOND_LEVEL_LABELS[existingBondLevel]})
                    </div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-950/70 text-amber-200 border border-amber-500/40">
                    Affinity {existingBond.affinity}
                  </span>
                </div>

                {/* 5-Level Progression Pips */}
                <div className="grid grid-cols-5 gap-1">
                  {([1, 2, 3, 4, 5] as BondLevel[]).map(lv => (
                    <div
                      key={lv}
                      className={`py-1 px-1 rounded-lg text-center border text-[9px] font-bold ${
                        lv <= existingBondLevel
                          ? 'bg-emerald-900/60 border-emerald-400 text-emerald-200'
                          : 'bg-[#071f17] border-[#1b4b3b] text-[#6d8e80]'
                      }`}
                    >
                      Lv{lv} {BOND_LEVEL_LABELS[lv]}
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  {existingBondLevel < 5 ? (
                    <button
                      onClick={handleDeepenExistingBond}
                      className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs flex items-center justify-center gap-1.5 hover:brightness-110 min-h-[38px]"
                    >
                      <ArrowUpCircle className="w-4 h-4" />
                      <span>Deepen to Lv {existingBondLevel + 1} ({upgradeSuccessRate}%)</span>
                    </button>
                  ) : (
                    <div className="flex-1 py-2 px-3 rounded-xl bg-emerald-950/80 border border-emerald-400/50 text-emerald-200 font-dao font-bold text-xs text-center">
                      Max Level Reached: Inseparable (5/5)
                    </div>
                  )}

                  {onSeverBond && (
                    <button
                      onClick={() => {
                        soundEngine.playClick();
                        onSeverBond(disciple1.id, disciple2.id);
                        setAttemptOutcome({
                          message: `Bond severed between ${disciple1.name} and ${disciple2.name}. They may now choose a new path.`,
                          success: false
                        });
                      }}
                      className="py-2 px-3 rounded-xl bg-red-950/60 hover:bg-red-900/70 border border-red-700/50 text-red-300 font-bold text-[11px] flex items-center gap-1 min-h-[38px]"
                    >
                      <Unlink className="w-3.5 h-3.5" />
                      <span>Sever</span>
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <>
                <div>
                  <label className="text-[10px] text-[#8daea0] block mb-1">Choose Desired Bond Type</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                    {availableBondTypes.map((item) => (
                      <button
                        key={item.type}
                        onClick={() => {
                          setSelectedBondType(item.type);
                          setAttemptOutcome(null);
                        }}
                        className={`p-2 rounded-xl text-left border transition-all ${
                          selectedBondType === item.type
                            ? 'bg-[#15803d] text-white border-[#4ade80] shadow-xs'
                            : 'bg-[#123d30] text-[#a4c5b7] border-[#1b4b3b] hover:bg-[#184838]'
                        }`}
                      >
                        <div className="font-bold text-[10px]">{item.label}</div>
                        <div className="text-[8px] opacity-75 truncate">{item.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {disciple1 && disciple2 && disciple1.id !== disciple2.id && (
                  <div className="p-2.5 rounded-xl bg-[#0b261d] border border-[#e2b054]/40 flex justify-between items-center text-xs">
                    <div>
                      <span className="text-[#a4c5b7]">Bond Formation Odds: </span>
                      <strong className={`font-mono text-sm ${currentSuccessRate >= 60 ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {currentSuccessRate}%
                      </strong>
                    </div>
                    <span className="text-[10px] text-[#9fc2b2] italic">
                      {currentSuccessRate < 50 ? 'Low compatibility / rank gap' : 'Favorable affinity'}
                    </span>
                  </div>
                )}

                <button
                  disabled={!selectedD1 || !selectedD2 || selectedD1 === selectedD2}
                  onClick={handleAttemptBond}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#184838] to-[#123d30] text-[#fce18b] border border-[#e2b054]/60 font-dao font-bold text-xs hover:brightness-110 active:scale-98 transition-all min-h-[40px]"
                >
                  Seal Chosen {selectedBondType} Bond (Starts Lv 2)
                </button>
              </>
            )}

            {/* Attempt Outcome Banner */}
            {attemptOutcome && (
              <div className={`p-2.5 rounded-xl border text-xs font-medium animate-scale-up ${
                attemptOutcome.success
                  ? 'bg-emerald-950/70 border-emerald-400 text-emerald-200'
                  : 'bg-red-950/70 border-red-500 text-red-200'
              }`}>
                {attemptOutcome.message}
              </div>
            )}
          </div>

          {/* Active Grudges & Jealousies */}
          <div className="space-y-2">
            <h4 className="font-bold font-dao text-sm text-[#fce18b] flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-red-400" />
              <span>Active Jealousies &amp; Grudges ({allGrudges.length})</span>
            </h4>

            {allGrudges.length === 0 ? (
              <div className="p-4 text-center text-xs text-[#86efac] bg-[#09261d] rounded-xl border border-[#1b4b3b]">
                The sect is in pure harmony! No disciples currently harbor active grudges or toxic jealousy.
              </div>
            ) : (
              <div className="space-y-2">
                {allGrudges.map((g, idx) => (
                  <div
                    key={idx}
                    className="bg-[#09261d] p-3 rounded-xl border border-red-900/40 space-y-1.5 text-xs"
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <strong className="text-white">{g.from.name}</strong>
                        <span className="text-red-400 mx-1.5">resentment towards</span>
                        <strong className="text-[#fce18b]">{g.to.name}</strong>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-900/60 text-red-200 font-bold font-mono">
                        Jealousy: {g.jealousy}%
                      </span>
                    </div>

                    {g.reason && (
                      <div className="text-[10px] text-red-300 italic">
                        "{g.reason}"
                      </div>
                    )}

                    <div className="flex justify-end pt-1">
                      <button
                        onClick={() => {
                          soundEngine.playGong();
                          onResolveGrudge(g.from.id, g.to.id);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-[#184838] hover:bg-[#1f5a46] text-[#86efac] border border-[#22c55e]/30 text-[10px] font-bold"
                      >
                        Mediate Feud
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Social Bonds &amp; Karma Matrix</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Close Matrix
          </button>
        </div>
      </div>
    </div>
  );
};

