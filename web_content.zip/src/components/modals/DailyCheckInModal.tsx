import React from 'react';
import { DailyCheckInState } from '../../types/cultivation';
import { soundEngine } from '../../services/audioEngine';
import { motion } from 'framer-motion';
import { CalendarCheck2, Sparkles, CheckCircle2, Gift, X } from 'lucide-react';

export interface CheckInDayReward {
  day: number;
  title: string;
  spiritStones: number;
  qi: number;
  pills: number;
  merit: number;
  prestige: number;
  summary: string;
}

export const CHECK_IN_REWARDS: CheckInDayReward[] = [
  { day: 1, title: 'Day 1 · Mountain Gate', spiritStones: 150, qi: 120, pills: 1, merit: 10, prestige: 25, summary: '+150 Stones · +120 Qi · +1 Pill' },
  { day: 2, title: 'Day 2 · Spirit Spring', spiritStones: 220, qi: 150, pills: 3, merit: 15, prestige: 35, summary: '+220 Stones · +3 Pills · +15 Merit' },
  { day: 3, title: 'Day 3 · Azure Array', spiritStones: 280, qi: 320, pills: 3, merit: 30, prestige: 50, summary: '+320 Qi · +280 Stones · +30 Merit' },
  { day: 4, title: 'Day 4 · Cauldron Elixir', spiritStones: 350, qi: 250, pills: 6, merit: 35, prestige: 75, summary: '+350 Stones · +6 Pills · +35 Merit' },
  { day: 5, title: 'Day 5 · Sword Pavilion', spiritStones: 450, qi: 500, pills: 6, merit: 55, prestige: 100, summary: '+500 Qi · +450 Stones · +55 Merit' },
  { day: 6, title: 'Day 6 · Celestial Jade', spiritStones: 650, qi: 600, pills: 9, merit: 80, prestige: 150, summary: '+650 Stones · +9 Pills · +150 Prestige' },
  { day: 7, title: 'Day 7 · Immortal Mandate', spiritStones: 1200, qi: 1000, pills: 15, merit: 150, prestige: 300, summary: '+1.2k Stones · +1k Qi · +15 Pills · +150 Merit' }
];

interface DailyCheckInModalProps {
  todayDateStr: string;
  checkInState: DailyCheckInState;
  devMode: boolean;
  onClose: () => void;
  onClaimDailyCheckIn: (reward: CheckInDayReward) => void;
}

export const DailyCheckInModal: React.FC<DailyCheckInModalProps> = ({
  todayDateStr,
  checkInState,
  devMode,
  onClose,
  onClaimDailyCheckIn
}) => {
  const claimedToday = checkInState.lastClaimDate === todayDateStr;
  const activeDayIndex = claimedToday
    ? ((checkInState.streakCount - 1) % 7 + 7) % 7
    : checkInState.streakCount % 7;

  const currentReward = CHECK_IN_REWARDS[activeDayIndex] || CHECK_IN_REWARDS[0];

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 12 }}
        className="bg-[#10362a] border-2 border-[#e2b054]/80 rounded-3xl w-full max-w-lg shadow-[0_0_50px_rgba(226,176,84,0.3)] overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-[#081f17] via-[#123d30] to-[#081f17] p-4 border-b border-[#e2b054]/40 flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-400/50 flex items-center justify-center">
              <CalendarCheck2 className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
                Immortal Pavilion Daily Check-In
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                Current Streak: <strong className="text-white font-mono">{checkInState.streakCount}</strong> Days · Total Claims: <strong className="text-white font-mono">{checkInState.totalClaims}</strong>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Daily Check-In"
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 7-Day Reward Grid */}
        <div className="p-4 space-y-3.5 overflow-y-auto grow text-xs text-[#d1e6dc]">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {CHECK_IN_REWARDS.map((r, idx) => {
              const isPast = claimedToday ? idx <= activeDayIndex : idx < activeDayIndex;
              const isCurrent = idx === activeDayIndex;
              const isDay7 = idx === 6;

              return (
                <div
                  key={r.day}
                  className={`p-3 rounded-2xl border flex flex-col justify-between transition-all ${
                    isDay7 ? 'col-span-2 sm:col-span-3' : ''
                  } ${
                    isCurrent && !claimedToday
                      ? 'bg-gradient-to-br from-[#184838] to-[#0f3427] border-[#fce18b] shadow-[0_0_20px_rgba(252,225,139,0.22)]'
                      : isPast
                      ? 'bg-[#081d16] border-emerald-600/40 opacity-80'
                      : 'bg-[#09261d] border-[#1b4b3b]'
                  }`}
                >
                  <div className="flex justify-between items-center gap-1">
                    <span className={`font-dao font-bold text-xs ${isDay7 ? 'text-[#fce18b]' : 'text-white'}`}>
                      {r.title}
                    </span>
                    {isPast ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : isCurrent ? (
                      <Sparkles className="w-4 h-4 text-[#fce18b] animate-pulse shrink-0" />
                    ) : (
                      <Gift className="w-3.5 h-3.5 text-[#6d8e80] shrink-0" />
                    )}
                  </div>
                  <div className="text-[10px] text-[#9fc2b2] mt-1.5 font-medium leading-snug">
                    {r.summary}
                  </div>
                </div>
              );
            })}
          </div>

          <button
            disabled={claimedToday && !devMode}
            onClick={() => {
              soundEngine.playCheckInReward();
              onClaimDailyCheckIn(currentReward);
            }}
            className={`w-full py-3 rounded-xl font-dao font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-all min-h-[44px] ${
              !claimedToday || devMode
                ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-98'
                : 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/40 cursor-default'
            }`}
          >
            {claimedToday && !devMode ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Today’s Tribute Claimed (Return Tomorrow)</span>
              </>
            ) : (
              <>
                <Gift className="w-4 h-4" />
                <span>{claimedToday && devMode ? `Dev Claim Next Tribute (${currentReward.title})` : `Claim ${currentReward.title} Tribute`}</span>
              </>
            )}
          </button>
        </div>

        {/* Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Daily Pavilion Stipend</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[40px]"
          >
            Close Ledger
          </button>
        </div>
      </motion.div>
    </div>
  );
};
