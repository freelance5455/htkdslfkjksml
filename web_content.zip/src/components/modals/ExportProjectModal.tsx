import React, { useState } from 'react';
import { 
  Download, 
  FolderArchive, 
  Rocket, 
  FileCode, 
  Terminal, 
  Check, 
  Copy, 
  ExternalLink, 
  Server, 
  Globe, 
  X, 
  Layers, 
  HardDriveDownload,
  Laptop
} from 'lucide-react';
import { Language } from '../../types';

interface ExportProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const ExportProjectModal: React.FC<ExportProjectModalProps> = ({
  isOpen,
  onClose,
  language
}) => {
  const [activeTab, setActiveTab] = useState<'downloads' | 'cpanel' | 'vercel' | 'netlify' | 'local'>('downloads');
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  if (!isOpen) return null;

  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const sourceZipUrl = `${origin}/shanju-source-code.zip`;
  const distZipUrl = `${origin}/shanju-production-dist.zip`;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLink(key);
    setTimeout(() => setCopiedLink(null), 2500);
  };

  const handleDirectDownload = (url: string, filename: string) => {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shadow-lg shadow-emerald-500/10">
              <FolderArchive className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">
                  {language === 'bn' ? 'প্রজেক্ট সোর্স কোড ও হোস্টিং এক্সপোর্ট' : 'Export Full Source Code & Hosting Pack'}
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full">
                  ZIP Ready
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {language === 'bn'
                  ? 'সম্পূর্ণ কোড ZIP ফাইল হিসেবে ডাউনলোড করুন এবং যেকোনো ওয়েব হোস্টিংয়ে ডিপ্লয় করুন'
                  : 'Download complete code ZIP and deploy instantly to cPanel, VPS, Vercel, or Netlify'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-slate-800 bg-slate-950/40 overflow-x-auto">
          <button
            onClick={() => setActiveTab('downloads')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'downloads'
                ? 'border-emerald-400 text-emerald-300 bg-slate-850/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <HardDriveDownload className="w-4 h-4" />
            {language === 'bn' ? '১-ক্লিক ডাউনলোড' : 'Download ZIPs'}
          </button>
          <button
            onClick={() => setActiveTab('cpanel')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'cpanel'
                ? 'border-emerald-400 text-emerald-300 bg-slate-850/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Server className="w-4 h-4" />
            {language === 'bn' ? 'cPanel / হোস্টিং গাইড' : 'cPanel / Hosting Guide'}
          </button>
          <button
            onClick={() => setActiveTab('vercel')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'vercel'
                ? 'border-emerald-400 text-emerald-300 bg-slate-850/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Rocket className="w-4 h-4" />
            Vercel
          </button>
          <button
            onClick={() => setActiveTab('netlify')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'netlify'
                ? 'border-emerald-400 text-emerald-300 bg-slate-850/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-4 h-4" />
            Netlify (Drag & Drop)
          </button>
          <button
            onClick={() => setActiveTab('local')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'local'
                ? 'border-emerald-400 text-emerald-300 bg-slate-850/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Laptop className="w-4 h-4" />
            {language === 'bn' ? 'লোকাল পিসিতে রান' : 'Run Locally'}
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-300 text-sm">
          {activeTab === 'downloads' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Source Code ZIP Card */}
                <div className="p-5 rounded-2xl bg-gradient-to-b from-slate-800/90 to-slate-850 border border-slate-700 hover:border-emerald-500/50 transition-all flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
                        <FileCode className="w-5 h-5" />
                      </div>
                      <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-blue-500/10 text-blue-300 border border-blue-500/20">
                        ~150 KB
                      </span>
                    </div>

                    <h4 className="text-base font-bold text-white mb-1">
                      {language === 'bn' ? 'ফুল সোর্স কোড (Source Code ZIP)' : 'Full Source Code ZIP'}
                    </h4>
                    <p className="text-xs text-slate-400 leading-relaxed mb-4">
                      {language === 'bn' 
                        ? 'React 19 + TypeScript + Vite + Tailwind CSS এর সম্পূর্ণ এডিটেবল সোর্স ফাইল, কম্পোনেন্টস ও কনফিগারেশন।'
                        : 'Complete editable source files, React components, Tailwind setup, types, and configurations.'}
                    </p>

                    <div className="space-y-1.5 text-[11px] text-slate-300 mb-5 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{language === 'bn' ? 'VS Code-এ সরাসরি ওপেনযোগ্য' : 'Open directly in VS Code'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{language === 'bn' ? 'Git / GitHub রিপোজিটরিতে পুশ করার উপযোগী' : 'Ready for Git / GitHub push'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{language === 'bn' ? 'npm install & npm run dev দিয়ে চলে' : 'Runs with npm install & npm run dev'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <button
                      onClick={() => handleDirectDownload(sourceZipUrl, 'shanju-source-code.zip')}
                      className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition-all transform active:scale-98"
                    >
                      <Download className="w-4 h-4" />
                      <span>{language === 'bn' ? 'সোর্স কোড ZIP ডাউনলোড করুন' : 'Download Source Code (.ZIP)'}</span>
                    </button>

                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        readOnly
                        value={sourceZipUrl}
                        className="flex-1 bg-slate-900/90 text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 text-[11px] font-mono select-all"
                      />
                      <button
                        onClick={() => copyToClipboard(sourceZipUrl, 'source')}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors border border-slate-700"
                        title="Copy direct download link"
                      >
                        {copiedLink === 'source' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedLink === 'source' ? 'কপি হয়েছে' : 'কপি লিঙ্ক'}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Production Dist ZIP Card */}
                <div className="p-5 rounded-2xl bg-gradient-to-b from-slate-800/90 to-slate-850 border border-slate-700 hover:border-emerald-500/50 transition-all flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
                        <Rocket className="w-5 h-5" />
                      </div>
                      <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                        ~235 KB (Compiled)
                      </span>
                    </div>

                    <h4 className="text-base font-bold text-white mb-1">
                      {language === 'bn' ? 'প্রোডাকশন বিল্ড (Ready-to-Deploy ZIP)' : 'Production Build ZIP (dist)'}
                    </h4>
                    <p className="text-xs text-slate-400 leading-relaxed mb-4">
                      {language === 'bn'
                        ? 'সরাসরি ওয়েব সার্ভার, cPanel public_html, বা Netlify-তে আপলোড করার জন্য প্রস্তুত কম্পাইল্ড ফাইল।'
                        : 'Pre-compiled minified HTML, CSS, JS and assets ready for cPanel public_html or Netlify.'}
                    </p>

                    <div className="space-y-1.5 text-[11px] text-slate-300 mb-5 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{language === 'bn' ? 'কোনো নোডজেএস বা কমান্ড রান করা লাগবে না' : 'No Node.js or build commands needed'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{language === 'bn' ? '.htaccess ফাইল অন্তর্ভুক্ত (SPA Routing)' : '.htaccess included for SPA Routing'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{language === 'bn' ? 'cPanel-এ এক্সট্রাক্ট করলেই সঙ্গে সঙ্গে লাইভ' : 'Extract in cPanel and live instantly'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <button
                      onClick={() => handleDirectDownload(distZipUrl, 'shanju-production-dist.zip')}
                      className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-sm shadow-lg shadow-teal-600/30 transition-all transform active:scale-98"
                    >
                      <Download className="w-4 h-4" />
                      <span>{language === 'bn' ? 'ডিপ্লয় বিল্ড ZIP ডাউনলোড করুন' : 'Download Deploy Build (.ZIP)'}</span>
                    </button>

                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        readOnly
                        value={distZipUrl}
                        className="flex-1 bg-slate-900/90 text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 text-[11px] font-mono select-all"
                      />
                      <button
                        onClick={() => copyToClipboard(distZipUrl, 'dist')}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors border border-slate-700"
                        title="Copy direct download link"
                      >
                        {copiedLink === 'dist' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedLink === 'dist' ? 'কপি হয়েছে' : 'কপি লিঙ্ক'}</span>
                      </button>
                    </div>
                  </div>
                </div>

              </div>

              {/* Quick Info Box */}
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Layers className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="font-semibold text-white text-xs">
                    {language === 'bn' ? 'কোন ফাইলটি ডাউনলোড করবেন?' : 'Which ZIP should you download?'}
                  </h5>
                  <p className="text-xs text-slate-400 mt-1">
                    {language === 'bn' 
                      ? '👉 যদি আপনি নিজের কাস্টম ডোমেনে কোনো কোডিং ছাড়াই সরাসরি ওয়েবসাইট লাইভ করতে চান, তবে "প্রোডাকশন বিল্ড ZIP" ডাউনলোড করুন এবং আপনার হোস্টিংয়ের public_html-এ আপলোড করুন। আর যদি কোড পরিবর্তন বা ভবিষ্যৎ ডেভলপমেন্ট করতে চান, তবে "ফুল সোর্স কোড ZIP" বেছে নিন।'
                      : '👉 If you want to deploy straight to your domain hosting without running any commands, download the "Production Build ZIP". If you want to customize the source code or work locally in VS Code, choose the "Full Source Code ZIP".'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'cpanel' && (
            <div className="space-y-4">
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <Server className="w-5 h-5 text-emerald-400" />
                {language === 'bn' ? 'cPanel / Shared Hosting / Hostinger এ ডিপ্লয় করার ধাপ' : 'Deploying to cPanel / Shared Hosting / Hostinger'}
              </h4>

              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/80">
                  <div className="flex items-center gap-2 font-bold text-emerald-400 text-xs mb-1">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center">১</span>
                    <span>{language === 'bn' ? 'প্রোডাকশন বিল্ড ZIP টি ডাউনলোড করুন' : 'Download the Production Build ZIP'}</span>
                  </div>
                  <p className="text-xs text-slate-300 ml-7">
                    {language === 'bn'
                      ? 'উপরের "ডাউনলোড" ট্যাব থেকে "ডিপ্লয় বিল্ড ZIP" (shanju-production-dist.zip) ফাইলটি আপনার পিসিতে সেভ করুন।'
                      : 'Save the shanju-production-dist.zip file to your computer from the Downloads tab.'}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/80">
                  <div className="flex items-center gap-2 font-bold text-emerald-400 text-xs mb-1">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center">২</span>
                    <span>{language === 'bn' ? 'cPanel-এ লগইন করে File Manager-এ যান' : 'Log into cPanel and open File Manager'}</span>
                  </div>
                  <p className="text-xs text-slate-300 ml-7">
                    {language === 'bn'
                      ? 'আপনার হোস্টিং ড্যাশবোর্ডে গিয়ে File Manager ওপেন করুন এবং public_html ফোল্ডারে প্রবেশ করুন।'
                      : 'Open File Manager in your hosting panel and navigate to the public_html folder (or subdomain directory).'}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/80">
                  <div className="flex items-center gap-2 font-bold text-emerald-400 text-xs mb-1">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center">৩</span>
                    <span>{language === 'bn' ? 'ZIP ফাইল আপলোড এবং Extract করুন' : 'Upload and Extract the ZIP File'}</span>
                  </div>
                  <p className="text-xs text-slate-300 ml-7">
                    {language === 'bn'
                      ? 'Upload বাটনে ক্লিক করে shanju-production-dist.zip আপলোড করুন। আপলোড শেষে ফাইলের উপর রাইট-ক্লিক করে "Extract" চাপুন।'
                      : 'Upload shanju-production-dist.zip. Right-click and choose "Extract" directly inside public_html.'}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/80">
                  <div className="flex items-center gap-2 font-bold text-emerald-400 text-xs mb-1">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center">৪</span>
                    <span>{language === 'bn' ? 'ব্রাউজারে আপনার ডোমেন চেক করুন' : 'Check Your Domain in Browser'}</span>
                  </div>
                  <p className="text-xs text-slate-300 ml-7">
                    {language === 'bn'
                      ? 'অভিনন্দন! আপনার ডোমেন (যেমন: www.yourdomain.com) ব্রাউজারে লিখলেই সাথে সাথে আপনার ওয়েবসাইটটি প্রদর্শিত হবে। কোনো পেজ রিলোডে যাতে সমস্যা না হয় সেজন্য .htaccess ফাইল প্যাকেজে ইতিমধ্যে দেওয়া রয়েছে।'
                      : 'Done! Visit your custom domain in the browser. The included .htaccess automatically handles client-side routing.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'vercel' && (
            <div className="space-y-4">
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <Rocket className="w-5 h-5 text-emerald-400" />
                {language === 'bn' ? 'Vercel-এ ১-ক্লিকে ফ্রি ডিপ্লয় (Custom Domain সহ)' : 'Free 1-Click Deployment to Vercel'}
              </h4>

              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/80">
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {language === 'bn'
                      ? '1. ফুল সোর্স কোড ZIP এক্সট্রাক্ট করে আপনার GitHub অ্যাকাউন্টে একটি নতুন রিপোজিটোরি হিসেবে Push করুন।'
                      : '1. Extract Full Source Code ZIP and push it to a new GitHub repository.'}
                  </p>
                  <p className="text-xs text-slate-300 leading-relaxed mt-2">
                    {language === 'bn'
                      ? '2. Vercel.com-এ গিয়ে "Add New Project" ক্লিক করে আপনার GitHub রিপোজিটোরি সিলেক্ট করুন।'
                      : '2. Go to Vercel.com, click "Add New Project", and select your GitHub repository.'}
                  </p>
                  <p className="text-xs text-slate-300 leading-relaxed mt-2">
                    {language === 'bn'
                      ? '3. Framework হিসেবে "Vite" সিলেক্ট থাকবে। সরাসরি "Deploy" বাটনে চাপুন।'
                      : '3. Framework preset Vite will be auto-detected. Click "Deploy".'}
                  </p>
                  <p className="text-xs text-slate-300 leading-relaxed mt-2">
                    {language === 'bn'
                      ? '4. ডিপ্লয় শেষ হলে Vercel Settings -> Domains-এ গিয়ে আপনার নিজস্ব ডোমেন যুক্ত করে দিন। ফ্রি SSL সার্টিফিকেট স্বয়ংক্রিয়ভাবে সক্রিয় হবে।'
                      : '4. In Vercel Project Settings -> Domains, attach your custom domain with free automatic SSL!'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'netlify' && (
            <div className="space-y-4">
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <Globe className="w-5 h-5 text-emerald-400" />
                {language === 'bn' ? 'Netlify-তে ড্র্যাগ অ্যান্ড ড্রপ ডিপ্লয়' : 'Netlify Drag & Drop Deployment'}
              </h4>

              <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-3">
                <p className="text-xs text-slate-300 leading-relaxed">
                  {language === 'bn'
                    ? '1. আমাদের দেওয়া "প্রোডাকশন বিল্ড ZIP" টি ডাউনলোড করে আপনার পিসিতে আনজিপ করুন।'
                    : '1. Download the "Production Build ZIP" and extract it on your PC.'}
                </p>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {language === 'bn'
                    ? '2. Netlify.com-এ লগইন করে Sites ট্যাবে যান।'
                    : '2. Log into Netlify.com and go to the Sites tab.'}
                </p>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {language === 'bn'
                    ? '3. আনজিপ করা ফোল্ডারটি মাউস দিয়ে টেনে "Drag and drop your site folder here" বক্সে ছেড়ে দিন।'
                    : '3. Drag and drop the extracted folder into Netlify.'}
                </p>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {language === 'bn'
                    ? '4. মাত্র ৫ সেকেন্ডের মধ্যে আপনার সাইট লাইভ হয়ে যাবে এবং আপনি ফ্রি ডোমেন বা কাস্টম ডোমেন সেট করতে পারবেন।'
                    : '4. Your site is live in 5 seconds with custom domain support!'}
                </p>
              </div>
            </div>
          )}

          {activeTab === 'local' && (
            <div className="space-y-4">
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <Terminal className="w-5 h-5 text-emerald-400" />
                {language === 'bn' ? 'লোকাল পিসিতে চালু করার নিয়ম (VS Code)' : 'Running on Local Machine (VS Code)'}
              </h4>

              <div className="p-4 rounded-xl bg-slate-950 font-mono text-xs text-slate-300 border border-slate-800 space-y-2">
                <div className="text-slate-500"># 1. আনজিপ করা সোর্স কোড ফোল্ডারে টার্মিনাল ওপেন করুন</div>
                <div className="text-emerald-400">cd shanju-ecommerce</div>
                <div className="text-slate-500 mt-2"># 2. প্রয়োজনীয় ডিপেন্ডেন্সি ইন্সটল করুন</div>
                <div className="text-emerald-400">npm install</div>
                <div className="text-slate-500 mt-2"># 3. ডেভেলপমেন্ট সার্ভার চালু করুন</div>
                <div className="text-emerald-400">npm run dev</div>
                <div className="text-slate-500 mt-2"># 4. প্রোডাকশন বিল্ড তৈরি করতে</div>
                <div className="text-emerald-400">npm run build</div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            {language === 'bn' ? 'প্যাকেজে সম্পূর্ণ লাইসেন্স ও ডকুমেন্টেশন অন্তর্ভুক্ত' : 'Full source code ownership included'}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
            >
              {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
            </button>
            <button
              onClick={() => handleDirectDownload(sourceZipUrl, 'shanju-source-code.zip')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'ZIP ডাউনলোড' : 'Download ZIP'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
