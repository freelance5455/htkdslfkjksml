import React, { useState } from 'react';
import {
  X,
  Briefcase,
  CheckCircle,
  XCircle,
  Wallet,
  Coins,
  Gem,
  DollarSign,
  ArrowRightLeft,
  Search,
  Check,
  Send,
  Sparkles,
  Clock,
  User,
  ShieldCheck,
  TrendingUp,
  BarChart3,
  Percent,
  Receipt,
} from 'lucide-react';
import { UserProfile, CashierRequest, TransactionRecord } from '../../types';
import { soundFX } from '../../utils/soundEffects';
import { saveAuditRecordToFirestore, saveUserProfileToFirestore } from '../../utils/firebaseSync';

interface CashierDeskModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpdateUser: (u: UserProfile) => void;
  cashierRequests: CashierRequest[];
  onApproveRequest: (id: string) => void;
  onRejectRequest: (id: string) => void;
  showNotification?: (msg: string) => void;
}

export const CashierDeskModal: React.FC<CashierDeskModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateUser,
  cashierRequests,
  onApproveRequest,
  onRejectRequest,
  showNotification,
}) => {
  const [activeTab, setActiveTab] = useState<'requests' | 'transfer' | 'earnings'>('requests');
  const [searchQuery, setSearchQuery] = useState('');

  // Commission balance ready to claim
  const [availableCommission, setAvailableCommission] = useState(485.5);

  // Quick Transfer to Player Form
  const [targetPlayerId, setTargetPlayerId] = useState('');
  const [transferAmount, setTransferAmount] = useState(1000);
  const [transferCurrency, setTransferCurrency] = useState<'COINS' | 'GEMS' | 'REAL_USD'>('COINS');
  const [transferNotes, setTransferNotes] = useState('شحن مباشر عبر مكتب الكاشير');

  if (!isOpen) return null;

  const handleWithdrawCommission = () => {
    if (availableCommission <= 0) return;
    soundFX.playVictoryFanfare();

    const updatedUser: UserProfile = {
      ...currentUser,
      realCashBalance: currentUser.realCashBalance + Math.round(availableCommission),
    };
    onUpdateUser(updatedUser);
    saveUserProfileToFirestore(updatedUser);

    if (showNotification) {
      showNotification(`🎉 تم ترحيل أرباح العمولات بقيمة $${availableCommission.toFixed(2)} إلى رصيدك النقدي بنجاح!`);
    }
    setAvailableCommission(0);
  };

  const filteredRequests = cashierRequests.filter(
    (r) =>
      r.playerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.playerId.includes(searchQuery)
  );

  const pendingRequests = filteredRequests.filter((r) => r.status === 'PENDING');
  const completedRequests = filteredRequests.filter((r) => r.status !== 'PENDING');

  const handleExecuteTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetPlayerId || transferAmount <= 0) return;

    soundFX.playVictoryFanfare();

    const txId = `TX-CSH-${Date.now().toString().slice(-6)}`;
    const auditRecord: TransactionRecord = {
      transactionId: txId,
      playerId: targetPlayerId,
      playerName: `اللاعب (ID: ${targetPlayerId})`,
      cashierOrAdminId: `CASHIER_${currentUser.name}`,
      amount: transferAmount,
      currencyType: transferCurrency,
      balanceBefore: 0,
      balanceAfter: transferAmount,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      status: 'COMPLETED',
      sourceMethod: 'CASHIER_TRANSFER',
      referenceNote: transferNotes,
      auditHash: `sha256:csh_${txId}_hash`,
      ledgerSequence: Math.floor(1000 + Math.random() * 9000),
    };

    saveAuditRecordToFirestore(auditRecord);

    if (showNotification) {
      showNotification(`✅ تم شحن ${transferAmount.toLocaleString()} ${transferCurrency} للاعب ${targetPlayerId} بنجاح!`);
    }

    setTargetPlayerId('');
    setTransferAmount(1000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in select-none">
      <div className="relative w-full max-w-4xl h-[750px] max-h-[90vh] bg-gradient-to-b from-[#082215] via-[#05160d] to-[#020a06] border-2 border-amber-400/80 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-[#05190e] border-b border-amber-500/30 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-black shadow-md font-black">
              <Briefcase className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-black text-amber-200 flex items-center gap-2">
                مكتب الكاشير المعتمد (Cashier Desk)
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                  كاشير معتمد 💼
                </span>
              </h3>
              <p className="text-xs text-gray-400">
                إدارة طلبات شحن وسحب اللاعبين، إرسال التحويلات الفورية، ومتابعة العمولات
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Cashier Balance Pill */}
            <div className="px-3.5 py-1.5 rounded-xl bg-black/60 border border-amber-500/30 flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1 text-emerald-300 font-mono font-bold">
                <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                <span>${currentUser.realCashBalance.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-1 text-amber-300 font-mono font-bold">
                <Coins className="w-3.5 h-3.5 text-amber-400" />
                <span>{currentUser.coins.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() => {
                soundFX.playButtonClick();
                onClose();
              }}
              className="p-1.5 rounded-full text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex bg-[#040e08] border-b border-amber-950 px-6 pt-2 gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('requests')}
            className={`px-4 py-2 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 ${
              activeTab === 'requests'
                ? 'bg-[#082215] text-amber-300 border-t-2 border-amber-400 shadow-md'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Wallet className="w-4 h-4 text-amber-400" />
            <span>طلبات السحب والإيداع ({pendingRequests.length})</span>
            {pendingRequests.length > 0 && (
              <span className="w-5 h-5 rounded-full bg-red-500 text-white text-[10px] font-black flex items-center justify-center animate-pulse">
                {pendingRequests.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('transfer')}
            className={`px-4 py-2 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 ${
              activeTab === 'transfer'
                ? 'bg-[#082215] text-amber-300 border-t-2 border-amber-400 shadow-md'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <ArrowRightLeft className="w-4 h-4 text-emerald-400" />
            <span>شحن وتحويل مباشر للاعب</span>
          </button>

          <button
            onClick={() => setActiveTab('earnings')}
            className={`px-4 py-2 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 ${
              activeTab === 'earnings'
                ? 'bg-[#082215] text-amber-300 border-t-2 border-amber-400 shadow-md'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-amber-300" />
            <span>لوحة الأرباح والعمولات (Earnings) 📈</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 p-6 overflow-y-auto">
          {activeTab === 'requests' ? (
            <div className="space-y-4">
              {/* Search */}
              <div className="flex items-center justify-between gap-3">
                <div className="relative flex-1 max-w-xs">
                  <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث بالاسم أو رقم الطلب أو الـ ID..."
                    className="w-full pr-9 pl-3 py-2 bg-black/50 border border-amber-950 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="text-xs text-gray-400">
                  عمولة الكاشير المعتمدة:{' '}
                  <span className="text-amber-300 font-bold font-mono">3.5%</span> عن كل عملية
                </div>
              </div>

              {/* Pending Requests List */}
              <div className="space-y-3">
                <h4 className="text-xs font-black text-amber-200">الطلبات المعلقة بانتظار الاعتماد:</h4>
                {pendingRequests.length === 0 ? (
                  <div className="p-8 text-center text-gray-500 text-xs rounded-2xl bg-black/40 border border-amber-950">
                    لا توجد طلبات معلقة حالياً
                  </div>
                ) : (
                  pendingRequests.map((req) => (
                    <div
                      key={req.id}
                      className="p-4 rounded-2xl bg-black/50 border border-amber-500/30 flex flex-wrap items-center justify-between gap-4 shadow-md"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center font-black ${
                            req.type === 'DEPOSIT'
                              ? 'bg-emerald-950 border border-emerald-500 text-emerald-300'
                              : 'bg-red-950 border border-red-500 text-red-300'
                          }`}
                        >
                          {req.type === 'DEPOSIT' ? 'إيداع' : 'سحب'}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-black text-white">{req.playerName}</span>
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
                              ID: {req.playerId}
                            </span>
                            <span className="text-[10px] text-gray-400">{req.id}</span>
                          </div>
                          <div className="text-xs text-gray-300 mt-0.5">
                            طريقة الدفع: <span className="text-amber-300 font-bold">{req.method}</span> • {req.walletAddressOrAccount}
                          </div>
                          {req.notes && (
                            <div className="text-[11px] text-gray-400 mt-0.5 italic">{req.notes}</div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-base font-black text-amber-300 font-mono">
                            ${req.amount.toLocaleString()} USD
                          </div>
                          <div className="text-[10px] text-emerald-400 font-bold">
                            عمولة الكاشير: +${(req.amount * 0.035).toFixed(2)}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              onRejectRequest(req.id);
                              if (showNotification) showNotification(`تم رفض الطلب ${req.id}`);
                            }}
                            className="px-3 py-1.5 rounded-xl bg-red-950/60 hover:bg-red-900 border border-red-500/50 text-red-300 text-xs font-bold transition-all"
                          >
                            رفض
                          </button>
                          <button
                            onClick={() => {
                              onApproveRequest(req.id);
                              if (showNotification) showNotification(`✅ تم اعتماد الطلب ${req.id} وإيداع العمولة!`);
                            }}
                            className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white text-xs font-black shadow-md transition-all flex items-center gap-1"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>اعتماد الطلب</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Completed Requests Archive */}
              {completedRequests.length > 0 && (
                <div className="pt-4 space-y-2">
                  <h4 className="text-xs font-bold text-gray-400">العمليات السابقة المنفذة:</h4>
                  {completedRequests.slice(0, 5).map((req) => (
                    <div
                      key={req.id}
                      className="p-3 rounded-xl bg-black/30 border border-amber-950 flex items-center justify-between text-xs text-gray-400"
                    >
                      <div className="flex items-center gap-2">
                        <span className={req.status === 'APPROVED' ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                          {req.status === 'APPROVED' ? 'معتمد ✅' : 'مرفوض ❌'}
                        </span>
                        <span>{req.playerName} ({req.id})</span>
                      </div>
                      <div className="font-mono text-gray-300 font-bold">
                        ${req.amount.toLocaleString()} USD
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            /* Direct Transfer to Player */
            <div className="max-w-xl mx-auto p-4 rounded-3xl bg-black/50 border border-amber-500/30">
              <h4 className="text-sm font-black text-amber-200 mb-1 flex items-center gap-2">
                <Send className="w-4 h-4 text-emerald-400" />
                شحن رصيد فوري للاعب من مكتب الكاشير
              </h4>
              <p className="text-xs text-gray-400 mb-4">
                أدخل معرف اللاعب (Player ID) والمبلغ المراد شحنه ليتم إيداعه فوراً وتوثيقه في السجل المالي
              </p>

              <form onSubmit={handleExecuteTransfer} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-gray-300 block mb-1">
                    معرف اللاعب المستفيد (Player ID):
                  </label>
                  <input
                    type="text"
                    required
                    value={targetPlayerId}
                    onChange={(e) => setTargetPlayerId(e.target.value)}
                    placeholder="مثال: 78453 أو 62194"
                    className="w-full p-2.5 bg-black/60 border border-amber-950 focus:border-amber-400 rounded-xl text-xs text-white focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-300 block mb-1">نوع الرصيد:</label>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    {[
                      { id: 'COINS', label: 'كوينز ذهبية 🪙' },
                      { id: 'GEMS', label: 'جواهر زمردية 💎' },
                      { id: 'REAL_USD', label: 'دولار نقدي 💵' },
                    ].map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => setTransferCurrency(c.id as any)}
                        className={`p-2.5 rounded-xl border font-bold transition-all ${
                          transferCurrency === c.id
                            ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                            : 'bg-black/40 border-amber-950 text-gray-400'
                        }`}
                      >
                        {c.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-300 block mb-1">المبلغ:</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(Math.max(1, parseInt(e.target.value) || 0))}
                    className="w-full p-2.5 bg-black/60 border border-amber-950 focus:border-amber-400 rounded-xl text-sm font-bold text-amber-200 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-300 block mb-1">ملاحظة السند:</label>
                  <input
                    type="text"
                    value={transferNotes}
                    onChange={(e) => setTransferNotes(e.target.value)}
                    className="w-full p-2.5 bg-black/60 border border-amber-950 focus:border-amber-400 rounded-xl text-xs text-gray-300 focus:outline-none"
                  />
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-black text-xs shadow-lg hover:from-amber-400 hover:to-amber-300 flex items-center gap-2 transition-all"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>تنفيذ الشحن وإصدار السند فوراً</span>
                  </button>
                </div>
              </form>
            </div>
          ) : (
            /* ========================================================
                TAB 3: EARNINGS & COMMISSION DASHBOARD (لوحة أرباح وعمولات الكاشير)
               ======================================================== */
            <div className="space-y-6">
              {/* Top Banner with Claim Commission Action */}
              <div className="p-5 rounded-3xl bg-gradient-to-r from-emerald-950/90 via-[#0a3821] to-[#041a0e] border-2 border-emerald-400/80 shadow-xl flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-black text-emerald-300">
                    <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />
                    <span>رصيد العمولات المحصلة الجاهز للسحب الفوري:</span>
                  </div>
                  <div className="text-3xl font-black text-amber-300 font-mono mt-1">
                    ${availableCommission.toFixed(2)} USD
                  </div>
                  <p className="text-[11px] text-gray-300 mt-1">
                    نسبة عمولتك المعتمدة: <strong className="text-emerald-400">3.5%</strong> عن كل حركة شحن أو سحب للاعبين
                  </p>
                </div>

                <button
                  type="button"
                  disabled={availableCommission <= 0}
                  onClick={handleWithdrawCommission}
                  className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <DollarSign className="w-4 h-4" />
                  <span>ترحيل أرباح العمولات إلى رصيد الكاشير النقدي</span>
                </button>
              </div>

              {/* Commission Stats Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-4 rounded-2xl bg-black/50 border border-emerald-500/30">
                  <div className="text-[11px] font-bold text-gray-400 mb-1">عمولات اليوم (Today)</div>
                  <div className="text-xl font-black text-emerald-300 font-mono">+$142.50</div>
                  <div className="text-[10px] text-gray-400 mt-0.5">12 عملية شحن وسحب</div>
                </div>

                <div className="p-4 rounded-2xl bg-black/50 border border-emerald-500/30">
                  <div className="text-[11px] font-bold text-gray-400 mb-1">عمولات هذا الأسبوع</div>
                  <div className="text-xl font-black text-emerald-300 font-mono">+$890.00</div>
                  <div className="text-[10px] text-gray-400 mt-0.5">64 عملية ناجحة</div>
                </div>

                <div className="p-4 rounded-2xl bg-black/50 border border-emerald-500/30">
                  <div className="text-[11px] font-bold text-gray-400 mb-1">عمولات هذا الشهر</div>
                  <div className="text-xl font-black text-amber-300 font-mono">+$3,420.00</div>
                  <div className="text-[10px] text-gray-400 mt-0.5">نمو +18% عن الشهر الماضي</div>
                </div>

                <div className="p-4 rounded-2xl bg-black/50 border border-amber-500/30">
                  <div className="text-[11px] font-bold text-gray-400 mb-1">حجم التداول الكلي</div>
                  <div className="text-xl font-black text-white font-mono">$97,714.00</div>
                  <div className="text-[10px] text-emerald-400 mt-0.5">إجمالي السيولة المدارة</div>
                </div>
              </div>

              {/* Recent Commissions Ledger Table */}
              <div className="space-y-2">
                <h4 className="text-xs font-black text-amber-200 flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-emerald-400" />
                  سجل العمولات المحصلة مؤخراً من عمليات اللاعبين:
                </h4>

                <div className="space-y-2">
                  {[
                    { id: 'COMM-891', date: 'اليوم 10:24', player: 'سامي (Sami)', type: 'إيداع نقدي كاشير', amount: 500, earned: 17.5 },
                    { id: 'COMM-890', date: 'اليوم 09:15', player: 'Player 1', type: 'شحن كوينز طرنيب', amount: 250, earned: 8.75 },
                    { id: 'COMM-889', date: 'اليوم 08:40', player: 'Queen', type: 'سحب أرباح USDT', amount: 600, earned: 21.0 },
                    { id: 'COMM-888', date: 'أمس 22:10', player: 'أحمد (Ahmed)', type: 'إيداع محفظة TRC20', amount: 1200, earned: 42.0 },
                    { id: 'COMM-887', date: 'أمس 18:30', player: 'King', type: 'شحن رصيد طاولة', amount: 450, earned: 15.75 },
                    { id: 'COMM-886', date: 'أمس 14:15', player: 'ليلى (Laila)', type: 'سحب نقدي بايننس', amount: 800, earned: 28.0 },
                  ].map((comm) => (
                    <div
                      key={comm.id}
                      className="p-3 rounded-2xl bg-black/40 border border-amber-950 hover:border-emerald-500/40 flex items-center justify-between text-xs transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                        <div>
                          <div className="font-bold text-white flex items-center gap-1.5">
                            <span>{comm.player}</span>
                            <span className="text-[10px] text-gray-400">({comm.type})</span>
                          </div>
                          <div className="text-[10px] text-gray-500">{comm.date} • {comm.id}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <span className="text-gray-400 text-[11px]">قيمة العملية: </span>
                          <span className="font-mono text-white font-bold">${comm.amount}</span>
                        </div>
                        <div className="px-3 py-1 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-mono font-black text-xs">
                          +${comm.earned.toFixed(2)} عمولة
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
