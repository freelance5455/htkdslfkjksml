import React, { useRef, useState } from 'react';
import { soundEngine, BGM_THEME_LABELS } from '../../services/audioEngine';
import {
  BgmTheme,
  ChampionTitle,
  ConstitutionType,
  Disciple,
  DiscipleExpression,
  DiscipleRank,
  GraphicsQuality,
  MythicalFormType,
  Season,
  SectResources,
  SectStability,
  SpiritRootType,
  TalentTier
} from '../../types/cultivation';
import { CULTIVATION_REALMS } from '../../data/realms';
import { CONSTITUTION_EFFECTS } from '../../data/loreData';
import { CUSTOM_HAIR_COLORS, DISCIPLE_EXPRESSIONS } from '../cultivation/CultivatorAvatar';
import {
  Settings,
  Volume2,
  Save,
  Upload,
  RotateCcw,
  X,
  Bug,
  Sliders,
  Music,
  Monitor,
  HelpCircle,
  BookOpen,
  LogOut,
  Check,
  Sparkles,
  Building2,
  MapPin,
  Swords,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface SettingsModalProps {
  devMode: boolean;
  onToggleDevMode: () => void;
  onClose: () => void;
  onSaveNow: () => void;
  onExportSaveJson: () => void;
  onImportSaveJson: (jsonString: string) => void;
  onResetSave: () => void;
  onExitToMainMenu: () => void;
  // Audio Settings
  volume: number;
  onVolumeChange: (vol: number) => void;
  isBgmActive: boolean;
  bgmTheme: BgmTheme;
  onToggleBgm: () => void;
  onSelectBgmTheme: (theme: BgmTheme) => void;
  sfxEnabled: boolean;
  onToggleSfx: () => void;
  // Graphics Settings
  graphicsQuality: GraphicsQuality;
  onChangeGraphicsQuality: (q: GraphicsQuality) => void;
  // Dev mode controller props (strictly manual, never auto-overwrites!)
  resources: SectResources;
  prestige: number;
  onUpdatePrestige: (val: number) => void;
  onUpdateResource: (key: keyof SectResources, value: number) => void;
  year: number;
  season: Season;
  stability: SectStability;
  onUpdateTimeline: (year: number, season: Season, stability: SectStability) => void;
  disciples: Disciple[];
  onUpdateDiscipleDev: (discipleId: string, updates: Partial<Disciple>) => void;
  onUnlockAllBuildingsDev: () => void;
  onUnlockMaxSectorsDev: () => void;
  onMaxAllDisciplesExpDev: () => void;
  onTriggerSeasonalEventsDev: () => void;
}

const HELP_GUIDES = [
  {
    title: 'Cultivation Paths & Conditional Tribulations',
    body: 'Every disciple walks one of 5 paths: Qi, Body, Sword, Soul, or Alchemy Dao. Body Cultivators hone flesh and bone relentlessly — they NEVER summon Heavenly Lightning Tribulations during breakthroughs, instead facing raw physique bottlenecks.'
  },
  {
    title: 'Breakthroughs, Skip Mode & Backlash Consequences',
    body: 'When Cultivation Qi fills to 100%, enter the Breakthrough chamber to view exact success odds, spend a Refinement Pill (+22%), and witness Lightning Tribulations (or Flesh Tempering). You may toggle Skip Animation / Instant Breakthrough at any time. Failing incurs 25% Qi backlash, +22 Stress, and -20 Morale.'
  },
  {
    title: '5-Year Bottleneck Notice & Stat Decline',
    body: 'Leaving a disciple stuck at a full breakthrough bottleneck for 5+ years triggers a Chronicle Stagnation alert and inflicts negative traits (Stagnant Dao-Heart). Unresolved stress (>=65), active grudges, or old age near lifespan gradually drain morale and combat focus until remedied.'
  },
  {
    title: 'Eight Trigrams Alchemy % & Scaled Buildings',
    body: 'Alchemy refinement success rate scales dynamically from assigned disciples’ average talent, total Sect Prestige, and Alchemy Pavilion level. Every unlocked building displays current-to-next level scaling so every upgrade meaningfully amplifies your sect.'
  },
  {
    title: '5-Level Peer Bonds & Alignment Compatibility',
    body: 'Disciples may form max 1 active bond per peer across 5 tiers (Unknown → Acquaintance → Trusted → Devoted → Inseparable). Personal and Sect alignments affect bond odds (+12% shared, -24% Righteous vs Demonic).'
  },
  {
    title: 'Favorite Prodigy Bonuses (Max 3)',
    body: 'Starring up to 3 Favorite disciples grants +20% Cultivation comprehension, +12% effective Combat Might in arena/expeditions, +10% Breakthrough odds, and calming stress resistance.'
  },
  {
    title: 'Gate Trials Rarity & Custom Creation',
    body: 'Gate Trials feature realistic mortal scarcity (Innate prodigies <2%). Refreshing the gate roster costs 25 Spirit Stones. Custom Creation allows exact control over Hair, Face, Aura, Mythical Form, Cultivation Path, and Alignment with costs scaling dynamically with stat rarity.'
  },
  {
    title: 'Peak Challenge, Soul Lanterns & Fair Play',
    body: 'Peak Challenge runs once per season with Auto/Manual technique duels. Tend Soul Lanterns to extend lifespan, cast Daily Divinations, and click Advance Time to trigger 1–10 sequential sect events.'
  }
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  devMode,
  onToggleDevMode,
  onClose,
  onSaveNow,
  onExportSaveJson,
  onImportSaveJson,
  onResetSave,
  onExitToMainMenu,
  volume,
  onVolumeChange,
  isBgmActive,
  bgmTheme,
  onToggleBgm,
  onSelectBgmTheme,
  sfxEnabled,
  onToggleSfx,
  graphicsQuality,
  onChangeGraphicsQuality,
  resources,
  prestige,
  onUpdatePrestige,
  onUpdateResource,
  year,
  season,
  stability,
  onUpdateTimeline,
  disciples,
  onUpdateDiscipleDev,
  onUnlockAllBuildingsDev,
  onUnlockMaxSectorsDev,
  onMaxAllDisciplesExpDev,
  onTriggerSeasonalEventsDev
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedDevDiscipleId, setSelectedDevDiscipleId] = useState<string>(disciples[0]?.id || '');
  const [savedFeedback, setSavedFeedback] = useState<boolean>(false);
  const [showHelp, setShowHelp] = useState<boolean>(false);
  const [showCredits, setShowCredits] = useState<boolean>(false);

  const selectedDevDisciple = disciples.find(d => d.id === selectedDevDiscipleId) || disciples[0];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (content) {
          onImportSaveJson(content);
        }
      };
      reader.readAsText(file);
    }
  };

  const handleSecretBugClick = () => {
    soundEngine.playTalisman();
    onToggleDevMode();
  };

  const handleQuickSave = () => {
    soundEngine.playCheckInReward();
    onSaveNow();
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 1800);
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] relative">
        {/* Sticky Header */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2 min-w-0">
            <Settings className="w-5 h-5 text-[#fce18b] shrink-0" />
            <div className="min-w-0">
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b] flex items-center gap-2 flex-wrap">
                <span>Sect Settings &amp; Archives</span>
                {devMode && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-950 text-red-300 border border-red-500/50 font-mono">
                    Bug / Cheat Menu Open
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-[#9fc2b2] truncate">
                Sound, graphics, tutorials, credits, storage, and main menu.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-3.5 sm:p-4 overflow-y-auto space-y-3.5 grow text-xs text-[#d1e6dc]">
          {/* 1. Audio & Sound Adjustments */}
          <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-3">
            <div className="flex justify-between items-center">
              <span className="font-bold text-[#fce18b] flex items-center gap-1.5 font-dao text-sm">
                <Volume2 className="w-4 h-4 text-[#38bdf8]" />
                <span>Sound Adjustments</span>
              </span>
              <span className="font-mono text-[#fce18b]">{Math.round(volume * 100)}%</span>
            </div>

            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
              className="w-full accent-[#e2b054] cursor-pointer"
            />

            <div className="grid grid-cols-2 gap-2 pt-0.5">
              <button
                onClick={onToggleBgm}
                className={`py-2 px-2 rounded-xl border text-[11px] font-bold flex items-center justify-center gap-1.5 transition-all min-h-[38px] ${
                  isBgmActive
                    ? 'bg-[#184838] border-[#e2b054] text-[#fce18b]'
                    : 'bg-[#123d30] border-[#1b4b3b] text-[#7ea091]'
                }`}
              >
                <Music className="w-3.5 h-3.5" />
                <span>BGM: {isBgmActive ? 'ON' : 'OFF'}</span>
              </button>

              <button
                onClick={onToggleSfx}
                className={`py-2 px-2 rounded-xl border text-[11px] font-bold flex items-center justify-center gap-1 transition-all min-h-[38px] ${
                  sfxEnabled
                    ? 'bg-[#184838] border-[#38bdf8]/60 text-[#bae6fd]'
                    : 'bg-[#123d30] border-[#1b4b3b] text-[#7ea091]'
                }`}
              >
                <span>SFX: {sfxEnabled ? 'ON' : 'OFF'}</span>
              </button>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] text-[#9fc2b2] block">Select Sect Soundtrack (5 Original Themes):</span>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                {(Object.keys(BGM_THEME_LABELS) as BgmTheme[]).map(themeKey => (
                  <button
                    key={themeKey}
                    onClick={() => {
                      soundEngine.playClick();
                      onSelectBgmTheme(themeKey);
                    }}
                    className={`py-1.5 px-2 rounded-xl border text-[10px] font-bold transition-all min-h-[36px] ${
                      bgmTheme === themeKey
                        ? 'bg-[#184838] border-[#fce18b] text-[#fce18b] shadow-xs'
                        : 'bg-[#123d30] border-[#1b4b3b] text-[#8daea0] hover:text-white'
                    }`}
                  >
                    {BGM_THEME_LABELS[themeKey].short}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 2. Graphics Quality */}
          <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-2.5">
            <div className="flex justify-between items-center">
              <span className="font-bold text-[#fce18b] flex items-center gap-1.5 font-dao text-sm">
                <Monitor className="w-4 h-4 text-emerald-400" />
                <span>Graphics &amp; Visual Effects</span>
              </span>
              <span className="text-[10px] text-[#9fc2b2] uppercase font-mono">{graphicsQuality}</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {([
                { id: 'low' as const, label: 'Low', desc: 'Battery saver' },
                { id: 'medium' as const, label: 'Medium', desc: 'Balanced' },
                { id: 'high' as const, label: 'High', desc: 'Full VFX & glow' }
              ]).map(opt => (
                <button
                  key={opt.id}
                  onClick={() => {
                    soundEngine.playClick();
                    onChangeGraphicsQuality(opt.id);
                  }}
                  className={`p-2 rounded-xl border text-center transition-all min-h-[44px] ${
                    graphicsQuality === opt.id
                      ? 'bg-[#184838] border-[#fce18b] text-[#fce18b] shadow-sm'
                      : 'bg-[#123d30] border-[#1b4b3b] text-[#8daea0] hover:border-[#2a6b56]'
                  }`}
                >
                  <div className="text-xs font-bold">{opt.label}</div>
                  <div className="text-[9px] opacity-80">{opt.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* 3. Save, Load & Exit to Main Menu */}
          <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-2.5">
            <span className="font-bold text-[#fce18b] block font-dao text-sm">Save, Load &amp; Session</span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <button
                onClick={handleQuickSave}
                className="py-2.5 px-3 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/50 font-bold text-[11px] flex items-center justify-center gap-1.5 min-h-[40px]"
              >
                {savedFeedback ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                <span>{savedFeedback ? 'Saved!' : 'Save Game'}</span>
              </button>

              <button
                onClick={() => {
                  soundEngine.playClick();
                  onExportSaveJson();
                }}
                className="py-2.5 px-3 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] border border-[#e2b054]/40 font-bold text-[11px] flex items-center justify-center gap-1.5 min-h-[40px]"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Export JSON</span>
              </button>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="py-2.5 px-3 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#38bdf8] border border-[#38bdf8]/40 font-bold text-[11px] flex items-center justify-center gap-1.5 min-h-[40px] col-span-2 sm:col-span-1"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Load (JSON)</span>
              </button>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".json"
                className="hidden"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => {
                  soundEngine.playClick();
                  onSaveNow();
                  onExitToMainMenu();
                }}
                className="py-2.5 px-3 rounded-xl bg-[#184838] hover:bg-[#205e4a] text-[#fce18b] border border-[#e2b054]/60 font-dao font-bold text-xs flex items-center justify-center gap-1.5 min-h-[42px]"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Save &amp; Exit to Main Menu</span>
              </button>

              <button
                onClick={() => {
                  if (window.confirm('Reset all sect progress back to Year 1 with starting disciples?')) {
                    onResetSave();
                  }
                }}
                className="py-2.5 px-3 rounded-xl bg-red-950/50 hover:bg-red-900/70 text-red-300 border border-red-800/50 font-bold text-[11px] flex items-center justify-center gap-1.5 min-h-[42px]"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Sect Progress</span>
              </button>
            </div>
          </div>

          {/* 4. Help / Tutorials & Credits */}
          <div className="space-y-2">
            <button
              onClick={() => {
                soundEngine.playClick();
                setShowHelp(!showHelp);
              }}
              className="w-full p-3 rounded-2xl bg-[#09261d] border border-[#1b4b3b] hover:border-[#e2b054]/50 flex justify-between items-center text-left"
            >
              <span className="font-dao font-bold text-xs sm:text-sm text-[#fce18b] flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-[#38bdf8]" />
                <span>Help &amp; Cultivation Tutorials</span>
              </span>
              {showHelp ? <ChevronUp className="w-4 h-4 text-[#9fc2b2]" /> : <ChevronDown className="w-4 h-4 text-[#9fc2b2]" />}
            </button>

            {showHelp && (
              <div className="bg-[#071f17] p-3.5 rounded-2xl border border-[#1d5543] space-y-2.5">
                {HELP_GUIDES.map((g, i) => (
                  <div key={i} className="border-b border-[#143d30] last:border-b-0 pb-2 last:pb-0">
                    <div className="font-bold text-[#86efac] text-[11px]">{i + 1}. {g.title}</div>
                    <p className="text-[11px] text-[#b8d4c7] leading-relaxed mt-0.5">{g.body}</p>
                  </div>
                ))}
              </div>
            )}

            <button
              onClick={() => {
                soundEngine.playClick();
                setShowCredits(!showCredits);
              }}
              className="w-full p-3 rounded-2xl bg-[#09261d] border border-[#1b4b3b] hover:border-[#e2b054]/50 flex justify-between items-center text-left"
            >
              <span className="font-dao font-bold text-xs sm:text-sm text-[#fce18b] flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-[#e2b054]" />
                <span>Credits &amp; Chronicle Info</span>
              </span>
              {showCredits ? <ChevronUp className="w-4 h-4 text-[#9fc2b2]" /> : <ChevronDown className="w-4 h-4 text-[#9fc2b2]" />}
            </button>

            {showCredits && (
              <div className="bg-[#071f17] p-3.5 rounded-2xl border border-[#1d5543] space-y-2 text-[11px] text-[#cbe3d7]">
                <div className="font-dao font-bold text-[#fce18b] text-xs">Amazing Sect Cultivation · Extreme World</div>
                <div className="p-2 rounded-xl bg-[#0d2e23] border border-[#e2b054]/40 text-[#fce18b] font-bold text-xs flex items-center justify-between">
                  <span>Developed &amp; Designed by</span>
                  <span className="font-dao text-sm text-amber-200">Jemeson Gabane</span>
                </div>
                <p>Immortal Sect Strategy &amp; Lineage Simulation crafted with Web Audio API 5-track Guzheng &amp; Xiao Bamboo Flute synthesis, custom vector Daoist portraiture, conditional cultivation tribulations, and turn-based combat choreography.</p>
                <div className="text-[10px] text-[#7ea091] pt-1">
                  Tap the subtle spirit beetle in the footer below whenever you wish to open the manual Sandbox Bug / Cheat Controller.
                </div>
              </div>
            )}
          </div>

          {/* 5. EXPANDED BUG / CHEAT CONTROLLER (STRICTLY MANUAL USER EDITS ONLY — ZERO AUTO CHEATS) */}
          {devMode && (
            <div className="bg-[#071d16] p-4 rounded-3xl border-2 border-red-500/70 shadow-2xl space-y-4 animate-scale-up">
              <div className="flex justify-between items-center border-b border-red-500/30 pb-2">
                <div className="flex items-center gap-2 text-red-400 font-dao font-bold text-sm">
                  <Sliders className="w-4 h-4 text-red-400" />
                  <span>Manual Bug / Cheat Controller</span>
                </div>
                <span className="text-[9px] text-amber-300/90 font-mono">Manual Only · No Auto-Overrides</span>
              </div>

              {/* A. Currency & Prestige Manual Editor */}
              <div className="space-y-2">
                <span className="font-bold text-[#fce18b] block text-[11px]">Edit Resources &amp; Prestige</span>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { key: 'spiritStones' as const, label: 'Spirit Stones', val: resources.spiritStones, icon: '💎' },
                    { key: 'qi' as const, label: 'Pure Qi', val: resources.qi, icon: '🟢' },
                    { key: 'pills' as const, label: 'Pills', val: resources.pills, icon: '🧪' },
                    { key: 'merit' as const, label: 'Merit (Rep)', val: resources.merit, icon: '📜' }
                  ].map(({ key, label, val, icon }) => (
                    <div key={key} className="bg-[#0d2e23] p-2 rounded-xl border border-[#1d5543] space-y-1.5">
                      <div className="flex justify-between items-center text-[10px] text-[#9fc2b2]">
                        <span>{icon} {label}</span>
                        <button
                          onClick={() => onUpdateResource(key, 0)}
                          className="text-[9px] text-red-300 hover:underline"
                        >
                          Zero
                        </button>
                      </div>
                      <input
                        type="number"
                        value={val}
                        onChange={(e) => onUpdateResource(key, Math.max(0, parseInt(e.target.value) || 0))}
                        className="w-full bg-[#071913] text-[#fce18b] font-mono text-center text-xs rounded border border-[#276e57] px-1 py-1"
                      />
                      <div className="grid grid-cols-3 gap-1">
                        <button
                          onClick={() => onUpdateResource(key, val + 100)}
                          className="py-0.5 rounded bg-emerald-950 text-emerald-200 text-[9px] font-bold"
                        >
                          +100
                        </button>
                        <button
                          onClick={() => onUpdateResource(key, val + 10000)}
                          className="py-0.5 rounded bg-emerald-900 text-emerald-100 text-[9px] font-bold"
                        >
                          +10K
                        </button>
                        <button
                          onClick={() => onUpdateResource(key, val + 1000000)}
                          className="py-0.5 rounded bg-amber-900 text-amber-100 text-[9px] font-bold"
                        >
                          +1M
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Prestige & Timeline Row */}
                <div className="grid grid-cols-3 gap-2 pt-1">
                  <div className="bg-[#0d2e23] p-2 rounded-xl border border-[#1d5543]">
                    <span className="text-[9px] text-[#9fc2b2] block mb-1">⭐ Prestige</span>
                    <input
                      type="number"
                      value={prestige}
                      onChange={(e) => onUpdatePrestige(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full bg-[#071913] text-[#fce18b] font-mono text-xs rounded border border-[#276e57] px-1.5 py-1"
                    />
                  </div>
                  <div className="bg-[#0d2e23] p-2 rounded-xl border border-[#1d5543]">
                    <span className="text-[9px] text-[#9fc2b2] block mb-1">📅 Year</span>
                    <input
                      type="number"
                      min="1"
                      value={year}
                      onChange={(e) => onUpdateTimeline(Math.max(1, parseInt(e.target.value) || 1), season, stability)}
                      className="w-full bg-[#071913] text-white font-mono text-xs rounded border border-[#276e57] px-1.5 py-1"
                    />
                  </div>
                  <div className="bg-[#0d2e23] p-2 rounded-xl border border-[#1d5543]">
                    <span className="text-[9px] text-[#9fc2b2] block mb-1">🌸 Season</span>
                    <select
                      value={season}
                      onChange={(e) => onUpdateTimeline(year, e.target.value as Season, stability)}
                      className="w-full bg-[#071913] text-white text-xs rounded border border-[#276e57] px-1 py-1"
                    >
                      {(['Spring', 'Summer', 'Autumn', 'Winter'] as Season[]).map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* B. Sect-Wide World Cheats */}
              <div className="space-y-1.5 pt-2 border-t border-red-500/20">
                <span className="font-bold text-[#fce18b] block text-[11px]">World &amp; Progression Cheats</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      soundEngine.playGong();
                      onUnlockAllBuildingsDev();
                    }}
                    className="py-2 px-2.5 rounded-xl bg-[#184838] hover:bg-[#1e5c48] text-[#fce18b] border border-[#e2b054]/40 text-[10px] font-bold flex items-center justify-center gap-1.5"
                  >
                    <Building2 className="w-3.5 h-3.5" />
                    <span>Unlock All Buildings</span>
                  </button>

                  <button
                    onClick={() => {
                      soundEngine.playGong();
                      onUnlockMaxSectorsDev();
                    }}
                    className="py-2 px-2.5 rounded-xl bg-[#184838] hover:bg-[#1e5c48] text-emerald-300 border border-emerald-500/40 text-[10px] font-bold flex items-center justify-center gap-1.5"
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    <span>Unlock &amp; Max Sectors</span>
                  </button>

                  <button
                    onClick={() => {
                      soundEngine.playFanfare();
                      onMaxAllDisciplesExpDev();
                    }}
                    className="py-2 px-2.5 rounded-xl bg-[#184838] hover:bg-[#1e5c48] text-sky-300 border border-sky-500/40 text-[10px] font-bold flex items-center justify-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Max All Disciple EXP</span>
                  </button>

                  <button
                    onClick={() => {
                      soundEngine.playTalisman();
                      onTriggerSeasonalEventsDev();
                    }}
                    className="py-2 px-2.5 rounded-xl bg-[#184838] hover:bg-[#1e5c48] text-amber-300 border border-amber-500/40 text-[10px] font-bold flex items-center justify-center gap-1.5"
                  >
                    <Swords className="w-3.5 h-3.5" />
                    <span>Spawn Seasonal Events</span>
                  </button>
                </div>
              </div>

              {/* C. Full Disciple Sandbox Editor */}
              {selectedDevDisciple && (
                <div className="space-y-2 pt-2 border-t border-red-500/20">
                  <div className="flex justify-between items-center gap-2">
                    <span className="font-bold text-[#fce18b] block text-[11px]">Disciple Sandbox Editor</span>
                    <select
                      value={selectedDevDisciple.id}
                      onChange={(e) => setSelectedDevDiscipleId(e.target.value)}
                      className="bg-[#0d2e23] text-[#fce18b] text-[10px] rounded-lg border border-[#276e57] px-2 py-1"
                    >
                      {disciples.map(d => (
                        <option key={d.id} value={d.id}>{d.name} ({d.rank})</option>
                      ))}
                    </select>
                  </div>

                  <div className="bg-[#0d2e23] p-3 rounded-2xl border border-[#1d5543] space-y-2.5">
                    {/* Name & Gender */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="col-span-2">
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Name</span>
                        <input
                          type="text"
                          value={selectedDevDisciple.name}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { name: e.target.value })}
                          className="w-full bg-[#071913] text-white px-2 py-1 rounded text-xs border border-[#276e57] font-bold"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Gender</span>
                        <select
                          value={selectedDevDisciple.gender}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { gender: e.target.value as 'Male' | 'Female' })}
                          className="w-full bg-[#071913] text-white px-1.5 py-1 rounded text-xs border border-[#276e57]"
                        >
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                        </select>
                      </div>
                    </div>

                    {/* Rank Assignment */}
                    <div className="space-y-1">
                      <span className="text-[10px] text-[#86efac] font-bold block">Rank</span>
                      <div className="flex flex-wrap gap-1">
                        {(['Outer', 'Inner', 'Direct', 'Elder', 'Grand Elder', 'Sect Leader'] as DiscipleRank[]).map(r => (
                          <button
                            key={r}
                            onClick={() => onUpdateDiscipleDev(selectedDevDisciple.id, { rank: r })}
                            className={`px-2 py-1 rounded text-[9px] font-bold transition-all ${
                              selectedDevDisciple.rank === r
                                ? 'bg-emerald-600 text-white'
                                : 'bg-[#123d30] text-[#a4c5b7] hover:bg-[#184838]'
                            }`}
                          >
                            {r}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Realm Slider */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px]">
                        <span className="text-[#9fc2b2]">Realm: {CULTIVATION_REALMS[selectedDevDisciple.currentRealmIndex]?.name}</span>
                        <span className="text-[#fce18b] font-mono">Lv {selectedDevDisciple.currentRealmIndex}</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max={CULTIVATION_REALMS.length - 1}
                        value={selectedDevDisciple.currentRealmIndex}
                        onChange={(e) => {
                          const idx = parseInt(e.target.value);
                          const rm = CULTIVATION_REALMS[idx];
                          onUpdateDiscipleDev(selectedDevDisciple.id, {
                            currentRealmIndex: idx,
                            maxExp: rm?.qiRequired || 100,
                            combatPower: rm?.combatPower || 100
                          });
                        }}
                        className="w-full accent-[#e2b054]"
                      />
                    </div>

                    {/* Combat Power, Talent, Lifespan numeric editors */}
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Combat Power</span>
                        <input
                          type="number"
                          value={selectedDevDisciple.combatPower}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { combatPower: Math.max(1, parseInt(e.target.value) || 1) })}
                          className="w-full bg-[#071913] text-[#38bdf8] font-mono px-1.5 py-1 rounded text-xs border border-[#276e57]"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Talent (1-100)</span>
                        <input
                          type="number"
                          min="1"
                          max="100"
                          value={selectedDevDisciple.talent}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { talent: Math.max(1, Math.min(100, parseInt(e.target.value) || 50)) })}
                          className="w-full bg-[#071913] text-[#fce18b] font-mono px-1.5 py-1 rounded text-xs border border-[#276e57]"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Lifespan</span>
                        <input
                          type="number"
                          value={selectedDevDisciple.lifespan}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { lifespan: Math.max(50, parseInt(e.target.value) || 100) })}
                          className="w-full bg-[#071913] text-emerald-300 font-mono px-1.5 py-1 rounded text-xs border border-[#276e57]"
                        />
                      </div>
                    </div>

                    {/* Root, Talent Tier, Physique, Expression */}
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Spirit Root</span>
                        <select
                          value={selectedDevDisciple.spiritRoot}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { spiritRoot: e.target.value as SpiritRootType })}
                          className="w-full bg-[#071913] text-white px-1.5 py-1 rounded text-[11px] border border-[#276e57]"
                        >
                          {(['Metal', 'Wood', 'Water', 'Fire', 'Earth', 'Thunder', 'Ice', 'Wind', 'Yin-Yang', 'Chaos', 'Heavenly', 'Immortal'] as SpiritRootType[]).map(r => (
                            <option key={r} value={r}>{r}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Talent Tier</span>
                        <select
                          value={selectedDevDisciple.talentTier}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { talentTier: e.target.value as TalentTier })}
                          className="w-full bg-[#071913] text-white px-1.5 py-1 rounded text-[11px] border border-[#276e57]"
                        >
                          {(['Poor', 'Lazy', 'Mediocre', 'Talented', 'Prodigy', 'Innate'] as TalentTier[]).map(t => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Physique</span>
                        <select
                          value={selectedDevDisciple.constitution}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { constitution: e.target.value as ConstitutionType })}
                          className="w-full bg-[#071913] text-white px-1.5 py-1 rounded text-[11px] border border-[#276e57]"
                        >
                          {(Object.keys(CONSTITUTION_EFFECTS) as ConstitutionType[]).map(c => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Expression</span>
                        <select
                          value={selectedDevDisciple.expression || 'Serene'}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { expression: e.target.value as DiscipleExpression })}
                          className="w-full bg-[#071913] text-white px-1.5 py-1 rounded text-[11px] border border-[#276e57]"
                        >
                          {DISCIPLE_EXPRESSIONS.map(exp => (
                            <option key={exp.id} value={exp.id}>{exp.label}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Appearance, Hair Color, Mythical Form */}
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Hair Style #</span>
                        <select
                          value={selectedDevDisciple.appearanceIndex ?? 0}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { appearanceIndex: parseInt(e.target.value) })}
                          className="w-full bg-[#071913] text-white px-1.5 py-1 rounded text-[11px] border border-[#276e57]"
                        >
                          {Array.from({ length: 10 }).map((_, i) => (
                            <option key={i} value={i}>Style #{i + 1}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Hair Color</span>
                        <select
                          value={selectedDevDisciple.hairColor || CUSTOM_HAIR_COLORS[0].id}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { hairColor: e.target.value })}
                          className="w-full bg-[#071913] text-white px-1.5 py-1 rounded text-[11px] border border-[#276e57]"
                        >
                          {CUSTOM_HAIR_COLORS.map(hc => (
                            <option key={hc.id} value={hc.id}>{hc.label}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <span className="text-[9px] text-[#9fc2b2] block mb-0.5">Mythical Form</span>
                        <select
                          value={selectedDevDisciple.mythicalForm || 'None'}
                          onChange={(e) => onUpdateDiscipleDev(selectedDevDisciple.id, { mythicalForm: e.target.value as MythicalFormType })}
                          className="w-full bg-[#071913] text-white px-1.5 py-1 rounded text-[11px] border border-[#276e57]"
                        >
                          <option value="None">Classic</option>
                          <option value="Thunder Sovereign">Thunder Sovereign</option>
                          <option value="Immortal Beast">Immortal Beast</option>
                        </select>
                      </div>
                    </div>

                    {/* Quick Toggles */}
                    <div className="grid grid-cols-3 gap-1 pt-1">
                      <button
                        onClick={() => onUpdateDiscipleDev(selectedDevDisciple.id, { cultivationExp: selectedDevDisciple.maxExp })}
                        className="py-1.5 rounded bg-[#184838] text-[#fce18b] text-[9px] font-bold"
                      >
                        Fill Break EXP
                      </button>
                      <button
                        onClick={() => onUpdateDiscipleDev(selectedDevDisciple.id, { loyalty: 100, morale: 100 })}
                        className="py-1.5 rounded bg-[#184838] text-emerald-300 text-[9px] font-bold"
                      >
                        Max Loyalty/Morale
                      </button>
                      <button
                        onClick={() => onUpdateDiscipleDev(selectedDevDisciple.id, { stress: 0, relations: [] })}
                        className="py-1.5 rounded bg-[#184838] text-amber-300 text-[9px] font-bold"
                      >
                        Clear Stress/Grudges
                      </button>
                    </div>

                    <div className="grid grid-cols-4 gap-1">
                      {(['None', 'Champion I', 'Champion II', 'Champion S'] as const).map(ct => (
                        <button
                          key={ct}
                          onClick={() => onUpdateDiscipleDev(selectedDevDisciple.id, { championTitle: ct === 'None' ? undefined : (ct as ChampionTitle) })}
                          className={`py-1 rounded text-[9px] font-bold ${
                            (selectedDevDisciple.championTitle || 'None') === ct
                              ? 'bg-amber-500 text-[#072018]'
                              : 'bg-[#123d30] text-[#9fc2b2]'
                          }`}
                        >
                          {ct}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom Exit Bar & Secret Bug Controller Toggle */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <div className="flex items-center gap-2">
            <span className="text-[#6d8e80] text-[10px]">Mystic Daoist Engine · Year {year}</span>
            <button
              onClick={handleSecretBugClick}
              title={devMode ? 'Close Bug / Cheat Menu' : 'Spirit Beetle (Open Bug / Cheat Menu)'}
              className={`p-1.5 rounded-lg transition-all flex items-center gap-1 ${
                devMode
                  ? 'text-red-300 bg-red-950/70 border border-red-500/40 shadow-sm'
                  : 'text-[#256953] hover:text-[#e2b054] opacity-50 hover:opacity-100'
              }`}
            >
              <Bug className="w-3.5 h-3.5" />
              {devMode && <span className="text-[9px] font-mono">CHEATS ON</span>}
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[38px]"
          >
            Close Settings
          </button>
        </div>
      </div>
    </div>
  );
};
