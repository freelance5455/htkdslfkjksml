import React, { useState, useEffect, useRef } from 'react';
import {
  Disciple,
  DiscipleExpression,
  TournamentCategory,
  TournamentFighter,
  TournamentMatchLog,
  ChampionTitle,
  SpiritRootType
} from '../../types/cultivation';
import { CULTIVATION_REALMS } from '../../data/realms';
import { TOURNAMENT_BOOSTERS } from '../../data/loreData';
import { CultivatorAvatar } from '../cultivation/CultivatorAvatar';
import { ChampionTitleBadge } from '../cultivation/ChampionTitleBadge';
import { soundEngine } from '../../services/audioEngine';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Trophy,
  Swords,
  Shield,
  Zap,
  Sparkles,
  Flame,
  Wind,
  Snowflake,
  Heart,
  Play,
  Pause,
  FastForward,
  UserCheck,
  X,
  Crown,
  Users,
  ScrollText
} from 'lucide-react';

interface TournamentModalProps {
  disciples: Disciple[];
  onClose: () => void;
  onCrownChampion: (
    discipleId: string,
    title: ChampionTitle,
    grantBreakthroughPill: boolean,
    directPromotionRank?: 'Inner' | 'Elder' | 'Grand Elder' | 'Sect Leader'
  ) => void;
  onRecruitDefeatedOpponent?: (fighter: TournamentFighter) => void;
  onGrantConsolationRewards?: (amountStones: number, amountMerit: number) => void;
  sectPrestige: number;
  devMode?: boolean;
}

type VfxType = 'sword' | 'lightning' | 'fire' | 'ice' | 'wind' | 'shield';

interface PlotBeat {
  title: string;
  introQuote: string;
  rivalryNote: string;
  midDuelTwist: string;
}

const ROUND_PLOTS: PlotBeat[] = [
  {
    title: 'Opening Trial: Whisper of Rival Sects',
    introQuote: '"Let us see if Mystic Daoist Temple merits its mountain plaque or merely hides behind mist!"',
    rivalryNote: 'Visiting outer envoys placed private spirit stone wagers along the West Balcony.',
    midDuelTwist: 'Hidden meridian resonance flares! Both cultivators shatter their restraint seals!'
  },
  {
    title: 'Second Clash: Resonance of Cold Iron',
    introQuote: '"My sect spent three decades tempering this blade-heart. Step forward if you dare answer!"',
    rivalryNote: 'Elder judges lean forward as sword-intent ripples disturb the clouds overhead.',
    midDuelTwist: 'Sparks ignite the arena flagstones — the stone formations hum with ancient battle-memory!'
  },
  {
    title: 'Third Ascent: Pride of the Nine Horizons',
    introQuote: '"Ordinary disciples kneel before my spiritual pressure. Show me an art worth remembering!"',
    rivalryNote: 'Rumors spread through the stands of an ancient inheritance hidden inside the Peak Stele.',
    midDuelTwist: 'Both fighters burn latent essence, turning the sky above the Peak Arena crimson and gold!'
  },
  {
    title: 'Semifinal Crucible: Shadow & Flame',
    introQuote: '"Only one prodigy steps onto the Jade Summit tomorrow. Leave nothing unspent!"',
    rivalryNote: 'Sect elders halt their murmurs; even rival sovereigns stand motionless in anticipation.',
    midDuelTwist: 'A sudden gust of primordial Qi sweeps the ring, empowering elemental techniques!'
  },
  {
    title: 'Grand Pinnacle Finale: Decree of Heaven',
    introQuote: '"Beneath ten thousand gazes and the watchful Dao, prove whose path eclipses all others!"',
    rivalryNote: 'The Ancestral Bronze Bell tolls thrice across Extreme World for the Championship bout.',
    midDuelTwist: 'Heavenly pressure descends on the ring — every final strike echoes like shattering jade!'
  }
];

function getVfxFromRoot(root: SpiritRootType): VfxType {
  if (root === 'Fire') return 'fire';
  if (root === 'Ice' || root === 'Water') return 'ice';
  if (root === 'Thunder') return 'lightning';
  if (root === 'Wind' || root === 'Wood') return 'wind';
  return 'sword';
}

function getTechniqueName(root: SpiritRootType, tier: 'basic' | 'elemental' | 'ultimate'): { name: string; vfx: VfxType } {
  if (tier === 'basic') {
    return { name: 'Azure Edge Sword Thrust', vfx: 'sword' };
  }
  const map: Record<string, { elem: string; ult: string; vfx: VfxType }> = {
    Fire: { elem: 'Crimson Lotus Flame Palm', ult: 'Nine-Suns Blazing Phoenix Ruin', vfx: 'fire' },
    Ice: { elem: 'Glacial Mirror Spear', ult: 'Absolute Frost Sovereign Seal', vfx: 'ice' },
    Water: { elem: 'Tidal Dragon Surge', ult: 'Abyssal Leviathan Deluge', vfx: 'ice' },
    Thunder: { elem: 'Purple Arc Lightning Flash', ult: 'Heaven-Punishing Ninefold Thunder', vfx: 'lightning' },
    Wind: { elem: 'Gale Zephyr Cleave', ult: 'Void-Shattering Tempest Waltz', vfx: 'wind' },
    Wood: { elem: 'Verdant Vine Binding Strike', ult: 'World-Tree Emerald Annihilation', vfx: 'wind' },
    Metal: { elem: 'Gilded庚 Gold Sword Rain', ult: 'Myriad Immortal Saber Convergence', vfx: 'sword' },
    Earth: { elem: 'Mountain-Crushing Palm', ult: 'Tectonic Dao Obelisk Crash', vfx: 'sword' },
    Chaos: { elem: 'Primordial Rift Slash', ult: 'Chaos Extinction Heaven Cleave', vfx: 'lightning' },
    Heavenly: { elem: 'Celestial Starlight Lance', ult: 'Immortal Emperor Starfall', vfx: 'lightning' },
    Immortal: { elem: 'Jade Dao Radiance', ult: 'Eternal Ascension Sword Art', vfx: 'sword' },
    'Yin-Yang': { elem: 'Taiji Twin-Moon Whirl', ult: 'Yin-Yang Reversal Domain', vfx: 'wind' }
  };
  const entry = map[root] || { elem: `${root} Dao Art`, ult: `${root} Heaven-Shattering Art`, vfx: getVfxFromRoot(root) };
  return {
    name: tier === 'elemental' ? entry.elem : entry.ult,
    vfx: entry.vfx
  };
}

function getElementalMatchup(rootA: SpiritRootType, rootB: SpiritRootType): { advantageA: boolean; advantageB: boolean; reason?: string } {
  const counters: Record<string, string> = {
    Water: 'Fire',
    Fire: 'Metal',
    Metal: 'Wood',
    Wood: 'Earth',
    Earth: 'Water',
    Thunder: 'Water',
    Ice: 'Fire',
    Wind: 'Wood',
    'Yin-Yang': 'All',
    Chaos: 'All',
    Heavenly: 'All',
    Immortal: 'All'
  };

  const strA = rootA as string;
  const strB = rootB as string;

  if (counters[strA] === strB || ['Chaos', 'Immortal', 'Heavenly'].includes(strA)) {
    return { advantageA: true, advantageB: false, reason: `${rootA} overwhelms ${rootB}` };
  }
  if (counters[strB] === strA || ['Chaos', 'Immortal', 'Heavenly'].includes(strB)) {
    return { advantageA: false, advantageB: true, reason: `${rootB} suppresses ${rootA}` };
  }
  return { advantageA: false, advantageB: false };
}

export const TournamentModal: React.FC<TournamentModalProps> = ({
  disciples,
  onClose,
  onCrownChampion,
  onRecruitDefeatedOpponent,
  onGrantConsolationRewards,
  sectPrestige,
  devMode = false
}) => {
  const [selectedCategory, setSelectedCategory] = useState<TournamentCategory>('AllSectsUniversal');
  const [selectedDiscipleId, setSelectedDiscipleId] = useState<string>(disciples[0]?.id || '');
  const [selectedBoosterId, setSelectedBoosterId] = useState<string | null>(null);

  // Stages: 'roster' -> 'challenger_preview' -> 'arena' -> 'round_reward' -> 'tournament_ended'
  const [stage, setStage] = useState<'roster' | 'challenger_preview' | 'arena' | 'round_reward' | 'tournament_ended'>('roster');

  const [bracketFighters, setBracketFighters] = useState<TournamentFighter[]>([]);
  const [currentRound, setCurrentRound] = useState<number>(1); // 1 to 5 rounds total
  const [currentOpponentIndex, setCurrentOpponentIndex] = useState<number>(1);

  // Battle Simulation State
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<1 | 2 | 3>(1);
  const [isAutoPlay, setIsAutoPlay] = useState<boolean>(true);
  const [turnPhase, setTurnPhase] = useState<'player' | 'opponent'>('player');
  const [turnCount, setTurnCount] = useState<number>(1);

  const [playerHp, setPlayerHp] = useState<number>(100);
  const [playerMaxHp, setPlayerMaxHp] = useState<number>(100);
  const [playerEnergy, setPlayerEnergy] = useState<number>(50);
  const [playerStatusEffect, setPlayerStatusEffect] = useState<string | null>(null);
  const [playerWardActive, setPlayerWardActive] = useState<boolean>(false);

  const [opponentHp, setOpponentHp] = useState<number>(100);
  const [opponentMaxHp, setOpponentMaxHp] = useState<number>(100);
  const [opponentEnergy, setOpponentEnergy] = useState<number>(50);
  const [opponentStatusEffect, setOpponentStatusEffect] = useState<string | null>(null);

  // Animated visual choreography state
  const [activeAttackSide, setActiveAttackSide] = useState<'player' | 'opponent' | null>(null);
  const [activeHurtSide, setActiveHurtSide] = useState<'player' | 'opponent' | null>(null);
  const [activeVfx, setActiveVfx] = useState<{ id: number; type: VfxType; target: 'player' | 'opponent'; label: string } | null>(null);
  const [floatingPopup, setFloatingPopup] = useState<{ id: number; side: 'player' | 'opponent'; text: string; isCrit?: boolean; isHeal?: boolean } | null>(null);
  const [midPlotTriggered, setMidPlotTriggered] = useState<boolean>(false);
  const [storyBanner, setStoryBanner] = useState<string>('');

  const [battleLogs, setBattleLogs] = useState<TournamentMatchLog[]>([]);
  const [spectatorCheer, setSpectatorCheer] = useState<string>('West & East stands erupt as the bell tolls!');

  // Final Outcome
  const [tournamentWinner, setTournamentWinner] = useState<TournamentFighter | null>(null);
  const [isPlayerChampion, setIsPlayerChampion] = useState<boolean>(false);
  const [hasRecruitedOpponent, setHasRecruitedOpponent] = useState<boolean>(false);

  const animTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (animTimerRef.current) window.clearTimeout(animTimerRef.current);
    };
  }, []);

  const selectedDisciple = disciples.find(d => d.id === selectedDiscipleId) || disciples[0];

  const getEligibleDisciples = () => {
    switch (selectedCategory) {
      case 'InnerPromotion':
        return disciples.filter(d => d.rank === 'Outer');
      case 'ElderChallenge':
        return disciples.filter(d => d.rank === 'Inner' || d.rank === 'Direct');
      case 'LeaderChallenge':
        return disciples.filter(d => d.rank === 'Grand Elder' || d.rank === 'Elder');
      case 'AllSectsUniversal':
      default:
        return disciples;
    }
  };

  const eligibleDisciples = getEligibleDisciples();

  useEffect(() => {
    if (eligibleDisciples.length > 0 && !eligibleDisciples.some(d => d.id === selectedDiscipleId)) {
      setSelectedDiscipleId(eligibleDisciples[0].id);
    }
  }, [selectedCategory, eligibleDisciples.length]);

  const generateBracketOpponents = (playerPower: number): TournamentFighter[] => {
    const oppNames: {
      name: string;
      title: string;
      root: SpiritRootType;
      sect: string;
      gender: 'Male' | 'Female';
      expression: DiscipleExpression;
    }[] = [
      { name: 'Xue Wuxin', title: 'Frost Blossom Scion', root: 'Ice', sect: 'Glacial Peak Sect', gender: 'Female', expression: 'Stoic' },
      { name: 'Lie Huo', title: 'Crimson Flame Tyrant', root: 'Fire', sect: 'True Sun Blood Sect', gender: 'Male', expression: 'Fierce' },
      { name: 'Mo Yanzhi', title: 'Wandering Hermit Blade', root: 'Wind', sect: 'Azure Wind Pavilion', gender: 'Male', expression: 'Smirk' },
      { name: 'Ye Lingfeng', title: 'Divine Thunderbolt Master', root: 'Thunder', sect: 'Nine Skies Altar', gender: 'Male', expression: 'Fierce' },
      { name: 'Baili Xuanyuan', title: 'Divine Sword Sovereign', root: 'Chaos', sect: 'Heavenly Sword Sect', gender: 'Female', expression: 'Serene' }
    ];

    return [1, 2, 3, 4].map((idx) => {
      const template = oppNames[(idx - 1 + Math.floor(Math.random() * 2)) % oppNames.length];
      const mult = 0.78 + idx * 0.16;
      const combatPwr = Math.max(25, Math.floor(playerPower * mult));
      const realmIdx = Math.min(24, Math.max(0, (selectedDisciple ? selectedDisciple.currentRealmIndex : 1) + Math.floor((idx - 1) / 2)));

      return {
        id: `opp_b_${idx}_${Date.now()}_${idx}`,
        name: `${template.name} · ${template.title}`,
        rank: idx >= 3 ? 'Direct' : 'Inner',
        currentRealmIndex: realmIdx,
        combatPower: combatPwr,
        spiritRoot: template.root,
        gender: template.gender,
        maxHp: 90 + combatPwr * 2,
        currentHp: 90 + combatPwr * 2,
        maxEnergy: 100,
        currentEnergy: 45,
        isForeign: true,
        sectName: template.sect,
        avatarStyle: {
          robeColor: idx === 1 ? '#0284c7' : idx === 2 ? '#b91c1c' : '#7c3aed',
          hairColor: idx >= 3 ? '#cbd5e1' : '#16141a',
          auraColor: '#e2b054',
          accessory: 'Dao Token',
          appearanceIndex: (idx * 2 + 1) % 10,
          skinTone: idx === 2 ? 'Sun Bronze' : 'Fair Jade',
          clothingColor: idx === 1 ? 'Astral Jade' : idx === 2 ? 'Phoenix Scarlet' : 'Celestial Violet',
          auraEffect: idx >= 3 ? 'Azure Thunder' : 'None'
        }
      };
    });
  };

  const calculateWinProbability = (pPower: number, oPower: number, rootA: SpiritRootType, rootB: SpiritRootType) => {
    const elem = getElementalMatchup(rootA, rootB);
    let pEff = pPower * (elem.advantageA ? 1.25 : elem.advantageB ? 0.75 : 1.0);
    const oEff = oPower * (elem.advantageB ? 1.25 : elem.advantageA ? 0.75 : 1.0);

    if (selectedBoosterId === 'booster_dragon_blood') pEff *= 1.25;
    if (selectedBoosterId === 'booster_golden_ward') pEff *= 1.15;

    return Math.min(99, Math.max(5, Math.round((pEff / (pEff + oEff)) * 100)));
  };

  const handleProceedToChallengerPreview = () => {
    if (!selectedDisciple) return;
    soundEngine.playGong();

    const pFighter: TournamentFighter = {
      id: selectedDisciple.id,
      name: selectedDisciple.name,
      rank: selectedDisciple.rank,
      currentRealmIndex: selectedDisciple.currentRealmIndex,
      combatPower: selectedDisciple.combatPower,
      spiritRoot: selectedDisciple.spiritRoot,
      gender: selectedDisciple.gender,
      maxHp: selectedDisciple.maxHp || 100 + selectedDisciple.combatPower * 2,
      currentHp: selectedDisciple.maxHp || 100 + selectedDisciple.combatPower * 2,
      maxEnergy: 100,
      currentEnergy: 50,
      isForeign: false,
      sectName: 'Mystic Daoist Temple',
      avatarStyle: {
        ...selectedDisciple.avatarStyle,
        appearanceIndex: selectedDisciple.appearanceIndex ?? selectedDisciple.avatarStyle?.appearanceIndex,
        skinTone: selectedDisciple.skinTone ?? selectedDisciple.avatarStyle?.skinTone,
        clothingColor: selectedDisciple.clothingColor ?? selectedDisciple.avatarStyle?.clothingColor,
        hairColor: selectedDisciple.hairColor ?? selectedDisciple.avatarStyle?.hairColor,
        auraEffect: selectedDisciple.auraEffect ?? selectedDisciple.avatarStyle?.auraEffect,
        mythicalForm: selectedDisciple.mythicalForm ?? selectedDisciple.avatarStyle?.mythicalForm
      }
    };

    if (selectedBoosterId === 'booster_dragon_blood') {
      pFighter.maxHp = Math.floor(pFighter.maxHp * 1.25);
      pFighter.currentHp = pFighter.maxHp;
      pFighter.combatPower = Math.floor(pFighter.combatPower * 1.25);
    } else if (selectedBoosterId === 'booster_astral_qi') {
      pFighter.currentEnergy = 90;
    }

    const opps = generateBracketOpponents(selectedDisciple.combatPower);
    setBracketFighters([pFighter, ...opps]);
    setCurrentRound(1);
    setCurrentOpponentIndex(1);
    setHasRecruitedOpponent(false);
    setStage('challenger_preview');
  };

  const currentOpponent = bracketFighters[currentOpponentIndex] || bracketFighters[1];
  const playerFighter = bracketFighters[0];
  const activePlot = ROUND_PLOTS[(currentRound - 1) % ROUND_PLOTS.length];

  const handleStartArenaDuel = () => {
    if (!playerFighter || !currentOpponent) return;

    soundEngine.playGong();
    setStage('arena');
    setBattleLogs([]);
    setIsPaused(false);
    setTurnPhase('player');
    setTurnCount(1);
    setMidPlotTriggered(false);
    setPlayerWardActive(false);
    setStoryBanner(activePlot.rivalryNote);

    const startHp = playerFighter.currentHp > 0 ? playerFighter.currentHp : playerFighter.maxHp;
    setPlayerHp(startHp);
    setPlayerMaxHp(playerFighter.maxHp);
    setPlayerEnergy(playerFighter.currentEnergy);
    setPlayerStatusEffect(null);

    setOpponentHp(currentOpponent.maxHp);
    setOpponentMaxHp(currentOpponent.maxHp);
    setOpponentEnergy(currentOpponent.currentEnergy);
    setOpponentStatusEffect(null);

    setActiveAttackSide(null);
    setActiveHurtSide(null);
    setActiveVfx(null);
    setFloatingPopup(null);

    setSpectatorCheer(`West Terrace roars for ${playerFighter.name}! East Terrace chants for ${currentOpponent.sectName}!`);
  };

  const triggerVfxAndHit = (
    attackerSide: 'player' | 'opponent',
    vfxType: VfxType,
    skillLabel: string,
    popupText: string,
    isCrit = false,
    isHeal = false
  ) => {
    const targetSide: 'player' | 'opponent' =
      vfxType === 'shield' ? attackerSide : attackerSide === 'player' ? 'opponent' : 'player';
    const uid = Date.now() + Math.random();

    setActiveAttackSide(attackerSide);
    if (!isHeal && vfxType !== 'shield') {
      setActiveHurtSide(targetSide);
    }
    setActiveVfx({ id: uid, type: vfxType, target: targetSide, label: skillLabel });
    setFloatingPopup({ id: uid, side: targetSide, text: popupText, isCrit, isHeal });

    if (animTimerRef.current) window.clearTimeout(animTimerRef.current);
    animTimerRef.current = window.setTimeout(() => {
      setActiveAttackSide(null);
      setActiveHurtSide(null);
      setActiveVfx(null);
      setFloatingPopup(null);
    }, Math.max(360, Math.floor(620 / playbackSpeed)));
  };

  const executePlayerMove = (moveType: 'basic' | 'elemental' | 'ward' | 'ultimate') => {
    if (!playerFighter || !currentOpponent || playerHp <= 0 || opponentHp <= 0 || turnPhase !== 'player') return;

    const elem = getElementalMatchup(playerFighter.spiritRoot, currentOpponent.spiritRoot);
    const baseDmg = 18 + Math.random() * 12 + playerFighter.combatPower * 0.14;
    const elemMult = elem.advantageA ? 1.2 : elem.advantageB ? 0.85 : 1.0;

    if (moveType === 'ward') {
      soundEngine.playTalisman();
      const healAmt = Math.floor(playerMaxHp * 0.08);
      const nextHp = Math.min(playerMaxHp, playerHp + healAmt);
      setPlayerHp(nextHp);
      setPlayerEnergy(e => Math.min(100, e + 30));
      setPlayerWardActive(true);
      setPlayerStatusEffect('Jade Ward');

      triggerVfxAndHit('player', 'shield', 'Jade Dao Ward', `+${healAmt} HP · WARD`, false, true);
      setSpectatorCheer(`West Stand gasps: "${playerFighter.name} weaves an impenetrable Jade Ward!"`);
      setBattleLogs(prev => [
        {
          turn: turnCount,
          attacker: playerFighter.name,
          defender: currentOpponent.name,
          skillName: 'Jade Dao Ward',
          actionText: `${playerFighter.name} channels [Jade Ward Stance], recovering ${healAmt} HP & halving the next blow!`,
          damage: 0,
          defenderHpRemaining: opponentHp
        },
        ...prev.slice(0, 18)
      ]);
      setTurnCount(t => t + 1);
      setTurnPhase('opponent');
      return;
    }

    let skillInfo = getTechniqueName(playerFighter.spiritRoot, 'basic');
    let mult = 1.0;
    let energyCost = 0;
    let energyGain = 25;
    let appliedStatus: string | null = null;
    let isCrit = Math.random() < 0.18;

    if (moveType === 'elemental' && playerEnergy >= 35) {
      skillInfo = getTechniqueName(playerFighter.spiritRoot, 'elemental');
      mult = 1.55;
      energyCost = 35;
      energyGain = 0;
      isCrit = Math.random() < 0.25;
      if (playerFighter.spiritRoot === 'Fire') appliedStatus = 'Burn';
      else if (playerFighter.spiritRoot === 'Ice' || playerFighter.spiritRoot === 'Water') appliedStatus = 'Frost';
      else if (playerFighter.spiritRoot === 'Thunder') appliedStatus = 'Paralyze';
    } else if (moveType === 'ultimate' && playerEnergy >= 70) {
      skillInfo = getTechniqueName(playerFighter.spiritRoot, 'ultimate');
      mult = 2.35;
      energyCost = 70;
      energyGain = 0;
      isCrit = true;
      appliedStatus = 'Shattered Guard';
    }

    if (skillInfo.vfx === 'lightning') soundEngine.playThunder();
    else if (skillInfo.vfx === 'fire') soundEngine.playGong();
    else soundEngine.playSwordSlash();

    const finalDmg = Math.max(8, Math.floor(baseDmg * mult * elemMult * (isCrit ? 1.3 : 1.0)));
    const newOppHp = Math.max(0, opponentHp - finalDmg);

    setPlayerEnergy(e => Math.min(100, Math.max(0, e - energyCost + energyGain)));
    if (appliedStatus) setOpponentStatusEffect(appliedStatus);
    setOpponentHp(newOppHp);

    triggerVfxAndHit('player', skillInfo.vfx, skillInfo.name, isCrit ? `CRIT -${finalDmg}` : `-${finalDmg}`, isCrit, false);

    if (!midPlotTriggered && newOppHp > 0 && newOppHp <= opponentMaxHp * 0.52) {
      setMidPlotTriggered(true);
      setStoryBanner(`⚡ Plot Twist: ${activePlot.midDuelTwist}`);
    }

    if (isCrit) {
      setSpectatorCheer(`West Stand erupts in thunderous applause! "[${skillInfo.name}] shook the mountain peak!"`);
    }

    setBattleLogs(prev => [
      {
        turn: turnCount,
        attacker: playerFighter.name,
        defender: currentOpponent.name,
        skillName: skillInfo.name,
        actionText: `${playerFighter.name} unleashes [${skillInfo.name}]!${appliedStatus ? ` (${appliedStatus})` : ''}${elem.advantageA ? ' [Elemental Crush]' : ''}`,
        damage: finalDmg,
        crit: isCrit,
        statusEffectApplied: appliedStatus || undefined,
        defenderHpRemaining: newOppHp
      },
      ...prev.slice(0, 18)
    ]);

    if (newOppHp <= 0) {
      handleRoundEnded(true);
    } else {
      setTurnCount(t => t + 1);
      setTurnPhase('opponent');
    }
  };

  const executeOpponentMove = () => {
    if (!playerFighter || !currentOpponent || playerHp <= 0 || opponentHp <= 0) return;

    const elem = getElementalMatchup(playerFighter.spiritRoot, currentOpponent.spiritRoot);
    const useUltimate = opponentEnergy >= 70;
    const useElemental = !useUltimate && opponentEnergy >= 35;
    const tier: 'basic' | 'elemental' | 'ultimate' = useUltimate ? 'ultimate' : useElemental ? 'elemental' : 'basic';
    const skillInfo = getTechniqueName(currentOpponent.spiritRoot, tier);

    let dmg = 14 + Math.random() * 11 + currentOpponent.combatPower * 0.12;
    if (tier === 'elemental') dmg *= 1.45;
    if (tier === 'ultimate') dmg *= 1.95;
    if (elem.advantageB) dmg *= 1.18;
    if (selectedBoosterId === 'booster_golden_ward') dmg *= 0.78;
    if (playerWardActive) {
      dmg *= 0.5;
      setPlayerWardActive(false);
    }

    const finalDmg = Math.max(5, Math.floor(dmg));
    const cost = tier === 'ultimate' ? 70 : tier === 'elemental' ? 35 : 0;
    const gain = tier === 'basic' ? 22 : 0;
    setOpponentEnergy(e => Math.min(100, Math.max(0, e - cost + gain)));

    if (skillInfo.vfx === 'lightning') soundEngine.playThunder();
    else soundEngine.playTalisman();

    const newPlayerHp = Math.max(0, playerHp - finalDmg);
    setPlayerHp(newPlayerHp);

    if (tier !== 'basic') {
      const st = currentOpponent.spiritRoot === 'Fire' ? 'Scorched' : currentOpponent.spiritRoot === 'Ice' ? 'Chilled' : 'Pressed';
      setPlayerStatusEffect(st);
    }

    triggerVfxAndHit('opponent', skillInfo.vfx, skillInfo.name, `-${finalDmg}${playerWardActive ? ' (WARD)' : ''}`, tier === 'ultimate', false);

    if (!midPlotTriggered && newPlayerHp > 0 && newPlayerHp <= playerMaxHp * 0.52) {
      setMidPlotTriggered(true);
      setStoryBanner(`⚡ Plot Twist: ${activePlot.midDuelTwist}`);
    }

    if (tier !== 'basic') {
      setSpectatorCheer(`East Stand cheers: "${currentOpponent.name} strikes back with [${skillInfo.name}]!"`);
    }

    setBattleLogs(prev => [
      {
        turn: turnCount,
        attacker: currentOpponent.name,
        defender: playerFighter.name,
        skillName: skillInfo.name,
        actionText: `${currentOpponent.name} counters with [${skillInfo.name}]!`,
        damage: finalDmg,
        defenderHpRemaining: newPlayerHp
      },
      ...prev.slice(0, 18)
    ]);

    if (newPlayerHp <= 0) {
      handleRoundEnded(false);
    } else {
      setTurnCount(t => t + 1);
      setTurnPhase('player');
    }
  };

  // Automatic turn progression loop
  useEffect(() => {
    if (stage !== 'arena' || isPaused || playerHp <= 0 || opponentHp <= 0) return;

    // In Manual mode, pause on player's turn waiting for skill selection
    if (!isAutoPlay && turnPhase === 'player') return;

    const baseDelay = Math.floor(920 / playbackSpeed);
    const timer = window.setTimeout(() => {
      if (turnPhase === 'player') {
        if (playerEnergy >= 70) executePlayerMove('ultimate');
        else if (playerEnergy >= 35) executePlayerMove('elemental');
        else executePlayerMove('basic');
      } else {
        executeOpponentMove();
      }
    }, baseDelay);

    return () => window.clearTimeout(timer);
  }, [stage, isPaused, isAutoPlay, turnPhase, playbackSpeed, turnCount, playerHp, opponentHp, playerEnergy, opponentEnergy]);

  const handleRoundEnded = (playerWon: boolean) => {
    if (playerWon) {
      soundEngine.playFanfare();
      if (currentRound >= 5 || currentOpponentIndex >= bracketFighters.length - 1) {
        setIsPlayerChampion(true);
        setTournamentWinner(playerFighter);
        setStage('tournament_ended');
      } else {
        // Carry over remaining HP (+20% rest recovery) into fighter object
        setBracketFighters(prev => {
          const pf = { ...prev[0] };
          pf.currentHp = Math.min(pf.maxHp, Math.max(Math.floor(pf.maxHp * 0.45), playerHp + Math.floor(pf.maxHp * 0.2)));
          pf.currentEnergy = Math.max(45, playerEnergy);
          return [pf, ...prev.slice(1)];
        });

        if (!isAutoPlay) {
          setStage('round_reward');
        } else {
          setCurrentRound(r => r + 1);
          setCurrentOpponentIndex(i => Math.min(bracketFighters.length - 1, i + 1));
          setStage('challenger_preview');
        }
      }
    } else {
      soundEngine.playThunder();
      setIsPlayerChampion(false);
      setTournamentWinner(currentOpponent);
      setStage('tournament_ended');
    }
  };

  const handleApplyTacticalBoost = (type: 'heal' | 'energy' | 'shield') => {
    soundEngine.playTalisman();
    setBracketFighters(prev => {
      const pf = { ...prev[0] };
      if (type === 'heal') {
        pf.currentHp = pf.maxHp;
      } else if (type === 'energy') {
        pf.currentEnergy = 100;
      } else if (type === 'shield') {
        pf.combatPower = Math.floor(pf.combatPower * 1.12);
        pf.currentHp = Math.min(pf.maxHp, pf.currentHp + Math.floor(pf.maxHp * 0.25));
      }
      return [pf, ...prev.slice(1)];
    });

    setCurrentRound(r => r + 1);
    setCurrentOpponentIndex(i => Math.min(bracketFighters.length - 1, i + 1));
    setStage('challenger_preview');
  };

  const handleClaimGrandVictory = () => {
    if (!selectedDisciple) return;

    let title: ChampionTitle = 'Champion I';
    let promoRank: 'Inner' | 'Elder' | 'Grand Elder' | 'Sect Leader' | undefined = undefined;

    if (selectedCategory === 'InnerPromotion') {
      title = 'Champion I';
      promoRank = 'Inner';
    } else if (selectedCategory === 'ElderChallenge') {
      title = 'Champion I';
      promoRank = 'Elder';
    } else if (selectedCategory === 'LeaderChallenge') {
      title = 'Champion II';
      promoRank = 'Sect Leader';
    } else if (selectedCategory === 'AllSectsUniversal') {
      title = 'Champion S';
    }

    onCrownChampion(selectedDisciple.id, title, true, promoRank);
    onClose();
  };

  const handleRecruitDefeated = () => {
    if (!hasRecruitedOpponent && tournamentWinner && tournamentWinner.isForeign) {
      soundEngine.playGong();
      if (onRecruitDefeatedOpponent) {
        onRecruitDefeatedOpponent(tournamentWinner);
      }
      setHasRecruitedOpponent(true);
    }
  };

  const renderArenaVfxOverlay = () => {
    if (!activeVfx) return null;

    return (
      <motion.div
        key={activeVfx.id}
        initial={{ opacity: 0, scale: 0.7 }}
        animate={{ opacity: [0, 1, 1, 0], scale: [0.75, 1.08, 1.15, 1.25] }}
        transition={{ duration: Math.max(0.35, 0.62 / playbackSpeed), ease: 'easeOut' }}
        className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center"
      >
        {/* Technique Name Banner */}
        <div className="px-3 py-1 rounded-full bg-black/80 border border-amber-400/60 text-[#fce18b] font-dao font-bold text-[11px] shadow-xl mb-1 tracking-wide">
          ✦ {activeVfx.label} ✦
        </div>

        {/* SVG Technique Choreography */}
        {activeVfx.type === 'sword' && (
          <svg viewBox="0 0 180 120" className="w-40 h-28 drop-shadow-[0_0_12px_rgba(253,224,71,0.85)]">
            <path d="M 20,100 Q 90,45 160,18" stroke="#fef08a" strokeWidth="6" strokeLinecap="round" fill="none" />
            <path d="M 35,20 Q 95,55 155,95" stroke="#38bdf8" strokeWidth="5" strokeLinecap="round" fill="none" />
            <circle cx="90" cy="60" r="14" fill="none" stroke="#ffffff" strokeWidth="2.5" strokeDasharray="6 4" />
          </svg>
        )}

        {activeVfx.type === 'lightning' && (
          <svg viewBox="0 0 180 120" className="w-44 h-28 drop-shadow-[0_0_14px_rgba(56,189,248,0.95)]">
            <polyline points="82,4 64,46 92,48 68,94 112,50 86,48 104,6" fill="#e0f2fe" stroke="#38bdf8" strokeWidth="3" />
            <path d="M 40,22 L 62,52 L 50,55 L 70,84" stroke="#facc15" strokeWidth="3" fill="none" strokeLinecap="round" />
            <ellipse cx="86" cy="96" rx="45" ry="10" fill="rgba(56,189,248,0.28)" stroke="#7dd3fc" strokeWidth="1.5" />
          </svg>
        )}

        {activeVfx.type === 'fire' && (
          <svg viewBox="0 0 180 120" className="w-44 h-28 drop-shadow-[0_0_16px_rgba(249,115,22,0.95)]">
            <circle cx="90" cy="62" r="34" fill="rgba(239,68,68,0.25)" stroke="#fb923c" strokeWidth="4" strokeDasharray="10 5" />
            <path d="M 90,14 C 110,42 126,64 108,92 C 98,105 82,105 72,92 C 54,64 70,42 90,14 Z" fill="rgba(251,146,60,0.45)" stroke="#fef08a" strokeWidth="2.5" />
          </svg>
        )}

        {activeVfx.type === 'ice' && (
          <svg viewBox="0 0 180 120" className="w-44 h-28 drop-shadow-[0_0_14px_rgba(125,211,252,0.9)]">
            <polygon points="90,12 104,58 90,104 76,58" fill="rgba(186,230,253,0.5)" stroke="#bae6fd" strokeWidth="2.5" />
            <polygon points="44,44 90,56 136,44 90,72" fill="rgba(56,189,248,0.35)" stroke="#e0f2fe" strokeWidth="2" />
            <circle cx="90" cy="58" r="24" fill="none" stroke="#7dd3fc" strokeWidth="2" strokeDasharray="4 4" />
          </svg>
        )}

        {activeVfx.type === 'wind' && (
          <svg viewBox="0 0 180 120" className="w-44 h-28 drop-shadow-[0_0_14px_rgba(52,211,153,0.85)]">
            <ellipse cx="90" cy="60" rx="52" ry="18" fill="none" stroke="#34d399" strokeWidth="3.5" strokeDasharray="18 8" />
            <ellipse cx="90" cy="60" rx="34" ry="11" fill="none" stroke="#a7f3d0" strokeWidth="2.5" />
            <path d="M 30,86 Q 90,26 150,76" stroke="#6ee7b7" strokeWidth="3" fill="none" />
          </svg>
        )}

        {activeVfx.type === 'shield' && (
          <svg viewBox="0 0 180 120" className="w-40 h-28 drop-shadow-[0_0_14px_rgba(250,204,21,0.9)]">
            <polygon points="90,14 134,36 134,76 90,104 46,76 46,36" fill="rgba(250,204,21,0.18)" stroke="#fde047" strokeWidth="3" />
            <circle cx="90" cy="58" r="20" fill="none" stroke="#fef08a" strokeWidth="2" strokeDasharray="5 3" />
          </svg>
        )}
      </motion.div>
    );
  };

  const canRecruitCondition = sectPrestige >= 100 || devMode;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/80 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh] relative">
        {/* Sticky Header */}
        <div className="sticky top-0 z-30 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2.5 min-w-0">
            <Trophy className="w-5 h-5 text-[#fce18b] shrink-0" />
            <div className="min-w-0">
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b] flex items-center gap-2 flex-wrap">
                <span>Peak Challenge Grand Tournament</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-950/80 text-amber-300 border border-amber-500/40 font-mono">
                  Round {currentRound}/5
                </span>
              </h3>
              <p className="text-[11px] text-[#9fc2b2] truncate">
                Monthly martial arena where disciples duel for Champion titles and heavenly destiny.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Close Arena"
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-3.5 sm:p-4 overflow-y-auto space-y-4 grow text-xs text-[#d1e6dc]">
          {/* STAGE 1: ROSTER & BOOSTERS */}
          {stage === 'roster' && (
            <div className="space-y-4 animate-fade-in">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {[
                  { id: 'AllSectsUniversal' as const, label: 'All Sects Universal', desc: 'Open to all disciples' },
                  { id: 'InnerPromotion' as const, label: 'Inner Promotion', desc: 'Outer disciples only' },
                  { id: 'ElderChallenge' as const, label: 'Elder Challenge', desc: 'Inner/Direct only' },
                  { id: 'LeaderChallenge' as const, label: 'Leader Challenge', desc: 'Elder/Grand Elder only' }
                ].map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      soundEngine.playClick();
                      setSelectedCategory(cat.id);
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      selectedCategory === cat.id
                        ? 'bg-[#184838] border-[#e2b054] text-[#fce18b] shadow-md font-bold'
                        : 'bg-[#09261d] border-[#1b4b3b] text-[#86a89b] hover:border-[#225e4c]'
                    }`}
                  >
                    <div className="text-[11px] font-bold truncate">{cat.label}</div>
                    <div className="text-[9px] text-[#9fc2b2] mt-0.5 line-clamp-1">{cat.desc}</div>
                  </button>
                ))}
              </div>

              <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-2.5">
                <span className="font-bold text-white block">1. Select Your Sect Champion Candidate</span>
                {eligibleDisciples.length === 0 ? (
                  <div className="text-center py-4 text-[#9fc2b2] italic">
                    No disciples currently meet the rank requirements for this division.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                    {eligibleDisciples.map(d => {
                      const realm = CULTIVATION_REALMS[d.currentRealmIndex];
                      const isSelected = d.id === selectedDiscipleId;
                      return (
                        <div
                          key={d.id}
                          onClick={() => {
                            soundEngine.playClick();
                            setSelectedDiscipleId(d.id);
                          }}
                          className={`p-2 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-[#184838] border-[#e2b054] shadow-sm'
                              : 'bg-[#123d30] border-[#1b4b3b] hover:border-[#23604f]'
                          }`}
                        >
                          <CultivatorAvatar
                            gender={d.gender}
                            rank={d.rank}
                            spiritRoot={d.spiritRoot}
                            realmIndex={d.currentRealmIndex}
                            appearanceIndex={d.appearanceIndex ?? d.avatarStyle?.appearanceIndex}
                            skinTone={d.skinTone ?? d.avatarStyle?.skinTone}
                            clothingColor={d.clothingColor ?? d.avatarStyle?.clothingColor}
                            hairColor={d.hairColor ?? d.avatarStyle?.hairColor}
                            expression={d.expression ?? d.avatarStyle?.expression}
                            auraEffect={d.auraEffect ?? d.avatarStyle?.auraEffect}
                            mythicalForm={d.mythicalForm ?? d.avatarStyle?.mythicalForm}
                            size="sm"
                          />
                          <div className="min-w-0 grow">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-bold text-[#fce18b] truncate text-[11px]">{d.name}</span>
                              {d.championTitle && <ChampionTitleBadge title={d.championTitle} size="sm" />}
                            </div>
                            <div className="text-[10px] text-[#86a89b] truncate">{realm?.name}</div>
                            <div className="text-[9px] text-[#38bdf8] font-mono">Combat Power: {d.combatPower}</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-2.5">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white">2. Select Pre-Match Booster (Optional)</span>
                  <span className="text-[10px] text-[#9fc2b2]">Empower battle attributes</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {TOURNAMENT_BOOSTERS.map(booster => {
                    const isSelected = selectedBoosterId === booster.id;
                    return (
                      <div
                        key={booster.id}
                        onClick={() => {
                          soundEngine.playClick();
                          setSelectedBoosterId(isSelected ? null : booster.id);
                        }}
                        className={`p-2 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-[#184838] border-[#e2b054] shadow-sm'
                            : 'bg-[#123d30] border-[#1b4b3b] hover:border-[#23604f]'
                        }`}
                      >
                        <div className="font-bold text-[11px] text-[#fce18b] truncate">{booster.name}</div>
                        <div className="text-[9px] text-[#9fc2b2] mt-0.5 line-clamp-2">{booster.description}</div>
                        <div className="mt-1 text-[9px] font-mono text-emerald-400 font-bold">{booster.effectDescription}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {selectedDisciple && (
                <button
                  onClick={handleProceedToChallengerPreview}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-sm flex items-center justify-center gap-2 shadow-lg hover:brightness-110 transition-all"
                >
                  <Swords className="w-4 h-4" />
                  <span>Inspect Bracket & Enter Peak Gauntlet</span>
                </button>
              )}
            </div>
          )}

          {/* STAGE 2: CHALLENGER PREVIEW & PLOT INTRO */}
          {stage === 'challenger_preview' && currentOpponent && selectedDisciple && (
            <div className="space-y-4 animate-fade-in">
              <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] flex justify-between items-center gap-2">
                <div>
                  <div className="font-bold text-white text-xs">{activePlot.title}</div>
                  <div className="text-[10px] text-[#9fc2b2]">Round {currentRound} of 5 · Last Cultivator Standing</div>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-[#123d30] text-[#fce18b] border border-[#e2b054]/30 shrink-0">
                  4-Seed Bracket
                </span>
              </div>

              {/* Plot Dialogue Card */}
              <div className="bg-amber-950/35 border border-amber-500/40 rounded-2xl p-3 space-y-1">
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-amber-300 uppercase tracking-wider">
                  <ScrollText className="w-3.5 h-3.5" />
                  <span>Arena Chronicle & Challenger Decree</span>
                </div>
                <p className="text-xs italic text-[#fce18b] leading-relaxed">{activePlot.introQuote}</p>
                <p className="text-[10px] text-[#a4c5b7]">{activePlot.rivalryNote}</p>
              </div>

              {/* Challenger Card */}
              <div className="bg-gradient-to-b from-[#0e3427] to-[#071d15] p-4 rounded-3xl border-2 border-[#e2b054]/50 shadow-xl space-y-3">
                <div className="flex justify-between items-start gap-2">
                  <div className="flex items-center gap-3 min-w-0">
                    <CultivatorAvatar
                      gender={currentOpponent.gender}
                      rank={currentOpponent.rank}
                      spiritRoot={currentOpponent.spiritRoot}
                      realmIndex={currentOpponent.currentRealmIndex}
                      appearanceIndex={currentOpponent.avatarStyle?.appearanceIndex}
                      skinTone={currentOpponent.avatarStyle?.skinTone}
                      clothingColor={currentOpponent.avatarStyle?.clothingColor}
                      hairColor={currentOpponent.avatarStyle?.hairColor}
                      expression={currentRound >= 3 ? 'Fierce' : 'Stoic'}
                      auraEffect={currentOpponent.avatarStyle?.auraEffect}
                      mythicalForm={currentOpponent.avatarStyle?.mythicalForm}
                      size="md"
                    />
                    <div className="min-w-0">
                      <h4 className="font-dao font-bold text-sm sm:text-base text-red-300 truncate">
                        {currentOpponent.name}
                      </h4>
                      <div className="text-[11px] text-[#a4c5b7]">
                        Realm: {CULTIVATION_REALMS[currentOpponent.currentRealmIndex]?.name}
                      </div>
                      <div className="text-[10px] text-[#38bdf8]">
                        Sect: {currentOpponent.sectName || 'Rogue Immortal'}
                      </div>
                    </div>
                  </div>

                  {devMode ? (
                    <div className="p-2 rounded-xl bg-purple-950/80 border border-purple-400/50 text-right shrink-0">
                      <div className="text-[9px] text-purple-300 font-mono">DEV MODE INTEL</div>
                      <div className="text-xs font-bold text-yellow-300 font-mono">
                        Win: {calculateWinProbability(playerFighter?.combatPower || selectedDisciple.combatPower, currentOpponent.combatPower, selectedDisciple.spiritRoot, currentOpponent.spiritRoot)}%
                      </div>
                      <div className="text-[9px] text-[#9fc2b2] font-mono">Power: {currentOpponent.combatPower}</div>
                    </div>
                  ) : (
                    <div className="text-right text-[10px] text-[#7ea091] shrink-0">
                      <div>Alignment: Neutral Rival</div>
                      <div className="text-[9px] text-amber-300/80 mt-0.5">Detailed power veiled by Dao</div>
                    </div>
                  )}
                </div>

                <div className="pt-2 border-t border-[#1b4b3b] flex items-center justify-between text-[11px]">
                  <span className="text-[#9fc2b2]">Elemental Affinity: <strong className="text-white">{currentOpponent.spiritRoot} Root</strong></span>
                  <span className="text-[#e2b054] font-bold">Round {currentRound} Bout</span>
                </div>
              </div>

              {/* Auto vs Manual Mode Selector */}
              <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] flex justify-between items-center text-xs gap-2">
                <div>
                  <div className="font-bold text-white">Combat Control Mode</div>
                  <div className="text-[10px] text-[#9fc2b2]">
                    {isAutoPlay
                      ? 'Auto: Continuous animated duel pacing'
                      : 'Manual: Choose martial arts & elemental skills every turn + tactical blessings'}
                  </div>
                </div>

                <div className="flex items-center gap-1 bg-[#123d30] p-1 rounded-xl border border-[#1b4b3b] shrink-0">
                  <button
                    onClick={() => setIsAutoPlay(true)}
                    className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all ${
                      isAutoPlay ? 'bg-[#15803d] text-white shadow-xs' : 'text-[#8daea0]'
                    }`}
                  >
                    Auto
                  </button>
                  <button
                    onClick={() => setIsAutoPlay(false)}
                    className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all ${
                      !isAutoPlay ? 'bg-[#15803d] text-white shadow-xs' : 'text-[#8daea0]'
                    }`}
                  >
                    Manual
                  </button>
                </div>
              </div>

              <button
                onClick={handleStartArenaDuel}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 via-amber-600 to-yellow-500 text-white font-dao font-bold text-sm flex items-center justify-center gap-2 shadow-xl hover:brightness-110 transition-all"
              >
                <Swords className="w-4 h-4" />
                <span>Enter the Arena Ring</span>
              </button>
            </div>
          )}

          {/* STAGE 3: ANIMATED TURN-BY-TURN ARENA DUEL */}
          {stage === 'arena' && playerFighter && currentOpponent && (
            <div className="space-y-3 animate-fade-in">
              {/* Top Controls */}
              <div className="flex justify-between items-center bg-[#09261d] p-2 rounded-2xl border border-[#1b4b3b] gap-2">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setIsPaused(!isPaused)}
                    className="p-1.5 rounded-lg bg-[#123d30] text-[#fce18b] border border-[#e2b054]/40 hover:bg-[#184838] min-w-[32px] min-h-[32px] flex items-center justify-center"
                    title={isPaused ? 'Resume Simulation' : 'Pause Simulation'}
                  >
                    {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                  </button>

                  <button
                    onClick={() => setPlaybackSpeed(s => (s === 1 ? 2 : s === 2 ? 3 : 1))}
                    className="px-2 py-1 rounded-lg bg-[#123d30] text-[#fce18b] border border-[#e2b054]/40 text-[10px] font-mono font-bold flex items-center gap-1 hover:bg-[#184838]"
                    title="Simulation Speed"
                  >
                    <FastForward className="w-3 h-3" />
                    <span>{playbackSpeed}x</span>
                  </button>
                </div>

                <div className="text-[10px] text-[#fce18b] font-bold font-dao flex items-center gap-1 truncate">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="truncate">Round {currentRound} · Turn {turnCount}</span>
                </div>

                <button
                  onClick={() => setIsAutoPlay(a => !a)}
                  className={`text-[10px] font-mono px-2.5 py-1 rounded-lg border transition-colors ${
                    isAutoPlay
                      ? 'bg-[#123d30] text-[#86efac] border-[#1f624d]'
                      : 'bg-amber-950/70 text-[#fce18b] border-amber-500/50'
                  }`}
                >
                  {isAutoPlay ? 'Auto' : 'Manual'}
                </button>
              </div>

              {/* Story Narrative Ticker */}
              {storyBanner && (
                <div className="bg-[#09261d] border border-amber-500/35 rounded-xl px-3 py-1.5 text-[10px] text-amber-200 flex items-center gap-1.5">
                  <ScrollText className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="truncate">{storyBanner}</span>
                </div>
              )}

              {/* Central Battle Ring with Spectators & Choreography */}
              <div className="relative bg-gradient-to-b from-[#061711] via-[#0b281f] to-[#04100b] p-3 sm:p-4 rounded-3xl border-2 border-[#e2b054]/60 shadow-2xl overflow-hidden">
                {/* 2-Sided Spectators */}
                <div className="flex flex-col sm:flex-row justify-between items-center text-[9px] text-[#86efac] font-medium border-b border-[#1b4b3b]/60 pb-1.5 mb-3 gap-1">
                  <span className="flex items-center gap-1 truncate max-w-full">
                    <Users className="w-3 h-3 text-emerald-400 shrink-0" />
                    <span className="truncate">{spectatorCheer}</span>
                  </span>
                  <span className="text-[9px] text-amber-300/80 font-mono shrink-0">
                    {turnPhase === 'player' ? 'Player Turn' : 'Challenger Turn'}
                  </span>
                </div>

                {/* Animated VFX Overlay */}
                <AnimatePresence>{renderArenaVfxOverlay()}</AnimatePresence>

                {/* Combatants Grid */}
                <div className="grid grid-cols-7 gap-1 items-center text-center relative">
                  {/* Player Fighter */}
                  <div className="col-span-3 flex flex-col items-center relative">
                    <AnimatePresence>
                      {floatingPopup?.side === 'player' && (
                        <motion.div
                          key={floatingPopup.id}
                          initial={{ opacity: 0, y: 8, scale: 0.8 }}
                          animate={{ opacity: 1, y: -16, scale: 1.05 }}
                          exit={{ opacity: 0, y: -28 }}
                          className={`absolute -top-2 z-30 px-2 py-0.5 rounded-full text-[10px] font-mono font-black shadow-lg ${
                            floatingPopup.isHeal
                              ? 'bg-emerald-900/90 text-emerald-200 border border-emerald-400'
                              : 'bg-red-950/90 text-red-200 border border-red-400'
                          }`}
                        >
                          {floatingPopup.text}
                        </motion.div>
                      )}
                    </AnimatePresence>

                    <motion.div
                      animate={
                        activeAttackSide === 'player'
                          ? { x: 40, y: -6, scale: 1.08 }
                          : { x: 0, y: 0, scale: 1 }
                      }
                      transition={{ type: 'spring', stiffness: 320, damping: 18 }}
                      className={activeHurtSide === 'player' ? 'animate-hit-shake' : ''}
                    >
                      <CultivatorAvatar
                        gender={playerFighter.gender}
                        rank={playerFighter.rank}
                        spiritRoot={playerFighter.spiritRoot}
                        realmIndex={playerFighter.currentRealmIndex}
                        appearanceIndex={playerFighter.avatarStyle?.appearanceIndex}
                        skinTone={playerFighter.avatarStyle?.skinTone}
                        clothingColor={playerFighter.avatarStyle?.clothingColor}
                        hairColor={playerFighter.avatarStyle?.hairColor}
                        expression="Fierce"
                        auraEffect={playerFighter.avatarStyle?.auraEffect}
                        mythicalForm={playerFighter.avatarStyle?.mythicalForm}
                        size="md"
                      />
                    </motion.div>

                    <div className="font-bold text-[#fce18b] text-[11px] mt-1 truncate max-w-[120px]">
                      {playerFighter.name}
                    </div>
                    <div className="flex items-center gap-1 min-h-[16px]">
                      {playerStatusEffect && (
                        <span className="text-[9px] px-1.5 rounded bg-amber-900 text-amber-200 border border-amber-500 font-mono">
                          {playerStatusEffect}
                        </span>
                      )}
                      {playerWardActive && (
                        <span className="text-[9px] px-1.5 rounded bg-yellow-900 text-yellow-200 border border-yellow-400 font-mono">
                          Shielded
                        </span>
                      )}
                    </div>

                    <div className="w-full bg-[#184838] h-2.5 rounded-full mt-1 overflow-hidden border border-[#276e57]">
                      <div
                        className="bg-emerald-500 h-full transition-all duration-300"
                        style={{ width: `${Math.max(0, (playerHp / playerMaxHp) * 100)}%` }}
                      />
                    </div>
                    <span className="text-[9px] font-mono text-emerald-400 mt-0.5 tabular-nums">
                      HP {playerHp}/{playerMaxHp}
                    </span>

                    <div className="w-full bg-[#103025] h-1.5 rounded-full mt-1 overflow-hidden border border-[#1b4b3b]">
                      <div
                        className="bg-cyan-400 h-full transition-all duration-300"
                        style={{ width: `${playerEnergy}%` }}
                      />
                    </div>
                    <span className="text-[8px] font-mono text-cyan-300 tabular-nums">Qi {playerEnergy}/100</span>
                  </div>

                  {/* Center VS */}
                  <div className="col-span-1 flex flex-col items-center justify-center">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-600 to-red-600 flex items-center justify-center shadow-lg border border-yellow-300 font-dao font-black text-white text-[11px]">
                      VS
                    </div>
                  </div>

                  {/* Opponent Fighter */}
                  <div className="col-span-3 flex flex-col items-center relative">
                    <AnimatePresence>
                      {floatingPopup?.side === 'opponent' && (
                        <motion.div
                          key={floatingPopup.id}
                          initial={{ opacity: 0, y: 8, scale: 0.8 }}
                          animate={{ opacity: 1, y: -16, scale: 1.1 }}
                          exit={{ opacity: 0, y: -28 }}
                          className={`absolute -top-2 z-30 px-2 py-0.5 rounded-full text-[10px] font-mono font-black shadow-lg ${
                            floatingPopup.isCrit
                              ? 'bg-amber-600 text-white border border-yellow-200'
                              : 'bg-red-950/90 text-red-200 border border-red-400'
                          }`}
                        >
                          {floatingPopup.text}
                        </motion.div>
                      )}
                    </AnimatePresence>

                    <motion.div
                      animate={
                        activeAttackSide === 'opponent'
                          ? { x: -40, y: -6, scale: 1.08 }
                          : { x: 0, y: 0, scale: 1 }
                      }
                      transition={{ type: 'spring', stiffness: 320, damping: 18 }}
                      className={activeHurtSide === 'opponent' ? 'animate-hit-shake' : ''}
                    >
                      <CultivatorAvatar
                        gender={currentOpponent.gender}
                        rank={currentOpponent.rank}
                        spiritRoot={currentOpponent.spiritRoot}
                        realmIndex={currentOpponent.currentRealmIndex}
                        appearanceIndex={currentOpponent.avatarStyle?.appearanceIndex}
                        skinTone={currentOpponent.avatarStyle?.skinTone}
                        clothingColor={currentOpponent.avatarStyle?.clothingColor}
                        hairColor={currentOpponent.avatarStyle?.hairColor}
                        expression="Smirk"
                        auraEffect={currentOpponent.avatarStyle?.auraEffect}
                        mythicalForm={currentOpponent.avatarStyle?.mythicalForm}
                        size="md"
                      />
                    </motion.div>

                    <div className="font-bold text-red-300 text-[11px] mt-1 truncate max-w-[120px]">
                      {currentOpponent.name}
                    </div>
                    <div className="min-h-[16px]">
                      {opponentStatusEffect && (
                        <span className="text-[9px] px-1.5 rounded bg-red-950 text-red-200 border border-red-500 font-mono">
                          {opponentStatusEffect}
                        </span>
                      )}
                    </div>

                    <div className="w-full bg-[#3b1212] h-2.5 rounded-full mt-1 overflow-hidden border border-[#5c1c1c]">
                      <div
                        className="bg-red-500 h-full transition-all duration-300"
                        style={{ width: `${Math.max(0, (opponentHp / opponentMaxHp) * 100)}%` }}
                      />
                    </div>
                    <span className="text-[9px] font-mono text-red-400 mt-0.5 tabular-nums">
                      HP {opponentHp}/{opponentMaxHp}
                    </span>

                    <div className="w-full bg-[#3b1212] h-1.5 rounded-full mt-1 overflow-hidden border border-[#5c1c1c]">
                      <div
                        className="bg-amber-400 h-full transition-all duration-300"
                        style={{ width: `${opponentEnergy}%` }}
                      />
                    </div>
                    <span className="text-[8px] font-mono text-amber-300 tabular-nums">Qi {opponentEnergy}/100</span>
                  </div>
                </div>

                {/* Manual Mode Interactive Technique Selector */}
                {!isAutoPlay && turnPhase === 'player' && !isPaused && playerHp > 0 && opponentHp > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-[#1b4b3b] space-y-2">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="font-bold text-[#fce18b]">Choose Martial Technique:</span>
                      <button
                        onClick={() => executePlayerMove(playerEnergy >= 70 ? 'ultimate' : playerEnergy >= 35 ? 'elemental' : 'basic')}
                        className="text-[10px] text-emerald-300 hover:underline font-mono"
                      >
                        Quick Strike
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        onClick={() => executePlayerMove('basic')}
                        className="p-2 rounded-xl bg-[#123d30] hover:bg-[#195443] border border-[#246652] text-left transition-all"
                      >
                        <div className="font-bold text-[10px] text-sky-200 flex items-center gap-1">
                          <Swords className="w-3 h-3" />
                          <span>Swift Qi Strike</span>
                        </div>
                        <div className="text-[9px] text-[#9fc2b2]">Basic slash · +25 Qi</div>
                      </button>

                      <button
                        disabled={playerEnergy < 35}
                        onClick={() => executePlayerMove('elemental')}
                        className={`p-2 rounded-xl border text-left transition-all ${
                          playerEnergy >= 35
                            ? 'bg-amber-950/60 hover:bg-amber-900/70 border-amber-500/60'
                            : 'bg-[#09261d] border-[#173c30] opacity-45 cursor-not-allowed'
                        }`}
                      >
                        <div className="font-bold text-[10px] text-amber-200 flex items-center gap-1">
                          {playerFighter.spiritRoot === 'Fire' ? <Flame className="w-3 h-3" /> :
                           playerFighter.spiritRoot === 'Ice' ? <Snowflake className="w-3 h-3" /> :
                           playerFighter.spiritRoot === 'Wind' ? <Wind className="w-3 h-3" /> :
                           <Zap className="w-3 h-3" />}
                          <span>{playerFighter.spiritRoot} Art</span>
                        </div>
                        <div className="text-[9px] text-amber-300/80">1.55x DMG + Status · 35 Qi</div>
                      </button>

                      <button
                        onClick={() => executePlayerMove('ward')}
                        className="p-2 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/70 border border-emerald-500/50 text-left transition-all"
                      >
                        <div className="font-bold text-[10px] text-emerald-200 flex items-center gap-1">
                          <Shield className="w-3 h-3" />
                          <span>Jade Ward Stance</span>
                        </div>
                        <div className="text-[9px] text-emerald-300/80">Halve next hit + Heal · +30 Qi</div>
                      </button>

                      <button
                        disabled={playerEnergy < 70}
                        onClick={() => executePlayerMove('ultimate')}
                        className={`p-2 rounded-xl border text-left transition-all ${
                          playerEnergy >= 70
                            ? 'bg-gradient-to-r from-red-900/80 to-amber-900/80 hover:brightness-110 border-yellow-400/70 shadow-md'
                            : 'bg-[#09261d] border-[#173c30] opacity-45 cursor-not-allowed'
                        }`}
                      >
                        <div className="font-bold text-[10px] text-[#fce18b] flex items-center gap-1">
                          <Sparkles className="w-3 h-3" />
                          <span>Heaven-Shattering Art</span>
                        </div>
                        <div className="text-[9px] text-yellow-200/85">2.35x Crit Finisher · 70 Qi</div>
                      </button>
                    </div>
                  </div>
                )}

                {/* Battle Log */}
                <div className="bg-[#051711] p-2.5 rounded-2xl border border-[#164738] h-28 overflow-y-auto space-y-1 text-[10px] font-mono mt-3">
                  {battleLogs.map((log, idx) => (
                    <div key={idx} className="flex items-start gap-1.5">
                      <span className="text-yellow-400 shrink-0">⚔️</span>
                      <span className="text-[#c7ded5] leading-tight grow">{log.actionText}</span>
                      {log.damage > 0 && (
                        <span className="text-red-400 shrink-0 font-bold">(-{log.damage})</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STAGE 4: BETWEEN-ROUND MANUAL TACTICAL BLESSINGS */}
          {stage === 'round_reward' && (
            <div className="bg-[#09261d] p-4 rounded-3xl border-2 border-[#e2b054]/60 space-y-3.5 animate-scale-up text-center">
              <div className="flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 text-[#fce18b]" />
                <h4 className="font-dao font-bold text-base text-[#fce18b]">Round {currentRound} Triumphed!</h4>
              </div>
              <p className="text-[11px] text-[#9fc2b2]">
                Choose 1 tactical support blessing before advancing to Round {currentRound + 1}:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
                <button
                  onClick={() => handleApplyTacticalBoost('heal')}
                  className="p-3 rounded-2xl bg-[#123d30] hover:bg-[#184838] border border-emerald-500/50 text-left space-y-1 transition-all"
                >
                  <div className="font-bold text-emerald-300 text-xs flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5" />
                    <span>Leyline Meditation</span>
                  </div>
                  <div className="text-[10px] text-[#9fc2b2]">Restores 100% Max HP cleanly.</div>
                </button>

                <button
                  onClick={() => handleApplyTacticalBoost('energy')}
                  className="p-3 rounded-2xl bg-[#123d30] hover:bg-[#184838] border border-cyan-500/50 text-left space-y-1 transition-all"
                >
                  <div className="font-bold text-cyan-300 text-xs flex items-center gap-1">
                    <Zap className="w-3.5 h-3.5" />
                    <span>Overload Qi Core</span>
                  </div>
                  <div className="text-[10px] text-[#9fc2b2]">Begins next bout with 100 Qi for instant Ultimates.</div>
                </button>

                <button
                  onClick={() => handleApplyTacticalBoost('shield')}
                  className="p-3 rounded-2xl bg-[#123d30] hover:bg-[#184838] border border-amber-500/50 text-left space-y-1 transition-all"
                >
                  <div className="font-bold text-amber-300 text-xs flex items-center gap-1">
                    <Shield className="w-3.5 h-3.5" />
                    <span>Temper Martial Might</span>
                  </div>
                  <div className="text-[10px] text-[#9fc2b2]">+12% Combat Power & +25% HP recovery.</div>
                </button>
              </div>
            </div>
          )}

          {/* STAGE 5: DRAMATIC ENDING */}
          {stage === 'tournament_ended' && (
            <div className={`p-4 rounded-3xl border-2 text-center space-y-3.5 animate-scale-up ${
              isPlayerChampion
                ? 'bg-gradient-to-r from-emerald-950/90 to-[#123d30] border-emerald-400'
                : 'bg-gradient-to-r from-red-950/90 to-[#2e0e0e] border-red-500'
            }`}>
              <div className="flex items-center justify-center gap-2">
                <Crown className="w-7 h-7 text-yellow-300 animate-bounce" />
                <h4 className="text-lg font-bold font-dao text-[#fce18b]">
                  {isPlayerChampion ? 'Grand Champion of the Peak Arena!' : 'Arena Gauntlet Concluded'}
                </h4>
              </div>

              <p className="text-[11px] text-[#cbe3d7] leading-relaxed max-w-lg mx-auto">
                {isPlayerChampion
                  ? `${selectedDisciple?.name} conquered all 5 Peak Challenge rounds! Bestowed supreme Champion acclaim, elder praise, and immortal prodigy prestige.`
                  : `${tournamentWinner?.name} prevailed in Round ${currentRound}. Your sect earned ${currentRound * 45} Spirit Stones & ${currentRound * 15} Merit for fierce participation.`
                }
              </p>

              {isPlayerChampion ? (
                <div className="space-y-2 pt-2">
                  <button
                    onClick={handleClaimGrandVictory}
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-sm shadow-xl hover:brightness-110 transition-all flex items-center justify-center gap-2"
                  >
                    <Crown className="w-4 h-4" />
                    <span>Bestow Champion Title, Praise & Breakthrough Pill</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2 pt-2">
                  {!hasRecruitedOpponent && tournamentWinner?.isForeign && (
                    <button
                      disabled={!canRecruitCondition}
                      onClick={handleRecruitDefeated}
                      className={`w-full py-2.5 px-4 rounded-xl font-dao font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all ${
                        canRecruitCondition
                          ? 'bg-gradient-to-r from-cyan-700 to-blue-600 hover:brightness-110 text-white'
                          : 'bg-[#09261d] text-[#6d8e80] border border-[#1a4738] cursor-not-allowed'
                      }`}
                    >
                      <UserCheck className="w-4 h-4" />
                      <span>
                        {canRecruitCondition
                          ? `Invite Foreign Champion ${tournamentWinner.name} to Join Sect`
                          : 'Requires 100 Sect Prestige to Invite Foreign Champion'}
                      </span>
                    </button>
                  )}

                  {hasRecruitedOpponent && (
                    <div className="text-xs text-emerald-300 font-bold bg-emerald-950/60 p-2 rounded-xl border border-emerald-500/40">
                      ✓ Foreign prodigy accepted your invitation and joined your sect!
                    </div>
                  )}

                  <button
                    onClick={() => {
                      if (onGrantConsolationRewards) {
                        onGrantConsolationRewards(currentRound * 45, currentRound * 15);
                      }
                      onClose();
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#123d30] hover:bg-[#1a4f3f] text-[#fce18b] font-bold text-xs border border-[#e2b054]/30"
                  >
                    Claim Participation Rewards (+{currentRound * 45} Stones, +{currentRound * 15} Merit)
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Peak Challenge · Monthly Martial Tradition</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Close Arena
          </button>
        </div>
      </div>
    </div>
  );
};
