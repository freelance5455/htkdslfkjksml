import React, { useState } from 'react';
import {
  X,
  Briefcase,
  CheckCircle,
  ShieldCheck,
  Percent,
  Coins,
  DollarSign,
  ArrowRightLeft,
  Sparkles,
  Phone,
  Building,
} from 'lucide-react';
import { UserProfile } from '../../types';
import { soundFX } from '../../utils/soundEffects';
import { saveUserProfileToFirestore, saveCashierAgentToFirestore } from '../../utils/firebaseSync';

interface BecomeCashierModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpdateUser: (u: UserProfile) => void;
  onOpenCashierDesk?: () => void;
  showNotification?: (msg: string) => void;
}

export const BecomeCashierModal: React.FC<BecomeCashierModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateUser,
  onOpenCashierDesk,
  showNotification,
}) => {
  const [branchName, setBranchName] = useState(`نقطة كاشير ${currentUser.name}`);
  const [phoneNumber, setPhoneNumber] = useState('+971 50 998 7766');
  const [agreedTerms, setAgreedTerms] = useState(true);
  const [isUpgrading, setIsUpgrading] = useState(false);

  if (!isOpen) return null;

  const handleActivateCashier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreedTerms) return;

    setIsUpgrading(true);
    soundFX.playVictoryFanfare();

    const updatedUser: UserProfile = {
      ...currentUser,
      role: 'CASHIER',
      title: 'كاشير معتمد 💼',
      kycVerified: true,
    };

    onUpdateUser(updatedUser);
    saveUserProfileToFirestore(updatedUser);

    // Register cashier agent
    saveCashierAgentToFirestore({
      id: `CASHIER_${currentUser.id}`,
      name: currentUser.name,
      code: `CSH-${currentUser.id.slice(-4)}`,
      branchName: branchName.trim() || 'فرع الكاشير المركزي',
      avatar: currentUser.avatar,
      status: 'ACTIVE',
      balanceUsd: currentUser.realCashBalance || 2500,
      balanceCoins: currentUser.coins || 10000,
      balanceGems: currentUser.gems || 150,
      totalTransferredToPlayers: 0,
      totalReceivedFromAdmin: 5000,
      commissionRate: 3.5, // 3.5% default commission
      phone: phoneNumber,
    });

    if (showNotification) {
      showNotification('🎉 مبروك! تم تفعيل حسابك ككاشير معتمد وفتح مكتب الكاشير لديك بنجاح.');
    }

    setIsUpgrading(false);
    onClose();

    if (onOpenCashierDesk) {
      setTimeout(() => {
        onOpenCashierDesk();
      }, 300);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in select-none">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-[#092b1a] via-[#05180f] to-[#020a06] border-2 border-amber-400/80 rounded-3xl p-6 md:p-8 shadow-[0_0_60px_rgba(16,185,129,0.3)] overflow-hidden">
        {/* Background ambient lights */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-amber-500/15 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={() => {
            soundFX.playButtonClick();
            onClose();
          }}
          className="absolute top-5 left-5 text-gray-400 hover:text-white p-2 rounded-full bg-black/40 border border-amber-950 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 border border-amber-300 mx-auto flex items-center justify-center shadow-lg text-black mb-3 animate-bounce">
            <Briefcase className="w-7 h-7" />
          </div>
          <h3 className="text-xl md:text-2xl font-black text-amber-200">
            تفعيل حسابك إلى كاشير معتمد (Become a Cashier)
          </h3>
          <p className="text-xs text-gray-300 mt-1 max-w-md mx-auto">
            انضم إلى شبكة كاشيرية TABEONA الرسمية، وابدأ في تقديم خدمات الشحن والسحب وتحقيق الأرباح والعمولات!
          </p>
        </div>

        {/* Cashier Features Showcase */}
        <div className="grid grid-cols-2 gap-2.5 mb-6 text-right">
          <div className="p-3 rounded-2xl bg-black/50 border border-emerald-500/30 flex items-start gap-2.5">
            <Percent className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold text-amber-200">عمولة أرباح فورية (2% - 5%)</div>
              <div className="text-[11px] text-gray-400">تحصيل عمولة تلقائية عن كل عملية شحن أو تحويل للاعبين</div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-black/50 border border-emerald-500/30 flex items-start gap-2.5">
            <Briefcase className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold text-amber-200">مكتب الكاشير المخصص</div>
              <div className="text-[11px] text-gray-400">واجهة كاملة لاستقبال طلبات السحب والإيداع واعتمادها</div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-black/50 border border-emerald-500/30 flex items-start gap-2.5">
            <ArrowRightLeft className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold text-amber-200">إرسال واستقبال التحويلات</div>
              <div className="text-[11px] text-gray-400">تحويل كوينز وجواهر مباشرة لحسابات اللاعبين بسندات موثقة</div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-black/50 border border-emerald-500/30 flex items-start gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold text-amber-200">شارة الكاشير الملكية 💼</div>
              <div className="text-[11px] text-gray-400">ظهور رتبة كاشير معتمد بجانب اسمك في غرف اللعب واللوبي</div>
            </div>
          </div>
        </div>

        {/* Upgrade Form */}
        <form onSubmit={handleActivateCashier} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-gray-300 block mb-1">
              اسم فرع أو نقطة الكاشير:
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={branchName}
                onChange={(e) => setBranchName(e.target.value)}
                placeholder="مثال: نقطة كاشير دبي المعتمدة #03"
                className="w-full p-2.5 bg-black/60 border border-amber-950 focus:border-amber-400 rounded-xl text-xs text-white pr-9 focus:outline-none"
              />
              <Building className="w-4 h-4 text-amber-400 absolute right-3 top-3" />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-gray-300 block mb-1">
              رقم الهاتف / الواتساب التجاري للتواصل مع اللاعبين:
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="+971 50 123 4567"
                className="w-full p-2.5 bg-black/60 border border-amber-950 focus:border-amber-400 rounded-xl text-xs text-white pr-9 focus:outline-none"
              />
              <Phone className="w-4 h-4 text-amber-400 absolute right-3 top-3" />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-xs text-amber-200/90 leading-relaxed">
            <label className="flex items-start gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={agreedTerms}
                onChange={(e) => setAgreedTerms(e.target.checked)}
                className="accent-amber-500 mt-0.5 rounded cursor-pointer"
              />
              <span>
                أوافق على ميثاق كاشيرية TABEONA: الالتزام بالأمانة المالية، سرعة تنفيذ عمليات الشحن والسحب للاعبين، والتقيد بسجل التدقيق الرقمي.
              </span>
            </label>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => {
                soundFX.playButtonClick();
                onClose();
              }}
              className="px-4 py-2.5 rounded-xl bg-black/40 text-gray-400 hover:text-white text-xs font-bold"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={!agreedTerms || isUpgrading}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black text-xs font-black shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all disabled:opacity-40"
            >
              <Sparkles className="w-4 h-4" />
              <span>تفعيل رتبة الكاشير وفتح مكتب الكاشير فوراً ⚡</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
