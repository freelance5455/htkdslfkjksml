import React, { useState } from 'react';
import { X, Play, Info, Trophy, Users, Shield, Award } from 'lucide-react';
import { soundFX } from '../../utils/soundEffects';

interface GamesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectGame: (gameId: string) => void;
}

export const GamesModal: React.FC<GamesModalProps> = ({ isOpen, onClose, onSelectGame }) => {
  const [selectedGameTab, setSelectedGameTab] = useState<string>('tarneeb');

  if (!isOpen) return null;

  const games = [
    {
      id: 'tarneeb',
      title: 'طرنيب',
      badge: 'اللعبة الأساسية ⭐',
      players: '4 لاعبين (شراكة)',
      deck: '52 ورقة (13 لكل لاعب)',
      description: 'لعبة الورق الملكية الأشهر، تعتمد على الذكاء، المزايدة من 2 إلى 13، وشراكة متقابلة مع نظام الفوز بالـ 41 بشرط ألا يكون الشريك تحت الصفر.',
      icon: '🃏',
      available: true,
      rules: [
        'توزيع 13 ورقة لكل لاعب.',
        'المزايدة من 2 إلى 13 (2=2، 3=3 ... 7=14، 8=16 ... 13=26).',
        'الحد الأدنى للمزايدة يرتفع إلى 3 إذا بلغ رصيدك 30، وإلى 4 إذا بلغ 40.',
        'الفوز عند الوصول لـ 41 نقطة بنهاية الجولة، بشرط أن يكون الشريك فوق الصفر (>= 0).',
        'إلزامية اتباع النوع في كل لمّة.',
      ],
    },
    {
      id: 'trix',
      title: 'تركس (Trix)',
      badge: 'نسخة قياسية',
      players: '4 لاعبين (فردي)',
      deck: '52 ورقة (13 لكل لاعب)',
      description: 'أربع ممالك وكل مملكة تتضمن 5 ألعاب دقيقة: شيخ الكبة، البنات، الديناري، اللطوش، ولعبة التركس الكبرى.',
      icon: '👑',
      available: true,
      rules: [
        'شيخ الكبة (King of Hearts): صاحب الورقة K♥ ينال -75.',
        'البنات (Queens): كل بنت تؤخذ تعطي -25 (المجموع -100).',
        'الديناري (Diamonds): كل ورقة ديناري تعطي -10 (المجموع -130).',
        'اللطوش (Ltoosh): كل لمّة تؤخذ تعطي -15 (المجموع -195).',
        'تركس (Trix): ترتيب السلاسل صعودًا إلى A ونزولاً إلى 2 انطلاقًا من الـ J (+200، +150، +100، +50).',
      ],
    },
    {
      id: 'chess',
      title: 'الشطرنج',
      badge: 'عقل واستراتيجية',
      players: 'لاعبان (1v1)',
      deck: 'رقعة 8×8',
      description: 'لعبة الملوك الكلاسيكية مع تصنيف ELO، ساعة توقيت رسمية، سجل النقلات PGN، طلب التعادل والاستسلام.',
      icon: '♟️',
      available: true,
      rules: [
        'رقعة 8×8 رسمية مع 16 قطعة لكل طرف.',
        'أنظمة كش مات، تعادل بالتراضي، أو بالقطع غير الكافية.',
        'سجل حركات لحظي ومؤقت رسمي.',
      ],
    },
    {
      id: 'ludo',
      title: 'لودو (Ludo)',
      badge: 'حماس اجتماعي',
      players: '2 - 4 لاعبين',
      deck: 'نرد ورقعة ملونة',
      description: '4 قطع لكل لاعب، رقم 6 يخرج القطعة ويعطي رمية إضافية، والتقاط قطع الخصم يعيدها للقاعدة مع مربعات الأمان.',
      icon: '🎲',
      available: true,
      rules: [
        'رقم 6 مطلوب لإخراج القطعة من المعسكر.',
        'رقم 6 يمنح رمية إضافية.',
        '3 ستات متتالية تلغي الدور وفق القوانين القياسية.',
        'أول من يدخل قطعه الأربع يفوز بالمباراة.',
      ],
    },
    {
      id: 'billiards',
      title: 'البلياردو (8-Ball)',
      badge: 'دقة وفيزياء',
      players: '1v1 أو 2v2',
      deck: 'طاولة 8-Ball',
      description: 'الكرات الفردية والمخططة مع الكرة السوداء رقم 8، قياس زاوية الضربة والقوة بدقة مع طاولة احترافية.',
      icon: '🎱',
      available: true,
      rules: [
        'الوضع الأساسي: 8-Ball.',
        'تحديد الكرات (Solids & Stripes).',
        'إسقاط الكرة السوداء 8 في الجيب المحدد بعد إنهاء كراتك للفوز.',
      ],
    },
    {
      id: 'backgammon',
      title: 'طاولة الزهر (Backgammon)',
      badge: 'عراقة وأصالة',
      players: 'لاعبان (1v1)',
      deck: '24 نقطة و 15 حجر',
      description: 'طاولة النرد الكلاسيكية، 15 حجرًا لكل لاعب، حركات الـ Double تضاعف 4 مرات، والـ Bear Off لإخراج الأحجار.',
      icon: '🎲',
      available: true,
      rules: [
        '15 حجر لكل لاعب على 24 نقطة.',
        'ضرب أحجار الخصم وإرسالها إلى الـ Bar.',
        'الرمية المزدوجة (Doubles) تمنح 4 حركات.',
        'إمكانية تفعيل مكعب المضاعفة (Doubling Cube: 2, 4, 8, 16, 32, 64).',
      ],
    },
  ];

  const currentGame = games.find((g) => g.id === selectedGameTab) || games[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div className="relative w-full max-w-4xl h-[85vh] bg-[#07130c] border-2 border-amber-500/50 rounded-2xl shadow-[0_0_40px_rgba(16,185,129,0.3)] flex flex-col overflow-hidden text-right">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0b2416] via-[#123823] to-[#0b2416] border-b border-amber-500/30 p-4 flex items-center justify-between">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="text-gray-400 hover:text-amber-400 p-1.5 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-2">
            <span className="text-xl">👑</span>
            <h2 className="text-xl font-bold text-amber-300">ألعاب TABEONA الملكية</h2>
          </div>
        </div>

        {/* Content Layout */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          {/* Games list on right (RTL) */}
          <div className="md:col-span-5 bg-[#050e08] border-l border-amber-900/40 p-3 overflow-y-auto space-y-2">
            {games.map((g) => (
              <button
                key={g.id}
                onClick={() => {
                  soundFX.playButtonClick();
                  setSelectedGameTab(g.id);
                }}
                className={`w-full p-3 rounded-xl border text-right transition-all flex items-center justify-between ${
                  selectedGameTab === g.id
                    ? 'bg-gradient-to-r from-emerald-950 to-emerald-900/70 border-amber-500 shadow-md'
                    : 'bg-[#08170f] border-amber-900/40 hover:border-amber-700/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-emerald-950/80 border border-amber-500/40 flex items-center justify-center text-2xl shadow-inner">
                    {g.icon}
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-100 text-sm flex items-center gap-2">
                      {g.title}
                      {g.id === 'tarneeb' && (
                        <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded border border-amber-500/40">
                          نشط
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-gray-400 mt-0.5">{g.players}</p>
                  </div>
                </div>
                <span className="text-xs text-amber-400 font-semibold">{g.badge}</span>
              </button>
            ))}
          </div>

          {/* Game Detail on left */}
          <div className="md:col-span-7 p-6 overflow-y-auto flex flex-col justify-between bg-gradient-to-b from-[#07170f] to-[#040c08]">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-black text-amber-300 flex items-center gap-2">
                    <span>{currentGame.icon}</span>
                    <span>{currentGame.title}</span>
                  </h3>
                  <div className="flex items-center gap-3 text-xs text-emerald-400 mt-1 font-semibold">
                    <span className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      {currentGame.players}
                    </span>
                    <span>•</span>
                    <span>{currentGame.deck}</span>
                  </div>
                </div>
                <div className="px-3 py-1 bg-amber-500/20 text-amber-300 text-xs font-bold rounded-full border border-amber-500/40">
                  {currentGame.badge}
                </div>
              </div>

              <p className="text-sm text-gray-300 leading-relaxed bg-[#05110a] p-3.5 rounded-xl border border-amber-950">
                {currentGame.description}
              </p>

              <div>
                <h4 className="font-bold text-amber-300 text-sm mb-2 flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-emerald-400" />
                  قواعد اللعبة المعتمدة في المنصة:
                </h4>
                <ul className="space-y-1.5 text-xs text-gray-300">
                  {currentGame.rules.map((r, i) => (
                    <li key={i} className="flex items-start gap-2 bg-[#05110a]/50 p-2 rounded-lg border border-amber-950/60">
                      <span className="text-amber-400 font-bold">✓</span>
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Launch CTA */}
            <div className="pt-4 border-t border-amber-950/80 mt-4 flex items-center justify-between">
              <div className="text-xs text-gray-400">
                <span>جاهز للعب الآن أونلاين أو ضد الذكاء الملكي</span>
              </div>
              <button
                onClick={() => {
                  soundFX.playButtonClick();
                  onSelectGame(currentGame.id);
                  onClose();
                }}
                className="px-6 py-3 bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 hover:from-emerald-500 hover:to-emerald-400 text-white font-bold text-sm rounded-xl shadow-[0_0_15px_rgba(16,185,129,0.5)] flex items-center gap-2 transition-transform active:scale-95"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>العب {currentGame.title} الآن</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
