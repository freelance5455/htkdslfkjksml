import React, { useState } from 'react';
import { MerchantItem, MerchantTier, SectResources } from '../../types/cultivation';
import { formatLargeNumber } from '../../data/realms';
import { soundEngine } from '../../services/audioEngine';
import { Briefcase, ShoppingBag, Sparkles, X, Shield, Award, Check } from 'lucide-react';

interface MerchantModalProps {
  items: MerchantItem[];
  resources: SectResources;
  onClose: () => void;
  onBuyItem: (item: MerchantItem) => void;
}

export const MerchantModal: React.FC<MerchantModalProps> = ({
  items,
  resources,
  onClose,
  onBuyItem
}) => {
  const [selectedTier, setSelectedTier] = useState<'All' | MerchantTier>('All');

  const filteredItems = items.filter(i => {
    if (selectedTier === 'All') return true;
    return i.tier === selectedTier;
  });

  const getTierBadgeStyle = (tier: MerchantTier) => {
    switch (tier) {
      case 'Mortal': return 'bg-gray-800 text-gray-300 border-gray-600';
      case 'Spiritual': return 'bg-blue-900/40 text-blue-300 border-blue-500/40';
      case 'Earth': return 'bg-amber-900/40 text-amber-300 border-amber-500/40';
      case 'Heaven': return 'bg-purple-900/40 text-purple-300 border-purple-500/40';
      case 'Divine': return 'bg-rose-900/50 text-rose-300 border-rose-500/50 animate-pulse';
    }
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] relative">
        {/* Sticky Header with generous touch target */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-[#fce18b]" />
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
                Bao's Immortal Pavilion
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                5 Tiered Treasure Catalog: Mortal, Spiritual, Earth, Heaven, Divine.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 5 Tier Selection Tabs */}
        <div className="flex items-center gap-1.5 p-2.5 bg-[#09261d] border-b border-[#1b4b3b] overflow-x-auto scroll-hide">
          {(['All', 'Mortal', 'Spiritual', 'Earth', 'Heaven', 'Divine'] as const).map((tier) => (
            <button
              key={tier}
              onClick={() => setSelectedTier(tier)}
              className={`px-3 py-1.5 rounded-xl text-[10px] sm:text-[11px] font-bold shrink-0 transition-all ${
                selectedTier === tier
                  ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] shadow-sm'
                  : 'bg-[#123d30] text-[#a4c5b7] hover:bg-[#184838]'
              }`}
            >
              {tier === 'All' ? 'All Tiers' : tier}
            </button>
          ))}
        </div>

        <div className="p-4 overflow-y-auto space-y-3 grow text-xs text-[#d1e6dc]">
          {filteredItems.map((item) => {
            const canAfford = item.currency === 'spiritStones'
              ? resources.spiritStones >= item.price
              : resources.merit >= item.price;

            return (
              <div
                key={item.id}
                className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] flex justify-between items-center gap-3 transition-colors hover:border-[#276e57]"
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-white text-xs sm:text-sm font-dao">
                      {item.name}
                    </span>
                    <span className={`text-[9px] px-2 py-0.5 rounded-full border font-bold ${getTierBadgeStyle(item.tier)}`}>
                      {item.tier}
                    </span>
                    <span className="text-[9px] text-[#9fc2b2]">
                      ({item.type})
                    </span>
                  </div>
                  <p className="text-[11px] text-[#a4c5b7] leading-relaxed">
                    {item.description}
                  </p>
                  <div className="text-[10px] text-[#86efac] font-medium">
                    Effect: {item.effect}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-xs font-mono font-bold text-[#fce18b] mb-1.5">
                    {item.currency === 'spiritStones' ? '💎' : '📜'} {formatLargeNumber(item.price)}
                  </div>
                  <button
                    disabled={!canAfford || item.stock <= 0}
                    onClick={() => {
                      soundEngine.playTalisman();
                      onBuyItem(item);
                    }}
                    className={`px-3 py-1.5 rounded-xl font-dao font-bold text-xs shadow-sm transition-all ${
                      item.stock <= 0
                        ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                        : canAfford
                        ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-95'
                        : 'bg-[#184838]/60 text-[#7ea091] cursor-not-allowed border border-[#1f5a46]'
                    }`}
                  >
                    {item.stock <= 0 ? 'Sold Out' : 'Purchase'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Traveling Merchant Bao · Balanced Pricing</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Exit Pavilion
          </button>
        </div>
      </div>
    </div>
  );
};
