import React, { useState } from 'react';
import { MerchantItem, MerchantTier, SectResources } from '../../types/cultivation';
import { formatLargeNumber } from '../../data/realms';
import { soundEngine } from '../../services/audioEngine';
import merchantArt from '../../assets/images/art_merchant_treasures_1794844217760.jpg';
import { Briefcase, RefreshCw, PackageCheck, X } from 'lucide-react';

interface MerchantModalProps {
  items: MerchantItem[];
  resources: SectResources;
  freeRefreshAvailable: boolean;
  onClose: () => void;
  onBuyItem: (item: MerchantItem) => void;
  onRefreshStock: (payment: 'free' | 'stones' | 'merit') => void;
}

export const MerchantModal: React.FC<MerchantModalProps> = ({
  items,
  resources,
  freeRefreshAvailable,
  onClose,
  onBuyItem,
  onRefreshStock
}) => {
  const [selectedTier, setSelectedTier] = useState<'All' | MerchantTier>('All');

  const filteredItems = items.filter(i => {
    if (selectedTier === 'All') return true;
    return i.tier === selectedTier;
  });

  const getTierTextStyle = (tier: MerchantTier) => {
    switch (tier) {
      case 'Mortal': return 'text-slate-300';
      case 'Spiritual': return 'text-sky-300';
      case 'Earth': return 'text-amber-300';
      case 'Heaven': return 'text-purple-300';
      case 'Divine': return 'text-rose-300';
    }
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] relative">
        {/* Sticky Header */}
        <div className="sticky top-0 z-20 relative overflow-hidden bg-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <img
            src={merchantArt}
            alt="Immortal Pavilion Goods"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover opacity-20 pointer-events-none"
          />
          <div className="relative z-10 flex items-center gap-2.5 min-w-0">
            <Briefcase className="w-5 h-5 text-[#fce18b] shrink-0" />
            <div className="min-w-0">
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b] truncate">
                Bao&apos;s Immortal Pavilion
              </h3>
              <p className="text-[11px] text-[#d1e6dc] truncate">
                Daily stock cap (1 each) · Purchased goods go straight to Sect Storage.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="relative z-10 p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Daily Refresh Bar */}
        <div className="bg-[#09261d] px-3.5 py-2.5 border-b border-[#1b4b3b] flex flex-wrap items-center justify-between gap-2 text-[11px]">
          <div className="text-[#9fc2b2]">
            {freeRefreshAvailable
              ? <span className="text-emerald-300 font-bold">1 Free Daily Refresh Ready</span>
              : <span>Next Free Refresh Tomorrow (or refresh with currency)</span>}
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              disabled={!freeRefreshAvailable}
              onClick={() => {
                soundEngine.playTalisman();
                onRefreshStock('free');
              }}
              className={`px-2.5 py-1.5 rounded-lg font-bold flex items-center gap-1 text-[10px] transition-all ${
                freeRefreshAvailable
                  ? 'bg-emerald-700 hover:bg-emerald-600 text-white shadow-xs'
                  : 'bg-[#0c2c22] text-[#5c7d70] border border-[#194536] cursor-not-allowed'
              }`}
            >
              <RefreshCw className="w-3 h-3" />
              <span>{freeRefreshAvailable ? 'Free Refresh (1/d)' : 'Free Used'}</span>
            </button>

            <button
              disabled={resources.spiritStones < 60}
              onClick={() => {
                soundEngine.playTalisman();
                onRefreshStock('stones');
              }}
              className={`px-2.5 py-1.5 rounded-lg font-bold text-[10px] font-mono tabular-nums transition-all ${
                resources.spiritStones >= 60
                  ? 'bg-[#184838] hover:bg-[#1f5c48] text-[#fce18b] border border-[#e2b054]/40'
                  : 'bg-[#0c2c22] text-[#5c7d70] border border-[#194536] cursor-not-allowed'
              }`}
            >
              60 Stones
            </button>

            <button
              disabled={resources.merit < 15}
              onClick={() => {
                soundEngine.playTalisman();
                onRefreshStock('merit');
              }}
              className={`px-2.5 py-1.5 rounded-lg font-bold text-[10px] font-mono tabular-nums transition-all ${
                resources.merit >= 15
                  ? 'bg-[#184838] hover:bg-[#1f5c48] text-amber-200 border border-[#e2b054]/40'
                  : 'bg-[#0c2c22] text-[#5c7d70] border border-[#194536] cursor-not-allowed'
              }`}
            >
              15 Merit
            </button>
          </div>
        </div>

        {/* 5 Tier Selection Tabs */}
        <div className="flex items-center gap-1.5 p-2.5 bg-[#09261d] border-b border-[#1b4b3b] overflow-x-auto scroll-hide">
          {(['All', 'Mortal', 'Spiritual', 'Earth', 'Heaven', 'Divine'] as const).map((tier) => (
            <button
              key={tier}
              onClick={() => setSelectedTier(tier)}
              className={`px-3 py-1.5 rounded-xl text-[10px] sm:text-[11px] font-bold shrink-0 transition-all whitespace-nowrap ${
                selectedTier === tier
                  ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] shadow-sm'
                  : 'bg-[#123d30] text-[#a4c5b7] hover:bg-[#184838]'
              }`}
            >
              {tier === 'All' ? 'All Tiers' : tier}
            </button>
          ))}
        </div>

        {/* Stock List */}
        <div className="p-4 overflow-y-auto space-y-2.5 grow text-xs text-[#d1e6dc]">
          {filteredItems.map((item) => {
            const isBought = item.stock <= 0 || Boolean(item.purchasedToday);
            const canAfford = item.currency === 'spiritStones'
              ? resources.spiritStones >= item.price
              : resources.merit >= item.price;

            return (
              <div
                key={item.id}
                className={`p-3.5 rounded-2xl border flex justify-between items-center gap-3 transition-colors ${
                  isBought
                    ? 'bg-[#071c15] border-[#13382c] opacity-65'
                    : 'bg-[#09261d] border-[#1b4b3b] hover:border-[#276e57]'
                }`}
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-bold text-white text-xs sm:text-sm font-dao">
                      {item.name}
                    </span>
                    <span className="text-[10px] text-[#9fc2b2]">
                      · <strong className={getTierTextStyle(item.tier)}>{item.tier}</strong> · {item.type}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#a4c5b7] leading-relaxed">
                    {item.description}
                  </p>
                  <div className="text-[10px] text-[#86efac] font-medium">
                    Effect: {item.effect} {item.equipSlot ? `· Equippable (${item.equipSlot})` : '· Stored in Vault'}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-xs font-mono tabular-nums font-bold text-[#fce18b] mb-1.5">
                    {item.currency === 'spiritStones' ? 'Stones' : 'Merit'} {formatLargeNumber(item.price)}
                  </div>
                  <button
                    disabled={!canAfford || isBought}
                    onClick={() => {
                      soundEngine.playTalisman();
                      onBuyItem(item);
                    }}
                    className={`px-3 py-1.5 rounded-xl font-dao font-bold text-xs shadow-sm transition-all flex items-center gap-1 ml-auto ${
                      isBought
                        ? 'bg-[#0d281f] text-[#6d8e80] border border-[#194536] cursor-not-allowed'
                        : canAfford
                        ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-95'
                        : 'bg-[#184838]/60 text-[#7ea091] cursor-not-allowed border border-[#1f5a46]'
                    }`}
                  >
                    {isBought ? (
                      <>
                        <PackageCheck className="w-3.5 h-3.5" />
                        <span>Sold Today</span>
                      </>
                    ) : (
                      <span>Buy (1 Left)</span>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Stock replenishes automatically each midnight</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Exit Pavilion
          </button>
        </div>
      </div>
    </div>
  );
};
