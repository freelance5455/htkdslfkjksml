import React, { useState } from 'react';
import { X, Users, Lock, Unlock, Play, Wifi, UserPlus, CheckCircle, Crown, Settings } from 'lucide-react';
import { RoomConfig, UserProfile } from '../../types';
import { soundFX } from '../../utils/soundEffects';

interface CreateRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onStartMatch: (room: RoomConfig) => void;
}

export const CreateRoomModal: React.FC<CreateRoomModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onStartMatch,
}) => {
  const [step, setStep] = useState<'create' | 'waiting'>('create');
  const [selectedGame, setSelectedGame] = useState<'tarneeb' | 'trix' | 'chess' | 'ludo' | 'billiards' | 'backgammon'>('tarneeb');
  const [gameMode, setGameMode] = useState('طرنيب سوق 41');
  const [isPrivate, setIsPrivate] = useState(false);
  const [password, setPassword] = useState('');
  const [stakeCoins, setStakeCoins] = useState(500);
  const [isHotspotLan, setIsHotspotLan] = useState(false);

  // Waiting room mock slots
  const [waitingPlayers, setWaitingPlayers] = useState([
    { id: 'p1', name: currentUser.name, avatar: currentUser.avatar, isReady: true, isHost: true, level: currentUser.level },
    { id: 'p2', name: 'أحمد (شريكك)', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop', isReady: true, isHost: false, level: 16 },
    { id: 'p3', name: 'سامي (خصم)', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop', isReady: true, isHost: false, level: 14 },
    { id: 'p4', name: 'ليلى (خصم)', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop', isReady: true, isHost: false, level: 18 },
  ]);

  if (!isOpen) return null;

  const handleCreateRoom = (e: React.FormEvent) => {
    e.preventDefault();
    soundFX.playButtonClick();
    setStep('waiting');
  };

  const handleLaunchGame = () => {
    soundFX.playVictoryFanfare();
    const room: RoomConfig = {
      id: `#${Math.floor(10000 + Math.random() * 90000)}`,
      name: `غرفة ${currentUser.name} الملكية`,
      game: selectedGame,
      mode: gameMode,
      isPrivate,
      password: isPrivate ? password : undefined,
      stakeCoins,
      maxPlayers: 4,
      currentPlayers: [],
      hostId: currentUser.id,
      isLanHotspot: isHotspotLan,
    };
    onStartMatch(room);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="relative w-full max-w-2xl bg-[#07130c] border-2 border-amber-500/50 rounded-2xl shadow-[0_0_40px_rgba(16,185,129,0.3)] overflow-hidden text-right flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0b2416] via-[#123823] to-[#0b2416] border-b border-amber-500/30 p-4 flex items-center justify-between">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="text-gray-400 hover:text-amber-400 p-1 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-amber-300 flex items-center gap-2">
            <span>➕</span>
            <span>{step === 'create' ? 'إنشاء غرفة جديدة' : 'غرفة الانتظار الملكية'}</span>
          </h2>
        </div>

        {step === 'create' ? (
          <form onSubmit={handleCreateRoom} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
            {/* Game Choice */}
            <div>
              <label className="block text-xs font-bold text-amber-300 mb-2">1. اختيار اللعبة:</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'tarneeb', name: 'طرنيب 🃏' },
                  { id: 'trix', name: 'تركس 👑' },
                  { id: 'chess', name: 'شطرنج ♟️' },
                  { id: 'ludo', name: 'لودو 🎲' },
                  { id: 'billiards', name: 'بلياردو 🎱' },
                  { id: 'backgammon', name: 'طاولة الزهر 🎲' },
                ].map((g) => (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => {
                      soundFX.playButtonClick();
                      setSelectedGame(g.id as any);
                    }}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                      selectedGame === g.id
                        ? 'bg-emerald-900 border-amber-400 text-amber-300 shadow-sm'
                        : 'bg-[#050f0a] border-amber-950 text-gray-300'
                    }`}
                  >
                    {g.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Mode Choice */}
            {selectedGame === 'tarneeb' && (
              <div>
                <label className="block text-xs font-bold text-amber-300 mb-1">2. نوع الطرنيب:</label>
                <div className="grid grid-cols-2 gap-2">
                  {['طرنيب سوق 41 (المعتمد)', 'طرنيب 31 سريع'].map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setGameMode(m)}
                      className={`p-2 rounded-lg text-xs font-semibold border ${
                        gameMode === m
                          ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                          : 'bg-[#050f0a] border-amber-950 text-gray-400'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Privacy & Password */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-amber-300 mb-1">نوع الغرفة:</label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsPrivate(false)}
                    className={`flex-1 py-2 rounded-lg border text-xs font-bold flex items-center justify-center gap-1 ${
                      !isPrivate ? 'bg-emerald-900 border-emerald-400 text-emerald-200' : 'bg-[#050f0a] border-amber-950 text-gray-400'
                    }`}
                  >
                    <Unlock className="w-3.5 h-3.5" /> عامة
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsPrivate(true)}
                    className={`flex-1 py-2 rounded-lg border text-xs font-bold flex items-center justify-center gap-1 ${
                      isPrivate ? 'bg-amber-900 border-amber-400 text-amber-200' : 'bg-[#050f0a] border-amber-950 text-gray-400'
                    }`}
                  >
                    <Lock className="w-3.5 h-3.5" /> خاصة
                  </button>
                </div>
              </div>

              {isPrivate && (
                <div>
                  <label className="block text-xs font-bold text-amber-300 mb-1">كلمة مرور الغرفة:</label>
                  <input
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="رمز الدخول (PIN)..."
                    className="w-full bg-[#050f0a] border border-amber-900/70 rounded-lg px-3 py-2 text-white text-xs focus:outline-none"
                    required
                  />
                </div>
              )}
            </div>

            {/* Bet / Stake Coins */}
            <div>
              <label className="block text-xs font-bold text-amber-300 mb-1">رسوم دخول الغرفة (كوينز):</label>
              <div className="flex gap-2">
                {[100, 500, 1000, 2500, 5000].map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setStakeCoins(st)}
                    className={`flex-1 py-1.5 rounded-lg border text-xs font-bold ${
                      stakeCoins === st ? 'bg-amber-500 text-black border-amber-400' : 'bg-[#050f0a] border-amber-950 text-gray-300'
                    }`}
                  >
                    {st} 🪙
                  </button>
                ))}
              </div>
            </div>

            {/* Offline Hotspot LAN option */}
            <div className="p-3 bg-[#05110a] border border-amber-900/50 rounded-xl flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-gray-200 flex items-center gap-1.5">
                  <Wifi className="w-4 h-4 text-emerald-400" />
                  وضع الشبكة المحلية (Hotspot / LAN Offline)
                </div>
                <div className="text-[11px] text-gray-400 mt-0.5">
                  للعب المباشر مع الأصدقاء عبر نقطة الاتصال دون استهلاك إنترنت (بدون رانكد مركزي).
                </div>
              </div>
              <input
                type="checkbox"
                checked={isHotspotLan}
                onChange={(e) => setIsHotspotLan(e.target.checked)}
                className="w-5 h-5 accent-emerald-500 rounded"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 hover:from-emerald-500 text-white font-bold rounded-xl shadow-lg transition-transform active:scale-95 text-sm"
            >
              إنشاء ودخول غرفة الانتظار
            </button>
          </form>
        ) : (
          /* Waiting Room View (غرفة الانتظار) */
          <div className="p-6 space-y-6">
            <div className="flex items-center justify-between bg-[#05100a] p-3 rounded-xl border border-amber-950">
              <div>
                <h3 className="font-bold text-amber-300 text-sm">{selectedGame === 'tarneeb' ? 'طرنيب سوق 41' : selectedGame}</h3>
                <span className="text-xs text-gray-400">غرفة #49281 • الرهان: {stakeCoins} كوينز</span>
              </div>
              <div className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-600/40 text-xs font-bold">
                جاهز للبدء (4/4)
              </div>
            </div>

            {/* 4 Players Slots */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {waitingPlayers.map((p, idx) => (
                <div
                  key={p.id}
                  className="bg-[#05110a] border border-amber-900/60 rounded-xl p-3 flex flex-col items-center text-center relative"
                >
                  {p.isHost && (
                    <span title="صاحب الغرفة" className="absolute top-2 right-2">
                      <Crown className="w-4 h-4 text-amber-400" />
                    </span>
                  )}
                  <img src={p.avatar} alt={p.name} className="w-14 h-14 rounded-full border-2 border-amber-400 object-cover mb-2" />
                  <div className="font-bold text-xs text-white truncate max-w-full">{p.name}</div>
                  <div className="text-[10px] text-amber-400">Lv {p.level}</div>
                  <div className="mt-2 text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-600/40">
                    جاهز ✓
                  </div>
                </div>
              ))}
            </div>

            {/* Action Bar */}
            <div className="pt-2 flex items-center justify-between gap-3">
              <button
                onClick={() => setStep('create')}
                className="px-4 py-2.5 rounded-xl bg-gray-900 hover:bg-gray-800 text-gray-300 text-xs"
              >
                رجوع للإعدادات
              </button>
              <button
                onClick={handleLaunchGame}
                className="flex-1 py-3 bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 hover:from-amber-500 text-black font-extrabold text-sm rounded-xl shadow-[0_0_20px_rgba(245,158,11,0.5)] flex items-center justify-center gap-2 active:scale-95 transition-transform"
              >
                <Play className="w-4 h-4 fill-black" />
                <span>ابدأ المباراة الآن (صاحب الغرفة)</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
