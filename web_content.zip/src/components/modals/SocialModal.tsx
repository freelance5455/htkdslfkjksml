import React, { useState } from 'react';
import { X, Search, UserPlus, Gift, MessageSquare, ShieldAlert, Check, UserCheck, Heart } from 'lucide-react';
import { Friend, UserProfile } from '../../types';
import { soundFX } from '../../utils/soundEffects';

interface SocialModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onSendGift: (targetPlayer: string, amount: number, type: 'COINS' | 'GEMS') => void;
}

export const SocialModal: React.FC<SocialModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSendGift,
}) => {
  const [activeTab, setActiveTab] = useState<'friends' | 'requests' | 'search' | 'gifts'>('friends');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFriendForGift, setSelectedFriendForGift] = useState<Friend | null>(null);
  const [giftAmount, setGiftAmount] = useState(100);
  const [giftCurrency, setGiftCurrency] = useState<'COINS' | 'GEMS'>('COINS');
  const [giftSuccessMsg, setGiftSuccessMsg] = useState<string | null>(null);

  const [friendsList, setFriendsList] = useState<Friend[]>([
    { id: 'f1', name: 'Player 2', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop', level: 21, status: 'online' },
    { id: 'f2', name: 'Queen', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop', level: 18, status: 'in_room', game: 'طرنيب سوق 41' },
    { id: 'f3', name: 'King', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100&h=100&fit=crop', level: 17, status: 'online' },
    { id: 'f4', name: 'Ace', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&h=100&fit=crop', level: 15, status: 'in_room', game: 'تركس' },
    { id: 'f5', name: 'Joker', avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&h=100&fit=crop', level: 13, status: 'busy' },
  ]);

  const [requestsList, setRequestsList] = useState([
    { id: 'req1', name: 'صقر قريش', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop', level: 9, idCode: '49201' },
    { id: 'req2', name: 'أمير الطرنيب', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop', level: 12, idCode: '38192' },
  ]);

  if (!isOpen) return null;

  const handleSendGiftSubmit = () => {
    if (!selectedFriendForGift) return;
    if (selectedFriendForGift.name === currentUser.name) {
      alert('ممنوع إرسال هدية للنفس بحسب لوائح TABEONA!');
      return;
    }
    if (giftCurrency === 'COINS' && currentUser.coins < giftAmount) {
      alert('رصيدك من الكوينز غير كافٍ!');
      return;
    }
    if (giftCurrency === 'GEMS' && currentUser.gems < giftAmount) {
      alert('رصيدك من الجواهر غير كافٍ!');
      return;
    }

    soundFX.playCoin();
    onSendGift(selectedFriendForGift.name, giftAmount, giftCurrency);
    setGiftSuccessMsg(`تم إرسال ${giftAmount} ${giftCurrency === 'COINS' ? 'كوينز' : 'جوهرة'} إلى ${selectedFriendForGift.name} بنجاح!`);
    setTimeout(() => {
      setGiftSuccessMsg(null);
      setSelectedFriendForGift(null);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div className="relative w-full max-w-2xl bg-[#07130c] border-2 border-amber-500/50 rounded-2xl shadow-[0_0_40px_rgba(16,185,129,0.3)] overflow-hidden text-right flex flex-col h-[75vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0b2416] via-[#123823] to-[#0b2416] border-b border-amber-500/30 p-4 flex items-center justify-between">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="text-gray-400 hover:text-amber-400 p-1 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-amber-300 flex items-center gap-2">
            <span>👥</span>
            <span>المركز الاجتماعي والأصدقاء</span>
          </h2>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-4 bg-[#040e08] border-b border-amber-950 p-1 text-xs font-bold">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              setActiveTab('friends');
            }}
            className={`py-2 text-center rounded-lg ${
              activeTab === 'friends'
                ? 'bg-emerald-900/80 text-amber-300 border border-amber-500/40'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            الأصدقاء ({friendsList.length})
          </button>
          <button
            onClick={() => {
              soundFX.playButtonClick();
              setActiveTab('requests');
            }}
            className={`py-2 text-center rounded-lg relative ${
              activeTab === 'requests'
                ? 'bg-emerald-900/80 text-amber-300 border border-amber-500/40'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            الطلبات
            {requestsList.length > 0 && (
              <span className="mr-1 px-1.5 py-0.2 bg-red-600 text-white rounded-full text-[10px]">
                {requestsList.length}
              </span>
            )}
          </button>
          <button
            onClick={() => {
              soundFX.playButtonClick();
              setActiveTab('search');
            }}
            className={`py-2 text-center rounded-lg ${
              activeTab === 'search'
                ? 'bg-emerald-900/80 text-amber-300 border border-amber-500/40'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            بحث بالـ ID
          </button>
          <button
            onClick={() => {
              soundFX.playButtonClick();
              setActiveTab('gifts');
            }}
            className={`py-2 text-center rounded-lg ${
              activeTab === 'gifts'
                ? 'bg-emerald-900/80 text-amber-300 border border-amber-500/40'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            إرسال هدايا 🎁
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 p-4 overflow-y-auto">
          {giftSuccessMsg && (
            <div className="mb-3 p-3 bg-emerald-900/60 border border-emerald-500 text-emerald-200 rounded-xl text-xs flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{giftSuccessMsg}</span>
            </div>
          )}

          {activeTab === 'friends' && (
            <div className="space-y-2">
              {friendsList.map((f) => (
                <div
                  key={f.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-[#05110a] border border-amber-950/70 hover:border-amber-700/50"
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <img src={f.avatar} alt={f.name} className="w-11 h-11 rounded-full border border-amber-400 object-cover" />
                      <span
                        className={`absolute bottom-0 left-0 w-3 h-3 rounded-full border-2 border-black ${
                          f.status === 'online'
                            ? 'bg-emerald-500'
                            : f.status === 'in_room'
                            ? 'bg-amber-500'
                            : 'bg-gray-500'
                        }`}
                      />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-gray-100 flex items-center gap-2">
                        <span>{f.name}</span>
                        <span className="text-[10px] text-amber-400">Lv {f.level}</span>
                      </div>
                      <div className="text-xs text-gray-400">
                        {f.status === 'online'
                          ? 'متصل باللوبي'
                          : f.status === 'in_room'
                          ? `في غرفة (${f.game || 'طرنيب'})`
                          : 'مشغول'}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        soundFX.playButtonClick();
                        setSelectedFriendForGift(f);
                        setActiveTab('gifts');
                      }}
                      className="p-2 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs flex items-center gap-1"
                      title="إرسال هدية"
                    >
                      <Gift className="w-3.5 h-3.5" />
                      <span>هدية</span>
                    </button>
                    <button
                      onClick={() => alert(`تم بدء محادثة مع ${f.name}`)}
                      className="p-2 rounded-lg bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-600/30 text-xs flex items-center gap-1"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>دردشة</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'requests' && (
            <div className="space-y-2">
              {requestsList.length === 0 ? (
                <div className="text-center py-8 text-xs text-gray-400">لا توجد طلبات صداقة معلقة حاليًا.</div>
              ) : (
                requestsList.map((req) => (
                  <div
                    key={req.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-[#05110a] border border-amber-950"
                  >
                    <div className="flex items-center gap-3">
                      <img src={req.avatar} alt={req.name} className="w-10 h-10 rounded-full border border-amber-400 object-cover" />
                      <div>
                        <div className="text-sm font-bold text-gray-100">{req.name}</div>
                        <div className="text-xs text-gray-400">ID: {req.idCode} • Lv {req.level}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          soundFX.playButtonClick();
                          setFriendsList((prev) => [
                            ...prev,
                            { id: req.id, name: req.name, avatar: req.avatar, level: req.level, status: 'online' },
                          ]);
                          setRequestsList((prev) => prev.filter((r) => r.id !== req.id));
                        }}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                      >
                        قبول
                      </button>
                      <button
                        onClick={() => {
                          soundFX.playButtonClick();
                          setRequestsList((prev) => prev.filter((r) => r.id !== req.id));
                        }}
                        className="px-3 py-1.5 rounded-lg bg-red-950 hover:bg-red-900 text-red-300 text-xs"
                      >
                        رفض
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'search' && (
            <div className="space-y-4">
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="أدخل معرّف اللاعب (مثال: 78453)..."
                  className="w-full bg-[#050f0a] border border-amber-900/70 focus:border-amber-400 rounded-xl px-4 py-3 text-white pr-10 text-sm focus:outline-none"
                />
                <Search className="w-4 h-4 text-amber-400 absolute right-3.5 top-3.5" />
              </div>

              <div className="p-4 rounded-xl bg-[#05110a] border border-amber-950 text-center">
                <div className="text-xs text-gray-400 mb-2">معرّفك الخاص لمشاركته مع أصدقائك:</div>
                <div className="font-mono text-xl text-amber-300 font-bold bg-[#030906] p-2 rounded-lg border border-amber-500/30 inline-block">
                  ID: 78453
                </div>
              </div>
            </div>
          )}

          {activeTab === 'gifts' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-amber-300 mb-1">المستلم:</label>
                <select
                  value={selectedFriendForGift?.id || ''}
                  onChange={(e) => {
                    const f = friendsList.find((fr) => fr.id === e.target.value);
                    setSelectedFriendForGift(f || null);
                  }}
                  className="w-full bg-[#050f0a] border border-amber-900/70 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none"
                >
                  <option value="">-- اختر صديقًا لإرسال الهدية --</option>
                  {friendsList.map((fr) => (
                    <option key={fr.id} value={fr.id}>
                      {fr.name} (Lv {fr.level})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setGiftCurrency('COINS')}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    giftCurrency === 'COINS'
                      ? 'bg-amber-950/70 border-amber-400 text-amber-300'
                      : 'bg-[#050e08] border-amber-950 text-gray-400'
                  }`}
                >
                  <div className="text-xl mb-1">🪙</div>
                  <div className="text-xs font-bold">كوينز (رصيدك: {currentUser.coins.toLocaleString()})</div>
                </button>
                <button
                  type="button"
                  onClick={() => setGiftCurrency('GEMS')}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    giftCurrency === 'GEMS'
                      ? 'bg-emerald-950/70 border-emerald-400 text-emerald-300'
                      : 'bg-[#050e08] border-amber-950 text-gray-400'
                  }`}
                >
                  <div className="text-xl mb-1">💎</div>
                  <div className="text-xs font-bold">جواهر (رصيدك: {currentUser.gems.toLocaleString()})</div>
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-amber-300 mb-1">الكمية:</label>
                <div className="flex gap-2">
                  {[50, 100, 250, 500].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setGiftAmount(amt)}
                      className={`flex-1 py-2 rounded-lg text-xs font-bold border ${
                        giftAmount === amt
                          ? 'bg-amber-500 text-black border-amber-400'
                          : 'bg-[#050f0a] border-amber-950 text-gray-300'
                      }`}
                    >
                      {amt}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-amber-950/20 border border-amber-500/20 rounded-xl text-xs text-amber-200">
                ⚠️ تأكيد مسبق: لا يمكن استرداد الهدية بعد إرسالها وتُسجل مباشرة في سجل العمليات المالي المركزي.
              </div>

              <button
                onClick={handleSendGiftSubmit}
                disabled={!selectedFriendForGift}
                className="w-full py-3 bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 disabled:opacity-50 text-black font-bold text-sm rounded-xl shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-2"
              >
                <Gift className="w-4 h-4" />
                <span>تأكيد إرسال الهدية إلى {selectedFriendForGift ? selectedFriendForGift.name : 'الصديق'}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
