import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  MessageSquare,
  Send,
  HelpCircle,
  Sparkles,
  CheckCircle,
  Clock,
  Plus,
  ShieldCheck,
  CheckCheck,
  PhoneCall,
  Coins,
  Gem,
  Gift,
} from 'lucide-react';
import { UserProfile, SupportTicket, SupportMessage, SupportCategory } from '../../types';
import { soundFX } from '../../utils/soundEffects';
import { saveSupportTicketToFirestore } from '../../utils/firebaseSync';

interface CustomerSupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  tickets: SupportTicket[];
  onUpdateTickets: (tickets: SupportTicket[]) => void;
}

export const CustomerSupportModal: React.FC<CustomerSupportModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  tickets,
  onUpdateTickets,
}) => {
  // Find or filter player's tickets
  const myTickets = tickets.filter(
    (t) => t.playerId === currentUser.id || t.playerName === currentUser.name
  );

  const [activeTicketId, setActiveTicketId] = useState<string>(
    myTickets[0]?.id || ''
  );
  const [showNewTicketForm, setShowNewTicketForm] = useState<boolean>(myTickets.length === 0);

  // New ticket form
  const [newSubject, setNewSubject] = useState('');
  const [newCategory, setNewCategory] = useState<SupportCategory>('GENERAL');
  const [newInitialMessage, setNewInitialMessage] = useState('');

  // Player message input
  const [playerInput, setPlayerInput] = useState('');
  const [isSending, setIsSending] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeTicket = tickets.find((t) => t.id === activeTicketId) || myTickets[0];

  useEffect(() => {
    if (myTickets.length > 0 && !activeTicketId) {
      setActiveTicketId(myTickets[0].id);
    }
  }, [myTickets, activeTicketId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeTicket?.messages]);

  // Mark player unread messages as read when opening
  useEffect(() => {
    if (activeTicket && activeTicket.unreadPlayerCount > 0) {
      const updated = tickets.map((t) =>
        t.id === activeTicket.id ? { ...t, unreadPlayerCount: 0 } : t
      );
      onUpdateTickets(updated);
    }
  }, [activeTicketId]);

  if (!isOpen) return null;

  // Handle Send Player Message
  const handleSendMessage = () => {
    const text = playerInput.trim();
    if (!text || !activeTicket) return;

    soundFX.playButtonClick();
    setIsSending(true);

    const newMsg: SupportMessage = {
      id: `MSG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      ticketId: activeTicket.id,
      senderType: 'PLAYER',
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      text,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      isRead: false,
    };

    const updatedTicket: SupportTicket = {
      ...activeTicket,
      status: activeTicket.status === 'RESOLVED' ? 'OPEN' : activeTicket.status,
      updatedAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastMessageSnippet: text,
      unreadAdminCount: activeTicket.unreadAdminCount + 1,
      unreadPlayerCount: 0,
      messages: [...activeTicket.messages, newMsg],
    };

    const updatedAll = tickets.map((t) => (t.id === activeTicket.id ? updatedTicket : t));
    onUpdateTickets(updatedAll);
    saveSupportTicketToFirestore(updatedTicket);

    setPlayerInput('');
    setIsSending(false);
  };

  // Handle Create New Ticket
  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject.trim() || !newInitialMessage.trim()) return;

    soundFX.playVictoryFanfare();

    const ticketId = `TICK-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString().replace('T', ' ').slice(0, 19);

    const initialMsg: SupportMessage = {
      id: `MSG-${Date.now()}`,
      ticketId,
      senderType: 'PLAYER',
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      text: newInitialMessage.trim(),
      timestamp: now,
      isRead: false,
    };

    const newTicket: SupportTicket = {
      id: ticketId,
      playerId: currentUser.id,
      playerName: currentUser.name,
      playerAvatar: currentUser.avatar,
      playerLevel: currentUser.level,
      playerVip: currentUser.vipLevel,
      category: newCategory,
      subject: newSubject.trim(),
      status: 'OPEN',
      priority: 'HIGH',
      createdAt: now,
      updatedAt: now,
      lastMessageSnippet: newInitialMessage.trim(),
      unreadAdminCount: 1,
      unreadPlayerCount: 0,
      playerBalance: {
        coins: currentUser.coins,
        gems: currentUser.gems,
        realCashBalance: currentUser.realCashBalance,
      },
      messages: [initialMsg],
    };

    const updatedAll = [newTicket, ...tickets];
    onUpdateTickets(updatedAll);
    saveSupportTicketToFirestore(newTicket);

    setActiveTicketId(ticketId);
    setShowNewTicketForm(false);
    setNewSubject('');
    setNewInitialMessage('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in select-none">
      <div className="w-full max-w-4xl h-[700px] max-h-[90vh] bg-gradient-to-b from-[#06190f] via-[#04110a] to-[#020704] border-2 border-amber-500/50 rounded-3xl overflow-hidden shadow-2xl flex flex-col relative">
        {/* Header */}
        <div className="px-6 py-4 bg-[#061a0e] border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500/30 to-emerald-600/30 border border-amber-400/50 flex items-center justify-center shadow-inner">
              <MessageSquare className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="text-base font-black text-amber-200 flex items-center gap-2">
                دعم العملاء والدردشة المباشرة مع الإدارة
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                  خدمة VIP 24/7
                </span>
              </h3>
              <p className="text-xs text-gray-400">
                فريق إدارة TABEONA جاهز للرد الفوري على كافة استفساراتك ومتابعة عملياتك
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                soundFX.playButtonClick();
                setShowNewTicketForm(true);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs flex items-center gap-1.5 shadow-md transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>فتح تذكرة جديدة</span>
            </button>

            <button
              onClick={() => {
                soundFX.playButtonClick();
                onClose();
              }}
              className="p-1.5 rounded-full text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Body Split */}
        <div className="flex-1 flex overflow-hidden">
          {/* Side Ticket History */}
          <div className="w-72 border-l border-amber-950/60 bg-[#030d07] flex flex-col shrink-0">
            <div className="p-3 border-b border-amber-950/60 text-xs font-bold text-gray-400 flex items-center justify-between">
              <span>تذاكري ومحادثاتي ({myTickets.length})</span>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-amber-950/30">
              {myTickets.length === 0 ? (
                <div className="p-6 text-center text-gray-500 text-xs">
                  ليس لديك تذاكر دعم سابقة
                </div>
              ) : (
                myTickets.map((ticket) => {
                  const isSelected = !showNewTicketForm && ticket.id === activeTicket?.id;
                  return (
                    <button
                      key={ticket.id}
                      onClick={() => {
                        soundFX.playButtonClick();
                        setActiveTicketId(ticket.id);
                        setShowNewTicketForm(false);
                      }}
                      className={`w-full text-right p-3 transition-all ${
                        isSelected
                          ? 'bg-gradient-to-r from-emerald-950 to-[#072515] border-r-4 border-amber-400 text-white'
                          : 'hover:bg-[#06180e] text-gray-400'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-amber-200 truncate">
                          {ticket.subject}
                        </span>
                        <span className="text-[10px] text-gray-500">
                          {ticket.updatedAt.slice(11, 16)}
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-400 line-clamp-1 truncate mb-1.5">
                        {ticket.lastMessageSnippet}
                      </p>
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                            ticket.status === 'RESOLVED'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {ticket.status === 'RESOLVED' ? 'محلولة ✅' : 'قيد المتابعة ⏳'}
                        </span>
                        <span className="text-[9px] text-gray-500">#{ticket.id}</span>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Main Content */}
          <div className="flex-1 flex flex-col bg-gradient-to-b from-[#05140b] via-[#030c07] to-[#020704]">
            {showNewTicketForm ? (
              /* New Ticket Form */
              <div className="flex-1 p-8 overflow-y-auto max-w-xl mx-auto w-full">
                <div className="text-center mb-6">
                  <h4 className="text-lg font-black text-amber-200">
                    إنشاء تذكرة استفسار جديدة للإدارة
                  </h4>
                  <p className="text-xs text-gray-400 mt-1">
                    سيقوم ممثل خدمة العملاء أو الكاشير المركزي بالرد عليك فوراً
                  </p>
                </div>

                <form onSubmit={handleCreateTicket} className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-gray-300 block mb-1">
                      تصنيف الاستفسار:
                    </label>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {[
                        { id: 'FINANCIAL', label: 'كاشير وسحب/إيداع أموال 💰' },
                        { id: 'GAMEPLAY', label: 'مشاكل جولات الطرنيب واللعب 🃏' },
                        { id: 'ACCOUNT', label: 'توثيق الهوية والحساب (KYC) 🛡️' },
                        { id: 'TECHNICAL', label: 'خلل تقني أو بالمايك ⚙️' },
                      ].map((cat) => (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => setNewCategory(cat.id as SupportCategory)}
                          className={`p-2.5 rounded-xl border text-right font-bold transition-all ${
                            newCategory === cat.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                              : 'bg-black/40 border-amber-950 text-gray-400 hover:text-white'
                          }`}
                        >
                          {cat.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-300 block mb-1">
                      موضوع الاستفسار (عنوان مختصر):
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: استفسار حول طلب سحب USDT أو انقطاع الجولة..."
                      value={newSubject}
                      onChange={(e) => setNewSubject(e.target.value)}
                      className="w-full p-2.5 bg-black/50 border border-amber-950 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-300 block mb-1">
                      تفاصيل الرسالة أو المشكلة:
                    </label>
                    <textarea
                      required
                      rows={5}
                      placeholder="اكتب بالتفصيل ما الذي ترغب بالاستفسار عنه لنتمكن من مساعدتك بأسرع وقت..."
                      value={newInitialMessage}
                      onChange={(e) => setNewInitialMessage(e.target.value)}
                      className="w-full p-3 bg-black/50 border border-amber-950 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400 resize-none"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-3">
                    {myTickets.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setShowNewTicketForm(false)}
                        className="px-4 py-2 rounded-xl bg-black/40 text-gray-400 text-xs font-bold"
                      >
                        إلغاء
                      </button>
                    )}
                    <button
                      type="submit"
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-black text-xs shadow-lg hover:from-amber-400 hover:to-amber-300 transition-all"
                    >
                      إرسال التذكرة للإدارة الآن
                    </button>
                  </div>
                </form>
              </div>
            ) : activeTicket ? (
              /* Active Chat Window */
              <div className="flex-1 flex flex-col h-full">
                {/* Active Ticket Banner */}
                <div className="px-6 py-3 bg-[#05170d] border-b border-amber-950/60 flex items-center justify-between shrink-0">
                  <div>
                    <h4 className="text-xs font-black text-amber-200">
                      {activeTicket.subject}
                    </h4>
                    <span className="text-[11px] text-gray-400">
                      تذكرة #{activeTicket.id} • الحالة:{' '}
                      {activeTicket.status === 'RESOLVED' ? 'محلولة ✅' : 'قيد المتابعة مع الإدارة ⏳'}
                    </span>
                  </div>

                  <span
                    className={`text-xs px-2.5 py-1 rounded-full font-bold border ${
                      activeTicket.status === 'RESOLVED'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                    }`}
                  >
                    {activeTicket.status === 'RESOLVED' ? 'تم الحل بنجاح' : 'الإدارة متواجدة للرد'}
                  </span>
                </div>

                {/* Messages Feed */}
                <div className="flex-1 p-6 overflow-y-auto space-y-4">
                  {activeTicket.messages.map((msg) => {
                    const isMe = msg.senderType === 'PLAYER';
                    const isSystem = msg.senderType === 'SYSTEM';

                    if (isSystem) {
                      return (
                        <div key={msg.id} className="flex justify-center my-2">
                          <div className="max-w-md px-4 py-1.5 rounded-full bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs font-medium text-center shadow-sm">
                            {msg.text}
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div
                        key={msg.id}
                        className={`flex items-start gap-3 ${isMe ? 'flex-row' : 'flex-row-reverse'}`}
                      >
                        <img
                          src={
                            msg.senderAvatar ||
                            (isMe
                              ? currentUser.avatar
                              : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop')
                          }
                          alt={msg.senderName}
                          className="w-8 h-8 rounded-full object-cover border border-amber-500/40 shrink-0 mt-1"
                        />

                        <div
                          className={`max-w-[75%] rounded-2xl p-3.5 shadow-md ${
                            isMe
                              ? 'bg-[#081f13] border border-emerald-500/30 text-white rounded-tr-none'
                              : 'bg-gradient-to-br from-emerald-900 to-[#07361c] border border-amber-400/50 text-white rounded-tl-none'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-3 mb-1 text-[11px]">
                            <span className="font-black text-amber-300 flex items-center gap-1">
                              {!isMe && <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />}
                              {msg.senderName}
                              {msg.senderRole && (
                                <span className="text-[10px] text-emerald-300 font-normal">
                                  ({msg.senderRole})
                                </span>
                              )}
                            </span>
                            <span className="text-[10px] text-gray-400">
                              {msg.timestamp.slice(11, 16)}
                            </span>
                          </div>

                          <p className="text-xs leading-relaxed whitespace-pre-wrap">
                            {msg.text}
                          </p>

                          {msg.actionTaken && (
                            <div className="mt-2 pt-1.5 border-t border-amber-500/20 text-[11px] text-amber-200 flex items-center gap-1">
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                              <span>{msg.actionTaken.details}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input Controls */}
                <div className="p-4 bg-[#05170d] border-t border-amber-950/70 flex items-center gap-3 shrink-0">
                  <input
                    type="text"
                    value={playerInput}
                    onChange={(e) => setPlayerInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    placeholder="اكتب ردك أو استفسارك هنا للإدارة..."
                    className="flex-1 p-3 bg-black/60 border border-amber-950 rounded-2xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400"
                  />

                  <button
                    onClick={handleSendMessage}
                    disabled={!playerInput.trim() || isSending}
                    className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-black text-xs flex items-center gap-2 shadow-lg disabled:opacity-40"
                  >
                    <span>إرسال</span>
                    <Send className="w-4 h-4 rotate-180" />
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};
