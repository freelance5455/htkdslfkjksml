import React, { useState } from 'react';
import { SECT_ACHIEVEMENTS, SectAchievement } from '../../data/achievements';
import { soundEngine } from '../../services/audioEngine';
import { Award, CheckCircle2, Lock, Sparkles, X, ChevronRight } from 'lucide-react';

interface AwardsModalProps {
  onClose: () => void;
  disciplesCount: number;
  maxRealmIndex: number;
  spiritStones: number;
  qi: number;
  merit: number;
  pills: number;
  hallLevel: number;
  hasTournamentWin: boolean;
  hasChampionTitle: boolean;
  hasAlliance: boolean;
  claimedAchievementIds: string[];
  onClaimMerit: (achievementId: string, amount: number) => void;
}

export const AwardsModal: React.FC<AwardsModalProps> = ({
  onClose,
  disciplesCount,
  maxRealmIndex,
  spiritStones,
  qi,
  merit,
  pills,
  hallLevel,
  hasTournamentWin,
  hasChampionTitle,
  hasAlliance,
  claimedAchievementIds,
  onClaimMerit
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'All' | SectAchievement['category']>('All');

  // Check if achievement is completed based on game state
  const isAchievementCompleted = (ach: SectAchievement): { completed: boolean; progressText: string } => {
    switch (ach.id) {
      case 'ach_1': return { completed: maxRealmIndex >= 2, progressText: maxRealmIndex >= 2 ? 'Achieved' : 'In Progress' };
      case 'ach_2': return { completed: maxRealmIndex >= 8, progressText: maxRealmIndex >= 8 ? 'Achieved' : 'In Progress' };
      case 'ach_3': return { completed: maxRealmIndex >= 9, progressText: maxRealmIndex >= 9 ? 'Achieved' : 'In Progress' };
      case 'ach_4': return { completed: maxRealmIndex >= 12, progressText: maxRealmIndex >= 12 ? 'Achieved' : 'In Progress' };
      case 'ach_5': return { completed: maxRealmIndex >= 13, progressText: maxRealmIndex >= 13 ? 'Achieved' : 'In Progress' };
      case 'ach_6': return { completed: maxRealmIndex >= 16, progressText: maxRealmIndex >= 16 ? 'Achieved' : 'In Progress' };
      case 'ach_7': return { completed: maxRealmIndex >= 17, progressText: maxRealmIndex >= 17 ? 'Achieved' : 'In Progress' };
      case 'ach_8': return { completed: maxRealmIndex >= 20, progressText: maxRealmIndex >= 20 ? 'Achieved' : 'In Progress' };
      case 'ach_9': return { completed: maxRealmIndex >= 21, progressText: maxRealmIndex >= 21 ? 'Achieved' : 'In Progress' };
      case 'ach_10': return { completed: maxRealmIndex >= 26, progressText: maxRealmIndex >= 26 ? 'Achieved' : 'In Progress' };

      case 'ach_11': return { completed: disciplesCount >= 2, progressText: `${disciplesCount}/2` };
      case 'ach_12': return { completed: disciplesCount >= 5, progressText: `${disciplesCount}/5` };
      case 'ach_13': return { completed: disciplesCount >= 10, progressText: `${disciplesCount}/10` };
      case 'ach_14': return { completed: disciplesCount >= 15, progressText: `${disciplesCount}/15` };

      case 'ach_21': return { completed: spiritStones >= 1000, progressText: `${Math.min(spiritStones, 1000)}/1,000` };
      case 'ach_22': return { completed: spiritStones >= 10000, progressText: `${Math.min(spiritStones, 10000)}/10,000` };
      case 'ach_23': return { completed: spiritStones >= 100000, progressText: `${Math.min(spiritStones, 100000)}/100,000` };
      case 'ach_25': return { completed: qi >= 1000, progressText: `${Math.min(qi, 1000)}/1,000` };
      case 'ach_27': return { completed: pills >= 50, progressText: `${Math.min(pills, 50)}/50` };
      case 'ach_28': return { completed: merit >= 1000, progressText: `${Math.min(merit, 1000)}/1,000` };

      case 'ach_29': return { completed: hallLevel >= 2, progressText: `Hall Lv ${hallLevel}/2` };
      case 'ach_30': return { completed: hallLevel >= 5, progressText: `Hall Lv ${hallLevel}/5` };
      case 'ach_31': return { completed: hallLevel >= 10, progressText: `Hall Lv ${hallLevel}/10` };

      case 'ach_37': return { completed: hasTournamentWin, progressText: hasTournamentWin ? 'Achieved' : 'Not Attempted' };
      case 'ach_42': return { completed: hasChampionTitle, progressText: hasChampionTitle ? 'Achieved' : 'In Progress' };
      case 'ach_48': return { completed: hasAlliance, progressText: hasAlliance ? 'Achieved' : 'No Alliances' };

      default: return { completed: false, progressText: 'In Progress' };
    }
  };

  const filteredAchievements = SECT_ACHIEVEMENTS.filter(a => {
    if (selectedCategory === 'All') return true;
    return a.category === selectedCategory;
  });

  const completedCount = SECT_ACHIEVEMENTS.filter(a => isAchievementCompleted(a).completed).length;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] relative">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-[#fce18b]" />
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b] flex items-center gap-2">
                <span>50 Dao Milestones & Honours</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-mono">
                  {completedCount}/50 Complete
                </span>
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                Monumental triumphs inscribed upon the Heavenly Stele.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 p-2 bg-[#09261d] border-b border-[#1b4b3b] overflow-x-auto scroll-hide">
          {(['All', 'Cultivation', 'Mentorship', 'Treasury', 'Pavilions', 'Tournament', 'Diplomacy'] as const).map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-[10px] sm:text-[11px] font-bold shrink-0 transition-all ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] shadow-sm'
                  : 'bg-[#123d30] text-[#a4c5b7] hover:bg-[#184838]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Achievement List */}
        <div className="p-4 overflow-y-auto space-y-2.5 grow text-xs text-[#d1e6dc]">
          {filteredAchievements.map(ach => {
            const { completed, progressText } = isAchievementCompleted(ach);
            const isClaimed = claimedAchievementIds.includes(ach.id);

            return (
              <div
                key={ach.id}
                className={`p-3 rounded-2xl border flex items-center justify-between gap-3 transition-all ${
                  completed
                    ? 'bg-[#184838] border-[#4ade80]/50 shadow-sm'
                    : 'bg-[#09261d] border-[#1b4b3b] opacity-80'
                }`}
              >
                <div className="flex items-start gap-2.5 min-w-0">
                  <div className={`p-2 rounded-xl shrink-0 mt-0.5 ${
                    completed ? 'bg-[#22c55e]/20 text-[#4ade80]' : 'bg-gray-800 text-gray-500'
                  }`}>
                    {completed ? <CheckCircle2 className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                  </div>
                  <div className="space-y-0.5 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-white text-xs sm:text-sm font-dao">
                        {ach.title}
                      </span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-[#0e3325] text-[#9fc2b2] border border-[#1a513d]">
                        {ach.category}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#9fc2b2] leading-snug">
                      {ach.description}
                    </p>
                    <div className="text-[10px] text-[#fce18b] font-mono">
                      Progress: {progressText} · Reward: {ach.rewardText}
                    </div>
                  </div>
                </div>

                <div className="shrink-0 text-right">
                  {completed ? (
                    isClaimed ? (
                      <span className="text-[10px] text-[#86efac] font-bold px-2 py-1 rounded-lg bg-emerald-950/60 border border-emerald-500/30">
                        Claimed
                      </span>
                    ) : (
                      <button
                        onClick={() => {
                          soundEngine.playFanfare();
                          onClaimMerit(ach.id, ach.meritReward);
                        }}
                        className="py-1 px-3 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs shadow-md hover:brightness-110 active:scale-95 transition-all"
                      >
                        Claim Reward
                      </button>
                    )
                  ) : (
                    <span className="text-[10px] text-[#6d8e80] italic">Locked</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Heavenly Dao Records</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Close Stele
          </button>
        </div>
      </div>
    </div>
  );
};
