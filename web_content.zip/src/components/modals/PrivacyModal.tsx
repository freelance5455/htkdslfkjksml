import React from 'react';
import { X, ShieldCheck, Lock, Eye, FileText } from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <h3 className="text-lg font-bold text-slate-900">Privacy & Data Security</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 hover:text-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
          <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-start gap-3">
            <Lock className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-slate-800 text-sm">HIPAA & GDPR Compliant</p>
              <p className="mt-0.5 text-slate-600">All medical scan records and report analysis are processed with end-to-end local encryption safeguards.</p>
            </div>
          </div>

          <div className="space-y-2 pt-1">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-blue-600" /> How Your Data is Handled
            </h4>
            <ul className="list-disc pl-4 space-y-1">
              <li>Prescription and pill images are processed locally on device.</li>
              <li>No personal health information (PHI) is sold or shared with third parties.</li>
              <li>You retain full ownership of your exported health timeline and logs.</li>
            </ul>
          </div>

          <div className="space-y-2 pt-1">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-purple-600" /> Medical Disclaimer
            </h4>
            <p className="text-slate-500 italic bg-slate-50 p-3 rounded-xl border border-slate-200/80">
              Mediguide AI is an educational healthcare assistant designed to support wellness. Always consult a certified physician for medical diagnosis and prescription verification.
            </p>
          </div>
        </div>

        <div className="pt-2">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-900 text-white font-semibold text-sm hover:bg-slate-800 transition-colors"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
