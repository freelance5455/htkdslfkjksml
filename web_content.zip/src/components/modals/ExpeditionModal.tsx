import React, { useState } from 'react';
import { SecretRealm, Disciple } from '../../types/cultivation';
import { CULTIVATION_REALMS, formatLargeNumber } from '../../data/realms';
import { soundEngine } from '../../services/audioEngine';
import { Compass, ShieldAlert, X, Swords, Lock, CheckCircle2 } from 'lucide-react';

interface ExpeditionModalProps {
  realms: SecretRealm[];
  disciples: Disciple[];
  devMode?: boolean;
  onClose: () => void;
  onDispatchExpedition: (realm: SecretRealm, squad: Disciple[]) => void;
}

export function computeExpeditionSuccessRate(realm: SecretRealm, squad: Disciple[], devMode = false): {
  chance: number;
  meetsRealm: boolean;
  isTooWeak: boolean;
  reason: string;
} {
  if (devMode) {
    return { chance: 100, meetsRealm: true, isTooWeak: false, reason: 'Dev Mode Override' };
  }
  if (squad.length === 0) {
    return { chance: 0, meetsRealm: false, isTooWeak: true, reason: 'No squad assembled' };
  }

  const maxSquadRealm = Math.max(...squad.map(d => d.currentRealmIndex));
  const meetsRealm = maxSquadRealm >= realm.minRealmIndex;
  const teamPower = squad.reduce((acc, d) => acc + d.combatPower, 0);
  const ratio = teamPower / Math.max(1, realm.recommendedPower);

  if (!meetsRealm) {
    const reqName = CULTIVATION_REALMS[realm.minRealmIndex]?.name || `Realm ${realm.minRealmIndex}`;
    return {
      chance: 0,
      meetsRealm: false,
      isTooWeak: true,
      reason: `Blocked: Requires at least one disciple at ${reqName}`
    };
  }

  if (ratio < 0.65) {
    return {
      chance: 0,
      meetsRealm: true,
      isTooWeak: true,
      reason: `Overwhelmed: Combat Power (${formatLargeNumber(teamPower)}) is far below ${formatLargeNumber(realm.recommendedPower)}`
    };
  }

  if (ratio < 1.0) {
    const scaled = Math.round(15 + ((ratio - 0.65) / 0.35) * 60); // 15% .. 75%
    return {
      chance: Math.max(10, Math.min(75, scaled)),
      meetsRealm: true,
      isTooWeak: false,
      reason: 'Dangerous expedition — bring higher realm disciples to raise odds'
    };
  }

  if (ratio < 1.25) {
    const scaled = Math.round(78 + ((ratio - 1.0) / 0.25) * 22);
    return {
      chance: Math.min(99, scaled),
      meetsRealm: true,
      isTooWeak: false,
      reason: 'Favorable odds — squad matches secret realm threat'
    };
  }

  return {
    chance: 100,
    meetsRealm: true,
    isTooWeak: false,
    reason: 'Guaranteed Triumph — crushing power advantage'
  };
}

export const ExpeditionModal: React.FC<ExpeditionModalProps> = ({
  realms,
  disciples,
  devMode = false,
  onClose,
  onDispatchExpedition
}) => {
  const [selectedRealm, setSelectedRealm] = useState<SecretRealm>(realms[0]);
  const [selectedSquadIds, setSelectedSquadIds] = useState<string[]>([]);

  const availableDisciples = disciples.filter(d => d.status !== 'Expedition');

  const toggleSelectDisciple = (id: string) => {
    soundEngine.playClick();
    if (selectedSquadIds.includes(id)) {
      setSelectedSquadIds(selectedSquadIds.filter(sid => sid !== id));
    } else {
      if (selectedSquadIds.length < 3) {
        setSelectedSquadIds([...selectedSquadIds, id]);
      }
    }
  };

  const selectedSquad = disciples.filter(d => selectedSquadIds.includes(d.id));
  const teamCombatPower = selectedSquad.reduce((acc, d) => acc + d.combatPower, 0);
  const assessment = computeExpeditionSuccessRate(selectedRealm, selectedSquad, devMode);
  const reqRealmName = CULTIVATION_REALMS[selectedRealm.minRealmIndex]?.name || 'Qi Condensation (Layer 1)';
  const canDispatch = selectedSquadIds.length > 0 && assessment.chance > 0;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] relative">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2">
            <Compass className="w-5 h-5 text-[#38bdf8]" />
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
                Secret Realm Expeditions
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                Realms enforce strict cultivation rank &amp; combat might thresholds.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-4 grow text-xs text-[#d1e6dc]">
          {/* Secret Realm Selector */}
          <div className="space-y-2">
            <span className="font-bold font-dao text-sm text-[#fce18b]">1. Select Destination Realm</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {realms.map((realm) => {
                const isSelected = selectedRealm.id === realm.id;
                const minRealmLabel = CULTIVATION_REALMS[realm.minRealmIndex]?.name || 'Layer 1';
                return (
                  <div
                    key={realm.id}
                    onClick={() => {
                      soundEngine.playClick();
                      setSelectedRealm(realm);
                    }}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#184838] border-[#e2b054] shadow-md ring-1 ring-[#fce18b]/50'
                        : 'bg-[#09261d] border-[#1b4b3b] hover:border-[#1e5845]'
                    }`}
                  >
                    <div className="flex justify-between items-start gap-1">
                      <strong className="text-white text-xs sm:text-sm font-dao">{realm.name}</strong>
                      <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold shrink-0 ${
                        realm.dangerLevel === 'Safe' ? 'bg-green-900/40 text-green-300' :
                        realm.dangerLevel === 'Moderate' ? 'bg-yellow-900/40 text-yellow-300' :
                        realm.dangerLevel === 'Dangerous' ? 'bg-orange-900/40 text-orange-300' :
                        'bg-red-900/50 text-red-300'
                      }`}>
                        {realm.dangerLevel}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#9fc2b2] mt-1 line-clamp-2">
                      {realm.description}
                    </div>
                    <div className="text-[10px] text-[#fce18b] font-mono mt-1.5 flex justify-between">
                      <span>Power: {formatLargeNumber(realm.recommendedPower)}</span>
                      <span className="text-[#86efac] truncate max-w-[125px]">Min: {minRealmLabel}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Realm Potential Yields */}
          <div className="bg-[#09261d] p-3 rounded-2xl border border-[#1b4b3b] space-y-2">
            <div className="font-bold text-[#fce18b] flex items-center justify-between flex-wrap gap-1">
              <span>Spoils: {selectedRealm.name}</span>
              <span className="text-[10px] text-[#38bdf8]">Min Realm: {reqRealmName}</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
              <div className="bg-[#123d30] p-2 rounded-xl">
                <div className="text-[#8daea0] text-[10px]">Spirit Stones</div>
                <div className="text-[#fce18b] font-mono font-bold">+{formatLargeNumber(selectedRealm.potentialStones)}</div>
              </div>
              <div className="bg-[#123d30] p-2 rounded-xl">
                <div className="text-[#8daea0] text-[10px]">Alchemy Pills</div>
                <div className="text-[#2dd4bf] font-mono font-bold">+{selectedRealm.potentialPills}</div>
              </div>
              <div className="bg-[#123d30] p-2 rounded-xl">
                <div className="text-[#8daea0] text-[10px]">Sect Merit</div>
                <div className="text-[#e2b054] font-mono font-bold">+{selectedRealm.potentialMerit}</div>
              </div>
            </div>
            <div className="text-[10px] text-[#9fc2b2]">
              Rare Drops: <span className="text-[#fde047]">{selectedRealm.drops.join(', ')}</span>
            </div>
          </div>

          {/* Squad Selection */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-bold font-dao text-sm text-[#fce18b]">
                2. Assemble Squad ({selectedSquadIds.length}/3 Disciples)
              </span>
              <span className="text-[11px] font-mono">
                Power: <strong className={teamCombatPower >= selectedRealm.recommendedPower ? 'text-[#86efac]' : 'text-amber-400'}>{formatLargeNumber(teamCombatPower)}</strong> / {formatLargeNumber(selectedRealm.recommendedPower)}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
              {availableDisciples.map((d) => {
                const isSelected = selectedSquadIds.includes(d.id);
                const realmEligible = d.currentRealmIndex >= selectedRealm.minRealmIndex;
                const dRealm = CULTIVATION_REALMS[d.currentRealmIndex]?.name || 'Layer 1';
                return (
                  <div
                    key={d.id}
                    onClick={() => toggleSelectDisciple(d.id)}
                    className={`p-2.5 rounded-xl border flex justify-between items-center cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#184838] border-[#4ade80] text-white shadow-xs'
                        : 'bg-[#09261d] border-[#1b4b3b] text-[#a4c5b7] hover:border-[#22c55e]/40'
                    }`}
                  >
                    <div className="min-w-0 pr-2">
                      <div className="font-bold text-xs flex items-center gap-1">
                        <span className="truncate">{d.name}</span>
                        {realmEligible ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                        ) : (
                          <Lock className="w-3 h-3 text-red-400 shrink-0" />
                        )}
                      </div>
                      <div className="text-[10px] text-[#9fc2b2] truncate">{dRealm} · {d.rank}</div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-xs font-mono font-bold text-[#fce18b]">
                        {formatLargeNumber(d.combatPower)}
                      </div>
                      <div className="text-[9px] text-[#86efac]">Root: {d.spiritRoot}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Honest Assessment Banner */}
          {selectedSquad.length > 0 && (
            <div
              className={`p-3 rounded-2xl border flex items-center justify-between gap-2 ${
                assessment.chance === 0
                  ? 'bg-red-950/60 border-red-500/60 text-red-200'
                  : assessment.chance < 75
                  ? 'bg-amber-950/60 border-amber-500/60 text-amber-200'
                  : 'bg-emerald-950/60 border-emerald-500/60 text-emerald-200'
              }`}
            >
              <div className="flex items-center gap-2 min-w-0">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span className="text-[11px] leading-snug">{assessment.reason}</span>
              </div>
              <span className="font-mono font-bold text-xs shrink-0 px-2 py-0.5 rounded bg-black/40">
                {assessment.chance}% Win
              </span>
            </div>
          )}

          {/* Dispatch Button */}
          <button
            disabled={!canDispatch}
            onClick={() => {
              soundEngine.playSwordSlash();
              onDispatchExpedition(selectedRealm, selectedSquad);
            }}
            className={`w-full py-3 rounded-2xl font-dao font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all min-h-[44px] ${
              !canDispatch
                ? 'bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700'
                : 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-98'
            }`}
          >
            <Swords className="w-4 h-4" />
            <span>
              {selectedSquad.length === 0
                ? 'Select Disciples to Dispatch'
                : assessment.chance === 0
                ? 'Squad Incapable — Realm or Power Too Low'
                : `Dispatch Expedition (${assessment.chance}% Success)`}
            </span>
          </button>
        </div>

        {/* Modal Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Secret Realms · Extreme World</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Close Expeditions
          </button>
        </div>
      </div>
    </div>
  );
};
