import React, { useState } from 'react';
import { X, Sparkles, Check, Shield } from 'lucide-react';
import { UserProfile } from '../../types';
import { soundFX } from '../../utils/soundEffects';

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  const [activeCategory, setActiveCategory] = useState<'cards' | 'tables' | 'badges'>('cards');
  const [equippedCard, setEquippedCard] = useState('card-emerald');
  const [equippedTable, setEquippedTable] = useState('table-emerald');

  if (!isOpen) return null;

  const cardDecks = [
    { id: 'card-default', name: 'الورق الكلاسيكي القياسي', rarity: 'شائع', icon: '🃏' },
    { id: 'card-emerald', name: 'ظهر الزمرد الملكي (Royal Emerald v1)', rarity: 'ملكي', icon: '👑' },
    { id: 'card-gold', name: 'الذهب الخالص الإمبراطوري', rarity: 'أسطوري', icon: '✨' },
  ];

  const tableFelts = [
    { id: 'table-emerald', name: 'طاولة الزمرد الكلاسيكية (Emerald Felt)', color: '#0f492b' },
    { id: 'table-obsidian', name: 'طاولة الفحم الملكي (Obsidian Velvet)', color: '#111827' },
    { id: 'table-ruby', name: 'طاولة المخمل الياقوتي (Royal Ruby)', color: '#450a0a' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="relative w-full max-w-2xl bg-[#07130c] border-2 border-amber-500/50 rounded-2xl shadow-[0_0_40px_rgba(16,185,129,0.3)] overflow-hidden text-right flex flex-col h-[70vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0b2416] via-[#123823] to-[#0b2416] border-b border-amber-500/30 p-4 flex items-center justify-between">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="text-gray-400 hover:text-amber-400 p-1 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-amber-300 flex items-center gap-2">
            <span>🎒</span>
            <span>مخزون اللاعب والأصول الشخصية</span>
          </h2>
        </div>

        {/* Category Tabs */}
        <div className="grid grid-cols-3 bg-[#050e08] border-b border-amber-950 p-1 text-xs font-bold">
          <button
            onClick={() => setActiveCategory('cards')}
            className={`py-2 text-center rounded-lg ${activeCategory === 'cards' ? 'bg-emerald-950 text-amber-300 border border-amber-500/40' : 'text-gray-400'}`}
          >
            أوراق اللعب 🃏
          </button>
          <button
            onClick={() => setActiveCategory('tables')}
            className={`py-2 text-center rounded-lg ${activeCategory === 'tables' ? 'bg-emerald-950 text-amber-300 border border-amber-500/40' : 'text-gray-400'}`}
          >
            جلود الطاولات 🟢
          </button>
          <button
            onClick={() => setActiveCategory('badges')}
            className={`py-2 text-center rounded-lg ${activeCategory === 'badges' ? 'bg-emerald-950 text-amber-300 border border-amber-500/40' : 'text-gray-400'}`}
          >
            الألقاب والشارات 🛡️
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 overflow-y-auto">
          {activeCategory === 'cards' && (
            <div className="space-y-3">
              {cardDecks.map((deck) => (
                <div
                  key={deck.id}
                  className="p-3.5 rounded-xl bg-[#05110a] border border-amber-950 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{deck.icon}</span>
                    <div>
                      <h4 className="font-bold text-sm text-gray-100">{deck.name}</h4>
                      <span className="text-[10px] text-amber-400">{deck.rarity}</span>
                    </div>
                  </div>
                  {equippedCard === deck.id ? (
                    <div className="flex items-center gap-1 text-xs text-emerald-400 font-bold px-3 py-1 bg-emerald-950/60 rounded-lg border border-emerald-600/40">
                      <Check className="w-3.5 h-3.5" /> مفعّل حاليًا
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        soundFX.playButtonClick();
                        setEquippedCard(deck.id);
                      }}
                      className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-black text-xs font-bold"
                    >
                      تجهيز
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {activeCategory === 'tables' && (
            <div className="space-y-3">
              {tableFelts.map((felt) => (
                <div
                  key={felt.id}
                  className="p-3.5 rounded-xl bg-[#05110a] border border-amber-950 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full border border-amber-400 shadow-inner" style={{ backgroundColor: felt.color }} />
                    <h4 className="font-bold text-sm text-gray-100">{felt.name}</h4>
                  </div>
                  {equippedTable === felt.id ? (
                    <div className="flex items-center gap-1 text-xs text-emerald-400 font-bold px-3 py-1 bg-emerald-950/60 rounded-lg border border-emerald-600/40">
                      <Check className="w-3.5 h-3.5" /> مفعّل حاليًا
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        soundFX.playButtonClick();
                        setEquippedTable(felt.id);
                      }}
                      className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-black text-xs font-bold"
                    >
                      تجهيز
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {activeCategory === 'badges' && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-xl bg-[#05110a] border border-amber-950 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-amber-300">الماستر الملكي 👑</h4>
                  <span className="text-xs text-gray-400">لقب المستوى 14</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-emerald-400 font-bold px-3 py-1 bg-emerald-950/60 rounded-lg border border-emerald-600/40">
                  <Check className="w-3.5 h-3.5" /> مجهّز
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#05110a] border border-amber-950 flex items-center justify-between opacity-60">
                <div>
                  <h4 className="font-bold text-sm text-gray-300">صائد البطولات 🏆</h4>
                  <span className="text-xs text-gray-400">يتطلب الفوز ببطولتين</span>
                </div>
                <span className="text-xs text-gray-500">مغلق</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
