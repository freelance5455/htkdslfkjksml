import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Disciple, DiscipleRelation, SpiritRootType } from '../../types/cultivation';
import { CULTIVATION_REALMS } from '../../data/realms';
import { CultivatorAvatar } from '../cultivation/CultivatorAvatar';
import { soundEngine } from '../../services/audioEngine';
import { motion, AnimatePresence } from 'framer-motion';
import peakArenaArt from '../../assets/images/art_peak_arena_1794844216353.jpg';
import {
  Swords,
  Skull,
  Lock,
  Play,
  Pause,
  AlertTriangle,
  X,
  HeartHandshake
} from 'lucide-react';

interface LifeDeathArenaModalProps {
  disciples: Disciple[];
  relations: DiscipleRelation[];
  onClose: () => void;
  onResolveLifeDeathDuel: (victorId: string, loserId: string, relationId: string) => void;
}

type SpeedMode = -3 | -2 | -1 | 1 | 2 | 3;
const SPEED_OPTIONS: SpeedMode[] = [-3, -2, -1, 1, 2, 3];

function getDelayMs(speed: SpeedMode): number {
  switch (speed) {
    case -3: return 3200;
    case -2: return 2400;
    case -1: return 1700;
    case 1: return 1050;
    case 2: return 640;
    case 3: return 400;
  }
}

function getTechniqueLabel(root: SpiritRootType, heavy: boolean): string {
  const styles: Record<string, [string, string]> = {
    Fire: ['Crimson Ember Palm', 'Hellfire Lotus Extinction'],
    Ice: ['Glacial Fang Thrust', 'Eternal Abyssal Frost Seal'],
    Thunder: ['Purple Arc Flash', 'Heaven-Shattering Thunder Judgement'],
    Wind: ['Gale Edge Cleave', 'Void-Severing Tempest Slash'],
    Chaos: ['Primordial Rift Strike', 'Chaos Oblivion Slash']
  };
  const pair = styles[root] || ['Focused Qi Slash', `${root} Mortal Ruin Art`];
  return heavy ? pair[1] : pair[0];
}

export const LifeDeathArenaModal: React.FC<LifeDeathArenaModalProps> = ({
  disciples,
  relations,
  onClose,
  onResolveLifeDeathDuel
}) => {
  const [selectedRelationId, setSelectedRelationId] = useState<string | null>(null);
  const [stage, setStage] = useState<'select' | 'arena' | 'ended'>('select');
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<SpeedMode>(1);
  const [turnPhase, setTurnPhase] = useState<'A' | 'B'>('A');
  const [turnCount, setTurnCount] = useState<number>(1);

  const [hpA, setHpA] = useState<number>(100);
  const [maxHpA, setMaxHpA] = useState<number>(100);
  const [hpB, setHpB] = useState<number>(100);
  const [maxHpB, setMaxHpB] = useState<number>(100);

  const [activeAttackSide, setActiveAttackSide] = useState<'A' | 'B' | null>(null);
  const [activeHurtSide, setActiveHurtSide] = useState<'A' | 'B' | null>(null);
  const [strikeBanner, setStrikeBanner] = useState<string | null>(null);
  const [logs, setLogs] = useState<string[]>([]);
  const [victorId, setVictorId] = useState<string | null>(null);
  const [loserId, setLoserId] = useState<string | null>(null);

  const duelResolvedRef = useRef<boolean>(false);
  const animTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (animTimerRef.current) window.clearTimeout(animTimerRef.current);
    };
  }, []);

  const conflictPairs = useMemo(() => {
    return relations
      .map(rel => {
        const dA = disciples.find(d => d.id === rel.discipleId1 && !d.isPerished);
        const dB = disciples.find(d => d.id === rel.discipleId2 && !d.isPerished);
        if (!dA || !dB) return null;
        const grudge = Math.round(rel.grudge || 0);
        return {
          rel,
          dA,
          dB,
          grudge,
          isEligible: grudge >= 80 && grudge <= 100
        };
      })
      .filter((x): x is NonNullable<typeof x> => x !== null && x.grudge > 0)
      .sort((a, b) => b.grudge - a.grudge);
  }, [disciples, relations]);

  const activePair = conflictPairs.find(p => p.rel.id === selectedRelationId) || null;

  const startDuel = () => {
    if (!activePair || !activePair.isEligible) return;
    soundEngine.playGong();
    duelResolvedRef.current = false;

    const aMax = Math.max(120, activePair.dA.maxHp || 100 + activePair.dA.combatPower * 2);
    const bMax = Math.max(120, activePair.dB.maxHp || 100 + activePair.dB.combatPower * 2);

    setMaxHpA(aMax);
    setHpA(aMax);
    setMaxHpB(bMax);
    setHpB(bMax);
    setTurnCount(1);
    setTurnPhase('A');
    setIsPaused(false);
    setActiveAttackSide(null);
    setActiveHurtSide(null);
    setStrikeBanner(null);
    setVictorId(null);
    setLoserId(null);
    setLogs([
      `The Obsidian Grudge Stele seals the ring. ${activePair.dA.name} vs ${activePair.dB.name} (${activePair.grudge} Grudge) — no mercy granted.`
    ]);
    setStage('arena');
  };

  useEffect(() => {
    if (stage !== 'arena' || isPaused || !activePair || hpA <= 0 || hpB <= 0 || duelResolvedRef.current) return;

    const delay = getDelayMs(playbackSpeed);
    const timer = window.setTimeout(() => {
      const attacker = turnPhase === 'A' ? activePair.dA : activePair.dB;
      const defender = turnPhase === 'A' ? activePair.dB : activePair.dA;
      const isCrit = Math.random() < 0.28;
      const skill = getTechniqueLabel(attacker.spiritRoot, isCrit);

      const base = 18 + attacker.combatPower * 0.16 + Math.random() * 14;
      const dmg = Math.max(10, Math.floor(base * (isCrit ? 1.45 : 1.0)));

      if (isCrit) soundEngine.playThunder();
      else soundEngine.playSwordSlash();

      setActiveAttackSide(turnPhase);
      setActiveHurtSide(turnPhase === 'A' ? 'B' : 'A');
      setStrikeBanner(`${attacker.name} · ${skill} (-${dmg} HP)`);

      if (animTimerRef.current) window.clearTimeout(animTimerRef.current);
      animTimerRef.current = window.setTimeout(() => {
        setActiveAttackSide(null);
        setActiveHurtSide(null);
      }, Math.min(580, Math.round(delay * 0.65)));

      setLogs(prev => [
        `Turn ${turnCount}: ${attacker.name} unleashes [${skill}] for ${dmg} lethal damage!`,
        ...prev.slice(0, 14)
      ]);

      if (turnPhase === 'A') {
        const nextB = Math.max(0, hpB - dmg);
        setHpB(nextB);
        if (nextB <= 0) {
          duelResolvedRef.current = true;
          soundEngine.playBreakthroughFail();
          setVictorId(attacker.id);
          setLoserId(defender.id);
          setStage('ended');
          return;
        }
        setTurnPhase('B');
      } else {
        const nextA = Math.max(0, hpA - dmg);
        setHpA(nextA);
        if (nextA <= 0) {
          duelResolvedRef.current = true;
          soundEngine.playBreakthroughFail();
          setVictorId(attacker.id);
          setLoserId(defender.id);
          setStage('ended');
          return;
        }
        setTurnPhase('A');
      }
      setTurnCount(t => t + 1);
    }, delay);

    return () => window.clearTimeout(timer);
  }, [stage, isPaused, playbackSpeed, turnPhase, turnCount, hpA, hpB, activePair]);

  const handleConfirmPerishedRecord = () => {
    if (!victorId || !loserId || !activePair) return;
    onResolveLifeDeathDuel(victorId, loserId, activePair.rel.id || '');
    onClose();
  };

  return (
    <div
      onClick={e => { if (e.target === e.currentTarget && stage !== 'ended') onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/92 backdrop-blur-md"
    >
      <div className="bg-[#1b0b0e] border-2 border-rose-500/70 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] text-[#f5e9ea]">
        {/* Header */}
        <div className="p-3.5 sm:p-4 border-b border-rose-500/35 bg-[#120608] flex justify-between items-center gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-rose-500/15 border border-rose-400/50 flex items-center justify-center shrink-0">
              <Skull className="w-5 h-5 text-rose-400" />
            </div>
            <div className="min-w-0">
              <h3 className="font-dao font-bold text-sm sm:text-base text-rose-200 truncate">
                Life-and-Death Grudge Arena
              </h3>
              <p className="text-[11px] text-rose-300/80 truncate">
                80–100 Grudge mortal trial · Zero rewards · Defeated disciple perishes permanently
              </p>
            </div>
          </div>

          {stage !== 'ended' && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-[#271014] text-rose-200 hover:text-white border border-rose-500/30 min-w-[38px] min-h-[38px] flex items-center justify-center shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="p-4 overflow-y-auto space-y-4 grow text-xs">
          {/* SELECT STAGE */}
          {stage === 'select' && (
            <div className="space-y-4">
              <div className="bg-[#281014] border border-rose-500/40 rounded-2xl p-3 flex items-start gap-2.5 text-[11px] text-rose-200">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>
                  Only rivalries reaching <strong>80–100 Grudge</strong> are permitted to step onto the Obsidian Killing Stone. Lower grudges (<strong>1–79</strong>) remain forbidden here and should be resolved through Bonds &amp; Mediation. Neither Spirit Stones nor items are granted.
                </span>
              </div>

              {conflictPairs.length === 0 ? (
                <div className="bg-[#120608] border border-rose-900/50 rounded-2xl p-6 text-center space-y-2 text-rose-200/75">
                  <HeartHandshake className="w-8 h-8 text-emerald-400 mx-auto" />
                  <p className="font-dao font-bold text-sm text-[#fce18b]">No Blood Feuds Within the Sect</p>
                  <p className="text-[11px]">Your disciples currently hold no active grudges.</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                  {conflictPairs.map(({ rel, dA, dB, grudge, isEligible }) => {
                    const isSelected = selectedRelationId === rel.id;
                    return (
                      <button
                        key={rel.id || `${dA.id}_${dB.id}`}
                        type="button"
                        onClick={() => {
                          soundEngine.playClick();
                          setSelectedRelationId(rel.id || null);
                        }}
                        className={`w-full p-3 rounded-2xl border text-left transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${
                          !isEligible
                            ? 'bg-[#140a0c] border-rose-950/70 opacity-75'
                            : isSelected
                            ? 'bg-[#361117] border-rose-400 shadow-lg'
                            : 'bg-[#220c10] border-rose-700/50 hover:border-rose-400'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <CultivatorAvatar
                            gender={dA.gender}
                            rank={dA.rank}
                            spiritRoot={dA.spiritRoot}
                            realmIndex={dA.currentRealmIndex}
                            size="sm"
                          />
                          <div className="min-w-0">
                            <div className="font-dao font-bold text-rose-100 truncate">
                              {dA.name} vs {dB.name}
                            </div>
                            <div className="text-[10px] text-rose-300/80">
                              {CULTIVATION_REALMS[dA.currentRealmIndex]?.name} vs {CULTIVATION_REALMS[dB.currentRealmIndex]?.name}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <span className={`font-mono tabular-nums font-bold text-[11px] ${isEligible ? 'text-rose-300' : 'text-amber-300'}`}>
                            Grudge {grudge}/100
                          </span>
                          {!isEligible ? (
                            <span className="flex items-center gap-1 text-[10px] text-amber-300/90">
                              <Lock className="w-3.5 h-3.5" />
                              <span>Requires 80–100 · Use Mediation</span>
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold text-rose-200 underline">
                              Eligible Mortal Feud
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {activePair && activePair.isEligible && (
                <button
                  onClick={startDuel}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-700 to-red-600 hover:brightness-110 text-white font-dao font-bold text-sm flex items-center justify-center gap-2 shadow-xl"
                >
                  <Swords className="w-4 h-4" />
                  <span>Seal Death Pact: {activePair.dA.name} vs {activePair.dB.name}</span>
                </button>
              )}
            </div>
          )}

          {/* ARENA DUEL STAGE */}
          {stage === 'arena' && activePair && (
            <div className="space-y-3">
              <div className="flex flex-wrap justify-between items-center bg-[#140709] p-2 rounded-2xl border border-rose-500/35 gap-2">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setIsPaused(p => !p)}
                    className="p-1.5 rounded-lg bg-[#281014] text-rose-200 border border-rose-400/40 min-w-[34px] min-h-[34px] flex items-center justify-center"
                  >
                    {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                  </button>
                  <div className="flex items-center bg-[#0d0405] p-0.5 rounded-lg border border-rose-900/50">
                    {SPEED_OPTIONS.map(spd => (
                      <button
                        key={spd}
                        onClick={() => setPlaybackSpeed(spd)}
                        className={`px-1.5 py-1 rounded text-[10px] font-mono tabular-nums font-bold ${
                          playbackSpeed === spd ? 'bg-rose-600 text-white' : 'text-rose-300/70 hover:text-white'
                        }`}
                      >
                        {spd}x
                      </button>
                    ))}
                  </div>
                </div>
                <span className="font-mono tabular-nums text-[10px] text-rose-200">
                  Turn {turnCount} · Grudge {activePair.grudge}/100
                </span>
              </div>

              <div className="relative overflow-hidden rounded-3xl border-2 border-rose-500/60 p-4 bg-[#120608]">
                <img
                  src={peakArenaArt}
                  alt="Obsidian Life and Death Ring"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover opacity-25 pointer-events-none"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-[#160609]/85 via-[#220a0e]/70 to-[#110406]/92 pointer-events-none" />

                <div className="relative z-10 space-y-4">
                  <AnimatePresence>
                    {strikeBanner && (
                      <motion.div
                        key={strikeBanner}
                        initial={{ opacity: 0, y: -4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        className="text-center text-[11px] font-dao font-bold text-rose-200 bg-black/75 border border-rose-400/50 py-1 px-3 rounded-lg mx-auto w-fit"
                      >
                        ⚔ {strikeBanner}
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div className="grid grid-cols-7 gap-1 items-center text-center">
                    <div className="col-span-3 flex flex-col items-center">
                      <motion.div
                        animate={activeAttackSide === 'A' ? { x: 36, scale: 1.08 } : { x: 0, scale: 1 }}
                        className={activeHurtSide === 'A' ? 'animate-hit-shake' : ''}
                      >
                        <CultivatorAvatar
                          gender={activePair.dA.gender}
                          rank={activePair.dA.rank}
                          spiritRoot={activePair.dA.spiritRoot}
                          realmIndex={activePair.dA.currentRealmIndex}
                          appearanceIndex={activePair.dA.appearanceIndex ?? activePair.dA.avatarStyle?.appearanceIndex}
                          skinTone={activePair.dA.skinTone ?? activePair.dA.avatarStyle?.skinTone}
                          clothingColor={activePair.dA.clothingColor ?? activePair.dA.avatarStyle?.clothingColor}
                          hairColor={activePair.dA.hairColor ?? activePair.dA.avatarStyle?.hairColor}
                          expression="Fierce"
                          size="md"
                        />
                      </motion.div>
                      <div className="font-bold text-rose-100 text-[11px] mt-1 truncate max-w-[120px]">{activePair.dA.name}</div>
                      <div className="w-full bg-[#361116] h-2.5 rounded-full mt-1 overflow-hidden border border-rose-700">
                        <div className="bg-rose-500 h-full transition-all duration-300" style={{ width: `${Math.max(0, (hpA / maxHpA) * 100)}%` }} />
                      </div>
                      <span className="text-[9px] font-mono tabular-nums text-rose-300 mt-0.5">HP {hpA}/{maxHpA}</span>
                    </div>

                    <div className="col-span-1 flex justify-center">
                      <div className="w-9 h-9 rounded-full bg-rose-900 border border-rose-400 flex items-center justify-center font-dao font-black text-[11px]">
                        VS
                      </div>
                    </div>

                    <div className="col-span-3 flex flex-col items-center">
                      <motion.div
                        animate={activeAttackSide === 'B' ? { x: -36, scale: 1.08 } : { x: 0, scale: 1 }}
                        className={activeHurtSide === 'B' ? 'animate-hit-shake' : ''}
                      >
                        <CultivatorAvatar
                          gender={activePair.dB.gender}
                          rank={activePair.dB.rank}
                          spiritRoot={activePair.dB.spiritRoot}
                          realmIndex={activePair.dB.currentRealmIndex}
                          appearanceIndex={activePair.dB.appearanceIndex ?? activePair.dB.avatarStyle?.appearanceIndex}
                          skinTone={activePair.dB.skinTone ?? activePair.dB.avatarStyle?.skinTone}
                          clothingColor={activePair.dB.clothingColor ?? activePair.dB.avatarStyle?.clothingColor}
                          hairColor={activePair.dB.hairColor ?? activePair.dB.avatarStyle?.hairColor}
                          expression="Fierce"
                          size="md"
                        />
                      </motion.div>
                      <div className="font-bold text-rose-100 text-[11px] mt-1 truncate max-w-[120px]">{activePair.dB.name}</div>
                      <div className="w-full bg-[#361116] h-2.5 rounded-full mt-1 overflow-hidden border border-rose-700">
                        <div className="bg-rose-500 h-full transition-all duration-300" style={{ width: `${Math.max(0, (hpB / maxHpB) * 100)}%` }} />
                      </div>
                      <span className="text-[9px] font-mono tabular-nums text-rose-300 mt-0.5">HP {hpB}/{maxHpB}</span>
                    </div>
                  </div>

                  <div className="bg-black/60 p-2.5 rounded-2xl border border-rose-900/60 h-28 overflow-y-auto space-y-1 text-[10px] font-mono">
                    {logs.map((entry, idx) => (
                      <div key={idx} className="text-rose-200/90 leading-snug">{entry}</div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ENDED STAGE */}
          {stage === 'ended' && activePair && (
            <div className="bg-[#230b0f] border-2 border-rose-400/70 rounded-3xl p-5 text-center space-y-3">
              <Skull className="w-9 h-9 text-rose-400 mx-auto" />
              <h4 className="font-dao font-bold text-lg text-[#fce18b]">Mortal Grudge Concluded</h4>
              <p className="text-xs text-rose-100 leading-relaxed">
                <strong>{victorId === activePair.dA.id ? activePair.dA.name : activePair.dB.name}</strong> stood last upon the Killing Stone.{' '}
                <strong>{loserId === activePair.dA.id ? activePair.dA.name : activePair.dB.name}</strong> fell beneath the blade and enters the Ancestral Lineage Archive forever. No currency or items are awarded.
              </p>
              <button
                onClick={handleConfirmPerishedRecord}
                className="w-full py-3 rounded-xl bg-rose-800 hover:bg-rose-700 text-white font-dao font-bold text-sm"
              >
                Seal Fate &amp; Record in Lineage Archive
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
