import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Printer,
  Award,
  GraduationCap,
  CheckCircle,
} from 'lucide-react';

export const ReportCardModal: React.FC = () => {
  const { selectedReportCard, setSelectedReportCard } = useApp();

  if (!selectedReportCard) return null;

  const card = selectedReportCard;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Controls Bar (hidden during print) */}
        <div className="px-6 py-3.5 bg-slate-900 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2 text-xs font-semibold">
            <GraduationCap className="w-4 h-4 text-indigo-400" />
            <span>Official Academic Progress & Examination Report Card</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Export PDF</span>
            </button>
            <button
              onClick={() => setSelectedReportCard(null)}
              className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Academic Report Card Sheet */}
        <div className="p-8 sm:p-10 space-y-6 text-slate-800" id="printable-report-card">
          {/* Header */}
          <div className="text-center pb-6 border-b-2 border-slate-900">
            <img
              src="/assets/aistudio/1793372617949_97205839.jpg"
              alt="Academy Seal"
              className="w-16 h-16 rounded-xl object-cover mx-auto mb-2 border border-slate-300 shadow-xs"
            />
            <h1 className="text-xl font-bold tracking-tight text-slate-900 uppercase">
              Synapse Academy of Science & Technology
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Office of the Academic Registrar · Term Examination & Performance Record
            </p>
            <div className="mt-3 inline-block px-4 py-1 bg-slate-100 rounded-full font-mono text-xs font-bold text-slate-800 uppercase tracking-widest">
              {card.term} · Academic Year {card.academicYear}
            </div>
          </div>

          {/* Student Profile Info Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Student Name</div>
              <div className="font-bold text-slate-900 text-sm mt-0.5">{card.studentName}</div>
            </div>
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Roll Number</div>
              <div className="font-mono font-bold text-slate-900 mt-0.5">{card.rollNumber}</div>
            </div>
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Class & Cohort</div>
              <div className="font-semibold text-slate-800 mt-0.5">{card.classGroup}</div>
            </div>
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Cumulative GPA</div>
              <div className="font-mono font-bold text-indigo-700 text-sm mt-0.5">
                {card.overallGPA.toFixed(2)} / 4.00
              </div>
            </div>
          </div>

          {/* Academic Results Matrix */}
          <div className="border border-slate-300 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 border-b border-slate-300 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-2.5 px-4">Academic Course / Subject</th>
                  <th className="py-2.5 px-3 text-center">Mid-Term</th>
                  <th className="py-2.5 px-3 text-center">Finals</th>
                  <th className="py-2.5 px-3 text-center">Assignments</th>
                  <th className="py-2.5 px-3 text-center font-bold">Total / 100</th>
                  <th className="py-2.5 px-3 text-center font-bold">Letter Grade</th>
                  <th className="py-2.5 px-4">Faculty Comments</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {card.subjects.map((sub, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50">
                    <td className="py-3 px-4 font-semibold text-slate-900">{sub.subject}</td>
                    <td className="py-3 px-3 text-center font-mono">{sub.midTermMarks}</td>
                    <td className="py-3 px-3 text-center font-mono">{sub.finalExamMarks}</td>
                    <td className="py-3 px-3 text-center font-mono">{sub.assignmentMarks}</td>
                    <td className="py-3 px-3 text-center font-mono font-bold text-slate-900">
                      {sub.totalMarks}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-900">
                        {sub.grade}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600 text-[11px]">{sub.remarks}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Attendance & Distinction Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 border border-slate-200 rounded-xl">
              <div className="text-[11px] font-semibold uppercase text-slate-400 mb-1">
                Faculty Advisor Assessment
              </div>
              <p className="text-slate-700 italic leading-relaxed">
                "{card.teacherRemarks}"
              </p>
            </div>
            <div className="p-4 border border-slate-200 rounded-xl">
              <div className="text-[11px] font-semibold uppercase text-slate-400 mb-1">
                Dean’s Office Commendation
              </div>
              <p className="text-slate-700 italic leading-relaxed">
                "{card.principalRemarks}"
              </p>
            </div>
          </div>

          {/* Signature & Seal Footer */}
          <div className="pt-6 border-t border-slate-200 flex items-center justify-between text-xs">
            <div>
              <div className="text-[11px] text-slate-400 uppercase font-semibold">Issue Date</div>
              <div className="font-mono text-slate-700">{card.issueDate}</div>
            </div>

            <div className="text-center">
              <div className="font-serif italic text-sm text-slate-900 border-b border-slate-400 pb-1 px-6">
                Arthur Pendelton, Ph.D.
              </div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider mt-1">
                Department Chair
              </div>
            </div>

            <div className="text-center">
              <div className="font-serif italic text-sm text-slate-900 border-b border-slate-400 pb-1 px-6">
                Dr. Evelyn Vance
              </div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider mt-1">
                Academic Dean
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
