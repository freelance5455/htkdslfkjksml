import React from 'react';
import { YearEndCeremonyReport } from '../../types/cultivation';
import { formatLargeNumber } from '../../data/realms';
import { soundEngine } from '../../services/audioEngine';
import spiritBladeArt from '../../assets/images/art_spirit_blade_1794844217347.jpg';
import spiritResourcesArt from '../../assets/images/art_spirit_resources_1794844216623.jpg';
import { Crown, Award, Sparkles, Package, Swords, X } from 'lucide-react';

interface YearEndCeremonyModalProps {
  report: YearEndCeremonyReport;
  onClose: () => void;
}

export const YearEndCeremonyModal: React.FC<YearEndCeremonyModalProps> = ({
  report,
  onClose
}) => {
  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/88 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#fce18b] rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header with Bespoke Resources Art */}
        <div className="relative overflow-hidden bg-[#0b261d] p-4 border-b border-[#e2b054]/50 flex justify-between items-center">
          <img
            src={spiritResourcesArt}
            alt="Annual Immortal Awards Ceremony"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover opacity-25 pointer-events-none"
          />
          <div className="relative z-10 flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-[#fce18b] flex items-center justify-center">
              <Crown className="w-5 h-5 text-[#fce18b]" />
            </div>
            <div>
              <h3 className="font-dao font-bold text-base sm:text-lg text-[#fce18b]">
                Year {report.year} Immortal Awards Ceremony
              </h3>
              <p className="text-[11px] text-[#d1e6dc]">
                Celestial Heavenly Pavilion Appraisal across Extreme World
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="relative z-10 p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[38px] min-h-[38px] flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-3 grow text-xs text-[#d1e6dc]">
          {/* 1. Strongest Sect */}
          <div className={`p-3.5 rounded-2xl border space-y-1.5 ${
            report.strongestWinner.isPlayer
              ? 'bg-gradient-to-r from-[#1c4e38] to-[#0f3427] border-[#fce18b]'
              : 'bg-[#09261d] border-[#1b4b3b]'
          }`}>
            <div className="flex justify-between items-center">
              <span className="font-dao font-bold text-sm text-[#fce18b] flex items-center gap-1.5">
                <Swords className="w-4 h-4 text-amber-300" />
                <span>Strongest Sect Award</span>
              </span>
              <span className={`text-[11px] font-bold ${report.strongestWinner.isPlayer ? 'text-emerald-300' : 'text-[#9fc2b2]'}`}>
                {report.strongestWinner.isPlayer ? 'Won by Your Sect!' : 'Foreign Winner'}
              </span>
            </div>
            <div className="flex justify-between items-center text-[11px]">
              <span className="font-bold text-white">{report.strongestWinner.sectName}</span>
              <span className="font-mono tabular-nums text-sky-300">
                Martial Score: {formatLargeNumber(report.strongestWinner.score)}
              </span>
            </div>
            <div className="text-[11px] text-[#86efac]">
              Prize: {report.strongestWinner.rewardText}
            </div>
          </div>

          {/* 2. Most Contributions */}
          <div className={`p-3.5 rounded-2xl border space-y-1.5 ${
            report.contributionsWinner.isPlayer
              ? 'bg-gradient-to-r from-[#1c4e38] to-[#0f3427] border-[#fce18b]'
              : 'bg-[#09261d] border-[#1b4b3b]'
          }`}>
            <div className="flex justify-between items-center">
              <span className="font-dao font-bold text-sm text-[#fce18b] flex items-center gap-1.5">
                <Award className="w-4 h-4 text-emerald-300" />
                <span>Most Contributions Award</span>
              </span>
              <span className={`text-[11px] font-bold ${report.contributionsWinner.isPlayer ? 'text-emerald-300' : 'text-[#9fc2b2]'}`}>
                {report.contributionsWinner.isPlayer ? 'Won by Your Sect!' : 'Foreign Winner'}
              </span>
            </div>
            <div className="flex justify-between items-center text-[11px]">
              <span className="font-bold text-white">{report.contributionsWinner.sectName}</span>
              <span className="font-mono tabular-nums text-amber-300">
                Merit Score: {formatLargeNumber(report.contributionsWinner.score)}
              </span>
            </div>
            <div className="text-[11px] text-[#86efac]">
              Prize: {report.contributionsWinner.rewardText}
            </div>
          </div>

          {/* 3. Most Prodigies & Talents */}
          <div className={`relative overflow-hidden p-3.5 rounded-2xl border space-y-2 ${
            report.prodigiesWinner.isPlayer
              ? 'bg-gradient-to-r from-[#1c4e38] to-[#0f3427] border-[#fce18b]'
              : 'bg-[#09261d] border-[#1b4b3b]'
          }`}>
            {report.prodigiesWinner.isPlayer && (
              <img
                src={spiritBladeArt}
                alt="Mid-Tier Immortal Equipment Award"
                referrerPolicy="no-referrer"
                className="absolute right-0 top-0 h-full w-24 object-cover opacity-20 pointer-events-none"
              />
            )}
            <div className="relative z-10 flex justify-between items-center">
              <span className="font-dao font-bold text-sm text-[#fce18b] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-sky-300" />
                <span>Most Prodigies &amp; Talents</span>
              </span>
              <span className={`text-[11px] font-bold ${report.prodigiesWinner.isPlayer ? 'text-emerald-300' : 'text-[#9fc2b2]'}`}>
                {report.prodigiesWinner.isPlayer ? 'Won by Your Sect!' : 'Foreign Winner'}
              </span>
            </div>
            <div className="relative z-10 flex justify-between items-center text-[11px]">
              <span className="font-bold text-white">{report.prodigiesWinner.sectName}</span>
              <span className="font-mono tabular-nums text-purple-300">
                Prodigy Index: {formatLargeNumber(report.prodigiesWinner.score)}
              </span>
            </div>
            {report.prodigiesWinner.isPlayer && report.prodigiesWinner.giftedGearNames.length > 0 ? (
              <div className="relative z-10 bg-[#0b261d]/90 p-2.5 rounded-xl border border-[#e2b054]/40 space-y-1">
                <div className="text-[10px] font-bold text-[#fce18b] flex items-center gap-1">
                  <Package className="w-3.5 h-3.5" />
                  <span>3 Mid-Tier Relics Deposited to Sect Storage:</span>
                </div>
                {report.prodigiesWinner.giftedGearNames.map((name, i) => (
                  <div key={i} className="text-[11px] text-emerald-200 pl-4">
                    • {name}
                  </div>
                ))}
              </div>
            ) : (
              <div className="relative z-10 text-[11px] text-[#9fc2b2]">
                Prize: 3 Mid-Tier Spiritual/Earth Equipment Relics stored directly in Sect Vault.
              </div>
            )}
          </div>
        </div>

        <div className="p-3.5 bg-[#081e17] border-t border-[#133d30] flex justify-end">
          <button
            onClick={() => {
              soundEngine.playFanfare();
              onClose();
            }}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs shadow-md hover:brightness-110 active:scale-95 transition-all"
          >
            Receive Celestial Decree
          </button>
        </div>
      </div>
    </div>
  );
};
