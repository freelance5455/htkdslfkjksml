import React, { useState, useEffect, useRef } from 'react';
import { Disciple } from '../../types/cultivation';
import { CULTIVATION_REALMS, formatLargeNumber } from '../../data/realms';
import { CultivatorAvatar } from '../cultivation/CultivatorAvatar';
import { soundEngine } from '../../services/audioEngine';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sparkles,
  Zap,
  Heart,
  Shield,
  Clock,
  Swords,
  ChevronRight,
  Flame,
  AlertTriangle,
  FastForward,
  CheckCircle2,
  X
} from 'lucide-react';

interface BreakthroughModalProps {
  disciple: Disciple;
  tribulationPlatformLevel?: number;
  pillsAvailable?: number;
  devMode?: boolean;
  onClose: () => void;
  onResolveBreakthrough: (
    disciple: Disciple,
    succeeded: boolean,
    usedPill: boolean,
    successRate: number
  ) => void;
}

export const calculateBreakthroughOdds = (
  disciple: Disciple,
  tribulationPlatformLevel: number = 1,
  usePill: boolean = false,
  devMode: boolean = false
): number => {
  if (devMode) return 100;
  const nextRealm = CULTIVATION_REALMS[disciple.currentRealmIndex + 1];
  if (!nextRealm) return 0;

  const isBodyCultivator = (disciple.cultivationType || 'Qi Cultivator') === 'Body Cultivator';
  const hasLightningTribulation = nextRealm.requiresTribulation && !isBodyCultivator;

  let base = hasLightningTribulation
    ? Math.max(40, 82 - disciple.currentRealmIndex * 1.4)
    : Math.max(62, 95 - disciple.currentRealmIndex * 0.9);

  base += Math.round((disciple.talent || 50) * 0.22);
  if (disciple.isFavorite) base += 10;
  if (disciple.soulProtected) base += 15;
  if (hasLightningTribulation) {
    base += Math.min(20, tribulationPlatformLevel * 2);
  } else if (isBodyCultivator) {
    // Body cultivators bypass Heavenly Tribulation wrath cleanly
    base += 8;
  }
  if (usePill) base += 22;

  const negCount = disciple.negativeTraits?.length || 0;
  base -= negCount * 9;
  base -= Math.floor((disciple.stress || 0) / 4);

  return Math.max(12, Math.min(99, Math.round(base)));
};

export const BreakthroughModal: React.FC<BreakthroughModalProps> = ({
  disciple,
  tribulationPlatformLevel = 1,
  pillsAvailable = 0,
  devMode = false,
  onClose,
  onResolveBreakthrough
}) => {
  const [phase, setPhase] = useState<'prep' | 'gathering' | 'tribulation' | 'result'>('prep');
  const [usePill, setUsePill] = useState<boolean>(false);
  const [succeeded, setSucceeded] = useState<boolean>(true);
  const [boltSeed, setBoltSeed] = useState<number>(0);

  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  const clearAllTimers = () => {
    timersRef.current.forEach(t => clearTimeout(t));
    timersRef.current = [];
  };

  useEffect(() => {
    return () => clearAllTimers();
  }, []);

  const currentRealm = CULTIVATION_REALMS[disciple.currentRealmIndex] || CULTIVATION_REALMS[0];
  const nextRealm = CULTIVATION_REALMS[disciple.currentRealmIndex + 1];
  if (!nextRealm) return null;

  const cultPath = disciple.cultivationType || 'Qi Cultivator';
  const isBodyCultivator = cultPath === 'Body Cultivator';
  const hasLightningTribulation = nextRealm.requiresTribulation && !isBodyCultivator;
  const computedRate = calculateBreakthroughOdds(disciple, tribulationPlatformLevel, usePill, devMode);

  const resolveOutcomeNow = (rollSucceeded: boolean) => {
    clearAllTimers();
    setSucceeded(rollSucceeded);
    setPhase('result');
    if (rollSucceeded) {
      soundEngine.playBreakthroughSuccess();
    } else {
      soundEngine.playBreakthroughFail();
    }
  };

  const startBreakthroughSequence = (skipImmediately: boolean = false) => {
    const roll = Math.random() * 100;
    const outcome = roll <= computedRate;

    if (skipImmediately) {
      resolveOutcomeNow(outcome);
      return;
    }

    setSucceeded(outcome);
    setPhase('gathering');
    soundEngine.playTalisman();

    const t1 = setTimeout(() => {
      setPhase('tribulation');
      setBoltSeed(s => s + 1);
      if (hasLightningTribulation) {
        soundEngine.playThunder();
      } else {
        soundEngine.playGong();
      }
    }, 950);

    const t2 = setTimeout(() => {
      setBoltSeed(s => s + 1);
      if (hasLightningTribulation) {
        soundEngine.playSwordSlash();
      }
    }, 1550);

    const t3 = setTimeout(() => {
      resolveOutcomeNow(outcome);
    }, 2350);

    timersRef.current = [t1, t2, t3];
  };

  const handleSkipAnimation = () => {
    soundEngine.playClick();
    resolveOutcomeNow(succeeded);
  };

  const handleSealAndClose = () => {
    onResolveBreakthrough(disciple, succeeded, usePill, computedRate);
    onClose();
  };

  const lifespanGained = nextRealm.lifespanBonus;
  const expLossOnFail = Math.floor(disciple.maxExp * 0.25);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/90 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.94 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.94 }}
        transition={{ duration: 0.22 }}
        className={`bg-[#081e17] border-2 rounded-3xl w-full max-w-lg overflow-hidden flex flex-col relative text-[#e8f1eb] shadow-2xl ${
          phase === 'result' && !succeeded
            ? 'border-red-500/80'
            : hasLightningTribulation && phase === 'tribulation'
            ? 'border-yellow-300'
            : 'border-[#e2b054]'
        }`}
      >
        {/* Compositor-only Animated Atmosphere Layer */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <motion.div
            animate={
              phase === 'tribulation'
                ? { opacity: [0.15, 0.55, 0.2, 0.65, 0.2], scale: [0.95, 1.08, 1] }
                : { opacity: 0.22, scale: 1 }
            }
            transition={{ duration: 0.9, repeat: phase === 'tribulation' ? Infinity : 0 }}
            className="absolute -top-12 left-1/2 -translate-x-1/2 w-80 h-80 rounded-full blur-3xl"
            style={{
              background:
                phase === 'result' && !succeeded
                  ? 'radial-gradient(circle, rgba(239,68,68,0.45), transparent)'
                  : isBodyCultivator
                  ? 'radial-gradient(circle, rgba(249,115,22,0.45), transparent)'
                  : hasLightningTribulation
                  ? 'radial-gradient(circle, rgba(250,204,21,0.55), transparent)'
                  : 'radial-gradient(circle, rgba(52,211,153,0.4), transparent)'
            }}
          />

          {/* Smooth SVG Tribulation Lightning Bolts or Flesh-Tempering Shockwave */}
          {phase === 'tribulation' && (
            <svg viewBox="0 0 400 320" className="absolute inset-0 w-full h-full">
              {hasLightningTribulation ? (
                <motion.g
                  key={boltSeed}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 1, 0.35, 1, 0.7] }}
                  transition={{ duration: 0.7 }}
                >
                  <path
                    d="M 110 0 L 145 75 L 122 86 L 170 165 L 152 174 L 195 235"
                    fill="none"
                    stroke="#fef08a"
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M 295 0 L 258 68 L 280 82 L 228 158 L 246 168 L 204 235"
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="3.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M 200 0 L 192 52 L 214 66 L 188 130 L 208 140 L 198 195"
                    fill="none"
                    stroke="#fde047"
                    strokeWidth="4.5"
                    strokeLinecap="round"
                  />
                </motion.g>
              ) : (
                <motion.g
                  initial={{ opacity: 0, scale: 0.7 }}
                  animate={{ opacity: [0.3, 0.9, 0.4], scale: [0.85, 1.12, 0.95] }}
                  transition={{ duration: 1.0, repeat: Infinity }}
                  style={{ transformOrigin: '200px 150px' }}
                >
                  <circle cx="200" cy="145" r="78" fill="none" stroke={isBodyCultivator ? '#fb923c' : '#34d399'} strokeWidth="3" strokeDasharray="10 6" />
                  <circle cx="200" cy="145" r="98" fill="none" stroke="#fce18b" strokeWidth="1.5" strokeDasharray="4 8" />
                </motion.g>
              )}
            </svg>
          )}
        </div>

        {/* Top Header */}
        <div className="relative z-10 p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center bg-[#061812]/90">
          <div className="flex items-center gap-2 min-w-0">
            {hasLightningTribulation ? (
              <Zap className="w-5 h-5 text-yellow-300 shrink-0" />
            ) : (
              <Sparkles className="w-5 h-5 text-[#fce18b] shrink-0" />
            )}
            <div className="min-w-0">
              <h3 className="font-dao font-bold text-sm sm:text-base text-[#fce18b] truncate">
                {phase === 'result'
                  ? succeeded
                    ? 'Realm Ascension Accomplished!'
                    : 'Breakthrough Backlash!'
                  : hasLightningTribulation
                  ? 'Heavenly Lightning Tribulation'
                  : isBodyCultivator
                  ? 'Body Tempering Bottleneck'
                  : 'Realm Bottleneck Breakthrough'}
              </h3>
              <p className="text-[11px] text-[#9fc2b2] truncate">
                {disciple.name} · <span className="text-amber-300 font-semibold">{cultPath}</span>
              </p>
            </div>
          </div>

          {(phase === 'gathering' || phase === 'tribulation') && (
            <button
              onClick={handleSkipAnimation}
              className="px-2.5 py-1.5 rounded-xl bg-[#184838] hover:bg-[#1f5b47] text-[#fce18b] border border-[#e2b054]/60 text-[11px] font-bold flex items-center gap-1 shrink-0 min-h-[36px]"
            >
              <FastForward className="w-3.5 h-3.5" />
              <span>Skip Animation</span>
            </button>
          )}

          {(phase === 'prep' || phase === 'result') && (
            <button
              onClick={phase === 'result' ? handleSealAndClose : onClose}
              className="p-2 rounded-xl bg-[#0b261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[38px] min-h-[38px] flex items-center justify-center shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Body Content */}
        <div className="relative z-10 p-4 sm:p-5 space-y-4 overflow-y-auto max-h-[74vh]">
          {/* Centerpiece Avatar & Realm Arrow */}
          <div className="flex flex-col items-center justify-center space-y-2">
            <motion.div
              animate={
                phase === 'tribulation'
                  ? { scale: [1, 1.05, 0.98, 1.04, 1], y: [0, -3, 0] }
                  : { scale: 1, y: 0 }
              }
              transition={{ duration: 0.65, repeat: phase === 'tribulation' ? Infinity : 0 }}
              className="relative"
            >
              <CultivatorAvatar
                gender={disciple.gender}
                rank={disciple.rank}
                spiritRoot={disciple.spiritRoot}
                realmIndex={phase === 'result' && succeeded ? disciple.currentRealmIndex + 1 : disciple.currentRealmIndex}
                isBreakthroughReady={true}
                appearanceIndex={disciple.appearanceIndex ?? disciple.avatarStyle?.appearanceIndex}
                skinTone={disciple.skinTone ?? disciple.avatarStyle?.skinTone}
                clothingColor={disciple.clothingColor ?? disciple.avatarStyle?.clothingColor}
                hairColor={disciple.hairColor ?? disciple.avatarStyle?.hairColor}
                expression={disciple.expression ?? disciple.avatarStyle?.expression}
                auraEffect={disciple.auraEffect ?? disciple.avatarStyle?.auraEffect}
                mythicalForm={disciple.mythicalForm ?? disciple.avatarStyle?.mythicalForm}
                soulProtected={disciple.soulProtected}
                size="xl"
              />
            </motion.div>

            <div className="text-center space-y-1">
              <div className="flex items-center justify-center gap-2 font-dao font-bold text-sm sm:text-base text-white">
                <span className="text-[#a4c5b7]">{currentRealm.name}</span>
                <ChevronRight className="w-4 h-4 text-amber-400" />
                <span className="text-[#fce18b]">{nextRealm.name}</span>
              </div>
              <div className="text-[10px] text-[#9fc2b2]">
                {isBodyCultivator
                  ? 'Body Cultivators temper flesh & bones directly — immune to Heavenly Lightning Tribulations.'
                  : hasLightningTribulation
                  ? `Major Realm Threshold: ${nextRealm.tribulationLightningPower || 2000} Thunder Pressure`
                  : 'Sub-stage meridian refinement breakthrough'}
              </div>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {/* PHASE 0: PREPARATION & PROBABILITY BREAKDOWN */}
            {phase === 'prep' && (
              <motion.div
                key="prep"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                className="space-y-3"
              >
                <div className="bg-[#0b261d] p-3.5 rounded-2xl border border-[#e2b054]/40 space-y-2.5">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-[#fce18b]">Estimated Success Rate</span>
                    <span
                      className={`text-lg font-mono font-extrabold tabular-nums ${
                        computedRate >= 75 ? 'text-emerald-400' : computedRate >= 50 ? 'text-amber-300' : 'text-red-400'
                      }`}
                    >
                      {computedRate}%
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5 text-[10px] text-[#a4c5b7]">
                    <div className="bg-[#081d16] px-2.5 py-1.5 rounded-lg border border-[#1b4b3b]">
                      Talent Bonus: <strong className="text-emerald-300">+{Math.round(disciple.talent * 0.22)}%</strong>
                    </div>
                    <div className="bg-[#081d16] px-2.5 py-1.5 rounded-lg border border-[#1b4b3b]">
                      {isBodyCultivator
                        ? <>Path Immunity: <strong className="text-amber-300">+8% (No Lightning)</strong></>
                        : <>Platform Ward: <strong className="text-sky-300">+{Math.min(20, tribulationPlatformLevel * 2)}%</strong></>}
                    </div>
                    {disciple.isFavorite && (
                      <div className="bg-[#081d16] px-2.5 py-1.5 rounded-lg border border-amber-500/40 text-amber-200">
                        Favorite Blessing: <strong>+10%</strong>
                      </div>
                    )}
                    {disciple.soulProtected && (
                      <div className="bg-[#081d16] px-2.5 py-1.5 rounded-lg border border-amber-500/40 text-amber-200">
                        Soul Seal Ward: <strong>+15%</strong>
                      </div>
                    )}
                    {(disciple.negativeTraits?.length || 0) > 0 && (
                      <div className="bg-red-950/60 px-2.5 py-1.5 rounded-lg border border-red-500/40 text-red-200">
                        Dao Flaws Penalty: <strong>-{(disciple.negativeTraits?.length || 0) * 9}%</strong>
                      </div>
                    )}
                  </div>

                  {/* Pill Assist Toggle */}
                  <button
                    type="button"
                    disabled={pillsAvailable <= 0 && !devMode}
                    onClick={() => {
                      soundEngine.playClick();
                      setUsePill(!usePill);
                    }}
                    className={`w-full p-2.5 rounded-xl border text-left flex justify-between items-center transition-all text-xs ${
                      usePill
                        ? 'bg-[#184838] border-[#4ade80] text-white'
                        : pillsAvailable > 0 || devMode
                        ? 'bg-[#09261d] border-[#1d5543] text-[#d1e6dc] hover:border-[#e2b054]/60'
                        : 'bg-[#081a14] border-[#13382c] text-[#5c7d70] cursor-not-allowed'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-[#fce18b]">Consume 1 Breakthrough Pill (+22% Odds)</div>
                      <div className="text-[10px] text-[#9fc2b2]">Sect Pill Stock: {pillsAvailable}</div>
                    </div>
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${usePill ? 'bg-emerald-600 text-white' : 'bg-[#123d30] text-[#9fc2b2]'}`}>
                      {usePill ? 'Using Pill' : 'Optional'}
                    </span>
                  </button>
                </div>

                {/* Possible Failure Consequences Warning */}
                <div className="bg-red-950/35 p-2.5 rounded-xl border border-red-700/40 text-[10px] text-red-200 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span>
                    If the breakthrough fails: consumes pill (if used), loses {formatLargeNumber(expLossOnFail)} EXP (-25%), adds +22 Stress, drops -20 Morale, and risks meridian backlash.
                  </span>
                </div>
              </motion.div>
            )}

            {/* PHASE 1: GATHERING */}
            {phase === 'gathering' && (
              <motion.div
                key="gathering"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-[#0e2a20] p-3.5 rounded-2xl border border-[#1b4b3b] text-center space-y-1.5"
              >
                <div className="text-xs font-bold text-[#fce18b] flex items-center justify-center gap-1.5">
                  <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
                  <span>
                    {isBodyCultivator ? 'Boiling Qi & Blood Through Bone Marrow...' : 'Condensing Dantian Spirit Sea...'}
                  </span>
                </div>
                <p className="text-[11px] text-[#9fc2b2]">
                  {isBodyCultivator
                    ? 'Pushing physical limits to shatter mortal shackles without disturbing celestial thunder.'
                    : 'Aligning twelve meridians to confront the realm barrier.'}
                </p>
              </motion.div>
            )}

            {/* PHASE 2: TRIBULATION OR BODY TEMPERING CLIMAX */}
            {phase === 'tribulation' && (
              <motion.div
                key="tribulation"
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                className={`p-3.5 rounded-2xl border text-center space-y-1.5 ${
                  hasLightningTribulation
                    ? 'bg-yellow-950/70 border-yellow-400/80'
                    : isBodyCultivator
                    ? 'bg-orange-950/70 border-orange-400/80'
                    : 'bg-emerald-950/70 border-emerald-400/80'
                }`}
              >
                <div className="text-xs font-bold text-yellow-300 flex items-center justify-center gap-1.5">
                  {hasLightningTribulation ? <Zap className="w-4 h-4" /> : <Shield className="w-4 h-4 text-orange-300" />}
                  <span>
                    {hasLightningTribulation
                      ? 'Nine-Heavens Thunder Tribulation Descending!'
                      : isBodyCultivator
                      ? 'Sacred Flesh Forging Climax!'
                      : 'Shattering Spiritual Bottleneck!'}
                  </span>
                </div>
                <p className="text-[11px] text-amber-100">
                  {hasLightningTribulation
                    ? `Deflecting ${nextRealm.tribulationLightningPower || 2000} lightning arcs (${computedRate}% survival odds)...`
                    : `Tempering physical core against realm pressure (${computedRate}% breakthrough odds)...`}
                </p>
              </motion.div>
            )}

            {/* PHASE 3: RESOLVED OUTCOME (SUCCESS OR FAILURE CONSEQUENCES) */}
            {phase === 'result' && (
              <motion.div
                key="result"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-3"
              >
                {succeeded ? (
                  <>
                    <div className="bg-gradient-to-r from-[#184838] to-[#123d30] p-3.5 rounded-2xl border border-emerald-400/70 text-center">
                      <span className="text-xs sm:text-sm font-dao font-bold text-[#86efac] flex items-center justify-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                        <span>Bottleneck Shattered! Realm Ascended!</span>
                      </span>
                      <p className="text-[11px] text-[#d1e6dc] mt-1">
                        {disciple.name} has broken into <strong className="text-[#fce18b]">{nextRealm.name}</strong> and purged accumulated bottleneck doubts!
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="bg-[#0b261d] p-2.5 rounded-xl border border-[#1b4b3b]">
                        <div className="flex items-center gap-1 text-[#9fc2b2] text-[10px]">
                          <Clock className="w-3.5 h-3.5 text-sky-400" />
                          <span>Lifespan Bonus</span>
                        </div>
                        <div className="text-sm font-bold font-mono text-sky-300 mt-0.5">
                          +{lifespanGained} yrs
                        </div>
                      </div>

                      <div className="bg-[#0b261d] p-2.5 rounded-xl border border-[#1b4b3b]">
                        <div className="flex items-center gap-1 text-[#9fc2b2] text-[10px]">
                          <Swords className="w-3.5 h-3.5 text-amber-400" />
                          <span>Combat Gain</span>
                        </div>
                        <div className="text-sm font-bold font-mono text-[#fce18b] mt-0.5">
                          +{formatLargeNumber(nextRealm.combatPower)}
                        </div>
                      </div>

                      <div className="bg-[#0b261d] p-2.5 rounded-xl border border-[#1b4b3b]">
                        <div className="flex items-center gap-1 text-[#9fc2b2] text-[10px]">
                          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Sect Prestige</span>
                        </div>
                        <div className="text-sm font-bold font-mono text-emerald-300 mt-0.5">
                          +{formatLargeNumber(nextRealm.prestigeYield)}
                        </div>
                      </div>

                      <div className="bg-[#0b261d] p-2.5 rounded-xl border border-[#1b4b3b]">
                        <div className="flex items-center gap-1 text-[#9fc2b2] text-[10px]">
                          <Heart className="w-3.5 h-3.5 text-rose-400" />
                          <span>Emotion &amp; Mind</span>
                        </div>
                        <div className="text-sm font-bold text-rose-200 mt-0.5">
                          Inspired (0 Stress)
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="bg-red-950/60 p-3.5 rounded-2xl border border-red-500/70 text-center">
                      <span className="text-xs sm:text-sm font-dao font-bold text-red-300 flex items-center justify-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-red-400" />
                        <span>Breakthrough Failed — Qi Deviation Backlash!</span>
                      </span>
                      <p className="text-[11px] text-red-100 mt-1">
                        {disciple.name}&apos;s spiritual assault fell short at {computedRate}% odds. Meridians trembled and vitality recessed.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="bg-[#1b0c0c] p-2.5 rounded-xl border border-red-800/60">
                        <span className="text-[10px] text-red-300 block">Cultivation EXP Lost</span>
                        <strong className="font-mono text-red-200">-{formatLargeNumber(expLossOnFail)} EXP</strong>
                      </div>
                      <div className="bg-[#1b0c0c] p-2.5 rounded-xl border border-red-800/60">
                        <span className="text-[10px] text-red-300 block">Mental Strain</span>
                        <strong className="font-mono text-red-200">+22 Stress · -20 Morale</strong>
                      </div>
                    </div>
                  </>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer Buttons */}
        <div className="relative z-10 p-3.5 bg-[#061812] border-t border-[#133d30] flex justify-between items-center gap-2 text-xs">
          {phase === 'prep' && (
            <>
              <button
                onClick={() => startBreakthroughSequence(true)}
                className="px-3.5 py-2 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] border border-[#e2b054]/40 font-bold text-[11px] flex items-center gap-1 min-h-[40px]"
              >
                <FastForward className="w-3.5 h-3.5" />
                <span>Instant Breakthrough</span>
              </button>
              <button
                onClick={() => startBreakthroughSequence(false)}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs sm:text-sm shadow-md hover:brightness-110 active:scale-95 transition-all min-h-[40px]"
              >
                Channel Breakthrough ({computedRate}%)
              </button>
            </>
          )}

          {(phase === 'gathering' || phase === 'tribulation') && (
            <>
              <span className="text-[#9fc2b2] text-[11px]">Resolving heavenly resonance...</span>
              <button
                onClick={handleSkipAnimation}
                className="px-4 py-2 rounded-xl bg-[#e2b054] text-[#072018] font-dao font-bold text-xs flex items-center gap-1.5 min-h-[38px]"
              >
                <FastForward className="w-3.5 h-3.5" />
                <span>Skip &amp; Resolve Now</span>
              </button>
            </>
          )}

          {phase === 'result' && (
            <>
              <span className="text-[#6d8e80]">Ancestral Dao Altar</span>
              <button
                onClick={handleSealAndClose}
                className={`px-5 py-2 rounded-xl font-dao font-bold text-xs sm:text-sm shadow-md transition-all min-h-[40px] ${
                  succeeded
                    ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018]'
                    : 'bg-red-800 hover:bg-red-700 text-white'
                }`}
              >
                {succeeded ? 'Seal Breakthrough & Advance' : 'Accept Consequence & Recover'}
              </button>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
};
