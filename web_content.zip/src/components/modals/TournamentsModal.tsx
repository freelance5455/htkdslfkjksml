import React from 'react';
import { X, Trophy, Calendar, Award, ShieldAlert, Users, Sparkles } from 'lucide-react';
import { soundFX } from '../../utils/soundEffects';

interface TournamentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRegisterTournament: (title: string) => void;
}

export const TournamentsModal: React.FC<TournamentsModalProps> = ({
  isOpen,
  onClose,
  onRegisterTournament,
}) => {
  if (!isOpen) return null;

  const tournaments = [
    {
      id: 'tour-1',
      title: 'بطولة تاج الطرنيب اليومية',
      type: 'يومية',
      game: 'طرنيب 41',
      playersMax: 64,
      registered: 48,
      time: 'تبدأ اليوم 21:00 بتوقيت مكة',
      prizes: '50,000 كوينز + 250 جوهرة + لقب ملك اليوم',
      entryFee: '500 كوينز',
      status: 'REGISTRATION_OPEN',
    },
    {
      id: 'tour-2',
      title: 'كأس تركس الأسبوعي الكبرى',
      type: 'أسبوعية',
      game: 'تركس فردي قياسي',
      playersMax: 128,
      registered: 112,
      time: 'تبدأ الجمعة القادمة 20:00',
      prizes: '150,000 كوينز + 800 جوهرة + سكن ورقة ملكي',
      entryFee: '2,000 كوينز',
      status: 'REGISTRATION_OPEN',
    },
    {
      id: 'tour-3',
      title: 'بطولة موسم الملوك الكبرى',
      type: 'موسمية',
      game: 'طرنيب ماسترز',
      playersMax: 512,
      registered: 320,
      time: 'نهاية الموسم (بعد 12 يوم)',
      prizes: '1,000,000 كوينز + 5,000 جوهرة + درع الموسم الأسطوري',
      entryFee: 'مجانًا (لأصحاب VIP أو مستوى 10+)',
      status: 'UPCOMING',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="relative w-full max-w-3xl bg-[#07130c] border-2 border-amber-500/50 rounded-2xl shadow-[0_0_40px_rgba(16,185,129,0.3)] overflow-hidden text-right flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0b2416] via-[#123823] to-[#0b2416] border-b border-amber-500/30 p-4 flex items-center justify-between">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="text-gray-400 hover:text-amber-400 p-1 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold text-amber-300">ساحة البطولات والجوائز الكبرى</h2>
          </div>
        </div>

        {/* Legal & Compliance Notice */}
        <div className="p-3 bg-amber-950/20 border-b border-amber-900/50 text-xs text-amber-300/90 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            تنبيه تنظيمي: البطولات تجري باستخدام العملات الافتراضية داخل اللعبة (Coins & Gems). الرهانات الحقيقية بالمال معطلة نهائيًا حتى استكمال التراخيص والاشتراطات النظامية.
          </span>
        </div>

        {/* Tournaments List */}
        <div className="p-6 space-y-4 max-h-[65vh] overflow-y-auto">
          {tournaments.map((t) => (
            <div
              key={t.id}
              className="p-4 rounded-xl bg-[#05110a] border border-amber-950/80 hover:border-amber-600/60 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                    {t.type}
                  </span>
                  <h3 className="font-bold text-sm text-gray-100">{t.title}</h3>
                </div>
                <div className="text-xs text-gray-400 flex items-center gap-3">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-amber-400" />
                    {t.time}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5 text-emerald-400" />
                    {t.registered}/{t.playersMax} لاعب
                  </span>
                </div>
                <div className="text-xs text-amber-300 flex items-center gap-1 font-semibold pt-1">
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  <span>الجوائز: {t.prizes}</span>
                </div>
              </div>

              <div className="flex flex-col items-end gap-1.5 w-full md:w-auto">
                <span className="text-xs text-gray-400">رسوم التسجيل: {t.entryFee}</span>
                <button
                  onClick={() => {
                    soundFX.playButtonClick();
                    onRegisterTournament(t.title);
                  }}
                  className="w-full md:w-auto px-5 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 text-black font-extrabold text-xs shadow-md active:scale-95 transition-transform"
                >
                  حجز مقعد والتسجيل
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
