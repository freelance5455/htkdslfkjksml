import React from 'react';
import { useMusic } from '../../context/MusicContext';
import { Moon, Clock, X, Check } from 'lucide-react';

interface SleepTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SleepTimerModal: React.FC<SleepTimerModalProps> = ({ isOpen, onClose }) => {
  const { sleepTimerRemaining, setSleepTimer } = useMusic();

  if (!isOpen) return null;

  const timerOptions = [
    { label: '5 minutes', value: 5 },
    { label: '15 minutes', value: 15 },
    { label: '30 minutes', value: 30 },
    { label: '45 minutes', value: 45 },
    { label: '1 hour', value: 60 },
    { label: 'Turn Off Timer', value: null }
  ];

  const formatRemaining = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-[#141622] border border-white/[0.1] p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-4 border-b border-white/[0.08]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <Moon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-white">Sleep Timer</h3>
              <p className="text-xs text-slate-400">Audio will fade out automatically</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {sleepTimerRemaining !== null && sleepTimerRemaining > 0 && (
          <div className="mt-4 p-3 rounded-2xl bg-purple-900/30 border border-purple-500/20 text-center">
            <span className="text-xs text-purple-300 font-medium">Timer actively counting down:</span>
            <p className="text-xl font-display font-bold text-white mt-0.5 tracking-wider">
              {formatRemaining(sleepTimerRemaining)}
            </p>
          </div>
        )}

        <div className="mt-4 space-y-1.5">
          {timerOptions.map((opt, i) => (
            <button
              key={i}
              onClick={() => {
                setSleepTimer(opt.value);
                onClose();
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-white/[0.06] text-left transition-colors text-sm font-medium text-slate-200"
            >
              <span>{opt.label}</span>
              {opt.value === null && sleepTimerRemaining === null && (
                <Check className="w-4 h-4 text-purple-400" />
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
