import React, { useState, useEffect } from 'react';
import {
  X,
  Gift,
  Crown,
  Sparkles,
  Coins,
  Gem,
  CheckCircle,
  Lock,
  Flame,
  Award,
  Zap,
  Star,
  Clock,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { UserProfile, TransactionRecord } from '../../types';
import { soundFX } from '../../utils/soundEffects';
import { saveAuditRecordToFirestore, saveUserProfileToFirestore } from '../../utils/firebaseSync';

interface DailyBonusModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpdateUser: (u: UserProfile) => void;
  onAddAuditTransaction?: (tx: TransactionRecord) => void;
}

interface DailyRewardConfig {
  day: number;
  coins: number;
  gems: number;
  specialTitle?: string;
  isMegaVault?: boolean;
}

const REWARDS_SCHEDULE: DailyRewardConfig[] = [
  { day: 1, coins: 1000, gems: 10 },
  { day: 2, coins: 2000, gems: 20 },
  { day: 3, coins: 3500, gems: 35 },
  { day: 4, coins: 5000, gems: 50 },
  { day: 5, coins: 7500, gems: 75 },
  { day: 6, coins: 10000, gems: 100 },
  {
    day: 7,
    coins: 20000,
    gems: 200,
    specialTitle: 'الصندوق الملكي الأعظم 👑',
    isMegaVault: true,
  },
];

export const DailyBonusModal: React.FC<DailyBonusModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateUser,
  onAddAuditTransaction,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const isClaimedToday = currentUser.lastDailyBonusClaimDate === todayStr;

  // Streak: 1 to 7 (defaults to 1 if not set)
  const currentStreak = currentUser.dailyBonusStreak || 1;

  const [hasJustClaimed, setHasJustClaimed] = useState(false);
  const [claimedReward, setClaimedReward] = useState<{
    coins: number;
    gems: number;
    vipBonusCoins: number;
    vipBonusGems: number;
    totalCoins: number;
    totalGems: number;
  } | null>(null);

  // VIP multiplier: VIP 1 = +10%, VIP 2 = +25%, VIP 3 = +50%, VIP 4+ = +100%
  const vipBonusMultiplier = currentUser.isVip
    ? currentUser.vipLevel >= 3
      ? 0.5
      : currentUser.vipLevel === 2
      ? 0.25
      : 0.15
    : 0;

  const currentRewardConfig =
    REWARDS_SCHEDULE.find((r) => r.day === currentStreak) || REWARDS_SCHEDULE[0];

  const previewVipBonusCoins = Math.round(currentRewardConfig.coins * vipBonusMultiplier);
  const previewVipBonusGems = Math.round(currentRewardConfig.gems * vipBonusMultiplier);
  const previewTotalCoins = currentRewardConfig.coins + previewVipBonusCoins;
  const previewTotalGems = currentRewardConfig.gems + previewVipBonusGems;

  useEffect(() => {
    if (isOpen && !isClaimedToday) {
      soundFX.playCoin();
    }
  }, [isOpen, isClaimedToday]);

  if (!isOpen) return null;

  const handleClaimReward = () => {
    if (isClaimedToday || hasJustClaimed) return;

    soundFX.playVictoryFanfare();

    const awardedCoins = previewTotalCoins;
    const awardedGems = previewTotalGems;

    setClaimedReward({
      coins: currentRewardConfig.coins,
      gems: currentRewardConfig.gems,
      vipBonusCoins: previewVipBonusCoins,
      vipBonusGems: previewVipBonusGems,
      totalCoins: awardedCoins,
      totalGems: awardedGems,
    });
    setHasJustClaimed(true);

    // Calculate next streak (rolls over to 1 after day 7)
    const nextStreak = currentStreak >= 7 ? 1 : currentStreak + 1;

    const updatedUser: UserProfile = {
      ...currentUser,
      coins: currentUser.coins + awardedCoins,
      gems: currentUser.gems + awardedGems,
      lastDailyBonusClaimDate: todayStr,
      dailyBonusStreak: nextStreak,
    };

    onUpdateUser(updatedUser);
    saveUserProfileToFirestore(updatedUser);

    // Save audit log
    const txId = `TX-DAILY-${Date.now().toString().slice(-6)}`;
    const auditRecord: TransactionRecord = {
      transactionId: txId,
      playerId: currentUser.id,
      playerName: currentUser.name,
      cashierOrAdminId: 'SYSTEM_DAILY_BONUS',
      amount: awardedCoins,
      currencyType: 'COINS',
      balanceBefore: currentUser.coins,
      balanceAfter: currentUser.coins + awardedCoins,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      status: 'COMPLETED',
      sourceMethod: 'REWARD',
      referenceNote: `مكافأة الدخول اليومي (اليوم ${currentStreak}/7) + ${awardedGems} جوهرة ومضاعف VIP`,
      auditHash: `sha256:daily_${txId}_hash`,
      ledgerSequence: Math.floor(1000 + Math.random() * 9000),
    };

    if (onAddAuditTransaction) {
      onAddAuditTransaction(auditRecord);
    }
    saveAuditRecordToFirestore(auditRecord);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in select-none">
      {/* Outer Glow Container */}
      <div className="relative w-full max-w-3xl bg-gradient-to-b from-[#082818] via-[#05170d] to-[#020905] border-2 border-amber-400/80 rounded-3xl p-6 md:p-8 shadow-[0_0_80px_rgba(245,158,11,0.25)] flex flex-col overflow-hidden">
        {/* Luxury Background Velvet and Gold Radiance */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_#12482c_0%,_#061a0f_50%,_#020804_100%)] opacity-90 pointer-events-none" />
        <div className="absolute -top-32 -left-32 w-64 h-64 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -top-32 -right-32 w-64 h-64 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={() => {
            soundFX.playButtonClick();
            onClose();
          }}
          className="absolute top-5 left-5 z-20 text-gray-400 hover:text-white p-2 rounded-full bg-black/40 hover:bg-black/60 border border-amber-500/30 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="relative z-10 text-center mb-6">
          <div className="inline-flex items-center justify-center gap-2 px-4 py-1 rounded-full bg-gradient-to-r from-amber-500/20 via-amber-400/30 to-amber-500/20 border border-amber-400/60 mb-2 shadow-sm">
            <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />
            <span className="text-xs font-black text-amber-300 tracking-wide uppercase">
              نظام المكافآت اليومية الملكية • TABEONA VIP
            </span>
            <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />
          </div>

          <h2 className="text-2xl md:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-100 flex items-center justify-center gap-2">
            <Crown className="w-7 h-7 text-amber-400 drop-shadow-[0_0_10px_#f59e0b]" />
            مكافأة تسجيل الدخول اليومي
            <Crown className="w-7 h-7 text-amber-400 drop-shadow-[0_0_10px_#f59e0b]" />
          </h2>
          <p className="text-xs md:text-sm text-gray-300 mt-1 max-w-lg mx-auto">
            سجل دخولك يومياً دون انقطاع لفتح الصندوق الملكي الأعظم في اليوم السابع مع مضاعفات كبار الشخصيات!
          </p>

          {/* Current Streak Indicator */}
          <div className="inline-flex items-center gap-2 mt-3 px-3.5 py-1.5 rounded-xl bg-black/60 border border-amber-500/40 text-xs font-bold text-amber-200 shadow-inner">
            <Flame className="w-4 h-4 text-orange-400 animate-pulse" />
            <span>سلسلة أيام الدخول الحالية:</span>
            <span className="text-amber-400 text-sm font-black font-mono">
              {currentStreak} من 7 أيام
            </span>
            {currentUser.isVip && (
              <span className="mr-2 text-[10px] px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-amber-300 text-black font-black">
                VIP {currentUser.vipLevel} (+{Math.round(vipBonusMultiplier * 100)}%)
              </span>
            )}
          </div>
        </div>

        {/* ========================================================
            7-DAY REWARD PROGRESSION CARDS
           ======================================================== */}
        <div className="relative z-10 grid grid-cols-4 sm:grid-cols-7 gap-2 md:gap-3 mb-6">
          {REWARDS_SCHEDULE.map((item) => {
            const isClaimed =
              item.day < currentStreak || (item.day === currentStreak && (isClaimedToday || hasJustClaimed));
            const isCurrentToday =
              item.day === currentStreak && !isClaimedToday && !hasJustClaimed;
            const isLocked = item.day > currentStreak;

            return (
              <div
                key={item.day}
                className={`relative rounded-2xl p-2.5 md:p-3 flex flex-col items-center justify-between text-center transition-all ${
                  item.isMegaVault
                    ? isCurrentToday
                      ? 'col-span-2 sm:col-span-1 bg-gradient-to-b from-amber-900/90 to-[#2e1c07] border-2 border-amber-300 shadow-[0_0_25px_rgba(245,158,11,0.6)] scale-105'
                      : 'col-span-2 sm:col-span-1 bg-gradient-to-b from-amber-950/60 to-black/80 border border-amber-500/50'
                    : isCurrentToday
                    ? 'bg-gradient-to-b from-emerald-900/90 to-[#072a17] border-2 border-amber-400 shadow-[0_0_20px_rgba(16,185,129,0.5)] scale-105 animate-pulse'
                    : isClaimed
                    ? 'bg-black/40 border border-emerald-500/40 opacity-75'
                    : 'bg-black/50 border border-amber-950/80 opacity-60'
                }`}
              >
                {/* Day Tag */}
                <div className="text-[10px] font-black text-amber-300 mb-1">
                  اليوم {item.day}
                </div>

                {/* Center Icon */}
                <div className="my-1">
                  {item.isMegaVault ? (
                    <div className="relative">
                      <Crown className={`w-8 h-8 ${isCurrentToday ? 'text-amber-300 animate-bounce' : 'text-amber-400'}`} />
                      <Sparkles className="w-3.5 h-3.5 text-yellow-200 absolute -top-1 -right-1" />
                    </div>
                  ) : (
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-500/20 to-emerald-600/30 border border-amber-500/30 flex items-center justify-center">
                      <Gift className={`w-4 h-4 ${isCurrentToday ? 'text-amber-300' : 'text-emerald-300'}`} />
                    </div>
                  )}
                </div>

                {/* Rewards Content */}
                <div className="w-full space-y-0.5 my-1">
                  <div className="flex items-center justify-center gap-1 text-[11px] font-black text-amber-300">
                    <Coins className="w-3 h-3 text-amber-400 shrink-0" />
                    <span className="font-mono">{item.coins.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-center gap-1 text-[10px] font-bold text-emerald-300">
                    <Gem className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                    <span className="font-mono">+{item.gems}</span>
                  </div>
                </div>

                {/* Status Badge */}
                <div className="mt-1">
                  {isClaimed ? (
                    <span className="inline-flex items-center gap-0.5 text-[9px] font-black text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded-full border border-emerald-500/40">
                      <CheckCircle className="w-2.5 h-2.5" />
                      مستلمة
                    </span>
                  ) : isCurrentToday ? (
                    <span className="inline-flex items-center gap-0.5 text-[9px] font-black text-amber-300 bg-amber-950 px-1.5 py-0.5 rounded-full border border-amber-400/80 animate-pulse">
                      <Star className="w-2.5 h-2.5" />
                      اليوم
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-gray-500 bg-black/60 px-1.5 py-0.5 rounded-full border border-gray-800">
                      <Lock className="w-2.5 h-2.5" />
                      قادم
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* ========================================================
            ACTION / CELEBRATION BOX
           ======================================================== */}
        <div className="relative z-10 bg-black/50 border border-amber-500/40 rounded-2xl p-4 md:p-5 flex flex-col items-center justify-center text-center shadow-inner">
          {hasJustClaimed && claimedReward ? (
            /* Celebration Just Claimed Screen */
            <div className="space-y-3 animate-in zoom-in-95">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 mx-auto flex items-center justify-center text-black shadow-lg animate-bounce">
                <Crown className="w-8 h-8" />
              </div>

              <div>
                <h3 className="text-xl font-black text-amber-300">
                  🎉 تهانينا! استلمت مكافأتك الملكية بنجاح
                </h3>
                <p className="text-xs text-gray-300 mt-0.5">
                  تم إيداع الكوينز والجواهر في رصيدك فوراً وتوثيقها في سجل الحساب
                </p>
              </div>

              {/* Awarded Badges */}
              <div className="flex items-center justify-center gap-4 py-2">
                <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-950/70 border border-amber-400 text-amber-300 font-mono font-black text-base shadow-md">
                  <Coins className="w-5 h-5 text-amber-400" />
                  <span>+{claimedReward.totalCoins.toLocaleString()} كوينز</span>
                </div>

                <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-950/70 border border-emerald-400 text-emerald-300 font-mono font-black text-base shadow-md">
                  <Gem className="w-5 h-5 text-emerald-400" />
                  <span>+{claimedReward.totalGems.toLocaleString()} جوهرة</span>
                </div>
              </div>

              {claimedReward.vipBonusCoins > 0 && (
                <div className="text-xs text-amber-300 font-bold bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-full inline-block">
                  ✨ تضمنت مكافأتك بونص كبار الشخصيات: +{claimedReward.vipBonusCoins.toLocaleString()} كوينز إضافية!
                </div>
              )}

              <div className="pt-2">
                <button
                  onClick={() => {
                    soundFX.playButtonClick();
                    onClose();
                  }}
                  className="px-8 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-black text-xs shadow-lg transition-all"
                >
                  رائع! دخول صالة اللعب
                </button>
              </div>
            </div>
          ) : isClaimedToday ? (
            /* Already Claimed Today Screen */
            <div className="space-y-2">
              <div className="flex items-center justify-center gap-2 text-emerald-400 font-black text-base">
                <CheckCircle className="w-6 h-6 text-emerald-400" />
                <span>لقد استلمت مكافأة اليوم بالفعل!</span>
              </div>
              <p className="text-xs text-gray-400 max-w-md mx-auto">
                عد غداً لمتابعة سلسلة الدخول والحصول على مكافأة اليوم التالي وزيادة كوينز وجواهر محفظتك.
              </p>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-black/60 border border-amber-950 text-xs font-mono text-gray-300 mt-2">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>المكافأة القادمة متاحة غداً عند منتصف الليل</span>
              </div>
            </div>
          ) : (
            /* Ready to Claim Button & Details */
            <div className="w-full space-y-3">
              <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-bold text-gray-300">
                <span className="flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-amber-400" />
                  الكوينز الأساسية: <strong className="text-amber-300 font-mono font-black">{currentRewardConfig.coins.toLocaleString()}</strong>
                </span>
                <span className="flex items-center gap-1.5">
                  <Gem className="w-4 h-4 text-emerald-400" />
                  الجواهر: <strong className="text-emerald-300 font-mono font-black">{currentRewardConfig.gems}</strong>
                </span>
                {previewVipBonusCoins > 0 && (
                  <span className="flex items-center gap-1.5 text-amber-300 bg-amber-500/20 px-2.5 py-0.5 rounded-full border border-amber-500/40 text-[11px]">
                    <Sparkles className="w-3 h-3 text-amber-300" />
                    بونص VIP ({Math.round(vipBonusMultiplier * 100)}%): +{previewVipBonusCoins.toLocaleString()} كوينز
                  </span>
                )}
              </div>

              {/* Big Glowing Claim Button */}
              <button
                onClick={handleClaimReward}
                className="w-full max-w-md mx-auto py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-sm md:text-base flex items-center justify-center gap-3 shadow-[0_0_30px_rgba(245,158,11,0.5)] hover:shadow-[0_0_40px_rgba(245,158,11,0.8)] transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Gift className="w-5 h-5 text-black animate-bounce" />
                <span>استلام مكافأة اليوم ({previewTotalCoins.toLocaleString()} كوينز 🪙 + {previewTotalGems} جوهرة 💎)</span>
                <Sparkles className="w-5 h-5 text-black" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
