import React from 'react';
import { NeighborSect, SectResources } from '../../types/cultivation';
import { formatLargeNumber } from '../../data/realms';
import { soundEngine } from '../../services/audioEngine';
import { Users2, Shield, HeartHandshake, Swords, ArrowRightLeft, ShieldAlert, X, Flag, Clock } from 'lucide-react';

interface DiplomacyModalProps {
  sects: NeighborSect[];
  resources: SectResources;
  totalCombatPower: number;
  onClose: () => void;
  onSendEmissary: (sect: NeighborSect) => void;
  onTradeTreaty: (sect: NeighborSect) => void;
  onProvideAid: (sect: NeighborSect) => void;
  onFormAlliance: (sect: NeighborSect) => void;
  onInvadeTerritory: (sect: NeighborSect) => void;
}

export const DiplomacyModal: React.FC<DiplomacyModalProps> = ({
  sects,
  resources,
  totalCombatPower,
  onClose,
  onSendEmissary,
  onTradeTreaty,
  onProvideAid,
  onFormAlliance,
  onInvadeTerritory
}) => {
  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/70 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] relative">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2">
            <Users2 className="w-5 h-5 text-[#fce18b]" />
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
                Sect Diplomacy & Realm Dominance
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                Cooperate, assist, form sacred alliances, or invade to seize spiritual territories.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-3.5 grow text-xs text-[#d1e6dc]">
          {sects.map((sect) => {
            const isCoolingDown = Boolean(sect.cooldownUntil && sect.cooldownUntil > Date.now());
            const cooldownSeconds = isCoolingDown ? Math.ceil((sect.cooldownUntil! - Date.now()) / 1000) : 0;

            return (
              <div
                key={sect.id}
                className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-3"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-dao font-bold text-sm text-[#fce18b]">
                        {sect.name}
                      </span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        sect.alignment === 'Righteous Orthodox'
                          ? 'bg-blue-900/40 text-blue-300 border border-blue-500/30'
                          : sect.alignment === 'Demonic Blood Cult'
                          ? 'bg-red-900/40 text-red-300 border border-red-500/30'
                          : 'bg-emerald-900/40 text-emerald-300 border border-emerald-500/30'
                      }`}>
                        {sect.alignment}
                      </span>
                    </div>
                    <div className="text-[11px] text-[#9fc2b2] mt-0.5">
                      Leader: {sect.leaderName} · Specialty: {sect.specialty}
                    </div>
                    <div className="text-[10px] text-[#e2b054] mt-0.5 flex items-center gap-2">
                      <span>Territory: <strong>{sect.territoryPoints} Provinces</strong></span>
                      <span>·</span>
                      <span>Reputation: {sect.reputation}/100</span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${
                      sect.attitude === 'Allied' || sect.attitude === 'Respectful'
                        ? 'bg-green-900/50 text-green-300'
                        : sect.attitude === 'Hostile'
                        ? 'bg-red-900/50 text-red-300'
                        : 'bg-yellow-900/50 text-yellow-300'
                    }`}>
                      {sect.attitude}
                    </span>
                    <div className="text-[10px] text-[#fce18b] font-mono mt-1">
                      Power: {formatLargeNumber(sect.strength)}
                    </div>
                  </div>
                </div>

                {isCoolingDown && (
                  <div className="p-1.5 rounded-lg bg-amber-950/40 border border-amber-600/30 text-[10px] text-amber-200 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-amber-400" />
                    <span>Diplomatic envoy active. Cooldown: {cooldownSeconds}s</span>
                  </div>
                )}

                {/* 4 Diplomatic Actions: Cooperate / Aid / Alliance / Invade */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-1 border-t border-[#1b4b3b]">
                  {/* Cooperate / Trade */}
                  <button
                    disabled={isCoolingDown}
                    onClick={() => {
                      soundEngine.playTalisman();
                      onTradeTreaty(sect);
                    }}
                    className="py-1.5 px-2 rounded-xl bg-[#123d30] hover:bg-[#184838] disabled:opacity-50 text-[#86efac] border border-[#22c55e]/30 font-bold text-[10px] flex items-center justify-center gap-1"
                  >
                    <ArrowRightLeft className="w-3 h-3" />
                    <span>Cooperate / Trade</span>
                  </button>

                  {/* Provide Aid / Help */}
                  <button
                    disabled={isCoolingDown}
                    onClick={() => {
                      soundEngine.playClick();
                      onProvideAid(sect);
                    }}
                    className="py-1.5 px-2 rounded-xl bg-[#123d30] hover:bg-[#184838] disabled:opacity-50 text-[#38bdf8] border border-[#38bdf8]/30 font-bold text-[10px] flex items-center justify-center gap-1"
                  >
                    <HeartHandshake className="w-3 h-3" />
                    <span>Provide Aid</span>
                  </button>

                  {/* Form Alliance */}
                  <button
                    disabled={isCoolingDown || sect.attitude === 'Hostile'}
                    onClick={() => {
                      soundEngine.playTalisman();
                      onFormAlliance(sect);
                    }}
                    className="py-1.5 px-2 rounded-xl bg-[#123d30] hover:bg-[#184838] disabled:opacity-50 text-[#fce18b] border border-[#e2b054]/30 font-bold text-[10px] flex items-center justify-center gap-1"
                  >
                    <Flag className="w-3 h-3" />
                    <span>Sacred Alliance</span>
                  </button>

                  {/* Invade Territory */}
                  <button
                    disabled={isCoolingDown}
                    onClick={() => {
                      soundEngine.playSwordSlash();
                      onInvadeTerritory(sect);
                    }}
                    className="py-1.5 px-2 rounded-xl bg-red-950/60 hover:bg-red-900 disabled:opacity-50 text-red-200 border border-red-700/40 font-bold text-[10px] flex items-center justify-center gap-1"
                  >
                    <Swords className="w-3 h-3" />
                    <span>Invade Territory</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Sect Foreign Relations · Extreme World</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[36px]"
          >
            Close Diplomacy
          </button>
        </div>
      </div>
    </div>
  );
};
