import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import { Sparkles, ListMusic, ArrowDownToLine, ChevronRight, Check } from 'lucide-react';

export const OnboardingModal: React.FC = () => {
  const { isOnboardingOpen, setIsOnboardingOpen } = useMusic();
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOnboardingOpen) return null;

  const steps = [
    {
      title: 'Discover Music',
      subtitle: 'Unlimited streaming across Bengali, Bollywood, Synthwave & Global Hits',
      description: 'Explore curated algorithmic radios, trending charts, and high-cadence workout playlists tailored to your exact taste.',
      icon: Sparkles,
      gradient: 'from-purple-600 via-indigo-600 to-pink-600'
    },
    {
      title: 'Create Your Playlists',
      subtitle: 'Organize your favorite tracks with custom artwork and instant sharing',
      description: 'Mix songs from different genres, reorder queues, and collaborate with friends in real-time.',
      icon: ListMusic,
      gradient: 'from-pink-600 via-rose-600 to-amber-600'
    },
    {
      title: 'Listen Anywhere',
      subtitle: 'True offline downloads with zero cellular data consumption',
      description: 'Download full lossless albums to your local device and toggle Offline Mode whenever you travel.',
      icon: ArrowDownToLine,
      gradient: 'from-blue-600 via-teal-600 to-emerald-600'
    }
  ];

  const step = steps[currentStep];
  const StepIcon = step.icon;

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setIsOnboardingOpen(false);
      localStorage.setItem('music_express_onboarding_done', 'true');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-[#141622] border border-white/10 p-6 shadow-2xl text-center relative overflow-hidden">
        {/* Glow backdrop */}
        <div className={`absolute -top-20 -left-20 w-44 h-44 rounded-full bg-gradient-to-br ${step.gradient} blur-3xl opacity-40`} />

        {/* Step indicator pills */}
        <div className="flex items-center justify-center gap-1.5 mb-6">
          {steps.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                i === currentStep
                  ? 'w-6 bg-purple-500'
                  : i < currentStep
                  ? 'w-2 bg-purple-800'
                  : 'w-2 bg-white/20'
              }`}
            />
          ))}
        </div>

        {/* Icon Emblem */}
        <div className="relative mx-auto mb-5 w-20 h-20 rounded-3xl bg-gradient-to-tr from-white/10 to-white/5 border border-white/10 flex items-center justify-center shadow-xl">
          <div className={`w-14 h-14 rounded-2xl bg-gradient-to-tr ${step.gradient} flex items-center justify-center text-white shadow-lg`}>
            <StepIcon className="w-7 h-7" />
          </div>
        </div>

        <h3 className="font-display font-extrabold text-xl text-white tracking-tight">
          {step.title}
        </h3>
        <p className="text-xs text-purple-300 font-medium mt-1">
          {step.subtitle}
        </p>
        <p className="text-xs text-slate-400 mt-3 leading-relaxed">
          {step.description}
        </p>

        {/* Controls */}
        <div className="mt-8 flex items-center gap-2">
          <button
            onClick={() => setIsOnboardingOpen(false)}
            className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-semibold transition-colors"
          >
            Skip
          </button>
          <button
            onClick={handleNext}
            className="flex-1 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg shadow-purple-600/30 flex items-center justify-center gap-1.5 transition-all active:scale-95"
          >
            <span>{currentStep === steps.length - 1 ? 'Get Started' : 'Next'}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
