import React from 'react';
import { Disciple, SectResources, SectSector } from '../../types/cultivation';
import { CULTIVATION_REALMS, formatLargeNumber } from '../../data/realms';
import { CultivatorAvatar } from '../cultivation/CultivatorAvatar';
import { soundEngine } from '../../services/audioEngine';
import {
  MapPin,
  Lock,
  Unlock,
  ArrowUpCircle,
  Shield,
  Swords,
  Sparkles,
  UserCheck,
  X
} from 'lucide-react';

interface SectSectorsModalProps {
  sectors: SectSector[];
  disciples: Disciple[];
  resources: SectResources;
  hallLevel: number;
  devMode?: boolean;
  onClose: () => void;
  onUnlockSector: (sector: SectSector) => void;
  onUpgradeSector: (sector: SectSector) => void;
  onAssignGuardian: (sectorId: string, discipleId: string | undefined) => void;
}

export const SectSectorsModal: React.FC<SectSectorsModalProps> = ({
  sectors,
  disciples,
  resources,
  hallLevel,
  devMode = false,
  onClose,
  onUnlockSector,
  onUpgradeSector,
  onAssignGuardian
}) => {
  const unlockedCount = sectors.filter(s => s.unlocked).length;

  const getUpgradeCost = (sector: SectSector) => {
    return Math.floor(sector.upgradeBaseStones * Math.pow(1.28, Math.max(0, sector.level - 1)));
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div className="bg-[#123d30] border-2 border-[#e2b054]/80 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] relative">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#e2b054]/15 border border-[#e2b054]/50 flex items-center justify-center shrink-0">
              <MapPin className="w-5 h-5 text-[#fce18b]" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-dao text-[#fce18b] flex items-center gap-2">
                <span>Sect Peaks &amp; Domain Sectors</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#09261d] text-emerald-300 border border-emerald-500/40">
                  {unlockedCount}/{sectors.length} Claimed
                </span>
              </h3>
              <p className="text-[11px] text-[#9fc2b2]">
                Claim surrounding spiritual peaks, appoint Sector Lords, and expand sect sovereignty.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-3.5 sm:p-4 overflow-y-auto space-y-3 grow text-xs text-[#d1e6dc]">
          {sectors.map((sector) => {
            const guardian = disciples.find(d => d.id === sector.guardianDiscipleId);
            const upgradeCost = getUpgradeCost(sector);
            const canUnlock =
              devMode ||
              (hallLevel >= sector.minHallLevel &&
                resources.spiritStones >= sector.unlockCostStones &&
                resources.merit >= sector.unlockCostMerit);
            const canUpgrade =
              sector.unlocked &&
              sector.level < sector.maxLevel &&
              (devMode || resources.spiritStones >= upgradeCost);

            const guardianBonusMultiplier = guardian ? 1.25 : 1.0;
            const currentEffectVal = Math.round(sector.level * sector.bonusValuePerLevel * guardianBonusMultiplier);

            if (!sector.unlocked) {
              return (
                <div
                  key={sector.id}
                  className="bg-[#09261d] border border-dashed border-[#23604f] rounded-2xl p-3.5 space-y-2.5"
                >
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <Lock className="w-4 h-4 text-[#e2b054] shrink-0" />
                        <span className="font-dao font-bold text-sm text-[#fce18b]">{sector.name}</span>
                      </div>
                      <div className="text-[10px] text-[#8daea0] mt-0.5">{sector.region}</div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#123d30] text-amber-300 border border-[#e2b054]/30 font-mono shrink-0">
                      Requires Hall Lv {sector.minHallLevel}
                    </span>
                  </div>

                  <p className="text-[11px] text-[#a4c5b7] leading-relaxed">{sector.description}</p>

                  <div className="bg-[#0e3226] px-3 py-2 rounded-xl border border-[#1b4b3b] text-[11px] text-[#86efac] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#e2b054] shrink-0" />
                    <span>Sector Bonus: {sector.bonusLabel}</span>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-[#1b4b3b]">
                    <div className="text-[11px] flex items-center gap-2 font-mono">
                      <span className={resources.spiritStones >= sector.unlockCostStones ? 'text-[#fce18b]' : 'text-red-400'}>
                        💎 {formatLargeNumber(sector.unlockCostStones)}
                      </span>
                      <span>·</span>
                      <span className={resources.merit >= sector.unlockCostMerit ? 'text-amber-300' : 'text-red-400'}>
                        📜 {formatLargeNumber(sector.unlockCostMerit)} Merit
                      </span>
                    </div>

                    <button
                      disabled={!canUnlock}
                      onClick={() => {
                        soundEngine.playGong();
                        onUnlockSector(sector);
                      }}
                      className={`px-3.5 py-2 rounded-xl font-dao font-bold text-xs flex items-center gap-1.5 min-h-[38px] transition-all ${
                        canUnlock
                          ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-95'
                          : 'bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700'
                      }`}
                    >
                      <Unlock className="w-3.5 h-3.5" />
                      <span>Claim Sector</span>
                    </button>
                  </div>
                </div>
              );
            }

            return (
              <div
                key={sector.id}
                className="bg-gradient-to-br from-[#0e3427] to-[#082219] border border-[#e2b054]/45 rounded-2xl p-3.5 sm:p-4 space-y-3 shadow-md"
              >
                <div className="flex justify-between items-start gap-2">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-dao font-bold text-sm sm:text-base text-[#fce18b]">
                        {sector.name}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#184838] text-[#86efac] border border-emerald-500/40 font-mono font-bold">
                        Lv {sector.level}/{sector.maxLevel}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#9fc2b2] mt-0.5">{sector.region}</div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-[#071a13] text-amber-300 border border-amber-500/30 flex items-center gap-1">
                      {sector.bonusType === 'combat' ? <Swords className="w-3 h-3" /> : <Shield className="w-3 h-3" />}
                      <span>
                        +{currentEffectVal}
                        {['combat', 'cultivation', 'defense'].includes(sector.bonusType) ? '%' : '/s'} Active
                      </span>
                    </span>
                  </div>
                </div>

                <p className="text-[11px] text-[#cbe3d7] leading-relaxed">{sector.description}</p>

                {/* Active Bonus Strip */}
                <div className="bg-[#071f17] p-2.5 rounded-xl border border-[#1b4b3b] flex items-center justify-between gap-2 text-[11px]">
                  <span className="text-[#86efac] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#e2b054] shrink-0" />
                    <span>{sector.bonusLabel}</span>
                  </span>
                  {guardian && (
                    <span className="text-[10px] font-bold text-amber-300 whitespace-nowrap">
                      +25% Guardian Synergy
                    </span>
                  )}
                </div>

                {/* Guardian Selector */}
                <div className="bg-[#0a291f] p-2.5 rounded-xl border border-[#1d5543] flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    {guardian ? (
                      <CultivatorAvatar
                        gender={guardian.gender}
                        rank={guardian.rank}
                        spiritRoot={guardian.spiritRoot}
                        realmIndex={guardian.currentRealmIndex}
                        appearanceIndex={guardian.appearanceIndex ?? guardian.avatarStyle?.appearanceIndex}
                        skinTone={guardian.skinTone ?? guardian.avatarStyle?.skinTone}
                        clothingColor={guardian.clothingColor ?? guardian.avatarStyle?.clothingColor}
                        hairColor={guardian.hairColor ?? guardian.avatarStyle?.hairColor}
                        expression={guardian.expression ?? guardian.avatarStyle?.expression}
                        showGenderBadge={false}
                        size="sm"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-xl bg-[#071d15] border border-dashed border-[#2b6b56] flex items-center justify-center shrink-0">
                        <UserCheck className="w-4 h-4 text-[#6d9484]" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="text-[10px] text-[#9fc2b2]">Sector Lord / Guardian</div>
                      <div className="text-xs font-bold text-white truncate">
                        {guardian ? `${guardian.name} (${CULTIVATION_REALMS[guardian.currentRealmIndex]?.majorRealm})` : 'Unassigned (+0% Synergy)'}
                      </div>
                    </div>
                  </div>

                  <select
                    value={sector.guardianDiscipleId || ''}
                    onChange={(e) => {
                      soundEngine.playClick();
                      onAssignGuardian(sector.id, e.target.value || undefined);
                    }}
                    className="bg-[#071a13] border border-[#e2b054]/40 text-[#fce18b] text-[11px] rounded-lg px-2 py-1.5 max-w-[140px]"
                  >
                    <option value="">No Guardian</option>
                    {disciples.map(d => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.rank})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Upgrade Bar */}
                <div className="flex items-center justify-between pt-1 border-t border-[#1b4b3b]">
                  <span className="text-[11px] font-mono text-[#a4c5b7]">
                    {sector.level >= sector.maxLevel ? (
                      <span className="text-emerald-300 font-bold">Maximum Sovereignty Reached</span>
                    ) : (
                      <span>
                        Fortify Cost:{' '}
                        <strong className={resources.spiritStones >= upgradeCost ? 'text-[#fce18b]' : 'text-red-400'}>
                          💎 {formatLargeNumber(upgradeCost)}
                        </strong>
                      </span>
                    )}
                  </span>

                  <button
                    disabled={!canUpgrade}
                    onClick={() => {
                      soundEngine.playGong();
                      onUpgradeSector(sector);
                    }}
                    className={`px-3.5 py-2 rounded-xl font-dao font-bold text-xs flex items-center gap-1.5 min-h-[38px] transition-all ${
                      canUpgrade
                        ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-95'
                        : 'bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700'
                    }`}
                  >
                    <ArrowUpCircle className="w-3.5 h-3.5" />
                    <span>{sector.level >= sector.maxLevel ? 'Max Level' : 'Upgrade Sector'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Exit Bar */}
        <div className="p-3 bg-[#081e17] border-t border-[#133d30] flex justify-between items-center text-xs">
          <span className="text-[#6d8e80]">Mountain Peak Sovereignty</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] font-bold text-[11px] border border-[#e2b054]/30 min-h-[38px]"
          >
            Close Sectors
          </button>
        </div>
      </div>
    </div>
  );
};
