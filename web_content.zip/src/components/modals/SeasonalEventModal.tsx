import React from 'react';
import { SeasonalEventChoice, SeasonalEventItem } from '../../types/cultivation';
import { soundEngine } from '../../services/audioEngine';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Scroll, AlertTriangle, Swords, Compass, X, ChevronRight } from 'lucide-react';

interface SeasonalEventModalProps {
  eventsQueue: SeasonalEventItem[];
  currentIndex: number;
  totalCount: number;
  onResolveCurrent: (event: SeasonalEventItem, choice: SeasonalEventChoice) => void;
  onDismissAll?: () => void;
}

export const SeasonalEventModal: React.FC<SeasonalEventModalProps> = ({
  eventsQueue,
  currentIndex,
  totalCount,
  onResolveCurrent,
  onDismissAll
}) => {
  const currentEvent = eventsQueue[0];
  if (!currentEvent) return null;

  const getCategoryIcon = (cat: SeasonalEventItem['category']) => {
    switch (cat) {
      case 'Crisis':
        return <AlertTriangle className="w-5 h-5 text-red-400" />;
      case 'Tribulation':
        return <Swords className="w-5 h-5 text-amber-300" />;
      case 'Sector':
        return <Compass className="w-5 h-5 text-emerald-300" />;
      case 'TournamentNotice':
        return <Sparkles className="w-5 h-5 text-yellow-300" />;
      default:
        return <Scroll className="w-5 h-5 text-sky-300" />;
    }
  };

  const getCategoryColor = (cat: SeasonalEventItem['category']) => {
    switch (cat) {
      case 'Crisis': return 'border-red-500/70 bg-red-950/50 text-red-200';
      case 'Tribulation': return 'border-amber-500/70 bg-amber-950/50 text-amber-200';
      case 'Sector': return 'border-emerald-500/70 bg-emerald-950/50 text-emerald-200';
      case 'TournamentNotice': return 'border-yellow-400/70 bg-yellow-950/50 text-yellow-200';
      default: return 'border-sky-500/70 bg-sky-950/50 text-sky-200';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentEvent.id}
          initial={{ opacity: 0, scale: 0.94, y: 14 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: -12 }}
          transition={{ duration: 0.22 }}
          className="bg-[#123d30] border-2 border-[#e2b054] rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-[#0b261d] via-[#123d30] to-[#0b261d] p-3.5 sm:p-4 border-b border-[#e2b054]/40 flex justify-between items-center">
            <div className="flex items-center gap-2.5 min-w-0">
              {getCategoryIcon(currentEvent.category)}
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-[#e2b054] text-[#072018]">
                    Event {currentIndex} of {totalCount}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getCategoryColor(currentEvent.category)}`}>
                    {currentEvent.category}
                  </span>
                </div>
                <h3 className="font-dao font-bold text-base sm:text-lg text-[#fce18b] mt-1 leading-tight">
                  {currentEvent.title}
                </h3>
              </div>
            </div>

            {onDismissAll && (
              <button
                onClick={onDismissAll}
                title="Auto-resolve remaining events"
                className="p-2 rounded-xl bg-[#09261d] text-[#a4c5b7] hover:text-white border border-[#1d5543] min-w-[38px] min-h-[38px] flex items-center justify-center shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Progress Dots */}
          <div className="px-4 pt-3 flex items-center gap-1">
            {Array.from({ length: totalCount }).map((_, idx) => (
              <div
                key={idx}
                className={`h-1.5 rounded-full flex-1 transition-all ${
                  idx < currentIndex - 1
                    ? 'bg-emerald-500'
                    : idx === currentIndex - 1
                    ? 'bg-[#fce18b]'
                    : 'bg-[#09261d]'
                }`}
              />
            ))}
          </div>

          {/* Body */}
          <div className="p-4 space-y-4 overflow-y-auto text-xs text-[#d1e6dc]">
            <p className="text-xs sm:text-sm text-[#e6f3ec] leading-relaxed bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b]">
              {currentEvent.description}
            </p>

            <div className="space-y-2">
              <span className="text-[11px] font-bold text-[#fce18b] font-dao block">
                Issue Your Decree ({eventsQueue.length - 1} {eventsQueue.length - 1 === 1 ? 'event' : 'events'} remaining after this):
              </span>
              {currentEvent.choices.map((choice, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    soundEngine.playTalisman();
                    onResolveCurrent(currentEvent, choice);
                  }}
                  className="w-full p-3 rounded-2xl bg-[#0d2e23] hover:bg-[#184838] border border-[#e2b054]/40 hover:border-[#fce18b] text-left transition-all flex items-center justify-between gap-2 group active:scale-[0.99] min-h-[48px]"
                >
                  <div className="space-y-0.5">
                    <div className="font-bold text-white group-hover:text-[#fce18b] text-xs sm:text-sm">
                      {choice.text}
                    </div>
                    <div className="text-[10px] text-[#86efac]">
                      {choice.outcomeText}
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#e2b054] shrink-0 group-hover:translate-x-0.5 transition-transform" />
                </button>
              ))}
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
