import { useState } from "react";
import { Copy, Pencil } from "lucide-react";
import { toast } from "sonner";
import { updateProfile, type Me } from "@/lib/library-api";
import { Field, Modal, errorText, initials } from "@/components/bits";

export function ProfilePanel({ me, onChange }: { me: Me; onChange: (next: Me) => void }) {
  const [open, setOpen] = useState(false);
  const joined = new Date(me.createdAt);
  const joinedLabel = Number.isNaN(joined.getTime())
    ? ""
    : joined.toLocaleDateString([], { month: "long", year: "numeric" });

  async function copyId() {
    try {
      await navigator.clipboard.writeText(me.publicId);
      toast.success("Reader ID copied");
    } catch {
      toast.error("Select the ID and copy it from there.");
    }
  }

  return (
    <section className="mx-auto max-w-2xl">
      <div className="lift p-6 sm:p-8">
        <div className="flex flex-col items-center gap-5 sm:flex-row sm:items-start">
          <div className="relative">
            <div className="grid size-24 place-items-center rounded-full bg-primary font-display text-3xl text-primary-fg">
              {initials(me.name)}
            </div>
            <button
              type="button"
              aria-label="Edit profile"
              className="btn btn-ghost absolute -right-1 -bottom-1 size-11 bg-surface px-0"
              onClick={() => setOpen(true)}
            >
              <Pencil className="size-4" />
            </button>
          </div>
          <div className="min-w-0 flex-1 text-center sm:text-left">
            <h2 className="font-display text-4xl">{me.name}</h2>
            <p className="mt-2 text-sm text-muted">
              Reader ID{" "}
              <span className="rounded-lg bg-primary-soft px-2 py-1 font-semibold text-primary">{me.publicId}</span>
            </p>
            {joinedLabel && <p className="mt-1 text-xs text-muted">On the shelf since {joinedLabel}</p>}
            <p className="mt-4 text-sm text-ink">“{me.bio}”</p>
            <button type="button" className="btn btn-ghost mt-4" onClick={() => void copyId()}>
              <Copy className="size-4" /> Copy reader ID
            </button>
          </div>
        </div>

        <dl className="mt-8 grid grid-cols-3 gap-3 border-t border-line pt-6 text-center">
          <Stat value={me.readCount} label="Books opened" />
          <Stat value={me.uploadedCount} label="Uploaded" />
          <Stat value={me.shortsCount} label="Reviews" />
        </dl>
      </div>
      <p className="mt-4 px-1 text-sm text-muted">
        To keep Good Health Reader on your phone, use your browser’s Add to Home Screen or Install option. Your
        profile, books, and messages stay with this account.
      </p>
      {open && (
        <EditProfile
          me={me}
          onClose={() => setOpen(false)}
          onSaved={(next) => {
            onChange(next);
            setOpen(false);
            toast.success("Profile updated");
          }}
        />
      )}
    </section>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div className="rounded-2xl bg-paper px-2 py-4">
      <dt className="font-display text-3xl tabular-nums text-primary">{value}</dt>
      <dd className="mt-1 text-xs text-muted">{label}</dd>
    </div>
  );
}

function EditProfile({
  me,
  onClose,
  onSaved,
}: {
  me: Me;
  onClose: () => void;
  onSaved: (next: Me) => void;
}) {
  const [name, setName] = useState(me.name);
  const [bio, setBio] = useState(me.bio);
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    try {
      const next = await updateProfile({ data: { name, bio } });
      onSaved(next);
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="Edit profile" onClose={onClose}>
      <div className="space-y-4">
        <Field label="Name">
          <input id="profile-name" className="field-input" value={name} onChange={(event) => setName(event.target.value)} />
        </Field>
        <Field label="Bio">
          <textarea id="profile-bio" className="field-input field-area" value={bio} onChange={(event) => setBio(event.target.value)} />
        </Field>
        <p className="text-xs text-muted">Your reader ID, {me.publicId}, stays the same.</p>
        <div className="flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>Cancel</button>
          <button type="button" className="btn btn-primary" onClick={() => void submit()} disabled={busy}>
            {busy ? "Saving…" : "Save profile"}
          </button>
        </div>
      </div>
    </Modal>
  );
}
