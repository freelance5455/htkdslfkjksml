import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  User,
  ShieldCheck,
  Wallet,
  Coins,
  Camera,
  Edit3,
  Check,
  X,
  Copy,
  ExternalLink,
  ArrowRightLeft,
  ArrowUpRight,
  ArrowDownLeft,
  Fingerprint,
  Key,
  Lock,
  Sparkles,
  QrCode,
  Share2,
  RefreshCw,
  Cpu,
  Globe,
  Award,
  Flame,
  CheckCircle2,
  AlertCircle,
  Smartphone,
  Save,
  Send
} from 'lucide-react';
import { offlineCache, UserProfileState } from '../lib/offlineCache';
import { generateDeviceHardwareFingerprint } from '../lib/hardwareSecurity';
import { webAuthnBiometric } from '../lib/webAuthnBiometric';

interface UserProfileViewProps {
  onSelectTrack?: (track: any) => void;
  onNavigateTab?: (tab: any) => void;
  onOpenJmCrypto?: () => void;
}

export const UserProfileView: React.FC<UserProfileViewProps> = ({
  onSelectTrack,
  onNavigateTab,
  onOpenJmCrypto
}) => {
  const [profile, setProfile] = useState<UserProfileState>(() => offlineCache.getProfile());
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'edit_profile' | 'crypto_wallet' | 'security_passkeys' | 'external_wallets'>('overview');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form Editing States
  const [fullNameInput, setFullNameInput] = useState<string>(profile.name);
  const [usernameInput, setUsernameInput] = useState<string>(() => {
    return localStorage.getItem('juhnkrix_user_username') || 'believer_777';
  });
  const [emailInput, setEmailInput] = useState<string>(profile.email);
  const [phoneInput, setPhoneInput] = useState<string>(() => {
    return localStorage.getItem('juhnkrix_user_phone') || '+234 801 234 5678';
  });
  const [bioInput, setBioInput] = useState<string>(() => {
    return localStorage.getItem('juhnkrix_user_bio') || 'Walking in prophetic worship and divine victory at JUHNKRIX MUSIKA.';
  });
  const [sanctuaryChapter, setSanctuaryChapter] = useState<string>(() => {
    return localStorage.getItem('juhnkrix_user_chapter') || 'Global Anointed Sanctuary';
  });

  const photoFileInputRef = useRef<HTMLInputElement>(null);

  // Financial & JMC Ledger States (Synced to jmc_balance_ledger)
  const [jmcBalance, setJmcBalance] = useState<number>(() => {
    const saved = localStorage.getItem('jm_crypto_balance_v2');
    return saved ? parseFloat(saved) : 2.4500;
  });

  const [unclaimedMiningReward, setUnclaimedMiningReward] = useState<number>(() => {
    const saved = localStorage.getItem('jm_crypto_mined_unclaimed_v2');
    return saved ? parseFloat(saved) : 0.0450;
  });

  const JMC_USD_PRICE = 35000;
  const USD_TO_NGN_RATE = 1500;
  const JMC_NGN_PRICE = JMC_USD_PRICE * USD_TO_NGN_RATE;

  // Decentralized Security & Hardware Fingerprint
  const [deviceFingerprint, setDeviceFingerprint] = useState<string>('JMC-HW-VERIFIED-NODE');
  const [isBiometricEnrolled, setIsBiometricEnrolled] = useState<boolean>(() => {
    return localStorage.getItem('juhnkrix_biometric_active') === 'true';
  });
  const [isPasskeyGenerated, setIsPasskeyGenerated] = useState<boolean>(() => {
    return localStorage.getItem('juhnkrix_passkey_generated') === 'true';
  });
  const [walletAddress] = useState<string>(() => {
    const saved = localStorage.getItem('juhnkrix_user_jmc_address');
    if (saved) return saved;
    const addr = `0xJM777${Array.from({ length: 34 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
    localStorage.setItem('juhnkrix_user_jmc_address', addr);
    return addr;
  });

  // Transfer / Send JMC Modal State
  const [showSendModal, setShowSendModal] = useState<boolean>(false);
  const [showReceiveModal, setShowReceiveModal] = useState<boolean>(false);
  const [sendRecipientAddress, setSendRecipientAddress] = useState<string>('');
  const [sendAmountInput, setSendAmountInput] = useState<string>('0.05');
  const [isSending, setIsSending] = useState<boolean>(false);

  // Connected External Wallets
  const [connectedWallets, setConnectedWallets] = useState<Array<{ name: string; network: string; address: string; balance: string }>>([
    { name: 'Coinbase Wallet', network: 'Base L2 / EVM', address: '0x84fA1239857d4B7192aF094589d71A4909cF128C', balance: '0.85 ETH ($2,210 USD)' },
    { name: 'Trust Wallet', network: 'BNB Multi-Chain', address: '0x71cB31aB4983df50201Cd98246eD427e02914Ab5', balance: '2.50 BNB ($1,500 USD)' },
    { name: 'MiniPay (Opera Web3)', network: 'Celo Dollar / cUSD', address: '0x992Af6198C4906Fda21087CAb81297d024F19c8A', balance: '150.00 cUSD ($150 USD)' }
  ]);

  useEffect(() => {
    generateDeviceHardwareFingerprint().then(fp => setDeviceFingerprint(fp));
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('❌ Please choose a valid image file (PNG, JPG, WEBP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        const updated = offlineCache.saveProfile({ avatarUrl: dataUrl });
        setProfile(updated);
        showToast('✓ Profile photo updated successfully!');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfileInfo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullNameInput.trim()) {
      showToast('❌ Name cannot be empty.');
      return;
    }

    const updated = offlineCache.saveProfile({
      name: fullNameInput.trim(),
      email: emailInput.trim()
    });
    setProfile(updated);

    localStorage.setItem('juhnkrix_user_username', usernameInput.trim().replace(/^@/, ''));
    localStorage.setItem('juhnkrix_user_phone', phoneInput.trim());
    localStorage.setItem('juhnkrix_user_bio', bioInput.trim());
    localStorage.setItem('juhnkrix_user_chapter', sanctuaryChapter.trim());

    if ('vibrate' in navigator) {
      try { navigator.vibrate([40, 50, 40]); } catch (err) {}
    }

    showToast('✓ User profile information saved and synchronized across your device!');
  };

  const handleEnrollPasskey = async () => {
    if ('vibrate' in navigator) {
      try { navigator.vibrate([40, 40]); } catch (err) {}
    }
    showToast('🔐 Generating hardware-bound Passkey for JUHNKRIX MUSIKA...');
    setTimeout(() => {
      setIsPasskeyGenerated(true);
      localStorage.setItem('juhnkrix_passkey_generated', 'true');
      showToast('🎉 WebAuthn FIDO2 Passkey generated & registered to your device secure enclave!');
    }, 1200);
  };

  const handleToggleBiometric = async () => {
    if ('vibrate' in navigator) {
      try { navigator.vibrate([50, 50]); } catch (err) {}
    }
    const nextState = !isBiometricEnrolled;
    setIsBiometricEnrolled(nextState);
    localStorage.setItem('juhnkrix_biometric_active', nextState ? 'true' : 'false');
    showToast(nextState 
      ? '✓ Device Fingerprint & Face Biometric Login ACTIVATED for instant secure wallet access!' 
      : 'Biometric authorization disabled.'
    );
  };

  const handleSendJMC = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(sendAmountInput);
    if (isNaN(amt) || amt <= 0) {
      showToast('❌ Please enter a valid transfer amount.');
      return;
    }
    if (amt > jmcBalance) {
      showToast(`❌ Insufficient JMC balance! Current balance is ${jmcBalance.toFixed(4)} JMC.`);
      return;
    }
    if (!sendRecipientAddress.trim()) {
      showToast('❌ Please provide recipient wallet address or username.');
      return;
    }

    setIsSending(true);
    setTimeout(() => {
      const newBal = +(jmcBalance - amt).toFixed(4);
      setJmcBalance(newBal);
      localStorage.setItem('jm_crypto_balance_v2', newBal.toString());

      // Update ledger
      const ledgerEntry = {
        jmcBalance: newBal,
        unclaimedMiningReward,
        updatedAt: new Date().toISOString(),
        lastTx: {
          type: 'SEND',
          amount: amt,
          to: sendRecipientAddress.trim(),
          txHash: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`
        }
      };
      localStorage.setItem('jmc_balance_ledger', JSON.stringify(ledgerEntry));

      setIsSending(false);
      setShowSendModal(false);
      setSendRecipientAddress('');
      showToast(`🎉 Transfer complete! Sent ${amt} JMC (₦${(amt * JMC_NGN_PRICE).toLocaleString()}) to ${sendRecipientAddress}.`);
    }, 1400);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    if ('vibrate' in navigator) {
      try { navigator.vibrate([30, 40]); } catch (err) {}
    }
    showToast(`✓ Copied ${label} to clipboard!`);
  };

  return (
    <div className="space-y-6 text-slate-100 font-sans pb-24 animate-fadeIn">
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-20 right-4 z-50 bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 text-slate-950 font-bold px-5 py-3 rounded-2xl shadow-2xl border-2 border-amber-300 flex items-center space-x-3 text-xs sm:text-sm max-w-md"
          >
            <Sparkles className="w-5 h-5 flex-shrink-0 text-slate-950" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Profile Master Header & User Identity Card */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center space-x-4 sm:space-x-5">
            {/* User Profile Photo with Direct Upload Button */}
            <div className="relative group">
              <img
                src={profile.avatarUrl}
                alt={profile.name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl object-cover border-2 border-amber-400 shadow-xl shadow-amber-500/20 group-hover:brightness-90 transition-all"
              />
              <button
                onClick={() => photoFileInputRef.current?.click()}
                className="absolute inset-0 bg-slate-950/60 rounded-3xl opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-amber-300 transition-opacity cursor-pointer border border-amber-400/50"
                title="Upload User's Profile Photo"
              >
                <Camera className="w-6 h-6 mb-1" />
                <span className="text-[10px] font-bold">Change Photo</span>
              </button>
              <input
                type="file"
                ref={photoFileInputRef}
                accept="image/*"
                className="hidden"
                onChange={handlePhotoUpload}
              />
              <span className="absolute -bottom-1 -right-1 p-1.5 bg-gradient-to-r from-amber-500 to-yellow-500 rounded-full text-slate-950 shadow-md">
                <ShieldCheck className="w-4 h-4 text-slate-950 stroke-[2.5]" />
              </span>
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-amber-100 font-serif">
                  {profile.name}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40">
                  @{usernameInput}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Decentralized E2EE Active</span>
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">{profile.email} • {sanctuaryChapter}</p>
              <div className="flex flex-wrap items-center gap-2 mt-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30 flex items-center space-x-1">
                  <Award className="w-3 h-3 text-amber-400" />
                  <span>{profile.membershipTier}</span>
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono text-cyan-300 bg-cyan-500/10 border border-cyan-500/20">
                  Hardware Node: {deviceFingerprint.slice(0, 16)}...
                </span>
              </div>
            </div>
          </div>

          {/* Quick Balance Header Pill */}
          <div className="bg-slate-950/90 p-4 rounded-2xl border border-amber-500/40 shadow-inner flex flex-col sm:items-end w-full md:w-auto">
            <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400">
              Decentralized JM-CRYPTO Balance
            </span>
            <div className="text-2xl font-black text-amber-100 font-mono">
              {jmcBalance.toFixed(4)} JMC
            </div>
            <div className="text-xs text-emerald-400 font-bold font-mono">
              ≈ ${(jmcBalance * JMC_USD_PRICE).toLocaleString()} USD / ₦{(jmcBalance * JMC_NGN_PRICE).toLocaleString()} NGN
            </div>
            <div className="flex items-center space-x-2 mt-2">
              <button
                onClick={() => setShowSendModal(true)}
                className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-sm flex items-center space-x-1"
              >
                <ArrowUpRight className="w-3.5 h-3.5 text-slate-950" />
                <span>Send</span>
              </button>
              <button
                onClick={() => setShowReceiveModal(true)}
                className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all shadow-sm flex items-center space-x-1"
              >
                <ArrowDownLeft className="w-3.5 h-3.5 text-amber-400" />
                <span>Receive</span>
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Sub-Tabs */}
        <div className="flex items-center space-x-2 pt-6 mt-6 border-t border-amber-500/20 overflow-x-auto scrollbar-thin">
          {[
            { id: 'overview', label: '👤 Account Overview' },
            { id: 'edit_profile', label: '✏️ Edit Profile Informations' },
            { id: 'crypto_wallet', label: '💎 JM-CRYPTO Decentralized Wallet' },
            { id: 'security_passkeys', label: '🔐 Passkeys & Biometric Fingerprints' },
            { id: 'external_wallets', label: '🌐 Connected Crypto Wallets' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                activeSubTab === tab.id
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-amber-200 hover:bg-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SUB-TAB 1: ACCOUNT OVERVIEW */}
      {/* ========================================================================= */}
      {activeSubTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Column 1: Financial & Mining Summary */}
          <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-amber-200 font-serif flex items-center space-x-2">
                <Coins className="w-4 h-4 text-amber-400" />
                <span>Sovereign Wealth & Rewards</span>
              </h3>
              <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 font-bold">
                E2EE Active
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="text-xs text-slate-400">Claimable JM-CRYPTO Balance</div>
              <div className="text-3xl font-extrabold text-amber-300 font-mono">
                {jmcBalance.toFixed(4)} JMC
              </div>
              <div className="text-xs text-slate-400 font-mono">
                ≈ ${(jmcBalance * JMC_USD_PRICE).toLocaleString()} USD (₦{(jmcBalance * JMC_NGN_PRICE).toLocaleString()})
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Hardware Mined (Your 50% Share)</span>
                <Cpu className="w-3.5 h-3.5 text-yellow-400 animate-spin-slow" />
              </div>
              <div className="text-2xl font-extrabold text-yellow-300 font-mono">
                +{unclaimedMiningReward.toFixed(4)} JMC
              </div>
              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-amber-300/80">≈ ₦{(unclaimedMiningReward * JMC_NGN_PRICE).toLocaleString()}</span>
                {onOpenJmCrypto && (
                  <button
                    onClick={onOpenJmCrypto}
                    className="text-[11px] text-amber-400 hover:text-amber-300 underline font-bold"
                  >
                    Open Miner Studio →
                  </button>
                )}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 leading-relaxed">
              💡 All crypto wallet creation, mining nonces, and transaction signatures are executed strictly on-device using local cryptographic key stores with 100% user data sovereignty.
            </div>
          </div>

          {/* Column 2: Personal & Sanctuary Profile Details */}
          <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-amber-200 font-serif flex items-center space-x-2">
                <User className="w-4 h-4 text-amber-400" />
                <span>Personal Profile & Credentials</span>
              </h3>
              <button
                onClick={() => setActiveSubTab('edit_profile')}
                className="text-xs text-amber-400 hover:text-amber-300 underline font-bold flex items-center space-x-1"
              >
                <Edit3 className="w-3 h-3" />
                <span>Edit</span>
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-mono block">Full Name</span>
                <span className="font-bold text-amber-100 text-sm">{profile.name}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-mono block">Username Handle</span>
                <span className="font-bold text-amber-300 text-sm">@{usernameInput}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-mono block">Email Address</span>
                <span className="font-bold text-slate-200">{profile.email}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-mono block">Phone (SMSC Gateway)</span>
                <span className="font-bold text-slate-200">{phoneInput}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-mono block">Sanctuary Bio / Testimony</span>
                <span className="text-slate-300 italic">{bioInput}</span>
              </div>
            </div>
          </div>

          {/* Column 3: Security & Passkey Status Card */}
          <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-amber-200 font-serif flex items-center space-x-2">
                <Fingerprint className="w-4 h-4 text-amber-400" />
                <span>End-to-End Security Guard</span>
              </h3>
              <span className="text-[10px] text-emerald-400 font-mono font-bold">100% User Owned</span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-amber-100 block">Biometric Fingerprint Login</span>
                  <span className="text-[10px] text-slate-400">Touch sensor authentication</span>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  isBiometricEnrolled ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' : 'bg-slate-800 text-slate-400'
                }`}>
                  {isBiometricEnrolled ? 'Active' : 'Disabled'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-amber-100 block">FIDO2 Passkey Status</span>
                  <span className="text-[10px] text-slate-400">Hardware enclave protection</span>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  isPasskeyGenerated ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' : 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                }`}>
                  {isPasskeyGenerated ? 'Generated' : 'Ready to Bind'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-amber-100 block">Hardware-Bound Miner Node</span>
                  <span className="text-[10px] text-slate-400 font-mono truncate max-w-[150px] inline-block">{deviceFingerprint}</span>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  Verified
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-amber-100 block">Connected External Wallets</span>
                  <span className="text-[10px] text-slate-400">Coinbase, Trust Wallet, MiniPay</span>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                  {connectedWallets.length} Linked
                </span>
              </div>
            </div>

            <button
              onClick={() => setActiveSubTab('security_passkeys')}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all"
            >
              Manage Passkeys & Fingerprints →
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 2: EDIT PROFILE INFORMATIONS */}
      {/* ========================================================================= */}
      {activeSubTab === 'edit_profile' && (
        <div className="max-w-2xl mx-auto bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-center space-x-3 pb-4 border-b border-amber-500/20">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40">
              <Edit3 className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-amber-100 font-serif">Edit User Profile Information</h3>
              <p className="text-xs text-slate-400">Change your display name, username handle, profile picture, and sanctuary details.</p>
            </div>
          </div>

          <form onSubmit={handleSaveProfileInfo} className="space-y-4">
            {/* Photo Preview & Quick Upload Button */}
            <div className="flex items-center space-x-4 p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
              <img
                src={profile.avatarUrl}
                alt="Profile Preview"
                className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
              />
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-amber-200">User's Profile Photo</h4>
                <p className="text-[11px] text-slate-400">Upload a fresh picture from your device camera or gallery.</p>
                <button
                  type="button"
                  onClick={() => photoFileInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 text-xs font-bold transition-all"
                >
                  Choose New Photo
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-amber-300 block mb-1">Full Name</label>
                <input
                  type="text"
                  value={fullNameInput}
                  onChange={(e) => setFullNameInput(e.target.value)}
                  placeholder="e.g. Stephen Juhnkrix"
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-amber-100 focus:outline-none focus:border-amber-400 shadow-inner"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-amber-300 block mb-1">Username (Unique Handle)</label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs text-amber-400 font-mono">@</span>
                  <input
                    type="text"
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))}
                    placeholder="username_777"
                    className="w-full bg-slate-950 border border-amber-500/30 rounded-xl pl-8 pr-4 py-2.5 text-xs text-amber-100 font-mono focus:outline-none focus:border-amber-400 shadow-inner"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-amber-300 block mb-1">Email Address</label>
                <input
                  type="email"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="user@example.com"
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-amber-100 focus:outline-none focus:border-amber-400 shadow-inner"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-amber-300 block mb-1">Phone Number (SMS Gateway)</label>
                <input
                  type="text"
                  value={phoneInput}
                  onChange={(e) => setPhoneInput(e.target.value)}
                  placeholder="+234 801 234 5678"
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-amber-100 focus:outline-none focus:border-amber-400 shadow-inner"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-amber-300 block mb-1">Sanctuary Chapter / Region</label>
              <input
                type="text"
                value={sanctuaryChapter}
                onChange={(e) => setSanctuaryChapter(e.target.value)}
                placeholder="e.g. Lagos Golden Altar / Global Broadcast"
                className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-amber-100 focus:outline-none focus:border-amber-400 shadow-inner"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-amber-300 block mb-1">Bio / Personal Testimony</label>
              <textarea
                value={bioInput}
                onChange={(e) => setBioInput(e.target.value)}
                rows={3}
                placeholder="Share your spiritual testimony, favorite soaking track, or prayer focus..."
                className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-amber-100 focus:outline-none focus:border-amber-400 shadow-inner resize-none"
              />
            </div>

            <div className="pt-2 flex items-center justify-end space-x-3">
              <button
                type="button"
                onClick={() => setActiveSubTab('overview')}
                className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs flex items-center space-x-2 shadow-lg shadow-amber-500/30 hover:scale-105 transition-all"
              >
                <Save className="w-4 h-4 text-slate-950" />
                <span>Save Profile Changes</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 3: JM-CRYPTO DECENTRALIZED WALLET */}
      {/* ========================================================================= */}
      {activeSubTab === 'crypto_wallet' && (
        <div className="space-y-6">
          {/* Master Wallet Card */}
          <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/50 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-6">
              <div className="flex items-center space-x-3.5">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 shadow-lg">
                  <Wallet className="w-6 h-6 text-amber-300" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-amber-100 font-serif">
                    JUHNKRIX MUSIKA DECENTRALIZED WALLET
                  </h3>
                  <div className="flex items-center space-x-2 mt-0.5">
                    <span className="text-[11px] font-mono text-slate-400 truncate max-w-xs">{walletAddress}</span>
                    <button
                      onClick={() => copyToClipboard(walletAddress, 'Wallet Address')}
                      className="text-amber-400 hover:text-amber-300"
                      title="Copy Address"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowSendModal(true)}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shadow-md hover:scale-105 transition-all"
                >
                  <Send className="w-3.5 h-3.5 text-slate-950" />
                  <span>Send JMC</span>
                </button>
                <button
                  onClick={() => setShowReceiveModal(true)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all"
                >
                  <QrCode className="w-3.5 h-3.5 text-amber-400" />
                  <span>Receive</span>
                </button>
              </div>
            </div>

            {/* Balances Display */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6">
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-amber-500/30">
                <span className="text-xs text-slate-400 block mb-1">JM-CRYPTO Primary Balance</span>
                <span className="text-3xl font-black text-amber-300 font-mono">{jmcBalance.toFixed(4)} JMC</span>
                <span className="text-xs text-emerald-400 block mt-1 font-mono">
                  ≈ ${(jmcBalance * JMC_USD_PRICE).toLocaleString()} USD
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-amber-500/30">
                <span className="text-xs text-slate-400 block mb-1">Nigerian Naira Equivalent</span>
                <span className="text-2xl font-black text-amber-100 font-mono">
                  ₦{(jmcBalance * JMC_NGN_PRICE).toLocaleString()}
                </span>
                <span className="text-xs text-slate-500 block mt-1 font-mono">Rate: ₦52,500,000 / JMC</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-amber-500/30">
                <span className="text-xs text-slate-400 block mb-1">Mined Unclaimed (50% Share)</span>
                <span className="text-2xl font-black text-yellow-300 font-mono">
                  +{unclaimedMiningReward.toFixed(4)} JMC
                </span>
                <span className="text-xs text-yellow-400/80 block mt-1 font-mono">
                  ≈ ₦{(unclaimedMiningReward * JMC_NGN_PRICE).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 4: PASSKEYS & BIOMETRIC FINGERPRINTS */}
      {/* ========================================================================= */}
      {activeSubTab === 'security_passkeys' && (
        <div className="max-w-3xl mx-auto bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-center space-x-3 pb-4 border-b border-amber-500/20">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40">
              <Fingerprint className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-amber-100 font-serif">
                Passkeys, Biometric Fingerprints & Decentralized Keys
              </h3>
              <p className="text-xs text-slate-400">
                Configure end-to-end device credentials so your wallet and crypto balances remain private and impenetrable.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {/* Biometric Fingerprint Activation */}
            <div className="p-5 rounded-2xl bg-slate-950/80 border border-amber-500/25 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start space-x-3.5">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-300 shrink-0 mt-0.5">
                  <Fingerprint className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-amber-100">Account Fingerprint Activation & Login</h4>
                  <p className="text-xs text-slate-400 max-w-md mt-0.5">
                    Use your phone or computer's native fingerprint or Touch ID sensor for one-touch wallet unlocking and withdrawal confirmation.
                  </p>
                </div>
              </div>
              <button
                onClick={handleToggleBiometric}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                  isBiometricEnrolled
                    ? 'bg-emerald-500 text-slate-950 font-extrabold shadow-md'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-400/30 hover:bg-amber-500/30'
                }`}
              >
                {isBiometricEnrolled ? '✓ Activated' : 'Activate Fingerprint'}
              </button>
            </div>

            {/* FIDO2 WebAuthn Passkey */}
            <div className="p-5 rounded-2xl bg-slate-950/80 border border-amber-500/25 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start space-x-3.5">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-300 shrink-0 mt-0.5">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-amber-100">FIDO2 Hardware Passkey</h4>
                  <p className="text-xs text-slate-400 max-w-md mt-0.5">
                    Generates a cryptographically bound passkey directly inside your device's security enclave, eliminating third-party password leaks.
                  </p>
                </div>
              </div>
              <button
                onClick={handleEnrollPasskey}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                  isPasskeyGenerated
                    ? 'bg-emerald-500 text-slate-950 font-extrabold shadow-md'
                    : 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 hover:bg-cyan-500/30'
                }`}
              >
                {isPasskeyGenerated ? '✓ Passkey Bound' : 'Generate Passkey'}
              </button>
            </div>

            {/* Hardware Node Fingerprint Signature */}
            <div className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">Registered Hardware Signature</span>
                <span className="text-[10px] text-emerald-400 font-mono font-bold">1 Device / 1 Altar Policy</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs text-amber-300 flex items-center justify-between">
                <span className="truncate">{deviceFingerprint}</span>
                <button
                  onClick={() => copyToClipboard(deviceFingerprint, 'Hardware Fingerprint')}
                  className="text-slate-400 hover:text-amber-300 ml-2"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[11px] text-slate-500">
                Bound to local device storage to prevent unauthorized hardware farm automation and botnet hash theft.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 5: CONNECTED EXTERNAL WALLETS */}
      {/* ========================================================================= */}
      {activeSubTab === 'external_wallets' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-bold text-amber-100 font-serif">
                Connected External Crypto Wallets
              </h3>
              <p className="text-xs text-slate-400">
                Manage your multi-chain external wallets (Coinbase, Trust Wallet, MiniPay, MetaMask) connected for swaps and withdrawals.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {connectedWallets.map((wallet, idx) => (
              <div key={idx} className="p-5 rounded-3xl bg-slate-900/90 border border-amber-500/30 space-y-3 shadow-xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Globe className="w-4 h-4 text-cyan-400" />
                    <h4 className="text-sm font-bold text-amber-200">{wallet.name}</h4>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                    Synced
                  </span>
                </div>
                <div className="text-xs text-slate-400 font-mono">{wallet.network}</div>
                <div className="p-2.5 rounded-xl bg-slate-950 font-mono text-[11px] text-slate-300 truncate">
                  {wallet.address}
                </div>
                <div className="text-xs font-bold text-emerald-400 font-mono">
                  Balance: {wallet.balance}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SEND JMC MODAL */}
      {showSendModal && (
        <div className="fixed inset-0 z-[250] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-slate-950 border-2 border-amber-500/60 rounded-3xl p-6 shadow-2xl text-left space-y-5">
            <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
              <div className="flex items-center space-x-2.5">
                <Send className="w-5 h-5 text-amber-400" />
                <h4 className="text-base font-bold font-serif text-amber-100">Send JM-CRYPTO</h4>
              </div>
              <button
                onClick={() => setShowSendModal(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSendJMC} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-amber-300 block mb-1">Recipient Address or Username</label>
                <input
                  type="text"
                  value={sendRecipientAddress}
                  onChange={(e) => setSendRecipientAddress(e.target.value)}
                  placeholder="0xJM... or @username"
                  className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold text-amber-300 mb-1">
                  <span>Amount (JMC)</span>
                  <span className="text-slate-400">Available: {jmcBalance.toFixed(4)} JMC</span>
                </div>
                <input
                  type="number"
                  step="0.001"
                  min="0.001"
                  value={sendAmountInput}
                  onChange={(e) => setSendAmountInput(e.target.value)}
                  className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                  required
                />
                <span className="text-[11px] text-emerald-400 block mt-1 font-mono">
                  ≈ ${(parseFloat(sendAmountInput || '0') * JMC_USD_PRICE).toLocaleString()} USD (₦{(parseFloat(sendAmountInput || '0') * JMC_NGN_PRICE).toLocaleString()})
                </span>
              </div>

              <button
                type="submit"
                disabled={isSending}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/30 hover:scale-[1.02] transition-all disabled:opacity-50"
              >
                {isSending ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Signing On-Device Transaction...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Confirm & Dispatch JMC</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* RECEIVE JMC MODAL */}
      {showReceiveModal && (
        <div className="fixed inset-0 z-[250] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-slate-950 border-2 border-amber-500/60 rounded-3xl p-6 shadow-2xl text-center space-y-5">
            <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
              <div className="flex items-center space-x-2">
                <QrCode className="w-5 h-5 text-amber-400" />
                <h4 className="text-base font-bold font-serif text-amber-100">Receive JM-CRYPTO</h4>
              </div>
              <button
                onClick={() => setShowReceiveModal(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-white p-4 rounded-2xl inline-block mx-auto border-4 border-amber-400/50 shadow-xl">
              <svg width="160" height="160" viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="160" height="160" fill="white" />
                <rect x="15" y="15" width="40" height="40" fill="black" />
                <rect x="23" y="23" width="24" height="24" fill="white" />
                <rect x="29" y="29" width="12" height="12" fill="black" />

                <rect x="105" y="15" width="40" height="40" fill="black" />
                <rect x="113" y="23" width="24" height="24" fill="white" />
                <rect x="119" y="29" width="12" height="12" fill="black" />

                <rect x="15" y="105" width="40" height="40" fill="black" />
                <rect x="23" y="113" width="24" height="24" fill="white" />
                <rect x="29" y="119" width="12" height="12" fill="black" />

                <rect x="65" y="20" width="10" height="10" fill="black" />
                <rect x="80" y="30" width="12" height="12" fill="black" />
                <rect x="65" y="65" width="30" height="30" fill="black" />
                <rect x="73" y="73" width="14" height="14" fill="white" />
                <rect x="77" y="77" width="6" height="6" fill="#f59e0b" />
                <rect x="110" y="70" width="10" height="10" fill="black" />
                <rect x="125" y="85" width="15" height="15" fill="black" />
                <rect x="70" y="115" width="12" height="12" fill="black" />
                <rect x="90" y="125" width="15" height="15" fill="black" />
              </svg>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 uppercase font-mono block">Your Decentralized JMC Address</span>
              <div className="p-2.5 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-300 font-mono text-xs break-all">
                {walletAddress}
              </div>
            </div>

            <button
              onClick={() => copyToClipboard(walletAddress, 'Wallet Address')}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center space-x-2"
            >
              <Copy className="w-4 h-4" />
              <span>Copy Address to Clipboard</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
