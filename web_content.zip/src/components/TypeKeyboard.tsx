interface Props {
  onKey: (ch: string) => void;
  onBackspace: () => void;
}

const ROWS = [
  ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
  ["a", "s", "d", "f", "g", "h", "j", "k", "l"],
  ["z", "x", "c", "v", "b", "n", "m"],
];

export default function TypeKeyboard({ onKey, onBackspace }: Props) {
  return (
    <div className="no-select mx-auto w-full max-w-2xl select-none px-2 pb-2">
      <div className="flex flex-col items-center gap-1.5">
        {ROWS.map((row, r) => (
          <div key={r} className="flex w-full justify-center gap-1">
            {row.map((k) => (
              <button
                key={k}
                onPointerDown={(e) => {
                  e.preventDefault();
                  onKey(k);
                }}
                className="h-9 min-w-0 flex-1 rounded-lg border border-white/10 bg-white/[0.07] font-display text-[13px] font-bold text-slate-100 shadow-[0_2px_0_rgba(255,255,255,0.06)] transition active:scale-90 active:bg-cyan-400/40 sm:h-11 sm:text-base"
              >
                {k}
              </button>
            ))}
            {r === 2 && (
              <button
                onPointerDown={(e) => {
                  e.preventDefault();
                  onBackspace();
                }}
                className="h-9 w-14 shrink-0 rounded-lg border border-white/10 bg-white/[0.07] text-sm font-bold text-rose-200 transition active:scale-90 active:bg-rose-400/40 sm:h-11 sm:w-16"
              >
                ⌫
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
