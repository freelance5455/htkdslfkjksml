import React, { useState, useEffect } from 'react';
import {
  X,
  Play,
  Pause,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Clock,
  Heart,
  Save,
  RotateCcw,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import confetti from 'canvas-confetti';
import { RegulationTool, ScriptStep } from '../types/index.ts';
import { storageService } from '../lib/supabase.ts';
import { BreathingWidget } from './BreathingWidget.tsx';
import { EftDiagram } from './EftDiagram.tsx';
import { GroundingWidget } from './GroundingWidget.tsx';

interface ToolRunnerModalProps {
  tool: RegulationTool | null;
  onClose: () => void;
  onSessionSaved?: () => void;
  initialVersion?: 'short' | 'full';
}

export const ToolRunnerModal: React.FC<ToolRunnerModalProps> = ({
  tool,
  onClose,
  onSessionSaved,
  initialVersion = 'short',
}) => {
  const { t } = useTranslation();

  const [version, setVersion] = useState<'short' | 'full'>(initialVersion);
  const [phase, setPhase] = useState<'before' | 'active' | 'after'>('before');
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [ratingBefore, setRatingBefore] = useState<number>(7);
  const [ratingAfter, setRatingAfter] = useState<number>(3);
  const [notes, setNotes] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Pause timer state
  const [isPauseRunning, setIsPauseRunning] = useState<boolean>(false);
  const [pauseSecondsRemaining, setPauseSecondsRemaining] = useState<number>(0);

  // Session elapsed timer
  const [sessionStartTime, setSessionStartTime] = useState<number>(Date.now());

  useEffect(() => {
    if (tool) {
      setVersion(initialVersion);
      setPhase('before');
      setCurrentStepIndex(0);
      setRatingBefore(7);
      setRatingAfter(3);
      setNotes('');
      setIsPauseRunning(false);
    }
  }, [tool, initialVersion]);

  // Pause timer countdown
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPauseRunning && pauseSecondsRemaining > 0) {
      timer = setInterval(() => {
        setPauseSecondsRemaining((prev) => {
          if (prev <= 1) {
            setIsPauseRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isPauseRunning, pauseSecondsRemaining]);

  if (!tool) return null;

  const steps: ScriptStep[] = version === 'short' ? tool.shortScript : tool.fullScript;
  const currentStep = steps[currentStepIndex] || steps[0];

  const handleStartExercise = () => {
    setSessionStartTime(Date.now());
    setPhase('active');
    setCurrentStepIndex(0);
    if (currentStep?.pauseDurationSeconds) {
      setPauseSecondsRemaining(currentStep.pauseDurationSeconds);
    }
  };

  const handleNextStep = () => {
    setIsPauseRunning(false);
    if (currentStepIndex < steps.length - 1) {
      const nextIndex = currentStepIndex + 1;
      setCurrentStepIndex(nextIndex);
      if (steps[nextIndex]?.pauseDurationSeconds) {
        setPauseSecondsRemaining(steps[nextIndex].pauseDurationSeconds);
      }
    } else {
      setPhase('after');
    }
  };

  const handlePrevStep = () => {
    setIsPauseRunning(false);
    if (currentStepIndex > 0) {
      const prevIndex = currentStepIndex - 1;
      setCurrentStepIndex(prevIndex);
      if (steps[prevIndex]?.pauseDurationSeconds) {
        setPauseSecondsRemaining(steps[prevIndex].pauseDurationSeconds);
      }
    }
  };

  const triggerPause = () => {
    if (!isPauseRunning) {
      const sec = currentStep.pauseDurationSeconds || 10;
      setPauseSecondsRemaining(sec);
      setIsPauseRunning(true);
    } else {
      setIsPauseRunning(false);
    }
  };

  const handleSaveSession = async () => {
    setIsSaving(true);
    try {
      const durationSeconds = Math.round((Date.now() - sessionStartTime) / 1000);
      const user = storageService.getUserProfile();
      await storageService.saveSession({
        userId: user ? user.id : 'guest',
        spaceType: tool.space,
        toolId: tool.id,
        toolTitle: tool.titleKey,
        durationSeconds: Math.max(durationSeconds, 30),
        ratingBefore,
        ratingAfter,
        notes,
        version,
      });

      // Also log emotional delta
      await storageService.saveEmotionalLog({
        userId: user ? user.id : 'guest',
        primaryEmotion: tool.titleKey,
        intensityBefore: ratingBefore,
        intensityAfter: ratingAfter,
        context: tool.space,
        notes,
      });

      if (ratingBefore > ratingAfter) {
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.7 },
            colors: ['#f43f5e', '#14b8a6', '#f59e0b', '#3b82f6'],
          });
        } catch {
          // Silent fallback if confetti fails
        }
      }

      if (onSessionSaved) {
        onSessionSaved();
      }
      onClose();
    } catch (err) {
      console.error('Failed to save session:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const reliefPoints = ratingBefore - ratingAfter;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-rose-100 dark:border-slate-800 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-slate-100 dark:border-slate-800 bg-gradient-to-r from-rose-50/70 via-white to-teal-50/70 dark:from-slate-900 dark:to-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500 text-white flex items-center justify-center shadow-md">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-base sm:text-lg leading-tight">
                {tool.titleKey}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {tool.space === 'parents' ? 'Espace Parents & Co-régulation' : 'Espace Adulte'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
              title={t('toolRunner.close')}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Version Switcher (Short / Full) */}
        {phase !== 'after' && (
          <div className="px-6 pt-4 pb-2 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30 border-b border-slate-100 dark:border-slate-800 text-xs">
            <span className="font-semibold text-slate-500 dark:text-slate-400">
              Format de la séance :
            </span>
            <div className="flex items-center gap-1 bg-white dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 shadow-2xs">
              <button
                onClick={() => {
                  setVersion('short');
                  setCurrentStepIndex(0);
                }}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                  version === 'short'
                    ? 'bg-rose-500 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                ⚡ {t('toolRunner.shortVersion')} (~{tool.durationShortMin} min)
              </button>
              <button
                onClick={() => {
                  setVersion('full');
                  setCurrentStepIndex(0);
                }}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                  version === 'full'
                    ? 'bg-rose-500 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                🌿 {t('toolRunner.fullVersion')} (~{tool.durationFullMin} min)
              </button>
            </div>
          </div>
        )}

        {/* Scrollable Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* PHASE 1: BEFORE RATING */}
          {phase === 'before' && (
            <div className="space-y-6 text-center max-w-md mx-auto py-4">
              <div className="w-16 h-16 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 mx-auto flex items-center justify-center">
                <Clock className="w-8 h-8" />
              </div>

              <div>
                <h4 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-1">
                  {t('toolRunner.beforeRatingTitle')}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {t('toolRunner.scaleHelp')}
                </p>
              </div>

              {/* 0 - 10 Scale Buttons */}
              <div className="grid grid-cols-11 gap-1 my-4">
                {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => {
                  const isSelected = ratingBefore === num;
                  return (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setRatingBefore(num)}
                      className={`h-11 rounded-xl font-extrabold text-sm transition-all ${
                        isSelected
                          ? 'bg-rose-500 text-white ring-4 ring-rose-200 dark:ring-rose-900 scale-110 shadow-md z-10'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-rose-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      {num}
                    </button>
                  );
                })}
              </div>

              <div className="flex justify-between text-xs text-slate-400 px-1 font-medium">
                <span>0 (Calme absolu)</span>
                <span>5 (Moyen)</span>
                <span>10 (Détresse max)</span>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleStartExercise}
                  className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-rose-500 to-rose-600 hover:from-rose-600 hover:to-rose-700 text-white font-bold text-base shadow-lg shadow-rose-200 dark:shadow-none transition-all flex items-center justify-center gap-2 group"
                >
                  <Play className="w-5 h-5 fill-current transition-transform group-hover:scale-110" />
                  <span>{t('toolRunner.start')}</span>
                </button>
              </div>
            </div>
          )}

          {/* PHASE 2: ACTIVE SCRIPT STEPPER */}
          {phase === 'active' && (
            <div className="space-y-6">
              {/* Step indicator */}
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 border-b border-slate-100 dark:border-slate-800 pb-2">
                <span className="font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider">
                  {t('toolRunner.step')} {currentStepIndex + 1} {t('toolRunner.of')} {steps.length}
                </span>
                <span className="font-semibold text-slate-600 dark:text-slate-300">
                  {currentStep.title}
                </span>
              </div>

              {/* Instruction banner */}
              <div className="p-3.5 rounded-2xl bg-teal-50 dark:bg-teal-950/30 border border-teal-100 dark:border-teal-900 text-teal-800 dark:text-teal-200 text-xs sm:text-sm font-semibold flex items-center gap-2.5">
                <div className="w-2 h-2 rounded-full bg-teal-500 animate-ping shrink-0" />
                <span>{currentStep.instruction}</span>
              </div>

              {/* Main Guided Script with breathing space */}
              <div className="p-5 sm:p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700 space-y-4">
                <p className="text-base sm:text-lg text-slate-800 dark:text-slate-100 leading-relaxed font-medium whitespace-pre-line">
                  {currentStep.script}
                </p>

                {/* Somatic anchor focus if present */}
                {currentStep.somaticFocus && (
                  <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900 text-amber-900 dark:text-amber-200 text-xs flex items-center gap-2">
                    <span className="font-bold">{t('toolRunner.somaticNotice')}</span>
                    <span>{currentStep.somaticFocus}</span>
                  </div>
                )}

                {/* Pause Cue with Interactive Countdown Button */}
                {currentStep.pauseDurationSeconds && (
                  <div className="mt-4 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-rose-100 dark:border-slate-700 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="text-center sm:text-left">
                      <div className="text-xs font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider">
                        {t('toolRunner.pauseIndicator')} ({currentStep.pauseDurationSeconds}s)
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        {currentStep.pauseNote || t('toolRunner.pauseInstruction')}
                      </p>
                    </div>

                    <button
                      onClick={triggerPause}
                      className={`px-4 py-2 rounded-full font-bold text-xs flex items-center gap-2 transition-all shadow-xs ${
                        isPauseRunning
                          ? 'bg-rose-500 text-white animate-pulse'
                          : 'bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-slate-800 dark:text-rose-300'
                      }`}
                    >
                      {isPauseRunning ? (
                        <>
                          <Pause className="w-3.5 h-3.5" />
                          <span>Pause en cours ({pauseSecondsRemaining}s)</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5" />
                          <span>Lancer la pause ({currentStep.pauseDurationSeconds}s)</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {/* Embedded Specialized Interactive Components */}
              {tool.interactiveComponent === 'breathing' && (
                <BreathingWidget targetMinutes={version === 'short' ? 3 : 5} />
              )}

              {tool.interactiveComponent === 'eft_adult' && (
                <EftDiagram mode="adult" />
              )}

              {tool.interactiveComponent === 'eft_child' && (
                <EftDiagram mode="child" />
              )}

              {tool.interactiveComponent === 'grounding_54321' && (
                <GroundingWidget />
              )}

              {/* Stepper Navigation Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={handlePrevStep}
                  disabled={currentStepIndex === 0}
                  className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold transition-all ${
                    currentStepIndex === 0
                      ? 'opacity-40 cursor-not-allowed text-slate-400'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>{t('toolRunner.prev')}</span>
                </button>

                <button
                  onClick={handleNextStep}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white text-xs sm:text-sm font-bold shadow-md transition-all"
                >
                  <span>
                    {currentStepIndex < steps.length - 1
                      ? t('toolRunner.next')
                      : t('toolRunner.finish')}
                  </span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* PHASE 3: AFTER RATING & RELIEF SUMMARY */}
          {phase === 'after' && (
            <div className="space-y-6 text-center max-w-md mx-auto py-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-300 mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <h4 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-1">
                  {t('toolRunner.afterRatingTitle')}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {t('toolRunner.scaleHelp')}
                </p>
              </div>

              {/* 0 - 10 Scale Buttons */}
              <div className="grid grid-cols-11 gap-1 my-4">
                {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => {
                  const isSelected = ratingAfter === num;
                  return (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setRatingAfter(num)}
                      className={`h-11 rounded-xl font-extrabold text-sm transition-all ${
                        isSelected
                          ? 'bg-emerald-500 text-white ring-4 ring-emerald-200 dark:ring-emerald-900 scale-110 shadow-md z-10'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      {num}
                    </button>
                  );
                })}
              </div>

              {/* Dynamic Relief Banner */}
              <div
                className={`p-4 rounded-2xl border text-sm font-semibold ${
                  reliefPoints > 0
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {reliefPoints > 0 ? (
                  <>
                    🌱 {t('toolRunner.deltaPositive', { points: reliefPoints })}
                    <div className="text-xs font-normal opacity-85 mt-1">
                      Votre système nerveux s'est déchargé de {ratingBefore}/10 à {ratingAfter}/10.
                    </div>
                  </>
                ) : (
                  <>🌿 {t('toolRunner.deltaNeutral')}</>
                )}
              </div>

              {/* Optional reflection notes */}
              <div className="text-left">
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  Notes ou sensations corporelles observées (optionnel) :
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ex : respiration plus profonde, mâchoire détendue, sensation de chaleur..."
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 resize-none h-18 focus:outline-none focus:ring-2 focus:ring-rose-400"
                />
              </div>

              {/* Save & Finish Button */}
              <button
                onClick={handleSaveSession}
                disabled={isSaving}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-base shadow-lg shadow-emerald-200 dark:shadow-none transition-all flex items-center justify-center gap-2"
              >
                <Save className="w-5 h-5" />
                <span>{isSaving ? 'Enregistrement...' : t('toolRunner.saveSession')}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
