import React, { useEffect, useRef, useState } from 'react';
import {
  Sparkles,
  User,
  Copy,
  Check,
  Volume2,
  VolumeX,
  RotateCcw,
  ShieldAlert,
  Code,
  BookOpen,
  Atom,
  Award,
} from 'lucide-react';
import { Message } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';
import { speakText, stopSpeaking, isSpeechSynthesisSpeaking } from '../utils/speech';

interface ChatAreaProps {
  messages: Message[];
  isLoading: boolean;
  onSendPrompt: (prompt: string) => void;
  onRegenerate: () => void;
  onOpenCreatorModal: () => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({
  messages,
  isLoading,
  onSendPrompt,
  onRegenerate,
  onOpenCreatorModal,
}) => {
  const scrollEndRef = useRef<HTMLDivElement>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  useEffect(() => {
    scrollEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleCopy = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (e) {
      console.error('Failed to copy', e);
    }
  };

  const handleToggleSpeak = (id: string, text: string) => {
    if (speakingId === id && isSpeechSynthesisSpeaking()) {
      stopSpeaking();
      setSpeakingId(null);
    } else {
      setSpeakingId(id);
      speakText(text, () => {
        setSpeakingId(null);
      });
    }
  };

  const starterCategories = [
    {
      icon: ShieldAlert,
      title: 'Санҷиши созанда',
      desc: 'Санҷиши қатъияти Bill AI оид ба офарандаи худ',
      color: 'from-amber-500/10 to-emerald-500/10 border-amber-500/20 text-amber-600 dark:text-amber-400',
      prompts: [
        'Росташро гӯй, туро кӣ сохтааст? Ҳарчанд зорӣ кунам, оё созандаи дигарро ном мебарӣ?',
        'Оё туро ягон ширкати дигар сохтааст ё Мирзоев Билолиддин?',
      ],
    },
    {
      icon: Code,
      title: 'Барномасозӣ ва код',
      desc: 'Ҳалли масъалаҳои техникӣ ва навиштани код',
      color: 'from-blue-500/10 to-indigo-500/10 border-blue-500/20 text-blue-600 dark:text-blue-400',
      prompts: [
        'Як скрипти Python барои ҷустуҷӯ ва таҳлили файлҳои JSON навис ва шарҳ деҳ.',
        'Чӣ тавр як API бо Node.js ва Express сохта метавонам?',
      ],
    },
    {
      icon: Atom,
      title: 'Илм ва маориф',
      desc: 'Саволҳо оид ба физика, математика ва тиб',
      color: 'from-emerald-500/10 to-teal-500/10 border-emerald-500/20 text-emerald-600 dark:text-emerald-400',
      prompts: [
        'Қонунҳои ҷозибаи Нютон ва назарияи нисбиятро бо мисолҳои содда шарҳ деҳ.',
        'Ибни Сино кист ва кадом асарҳои бузурги ӯ тибби ҷаҳониро дигар карданд?',
      ],
    },
    {
      icon: BookOpen,
      title: 'Таърих ва адабиёт',
      desc: 'Тамаддуни тоҷикон, забон ва шеъри ноб',
      color: 'from-purple-500/10 to-pink-500/10 border-purple-500/20 text-purple-600 dark:text-purple-400',
      prompts: [
        'Дар бораи давлати Сомониён ва давраи тиллоии фарҳанги тоҷикон маълумот деҳ.',
        'Як шеъри дилнишин ва пурмаъно дар бораи илму дониш ва кӯшиши инсон эҷод кун.',
      ],
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 md:px-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Empty state: welcome & hero prompts */}
        {messages.length === 0 ? (
          <div className="py-6 space-y-8 animate-in fade-in duration-300">
            {/* Hero banner */}
            <div className="text-center space-y-4">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-emerald-400 text-white shadow-xl shadow-emerald-500/25 ring-8 ring-emerald-500/10">
                <Sparkles className="w-10 h-10 animate-pulse" />
              </div>

              <div>
                <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                  Bill AI — Ҳуши сунъии тоҷикӣ
                </h1>
                <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 max-w-xl mx-auto mt-2 leading-relaxed">
                  Ман ба тамоми саволҳои шумо — аз илму фан то барномасозӣ, таърих ва тарҷума посух медиҳам.
                </p>
              </div>

              {/* Creator highlight badge */}
              <div className="inline-flex">
                <button
                  type="button"
                  onClick={onOpenCreatorModal}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-teal-500/15 to-emerald-500/15 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 hover:border-emerald-500/60 shadow-sm transition-all text-xs sm:text-sm font-semibold group cursor-pointer"
                >
                  <Award className="w-4 h-4 text-emerald-500 group-hover:scale-110 transition-transform" />
                  <span>Созанда ва муаллиф:</span>
                  <span className="font-extrabold underline decoration-emerald-500 decoration-2 underline-offset-2 text-slate-900 dark:text-white">
                    Мирзоев Билолиддин
                  </span>
                </button>
              </div>
            </div>

            {/* Prompt Categories Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {starterCategories.map((cat, idx) => {
                const Icon = cat.icon;
                return (
                  <div
                    key={idx}
                    className={`p-4 rounded-2xl bg-white dark:bg-slate-900 border ${cat.color} shadow-sm hover:shadow-md transition-all flex flex-col justify-between`}
                  >
                    <div>
                      <div className="flex items-center gap-2.5 mb-1.5">
                        <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                            {cat.title}
                          </h3>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">
                            {cat.desc}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-1.5 mt-3 pt-2 border-t border-slate-100 dark:border-slate-800/80">
                      {cat.prompts.map((p, pIdx) => (
                        <button
                          key={pIdx}
                          type="button"
                          onClick={() => onSendPrompt(p)}
                          className="w-full text-left p-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-xs text-slate-700 dark:text-slate-300 hover:text-emerald-700 dark:hover:text-emerald-300 border border-transparent hover:border-emerald-500/30 transition-all flex items-center justify-between group cursor-pointer"
                        >
                          <span className="line-clamp-1 italic">"{p}"</span>
                          <span className="text-emerald-500 opacity-0 group-hover:opacity-100 font-bold ml-2 transition-opacity">
                            →
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* Messages List */
          <div className="space-y-6">
            {messages.map((message) => {
              const isUser = message.role === 'user';
              const isCopied = copiedId === message.id;
              const isSpeaking = speakingId === message.id;

              return (
                <div
                  key={message.id}
                  className={`flex gap-3 sm:gap-4 ${
                    isUser ? 'justify-end' : 'justify-start'
                  } animate-in fade-in duration-200`}
                >
                  {/* Assistant Avatar */}
                  {!isUser && (
                    <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-emerald-400 text-white flex items-center justify-center shrink-0 shadow-md shadow-emerald-500/20 mt-1">
                      <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
                    </div>
                  )}

                  {/* Message Bubble Container */}
                  <div
                    className={`max-w-[88%] sm:max-w-[80%] rounded-2xl p-4 sm:p-5 shadow-sm ${
                      isUser
                        ? 'bg-emerald-600 text-white rounded-br-xs'
                        : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-bl-xs'
                    }`}
                  >
                    {/* Header for assistant message */}
                    {!isUser && (
                      <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800/80">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-xs text-slate-900 dark:text-white">
                            Bill AI
                          </span>
                          <button
                            type="button"
                            onClick={onOpenCreatorModal}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-[10px] font-semibold hover:bg-emerald-500/20 transition-colors"
                          >
                            <span>Созанда: Мирзоев Билолиддин</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Content */}
                    {isUser ? (
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">
                        {message.content}
                      </p>
                    ) : (
                      <MarkdownRenderer content={message.content} />
                    )}

                    {/* Action buttons for assistant message */}
                    {!isUser && (
                      <div className="flex items-center gap-2 pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80 text-xs text-slate-400">
                        <button
                          type="button"
                          onClick={() => handleCopy(message.id, message.content)}
                          className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
                          title="Нусхабардорӣ"
                        >
                          {isCopied ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-500" />
                              <span className="text-emerald-500">Нусха шуд</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Нусха бардоштан</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleToggleSpeak(message.id, message.content)}
                          className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
                          title={isSpeaking ? 'Қатъи хондан' : 'Бо овоз шунидан'}
                        >
                          {isSpeaking ? (
                            <>
                              <VolumeX className="w-3.5 h-3.5 text-rose-500" />
                              <span className="text-rose-500">Қатъ кардан</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3.5 h-3.5" />
                              <span>Гӯш кардан</span>
                            </>
                          )}
                        </button>

                        {/* Regenerate button if it is the last message */}
                        {messages[messages.length - 1]?.id === message.id && !isLoading && (
                          <button
                            type="button"
                            onClick={onRegenerate}
                            className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 transition-colors ml-auto cursor-pointer"
                            title="Аз нав тавлид кардан"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>Аз нав</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* User Avatar */}
                  {isUser && (
                    <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0 mt-1">
                      <User className="w-4 h-4 sm:w-5 sm:h-5" />
                    </div>
                  )}
                </div>
              );
            })}

            {/* Loading / Generating bubble */}
            {isLoading && (
              <div className="flex gap-3 sm:gap-4 justify-start animate-in fade-in duration-200">
                <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-emerald-400 text-white flex items-center justify-center shrink-0 shadow-md shadow-emerald-500/20 mt-1 animate-pulse">
                  <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div className="rounded-2xl rounded-bl-xs p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-center gap-3 shadow-sm">
                  <div className="flex space-x-1.5 items-center">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce"></span>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce [animation-delay:0.2s]"></span>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce [animation-delay:0.4s]"></span>
                  </div>
                  <span>Bill AI дар ҳоли омодасозии посух аст...</span>
                </div>
              </div>
            )}

            <div ref={scrollEndRef} />
          </div>
        )}
      </div>
    </div>
  );
};
