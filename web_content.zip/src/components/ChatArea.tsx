import React, { useState, useRef, useEffect } from 'react';
import {
  Menu,
  Sparkles,
  Copy,
  Check,
  Volume2,
  VolumeX,
  Trash2,
  FileSpreadsheet,
  FileText,
  Loader2,
  RotateCw,
  Plus,
  PanelLeft,
  ChevronDown,
  ArrowDown,
  ExternalLink,
  Code2,
  PenTool,
  Image as ImageIcon,
  BarChart3,
  Bot
} from 'lucide-react';
import { Message, Attachment } from '../types/chat';
import { UserSettings } from '../types/auth';
import { globalSpeechPlayer } from '../lib/speechPlayer';
import { MarkdownRenderer } from './MarkdownRenderer';
import { detectTextDirection } from '../lib/textDirection';

interface ChatAreaProps {
  messages: Message[];
  isLoading: boolean;
  streamingMessage: string;
  isLight?: boolean;
  userSettings?: UserSettings;
  onDeleteMessage: (messageId: string) => void;
  onClearChat: () => void;
  onNewChat: () => void;
  onSelectPrompt?: (prompt: string) => void;
  onOpenSidebar: () => void;
  isSidebarOpen?: boolean;
  onViewAttachment: (att: Attachment) => void;
  currentTitle: string;
  onRegenerate?: (messageId?: string) => void;
  onOpenVoiceModal?: () => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({
  messages,
  isLoading,
  streamingMessage,
  isLight = false,
  userSettings,
  onDeleteMessage,
  onClearChat,
  onNewChat,
  onSelectPrompt,
  onOpenSidebar,
  isSidebarOpen = false,
  onViewAttachment,
  currentTitle,
  onRegenerate,
  onOpenVoiceModal,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [loadingAudioId, setLoadingAudioId] = useState<string | null>(null);
  const [confirmDeleteMsgId, setConfirmDeleteMsgId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [isAtBottom, setIsAtBottom] = useState(true);
  const userScrolledUpRef = useRef(false);
  const prevMessagesCountRef = useRef(messages.length);

  // Track user manual scrolling: if scrolled up, don't interrupt reading
  const handleScroll = () => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const { scrollTop, scrollHeight, clientHeight } = container;
    const distanceFromBottom = scrollHeight - (scrollTop + clientHeight);

    // If within 80px from bottom, consider at bottom
    const atBottom = distanceFromBottom < 80;
    setIsAtBottom(atBottom);
    userScrolledUpRef.current = !atBottom;
  };

  const scrollToBottom = (smooth = true) => {
    userScrolledUpRef.current = false;
    setIsAtBottom(true);
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
  };

  // When user sends a new message or chat opens, scroll to bottom
  useEffect(() => {
    if (messages.length > prevMessagesCountRef.current) {
      userScrolledUpRef.current = false;
      setIsAtBottom(true);
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
    prevMessagesCountRef.current = messages.length;
  }, [messages]);

  // When loading starts, jump to bottom
  useEffect(() => {
    if (isLoading && !streamingMessage) {
      userScrolledUpRef.current = false;
      setIsAtBottom(true);
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isLoading]);

  // While AI is actively streaming text:
  // If the user has scrolled up to read previous text, DO NOT force scroll down!
  // If they are at the bottom, auto-scroll to keep up with generation.
  useEffect(() => {
    if (!streamingMessage) return;

    if (!userScrolledUpRef.current) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [streamingMessage]);

  useEffect(() => {
    return () => {
      globalSpeechPlayer.stop();
    };
  }, []);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handlePlayTTS = (id: string, text: string) => {
    if (playingAudioId === id || loadingAudioId === id) {
      globalSpeechPlayer.stop();
      setPlayingAudioId(null);
      setLoadingAudioId(null);
      return;
    }

    globalSpeechPlayer.stop();
    setPlayingAudioId(null);
    setLoadingAudioId(id);

    const voice = userSettings?.voiceName || 'Aoede';
    const speed = userSettings?.voiceSpeed || 1.0;

    globalSpeechPlayer.play(id, text, {
      voice,
      speed,
      onStart: () => {
        setLoadingAudioId(null);
        setPlayingAudioId(id);
      },
      onEnded: () => {
        setPlayingAudioId(null);
        setLoadingAudioId(null);
      },
      onError: (err) => {
        console.warn('TTS playback notification:', err?.message || err);
        setPlayingAudioId(null);
        setLoadingAudioId(null);
      },
    });
  };

  const handleDeleteMsg = (id: string) => {
    if (userSettings?.confirmBeforeDelete) {
      if (confirmDeleteMsgId === id) {
        onDeleteMessage(id);
        setConfirmDeleteMsgId(null);
      } else {
        setConfirmDeleteMsgId(id);
        setTimeout(() => setConfirmDeleteMsgId((prev) => (prev === id ? null : prev)), 3500);
      }
    } else {
      onDeleteMessage(id);
    }
  };

  return (
    <div
      className={`flex-1 flex flex-col h-full overflow-hidden relative ${
        isLight ? 'bg-white text-[#202123]' : 'bg-[#171717] text-[#ececec]'
      }`}
    >
      {/* ChatGPT Modern Top Header */}
      <header
        className={`h-13 px-4 flex items-center justify-between border-b shrink-0 z-20 ${
          isLight
            ? 'bg-white/95 border-[#e5e5e5] backdrop-blur-xs'
            : 'bg-[#171717]/95 border-[#262626] backdrop-blur-xs'
        }`}
      >
        {/* Right side in RTL: Sidebar toggle + Model label */}
        <div className="flex items-center gap-2">
          {!isSidebarOpen && (
            <button
              onClick={onOpenSidebar}
              className={`p-2 rounded-xl transition-all ${
                isLight
                  ? 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100'
                  : 'text-neutral-400 hover:text-white hover:bg-[#262626]'
              }`}
              title="فتح الشريط الجانبي"
            >
              <PanelLeft className="w-4 h-4 rotate-180" />
            </button>
          )}

          {/* Model Badge */}
          <div
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-medium cursor-default transition-colors ${
              isLight
                ? 'bg-neutral-100 text-[#202123] hover:bg-neutral-200/60'
                : 'bg-[#262626] text-neutral-200 hover:bg-[#303030]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-neutral-600 dark:text-neutral-300" />
            <span>Onyx Mind</span>
            <span className={`text-[10px] px-1 py-0.2 rounded font-mono ${
              isLight ? 'bg-neutral-200/70 text-neutral-700' : 'bg-neutral-700/60 text-neutral-300'
            }`}>
              3.8 Flash
            </span>
          </div>

          <h2 className={`text-xs sm:text-sm font-medium truncate max-w-[160px] sm:max-w-[280px] hidden md:block ${
            isLight ? 'text-neutral-500' : 'text-neutral-400'
          }`}>
            {currentTitle || 'محادثة جديدة'}
          </h2>
        </div>

        {/* Left side in RTL: New chat button + Voice chat shortcut */}
        <div className="flex items-center gap-1.5">
          {onOpenVoiceModal && (
            <button
              onClick={onOpenVoiceModal}
              className={`p-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all ${
                isLight
                  ? 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                  : 'text-neutral-300 hover:text-white hover:bg-[#262626]'
              }`}
              title="محادثة صوتية مباشرة"
            >
              <Volume2 className="w-4 h-4" />
              <span className="hidden sm:inline">صوتي</span>
            </button>
          )}

          <button
            onClick={onNewChat}
            className={`p-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all ${
              isLight
                ? 'bg-neutral-100 hover:bg-neutral-200 text-[#202123]'
                : 'bg-[#262626] hover:bg-[#303030] text-neutral-100'
            }`}
            title="محادثة جديدة"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">جديدة</span>
          </button>
        </div>
      </header>

      {/* Messages Scroll Area with smart scroll listener */}
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 relative"
      >
        {/* Clean Empty State View without options cards */}
        {messages.length === 0 && !streamingMessage && (
          <div className="h-full flex flex-col items-center justify-center max-w-xl mx-auto py-16 px-4 text-center animate-in fade-in duration-300">
            <div className={`w-13 h-13 rounded-2xl flex items-center justify-center mb-4 border ${
              isLight
                ? 'bg-[#F7F7F8] border-[#e5e5e5] text-neutral-800 shadow-2xs'
                : 'bg-[#262626] border-[#383838] text-neutral-200'
            }`}>
              <Sparkles className="w-6 h-6" />
            </div>

            <h1 className={`text-xl sm:text-2xl font-semibold mb-2 tracking-tight ${
              isLight ? 'text-[#202123]' : 'text-[#f3f3f3]'
            }`}>
              ما الذي يمكنني مساعدتك به اليوم؟
            </h1>
            <p className={`text-xs sm:text-sm max-w-md leading-relaxed ${
              isLight ? 'text-neutral-500' : 'text-neutral-400'
            }`}>
              مساعدك الذكي الشامل — اسأل عن أي موضوع، استفسر عن أحدث الأخبار والمعلومات عبر بحث Google التلقائي، حلل الملفات والبيانات، أو اكتب الأكواد.
            </p>
          </div>
        )}

        {/* Message Items */}
        {messages.map((message, index) => {
          const isUser = message.role === 'user';
          const direction = detectTextDirection(message.content);
          const isLastAssistantMessage = !isUser && index === messages.length - 1;

          return (
            <div
              key={message.id}
              className={`max-w-3xl mx-auto flex flex-col group ${
                isUser ? 'items-end' : 'items-start'
              }`}
            >
              {/* Attachments preview chips */}
              {message.attachments && message.attachments.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-2 max-w-[90%]">
                  {message.attachments.map((att) => (
                    <div
                      key={att.id}
                      onClick={() => onViewAttachment(att)}
                      className={`cursor-pointer p-2 rounded-xl flex items-center gap-2 text-xs transition-colors border shadow-2xs ${
                        isLight
                          ? 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-800'
                          : 'bg-[#2a2a2a] hover:bg-[#333333] border-[#383838] text-neutral-200'
                      }`}
                    >
                      {att.type === 'image' && att.dataUrl ? (
                        <img src={att.dataUrl} alt="" className="w-8 h-8 rounded-lg object-cover" />
                      ) : att.type === 'excel' || att.type === 'csv' ? (
                        <FileSpreadsheet className="w-4 h-4 text-emerald-500 shrink-0" />
                      ) : (
                        <FileText className={`w-4 h-4 ${isLight ? 'text-slate-500' : 'text-neutral-400'} shrink-0`} />
                      )}
                      <div className="truncate max-w-[130px]">
                        <span className="font-semibold block truncate">{att.name}</span>
                        {att.sheetData && (
                          <span className="text-[10px] text-emerald-500">{att.sheetData.totalRows} صفوف</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Message Row */}
              <div
                className={`flex gap-3 w-full ${
                  isUser ? 'justify-end' : 'justify-start'
                }`}
              >
                {/* Assistant Avatar in ChatGPT style */}
                {!isUser && (
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 border ${
                    isLight
                      ? 'bg-neutral-100 border-[#e5e5e5] text-neutral-800 shadow-2xs'
                      : 'bg-[#262626] border-[#383838] text-neutral-200 shadow-xs'
                  }`}>
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                )}

                {/* Message Content Bubble */}
                <div
                  dir={direction}
                  className={`rounded-2xl text-sm sm:text-[15px] leading-relaxed transition-all ${
                    isUser
                      ? isLight
                        ? 'bg-[#f4f4f4] text-[#202123] px-4 py-2.5 max-w-[85%] rounded-2xl border border-[#e5e5e5]/80 shadow-2xs'
                        : 'bg-[#2f2f2f] text-[#ececec] px-4 py-2.5 max-w-[85%] rounded-2xl border border-[#383838] shadow-xs'
                      : 'flex-1 min-w-0 py-0.5 px-1 text-inherit'
                  } ${direction === 'rtl' ? 'text-right' : 'text-left'}`}
                >
                  {isUser ? (
                    <div className="whitespace-pre-wrap select-text leading-relaxed">
                      {message.content}
                    </div>
                  ) : (
                    <div className="w-full">
                      <MarkdownRenderer content={message.content} isLight={isLight} />

                      {/* Web grounding citations if available */}
                      {message.groundingSources && message.groundingSources.length > 0 && (
                        <div className="mt-3 pt-2.5 border-t border-neutral-500/20 text-xs">
                          <span className="font-semibold text-neutral-400 block mb-1.5">المصادر المرجعية:</span>
                          <div className="flex flex-wrap gap-2">
                            {message.groundingSources.map((source: any, sIdx: number) => (
                              <a
                                key={sIdx}
                                href={source.url}
                                target="_blank"
                                rel="noreferrer"
                                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] border transition-colors ${
                                  isLight
                                    ? 'bg-[#F7F7F8] hover:bg-neutral-100 border-[#e5e5e5] text-neutral-800'
                                    : 'bg-[#2a2a2a] hover:bg-[#333333] border-[#383838] text-neutral-200'
                                }`}
                              >
                                <ExternalLink className="w-3 h-3 text-neutral-400" />
                                <span className="truncate max-w-[150px]">{source.title || source.url}</span>
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Action Bar under Assistant response: TTS, Copy, Regenerate, Delete */}
              {!isUser && (
                <div
                  className={`flex items-center gap-1 mt-2 mr-10 ${
                    isLight ? 'text-neutral-400' : 'text-neutral-400'
                  } opacity-80 group-hover:opacity-100 transition-opacity`}
                  dir="rtl"
                >
                  {/* TTS Voice play button */}
                  <button
                    onClick={() => handlePlayTTS(message.id, message.content)}
                    disabled={loadingAudioId === message.id}
                    className={`p-1.5 rounded-lg transition-colors ${
                      isLight
                        ? 'hover:text-neutral-900 hover:bg-neutral-100'
                        : 'hover:text-white hover:bg-[#262626]'
                    }`}
                    title={playingAudioId === message.id ? 'إيقاف الصوت' : 'استماع صوتي للإجابة'}
                  >
                    {loadingAudioId === message.id ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-500" />
                    ) : playingAudioId === message.id ? (
                      <VolumeX className="w-3.5 h-3.5 text-rose-500" />
                    ) : (
                      <Volume2 className="w-3.5 h-3.5" />
                    )}
                  </button>

                  {/* Copy button */}
                  <button
                    onClick={() => handleCopy(message.id, message.content)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      isLight
                        ? 'hover:text-slate-900 hover:bg-slate-100'
                        : 'hover:text-white hover:bg-[#2f2f2f]'
                    }`}
                    title="نسخ النص"
                  >
                    {copiedId === message.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  {/* Regenerate button */}
                  {onRegenerate && (
                    <button
                      onClick={() => onRegenerate(message.id)}
                      disabled={isLoading}
                      className={`p-1.5 rounded-lg transition-colors ${
                        isLight
                          ? 'hover:text-slate-900 hover:bg-slate-100'
                          : 'hover:text-white hover:bg-[#2f2f2f]'
                      }`}
                      title="إعادة التوليد (Regenerate)"
                    >
                      <RotateCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                    </button>
                  )}

                  {/* Delete message button */}
                  <button
                    onClick={() => handleDeleteMsg(message.id)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      isLight
                        ? 'hover:text-rose-600 hover:bg-rose-50'
                        : 'hover:text-rose-400 hover:bg-rose-950/20'
                    }`}
                    title="حذف الرسالة"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                  {confirmDeleteMsgId === message.id && (
                    <span className="text-[11px] text-rose-500 mr-1 animate-in fade-in">
                      انقر مرة أخرى للتأكيد
                    </span>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {/* Live Streaming Response Block */}
        {streamingMessage && (
          <div className="max-w-3xl mx-auto flex items-start gap-3 w-full">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 border ${
              isLight
                ? 'bg-neutral-100 border-[#e5e5e5] text-neutral-800 shadow-2xs'
                : 'bg-[#262626] border-[#383838] text-neutral-200 shadow-xs'
            }`}>
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
            </div>

            <div
              dir={detectTextDirection(streamingMessage)}
              className={`flex-1 py-0.5 px-1 text-sm sm:text-[15px] leading-relaxed ${
                detectTextDirection(streamingMessage) === 'rtl' ? 'text-right' : 'text-left'
              }`}
            >
              <MarkdownRenderer content={streamingMessage} isLight={isLight} />
              <span className="inline-block w-2 h-4 bg-neutral-900 dark:bg-white animate-pulse ml-1 align-middle rounded-xs" />
            </div>
          </div>
        )}

        {/* Loading Spinner before first streaming chunk arrives */}
        {isLoading && !streamingMessage && (
          <div className="max-w-3xl mx-auto flex items-center gap-3 py-2">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 border ${
              isLight
                ? 'bg-neutral-100 border-[#e5e5e5] text-neutral-800'
                : 'bg-[#262626] border-[#383838] text-neutral-200'
            }`}>
              <Sparkles className="w-3.5 h-3.5 animate-spin" />
            </div>
            <div className={`flex items-center gap-2 text-xs ${isLight ? 'text-neutral-500' : 'text-neutral-400'}`}>
              <div className="w-2 h-2 rounded-full bg-neutral-800 dark:bg-neutral-200 animate-ping" />
              <span>Onyx AI يحلل ويكتب الرد...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Floating Scroll to Bottom Arrow Button (pure icon without any words) */}
      {!isAtBottom && (
        <button
          type="button"
          onClick={() => scrollToBottom(true)}
          aria-label="الانتقال إلى أسفل المحادثة"
          className={`absolute bottom-4 left-1/2 -translate-x-1/2 z-30 w-9 h-9 rounded-full flex items-center justify-center transition-all duration-200 shadow-lg border active:scale-95 cursor-pointer group animate-in fade-in zoom-in-95 ${
            isLight
              ? 'bg-white hover:bg-neutral-50 text-neutral-700 border-neutral-300 shadow-neutral-400/30'
              : 'bg-[#222222] hover:bg-[#2c2c2c] text-neutral-100 border-neutral-700 shadow-black/60'
          }`}
          title="الانتقال إلى أسفل المحادثة"
        >
          <ArrowDown className="w-4 h-4 stroke-[2.3] group-hover:translate-y-0.5 transition-transform" />

          {/* Live pulsing dot when AI is actively writing/streaming down below */}
          {(isLoading || !!streamingMessage) && (
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-blue-500" />
            </span>
          )}
        </button>
      )}
    </div>
  );
};
