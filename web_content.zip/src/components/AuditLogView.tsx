import React, { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AuditLogView: React.FC = () => {
  const { snapshot } = useApp();
  const [query, setQuery] = useState('');
  const [actionFilter, setActionFilter] = useState('all');

  const actions = useMemo(
    () => Array.from(new Set(snapshot.auditLogs.map((l) => l.action))),
    [snapshot.auditLogs]
  );

  const logs = useMemo(() => {
    return snapshot.auditLogs.filter((l) => {
      if (actionFilter !== 'all' && l.action !== actionFilter) return false;
      if (query.trim()) {
        const q = query.toLowerCase();
        return (
          l.summary.toLowerCase().includes(q) ||
          l.entityType.toLowerCase().includes(q) ||
          l.action.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [snapshot.auditLogs, query, actionFilter]);

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-slate-200 bg-white p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" aria-hidden="true" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search audit history..."
            aria-label="Search audit history"
            className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300"
          />
        </div>
        <select
          aria-label="Filter by activity type"
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          className="px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
        >
          <option value="all">All Activities</option>
          {actions.map((act) => (
            <option key={act} value={act}>
              {act.replace(/_/g, ' ')}
            </option>
          ))}
        </select>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        {logs.length === 0 ? (
          <div className="p-10 text-center text-sm text-slate-500">No audit entries found.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4">Date &amp; Time</th>
                  <th className="py-3 px-4">Activity</th>
                  <th className="py-3 px-4">Entity</th>
                  <th className="py-3 px-4">Summary</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono-num text-xs text-slate-500 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-xs font-semibold text-slate-800 whitespace-nowrap">
                      {log.action.replace(/_/g, ' ')}
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-500">{log.entityType}</td>
                    <td className="py-3 px-4 text-slate-800">{log.summary}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
