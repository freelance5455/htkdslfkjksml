import { useState } from "react";
import { useApp } from "@/lib/store";
import { buildAimModel, ffValues, fmt } from "@/lib/sensitivity";
import { Btn, Card, Segmented, Slider, Stat, Toggle } from "./UI";

export default function SensitivityPanel() {
  const { settings, set, resetSettings, applyProfile, profiles } = useApp();
  const model = buildAimModel(settings);
  const ff = ffValues(settings);
  const [copied, setCopied] = useState(false);

  return (
    <div className="space-y-4">
      <Card
        title="Sensibilidade do Touch"
        icon="🎯"
        desc="Define quanto a câmera gira quando você arrasta o dedo na tela."
      >
        <div className="space-y-4">
          <Slider
            label="Sensibilidade horizontal"
            value={settings.sensHorizontal}
            min={0}
            max={300}
            onChange={(v) => set("sensHorizontal", v)}
            accent="lime"
            hint="Controla o giro da câmera para os lados (mirar na horizontal)."
          />
          <Slider
            label="Sensibilidade vertical"
            value={settings.sensVertical}
            min={0}
            max={300}
            onChange={(v) => set("sensVertical", v)}
            accent="cyan"
            hint="Controla a subida e descida da mira (olhar para cima/baixo)."
          />
          <Slider
            label="Ganho do arraste (modificador de touch)"
            value={settings.dragGain}
            min={30}
            max={200}
            onChange={(v) => set("dragGain", v)}
            accent="amber"
            hint="Multiplica a resposta do dedo. Acima de 100% gira mais rápido."
          />
          <Toggle
            icon="🔃"
            label="Inverter eixo vertical"
            desc="Arrastar para cima passa a olhar para baixo."
            checked={settings.invertY}
            onChange={(v) => set("invertY", v)}
          />
        </div>
      </Card>

      <Card
        title="Leitura ao vivo"
        icon="📐"
        desc="Como o seu dedo vira rotação de câmera no simulador."
        action={
          <span className="rounded-full bg-lime-400/15 px-2 py-1 font-mono text-[11px] text-lime-300">
            tempo real
          </span>
        }
      >
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <Stat label="Graus / 100px (H)" value={`${fmt(model.degPer100px, 1)}°`} tone="lime" />
          <Stat label="Graus / 100px (V)" value={`${fmt(model.degPerPxY * 100, 1)}°`} tone="cyan" />
          <Stat label="Px para 360°" value={isFinite(model.pxFor360) ? `${Math.round(model.pxFor360)}` : "—"} />
          <Stat label="Ganho efetivo" value={`${fmt(model.effectiveGain * 100, 0)}%`} tone="amber" />
        </div>

        <div className="mt-3 rounded-2xl border border-white/10 bg-black/25 p-3">
          <div className="mb-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Simulação de arraste</span>
            <span className="font-mono text-slate-300">dedo → câmera</span>
          </div>
          {[
            { px: 50, label: "Toque curto (50px)" },
            { px: 150, label: "Arraste médio (150px)" },
            { px: 300, label: "Arraste longo (300px)" },
          ].map((row) => (
            <div key={row.px} className="mb-1.5 flex items-center gap-2">
              <span className="w-[115px] shrink-0 text-[11px] text-slate-500">{row.label}</span>
              <div className="relative h-2 flex-1 overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-lime-300 to-emerald-400"
                  style={{ width: `${Math.min(100, (model.degPerPxX * row.px * 180) / 360)}%` }}
                />
              </div>
              <span className="w-12 shrink-0 text-right font-mono text-[11px] text-lime-300">
                {fmt(model.degPerPxX * row.px, 1)}°
              </span>
            </div>
          ))}
          <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
            Regra prática: se no jogo a câmera “pula” demais, baixe a horizontal em 5% por vez. Se
            fica “travada”, suba 5%.
          </p>
        </div>
      </Card>

      <Card
        title="Modificador de touch"
        icon="🛠️"
        desc="Desloca, suaviza e filtra o seu toque antes de virar mira — é o coração do GG Mouse."
      >
        <div className="space-y-4">
          <Slider
            label="Offset horizontal do toque"
            value={settings.touchOffsetX}
            min={0}
            max={30}
            suffix=" px"
            onChange={(v) => set("touchOffsetX", v)}
            accent="rose"
            hint="Pixels ignorados no início do arraste horizontal. Ajuda a mirar sem tremer."
          />
          <Slider
            label="Offset vertical do toque"
            value={settings.touchOffsetY}
            min={0}
            max={30}
            suffix=" px"
            onChange={(v) => set("touchOffsetY", v)}
            accent="rose"
            hint="Mesmo efeito no eixo vertical (mira para cima/baixo)."
          />
          <Slider
            label="Suavização do toque"
            value={settings.smoothing}
            min={0}
            max={100}
            onChange={(v) => set("smoothing", v)}
            accent="cyan"
            hint="0 = resposta crua (rápida). 100 = toque muito macio, sem tremor."
          />
          <Slider
            label="Zona morta"
            value={settings.deadZone}
            min={0}
            max={20}
            step={1}
            suffix=" px"
            onChange={(v) => set("deadZone", v)}
            accent="amber"
            hint="Pixels de movimento ignorados antes da câmera reagir."
          />
          <Slider
            label="Curva de resposta"
            value={settings.curve}
            min={0.5}
            max={2}
            step={0.05}
            suffix="x"
            format={(v) => fmt(v, 2)}
            onChange={(v) => set("curve", v)}
            accent="rose"
            hint="Acima de 1.0: começa devagar (precisão). Abaixo de 1.0: responde na hora (agilidade)."
          />
          <Slider
            label="Velocidade de movimento"
            value={settings.moveSpeed}
            min={30}
            max={200}
            onChange={(v) => set("moveSpeed", v)}
            accent="lime"
            hint="Velocidade do personagem ao usar o joystick virtual."
          />
          <Slider
            label="Sensibilidade na mira (ADS)"
            value={settings.adsMultiplier}
            min={20}
            max={150}
            onChange={(v) => set("adsMultiplier", v)}
            accent="cyan"
            hint="Multiplica a sensibilidade quando a arma está na luneta."
          />
        </div>
      </Card>

      <Card
        title="Sensibilidade por mira"
        icon="🔭"
        desc="Multiplicadores usados para calcular o valor de cada lente do Free Fire."
      >
        <div className="space-y-4">
          <Slider
            label="Ponto vermelho (Red Dot)"
            value={settings.adsRedDot}
            min={20}
            max={150}
            onChange={(v) => set("adsRedDot", v)}
            accent="cyan"
          />
          <Slider
            label="Mira 2x"
            value={settings.ads2x}
            min={10}
            max={150}
            onChange={(v) => set("ads2x", v)}
            accent="cyan"
          />
          <Slider
            label="Mira 4x"
            value={settings.ads4x}
            min={10}
            max={150}
            onChange={(v) => set("ads4x", v)}
            accent="amber"
          />
          <Slider
            label="Mira AWM / Sniper"
            value={settings.adsAwp}
            min={5}
            max={120}
            onChange={(v) => set("adsAwp", v)}
            accent="rose"
          />
          <Slider
            label="Olhadinha (Free Look)"
            value={settings.freeLook}
            min={20}
            max={150}
            onChange={(v) => set("freeLook", v)}
            accent="lime"
          />
        </div>
      </Card>

      <Card
        title="Valores para colar no Free Fire"
        icon="📋"
        desc="Configurações › Sensibilidade: copie estes números para o jogo."
        action={
          <div className="w-40">
            <Segmented
              options={[
                { value: "100", label: "Escala 0-100" },
                { value: "200", label: "Escala 0-200" },
              ]}
              value={String(settings.gameScale)}
              onChange={(v) => set("gameScale", Number(v) as 100 | 200)}
            />
          </div>
        }
      >
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {[
            { k: "Geral · Vertical", v: ff.geralVertical },
            { k: "Geral · Horizontal", v: ff.geralHorizontal },
            { k: "Ponto vermelho", v: ff.pontoVermelho },
            { k: "Mira 2x", v: ff.mira2x },
            { k: "Mira 4x", v: ff.mira4x },
            { k: "Mira AWM", v: ff.miraAwp },
            { k: "Olhadinha", v: ff.olhadinha },
          ].map((row) => (
            <div
              key={row.k}
              className="flex items-center justify-between gap-2 rounded-2xl border border-white/10 bg-black/25 px-3 py-2"
            >
              <span className="text-[11px] text-slate-400">{row.k}</span>
              <span className="font-mono text-sm font-bold text-lime-300">{row.v}</span>
            </div>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <Btn
            variant="primary"
            onClick={async () => {
              const text = [
                `Geral Vertical: ${ff.geralVertical}`,
                `Geral Horizontal: ${ff.geralHorizontal}`,
                `Ponto Vermelho: ${ff.pontoVermelho}`,
                `Mira 2x: ${ff.mira2x}`,
                `Mira 4x: ${ff.mira4x}`,
                `Mira AWM: ${ff.miraAwp}`,
                `Olhadinha: ${ff.olhadinha}`,
              ].join("\n");
              try {
                await navigator.clipboard.writeText(text);
                setCopied(true);
                setTimeout(() => setCopied(false), 1800);
              } catch {
                setCopied(false);
              }
            }}
          >
            {copied ? "✔ Copiado!" : "Copiar valores"}
          </Btn>
          <span className="text-[11px] text-slate-500">
            A escala 0-200 é a usada nas versões mais recentes do Free Fire.
          </span>
        </div>
      </Card>

      <Card title="Presets rápidos" icon="⚡" desc="Aplique um perfil e ajuste fino em cima dele.">
        <div className="flex flex-wrap gap-2">
          {profiles
            .filter((p) => p.builtin)
            .map((p) => (
              <Btn key={p.id} onClick={() => applyProfile(p.id)}>
                {p.name}
              </Btn>
            ))}
          <Btn variant="danger" onClick={resetSettings}>
            Restaurar padrão
          </Btn>
        </div>
      </Card>
    </div>
  );
}
