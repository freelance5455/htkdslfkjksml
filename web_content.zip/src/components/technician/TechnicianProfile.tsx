import React, { useEffect, useState } from 'react';
import {
  User,
  Phone,
  Mail,
  MapPin,
  Shield,
  Award as AwardIcon,
  AlertCircle,
  LogOut,
  Camera,
  Edit3,
  CheckCircle2,
  Building2,
  ArrowRight,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { Award, Employee } from '../../types/index.ts';
import { UserProfileModal } from '../common/UserProfileModal.tsx';
import { EmployeeTimelineModal } from '../admin/EmployeeTimelineModal.tsx';
import { CompanyJoinModal } from './CompanyJoinModal.tsx';
import { Activity } from 'lucide-react';

export const TechnicianProfile: React.FC = () => {
  const { currentEmployee, userProfile, currentOrg, signOutUser } = useAuth();
  const [awards, setAwards] = useState<Award[]>([]);
  const [loading, setLoading] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isTimelineOpen, setIsTimelineOpen] = useState(false);
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);

  const emp = currentEmployee || {
    id: userProfile?.employeeId || userProfile?.id || 'pending_tech',
    name: userProfile?.displayName || userProfile?.email?.split('@')[0] || 'Field Technician',
    email: userProfile?.email || '',
    employeeCode: 'PENDING',
    phone: userProfile?.phone || 'Not configured',
    department: 'Field Operations',
    designation: 'Technician',
    territory: 'Primary Territory',
    managerName: 'Operations Lead',
    emergencyContact: 'Main Office',
    status: 'active' as const,
    joiningDate: userProfile?.createdAt ? userProfile.createdAt.split('T')[0] : new Date().toISOString().split('T')[0],
    orgId: currentOrg?.id || '',
    avatarUrl: userProfile?.avatarUrl || '',
    createdAt: userProfile?.createdAt || new Date().toISOString(),
  };

  const displayAvatar = userProfile?.avatarUrl || currentEmployee?.avatarUrl || '';

  useEffect(() => {
    if (!currentOrg) return;
    const fetchAwards = async () => {
      setLoading(true);
      try {
        const q = query(
          collection(db, 'awards'),
          where('orgId', '==', currentOrg.id),
          where('employeeId', '==', emp.id)
        );
        const snap = await getDocs(q);
        const list: Award[] = [];
        snap.forEach((d) => list.push(d.data() as Award));
        setAwards(list);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchAwards();
  }, [currentOrg, emp.id]);

  const triggerConfetti = () => {
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  return (
    <div className="space-y-4">
      {/* Profile Card */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs text-center relative overflow-hidden">
        <div className="relative inline-block mx-auto mb-3 group">
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-sky-600 to-indigo-600 text-white font-black text-3xl flex items-center justify-center border-4 border-white shadow-md mx-auto overflow-hidden">
            {displayAvatar ? (
              <img src={displayAvatar} alt={emp.name} className="w-full h-full object-cover" />
            ) : (
              emp.name.charAt(0)
            )}
          </div>
          <span className="absolute bottom-1 right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full"></span>
          <button
            onClick={() => setIsEditModalOpen(true)}
            className="absolute bottom-0 left-0 p-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-full border-2 border-white shadow-md transition-all active:scale-95"
            title="Edit Profile & Photo"
          >
            <Camera className="w-3.5 h-3.5" />
          </button>
        </div>

        <h2 className="text-lg font-bold text-slate-900">{emp.name}</h2>
        <p className="text-xs font-semibold text-sky-600 mt-0.5">{emp.designation}</p>
        <p className="text-xs text-slate-500">{emp.department} · {currentOrg?.name}</p>

        <div className="mt-3 flex items-center justify-center gap-2">
          <span className="px-3 py-1 bg-slate-100 rounded-full text-xs font-bold text-slate-700 font-mono">
            ID: {emp.employeeCode}
          </span>
          <button
            onClick={() => setIsEditModalOpen(true)}
            className="px-3 py-1 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-full text-xs font-bold flex items-center gap-1 transition-colors"
          >
            <Edit3 className="w-3 h-3" />
            <span>Edit Profile & DP</span>
          </button>
        </div>
      </div>

      {/* Details List */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3 text-xs">
        <h3 className="font-bold text-sm text-slate-900 mb-1">Field Assignment</h3>

        <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
          <span className="text-slate-500 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-slate-400" />
            <span>Assigned Territory</span>
          </span>
          <span className="font-bold text-slate-800">{emp.territory || 'Central'}</span>
        </div>

        <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
          <span className="text-slate-500 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span>Direct Manager</span>
          </span>
          <span className="font-bold text-slate-800">{emp.managerName || 'Operations Lead'}</span>
        </div>

        <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
          <span className="text-slate-500 flex items-center gap-1.5">
            <Mail className="w-3.5 h-3.5 text-slate-400" />
            <span>Email</span>
          </span>
          <span className="font-bold text-slate-800">{emp.email}</span>
        </div>

        <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
          <span className="text-slate-500 flex items-center gap-1.5">
            <Phone className="w-3.5 h-3.5 text-slate-400" />
            <span>Mobile Phone</span>
          </span>
          <span className="font-bold text-slate-800">{userProfile?.phone || emp.phone || 'N/A'}</span>
        </div>

        <div className="flex items-center justify-between py-1.5">
          <span className="text-slate-500 flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-slate-400" />
            <span>Emergency Contact</span>
          </span>
          <span className="font-bold text-slate-800">{emp.emergencyContact || 'Operations Desk'}</span>
        </div>
      </div>

      {/* Awards & Honors */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <AwardIcon className="w-4 h-4 text-amber-500" />
            <h3 className="font-bold text-sm text-slate-900">Awards & Recognition</h3>
          </div>
          {awards.length > 0 && (
            <button
              onClick={triggerConfetti}
              className="text-[11px] font-bold text-amber-600 hover:text-amber-800"
            >
              🎉 Celebrate
            </button>
          )}
        </div>

        {awards.length === 0 ? (
          <div className="text-center py-4 text-xs text-slate-400">
            No recognition awards logged yet.
          </div>
        ) : (
          <div className="space-y-2">
            {awards.map((a) => (
              <div
                key={a.id}
                onClick={triggerConfetti}
                className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-xs space-y-1 cursor-pointer hover:bg-amber-100/60 transition-colors"
              >
                <div className="flex items-center justify-between font-bold text-amber-900">
                  <span>🏆 {a.title}</span>
                  <span className="text-[10px] text-amber-700">{a.period}</span>
                </div>
                <p className="text-amber-800 text-[11px] leading-relaxed">"{a.reason}"</p>
                <div className="text-[10px] text-amber-600 pt-0.5">
                  Awarded by: {a.awardedBy} · {a.date}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Company Membership / Join Request Card */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <Building2 className="w-4 h-4" />
          </div>
          <div>
            <div className="font-bold text-sm text-slate-900">Company Membership</div>
            <div className="text-[11px] text-slate-500">
              {currentOrg ? currentOrg.name : 'No company connected'}
            </div>
          </div>
        </div>
        <button
          onClick={() => setIsJoinModalOpen(true)}
          className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl transition-colors shadow-2xs flex items-center gap-1"
        >
          <span>Join Company</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>

      {/* Activity Timeline Card */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
            <Activity className="w-4 h-4" />
          </div>
          <div>
            <div className="font-bold text-sm text-slate-900">Activity Timeline</div>
            <div className="text-[11px] text-slate-500">View your verified attendance, visits & task milestones</div>
          </div>
        </div>
        <button
          onClick={() => setIsTimelineOpen(true)}
          className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl transition-colors shadow-2xs"
        >
          View Timeline
        </button>
      </div>

      {/* Sign Out Button */}
      <button
        onClick={signOutUser}
        className="w-full py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-2xl text-xs flex items-center justify-center gap-1.5 transition-colors"
      >
        <LogOut className="w-4 h-4" />
        <span>Sign Out from FieldFlow</span>
      </button>

      {/* Edit Profile & DP Modal */}
      <UserProfileModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
      />

      {/* Technician's Own Activity Timeline Modal */}
      {isTimelineOpen && (
        <EmployeeTimelineModal
          employee={emp as Employee}
          onClose={() => setIsTimelineOpen(false)}
          isTechnicianView={true}
        />
      )}

      {/* Company Join Request Modal */}
      <CompanyJoinModal
        isOpen={isJoinModalOpen}
        onClose={() => setIsJoinModalOpen(false)}
      />
    </div>
  );
};
