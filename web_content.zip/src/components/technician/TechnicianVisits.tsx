import React, { useEffect, useState, useRef } from 'react';
import {
  MapPin,
  Phone,
  Clock,
  CheckCircle2,
  Play,
  Camera,
  Sparkles,
  ExternalLink,
  AlertCircle,
  X,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { FieldVisit, VisitStatus } from '../../types/index.ts';
import { compressImage } from '../../utils/imageCompressor.ts';
import { enqueueOfflineAction, isItemPendingSync } from '../../utils/offlineQueue.ts';
import { logMilestoneLocation } from '../../utils/locationTracker.ts';

export const TechnicianVisits: React.FC = () => {
  const { currentEmployee, currentOrg, userProfile } = useAuth();
  const [visits, setVisits] = useState<FieldVisit[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('all');

  // Complete Visit Modal state
  const [activeVisit, setActiveVisit] = useState<FieldVisit | null>(null);
  const [outcomeNotes, setOutcomeNotes] = useState('');
  const [compressedPhoto, setCompressedPhoto] = useState<string | null>(null);
  const [isAnalyzingPhoto, setIsAnalyzingPhoto] = useState(false);
  const [aiPhotoSummary, setAiPhotoSummary] = useState<{
    inspectionSummary: string;
    detectedEquipmentOrCondition: string;
    recommendations: string;
  } | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const employeeId = currentEmployee?.id || userProfile?.employeeId || 'emp-101';

  const fetchVisits = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const q = query(
        collection(db, 'visits'),
        where('orgId', '==', currentOrg.id),
        where('assignedEmployeeId', '==', employeeId)
      );
      const snap = await getDocs(q);
      const list: FieldVisit[] = [];
      snap.forEach((d) => list.push(d.data() as FieldVisit));
      // Sort: scheduled/in_progress first, then date
      list.sort((a, b) => (a.status === 'completed' ? 1 : -1));
      setVisits(list);
    } catch (e) {
      console.error('Error fetching visits:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVisits();
  }, [currentOrg, employeeId]);

  const handleStart = async (visit: FieldVisit) => {
    setActionLoading(true);
    try {
      const updated: FieldVisit = {
        ...visit,
        status: 'in_progress',
        startedAt: new Date().toISOString(),
      };
      if (!navigator.onLine) {
        enqueueOfflineAction('start_visit', updated);
      } else {
        await updateDoc(doc(db, 'visits', visit.id), {
          status: 'in_progress',
          startedAt: updated.startedAt,
        });
      }
      setVisits((prev) => prev.map((v) => (v.id === visit.id ? updated : v)));

      // Log milestone location
      if (currentOrg) {
        logMilestoneLocation({
          orgId: currentOrg.id,
          employeeId,
          employeeName: currentEmployee?.name || userProfile?.displayName || 'Technician',
          eventType: 'visit_start',
          notes: `Started visit: ${visit.title}`,
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setActionLoading(false);
    }
  };

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const result = await compressImage(file, { maxWidth: 1024, maxHeight: 1024, quality: 0.75 });
      setCompressedPhoto(result.dataUrl);

      // Automatically trigger server-side Gemini inspection
      setIsAnalyzingPhoto(true);
      const base64Data = result.dataUrl.split(',')[1];
      const res = await fetch('/api/ai/analyze-photo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64Data, mimeType: 'image/jpeg' }),
      });
      if (res.ok) {
        const data = await res.json();
        setAiPhotoSummary(data);
        if (!outcomeNotes) {
          setOutcomeNotes(data.inspectionSummary);
        }
      }
    } catch (err: any) {
      console.error('Photo handling or analysis error:', err);
    } finally {
      setIsAnalyzingPhoto(false);
    }
  };

  const handleCompleteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeVisit || !currentOrg) return;
    setActionLoading(true);
    try {
      const completedAt = new Date().toISOString();
      const updated: FieldVisit = {
        ...activeVisit,
        status: 'completed',
        completedAt,
        outcomeNotes,
        photoUrl: compressedPhoto || undefined,
        photoInspection: aiPhotoSummary || undefined,
      };

      if (!navigator.onLine) {
        enqueueOfflineAction('complete_visit', updated);
      } else {
        await updateDoc(doc(db, 'visits', activeVisit.id), {
          status: 'completed',
          completedAt,
          outcomeNotes,
          photoUrl: compressedPhoto || null,
          photoInspection: aiPhotoSummary || null,
        });
      }

      setVisits((prev) => prev.map((v) => (v.id === activeVisit.id ? updated : v)));

      // Log milestone location
      logMilestoneLocation({
        orgId: currentOrg.id,
        employeeId,
        employeeName: currentEmployee?.name || userProfile?.displayName || 'Technician',
        eventType: 'visit_complete',
        notes: `Completed visit: ${activeVisit.title} at ${activeVisit.customerName}`,
      });

      setActiveVisit(null);
      setOutcomeNotes('');
      setCompressedPhoto(null);
      setAiPhotoSummary(null);
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoading(false);
    }
  };

  const filteredVisits = visits.filter((v) => {
    if (filter === 'pending') return v.status !== 'completed' && v.status !== 'cancelled';
    if (filter === 'completed') return v.status === 'completed';
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Header & Filter */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-sky-600" />
            <h2 className="text-base font-bold text-slate-900">Assigned Field Visits</h2>
          </div>
          <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
            {visits.length} Total
          </span>
        </div>

        {/* Filter Pills */}
        <div className="flex gap-1.5 p-1 bg-slate-100 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setFilter('all')}
            className={`flex-1 py-1.5 rounded-lg transition-colors ${
              filter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('pending')}
            className={`flex-1 py-1.5 rounded-lg transition-colors ${
              filter === 'pending' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Active / Pending
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`flex-1 py-1.5 rounded-lg transition-colors ${
              filter === 'completed' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Completed
          </button>
        </div>
      </div>

      {/* Visits List */}
      {loading ? (
        <div className="text-center py-10 text-xs text-slate-500 font-medium">Loading visits...</div>
      ) : filteredVisits.length === 0 ? (
        <div className="text-center py-10 bg-white rounded-2xl border border-slate-200 p-6 text-xs text-slate-400">
          No visits matching this filter.
        </div>
      ) : (
        <div className="space-y-3">
          {filteredVisits.map((vis) => (
            <div
              key={vis.id}
              className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">{vis.title}</h3>
                  <div className="text-xs font-semibold text-slate-700 mt-0.5">{vis.customerName}</div>
                </div>
                <div className="flex flex-col items-end gap-1 shrink-0">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                      vis.status === 'completed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : vis.status === 'in_progress'
                        ? 'bg-sky-100 text-sky-800 animate-pulse'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {vis.status.replace('_', ' ')}
                  </span>
                  {isItemPendingSync(vis.id) && (
                    <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-amber-50 text-amber-800 border border-amber-300">
                      ⏳ Pending Sync
                    </span>
                  )}
                </div>
              </div>

              {/* Address & Call Buttons */}
              <div className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex items-start gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                  <span className="leading-snug">{vis.siteAddress}</span>
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px]">
                  <span className="text-slate-500">
                    Scheduled: <strong className="text-slate-800">{vis.scheduledTime || '09:00 AM'}</strong> ({vis.scheduledDate})
                  </span>
                  {vis.customerPhone && (
                    <a
                      href={`tel:${vis.customerPhone}`}
                      className="text-sky-600 font-bold flex items-center gap-1 hover:underline"
                    >
                      <Phone className="w-3 h-3" />
                      <span>Call Customer</span>
                    </a>
                  )}
                </div>
              </div>

              {/* Outcome notes preview if completed */}
              {vis.outcomeNotes && (
                <div className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs text-emerald-900">
                  <div className="font-bold text-[10px] text-emerald-800 uppercase">Outcome Notes:</div>
                  <div className="mt-0.5">{vis.outcomeNotes}</div>
                  {vis.photoInspection && (
                    <div className="mt-1 pt-1 border-t border-emerald-200 text-[11px] text-emerald-800">
                      <strong>AI Inspection:</strong> {vis.photoInspection.inspectionSummary}
                    </div>
                  )}
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-1">
                {vis.status === 'scheduled' && (
                  <button
                    onClick={() => handleStart(vis)}
                    disabled={actionLoading}
                    className="flex-1 py-3 px-4 bg-sky-600 hover:bg-sky-700 active:scale-[0.99] text-white font-black rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition-all uppercase tracking-wide min-h-[44px]"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>START VISIT</span>
                  </button>
                )}

                {vis.status === 'in_progress' && (
                  <button
                    onClick={() => {
                      setActiveVisit(vis);
                      setOutcomeNotes(vis.outcomeNotes || '');
                      setCompressedPhoto(vis.photoUrl || null);
                    }}
                    className="flex-1 py-3 px-4 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] text-white font-black rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition-all uppercase tracking-wide min-h-[44px]"
                  >
                    <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                    <span>COMPLETE VISIT</span>
                  </button>
                )}

                {/* Google Maps directions */}
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(vis.siteAddress)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-3 px-3.5 rounded-xl border border-slate-300 bg-white text-slate-800 hover:bg-slate-50 font-bold text-xs flex items-center gap-1.5 shadow-xs min-h-[44px]"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                  <span>Navigate</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Complete Visit Modal */}
      {activeVisit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-5 max-w-sm w-full border border-slate-200 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-base text-slate-900">Complete Field Visit</h3>
              <button onClick={() => setActiveVisit(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-500 mb-3">{activeVisit.title}</p>

            <form onSubmit={handleCompleteSubmit} className="space-y-3 text-xs">
              {/* Photo capture / upload */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Site / Equipment Photo (Optional)
                </label>
                <input
                  type="file"
                  accept="image/*"
                  ref={fileInputRef}
                  onChange={handlePhotoSelect}
                  className="hidden"
                />
                {!compressedPhoto ? (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-3 px-4 border-2 border-dashed border-slate-200 hover:border-sky-400 rounded-xl flex items-center justify-center gap-2 text-slate-600 font-semibold"
                  >
                    <Camera className="w-4 h-4 text-sky-600" />
                    <span>Take or Upload Site Photo</span>
                  </button>
                ) : (
                  <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                    <img src={compressedPhoto} alt="Site capture" className="w-full h-36 object-cover" />
                    <button
                      type="button"
                      onClick={() => {
                        setCompressedPhoto(null);
                        setAiPhotoSummary(null);
                      }}
                      className="absolute top-2 right-2 p-1 rounded-full bg-slate-900/70 text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* AI Photo Inspection Feedback */}
              {isAnalyzingPhoto && (
                <div className="p-2.5 rounded-xl bg-sky-50 text-sky-700 font-medium flex items-center gap-2 text-[11px] animate-pulse">
                  <Sparkles className="w-3.5 h-3.5 shrink-0" />
                  <span>AI is analyzing equipment and site photo...</span>
                </div>
              )}

              {aiPhotoSummary && (
                <div className="p-2.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-[11px] space-y-1">
                  <div className="font-bold flex items-center gap-1 text-indigo-700">
                    <Sparkles className="w-3 h-3" />
                    <span>AI Site Inspection Result:</span>
                  </div>
                  <div>{aiPhotoSummary.inspectionSummary}</div>
                  <div className="text-[10px] text-indigo-700">
                    <strong>Recommended:</strong> {aiPhotoSummary.recommendations}
                  </div>
                </div>
              )}

              {/* Outcome Notes */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Work Outcome & Notes *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Detail work performed, parts replaced, or customer feedback..."
                  value={outcomeNotes}
                  onChange={(e) => setOutcomeNotes(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl text-xs leading-relaxed"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveVisit(null)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-xs"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{actionLoading ? 'Saving...' : 'Finish Visit'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
