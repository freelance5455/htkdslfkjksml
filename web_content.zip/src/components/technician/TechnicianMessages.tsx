import React, { useEffect, useState, useRef } from 'react';
import {
  MessageSquare,
  Send,
  Mic,
  Square,
  Sparkles,
  FileText,
  Paperclip,
  Film,
  X,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { Message } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import {
  validateAndPrepareAttachment,
  ValidatedAttachmentFile,
  ResumableUploadTask,
  ResumableUploadProgress,
  formatFileSize,
  CHAT_FILE_INPUT_ACCEPT,
} from '../../utils/mediaHelper.ts';
import { sendNotification } from '../../utils/notificationHelper.ts';
import { ChatFileAttachmentCard } from '../common/ChatFileAttachmentCard.tsx';

export const TechnicianMessages: React.FC = () => {
  const { currentEmployee, currentOrg, userProfile } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);

  // Voice Note State
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [recordedBase64DataUrl, setRecordedBase64DataUrl] = useState<string | null>(null);
  const [audioDuration, setAudioDuration] = useState(0);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [voiceAiSummary, setVoiceAiSummary] = useState<{
    transcript: string;
    suggestedVisitNote: string;
    suggestedFollowUpTask?: string;
  } | null>(null);

  // Media Attachment State (lightweight reference only, never full large file in React state)
  const [pendingMedia, setPendingMedia] = useState<ValidatedAttachmentFile | null>(null);
  const [processingMedia, setProcessingMedia] = useState(false);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const [previewModal, setPreviewModal] = useState<{
    url: string;
    type: 'image' | 'video' | 'pdf';
    title?: string;
  } | null>(null);

  // Resumable Upload Progress Map (keyed by message.id)
  const [uploadProgressMap, setUploadProgressMap] = useState<Record<string, ResumableUploadProgress>>({});
  const uploadTasksRef = useRef<Record<string, { task: ResumableUploadTask; message: Message }>>({});

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const employeeId = currentEmployee?.id || userProfile?.employeeId || userProfile?.id || '';
  const authUserId = userProfile?.id || employeeId;
  const employeeName =
    currentEmployee?.name || userProfile?.displayName || userProfile?.email?.split('@')[0] || 'Technician';

  const fetchMessages = async () => {
    if (!currentOrg || !employeeId) return;
    try {
      const q = query(collection(db, 'messages'), where('orgId', '==', currentOrg.id));
      const snap = await getDocs(q);
      const list: Message[] = [];
      snap.forEach((d) => {
        const m = d.data() as Message;
        // Strictly show messages that involve this specific employee or are company broadcasts
        if (m.senderId === employeeId || m.recipientId === employeeId || m.recipientId === 'all') {
          list.push(m);
        }
      });

      list.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
      setMessages(list);
    } catch (e) {
      console.error('Error fetching messages:', e);
    }
  };

  useEffect(() => {
    fetchMessages();
  }, [currentOrg, employeeId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, voiceAiSummary, pendingMedia, recordedAudioUrl]);

  const handleSelectFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMediaError(null);
    setProcessingMedia(true);
    try {
      const validated = await validateAndPrepareAttachment(file);
      if (pendingMedia?.objectPreviewUrl) {
        URL.revokeObjectURL(pendingMedia.objectPreviewUrl);
      }
      setPendingMedia(validated);
    } catch (err: any) {
      setMediaError(err?.message || 'Failed to validate file attachment.');
    } finally {
      setProcessingMedia(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const clearPendingMedia = () => {
    if (pendingMedia?.objectPreviewUrl) {
      URL.revokeObjectURL(pendingMedia.objectPreviewUrl);
    }
    setPendingMedia(null);
  };

  const runResumableAttachmentUpload = async (msg: Message, task: ResumableUploadTask) => {
    if (!currentOrg) return;
    try {
      const completedMeta = await task.startOrResume(msg.id);

      const finalizedMsg: Message = {
        ...msg,
        fileId: completedMeta.id,
        storagePath: completedMeta.storagePath,
        uploadStatus: 'completed',
        thumbnailUrl: completedMeta.thumbnailUrl || msg.thumbnailUrl,
      };

      await setDoc(doc(db, 'messages', msg.id), removeUndefinedFields(finalizedMsg));
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? finalizedMsg : m)));

      // Notify dispatch admin after upload completes
      await sendNotification({
        orgId: currentOrg.id,
        userId: 'admin',
        targetRole: 'org_admin',
        title: `File from ${employeeName}`,
        message: `${msg.fileName || 'Attachment'} (${formatFileSize(msg.fileSizeBytes)})`,
        type: 'message',
        linkTab: 'messages',
      });
    } catch (err: any) {
      console.warn('Technician resumable upload interrupted or failed:', err);
      const failedMsg: Message = {
        ...msg,
        uploadStatus: 'failed',
      };
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? failedMsg : m)));
    }
  };

  const handleRetryUpload = async (messageId: string) => {
    const entry = uploadTasksRef.current[messageId];
    if (!entry) {
      setMediaError('Please re-select the file to start a new upload.');
      return;
    }
    setMediaError(null);
    setMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, uploadStatus: 'uploading' } : m))
    );
    await runResumableAttachmentUpload(entry.message, entry.task);
  };

  const handleCancelUpload = async (messageId: string) => {
    const entry = uploadTasksRef.current[messageId];
    if (entry) {
      await entry.task.cancel();
      delete uploadTasksRef.current[messageId];
    }
    setUploadProgressMap((prev) => {
      const next = { ...prev };
      delete next[messageId];
      return next;
    });
    setMessages((prev) => prev.filter((m) => m.id !== messageId));
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!currentOrg || !employeeId || isSending) return;
    if (!inputText.trim() && !pendingMedia) return;

    const captionText = inputText.trim();
    const attachmentToUpload = pendingMedia;

    if (attachmentToUpload) {
      const msgId = `msg_${Date.now()}`;
      const content =
        captionText || `Attached ${attachmentToUpload.messageType}: ${attachmentToUpload.fileName}`;

      const optimisticMsg: Message = {
        id: msgId,
        orgId: currentOrg.id,
        senderId: employeeId,
        senderName: employeeName,
        senderRole: 'employee',
        recipientId: 'admin',
        content,
        messageType: attachmentToUpload.messageType,
        fileName: attachmentToUpload.fileName,
        fileSizeBytes: attachmentToUpload.fileSizeBytes,
        mimeType: attachmentToUpload.mimeType,
        thumbnailUrl: attachmentToUpload.thumbnailUrl,
        uploadStatus: 'uploading',
        read: false,
        createdAt: new Date().toISOString(),
      };

      const task = new ResumableUploadTask({
        file: attachmentToUpload.file,
        mimeType: attachmentToUpload.mimeType,
        companyId: currentOrg.id,
        conversationId: employeeId,
        uploaderId: authUserId,
        uploaderName: employeeName,
        employeeId,
        thumbnailUrl: attachmentToUpload.thumbnailUrl,
        onProgress: (progress) => {
          setUploadProgressMap((prev) => ({
            ...prev,
            [msgId]: progress,
          }));
        },
      });

      uploadTasksRef.current[msgId] = { task, message: optimisticMsg };
      setMessages((prev) => [...prev, optimisticMsg]);
      setInputText('');
      clearPendingMedia();
      setMediaError(null);

      // Run upload asynchronously so technician mobile screen stays responsive
      runResumableAttachmentUpload(optimisticMsg, task);
      return;
    }

    setIsSending(true);
    const newMsg: Message = {
      id: `msg_${Date.now()}`,
      orgId: currentOrg.id,
      senderId: employeeId,
      senderName: employeeName,
      senderRole: 'employee',
      recipientId: 'admin',
      content: captionText,
      messageType: 'text',
      read: false,
      createdAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'messages', newMsg.id), removeUndefinedFields(newMsg));
      setMessages((prev) => [...prev, newMsg]);
      setInputText('');
      setMediaError(null);

      // Notify dispatch admin
      await sendNotification({
        orgId: currentOrg.id,
        userId: 'admin',
        targetRole: 'org_admin',
        title: `Message from ${employeeName}`,
        message: captionText.substring(0, 100),
        type: 'message',
        linkTab: 'messages',
      });
    } catch (err) {
      console.error('Error sending message:', err);
    } finally {
      setIsSending(false);
    }
  };

  // Real Web Audio Recording
  const startRecording = async () => {
    setVoiceError(null);
    setVoiceAiSummary(null);
    setRecordedAudioUrl(null);
    setRecordedBase64DataUrl(null);
    setAudioDuration(0);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setVoiceError('Voice recording is not supported in this browser.');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(audioBlob);
        setRecordedAudioUrl(url);

        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64DataUrl = reader.result as string;
          setRecordedBase64DataUrl(base64DataUrl);
          const rawBase64 = base64DataUrl.split(',')[1];

          // Trigger asynchronous AI transcription in the background (non-blocking)
          setIsTranscribing(true);
          try {
            const res = await fetch('/api/ai/voice-transcribe', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ audioBase64: rawBase64, mimeType: 'audio/webm' }),
            });
            if (res.ok) {
              const data = await res.json();
              setVoiceAiSummary(data);
            }
          } catch (e) {
            console.warn('AI voice transcription notice:', e);
          } finally {
            setIsTranscribing(false);
          }
        };

        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start(250);
      setIsRecording(true);

      timerRef.current = setInterval(() => {
        setAudioDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.warn('Microphone permission denied or unavailable:', err);
      setVoiceError('Microphone permission denied. Please allow microphone access to record voice notes.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
  };

  const cancelRecording = () => {
    if (isRecording) {
      stopRecording();
    }
    setRecordedAudioUrl(null);
    setRecordedBase64DataUrl(null);
    setAudioDuration(0);
    setVoiceAiSummary(null);
    setVoiceError(null);
  };

  const handleSendVoiceMessage = async () => {
    if (!currentOrg || !recordedBase64DataUrl || isSending) return;
    setIsSending(true);

    const transcript = voiceAiSummary?.transcript || `Voice note (${audioDuration}s)`;
    const newMsg: Message = {
      id: `msg_voice_${Date.now()}`,
      orgId: currentOrg.id,
      senderId: employeeId,
      senderName: employeeName,
      senderRole: 'employee',
      recipientId: 'admin',
      content: transcript,
      messageType: 'voice',
      mediaUrl: recordedBase64DataUrl,
      voiceDuration: audioDuration,
      voiceTranscript: voiceAiSummary?.transcript,
      read: false,
      createdAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'messages', newMsg.id), removeUndefinedFields(newMsg));
      setMessages((prev) => [...prev, newMsg]);
      cancelRecording();

      // Notify dispatch admin
      await sendNotification({
        orgId: currentOrg.id,
        userId: 'admin',
        targetRole: 'org_admin',
        title: `Voice note from ${employeeName}`,
        message: transcript.substring(0, 100),
        type: 'message',
        linkTab: 'messages',
      });
    } catch (err) {
      console.error('Error sending voice message:', err);
      setVoiceError('Failed to send voice note. Please try again.');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-14rem)] bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Top Header */}
      <div className="p-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-sky-600 text-white flex items-center justify-center font-bold text-xs">
            M
          </div>
          <div>
            <div className="text-xs font-bold text-slate-900">Operations Management & Dispatch</div>
            <div className="text-[10px] text-slate-500">Active · Direct Support</div>
          </div>
        </div>
        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
          Connected
        </span>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 p-3 overflow-y-auto space-y-2.5 bg-slate-50/50">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-2 py-8">
            <MessageSquare className="w-8 h-8 stroke-[1.5]" />
            <p className="text-xs">No messages yet. Send an update, file (up to 500 MB), or voice note below.</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = msg.senderId === employeeId;
            const isFileMsg =
              msg.messageType === 'image' ||
              msg.messageType === 'document' ||
              msg.messageType === 'video';

            return (
              <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                <div
                  className={`max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed space-y-2 ${
                    isMe
                      ? 'bg-sky-600 text-white rounded-br-xs'
                      : 'bg-white text-slate-800 rounded-bl-xs border border-slate-200 shadow-2xs'
                  }`}
                >
                  {/* Voice Message */}
                  {msg.messageType === 'voice' && (
                    <div className="space-y-1.5 min-w-[200px]">
                      <div className="flex items-center gap-1.5 font-bold text-[11px]">
                        <Mic className={`w-3.5 h-3.5 ${isMe ? 'text-amber-300' : 'text-sky-600'}`} />
                        <span>Voice Note ({msg.voiceDuration || 5}s)</span>
                      </div>
                      {msg.mediaUrl && (
                        <audio controls src={msg.mediaUrl} className="w-full max-w-[240px] h-8 mt-1 rounded-lg" />
                      )}
                      {msg.voiceTranscript && (
                        <div className={`text-[11px] italic ${isMe ? 'text-sky-100' : 'text-slate-600'}`}>
                          &quot;{msg.voiceTranscript}&quot;
                        </div>
                      )}
                    </div>
                  )}

                  {/* File Attachment Message (Image, Document, Video up to 500 MB) */}
                  {isFileMsg && currentOrg && (
                    <ChatFileAttachmentCard
                      message={msg}
                      isOwnMessage={isMe}
                      currentUserId={authUserId}
                      currentCompanyId={currentOrg.id}
                      currentEmployeeId={employeeId}
                      uploadProgress={uploadProgressMap[msg.id]}
                      onRetryUpload={handleRetryUpload}
                      onCancelUpload={handleCancelUpload}
                      onPreviewMedia={(url, type, title) => setPreviewModal({ url, type, title })}
                    />
                  )}

                  {/* Regular Text */}
                  {msg.messageType === 'text' && <div>{msg.content}</div>}
                </div>

                <span className="text-[10px] text-slate-400 mt-0.5 px-1">
                  {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            );
          })
        )}

        {/* Live Voice Recording Preview */}
        {isRecording && (
          <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center justify-between animate-pulse">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping"></span>
              <span className="font-bold">Recording voice message... ({audioDuration}s)</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={cancelRecording}
                className="px-2 py-1 text-slate-500 hover:text-slate-800 font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={stopRecording}
                className="p-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold flex items-center gap-1 text-[11px]"
              >
                <Square className="w-3 h-3 fill-current" />
                <span>Stop</span>
              </button>
            </div>
          </div>
        )}

        {/* Voice Note Ready to Send Preview */}
        {recordedAudioUrl && !isRecording && (
          <div className="p-3 rounded-2xl bg-sky-50 border border-sky-200 text-xs space-y-2 shadow-2xs">
            <div className="flex items-center justify-between font-bold text-sky-950">
              <div className="flex items-center gap-1.5">
                <Mic className="w-4 h-4 text-sky-600" />
                <span>Voice Note Ready ({audioDuration}s)</span>
              </div>
              <button
                type="button"
                onClick={cancelRecording}
                className="text-slate-400 hover:text-slate-600 font-semibold text-[11px]"
              >
                Discard
              </button>
            </div>

            <audio controls src={recordedAudioUrl} className="w-full h-8 rounded-lg" />

            {isTranscribing && (
              <div className="flex items-center gap-1.5 text-[11px] text-indigo-700 animate-pulse">
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI is transcribing note...</span>
              </div>
            )}

            {voiceAiSummary && (
              <div className="p-2 bg-white/80 rounded-xl border border-sky-100 text-[11px] text-slate-700 italic">
                &quot;{voiceAiSummary.transcript}&quot;
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={cancelRecording}
                className="px-3 py-1.5 border border-slate-300 bg-white rounded-xl text-slate-600 font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSendVoiceMessage}
                disabled={isSending}
                className="px-4 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs disabled:opacity-50"
              >
                {isSending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span>Send Voice Note</span>
              </button>
            </div>
          </div>
        )}

        {/* Voice Error Alert */}
        {voiceError && (
          <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{voiceError}</span>
            </div>
            <button onClick={() => setVoiceError(null)} className="font-bold text-xs p-1">
              ✕
            </button>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Pending Media Attachment Preview */}
      {pendingMedia && (
        <div className="p-2.5 bg-sky-50 border-t border-sky-100 flex items-center justify-between text-xs text-sky-950">
          <div className="flex items-center gap-2.5 truncate">
            {pendingMedia.thumbnailUrl || pendingMedia.objectPreviewUrl ? (
              <img
                src={pendingMedia.thumbnailUrl || pendingMedia.objectPreviewUrl}
                alt="Preview"
                className="w-9 h-9 rounded-lg object-cover border border-sky-200 shrink-0"
              />
            ) : pendingMedia.messageType === 'video' ? (
              <Film className="w-5 h-5 text-sky-600 shrink-0" />
            ) : (
              <FileText className="w-5 h-5 text-sky-600 shrink-0" />
            )}
            <div className="truncate">
              <div className="truncate font-bold">{pendingMedia.fileName}</div>
              <div className="text-[10px] text-slate-500">
                {pendingMedia.extension.toUpperCase()} · {formatFileSize(pendingMedia.fileSizeBytes)} · Ready for resumable upload
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={clearPendingMedia}
            className="p-1 text-slate-400 hover:text-slate-600 shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Media Error Alert */}
      {mediaError && (
        <div className="p-2.5 bg-rose-50 border-t border-rose-200 text-rose-700 text-xs flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{mediaError}</span>
          </div>
          <button onClick={() => setMediaError(null)} className="font-bold text-xs px-1">
            ✕
          </button>
        </div>
      )}

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept={CHAT_FILE_INPUT_ACCEPT}
        onChange={handleSelectFile}
        className="hidden"
      />

      {/* Input bar */}
      <div className="p-2.5 bg-slate-50 border-t border-slate-200">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
          {/* File Attachment Button */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={processingMedia}
            className="p-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 transition-colors shrink-0 disabled:opacity-50"
            title="Attach file (PDF, DOCX, XLSX, CSV, PPTX, JPG, PNG, WEBP, MP4, MOV, ZIP up to 500 MB)"
          >
            {processingMedia ? (
              <Loader2 className="w-4 h-4 animate-spin text-slate-600" />
            ) : (
              <Paperclip className="w-4 h-4" />
            )}
          </button>

          {/* Voice Record Button */}
          <button
            type="button"
            onClick={isRecording ? stopRecording : startRecording}
            className={`p-2.5 rounded-xl transition-all shrink-0 ${
              isRecording
                ? 'bg-rose-600 text-white animate-pulse'
                : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
            }`}
            title="Hold or tap to record voice note"
          >
            <Mic className="w-4 h-4" />
          </button>

          <input
            type="text"
            placeholder={
              pendingMedia
                ? 'Add a caption (optional)...'
                : 'Type message to operations... (Press Enter to send)'
            }
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="flex-1 px-3 py-2.5 text-xs bg-white rounded-xl border border-slate-200 focus:outline-hidden focus:border-sky-500"
          />

          {/* Working, visible SEND button */}
          <button
            type="submit"
            disabled={(!inputText.trim() && !pendingMedia) || isSending}
            className="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 disabled:opacity-40 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors shrink-0 active:scale-95 cursor-pointer"
          >
            {isSending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Send className="w-3.5 h-3.5" />
            )}
            <span className="font-bold">Send</span>
          </button>
        </form>
      </div>

      {/* Modal for viewing full size image, video, or PDF preview */}
      {previewModal && (
        <div
          onClick={() => setPreviewModal(null)}
          className="fixed inset-0 z-[90] bg-black/80 flex items-center justify-center p-4 backdrop-blur-xs"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-4xl w-full max-h-[88vh] flex flex-col items-center"
          >
            <div className="w-full flex items-center justify-between text-white mb-2 px-1">
              <span className="text-xs font-bold truncate">{previewModal.title || 'File Preview'}</span>
              <button
                onClick={() => setPreviewModal(null)}
                className="text-white hover:text-slate-300 p-1.5 rounded-lg bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {previewModal.type === 'image' && (
              <img
                src={previewModal.url}
                alt={previewModal.title || 'Preview'}
                className="rounded-xl max-h-[80vh] w-auto object-contain bg-black"
              />
            )}
            {previewModal.type === 'video' && (
              <video
                controls
                autoPlay
                src={previewModal.url}
                className="rounded-xl max-h-[80vh] w-full bg-black"
              />
            )}
            {previewModal.type === 'pdf' && (
              <iframe
                src={previewModal.url}
                title={previewModal.title || 'PDF Preview'}
                className="w-full h-[78vh] rounded-xl bg-white border border-slate-300"
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
};
