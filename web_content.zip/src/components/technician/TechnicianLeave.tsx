import React, { useEffect, useState } from 'react';
import { Calendar, Plus, Clock, CheckCircle2, XCircle, Send } from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { LeaveRequest, LeaveType } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';

export const TechnicianLeave: React.FC = () => {
  const { currentEmployee, currentOrg, userProfile } = useAuth();
  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [showApplyModal, setShowApplyModal] = useState(false);

  // Form states
  const [leaveType, setLeaveType] = useState<LeaveType>('annual');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const employeeId = currentEmployee?.id || userProfile?.employeeId || 'emp-101';
  const employeeName = currentEmployee?.name || userProfile?.displayName || 'Technician';

  // Calculate remaining balances dynamically based on approved leave requests
  const calculateDays = (start: string, end: string) => {
    try {
      const s = new Date(start).getTime();
      const e = new Date(end).getTime();
      if (isNaN(s) || isNaN(e)) return 1;
      return Math.max(1, Math.round((e - s) / (1000 * 3600 * 24)) + 1);
    } catch {
      return 1;
    }
  };

  const approvedLeaves = leaves.filter((l) => l.status === 'approved');
  const usedAnnual = approvedLeaves
    .filter((l) => l.leaveType === 'annual')
    .reduce((sum, l) => sum + calculateDays(l.startDate, l.endDate), 0);
  const usedSick = approvedLeaves
    .filter((l) => l.leaveType === 'sick')
    .reduce((sum, l) => sum + calculateDays(l.startDate, l.endDate), 0);
  const usedCasual = approvedLeaves
    .filter((l) => l.leaveType === 'casual')
    .reduce((sum, l) => sum + calculateDays(l.startDate, l.endDate), 0);

  const remainingAnnual = Math.max(0, 14 - usedAnnual);
  const remainingSick = Math.max(0, 7 - usedSick);
  const remainingCasual = Math.max(0, 3 - usedCasual);

  const fetchLeaves = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const q = query(
        collection(db, 'leave_requests'),
        where('orgId', '==', currentOrg.id),
        where('employeeId', '==', employeeId)
      );
      const snap = await getDocs(q);
      const list: LeaveRequest[] = [];
      snap.forEach((d) => list.push(d.data() as LeaveRequest));
      list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setLeaves(list);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeaves();
  }, [currentOrg, employeeId]);

  const handleSubmitLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentOrg || !startDate || !endDate || !reason) return;
    setSubmitting(true);
    try {
      const newLeave: LeaveRequest = {
        id: `leave_${Date.now()}`,
        orgId: currentOrg.id,
        employeeId,
        employeeName,
        leaveType,
        startDate,
        endDate,
        reason,
        status: 'pending',
        createdAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'leave_requests', newLeave.id), removeUndefinedFields(newLeave));
      setLeaves((prev) => [newLeave, ...prev]);
      setShowApplyModal(false);
      setReason('');
      setStartDate('');
      setEndDate('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-sky-600" />
            <span>Time Off & Leave</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">Submit and track leave applications</p>
        </div>
        <button
          onClick={() => setShowApplyModal(true)}
          className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Apply</span>
        </button>
      </div>

      {/* Leave balance indicators */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-lg font-black text-sky-700">{remainingAnnual}</div>
          <div className="text-[10px] text-slate-500 font-bold uppercase mt-0.5">Annual Days</div>
        </div>
        <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-lg font-black text-emerald-700">{remainingSick}</div>
          <div className="text-[10px] text-slate-500 font-bold uppercase mt-0.5">Sick Leave</div>
        </div>
        <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-lg font-black text-amber-700">{remainingCasual}</div>
          <div className="text-[10px] text-slate-500 font-bold uppercase mt-0.5">Emergency</div>
        </div>
      </div>

      {/* Requests History */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <h3 className="font-bold text-sm text-slate-900 mb-3">Applications History</h3>

        {loading ? (
          <div className="text-center py-6 text-xs text-slate-500">Loading requests...</div>
        ) : leaves.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-400">No leave requests submitted yet.</div>
        ) : (
          <div className="space-y-2.5">
            {leaves.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 capitalize">
                    {item.leaveType} Leave
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                      item.status === 'approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.status === 'rejected'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>

                <div className="text-slate-600 font-medium">
                  📅 {item.startDate} → {item.endDate}
                </div>

                <div className="text-slate-500 text-[11px] italic">"{item.reason}"</div>

                {item.adminComment && (
                  <div className="pt-1 border-t border-slate-200 text-[11px] text-slate-700">
                    <strong>Manager Note:</strong> {item.adminComment}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Apply Modal */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-5 max-w-sm w-full border border-slate-200 shadow-2xl">
            <h3 className="font-bold text-base text-slate-900">Apply for Leave</h3>
            <form onSubmit={handleSubmitLeave} className="mt-3 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Leave Type</label>
                <select
                  value={leaveType}
                  onChange={(e) => setLeaveType(e.target.value as LeaveType)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                >
                  <option value="annual">Annual Leave</option>
                  <option value="sick">Sick Leave</option>
                  <option value="casual">Casual Leave</option>
                  <option value="emergency">Emergency Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Start Date</label>
                  <input
                    type="date"
                    required
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">End Date</label>
                  <input
                    type="date"
                    required
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Reason</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Explain reason for time off..."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowApplyModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-1.5 bg-sky-600 text-white rounded-lg font-bold hover:bg-sky-700 flex items-center gap-1"
                >
                  <Send className="w-3 h-3" />
                  <span>{submitting ? 'Submitting...' : 'Submit Request'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
