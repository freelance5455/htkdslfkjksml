import React, { useState, useEffect } from 'react';
import {
  Building2,
  Search,
  Send,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  X,
  Shield,
  KeyRound,
  FileText,
  User,
  Phone,
  Mail,
  RotateCcw,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { Organization, CompanyJoinRequest, AuditLogEntry } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import { sendNotification } from '../../utils/notificationHelper.ts';
import { verifyCompanyPassword } from '../../utils/securityHelper.ts';

interface CompanyJoinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onJoinedSuccessfully?: () => void;
}

export const CompanyJoinModal: React.FC<CompanyJoinModalProps> = ({
  isOpen,
  onClose,
  onJoinedSuccessfully,
}) => {
  const { userProfile, currentOrg, reloadUserData } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [accessCodeInput, setAccessCodeInput] = useState('');
  const [phoneInput, setPhoneInput] = useState('');
  const [notesInput, setNotesInput] = useState('');

  const [availableCompanies, setAvailableCompanies] = useState<Organization[]>([]);
  const [selectedCompany, setSelectedCompany] = useState<Organization | null>(null);
  const [myRequests, setMyRequests] = useState<CompanyJoinRequest[]>([]);

  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const fetchCompaniesAndRequests = async () => {
    if (!userProfile) return;
    setIsLoading(true);
    setErrorMessage('');
    try {
      // 1. Fetch active organizations
      const orgSnap = await getDocs(query(collection(db, 'organizations'), where('status', '==', 'active')));
      const orgList: Organization[] = [];
      orgSnap.forEach((d) => {
        const data = d.data() as Organization;
        if (!data.isDeleted) {
          orgList.push(data);
        }
      });
      setAvailableCompanies(orgList);

      // 2. Fetch my join requests
      const reqSnap = await getDocs(
        query(collection(db, 'company_join_requests'), where('userId', '==', userProfile.id))
      );
      const reqList: CompanyJoinRequest[] = [];
      reqSnap.forEach((d) => reqList.push(d.data() as CompanyJoinRequest));
      reqList.sort((a, b) => b.requestedAt.localeCompare(a.requestedAt));
      setMyRequests(reqList);
    } catch (err: any) {
      console.error('Error fetching companies/requests:', err);
      setErrorMessage('Could not load company list. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchCompaniesAndRequests();
      setSelectedCompany(null);
      setErrorMessage('');
      setSuccessMessage('');
    }
  }, [isOpen, userProfile]);

  const filteredCompanies = availableCompanies.filter(
    (c) =>
      c.name.toLowerCase().includes(searchTerm.toLowerCase().trim()) ||
      c.id.toLowerCase().includes(searchTerm.toLowerCase().trim())
  );

  const handleSubmitRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCompany || !userProfile) return;
    setErrorMessage('');
    setSuccessMessage('');

    // Check if company has an access code requirement
    if (selectedCompany.accessPasswordHash && selectedCompany.accessPasswordSalt) {
      const isValid = await verifyCompanyPassword(
        accessCodeInput.trim(),
        selectedCompany.accessPasswordHash,
        selectedCompany.accessPasswordSalt
      );
      if (!isValid) {
        setErrorMessage('Invalid Company Access Code / Password. Please verify the code with your company manager.');
        return;
      }
    } else if (selectedCompany.accessCode && selectedCompany.accessCode.trim()) {
      if (accessCodeInput.trim().toUpperCase() !== selectedCompany.accessCode.trim().toUpperCase()) {
        setErrorMessage('Invalid Company Access Code. Please request the current code from your company administrator.');
        return;
      }
    }

    // Check if pending request already exists
    const hasPending = myRequests.some(
      (r) => r.orgId === selectedCompany.id && r.status === 'pending'
    );
    if (hasPending) {
      setErrorMessage(`You already have a pending request for ${selectedCompany.name}.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const requestId = `req_${userProfile.id}_${selectedCompany.id}_${Date.now()}`;
      const newRequest: CompanyJoinRequest = {
        id: requestId,
        userId: userProfile.id,
        userEmail: userProfile.email,
        userName: userProfile.displayName || userProfile.email.split('@')[0],
        userPhone: phoneInput.trim() || undefined,
        orgId: selectedCompany.id,
        orgName: selectedCompany.name,
        status: 'pending',
        notes: notesInput.trim() || undefined,
        requestedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'company_join_requests', requestId), removeUndefinedFields(newRequest));

      // Dispatch in-app notification to the company's admin team
      await sendNotification({
        orgId: selectedCompany.id,
        userId: 'admin',
        targetRole: 'org_admin',
        title: 'New Technician Join Request',
        message: `${newRequest.userName} (${newRequest.userEmail}) submitted a join request.`,
        type: 'join_request',
        linkTab: 'employees',
      });

      // Audit log
      const auditEntry: AuditLogEntry = {
        id: `aud_req_${Date.now()}`,
        orgId: selectedCompany.id,
        userId: userProfile.id,
        userName: newRequest.userName,
        userRole: 'employee',
        action: 'SUBMIT_JOIN_REQUEST',
        module: 'Workforce Onboarding',
        details: `Technician submitted join request to company ${selectedCompany.name}`,
        targetId: requestId,
        targetName: selectedCompany.name,
        result: 'success',
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditEntry.id), removeUndefinedFields(auditEntry));

      setSuccessMessage(`Join request submitted to ${selectedCompany.name}! The company administrator will review your application.`);
      setSelectedCompany(null);
      setAccessCodeInput('');
      setPhoneInput('');
      setNotesInput('');
      await fetchCompaniesAndRequests();
    } catch (err: any) {
      console.error('Error submitting join request:', err);
      setErrorMessage(err?.message || 'Failed to submit join request. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancelRequest = async (requestId: string, companyName: string) => {
    try {
      await updateDoc(doc(db, 'company_join_requests', requestId), {
        status: 'cancelled',
        reviewedAt: new Date().toISOString(),
      });
      setMyRequests((prev) =>
        prev.map((r) => (r.id === requestId ? { ...r, status: 'cancelled' } : r))
      );
      setSuccessMessage(`Request to join ${companyName} has been cancelled.`);
    } catch (err: any) {
      console.error('Error cancelling request:', err);
      setErrorMessage('Could not cancel request.');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl p-5 sm:p-7 max-w-lg w-full border border-slate-200 shadow-2xl space-y-5 my-8 animate-in fade-in-0 duration-200 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">Join Company Workspace</h3>
              <p className="text-xs text-slate-500">Request access to your field operations company</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Company Status */}
        {currentOrg && (
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-xs flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-slate-500">Active Company:</span>
              <span className="font-bold text-slate-900">{currentOrg.name}</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
              Connected
            </span>
          </div>
        )}

        {/* Alerts */}
        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs flex items-center gap-2 shrink-0">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs flex items-center gap-2 shrink-0">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        <div className="flex-1 overflow-y-auto space-y-5 pr-1 text-xs">
          {/* Section 1: Search & Request Form */}
          {!selectedCompany ? (
            <div className="space-y-3">
              <div className="font-bold text-slate-800 flex items-center gap-1.5">
                <Search className="w-4 h-4 text-sky-600" />
                <span>Search Company</span>
              </div>

              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Type company name or workspace code..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                />
              </div>

              {/* Company Results */}
              <div className="space-y-2 max-h-56 overflow-y-auto">
                {isLoading ? (
                  <div className="p-6 text-center text-slate-400">Loading organizations...</div>
                ) : filteredCompanies.length === 0 ? (
                  <div className="p-6 text-center text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                    No active companies found matching &quot;{searchTerm}&quot;.
                  </div>
                ) : (
                  filteredCompanies.map((comp) => {
                    const isAlreadyCurrent = currentOrg?.id === comp.id;
                    const existingReq = myRequests.find((r) => r.orgId === comp.id && r.status === 'pending');

                    return (
                      <div
                        key={comp.id}
                        className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between transition-colors gap-3"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className="w-9 h-9 rounded-xl flex items-center justify-center text-white font-bold shrink-0"
                            style={{ backgroundColor: comp.accentColor || '#0284c7' }}
                          >
                            {comp.logoUrl ? (
                              <img src={comp.logoUrl} alt="" className="w-7 h-7 object-contain" />
                            ) : (
                              comp.name.charAt(0)
                            )}
                          </div>
                          <div className="min-w-0">
                            <div className="font-bold text-slate-900 truncate">{comp.name}</div>
                            <div className="text-[10px] text-slate-400 flex items-center gap-1">
                              <span>Field Operations Workspace</span>
                              {(comp.hasAccessPassword || comp.accessPasswordHash || comp.accessCode) && (
                                <span className="text-amber-600 font-semibold flex items-center gap-0.5">
                                  · <KeyRound className="w-2.5 h-2.5" /> Requires Code
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <div>
                          {isAlreadyCurrent ? (
                            <span className="px-2.5 py-1 text-[11px] font-bold text-slate-400 bg-slate-100 rounded-lg">
                              Current
                            </span>
                          ) : existingReq ? (
                            <span className="px-2.5 py-1 text-[11px] font-bold text-amber-700 bg-amber-50 rounded-lg border border-amber-200">
                              Pending
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setSelectedCompany(comp)}
                              className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 transition-colors shadow-xs"
                            >
                              <span>Request to Join</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          ) : (
            /* Selected Company Application Form */
            <form onSubmit={handleSubmitRequest} className="space-y-3.5 bg-sky-50/50 p-4 rounded-2xl border border-sky-100">
              <div className="flex items-center justify-between pb-2 border-b border-sky-200/60">
                <div className="flex items-center gap-2">
                  <div
                    className="w-7 h-7 rounded-lg text-white font-bold flex items-center justify-center text-xs"
                    style={{ backgroundColor: selectedCompany.accentColor || '#0284c7' }}
                  >
                    {selectedCompany.name.charAt(0)}
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px]">Joining: </span>
                    <strong className="text-slate-900">{selectedCompany.name}</strong>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedCompany(null)}
                  className="text-xs text-sky-600 hover:text-sky-800 font-bold"
                >
                  Change
                </button>
              </div>

              {(selectedCompany.hasAccessPassword || selectedCompany.accessPasswordHash || selectedCompany.accessCode) && (
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    Company Access Code / Organization Password *
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      placeholder="Enter company access code provided by your admin"
                      value={accessCodeInput}
                      onChange={(e) => setAccessCodeInput(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono uppercase focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-800 mb-1">Your Contact Phone</label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    placeholder="e.g. +1 (555) 019-2834"
                    value={phoneInput}
                    onChange={(e) => setPhoneInput(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  Introduction / Qualification Note
                </label>
                <textarea
                  rows={3}
                  placeholder="Introduce yourself to the company manager (e.g. Certified field technician with 4 years HVAC / electrical experience)..."
                  value={notesInput}
                  onChange={(e) => setNotesInput(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setSelectedCompany(null)}
                  className="px-4 py-2 border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-xl text-xs"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Submitting...' : 'Send Join Request'}</span>
                </button>
              </div>
            </form>
          )}

          {/* Section 2: My Pending & Past Requests */}
          <div className="pt-2 border-t border-slate-100 space-y-2.5">
            <div className="font-bold text-slate-800 flex items-center justify-between">
              <span>My Join Requests</span>
              <button
                type="button"
                onClick={fetchCompaniesAndRequests}
                className="text-[10px] text-sky-600 hover:text-sky-800 font-semibold flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" /> Refresh
              </button>
            </div>

            {myRequests.length === 0 ? (
              <div className="p-4 bg-slate-50 rounded-2xl text-center text-slate-400 text-xs">
                You have not submitted any company join requests yet.
              </div>
            ) : (
              <div className="space-y-2">
                {myRequests.map((req) => (
                  <div
                    key={req.id}
                    className="p-3 bg-white border border-slate-200 rounded-2xl flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="font-bold text-slate-900">{req.orgName}</div>
                      <div className="text-[10px] text-slate-400">
                        Requested: {new Date(req.requestedAt).toLocaleDateString()}
                      </div>
                      {req.rejectionReason && (
                        <div className="text-[10px] text-rose-600 mt-0.5">
                          Reason: {req.rejectionReason}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {req.status === 'pending' && (
                        <>
                          <span className="px-2.5 py-1 text-[10px] font-bold rounded-lg bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-1">
                            <Clock className="w-3 h-3" /> Pending Review
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCancelRequest(req.id, req.orgName)}
                            className="px-2 py-1 text-[10px] font-bold text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          >
                            Cancel
                          </button>
                        </>
                      )}
                      {req.status === 'approved' && (
                        <span className="px-2.5 py-1 text-[10px] font-bold rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Approved
                        </span>
                      )}
                      {req.status === 'rejected' && (
                        <span className="px-2.5 py-1 text-[10px] font-bold rounded-lg bg-rose-50 text-rose-700 border border-rose-200 flex items-center gap-1">
                          <XCircle className="w-3 h-3" /> Rejected
                        </span>
                      )}
                      {req.status === 'cancelled' && (
                        <span className="px-2.5 py-1 text-[10px] font-bold rounded-lg bg-slate-100 text-slate-500">
                          Cancelled
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
