/// <reference types="@types/google.maps" />
import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import {
  MapPin,
  Navigation,
  Compass,
  Clock,
  Battery,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  Layers,
  Activity,
  X,
  Crosshair,
  Footprints,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  Map as MapIcon,
  ChevronDown,
  ChevronUp,
  Zap,
  Route as RouteIcon,
  ArrowRight,
  Car,
  Sparkles,
} from 'lucide-react';
import { collection, query, where, getDocs, onSnapshot } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { LocationHistoryPoint, AttendanceRecord, FieldVisit } from '../../types/index.ts';
import {
  subscribeTrackerState,
  TrackerState,
  calculateDistanceMeters,
  formatRelativeTime,
  logMilestoneLocation,
} from '../../utils/locationTracker.ts';
import {
  loadGoogleMapsScript,
  GOOGLE_MAPS_API_KEY,
  GOOGLE_MAPS_TILE_PROVIDERS,
} from '../../utils/googleMapsLoader.ts';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface RealTimeGpsTrackingProps {
  onClose?: () => void;
  isModal?: boolean;
}

export interface OptimizedStopLeg {
  fromName: string;
  toVisit: FieldVisit;
  distanceMeters: number;
  durationMinutes: number;
}

export interface OptimizedRoutePlan {
  stops: FieldVisit[];
  totalDistanceMeters: number;
  totalDurationMinutes: number;
  legs: OptimizedStopLeg[];
  distanceSavedMeters: number;
  percentSaved: number;
  isGoogleDirections: boolean;
}

export const RealTimeGpsTracking: React.FC<RealTimeGpsTrackingProps> = ({
  onClose,
  isModal = false,
}) => {
  const { currentEmployee, currentOrg, userProfile } = useAuth();
  const employeeId = currentEmployee?.id || userProfile?.employeeId || 'emp-101';
  const employeeName = currentEmployee?.name || userProfile?.displayName || 'Technician';
  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);

  // Tracker state from browser geolocation watcher
  const [trackerState, setTrackerState] = useState<TrackerState>({
    isTracking: false,
    permissionStatus: 'prompt',
    lastCoords: null,
    lastUpdate: null,
    errorMessage: null,
  });

  // Today's route history points from Firestore
  const [historyPoints, setHistoryPoints] = useState<LocationHistoryPoint[]>([]);
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord | null>(null);
  const [todayVisits, setTodayVisits] = useState<FieldVisit[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPoint, setSelectedPoint] = useState<LocationHistoryPoint | null>(null);
  const [selectedVisitStop, setSelectedVisitStop] = useState<FieldVisit | null>(null);

  // Map engine & view state
  const [mapEngine, setMapEngine] = useState<'google' | 'leaflet'>('google');
  const [mapType, setMapType] = useState<'roadmap' | 'satellite' | 'terrain'>('roadmap');
  const [routeViewMode, setRouteViewMode] = useState<'all' | 'history' | 'optimized'>('all');
  const [activeBottomTab, setActiveBottomTab] = useState<'optimized' | 'history'>('optimized');
  const [isTimelineExpanded, setIsTimelineExpanded] = useState(true);
  const [waypointNote, setWaypointNote] = useState('');
  const [isLoggingWaypoint, setIsLoggingWaypoint] = useState(false);
  const [logSuccessMessage, setLogSuccessMessage] = useState<string | null>(null);

  // Route Optimization state
  const [optimizedPlan, setOptimizedPlan] = useState<OptimizedRoutePlan | null>(null);
  const [isCalculatingRoute, setIsCalculatingRoute] = useState(false);

  // References for Google Maps
  const googleMapContainerRef = useRef<HTMLDivElement | null>(null);
  const googleMapInstanceRef = useRef<google.maps.Map | null>(null);
  const googleCurrentMarkerRef = useRef<google.maps.Marker | null>(null);
  const googleAccuracyCircleRef = useRef<google.maps.Circle | null>(null);
  const googleHistoryPolylineRef = useRef<google.maps.Polyline | null>(null);
  const googleOptimizedPolylineRef = useRef<google.maps.Polyline | null>(null);
  const googleDirectionsRendererRef = useRef<google.maps.DirectionsRenderer | null>(null);
  const googleHistoryMarkersRef = useRef<google.maps.Marker[]>([]);
  const googleOptimizedMarkersRef = useRef<google.maps.Marker[]>([]);

  // References for Leaflet Fallback
  const leafletMapContainerRef = useRef<HTMLDivElement | null>(null);
  const leafletMapInstanceRef = useRef<L.Map | null>(null);
  const leafletHistoryPolylineRef = useRef<L.Polyline | null>(null);
  const leafletOptimizedPolylineRef = useRef<L.Polyline | null>(null);
  const leafletHistoryMarkersLayerRef = useRef<L.LayerGroup | null>(null);
  const leafletOptimizedMarkersLayerRef = useRef<L.LayerGroup | null>(null);
  const leafletTileLayersRef = useRef<{ [key: string]: L.TileLayer }>({});

  // 1. Subscribe to Live GPS tracker state
  useEffect(() => {
    const unsub = subscribeTrackerState((st) => {
      setTrackerState(st);
    });
    return () => unsub();
  }, []);

  // 2. Fetch today's route data and visits from Firestore
  useEffect(() => {
    if (!currentOrg || !employeeId) return;
    setLoading(true);

    // Query today's attendance record
    const attQuery = query(
      collection(db, 'attendance'),
      where('orgId', '==', currentOrg.id),
      where('employeeId', '==', employeeId),
      where('date', '==', todayStr)
    );
    getDocs(attQuery)
      .then((snap) => {
        if (!snap.empty) {
          setTodayAttendance(snap.docs[0].data() as AttendanceRecord);
        }
      })
      .catch((e) => console.warn('Attendance load error:', e));

    // Query today's visits
    const visitsQuery = query(
      collection(db, 'visits'),
      where('orgId', '==', currentOrg.id),
      where('assignedEmployeeId', '==', employeeId),
      where('scheduledDate', '==', todayStr)
    );
    getDocs(visitsQuery)
      .then((snap) => {
        const vList: FieldVisit[] = [];
        snap.forEach((d) => vList.push(d.data() as FieldVisit));
        setTodayVisits(vList);
      })
      .catch((e) => console.warn('Visits load error:', e));

    // Real-time location history listener for today
    const historyQuery = query(
      collection(db, 'location_history'),
      where('orgId', '==', currentOrg.id),
      where('employeeId', '==', employeeId)
    );

    const unsubscribeHistory = onSnapshot(
      historyQuery,
      (snap) => {
        const list: LocationHistoryPoint[] = [];
        snap.forEach((d) => {
          const pt = d.data() as LocationHistoryPoint;
          if (pt.timestamp && pt.timestamp.startsWith(todayStr)) {
            list.push(pt);
          }
        });

        // Sort chronologically ascending
        list.sort((a, b) => a.timestamp.localeCompare(b.timestamp));
        setHistoryPoints(list);
        setLoading(false);
      },
      (err) => {
        console.warn('Location history listener error:', err);
        setLoading(false);
      }
    );

    return () => {
      unsubscribeHistory();
    };
  }, [currentOrg, employeeId, todayStr]);

  // Filter pending visits for today (scheduled, en_route, or in_progress)
  const pendingVisits = useMemo(() => {
    return todayVisits.filter(
      (v) =>
        (v.status === 'scheduled' || v.status === 'en_route' || v.status === 'in_progress') &&
        typeof v.lat === 'number' &&
        typeof v.lng === 'number'
    );
  }, [todayVisits]);

  // Combine route points: include check-in point if not already in history
  const combinedRoutePoints = useMemo(() => {
    const pts = [...historyPoints];

    if (
      todayAttendance?.checkInLat &&
      todayAttendance?.checkInLng &&
      !pts.some((p) => p.eventType === 'check_in')
    ) {
      pts.unshift({
        id: `att_start_${todayAttendance.id}`,
        orgId: todayAttendance.orgId,
        employeeId: todayAttendance.employeeId,
        employeeName: todayAttendance.employeeName,
        lat: todayAttendance.checkInLat,
        lng: todayAttendance.checkInLng,
        eventType: 'check_in',
        notes: todayAttendance.checkInAddress || 'Shift Start Check-In',
        timestamp: todayAttendance.checkInTime,
      });
    }

    if (trackerState.lastCoords) {
      const lastPt = pts[pts.length - 1];
      const distFromLast = lastPt
        ? calculateDistanceMeters(
            lastPt.lat,
            lastPt.lng,
            trackerState.lastCoords.lat,
            trackerState.lastCoords.lng
          )
        : 999;

      if (distFromLast > 20) {
        pts.push({
          id: 'live_transient_current',
          orgId: currentOrg?.id || '',
          employeeId,
          employeeName,
          lat: trackerState.lastCoords.lat,
          lng: trackerState.lastCoords.lng,
          accuracy: trackerState.lastCoords.accuracy,
          eventType: 'shift_active',
          notes: 'Current Live GPS Location',
          timestamp: trackerState.lastUpdate || new Date().toISOString(),
        });
      }
    }

    return pts;
  }, [historyPoints, todayAttendance, trackerState.lastCoords, trackerState.lastUpdate, currentOrg?.id, employeeId, employeeName]);

  // Calculate total past route distance
  const totalDistanceMeters = useMemo(() => {
    if (combinedRoutePoints.length < 2) return 0;
    let dist = 0;
    for (let i = 0; i < combinedRoutePoints.length - 1; i++) {
      dist += calculateDistanceMeters(
        combinedRoutePoints[i].lat,
        combinedRoutePoints[i].lng,
        combinedRoutePoints[i + 1].lat,
        combinedRoutePoints[i + 1].lng
      );
    }
    return dist;
  }, [combinedRoutePoints]);

  const totalDistanceKm = (totalDistanceMeters / 1000).toFixed(2);
  const totalDistanceMiles = (totalDistanceMeters * 0.000621371).toFixed(2);

  // Center coordinate determination
  const defaultCenter = useMemo<{ lat: number; lng: number }>(() => {
    if (trackerState.lastCoords) {
      return { lat: trackerState.lastCoords.lat, lng: trackerState.lastCoords.lng };
    }
    if (combinedRoutePoints.length > 0) {
      const last = combinedRoutePoints[combinedRoutePoints.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    if (pendingVisits.length > 0 && pendingVisits[0].lat && pendingVisits[0].lng) {
      return { lat: pendingVisits[0].lat, lng: pendingVisits[0].lng };
    }
    return { lat: 37.7749, lng: -122.4194 }; // Default San Francisco
  }, [trackerState.lastCoords, combinedRoutePoints, pendingVisits]);

  // ---------------------------------------------------------------------------
  // EFFICIENT ROUTE CALCULATION (TSP Nearest-Neighbor + 2-Opt & Google Directions)
  // ---------------------------------------------------------------------------
  const calculateOptimizedRoute = useCallback(async () => {
    if (pendingVisits.length === 0) {
      setOptimizedPlan(null);
      return;
    }

    setIsCalculatingRoute(true);

    const startPos = trackerState.lastCoords
      ? { lat: trackerState.lastCoords.lat, lng: trackerState.lastCoords.lng, name: 'Current Location' }
      : defaultCenter
      ? { lat: defaultCenter.lat, lng: defaultCenter.lng, name: 'Current Depot' }
      : { lat: 37.7749, lng: -122.4194, name: 'Dispatch Center' };

    // 1. Algorithmic TSP Optimization (Nearest Neighbor with 2-Opt refinement)
    const unvisited = [...pendingVisits];
    const ordered: FieldVisit[] = [];
    let currentLat = startPos.lat;
    let currentLng = startPos.lng;

    while (unvisited.length > 0) {
      let closestIdx = 0;
      let closestDist = Infinity;
      for (let i = 0; i < unvisited.length; i++) {
        const d = calculateDistanceMeters(currentLat, currentLng, unvisited[i].lat!, unvisited[i].lng!);
        if (d < closestDist) {
          closestDist = d;
          closestIdx = i;
        }
      }
      const nextVisit = unvisited.splice(closestIdx, 1)[0];
      ordered.push(nextVisit);
      currentLat = nextVisit.lat!;
      currentLng = nextVisit.lng!;
    }

    // 2-Opt pairwise improvement
    let improved = true;
    let iterations = 0;
    while (improved && iterations < 30 && ordered.length > 2) {
      improved = false;
      iterations++;
      for (let i = 0; i < ordered.length - 1; i++) {
        for (let k = i + 1; k < ordered.length; k++) {
          const prevLat = i === 0 ? startPos.lat : ordered[i - 1].lat!;
          const prevLng = i === 0 ? startPos.lng : ordered[i - 1].lng!;

          const currentDist =
            calculateDistanceMeters(prevLat, prevLng, ordered[i].lat!, ordered[i].lng!) +
            (k + 1 < ordered.length
              ? calculateDistanceMeters(ordered[k].lat!, ordered[k].lng!, ordered[k + 1].lat!, ordered[k + 1].lng!)
              : 0);

          const swappedDist =
            calculateDistanceMeters(prevLat, prevLng, ordered[k].lat!, ordered[k].lng!) +
            (k + 1 < ordered.length
              ? calculateDistanceMeters(ordered[i].lat!, ordered[i].lng!, ordered[k + 1].lat!, ordered[k + 1].lng!)
              : 0);

          if (swappedDist < currentDist - 10) {
            const sub = ordered.slice(i, k + 1).reverse();
            ordered.splice(i, k - i + 1, ...sub);
            improved = true;
          }
        }
      }
    }

    // Naive distance calculation (unoptimized order)
    let naiveDist = 0;
    let nLat = startPos.lat;
    let nLng = startPos.lng;
    for (const v of pendingVisits) {
      naiveDist += calculateDistanceMeters(nLat, nLng, v.lat!, v.lng!);
      nLat = v.lat!;
      nLng = v.lng!;
    }

    // Build leg details
    const legs: OptimizedStopLeg[] = [];
    let totalDist = 0;
    let prevName = startPos.name;
    let pLat = startPos.lat;
    let pLng = startPos.lng;

    for (const visit of ordered) {
      const legDist = calculateDistanceMeters(pLat, pLng, visit.lat!, visit.lng!);
      totalDist += legDist;
      // Approx 30-35 km/h urban speed with traffic factor (1.8 mins per km)
      const legDuration = Math.max(3, Math.round((legDist / 1000) * 1.85));

      legs.push({
        fromName: prevName,
        toVisit: visit,
        distanceMeters: legDist,
        durationMinutes: legDuration,
      });

      pLat = visit.lat!;
      pLng = visit.lng!;
      prevName = visit.customerName;
    }

    const totalDurationMinutes = legs.reduce((acc, l) => acc + l.durationMinutes, 0);
    const distanceSaved = Math.max(0, naiveDist - totalDist);
    const percentSaved = naiveDist > 0 ? Math.round((distanceSaved / naiveDist) * 100) : 0;

    let isGoogleDirections = false;

    // 2. Try Google Maps DirectionsService for true road routing
    if (
      typeof window !== 'undefined' &&
      (window as any).google?.maps &&
      googleMapInstanceRef.current &&
      ordered.length > 0
    ) {
      try {
        const directionsService = new (window as any).google.maps.DirectionsService();
        const origin = { lat: startPos.lat, lng: startPos.lng };
        const destination = { lat: ordered[ordered.length - 1].lat!, lng: ordered[ordered.length - 1].lng! };

        const waypoints = ordered.slice(0, ordered.length - 1).map((v) => ({
          location: { lat: v.lat!, lng: v.lng! },
          stopover: true,
        }));

        const request: google.maps.DirectionsRequest = {
          origin,
          destination,
          waypoints,
          travelMode: (window as any).google.maps.TravelMode.DRIVING,
          optimizeWaypoints: false, // Already pre-optimized via TSP
        };

        const result: google.maps.DirectionsResult = await new Promise((res, rej) => {
          directionsService.route(request, (resObj: any, status: any) => {
            if (status === 'OK' && resObj) {
              res(resObj);
            } else {
              rej(new Error(status));
            }
          });
        });

        if (result && googleDirectionsRendererRef.current) {
          googleDirectionsRendererRef.current.setDirections(result);
          isGoogleDirections = true;
        }
      } catch (directionsErr) {
        console.info('Google Directions API fallback to optimized polyline:', directionsErr);
      }
    }

    setOptimizedPlan({
      stops: ordered,
      totalDistanceMeters: totalDist,
      totalDurationMinutes,
      legs,
      distanceSavedMeters: distanceSaved,
      percentSaved,
      isGoogleDirections,
    });

    setIsCalculatingRoute(false);
  }, [pendingVisits, trackerState.lastCoords, defaultCenter]);

  // Recalculate route whenever pending visits or live position change
  useEffect(() => {
    calculateOptimizedRoute();
  }, [pendingVisits.length, calculateOptimizedRoute]);

  // 3. Initialize Google Maps JavaScript SDK
  useEffect(() => {
    let isCancelled = false;

    loadGoogleMapsScript()
      .then(() => {
        if (isCancelled || !googleMapContainerRef.current) return;
        if (typeof window === 'undefined' || !(window as any).google?.maps) {
          setMapEngine('leaflet');
          return;
        }

        setMapEngine('google');

        if (!googleMapInstanceRef.current) {
          const map = new (window as any).google.maps.Map(googleMapContainerRef.current, {
            center: defaultCenter,
            zoom: 14,
            mapTypeId: mapType,
            mapTypeControl: false,
            streetViewControl: false,
            fullscreenControl: false,
            zoomControl: true,
            zoomControlOptions: {
              position: (window as any).google.maps.ControlPosition.RIGHT_CENTER,
            },
            styles: [
              {
                featureType: 'poi',
                elementType: 'labels.text',
                stylers: [{ visibility: 'simplified' }],
              },
            ],
          });

          // History Polyline (Sky blue)
          const historyPolyline = new (window as any).google.maps.Polyline({
            path: [],
            geodesic: true,
            strokeColor: '#0284c7', // Sky-600
            strokeOpacity: 0.85,
            strokeWeight: 4,
            map: map,
          });

          // Optimized Route Polyline (Purple)
          const optimizedPolyline = new (window as any).google.maps.Polyline({
            path: [],
            geodesic: true,
            strokeColor: '#7c3aed', // Purple-600
            strokeOpacity: 0.9,
            strokeWeight: 5,
            map: map,
          });

          // Directions Renderer for real road paths
          const directionsRenderer = new (window as any).google.maps.DirectionsRenderer({
            map: map,
            suppressMarkers: true,
            polylineOptions: {
              strokeColor: '#7c3aed',
              strokeWeight: 5,
              strokeOpacity: 0.9,
            },
          });

          // Accuracy radius circle
          const accuracyCircle = new (window as any).google.maps.Circle({
            map: map,
            fillColor: '#38bdf8',
            fillOpacity: 0.2,
            strokeColor: '#0284c7',
            strokeOpacity: 0.6,
            strokeWeight: 1,
            radius: 0,
          });

          googleMapInstanceRef.current = map;
          googleHistoryPolylineRef.current = historyPolyline;
          googleOptimizedPolylineRef.current = optimizedPolyline;
          googleDirectionsRendererRef.current = directionsRenderer;
          googleAccuracyCircleRef.current = accuracyCircle;
        }
      })
      .catch((err) => {
        console.warn('Google Maps script failed to load, falling back to Leaflet with Google Maps tiles:', err);
        setMapEngine('leaflet');
      });

    return () => {
      isCancelled = true;
    };
  }, []);

  // 4. Update Google Map Type when changed
  useEffect(() => {
    if (googleMapInstanceRef.current && (window as any).google?.maps) {
      googleMapInstanceRef.current.setMapTypeId(mapType);
    }
  }, [mapType]);

  // 5. Update Google Maps markers & polylines (History + Optimized Route)
  useEffect(() => {
    if (mapEngine !== 'google' || !googleMapInstanceRef.current || !(window as any).google?.maps) {
      return;
    }

    const gMap = googleMapInstanceRef.current;
    const gMaps = (window as any).google.maps;
    const bounds = new gMaps.LatLngBounds();

    // Clear previous history markers
    googleHistoryMarkersRef.current.forEach((m) => m.setMap(null));
    googleHistoryMarkersRef.current = [];

    // Clear previous optimized stop markers
    googleOptimizedMarkersRef.current.forEach((m) => m.setMap(null));
    googleOptimizedMarkersRef.current = [];

    // --- A. Render Past History Trail ---
    if (routeViewMode === 'all' || routeViewMode === 'history') {
      const pathCoords: { lat: number; lng: number }[] = combinedRoutePoints.map((pt) => ({
        lat: pt.lat,
        lng: pt.lng,
      }));

      if (googleHistoryPolylineRef.current) {
        googleHistoryPolylineRef.current.setPath(pathCoords);
        googleHistoryPolylineRef.current.setVisible(true);
      }

      combinedRoutePoints.forEach((pt, idx) => {
        const isStart = pt.eventType === 'check_in' || idx === 0;
        const isEnd = idx === combinedRoutePoints.length - 1;
        const isVisit = pt.eventType === 'visit_start' || pt.eventType === 'visit_complete';

        const color = isStart ? '#10b981' : isEnd ? '#ef4444' : isVisit ? '#8b5cf6' : '#0284c7';

        const marker = new gMaps.Marker({
          position: { lat: pt.lat, lng: pt.lng },
          map: gMap,
          title: `${pt.eventType || 'Waypoint'} - ${new Date(pt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
          icon: {
            path: gMaps.SymbolPath.CIRCLE,
            scale: isEnd ? 8 : 6,
            fillColor: color,
            fillOpacity: 0.9,
            strokeColor: '#ffffff',
            strokeWeight: 1.5,
          },
          zIndex: isEnd ? 80 : 10,
        });

        const timeStr = new Date(pt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const infoWindow = new gMaps.InfoWindow({
          content: `
            <div style="font-family: system-ui, sans-serif; padding: 4px 6px; max-width: 200px;">
              <div style="font-size: 10px; font-weight: bold; color: ${color}; text-transform: uppercase;">
                ${pt.eventType?.replace('_', ' ') || 'Point'}
              </div>
              <div style="font-size: 13px; font-weight: 700; color: #0f172a; margin-top: 1px;">
                ${timeStr}
              </div>
              ${pt.notes ? `<div style="font-size: 11px; color: #475569; margin-top: 2px;">${pt.notes}</div>` : ''}
              ${pt.accuracy ? `<div style="font-size: 10px; color: #94a3b8; margin-top: 1px;">±${pt.accuracy}m</div>` : ''}
            </div>
          `,
        });

        marker.addListener('click', () => {
          infoWindow.open(gMap, marker);
          setSelectedPoint(pt);
        });

        googleHistoryMarkersRef.current.push(marker);
        bounds.extend({ lat: pt.lat, lng: pt.lng });
      });
    } else {
      if (googleHistoryPolylineRef.current) {
        googleHistoryPolylineRef.current.setVisible(false);
      }
    }

    // --- B. Render Efficient Planned Route & Numbered Stop Pins ---
    if ((routeViewMode === 'all' || routeViewMode === 'optimized') && optimizedPlan) {
      // Connect current position to optimized stops
      const currentPos = trackerState.lastCoords
        ? { lat: trackerState.lastCoords.lat, lng: trackerState.lastCoords.lng }
        : defaultCenter;

      const optCoords: { lat: number; lng: number }[] = [
        currentPos,
        ...optimizedPlan.stops.map((v) => ({ lat: v.lat!, lng: v.lng! })),
      ];

      if (googleOptimizedPolylineRef.current) {
        // If Google Directions rendered the route, keep polyline as backup or hide
        if (!optimizedPlan.isGoogleDirections) {
          googleOptimizedPolylineRef.current.setPath(optCoords);
          googleOptimizedPolylineRef.current.setVisible(true);
        } else {
          googleOptimizedPolylineRef.current.setVisible(false);
        }
      }

      // Add Numbered Stop Markers (#1, #2, #3...)
      optimizedPlan.stops.forEach((visit, idx) => {
        const stopNum = idx + 1;
        const isNextStop = stopNum === 1;

        // Custom SVG Pin for stop
        const pinColor = isNextStop ? '#7c3aed' : '#9333ea';

        const marker = new gMaps.Marker({
          position: { lat: visit.lat!, lng: visit.lng! },
          map: gMap,
          title: `Stop #${stopNum}: ${visit.customerName}`,
          label: {
            text: String(stopNum),
            color: '#ffffff',
            fontWeight: 'bold',
            fontSize: '12px',
          },
          icon: {
            path: 'M 0,0 C -2,-20 -10,-22 -10,-30 A 10,10 0 1,1 10,-30 C 10,-22 2,-20 0,0 Z',
            fillColor: pinColor,
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
            scale: isNextStop ? 1.3 : 1.1,
            labelOrigin: new gMaps.Point(0, -30),
          },
          zIndex: 200 - idx,
        });

        const leg = optimizedPlan.legs[idx];
        const legDistanceKm = leg ? (leg.distanceMeters / 1000).toFixed(1) : '';
        const navUrl = `https://www.google.com/maps/dir/?api=1&origin=${currentPos.lat},${currentPos.lng}&destination=${visit.lat},${visit.lng}&travelmode=driving`;

        const infoWindow = new gMaps.InfoWindow({
          content: `
            <div style="font-family: system-ui, sans-serif; padding: 6px 8px; max-width: 220px;">
              <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px;">
                <span style="font-size: 11px; font-weight: 800; color: #7c3aed; text-transform: uppercase;">
                  Stop #${stopNum} ${isNextStop ? '(Next)' : ''}
                </span>
                <span style="font-size: 10px; font-weight: bold; background: #f3e8ff; color: #6b21a8; padding: 2px 6px; border-radius: 6px;">
                  ${visit.priority.toUpperCase()}
                </span>
              </div>
              <div style="font-size: 13px; font-weight: 700; color: #0f172a; margin-top: 2px;">
                ${visit.customerName}
              </div>
              <div style="font-size: 11px; color: #475569; margin-top: 2px;">
                ${visit.siteAddress}
              </div>
              <div style="margin-top: 6px; padding-top: 6px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #334155; display: flex; justify-content: space-between;">
                <span>Est. Travel:</span>
                <strong>${legDistanceKm} km (~${leg?.durationMinutes}m)</strong>
              </div>
              <a href="${navUrl}" target="_blank" rel="noopener noreferrer" style="display: block; margin-top: 8px; text-align: center; background: #7c3aed; color: #ffffff; padding: 6px 10px; border-radius: 8px; font-size: 11px; font-weight: bold; text-decoration: none;">
                Navigate in Google Maps &rarr;
              </a>
            </div>
          `,
        });

        marker.addListener('click', () => {
          infoWindow.open(gMap, marker);
          setSelectedVisitStop(visit);
        });

        googleOptimizedMarkersRef.current.push(marker);
        bounds.extend({ lat: visit.lat!, lng: visit.lng! });
      });
    } else {
      if (googleOptimizedPolylineRef.current) {
        googleOptimizedPolylineRef.current.setVisible(false);
      }
      if (googleDirectionsRendererRef.current) {
        googleDirectionsRendererRef.current.setMap(null);
        googleDirectionsRendererRef.current.setMap(gMap);
      }
    }

    // --- C. Current Live Location Marker ---
    if (trackerState.lastCoords) {
      const currentPos = { lat: trackerState.lastCoords.lat, lng: trackerState.lastCoords.lng };

      if (!googleCurrentMarkerRef.current) {
        googleCurrentMarkerRef.current = new gMaps.Marker({
          position: currentPos,
          map: gMap,
          title: `${employeeName} (Current Real-time Location)`,
          icon: {
            path: gMaps.SymbolPath.FORWARD_CLOSED_ARROW,
            scale: 5,
            fillColor: '#0284c7',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
            rotation: 0,
          },
          zIndex: 999,
        });
      } else {
        googleCurrentMarkerRef.current.setPosition(currentPos);
      }

      if (googleAccuracyCircleRef.current) {
        googleAccuracyCircleRef.current.setCenter(currentPos);
        googleAccuracyCircleRef.current.setRadius(trackerState.lastCoords.accuracy || 15);
      }

      bounds.extend(currentPos);
    }

    // Fit map bounds
    if (!bounds.isEmpty()) {
      gMap.fitBounds(bounds, 50);
    } else if (trackerState.lastCoords) {
      gMap.setCenter({ lat: trackerState.lastCoords.lat, lng: trackerState.lastCoords.lng });
    }
  }, [mapEngine, combinedRoutePoints, trackerState.lastCoords, employeeName, routeViewMode, optimizedPlan]);

  // 6. Initialize Leaflet Map Fallback
  useEffect(() => {
    if (mapEngine !== 'leaflet' || !leafletMapContainerRef.current) return;

    if (!leafletMapInstanceRef.current) {
      const map = L.map(leafletMapContainerRef.current, {
        center: [defaultCenter.lat, defaultCenter.lng],
        zoom: 14,
        zoomControl: true,
      });

      const roadmapLayer = L.tileLayer(GOOGLE_MAPS_TILE_PROVIDERS.roadmap.url, {
        attribution: GOOGLE_MAPS_TILE_PROVIDERS.roadmap.attribution,
        maxZoom: 20,
        subdomains: GOOGLE_MAPS_TILE_PROVIDERS.roadmap.subdomains,
      });

      const satelliteLayer = L.tileLayer(GOOGLE_MAPS_TILE_PROVIDERS.satellite.url, {
        attribution: GOOGLE_MAPS_TILE_PROVIDERS.satellite.attribution,
        maxZoom: 20,
        subdomains: GOOGLE_MAPS_TILE_PROVIDERS.satellite.subdomains,
      });

      roadmapLayer.addTo(map);
      leafletTileLayersRef.current = {
        roadmap: roadmapLayer,
        satellite: satelliteLayer,
      };

      const historyGroup = L.layerGroup().addTo(map);
      const optGroup = L.layerGroup().addTo(map);

      leafletHistoryMarkersLayerRef.current = historyGroup;
      leafletOptimizedMarkersLayerRef.current = optGroup;
      leafletMapInstanceRef.current = map;
    }

    const timer = setTimeout(() => {
      leafletMapInstanceRef.current?.invalidateSize();
    }, 250);

    return () => clearTimeout(timer);
  }, [mapEngine, defaultCenter]);

  // 7. Update Leaflet Fallback Markers & Polylines
  useEffect(() => {
    if (
      mapEngine !== 'leaflet' ||
      !leafletMapInstanceRef.current ||
      !leafletHistoryMarkersLayerRef.current ||
      !leafletOptimizedMarkersLayerRef.current
    ) {
      return;
    }

    const map = leafletMapInstanceRef.current;
    leafletHistoryMarkersLayerRef.current.clearLayers();
    leafletOptimizedMarkersLayerRef.current.clearLayers();

    if (leafletHistoryPolylineRef.current) {
      leafletHistoryPolylineRef.current.remove();
      leafletHistoryPolylineRef.current = null;
    }
    if (leafletOptimizedPolylineRef.current) {
      leafletOptimizedPolylineRef.current.remove();
      leafletOptimizedPolylineRef.current = null;
    }

    const allLatLngs: [number, number][] = [];

    // History trail
    if (routeViewMode === 'all' || routeViewMode === 'history') {
      const historyCoords: [number, number][] = combinedRoutePoints.map((pt) => [pt.lat, pt.lng]);
      allLatLngs.push(...historyCoords);

      if (historyCoords.length > 1) {
        leafletHistoryPolylineRef.current = L.polyline(historyCoords, {
          color: '#0284c7',
          weight: 4,
          opacity: 0.85,
          dashArray: '4, 4',
        }).addTo(map);
      }

      combinedRoutePoints.forEach((pt, idx) => {
        const isStart = pt.eventType === 'check_in' || idx === 0;
        const isEnd = idx === combinedRoutePoints.length - 1;
        const isVisit = pt.eventType === 'visit_start' || pt.eventType === 'visit_complete';
        const color = isStart ? '#10b981' : isEnd ? '#ef4444' : isVisit ? '#8b5cf6' : '#0284c7';
        const label = isStart ? 'S' : isEnd ? 'E' : isVisit ? 'V' : String(idx + 1);

        const customIcon = L.divIcon({
          className: 'gps-history-marker',
          html: `
            <div style="background-color: ${color}; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 10px; border: 2px solid white; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3);">
              ${label}
            </div>
          `,
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        });

        const marker = L.marker([pt.lat, pt.lng], { icon: customIcon });
        marker.on('click', () => setSelectedPoint(pt));
        leafletHistoryMarkersLayerRef.current?.addLayer(marker);
      });
    }

    // Optimized stops
    if ((routeViewMode === 'all' || routeViewMode === 'optimized') && optimizedPlan) {
      const currentPos = trackerState.lastCoords
        ? [trackerState.lastCoords.lat, trackerState.lastCoords.lng] as [number, number]
        : [defaultCenter.lat, defaultCenter.lng] as [number, number];

      const optCoords: [number, number][] = [
        currentPos,
        ...optimizedPlan.stops.map((v) => [v.lat!, v.lng!] as [number, number]),
      ];
      allLatLngs.push(...optCoords);

      if (optCoords.length > 1) {
        leafletOptimizedPolylineRef.current = L.polyline(optCoords, {
          color: '#7c3aed',
          weight: 5,
          opacity: 0.9,
        }).addTo(map);
      }

      optimizedPlan.stops.forEach((visit, idx) => {
        const stopNum = idx + 1;
        const icon = L.divIcon({
          className: 'gps-opt-marker',
          html: `
            <div style="background-color: #7c3aed; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 800; font-size: 12px; border: 2px solid white; box-shadow: 0 4px 10px rgba(124, 58, 237, 0.5);">
              ${stopNum}
            </div>
          `,
          iconSize: [28, 28],
          iconAnchor: [14, 14],
        });

        const marker = L.marker([visit.lat!, visit.lng!], { icon });
        marker.on('click', () => setSelectedVisitStop(visit));
        leafletOptimizedMarkersLayerRef.current?.addLayer(marker);
      });
    }

    if (allLatLngs.length > 1) {
      map.fitBounds(L.latLngBounds(allLatLngs), { padding: [40, 40] });
    }
  }, [mapEngine, combinedRoutePoints, trackerState.lastCoords, routeViewMode, optimizedPlan, defaultCenter]);

  // Recenter map on current location
  const handleRecenter = () => {
    if (trackerState.lastCoords) {
      const { lat, lng } = trackerState.lastCoords;
      if (mapEngine === 'google' && googleMapInstanceRef.current) {
        googleMapInstanceRef.current.panTo({ lat, lng });
        googleMapInstanceRef.current.setZoom(16);
      } else if (mapEngine === 'leaflet' && leafletMapInstanceRef.current) {
        leafletMapInstanceRef.current.setView([lat, lng], 16, { animate: true });
      }
    } else if (combinedRoutePoints.length > 0) {
      const last = combinedRoutePoints[combinedRoutePoints.length - 1];
      if (mapEngine === 'google' && googleMapInstanceRef.current) {
        googleMapInstanceRef.current.panTo({ lat: last.lat, lng: last.lng });
        googleMapInstanceRef.current.setZoom(15);
      }
    }
  };

  // Pan to a selected waypoint
  const handleSelectWaypoint = (pt: LocationHistoryPoint) => {
    setSelectedPoint(pt);
    setSelectedVisitStop(null);
    if (mapEngine === 'google' && googleMapInstanceRef.current) {
      googleMapInstanceRef.current.panTo({ lat: pt.lat, lng: pt.lng });
      googleMapInstanceRef.current.setZoom(16);
    } else if (mapEngine === 'leaflet' && leafletMapInstanceRef.current) {
      leafletMapInstanceRef.current.setView([pt.lat, pt.lng], 16, { animate: true });
    }
  };

  // Pan to a selected optimized visit stop
  const handleSelectOptimizedStop = (visit: FieldVisit) => {
    setSelectedVisitStop(visit);
    setSelectedPoint(null);
    if (mapEngine === 'google' && googleMapInstanceRef.current) {
      googleMapInstanceRef.current.panTo({ lat: visit.lat!, lng: visit.lng! });
      googleMapInstanceRef.current.setZoom(16);
    } else if (mapEngine === 'leaflet' && leafletMapInstanceRef.current) {
      leafletMapInstanceRef.current.setView([visit.lat!, visit.lng!], 16, { animate: true });
    }
  };

  // Drop an instant waypoint breadcrumb with notes
  const handleDropWaypoint = async () => {
    if (!currentOrg || isLoggingWaypoint) return;
    setIsLoggingWaypoint(true);
    try {
      await logMilestoneLocation({
        orgId: currentOrg.id,
        employeeId,
        employeeName,
        eventType: 'waypoint',
        notes: waypointNote.trim() || 'Manual field GPS checkpoint',
        lat: trackerState.lastCoords?.lat,
        lng: trackerState.lastCoords?.lng,
        accuracy: trackerState.lastCoords?.accuracy,
      });
      setWaypointNote('');
      setLogSuccessMessage('GPS checkpoint recorded to route!');
      setTimeout(() => setLogSuccessMessage(null), 3500);
    } catch (e) {
      console.error('Failed to log waypoint:', e);
    } finally {
      setIsLoggingWaypoint(false);
    }
  };

  return (
    <div
      className={`bg-white flex flex-col ${
        isModal
          ? 'fixed inset-0 z-50 overflow-hidden'
          : 'rounded-2xl border border-slate-200 shadow-sm overflow-hidden'
      }`}
    >
      {/* Top Header */}
      <div className="bg-slate-900 text-white px-4 py-3 flex items-center justify-between shadow-md z-10 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-400/30 flex items-center justify-center">
            <RouteIcon className="w-4 h-4 animate-pulse text-purple-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white tracking-tight">Real-time GPS Tracking</h2>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30 font-mono">
                Route Optimizer
              </span>
            </div>
            <div className="text-[11px] text-slate-300 flex items-center gap-1.5">
              <span>{employeeName}</span>
              <span>•</span>
              <span>{pendingVisits.length} Pending Visits</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Map Layer Switcher */}
          <div className="flex bg-slate-800 p-0.5 rounded-lg border border-slate-700 text-[11px]">
            <button
              onClick={() => setMapType('roadmap')}
              className={`px-2 py-1 rounded font-medium transition-colors ${
                mapType === 'roadmap' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Map
            </button>
            <button
              onClick={() => setMapType('satellite')}
              className={`px-2 py-1 rounded font-medium transition-colors ${
                mapType === 'satellite' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Satellite
            </button>
            <button
              onClick={() => setMapType('terrain')}
              className={`px-2 py-1 rounded font-medium transition-colors ${
                mapType === 'terrain' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Terrain
            </button>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Close GPS Tracker"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Route Mode Switcher & Recalculate Bar */}
      <div className="bg-slate-900 border-t border-slate-800 px-3 py-1.5 flex items-center justify-between text-xs text-slate-300 gap-2 overflow-x-auto">
        <div className="flex items-center gap-1 bg-slate-800/80 p-0.5 rounded-xl border border-slate-700 text-[11px] shrink-0">
          <button
            onClick={() => setRouteViewMode('all')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
              routeViewMode === 'all'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All Paths
          </button>
          <button
            onClick={() => setRouteViewMode('optimized')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-all flex items-center gap-1 ${
              routeViewMode === 'optimized'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'text-purple-300 hover:text-white'
            }`}
          >
            <Zap className="w-3 h-3 text-amber-300" />
            <span>Efficient Plan</span>
          </button>
          <button
            onClick={() => setRouteViewMode('history')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
              routeViewMode === 'history'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Past Breadcrumbs
          </button>
        </div>

        <button
          onClick={calculateOptimizedRoute}
          disabled={isCalculatingRoute || pendingVisits.length === 0}
          className="flex items-center gap-1 px-2.5 py-1 bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-500/40 rounded-xl text-[11px] font-bold transition-colors active:scale-95 disabled:opacity-50 shrink-0"
          title="Recalculate most efficient route from current GPS position"
        >
          <RefreshCw className={`w-3 h-3 ${isCalculatingRoute ? 'animate-spin' : ''}`} />
          <span>{isCalculatingRoute ? 'Optimizing...' : 'Recalculate Route'}</span>
        </button>
      </div>

      {/* Real-time Telemetry Bar */}
      <div className="bg-slate-50 border-b border-slate-200 px-3 py-2 flex items-center justify-between text-xs shrink-0 flex-wrap gap-2">
        <div className="flex items-center gap-3">
          {trackerState.isTracking ? (
            <div className="flex items-center gap-1.5 text-emerald-700 font-bold bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              <span>Live Streaming</span>
              {trackerState.lastCoords?.accuracy && (
                <span className="text-[10px] text-emerald-800 font-normal">
                  (±{trackerState.lastCoords.accuracy}m)
                </span>
              )}
            </div>
          ) : trackerState.permissionStatus === 'denied' ? (
            <div className="flex items-center gap-1 text-amber-700 font-bold bg-amber-50 px-2 py-1 rounded-lg border border-amber-200">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>GPS Blocked</span>
            </div>
          ) : (
            <div className="flex items-center gap-1 text-slate-600 font-medium bg-white px-2 py-1 rounded-lg border border-slate-200">
              <span className="w-2 h-2 rounded-full bg-slate-400" />
              <span>Standby</span>
            </div>
          )}

          {trackerState.lastUpdate && (
            <div className="text-[11px] text-slate-500 flex items-center gap-1">
              <Clock className="w-3 h-3 text-slate-400" />
              <span>Updated {formatRelativeTime(trackerState.lastUpdate)}</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRecenter}
            className="flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-sky-50 text-sky-700 border border-slate-200 hover:border-sky-300 rounded-lg font-bold text-[11px] transition-colors shadow-2xs"
          >
            <Crosshair className="w-3.5 h-3.5 text-sky-600" />
            <span>Recenter</span>
          </button>
        </div>
      </div>

      {/* Map Viewport Area */}
      <div className="relative flex-1 min-h-[300px] w-full bg-slate-100 overflow-hidden">
        {/* Google Maps Container */}
        <div
          ref={googleMapContainerRef}
          className={`w-full h-full ${mapEngine === 'google' ? 'block' : 'hidden'}`}
          style={{ minHeight: '320px' }}
        />

        {/* Leaflet Fallback Container */}
        <div
          ref={leafletMapContainerRef}
          className={`w-full h-full ${mapEngine === 'leaflet' ? 'block' : 'hidden'}`}
          style={{ minHeight: '320px' }}
        />

        {/* Floating Route Efficiency Banner (Top Left) */}
        {optimizedPlan && (
          <div className="absolute top-3 left-3 z-10 bg-white/95 backdrop-blur-sm border border-purple-200 shadow-lg rounded-2xl p-2.5 text-xs space-y-1.5 max-w-[230px] animate-in fade-in-0">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-purple-700 tracking-wider flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-500 fill-amber-400" />
                <span>Efficient Plan</span>
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.2 bg-purple-100 text-purple-800 rounded-full">
                {optimizedPlan.stops.length} Stops
              </span>
            </div>

            <div className="flex items-baseline gap-2">
              <div className="flex items-baseline gap-1">
                <span className="text-base font-black text-slate-900">
                  {(optimizedPlan.totalDistanceMeters / 1000).toFixed(1)}
                </span>
                <span className="text-[10px] text-slate-500 font-bold">KM</span>
              </div>
              <span className="text-slate-300">•</span>
              <div className="flex items-baseline gap-1">
                <span className="text-base font-black text-slate-900">
                  ~{optimizedPlan.totalDurationMinutes}
                </span>
                <span className="text-[10px] text-slate-500 font-bold">MINS</span>
              </div>
            </div>

            {optimizedPlan.percentSaved > 0 && (
              <div className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200 font-bold flex items-center gap-1">
                <TrendingUp className="w-3 h-3 text-emerald-600" />
                <span>Saves ~{(optimizedPlan.distanceSavedMeters / 1000).toFixed(1)} km ({optimizedPlan.percentSaved}%)</span>
              </div>
            )}

            {optimizedPlan.stops.length > 0 && (
              <div className="pt-1 border-t border-slate-100 text-[10px] text-slate-600 truncate">
                <span className="font-bold text-purple-700">Next: </span>
                <span>{optimizedPlan.stops[0].customerName}</span>
              </div>
            )}
          </div>
        )}

        {/* Floating Map Legend (Top Right) */}
        <div className="absolute top-3 right-3 z-10 bg-white/90 backdrop-blur-xs rounded-xl p-2 border border-slate-200 text-[10px] space-y-1 shadow-sm hidden sm:block">
          <div className="flex items-center gap-1.5 text-slate-700">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
            <span>Past Breadcrumbs</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-700 font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-600" />
            <span>Optimized Route</span>
          </div>
        </div>

        {/* Floating Controls (Bottom Right) */}
        <div className="absolute bottom-4 right-3 z-10 flex flex-col gap-2">
          <button
            onClick={handleRecenter}
            className="w-10 h-10 bg-white rounded-xl shadow-lg border border-slate-200 flex items-center justify-center text-slate-700 hover:text-sky-600 hover:bg-sky-50 active:scale-95 transition-all"
            title="Recenter on My Location"
          >
            <Crosshair className="w-5 h-5 text-sky-600" />
          </button>
        </div>

        {/* Selected Visit Stop Popover */}
        {selectedVisitStop && (
          <div className="absolute bottom-3 left-3 right-16 z-20 bg-white/95 backdrop-blur-md rounded-2xl p-3 shadow-xl border border-purple-200 animate-in fade-in-0">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700 bg-purple-100 px-1.5 py-0.5 rounded-md">
                    Stop #{optimizedPlan?.stops.findIndex((s) => s.id === selectedVisitStop.id)! + 1 || 'Visit'}
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md uppercase bg-slate-100 text-slate-700">
                    {selectedVisitStop.priority}
                  </span>
                </div>
                <div className="text-xs font-bold text-slate-900 mt-1">
                  {selectedVisitStop.customerName}
                </div>
                <p className="text-[11px] text-slate-600 truncate">{selectedVisitStop.siteAddress}</p>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  Scheduled: {selectedVisitStop.scheduledTime}
                </div>
              </div>
              <button
                onClick={() => setSelectedVisitStop(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[10px] text-slate-500 font-medium">Ready for dispatch</span>
              <a
                href={`https://www.google.com/maps/dir/?api=1&destination=${selectedVisitStop.lat},${selectedVisitStop.lng}&travelmode=driving`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors"
              >
                <Car className="w-3 h-3" />
                <span>Navigate</span>
              </a>
            </div>
          </div>
        )}

        {/* Selected Waypoint Popover */}
        {selectedPoint && !selectedVisitStop && (
          <div className="absolute bottom-3 left-3 right-16 z-20 bg-white/95 backdrop-blur-md rounded-2xl p-3 shadow-xl border border-sky-200 animate-in fade-in-0">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-sky-600">
                  {selectedPoint.eventType?.replace('_', ' ') || 'Waypoint'}
                </span>
                <div className="text-xs font-bold text-slate-900">
                  {new Date(selectedPoint.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
                {selectedPoint.notes && (
                  <p className="text-[11px] text-slate-600 mt-0.5 line-clamp-2">{selectedPoint.notes}</p>
                )}
                <div className="text-[10px] text-slate-400 font-mono mt-1">
                  Lat: {selectedPoint.lat.toFixed(5)}, Lng: {selectedPoint.lng.toFixed(5)}
                  {selectedPoint.accuracy ? ` (±${selectedPoint.accuracy}m)` : ''}
                </div>
              </div>
              <button
                onClick={() => setSelectedPoint(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Manual Checkpoint / Note Drop Bar */}
      <div className="bg-white border-t border-slate-200 px-3 py-2 shrink-0">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={waypointNote}
            onChange={(e) => setWaypointNote(e.target.value)}
            placeholder="Record GPS checkpoint note (e.g. Arrived at client)..."
            className="flex-1 text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-sky-500"
          />
          <button
            onClick={handleDropWaypoint}
            disabled={isLoggingWaypoint}
            className="px-3 py-2 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors shrink-0"
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>{isLoggingWaypoint ? 'Saving...' : 'Pin Location'}</span>
          </button>
        </div>

        {logSuccessMessage && (
          <div className="mt-1 text-[11px] font-medium text-emerald-600 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>{logSuccessMessage}</span>
          </div>
        )}
      </div>

      {/* Interactive Bottom Drawer: Optimized Plan vs History Timeline */}
      <div className="bg-slate-50 border-t border-slate-200 shrink-0">
        <div className="flex border-b border-slate-200/80 bg-white">
          <button
            onClick={() => {
              setActiveBottomTab('optimized');
              setIsTimelineExpanded(true);
            }}
            className={`flex-1 py-2.5 px-3 text-xs font-bold flex items-center justify-center gap-1.5 border-b-2 transition-all ${
              activeBottomTab === 'optimized'
                ? 'border-purple-600 text-purple-700 bg-purple-50/50'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-purple-600" />
            <span>Efficient Stops ({optimizedPlan?.stops.length || pendingVisits.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveBottomTab('history');
              setIsTimelineExpanded(true);
            }}
            className={`flex-1 py-2.5 px-3 text-xs font-bold flex items-center justify-center gap-1.5 border-b-2 transition-all ${
              activeBottomTab === 'history'
                ? 'border-sky-600 text-sky-700 bg-sky-50/50'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Footprints className="w-3.5 h-3.5 text-sky-600" />
            <span>Milestones ({combinedRoutePoints.length})</span>
          </button>

          <button
            onClick={() => setIsTimelineExpanded(!isTimelineExpanded)}
            className="px-3 text-slate-400 hover:text-slate-600"
            title={isTimelineExpanded ? 'Collapse Drawer' : 'Expand Drawer'}
          >
            {isTimelineExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>

        {isTimelineExpanded && (
          <div className="px-4 py-3 max-h-60 overflow-y-auto space-y-2">
            {/* TAB 1: OPTIMIZED STOPS SEQUENCE */}
            {activeBottomTab === 'optimized' && (
              <div className="space-y-2">
                {!optimizedPlan || optimizedPlan.stops.length === 0 ? (
                  <div className="text-center py-6 text-xs text-slate-400 space-y-1">
                    <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto" />
                    <p className="font-semibold text-slate-700">All Field Visits Completed for Today!</p>
                    <p className="text-[11px]">No pending visits remain to optimize.</p>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 px-1">
                      <span>Most efficient driving sequence from your position:</span>
                      <span className="font-bold text-purple-700">
                        {(optimizedPlan.totalDistanceMeters / 1000).toFixed(1)} km total
                      </span>
                    </div>

                    {optimizedPlan.stops.map((visit, idx) => {
                      const stopNum = idx + 1;
                      const isNext = stopNum === 1;
                      const isSelected = selectedVisitStop?.id === visit.id;
                      const leg = optimizedPlan.legs[idx];

                      return (
                        <div
                          key={visit.id}
                          onClick={() => handleSelectOptimizedStop(visit)}
                          className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-purple-50/90 border-purple-400 shadow-xs'
                              : isNext
                              ? 'bg-white border-purple-200 hover:border-purple-300 shadow-2xs'
                              : 'bg-white border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-start gap-2.5 min-w-0">
                              <span
                                className={`w-6 h-6 rounded-full flex items-center justify-center font-black text-xs shrink-0 ${
                                  isNext
                                    ? 'bg-purple-600 text-white shadow-xs'
                                    : 'bg-purple-100 text-purple-800'
                                }`}
                              >
                                {stopNum}
                              </span>

                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="font-bold text-xs text-slate-900 truncate">
                                    {visit.customerName}
                                  </span>
                                  {isNext && (
                                    <span className="text-[9px] font-black px-1.5 py-0.2 rounded-md bg-purple-600 text-white uppercase">
                                      Next Stop
                                    </span>
                                  )}
                                </div>
                                <p className="text-[11px] text-slate-500 truncate mt-0.5">{visit.siteAddress}</p>
                              </div>
                            </div>

                            <span
                              className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md uppercase shrink-0 ${
                                visit.priority === 'urgent'
                                  ? 'bg-red-100 text-red-800'
                                  : visit.priority === 'high'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-sky-100 text-sky-800'
                              }`}
                            >
                              {visit.priority}
                            </span>
                          </div>

                          <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                            <div className="flex items-center gap-1.5 text-slate-500 font-medium">
                              <Car className="w-3 h-3 text-purple-600" />
                              <span>
                                {leg ? `${(leg.distanceMeters / 1000).toFixed(1)} km (~${leg.durationMinutes} mins)` : 'Next leg'}
                              </span>
                            </div>

                            <a
                              href={`https://www.google.com/maps/dir/?api=1&destination=${visit.lat},${visit.lng}&travelmode=driving`}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="text-[10px] font-bold text-purple-700 hover:text-purple-900 flex items-center gap-0.5"
                            >
                              <span>Navigate</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          </div>
                        </div>
                      );
                    })}
                  </>
                )}
              </div>
            )}

            {/* TAB 2: MILESTONES & HISTORY TIMELINE */}
            {activeBottomTab === 'history' && (
              <div className="space-y-2">
                {combinedRoutePoints.length === 0 ? (
                  <div className="text-center py-4 text-xs text-slate-400">
                    No GPS route points recorded yet for today. Check in to begin tracking.
                  </div>
                ) : (
                  combinedRoutePoints.map((pt, idx) => {
                    const isStart = pt.eventType === 'check_in' || idx === 0;
                    const isEnd = idx === combinedRoutePoints.length - 1;
                    const isVisit = pt.eventType === 'visit_start' || pt.eventType === 'visit_complete';
                    const isSelected = selectedPoint?.id === pt.id;

                    const badgeBg = isStart
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                      : isEnd
                      ? 'bg-rose-100 text-rose-800 border-rose-200'
                      : isVisit
                      ? 'bg-purple-100 text-purple-800 border-purple-200'
                      : 'bg-sky-100 text-sky-800 border-sky-200';

                    return (
                      <div
                        key={pt.id || idx}
                        onClick={() => handleSelectWaypoint(pt)}
                        className={`flex items-start gap-2.5 p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-sky-50 border-sky-300 shadow-xs'
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <span
                          className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 border ${badgeBg}`}
                        >
                          {isStart ? 'S' : isEnd ? '•' : isVisit ? 'V' : idx + 1}
                        </span>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-900 capitalize truncate">
                              {pt.eventType?.replace('_', ' ') || 'Waypoint'}
                            </span>
                            <span className="text-[10px] font-mono text-slate-500">
                              {new Date(pt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          {pt.notes && <p className="text-[11px] text-slate-600 truncate mt-0.5">{pt.notes}</p>}
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                            {pt.lat.toFixed(5)}, {pt.lng.toFixed(5)} {pt.accuracy ? `(±${pt.accuracy}m)` : ''}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer Info / Safety Assurance */}
      <div className="bg-slate-100 border-t border-slate-200 px-3 py-1.5 flex items-center justify-between text-[10px] text-slate-500 shrink-0">
        <div className="flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Google Maps Efficient Route Optimization • Privacy protected</span>
        </div>
        <span className="font-mono text-slate-400">FieldFlow GPS</span>
      </div>
    </div>
  );
};
