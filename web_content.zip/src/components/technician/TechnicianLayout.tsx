import React, { useState, useEffect } from 'react';
import { Home, Clock, MapPin, CheckSquare, MessageSquare, User, Navigation, ShieldCheck, Info, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { subscribeTrackerState, TrackerState, checkGeolocationPermission } from '../../utils/locationTracker.ts';
import { RealTimeGpsTracking } from './RealTimeGpsTracking.tsx';

interface TechnicianLayoutProps {
  activeTab: 'home' | 'attendance' | 'visits' | 'tasks' | 'leave' | 'messages' | 'profile' | 'tracking';
  setActiveTab: (tab: 'home' | 'attendance' | 'visits' | 'tasks' | 'leave' | 'messages' | 'profile' | 'tracking') => void;
  children: React.ReactNode;
}

export const TechnicianLayout: React.FC<TechnicianLayoutProps> = ({ activeTab, setActiveTab, children }) => {
  const { currentEmployee, userProfile } = useAuth();
  const displayName = currentEmployee?.name || userProfile?.displayName || 'Technician';

  const [trackerState, setTrackerState] = useState<TrackerState>({
    isTracking: false,
    permissionStatus: 'prompt',
    lastCoords: null,
    lastUpdate: null,
    errorMessage: null,
  });
  const [showGpsInfoModal, setShowGpsInfoModal] = useState(false);
  const [showRealTimeGpsModal, setShowRealTimeGpsModal] = useState(false);

  useEffect(() => {
    checkGeolocationPermission();
    const unsub = subscribeTrackerState((state) => {
      setTrackerState(state);
    });
    return () => unsub();
  }, []);

  // Mobile bottom navigation (5 items for optimal touch target on 320px - 430px screens):
  // HOME | VISITS | TASKS | MESSAGES | PROFILE
  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'visits', label: 'Visits', icon: MapPin },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare },
    { id: 'messages', label: 'Messages', icon: MessageSquare },
    { id: 'profile', label: 'Profile', icon: User },
  ] as const;

  return (
    <div className="min-h-[calc(100vh-3.5rem)] bg-slate-50 flex flex-col justify-between max-w-md mx-auto w-full border-x border-slate-200 shadow-sm relative">
      {/* Top Mobile Bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-2.5 sticky top-14 z-20 space-y-1.5 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Field Operations Mobile</div>
            <div className="text-sm font-black text-slate-900 truncate">
              {displayName}
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-lg bg-sky-50 text-sky-700 border border-sky-200 font-mono">
              {currentEmployee?.employeeCode || 'TECH'}
            </span>
          </div>
        </div>

        {/* Real-time GPS Tracking Banner & Trigger */}
        <div className="flex items-center justify-between text-[11px] bg-slate-50 p-1.5 rounded-xl border border-slate-200 gap-2">
          {/* Clickable GPS Telemetry Badge that opens Real-time GPS Tracking */}
          <button
            onClick={() => setShowRealTimeGpsModal(true)}
            className="flex-1 flex items-center gap-1.5 text-left p-1 rounded-lg hover:bg-white transition-colors group"
            title="Open Real-time GPS Tracking map"
          >
            {trackerState.isTracking ? (
              <span className="flex items-center gap-1.5 font-bold text-emerald-700">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                <span className="truncate">GPS Live Active</span>
                {trackerState.lastCoords?.accuracy && (
                  <span className="text-[10px] text-slate-400 font-normal">
                    (±{trackerState.lastCoords.accuracy}m)
                  </span>
                )}
              </span>
            ) : trackerState.permissionStatus === 'denied' ? (
              <span className="text-amber-800 font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                <span className="truncate">GPS Blocked</span>
              </span>
            ) : (
              <span className="text-slate-500 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-slate-400 shrink-0" />
                <span className="truncate">GPS Standby (Punches only)</span>
              </span>
            )}
          </button>

          <div className="flex items-center gap-1.5 shrink-0">
            {/* Real-time GPS Tracking Quick Action Button */}
            <button
              onClick={() => setShowRealTimeGpsModal(true)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold text-[10px] transition-colors shadow-2xs"
              title="Open Real-time GPS Tracking & Route History"
            >
              <Navigation className="w-3 h-3 animate-pulse" />
              <span>Real-time GPS</span>
            </button>

            <button
              onClick={() => setShowGpsInfoModal(true)}
              className="text-[10px] text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-200/60"
              title="Location tracking transparency policy"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 p-3 pb-24 overflow-y-auto">
        {children}
      </main>

      {/* Real-time GPS Tracking Modal / Full View */}
      {showRealTimeGpsModal && (
        <RealTimeGpsTracking
          isModal={true}
          onClose={() => setShowRealTimeGpsModal(false)}
        />
      )}

      {/* GPS Transparency Disclosure Modal */}
      {showGpsInfoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-5 max-w-sm w-full space-y-3 shadow-2xl border border-slate-200 animate-in fade-in-0">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-sm text-slate-900">Location Transparency Policy</h3>
              </div>
              <button
                onClick={() => setShowGpsInfoModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-600 leading-relaxed">
              <p>
                <strong>Legitimate Operational Use:</strong> FieldFlow collects device location coordinates solely for verified job dispatch, customer arrival verification, and technician safety during active work shifts.
              </p>
              <p>
                <strong>Browser Tracking Limits:</strong> Continuous location streaming occurs only while this web app is open in your mobile browser. It does not track you after the browser is closed.
              </p>
              <p>
                <strong>Privacy Protected:</strong> Other field technicians cannot track your device. Only authorized organization administrators can view dispatch positions.
              </p>
            </div>

            <button
              onClick={() => setShowGpsInfoModal(false)}
              className="w-full py-2.5 bg-slate-900 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              Understood
            </button>
          </div>
        </div>
      )}

      {/* Bottom Navigation: 5 items, high-contrast, touch targets >= 48px */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-200 z-30 shadow-lg select-none">
        <div className="grid grid-cols-5 h-16 items-center">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center h-full transition-colors ${
                  isActive ? 'text-sky-600 font-bold' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.4]' : 'stroke-[1.8]'}`} />
                <span className="text-[10px] mt-1 tracking-tight">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};
