import React, { useEffect, useState } from 'react';
import { Clock, MapPin, CheckSquare, ArrowRight, Play, CheckCircle2, AlertCircle, Calendar, Sparkles, Navigation, Bell, Building2 } from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc, updateDoc, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { AttendanceRecord, FieldVisit, TaskItem, NotificationItem } from '../../types/index.ts';
import { enqueueOfflineAction, isItemPendingSync } from '../../utils/offlineQueue.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import {
  startTechnicianLiveTracking,
  stopTechnicianLiveTracking,
  logMilestoneLocation,
} from '../../utils/locationTracker.ts';
import { CompanyJoinModal } from './CompanyJoinModal.tsx';

interface TechnicianHomeProps {
  onNavigateTab: (tab: 'home' | 'attendance' | 'visits' | 'tasks' | 'leave' | 'messages' | 'profile' | 'tracking') => void;
}

export const TechnicianHome: React.FC<TechnicianHomeProps> = ({ onNavigateTab }) => {
  const { currentEmployee, currentOrg, userProfile } = useAuth();
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord | null>(null);
  const [visits, setVisits] = useState<FieldVisit[]>([]);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [actionLoading, setActionLoading] = useState<boolean>(false);
  const [gpsStatus, setGpsStatus] = useState<string>('');
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];
  const employeeId = currentEmployee?.id || userProfile?.employeeId || userProfile?.id || '';
  const employeeName = currentEmployee?.name || userProfile?.displayName || userProfile?.email?.split('@')[0] || 'Technician';

  // Greeting based on time of day
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  const loadHomeData = async () => {
    if (!currentOrg) {
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    try {
      // 1. Fetch today's attendance record
      const attDocRef = doc(db, 'attendance', `att_${todayStr}_${employeeId}`);
      const attSnap = await getDocs(
        query(
          collection(db, 'attendance'),
          where('orgId', '==', currentOrg.id),
          where('employeeId', '==', employeeId),
          where('date', '==', todayStr)
        )
      );

      if (!attSnap.empty) {
        const att = attSnap.docs[0].data() as AttendanceRecord;
        setTodayAttendance(att);
        if (!att.checkOutTime) {
          startTechnicianLiveTracking({
            orgId: currentOrg.id,
            employeeId,
            employeeName,
            employeeCode: currentEmployee?.employeeCode,
            department: currentEmployee?.department,
            phone: currentEmployee?.phone,
          });
        }
      } else {
        setTodayAttendance(null);
      }

      // 2. Fetch today's assigned visits
      const visitsSnap = await getDocs(
        query(
          collection(db, 'visits'),
          where('orgId', '==', currentOrg.id),
          where('assignedEmployeeId', '==', employeeId),
          where('scheduledDate', '==', todayStr)
        )
      );
      const visitList: FieldVisit[] = [];
      visitsSnap.forEach((d) => visitList.push(d.data() as FieldVisit));
      setVisits(visitList);

      // 3. Fetch pending tasks
      const tasksSnap = await getDocs(
        query(
          collection(db, 'tasks'),
          where('orgId', '==', currentOrg.id),
          where('assignedEmployeeId', '==', employeeId),
          where('status', 'in', ['pending', 'in_progress'])
        )
      );
      const taskList: TaskItem[] = [];
      tasksSnap.forEach((d) => taskList.push(d.data() as TaskItem));
      setTasks(taskList);

      // 4. Fetch recent important notifications
      const notifSnap = await getDocs(
        query(
          collection(db, 'notifications'),
          where('orgId', '==', currentOrg.id),
          where('userId', '==', employeeId),
          limit(5)
        )
      );
      const notifList: NotificationItem[] = [];
      notifSnap.forEach((d) => notifList.push(d.data() as NotificationItem));
      notifList.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setNotifications(notifList);
    } catch (e) {
      console.error('Error loading technician home data:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadHomeData();
  }, [currentOrg, employeeId, todayStr]);

  // Real browser geolocation acquisition
  const getCurrentLocation = async (): Promise<{ lat?: number; lng?: number; address?: string }> => {
    setGpsStatus('Acquiring GPS location...');
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        setGpsStatus('');
        resolve({ address: 'Field Service Area' });
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setGpsStatus('');
          resolve({
            lat: Number(pos.coords.latitude.toFixed(5)),
            lng: Number(pos.coords.longitude.toFixed(5)),
            address: `Lat: ${pos.coords.latitude.toFixed(4)}, Lng: ${pos.coords.longitude.toFixed(4)}`,
          });
        },
        (err) => {
          console.warn('Geolocation error or denied:', err);
          setGpsStatus('');
          resolve({ address: 'Authorized Field Area' });
        },
        { timeout: 7000, enableHighAccuracy: true }
      );
    });
  };

  const handleCheckIn = async () => {
    if (!currentOrg) {
      setIsJoinModalOpen(true);
      return;
    }
    setActionLoading(true);
    try {
      const loc = await getCurrentLocation();
      const attId = `att_${todayStr}_${employeeId}`;
      const newRecord: AttendanceRecord = {
        id: attId,
        orgId: currentOrg.id,
        employeeId,
        employeeName,
        date: todayStr,
        checkInTime: new Date().toISOString(),
        checkInLat: loc.lat,
        checkInLng: loc.lng,
        checkInAddress: loc.address || 'Field Location Verified',
        status: 'present',
        durationMinutes: 0,
      };

      if (!navigator.onLine) {
        enqueueOfflineAction('check_in', newRecord);
        setTodayAttendance(newRecord);
      } else {
        try {
          await setDoc(doc(db, 'attendance', attId), removeUndefinedFields(newRecord));
          setTodayAttendance(newRecord);
        } catch (netErr) {
          console.warn('Network issue during check-in, queued for Service Worker offline sync:', netErr);
          enqueueOfflineAction('check_in', newRecord);
          setTodayAttendance(newRecord);
        }
      }

      // Start live GPS tracking for technician shift
      startTechnicianLiveTracking({
        orgId: currentOrg.id,
        employeeId,
        employeeName,
        employeeCode: currentEmployee?.employeeCode,
        department: currentEmployee?.department,
        phone: currentEmployee?.phone,
      });

      // Record milestone breadcrumb
      logMilestoneLocation({
        orgId: currentOrg.id,
        employeeId,
        employeeName,
        eventType: 'check_in',
        notes: `Check-in: ${loc.address || 'Field punch'}`,
        lat: loc.lat,
        lng: loc.lng,
      });
    } catch (e) {
      console.error('Check-in error:', e);
    } finally {
      setActionLoading(false);
    }
  };

  const handleCheckOut = async () => {
    if (!currentOrg || !todayAttendance) return;
    setActionLoading(true);
    try {
      const loc = await getCurrentLocation();
      const checkOutTime = new Date().toISOString();
      const checkInDate = new Date(todayAttendance.checkInTime);
      const minutes = Math.max(1, Math.round((new Date().getTime() - checkInDate.getTime()) / 60000));

      const updatedRecord: AttendanceRecord = {
        ...todayAttendance,
        checkOutTime,
        checkOutLat: loc.lat,
        checkOutLng: loc.lng,
        checkOutAddress: loc.address || 'Field Exit Verified',
        durationMinutes: minutes,
        status: 'completed',
      };

      if (!navigator.onLine) {
        enqueueOfflineAction('check_out', updatedRecord);
        setTodayAttendance(updatedRecord);
      } else {
        try {
          await setDoc(doc(db, 'attendance', todayAttendance.id), removeUndefinedFields(updatedRecord));
          setTodayAttendance(updatedRecord);
        } catch (netErr) {
          console.warn('Network issue during checkout, queued for Service Worker offline sync:', netErr);
          enqueueOfflineAction('check_out', updatedRecord);
          setTodayAttendance(updatedRecord);
        }
      }

      // Stop live GPS tracking and log end breadcrumb
      await stopTechnicianLiveTracking(employeeId);
      logMilestoneLocation({
        orgId: currentOrg.id,
        employeeId,
        employeeName,
        eventType: 'check_out',
        notes: `Check-out: Worked ${minutes} mins`,
        lat: loc.lat,
        lng: loc.lng,
      });
    } catch (e) {
      console.error('Check-out error:', e);
    } finally {
      setActionLoading(false);
    }
  };

  const handleStartVisit = async (visit: FieldVisit) => {
    if (!currentOrg) return;
    setActionLoading(true);
    try {
      const updated: FieldVisit = {
        ...visit,
        status: 'in_progress',
        startedAt: new Date().toISOString(),
      };
      if (!navigator.onLine) {
        enqueueOfflineAction('start_visit', updated);
      } else {
        await updateDoc(doc(db, 'visits', visit.id), {
          status: 'in_progress',
          startedAt: updated.startedAt,
        });
      }
      setVisits((prev) => prev.map((v) => (v.id === visit.id ? updated : v)));

      // Log milestone
      logMilestoneLocation({
        orgId: currentOrg.id,
        employeeId,
        employeeName,
        eventType: 'visit_start',
        notes: `Started visit: ${visit.title} at ${visit.customerName}`,
      });
    } catch (e) {
      console.error('Start visit error:', e);
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* 1. Greeting */}
      <div className="bg-gradient-to-r from-sky-600 to-indigo-700 rounded-2xl p-4 text-white shadow-sm">
        <div className="text-sm font-medium text-sky-100">
          {greeting},
        </div>
        <div className="text-xl font-bold mt-0.5">{employeeName}</div>
        <div className="text-xs text-sky-100 mt-1 flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5" />
          <span>{new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}</span>
        </div>
      </div>

      {/* Join Company Workspace Prompt if no active company connected */}
      {!currentOrg && (
        <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 text-xs space-y-3 shadow-xs">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
              <Building2 className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <div className="font-bold text-sm text-purple-950">Join a Company Workspace</div>
              <p className="text-purple-800 leading-relaxed text-[11px]">
                You are not currently linked to an active operations company. Search for your organization and submit a join request with your company access code.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setIsJoinModalOpen(true)}
            className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
          >
            <span>Search & Request Company Access</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Important Notifications / Dispatch Alerts */}
      {notifications.length > 0 && notifications.some((n) => !n.read) && (
        <div className="bg-amber-50/90 border border-amber-200/90 rounded-2xl p-3.5 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-amber-200/60 text-amber-800 flex items-center justify-center">
                <Bell className="w-3.5 h-3.5 animate-bounce" />
              </div>
              <span className="font-bold text-xs text-amber-900">Important Notifications</span>
            </div>
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-amber-200 text-amber-900">
              {notifications.filter((n) => !n.read).length} new
            </span>
          </div>

          <div className="space-y-1.5">
            {notifications
              .filter((n) => !n.read)
              .slice(0, 2)
              .map((n) => (
                <div
                  key={n.id}
                  onClick={() => {
                    if (n.type === 'visit') onNavigateTab('visits');
                    else if (n.type === 'task') onNavigateTab('tasks');
                    else if (n.type === 'leave') onNavigateTab('leave');
                    else if (n.type === 'message') onNavigateTab('messages');
                  }}
                  className="bg-white/80 hover:bg-white p-2.5 rounded-xl border border-amber-200/60 text-xs cursor-pointer transition-colors"
                >
                  <div className="font-bold text-slate-900 flex items-center justify-between">
                    <span>{n.title}</span>
                    <span className="text-[10px] text-slate-400 font-normal">
                      {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-0.5 leading-snug">{n.message}</p>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* 2. Attendance Card (Instant Check-In / Check-Out) */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
            <span className="font-bold text-sm text-slate-900">Attendance</span>
          </div>
          {todayAttendance?.checkInTime && (
            isItemPendingSync(todayAttendance.id) ? (
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-300 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                Pending Sync (Saved Locally)
              </span>
            ) : (
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                Checked In
              </span>
            )
          )}
        </div>

        {gpsStatus && (
          <div className="text-xs text-sky-600 mb-2 font-medium animate-pulse flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-sky-500"></span>
            {gpsStatus}
          </div>
        )}

        {!todayAttendance ? (
          <button
            onClick={handleCheckIn}
            disabled={actionLoading}
            className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 text-base active:scale-[0.99]"
          >
            <Clock className="w-5 h-5" />
            {actionLoading ? 'Verifying location...' : 'CHECK IN'}
          </button>
        ) : !todayAttendance.checkOutTime ? (
          <div className="space-y-3">
            <div className="text-xs bg-slate-50 p-2.5 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-slate-500">Punch In: </span>
                <span className="font-bold text-slate-800">
                  {new Date(todayAttendance.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <div className="text-slate-500 text-[11px] truncate max-w-[150px]">
                {todayAttendance.checkInAddress || 'Location verified'}
              </div>
            </div>

            <button
              onClick={handleCheckOut}
              disabled={actionLoading}
              className="w-full py-3.5 px-4 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 text-base active:scale-[0.99]"
            >
              <Clock className="w-5 h-5" />
              {actionLoading ? 'Updating...' : 'CHECK OUT'}
            </button>
          </div>
        ) : (
          <div className="text-center py-2 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-xs text-slate-500 font-medium">Shift Finished for Today</div>
            <div className="text-sm font-bold text-slate-800 mt-0.5">
              Worked {Math.floor((todayAttendance.durationMinutes || 0) / 60)}h {(todayAttendance.durationMinutes || 0) % 60}m
            </div>
          </div>
        )}
      </div>

      {/* Real-time GPS Tracking Card (Google Maps) */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
              <Navigation className="w-4 h-4 text-sky-600 animate-pulse" />
            </div>
            <div>
              <span className="font-bold text-sm text-slate-900">Real-time GPS Tracking</span>
              <span className="ml-2 text-[10px] font-bold px-1.5 py-0.5 rounded bg-sky-100 text-sky-700">Google Maps</span>
            </div>
          </div>
          <span className="text-[11px] font-bold text-emerald-600 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            Active
          </span>
        </div>

        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs">
          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Today&apos;s Route</div>
            <div className="font-bold text-slate-800 text-sm mt-0.5">Live Shift Path</div>
          </div>
          <button
            onClick={() => onNavigateTab('tracking')}
            className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5 active:scale-95"
          >
            <Navigation className="w-3.5 h-3.5" />
            <span>Open Map</span>
          </button>
        </div>
      </div>

      {/* Primary Mobile Quick Actions Bar */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          onClick={() => onNavigateTab('tasks')}
          className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl shadow-xs flex items-center justify-between active:scale-[0.98] transition-all"
        >
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <CheckSquare className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Assignments</div>
              <div className="text-xs font-black text-slate-900">VIEW TASKS</div>
            </div>
          </div>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold">
            {tasks.length}
          </span>
        </button>

        <button
          onClick={() => onNavigateTab('leave')}
          className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl shadow-xs flex items-center justify-between active:scale-[0.98] transition-all"
        >
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Time Off</div>
              <div className="text-xs font-black text-slate-900">APPLY LEAVE</div>
            </div>
          </div>
          <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
        </button>
      </div>

      {/* 3. Today's Work (Visits) */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
              <MapPin className="w-4 h-4" />
            </div>
            <span className="font-bold text-sm text-slate-900">Today's Work</span>
          </div>
          <button
            onClick={() => onNavigateTab('visits')}
            className="text-xs text-sky-600 hover:text-sky-800 font-bold flex items-center gap-0.5"
          >
            <span>View All</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {visits.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-400">
            No field visits scheduled for today.
          </div>
        ) : (
          <div className="space-y-3">
            {visits.map((vis, idx) => (
              <div
                key={vis.id}
                className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-sky-300 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[11px] font-bold text-sky-700 uppercase">
                      📍 Visit {idx + 1}
                    </span>
                    <h4 className="font-bold text-sm text-slate-900 mt-0.5">{vis.title}</h4>
                    <p className="text-xs text-slate-600 mt-0.5 font-medium">{vis.customerName}</p>
                    <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1">
                      <MapPin className="w-3 h-3 shrink-0" />
                      <span className="truncate">{vis.siteAddress}</span>
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                        vis.status === 'completed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : vis.status === 'in_progress'
                          ? 'bg-sky-100 text-sky-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {vis.status.replace('_', ' ')}
                    </span>
                    {isItemPendingSync(vis.id) && (
                      <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-amber-50 text-amber-800 border border-amber-300">
                        ⏳ Pending Sync
                      </span>
                    )}
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-200/80 flex items-center justify-between">
                  <div className="text-xs font-semibold text-slate-700">
                    ⏰ {vis.scheduledTime || '09:00 AM'}
                  </div>

                  {vis.status === 'scheduled' ? (
                    <button
                      onClick={() => handleStartVisit(vis)}
                      className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-lg flex items-center gap-1 active:scale-95 transition-all"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Start Visit</span>
                    </button>
                  ) : vis.status === 'in_progress' ? (
                    <button
                      onClick={() => onNavigateTab('visits')}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg flex items-center gap-1 active:scale-95 transition-all"
                    >
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Complete Work</span>
                    </button>
                  ) : (
                    <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Finished
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 4. Tasks Summary */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
              <CheckSquare className="w-4 h-4" />
            </div>
            <span className="font-bold text-sm text-slate-900">Tasks</span>
          </div>
          <span className="text-xs font-bold text-slate-600">
            {tasks.length} pending
          </span>
        </div>

        {tasks.length > 0 ? (
          <div className="mt-3">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900">{tasks[0].title}</span>
                <div className="text-slate-500 text-[11px] mt-0.5">Due: {tasks[0].dueDate}</div>
              </div>
              <button
                onClick={() => onNavigateTab('tasks')}
                className="px-2.5 py-1 text-xs font-bold bg-white border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-100"
              >
                View
              </button>
            </div>
            <button
              onClick={() => onNavigateTab('tasks')}
              className="w-full mt-2 py-2 text-xs font-bold text-sky-600 hover:text-sky-800 text-center"
            >
              View All {tasks.length} Tasks →
            </button>
          </div>
        ) : (
          <div className="text-center py-4 text-xs text-slate-400">
            All tasks are completed for today.
          </div>
        )}
      </div>

      {/* Company Join Modal */}
      <CompanyJoinModal
        isOpen={isJoinModalOpen}
        onClose={() => setIsJoinModalOpen(false)}
      />
    </div>
  );
};
