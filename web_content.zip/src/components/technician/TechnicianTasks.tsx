import React, { useEffect, useState } from 'react';
import { CheckSquare, Clock, AlertCircle, CheckCircle2, ChevronRight } from 'lucide-react';
import { collection, query, where, getDocs, doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { TaskItem, TaskStatus, PriorityLevel } from '../../types/index.ts';
import { enqueueOfflineAction, isItemPendingSync } from '../../utils/offlineQueue.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';

export const TechnicianTasks: React.FC = () => {
  const { currentEmployee, currentOrg, userProfile } = useAuth();
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('pending');

  const employeeId = currentEmployee?.id || userProfile?.employeeId || 'emp-101';

  const fetchTasks = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const q = query(
        collection(db, 'tasks'),
        where('orgId', '==', currentOrg.id),
        where('assignedEmployeeId', '==', employeeId)
      );
      const snap = await getDocs(q);
      const list: TaskItem[] = [];
      snap.forEach((d) => list.push(d.data() as TaskItem));
      list.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
      setTasks(list);
    } catch (e) {
      console.error('Error fetching tasks:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [currentOrg, employeeId]);

  const toggleTaskStatus = async (task: TaskItem) => {
    const newStatus: TaskStatus = task.status === 'completed' ? 'pending' : 'completed';
    const completedAt = newStatus === 'completed' ? new Date().toISOString() : null;
    const updated: TaskItem = {
      ...task,
      status: newStatus,
      completedAt,
    };

    if (!navigator.onLine) {
      enqueueOfflineAction('update_task', removeUndefinedFields(updated));
    } else {
      try {
        await updateDoc(doc(db, 'tasks', task.id), {
          status: newStatus,
          completedAt: completedAt || null,
        });
      } catch (netErr) {
        console.warn('Network issue writing task online, queued for Service Worker offline sync:', netErr);
        enqueueOfflineAction('update_task', removeUndefinedFields(updated));
      }
    }

    setTasks((prev) => prev.map((t) => (t.id === task.id ? updated : t)));
  };

  const filteredTasks = tasks.filter((t) => {
    if (filter === 'pending') return t.status !== 'completed' && t.status !== 'cancelled';
    if (filter === 'completed') return t.status === 'completed';
    return true;
  });

  const getPriorityColor = (p: PriorityLevel) => {
    switch (p) {
      case 'urgent':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'medium':
        return 'bg-sky-100 text-sky-800 border-sky-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-4">
      {/* Header & Tabs */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-sky-600" />
            <h2 className="text-base font-bold text-slate-900">Work Tasks</h2>
          </div>
          <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
            {tasks.filter((t) => t.status !== 'completed').length} Pending
          </span>
        </div>

        {/* Filter Pills */}
        <div className="flex gap-1.5 p-1 bg-slate-100 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setFilter('pending')}
            className={`flex-1 py-1.5 rounded-lg transition-colors ${
              filter === 'pending' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pending
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`flex-1 py-1.5 rounded-lg transition-colors ${
              filter === 'completed' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Completed
          </button>
          <button
            onClick={() => setFilter('all')}
            className={`flex-1 py-1.5 rounded-lg transition-colors ${
              filter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All
          </button>
        </div>
      </div>

      {/* Task Items */}
      {loading ? (
        <div className="text-center py-10 text-xs text-slate-500 font-medium">Loading tasks...</div>
      ) : filteredTasks.length === 0 ? (
        <div className="text-center py-10 bg-white rounded-2xl border border-slate-200 p-6 text-xs text-slate-400">
          No tasks found in this view.
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredTasks.map((task) => {
            const isDone = task.status === 'completed';
            return (
              <div
                key={task.id}
                onClick={() => toggleTaskStatus(task)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 select-none ${
                  isDone
                    ? 'bg-slate-50 border-slate-200 opacity-75'
                    : 'bg-white border-slate-200 shadow-xs hover:border-sky-300'
                }`}
              >
                <div className="mt-0.5 shrink-0">
                  <div
                    className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors ${
                      isDone
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : 'border-slate-300 bg-white hover:border-sky-500'
                    }`}
                  >
                    {isDone && <CheckCircle2 className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                </div>

                <div className="flex-1">
                  <div className="flex items-center justify-between gap-1.5">
                    <span
                      className={`text-sm font-bold ${
                        isDone ? 'line-through text-slate-500' : 'text-slate-900'
                      }`}
                    >
                      {task.title}
                    </span>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md uppercase border shrink-0 ${getPriorityColor(
                        task.priority
                      )}`}
                    >
                      {task.priority}
                    </span>
                  </div>

                  {task.description && (
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">{task.description}</p>
                  )}

                  <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 pt-1 border-t border-slate-100">
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1 text-slate-500 font-medium">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>Due: {task.dueDate}</span>
                      </div>
                      {isItemPendingSync(task.id) && (
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-amber-50 text-amber-800 border border-amber-300">
                          ⏳ Pending Sync
                        </span>
                      )}
                    </div>
                    {isDone ? (
                      <span className="text-emerald-700 font-bold text-[10px]">Completed</span>
                    ) : (
                      <span className="text-sky-600 font-bold text-[10px]">Tap to Complete</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
