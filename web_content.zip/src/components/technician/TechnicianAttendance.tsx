import React, { useEffect, useState } from 'react';
import { Clock, MapPin, Calendar, AlertCircle, CheckCircle2, History, Send } from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc, updateDoc, orderBy, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { AttendanceRecord } from '../../types/index.ts';
import { enqueueOfflineAction, isItemPendingSync } from '../../utils/offlineQueue.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';

export const TechnicianAttendance: React.FC = () => {
  const { currentEmployee, currentOrg, userProfile } = useAuth();
  const [todayRecord, setTodayRecord] = useState<AttendanceRecord | null>(null);
  const [history, setHistory] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [showCorrectionModal, setShowCorrectionModal] = useState(false);

  // Correction Form
  const [correctionDate, setCorrectionDate] = useState('');
  const [correctionReason, setCorrectionReason] = useState('');
  const [reqCheckIn, setReqCheckIn] = useState('09:00');
  const [reqCheckOut, setReqCheckOut] = useState('17:30');

  const employeeId = currentEmployee?.id || userProfile?.employeeId || 'emp-101';
  const employeeName = currentEmployee?.name || userProfile?.displayName || 'Technician';
  const todayStr = new Date().toISOString().split('T')[0];

  const fetchAttendance = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const attQuery = query(
        collection(db, 'attendance'),
        where('orgId', '==', currentOrg.id),
        where('employeeId', '==', employeeId),
        limit(30)
      );
      const snap = await getDocs(attQuery);
      const list: AttendanceRecord[] = [];
      snap.forEach((d) => list.push(d.data() as AttendanceRecord));

      // Sort newest first
      list.sort((a, b) => b.date.localeCompare(a.date));
      setHistory(list);

      const foundToday = list.find((r) => r.date === todayStr);
      setTodayRecord(foundToday || null);
    } catch (e) {
      console.error('Error fetching attendance:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAttendance();
  }, [currentOrg, employeeId, todayStr]);

  const getCurrentCoords = async (): Promise<{ lat?: number; lng?: number; address?: string }> => {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve({ address: 'Mobile Field Punch' });
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          resolve({
            lat: Number(pos.coords.latitude.toFixed(5)),
            lng: Number(pos.coords.longitude.toFixed(5)),
            address: `Lat: ${pos.coords.latitude.toFixed(4)}, Lng: ${pos.coords.longitude.toFixed(4)}`,
          });
        },
        () => resolve({ address: 'Field Location Recorded' }),
        { timeout: 7000 }
      );
    });
  };

  const handlePunchIn = async () => {
    if (!currentOrg) return;
    setActionLoading(true);
    try {
      const loc = await getCurrentCoords();
      const id = `att_${todayStr}_${employeeId}`;
      const record: AttendanceRecord = {
        id,
        orgId: currentOrg.id,
        employeeId,
        employeeName,
        date: todayStr,
        checkInTime: new Date().toISOString(),
        checkInLat: loc.lat,
        checkInLng: loc.lng,
        checkInAddress: loc.address,
        status: 'present',
        durationMinutes: 0,
      };

      if (!navigator.onLine) {
        enqueueOfflineAction('check_in', record);
      } else {
        try {
          await setDoc(doc(db, 'attendance', id), removeUndefinedFields(record));
        } catch (netErr) {
          console.warn('Network issue punching in online, queued for Service Worker offline sync:', netErr);
          enqueueOfflineAction('check_in', record);
        }
      }
      setTodayRecord(record);
      setHistory((prev) => [record, ...prev.filter((r) => r.id !== id)]);
    } catch (e) {
      console.error(e);
    } finally {
      setActionLoading(false);
    }
  };

  const handlePunchOut = async () => {
    if (!currentOrg || !todayRecord) return;
    setActionLoading(true);
    try {
      const loc = await getCurrentCoords();
      const checkOutTime = new Date().toISOString();
      const checkInDate = new Date(todayRecord.checkInTime);
      const minutes = Math.max(1, Math.round((new Date().getTime() - checkInDate.getTime()) / 60000));

      const updated: AttendanceRecord = {
        ...todayRecord,
        checkOutTime,
        checkOutLat: loc.lat,
        checkOutLng: loc.lng,
        checkOutAddress: loc.address,
        durationMinutes: minutes,
        status: 'completed',
      };

      if (!navigator.onLine) {
        enqueueOfflineAction('check_out', updated);
      } else {
        try {
          await setDoc(doc(db, 'attendance', todayRecord.id), removeUndefinedFields(updated));
        } catch (netErr) {
          console.warn('Network issue punching out online, queued for Service Worker offline sync:', netErr);
          enqueueOfflineAction('check_out', updated);
        }
      }
      setTodayRecord(updated);
      setHistory((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
    } catch (e) {
      console.error(e);
    } finally {
      setActionLoading(false);
    }
  };

  const handleRequestCorrection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentOrg || !correctionDate || !correctionReason) return;
    try {
      const id = `att_${correctionDate}_${employeeId}`;
      const existing = history.find((r) => r.date === correctionDate);

      const updated: AttendanceRecord = existing
        ? {
            ...existing,
            correctionRequest: {
              reason: correctionReason,
              requestedCheckIn: reqCheckIn,
              requestedCheckOut: reqCheckOut,
              status: 'pending',
            },
          }
        : {
            id,
            orgId: currentOrg.id,
            employeeId,
            employeeName,
            date: correctionDate,
            checkInTime: `${correctionDate}T${reqCheckIn}:00.000Z`,
            checkOutTime: `${correctionDate}T${reqCheckOut}:00.000Z`,
            status: 'present',
            durationMinutes: 480,
            correctionRequest: {
              reason: correctionReason,
              requestedCheckIn: reqCheckIn,
              requestedCheckOut: reqCheckOut,
              status: 'pending',
            },
          };

      await setDoc(doc(db, 'attendance', id), removeUndefinedFields(updated));
      setShowCorrectionModal(false);
      setCorrectionReason('');
      fetchAttendance();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header card */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <Clock className="w-5 h-5 text-sky-600" />
          <span>Attendance Verification</span>
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          Punches are timestamped and GPS verified automatically.
        </p>

        {/* Current status */}
        <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Today's Shift</span>
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded-full capitalize ${
                todayRecord?.checkOutTime
                  ? 'bg-slate-200 text-slate-700'
                  : todayRecord?.checkInTime
                  ? 'bg-emerald-100 text-emerald-800 animate-pulse'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              {todayRecord?.checkOutTime ? 'Completed' : todayRecord?.checkInTime ? 'Present & Working' : 'Not Checked In'}
            </span>
          </div>

          {todayRecord && isItemPendingSync(todayRecord.id) && (
            <div className="mt-2 text-[11px] font-medium text-amber-800 bg-amber-50 px-2.5 py-1.5 rounded-lg border border-amber-300 flex items-center gap-1.5 animate-pulse">
              <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
              <span>Punch queued offline — Service Worker will upload automatically once connection is restored.</span>
            </div>
          )}

          <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
            <div className="bg-white p-2.5 rounded-lg border border-slate-200">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Punch In</span>
              <span className="text-sm font-bold text-slate-800">
                {todayRecord?.checkInTime
                  ? new Date(todayRecord.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                  : '--:--'}
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-lg border border-slate-200">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Punch Out</span>
              <span className="text-sm font-bold text-slate-800">
                {todayRecord?.checkOutTime
                  ? new Date(todayRecord.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                  : '--:--'}
              </span>
            </div>
          </div>

          {/* Action button */}
          <div className="mt-3">
            {!todayRecord ? (
              <button
                onClick={handlePunchIn}
                disabled={actionLoading}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-sm shadow-xs flex items-center justify-center gap-2 active:scale-95 transition-all"
              >
                <Clock className="w-4 h-4" />
                {actionLoading ? 'Acquiring GPS...' : 'Punch In Now'}
              </button>
            ) : !todayRecord.checkOutTime ? (
              <button
                onClick={handlePunchOut}
                disabled={actionLoading}
                className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-sm shadow-xs flex items-center justify-center gap-2 active:scale-95 transition-all"
              >
                <Clock className="w-4 h-4" />
                {actionLoading ? 'Updating...' : 'Punch Out Now'}
              </button>
            ) : (
              <div className="text-xs text-center text-slate-500 font-medium py-1">
                Day shift complete ({Math.floor((todayRecord.durationMinutes || 0) / 60)}h {(todayRecord.durationMinutes || 0) % 60}m)
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Attendance History */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-slate-600" />
            <h3 className="font-bold text-sm text-slate-900">Recent Attendance Log</h3>
          </div>
          <button
            onClick={() => {
              setCorrectionDate(todayStr);
              setShowCorrectionModal(true);
            }}
            className="text-xs font-bold text-sky-600 hover:text-sky-800"
          >
            Request Correction
          </button>
        </div>

        {history.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-400">No attendance history yet</div>
        ) : (
          <div className="space-y-2">
            {history.map((item) => (
              <div
                key={item.id}
                className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-800">{item.date}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {new Date(item.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    {item.checkOutTime && ` → ${new Date(item.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                  </div>
                  {item.correctionRequest && (
                    <div className="text-[10px] text-amber-700 font-medium mt-0.5">
                      Correction: {item.correctionRequest.status}
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <span
                    className={`font-semibold px-2 py-0.5 rounded-full capitalize text-[10px] ${
                      item.status === 'completed' || item.status === 'present'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {item.status}
                  </span>
                  {item.durationMinutes ? (
                    <div className="text-[10px] text-slate-400 mt-1">
                      {Math.floor(item.durationMinutes / 60)}h {item.durationMinutes % 60}m
                    </div>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Correction Modal */}
      {showCorrectionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-5 max-w-sm w-full border border-slate-200 shadow-2xl">
            <h3 className="font-bold text-base text-slate-900">Request Attendance Correction</h3>
            <p className="text-xs text-slate-500 mt-1">
              All manual changes require manager approval and are audit-logged.
            </p>

            <form onSubmit={handleRequestCorrection} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Date</label>
                <input
                  type="date"
                  required
                  value={correctionDate}
                  onChange={(e) => setCorrectionDate(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Check In</label>
                  <input
                    type="time"
                    required
                    value={reqCheckIn}
                    onChange={(e) => setReqCheckIn(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Check Out</label>
                  <input
                    type="time"
                    required
                    value={reqCheckOut}
                    onChange={(e) => setReqCheckOut(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Reason for Correction</label>
                <textarea
                  required
                  rows={2}
                  placeholder="e.g. Weak cell coverage at commercial basement site"
                  value={correctionReason}
                  onChange={(e) => setCorrectionReason(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCorrectionModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-sky-600 text-white rounded-lg font-bold hover:bg-sky-700 flex items-center gap-1"
                >
                  <Send className="w-3 h-3" />
                  <span>Submit</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
