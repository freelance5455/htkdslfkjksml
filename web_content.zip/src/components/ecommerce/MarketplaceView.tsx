import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Product } from '../../types';
import {
  Search,
  Plus,
  SlidersHorizontal,
  Package,
  Check,
  AlertTriangle,
  X,
  PlusCircle,
  MinusCircle,
  Eye,
  ShoppingBag,
} from 'lucide-react';

export const MarketplaceView: React.FC = () => {
  const { products, addProduct, updateStock, addToCart, setIsCartOpen } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewMode, setViewMode] = useState<'catalog' | 'inventory'>('catalog');
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);

  // New product form states
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<Product['category']>('Tech & Hardware');
  const [newPrice, setNewPrice] = useState('89.00');
  const [newStock, setNewStock] = useState('25');
  const [newSku, setNewSku] = useState('SYN-ITEM-01');
  const [newDesc, setNewDesc] = useState('');
  const [newImage, setNewImage] = useState('/src/assets/images/marketplace_laptop_station_1793373690260.jpg');

  const categories = [
    'All',
    'Tech & Hardware',
    'Stationery & Books',
    'STEM & Robotics',
    'Office Furnishing',
    'Uniforms & Apparel',
  ];

  const filteredProducts = products.filter((prod) => {
    const matchesCat = selectedCategory === 'All' || prod.category === selectedCategory;
    const matchesSearch =
      prod.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prod.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prod.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    addProduct({
      title: newTitle.trim(),
      category: newCategory,
      price: parseFloat(newPrice) || 10,
      stock: parseInt(newStock, 10) || 1,
      sku: newSku.trim() || `SKU-${Date.now()}`,
      image: newImage,
      description: newDesc.trim() || 'High quality equipment listed for institutional procurement.',
      inStock: parseInt(newStock, 10) > 0,
    });

    setIsAddModalOpen(false);
    setNewTitle('');
    setNewDesc('');
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Digital Marketplace & Storefront
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Browse institutional supplies, hardware, and academic materials, or manage catalog inventories.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Segmented Catalog vs Inventory View Mode */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg">
            <button
              onClick={() => setViewMode('catalog')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                viewMode === 'catalog'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Storefront View
            </button>
            <button
              onClick={() => setViewMode('inventory')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                viewMode === 'inventory'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Inventory Manager
            </button>
          </div>

          {/* Add Product Button */}
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>List Product</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Strip */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Category Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors font-medium ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search catalog by title, SKU..."
            className="w-full pl-9 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs placeholder-slate-400 focus:outline-hidden focus:border-indigo-500"
          />
        </div>
      </div>

      {/* VIEW 1: CATALOG STOREFRONT */}
      {viewMode === 'catalog' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-slate-300 transition-all flex flex-col justify-between shadow-xs group"
            >
              <div>
                {/* Product Image Frame */}
                <div className="relative aspect-4/3 bg-slate-100 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                  />
                  {product.stock <= 5 && (
                    <div className="absolute top-2 right-2 bg-amber-600 text-white text-[11px] font-semibold px-2 py-0.5 rounded shadow-sm">
                      {product.stock === 0 ? 'Out of Stock' : `Only ${product.stock} left`}
                    </div>
                  )}
                </div>

                {/* Details */}
                <div className="p-4">
                  {/* Clean unboxed metadata with bullet separators */}
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1.5">
                    <span>{product.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-[11px]">{product.sku}</span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 mb-1 leading-snug">
                    {product.title}
                  </h3>
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {product.description}
                  </p>
                </div>
              </div>

              {/* Price & Add to Cart Footer */}
              <div className="p-4 pt-2 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-slate-400">Unit Price</div>
                  <div className="text-base font-bold text-slate-900 font-mono tabular-nums">
                    ${product.price.toFixed(2)}
                  </div>
                </div>

                <button
                  onClick={() => {
                    addToCart(product, 1);
                    setIsCartOpen(true);
                  }}
                  disabled={product.stock === 0}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 disabled:cursor-not-allowed rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Add to Cart</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* VIEW 2: INVENTORY MANAGEMENT TABLE */}
      {viewMode === 'inventory' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">
              Live Stock Ledger & Inventory Controls
            </h2>
            <div className="text-xs text-slate-500">
              {filteredProducts.length} items listed
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">Item & SKU</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4 text-right">Price</th>
                  <th className="py-3 px-4 text-center">Stock Count</th>
                  <th className="py-3 px-4 text-center">Quick Adjust</th>
                  <th className="py-3 px-4 text-right">Inventory Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-normal">
                {filteredProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 flex items-center gap-3">
                      <img
                        src={p.image}
                        alt={p.title}
                        referrerPolicy="no-referrer"
                        className="w-9 h-9 rounded-md object-cover border border-slate-200"
                      />
                      <div>
                        <div className="font-semibold text-slate-900">{p.title}</div>
                        <div className="font-mono text-[11px] text-slate-400">{p.sku}</div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-600">{p.category}</td>
                    <td className="py-3 px-4 text-right font-mono font-medium text-slate-900 tabular-nums">
                      ${p.price.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-bold text-slate-800 tabular-nums">
                      {p.stock} units
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => updateStock(p.id, p.stock - 1)}
                          className="p-1 hover:text-red-600 rounded text-slate-400 hover:bg-slate-100"
                          title="Decrease stock by 1"
                        >
                          <MinusCircle className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => updateStock(p.id, p.stock + 5)}
                          className="px-2 py-0.5 text-[11px] bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-medium"
                          title="Restock +5"
                        >
                          +5
                        </button>
                        <button
                          onClick={() => updateStock(p.id, p.stock + 1)}
                          className="p-1 hover:text-emerald-600 rounded text-slate-400 hover:bg-slate-100"
                          title="Increase stock by 1"
                        >
                          <PlusCircle className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {p.stock > 10 ? (
                        <span className="text-emerald-700 font-medium">In Stock</span>
                      ) : p.stock > 0 ? (
                        <span className="text-amber-700 font-medium">Low Stock</span>
                      ) : (
                        <span className="text-red-700 font-medium">Depleted</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL: ADD PRODUCT */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h2 className="text-base font-bold text-slate-900">List New Store Item</h2>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Product Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Scientific Graphing Calculator V4"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as Product['category'])}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    <option value="Tech & Hardware">Tech & Hardware</option>
                    <option value="Stationery & Books">Stationery & Books</option>
                    <option value="STEM & Robotics">STEM & Robotics</option>
                    <option value="Office Furnishing">Office Furnishing</option>
                    <option value="Uniforms & Apparel">Uniforms & Apparel</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">SKU Code</label>
                  <input
                    type="text"
                    required
                    value={newSku}
                    onChange={(e) => setNewSku(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Price ($ USD)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Initial Stock Count</label>
                  <input
                    type="number"
                    required
                    value={newStock}
                    onChange={(e) => setNewStock(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Select Catalog Asset Image</label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: 'Laptop Station', src: '/src/assets/images/marketplace_laptop_station_1793373690260.jpg' },
                    { label: 'Stationery Set', src: '/src/assets/images/marketplace_stationery_set_1793373690992.jpg' },
                    { label: 'STEM Lab Kit', src: '/src/assets/images/marketplace_stem_lab_kit_1793373691758.jpg' },
                    { label: 'Office Chair', src: '/src/assets/images/marketplace_office_chair_1793373696140.jpg' },
                  ].map((img) => (
                    <button
                      type="button"
                      key={img.src}
                      onClick={() => setNewImage(img.src)}
                      className={`relative rounded-lg overflow-hidden border-2 aspect-square p-0.5 transition-all ${
                        newImage === img.src ? 'border-indigo-600 ring-2 ring-indigo-200' : 'border-slate-200 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={img.src} alt={img.label} className="w-full h-full object-cover rounded" />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Details regarding technical specifications, warranty, and compatibility..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Publish Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
