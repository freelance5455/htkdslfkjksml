import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Order, OrderStatus } from '../../types';
import {
  FileText,
  Search,
  Truck,
  CheckCircle2,
  Clock,
  PackageCheck,
  ChevronRight,
  Filter,
} from 'lucide-react';

export const OrderManagerView: React.FC = () => {
  const { orders, updateOrderStatus, setSelectedReceiptOrder } = useApp();
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeOrderDetail, setActiveOrderDetail] = useState<Order | null>(orders[0] || null);

  const statuses = ['all', 'pending', 'processing', 'shipped', 'delivered', 'cancelled'];

  const filteredOrders = orders.filter((o) => {
    const matchesStatus = selectedStatus === 'all' || o.status === selectedStatus;
    const matchesQuery =
      o.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerDepartment.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesQuery;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Order Management & Fulfillment
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Track order status lifecycles, courier dispatches, department invoice verifications, and digital receipt generation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Order #, Name..."
              className="pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs placeholder-slate-400 focus:outline-hidden focus:border-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto text-xs pb-1">
        {statuses.map((status) => (
          <button
            key={status}
            onClick={() => setSelectedStatus(status)}
            className={`px-3 py-1.5 rounded-lg font-medium capitalize whitespace-nowrap transition-colors ${
              selectedStatus === status
                ? 'bg-slate-900 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {status}
          </button>
        ))}
      </div>

      {/* Main Split: Orders List and Order Timeline Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Orders Table */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">Order Details</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4 text-right">Total Amount</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400">
                      No orders found matching criteria.
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((ord) => {
                    const isSelected = activeOrderDetail?.id === ord.id;
                    return (
                      <tr
                        key={ord.id}
                        onClick={() => setActiveOrderDetail(ord)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-indigo-50/50' : 'hover:bg-slate-50/70'
                        }`}
                      >
                        <td className="py-3.5 px-4">
                          <div className="font-mono font-bold text-slate-900">{ord.id}</div>
                          <div className="text-slate-600 font-medium">{ord.customerName}</div>
                          <div className="text-[11px] text-slate-400">{ord.orderDate}</div>
                        </td>
                        <td className="py-3.5 px-4 text-slate-600">
                          <div>{ord.customerDepartment}</div>
                          <div className="text-[11px] text-slate-400 font-mono">{ord.items.length} items</div>
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                          ${ord.total.toFixed(2)}
                          <div className="text-[11px] text-slate-400 font-normal">{ord.paymentMethod}</div>
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          {/* Unboxed clean status with typography indicator */}
                          <div className="font-semibold capitalize text-xs">
                            {ord.status === 'delivered' && (
                              <span className="text-emerald-700">Delivered</span>
                            )}
                            {ord.status === 'shipped' && (
                              <span className="text-indigo-700">In Transit</span>
                            )}
                            {ord.status === 'processing' && (
                              <span className="text-amber-700">Processing</span>
                            )}
                            {ord.status === 'pending' && (
                              <span className="text-slate-600">Pending</span>
                            )}
                            {ord.status === 'cancelled' && (
                              <span className="text-red-700">Cancelled</span>
                            )}
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedReceiptOrder(ord);
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                            title="Generate Official Digital Receipt"
                          >
                            <FileText className="w-3.5 h-3.5 text-indigo-600" />
                            <span>Receipt</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 1 Col: Order Timeline & Status Progression */}
        {activeOrderDetail ? (
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                    Order Inspection
                  </div>
                  <h3 className="text-base font-bold text-slate-900 font-mono">
                    {activeOrderDetail.id}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedReceiptOrder(activeOrderDetail)}
                  className="px-3 py-1.5 text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <FileText className="w-3.5 h-3.5" />
                  View Receipt
                </button>
              </div>

              {/* Status Update Dropdown */}
              <div className="my-4 p-3 bg-slate-50 rounded-lg border border-slate-200">
                <label className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                  Update Order Pipeline Status
                </label>
                <select
                  value={activeOrderDetail.status}
                  onChange={(e) => updateOrderStatus(activeOrderDetail.id, e.target.value as OrderStatus)}
                  className="w-full bg-white border border-slate-300 rounded-md px-3 py-1.5 text-xs font-semibold text-slate-800 focus:outline-hidden focus:border-indigo-500"
                >
                  <option value="pending">Pending Review</option>
                  <option value="processing">Processing & Packaged</option>
                  <option value="shipped">Shipped via Campus Courier</option>
                  <option value="delivered">Delivered & Handed Over</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>

              {/* Itemized list */}
              <div className="space-y-2 mb-4">
                <div className="text-xs font-bold text-slate-700">Order Items</div>
                {activeOrderDetail.items.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs py-1.5 border-b border-slate-50">
                    <div className="truncate max-w-[180px]">
                      <div className="font-medium text-slate-900 truncate">{item.product.title}</div>
                      <div className="text-[11px] text-slate-400 font-mono">Qty: {item.quantity} × ${item.product.price.toFixed(2)}</div>
                    </div>
                    <div className="font-mono font-semibold text-slate-800">
                      ${(item.quantity * item.product.price).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>

              {/* Timeline Steps */}
              <div>
                <div className="text-xs font-bold text-slate-700 mb-2">Tracking History</div>
                <div className="space-y-3 relative before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 pl-6">
                  {activeOrderDetail.timeline.map((evt, i) => (
                    <div key={i} className="relative text-xs">
                      <div className="absolute -left-6 top-1 w-2.5 h-2.5 rounded-full bg-indigo-600 ring-4 ring-white" />
                      <div className="font-semibold text-slate-900 capitalize">{evt.status}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{evt.date}</div>
                      <div className="text-slate-600 text-[11px] mt-0.5">{evt.description}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Destination summary */}
            <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500">
              <span className="font-semibold text-slate-700">Destination:</span> {activeOrderDetail.shippingAddress}
            </div>
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-slate-400 flex flex-col items-center justify-center">
            <p className="text-xs">Select an order from the ledger to view tracking status.</p>
          </div>
        )}
      </div>
    </div>
  );
};
