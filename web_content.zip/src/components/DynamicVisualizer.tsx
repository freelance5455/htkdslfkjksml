import React, { useEffect, useRef } from 'react';
import { audioEngine, EQ_FREQUENCIES } from '../services/audioEngine';
import { VisualizerMode } from '../types/audio';

interface Props {
  mode: VisualizerMode;
  isPlaying: boolean;
  beatStrength: number;
  bpm: number;
  className?: string;
}

export const DynamicVisualizer: React.FC<Props> = ({
  mode,
  isPlaying,
  beatStrength,
  bpm,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const freqData = new Uint8Array(256);
    const timeData = new Uint8Array(256);
    let rotation = 0;
    const peakBars = new Array(EQ_FREQUENCIES.length).fill(0);

    const render = () => {
      animId = requestAnimationFrame(render);
      const width = canvas.width;
      const height = canvas.height;

      // Clear with dark transparent fade for subtle motion blur
      ctx.fillStyle = 'rgba(9, 10, 15, 0.35)';
      ctx.fillRect(0, 0, width, height);

      audioEngine.getVisualizerData(freqData, timeData);
      const rhythm = audioEngine.getRhythmState();
      const pulse = rhythm.beatStrength;

      if (mode === 'spectre') {
        // Kinetic Radial Pulsar
        const centerX = width / 2;
        const centerY = height / 2;
        const baseRadius = Math.min(width, height) * 0.22 + pulse * 14;
        rotation += 0.006 + pulse * 0.012;

        const numPoints = 64;
        const angleStep = (Math.PI * 2) / numPoints;

        // Outer frequency ring
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(rotation);

        // Ambient inner glow
        const radGrad = ctx.createRadialGradient(0, 0, baseRadius * 0.4, 0, 0, baseRadius * 1.5);
        radGrad.addColorStop(0, `rgba(99, 102, 241, ${0.15 + pulse * 0.35})`);
        radGrad.addColorStop(0.6, `rgba(236, 72, 153, ${0.08 + pulse * 0.2})`);
        radGrad.addColorStop(1, 'rgba(9, 10, 15, 0)');
        ctx.fillStyle = radGrad;
        ctx.beginPath();
        ctx.arc(0, 0, baseRadius * 1.6, 0, Math.PI * 2);
        ctx.fill();

        ctx.beginPath();
        for (let i = 0; i < numPoints; i++) {
          const angle = i * angleStep;
          const dataIdx = Math.floor((i / numPoints) * 80);
          const val = isPlaying ? freqData[dataIdx] || 0 : Math.sin(i + rotation * 2) * 10 + 20;
          const r = baseRadius + (val / 255) * (height * 0.22);
          const x = Math.cos(angle) * r;
          const y = Math.sin(angle) * r;

          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();

        ctx.strokeStyle = `rgba(${120 + Math.floor(pulse * 135)}, ${100 + Math.floor(pulse * 80)}, 255, 0.85)`;
        ctx.lineWidth = 2.5 + pulse * 1.5;
        ctx.shadowColor = '#6366f1';
        ctx.shadowBlur = 12 + pulse * 16;
        ctx.stroke();

        // Inner circle
        ctx.beginPath();
        ctx.arc(0, 0, baseRadius * 0.75, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.restore();

      } else if (mode === 'waves') {
        // Fluid Glowing Waveform
        ctx.lineWidth = 2.5 + pulse * 1.5;
        ctx.strokeStyle = '#38bdf8';
        ctx.shadowColor = '#0284c7';
        ctx.shadowBlur = 10 + pulse * 14;

        ctx.beginPath();
        const sliceWidth = width / 128;
        let x = 0;

        for (let i = 0; i < 128; i++) {
          const v = (timeData[i * 2] || 128) / 128.0;
          const dynamicAmp = isPlaying ? (height * 0.35) * (1 + pulse * 0.5) : 8;
          const y = (v * (height / 2)) + (height / 4) + (Math.sin(i * 0.1 + rotation) * 4);

          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);

          x += sliceWidth;
        }
        ctx.stroke();

        // Harmonic secondary wave
        ctx.beginPath();
        ctx.lineWidth = 1.5;
        ctx.strokeStyle = 'rgba(236, 72, 153, 0.55)';
        ctx.shadowColor = '#ec4899';
        ctx.shadowBlur = 8;
        x = 0;
        for (let i = 0; i < 128; i++) {
          const v = (timeData[i * 2 + 1] || 128) / 128.0;
          const y = height / 2 + (v - 1) * (height * 0.28);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
          x += sliceWidth;
        }
        ctx.stroke();

      } else if (mode === 'bars') {
        // Studio 10-Band EQ Bars with peak decay
        const count = EQ_FREQUENCIES.length;
        const totalPadding = (count + 1) * 8;
        const barWidth = Math.max(12, (width - totalPadding) / count);
        const startX = (width - (count * barWidth + (count - 1) * 8)) / 2;

        const binStep = Math.floor(120 / count);

        for (let i = 0; i < count; i++) {
          const binStart = i * binStep;
          let sum = 0;
          for (let b = 0; b < binStep; b++) {
            sum += freqData[binStart + b] || 0;
          }
          const avg = sum / binStep;
          const rawHeight = isPlaying ? (avg / 255) * (height * 0.75) : 6;
          const h = Math.max(4, rawHeight);

          if (h > peakBars[i]) {
            peakBars[i] = h;
          } else {
            peakBars[i] = Math.max(0, peakBars[i] - 1.2);
          }

          const bx = startX + i * (barWidth + 8);
          const by = height - h - 16;

          // Bar gradient
          const grad = ctx.createLinearGradient(0, height - 16, 0, by);
          grad.addColorStop(0, '#06b6d4');
          grad.addColorStop(0.6, '#6366f1');
          grad.addColorStop(1, '#ec4899');

          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.roundRect(bx, by, barWidth, h, [4, 4, 0, 0]);
          ctx.fill();

          // Peak cap indicator
          ctx.fillStyle = '#f43f5e';
          const peakY = height - peakBars[i] - 18;
          ctx.fillRect(bx, peakY, barWidth, 2.5);
        }

      } else if (mode === 'aura') {
        // Ambient Dynamic Glow Aura
        const centerX = width / 2;
        const centerY = height / 2;
        const auraRadius = Math.min(width, height) * 0.45 + pulse * 28;

        const grad = ctx.createRadialGradient(
          centerX,
          centerY,
          auraRadius * 0.1,
          centerX,
          centerY,
          auraRadius
        );

        const hue = (rotation * 40) % 360;
        grad.addColorStop(0, `hsla(${hue}, 85%, 60%, ${0.25 + pulse * 0.45})`);
        grad.addColorStop(0.5, `hsla(${(hue + 60) % 360}, 80%, 50%, ${0.12 + pulse * 0.25})`);
        grad.addColorStop(1, 'rgba(9, 10, 15, 0)');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(centerX, centerY, auraRadius, 0, Math.PI * 2);
        ctx.fill();
        rotation += 0.01;
      }
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [mode, isPlaying]);

  return (
    <div className={`relative w-full h-full overflow-hidden ${className}`}>
      <canvas
        ref={canvasRef}
        width={600}
        height={320}
        className="w-full h-full object-cover block"
      />
    </div>
  );
};
