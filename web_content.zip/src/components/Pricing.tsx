import { useState } from "react";
import { pricingPlans } from "../data/content";
import { cn } from "../utils/cn";
import { CheckIcon, ArrowRightIcon } from "./icons";

export function Pricing() {
  const [annual, setAnnual] = useState(true);

  return (
    <section id="pricing" className="relative py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0 mesh-gradient opacity-50" />

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <p className="reveal text-sm font-semibold tracking-wider text-brand-400 uppercase">
            Pricing
          </p>
          <h2 className="reveal delay-100 mt-3 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            Simple plans that{" "}
            <span className="text-gradient-brand">scale with you</span>
          </h2>
          <p className="reveal delay-200 mt-4 text-base text-ink-400 sm:text-lg">
            Start free for 14 days. Upgrade when your workflows start saving
            real hours—and real money.
          </p>

          {/* Billing toggle */}
          <div className="reveal delay-300 mt-8 flex items-center justify-center gap-3">
            <span
              className={cn(
                "text-sm font-medium transition-colors",
                !annual ? "text-white" : "text-ink-500"
              )}
            >
              Monthly
            </span>
            <button
              type="button"
              role="switch"
              aria-checked={annual}
              aria-label="Toggle annual billing"
              onClick={() => setAnnual((v) => !v)}
              className={cn(
                "relative h-7 w-12 rounded-full transition-colors duration-300",
                annual ? "bg-brand-600" : "bg-white/15"
              )}
            >
              <span
                className={cn(
                  "absolute top-0.5 left-0.5 h-6 w-6 rounded-full bg-white shadow-md transition-transform duration-300",
                  annual && "translate-x-5"
                )}
              />
            </button>
            <span
              className={cn(
                "text-sm font-medium transition-colors",
                annual ? "text-white" : "text-ink-500"
              )}
            >
              Annual
              <span className="ml-1.5 rounded-full bg-brand-500/20 px-2 py-0.5 text-xs font-semibold text-brand-300">
                Save 20%
              </span>
            </span>
          </div>
        </div>

        <div className="mt-12 grid items-stretch gap-5 lg:grid-cols-3">
          {pricingPlans.map((plan, i) => {
            const price =
              plan.price === null
                ? null
                : annual
                  ? Math.round(plan.price * 0.8)
                  : plan.price;

            const delays = ["delay-100", "delay-200", "delay-300"] as const;
            return (
              <article
                key={plan.name}
                className={cn(
                  `reveal ${delays[i]} relative flex flex-col rounded-2xl border p-6 sm:p-8 transition-all duration-500`,
                  plan.highlighted
                    ? "border-brand-400/40 bg-gradient-to-b from-brand-500/15 via-white/[0.04] to-white/[0.02] glow-brand scale-[1.02] lg:scale-105 z-10"
                    : "border-white/8 bg-white/[0.03] card-lift"
                )}
              >
                {plan.badge && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="rounded-full bg-gradient-to-r from-brand-500 to-violet-600 px-3 py-1 text-xs font-semibold text-white shadow-lg shadow-brand-600/40">
                      {plan.badge}
                    </span>
                  </div>
                )}

                <div>
                  <h3 className="text-lg font-semibold text-white">
                    {plan.name}
                  </h3>
                  <p className="mt-2 text-sm text-ink-400">{plan.description}</p>
                </div>

                <div className="mt-6 flex items-baseline gap-1">
                  {price !== null ? (
                    <>
                      <span className="text-4xl font-semibold tracking-tight text-white">
                        ${price}
                      </span>
                      <span className="text-sm text-ink-500">{plan.period}</span>
                    </>
                  ) : (
                    <span className="text-4xl font-semibold tracking-tight text-white">
                      Custom
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  className={cn(
                    "mt-6 w-full justify-center",
                    plan.highlighted ? "btn-primary" : "btn-secondary"
                  )}
                >
                  {plan.cta}
                  <ArrowRightIcon size={16} />
                </button>

                <ul className="mt-8 flex-1 space-y-3 border-t border-white/8 pt-6">
                  {plan.features.map((f) => (
                    <li
                      key={f}
                      className="flex items-start gap-2.5 text-sm text-ink-300"
                    >
                      <CheckIcon
                        size={16}
                        className={cn(
                          "mt-0.5 shrink-0",
                          plan.highlighted ? "text-brand-300" : "text-ink-500"
                        )}
                      />
                      {f}
                    </li>
                  ))}
                </ul>
              </article>
            );
          })}
        </div>

        <p className="reveal mt-8 text-center text-sm text-ink-500">
          All plans include SSL, 99.99% uptime SLA, and unlimited viewers.{" "}
          <button type="button" className="text-brand-300 underline-offset-2 hover:underline">
            Compare plans in detail →
          </button>
        </p>
      </div>
    </section>
  );
}
