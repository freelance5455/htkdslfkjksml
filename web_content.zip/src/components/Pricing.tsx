import { useState } from "react";
import { BadgeCheck, Check, ChevronRight, Code2, ShoppingBag, Sparkles } from "lucide-react";
import { EXTRA_PLANS, PLANS } from "../lib/data";

export default function Pricing() {
  const [yearly, setYearly] = useState(true);

  return (
    <section id="precios" className="scroll-mt-28 mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20">
      <div className="mx-auto max-w-3xl text-center">
        <p className="eyebrow">Modelo transparente</p>
        <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-white sm:text-5xl">
          Empieza gratis.<br /><span className="grad-text">Mejora cuando quieras.</span>
        </h2>
        <p className="mt-3 text-slate-400">FREE para siempre. Sin permanencia. Cancela en un toque y conserva tus funciones gratuitas.</p>

        {/* billing toggle */}
        <div className="mt-6 inline-flex items-center rounded-2xl border border-white/10 bg-white/5 p-1.5" role="group" aria-label="Periodo de facturación">
          <button onClick={() => setYearly(false)} aria-pressed={!yearly} className={`h-10 rounded-xl px-5 text-sm font-semibold transition-all ${!yearly ? "bg-panel3 text-white shadow" : "text-slate-400 hover:text-white"}`}>Mensual</button>
          <button onClick={() => setYearly(true)} aria-pressed={yearly} className={`flex h-10 items-center gap-2 rounded-xl px-5 text-sm font-semibold transition-all ${yearly ? "grad-btn text-white" : "text-slate-400 hover:text-white"}`}>
            Anual <span className="rounded-md bg-black/30 px-1.5 py-0.5 text-[10px] font-black">−19%</span>
          </button>
        </div>
      </div>

      {/* main plans */}
      <div className="mt-10 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {PLANS.map((p) => {
          const price = yearly ? p.yearly : p.monthly;
          const perMonth = yearly && p.yearly > 0 ? (p.yearly / 12).toFixed(2) : null;
          const fmt = (n: number) => n.toFixed(2).replace(".", ",");
          return (
            <article
              key={p.id}
              className={`relative flex flex-col rounded-2xl border p-5 transition-transform duration-300 hover:-translate-y-1 ${
                p.popular
                  ? "border-cyanx/50 bg-gradient-to-b from-electric/25 via-[#0a1136] to-[#0a1136] shadow-[0_0_60px_-15px_rgba(47,123,255,0.5)]"
                  : "tile"
              }`}
            >
              {p.popular && (
                <span className="absolute -top-3 left-1/2 flex -translate-x-1/2 items-center gap-1.5 whitespace-nowrap rounded-full bg-gradient-to-r from-cyan-400 to-blue-600 px-4 py-1.5 text-[10px] font-black uppercase tracking-widest text-[#03102a]">
                  <Sparkles size={11} /> Más popular
                </span>
              )}
              <h3 className="font-display text-lg font-black tracking-wide" style={{ color: p.accent }}>{p.name}</h3>
              <p className="text-[11px] uppercase tracking-widest text-slate-500">{p.tagline}</p>
              <p className="mt-4 flex items-end gap-2">
                <span className="font-display text-4xl font-black text-white">{price === 0 ? "0 €" : `${fmt(price)} €`}</span>
                <span className="pb-1.5 text-[11px] leading-tight text-slate-500">
                  {price === 0 ? "para siempre" : yearly ? "/año" : "/mes"}
                  {perMonth && <><br />≈ {perMonth.replace(".", ",")} €/mes</>}
                </span>
              </p>
              <ul className="mt-4 flex-1 space-y-2 text-[12px] text-slate-200">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2"><Check size={13} strokeWidth={3.5} className="mt-0.5 shrink-0 text-emerald-400" />{f}</li>
                ))}
              </ul>
              <a
                href="#descargar"
                className={`mt-5 flex h-11 items-center justify-center gap-1.5 rounded-xl text-sm font-bold transition-all ${
                  p.popular ? "grad-btn text-white" : "ghost-btn text-white"
                }`}
              >
                {p.cta} <ChevronRight size={15} />
              </a>
            </article>
          );
        })}
      </div>

      {/* STORE + DEVELOPER */}
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        {EXTRA_PLANS.map((p) => (
          <div key={p.id} className="tile flex flex-col items-start justify-between gap-4 rounded-2xl p-5 sm:flex-row sm:items-center">
            <div className="flex items-start gap-4">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-panel3 text-cyanx">
                {p.id === "store" ? <ShoppingBag size={22} /> : <Code2 size={22} />}
              </span>
              <div>
                <p className="font-display text-base font-black text-white">TV LO3 {p.name} <span className="ml-1 align-middle text-[10px] font-bold uppercase tracking-widest text-slate-500">{p.price}</span></p>
                <p className="mt-1 max-w-md text-xs leading-snug text-slate-400">{p.detail}</p>
              </div>
            </div>
            <a href="#descargar" className="ghost-btn flex h-10 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl px-4 text-xs font-bold text-white">{p.cta} <ChevronRight size={13} /></a>
          </div>
        ))}
      </div>

      <p className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[11px] text-slate-500">
        {["IVA incluido", "Sin permanencia", "7 días de prueba en PREMIUM", "Cancela en un toque", "Tus datos nunca se venden"].map((t) => (
          <span key={t} className="flex items-center gap-1.5"><BadgeCheck size={13} className="text-emerald-400" />{t}</span>
        ))}
      </p>
    </section>
  );
}
