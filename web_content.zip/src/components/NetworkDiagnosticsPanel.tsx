import React, { useState, useEffect } from 'react';
import { nativeSocketEngine, SocketConnectionState } from '../lib/magicIpEngine';
import { Activity, Server, Zap, ShieldCheck, RefreshCw, AlertTriangle } from 'lucide-react';

export const NetworkDiagnosticsPanel: React.FC = () => {
  const [socketState, setSocketState] = useState<SocketConnectionState>(nativeSocketEngine.getState());
  const [isPinging, setIsPinging] = useState(false);

  useEffect(() => {
    const unsubscribe = nativeSocketEngine.subscribe((state) => {
      setSocketState(state);
    });
    return () => unsubscribe();
  }, []);

  const handleManualPing = () => {
    setIsPinging(true);
    // Disconnect and reconnect to force a fresh ping test cycle
    nativeSocketEngine.disconnect();
    setTimeout(() => {
      nativeSocketEngine.connect();
      setTimeout(() => setIsPinging(false), 1000);
    }, 500);
  };

  return (
    <div className="bg-slate-900 border-2 border-indigo-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      
      <div className="space-y-2 relative z-10 border-b border-indigo-500/20 pb-5 flex justify-between items-center">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold font-serif text-amber-100 flex items-center space-x-3">
            <Activity className="w-6 h-6 text-emerald-400" />
            <span>Network Diagnostics (Non-Webbase)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">Live WebSocket & BGP monitoring for the Standalone Virtual Engine.</p>
        </div>
        
        <button
          onClick={handleManualPing}
          disabled={isPinging}
          className="px-4 py-2 bg-indigo-500 hover:bg-indigo-400 text-slate-900 text-xs font-bold rounded-xl flex items-center space-x-2 transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isPinging ? 'animate-spin' : ''}`} />
          <span>{isPinging ? 'Pinging Node...' : 'Ping Connection'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative z-10">
        <div className="bg-slate-950 p-4 rounded-xl border border-indigo-500/20">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Live IP Target</div>
          <div className="text-lg font-mono font-bold text-emerald-400">142.250.190.46</div>
        </div>
        
        <div className="bg-slate-950 p-4 rounded-xl border border-indigo-500/20">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1 flex items-center space-x-1">
            <Server className="w-3 h-3" /> <span>Socket Status</span>
          </div>
          <div className={`text-lg font-bold flex items-center space-x-2 ${socketState.status === 'CONNECTED' ? 'text-emerald-400' : 'text-amber-400'}`}>
            {socketState.status === 'CONNECTED' && <ShieldCheck className="w-5 h-5" />}
            {socketState.status === 'DISCONNECTED' && <AlertTriangle className="w-5 h-5" />}
            <span>{socketState.status}</span>
          </div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-indigo-500/20">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1 flex items-center space-x-1">
            <Zap className="w-3 h-3" /> <span>Network Latency</span>
          </div>
          <div className="text-lg font-mono font-bold text-amber-300">
            {socketState.status === 'CONNECTED' ? `${socketState.latency} ms` : '---'}
          </div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-indigo-500/20">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Packet Stream</div>
          <div className="text-xs font-mono text-slate-400 space-y-1 mt-2">
            <div className="flex justify-between"><span>TX:</span> <span className="text-sky-400">{socketState.packetsSent} PKT</span></div>
            <div className="flex justify-between"><span>RX:</span> <span className="text-emerald-400">{socketState.packetsReceived} PKT</span></div>
          </div>
        </div>
      </div>
    </div>
  );
};
