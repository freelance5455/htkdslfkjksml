import { FILTERS, itemMatchesFilter, useAppStore } from "@/store/app-store";
import { getLeaguePrior } from "@/lib/engine/config";
import type { LiveItem } from "@/lib/engine/types";
import { MatchRow } from "@/components/match-row";
import { MatchDetail } from "@/components/match-detail";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/cn";

function groupByLeague(items: LiveItem[]) {
  const groups: { league: string; country?: string; rows: LiveItem[] }[] = [];
  const idx = new Map<string, number>();
  for (const it of items) {
    const key = it.match.league || "Liga";
    if (!idx.has(key)) {
      idx.set(key, groups.length);
      groups.push({ league: key, country: it.match.country, rows: [] });
    }
    groups[idx.get(key)!].rows.push(it);
  }
  return groups;
}

function LeagueHead({ league, country }: { league: string; country?: string }) {
  const prior = getLeaguePrior(league);
  const parts = league.split(":");
  const name = parts.length > 1 ? parts.slice(1).join(":").trim() : league;
  const sub = country || (parts.length > 1 ? parts[0] : prior.code);
  return (
    <div className="flex items-center gap-3 px-1 pb-2 pt-1">
      <span className="flex size-8 items-center justify-center rounded-lg bg-elevated font-mono text-[10px] font-bold text-accent shadow-[var(--shadow-border)]">
        {prior.code}
      </span>
      <div className="min-w-0">
        <div className="truncate text-[15px] font-semibold tracking-tight">{name}</div>
        {sub ? <div className="text-xs text-muted">{sub}</div> : null}
      </div>
    </div>
  );
}

export function LiveView() {
  const items = useAppStore((s) => s.items);
  const filter = useAppStore((s) => s.filter);
  const setFilter = useAppStore((s) => s.setFilter);
  const selectedId = useAppStore((s) => s.selectedId);
  const setSelected = useAppStore((s) => s.setSelected);
  const status = useAppStore((s) => s.status);
  const fetching = useAppStore((s) => s.fetching);

  const shown = items.filter((it) => itemMatchesFilter(it, filter));
  const groups = groupByLeague(shown);
  const selected = items.find((it) => it.match.id === selectedId) ?? shown[0] ?? null;
  const counts = Object.fromEntries(
    FILTERS.map((f) => [f.id, items.filter((it) => itemMatchesFilter(it, f.id)).length]),
  ) as Record<string, number>;

  return (
    <div className="mx-auto grid max-w-6xl gap-4 lg:grid-cols-[minmax(0,1fr)_400px] lg:items-start">
      <div>
        <div className="mb-3 flex items-end justify-between gap-3 px-1">
          <h1 className="text-xl font-semibold tracking-tight">Ao vivo</h1>
          <span className="text-sm font-medium text-hot tabular-nums">{items.length} jogos</span>
        </div>
        <div className="-mx-1 mb-4 flex gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              className={cn(
                "flex h-10 shrink-0 items-center gap-2 rounded-full px-3.5 text-xs font-semibold",
                filter === f.id
                  ? "bg-accent text-accent-fg"
                  : "bg-surface text-muted shadow-[var(--shadow-border)]",
              )}
            >
              {f.label}
              <b className="font-mono tabular-nums">{counts[f.id] ?? 0}</b>
            </button>
          ))}
        </div>

        {status === "loading" && !items.length ? (
          <div className="space-y-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-[92px] rounded-xl" />
            ))}
          </div>
        ) : !shown.length ? (
          <div className="rounded-2xl bg-surface px-6 py-16 text-center text-sm text-muted shadow-[var(--shadow-border)]">
            {fetching ? "A carregar jogos ao vivo…" : "Nenhum jogo neste filtro agora."}
          </div>
        ) : (
          <div className="space-y-5">
            {groups.map((g) => (
              <section key={g.league}>
                <LeagueHead league={g.league} country={g.country} />
                <div className="grid gap-2">
                  {g.rows.map((it) => (
                    <MatchRow
                      key={it.match.id}
                      item={it}
                      selected={selected?.match.id === it.match.id}
                      onSelect={() => setSelected(it.match.id)}
                    />
                  ))}
                </div>
              </section>
            ))}
          </div>
        )}

        <div className="mt-4 lg:hidden">
          {selected ? <MatchDetail item={selected} /> : null}
        </div>
      </div>

      <aside className="sticky top-4 hidden lg:block">
        <MatchDetail item={selected} />
      </aside>
    </div>
  );
}
