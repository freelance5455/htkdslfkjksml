"use client";

import { useEffect, useState } from "react";
import { DOOMSDAY_DATE } from "@/lib/palette";

type Remaining = { days: number; hours: number; minutes: number; seconds: number; done: boolean };

function computeRemaining(): Remaining {
  const target = new Date(DOOMSDAY_DATE).getTime();
  const diff = target - Date.now();
  if (diff <= 0) return { days: 0, hours: 0, minutes: 0, seconds: 0, done: true };
  return {
    days: Math.floor(diff / 86_400_000),
    hours: Math.floor((diff / 3_600_000) % 24),
    minutes: Math.floor((diff / 60_000) % 60),
    seconds: Math.floor((diff / 1000) % 60),
    done: false,
  };
}

export function Countdown({ compact = false }: { compact?: boolean }) {
  const [remaining, setRemaining] = useState<Remaining | null>(null);

  useEffect(() => {
    setRemaining(computeRemaining());
    const timer = setInterval(() => setRemaining(computeRemaining()), 1000);
    return () => clearInterval(timer);
  }, []);

  if (compact) {
    const cells: Array<[string, number]> = [
      ["g", remaining?.days ?? 0],
      ["h", remaining?.hours ?? 0],
      ["m", remaining?.minutes ?? 0],
      ["s", remaining?.seconds ?? 0],
    ];
    return (
      <div className="flex items-center gap-1 font-mono text-[11px] font-bold text-white/80 tabular-nums">
        {cells.map(([label, value], index) => (
          <span key={label} className="flex items-center gap-1">
            {index > 0 ? <span className="text-white/20">:</span> : null}
            <span className="rounded bg-black/40 px-1 py-0.5">
              {remaining === null ? "--" : String(value).padStart(2, "0")}
              <span className="ml-0.5 text-[8px] font-normal text-white/40">{label}</span>
            </span>
          </span>
        ))}
      </div>
    );
  }

  const cells: Array<[string, number]> = [
    ["Giorni", remaining?.days ?? 0],
    ["Ore", remaining?.hours ?? 0],
    ["Minuti", remaining?.minutes ?? 0],
    ["Secondi", remaining?.seconds ?? 0],
  ];

  return (
    <div>
      <div className="grid grid-cols-4 gap-2">
        {cells.map(([label, value]) => (
          <div
            key={label}
            className="rounded-xl border border-white/10 bg-black/40 px-2 py-2 text-center backdrop-blur-sm"
          >
            <p className="font-display text-2xl leading-none text-white tabular-nums sm:text-3xl">
              {remaining === null ? "--" : String(value).padStart(2, "0")}
            </p>
            <p className="mt-1 text-[9px] font-bold uppercase tracking-widest text-white/40">{label}</p>
          </div>
        ))}
      </div>
      <p className="mt-2 text-[10px] uppercase tracking-widest text-white/35">
        {remaining?.done ? "Doomsday è arrivato: buona visione!" : "Avengers: Doomsday · 18 dicembre 2026"}
      </p>
    </div>
  );
}
