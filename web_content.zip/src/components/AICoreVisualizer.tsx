import React, { useEffect, useRef, useState } from 'react';
import type { AssistantState } from '../types';

interface AICoreVisualizerProps {
  state: AssistantState;
  audioActivity: number;
  assistantName: string;
  onCoreTap: () => void;
  compact?: boolean;
  lowPowerActive?: boolean;
}

interface Particle {
  angle: number;
  radius: number;
  speed: number;
  size: number;
  alpha: number;
}

export const AICoreVisualizer: React.FC<AICoreVisualizerProps> = ({
  state,
  audioActivity,
  assistantName,
  onCoreTap,
  compact = false,
  lowPowerActive = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stateRef = useRef(state);
  const activityRef = useRef(audioActivity);
  const lowPowerRef = useRef(lowPowerActive);
  const [reducedMotion, setReducedMotion] = useState(false);

  stateRef.current = state;
  activityRef.current = audioActivity;
  lowPowerRef.current = lowPowerActive;

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  const isStaticFrame = reducedMotion || (lowPowerActive && state === 'IDLE');

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = lowPowerActive ? 1 : Math.min(window.devicePixelRatio || 1, 2);
    const size = compact ? 156 : 196;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width = `${size}px`;
    canvas.style.height = `${size}px`;

    const particles: Particle[] = lowPowerActive
      ? []
      : Array.from({ length: 18 }, (_, idx) => ({
          angle: (Math.PI * 2 * idx) / 18,
          radius: size * 0.34 + (idx % 3) * 10,
          speed: (idx % 2 === 0 ? 1 : -1) * (0.004 + (idx % 4) * 0.002),
          size: 1.3 + (idx % 3) * 0.5,
          alpha: 0.35 + (idx % 3) * 0.2,
        }));

    let rafId = 0;
    let tick = 0;
    let lastDrawTime = 0;

    const drawFrame = (timestamp = 0) => {
      const lowPower = lowPowerRef.current;
      const staticOnly = reducedMotion || (lowPower && stateRef.current === 'IDLE');

      if (!staticOnly && lowPower && timestamp - lastDrawTime < 80) {
        rafId = window.requestAnimationFrame(drawFrame);
        return;
      }
      lastDrawTime = timestamp;

      const currentState = stateRef.current;
      const activity = activityRef.current;
      const cx = size / 2;
      const cy = size / 2;

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, size, size);

      const speedMult =
        currentState === 'THINKING'
          ? 2.6
          : currentState === 'LISTENING'
            ? 1.7
            : currentState === 'SPEAKING'
              ? 2.0
              : 0.7;

      const timeScale = lowPower ? 0.05 : 0.016;
      const phase = staticOnly ? 0 : tick * timeScale * speedMult;
      const pulse = staticOnly
        ? 0
        : Math.sin(tick * (lowPower ? 0.14 : 0.05)) *
          (currentState === 'LISTENING' || currentState === 'SPEAKING'
            ? 4.5 * activity
            : currentState === 'THINKING'
              ? 3
              : 1.5);

      const primaryColor =
        currentState === 'LISTENING'
          ? '34, 211, 238'
          : currentState === 'THINKING'
            ? '56, 189, 248'
            : currentState === 'SPEAKING'
              ? '103, 232, 249'
              : '14, 165, 233';

      if (lowPower) {
        // Lightweight flat glow fill to reduce GPU/fill cost
        ctx.fillStyle = `rgba(${primaryColor}, ${currentState === 'IDLE' ? 0.07 : 0.14})`;
        ctx.beginPath();
        ctx.arc(cx, cy, size * 0.38 + pulse * 0.4, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Ambient radial core glow
        const glowRadius = size * 0.46 + pulse;
        const glow = ctx.createRadialGradient(cx, cy, 8, cx, cy, glowRadius);
        glow.addColorStop(0, `rgba(${primaryColor}, ${currentState === 'IDLE' ? 0.22 : 0.38})`);
        glow.addColorStop(0.55, `rgba(${primaryColor}, 0.08)`);
        glow.addColorStop(1, 'rgba(4, 8, 18, 0)');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(cx, cy, glowRadius, 0, Math.PI * 2);
        ctx.fill();
      }

      // Subtle outer calibration ring
      ctx.strokeStyle = `rgba(${primaryColor}, 0.2)`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(cx, cy, size * 0.43, 0, Math.PI * 2);
      ctx.stroke();

      // Segmented rotating arc 1 (single ring in low power)
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(phase);
      ctx.strokeStyle = `rgba(${primaryColor}, ${lowPower ? 0.72 : 0.85})`;
      ctx.lineWidth = lowPower ? 2 : 2.6;
      ctx.lineCap = 'round';
      for (let i = 0; i < 3; i++) {
        const start = (i * Math.PI * 2) / 3 + 0.15;
        const end = start + Math.PI * 0.42;
        ctx.beginPath();
        ctx.arc(0, 0, size * 0.35 + pulse * 0.4, start, end);
        ctx.stroke();
      }
      ctx.restore();

      if (!lowPower) {
        // Counter-rotating dashed inner arc 2
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(-phase * 1.35);
        ctx.strokeStyle = 'rgba(125, 211, 252, 0.55)';
        ctx.lineWidth = 1.6;
        ctx.setLineDash([12, 10]);
        ctx.beginPath();
        ctx.arc(0, 0, size * 0.26, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();

        // Orbiting particles
        for (const p of particles) {
          if (!staticOnly) {
            p.angle += p.speed * speedMult;
          }
          const px = cx + Math.cos(p.angle) * (p.radius + pulse * 0.5);
          const py = cy + Math.sin(p.angle) * (p.radius + pulse * 0.5);
          ctx.fillStyle = `rgba(103, 232, 249, ${p.alpha})`;
          ctx.beginPath();
          ctx.arc(px, py, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Inner glowing energy ring + center nucleus
      const coreR = size * 0.145 + pulse * 0.45;
      ctx.fillStyle = `rgba(${primaryColor}, 0.16)`;
      ctx.strokeStyle = `rgba(${primaryColor}, 0.92)`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, coreR, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = currentState === 'IDLE' ? '#38bdf8' : '#a5f3fc';
      ctx.beginPath();
      ctx.arc(cx, cy, size * 0.055, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();

      if (!staticOnly) {
        tick += 1;
        rafId = window.requestAnimationFrame(drawFrame);
      }
    };

    drawFrame(performance.now());
    return () => {
      if (rafId) window.cancelAnimationFrame(rafId);
    };
  }, [compact, isStaticFrame, lowPowerActive, reducedMotion]);

  const statusLabel =
    state === 'LISTENING'
      ? 'LISTENING'
      : state === 'THINKING'
        ? 'PROCESSING'
        : state === 'SPEAKING'
          ? 'SPEAKING'
          : 'READY';

  const barCount = lowPowerActive ? 7 : 15;
  const isWaveActive = state === 'LISTENING' || state === 'SPEAKING' || state === 'THINKING';

  return (
    <div className="flex flex-col items-center select-none">
      <button
        type="button"
        onClick={onCoreTap}
        aria-label={
          state === 'LISTENING'
            ? `Stop listening to ${assistantName}`
            : state === 'SPEAKING'
              ? `Stop ${assistantName} speaking`
              : `Tap to talk to ${assistantName}`
        }
        className="group relative flex items-center justify-center rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 active:scale-[0.98] transition-transform"
      >
        <canvas ref={canvasRef} className="block" />
        <span className="sr-only">{statusLabel}</span>
      </button>

      {/* Real-time status & animated voice waveform */}
      <div className="mt-1 flex flex-col items-center gap-1.5">
        <div
          className="flex h-6 items-center justify-center gap-[3px]"
          aria-hidden="true"
        >
          {Array.from({ length: barCount }).map((_, idx) => {
            const centerWeight = 1 - Math.abs(idx - (barCount - 1) / 2) / ((barCount - 1) / 2);
            const activeHeight = isWaveActive
              ? Math.max(4, Math.round(6 + centerWeight * 16 * Math.max(0.35, audioActivity)))
              : 3;

            return (
              <span
                key={idx}
                className={`w-[3px] rounded-full ${lowPowerActive ? '' : 'transition-all duration-150'} ${
                  state === 'LISTENING'
                    ? 'bg-cyan-300'
                    : state === 'SPEAKING'
                      ? 'bg-sky-300'
                      : state === 'THINKING'
                        ? 'bg-sky-400/75'
                        : 'bg-sky-500/25'
                }`}
                style={{
                  height: `${activeHeight}px`,
                  opacity: isWaveActive ? 0.55 + centerWeight * 0.45 : 0.45,
                }}
              />
            );
          })}
        </div>

        <div className="flex items-center gap-2 text-xs font-medium tracking-wide text-sky-200/85">
          <span>{assistantName}</span>
          <span aria-hidden="true" className="text-sky-500/50">
            ·
          </span>
          <span
            className={
              state === 'LISTENING'
                ? 'text-cyan-300'
                : state === 'THINKING'
                  ? 'text-sky-300'
                  : state === 'SPEAKING'
                    ? 'text-cyan-200'
                    : 'text-slate-400'
            }
          >
            {statusLabel}
          </span>
          {lowPowerActive && (
            <>
              <span aria-hidden="true" className="text-sky-500/50">
                ·
              </span>
              <span className="text-amber-300">LOW POWER</span>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
