import React from 'react';
import { useGame } from '../context/GameContext.tsx';
import { getRequiredExp } from '../utils/gameLogic.ts';
import {
  Package,
  BookOpen,
  Settings,
  Sun,
  CloudRain,
  CloudFog,
  CloudLightning,
  Sparkles,
  Shovel,
  Flame,
  Moon,
  Clock,
} from 'lucide-react';

interface TopHUDProps {
  onOpenInventory: () => void;
  onOpenAlmanac: () => void;
  onOpenSettings: () => void;
}

export const TopHUD: React.FC<TopHUDProps> = ({
  onOpenInventory,
  onOpenAlmanac,
  onOpenSettings,
}) => {
  const { player, shovelModeActive, setShovelModeActive } = useGame();

  const reqExp = getRequiredExp(player.level);
  const expPercent = Math.min(100, Math.floor((player.currentExp / reqExp) * 100));

  const weatherIcons: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
    sunny: { label: 'Nắng Ấm', icon: <Sun className="w-3.5 h-3.5 text-amber-500 animate-spin-slow" />, color: 'bg-amber-100 text-amber-900 border-amber-300' },
    rainy: { label: 'Mưa Rào (Tự Tưới)', icon: <CloudRain className="w-3.5 h-3.5 text-blue-500" />, color: 'bg-blue-100 text-blue-900 border-blue-300' },
    foggy: { label: 'Sương Mù (+50% Quả/Nấm)', icon: <CloudFog className="w-3.5 h-3.5 text-slate-500" />, color: 'bg-slate-100 text-slate-900 border-slate-300' },
    stormy: { label: 'Dông Bão', icon: <CloudLightning className="w-3.5 h-3.5 text-purple-600" />, color: 'bg-purple-100 text-purple-900 border-purple-300' },
    rainbow: { label: 'Cầu Vồng (x2 Sản Lượng)', icon: <Sparkles className="w-3.5 h-3.5 text-pink-500 animate-bounce" />, color: 'bg-pink-100 text-pink-900 border-pink-300' },
  };

  const todConfig: Record<string, { label: string; icon: React.ReactNode; bg: string }> = {
    dawn: { label: 'Bình Minh (05:00 - 08:00)', icon: <Sun className="w-3.5 h-3.5 text-orange-400" />, bg: 'bg-orange-50 text-orange-950 border-orange-200' },
    day: { label: 'Ban Ngày (08:00 - 16:00)', icon: <Sun className="w-3.5 h-3.5 text-amber-500" />, bg: 'bg-amber-50 text-amber-950 border-amber-200' },
    golden: { label: 'Hoàng Hôn (Ánh Kim ⭐)', icon: <Flame className="w-3.5 h-3.5 text-amber-600" />, bg: 'bg-yellow-100 text-amber-950 border-yellow-300' },
    dusk: { label: 'Chập Tối (18:00 - 20:00)', icon: <Moon className="w-3.5 h-3.5 text-indigo-400" />, bg: 'bg-indigo-50 text-indigo-950 border-indigo-200' },
    night: { label: 'Đêm Trăng (Nguyệt Quang x2)', icon: <Moon className="w-3.5 h-3.5 text-purple-400" />, bg: 'bg-purple-900 text-purple-100 border-purple-700' },
    midnight: { label: 'Nửa Đêm (Vũ Trụ x2)', icon: <Sparkles className="w-3.5 h-3.5 text-cyan-300" />, bg: 'bg-slate-900 text-cyan-200 border-cyan-800' },
  };

  const currentWeather = weatherIcons[player.weather] || weatherIcons.sunny;
  const currentTod = todConfig[player.timeOfDay] || todConfig.day;

  return (
    <header className="sticky top-0 z-40 bg-stone-900/95 backdrop-blur-md border-b-2 border-stone-800 text-stone-100 shadow-md px-2 py-1.5 sm:px-4 sm:py-2">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-1.5 sm:gap-3 text-xs sm:text-sm">
        {/* Left: Level & EXP Bar */}
        <div className="flex items-center gap-2 min-w-[180px] sm:min-w-[240px]">
          <div className="flex items-center gap-1 bg-amber-500/20 border border-amber-400/40 rounded-lg px-2 py-0.5 font-bold text-amber-300 shadow-inner">
            <span className="text-[10px] sm:text-xs uppercase text-amber-200/80">Cấp</span>
            <span className="text-sm sm:text-base font-black text-amber-400">{player.level}</span>
          </div>

          <div className="flex-1 flex flex-col justify-center">
            <div className="flex justify-between items-center text-[10px] text-stone-300 font-semibold mb-0.5">
              <span>EXP</span>
              <span>
                {player.currentExp} / {reqExp} ({expPercent}%)
              </span>
            </div>
            <div className="w-full bg-stone-800 rounded-full h-2.5 overflow-hidden border border-stone-700/80 p-0.5">
              <div
                className="bg-gradient-to-r from-emerald-500 to-green-400 h-full rounded-full transition-all duration-300 shadow-sm"
                style={{ width: `${expPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Center: Currencies (Gold, Jade) */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-1.5 bg-stone-800/90 border border-amber-500/40 rounded-lg px-2 sm:px-2.5 py-1 text-amber-300 font-bold shadow-sm">
            <span className="text-sm sm:text-base">🪙</span>
            <span>{player.gold.toLocaleString()}</span>
          </div>

          <div className="flex items-center gap-1.5 bg-stone-800/90 border border-emerald-500/40 rounded-lg px-2 sm:px-2.5 py-1 text-emerald-300 font-bold shadow-sm">
            <span className="text-sm sm:text-base">💎</span>
            <span>{player.jade.toLocaleString()}</span>
          </div>
        </div>

        {/* Center-Right: Time of Day & Weather Badges */}
        <div className="hidden md:flex items-center gap-2 text-xs">
          <div
            className={`flex items-center gap-1 px-2 py-0.5 rounded-md border font-medium ${currentTod.bg}`}
            title="Thời khắc thực tế"
          >
            {currentTod.icon}
            <span>{currentTod.label}</span>
          </div>

          <div
            className={`flex items-center gap-1 px-2 py-0.5 rounded-md border font-medium ${currentWeather.color}`}
            title="Thời tiết hiện tại tác động trực tiếp nông trại"
          >
            {currentWeather.icon}
            <span>{currentWeather.label}</span>
          </div>

          {player.timeSpeed > 1 && (
            <span className="bg-amber-400 text-stone-950 font-black text-[10px] px-1.5 py-0.5 rounded shadow">
              {player.timeSpeed}x
            </span>
          )}
        </div>

        {/* Right: Quick action buttons */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          {/* Shovel tool toggle */}
          <button
            type="button"
            onClick={() => setShovelModeActive((prev) => !prev)}
            className={`flex items-center gap-1 px-2 py-1 rounded-lg border text-xs font-bold transition-colors ${
              shovelModeActive
                ? 'bg-rose-600 text-white border-rose-400 shadow-md ring-2 ring-rose-400 animate-pulse'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-200 border-stone-700'
            }`}
            title="Xẻng Đào Cây (Nhấn để bật chế độ đào bỏ cây trồng/gốc nấm)"
            aria-label="Xẻng Đào Cây"
          >
            <Shovel className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{shovelModeActive ? 'Đang bật Xẻng' : 'Xẻng'}</span>
          </button>

          {/* Inventory */}
          <button
            type="button"
            onClick={onOpenInventory}
            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-amber-300 border border-stone-700 text-xs font-semibold shadow-sm transition"
            aria-label="Mở Kho Đồ"
          >
            <Package className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Kho Đồ</span>
          </button>

          {/* Almanac */}
          <button
            type="button"
            onClick={onOpenAlmanac}
            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-emerald-300 border border-stone-700 text-xs font-semibold shadow-sm transition"
            aria-label="Mở Bách Khoa Toàn Thư"
          >
            <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Bách Khoa</span>
          </button>

          {/* Settings */}
          <button
            type="button"
            onClick={onOpenSettings}
            className="p-1 sm:px-2 sm:py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700 text-xs font-semibold transition"
            aria-label="Cài Đặt Game"
            title="Cài Đặt & Lưu Trữ Offline"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
