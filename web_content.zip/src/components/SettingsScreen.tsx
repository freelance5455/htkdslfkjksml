import React, { useState } from 'react';
import {
  HardDrive,
  Moon,
  Volume2,
  ShieldCheck,
  Upload,
  Sparkles,
  Smartphone,
  Trash2,
} from 'lucide-react';

interface SettingsScreenProps {
  storageStats: { songsSize: number; count: number };
  sleepTimerMinutes: number | null;
  onOpenSleepTimer: () => void;
  onCleanStorage: () => void;
  onImportPlaylist: (file: File) => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  storageStats,
  sleepTimerMinutes,
  onOpenSleepTimer,
  onCleanStorage,
  onImportPlaylist,
}) => {
  const [cleaned, setCleaned] = useState(false);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleClean = () => {
    onCleanStorage();
    setCleaned(true);
    setTimeout(() => setCleaned(false), 3000);
  };

  return (
    <div className="space-y-4 pb-28 pt-2">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-100">
          Settings
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          App preferences & local storage
        </p>
      </div>

      {/* Storage Management Card */}
      <div className="p-4 rounded-2xl bg-[#12181F] border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
          <HardDrive size={18} />
          <span>Storage Management</span>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-1">
          <div className="p-3 bg-[#1A232C] rounded-xl border border-slate-700/60">
            <span className="text-[11px] text-slate-400">Imported Audio Files</span>
            <p className="text-lg font-bold text-slate-100 mt-0.5">
              {formatBytes(storageStats.songsSize)}
            </p>
          </div>
          <div className="p-3 bg-[#1A232C] rounded-xl border border-slate-700/60">
            <span className="text-[11px] text-slate-400">Total Tracks</span>
            <p className="text-lg font-bold text-slate-100 mt-0.5">
              {storageStats.count} tracks
            </p>
          </div>
        </div>

        <div className="pt-2 flex items-center justify-between">
          <p className="text-xs text-slate-400">
            All imported songs are securely cached in client-side storage.
          </p>
          <button
            onClick={handleClean}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 hover:border-emerald-500 text-xs font-semibold text-slate-300 hover:text-emerald-400 transition-colors flex-shrink-0"
          >
            <Trash2 size={14} />
            <span>{cleaned ? 'Optimized!' : 'Optimize Cache'}</span>
          </button>
        </div>
      </div>

      {/* Sleep Timer Card */}
      <div className="p-4 rounded-2xl bg-[#12181F] border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
            <Moon size={18} />
            <span>Sleep Timer</span>
          </div>
          {sleepTimerMinutes !== null && (
            <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-500/40">
              Active: {sleepTimerMinutes}m remaining
            </span>
          )}
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          Automatically stops audio playback after a set duration so you can fall asleep listening to your favorite music.
        </p>

        <button
          onClick={onOpenSleepTimer}
          className="w-full py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors"
        >
          {sleepTimerMinutes !== null ? 'Change or Stop Timer' : 'Set Sleep Timer'}
        </button>
      </div>

      {/* Audio Controls & Focus Notice */}
      <div className="p-4 rounded-2xl bg-[#12181F] border border-slate-800 space-y-2">
        <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
          <Volume2 size={18} />
          <span>Playback Controls & Audio Focus</span>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          • <strong>Bluetooth Headsets</strong>: Full support for Play/Pause, Next Track, and Previous Track commands.
        </p>
        <p className="text-xs text-slate-400 leading-relaxed">
          • <strong>Audio Becoming Noisy</strong>: Music automatically pauses when headphones or Bluetooth devices disconnect.
        </p>
        <p className="text-xs text-slate-400 leading-relaxed">
          • <strong>Audio Focus</strong>: Automatically ducks or pauses during phone calls and navigation instructions.
        </p>
      </div>

      {/* Playlist JSON Transfer */}
      <div className="p-4 rounded-2xl bg-[#12181F] border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
          <Upload size={18} />
          <span>Playlist JSON Import</span>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          Transfer playlists across devices or browsers using standard JSON files matching the app's metadata schema.
        </p>
        <label className="flex items-center justify-center gap-2 w-full py-2 rounded-xl border border-slate-700 hover:border-emerald-500 text-xs font-semibold text-slate-300 hover:text-emerald-400 cursor-pointer transition-colors">
          <Upload size={14} />
          <span>Select Playlist JSON File</span>
          <input
            type="file"
            accept=".json,application/json"
            onChange={(e) => {
              if (e.target.files?.[0]) onImportPlaylist(e.target.files[0]);
            }}
            className="hidden"
          />
        </label>
      </div>

      {/* Privacy Guarantee */}
      <div className="p-4 rounded-2xl bg-[#12181F] border border-slate-800 space-y-2">
        <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
          <ShieldCheck size={18} />
          <span>Privacy & Offline Guarantee</span>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          This music player is 100% offline. All audio files, artwork, custom tags, playlists, and listening statistics are stored locally on your device in private storage. Zero tracking, zero telemetry, zero analytics.
        </p>
      </div>

      {/* Android Native Integration */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 to-[#12181F] border border-emerald-500/20 space-y-2">
        <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
          <Smartphone size={18} />
          <span>Android App Included</span>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          A companion native Android project with Jetpack Compose, Room Database, and Media3 ExoPlayer background service is compiled in the repository at <code className="text-emerald-400">/app</code> ready for APK export.
        </p>
      </div>
    </div>
  );
};
