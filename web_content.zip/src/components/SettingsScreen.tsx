import React, { useState } from 'react';
import { Volume2, VolumeX, Sparkles, Vibrate, Trash2, Info, AlertTriangle } from 'lucide-react';
import { PlayerSettings } from '../types/crossword';
import { soundManager } from '../utils/audio';

interface SettingsScreenProps {
  settings: PlayerSettings;
  onUpdateSettings: (newSettings: PlayerSettings) => void;
  onResetAllProgress: () => void;
  onOpenAbout: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  onUpdateSettings,
  onResetAllProgress,
  onOpenAbout,
}) => {
  const [showConfirmResetAll, setShowConfirmResetAll] = useState(false);

  const toggleSound = () => {
    const nextVal = !settings.sound;
    const newSettings = { ...settings, sound: nextVal };
    soundManager.setSettings(newSettings);
    if (nextVal) {
      soundManager.playKeyClick();
    }
    onUpdateSettings(newSettings);
  };

  const toggleEffects = () => {
    const nextVal = !settings.effects;
    const newSettings = { ...settings, effects: nextVal };
    soundManager.setSettings(newSettings);
    if (nextVal) {
      soundManager.playWordComplete();
    }
    onUpdateSettings(newSettings);
  };

  const toggleVibration = () => {
    const nextVal = !settings.vibration;
    const newSettings = { ...settings, vibration: nextVal };
    soundManager.setSettings(newSettings);
    if (nextVal) {
      soundManager.vibrate([40, 50, 40]);
    }
    onUpdateSettings(newSettings);
  };

  return (
    <div className="flex-1 flex flex-col p-4 sm:p-6 max-w-md mx-auto w-full">
      <div className="bg-[#f8f4ed] border-2 border-[#2c2c2c] newspaper-border-double p-4 shadow-xs mb-6 text-center">
        <h2 className="newspaper-font text-2xl font-bold text-[#1a1a1a]">
          إعدادات اللعبة
        </h2>
        <p className="text-xs text-[#2c2c2c] mt-1">
          تخصيص تجربة اللعب وخيارات إعادة التعيين
        </p>
      </div>

      {/* Audio and Haptic Toggles */}
      <div className="bg-[#f8f4ed] border border-[#2c2c2c] rounded-xs p-3 mb-5 flex flex-col gap-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#2c2c2c]/20">
          <div className="flex items-center gap-2 text-[#1a1a1a]">
            {settings.sound ? (
              <Volume2 className="w-5 h-5" />
            ) : (
              <VolumeX className="w-5 h-5 text-[#2c2c2c]/50" />
            )}
            <span className="font-bold text-sm">الصوت</span>
          </div>
          <button
            type="button"
            onClick={toggleSound}
            className={`w-12 h-6 rounded-full transition-colors relative p-1 ${
              settings.sound ? 'bg-[#1a1a1a]' : 'bg-[#ede9e1]'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-[#fdfbf7] transition-transform ${
                settings.sound ? 'translate-x-0' : '-translate-x-6'
              }`}
            />
          </button>
        </div>

        <div className="flex items-center justify-between pb-2 border-b border-[#2c2c2c]/20">
          <div className="flex items-center gap-2 text-[#1a1a1a]">
            <Sparkles className="w-5 h-5" />
            <span className="font-bold text-sm">المؤثرات الصوتية</span>
          </div>
          <button
            type="button"
            onClick={toggleEffects}
            className={`w-12 h-6 rounded-full transition-colors relative p-1 ${
              settings.effects ? 'bg-[#1a1a1a]' : 'bg-[#ede9e1]'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-[#fdfbf7] transition-transform ${
                settings.effects ? 'translate-x-0' : '-translate-x-6'
              }`}
            />
          </button>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-[#1a1a1a]">
            <Vibrate className="w-5 h-5" />
            <span className="font-bold text-sm">الاهتزاز</span>
          </div>
          <button
            type="button"
            onClick={toggleVibration}
            className={`w-12 h-6 rounded-full transition-colors relative p-1 ${
              settings.vibration ? 'bg-[#1a1a1a]' : 'bg-[#ede9e1]'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-[#fdfbf7] transition-transform ${
                settings.vibration ? 'translate-x-0' : '-translate-x-6'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Actions and Reset Options */}
      <div className="flex flex-col gap-3 mb-6">
        {/* Reset All Progress */}
        <button
          type="button"
          onClick={() => setShowConfirmResetAll(true)}
          className="w-full py-3 px-4 bg-[#fce8e8] hover:bg-[#f8d0d0] text-[#7a1c1c] font-bold text-sm rounded-xs border border-[#7a1c1c] shadow-xs flex items-center justify-center gap-2 transition-all"
        >
          <Trash2 className="w-4 h-4" />
          <span>إعادة تعيين جميع التقدم</span>
        </button>

        {/* About Game Button */}
        <button
          type="button"
          onClick={onOpenAbout}
          className="w-full py-3 px-4 bg-[#fdfbf7] hover:bg-[#e6d5b8] text-[#1a1a1a] font-bold text-sm rounded-xs border border-[#2c2c2c] shadow-xs flex items-center justify-center gap-2 transition-all mt-1"
        >
          <Info className="w-4 h-4" />
          <span>حول اللعبة والجريدة</span>
        </button>
      </div>

      {/* Confirmation Modal for Reset ALL Progress */}
      {showConfirmResetAll && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-[#f8f4ed] border-2 border-[#7a1c1c] newspaper-border-double p-5 rounded-xs max-w-sm w-full text-center shadow-lg">
            <AlertTriangle className="w-10 h-10 text-[#7a1c1c] mx-auto mb-2" />
            <h3 className="newspaper-font text-xl font-bold mb-2 text-[#7a1c1c]">
              تأكيد إعادة تعيين جميع التقدم؟
            </h3>
            <p className="text-xs text-[#2c2c2c] mb-5">
              تحذير: سيتم حذف جميع إنجازاتك وقفل جميع المراحل المفتوحة والعودة للمرحلة الأولى نهائياً. هل أنت متأكد؟
            </p>
            <div className="flex gap-2 justify-center">
              <button
                type="button"
                onClick={() => {
                  onResetAllProgress();
                  setShowConfirmResetAll(false);
                }}
                className="py-2.5 px-4 bg-[#7a1c1c] text-[#fff] font-bold text-xs rounded-xs border border-[#521212]"
              >
                نعم، احذف كل التقدم
              </button>
              <button
                type="button"
                onClick={() => setShowConfirmResetAll(false)}
                className="py-2.5 px-4 bg-[#ede9e1] text-[#1a1a1a] font-bold text-xs rounded-xs border border-[#2c2c2c]"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
