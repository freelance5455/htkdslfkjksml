import React from 'react';
import { 
  Moon, 
  Sun, 
  Type, 
  Vibrate, 
  Volume2, 
  RotateCcw, 
  Info, 
  ShieldCheck, 
  BookOpen, 
  Heart, 
  FastForward, 
  Sparkles, 
  Bell, 
  Send,
  MapPin,
  Clock,
  Headphones,
  Zap,
  Battery,
  User,
  Check,
  Award,
  Trophy,
  Cloud,
  LogOut,
  LogIn,
  RefreshCw
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FontSizeOption, ArabicFontOption, NightWarmthLevel } from '../types';
import { RECITERS_LIST, recitationEngine } from '../utils/recitationService';

export const SettingsScreen: React.FC = () => {
  const { 
    user,
    login,
    logout,
    isSyncing,
    settings, 
    updateSettings, 
    toggleNotifications, 
    sendTestReminderNotification, 
    resetAllProgress, 
    setShowAboutModal,
    solarTimes,
    refreshLocationForSolarTimes,
    setShowNotificationCenter,
    triggerTestReminder,
    nextReminderInfo,
    setShowAmbientModal,
    ambientType,
    ambientPlaying,
    setAmbientType,
    showToast,
    totalDhikrCount,
    resetTotalDhikrCount
  } = useApp();

  const [showResetTotalModal, setShowResetTotalModal] = React.useState<boolean>(false);

  const fontSizes: { key: FontSizeOption; label: string; preview: string }[] = [
    { key: 'sm', label: 'صغير', preview: 'بِسْمِ اللَّهِ' },
    { key: 'md', label: 'متوسط', preview: 'بِسْمِ اللَّهِ' },
    { key: 'lg', label: 'كبير', preview: 'بِسْمِ اللَّهِ' },
    { key: 'xl', label: 'كبير جداً', preview: 'بِسْمِ اللَّهِ' },
  ];

  const arabicFonts: { key: ArabicFontOption; label: string; preview: string; isUthmani?: boolean }[] = [
    { key: 'uthmani', label: 'الخط العثماني (رسم المصحف)', preview: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', isUthmani: true },
    { key: 'amiri', label: 'خط أميري', preview: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ' },
    { key: 'cairo', label: 'خط كايرو', preview: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ' },
    { key: 'tajawal', label: 'خط تجوال', preview: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ' },
  ];

  const handleResetCounters = () => {
    if (window.confirm('هل تريد بالتأكيد إعادة ضبط جميع عدادات الأذكار؟')) {
      resetAllProgress();
    }
  };

  return (
    <div className="space-y-5 pb-24 text-right">
      {/* Header */}
      <div className="pt-2">
        <h2 className="text-2xl font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
          الإعدادات والتفضيلات
        </h2>
        <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal mt-0.5">
          تخصيص مظهر التطبيق، حجم الخطوط، والتنبيهات التفاعلية
        </p>
      </div>

      {/* ============================================================== */}
      {/* GOOGLE ACCOUNT & CLOUD SYNC CARD (حساب المستخدم والمزامنة السحابية) */}
      {/* ============================================================== */}
      <div className="bg-gradient-to-br from-[#073325] via-[#05281d] to-[#031d15] border border-emerald-500/30 dark:border-emerald-500/20 rounded-3xl p-4.5 space-y-3.5 shadow-lg text-right relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-400/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'صورة المستخدم'}
                className="w-12 h-12 rounded-2xl object-cover border-2 border-emerald-400/60 shadow-md"
              />
            ) : (
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center justify-center shadow-xs">
                <User className="w-6 h-6 text-emerald-300" />
              </div>
            )}
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-extrabold text-[#e8f5ee] font-cairo">
                  {user ? user.displayName || 'مستخدم مسجل' : 'حساب المسلم السحابي'}
                </h3>
                {user && (
                  <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-tajawal">
                    <Check className="w-2.5 h-2.5" />
                    متصل
                  </span>
                )}
              </div>
              <p className="text-xs text-[#84b8a0] font-tajawal mt-0.5">
                {user ? user.email || 'تم تفعيل المزامنة الفورية' : 'سجّل دخولك لحفظ مفضلتك وأذكارك سحابياً'}
              </p>
            </div>
          </div>

          {/* Sync indicator */}
          {user && isSyncing && (
            <div className="flex items-center gap-1 text-[11px] text-amber-300 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-xl animate-pulse">
              <RefreshCw className="w-3 h-3 animate-spin" />
              <span>مزامنة...</span>
            </div>
          )}
        </div>

        {/* Action Button */}
        <div className="pt-1 relative z-10">
          {user ? (
            <div className="flex items-center justify-between gap-2 bg-emerald-950/40 p-2.5 rounded-2xl border border-emerald-500/20">
              <div className="flex items-center gap-2 text-xs text-emerald-300/90 font-tajawal">
                <Cloud className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>مزامنة سحابية نشطة (Firebase Firestore)</span>
              </div>
              <button
                type="button"
                onClick={logout}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-red-200 bg-red-500/20 hover:bg-red-500/30 active:scale-95 border border-red-500/30 rounded-xl transition-all cursor-pointer font-cairo"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>تسجيل الخروج</span>
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={login}
              className="w-full flex items-center justify-center gap-2.5 py-2.5 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-500 hover:to-teal-600 text-white font-bold text-xs rounded-2xl shadow-md border border-emerald-400/40 active:scale-98 transition-all cursor-pointer font-cairo"
            >
              <LogIn className="w-4 h-4" />
              <span>تسجيل الدخول باستخدام Google</span>
            </button>
          )}
        </div>
      </div>

      {/* ============================================================== */}
      {/* LIFETIME TOTAL DHIKR COUNTER CARD (إجمالي رصيد التسبيح طوال فترة الاستخدام) */}
      {/* ============================================================== */}
      <div className="bg-gradient-to-br from-[#04281e] via-[#053225] to-[#021811] border border-amber-500/40 rounded-3xl p-4.5 space-y-3.5 shadow-lg text-right relative overflow-hidden">
        {/* Decorative Golden Ambient Glow */}
        <div className="absolute top-0 left-0 w-36 h-36 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-400/40 flex items-center justify-center shadow-xs">
              <Award className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-extrabold text-[#f5ebd9] font-cairo">
                  عداد التسبيح التراكمي
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 font-mono font-bold">
                  طوال الاستخدام
                </span>
              </div>
              <p className="text-[11px] text-[#84b8a0] font-tajawal mt-0.5">
                إجمالي الأذكار والتسبيحات المسجلة في رصيدك
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowResetTotalModal(true)}
            className="text-[10px] text-slate-400 hover:text-red-300 underline font-tajawal cursor-pointer"
            title="تصفير العداد التراكمي"
          >
            تصفير العداد
          </button>
        </div>

        {/* Counter Big Display */}
        <div className="p-3.5 rounded-2xl bg-black/40 border border-emerald-700/40 flex items-center justify-between relative z-10">
          <div>
            <span className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-amber-300 drop-shadow-[0_2px_10px_rgba(251,191,36,0.3)]">
              {totalDhikrCount.toLocaleString('ar-EG')}
            </span>
            <span className="text-xs font-bold text-amber-200/80 mr-2 font-cairo">تسبيحة مباركة</span>
          </div>
          <div className="text-left font-mono text-xs text-emerald-400/80">
            <span>({totalDhikrCount.toLocaleString('en-US')})</span>
          </div>
        </div>

        {/* Motivational Status & Milestone Badges */}
        <div className="space-y-1.5 relative z-10">
          <p className="text-xs text-amber-200/90 font-tajawal leading-relaxed">
            {totalDhikrCount >= 5000 
              ? '🌟 هنيئاً لك! تجاوزت ٥,٠٠٠ تسبيحة، جعلها الله ثقيلة في ميزان حسناتك ورفعة لدرجاتك.' 
              : totalDhikrCount >= 1000 
                ? '⭐ ما شاء الله تبارك الله! بلغت أكثر من ١,٠٠٠ تسبيحة، دمت من الذاكرين الله كثيراً والذاكرات.' 
                : totalDhikrCount >= 100 
                  ? '🌿 بداية مباركة ومستمرة في ذكر الله، كل تسبيحة غرس لك في الجنة.' 
                  : '🌱 ابدأ أذكارك وتسبيحاتك اليومية لتشهد رصيدك المبارك يزداد يوماً بعد يوم.'}
          </p>

          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            {[
              { target: 100, label: '١٠٠' },
              { target: 500, label: '٥٠٠' },
              { target: 1000, label: '١,٠٠٠' },
              { target: 5000, label: '٥,٠٠٠' },
              { target: 10000, label: '١٠,٠٠٠' },
            ].map(m => {
              const achieved = totalDhikrCount >= m.target;
              return (
                <span
                  key={m.target}
                  className={`text-[10px] px-2 py-0.5 rounded-lg border flex items-center gap-1 font-mono ${
                    achieved
                      ? 'bg-amber-500/25 border-amber-400 text-amber-200 font-bold shadow-2xs'
                      : 'bg-black/20 border-emerald-900/50 text-slate-500'
                  }`}
                >
                  {achieved ? '✓' : '○'} {m.label}
                </span>
              );
            })}
          </div>
        </div>
      </div>

      {/* Appearance Section */}
      <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-4 space-y-4 shadow-xs">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-[#4d7d67] dark:text-emerald-400/90 uppercase tracking-wider font-cairo">
            المظهر ووضعية الشاشة
          </h3>
          <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 font-tajawal">
            {settings.themeMode === 'auto' 
              ? 'تلقائي حسب الشمس' 
              : settings.darkMode ? 'ليلي دائم' : 'نهاري دائم'}
          </span>
        </div>

        {/* 3-Way Mode Switcher: Auto (Sunset/Sunrise) | Dark | Light */}
        <div className="grid grid-cols-3 gap-1.5 p-1.5 bg-[#eaf5ef] dark:bg-[#062c20] rounded-2xl border border-emerald-300/40 dark:border-emerald-800">
          <button
            onClick={() => updateSettings({ themeMode: 'dark', darkMode: true })}
            className={`py-2.5 px-1 text-center rounded-xl text-xs font-bold font-cairo transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
              settings.themeMode === 'dark'
                ? 'bg-[#093526] text-amber-200 shadow-sm border border-emerald-500/60 ring-1 ring-emerald-500/30'
                : 'text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <div className="relative flex items-center justify-center">
              <Moon className="w-4.5 h-4.5 text-amber-200 fill-amber-200/30" />
              <Sparkles className="w-2 h-2 text-amber-300 absolute -top-1 -right-1" />
            </div>
            <span>وضع الليل 🌙</span>
            <span className="text-[10px] font-tajawal text-[#84b8a0]">القمر المنير</span>
          </button>

          <button
            onClick={() => updateSettings({ themeMode: 'light', darkMode: false })}
            className={`py-2.5 px-1 text-center rounded-xl text-xs font-bold font-cairo transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
              settings.themeMode === 'light'
                ? 'bg-[#093526] text-amber-300 shadow-sm border border-amber-500/60 ring-1 ring-amber-500/30'
                : 'text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <div className="relative flex items-center justify-center">
              <Sun className="w-4.5 h-4.5 text-amber-400 drop-shadow-[0_0_6px_rgba(251,191,36,0.8)]" />
            </div>
            <span>وضع النهار ☀️</span>
            <span className="text-[10px] font-tajawal text-[#84b8a0]">الشمس مضيئة</span>
          </button>

          <button
            onClick={() => {
              updateSettings({ themeMode: 'auto' });
              refreshLocationForSolarTimes();
            }}
            className={`py-2.5 px-1 text-center rounded-xl text-xs font-bold font-cairo transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
              settings.themeMode === 'auto'
                ? 'bg-[#093526] text-emerald-200 shadow-sm border border-emerald-500/60 ring-1 ring-emerald-500/30'
                : 'text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <div className="flex items-center gap-1">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <Moon className="w-3.5 h-3.5 text-amber-200" />
            </div>
            <span>تلقائي 🌅</span>
            <span className="text-[10px] font-tajawal text-[#84b8a0]">شمس / قمر</span>
          </button>
        </div>

        {/* Solar Times Details & Geolocation Info Card */}
        <div className="bg-[#032017] p-4 rounded-2xl border border-emerald-700/60 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-[#e8f5ee] font-cairo flex items-center gap-1.5">
                <span>توقيت الشروق والغروب</span>
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-900/80 text-emerald-300 font-tajawal border border-emerald-600/50 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-amber-400" />
                <span>{solarTimes.cityName || 'موقعك الجغرافي'}</span>
              </span>
            </div>

            <span className="text-[11px] font-bold">
              {solarTimes.isNight ? (
                <span className="text-amber-200 flex items-center gap-1 font-tajawal">
                  <span>الليل 🌙</span>
                  <Moon className="w-3.5 h-3.5 fill-amber-200/30" />
                </span>
              ) : (
                <span className="text-amber-300 flex items-center gap-1 font-tajawal">
                  <span>النهار ☀️</span>
                  <Sun className="w-3.5 h-3.5" />
                </span>
              )}
            </span>
          </div>

          {/* Sunrise and Sunset times */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-[#042017] border border-emerald-700/60 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-amber-300">
                <Sun className="w-4 h-4 text-amber-400" />
                <span className="text-[#84b8a0] font-tajawal">شروق الشمس:</span>
              </div>
              <strong className="font-mono text-base text-[#e8f5ee]">{solarTimes.sunriseFormatted}</strong>
            </div>

            <div className="p-2.5 rounded-xl bg-[#042017] border border-emerald-700/60 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-amber-200">
                <Moon className="w-4 h-4 text-amber-300 fill-amber-300/30" />
                <span className="text-[#84b8a0] font-tajawal">غروب الشمس:</span>
              </div>
              <strong className="font-mono text-base text-[#e8f5ee]">{solarTimes.sunsetFormatted}</strong>
            </div>
          </div>

          {/* Next Transition Status Banner */}
          <div className="p-2.5 rounded-xl bg-black/30 border border-emerald-800/60 text-xs font-tajawal flex items-center justify-between text-amber-200">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{solarTimes.nextTransitionText}</span>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-500/15 border border-amber-400/30 text-amber-300 shrink-0 font-cairo">
              {settings.themeMode === 'auto' ? 'مفعّل تلقائياً ✓' : 'وضع يدوي'}
            </span>
          </div>

          {/* Geolocation API Refresh Button */}
          <button
            type="button"
            onClick={() => refreshLocationForSolarTimes(false)}
            className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-800/40 via-emerald-700/30 to-emerald-800/40 hover:from-emerald-700/50 hover:to-emerald-700/50 text-emerald-200 border border-emerald-600/50 text-xs font-bold font-cairo flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs active:scale-[0.99]"
          >
            <MapPin className="w-4 h-4 text-amber-400" />
            <span>تحديد موقعي وتحديث الشروق والغروب (Geolocation API)</span>
          </button>
        </div>

        {/* ============================================================== */}
        {/* DEDICATED OLED / AMOLED DEEP BLACK MODE TOGGLE (TRUE BLACK #000000) */}
        {/* ============================================================== */}
        <div className="pt-2 border-t border-emerald-100 dark:border-emerald-800/60 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-black flex items-center justify-center border border-neutral-700 shadow-xs shrink-0">
                <Zap className="w-5 h-5 text-amber-400 fill-amber-400/20" />
              </div>
              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h4 className="text-sm font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                    وضع السواد التام (True AMOLED Mode)
                  </h4>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-tajawal">
                    توفير بطارية OLED ⚡
                  </span>
                </div>
                <p className="text-[11px] text-[#4d7d67] dark:text-[#84b8a0] font-tajawal mt-0.5">
                  خلفية سوداء حالكة (#000000) بدلاً من الزمردي الداكن (#02140e) لإطفاء البكسلات
                </p>
              </div>
            </div>

            {/* Toggle Switch */}
            <button
              type="button"
              role="switch"
              aria-checked={Boolean(settings.amoledMode)}
              onClick={() => {
                const nextVal = !settings.amoledMode;
                updateSettings({
                  amoledMode: nextVal,
                  ...(nextVal && !settings.darkMode ? { darkMode: true, themeMode: 'dark' } : {})
                });
                showToast(
                  nextVal
                    ? 'تم تفعيل وضع السواد التام (AMOLED) - تم إطفاء بكسلات الشاشة لتوفير البطارية ⚡'
                    : 'تم العودة للوضع الزمردي الداكن الكلاسيكي 🌿'
                );
              }}
              className={`w-13 h-7 rounded-full p-0.5 transition-colors duration-200 ease-in-out cursor-pointer relative shrink-0 ${
                settings.amoledMode ? 'bg-amber-500 ring-2 ring-amber-400/40' : 'bg-emerald-900/60 border border-emerald-700/60'
              }`}
              title="تبديل وضع السواد التام AMOLED"
            >
              <div
                className={`w-6 h-6 rounded-full shadow-md transform transition-transform duration-200 flex items-center justify-center ${
                  settings.amoledMode ? '-translate-x-6 bg-black text-amber-400' : 'translate-x-0 bg-white text-emerald-800'
                }`}
              >
                {settings.amoledMode ? (
                  <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                ) : (
                  <Moon className="w-3.5 h-3.5 text-emerald-700" />
                )}
              </div>
            </button>
          </div>

          {/* Interactive Mode Comparison Cards: Dark Emerald vs True AMOLED */}
          <div className="grid grid-cols-2 gap-2 pt-0.5">
            {/* 1. Dark Emerald Option */}
            <button
              type="button"
              onClick={() => {
                updateSettings({ amoledMode: false });
                showToast('تم اختيار الوضع الزمردي الداكن الكلاسيكي 🌿');
              }}
              className={`p-3 rounded-xl border text-right transition-all cursor-pointer relative flex flex-col justify-between ${
                !settings.amoledMode
                  ? 'border-emerald-500 bg-[#02140e] text-emerald-200 ring-2 ring-emerald-500/30 shadow-sm'
                  : 'border-emerald-800/60 bg-[#02140e]/60 text-emerald-400/80 hover:border-emerald-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold font-cairo text-[#e8f5ee] flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#042017] border border-emerald-500 shrink-0"></span>
                  الزمردي الداكن
                </span>
                {!settings.amoledMode && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400 ring-4 ring-emerald-400/20 shrink-0" />
                )}
              </div>
              <p className="text-[10px] text-[#84b8a0] font-tajawal leading-tight mb-2">
                خلفية زمردية تراثية مريحة للعينين
              </p>
              <div className="flex items-center justify-between text-[9px] font-mono font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/60">
                <span>#02140e</span>
                <span className="font-tajawal text-[9px]">الافتراضي</span>
              </div>
            </button>

            {/* 2. True AMOLED Black Option */}
            <button
              type="button"
              onClick={() => {
                updateSettings({
                  amoledMode: true,
                  ...(!settings.darkMode ? { darkMode: true, themeMode: 'dark' } : {})
                });
                showToast('تم اختيار وضع السواد التام AMOLED لتوفير بطارية OLED ⚡');
              }}
              className={`p-3 rounded-xl border text-right transition-all cursor-pointer relative flex flex-col justify-between ${
                settings.amoledMode
                  ? 'border-amber-400 bg-black text-amber-200 ring-2 ring-amber-400/30 shadow-sm'
                  : 'border-neutral-800 bg-black/70 text-neutral-300 hover:border-neutral-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold font-cairo text-white flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-black border border-amber-400 shrink-0"></span>
                  سواد AMOLED حالك
                </span>
                {settings.amoledMode && (
                  <span className="w-2 h-2 rounded-full bg-amber-400 ring-4 ring-amber-400/20 shrink-0" />
                )}
              </div>
              <p className="text-[10px] text-amber-200/80 font-tajawal leading-tight mb-2">
                إطفاء بكسلات OLED بنسبة 100% لتوفير الطاقة
              </p>
              <div className="flex items-center justify-between text-[9px] font-mono font-bold text-amber-300 bg-black px-2 py-0.5 rounded border border-neutral-800">
                <span>#000000</span>
                <span className="font-tajawal text-[9px] text-amber-300">أوليد ⚡</span>
              </div>
            </button>
          </div>

          {/* Efficiency Explanation Box */}
          <div className="p-2.5 rounded-xl bg-black/40 border border-emerald-900/60 dark:border-neutral-800 flex items-start gap-2 text-xs">
            <Battery className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <p className="text-[11px] text-[#84b8a0] font-tajawal leading-relaxed">
              <strong className="text-amber-200 font-bold">معلومة تقنية: </strong>
              على شاشات OLED و Super AMOLED، تطفئ البكسلات السوداء تماماً إضاءتها الفردية، مما يمنح تبايناً فائقاً ويوفر استهلاك البطارية بنسبة تصل إلى ٤٠٪ أثناء قراءة الأذكار.
            </p>
          </div>
        </div>

        {/* Font Size Selector */}
        <div className="pt-2 border-t border-emerald-100 dark:border-emerald-800/60 space-y-2">
          <div className="flex items-center gap-2">
            <Type className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
            <p className="text-sm font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
              حجم خط نصوص الأذكار
            </p>
          </div>

          <div className="grid grid-cols-4 gap-1.5 pt-1">
            {fontSizes.map((size) => (
              <button
                key={size.key}
                onClick={() => updateSettings({ fontSize: size.key })}
                className={`py-2 px-1 text-center rounded-xl border transition-all cursor-pointer ${
                  settings.fontSize === size.key
                    ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-200 font-bold'
                    : 'border-emerald-200/60 dark:border-emerald-800/60 text-[#2b5945] dark:text-[#84b8a0] hover:bg-[#062c20] dark:hover:bg-[#062c20]'
                }`}
              >
                <div className="text-xs font-cairo">{size.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Arabic Script / Font Family Selector */}
        <div className="pt-2 border-t border-emerald-100 dark:border-emerald-800/60 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
              <p className="text-sm font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                نوع الخط العربي
              </p>
            </div>
            {settings.arabicFont === 'uthmani' && (
              <span className="text-[10px] font-bold text-amber-500 dark:text-amber-300 bg-amber-500/10 border border-amber-400/30 px-2 py-0.5 rounded-full">
                رسم المصحف الشريف
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            {arabicFonts.map((font) => (
              <button
                key={font.key}
                onClick={() => updateSettings({ arabicFont: font.key })}
                className={`p-2.5 text-right rounded-xl border transition-all cursor-pointer flex flex-col gap-1 ${
                  settings.arabicFont === font.key
                    ? 'border-amber-500/80 bg-amber-500/10 dark:bg-amber-500/15 text-amber-900 dark:text-amber-200 shadow-xs ring-1 ring-amber-400/30'
                    : 'border-emerald-200/60 dark:border-emerald-800/60 text-[#2b5945] dark:text-[#84b8a0] hover:bg-[#062c20]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-cairo">{font.label}</span>
                  {settings.arabicFont === font.key && (
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                  )}
                </div>
                <div className={`text-sm truncate opacity-85 ${font.key === 'uthmani' ? 'font-uthmani' : font.key === 'amiri' ? 'font-quran' : font.key === 'tajawal' ? 'font-tajawal' : 'font-cairo'}`}>
                  {font.preview}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Night Reading Mode & Eye Protection (وضع القراءة الليلية لراحة العين وتقليل الضوء الأزرق) */}
      <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-4 space-y-3.5 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Moon className="w-4.5 h-4.5 text-amber-400 fill-amber-400/30" />
            <h3 className="text-sm font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
              وضع القراءة الليلية لراحة العين قبل النوم
            </h3>
          </div>
          <span className="text-[11px] font-bold text-amber-300 font-tajawal bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full">
            {settings.nightReadingMode === 'auto' ? 'تلقائي 🌅' : settings.nightReadingMode === 'on' ? 'مفعّل 🌙' : 'إيقاف ☀️'}
          </span>
        </div>

        <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal leading-relaxed">
          يقوم بتعديل تباين الألوان وتخفيض الإضاءة الزرقاء لراحة العينين والمساعدة على الاسترخاء والنوم الهادئ أثناء قراءة أذكار المساء والنوم.
        </p>

        {/* 3-Way Mode Switcher: Auto | On | Off */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#eaf5ef] dark:bg-[#062c20] rounded-xl border border-emerald-300/40 dark:border-emerald-800">
          <button
            onClick={() => {
              updateSettings({ nightReadingMode: 'auto' });
              showToast(solarTimes.isNight ? 'وضع القراءة الليلي: تلقائي (مفعّل الآن 🌙)' : 'وضع القراءة الليلي: تلقائي (سيفعّل مع الليل 🌅)');
            }}
            className={`py-2 px-1 text-center rounded-lg text-xs font-bold font-cairo transition-all cursor-pointer ${
              (settings.nightReadingMode || 'auto') === 'auto'
                ? 'bg-amber-600/30 text-amber-200 border border-amber-500/60 shadow-xs'
                : 'text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <span>تلقائي 🌅</span>
            <div className="text-[10px] font-tajawal opacity-75">مع حلول الليل</div>
          </button>

          <button
            onClick={() => {
              updateSettings({ nightReadingMode: 'on' });
              showToast('تم تفعيل وضع القراءة الليلي (تقليل الضوء الأزرق لراحة العين) 🌙');
            }}
            className={`py-2 px-1 text-center rounded-lg text-xs font-bold font-cairo transition-all cursor-pointer ${
              settings.nightReadingMode === 'on'
                ? 'bg-amber-600/30 text-amber-200 border border-amber-500/60 shadow-xs'
                : 'text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <span>مفعّل دائم 🌙</span>
            <div className="text-[10px] font-tajawal opacity-75">راحة فورية</div>
          </button>

          <button
            onClick={() => {
              updateSettings({ nightReadingMode: 'off' });
              showToast('تم إيقاف وضع القراءة الليلي ☀️');
            }}
            className={`py-2 px-1 text-center rounded-lg text-xs font-bold font-cairo transition-all cursor-pointer ${
              settings.nightReadingMode === 'off'
                ? 'bg-amber-600/30 text-amber-200 border border-amber-500/60 shadow-xs'
                : 'text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <span>إيقاف ☀️</span>
            <div className="text-[10px] font-tajawal opacity-75">الوضع العادي</div>
          </button>
        </div>

        {/* Warmth Level Selector */}
        <div className="pt-2 border-t border-emerald-100 dark:border-emerald-800/60 space-y-2">
          <p className="text-xs font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
            درجة الدفء وحجب الضوء الأزرق:
          </p>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { key: 'mild' as NightWarmthLevel, label: 'معتدل', desc: 'حجب 50% أزرق' },
              { key: 'warm' as NightWarmthLevel, label: 'عنبري هادئ ⭐', desc: 'حجب 80% أزرق' },
              { key: 'deep_amber' as NightWarmthLevel, label: 'شمعة داكنة', desc: 'حجب 95% أزرق' },
            ].map((w) => (
              <button
                key={w.key}
                onClick={() => {
                  updateSettings({ nightWarmthLevel: w.key });
                  showToast(
                    w.key === 'deep_amber' 
                      ? 'درجة الدفء: شمعة داكنة (أقصى حجب للضوء الأزرق 95%) 🕯️' 
                      : w.key === 'warm' 
                        ? 'درجة الدفء: عنبري هادئ للنوم (حجب 80%) ⭐' 
                        : 'درجة الدفء: دافئ معتدل (حجب 50%) 🌙'
                  );
                }}
                className={`py-2 px-1 text-center rounded-xl border transition-all cursor-pointer ${
                  (settings.nightWarmthLevel || 'warm') === w.key
                    ? 'border-amber-500 bg-amber-500/20 text-amber-200 font-bold shadow-xs'
                    : 'border-emerald-200/50 dark:border-emerald-800/60 text-[#2b5945] dark:text-[#84b8a0] hover:bg-emerald-950/40'
                }`}
              >
                <div className="text-xs font-cairo">{w.label}</div>
                <div className="text-[10px] font-tajawal opacity-75">{w.desc}</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Interactions Section */}
      <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-4 space-y-4 shadow-xs">
        <h3 className="text-xs font-bold text-[#4d7d67] dark:text-emerald-400/90 uppercase tracking-wider font-cairo">
          التفاعل والعداد
        </h3>

        {/* Vibration Toggle */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#eaf5ef] dark:bg-[#083526] text-[#1a4432] dark:text-[#a7d7c0] flex items-center justify-center">
              <Vibrate className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                الاهتزاز اللمسي (Haptic)
              </p>
              <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal">
                اهتزاز خفيف وهادئ عند الضغط على زر التسبيح
              </p>
            </div>
          </div>

          <button
            onClick={() => updateSettings({ vibration: !settings.vibration })}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.vibration ? 'bg-emerald-600' : 'bg-[#cfded6] dark:bg-[#093526]'
            }`}
            aria-label="تبديل الاهتزاز"
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                settings.vibration ? 'right-7' : 'right-1'
              }`}
            />
          </button>
        </div>

        {/* Milestone vibration selector */}
        {settings.vibration && (
          <div className="pt-2 border-t border-emerald-100/60 dark:border-emerald-800/40 space-y-1.5 animate-in fade-in duration-150">
            <p className="text-xs font-bold text-[#1a4432] dark:text-[#a7d7c0] font-cairo">
              محطات الاهتزاز التنبيهي:
            </p>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: '33', label: 'كل ٣٣' },
                { id: '10', label: 'كل ١٠' },
                { id: 'target', label: 'عند الهدف' }
              ].map(opt => (
                <button
                  key={opt.id}
                  onClick={() => updateSettings({ vibrationMilestone: opt.id as any })}
                  className={`py-1.5 px-2 rounded-xl text-xs font-bold font-cairo border transition-all cursor-pointer ${
                    settings.vibrationMilestone === opt.id
                      ? 'border-emerald-600 bg-emerald-700/15 text-emerald-900 dark:text-emerald-200'
                      : 'border-emerald-200/50 dark:border-emerald-800/60 text-[#4d7d67] dark:text-[#84b8a0] hover:bg-[#062c20]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Sound Toggle */}
        <div className="flex items-center justify-between pt-2 border-t border-emerald-100 dark:border-emerald-800/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#eaf5ef] dark:bg-[#083526] text-[#1a4432] dark:text-[#a7d7c0] flex items-center justify-center">
              <Volume2 className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                المؤثر الصوتي
              </p>
              <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal">
                صوت ناعم ومريح للأذن عند كل تسبيحة وعند الاكتمال
              </p>
            </div>
          </div>

          <button
            onClick={() => updateSettings({ sound: !settings.sound })}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.sound ? 'bg-emerald-600' : 'bg-[#cfded6] dark:bg-[#093526]'
            }`}
            aria-label="تبديل الصوت"
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                settings.sound ? 'right-7' : 'right-1'
              }`}
            />
          </button>
        </div>

        {/* Auto Advance Toggle */}
        <div className="flex items-center justify-between pt-2 border-t border-emerald-100 dark:border-emerald-800/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#eaf5ef] dark:bg-[#083526] text-[#1a4432] dark:text-[#a7d7c0] flex items-center justify-center">
              <FastForward className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                الانتقال التلقائي للذكر التالي
              </p>
              <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal">
                الانتقال السلس تلقائياً بعد اكتمال تكرار الذكر
              </p>
            </div>
          </div>

          <button
            onClick={() => updateSettings({ autoAdvance: !settings.autoAdvance })}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.autoAdvance ? 'bg-emerald-600' : 'bg-[#cfded6] dark:bg-[#093526]'
            }`}
            aria-label="الانتقال التلقائي"
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                settings.autoAdvance ? 'right-7' : 'right-1'
              }`}
            />
          </button>
        </div>

        {/* Reset Counters Button */}
        <div className="pt-2 border-t border-emerald-100 dark:border-emerald-800/60">
          <button
            onClick={handleResetCounters}
            className="w-full py-2.5 px-3 rounded-xl border border-red-200/80 dark:border-red-900/60 bg-red-50/50 dark:bg-red-950/20 text-red-600 dark:text-red-400 hover:bg-red-100/60 transition-colors flex items-center justify-center gap-2 text-xs font-bold font-cairo cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>إعادة ضبط جميع العدادات لليوم</span>
          </button>
        </div>
      </div>

      {/* Chosen Reciter Section (القارئ المختار لتلاوة الأذكار) */}
      <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-4 space-y-3 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/40 flex items-center justify-center">
              <User className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                القارئ المختار لتلاوة الأذكار
              </h3>
              <p className="text-[11px] text-[#4d7d67] dark:text-[#84b8a0] font-tajawal">
                الصوت المستخدم في المشغل الصوتي للاستماع والتجويد
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 pt-1">
          {RECITERS_LIST.map((r) => {
            const isSelected = (settings.selectedReciter || 'alafasy') === r.id;
            return (
              <button
                key={r.id}
                onClick={() => {
                  updateSettings({ selectedReciter: r.id });
                  recitationEngine.setReciter(r.id);
                  showToast(`تم اختيار القارئ: ${r.name} 🎙️`);
                }}
                className={`p-2.5 rounded-xl border text-right transition-all flex flex-col justify-between cursor-pointer ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-400 text-amber-100 ring-1 ring-amber-400/40 shadow-xs'
                    : 'bg-[#eaf5ef] dark:bg-[#062c20] border-emerald-200/50 dark:border-emerald-800/60 text-[#0c2e20] dark:text-[#e8f5ee] hover:bg-[#d8ece0] dark:hover:bg-[#093526]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-cairo">{r.name}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-amber-400 stroke-[3]" />}
                </div>
                <span className="text-[10px] text-[#4d7d67] dark:text-[#84b8a0] font-tajawal mt-1">
                  {r.badge}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Ambient Soundscape Section (أصوات السكينة والخشوع) */}
      <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-4 space-y-3.5 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/40 flex items-center justify-center">
              <Headphones className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#e8f5ee] font-cairo">
                أصوات السكينة والخشوع
              </h3>
              <p className="text-[11px] text-[#84b8a0] font-tajawal">
                أصوات طبيعية هادئة (مطر، طيور، نسيم) تعزز التركيز أثناء الذكر
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowAmbientModal(true)}
            className="px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/40 text-amber-300 font-bold font-cairo text-xs transition-colors cursor-pointer"
          >
            {ambientPlaying ? 'تعديل 🔊' : 'اختيار 🎧'}
          </button>
        </div>

        {/* Quick Ambient Chips */}
        <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5 pt-1 text-xs font-tajawal font-bold">
          <button
            onClick={() => setAmbientType(ambientType === 'rain' && ambientPlaying ? 'none' : 'rain')}
            className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
              ambientType === 'rain' && ambientPlaying
                ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-xs'
                : 'bg-[#062c20] border-emerald-800 text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <span>مطر 🌧️</span>
          </button>

          <button
            onClick={() => setAmbientType(ambientType === 'birds' && ambientPlaying ? 'none' : 'birds')}
            className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
              ambientType === 'birds' && ambientPlaying
                ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-xs'
                : 'bg-[#062c20] border-emerald-800 text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <span>طيور 🕊️</span>
          </button>

          <button
            onClick={() => setAmbientType(ambientType === 'nature' && ambientPlaying ? 'none' : 'nature')}
            className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
              ambientType === 'nature' && ambientPlaying
                ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-xs'
                : 'bg-[#062c20] border-emerald-800 text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <span>نسيم 🍃</span>
          </button>

          <button
            onClick={() => setAmbientType(ambientType === 'water' && ambientPlaying ? 'none' : 'water')}
            className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
              ambientType === 'water' && ambientPlaying
                ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-xs'
                : 'bg-[#062c20] border-emerald-800 text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <span>ماء 🌊</span>
          </button>

          <button
            onClick={() => setAmbientType(ambientType === 'night' && ambientPlaying ? 'none' : 'night')}
            className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
              ambientType === 'night' && ambientPlaying
                ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-xs'
                : 'bg-[#062c20] border-emerald-800 text-[#84b8a0] hover:text-[#e8f5ee]'
            }`}
          >
            <span>سكون 🌙</span>
          </button>
        </div>
      </div>

      {/* Notifications Section */}
      <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-4 space-y-4 shadow-xs">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-[#4d7d67] dark:text-emerald-400/90 uppercase tracking-wider font-cairo">
            نظام التذكيرات والإشعارات اليومية
          </h3>
          <button
            onClick={() => setShowNotificationCenter(true)}
            className="text-xs text-amber-300 hover:text-amber-200 font-bold font-cairo flex items-center gap-1 cursor-pointer"
          >
            <span>مركز الجدولة</span>
            <Clock className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Master Notifications Toggle */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#083526] text-[#a7d7c0] flex items-center justify-center">
              <Bell className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#e8f5ee] font-cairo">
                تفعيل تذكيرات الأذكار
              </p>
              <p className="text-xs text-[#84b8a0] font-tajawal">
                تنبيهات يومية مجدولة داخل التطبيق لأذكار الصباح والمساء
              </p>
            </div>
          </div>

          <button
            onClick={() => toggleNotifications(!settings.notificationsEnabled)}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.notificationsEnabled ? 'bg-emerald-600' : 'bg-[#093526] border border-emerald-700/50'
            }`}
            aria-label="تبديل إشعارات التذكير"
          >
            <div
              className={`w-4.5 h-4.5 rounded-full bg-white transition-transform absolute top-0.5 ${
                settings.notificationsEnabled ? 'right-7' : 'right-1'
              }`}
            />
          </button>
        </div>

        {/* Next Reminder info if active */}
        {settings.notificationsEnabled && nextReminderInfo && (
          <div className="p-3 rounded-xl bg-[#062c20] border border-amber-400/30 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-300" />
              <div>
                <p className="font-bold font-cairo text-[#e8f5ee]">التذكير القادم: {nextReminderInfo.title}</p>
                <p className="text-[10px] text-amber-200 font-tajawal">
                  الساعة {nextReminderInfo.timeFormatted} ({nextReminderInfo.timeText})
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowNotificationCenter(true)}
              className="px-2.5 py-1 rounded-lg bg-[#093526] border border-emerald-600/50 text-emerald-300 font-bold font-cairo text-[10px] cursor-pointer"
            >
              تعديل
            </button>
          </div>
        )}

        {/* Detailed Notification Time Selectors (Visible when enabled) */}
        {settings.notificationsEnabled && (
          <div className="pt-2 border-t border-emerald-800/60 space-y-3 animate-in fade-in duration-150">
            {/* Morning Reminder Row */}
            <div className="flex items-center justify-between bg-[#062c20] p-3 rounded-xl border border-emerald-800/60">
              <div className="flex items-center gap-2.5">
                <Sun className="w-4 h-4 text-amber-400" />
                <div>
                  <p className="text-xs font-bold text-[#e8f5ee] font-cairo">
                    أذكار الصباح
                  </p>
                  <p className="text-[11px] text-[#84b8a0]">
                    وقت التذكير اليومي
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={settings.morningNotificationTime}
                  onChange={(e) => updateSettings({ morningNotificationTime: e.target.value })}
                  className="px-2.5 py-1 text-xs bg-[#042017] border border-emerald-700/60 rounded-lg text-[#e8f5ee] font-mono font-medium focus:outline-none focus:ring-1 focus:ring-emerald-600 cursor-pointer"
                />
                <button
                  onClick={() => updateSettings({ morningNotification: !settings.morningNotification })}
                  className={`w-8 h-5 rounded-full transition-colors relative cursor-pointer ${
                    settings.morningNotification ? 'bg-emerald-600' : 'bg-[#093526]'
                  }`}
                  title="تفعيل أو تعطيل تذكير الصباح"
                >
                  <div
                    className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${
                      settings.morningNotification ? 'right-4' : 'right-0.5'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Evening Reminder Row */}
            <div className="flex items-center justify-between bg-[#062c20] p-3 rounded-xl border border-emerald-800/60">
              <div className="flex items-center gap-2.5">
                <Moon className="w-4 h-4 text-amber-300" />
                <div>
                  <p className="text-xs font-bold text-[#e8f5ee] font-cairo">
                    أذكار المساء
                  </p>
                  <p className="text-[11px] text-[#84b8a0]">
                    وقت التذكير اليومي
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={settings.eveningNotificationTime}
                  onChange={(e) => updateSettings({ eveningNotificationTime: e.target.value })}
                  className="px-2.5 py-1 text-xs bg-[#042017] border border-emerald-700/60 rounded-lg text-[#e8f5ee] font-mono font-medium focus:outline-none focus:ring-1 focus:ring-emerald-600 cursor-pointer"
                />
                <button
                  onClick={() => updateSettings({ eveningNotification: !settings.eveningNotification })}
                  className={`w-8 h-5 rounded-full transition-colors relative cursor-pointer ${
                    settings.eveningNotification ? 'bg-emerald-600' : 'bg-[#093526]'
                  }`}
                  title="تفعيل أو تعطيل تذكير المساء"
                >
                  <div
                    className={`w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.5 ${
                      settings.eveningNotification ? 'right-4' : 'right-0.5'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Test Notification Buttons */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => triggerTestReminder('morning')}
                className="py-2.5 px-3 rounded-xl border border-amber-400/40 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 transition-colors flex items-center justify-center gap-1.5 text-xs font-bold font-cairo cursor-pointer"
              >
                <Sun className="w-3.5 h-3.5" />
                <span>تجربة إشعار الصباح ☀️</span>
              </button>

              <button
                onClick={() => triggerTestReminder('evening')}
                className="py-2.5 px-3 rounded-xl border border-emerald-600/50 bg-[#093526] text-amber-200 hover:bg-[#0c4331] transition-colors flex items-center justify-center gap-1.5 text-xs font-bold font-cairo cursor-pointer"
              >
                <Moon className="w-3.5 h-3.5 fill-amber-200/30" />
                <span>تجربة إشعار المساء 🌙</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* About & Religious Authenticity */}
      <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-4 space-y-3 shadow-xs">
        <h3 className="text-xs font-bold text-[#4d7d67] dark:text-emerald-400/90 uppercase tracking-wider font-cairo">
          عن التطبيق والصدقة الجارية
        </h3>

        <button
          onClick={() => setShowAboutModal(true)}
          className="w-full p-2.5 rounded-xl bg-[#f4f9f6]/80 dark:bg-[#031d15]/60 border border-emerald-600/20 dark:border-emerald-700/40 hover:border-emerald-500/50 flex items-center justify-between transition-colors text-right cursor-pointer"
        >
          <div className="flex items-center gap-2.5">
            <Heart className="w-4 h-4 text-emerald-600 dark:text-emerald-400 fill-emerald-500/20 shrink-0" />
            <div>
              <p className="text-xs font-semibold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                عن التطبيق ونيّة الصدقة الجارية
              </p>
              <p className="text-[11px] text-[#4d7d67] dark:text-[#84b8a0] font-tajawal mt-0.5">
                صدقة جارية عن الحاجة هدى · نسأل الله القبول
              </p>
            </div>
          </div>
          <Info className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
        </button>

        <button
          onClick={() => setShowAboutModal(true)}
          className="w-full p-3 rounded-xl bg-[#062c20] dark:bg-[#062c20] hover:bg-[#e6f4ed] dark:hover:bg-[#093526] flex items-center justify-between transition-colors text-right cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <BookOpen className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
            <div>
              <p className="text-xs font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                مصدر المحتوى والتدقيق الشرعي
              </p>
              <p className="text-[11px] text-[#4d7d67] dark:text-[#84b8a0]">
                من القرآن الكريم والسنة النبوية الصحيحة
              </p>
            </div>
          </div>
          <ShieldCheck className="w-4 h-4 text-[#4d7d67] dark:text-emerald-500" />
        </button>
      </div>

      {/* Re-open Splash Screen option */}
      <div className="pt-1 text-center">
        <button
          onClick={() => {
            sessionStorage.removeItem('hisn_splash_dismissed');
            window.location.reload();
          }}
          className="text-xs text-emerald-700 dark:text-emerald-400 hover:underline inline-flex items-center gap-1 font-tajawal cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>عرض شاشة البداية مجدداً</span>
        </button>
      </div>

      {/* Confirmation Modal to Reset Lifetime Total Count */}
      {showResetTotalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-[#042017] border border-amber-500/40 rounded-3xl p-5 shadow-2xl text-right space-y-4">
            <div className="flex items-center gap-2 text-amber-400">
              <Award className="w-5 h-5" />
              <h3 className="text-sm font-extrabold font-cairo text-white">تصفير عداد التسبيح التراكمي؟</h3>
            </div>
            <p className="text-xs text-[#84b8a0] font-tajawal leading-relaxed">
              سيتم إعادة ضبط إجمالي التسبيحات طوال فترة الاستخدام إلى (0). هل أنت متأكد من رغبتك في البدء من جديد؟
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => {
                  resetTotalDhikrCount();
                  setShowResetTotalModal(false);
                }}
                className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs font-cairo cursor-pointer"
              >
                نعم، تصفير العداد
              </button>
              <button
                onClick={() => setShowResetTotalModal(false)}
                className="flex-1 py-2 rounded-xl bg-emerald-900/60 hover:bg-emerald-900 text-emerald-200 font-bold text-xs font-cairo cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
