import React, { useState } from 'react';
import { Settings as SettingsIcon, User, Lock, Mail } from 'lucide-react';
import { getMasterPin, getUserSession } from '../lib/storage';
import {
  openWhatsAppDirect,
  getWhatsAppHelpMessage,
  openContactEmail,
  CONTACT_EMAIL_MESSAGE,
} from '../lib/whatsapp';

interface SettingsScreenProps {
  onBack: () => void;
  onOpenAccountSetting: () => void;
  onStartChangePassword: () => void;
  onRejectChangePassword: () => void;
}

// Original WhatsApp Logo SVG
export const OriginalWhatsAppIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none">
    <circle cx="12" cy="12" r="11.5" fill="#25D366" stroke="#128C7E" strokeWidth="0.5" />
    <path
      d="M12.012 3.5c-4.69 0-8.5 3.81-8.5 8.5 0 1.5.39 2.95 1.14 4.22L3.5 20.5l4.43-1.16c1.23.67 2.62 1.03 4.08 1.03 4.69 0 8.5-3.81 8.5-8.5s-3.81-8.37-8.5-8.37z"
      fill="#25D366"
    />
    <path
      d="M16.98 14.36c-.27-.14-1.61-.79-1.86-.88-.25-.09-.43-.14-.61.14-.18.27-.71.88-.87 1.06-.16.18-.32.2-.59.07-.27-.14-1.15-.42-2.18-1.34-.81-.71-1.35-1.6-1.51-1.87-.16-.27-.02-.42.12-.55.12-.12.27-.32.41-.47.14-.16.18-.27.27-.45.09-.18.05-.34-.02-.48-.07-.14-.61-1.48-.84-2.03-.22-.53-.45-.46-.61-.47l-.52-.01c-.18 0-.48.07-.73.34-.25.27-.95.93-.95 2.27s.98 2.63 1.11 2.81c.14.18 1.93 2.94 4.67 4.12.65.28 1.16.45 1.56.57.65.21 1.25.18 1.72.11.53-.08 1.61-.66 1.84-1.29.23-.64.23-1.18.16-1.29-.07-.12-.25-.19-.52-.33z"
      fill="#FFFFFF"
    />
  </svg>
);

// App Information Icon SVG
export const AppInfoIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg className={className} viewBox="0 0 100 100" fill="none">
    <rect width="100" height="100" rx="26" fill="url(#blue_info_grad)" />
    <defs>
      <linearGradient id="blue_info_grad" x1="50" y1="0" x2="50" y2="100" gradientUnits="userSpaceOnUse">
        <stop stopColor="#38bdf8" />
        <stop offset="0.55" stopColor="#0284c7" />
        <stop offset="1" stopColor="#0369a1" />
      </linearGradient>
    </defs>
    <ellipse cx="50" cy="24" rx="14" ry="9" fill="#ffffff" />
    <rect x="42" y="38" width="16" height="42" rx="1" fill="#ffffff" />
  </svg>
);

const APP_INFO_TEXT_EN = `Important Notes:
If you share your Email and Password with someone else by yourself or if it gets leaked, then in that condition the app will not be responsible for your data.

After logging in with your Email and Password, please turn ON Automatic Backup. Once you turn it ON, all your photos, videos and notes will start backing up automatically.

And if you delete or uninstall the app and then install or download the app again, all your data will be safely restored back inside the app.

App Developers:
Saleem Zakhmi
Zubair Khan`;

const APP_INFO_TEXT_UR = `ضروری ہدایات:
اگر آپ خود اپنی مرضی سے اپنا ای میل اور پاس ورڈ کسی اور کے ساتھ شیئر کرتے ہیں یا اگر یہ لیک ہو جاتا ہے تو اس صورت میں ایپ آپ کے ڈیٹا کی ذمہ دار نہیں ہوگی۔

اپنے ای میل اور پاس ورڈ سے لاگ ان کرنے کے بعد، براہ کرم آٹومیٹک بیک اپ کو آن رکھیں۔ جب آپ اسے آن کریں گے تو آپ کی تمام تصاویر، ویڈیوز اور نوٹس خود بخود محفوظ ہونا شروع ہو جائیں گے۔

اور اگر آپ ایپ ڈیلیٹ یا ان انسٹال کر دیتے ہیں اور پھر دوبارہ ایپ ڈاؤن لوڈ یا انسٹال کرتے ہیں تو آپ کا تمام ڈیٹا باحفاظت واپس بحال ہو جائے گا۔

ایپ ڈویلپرز:
سلیم زخمی
زبیر خان`;

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onBack,
  onOpenAccountSetting,
  onStartChangePassword,
  onRejectChangePassword,
}) => {
  const [showInfo, setShowInfo] = useState<boolean>(false);
  const [language, setLanguage] = useState<'en' | 'ur'>('en');
  const [showEmailModal, setShowEmailModal] = useState<boolean>(false);

  const handleChangePasswordClick = () => {
    const pin = getMasterPin();
    if (!pin || pin.trim().length === 0) {
      onRejectChangePassword();
    } else {
      onStartChangePassword();
    }
  };

  const handleWhatsAppHelp = () => {
    const session = getUserSession();
    const currentEmail = session.email || localStorage.getItem('current_user_email') || '';
    const message = getWhatsAppHelpMessage(currentEmail);
    openWhatsAppDirect(message);
  };

  const handleContactEmail = () => {
    openContactEmail();
  };

  // App Information View
  if (showInfo) {
    return (
      <div className="w-full h-full max-w-xl mx-auto flex flex-col justify-between px-4 sm:px-6 py-4 select-none bg-[#0c1422] text-white overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b border-[#24354f] shrink-0 gap-2">
          <button
            type="button"
            onClick={() => setLanguage((prev) => (prev === 'en' ? 'ur' : 'en'))}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-[#1e293b] hover:bg-[#334155] border border-slate-700 text-xs font-semibold text-slate-200 active:scale-95 transition cursor-pointer shadow-sm shrink-0"
            title="Translate language"
          >
            <span className="text-sm">🌐</span>
            <span className="text-sky-400 font-bold">
              {language === 'en' ? 'Urdu' : 'English'}
            </span>
          </button>
          <div className="flex items-center gap-2 min-w-0">
            <AppInfoIcon className="w-6 h-6 shadow shrink-0" />
            <h1 className="text-base sm:text-xl font-bold text-white tracking-tight truncate">
              {language === 'ur' ? 'معلومات' : 'App Information'}
            </h1>
          </div>
          <button
            onClick={() => setShowInfo(false)}
            className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-4 py-1.5 rounded-xl text-sm transition shadow-md flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            Back
          </button>
        </div>

        <div className="flex-1 bg-[#131e2e] border border-[#24354f] rounded-2xl p-5 sm:p-6 flex flex-col justify-between min-h-0 shadow-2xl overflow-y-auto my-3 select-none space-y-4">
          <p
            className={`text-sm sm:text-base text-slate-100 leading-relaxed select-none whitespace-pre-line ${
              language === 'ur' ? 'text-right font-medium' : 'text-left font-normal font-sans'
            }`}
            dir={language === 'ur' ? 'rtl' : 'ltr'}
          >
            {language === 'ur' ? APP_INFO_TEXT_UR : APP_INFO_TEXT_EN}
          </p>

          <button
            onClick={handleWhatsAppHelp}
            className="w-full py-3 bg-[#25D366] hover:bg-[#20ba5a] active:scale-95 text-white font-bold rounded-xl transition flex items-center justify-center gap-2.5 shadow-lg shadow-green-500/20 text-sm cursor-pointer shrink-0"
          >
            <OriginalWhatsAppIcon className="w-5 h-5" />
            <span>Contact WhatsApp</span>
          </button>
        </div>
      </div>
    );
  }

  // Main Settings View
  return (
    <div className="w-full h-full max-w-xl mx-auto flex flex-col justify-between px-4 sm:px-6 py-4 select-none bg-[#0c1422] text-white overflow-y-auto relative">
      <div className="flex items-center justify-between pb-6 pt-1">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Calculator Pro</h1>
          <p className="text-sm text-slate-400 font-normal mt-0.5">Settings</p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenAccountSetting}
            className="w-12 h-12 rounded-2xl bg-[#1c74e9] hover:bg-[#1563ca] border border-[#3b82f6] flex items-center justify-center text-white transition active:scale-90 cursor-pointer shadow-lg shadow-blue-500/30"
            title="Account & Supabase Cloud Settings"
          >
            <User className="w-6 h-6 text-white stroke-[2.3]" />
          </button>
          <button
            onClick={onBack}
            className="bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-medium px-4 py-2 rounded-xl text-sm transition shadow-md flex items-center gap-1.5 cursor-pointer"
          >
            Back
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-start space-y-6">
        <div className="flex items-center gap-3 px-1">
          <div className="w-12 h-12 rounded-2xl bg-[#ef4444] flex items-center justify-center shadow-lg shadow-red-500/20">
            <SettingsIcon className="w-7 h-7 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white tracking-wide">Setting</h2>
        </div>

        {/* 4 Settings Items */}
        <div className="bg-[#152033] border border-[#23344d] rounded-2xl p-5 shadow-2xl space-y-5">
          {/* Item 1: Change Password */}
          <div
            onClick={handleChangePasswordClick}
            className="flex items-center gap-4 py-3 px-2 rounded-xl hover:bg-[#1a283e] active:scale-[0.99] cursor-pointer transition group"
          >
            <span className="text-lg font-bold text-white w-4">1</span>
            <div className="w-6 h-6 flex items-center justify-center text-[#f59e0b]">
              <Lock className="w-5 h-5 fill-[#f59e0b]/20" />
            </div>
            <span className="text-[#f59e0b] font-semibold text-lg tracking-wide group-hover:translate-x-1 transition">
              Change Password
            </span>
          </div>

          {/* Item 2: Contact Email (Name: Contact Email, Icon: Original Email) */}
          <div
            onClick={handleContactEmail}
            className="flex items-center gap-4 py-3 px-2 rounded-xl hover:bg-[#1a283e] active:scale-[0.99] cursor-pointer transition group"
          >
            <span className="text-lg font-bold text-white w-4">2</span>
            <div className="w-6 h-6 flex items-center justify-center text-[#38bdf8]">
              <Mail className="w-5 h-5 text-[#38bdf8]" />
            </div>
            <span className="text-[#38bdf8] font-semibold text-lg tracking-wide group-hover:translate-x-1 transition">
              Contact Email
            </span>
          </div>

          {/* Item 3: Contact WhatsApp (Name: Contact WhatsApp, Icon: Original WhatsApp) */}
          <div
            onClick={handleWhatsAppHelp}
            className="flex items-center gap-4 py-3 px-2 rounded-xl hover:bg-[#1a283e] active:scale-[0.99] cursor-pointer transition group"
          >
            <span className="text-lg font-bold text-white w-4">3</span>
            <div className="w-6 h-6 flex items-center justify-center">
              <OriginalWhatsAppIcon className="w-6 h-6" />
            </div>
            <span className="text-[#25D366] font-semibold text-lg tracking-wide group-hover:translate-x-1 transition">
              Contact WhatsApp
            </span>
          </div>

          {/* Item 4: App Information */}
          <div
            onClick={() => setShowInfo(true)}
            className="flex items-center gap-4 py-3 px-2 rounded-xl hover:bg-[#1a283e] active:scale-[0.99] cursor-pointer transition group"
          >
            <span className="text-lg font-bold text-white w-4">4</span>
            <div className="w-6 h-6 flex items-center justify-center shrink-0">
              <AppInfoIcon className="w-6 h-6" />
            </div>
            <span className="text-[#38bdf8] font-semibold text-lg tracking-wide group-hover:translate-x-1 transition">
              App Information
            </span>
          </div>
        </div>
      </div>

      {/* Contact Email Modal */}
      {showEmailModal && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => setShowEmailModal(false)}
        >
          <div
            className="bg-[#152033] border border-[#2b3e5e] w-full max-w-sm rounded-2xl p-5 shadow-2xl space-y-4 text-white animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2.5 text-sky-400 border-b border-[#24354f] pb-3">
              <Mail className="w-5 h-5 text-sky-400" />
              <h3 className="text-base font-bold text-white">Contact Email</h3>
            </div>
            <div className="bg-[#0c1422] p-3.5 rounded-xl border border-[#24354f] text-xs text-slate-200 leading-relaxed font-sans">
              <p className="font-semibold text-sky-300 mb-1">Message Preview:</p>
              <p className="italic">{CONTACT_EMAIL_MESSAGE}</p>
            </div>
            <div className="flex gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setShowEmailModal(false)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 font-semibold text-xs rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleContactEmail();
                  setShowEmailModal(false);
                }}
                className="flex-1 py-2.5 bg-[#1c74e9] hover:bg-[#1563ca] active:scale-95 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Mail className="w-4 h-4" />
                <span>Open Email</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
