import React, { useState } from 'react';
import { UserProfile } from '../types';
import { speechManager } from '../utils/speechUtils';
import { playClickTone, playReplyTone } from '../utils/audioEffects';
import {
  ArrowLeft,
  Volume2,
  Sliders,
  HardDrive,
  Shield,
  KeyRound,
  RotateCcw,
  MessageSquare,
  Check,
  AlertCircle,
  Sparkles,
  Globe,
} from 'lucide-react';

interface SettingsScreenProps {
  profile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  onResetProfile: () => void;
  onBack: () => void;
  onOpenHistory: () => void;
  historyCount: number;
  onClearHistory: () => void;
  currentUser: any | null;
  onOpenAuth: (mode?: 'login' | 'signup') => void;
  onSignOut: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  profile,
  onUpdateProfile,
  onResetProfile,
  onBack,
  onOpenHistory,
  historyCount,
  onClearHistory,
  currentUser,
  onOpenAuth,
  onSignOut,
}) => {
  const [speechRate, setSpeechRate] = useState(profile.speechRate || 1.0);
  const [speechPitch, setSpeechPitch] = useState(profile.speechPitch || 1.0);
  const [adminPin, setAdminPin] = useState('');
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');
  const [adminMessage, setAdminMessage] = useState('');
  const [testSpeaking, setTestSpeaking] = useState(false);

  const handleRateChange = (newRate: number) => {
    setSpeechRate(newRate);
    onUpdateProfile({ ...profile, speechRate: newRate });
  };

  const handlePitchChange = (newPitch: number) => {
    setSpeechPitch(newPitch);
    onUpdateProfile({ ...profile, speechPitch: newPitch });
  };

  const handleTestVoice = () => {
    playReplyTone();
    setTestSpeaking(true);
    const isEnglish = profile.language === 'English';
    const testText = isEnglish
      ? profile.gender === 'Female'
        ? "Hello! I'm Ayesha. This is an audio test in English. Can you hear me clearly?"
        : "Hello! I'm Hamza. This is an audio test in English. Can you hear me clearly?"
      : profile.gender === 'Female'
      ? 'سلام! میں عائشہ ہوں۔ صوتی آواز کا یہ ٹیسٹ ہے۔ کیا میری رفتار مناسب ہے؟'
      : 'سلام! میں حمزہ ہوں۔ یہ صوتی آواز کا ٹیسٹ ہے۔ کیا آپ مجھے واضح سن سکتے ہیں؟';

    speechManager.speak(testText, {
      gender: profile.gender,
      language: profile.language || 'Urdu',
      rate: speechRate,
      pitch: speechPitch,
      onEnd: () => setTestSpeaking(false),
      onError: () => setTestSpeaking(false),
    });
  };

  const handleCheckAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    playClickTone();
    // PIN 786 from user's original specification
    if (adminPin.trim() === '786') {
      setIsAdminUnlocked(true);
      setAdminMessage('ایڈمن پینل کھل گیا ہے! (Admin Panel Unlocked!)');
    } else {
      setAdminMessage('غلط پن کوڈ! براہ کرم 786 درج کریں۔ (Incorrect PIN!)');
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#081225] text-white p-4 sm:p-6 pb-20 select-none">
      <div className="max-w-md mx-auto space-y-5">
        {/* Top Header */}
        <div className="flex items-center gap-3 pb-3 border-b border-[#1e3258]">
          <button
            onClick={() => {
              playClickTone();
              onBack();
            }}
            className="p-2.5 rounded-xl bg-[#111e38] border border-[#2a4365] text-[#E2C067] hover:bg-[#1a3366] transition-colors cursor-pointer"
            aria-label="Back to Voice"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-lg font-bold text-[#E2C067] tracking-wider">
              ترتیبات اور ایڈمن (Settings)
            </h1>
            <p className="text-xs text-gray-400">
              AB Voice Bot &bull; Preferences & Storage
            </p>
          </div>
        </div>

        {/* User Account & Cloud Sync Section */}
        <div className="bg-[#111e38] border border-[#1e3258] rounded-2xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#E2C067]" />
              <span>صارف کا اکاؤنٹ (User Account)</span>
            </h2>
            {currentUser && (
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10px] font-semibold border border-emerald-500/30">
                Synced (کلاؤڈ سنک فعال)
              </span>
            )}
          </div>

          {currentUser ? (
            <div className="p-3 bg-[#081225] rounded-xl border border-[#2a4365] space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-white">
                    {currentUser.displayName || profile.name}
                  </div>
                  <div className="text-[11px] text-gray-400 font-mono">
                    {currentUser.email}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    playClickTone();
                    onSignOut();
                  }}
                  className="py-1 px-3 rounded-lg bg-red-950/30 border border-red-500/30 text-red-300 text-xs font-semibold hover:bg-red-900/50 cursor-pointer transition-colors"
                >
                  لاگ آؤٹ (Log Out)
                </button>
              </div>
              <p className="text-[10px] text-gray-400">
                آپ کی گفتگو کی تمام تاریخ کلاؤڈ میں محفوظ ہے اور ڈیوائسز کے درمیان سنک ہوتی ہے۔
              </p>
            </div>
          ) : (
            <div className="p-3 bg-[#081225] rounded-xl border border-[#2a4365] space-y-2.5">
              <p className="text-xs text-gray-300">
                اپنے اکاؤنٹ میں لاگ ان کریں یا نیا اکاؤنٹ بنائیں تاکہ آپ کی گفتگو اور سیٹنگز محفوظ رہیں۔
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    playClickTone();
                    onOpenAuth('login');
                  }}
                  className="py-2 px-3 rounded-xl bg-gradient-to-r from-[#FFF2B2] via-[#E2C067] to-[#B89230] text-[#081225] font-bold text-xs hover:brightness-110 cursor-pointer shadow text-center"
                >
                  لاگ ان (Log In)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    playClickTone();
                    onOpenAuth('signup');
                  }}
                  className="py-2 px-3 rounded-xl bg-[#112244] border border-[#2a4365] text-white hover:bg-[#1a3366] font-semibold text-xs cursor-pointer text-center"
                >
                  نیا اکاؤنٹ بنائیں (Sign Up)
                </button>
              </div>
            </div>
          )}
        </div>

        {/* AI Response Language Switcher Section */}
        <div className="bg-[#111e38] border border-[#1e3258] rounded-2xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Globe className="w-4 h-4 text-[#E2C067]" />
              <span>AI جوابات کی زبان (AI Language)</span>
            </h2>
            <span className="text-[11px] font-bold text-[#E2C067] px-2.5 py-0.5 rounded-full bg-[#E2C067]/15 border border-[#E2C067]/40 shadow-sm">
              {profile.language === 'English' ? '🇬🇧 English' : '🇵🇰 اردو (Urdu)'}
            </span>
          </div>

          <p className="text-xs text-gray-400">
            منتخب کریں کہ بوٹ آپ سے اردو میں بات کرے یا خالص انگریزی میں۔ سسٹم پرامپٹ خود بخود اس زبان پر ایڈجسٹ ہو جائے گا۔
          </p>

          <div className="grid grid-cols-2 gap-2.5 pt-1">
            <button
              type="button"
              onClick={() => {
                playClickTone();
                onUpdateProfile({ ...profile, language: 'Urdu' });
              }}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                profile.language !== 'English'
                  ? 'bg-gradient-to-br from-[#E2C067] to-[#b89230] text-[#081225] border-[#E2C067] font-bold shadow-[0_0_15px_rgba(226,192,103,0.35)]'
                  : 'bg-[#081225] text-gray-300 border-[#2a4365] hover:border-gray-500'
              }`}
            >
              <div className="flex items-center gap-1.5 font-bold text-sm">
                <span className="text-base">🇵🇰</span>
                <span>اردو (Urdu)</span>
                {profile.language !== 'English' && (
                  <Check className="w-3.5 h-3.5 text-[#081225]" />
                )}
              </div>
              <span
                className={`text-[10px] ${
                  profile.language !== 'English' ? 'text-[#081225]/85' : 'text-gray-400'
                }`}
              >
                قدرتی اردو میں گفتگو اور صوتیات
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                playClickTone();
                onUpdateProfile({ ...profile, language: 'English' });
              }}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                profile.language === 'English'
                  ? 'bg-gradient-to-br from-[#E2C067] to-[#b89230] text-[#081225] border-[#E2C067] font-bold shadow-[0_0_15px_rgba(226,192,103,0.35)]'
                  : 'bg-[#081225] text-gray-300 border-[#2a4365] hover:border-gray-500'
              }`}
            >
              <div className="flex items-center gap-1.5 font-bold text-sm">
                <span className="text-base">🇬🇧</span>
                <span>English</span>
                {profile.language === 'English' && (
                  <Check className="w-3.5 h-3.5 text-[#081225]" />
                )}
              </div>
              <span
                className={`text-[10px] ${
                  profile.language === 'English' ? 'text-[#081225]/85' : 'text-gray-400'
                }`}
              >
                Natural fluent English responses
              </span>
            </button>
          </div>
        </div>

        {/* Voice Customization Section */}
        <div className="bg-[#111e38] border border-[#1e3258] rounded-2xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#E2C067]" />
              <span>آواز کی ترتیبات (Voice Audio Settings)</span>
            </h2>
            <button
              onClick={handleTestVoice}
              disabled={testSpeaking}
              className="px-3 py-1 text-xs font-semibold rounded-lg bg-[#E2C067]/20 border border-[#E2C067]/40 text-[#E2C067] hover:bg-[#E2C067]/30 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Volume2 className={`w-3.5 h-3.5 ${testSpeaking ? 'animate-bounce' : ''}`} />
              <span>{testSpeaking ? 'ٹیسٹ ہو رہا ہے...' : 'آواز ٹیسٹ کریں'}</span>
            </button>
          </div>

          {/* Speech Rate */}
          <div>
            <div className="flex justify-between text-xs text-gray-300 mb-1">
              <span>بولنے کی رفتار (Speech Speed):</span>
              <span className="font-bold text-[#E2C067]">{speechRate.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.6"
              max="1.8"
              step="0.1"
              value={speechRate}
              onChange={(e) => handleRateChange(parseFloat(e.target.value))}
              className="w-full accent-[#E2C067] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-gray-400">
              <span>آہستہ (0.6x)</span>
              <span>عام (1.0x)</span>
              <span>تیز (1.8x)</span>
            </div>
          </div>

          {/* Speech Pitch */}
          <div>
            <div className="flex justify-between text-xs text-gray-300 mb-1">
              <span>آواز کا سر (Voice Pitch):</span>
              <span className="font-bold text-[#E2C067]">{speechPitch.toFixed(1)}</span>
            </div>
            <input
              type="range"
              min="0.7"
              max="1.4"
              step="0.05"
              value={speechPitch}
              onChange={(e) => handlePitchChange(parseFloat(e.target.value))}
              className="w-full accent-[#E2C067] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-gray-400">
              <span>بھاری (Deep)</span>
              <span>نارمل (Natural)</span>
              <span>باریک (High)</span>
            </div>
          </div>

          {/* Active Bot Character Switcher */}
          <div className="pt-2 border-t border-white/5">
            <div className="text-xs text-gray-300 mb-2">فعال کردار (Active Character):</div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  playClickTone();
                  onUpdateProfile({
                    ...profile,
                    gender: 'Male',
                    characterName: 'حمزہ (Hamza)',
                  });
                }}
                className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                  profile.gender === 'Male'
                    ? 'bg-[#E2C067] text-[#081225] border-[#E2C067] font-bold shadow'
                    : 'bg-[#081225] text-gray-300 border-[#2a4365]'
                }`}
              >
                <span>حمزہ (Boy)</span>
                {profile.gender === 'Male' && <Check className="w-3.5 h-3.5" />}
              </button>

              <button
                type="button"
                onClick={() => {
                  playClickTone();
                  onUpdateProfile({
                    ...profile,
                    gender: 'Female',
                    characterName: 'عائشہ (Ayesha)',
                  });
                }}
                className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                  profile.gender === 'Female'
                    ? 'bg-[#E2C067] text-[#081225] border-[#E2C067] font-bold shadow'
                    : 'bg-[#081225] text-gray-300 border-[#2a4365]'
                }`}
              >
                <span>عائشہ (Girl)</span>
                {profile.gender === 'Female' && <Check className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Conversation History & Memory Hub */}
        <div className="bg-[#111e38] border border-[#1e3258] rounded-2xl p-5 shadow-lg space-y-3">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-[#E2C067]" />
            <span>گفتگو کی میموری (Conversation History)</span>
          </h2>
          <p className="text-xs text-gray-400">
            آپ کے تمام پیغامات ڈیوائس میموری میں محفوظ ہیں تاکہ AI آپ کو یاد رکھ سکے۔
          </p>

          <div className="p-3 bg-[#081225] rounded-xl border border-[#2a4365] flex items-center justify-between">
            <div>
              <div className="text-xs text-gray-400">محفوظ پیغامات:</div>
              <div className="text-base font-bold text-[#E2C067]">
                {historyCount} Messages
              </div>
            </div>
            <button
              onClick={() => {
                playClickTone();
                onOpenHistory();
              }}
              className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-[#E2C067] to-[#b89230] text-[#081225] font-bold text-xs hover:brightness-110 cursor-pointer shadow"
            >
              تاریخ دیکھیں (View History)
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={() => {
                if (window.confirm('کیا آپ تمام چیٹ میموری صاف کرنا چاہتے ہیں؟')) {
                  playClickTone();
                  onClearHistory();
                }
              }}
              disabled={historyCount === 0}
              className="py-2.5 px-3 rounded-xl border border-red-500/30 bg-red-950/20 text-red-300 text-xs font-semibold hover:bg-red-900/40 disabled:opacity-40 transition-colors cursor-pointer"
            >
              میموری صاف کریں (Clear)
            </button>

            <button
              onClick={() => {
                if (window.confirm('پروفائل ری سیٹ کریں اور نام تبدیل کریں؟')) {
                  playClickTone();
                  onResetProfile();
                }
              }}
              className="py-2.5 px-3 rounded-xl border border-[#2a4365] bg-[#081225] text-gray-200 text-xs font-semibold hover:text-[#E2C067] hover:border-[#E2C067] transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>نام تبدیل کریں (Reset)</span>
            </button>
          </div>
        </div>

        {/* Device Storage Status Check (Matching Cordova checkStorageSpace) */}
        <div className="bg-[#111e38] border border-[#1e3258] rounded-2xl p-5 shadow-lg space-y-2.5">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <HardDrive className="w-4 h-4 text-emerald-400" />
            <span>انٹرنل اسٹوریج چیک (Storage Health)</span>
          </div>
          <div className="p-3 bg-[#081225] rounded-xl border border-[#2a4365] space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-gray-400">اسٹوریج کیفیت:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                محفوظ اور نارمل (Safe)
              </span>
            </div>
            <div className="w-full bg-[#111e38] h-2 rounded-full overflow-hidden mt-2">
              <div className="bg-emerald-400 h-full w-[12%]" />
            </div>
            <div className="text-[10px] text-gray-400 pt-1">
              موبائل اسٹوریج میں گفتگو محفوظ کرنے کے لیے وافر گنجائش موجود ہے۔
            </div>
          </div>
        </div>

        {/* Secret Admin Panel Trigger (PIN 786) */}
        <div className="bg-[#111e38] border border-[#1e3258] rounded-2xl p-5 shadow-lg space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-[#E2C067]">
            <Shield className="w-4 h-4" />
            <span>خفیہ ایڈمن رسائی (Admin Access)</span>
          </div>
          <p className="text-xs text-gray-400">
            ایڈمن پینل کھولنے کے لیے خفیہ پن کوڈ (PIN 786) درج کریں۔
          </p>

          {!isAdminUnlocked ? (
            <form onSubmit={handleCheckAdmin} className="space-y-3">
              <div className="relative">
                <input
                  type="password"
                  placeholder="Enter Secret Code (786)"
                  value={adminPin}
                  onChange={(e) => setAdminPin(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#081225] border border-[#2a4365] rounded-xl text-white text-sm placeholder-gray-500 focus:outline-none focus:border-[#E2C067]"
                />
                <KeyRound className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
              </div>

              {adminMessage && (
                <div
                  className={`text-xs p-2 rounded-lg flex items-center gap-1.5 ${
                    adminMessage.includes('غلط')
                      ? 'bg-red-950/40 text-red-300 border border-red-800/40'
                      : 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/40'
                  }`}
                >
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{adminMessage}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#FFF2B2] via-[#E2C067] to-[#B89230] text-[#081225] font-bold text-xs uppercase tracking-wider hover:brightness-110 cursor-pointer shadow"
              >
                ایڈمن پینل کھولیں (Open Admin Panel)
              </button>
            </form>
          ) : (
            /* Unlocked Admin Panel */
            <div className="p-4 bg-[#081225] border border-dashed border-[#E2C067] rounded-xl space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between text-xs text-[#E2C067] font-bold border-b border-white/10 pb-2">
                <span>🛠️ Secret Admin Panel (Unlocked)</span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px]">
                  PIN Verified
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-gray-400 block mb-1">
                    AI انجن اور ماڈل:
                  </span>
                  <div className="p-2 bg-[#111e38] rounded-lg border border-[#1e3258] text-emerald-300 font-mono text-[11px]">
                    Google Gemini 3.8 Flash (Server-Side Proxy Active)
                  </div>
                </div>

                <div>
                  <label className="text-gray-400 block mb-1">
                    اپنی مرضی کی ہدایات (Custom System Prompt Extension):
                  </label>
                  <textarea
                    rows={2}
                    value={customPrompt}
                    onChange={(e) => setCustomPrompt(e.target.value)}
                    placeholder="مثال: بات چیت میں زیادہ شائستہ الفاظ استعمال کریں..."
                    className="w-full p-2.5 bg-[#111e38] border border-[#2a4365] rounded-lg text-white text-xs focus:outline-none focus:border-[#E2C067]"
                  />
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <span className="text-[11px] text-gray-400">
                    AB Innovations Cloud Core
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      playClickTone();
                      alert('ایڈمن ترتیبات کامیابی سے محفوظ ہو گئیں!');
                    }}
                    className="px-3 py-1.5 rounded-lg bg-[#E2C067] text-[#081225] font-bold text-xs hover:brightness-110 cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
