import React, { useState } from 'react';
import { BusinessProfile } from '../types/business';
import { StorageService } from '../db/storage';
import {
  Settings,
  ArrowLeft,
  Building2,
  Globe,
  Download,
  Upload,
  User,
  Phone,
  MapPin,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Mail,
  MessageCircle,
} from 'lucide-react';
import { DEVELOPER_INFO } from '../utils/developerInfo';

interface SettingsScreenProps {
  profile: BusinessProfile;
  lang: 'bn' | 'en';
  onBack: () => void;
  onLanguageChange: (lang: 'bn' | 'en') => void;
  onProfileUpdate: (updated: BusinessProfile) => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  profile,
  lang,
  onBack,
  onLanguageChange,
  onProfileUpdate,
}) => {
  const [businessName, setBusinessName] = useState(profile.businessName);
  const [ownerName, setOwnerName] = useState(profile.ownerName || DEVELOPER_INFO.name);
  const [phone, setPhone] = useState(profile.phone || DEVELOPER_INFO.contactNumber);
  const [address, setAddress] = useState(profile.address || DEVELOPER_INFO.address);
  const [successMsg, setSuccessMsg] = useState('');
  const [importStatus, setImportStatus] = useState('');

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: BusinessProfile = {
      ...profile,
      businessName: businessName.trim(),
      ownerName: ownerName.trim(),
      phone: phone.trim(),
      address: address.trim(),
      updatedAt: new Date().toISOString(),
    };

    StorageService.saveBusinessProfile(updated);
    onProfileUpdate(updated);
    setSuccessMsg(lang === 'bn' ? 'ব্যবসায়িক তথ্য সফলভাবে আপডেট হয়েছে!' : 'Profile updated successfully!');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  // Export JSON Backup
  const handleExportBackup = () => {
    const jsonStr = StorageService.exportBackupJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Business_Management_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Import JSON Restore
  const handleImportRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        const res = StorageService.importBackupJson(content);
        if (res.success) {
          setImportStatus('✓ ' + res.message);
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        } else {
          setImportStatus('⚠️ ' + res.message);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <Settings className="w-5 h-5 text-slate-700" />
                <span>{lang === 'bn' ? 'অ্যাপ সেটিংস ও ব্যাকআপ' : 'Settings & Backup'}</span>
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn' ? 'ভাষা, প্রোফাইল ও ডাটাবেজ ব্যাকআপ পরিচালনা' : 'Manage language, business profile & backups'}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Developer Credit Badge */}
        <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-indigo-700 rounded-3xl p-6 text-white shadow-md relative overflow-hidden">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-semibold uppercase tracking-wider text-blue-100">
                  {lang === 'bn' ? 'অফিসিয়াল ডেভেলপার পরিচিতি' : 'Official Developer Profile'}
                </span>
              </div>
              <h3 className="text-2xl font-black mt-2 tracking-tight">
                {DEVELOPER_INFO.name} ({DEVELOPER_INFO.nameBn})
              </h3>

              {/* Contact Info Pills */}
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-2 rounded-xl border border-white/10">
                  <Phone className="w-4 h-4 text-emerald-300 shrink-0" />
                  <div>
                    <span className="text-[10px] text-blue-200 block">{lang === 'bn' ? 'মোবাইল নম্বর' : 'Phone'}</span>
                    <a href={`tel:${DEVELOPER_INFO.contactNumber}`} className="font-bold hover:underline">
                      {DEVELOPER_INFO.contactNumber}
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-2 rounded-xl border border-white/10">
                  <Mail className="w-4 h-4 text-amber-300 shrink-0" />
                  <div>
                    <span className="text-[10px] text-blue-200 block">{lang === 'bn' ? 'ইমেইল অ্যাড্রেস' : 'Email'}</span>
                    <a href={`mailto:${DEVELOPER_INFO.email}`} className="font-bold hover:underline truncate block">
                      {DEVELOPER_INFO.email}
                    </a>
                  </div>
                </div>
              </div>

              {/* Detailed Address Grid */}
              <div className="mt-3 p-3.5 rounded-2xl bg-black/15 backdrop-blur-sm border border-white/10 text-xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-blue-100 font-semibold">
                  <MapPin className="w-4 h-4 text-rose-300 shrink-0" />
                  <span>{lang === 'bn' ? 'ঠিকানা ও লোকেশন বিবরণ:' : 'Address & Location Details:'}</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px] text-blue-100">
                  <div>
                    <span className="text-blue-300 block text-[10px]">{lang === 'bn' ? 'পোস্ট অফিস' : 'Post Office'}</span>
                    <span className="font-bold">{DEVELOPER_INFO.postOffice}</span>
                  </div>
                  <div>
                    <span className="text-blue-300 block text-[10px]">{lang === 'bn' ? 'থানা' : 'Thana'}</span>
                    <span className="font-bold">{DEVELOPER_INFO.thana}</span>
                  </div>
                  <div>
                    <span className="text-blue-300 block text-[10px]">{lang === 'bn' ? 'উপজেলা' : 'Upazila'}</span>
                    <span className="font-bold">{DEVELOPER_INFO.upazila}</span>
                  </div>
                  <div>
                    <span className="text-blue-300 block text-[10px]">{lang === 'bn' ? 'জেলা ও দেশ' : 'District & Country'}</span>
                    <span className="font-bold">Sylhet, Bangladesh</span>
                  </div>
                </div>
              </div>

              {/* Direct Quick Action Buttons */}
              <div className="mt-3.5 flex flex-wrap items-center gap-2">
                <a
                  href={`tel:${DEVELOPER_INFO.contactNumber}`}
                  className="px-3 py-1.5 rounded-xl bg-white text-indigo-700 font-bold text-xs flex items-center gap-1.5 hover:bg-blue-50 transition-colors shadow-xs"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'সরাসরি কল' : 'Call'}</span>
                </a>
                <a
                  href={`https://wa.me/88${DEVELOPER_INFO.contactNumber}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
                <a
                  href={`mailto:${DEVELOPER_INFO.email}`}
                  className="px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Email</span>
                </a>
              </div>
            </div>

            <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center shrink-0 self-start sm:self-center">
              <ShieldCheck className="w-8 h-8 text-white" />
            </div>
          </div>
        </div>

        {/* Language Switch */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-3">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Globe className="w-4 h-4 text-blue-600" />
            <span>{lang === 'bn' ? 'ভাষা নির্বাচন (Language)' : 'Language Selection'}</span>
          </h3>
          <div className="flex gap-3">
            <button
              onClick={() => onLanguageChange('bn')}
              className={`flex-1 py-3 rounded-2xl text-xs font-bold border cursor-pointer transition-all ${
                lang === 'bn'
                  ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              বাংলা (Bengali - Default)
            </button>
            <button
              onClick={() => onLanguageChange('en')}
              className={`flex-1 py-3 rounded-2xl text-xs font-bold border cursor-pointer transition-all ${
                lang === 'en'
                  ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              English
            </button>
          </div>
        </div>

        {/* Business Profile Edit */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Building2 className="w-4 h-4 text-indigo-600" />
            <span>{lang === 'bn' ? 'ব্যবসায়িক তথ্য সম্পাদনা' : 'Business Profile'}</span>
          </h3>

          {successMsg && (
            <div className="p-3 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">প্রতিষ্ঠানের নাম</label>
              <input
                type="text"
                required
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">মালিকের নাম</label>
                <input
                  type="text"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">মোবাইল নম্বর</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ঠিকানা / লোকেশন</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
              />
            </div>

            <button
              type="submit"
              className="py-2.5 px-5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-500/20 cursor-pointer"
            >
              প্রোফাইল আপডেট করুন
            </button>
          </form>
        </div>

        {/* Backup & Restore (JSON / Google Drive Ready) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Download className="w-4 h-4 text-emerald-600" />
            <span>{lang === 'bn' ? 'ডাটাবেজ ব্যাকআপ ও রিস্টোর' : 'Backup & Restore'}</span>
          </h3>
          <p className="text-xs text-slate-500">
            {lang === 'bn'
              ? 'আপনার সকল পণ্য, কাস্টমার, চালান, বাকি ও আর্থিক খতিয়ান নিরাপদে অফলাইন ফাইলে ডাউনলোড করুন অথবা Google Drive এ সেভ রাখুন।'
              : 'Download complete offline encrypted JSON backup or restore onto a new device.'}
          </p>

          {importStatus && (
            <div className="p-3 bg-blue-50 text-blue-900 text-xs font-bold rounded-xl">
              {importStatus}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <button
              onClick={handleExportBackup}
              className="py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{lang === 'bn' ? 'এখনই ব্যাকআপ ডাউনলোড করুন' : 'Backup Now'}</span>
            </button>

            <label className="py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer">
              <Upload className="w-4 h-4" />
              <span>{lang === 'bn' ? 'ফাইল থেকে রিস্টোর করুন' : 'Restore from File'}</span>
              <input
                type="file"
                accept=".json"
                className="hidden"
                onChange={handleImportRestore}
              />
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};
