import React, { useState, useRef, useEffect } from 'react';
import { Calendar, Gift, Sparkles, Check, ExternalLink, Trophy, Target, Award } from 'lucide-react';
import confetti from 'canvas-confetti';
import { EarnTask, DailyStreakDay, Mission } from '../types';
import { soundEngine, triggerHaptic } from '../utils/audio';

interface EarnViewProps {
  tasks: EarnTask[];
  dailyStreaks: DailyStreakDay[];
  missions: Mission[];
  onClaimDaily: (dayIndex: number) => void;
  onClaimTask: (taskId: string) => void;
  onClaimMission: (missionId: string) => void;
  onSpinReward: (coinsWon: number) => void;
  freeSpinsAvailable: number;
}

const WHEEL_SEGMENTS = [
  { label: '500 Coins', value: 500, color: '#3b82f6', text: '#ffffff' },
  { label: '1,000 Coins', value: 1000, color: '#10b981', text: '#ffffff' },
  { label: '2,500 Coins', value: 2500, color: '#f59e0b', text: '#000000' },
  { label: '250 Coins', value: 250, color: '#6366f1', text: '#ffffff' },
  { label: '5,000 Coins', value: 5000, color: '#ec4899', text: '#ffffff' },
  { label: '1,500 Coins', value: 1500, color: '#14b8a6', text: '#ffffff' },
  { label: '10,000 JACKPOT', value: 10000, color: '#eab308', text: '#000000' },
  { label: '750 Coins', value: 750, color: '#8b5cf6', text: '#ffffff' },
];

export const EarnView: React.FC<EarnViewProps> = ({
  tasks,
  dailyStreaks,
  missions,
  onClaimDaily,
  onClaimTask,
  onClaimMission,
  onSpinReward,
  freeSpinsAvailable,
}) => {
  const [activeEarnTab, setActiveEarnTab] = useState<'missions' | 'streak' | 'wheel' | 'tasks'>('missions');
  const [isSpinning, setIsSpinning] = useState(false);
  const [wheelRotation, setWheelRotation] = useState(0);
  const [lastWonPrize, setLastWonPrize] = useState<number | null>(null);

  // Scratch card state
  const [scratchedBoxes, setScratchedBoxes] = useState<boolean[]>([false, false, false]);
  const [scratchRewardClaimed, setScratchRewardClaimed] = useState(false);
  const scratchValues = [1200, 1200, 1200];

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const claimableMissionsCount = missions.filter(
    (m) => m.currentCount >= m.targetCount && !m.claimed
  ).length;

  // Draw the spinning wheel on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = canvas.width;
    const center = size / 2;
    const radius = center - 8;
    const numSegments = WHEEL_SEGMENTS.length;
    const anglePerSegment = (2 * Math.PI) / numSegments;

    ctx.clearRect(0, 0, size, size);

    WHEEL_SEGMENTS.forEach((seg, i) => {
      const startAngle = i * anglePerSegment;
      const endAngle = startAngle + anglePerSegment;

      ctx.beginPath();
      ctx.moveTo(center, center);
      ctx.arc(center, center, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = seg.color;
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#0f172a';
      ctx.stroke();

      // Text label
      ctx.save();
      ctx.translate(center, center);
      ctx.rotate(startAngle + anglePerSegment / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = seg.text;
      ctx.font = 'bold 11px Outfit, sans-serif';
      ctx.fillText(seg.label, radius - 14, 4);
      ctx.restore();
    });

    // Center peg
    ctx.beginPath();
    ctx.arc(center, center, 18, 0, 2 * Math.PI);
    ctx.fillStyle = '#0f172a';
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#f59e0b';
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(center, center, 8, 0, 2 * Math.PI);
    ctx.fillStyle = '#f59e0b';
    ctx.fill();
  }, [activeEarnTab]);

  const handleSpinWheel = () => {
    if (isSpinning || freeSpinsAvailable <= 0) return;

    setIsSpinning(true);
    setLastWonPrize(null);
    triggerHaptic('medium');

    const chosenIndex = Math.floor(Math.random() * WHEEL_SEGMENTS.length);
    const chosenPrize = WHEEL_SEGMENTS[chosenIndex];

    const segmentAngle = 360 / WHEEL_SEGMENTS.length;
    const extraRounds = 5 * 360;
    const targetAngle = 270 - (chosenIndex * segmentAngle + segmentAngle / 2);
    const totalNewRotation = wheelRotation + extraRounds + (targetAngle - (wheelRotation % 360));

    setWheelRotation(totalNewRotation);

    let tickCount = 0;
    const tickInterval = setInterval(() => {
      soundEngine.playSpinTick();
      tickCount++;
      if (tickCount > 18) clearInterval(tickInterval);
    }, 150);

    setTimeout(() => {
      setIsSpinning(false);
      setLastWonPrize(chosenPrize.value);
      soundEngine.playCashRegister();
      triggerHaptic('success');
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
      onSpinReward(chosenPrize.value);
    }, 3200);
  };

  const handleScratch = (index: number) => {
    if (scratchedBoxes[index] || scratchRewardClaimed) return;
    triggerHaptic('light');
    soundEngine.playCoin();

    const updated = [...scratchedBoxes];
    updated[index] = true;
    setScratchedBoxes(updated);

    if (updated.every(Boolean) && !scratchRewardClaimed) {
      setScratchRewardClaimed(true);
      soundEngine.playCrit();
      triggerHaptic('success');
      confetti({ particleCount: 40, spread: 50 });
      onSpinReward(1200);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-3 space-y-4 pb-20">
      {/* Category Tabs */}
      <div className="grid grid-cols-4 gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveEarnTab('missions');
          }}
          className={`py-2 px-1 text-[11px] font-bold rounded-lg transition-colors flex items-center justify-center gap-1 relative ${
            activeEarnTab === 'missions'
              ? 'bg-slate-800 text-amber-400 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Target className="w-3.5 h-3.5" />
          <span className="truncate">Missions</span>
          {claimableMissionsCount > 0 && (
            <span className="w-2 h-2 rounded-full bg-emerald-400 absolute top-1 right-1" />
          )}
        </button>

        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveEarnTab('streak');
          }}
          className={`py-2 px-1 text-[11px] font-bold rounded-lg transition-colors flex items-center justify-center gap-1 ${
            activeEarnTab === 'streak'
              ? 'bg-slate-800 text-amber-400 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span className="truncate">7-Day</span>
        </button>

        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveEarnTab('wheel');
          }}
          className={`py-2 px-1 text-[11px] font-bold rounded-lg transition-colors flex items-center justify-center gap-1 ${
            activeEarnTab === 'wheel'
              ? 'bg-slate-800 text-amber-400 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="truncate">Wheel</span>
        </button>

        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveEarnTab('tasks');
          }}
          className={`py-2 px-1 text-[11px] font-bold rounded-lg transition-colors flex items-center justify-center gap-1 ${
            activeEarnTab === 'tasks'
              ? 'bg-slate-800 text-amber-400 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Gift className="w-3.5 h-3.5" />
          <span className="truncate">Tasks</span>
        </button>
      </div>

      {/* Tab 0: Missions & Challenges */}
      {activeEarnTab === 'missions' && (
        <div className="space-y-3">
          <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border border-amber-800/40 rounded-2xl p-3.5 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-extrabold text-white font-display">Clicker Missions</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Complete tap and upgrade goals for huge bonus cash!
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Award className="w-5 h-5 text-amber-400" />
            </div>
          </div>

          <div className="space-y-2.5">
            {missions.map((mission) => {
              const progressPct = Math.min(
                100,
                Math.round((mission.currentCount / mission.targetCount) * 100)
              );
              const isCompleted = mission.currentCount >= mission.targetCount;

              return (
                <div
                  key={mission.id}
                  className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3.5 space-y-2.5 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-xs font-bold text-white">{mission.title}</h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">{mission.description}</p>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-xs font-black text-amber-400 font-mono-num block">
                        +{mission.rewardCoins.toLocaleString()} Coins
                      </span>
                      <span className="text-[10px] font-bold text-emerald-400 font-mono-num block">
                        Rs. {mission.rewardPKR}
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] font-mono-num text-slate-400">
                      <span>Progress:</span>
                      <span className="font-bold text-slate-300">
                        {Math.min(mission.currentCount, mission.targetCount)} / {mission.targetCount} ({progressPct}%)
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-950 border border-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isCompleted
                            ? 'bg-gradient-to-r from-emerald-500 to-green-400'
                            : 'bg-gradient-to-r from-amber-500 to-yellow-400'
                        }`}
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                  </div>

                  {/* Action Button */}
                  <div className="pt-1">
                    {mission.claimed ? (
                      <div className="w-full py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-emerald-400 text-xs font-bold flex items-center justify-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        <span>Completed & Claimed</span>
                      </div>
                    ) : isCompleted ? (
                      <button
                        onClick={() => {
                          triggerHaptic('success');
                          soundEngine.playCashRegister();
                          confetti({ particleCount: 50, spread: 60 });
                          onClaimMission(mission.id);
                        }}
                        className="w-full py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-green-500 text-slate-950 text-xs font-black shadow-md shadow-emerald-500/20 active:scale-95 transition-transform"
                      >
                        Claim Reward (+{mission.rewardCoins.toLocaleString()} Coins)
                      </button>
                    ) : (
                      <div className="w-full py-1.5 rounded-xl bg-slate-800/60 text-slate-500 text-[11px] font-semibold text-center">
                        In Progress ({mission.targetCount - mission.currentCount} remaining)
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 1: 7-Day Streak Calendar */}
      {activeEarnTab === 'streak' && (
        <div className="space-y-3">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-bold text-white font-display">Daily Check-In Streak</h3>
                <p className="text-xs text-slate-400">Log in every day to unlock the Day 7 Mega Chest!</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                <Trophy className="w-5 h-5 text-amber-400" />
              </div>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
              {dailyStreaks.map((item, idx) => (
                <div
                  key={item.day}
                  className={`p-2 rounded-xl border text-center transition-all flex flex-col justify-between ${
                    item.claimed
                      ? 'bg-slate-950/60 border-slate-800 opacity-60'
                      : item.isToday
                      ? 'bg-amber-500/10 border-amber-500 ring-1 ring-amber-400'
                      : 'bg-slate-900 border-slate-800'
                  }`}
                >
                  <span className="text-[10px] font-bold text-slate-400">
                    Day {item.day}
                  </span>
                  <div className="my-1.5">
                    <span className="text-xs font-black text-amber-400 font-mono-num block">
                      +{item.coins >= 1000 ? `${item.coins / 1000}k` : item.coins}
                    </span>
                    <span className="text-[9px] text-emerald-400 font-bold block">
                      Rs. {item.pkrValue}
                    </span>
                  </div>
                  {item.claimed ? (
                    <span className="text-[10px] text-slate-500 font-bold">Claimed</span>
                  ) : item.isToday ? (
                    <button
                      onClick={() => {
                        triggerHaptic('success');
                        soundEngine.playCoin();
                        confetti({ particleCount: 30, spread: 40 });
                        onClaimDaily(idx);
                      }}
                      className="w-full py-1 rounded bg-amber-400 text-slate-950 text-[10px] font-black active:scale-95 transition-transform"
                    >
                      Claim
                    </button>
                  ) : (
                    <span className="text-[10px] text-slate-600 font-semibold">Locked</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Mystery Scratch Card Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Hourly Mystery Scratch Card
                </h4>
                <p className="text-[11px] text-slate-400">Scratch all 3 boxes to reveal your instant jackpot!</p>
              </div>
              <span className="text-xs font-mono font-bold text-amber-400">
                {scratchRewardClaimed ? 'Claimed' : 'Ready'}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 mt-3">
              {scratchedBoxes.map((isScratched, i) => (
                <button
                  key={i}
                  disabled={isScratched || scratchRewardClaimed}
                  onClick={() => handleScratch(i)}
                  className={`h-16 rounded-xl border font-black text-sm flex items-center justify-center transition-all ${
                    isScratched
                      ? 'bg-amber-500/10 border-amber-500/50 text-amber-300 font-mono-num'
                      : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-400 cursor-pointer active:scale-95'
                  }`}
                >
                  {isScratched ? `🪙 ${scratchValues[i]}` : '❓ Scratch'}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Lucky Wheel */}
      {activeEarnTab === 'wheel' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-center space-y-4">
          <div>
            <h3 className="text-sm font-bold text-white font-display">Lucky Cash Spin Wheel</h3>
            <p className="text-xs text-slate-400">
              Spin to win up to 10,000 Coins (Rs. 100) instantly!
            </p>
          </div>

          <div className="relative w-64 h-64 mx-auto flex items-center justify-center">
            {/* Top Pointer */}
            <div className="absolute -top-2 left-1/2 -translate-x-1/2 z-20 w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[18px] border-t-amber-400 drop-shadow-md" />

            {/* Canvas Wheel */}
            <canvas
              ref={canvasRef}
              width={256}
              height={256}
              className="rounded-full shadow-2xl transition-transform ease-out"
              style={{
                transform: `rotate(${wheelRotation}deg)`,
                transitionDuration: isSpinning ? '3.2s' : '0s',
                transitionTimingFunction: 'cubic-bezier(0.15, 0.9, 0.2, 1)',
              }}
            />
          </div>

          {lastWonPrize !== null && (
            <div className="p-2.5 bg-emerald-950/60 border border-emerald-800/80 rounded-xl text-xs font-bold text-emerald-300 animate-fadeIn">
              🎉 Congratulations! You won {lastWonPrize.toLocaleString()} Coins!
            </div>
          )}

          <div className="pt-2">
            <button
              onClick={handleSpinWheel}
              disabled={isSpinning || freeSpinsAvailable <= 0}
              className={`w-full h-12 rounded-xl font-black text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95 ${
                freeSpinsAvailable > 0 && !isSpinning
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 hover:brightness-105 shadow-amber-500/20'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              {isSpinning ? (
                <span>Spinning Wheel...</span>
              ) : (
                <span>
                  Spin Now ({freeSpinsAvailable} Free Spin{freeSpinsAvailable === 1 ? '' : 's'})
                </span>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Tab 3: Cash Tasks */}
      {activeEarnTab === 'tasks' && (
        <div className="space-y-2.5">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Sponsored Payout Tasks
            </h3>
            <span className="text-xs text-slate-500">Instant verification</span>
          </div>

          {tasks.map((task) => (
            <div
              key={task.id}
              className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3 flex items-center justify-between gap-3"
            >
              <div>
                <h4 className="text-xs font-bold text-white">{task.title}</h4>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[11px] font-black text-amber-400 font-mono-num">
                    +{task.rewardCoins.toLocaleString()} Coins
                  </span>
                  <span className="text-slate-600 text-[10px]">·</span>
                  <span className="text-[11px] font-bold text-emerald-400 font-mono-num">
                    Rs. {task.rewardPKR}
                  </span>
                </div>
              </div>

              {task.claimed ? (
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1 bg-emerald-500/10 px-2.5 py-1.5 rounded-xl">
                  <Check className="w-3.5 h-3.5" />
                  <span>Claimed</span>
                </span>
              ) : (
                <button
                  onClick={() => {
                    triggerHaptic('success');
                    soundEngine.playCashRegister();
                    confetti({ particleCount: 40, spread: 60 });
                    onClaimTask(task.id);
                  }}
                  className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold transition-all active:scale-95 flex items-center gap-1 shrink-0"
                >
                  <span>{task.actionLabel}</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
