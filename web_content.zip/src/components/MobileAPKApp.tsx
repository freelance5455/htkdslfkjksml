import React, { useEffect, useState } from 'react';
import { Fighter, MatClass } from '../data/dcaData';

export const ACADEMY_COORDS = {
  latitude: 28.6315,
  longitude: 77.2167,
  allowedRadiusMeters: 50,
};

export function getDistanceInMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3;
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c);
}

interface MobileAPKAppProps {
  dailyPin: string;
  onRegeneratePin: () => string;
  classes: MatClass[];
  fighters: Fighter[];
  onCheckInSuccess: (method: string, memberName?: string) => void;
  onOpenAPKStudio: () => void;
  onSwitchToDesktopPortal: () => void;
}

export const MobileAPKApp: React.FC<MobileAPKAppProps> = ({
  dailyPin,
  onRegeneratePin,
  classes,
  fighters,
  onCheckInSuccess,
  onOpenAPKStudio,
  onSwitchToDesktopPortal,
}) => {
  const [userRole, setUserRole] = useState<'member' | 'admin' | null>('member');
  const [authTab, setAuthTab] = useState<'member' | 'admin'>('member');
  const [activeBottomTab, setActiveBottomTab] = useState<'schedule' | 'checkin' | 'profile' | 'analytics'>('checkin');

  // Login states
  const [phoneNumber, setPhoneNumber] = useState('9811244019');
  const [otpCode, setOtpCode] = useState('123456');
  const [otpSent, setOtpSent] = useState(false);
  const [staffId, setStaffId] = useState('coach.vikram@delhicombat.com');
  const [staffPassword, setStaffPassword] = useState('dca-admin-2025');
  const [bannerAlert, setBannerAlert] = useState<{ title: string; message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Geofence & Biometric states
  const [distance, setDistance] = useState<number>(12);
  const [isInsideGeofence, setIsInsideGeofence] = useState<boolean>(true);
  const [isScanningBiometric, setIsScanningBiometric] = useState<boolean>(false);
  const [enteredPin, setEnteredPin] = useState<string>('');
  const [checkInLogs, setCheckInLogs] = useState([
    { id: '1', title: 'Boxing Heavy Bag & Footwork', time: 'Yesterday · 06:30 AM', method: 'Face ID' },
    { id: '2', title: 'MMA Octagon Sparring', time: 'Monday · 05:30 PM', method: 'Daily PIN' },
  ]);

  // Countdown until 23:59 IST
  const [timeRemaining, setTimeRemaining] = useState('06h 42m');

  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      const hrs = 23 - now.getHours();
      const mins = 59 - now.getMinutes();
      setTimeRemaining(`${String(hrs).padStart(2, '0')}h ${String(mins).padStart(2, '0')}m`);
    };
    updateCountdown();
    const timer = setInterval(updateCountdown, 30000);
    return () => clearInterval(timer);
  }, []);

  const showNotice = (title: string, message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setBannerAlert({ title, message, type });
    setTimeout(() => {
      setBannerAlert((prev) => (prev?.title === title ? null : prev));
    }, 3800);
  };

  const detectRealGeolocation = () => {
    if (!('geolocation' in navigator)) {
      setIsInsideGeofence(true);
      setDistance(12);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const dist = getDistanceInMeters(
          pos.coords.latitude,
          pos.coords.longitude,
          ACADEMY_COORDS.latitude,
          ACADEMY_COORDS.longitude
        );
        if (dist <= ACADEMY_COORDS.allowedRadiusMeters) {
          setDistance(dist);
          setIsInsideGeofence(true);
          showNotice('GPS Verified', `Inside 50m club perimeter (${dist}m from ring).`, 'success');
        } else {
          // Show actual distance or allow simulation
          setDistance(dist);
          setIsInsideGeofence(false);
          showNotice(
            'GPS Coordinate Read',
            `Your device is ${dist}m from Connaught Place HQ. Use the Simulator button to test inside-perimeter check-in.`,
            'info'
          );
        }
      },
      () => {
        setDistance(12);
        setIsInsideGeofence(true);
        showNotice('Simulated Club Beacon', 'Connected to DCA-MESH-HQ (12m from Ring).', 'success');
      },
      { enableHighAccuracy: true, timeout: 4000 }
    );
  };

  const handleSendOTP = () => {
    const cleaned = phoneNumber.replace(/\D/g, '');
    if (cleaned.length < 10) {
      showNotice('Invalid Number', 'Please enter a valid 10-digit mobile number.', 'error');
      return;
    }
    setOtpSent(true);
    showNotice('WhatsApp OTP Sent', `6-digit code sent to +91 ${phoneNumber} (Demo code: 123456).`, 'info');
  };

  const handleMemberLogin = () => {
    if (!otpSent) {
      handleSendOTP();
      return;
    }
    if (otpCode.trim().length === 6) {
      setUserRole('member');
      setActiveBottomTab('checkin');
      showNotice('Authenticated', 'Logged in as Aman Sharma (DCA-7840).', 'success');
    } else {
      showNotice('Invalid OTP', 'Please enter the 6-digit OTP code (123456).', 'error');
    }
  };

  const handleAdminLogin = () => {
    if (staffId.trim() && staffPassword.trim()) {
      setUserRole('admin');
      setActiveBottomTab('analytics');
      showNotice('Admin Mode Active', 'Authenticated as Coach Vikram Rathore.', 'success');
    } else {
      showNotice('Credentials Required', 'Enter Coach / Admin ID and passkey.', 'error');
    }
  };

  const completeCheckIn = (method: string) => {
    const newEntry = {
      id: Date.now().toString(),
      title: 'Muay Thai Clinch & Elbow Drills',
      time: 'Just now',
      method,
    };
    setCheckInLogs((prev) => [newEntry, ...prev]);
    onCheckInSuccess(method, 'Aman Sharma');
    showNotice(
      'Attendance Marked ✓',
      `Verified via ${method}. Turnstile Gate 1 unlocked for Aman Sharma.`,
      'success'
    );
  };

  const handleNativeBiometricScan = async () => {
    if (!isInsideGeofence) {
      showNotice(
        'Outside Academy Perimeter',
        'You must be within the 50m club radius to unlock biometric check-in.',
        'error'
      );
      return;
    }
    setIsScanningBiometric(true);
    setTimeout(() => {
      setIsScanningBiometric(false);
      completeCheckIn('Phone Biometrics (Face ID / Fingerprint)');
    }, 900);
  };

  const handlePinPress = (digit: string) => {
    if (enteredPin.length < 4) {
      setEnteredPin((prev) => prev + digit);
    }
  };

  const handlePinSubmit = () => {
    if (!isInsideGeofence) {
      showNotice('Out of Range', 'PIN check-in requires being within the 50m academy perimeter.', 'error');
      return;
    }
    if (enteredPin === dailyPin) {
      completeCheckIn(`Daily PIN (#${dailyPin})`);
      setEnteredPin('');
    } else {
      showNotice(
        'Incorrect Daily PIN',
        `Entered #${enteredPin} does not match today's active club PIN (#${dailyPin}).`,
        'error'
      );
      setEnteredPin('');
    }
  };

  return (
    <div className="min-h-screen bg-[#07080c] text-white flex flex-col items-center justify-start py-4 px-3">
      {/* Top Bar Controls Above Phone Frame */}
      <div className="w-full max-w-[430px] mb-3 flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl bg-[#16181f] border border-[#2e3039]">
        <div className="flex items-center gap-2">
          <span className="material-symbols-outlined text-[#ff2a2a] text-[18px]">android</span>
          <span className="font-headline text-xs uppercase font-bold tracking-wider text-white">
            DCA Mobile APK Runtime
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              if (userRole === 'admin') {
                setUserRole('member');
                setActiveBottomTab('checkin');
              } else {
                setUserRole('admin');
                setActiveBottomTab('analytics');
              }
            }}
            className="px-2.5 py-1 rounded bg-[#24262e] hover:bg-[#32343e] text-[11px] font-headline uppercase font-semibold text-[#ff8a34] cursor-pointer"
          >
            {userRole === 'admin' ? 'Role: Admin' : userRole === 'member' ? 'Role: Member' : 'Login View'}
          </button>
          <button
            onClick={onOpenAPKStudio}
            className="px-2.5 py-1 rounded bg-[#ff2a2a] hover:bg-red-600 text-[11px] font-headline uppercase font-bold text-white cursor-pointer"
          >
            Export APK
          </button>
          <button
            onClick={onSwitchToDesktopPortal}
            className="px-2.5 py-1 rounded bg-[#24262e] hover:bg-[#32343e] text-[11px] font-headline uppercase font-semibold text-[#9ca3af] hover:text-white cursor-pointer"
          >
            Web HQ
          </button>
        </div>
      </div>

      {/* Mobile Device Viewport Shell */}
      <div className="w-full max-w-[430px] min-h-[820px] rounded-[34px] border-[5px] border-[#24262e] bg-[#111318] shadow-[0_24px_80px_rgba(0,0,0,0.85)] flex flex-col justify-between overflow-hidden relative">
        {/* Android Status Bar */}
        <div className="h-8 px-5 bg-[#0c0e13] flex items-center justify-between text-[11px] font-mono-num text-[#9ca3af] border-b border-[#2e3039]/50">
          <span>09:41 IST</span>
          <div className="flex items-center gap-2">
            <span className="text-[#10b981]">5G · GPS</span>
            <span>100%</span>
          </div>
        </div>

        {/* Top App Bar */}
        {userRole && (
          <header className="h-13 px-4 bg-[#1a1b21] border-b border-[#2e3039] flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-md bg-[#ff2a2a] flex items-center justify-center font-headline font-bold text-xs text-white">
                DCA
              </div>
              <span className="font-headline text-sm font-bold uppercase tracking-wider text-white">
                {activeBottomTab === 'checkin'
                  ? 'Biometric Check-In'
                  : activeBottomTab === 'analytics'
                  ? 'Admin Analytics & PIN'
                  : activeBottomTab === 'schedule'
                  ? 'Class & Mat Schedule'
                  : 'Member Combat Profile'}
              </span>
            </div>
            <button
              onClick={() => setUserRole(null)}
              className="text-[11px] font-headline uppercase text-[#9ca3af] hover:text-white cursor-pointer"
            >
              Switch Account
            </button>
          </header>
        )}

        {/* Toast / Alert Banner Inside Phone */}
        {bannerAlert && (
          <div
            className={`mx-4 mt-3 p-3 rounded-lg border text-xs flex items-start justify-between gap-2 ${
              bannerAlert.type === 'success'
                ? 'bg-[#10b981]/15 border-[#10b981] text-white'
                : bannerAlert.type === 'error'
                ? 'bg-[#ff2a2a]/15 border-[#ff2a2a] text-white'
                : 'bg-[#24262e] border-[#ff8a34] text-white'
            }`}
          >
            <div>
              <div className="font-bold">{bannerAlert.title}</div>
              <div className="text-[#9ca3af] mt-0.5">{bannerAlert.message}</div>
            </div>
            <button onClick={() => setBannerAlert(null)} className="text-[#9ca3af] hover:text-white">
              ✕
            </button>
          </div>
        )}

        {/* Screen Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* SCREEN 0: UNIFIED LOGIN SCREEN */}
          {!userRole && (
            <div className="py-6 flex flex-col justify-center space-y-5">
              <div className="text-center">
                <h1 className="font-headline text-2xl font-bold tracking-wider text-white uppercase">
                  DELHI COMBAT ACADEMY
                </h1>
                <p className="text-[11px] font-bold tracking-widest text-[#ff2a2a] mt-1 uppercase">
                  SINGLE ACCESS GATEWAY · MEMBERS &amp; STAFF
                </p>
              </div>

              {/* Role Toggle */}
              <div className="grid grid-cols-2 bg-[#1a1b21] p-1 rounded-lg border border-[#2e3039]">
                <button
                  onClick={() => setAuthTab('member')}
                  className={`py-2.5 rounded-md font-headline text-xs font-bold uppercase tracking-wider cursor-pointer transition-colors ${
                    authTab === 'member' ? 'bg-[#ff2a2a] text-white' : 'text-[#9ca3af]'
                  }`}
                >
                  Member Login
                </button>
                <button
                  onClick={() => setAuthTab('admin')}
                  className={`py-2.5 rounded-md font-headline text-xs font-bold uppercase tracking-wider cursor-pointer transition-colors ${
                    authTab === 'admin' ? 'bg-[#ff2a2a] text-white' : 'text-[#9ca3af]'
                  }`}
                >
                  Admin Portal
                </button>
              </div>

              {authTab === 'member' ? (
                <div className="bg-[#1a1b21] rounded-xl p-5 border border-[#2e3039] space-y-3.5">
                  <button
                    onClick={() => {
                      setUserRole('member');
                      setActiveBottomTab('checkin');
                    }}
                    className="w-full py-3 rounded-lg bg-white text-black font-bold text-xs uppercase tracking-wide cursor-pointer hover:bg-gray-100 transition-colors"
                  >
                    Continue with Google
                  </button>

                  <div className="flex items-center gap-2 py-1">
                    <div className="flex-1 h-px bg-[#2e3039]" />
                    <span className="text-[10px] font-bold text-[#6b7280] uppercase">
                      OR WHATSAPP / MOBILE OTP
                    </span>
                    <div className="flex-1 h-px bg-[#2e3039]" />
                  </div>

                  <div>
                    <label className="block text-xs text-[#9ca3af] font-semibold mb-1.5">
                      Registered Mobile Number
                    </label>
                    <input
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="e.g. 98765 43210"
                      className="w-full h-11 px-3.5 rounded-lg bg-[#24262e] border border-[#2e3039] text-white text-sm font-mono-num focus:outline-none focus:border-[#ff2a2a]"
                    />
                  </div>

                  {otpSent && (
                    <div>
                      <label className="block text-xs text-[#9ca3af] font-semibold mb-1.5">
                        Enter 6-Digit OTP
                      </label>
                      <input
                        type="text"
                        maxLength={6}
                        value={otpCode}
                        onChange={(e) => setOtpCode(e.target.value)}
                        placeholder="123456"
                        className="w-full h-11 px-3.5 rounded-lg bg-[#24262e] border border-[#2e3039] text-white text-sm font-mono-num focus:outline-none focus:border-[#ff2a2a]"
                      />
                    </div>
                  )}

                  <button
                    onClick={handleMemberLogin}
                    className="w-full py-3.5 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-sm font-bold uppercase tracking-wider cursor-pointer transition-colors"
                  >
                    {otpSent ? 'Verify OTP & Enter' : 'Send WhatsApp OTP'}
                  </button>

                  <p className="text-[11px] text-[#6b7280] text-center">
                    No password required. New members verify mobile on first entry.
                  </p>
                </div>
              ) : (
                <div className="bg-[#1a1b21] rounded-xl p-5 border border-[#2e3039] space-y-3.5">
                  <div>
                    <label className="block text-xs text-[#9ca3af] font-semibold mb-1.5">
                      Staff Email or Coach ID
                    </label>
                    <input
                      type="text"
                      value={staffId}
                      onChange={(e) => setStaffId(e.target.value)}
                      className="w-full h-11 px-3.5 rounded-lg bg-[#24262e] border border-[#2e3039] text-white text-sm focus:outline-none focus:border-[#ff2a2a]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#9ca3af] font-semibold mb-1.5">
                      Passkey / Password
                    </label>
                    <input
                      type="password"
                      value={staffPassword}
                      onChange={(e) => setStaffPassword(e.target.value)}
                      className="w-full h-11 px-3.5 rounded-lg bg-[#24262e] border border-[#2e3039] text-white text-sm focus:outline-none focus:border-[#ff2a2a]"
                    />
                  </div>
                  <button
                    onClick={handleAdminLogin}
                    className="w-full py-3.5 rounded-lg bg-[#ff2a2a] hover:bg-red-600 text-white font-headline text-sm font-bold uppercase tracking-wider cursor-pointer transition-colors"
                  >
                    Authenticate as Admin
                  </button>
                  <p className="text-[11px] text-[#6b7280] text-center">
                    Requires authorized role credentials (Head Coach / Front Desk / Billing).
                  </p>
                </div>
              )}

              <div className="text-center pt-2">
                <p className="text-xs text-[#9ca3af]">Need admission or help? Visit Front Desk / Mat Ops</p>
                <p className="text-[11px] text-[#6b7280] mt-0.5">HQ Connaught Place &amp; Rohini, New Delhi</p>
              </div>
            </div>
          )}

          {/* SCREEN 1: BIOMETRIC CHECK-IN + GEOFENCE + DAILY PIN */}
          {userRole && activeBottomTab === 'checkin' && (
            <>
              {/* Geofence Status Card */}
              <div
                className={`bg-[#1a1b21] rounded-xl p-4 border ${
                  isInsideGeofence ? 'border-[#3f424e]' : 'border-[#ff2a2a]'
                }`}
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-[#ff8a34]">
                    {isInsideGeofence
                      ? '● GPS VERIFIED: INSIDE PERIMETER'
                      : '○ GPS: OUTSIDE CLUB BOUNDARY'}
                  </span>
                  <span className="text-[#9ca3af] font-mono-num">Wi-Fi: DCA-MESH-HQ</span>
                </div>

                <h2 className="font-headline text-lg font-bold text-white mt-2">
                  Delhi Combat Academy HQ
                </h2>
                <p className="text-xs text-[#9ca3af] font-mono-num">
                  Connaught Place · 28.6315° N, 77.2167° E
                </p>

                <div className="grid grid-cols-2 gap-2.5 mt-3.5">
                  <div className="bg-[#24262e] p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-[#6b7280] uppercase">
                      Club Boundary
                    </div>
                    <div className="text-sm font-bold text-white mt-1 font-mono-num">
                      50m Radius
                    </div>
                    <div className="text-[11px] text-[#9ca3af] mt-0.5 font-mono-num">
                      Current: {distance}m from Ring
                    </div>
                  </div>
                  <div className="bg-[#24262e] p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-[#6b7280] uppercase">
                      Check-In Hardware
                    </div>
                    <div
                      className={`text-sm font-bold mt-1 ${
                        isInsideGeofence ? 'text-[#10b981]' : 'text-[#ff2a2a]'
                      }`}
                    >
                      {isInsideGeofence ? 'Biometrics Unlocked' : 'Hardware Locked'}
                    </div>
                    <div className="text-[11px] text-[#9ca3af] mt-0.5">
                      {isInsideGeofence ? 'Ready for scan' : 'Arrive at club to enable'}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 mt-3">
                  <button
                    onClick={() => {
                      const next = !isInsideGeofence;
                      setIsInsideGeofence(next);
                      setDistance(next ? 12 : 145);
                    }}
                    className="py-2 px-2.5 rounded-md bg-[#32343e] hover:bg-[#3f424e] text-[#ff8a34] text-[11px] font-bold cursor-pointer transition-colors"
                  >
                    {isInsideGeofence
                      ? 'Simulate: Step Outside (145m)'
                      : 'Simulate: Enter 50m Perimeter'}
                  </button>
                  <button
                    onClick={detectRealGeolocation}
                    className="py-2 px-2.5 rounded-md bg-[#24262e] hover:bg-[#32343e] text-[#9ca3af] hover:text-white text-[11px] font-semibold cursor-pointer transition-colors"
                  >
                    Ping Device GPS
                  </button>
                </div>
              </div>

              {/* 1-Tap Phone Biometric Attendance */}
              <div className="bg-[#1a1b21] rounded-xl p-4 border border-[#2e3039]">
                <h3 className="font-headline text-sm font-bold tracking-wider text-white uppercase">
                  1-Tap Phone Biometric Attendance
                </h3>
                <p className="text-xs text-[#9ca3af] mt-1 leading-relaxed">
                  Uses your phone&apos;s built-in Face ID, Fingerprint, or screen lock. No separate registration needed.
                </p>

                <button
                  onClick={handleNativeBiometricScan}
                  disabled={!isInsideGeofence || isScanningBiometric}
                  className={`w-full mt-4 py-4 rounded-xl bg-[#ff2a2a] hover:bg-red-600 text-white flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    !isInsideGeofence ? 'opacity-35 cursor-not-allowed' : ''
                  }`}
                >
                  <span className="material-symbols-outlined text-[34px]">
                    {isScanningBiometric ? 'sync' : 'fingerprint'}
                  </span>
                  <span className="font-headline text-xs font-bold uppercase tracking-wider">
                    {isScanningBiometric
                      ? 'Scanning Native Biometric Sensor...'
                      : 'Verify Attendance With Phone Biometric'}
                  </span>
                </button>
              </div>

              {/* Today's Daily Rotating PIN Backup */}
              <div className="bg-[#1a1b21] rounded-xl p-4 border border-[#2e3039]">
                <div className="flex items-center justify-between">
                  <h3 className="font-headline text-sm font-bold tracking-wider text-white uppercase">
                    Today&apos;s Daily Rotating PIN
                  </h3>
                  <span className="text-[10px] font-mono-num font-bold text-[#ff8a34] bg-[#24262e] px-2 py-0.5 rounded">
                    Valid till 23:59 IST · #{dailyPin}
                  </span>
                </div>
                <p className="text-xs text-[#9ca3af] mt-1">
                  If phone biometric fails, enter today&apos;s 4-digit code displayed at the reception desk.
                </p>

                {/* 4 PIN Dots */}
                <div className="flex items-center justify-center gap-3.5 my-4">
                  {[0, 1, 2, 3].map((idx) => (
                    <div
                      key={idx}
                      className={`w-3.5 h-3.5 rounded-full border ${
                        enteredPin.length > idx
                          ? 'bg-[#ff2a2a] border-[#ff2a2a]'
                          : 'bg-[#24262e] border-[#2e3039]'
                      }`}
                    />
                  ))}
                </div>

                {/* Numeric Keypad */}
                <div className="grid grid-cols-3 gap-2">
                  {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'CLEAR', '0', '⌫'].map((key) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => {
                        if (key === 'CLEAR') setEnteredPin('');
                        else if (key === '⌫') setEnteredPin((p) => p.slice(0, -1));
                        else handlePinPress(key);
                      }}
                      className="h-11 rounded-lg bg-[#24262e] hover:bg-[#32343e] text-white font-mono-num text-sm font-bold flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
                    >
                      {key}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  disabled={!isInsideGeofence || enteredPin.length !== 4}
                  onClick={handlePinSubmit}
                  className={`w-full mt-3.5 py-3.5 rounded-lg bg-[#32343e] hover:bg-[#ff2a2a] text-white font-headline text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                    !isInsideGeofence || enteredPin.length !== 4
                      ? 'opacity-35 cursor-not-allowed'
                      : ''
                  }`}
                >
                  Submit Today&apos;s Club PIN
                </button>
              </div>

              {/* Recent Verified Entries */}
              <div className="bg-[#1a1b21] rounded-xl p-4 border border-[#2e3039]">
                <div className="text-xs font-bold text-[#6b7280] uppercase mb-2.5">
                  Recent Verified Entries
                </div>
                <div className="divide-y divide-[#24262e]">
                  {checkInLogs.map((log) => (
                    <div key={log.id} className="py-2.5 flex items-center justify-between">
                      <div>
                        <div className="text-xs font-bold text-white">{log.title}</div>
                        <div className="text-[11px] text-[#9ca3af] mt-0.5">
                          {log.time} · {log.method}
                        </div>
                      </div>
                      <span className="text-[11px] font-mono-num font-bold text-[#10b981]">
                        LOGGED ✓
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* SCREEN 2: ADMIN ANALYTICS & DAILY ROTATING PIN MANAGER */}
          {userRole && activeBottomTab === 'analytics' && (
            <>
              <div>
                <div className="text-[11px] font-bold text-[#ff8a34] uppercase">
                  COACH VIKRAM (HEAD TRAINER) · MANAGER MODE
                </div>
                <h2 className="font-headline text-xl font-bold text-white uppercase mt-0.5">
                  Admin &amp; Facility Analytics
                </h2>
              </div>

              {/* Daily Rotating PIN Control Deck */}
              <div className="bg-[#1a1b21] rounded-xl p-4 border border-[#2e3039]">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#9ca3af] uppercase">
                    Today&apos;s Daily Rotating PIN
                  </span>
                  <span className="text-[10px] font-mono-num font-bold text-[#ff8a34] bg-[#24262e] px-2 py-0.5 rounded">
                    AUTO 00:00 IST
                  </span>
                </div>

                <div className="flex items-center justify-center gap-3 my-4">
                  {dailyPin.split('').map((digit, i) => (
                    <div
                      key={i}
                      className="w-12 h-14 rounded-lg bg-[#24262e] border border-[#ff2a2a] flex items-center justify-center font-mono-num text-2xl font-bold text-white"
                    >
                      {digit}
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between text-[11px] text-[#9ca3af]">
                  <span>Next rotation in: {timeRemaining}</span>
                  <span>Valid for all active members</span>
                </div>

                <div className="grid grid-cols-2 gap-2.5 mt-3.5">
                  <button
                    onClick={() =>
                      showNotice('Kiosk Synced', `PIN #${dailyPin} pushed to front-desk monitor.`, 'success')
                    }
                    className="py-2.5 rounded-lg bg-[#24262e] hover:bg-[#32343e] text-white text-xs font-bold cursor-pointer"
                  >
                    Push to Kiosk
                  </button>
                  <button
                    onClick={() => {
                      const nextPin = onRegeneratePin();
                      showNotice(
                        'Emergency Rotation',
                        `Today's Daily PIN regenerated to #${nextPin}. Synced with Member Check-In.`,
                        'info'
                      );
                    }}
                    className="py-2.5 rounded-lg bg-[#32343e] border border-[#ff2a2a] text-[#ff2a2a] hover:bg-[#ff2a2a] hover:text-white text-xs font-bold cursor-pointer transition-colors"
                  >
                    Regenerate Code
                  </button>
                </div>
              </div>

              {/* Operational KPIs */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#1a1b21] p-3.5 rounded-xl border border-[#2e3039]">
                  <div className="text-[10px] font-bold text-[#6b7280] uppercase">
                    Active Members
                  </div>
                  <div className="font-headline text-2xl font-bold text-white mt-1 tabular-nums">
                    1,284
                  </div>
                  <div className="text-[11px] text-[#10b981] font-semibold mt-1">+14% mo/mo</div>
                </div>
                <div className="bg-[#1a1b21] p-3.5 rounded-xl border border-[#2e3039]">
                  <div className="text-[10px] font-bold text-[#6b7280] uppercase">
                    Today&apos;s Entries
                  </div>
                  <div className="font-headline text-2xl font-bold text-white mt-1 tabular-nums">
                    142
                  </div>
                  <div className="text-[11px] text-[#10b981] font-semibold mt-1">
                    92% Biometric · 8% PIN
                  </div>
                </div>
              </div>

              {/* Live Mat & Cage Load */}
              <div className="bg-[#1a1b21] p-4 rounded-xl border border-[#2e3039]">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-[#9ca3af] uppercase">Live Mat &amp; Cage Load</span>
                  <span className="text-[#ff8a34] font-mono-num">68 / 120 (57%)</span>
                </div>
                <div className="w-full h-2 bg-[#24262e] rounded-full my-2.5 overflow-hidden">
                  <div className="h-full bg-[#ff2a2a]" style={{ width: '57%' }} />
                </div>
                <div className="flex items-center justify-between text-[11px] text-[#9ca3af]">
                  <span>Cage Area: 22 members</span>
                  <span>Open Mats: 46 members</span>
                </div>
              </div>

              {/* Bulk WhatsApp & SMS Reminders */}
              <button
                onClick={() =>
                  showNotice(
                    'Automated Dispatch',
                    '14 WhatsApp & SMS reminders dispatched to expiring members.',
                    'success'
                  )
                }
                className="w-full p-4 rounded-xl bg-[#ff2a2a] hover:bg-red-600 text-center cursor-pointer transition-colors"
              >
                <div className="font-headline text-xs font-bold text-white uppercase tracking-wider">
                  Send Bulk WhatsApp &amp; SMS Reminders
                </div>
                <div className="text-[11px] text-white/80 mt-0.5">
                  14 memberships expire in ≤ 7 days
                </div>
              </button>

              {/* Real-Time Turnstile Access Log */}
              <div className="bg-[#1a1b21] p-4 rounded-xl border border-[#2e3039]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#9ca3af] uppercase">
                    Live Turnstile Access Log
                  </span>
                  <span className="text-[10px] font-bold text-[#10b981]">● SYNCED</span>
                </div>
                <div className="divide-y divide-[#24262e]">
                  {[
                    { name: 'Aman Sharma', badge: 'MMA Batch A', time: '2m ago', gate: 'Face ID · Mat Gate 1' },
                    { name: 'Rohit Deshmukh', badge: 'Muay Thai', time: '5m ago', gate: `Daily PIN (#${dailyPin}) · Gate #2` },
                    { name: 'Tarun Gill', badge: 'Boxing', time: '14m ago', gate: 'Face ID · Ring South' },
                  ].map((entry, idx) => (
                    <div key={idx} className="py-2.5 flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white">{entry.name}</span>
                          <span className="text-[10px] font-semibold text-[#ff8a34]">
                            · {entry.badge}
                          </span>
                        </div>
                        <div className="text-[11px] text-[#9ca3af] mt-0.5">{entry.gate}</div>
                      </div>
                      <span className="text-[11px] font-mono-num text-[#6b7280]">{entry.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* SCREEN 3: SCHEDULE TAB */}
          {userRole && activeBottomTab === 'schedule' && (
            <div className="space-y-3">
              <div className="bg-[#1a1b21] p-4 rounded-xl border border-[#2e3039]">
                <h3 className="font-headline text-base font-bold text-white uppercase">
                  Today&apos;s Class &amp; Training Schedule
                </h3>
                <p className="text-xs text-[#9ca3af] mt-0.5">
                  Tap any session to pre-book your mat spot
                </p>
              </div>
              {classes.map((cls) => (
                <div
                  key={cls.id}
                  className="bg-[#1a1b21] p-4 rounded-xl border border-[#2e3039] flex items-center justify-between gap-3"
                >
                  <div>
                    <span className="text-xs font-mono-num font-bold text-[#ff2a2a]">
                      {cls.time} · {cls.zone}
                    </span>
                    <div className="font-headline text-sm font-bold text-white uppercase mt-0.5">
                      {cls.title}
                    </div>
                    <div className="text-xs text-[#9ca3af]">{cls.coach}</div>
                  </div>
                  <button
                    onClick={() =>
                      showNotice('Spot Reserved', `Reserved mat spot for ${cls.title}.`, 'success')
                    }
                    className="px-3 py-1.5 rounded-lg bg-[#24262e] hover:bg-[#ff2a2a] text-xs font-headline uppercase font-bold text-white cursor-pointer transition-colors shrink-0"
                  >
                    {cls.enrolled}/{cls.capacity}
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* SCREEN 4: MEMBER COMBAT PROFILE TAB */}
          {userRole && activeBottomTab === 'profile' && (
            <div className="space-y-3">
              <div className="bg-[#1a1b21] p-5 rounded-xl border border-[#2e3039] flex items-center gap-3.5">
                <div className="w-14 h-14 rounded-full bg-[#ff2a2a]/20 border border-[#ff2a2a] flex items-center justify-center font-headline text-xl font-bold text-[#ff2a2a]">
                  {fighters[0]?.initials || 'AS'}
                </div>
                <div>
                  <h3 className="font-headline text-lg font-bold text-white uppercase">
                    {fighters[0]?.name || 'Aman Sharma'}
                  </h3>
                  <p className="text-xs text-[#9ca3af] font-mono-num">
                    ID: {fighters[0]?.tagId || 'DCA-7840'} · {fighters[0]?.weightClass}
                  </p>
                  <p className="text-xs text-[#10b981] font-semibold mt-0.5">
                    Active Membership · Valid till {fighters[0]?.expiryDate || 'Nov 15'}
                  </p>
                </div>
              </div>

              <div className="bg-[#1a1b21] p-4 rounded-xl border border-[#2e3039] space-y-2.5 text-xs">
                <div className="flex justify-between py-1.5 border-b border-[#24262e]">
                  <span className="text-[#9ca3af]">Training Batch</span>
                  <span className="text-white font-semibold">{fighters[0]?.discipline}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#24262e]">
                  <span className="text-[#9ca3af]">Biometric Hardware Status</span>
                  <span className="text-[#10b981] font-semibold">Enrolled (Face ID + Touch)</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#24262e]">
                  <span className="text-[#9ca3af]">RFID Wristband Tag</span>
                  <span className="text-white font-mono-num">{fighters[0]?.rfid}</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-[#9ca3af]">Medical Sparring Clearance</span>
                  <span className="text-white font-semibold">{fighters[0]?.medicalClearance}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Navigation Bar inside Mobile Frame */}
        {userRole && (
          <nav className="h-16 bg-[#1a1b21] border-t border-[#2e3039] grid grid-cols-4 items-center shrink-0">
            <button
              onClick={() => setActiveBottomTab('schedule')}
              className={`h-full flex flex-col items-center justify-center cursor-pointer ${
                activeBottomTab === 'schedule' ? 'text-[#ff2a2a]' : 'text-[#6b7280]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">calendar_month</span>
              <span className="text-[10px] font-bold tracking-wider mt-0.5">SCHEDULE</span>
            </button>

            <button
              onClick={() => setActiveBottomTab('checkin')}
              className={`h-full flex flex-col items-center justify-center cursor-pointer ${
                activeBottomTab === 'checkin' ? 'text-[#ff2a2a]' : 'text-[#6b7280]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">fingerprint</span>
              <span className="text-[10px] font-bold tracking-wider mt-0.5">CHECK-IN</span>
            </button>

            <button
              onClick={() => setActiveBottomTab('profile')}
              className={`h-full flex flex-col items-center justify-center cursor-pointer ${
                activeBottomTab === 'profile' ? 'text-[#ff2a2a]' : 'text-[#6b7280]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">sports_mma</span>
              <span className="text-[10px] font-bold tracking-wider mt-0.5">PROFILE</span>
            </button>

            <button
              onClick={() => {
                setUserRole('admin');
                setActiveBottomTab('analytics');
              }}
              className={`h-full flex flex-col items-center justify-center cursor-pointer ${
                activeBottomTab === 'analytics' ? 'text-[#ff2a2a]' : 'text-[#6b7280]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">insights</span>
              <span className="text-[10px] font-bold tracking-wider mt-0.5">ANALYTICS</span>
            </button>
          </nav>
        )}
      </div>
    </div>
  );
};
