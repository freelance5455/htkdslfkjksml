"use client";

import React, { useState } from "react";
import {
  FileText,
  Calculator,
  Download,
  PlusCircle,
  CheckCircle,
  Landmark,
  Receipt,
} from "lucide-react";

export interface TaxInvoiceItem {
  id: number;
  invoiceNumber: string;
  clientOrExchange: string;
  descriptionHe: string;
  amountUsdt: number;
  usdIlsRate: number;
  amountIls: number;
  taxCategory: string;
  estimatedTaxIls: number;
  form909Status: string;
  txHash: string;
  createdAt: string;
}

interface InvoappTaxModuleProps {
  realizedPnlUsdt: number;
  unrealizedPnlUsdt: number;
  invoices: TaxInvoiceItem[];
  onCreateInvoice: (payload: {
    clientOrExchange: string;
    descriptionHe: string;
    amountUsdt: number;
    usdIlsRate: number;
    taxType: "capital_gains_25" | "business_income";
  }) => Promise<void>;
}

export function InvoappTaxModule({
  realizedPnlUsdt,
  unrealizedPnlUsdt,
  invoices,
  onCreateInvoice,
}: InvoappTaxModuleProps) {
  const [taxRegime, setTaxRegime] = useState<"capital_gains_25" | "business_income">(
    "capital_gains_25"
  );
  const [usdIlsRate, setUsdIlsRate] = useState<number>(3.72);
  const [clientOrExchange, setClientOrExchange] = useState<string>(
    "Bybit Linear Perpetuals - משיכת רווחי מסחר"
  );
  const [descriptionHe, setDescriptionHe] = useState<string>(
    "מימוש רווח הון מעסקאות חוזים עתידיים קריפטו (BTC/ETH/SOL)"
  );
  const [amountUsdt, setAmountUsdt] = useState<number>(850);
  const [submitting, setSubmitting] = useState<boolean>(false);

  const safeInvoices = Array.isArray(invoices) ? invoices : [];

  const totalInvoicedUsdt = safeInvoices.reduce(
    (acc, inv) => acc + (inv.amountUsdt || 0),
    0
  );
  const totalInvoicedIls = safeInvoices.reduce(
    (acc, inv) => acc + (inv.amountIls || 0),
    0
  );
  const totalEstimatedTaxIls = safeInvoices.reduce(
    (acc, inv) => acc + (inv.estimatedTaxIls || 0),
    0
  );

  const handleExportForm909Csv = () => {
    const headers = [
      "מספר אסמכתא",
      "זירת מסחר / לקוח",
      "תיאור אירוע מס",
      "סכום בדולר (USDT)",
      "שער יציג בנק ישראל (ILS)",
      "שווי בשקלים (₪)",
      "סיווג מס",
      "חבות מס משוערת (₪)",
      "סטטוס טופס 909",
    ];
    const rows = safeInvoices.map((inv) => [
      inv.invoiceNumber,
      `"${inv.clientOrExchange}"`,
      `"${inv.descriptionHe}"`,
      inv.amountUsdt,
      inv.usdIlsRate,
      inv.amountIls,
      `"${inv.taxCategory}"`,
      inv.estimatedTaxIls,
      `"${inv.form909Status}"`,
    ]);
    const csvContent =
      "\uFEFF" +
      [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Israeli_Tax_Form_909_Invoapp_${new Date()
      .toISOString()
      .slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div dir="rtl" className="space-y-6">
      {/* Top Israeli Tax Authority & Invoapp Summary Banner */}
      <div className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Landmark className="h-6 w-6 text-[#00E676]" />
              <h2 className="text-xl font-bold text-[#F1F5F9]">
                מרכז פיננסים, חשבוניות קריפטו (Invoapp) ודיווח מס ישראלי (טופס 909)
              </h2>
            </div>
            <p className="mt-1 text-sm text-[#94A3B8]">
              ניהול ספר רווח והפסד שקלי/דולרי, חישוב מס רווחי הון ריאלי (25%) מול
              הכנסה עסקית (פירותית), והפקת דוח מותאם לרשות המסים בישראל.
            </p>
          </div>

          <button
            type="button"
            onClick={handleExportForm909Csv}
            className="inline-flex items-center gap-2 rounded-lg bg-[#3B82F6] px-4 py-2.5 text-xs font-bold text-white transition hover:bg-[#2563EB]"
          >
            <Download className="h-4 w-4" />
            <span>ייצוא דוח טופס 909 לרואה חשבון (CSV)</span>
          </button>
        </div>

        {/* 4 Financial & Tax KPIs */}
        <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-4">
            <span className="text-xs text-[#94A3B8]">
              רווח ממומש בתיק הדמו + שכפול
            </span>
            <div className="mt-1 font-mono text-2xl font-extrabold text-[#00E676]">
              +${realizedPnlUsdt.toFixed(2)}{" "}
              <span className="text-sm text-[#94A3B8]">
                (₪{(realizedPnlUsdt * usdIlsRate).toFixed(0)})
              </span>
            </div>
            <span className="text-[11px] text-[#64748B]">
              רווח לא ממומש פתוח: ${unrealizedPnlUsdt.toFixed(2)}
            </span>
          </div>

          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-4">
            <span className="text-xs text-[#94A3B8]">
              סה״כ אירועי מס מתועדים (Invoapp)
            </span>
            <div className="mt-1 font-mono text-2xl font-extrabold text-[#F1F5F9]">
              ₪{totalInvoicedIls.toLocaleString()}
            </div>
            <span className="font-mono text-[11px] text-[#3B82F6]">
              ${totalInvoicedUsdt.toLocaleString()} USDT (שער יציג ₪{usdIlsRate})
            </span>
          </div>

          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-4">
            <span className="text-xs text-[#94A3B8]">
              אומדן חבות מס לתשלום (רשות המסים)
            </span>
            <div className="mt-1 font-mono text-2xl font-extrabold text-[#F59E0B]">
              ₪{totalEstimatedTaxIls.toLocaleString()}
            </div>
            <span className="text-[11px] text-[#94A3B8]">
              לפי סיווג {taxRegime === "capital_gains_25" ? "רווח הון 25%" : "עסקי 47%"}
            </span>
          </div>

          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-4">
            <span className="text-xs text-[#94A3B8]">תאימות חוזר מס הכנסה 05/2018</span>
            <div className="mt-1 flex items-center gap-1.5 text-lg font-extrabold text-[#00E676]">
              <CheckCircle className="h-5 w-5" />
              <span>מוכן לטופס 1301 + נספח 909</span>
            </div>
            <span className="text-[11px] text-[#64748B]">
              תיעוד FIFO ושערי המרה יומיים
            </span>
          </div>
        </div>
      </div>

      {/* Main Split: Invoapp Invoice Generator (5 cols) + Tax Ledger Table (7 cols) */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
        {/* Invoapp Crypto Invoice & Tax Simulator Form */}
        <div className="lg:col-span-5 rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
          <div className="mb-4 flex items-center gap-2 border-b border-[#222B3A] pb-3">
            <Receipt className="h-5 w-5 text-[#3B82F6]" />
            <h3 className="text-base font-bold text-[#F1F5F9]">
              הפקת חשבונית מס / תיעוד אירוע מס קריפטו (Invoapp)
            </h3>
          </div>

          <div className="space-y-3.5">
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#94A3B8]">
                סיווג מיסוי לפי פקודת מס הכנסה (ישראל):
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setTaxRegime("capital_gains_25")}
                  className={`rounded-lg border p-2.5 text-right text-xs font-bold transition ${
                    taxRegime === "capital_gains_25"
                      ? "border-[#00E676] bg-[#00E676]/15 text-[#00E676]"
                      : "border-[#222B3A] bg-[#0B0E14] text-[#94A3B8]"
                  }`}
                >
                  מס רווחי הון ריאלי (25%)
                  <span className="block text-[10px] font-normal opacity-80">
                    סעיף 88 – משקיע יחיד
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => setTaxRegime("business_income")}
                  className={`rounded-lg border p-2.5 text-right text-xs font-bold transition ${
                    taxRegime === "business_income"
                      ? "border-[#F59E0B] bg-[#F59E0B]/15 text-[#F59E0B]"
                      : "border-[#222B3A] bg-[#0B0E14] text-[#94A3B8]"
                  }`}
                >
                  הכנסה עסקית / פירותית (47%)
                  <span className="block text-[10px] font-normal opacity-80">
                    סעיף 2(1) – מסחר תדיר/עסקי
                  </span>
                </button>
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs text-[#94A3B8]">
                זירת מסחר / לקוח משלם:
              </label>
              <input
                type="text"
                value={clientOrExchange}
                onChange={(e) => setClientOrExchange(e.target.value)}
                className="w-full rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-2 text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-1 block text-xs text-[#94A3B8]">
                פירוט העסקה / אירוע המימוש (עבור טופס 909):
              </label>
              <input
                type="text"
                value={descriptionHe}
                onChange={(e) => setDescriptionHe(e.target.value)}
                className="w-full rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-2 text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-xs text-[#94A3B8]">
                  סכום רווח בדולר ($ USDT):
                </label>
                <input
                  type="number"
                  min={10}
                  value={amountUsdt}
                  onChange={(e) => setAmountUsdt(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-2 font-mono text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#94A3B8]">
                  שער יציג USD/ILS (בנק ישראל):
                </label>
                <input
                  type="number"
                  step={0.01}
                  value={usdIlsRate}
                  onChange={(e) => setUsdIlsRate(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-2 font-mono text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
                />
              </div>
            </div>

            {/* Live Calculation Preview Box */}
            <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3 text-xs">
              <div className="flex justify-between py-1">
                <span className="text-[#94A3B8]">שווי שקלי ברוטו:</span>
                <span className="font-mono font-bold text-[#F1F5F9]">
                  ₪{(amountUsdt * usdIlsRate).toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#94A3B8]">
                  חבות מס משוערת ({taxRegime === "capital_gains_25" ? "25%" : "47%"}):
                </span>
                <span className="font-mono font-bold text-[#F59E0B]">
                  ₪
                  {(
                    amountUsdt *
                    usdIlsRate *
                    (taxRegime === "capital_gains_25" ? 0.25 : 0.47)
                  ).toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between border-t border-[#222B3A] pt-1.5 font-bold">
                <span className="text-[#00E676]">רווח נטו לאחר מס:</span>
                <span className="font-mono text-[#00E676]">
                  ₪
                  {(
                    amountUsdt *
                    usdIlsRate *
                    (taxRegime === "capital_gains_25" ? 0.75 : 0.53)
                  ).toFixed(2)}
                </span>
              </div>
            </div>

            <button
              type="button"
              disabled={submitting}
              onClick={async () => {
                setSubmitting(true);
                await onCreateInvoice({
                  clientOrExchange,
                  descriptionHe,
                  amountUsdt,
                  usdIlsRate,
                  taxType: taxRegime,
                });
                setSubmitting(false);
              }}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#00E676] py-2.5 text-xs font-extrabold text-[#0B0E14] transition hover:brightness-110"
            >
              <PlusCircle className="h-4 w-4" />
              <span>הפק חשבונית ורשום בספר טופס 909</span>
            </button>
          </div>
        </div>

        {/* Right Column: Persisted Tax & Invoapp Ledger Table */}
        <div className="lg:col-span-7 rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
          <div className="mb-4 flex items-center justify-between border-b border-[#222B3A] pb-3">
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-[#00E676]" />
              <h3 className="text-base font-bold text-[#F1F5F9]">
                יומן חשבוניות ואירועי מס קריפטו (טופס 909 רשות המסים)
              </h3>
            </div>
            <span className="font-mono text-xs text-[#94A3B8]">
              {safeInvoices.length} רשומות מאומתות
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-[#222B3A] text-[#64748B]">
                  <th className="py-2 pr-2">מס&apos; אסמכתא</th>
                  <th className="py-2">מקור / תיאור</th>
                  <th className="py-2">סכום ($ USDT)</th>
                  <th className="py-2">שווי בש״ח (₪)</th>
                  <th className="py-2">אומדן מס (₪)</th>
                  <th className="py-2">סטטוס טופס 909</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#222B3A]/60">
                {safeInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-[#181F2C]/60">
                    <td className="py-3 pr-2 font-mono font-bold text-[#3B82F6]">
                      {inv.invoiceNumber}
                      <span className="block text-[10px] text-[#64748B]">
                        {inv.txHash}
                      </span>
                    </td>
                    <td className="py-3">
                      <strong className="block text-[#F1F5F9]">
                        {inv.clientOrExchange}
                      </strong>
                      <span className="text-[11px] text-[#94A3B8]">
                        {inv.descriptionHe}
                      </span>
                    </td>
                    <td className="py-3 font-mono font-bold text-[#00E676]">
                      ${inv.amountUsdt.toLocaleString()}
                    </td>
                    <td className="py-3 font-mono font-bold text-[#F1F5F9]">
                      ₪{inv.amountIls.toLocaleString()}
                    </td>
                    <td className="py-3 font-mono font-bold text-[#F59E0B]">
                      ₪{inv.estimatedTaxIls.toLocaleString()}
                      <span className="block font-sans text-[10px] font-normal text-[#94A3B8]">
                        {inv.taxCategory}
                      </span>
                    </td>
                    <td className="py-3">
                      <span className="inline-flex items-center gap-1 rounded-full bg-[#00E676]/15 px-2.5 py-0.5 text-[10px] font-bold text-[#00E676]">
                        <Calculator className="h-3 w-3" />
                        {inv.form909Status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
