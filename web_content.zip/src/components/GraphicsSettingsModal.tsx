import React, { useState } from 'react';
import {
  X,
  Save,
  RotateCcw,
  Sparkles,
  Sliders,
  MonitorSmartphone,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { AudioSettings, GraphicsPreset, GraphicsSettings, QualityLevel } from '../game/types';
import { getPresetGraphicsSettings } from '../game/storage/saveSystem';

interface GraphicsSettingsModalProps {
  open: boolean;
  settings: GraphicsSettings;
  audioSettings: AudioSettings;
  seed: number;
  playTimeSeconds: number;
  onClose: () => void;
  onChangeSettings: (next: GraphicsSettings) => void;
  onChangeAudioSettings: (next: AudioSettings) => void;
  onSaveNow: () => void;
  onReloadSave: () => void;
  onNewWorld: (customSeed?: number) => void;
}

export const GraphicsSettingsModal: React.FC<GraphicsSettingsModalProps> = ({
  open,
  settings,
  audioSettings,
  seed,
  playTimeSeconds,
  onClose,
  onChangeSettings,
  onChangeAudioSettings,
  onSaveNow,
  onReloadSave,
  onNewWorld,
}) => {
  const [seedInput, setSeedInput] = useState(String(seed));

  if (!open) return null;

  const applyPreset = (preset: GraphicsPreset) => {
    onChangeSettings(getPresetGraphicsSettings(preset));
  };

  const updateField = <K extends keyof GraphicsSettings>(key: K, value: GraphicsSettings[K]) => {
    onChangeSettings({
      ...settings,
      [key]: value,
    });
  };

  const updateAudioField = <K extends keyof AudioSettings>(key: K, value: AudioSettings[K]) => {
    onChangeAudioSettings({
      ...audioSettings,
      [key]: value,
    });
  };

  const formatTime = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${mins}د ${s}ث`;
  };

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-3 sm:p-6"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="hud-scroll max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-2xl border border-amber-500/35 bg-slate-900 text-slate-100 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4">
          <div className="flex items-center gap-2.5">
            <Sliders className="h-5 w-5 text-amber-400" />
            <h2 className="text-lg font-bold text-amber-100">إعدادات الرسومات والعالم</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-slate-700 bg-slate-800 p-2 text-slate-300 hover:bg-slate-700 hover:text-white"
            aria-label="إغلاق"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-5 p-5">
          {/* Graphics Presets */}
          <section className="space-y-2.5">
            <div className="flex items-center gap-2 text-sm font-semibold text-amber-300">
              <MonitorSmartphone className="h-4 w-4" />
              <span>مستوى جودة الرسومات (Presets)</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {([
                { id: 'low', label: 'منخفضة (Low)', desc: 'للهواتف الضعيفة' },
                { id: 'medium', label: 'متوسطة (Med)', desc: 'توازن مثالي' },
                { id: 'high', label: 'عالية (High)', desc: 'أقصى تفاصيل' },
              ] as const).map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => applyPreset(p.id)}
                  className={`rounded-xl border px-3 py-2.5 text-right transition ${
                    settings.preset === p.id
                      ? 'border-amber-400 bg-amber-500/20 text-amber-100'
                      : 'border-slate-700 bg-slate-800/70 text-slate-300 hover:border-slate-600'
                  }`}
                >
                  <div className="text-xs font-bold">{p.label}</div>
                  <div className="mt-0.5 text-[11px] text-slate-400">{p.desc}</div>
                </button>
              ))}
            </div>
          </section>

          {/* Detailed Graphics Options */}
          <section className="grid grid-cols-1 gap-3 rounded-xl border border-slate-800 bg-slate-950/60 p-4 sm:grid-cols-2">
            {/* Texture Quality */}
            <label className="flex flex-col gap-1 text-xs">
              <span className="text-slate-300">جودة الخامات</span>
              <select
                value={settings.textureQuality}
                onChange={(e) => updateField('textureQuality', e.target.value as QualityLevel)}
                className="rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-2 text-slate-100"
              >
                <option value="low">منخفضة</option>
                <option value="medium">متوسطة</option>
                <option value="high">عالية</option>
              </select>
            </label>

            {/* Shadow Quality */}
            <label className="flex flex-col gap-1 text-xs">
              <span className="text-slate-300">جودة الظلال</span>
              <select
                value={settings.shadowQuality}
                onChange={(e) =>
                  updateField('shadowQuality', e.target.value as GraphicsSettings['shadowQuality'])
                }
                className="rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-2 text-slate-100"
              >
                <option value="off">مغلقة (أسرع أداء)</option>
                <option value="low">منخفضة (512px)</option>
                <option value="medium">متوسطة (1024px)</option>
                <option value="high">عالية (2048px)</option>
              </select>
            </label>

            {/* View Distance (Camera + Fog Horizon) */}
            <label className="flex flex-col gap-1 text-xs">
              <span className="text-slate-300">نطاق الرؤية: {settings.viewDistanceMeters} متر</span>
              <input
                type="range"
                min={45}
                max={120}
                step={5}
                value={settings.viewDistanceMeters}
                onChange={(e) => updateField('viewDistanceMeters', Number(e.target.value))}
                className="accent-amber-400"
              />
            </label>

            {/* Draw Distance */}
            <label className="flex flex-col gap-1 text-xs">
              <span className="text-slate-300">مسافة تحميل المناطق: {settings.drawDistance} Chunks</span>
              <input
                type="range"
                min={2}
                max={4}
                step={1}
                value={settings.drawDistance}
                onChange={(e) => updateField('drawDistance', Number(e.target.value))}
                className="accent-amber-400"
              />
            </label>

            {/* Foliage Density */}
            <label className="flex flex-col gap-1 text-xs">
              <span className="text-slate-300">
                كثافة العشب والنباتات: {Math.round(settings.foliageDensity * 100)}%
              </span>
              <input
                type="range"
                min={0.25}
                max={1.0}
                step={0.15}
                value={settings.foliageDensity}
                onChange={(e) => updateField('foliageDensity', Number(e.target.value))}
                className="accent-amber-400"
              />
            </label>

            {/* Render Resolution */}
            <label className="flex flex-col gap-1 text-xs">
              <span className="text-slate-300">
                دقة العرض (Render Scale): {Math.round(settings.renderScale * 100)}%
              </span>
              <input
                type="range"
                min={0.6}
                max={1.25}
                step={0.05}
                value={settings.renderScale}
                onChange={(e) => updateField('renderScale', Number(e.target.value))}
                className="accent-amber-400"
              />
            </label>

            {/* Max FPS */}
            <label className="flex flex-col gap-1 text-xs sm:col-span-2">
              <span className="text-slate-300">الحد الأقصى لمعدل الإطارات</span>
              <select
                value={settings.maxFps}
                onChange={(e) => updateField('maxFps', Number(e.target.value) as 30 | 60)}
                className="rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-2 text-slate-100"
              >
                <option value={30}>30 FPS (توفير البطارية)</option>
                <option value={60}>60 FPS (أقصى سلاسة)</option>
              </select>
            </label>
          </section>

          {/* Audio Settings */}
          <section className="space-y-3 rounded-xl border border-slate-800 bg-slate-950/60 p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-semibold text-amber-300">
                {audioSettings.muted ? (
                  <VolumeX className="h-4 w-4 text-rose-400" />
                ) : (
                  <Volume2 className="h-4 w-4 text-emerald-400" />
                )}
                <span>إعدادات الصوت والموسيقى</span>
              </div>
              <button
                type="button"
                onClick={() => updateAudioField('muted', !audioSettings.muted)}
                className={`rounded-lg border px-2.5 py-1 text-xs font-bold ${
                  audioSettings.muted
                    ? 'border-rose-500/50 bg-rose-500/20 text-rose-200'
                    : 'border-emerald-500/40 bg-emerald-500/15 text-emerald-200'
                }`}
              >
                {audioSettings.muted ? 'مكتوم (تشغيل)' : 'الصوت مفعّل (كتم)'}
              </button>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <label className="flex flex-col gap-1 text-xs">
                <span className="text-slate-300">
                  الصوت العام: {Math.round(audioSettings.masterVolume * 100)}%
                </span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={audioSettings.masterVolume}
                  onChange={(e) => updateAudioField('masterVolume', Number(e.target.value))}
                  className="accent-amber-400"
                />
              </label>
              <label className="flex flex-col gap-1 text-xs">
                <span className="text-slate-300">
                  الموسيقى التفاعلية: {Math.round(audioSettings.musicVolume * 100)}%
                </span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={audioSettings.musicVolume}
                  onChange={(e) => updateAudioField('musicVolume', Number(e.target.value))}
                  className="accent-amber-400"
                />
              </label>
              <label className="flex flex-col gap-1 text-xs">
                <span className="text-slate-300">
                  المؤثرات القتالية والخطوات: {Math.round(audioSettings.sfxVolume * 100)}%
                </span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={audioSettings.sfxVolume}
                  onChange={(e) => updateAudioField('sfxVolume', Number(e.target.value))}
                  className="accent-amber-400"
                />
              </label>
              <label className="flex flex-col gap-1 text-xs">
                <span className="text-slate-300">
                  الأصوات البيئية والطقس: {Math.round(audioSettings.ambientVolume * 100)}%
                </span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={audioSettings.ambientVolume}
                  onChange={(e) => updateAudioField('ambientVolume', Number(e.target.value))}
                  className="accent-amber-400"
                />
              </label>
              <label className="flex flex-col gap-1 text-xs sm:col-span-2">
                <span className="text-slate-300">
                  أصوات الوحوش والهياكل العظمية: {Math.round((audioSettings.monsterVolume ?? 0.8) * 100)}%
                </span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={audioSettings.monsterVolume ?? 0.8}
                  onChange={(e) => updateAudioField('monsterVolume', Number(e.target.value))}
                  className="accent-amber-400"
                />
              </label>
            </div>
          </section>

          {/* World Save & Seed */}
          <section className="space-y-3 rounded-xl border border-slate-800 bg-slate-950/60 p-4">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span>بذرة العالم الحالية (Seed): <strong className="text-amber-300">{seed}</strong></span>
              <span>وقت اللعب: <strong className="text-emerald-300">{formatTime(playTimeSeconds)}</strong></span>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={onSaveNow}
                className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-500"
              >
                <Save className="h-3.5 w-3.5" />
                حفظ التقدم الآن
              </button>
              <button
                type="button"
                onClick={onReloadSave}
                className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                تحميل آخر حفظ
              </button>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="number"
                value={seedInput}
                onChange={(e) => setSeedInput(e.target.value)}
                placeholder="بذرة جديدة..."
                className="w-36 rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1.5 text-xs text-slate-100"
              />
              <button
                type="button"
                onClick={() => {
                  const parsed = parseInt(seedInput, 10);
                  onNewWorld(Number.isFinite(parsed) && parsed > 0 ? parsed : undefined);
                }}
                className="flex items-center gap-1.5 rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-amber-500"
              >
                <Sparkles className="h-3.5 w-3.5" />
                عالم جديد بهذه البذرة
              </button>
              <button
                type="button"
                onClick={() => {
                  const rnd = Math.floor(100000 + Math.random() * 900000);
                  setSeedInput(String(rnd));
                  onNewWorld(rnd);
                }}
                className="rounded-lg border border-amber-500/40 bg-amber-500/10 px-2.5 py-1.5 text-xs text-amber-200 hover:bg-amber-500/20"
              >
                عشوائي
              </button>
            </div>
          </section>

          {/* Controls Guide */}
          <section className="rounded-xl border border-slate-800 bg-slate-950/60 p-3.5 text-xs text-slate-300">
            <div className="mb-1.5 font-bold text-amber-300">عناصر التحكم</div>
            <div className="grid grid-cols-1 gap-1 sm:grid-cols-2">
              <div>• الهاتف: الجويستيك الأيسر للحركة، اسحب الشاشة للكاميرا</div>
              <div>• الحاسوب: WASD للحركة، Space للقفز، Shift للركض</div>
              <div>• القتال والصد: E/J للهجوم، K أو كليك يمين للصد بالدرع</div>
              <div>• الكاميرا والاندفاع: V للمنظور، Q للاندفاع، R للتفاعل</div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
