import { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import {
  signInWithGoogle,
  logOutGoogle,
  getAccessToken,
  initAuth
} from '../services/authService';
import {
  listDriveBackups,
  saveBackupToDrive,
  fetchBackupContent,
  exportTextReportToDrive,
  DriveFileItem
} from '../services/driveService';
import { Student, Lesson, PaymentRecord, NoteEntry } from '../types';
import {
  Cloud,
  CheckCircle2,
  AlertCircle,
  UploadCloud,
  RefreshCw,
  LogOut,
  X,
  FileText,
  ShieldCheck
} from 'lucide-react';

interface GoogleDriveSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  lessons: Lesson[];
  payments: PaymentRecord[];
  notes: NoteEntry[];
  onRestoreData: (data: {
    students: Student[];
    lessons: Lesson[];
    payments: PaymentRecord[];
    notes: NoteEntry[];
  }) => void;
}

export const GoogleDriveSyncModal = ({
  isOpen,
  onClose,
  students,
  lessons,
  payments,
  notes,
  onRestoreData,
}: GoogleDriveSyncModalProps) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [driveBackups, setDriveBackups] = useState<DriveFileItem[]>([]);
  const [isListing, setIsListing] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    const unsubscribe = initAuth(
      (user, accessToken) => {
        setCurrentUser(user);
        setToken(accessToken || null);
        if (accessToken) {
          loadDriveFiles(accessToken);
        }
      },
      () => {
        setCurrentUser(null);
        setToken(null);
      }
    );

    return () => unsubscribe();
  }, [isOpen]);

  const loadDriveFiles = async (accessToken: string) => {
    setIsListing(true);
    setErrorMsg(null);
    try {
      const files = await listDriveBackups(accessToken);
      setDriveBackups(files);
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Drive dosyaları getirilirken sorun oluştu: ' + (err.message || 'Hata'));
    } finally {
      setIsListing(false);
    }
  };

  const handleSignIn = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await signInWithGoogle();
      setCurrentUser(res.user);
      setToken(res.accessToken);
      await loadDriveFiles(res.accessToken);
    } catch (err: any) {
      setErrorMsg('Google ile oturum açılamadı: ' + (err.message || ''));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    await logOutGoogle();
    setCurrentUser(null);
    setToken(null);
    setDriveBackups([]);
  };

  const handleBackupNow = async () => {
    const confirmed = window.confirm(
      "Zeynep'in Günlüğü mevcut tüm öğrenci, ders ve cüzdan kayıtlarını Google Drive hesabınıza yedeklemek istiyor musunuz?"
    );
    if (!confirmed) return;

    const currentToken = token || (await getAccessToken());
    if (!currentToken) {
      setErrorMsg('Lütfen önce Google hesabınızla giriş yapın.');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const payload = {
        exportedAt: new Date().toISOString(),
        appName: "Zeynep'in Günlüğü",
        version: '1.0.0',
        students,
        lessons,
        payments,
        notes,
      };

      const result = await saveBackupToDrive(currentToken, payload);
      setSuccessMsg(`Yedekleme Google Drive'a başarıyla kaydedildi: ${result.name}`);
      await loadDriveFiles(currentToken);
    } catch (err: any) {
      setErrorMsg('Yedekleme başarısız: ' + (err.message || ''));
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportTextSummary = async () => {
    const currentToken = token || (await getAccessToken());
    if (!currentToken) {
      setErrorMsg('Lütfen önce Google hesabınızla giriş yapın.');
      return;
    }

    const confirmed = window.confirm(
      "Öğrenci listesi ve kazanç dökümünü Google Drive'a metin raporu olarak kaydetmek istiyor musunuz?"
    );
    if (!confirmed) return;

    setIsLoading(true);
    try {
      const report = `=========================================
ZEYNEP'İN GÜNLÜĞÜ - DERS & CÜZDAN RAPORU
Tarih: ${new Date().toLocaleString('tr-TR')}
=========================================

1. KAYITLI ÖĞRENCİLER (${students.length}):
${students
  .map(
    (s) =>
      `- ${s.name} | ${s.subject.toUpperCase()} | ${s.hourlyRate} ${s.currency}/ders | Döngü: ${s.lessonsInCurrentCycle}/${s.paymentFrequency} ders`
  )
  .join('\n')}

2. CÜZDAN TAHSİLATLARI:
- Toplam TL: ${payments.filter((p) => p.currency === 'TL').reduce((a, b) => a + b.amount, 0)} ₺
- Toplam USD: $${payments.filter((p) => p.currency === 'USD').reduce((a, b) => a + b.amount, 0)}

Son 5 Tahsilat:
${payments
  .slice(-5)
  .map((p) => `- ${p.date.slice(0, 10)}: ${p.studentName} (+${p.amount} ${p.currency}) - ${p.cycleDescription}`)
  .join('\n')}
`;

      const result = await exportTextReportToDrive(
        currentToken,
        report,
        `Zeynep_Gunlugu_Ozet_Rapor_${new Date().toISOString().slice(0, 10)}.txt`
      );
      setSuccessMsg(`Rapor Google Drive'a kaydedildi: ${result.name}`);
      await loadDriveFiles(currentToken);
    } catch (err: any) {
      setErrorMsg('Rapor yüklenemedi: ' + (err.message || ''));
    } finally {
      setIsLoading(false);
    }
  };

  const handleRestoreFile = async (file: DriveFileItem) => {
    const confirmed = window.confirm(
      `'${file.name}' dosyasındaki verileri geri yüklemek istediğinize emin misiniz? Mevcut uygulama verileriniz bu dosya içeriği ile güncellenecektir.`
    );
    if (!confirmed) return;

    const currentToken = token || (await getAccessToken());
    if (!currentToken) return;

    setIsLoading(true);
    try {
      const data = await fetchBackupContent(currentToken, file.id);
      if (data && data.students && data.lessons) {
        onRestoreData({
          students: data.students || [],
          lessons: data.lessons || [],
          payments: data.payments || [],
          notes: data.notes || [],
        });
        setSuccessMsg(`'${file.name}' başarıyla geri yüklendi!`);
        setTimeout(() => onClose(), 1500);
      } else {
        setErrorMsg('Dosya formatı geçerli bir Zeynep Günlüğü yedeği değil.');
      }
    } catch (err: any) {
      setErrorMsg('Geri yükleme başarısız oldu: ' + (err.message || ''));
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-[#121214] text-stone-100 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-zinc-800 relative overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-zinc-900 border border-zinc-800 text-amber-400">
              <Cloud className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg font-serif text-white">
                Google Drive Senkronizasyonu
              </h3>
              <p className="text-xs text-stone-400">
                Verilerinizi güvenle Google Drive hesabınızda saklayın
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-white bg-zinc-900 rounded-xl transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="py-4 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{successMsg}</span>
            </div>
          )}

          {!currentUser ? (
            <div className="text-center py-6 px-4 bg-zinc-900 rounded-2xl border border-zinc-800">
              <ShieldCheck className="w-10 h-10 text-stone-400 mx-auto mb-3" />
              <h4 className="font-bold text-white text-sm mb-1">
                Google Drive'a Bağlanın
              </h4>
              <p className="text-xs text-stone-400 max-w-sm mx-auto mb-5 leading-relaxed">
                Ders kayıtlarınız, öğrenci notlarınız ve cüzdan tahsilatlarınız izniniz dahilinde Google Drive'ınıza yedeklensin.
              </p>

              <button
                type="button"
                onClick={handleSignIn}
                disabled={isLoading}
                className="inline-flex items-center justify-center gap-3 px-5 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-xs rounded-xl border border-zinc-700 shadow-lg transition-all cursor-pointer active:scale-95 disabled:opacity-50"
              >
                <svg className="w-4 h-4" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                </svg>
                <span>{isLoading ? 'Giriş Yapılıyor...' : 'Google ile Giriş Yap'}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                <div className="flex items-center gap-2.5">
                  {currentUser.photoURL ? (
                    <img
                      src={currentUser.photoURL}
                      alt={currentUser.displayName || ''}
                      className="w-8 h-8 rounded-full border border-zinc-700"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-rose-950 text-rose-300 font-bold flex items-center justify-center text-xs border border-rose-800">
                      {currentUser.displayName?.charAt(0) || 'Z'}
                    </div>
                  )}
                  <div>
                    <div className="text-xs font-bold text-white">
                      {currentUser.displayName || 'Google Kullanıcısı'}
                    </div>
                    <div className="text-[11px] text-stone-400">
                      {currentUser.email}
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleSignOut}
                  className="p-1.5 text-stone-400 hover:text-white rounded-lg transition-all cursor-pointer"
                  title="Çıkış Yap"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={handleBackupNow}
                  disabled={isLoading}
                  className="flex items-center justify-center gap-2 px-3 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer active:scale-95 disabled:opacity-50 border border-zinc-700"
                >
                  <UploadCloud className="w-4 h-4 text-amber-400" />
                  <span>Şimdi Yedekle</span>
                </button>

                <button
                  type="button"
                  onClick={handleExportTextSummary}
                  disabled={isLoading}
                  className="flex items-center justify-center gap-2 px-3 py-2.5 bg-zinc-900 hover:bg-zinc-850 text-stone-200 rounded-xl text-xs font-semibold transition-all cursor-pointer active:scale-95 disabled:opacity-50 border border-zinc-800"
                >
                  <FileText className="w-4 h-4 text-rose-400" />
                  <span>Drive Raporu Yaz</span>
                </button>
              </div>

              <div className="pt-2">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">
                    Drive'daki Yedekler ({driveBackups.length})
                  </span>
                  <button
                    onClick={() => token && loadDriveFiles(token)}
                    disabled={isListing}
                    className="p-1 text-stone-400 hover:text-white cursor-pointer"
                    title="Yenile"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isListing ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                <div className="space-y-1.5 max-h-48 overflow-y-auto">
                  {driveBackups.length === 0 ? (
                    <p className="text-xs text-stone-500 py-3 text-center italic">
                      Drive hesabınızda henüz yedek bulunmuyor.
                    </p>
                  ) : (
                    driveBackups.map((file) => (
                      <div
                        key={file.id}
                        className="flex items-center justify-between p-2.5 bg-zinc-900 hover:bg-zinc-850 rounded-xl border border-zinc-800 text-xs transition-all"
                      >
                        <div className="truncate mr-2">
                          <div className="font-semibold text-white truncate">
                            {file.name}
                          </div>
                          <div className="text-[10px] text-stone-500">
                            {new Date(file.modifiedTime).toLocaleString('tr-TR')}
                          </div>
                        </div>

                        {file.name.endsWith('.json') && (
                          <button
                            type="button"
                            onClick={() => handleRestoreFile(file)}
                            className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-stone-200 rounded-lg text-[11px] font-bold shrink-0 cursor-pointer border border-zinc-700"
                          >
                            Geri Yükle
                          </button>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
