import React, { useState } from 'react';
import { useGame } from '../context/GameContext.tsx';
import { ALL_SPECIES, SPECIES_MAP } from '../data/species.ts';
import { Dna, CheckCircle2, Lock, Sparkles } from 'lucide-react';

export const Zone5BreedingLab: React.FC = () => {
  const { player, synthesizeMutation } = useGame();

  const [activeBranch, setActiveBranch] = useState<'plant' | 'animal' | 'aquatic'>('plant');
  const [tierFilter, setTierFilter] = useState<4 | 5 | 'all'>('all');
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // Filter candidates for Tier 4 and Tier 5 that have breeding formulas
  const candidates = ALL_SPECIES.filter((s) => {
    if (s.tier < 4) return false;
    if (tierFilter !== 'all' && s.tier !== tierFilter) return false;

    if (activeBranch === 'plant') {
      return s.category === 'crop_grain' || s.category === 'crop_vegetable' || s.category === 'crop_flower' || s.category === 'crop_herb' || s.category === 'fruit_tree' || s.category === 'mushroom';
    }
    if (activeBranch === 'animal') return s.category === 'animal';
    if (activeBranch === 'aquatic') return s.category === 'aquatic';
    return false;
  });

  const handleSynthesize = (speciesId: string) => {
    const success = synthesizeMutation(speciesId);
    const sp = SPECIES_MAP.get(speciesId);
    if (success && sp) {
      setSuccessNotice(`Lai tạo thành công giống Bậc ${sp.tier}: ${sp.name}! Sản phẩm đã được chuyển vào kho đồ.`);
      setTimeout(() => setSuccessNotice(null), 4000);
    }
  };

  return (
    <div className="space-y-4">
      {/* Action Bar */}
      <div className="bg-stone-900/90 border border-stone-800 rounded-xl p-3 shadow-md space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🧬</span>
            <div>
              <h2 className="text-base font-bold text-purple-300">
                Khu 5: Nhà Kính Sinh Học & Trung Tâm Lai Gen
              </h2>
              <p className="text-xs text-stone-400">
                Giải mã công thức đột biến Bậc 4 (Thần Thoại) & Bậc 5 (Vũ Trụ) • Minh bạch 100% điều kiện
              </p>
            </div>
          </div>

          {/* Tier Filters */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-stone-400 font-semibold">Phẩm chất:</span>
            {[
              { id: 'all', label: 'Tất Cả' },
              { id: 4, label: '✨ Bậc 4 (Thần Thoại)' },
              { id: 5, label: '🌌 Bậc 5 (Vũ Trụ)' },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTierFilter(t.id as any)}
                className={`px-2.5 py-1 rounded-lg border font-bold transition ${
                  tierFilter === t.id
                    ? 'bg-purple-600 text-white border-purple-400 shadow-sm'
                    : 'bg-stone-800 text-stone-400 border-stone-700 hover:text-stone-200'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* 3 Branches */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-stone-800 text-xs">
          {[
            { id: 'plant', label: '🌿 Nhánh Thực Vật Đột Biến' },
            { id: 'animal', label: '🦁 Nhánh Lồng Ấp Linh Thú' },
            { id: 'aquatic', label: '🌊 Nhánh Bể Dung Hợp Thủy Sinh' },
          ].map((br) => (
            <button
              key={br.id}
              type="button"
              onClick={() => setActiveBranch(br.id as any)}
              className={`px-3 py-1.5 rounded-lg border font-bold transition ${
                activeBranch === br.id
                  ? 'bg-purple-500/20 text-purple-300 border-purple-400 shadow-sm'
                  : 'bg-stone-800 text-stone-400 border-stone-700 hover:text-stone-200'
              }`}
            >
              {br.label}
            </button>
          ))}
        </div>
      </div>

      {successNotice && (
        <div className="p-3 rounded-xl bg-purple-950/80 border border-purple-400 text-purple-200 text-xs font-bold flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span>{successNotice}</span>
        </div>
      )}

      {/* Candidates List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {candidates.map((sp) => {
          const isLevelOk = player.level >= sp.unlockLevel;

          let masteryOk = true;
          let p1Name = 'Loài Bố';
          let p2Name = 'Loài Mẹ';
          let m1 = 0;
          let m2 = 0;
          const reqMastery = sp.tier === 4 ? 20 : 35;

          if (sp.breedingParents) {
            const [p1, p2] = sp.breedingParents;
            const sp1 = SPECIES_MAP.get(p1);
            const sp2 = SPECIES_MAP.get(p2);
            p1Name = sp1 ? sp1.name : p1;
            p2Name = sp2 ? sp2.name : p2;
            m1 = player.speciesMastery[p1] || 0;
            m2 = player.speciesMastery[p2] || 0;
            if (m1 < reqMastery || m2 < reqMastery) {
              masteryOk = false;
            }
          }

          const canSynthesize = isLevelOk && masteryOk;

          return (
            <div
              key={sp.id}
              className={`bg-stone-900 border-2 rounded-2xl p-4 shadow-md flex flex-col justify-between space-y-3 ${
                sp.tier === 5
                  ? 'border-cyan-600/60 bg-gradient-to-br from-stone-900 to-slate-950'
                  : 'border-purple-600/60 bg-gradient-to-br from-stone-900 to-purple-950/30'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-3xl p-2 bg-stone-800 rounded-xl border border-stone-700">
                    {sp.icon}
                  </span>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-bold text-stone-100 text-sm sm:text-base">{sp.name}</h4>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded font-black border ${
                          sp.tier === 5
                            ? 'bg-cyan-950 text-cyan-300 border-cyan-500'
                            : 'bg-purple-950 text-purple-300 border-purple-500'
                        }`}
                      >
                        {sp.tier === 5 ? '🌌 Bậc 5 (Vũ Trụ)' : '✨ Bậc 4 (Thần Thoại)'}
                      </span>
                    </div>
                    <p className="text-xs text-stone-400 mt-0.5">{sp.description}</p>
                  </div>
                </div>
              </div>

              {/* Requirements Checklist */}
              <div className="bg-stone-950/70 p-3 rounded-xl border border-stone-800 space-y-2 text-xs">
                <div className="font-bold text-stone-300 flex items-center justify-between border-b border-stone-800 pb-1">
                  <span>Điều Kiện Giải Mã:</span>
                  <span className={canSynthesize ? 'text-emerald-400' : 'text-amber-400'}>
                    {canSynthesize ? 'Đủ 100% Điều Kiện' : 'Chưa Đạt'}
                  </span>
                </div>

                {/* 1. Player Level */}
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">
                    • Cấp độ người chơi yêu cầu: <strong>Cấp {sp.unlockLevel}</strong>
                  </span>
                  {isLevelOk ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <span className="text-[11px] text-rose-400 font-bold flex items-center gap-0.5">
                      <Lock className="w-3 h-3" /> Cấp {player.level}/{sp.unlockLevel}
                    </span>
                  )}
                </div>

                {/* 2. Parent Mastery */}
                {sp.breedingParents && (
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-stone-400">
                        • Điểm thông thạo {p1Name}: <strong>{m1}/{reqMastery}</strong>
                      </span>
                      {m1 >= reqMastery ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <span className="text-amber-400 font-bold text-[10px]">Cần thu hoạch thêm</span>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-stone-400">
                        • Điểm thông thạo {p2Name}: <strong>{m2}/{reqMastery}</strong>
                      </span>
                      {m2 >= reqMastery ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <span className="text-amber-400 font-bold text-[10px]">Cần thu hoạch thêm</span>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Synthesize Button */}
              <button
                type="button"
                disabled={!canSynthesize}
                onClick={() => handleSynthesize(sp.id)}
                className={`w-full py-2.5 rounded-xl font-black text-xs transition flex items-center justify-center gap-1.5 shadow ${
                  canSynthesize
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white ring-2 ring-purple-400/50'
                    : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                }`}
              >
                <Dna className="w-4 h-4" />
                <span>{canSynthesize ? '🧬 Dung Hợp Đột Biến 100%' : 'Chưa Đủ Điều Kiện'}</span>
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
