import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { GPSCoordinate } from '../types';

interface RunMapProps {
  coordinates: GPSCoordinate[];
  currentPosition: GPSCoordinate | null;
  accuracy: number | null;
  isLive?: boolean;
}

export const RunMap: React.FC<RunMapProps> = ({
  coordinates,
  currentPosition,
  accuracy,
  isLive = true,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const polylineRef = useRef<L.Polyline | null>(null);
  const markerRef = useRef<L.CircleMarker | null>(null);
  const accuracyCircleRef = useRef<L.Circle | null>(null);
  const startMarkerRef = useRef<L.CircleMarker | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Default to Delhi India coordinates if no initial location yet
      const initialLat = currentPosition?.lat || 28.6139;
      const initialLng = currentPosition?.lng || 77.2090;

      // Disable zoom and fade animations to avoid _leaflet_pos race condition on unmount
      const map = L.map(mapContainerRef.current, {
        center: [initialLat, initialLng],
        zoom: 16,
        zoomControl: false,
        attributionControl: false,
        zoomAnimation: false,
        fadeAnimation: false,
        markerZoomAnimation: false,
      });

      // CartoDB Dark Matter Tiles (High contrast, modern dark theme)
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd',
      }).addTo(map);

      // Add custom minimal zoom control in top right
      L.control.zoom({ position: 'topright' }).addTo(map);

      // Running Polyline with electric neon green styling
      const polyline = L.polyline([], {
        color: '#00FF66',
        weight: 5,
        opacity: 0.95,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(map);

      polylineRef.current = polyline;
      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Invalidate map size to ensure full container coverage
    const timer = setTimeout(() => {
      if (mapInstanceRef.current) {
        try {
          mapInstanceRef.current.invalidateSize();
        } catch {
          // ignore
        }
      }
    }, 200);

    return () => {
      clearTimeout(timer);
      if (mapInstanceRef.current) {
        try {
          mapInstanceRef.current.stop();
          mapInstanceRef.current.off();
          mapInstanceRef.current.remove();
        } catch {
          // ignore unmount errors
        }
        mapInstanceRef.current = null;
        polylineRef.current = null;
        markerRef.current = null;
        accuracyCircleRef.current = null;
        startMarkerRef.current = null;
      }
    };
  }, []);

  // Update polyline and markers when coordinates change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const latLngs = coordinates.map((c) => [c.lat, c.lng] as [number, number]);

    if (polylineRef.current) {
      polylineRef.current.setLatLngs(latLngs);
    }

    // Set start marker if first coordinate exists
    if (coordinates.length > 0 && !startMarkerRef.current) {
      const startCoord = coordinates[0];
      startMarkerRef.current = L.circleMarker([startCoord.lat, startCoord.lng], {
        radius: 7,
        fillColor: '#FFFFFF',
        color: '#00FF66',
        weight: 3,
        fillOpacity: 1,
      }).addTo(map);
    }

    // Update runner's current position marker
    if (currentPosition) {
      const currentLatLng: [number, number] = [currentPosition.lat, currentPosition.lng];

      if (!markerRef.current) {
        markerRef.current = L.circleMarker(currentLatLng, {
          radius: 9,
          fillColor: '#00FF66',
          color: '#FFFFFF',
          weight: 3,
          fillOpacity: 1,
        }).addTo(map);
      } else {
        markerRef.current.setLatLng(currentLatLng);
      }

      // Update accuracy circle
      if (accuracy && accuracy > 0 && isLive) {
        if (!accuracyCircleRef.current) {
          accuracyCircleRef.current = L.circle(currentLatLng, {
            radius: accuracy,
            color: '#00FF66',
            fillColor: '#00FF66',
            fillOpacity: 0.12,
            weight: 1,
          }).addTo(map);
        } else {
          accuracyCircleRef.current.setLatLng(currentLatLng);
          accuracyCircleRef.current.setRadius(accuracy);
        }
      }

      if (isLive) {
        map.panTo(currentLatLng, { animate: false });
      }
    }

    // If viewing a completed workout route, fit bounds
    if (!isLive && latLngs.length > 1) {
      try {
        map.fitBounds(L.latLngBounds(latLngs), { padding: [30, 30], animate: false });
      } catch {
        // ignore
      }
    }
  }, [coordinates, currentPosition, accuracy, isLive]);

  return (
    <div className="relative w-full h-full min-h-[220px] rounded-2xl overflow-hidden border border-zinc-800 shadow-inner bg-[#121212]">
      <div ref={mapContainerRef} className="w-full h-full min-h-[220px]" />
      
      {/* Live tracking overlay indicator */}
      {isLive && (
        <div className="absolute top-3 left-3 z-[1000] flex items-center gap-2 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-zinc-700">
          <span className="w-2.5 h-2.5 rounded-full bg-[#00FF66] animate-pulse" />
          <span className="text-xs font-semibold tracking-wider uppercase text-zinc-300">
            Live GPS Route
          </span>
        </div>
      )}
    </div>
  );
};
