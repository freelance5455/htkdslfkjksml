import React, { useState, useEffect } from 'react';
import { MAP_CATALOG, MapInfo } from '../game/map/MapRegistry';
import { GameEngine } from '../game/core/GameEngine';
import { sound } from '../audio/SoundEngine';
import { Crosshair, MapPin, Compass, AlertTriangle, RotateCcw } from 'lucide-react';

interface MapLoadingScreenProps {
  mapId: string;
  engine: GameEngine;
  onLoaded: () => void;
}

export const MapLoadingScreen: React.FC<MapLoadingScreenProps> = ({ mapId, engine, onLoaded }) => {
  const map: MapInfo = MAP_CATALOG.find(m => m.id === mapId) || MAP_CATALOG[0];
  const [stage, setStage] = useState('Loading terrain...');
  const [progress, setProgress] = useState(10);
  const [hasError, setHasError] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const runStreaming = async () => {
    setHasError(false);
    sound.startCinematicMusic();

    try {
      // Stage 1: Loading terrain...
      setStage('Loading terrain...');
      setProgress(15);
      await new Promise(r => setTimeout(r, 140));

      // Stream map geometry
      engine.loadMap(mapId);

      // Stage 2: Loading buildings...
      setStage('Loading buildings...');
      setProgress(30);
      await new Promise(r => setTimeout(r, 150));

      // Stage 3: Loading environment...
      setStage('Loading environment...');
      setProgress(45);
      await new Promise(r => setTimeout(r, 140));

      // Stage 4: Loading characters...
      setStage('Loading characters...');
      setProgress(60);
      await new Promise(r => setTimeout(r, 130));

      // Stage 5: Loading zombies...
      setStage('Loading zombies...');
      setProgress(72);
      await new Promise(r => setTimeout(r, 130));

      // Stage 6: Loading weapons...
      setStage('Loading weapons...');
      setProgress(82);
      await new Promise(r => setTimeout(r, 120));

      // Stage 7: Building navigation...
      setStage('Building navigation...');
      setProgress(90);
      await new Promise(r => setTimeout(r, 120));

      // Stage 8: Preparing lighting...
      setStage('Preparing lighting...');
      setProgress(95);
      await new Promise(r => setTimeout(r, 100));

      // Stage 9: Optimizing map...
      setStage('Optimizing map...');
      setProgress(98);
      await new Promise(r => setTimeout(r, 90));

      // Pre-flight Map Validation (Requirement 16)
      const validation = engine.verifyMapLoaded(mapId);
      if (!validation.success) {
        // Attempt immediate auto-recovery
        engine.loadMap(mapId);
        const retryVal = engine.verifyMapLoaded(mapId);
        if (!retryVal.success) {
          setHasError(true);
          setErrorMsg(retryVal.errors.join(', '));
          return;
        }
      }

      // Stage 10: READY
      setStage('READY');
      setProgress(100);
      await new Promise(r => setTimeout(r, 140));

      onLoaded();
    } catch (e: any) {
      setHasError(true);
      setErrorMsg(e?.message || 'Error initializing 3D theater environment');
    }
  };

  useEffect(() => {
    runStreaming();
  }, [mapId]);

  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-between p-6 sm:p-12 bg-black select-none font-sans overflow-hidden">
      {/* Background ambient lighting */}
      <div className={`absolute inset-0 bg-gradient-to-br ${map.previewGradient} opacity-60 pointer-events-none`} />
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:28px_28px] pointer-events-none" />

      {/* Top Banner */}
      <div className="w-full flex justify-between items-center z-10">
        <div className="flex items-center gap-2 text-red-500 font-mono-tech text-xs tracking-widest uppercase font-bold">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
          STREAMING {map.codename} // {map.difficulty}
        </div>
        <div className="text-zinc-400 font-mono-tech text-xs">
          THEATER ASSET STREAMING
        </div>
      </div>

      {/* Center Theater Artwork Dossier */}
      <div className="flex flex-col items-center text-center max-w-xl z-10">
        <div className="w-16 h-16 rounded-2xl bg-zinc-900/90 border border-zinc-700/80 flex items-center justify-center mb-3 shadow-2xl relative">
          <MapPin className="w-8 h-8 text-red-500" />
          <Compass className="absolute -right-4 -bottom-4 w-12 h-12 text-white/10 pointer-events-none" />
        </div>

        <span className="font-mono-tech text-xs text-red-400 tracking-[0.3em] uppercase mb-1 font-bold">
          LOADING — {map.name.toUpperCase()}
        </span>

        <h1 className="text-4xl sm:text-6xl font-teko uppercase font-extrabold text-white tracking-wide leading-none drop-shadow-2xl">
          {map.name}
        </h1>

        <p className="text-zinc-300 text-xs sm:text-sm font-mono-tech tracking-wider mt-2 mb-4 max-w-lg">
          {map.description}
        </p>

        <div className="p-3 rounded-xl bg-black/80 border border-zinc-800 text-zinc-400 font-mono-tech text-xs max-w-md shadow-lg flex items-center gap-2">
          <Crosshair className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>ENVIRONMENT: {map.environment}</span>
        </div>
      </div>

      {/* Error state (Never load into black void) */}
      {hasError ? (
        <div className="w-full max-w-md flex flex-col items-center z-20 p-4 rounded-xl bg-red-950/80 border border-red-500 text-center animate-fade-in">
          <AlertTriangle className="w-8 h-8 text-red-400 mb-2" />
          <span className="font-teko text-2xl text-white font-bold">MAP LOADING ERROR</span>
          <span className="font-mono-tech text-xs text-red-300 mt-1 mb-3">{errorMsg || 'Failed to verify 3D environment'}</span>
          <button
            onClick={runStreaming}
            className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-2 cursor-pointer shadow-lg"
          >
            <RotateCcw className="w-4 h-4" />
            <span>RETRY INITIALIZATION</span>
          </button>
        </div>
      ) : (
        /* Normal Progress Bar */
        <div className="w-full max-w-md flex flex-col items-center z-10">
          <div className="w-full h-3.5 bg-zinc-950 border border-zinc-800 rounded-full overflow-hidden p-0.5 mb-2.5 shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-red-600 via-amber-500 to-red-500 rounded-full transition-all duration-150 shadow-lg shadow-red-500/50"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="w-full flex justify-between font-mono-tech text-xs text-zinc-300">
            <span className="text-amber-300 font-bold tracking-wider">{stage}</span>
            <span className="text-red-400 font-bold">{progress}%</span>
          </div>
        </div>
      )}
    </div>
  );
};
