import { candidateNoun, formatScore, fullName, genderLabel } from "@/lib/bac/calc";
import type { StudentDetail } from "@/lib/bac/types";

function Seal() {
  return (
    <svg viewBox="0 0 88 88" className="size-20 text-primary" aria-hidden="true">
      <circle cx="44" cy="44" r="41" fill="none" stroke="currentColor" strokeWidth="2" />
      <circle cx="44" cy="44" r="35" fill="none" stroke="currentColor" strokeWidth="1" />
      <path
        d="M44 18 L48 34 H64 L51 44 L56 60 L44 50 L32 60 L37 44 L24 34 H40 Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function CertificateDoc({ student }: { student: StudentDetail }) {
  const name = fullName(student.lastName, student.firstName);
  const average = student.average ?? 0;
  const issued = student.certificateNumber;

  return (
    <article className="print-sheet relative mx-auto w-full max-w-[210mm] overflow-hidden rounded-lg bg-surface px-6 py-8 text-fg shadow-card sm:px-10 sm:py-12">
      <div className="pointer-events-none absolute inset-3 rounded-md border border-primary/30" />
      <div className="pointer-events-none absolute inset-4 rounded-sm border border-primary/15" />

      <header className="relative text-center">
        <p className="font-display text-lg leading-snug text-primary sm:text-xl">
          الجمهورية الجزائرية الديمقراطية الشعبية
        </p>
        <p className="mt-1 text-xs tracking-wide text-muted">
          وزارة التربية الوطنية · ديوان امتحانات شهادة البكالوريا
        </p>
        <div className="mx-auto mt-4 h-px w-40 bg-primary/30" />
        <div className="mt-5 flex justify-center">
          <Seal />
        </div>
        <h1 className="font-display mt-3 text-3xl text-primary sm:text-4xl">
          شهادة البكالوريا
        </h1>
        <p className="mt-1 text-sm text-muted">للتعليم الثانوي العام والتكنولوجي</p>
      </header>

      <div className="relative mt-8 space-y-4 text-center font-display text-lg leading-relaxed sm:text-xl">
        <p>
          يشهد وزير التربية الوطنية أن {candidateNoun(student.gender)}
        </p>
        <p className="text-2xl font-bold text-ink sm:text-3xl">{name}</p>
        <p className="text-base text-muted sm:text-lg">
          المولود{student.gender === "female" ? "ة" : ""} بتاريخ {student.birthDate} بمدينة{" "}
          {student.birthPlace} · {genderLabel(student.gender)}
        </p>
        <p>
          قد نجح{student.gender === "female" ? "ت" : ""} في امتحان شهادة البكالوريا
          <br />
          شعبة <span className="font-bold text-primary">{student.streamName}</span>
        </p>
        <p className="text-base sm:text-lg">{student.sessionLabel}</p>
      </div>

      <dl className="relative mx-auto mt-8 grid max-w-md grid-cols-2 gap-3 text-center">
        <div className="rounded-md bg-surface-2/80 px-3 py-3">
          <dt className="text-xs text-muted">المعدل العام</dt>
          <dd className="mt-1 font-display text-2xl tabular-nums text-primary">
            {formatScore(average)}
          </dd>
        </div>
        <div className="rounded-md bg-surface-2/80 px-3 py-3">
          <dt className="text-xs text-muted">التقدير</dt>
          <dd className="mt-1 font-display text-2xl text-primary">
            {student.mention ?? "—"}
          </dd>
        </div>
      </dl>

      <footer className="relative mt-10 grid grid-cols-2 gap-4 text-sm text-muted">
        <div>
          <p>رقم التسجيل: {student.examNumber}</p>
          <p className="mt-1">رقم الشهادة: {issued ?? "غير مُصدَرة"}</p>
          <p className="mt-1">{student.schoolName} — {student.wilaya}</p>
        </div>
        <div className="text-end">
          <p>حررت في {student.wilaya}</p>
          <p className="mt-6 font-display text-base text-fg">الختم والإمضاء</p>
        </div>
      </footer>
    </article>
  );
}
