import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  Search,
  Filter,
  Check,
  Lock,
  Unlock,
  AlertTriangle,
  Flame,
  Shield,
  Star,
  Sparkles,
  Archive,
} from 'lucide-react';
import type { Trick, Player, Category, TrickDifficulty } from '../types/index.ts';
import { canPublishTrick } from '../utils/garrafoesLogic.ts';

interface TrickCatalogViewProps {
  tricks: Trick[];
  players: Player[];
  activePlayer: Player;
  categories: Category[];
  isAdmin: boolean;
  onCreateTrick: (data: {
    name: string;
    description: string;
    categoryId?: string;
    difficulty: TrickDifficulty;
  }) => Promise<boolean>;
  onExecuteTrick: (trickId: string) => Promise<void>;
  onPublishTrick: (trickId: string) => Promise<boolean>;
  onArchiveTrick?: (trickId: string, reason: string) => Promise<void>;
}

export const TrickCatalogView: React.FC<TrickCatalogViewProps> = ({
  tricks,
  players,
  activePlayer,
  categories,
  isAdmin,
  onCreateTrick,
  onExecuteTrick,
  onPublishTrick,
  onArchiveTrick,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [difficultyFilter, setDifficultyFilter] = useState<'all' | TrickDifficulty>('all');
  const [tab, setTab] = useState<'published' | 'drafts'>('published');
  const [showNewModal, setShowNewModal] = useState(false);

  // Form state
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCatId, setNewCatId] = useState<string>('');
  const [newDifficulty, setNewDifficulty] = useState<TrickDifficulty>('medio');
  const [formError, setFormError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const getPlayer = (id: string): Player | undefined => {
    return players.find((p) => p.id === id);
  };

  const getDifficultyBadge = (diff: TrickDifficulty) => {
    switch (diff) {
      case 'facil':
        return <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">Fácil</span>;
      case 'medio':
        return <span className="text-[10px] font-bold text-blue-400 bg-blue-950/80 px-2 py-0.5 rounded border border-blue-800">Médio</span>;
      case 'dificil':
        return <span className="text-[10px] font-bold text-purple-400 bg-purple-950/80 px-2 py-0.5 rounded border border-purple-800">Difícil</span>;
      case 'lendario':
        return <span className="text-[10px] font-bold text-amber-400 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-800">Lendário</span>;
    }
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newDesc.trim()) {
      setFormError('Preencha o nome e a descrição curta da manobra.');
      return;
    }

    setIsSubmitting(true);
    setFormError('');

    const success = await onCreateTrick({
      name: newName.trim(),
      description: newDesc.trim(),
      categoryId: newCatId || undefined,
      difficulty: newDifficulty,
    });

    setIsSubmitting(false);
    if (success) {
      setNewName('');
      setNewDesc('');
      setShowNewModal(false);
      setTab('drafts');
    }
  };

  const filteredTricks = tricks.filter((t) => {
    if (tab === 'published' && t.status !== 'published') return false;
    if (tab === 'drafts' && t.status !== 'draft') return false;

    if (difficultyFilter !== 'all' && t.difficulty !== difficultyFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      return t.name.toLowerCase().includes(q) || t.description.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Action */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-5 h-5 text-emerald-400" />
            <h2 className="text-xl font-extrabold text-white">Catálogo Oficial de Manobras</h2>
          </div>
          <p className="text-xs text-neutral-400">
            Crie, treine e publique variações de virar garrafa. É necessário validar 5 acertos pessoais para publicar.
          </p>
        </div>

        <button
          onClick={() => setShowNewModal(true)}
          className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-950 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Propor Nova Manobra</span>
        </button>
      </div>

      {/* Tabs & Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Tab selector */}
        <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-xl">
          <button
            onClick={() => setTab('published')}
            className={`flex-1 py-2 px-4 rounded-lg text-xs font-bold transition-colors ${
              tab === 'published'
                ? 'bg-neutral-800 text-white border border-neutral-700'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Publicadas ({tricks.filter((t) => t.status === 'published').length})
          </button>
          <button
            onClick={() => setTab('drafts')}
            className={`flex-1 py-2 px-4 rounded-lg text-xs font-bold transition-colors ${
              tab === 'drafts'
                ? 'bg-neutral-800 text-white border border-neutral-700'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Rascunhos em Validação ({tricks.filter((t) => t.status === 'draft').length})
          </button>
        </div>

        {/* Search & Difficulty Filter */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1 sm:w-60">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar manobras..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-neutral-900 border border-neutral-800 rounded-lg text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <select
            value={difficultyFilter}
            onChange={(e) => setDifficultyFilter(e.target.value as any)}
            className="px-2.5 py-1.5 text-xs bg-neutral-900 border border-neutral-800 rounded-lg text-white focus:outline-none focus:border-emerald-500"
            aria-label="Filtrar por dificuldade"
          >
            <option value="all">Todas Dificuldades</option>
            <option value="facil">Fácil</option>
            <option value="medio">Médio</option>
            <option value="dificil">Difícil</option>
            <option value="lendario">Lendário</option>
          </select>
        </div>
      </div>

      {/* Tricks List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTricks.length === 0 ? (
          <div className="col-span-full bg-neutral-900 border border-neutral-800 rounded-2xl p-8 text-center">
            <BookOpen className="w-10 h-10 text-neutral-600 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-neutral-300">Nenhuma manobra encontrada nesta seção</h3>
            <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
              {tab === 'published'
                ? 'Seja o primeiro a validar 5 acertos e publicar uma manobra inovadora!'
                : 'Não há rascunhos em aberto no momento. Clique em "Propor Nova Manobra" para começar.'}
            </p>
          </div>
        ) : (
          filteredTricks.map((trick) => {
            const author = getPlayer(trick.authorId);
            const isAuthor = trick.authorId === activePlayer.id;
            const publishGate = canPublishTrick(trick);
            const myExecutions = trick.executionsByPlayer?.[activePlayer.id] || 0;
            const totalExecutions = Object.values(trick.executionsByPlayer || {}).reduce(
              (acc, v) => acc + v,
              0
            );

            return (
              <div
                key={trick.id}
                className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 flex flex-col justify-between space-y-4 hover:border-neutral-700 transition-all"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2">
                      <h3 className="font-extrabold text-base text-white">{trick.name}</h3>
                      {getDifficultyBadge(trick.difficulty)}
                    </div>

                    {trick.status === 'draft' ? (
                      <span className="text-[10px] font-bold text-amber-400 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-800 flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        <span>Rascunho ({publishGate.authorExecutions}/5)</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800 flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        <span>Publicada</span>
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-neutral-300 leading-relaxed">
                    {trick.description}
                  </p>

                  <div className="flex items-center gap-2 text-[11px] text-neutral-500 mt-3">
                    <span>Autor: <strong className="text-neutral-300">{author?.name || 'Desconhecido'}</strong></span>
                    <span aria-hidden="true">·</span>
                    <span>Total de execuções no grupo: <strong className="text-neutral-300">{totalExecutions}</strong></span>
                  </div>
                </div>

                {/* Validation & Action Footer */}
                <div className="pt-4 border-t border-neutral-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                  {/* Execution Counter for Active Player */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onExecuteTrick(trick.id)}
                      className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors border border-neutral-700 active:scale-95 cursor-pointer"
                      title="Registrar mais 1 acerto nesta manobra"
                    >
                      <Plus className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />
                      <span>+1 Acerto Meu</span>
                    </button>
                    <span className="text-xs font-mono-numbers text-neutral-400">
                      Você acertou: <strong className="text-white">{myExecutions}x</strong>
                    </span>
                  </div>

                  {/* Publish Button for Drafts (Requires 5 Author Executions) */}
                  {trick.status === 'draft' && (
                    <div>
                      {isAuthor ? (
                        <button
                          onClick={() => onPublishTrick(trick.id)}
                          disabled={!publishGate.allowed}
                          className={`px-3 py-1.5 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-all ${
                            publishGate.allowed
                              ? 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950 shadow-md shadow-emerald-950 cursor-pointer'
                              : 'bg-neutral-800 text-neutral-500 border border-neutral-700/60 cursor-not-allowed'
                          }`}
                          title={
                            publishGate.allowed
                              ? 'Publicar manobra agora!'
                              : `Faltam ${publishGate.remainingToUnlock} acertos do autor para liberar a publicação`
                          }
                        >
                          {publishGate.allowed ? (
                            <>
                              <Unlock className="w-3.5 h-3.5" />
                              <span>Liberar e Publicar</span>
                            </>
                          ) : (
                            <>
                              <Lock className="w-3.5 h-3.5" />
                              <span>Publicar (Faltam {publishGate.remainingToUnlock})</span>
                            </>
                          )}
                        </button>
                      ) : (
                        <span className="text-[11px] text-amber-500/80 font-medium">
                          Aguardando autor validar 5 acertos
                        </span>
                      )}
                    </div>
                  )}

                  {/* Moderate / Archive option for Admin */}
                  {isAdmin && onArchiveTrick && trick.status !== 'archived' && (
                    <button
                      onClick={() => {
                        const reason = prompt('Motivo da moderação/arquivamento da manobra:');
                        if (reason) onArchiveTrick(trick.id, reason);
                      }}
                      className="text-[10px] text-neutral-500 hover:text-red-400 flex items-center gap-1"
                    >
                      <Archive className="w-3 h-3" />
                      <span>Moderar</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Propose Trick Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-md">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl relative">
            <h3 className="text-lg font-extrabold text-white mb-1">
              Propor Nova Manobra
            </h3>
            <p className="text-xs text-neutral-400 mb-4">
              A manobra será salva como rascunho pessoal. Você precisará validar 5 acertos bem-sucedidos para que ela seja liberada no catálogo oficial.
            </p>

            {formError && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/40 border border-red-800/60 text-xs text-red-300">
                {formError}
              </div>
            )}

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  Nome da Manobra
                </label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Ex: Flip Duplo Invertido"
                  className="w-full px-3 py-2 text-xs bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  Descrição Curta da Execução
                </label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Explique o movimento, rotação ou superfície onde a garrafa deve pousar..."
                  rows={3}
                  className="w-full px-3 py-2 text-xs bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    Dificuldade
                  </label>
                  <select
                    value={newDifficulty}
                    onChange={(e) => setNewDifficulty(e.target.value as TrickDifficulty)}
                    className="w-full px-3 py-2 text-xs bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="facil">Fácil</option>
                    <option value="medio">Médio</option>
                    <option value="dificil">Difícil</option>
                    <option value="lendario">Lendário</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    Categoria (Opcional)
                  </label>
                  <select
                    value={newCatId}
                    onChange={(e) => setNewCatId(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="">Qualquer peso</option>
                    {categories.filter((c) => c.status === 'active').map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="px-4 py-2 text-xs font-bold text-neutral-400 hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-bold bg-emerald-500 text-neutral-950 rounded-lg hover:bg-emerald-400 transition-colors cursor-pointer"
                >
                  Criar Rascunho
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
