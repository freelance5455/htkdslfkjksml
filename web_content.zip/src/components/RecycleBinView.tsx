import React, { useState } from 'react';
import { RotateCcw, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ConfirmDialog } from './ConfirmDialog';

export const RecycleBinView: React.FC = () => {
  const { snapshot, restoreFromRecycleBin, purgeFromRecycleBin, notify } = useApp();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [confirmPurge, setConfirmPurge] = useState<string[] | null>(null);

  const items = snapshot.recycleBin;

  const toggle = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-slate-200 bg-white p-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-base font-bold text-slate-900">Recycle Bin</h2>
          <p className="text-xs text-slate-500">
            Restore deleted records or permanently purge selected items.
          </p>
        </div>
        {selectedIds.length > 0 && (
          <button
            type="button"
            onClick={() => setConfirmPurge(selectedIds)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-red-600 hover:bg-red-700 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Permanently Delete ({selectedIds.length})</span>
          </button>
        )}
      </div>

      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        {items.length === 0 ? (
          <div className="p-10 text-center text-sm text-slate-500">Recycle Bin is empty.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4 w-10">
                    <input
                      type="checkbox"
                      aria-label="Select all recycle bin items"
                      checked={selectedIds.length === items.length && items.length > 0}
                      onChange={(e) => setSelectedIds(e.target.checked ? items.map((i) => i.id) : [])}
                    />
                  </th>
                  <th className="py-3 px-4">Item</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Deleted At</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {items.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4">
                      <input
                        type="checkbox"
                        aria-label={`Select ${item.label}`}
                        checked={selectedIds.includes(item.id)}
                        onChange={() => toggle(item.id)}
                      />
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{item.label}</td>
                    <td className="py-3 px-4 text-xs text-slate-500">{item.entityType}</td>
                    <td className="py-3 px-4 text-xs font-mono-num text-slate-500">
                      {new Date(item.deletedAt).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={async () => {
                            await restoreFromRecycleBin(item.id);
                            notify(`Restored "${item.label}"`);
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold text-emerald-700 hover:bg-emerald-50 cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Restore</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmPurge([item.id])}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold text-red-600 hover:bg-red-50 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Purge</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <ConfirmDialog
        open={!!confirmPurge}
        title="Permanently Delete Selected Items?"
        message={`You are about to permanently delete ${confirmPurge?.length || 0} item(s). This action cannot be undone.`}
        destructive
        confirmLabel="Permanently Delete"
        onConfirm={async () => {
          if (confirmPurge) {
            await purgeFromRecycleBin(confirmPurge);
            setSelectedIds((prev) => prev.filter((id) => !confirmPurge.includes(id)));
            notify('Items permanently deleted');
          }
          setConfirmPurge(null);
        }}
        onCancel={() => setConfirmPurge(null)}
      />
    </div>
  );
};
