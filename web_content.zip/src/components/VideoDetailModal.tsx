import React, { useState } from 'react';
import { useVideo } from '../context/VideoContext';
import { formatDuration } from '../utils/format';
import {
  X,
  Play,
  Plus,
  Check,
  ThumbsUp,
  Volume2,
  VolumeX,
  Trash2,
  Share2,
  Calendar,
  Clock,
  Award,
  Sparkles,
  MessageCircle,
  Send,
} from 'lucide-react';

export const VideoDetailModal: React.FC = () => {
  const {
    detailVideo,
    setDetailVideo,
    setActiveVideo,
    setYoutubeVideo,
    videos,
    myList,
    toggleMyList,
    likedVideos,
    reactToVideo,
    deleteVideo,
    language,
  } = useVideo();

  const [isMuted, setIsMuted] = useState(true);
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState<
    { id: string; user: string; text: string; time: string }[]
  >([
    {
      id: 'c1',
      user: 'Salman K.',
      text: 'Superb cinematic visual fidelity and sound mixing! Loved it.',
      time: '2 hours ago',
    },
    {
      id: 'c2',
      user: 'Ali Raza',
      text: 'Netflix style layout is slick. Video streams instantly with no lag.',
      time: '1 day ago',
    },
  ]);

  if (!detailVideo) return null;

  const isInMyList = myList.includes(detailVideo.id);
  const isLiked = likedVideos.includes(detailVideo.id);

  // Recommendations: videos in the same category or tags (deduplicated)
  const similarVideos = Array.from(
    new Map(
      videos
        .filter((v) => v.id !== detailVideo.id)
        .map((v) => [v.id, v])
    ).values()
  ).slice(0, 6);

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    setComments([
      {
        id: `c-${Date.now()}`,
        user: 'You',
        text: commentText.trim(),
        time: 'Just now',
      },
      ...comments,
    ]);
    setCommentText('');
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-start justify-center p-0 sm:p-4 md:p-6"
      onClick={() => setDetailVideo(null)}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl bg-[#181818] rounded-none sm:rounded-lg overflow-hidden shadow-2xl my-0 sm:my-8 border border-white/10 text-white"
      >
        {/* Close Button */}
        <button
          onClick={() => setDetailVideo(null)}
          className="absolute top-4 right-4 z-40 p-2 rounded-full bg-[#181818]/80 hover:bg-[#181818] text-white border border-white/20 transition-all cursor-pointer"
          title="Close (Esc)"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Trailer Banner */}
        <div className="relative aspect-video sm:h-[420px] w-full bg-black overflow-hidden">
          <video
            src={detailVideo.trailerUrl || detailVideo.videoUrl}
            poster={detailVideo.backdropUrl || detailVideo.thumbnailUrl}
            autoPlay
            muted={isMuted}
            loop
            playsInline
            className="w-full h-full object-cover"
          />

          {/* Gradients */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#181818] via-transparent to-black/30" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-transparent" />

          {/* Banner Title & Actions */}
          <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between z-20">
            <div className="max-w-xl space-y-3">
              <span className="bg-[#E50914] text-white text-[10px] font-black tracking-widest px-1.5 py-0.5 rounded-xs uppercase">
                CINESTREAM
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight drop-shadow-lg">
                {detailVideo.title}
              </h2>

              <div className="flex items-center space-x-3 pt-1">
                {/* Play Button (Netflix Cinema) */}
                <button
                  onClick={() => {
                    setDetailVideo(null);
                    setActiveVideo(detailVideo);
                  }}
                  className="flex items-center space-x-2 px-5 py-2 rounded bg-white hover:bg-zinc-200 text-black font-bold text-sm transition-all transform hover:scale-105 active:scale-95 shadow-md cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-black" />
                  <span>{language === 'ur' ? 'ابھی چلائیں' : 'Cinema Play'}</span>
                </button>

                {/* YouTube Watch Button */}
                <button
                  onClick={() => {
                    setDetailVideo(null);
                    setYoutubeVideo(detailVideo);
                  }}
                  className="flex items-center space-x-2 px-4 py-2 rounded bg-red-600/30 hover:bg-red-600/50 border border-red-500/40 text-red-300 hover:text-white font-semibold text-sm transition-all transform hover:scale-105 active:scale-95 cursor-pointer"
                  title="Watch in YouTube View"
                >
                  <div className="w-3.5 h-3.5 rounded-xs bg-[#E50914] flex items-center justify-center">
                    <Play className="w-2 h-2 fill-white text-white ml-0.5" />
                  </div>
                  <span>{language === 'ur' ? 'یوٹیوب موڈ' : 'YouTube Mode'}</span>
                </button>

                {/* My List Toggle */}
                <button
                  onClick={() => toggleMyList(detailVideo.id)}
                  className="p-2 rounded-full border border-zinc-400 hover:border-white bg-black/50 text-white transition-all transform hover:scale-110 active:scale-95 cursor-pointer"
                  title={isInMyList ? 'Remove from My List' : 'Add to My List'}
                >
                  {isInMyList ? <Check className="w-4 h-4 text-emerald-400" /> : <Plus className="w-4 h-4" />}
                </button>

                {/* Like Button */}
                <button
                  onClick={() => reactToVideo(detailVideo.id, isLiked ? 'none' : 'like')}
                  className={`p-2 rounded-full border border-zinc-400 hover:border-white bg-black/50 text-white transition-all transform hover:scale-110 active:scale-95 cursor-pointer ${
                    isLiked ? 'text-blue-400 border-blue-400' : ''
                  }`}
                  title="Like"
                >
                  <ThumbsUp className={`w-4 h-4 ${isLiked ? 'fill-blue-400' : ''}`} />
                </button>

                {/* Delete button if uploaded */}
                {detailVideo.isUploaded && (
                  <button
                    onClick={() => {
                      if (confirm(`Are you sure you want to delete "${detailVideo.title}"?`)) {
                        deleteVideo(detailVideo.id);
                      }
                    }}
                    className="p-2 rounded-full border border-red-500/50 hover:border-red-500 bg-black/50 text-red-400 hover:text-red-300 transition-all cursor-pointer"
                    title="Delete Video"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Mute toggle button */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 rounded-full border border-white/30 bg-black/50 hover:bg-black/70 text-white transition-colors cursor-pointer"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Modal Body: Metadata & Info */}
        <div className="p-6 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Left 2 Cols: Details, Badges, Synopsis */}
            <div className="md:col-span-2 space-y-4">
              <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm font-semibold">
                <span className="text-emerald-400 font-bold">{detailVideo.matchScore}% Match</span>
                <span className="text-zinc-400">{detailVideo.releaseYear}</span>
                <span className="px-1.5 py-0.5 border border-zinc-600 rounded text-xs text-zinc-300">
                  {detailVideo.rating}
                </span>
                <span className="text-zinc-400">{formatDuration(detailVideo.duration)}</span>
                <span className="px-1.5 py-0.5 bg-zinc-800 border border-white/20 rounded text-[11px] font-bold">
                  {detailVideo.quality}
                </span>
                <span className="px-2 py-0.5 rounded bg-red-600/20 text-red-400 border border-red-600/30 text-xs">
                  {detailVideo.category.toUpperCase()}
                </span>
              </div>

              <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
                {detailVideo.description}
              </p>

              {detailVideo.isUploaded && (
                <div className="p-3 bg-zinc-900/80 rounded border border-white/10 text-xs space-y-1">
                  <p className="text-zinc-400">
                    <span className="text-white font-semibold">Uploaded by:</span> {detailVideo.uploaderName || 'Community Member'}
                  </p>
                  <p className="text-zinc-400">
                    <span className="text-white font-semibold">Uploaded on:</span>{' '}
                    {detailVideo.uploadedAt ? new Date(detailVideo.uploadedAt).toLocaleDateString() : 'Recent'}
                  </p>
                  <p className="text-zinc-400">
                    <span className="text-white font-semibold">Streaming Protocol:</span> HTTP 206 Partial Content (Dynamic Range Seeking)
                  </p>
                </div>
              )}
            </div>

            {/* Right Col: Cast, Director, Genres */}
            <div className="space-y-3 text-xs sm:text-sm border-t md:border-t-0 md:border-l border-white/10 pt-4 md:pt-0 md:pl-6 text-zinc-400">
              {detailVideo.cast && detailVideo.cast.length > 0 && (
                <div>
                  <span className="text-zinc-500 font-medium">Cast: </span>
                  <span className="text-zinc-200">{detailVideo.cast.join(', ')}</span>
                </div>
              )}

              {detailVideo.director && (
                <div>
                  <span className="text-zinc-500 font-medium">Director: </span>
                  <span className="text-zinc-200">{detailVideo.director}</span>
                </div>
              )}

              <div>
                <span className="text-zinc-500 font-medium">Genres: </span>
                <span className="text-zinc-200">{detailVideo.tags.join(', ')}</span>
              </div>

              <div>
                <span className="text-zinc-500 font-medium">Maturity Rating: </span>
                <span className="text-zinc-200">
                  Recommended for {detailVideo.rating === 'All' ? 'all audiences' : `ages ${detailVideo.rating} and above`}.
                </span>
              </div>
            </div>
          </div>

          {/* More Like This (Related Recommendations) */}
          <div className="pt-4 border-t border-white/10">
            <h3 className="text-lg font-bold text-white mb-4">
              {language === 'ur' ? 'مزید ایسی ویڈیوز' : 'More Like This'}
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {similarVideos.map((sim) => (
                <div
                  key={sim.id}
                  onClick={() => setDetailVideo(sim)}
                  className="bg-[#232323] rounded-md overflow-hidden group cursor-pointer hover:bg-[#2c2c2c] transition-colors"
                >
                  <div className="relative aspect-video w-full bg-zinc-800">
                    <img
                      src={sim.thumbnailUrl}
                      alt={sim.title}
                      className="w-full h-full object-cover transform transition-transform group-hover:scale-105"
                    />
                    <div className="absolute top-2 right-2 px-1 bg-black/70 text-[10px] rounded text-white">
                      {formatDuration(sim.duration)}
                    </div>
                  </div>
                  <div className="p-3 space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-emerald-400">{sim.matchScore}% Match</span>
                      <span className="px-1 border border-zinc-600 rounded text-[9px] text-zinc-300">
                        {sim.rating}
                      </span>
                    </div>
                    <h4 className="text-white text-xs sm:text-sm font-bold truncate">
                      {sim.title}
                    </h4>
                    <p className="text-zinc-400 text-[11px] line-clamp-2">
                      {sim.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Comments & Reviews Section */}
          <div className="pt-4 border-t border-white/10 space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center space-x-2">
              <MessageCircle className="w-5 h-5 text-red-500" />
              <span>{language === 'ur' ? 'تبصرے اور جائزے' : 'Audience Reviews & Comments'}</span>
            </h3>

            {/* Comment Form */}
            <form onSubmit={handleAddComment} className="flex gap-2">
              <input
                type="text"
                placeholder={
                  language === 'ur'
                    ? 'اس ویڈیو پر اپنا تبصرہ لکھیں...'
                    : 'Share your thoughts on this video...'
                }
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                className="flex-1 bg-zinc-900 border border-zinc-700 rounded-md px-3 py-2 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-red-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-[#E50914] hover:bg-red-700 text-white rounded-md font-semibold text-sm flex items-center space-x-1.5 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>{language === 'ur' ? 'بھیجیں' : 'Post'}</span>
              </button>
            </form>

            {/* Comments List */}
            <div className="space-y-3 pt-2">
              {comments.map((c) => (
                <div key={c.id} className="bg-zinc-900/60 p-3 rounded-md text-xs space-y-1 border border-white/5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">{c.user}</span>
                    <span className="text-zinc-500 text-[10px]">{c.time}</span>
                  </div>
                  <p className="text-zinc-300">{c.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
