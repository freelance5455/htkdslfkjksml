import React from 'react';
import { 
  Layers, 
  Sparkles, 
  Sliders, 
  Flame, 
  Gauge, 
  Crosshair, 
  Zap, 
  Smartphone, 
  CheckCircle,
  Eye,
  RotateCcw
} from 'lucide-react';
import { HudSettings, SystemMetrics, AdbStatus } from '../types';

interface HudShowcaseProps {
  hudSettings: HudSettings;
  setHudSettings: React.Dispatch<React.SetStateAction<HudSettings>>;
  metrics: SystemMetrics;
  setMetrics: React.Dispatch<React.SetStateAction<SystemMetrics>>;
  adbStatus: AdbStatus;
}

export const HudShowcase: React.FC<HudShowcaseProps> = ({
  hudSettings,
  setHudSettings,
  metrics,
  setMetrics,
  adbStatus,
}) => {
  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto space-y-6">
      
      {/* Top Banner */}
      <div className="p-4 md:p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <div className="p-2.5 rounded-lg bg-white text-black shrink-0">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm font-bold text-white tracking-wide">
                  Menu Flutuante Nativo (Overlay HUD)
                </h2>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                  hudSettings.visible ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-neutral-800 text-neutral-400'
                }`}>
                  {hudSettings.visible ? 'VISÍVEL NA TELA' : 'OCULTO'}
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                O menu flutuante agora é 100% interativo! Você pode arrastá-lo livremente pela tela com o mouse ou toque, alternar entre modo bolinha compacta e painel expandido, acionar mira central para jogos e monitorar temperatura da CPU e FPS.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            <button
              onClick={() => setHudSettings(prev => ({ ...prev, visible: !prev.visible }))}
              className={`px-4 py-2 rounded text-xs font-bold transition shadow flex items-center space-x-1.5 ${
                hudSettings.visible
                  ? 'bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700'
                  : 'bg-white hover:bg-neutral-200 text-black'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{hudSettings.visible ? "Ocultar Menu Flutuante" : "Ativar Menu Flutuante"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid of Controls & Android Native Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Card: Simulação e Ajustes Rápidos */}
        <div className="p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-5">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
            <h3 className="text-xs font-mono font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-400" />
              Ajustes do Menu Flutuante
            </h3>
            <button
              onClick={() => {
                setHudSettings({
                  visible: true,
                  expanded: false,
                  opacity: 0.95,
                  scale: 1,
                  accentColor: 'white',
                  showFps: true,
                  showCpuTemp: true,
                  showBatteryTemp: true,
                  showGpu: true,
                  showRam: true,
                  showCrosshair: false,
                  position: { x: window.innerWidth - 300, y: 80 }
                });
              }}
              className="text-[11px] font-mono text-neutral-400 hover:text-white flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Padrão</span>
            </button>
          </div>

          <div className="space-y-4 text-xs">
            {/* Visibilidade e Modo */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-neutral-900/60 border border-neutral-800">
              <div>
                <span className="font-bold text-white block">Estado de Exibição</span>
                <span className="text-[11px] text-neutral-400">Exibir HUD flutuando sobre a aplicação</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={hudSettings.visible}
                  onChange={e => setHudSettings(prev => ({ ...prev, visible: e.target.checked }))}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-white peer-checked:after:bg-black"></div>
              </label>
            </div>

            {/* Alternar Modo Compacto / Expandido */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-neutral-900/60 border border-neutral-800">
              <div>
                <span className="font-bold text-white block">Modo Expandido</span>
                <span className="text-[11px] text-neutral-400">Alternar entre bolinha compacta e dock completo</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={hudSettings.expanded}
                  onChange={e => setHudSettings(prev => ({ ...prev, expanded: e.target.checked }))}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-white peer-checked:after:bg-black"></div>
              </label>
            </div>

            {/* Opacidade */}
            <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 space-y-2">
              <div className="flex justify-between font-mono">
                <span className="text-neutral-300">Transparência / Opacidade:</span>
                <span className="text-white font-bold">{Math.round(hudSettings.opacity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.3"
                max="1"
                step="0.05"
                value={hudSettings.opacity}
                onChange={e => setHudSettings(prev => ({ ...prev, opacity: parseFloat(e.target.value) }))}
                className="w-full accent-white h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Tema de Cores do HUD */}
            <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 space-y-2">
              <span className="text-neutral-300 font-mono block">Esquema de Cores do Overlay:</span>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { id: 'white', label: 'Stealth White', color: 'border-white text-white' },
                  { id: 'emerald', label: 'Neon Emerald', color: 'border-emerald-500 text-emerald-400' },
                  { id: 'cyan', label: 'Cyber Cyan', color: 'border-cyan-500 text-cyan-400' },
                  { id: 'crimson', label: 'Crimson Alert', color: 'border-rose-500 text-rose-400' },
                ].map(item => (
                  <button
                    key={item.id}
                    onClick={() => setHudSettings(prev => ({ ...prev, accentColor: item.id as any }))}
                    className={`p-2 rounded border text-[11px] font-mono text-center transition ${
                      hudSettings.accentColor === item.id
                        ? 'bg-neutral-800 border-white text-white font-bold'
                        : 'bg-black border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

          </div>
        </div>

        {/* Right Card: Como funciona no Android Nativo sem Root */}
        <div className="p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-5">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
            <h3 className="text-xs font-mono font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              Arquitetura Nativa no Android
            </h3>
            <span className="text-[10px] font-mono text-emerald-400">100% SEM ROOT</span>
          </div>

          <div className="space-y-3.5 text-xs">
            <p className="text-neutral-400 leading-relaxed">
              No pacote corrigido do Android Studio, o menu flutuante é gerido pelo <code className="text-white font-mono">OverlayService.kt</code>. Veja como ele funciona:
            </p>

            <div className="space-y-2.5">
              <div className="p-3 rounded-lg bg-black/60 border border-neutral-900 space-y-1">
                <div className="flex items-center space-x-2 text-white font-bold">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WindowManager com TYPE_APPLICATION_OVERLAY</span>
                </div>
                <p className="text-neutral-400 text-[11px]">
                  Cria uma camada flutuante independente do ciclo de vida da Activity, permitindo que a bolinha e o painel fiquem visíveis por cima de Free Fire, Call of Duty, navegadores ou qualquer jogo.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-black/60 border border-neutral-900 space-y-1">
                <div className="flex items-center space-x-2 text-white font-bold">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  <span>OnTouchListener com Suporte a Drag & Snap</span>
                </div>
                <p className="text-neutral-400 text-[11px]">
                  Calcula coordenadas X e Y relativas em tempo real. Se o usuário soltar próximo à borda, ele se fixa suavemente no canto da tela sem obstruir a visão.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-black/60 border border-neutral-900 space-y-1">
                <div className="flex items-center space-x-2 text-white font-bold">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Foreground Service com Notificação Contínua</span>
                </div>
                <p className="text-neutral-400 text-[11px]">
                  Evita que a otimização de bateria do Android (Doze Mode) feche o monitor térmico enquanto você joga.
                </p>
              </div>
            </div>

            {/* Quick action to test */}
            <div className="pt-2">
              <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs flex items-center justify-between">
                <span>Dica: experimente arrastar a bolinha flutuante agora na sua tela!</span>
                <Eye className="w-4 h-4 text-emerald-400" />
              </div>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
