import React, { useState, useMemo } from 'react';
import {
  CheckSquare,
  Plus,
  Search,
  AlertCircle,
  Clock,
  CheckCircle2,
  Calendar,
  User,
  Trash2,
  Edit2,
  Download,
  AlertTriangle,
} from 'lucide-react';
import { AppSettings, OfficeTask, TaskPriority, TaskStatus } from '../types';
import { translations } from '../utils/translations';
import { StorageService } from '../utils/storage';

interface OfficeTasksProps {
  records: OfficeTask[];
  onUpdateRecords: (records: OfficeTask[]) => void;
  settings: AppSettings;
}

export const OfficeTasks: React.FC<OfficeTasksProps> = ({
  records,
  onUpdateRecords,
  settings,
}) => {
  const t = translations[settings.language];
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [priorityFilter, setPriorityFilter] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<OfficeTask | null>(null);

  // Form State
  const [taskDate, setTaskDate] = useState(new Date().toISOString().slice(0, 10));
  const [taskTitle, setTaskTitle] = useState('');
  const [description, setDescription] = useState('');
  const [assignedPerson, setAssignedPerson] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('Normal');
  const [status, setStatus] = useState<TaskStatus>('Pending');
  const [completionDate, setCompletionDate] = useState('');
  const [remarks, setRemarks] = useState('');

  const todayStr = new Date().toISOString().slice(0, 10);

  // Filtered tasks
  const activeTasks = useMemo(() => {
    return records
      .filter((r) => !r.isDeleted)
      .filter((r) => {
        const matchesSearch =
          search === '' ||
          r.taskTitle.toLowerCase().includes(search.toLowerCase()) ||
          r.assignedPerson.toLowerCase().includes(search.toLowerCase()) ||
          (r.description && r.description.toLowerCase().includes(search.toLowerCase()));
        const matchesStatus = statusFilter === '' || r.status === statusFilter;
        const matchesPriority = priorityFilter === '' || r.priority === priorityFilter;
        return matchesSearch && matchesStatus && matchesPriority;
      })
      .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
  }, [records, search, statusFilter, priorityFilter]);

  // Task Stats
  const { total, pending, inProgress, complete, overdue } = useMemo(() => {
    const active = records.filter((r) => !r.isDeleted);
    let pend = 0;
    let inProg = 0;
    let comp = 0;
    let over = 0;

    for (const task of active) {
      if (task.status === 'Complete') {
        comp++;
      } else if (task.status === 'Cancelled') {
        // skip overdue check
      } else {
        if (task.status === 'Pending') pend++;
        if (task.status === 'In Progress') inProg++;
        if (task.dueDate && task.dueDate < todayStr) {
          over++;
        }
      }
    }

    return {
      total: active.length,
      pending: pend,
      inProgress: inProg,
      complete: comp,
      overdue: over,
    };
  }, [records, todayStr]);

  const handleOpenAdd = () => {
    setEditingTask(null);
    setTaskDate(todayStr);
    setTaskTitle('');
    setDescription('');
    setAssignedPerson('Saif Ullah');
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 5);
    setDueDate(nextWeek.toISOString().slice(0, 10));
    setPriority('Normal');
    setStatus('Pending');
    setCompletionDate('');
    setRemarks('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (task: OfficeTask) => {
    setEditingTask(task);
    setTaskDate(task.taskDate);
    setTaskTitle(task.taskTitle);
    setDescription(task.description || '');
    setAssignedPerson(task.assignedPerson);
    setDueDate(task.dueDate);
    setPriority(task.priority);
    setStatus(task.status);
    setCompletionDate(task.completionDate || '');
    setRemarks(task.remarks || '');
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) {
      alert('Task title is required');
      return;
    }

    if (editingTask) {
      const old = { ...editingTask };
      const updated: OfficeTask = {
        ...editingTask,
        taskDate,
        taskTitle: taskTitle.trim(),
        description: description.trim(),
        assignedPerson: assignedPerson.trim(),
        dueDate,
        priority,
        status,
        completionDate: status === 'Complete' ? (completionDate || todayStr) : undefined,
        remarks: remarks.trim(),
        updatedAt: new Date().toISOString(),
      };
      const updatedList = records.map((t) => (t.id === editingTask.id ? updated : t));
      onUpdateRecords(updatedList);
      StorageService.saveTasks(updatedList);
      StorageService.addAuditLog('UPDATE', 'Tasks', `Updated task "${taskTitle}"`, old, updated);
    } else {
      const newTask: OfficeTask = {
        id: `task_${Date.now()}`,
        taskDate,
        taskTitle: taskTitle.trim(),
        description: description.trim(),
        assignedPerson: assignedPerson.trim(),
        dueDate,
        priority,
        status,
        completionDate: status === 'Complete' ? todayStr : undefined,
        remarks: remarks.trim(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const updatedList = [newTask, ...records];
      onUpdateRecords(updatedList);
      StorageService.saveTasks(updatedList);
      StorageService.addAuditLog('CREATE', 'Tasks', `Created task "${taskTitle}" for ${assignedPerson}`, null, newTask);
    }

    setIsModalOpen(false);
  };

  const handleQuickComplete = (task: OfficeTask) => {
    const updated: OfficeTask = {
      ...task,
      status: 'Complete',
      completionDate: todayStr,
      updatedAt: new Date().toISOString(),
    };
    const updatedList = records.map((t) => (t.id === task.id ? updated : t));
    onUpdateRecords(updatedList);
    StorageService.saveTasks(updatedList);
    StorageService.addAuditLog('UPDATE', 'Tasks', `Marked task "${task.taskTitle}" as Complete`);
  };

  const handleDelete = (task: OfficeTask) => {
    if (window.confirm(t.confirmDelete)) {
      const updated = records.map((t) => (t.id === task.id ? { ...t, isDeleted: true } : t));
      onUpdateRecords(updated);
      StorageService.saveTasks(updated);
      StorageService.moveToRecycleBin('Tasks', task.id, task.taskTitle, task);
    }
  };

  const handleExportCSV = () => {
    const rows = activeTasks.map((t) => ({
      'Task Title': t.taskTitle,
      'Assigned Person': t.assignedPerson,
      'Due Date': t.dueDate,
      Priority: t.priority,
      Status: t.status,
      'Created Date': t.taskDate,
      'Completion Date': t.completionDate || '',
      Remarks: t.remarks || '',
    }));
    StorageService.exportToCsv('Office_Tasks_Export', rows);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 rounded-lg">
            <CheckSquare className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              {t.officeTasks}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Factory & Administrative task assignments with overdue tracking
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>{t.exportCsv}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addTask}</span>
          </button>
        </div>
      </div>

      {/* Overdue alert banner if overdue tasks exist */}
      {overdue > 0 && (
        <div className="bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 p-3 rounded-xl flex items-center gap-2 text-xs text-rose-900 dark:text-rose-200 font-medium">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>
            Attention: You have <strong>{overdue} overdue task(s)</strong> that have passed their deadline!
          </span>
        </div>
      )}

      {/* KPI Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] text-slate-400 block">Total Tasks</span>
          <span className="text-xl font-bold text-slate-900 dark:text-white">{total}</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] text-amber-500 font-medium block">Pending</span>
          <span className="text-xl font-bold text-amber-600 dark:text-amber-400">{pending}</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] text-blue-500 font-medium block">In Progress</span>
          <span className="text-xl font-bold text-blue-600 dark:text-blue-400">{inProgress}</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] text-emerald-500 font-medium block">Complete</span>
          <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{complete}</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] text-rose-500 font-medium block">Overdue</span>
          <span className="text-xl font-bold text-rose-600 dark:text-rose-400">{overdue}</span>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 rtl:left-auto rtl:right-3" />
          <input
            type="text"
            placeholder="Search tasks, assignee, or notes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 rtl:pl-3 rtl:pr-9 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 border-0"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 border-0"
        >
          <option value="">All Statuses</option>
          <option value="Pending">Pending</option>
          <option value="In Progress">In Progress</option>
          <option value="Complete">Complete</option>
          <option value="On Hold">On Hold</option>
          <option value="Cancelled">Cancelled</option>
        </select>

        <select
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value)}
          className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 border-0"
        >
          <option value="">All Priorities</option>
          <option value="Urgent">Urgent</option>
          <option value="High">High</option>
          <option value="Normal">Normal</option>
          <option value="Low">Low</option>
        </select>
      </div>

      {/* Task List Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider font-semibold">
              <tr>
                <th className="px-4 py-3">{t.taskTitle}</th>
                <th className="px-4 py-3">{t.assignedPerson}</th>
                <th className="px-4 py-3">{t.dueDate}</th>
                <th className="px-4 py-3">{t.priority}</th>
                <th className="px-4 py-3">{t.status}</th>
                <th className="px-4 py-3">{t.remarks}</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {activeTasks.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-400">
                    No office tasks found matching filters.
                  </td>
                </tr>
              ) : (
                activeTasks.map((task) => {
                  const isOverdue =
                    task.status !== 'Complete' &&
                    task.status !== 'Cancelled' &&
                    task.dueDate < todayStr;

                  return (
                    <tr
                      key={task.id}
                      className={`hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition ${
                        isOverdue ? 'bg-rose-50/30 dark:bg-rose-950/20' : ''
                      }`}
                    >
                      <td className="px-4 py-3">
                        <div className="font-semibold text-slate-900 dark:text-white">
                          {task.taskTitle}
                        </div>
                        {task.description && (
                          <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                            {task.description}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-800 dark:text-slate-200 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          <span>{task.assignedPerson}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div
                          className={`font-medium ${
                            isOverdue
                              ? 'text-rose-600 dark:text-rose-400 font-bold flex items-center gap-1'
                              : 'text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {isOverdue && <AlertCircle className="w-3.5 h-3.5" />}
                          <span>{task.dueDate}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            task.priority === 'Urgent'
                              ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-400'
                              : task.priority === 'High'
                              ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400'
                              : task.priority === 'Normal'
                              ? 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-400'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          {task.priority}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${
                            task.status === 'Complete'
                              ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400'
                              : task.status === 'In Progress'
                              ? 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-400'
                              : task.status === 'Pending'
                              ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                          }`}
                        >
                          {task.status === 'Complete' && <CheckCircle2 className="w-3 h-3" />}
                          {task.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-500 max-w-xs truncate">
                        {task.remarks || '—'}
                      </td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          {task.status !== 'Complete' && (
                            <button
                              type="button"
                              onClick={() => handleQuickComplete(task)}
                              className="p-1 rounded text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950"
                              title="Mark as Complete"
                              aria-label={`Mark task ${task.taskTitle} as complete`}
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(task)}
                            className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                            title="Edit"
                            aria-label={`Edit task ${task.taskTitle}`}
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(task)}
                            className="p-1 rounded text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50"
                            title="Delete"
                            aria-label={`Delete task ${task.taskTitle}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Task Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CheckSquare className="w-5 h-5 text-indigo-600" />
                {editingTask ? 'Edit Office Task' : t.addTask}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Task Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Quarterly Boiler Safety Inspection"
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  placeholder="Detailed notes or requirements"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Assigned Person *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Name"
                    value={assignedPerson}
                    onChange={(e) => setAssignedPerson(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Due Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as TaskPriority)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-medium"
                  >
                    <option value="Low">Low</option>
                    <option value="Normal">Normal</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as TaskStatus)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-medium"
                  >
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Complete">Complete</option>
                    <option value="On Hold">On Hold</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Remarks / Follow-up notes
                </label>
                <input
                  type="text"
                  placeholder="Optional remarks"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition"
                >
                  {editingTask ? 'Update Task' : t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
