import type { Color, PieceSymbol } from "chess.js";
import { cn } from "@/lib/cn";

export function ChessPiece({
  type,
  color,
  className,
}: {
  type: PieceSymbol;
  color: Color;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 80 80"
      className={cn("piece-svg", color === "w" ? "piece-light" : "piece-dark", className)}
      aria-hidden
    >
      <g strokeWidth="1.6" strokeLinejoin="round">
        {type === "p" && <Pawn />}
        {type === "r" && <Rook />}
        {type === "n" && <Knight />}
        {type === "b" && <Bishop />}
        {type === "q" && <Queen />}
        {type === "k" && <King />}
      </g>
    </svg>
  );
}

function Base() {
  return <rect x="16" y="64" width="48" height="7" rx="2.5" />;
}

function Pawn() {
  return (
    <>
      <circle cx="40" cy="26" r="10" />
      <path d="M30 64c1.2-14 4-22 10-24 6 2 8.8 10 10 24z" />
      <Base />
    </>
  );
}

function Rook() {
  return (
    <>
      <path d="M20 28h8v6h6v-6h12v6h6v-6h8v10H20z" />
      <path d="M24 38h32v26H24z" />
      <Base />
    </>
  );
}

function Knight() {
  return (
    <>
      <path d="M18 66h40l-2-12c6-2 10-8 8-16-2-6-6-8-8-14l6-6-5-4-8 6c-2-4-8-6-14-4-10 3-16 12-14 22l-8 6c2 6 6 10 8 14z" />
      <circle className="piece-eye" cx="46" cy="28" r="2.1" />
      <Base />
    </>
  );
}

function Bishop() {
  return (
    <>
      <path d="M40 10l5 8H35z" />
      <circle cx="40" cy="26" r="9" />
      <path className="piece-line" d="M40 20v10" />
      <path d="M28 64c1-16 4-24 12-28 8 4 11 12 12 28z" />
      <Base />
    </>
  );
}

function Queen() {
  return (
    <>
      <circle cx="16" cy="24" r="3.3" />
      <circle cx="28" cy="16" r="3.3" />
      <circle cx="40" cy="12" r="3.3" />
      <circle cx="52" cy="16" r="3.3" />
      <circle cx="64" cy="24" r="3.3" />
      <path d="M16 26c3 8 8 14 24 16 16-2 21-8 24-16-2 14-8 22-24 24C24 48 18 40 16 26z" />
      <path d="M26 64c1-8 4-12 14-14 10 2 13 6 14 14z" />
      <Base />
    </>
  );
}

function King() {
  return (
    <>
      <path className="piece-line" d="M40 6v12M34 12h12" />
      <path d="M24 32h32l-3 8H27z" />
      <circle cx="22" cy="30" r="3" />
      <circle cx="40" cy="26" r="3.2" />
      <circle cx="58" cy="30" r="3" />
      <path d="M28 64c1-14 4-20 12-22 8 2 11 8 12 22z" />
      <Base />
    </>
  );
}
