import { Chess, type Color, type Square } from "chess.js";
import { useRef, useState } from "react";
import { ChessPiece } from "@/components/chess/pieces";
import { cn } from "@/lib/cn";

const FILES = ["a", "b", "c", "d", "e", "f", "g", "h"] as const;

interface DragState {
  from: Square;
  x: number;
  y: number;
  size: number;
  type: "p" | "n" | "b" | "r" | "q" | "k";
  color: Color;
}

export function Board({
  fen,
  orientation,
  selected,
  targets,
  captures,
  last,
  check,
  hint,
  interactive,
  onSquare,
  onDrop,
}: {
  fen: string;
  orientation: Color;
  selected: Square | null;
  targets: Square[];
  captures: Square[];
  last: { from: Square; to: Square } | null;
  check: Square | null;
  hint: string | null;
  interactive: boolean;
  onSquare: (square: Square) => void;
  onDrop: (from: Square, to: Square) => void;
}) {
  const boardRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<(DragState & { x0: number; y0: number; moved: boolean }) | null>(null);
  const [ghost, setGhost] = useState<DragState | null>(null);
  const chess = new Chess(fen);
  const ranks = orientation === "w" ? [8, 7, 6, 5, 4, 3, 2, 1] : [1, 2, 3, 4, 5, 6, 7, 8];
  const files = orientation === "w" ? FILES : [...FILES].reverse();
  const targetSet = new Set(targets);
  const captureSet = new Set(captures);

  function squareFromPoint(x: number, y: number) {
    const node = document.elementFromPoint(x, y);
    const square = node?.closest("[data-square]")?.getAttribute("data-square");
    return square ? (square as Square) : null;
  }

  function center(square: string) {
    const file = square.charCodeAt(0) - 97;
    const rank = Number(square[1]) - 1;
    const x = (orientation === "w" ? file : 7 - file) + 0.5;
    const y = (orientation === "w" ? 7 - rank : rank) + 0.5;
    return { x, y };
  }

  const arrow = hint && hint.length >= 4 ? { from: hint.slice(0, 2), to: hint.slice(2, 4) } : null;
  const start = arrow ? center(arrow.from) : null;
  const end = arrow ? center(arrow.to) : null;
  const tip =
    start && end
      ? { x: start.x + (end.x - start.x) * 0.72, y: start.y + (end.y - start.y) * 0.72 }
      : null;

  return (
    <div ref={boardRef} className="relative w-full touch-none select-none" style={{ aspectRatio: "1" }}>
      <div className="grid h-full w-full grid-cols-8 overflow-hidden rounded-xl">
        {ranks.flatMap((rank) =>
          files.map((file) => {
            const square = `${file}${rank}` as Square;
            const piece = chess.get(square);
            const light = (file.charCodeAt(0) - 97 + rank) % 2 === 1;
            const hide = ghost?.from === square;
            return (
              <button
                key={square}
                type="button"
                data-square={square}
                aria-label={piece ? `${square} ${piece.color === "w" ? "white" : "black"} ${piece.type}` : square}
                className={cn("sq", light ? "sq-light" : "sq-dark", interactive ? "cursor-pointer" : "cursor-default")}
                onPointerDown={(event) => {
                  if (!interactive) return;
                  onSquare(square);
                  if (!piece || piece.color !== chess.turn()) return;
                  const rect = boardRef.current?.getBoundingClientRect();
                  const size = rect ? rect.width / 8 : 48;
                  const next = {
                    from: square,
                    x: event.clientX,
                    y: event.clientY,
                    x0: event.clientX,
                    y0: event.clientY,
                    size,
                    type: piece.type,
                    color: piece.color,
                    moved: false,
                  };
                  dragRef.current = next;
                  event.currentTarget.setPointerCapture(event.pointerId);
                }}
                onPointerMove={(event) => {
                  const drag = dragRef.current;
                  if (!drag || drag.from !== square) return;
                  const moved = Math.hypot(event.clientX - drag.x0, event.clientY - drag.y0) > 8;
                  drag.x = event.clientX;
                  drag.y = event.clientY;
                  drag.moved = drag.moved || moved;
                  if (drag.moved) {
                    setGhost({
                      from: drag.from,
                      x: drag.x,
                      y: drag.y,
                      size: drag.size,
                      type: drag.type,
                      color: drag.color,
                    });
                  }
                }}
                onPointerUp={(event) => {
                  const drag = dragRef.current;
                  if (!drag || drag.from !== square) return;
                  dragRef.current = null;
                  setGhost(null);
                  if (!drag.moved) return;
                  const dest = squareFromPoint(event.clientX, event.clientY);
                  if (dest && dest !== drag.from) onDrop(drag.from, dest);
                }}
                onContextMenu={(event) => event.preventDefault()}
              >
                {last && (last.from === square || last.to === square) && <span className="sq-wash sq-wash-last" />}
                {selected === square && <span className="sq-wash sq-wash-sel" />}
                {check === square && <span className="sq-check" />}
                {file === files[0] && <span className="coord coord-rank">{rank}</span>}
                {rank === ranks[7] && <span className="coord coord-file">{file}</span>}
                {targetSet.has(square) && <span className={captureSet.has(square) ? "dot-ring" : "dot"} />}
                {piece && !hide && <ChessPiece type={piece.type} color={piece.color} />}
              </button>
            );
          }),
        )}
      </div>
      {start && tip && (
        <svg className="pointer-events-none absolute inset-0 z-[4]" viewBox="0 0 8 8" aria-hidden>
          <line
            x1={start.x}
            y1={start.y}
            x2={tip.x}
            y2={tip.y}
            stroke="var(--color-pine)"
            strokeWidth="0.14"
            strokeLinecap="round"
          />
          <circle cx={tip.x} cy={tip.y} r="0.16" fill="var(--color-pine)" />
        </svg>
      )}
      {ghost && (
        <div
          className="pointer-events-none fixed z-30"
          style={{
            left: ghost.x,
            top: ghost.y,
            width: ghost.size,
            height: ghost.size,
            transform: "translate(-50%, -50%)",
          }}
        >
          <ChessPiece type={ghost.type} color={ghost.color} />
        </div>
      )}
    </div>
  );
}
