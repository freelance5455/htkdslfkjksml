import * as Dialog from "@radix-ui/react-dialog";
import * as Slider from "@radix-ui/react-slider";
import { Chess, DEFAULT_POSITION, type Color, type PieceSymbol, type Square } from "chess.js";
import {
  ChevronFirst,
  ChevronLast,
  ChevronLeft,
  ChevronRight,
  FlipVertical2,
  RotateCcw,
  SquarePen,
} from "lucide-react";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Board } from "@/components/chess/board";
import { ChessPiece } from "@/components/chess/pieces";
import { Button } from "@/components/ui/button";
import { MARK_GLYPH, buildPgn, evalShare, formatEval, strengthLabel } from "@/lib/chess/format";
import { openingName } from "@/lib/chess/openings";
import { engine } from "@/lib/chess/uci";
import { unlockAudio } from "@/lib/chess/sound";
import { useStudio } from "@/lib/chess/store";
import { cn } from "@/lib/cn";

const PRESETS = [
  { elo: 200, name: "Beginner" },
  { elo: 600, name: "Casual" },
  { elo: 1000, name: "Club" },
  { elo: 1400, name: "Strong" },
  { elo: 1800, name: "Expert" },
  { elo: 2200, name: "Master" },
  { elo: 2700, name: "Grandmaster" },
  { elo: 3200, name: "Engine" },
  { elo: 4000, name: "Max" },
];

const SAMPLES = [
  {
    name: "Scholar's mate",
    pgn: `[Event "Halden sample"]
[Result "1-0"]

1. e4 e5 2. Qh5 Nc6 3. Bc4 Nf6 4. Qxf7# 1-0`,
  },
  {
    name: "Fool's mate",
    pgn: `[Event "Halden sample"]
[Result "0-1"]

1. f3 e5 2. g4 Qh4# 0-1`,
  },
  {
    name: "Opera game",
    pgn: `[Event "Opera game"]
[White "Morphy"]
[Black "Duke and Count"]
[Result "1-0"]

1. e4 e5 2. Nf3 d6 3. d4 Bg4 4. dxe5 Bxf3 5. Qxf3 dxe5 6. Bc4 Nf6 7. Qb3 Qe7 8. Nc3 c6 9. Bg5 b5 10. Nxb5 cxb5 11. Bxb5+ Nbd7 12. O-O-O Rd8 13. Rxd7 Rxd7 14. Rd1 Qe6 15. Bxd7+ Nxd7 16. Qb8+ Nxb8 17. Rd8# 1-0`,
  },
];

const PIECE_NAME: Record<PieceSymbol, string> = {
  p: "pawn",
  n: "knight",
  b: "bishop",
  r: "rook",
  q: "queen",
  k: "king",
};

export function Studio() {
  const state = useStudio();
  const fen = state.fens[state.cursor] ?? DEFAULT_POSITION;
  const [notationOpen, setNotationOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [copied, setCopied] = useState(false);
  const [eloText, setEloText] = useState(String(state.botElo));

  useEffect(() => {
    state.boot();
  }, [state.boot]);

  useEffect(() => {
    state.onPosition();
  }, [
    state.onPosition,
    fen,
    state.cursor,
    state.mode,
    state.over,
    state.player,
    state.hints,
    state.reviewing,
    state.engineReady,
    state.thinking,
    state.botElo,
  ]);

  useEffect(() => {
    setEloText(String(state.botElo));
  }, [state.botElo]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
      if (event.key === "ArrowLeft") state.step(-1);
      if (event.key === "ArrowRight") state.step(1);
      if (event.key === "Home") state.goto(0);
      if (event.key === "End") state.goto(state.fens.length - 1);
      if (event.key === "f" || event.key === "F") state.flip();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [state.step, state.goto, state.flip, state.fens.length]);

  const position = useMemo(() => new Chess(fen), [fen]);
  const opening = openingName(state.startFen, state.sans.slice(0, state.cursor));
  const last = useMemo(() => lastSquares(state.fens, state.sans, state.cursor), [state.fens, state.sans, state.cursor]);
  const check = useMemo(() => {
    if (!position.inCheck()) return null;
    for (const row of position.board()) {
      for (const piece of row) {
        if (piece && piece.type === "k" && piece.color === position.turn()) return piece.square;
      }
    }
    return null;
  }, [position]);
  const legal = state.selected ? position.moves({ square: state.selected, verbose: true }) : [];
  const interactive = canPlay(state, position);
  const line = state.lines[0];
  const hint = state.mode === "review" || state.hints ? (line?.pvUci[0] ?? null) : null;
  const share = line ? evalShare(line.cp, line.mate) : 50;
  const bottomShare = state.orientation === "w" ? share : 100 - share;
  const ann = state.cursor > 0 ? state.anns[state.cursor - 1] : null;
  const status = statusText(state, position, opening);

  function openNotation() {
    unlockAudio();
    try {
      setDraft(
        buildPgn({
          startFen: state.startFen,
          sans: state.sans,
          player: state.player,
          botElo: state.botElo,
          result: state.result,
        }),
      );
    } catch {
      setDraft("");
    }
    setCopied(false);
    setNotationOpen(true);
  }

  return (
    <main className="mx-auto min-h-dvh w-full max-w-6xl px-3 pb-8 pt-4 sm:px-6" onPointerDown={unlockAudio}>
      <header className="mb-4 flex items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl leading-none tracking-tight text-ink">Halden</h1>
          <p className="mt-1 text-sm text-muted">Play, import, and review</p>
        </div>
        <div className="seg" role="tablist" aria-label="Mode">
          <button type="button" role="tab" aria-selected={state.mode === "play"} aria-pressed={state.mode === "play"} onClick={() => state.setMode("play")}>
            Play
          </button>
          <button type="button" role="tab" aria-selected={state.mode === "review"} aria-pressed={state.mode === "review"} onClick={() => state.setMode("review")}>
            Review
          </button>
        </div>
      </header>

      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,40rem)_minmax(18rem,1fr)]">
        <section className="min-w-0">
          <div className="flex items-stretch gap-2">
            <div
              className="eval-track"
              role="img"
              aria-label={line ? `Evaluation ${formatEval(line.cp, line.mate)}` : "No evaluation yet"}
            >
              <div className={cn("eval-fill", state.orientation === "w" ? "eval-dark" : "eval-light")} style={{ flex: 100 - bottomShare }} />
              <div className={cn("eval-fill", state.orientation === "w" ? "eval-light" : "eval-dark")} style={{ flex: bottomShare }} />
            </div>
            <div className="relative min-w-0 flex-1">
              <Board
                fen={fen}
                orientation={state.orientation}
                selected={state.selected}
                targets={legal.map((move) => move.to)}
                captures={legal.filter((move) => move.captured || move.isEnPassant()).map((move) => move.to)}
                last={last}
                check={check}
                hint={hint}
                interactive={interactive}
                onSquare={state.handleSquare}
                onDrop={state.tryMove}
              />
              {state.promo && (
                <div className="absolute inset-0 z-20 flex items-center justify-center bg-canvas/55">
                  <div className="panel flex gap-2 p-3" role="dialog" aria-label="Choose promotion">
                    {(["q", "r", "b", "n"] as PieceSymbol[]).map((piece) => (
                      <button
                        key={piece}
                        type="button"
                        className="flex size-14 items-center justify-center rounded-xl bg-sq-light"
                        aria-label={`Promote to ${PIECE_NAME[piece]}`}
                        onClick={() => state.choosePromotion(piece)}
                      >
                        <ChessPiece type={piece} color={position.turn()} />
                      </button>
                    ))}
                    <Button variant="ghost" size="sm" onClick={state.cancelPromo}>
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="mt-3 flex items-end justify-between gap-3">
            <div className="min-w-0">
              <p className={cn("text-sm font-medium text-ink", state.thinking && "pulse-soft")} role="status">
                {status}
              </p>
              <p className="truncate text-sm text-muted">
                {line ? (
                  <span className="tabular-nums">
                    {formatEval(line.cp, line.mate)}
                    <span className="text-faint"> · depth {line.depth}</span>
                  </span>
                ) : opening ? (
                  opening
                ) : (
                  " "
                )}
                {ann ? (
                  <span className={ann.mark === "blunder" || ann.mark === "mistake" ? "text-danger" : "text-pine"}>
                    {` · ${labelMark(ann.mark)}`}
                    {ann.bestSan ? ` · best ${ann.bestSan}` : ""}
                  </span>
                ) : null}
              </p>
            </div>
            <div className="flex shrink-0 gap-1">
              <IconButton label="Start" onClick={() => state.goto(0)}>
                <ChevronFirst className="size-5" />
              </IconButton>
              <IconButton label="Previous move" onClick={() => state.step(-1)}>
                <ChevronLeft className="size-5" />
              </IconButton>
              <IconButton label="Next move" onClick={() => state.step(1)}>
                <ChevronRight className="size-5" />
              </IconButton>
              <IconButton label="Latest" onClick={() => state.goto(state.fens.length - 1)}>
                <ChevronLast className="size-5" />
              </IconButton>
            </div>
          </div>
        </section>

        <aside className="panel min-w-0 p-4">
          {state.mode === "play" ? (
            <div className="flex flex-col gap-4">
              <div>
                <p className="text-sm font-medium text-muted">You play</p>
                <div className="seg mt-2 w-fit">
                  <button type="button" aria-pressed={state.player === "w"} onClick={() => state.newGame("w")}>
                    White
                  </button>
                  <button type="button" aria-pressed={state.player === "b"} onClick={() => state.newGame("b")}>
                    Black
                  </button>
                </div>
              </div>
              <div>
                <div className="flex items-baseline justify-between gap-3">
                  <p className="text-sm font-medium text-muted">Opponent</p>
                  <p className="font-display text-2xl tabular-nums leading-none">{state.botElo}</p>
                </div>
                <p className="mt-1 text-sm text-faint">
                  {strengthLabel(state.botElo, engine.eloMin, engine.eloMax, state.engineReady && !state.engineError)}
                </p>
                <Slider.Root
                  className="relative mt-3 flex h-11 w-full touch-none items-center"
                  min={100}
                  max={4000}
                  step={10}
                  value={[state.botElo]}
                  onValueChange={([value]) => state.setElo(value)}
                  aria-label="Opponent Elo"
                >
                  <Slider.Track className="relative h-1.5 grow rounded-full bg-panel-2">
                    <Slider.Range className="absolute h-full rounded-full bg-pine" />
                  </Slider.Track>
                  <Slider.Thumb className="flex size-11 items-center justify-center rounded-full focus-visible:outline-none">
                    <span className="block size-5 rounded-full bg-accent" />
                  </Slider.Thumb>
                </Slider.Root>
                <label className="mt-2 flex items-center justify-between gap-3 text-sm text-muted">
                  Exact Elo
                  <input
                    className="field h-11 w-24 text-center tabular-nums"
                    inputMode="numeric"
                    aria-label="Exact Elo"
                    value={eloText}
                    onChange={(event) => setEloText(event.target.value.replace(/[^\d]/g, "").slice(0, 4))}
                    onBlur={() => {
                      const next = Math.max(100, Math.min(4000, Number(eloText) || state.botElo));
                      setEloText(String(next));
                      state.setElo(next);
                    }}
                    onKeyDown={(event) => {
                      if (event.key === "Enter") event.currentTarget.blur();
                    }}
                  />
                </label>
                <div className="mt-3 flex flex-wrap gap-2">
                  {PRESETS.map((preset) => (
                    <button
                      key={preset.elo}
                      type="button"
                      aria-pressed={state.botElo === preset.elo}
                      className={cn(
                        "h-11 rounded-full border border-line px-3 text-sm",
                        state.botElo === preset.elo ? "bg-accent text-accent-ink" : "bg-panel-2 text-muted",
                      )}
                      onClick={() => state.setElo(preset.elo)}
                    >
                      {preset.name} <span className="tabular-nums">{preset.elo}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="primary" onClick={() => state.newGame()}>
                  New game
                </Button>
                <Button onClick={state.takeback} disabled={!state.sans.length}>
                  <RotateCcw className="size-4" />
                  Take back
                </Button>
                <Button onClick={state.flip}>
                  <FlipVertical2 className="size-4" />
                  Flip
                </Button>
                <Button onClick={state.resign} disabled={state.over || state.sans.length === 0}>
                  Resign
                </Button>
              </div>
              <button
                type="button"
                aria-pressed={state.hints}
                className="flex h-11 items-center justify-between rounded-2xl border border-line bg-panel-2 px-3 text-sm"
                onClick={() => state.setHints(!state.hints)}
              >
                Engine lines while you play
                <span className={cn("tabular-nums", state.hints ? "text-pine" : "text-faint")}>{state.hints ? "On" : "Off"}</span>
              </button>
              {state.mode === "play" && state.cursor < state.fens.length - 1 && (
                <Button onClick={() => state.goto(state.fens.length - 1)}>Back to the live game</Button>
              )}
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="primary"
                  onClick={state.reviewGame}
                  disabled={!state.sans.length || state.reviewing || !state.engineReady}
                >
                  {state.reviewing ? `Reading ${state.reviewIndex}/${state.sans.length}` : "Analyze game"}
                </Button>
                {state.reviewing && (
                  <Button variant="ghost" onClick={state.cancelReview}>
                    Cancel
                  </Button>
                )}
                <Button onClick={state.playFromHere}>Play from here</Button>
                <Button onClick={state.flip}>
                  <FlipVertical2 className="size-4" />
                  Flip
                </Button>
              </div>
              {state.reviewing && (
                <div className="h-1 overflow-hidden rounded-full bg-panel-2" aria-hidden>
                  <div
                    className="h-full bg-pine"
                    style={{ width: `${state.sans.length ? (state.reviewIndex / state.sans.length) * 100 : 0}%` }}
                  />
                </div>
              )}
              <p className="text-sm text-faint">
                {state.engineError ??
                  (state.engineReady
                    ? "Stockfish reads the current position. Analyze game marks every move."
                    : "Preparing Stockfish…")}
              </p>
            </div>
          )}

          <EngineLines />
          <MoveList />

          <div className="mt-4 flex flex-wrap gap-2">
            <Button onClick={openNotation}>
              <SquarePen className="size-4" />
              PGN / FEN
            </Button>
          </div>
          {state.archive.length > 0 && (
            <div className="mt-4">
              <p className="text-sm font-medium text-muted">Saved on this device</p>
              <ul className="mt-2 flex flex-col gap-1">
                {state.archive.slice(0, 6).map((game) => (
                  <li key={game.id}>
                    <button
                      type="button"
                      className="w-full rounded-xl px-2 py-2 text-left text-sm text-ink hover:bg-panel-2"
                      onClick={() => state.loadNotation(game.pgn)}
                    >
                      {game.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <p className="mt-4 text-xs leading-relaxed text-faint">
            Bots under {engine.eloMin} are a built-in player. {engine.eloMin}–{engine.eloMax} uses Stockfish with a strength cap.
            Above that, Stockfish thinks longer at full strength. Engine:{" "}
            <a className="underline" href="https://github.com/official-stockfish/Stockfish" target="_blank" rel="noreferrer">
              Stockfish 19
            </a>{" "}
            (GPL-3.0).
          </p>
        </aside>
      </div>

      <Dialog.Root open={notationOpen} onOpenChange={setNotationOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="modal-overlay" />
          <Dialog.Content className="modal-card" aria-describedby={undefined}>
            <Dialog.Title className="font-display text-2xl tracking-tight">Notation</Dialog.Title>
            <Dialog.Description className="mt-1 text-sm text-muted">
              Paste a PGN or a FEN. Samples load straight into review.
            </Dialog.Description>
            <textarea
              className="field mt-3 min-h-40 font-mono text-sm"
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              spellCheck={false}
              aria-label="PGN or FEN"
            />
            {state.notationError && <p className="mt-2 text-sm text-danger">{state.notationError}</p>}
            <div className="mt-3 flex flex-wrap gap-2">
              <Button
                variant="primary"
                onClick={() => {
                  state.loadNotation(draft);
                  if (!useStudio.getState().notationError) setNotationOpen(false);
                }}
              >
                Load
              </Button>
              <Button
                onClick={() => {
                  void navigator.clipboard?.writeText(draft).then(
                    () => setCopied(true),
                    () => setCopied(false),
                  );
                }}
              >
                {copied ? "Copied" : "Copy"}
              </Button>
              <Button variant="ghost" onClick={() => setNotationOpen(false)}>
                Close
              </Button>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {SAMPLES.map((sample) => (
                <Button
                  key={sample.name}
                  size="sm"
                  onClick={() => {
                    setDraft(sample.pgn);
                    state.loadNotation(sample.pgn);
                    if (!useStudio.getState().notationError) setNotationOpen(false);
                  }}
                >
                  {sample.name}
                </Button>
              ))}
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </main>
  );
}

function EngineLines() {
  const lines = useStudio((s) => s.lines);
  const mode = useStudio((s) => s.mode);
  const hints = useStudio((s) => s.hints);
  const thinking = useStudio((s) => s.thinking);
  if (mode === "play" && !hints) return null;
  return (
    <div className="mt-4 flex flex-col gap-2">
      <p className="text-sm font-medium text-muted">Lines</p>
      {lines.length === 0 ? (
        <p className={cn("text-sm text-faint", thinking && "pulse-soft")}>{thinking ? "Opponent is thinking" : "Waiting for the engine"}</p>
      ) : (
        lines.map((row) => (
          <p key={row.multipv} className="text-sm leading-snug text-ink">
            <span className="mr-2 tabular-nums text-pine">{formatEval(row.cp, row.mate)}</span>
            <span className="text-faint">{row.pvSan.join(" ") || "…"}</span>
          </p>
        ))
      )}
    </div>
  );
}

function MoveList() {
  const sans = useStudio((s) => s.sans);
  const cursor = useStudio((s) => s.cursor);
  const anns = useStudio((s) => s.anns);
  const goto = useStudio((s) => s.goto);
  if (!sans.length) {
    return <p className="mt-4 text-sm text-faint">Moves will show up here. Tap a piece, then a square, or drag it.</p>;
  }
  const rows: { n: number; w?: string; b?: string; wPly: number; bPly?: number }[] = [];
  for (let i = 0; i < sans.length; i += 2) {
    rows.push({ n: i / 2 + 1, w: sans[i], b: sans[i + 1], wPly: i, bPly: sans[i + 1] ? i + 1 : undefined });
  }
  return (
    <div className="mt-4 max-h-64 overflow-auto pr-1">
      <div className="grid grid-cols-[2rem_1fr_1fr] gap-x-2 gap-y-1 text-sm">
        {rows.flatMap((row) => [
          <span key={`n-${row.n}`} className="self-center tabular-nums text-faint">
            {row.n}.
          </span>,
          <MoveButton key={`w-${row.n}`} san={row.w ?? ""} ply={row.wPly} cursor={cursor} ann={anns[row.wPly]} onGoto={goto} />,
          row.bPly != null ? (
            <MoveButton key={`b-${row.n}`} san={row.b ?? ""} ply={row.bPly} cursor={cursor} ann={anns[row.bPly]} onGoto={goto} />
          ) : (
            <span key={`e-${row.n}`} />
          ),
        ])}
      </div>
    </div>
  );
}

function MoveButton({
  san,
  ply,
  cursor,
  ann,
  onGoto,
}: {
  san: string;
  ply: number;
  cursor: number;
  ann: { mark: keyof typeof MARK_GLYPH } | null | undefined;
  onGoto: (cursor: number) => void;
}) {
  const glyph = ann ? MARK_GLYPH[ann.mark] : "";
  const bad = ann && (ann.mark === "blunder" || ann.mark === "mistake" || ann.mark === "inaccuracy");
  return (
    <button
      type="button"
      className={cn(
        "h-11 rounded-lg px-2 text-left tabular-nums",
        cursor === ply + 1 ? "move-on" : "hover:bg-panel-2",
        bad ? "text-danger" : ann?.mark === "best" ? "text-pine" : "text-ink",
      )}
      onClick={() => onGoto(ply + 1)}
    >
      {san}
      {glyph}
    </button>
  );
}

function IconButton({ label, onClick, children }: { label: string; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" aria-label={label} className="flex size-11 items-center justify-center rounded-full bg-panel text-ink" onClick={onClick}>
      {children}
    </button>
  );
}

function canPlay(
  state: {
    thinking: boolean;
    reviewing: boolean;
    promo: unknown;
    mode: "play" | "review";
    over: boolean;
    cursor: number;
    fens: string[];
    player: Color;
  },
  position: Chess,
) {
  if (state.thinking || state.reviewing || state.promo) return false;
  if (position.isGameOver()) return false;
  if (state.mode === "play") {
    if (state.over) return false;
    if (state.cursor !== state.fens.length - 1) return false;
    if (position.turn() !== state.player) return false;
  }
  return true;
}

function statusText(
  state: {
    thinking: boolean;
    reviewing: boolean;
    reviewIndex: number;
    sans: string[];
    mode: "play" | "review";
    over: boolean;
    result: string | null;
    cursor: number;
    fens: string[];
    player: Color;
  },
  position: Chess,
  opening: string | null,
) {
  if (state.reviewing) return `Analyzing move ${state.reviewIndex} of ${state.sans.length}`;
  if (state.result && (state.over || position.isGameOver())) return state.result;
  if (position.isGameOver()) return resultText(position);
  if (state.mode === "play" && state.cursor < state.fens.length - 1) return "Browsing the game";
  if (state.thinking) return "Halden is thinking";
  if (state.mode === "play" && position.turn() === state.player) return opening ? `Your move · ${opening}` : "Your move";
  if (state.mode === "play") return "Halden to move";
  return position.turn() === "w" ? "White to move" : "Black to move";
}

function resultText(position: Chess) {
  if (position.isCheckmate()) return position.turn() === "w" ? "Checkmate · Black wins" : "Checkmate · White wins";
  if (position.isStalemate()) return "Stalemate · draw";
  if (position.isDraw()) return "Draw";
  return "Game over";
}

function labelMark(mark: string) {
  if (mark === "best") return "Best";
  if (mark === "excellent") return "Excellent";
  if (mark === "good") return "Good";
  if (mark === "inaccuracy") return "Inaccuracy";
  if (mark === "mistake") return "Mistake";
  return "Blunder";
}

function lastSquares(fens: string[], sans: string[], cursor: number) {
  if (cursor <= 0) return null;
  try {
    const chess = new Chess(fens[cursor - 1]);
    const move = chess.move(sans[cursor - 1]);
    return { from: move.from, to: move.to };
  } catch {
    return null;
  }
}
