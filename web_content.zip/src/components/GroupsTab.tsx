import React, { useState, useEffect } from 'react';
import { Users, Plus, Shield, MessageSquare, X, Check } from 'lucide-react';
import type { User, Chat } from '../types/index.ts';
import { api } from '../services/api.ts';

interface GroupsTabProps {
  currentUser: User;
  onOpenChat: (chat: Chat) => void;
}

export const GroupsTab: React.FC<GroupsTabProps> = ({ currentUser, onOpenChat }) => {
  const [groups, setGroups] = useState<Chat[]>([]);
  const [availableUsers, setAvailableUsers] = useState<User[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [groupDescription, setGroupDescription] = useState('');
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  const loadGroups = async () => {
    try {
      const chats = await api.getChats(currentUser.id);
      setGroups(chats.filter(c => c.type === 'group'));
      const allUsers = await api.getUsers();
      setAvailableUsers(allUsers.filter(u => u.id !== currentUser.id));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGroups();
  }, [currentUser.id]);

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim() || selectedMembers.length === 0) {
      alert('Please provide a squad name and select at least one clan member');
      return;
    }

    try {
      const newGroup = await api.createGroupChat(
        currentUser.id,
        groupName.trim(),
        selectedMembers,
        undefined,
        groupDescription.trim() || 'Unknown Gamer Clan Squad'
      );
      setGroupName('');
      setGroupDescription('');
      setSelectedMembers([]);
      setShowCreateModal(false);
      loadGroups();
      onOpenChat(newGroup);
    } catch (e: any) {
      alert(e.message || 'Failed to create group');
    }
  };

  const toggleMemberSelection = (userId: string) => {
    setSelectedMembers(prev =>
      prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]
    );
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#080a0f] overflow-hidden text-slate-100">
      {/* Header with New Squad Button */}
      <div className="p-4 bg-[#0a0f18] border-b border-slate-800 flex items-center justify-between shrink-0">
        <div>
          <h2 className="text-sm font-bold text-white font-display uppercase tracking-wider">
            Clan Squads & Groups
          </h2>
          <p className="text-xs text-slate-400">Team channels and tournament coordination</p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 active:scale-95 transition-all cursor-pointer"
        >
          <Plus size={16} />
          <span>New Squad</span>
        </button>
      </div>

      {/* Squads List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {groups.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <Users size={36} className="mx-auto mb-2 text-slate-600" />
            <p className="text-xs">No active clan squads found</p>
            <p className="text-[11px] text-slate-500 mt-1">Create a group to start strategizing!</p>
          </div>
        ) : (
          groups.map((grp) => (
            <div
              key={grp.id}
              onClick={() => onOpenChat(grp)}
              className="p-4 rounded-2xl bg-[#0c121e] border border-slate-800/80 hover:border-cyan-500/30 transition-all flex items-center justify-between gap-3 cursor-pointer group"
            >
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={grp.avatar}
                  alt={grp.name}
                  className="w-12 h-12 rounded-xl bg-slate-900 border border-cyan-500/30 object-cover"
                />
                <div className="min-w-0">
                  <h3 className="font-bold text-white text-sm group-hover:text-cyan-300 transition-colors truncate">
                    {grp.name}
                  </h3>
                  <div className="text-xs text-cyan-400">
                    {grp.participants.length} Active Members
                  </div>
                  {grp.description && (
                    <div className="text-[11px] text-slate-400 truncate max-w-xs mt-0.5">
                      {grp.description}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenChat(grp);
                  }}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-cyan-400 transition-colors"
                >
                  <MessageSquare size={16} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* CREATE GROUP MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-[#0a0f18] border border-cyan-500/30 p-6 shadow-2xl text-xs text-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-base font-display">Create Clan Squad</h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateGroup} className="space-y-4 mt-4">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Squad Name *</label>
                <input
                  type="text"
                  value={groupName}
                  onChange={(e) => setGroupName(e.target.value)}
                  placeholder="e.g. Apex Predators Clan"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Squad Bio / Motto</label>
                <input
                  type="text"
                  value={groupDescription}
                  onChange={(e) => setGroupDescription(e.target.value)}
                  placeholder="e.g. Scrims & Ranked Grinders"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Select Squad Members ({selectedMembers.length} selected)
                </label>
                <div className="max-h-48 overflow-y-auto space-y-1.5 p-2 rounded-xl bg-[#0c121e] border border-slate-800">
                  {availableUsers.map((u) => {
                    const isSelected = selectedMembers.includes(u.id);
                    return (
                      <div
                        key={u.id}
                        onClick={() => toggleMemberSelection(u.id)}
                        className={`p-2 rounded-lg flex items-center justify-between cursor-pointer transition-colors ${
                          isSelected ? 'bg-cyan-950/70 border border-cyan-500/40 text-cyan-200' : 'hover:bg-slate-850 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <img src={u.avatarUrl} alt={u.username} className="w-6 h-6 rounded-md object-cover" />
                          <span className="font-medium">{u.fullName}</span>
                          <span className="text-[10px] text-slate-500">@{u.username}</span>
                        </div>
                        {isSelected && <Check size={14} className="text-cyan-400" />}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-slate-950 font-bold"
                >
                  Establish Squad
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
