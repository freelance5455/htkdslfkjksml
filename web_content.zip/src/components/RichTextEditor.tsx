import React, { useState, useRef, useEffect } from "react";
import { Toolbar, MS_WORD_FONTS } from "./Toolbar";
import { RadialMenu } from "./RadialMenu";
import { RadialActionType } from "../types";

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  onGenerateMindMap?: () => void;
  hasAudioVideoMedia?: boolean;
  onGenerateAudioVideoMindMap?: () => void;
  minHeight?: string;
}

export const RichTextEditor: React.FC<RichTextEditorProps> = ({
  value,
  onChange,
  placeholder = "Notunuzu buraya yazmaya başlayın...",
  onGenerateMindMap,
  hasAudioVideoMedia = false,
  onGenerateAudioVideoMindMap,
  minHeight = "min-h-[280px]",
}) => {
  const [selectedFont, setSelectedFont] = useState<string>("Calibri, sans-serif");
  const [selectedFontSize, setSelectedFontSize] = useState<string>("14px");
  const [isRadialOpen, setIsRadialOpen] = useState<boolean>(false);
  const [isFocused, setIsFocused] = useState<boolean>(false);

  const editorRef = useRef<HTMLDivElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync value from props to editor HTML if changed externally
  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== value) {
      editorRef.current.innerHTML = value || "";
    }
  }, [value]);

  const handleCommand = (cmd: string, val?: string) => {
    document.execCommand(cmd, false, val);
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const handleInput = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  // Instant Radial Action Execution
  const handleRadialAction = (actionId: RadialActionType | string) => {
    if (!editorRef.current) return;

    switch (actionId) {
      case "bold":
        handleCommand("bold");
        break;
      case "italic":
        handleCommand("italic");
        break;
      case "underline":
        handleCommand("underline");
        break;
      case "strikethrough":
        handleCommand("strikeThrough");
        break;
      case "h1":
        handleCommand("formatBlock", "<h1>");
        break;
      case "h2":
        handleCommand("formatBlock", "<h2>");
        break;
      case "h3":
        handleCommand("formatBlock", "<h3>");
        break;
      case "paragraph":
        handleCommand("formatBlock", "<p>");
        break;
      case "ul":
        handleCommand("insertUnorderedList");
        break;
      case "ol":
        handleCommand("insertOrderedList");
        break;
      case "camera-capture":
        if (cameraInputRef.current) cameraInputRef.current.click();
        break;
      case "attachment":
        if (fileInputRef.current) fileInputRef.current.click();
        break;
      case "ai-mindmap":
        if (onGenerateMindMap) onGenerateMindMap();
        break;
      case "voice-record":
        // Speech Recognition STT or Audio Insertion
        if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
          try {
            const SpeechRecognition =
              (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
            const recognition = new SpeechRecognition();
            recognition.lang = "tr-TR";
            recognition.start();
            recognition.onresult = (event: any) => {
              const transcript = event.results[0][0].transcript;
              if (transcript && editorRef.current) {
                editorRef.current.innerHTML += ` 🎙️ <em>${transcript}</em> `;
                onChange(editorRef.current.innerHTML);
              }
            };
          } catch (e) {
            console.warn("Speech recognition error:", e);
          }
        } else {
          alert("Tarayıcınız canlı ses transkripsiyonunu desteklemiyor.");
        }
        break;
      default:
        handleCommand(actionId);
        break;
    }
  };

  // Image / Attachment File Handlers
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const result = evt.target?.result as string;
      if (result && editorRef.current) {
        if (file.type.startsWith("image/")) {
          editorRef.current.innerHTML += `<div style="margin:12px 0;"><img src="${result}" alt="${file.name}" style="max-width:100%; border-radius:12px; shadow:0 4px 12px rgba(0,0,0,0.1);" /></div><p><br></p>`;
        } else {
          editorRef.current.innerHTML += `<div style="margin:10px 0; padding:10px; background:#f1f5f9; border-radius:10px; border:1px solid #cbd5e1; display:inline-block; font-size:12px;">📎 <strong>${file.name}</strong> (${Math.round(file.size / 1024)} KB)</div><p><br></p>`;
        }
        onChange(editorRef.current.innerHTML);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="w-full space-y-2 relative z-0 flex flex-col">
      {/* Hidden File Inputs for Camera & Attachments */}
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFileUpload}
      />
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        onChange={handleFileUpload}
      />

      {/* 1. SINGLE UNIFIED RICH TEXT TOOLBAR (z-10 container) */}
      <div className="relative z-10 shrink-0">
        <Toolbar
          onCommand={handleCommand}
          selectedFont={selectedFont}
          selectedFontSize={selectedFontSize}
          onFontChange={(f) => setSelectedFont(f)}
          onFontSizeChange={(s) => setSelectedFontSize(s)}
          onGenerateMindMap={onGenerateMindMap}
          hasAudioVideoMedia={hasAudioVideoMedia}
          onGenerateAudioVideoMindMap={onGenerateAudioVideoMindMap}
        />
      </div>

      {/* 2. RICH TEXT EDITOR CANVAS (z-0 area) */}
      <div
        className={`relative z-0 w-full rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 p-4 shadow-inner text-slate-900 dark:text-slate-100 focus-within:ring-2 focus-within:ring-teal-500/40 transition-all ${minHeight}`}
      >
        <div
          ref={editorRef}
          contentEditable={true}
          onInput={handleInput}
          onFocus={() => {
            setIsFocused(true);
            setIsRadialOpen(true);
          }}
          onClick={() => {
            setIsFocused(true);
            setIsRadialOpen(true);
          }}
          className="w-full h-full min-h-[240px] outline-none font-normal leading-relaxed overflow-y-auto"
          style={{
            fontFamily: selectedFont,
            fontSize: selectedFontSize,
          }}
          data-placeholder={placeholder}
        />
      </div>

      {/* 3. CONTEXTUAL AUTO-TRIGGERED RADIAL MENU (Only renders inside editor context when focused/opened) */}
      {(isFocused || isRadialOpen) && (
        <RadialMenu
          isOpen={isRadialOpen}
          onToggle={() => setIsRadialOpen(!isRadialOpen)}
          onClose={() => setIsRadialOpen(false)}
          onSelectAction={handleRadialAction}
        />
      )}
    </div>
  );
};
