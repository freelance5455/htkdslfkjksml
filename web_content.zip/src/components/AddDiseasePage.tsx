import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
  Globe,
  Stethoscope,
  Pill,
  Activity,
  Heart,
  Thermometer,
  ShieldCheck,
  Sparkles,
  ChevronRight,
  Info
} from 'lucide-react';
import { TopAppBar } from './TopAppBar';

export type TrackerLanguage = 'English' | 'Hindi' | 'Marathi';

interface AddDiseasePageProps {
  onBack: () => void;
  initialDisease?: any;
  onSaveSuccess?: () => void;
}

interface MedicineEntry {
  id: string;
  name: string;
  strength: string;
  dose: string;
  frequency: string;
  notes?: string;
}

const COMMON_DISEASES = [
  { id: 'diabetes', key: 'disease_diabetes', defaultName: 'Diabetes' },
  { id: 'hypertension', key: 'disease_hypertension', defaultName: 'Hypertension (Blood Pressure)' },
  { id: 'asthma', key: 'disease_asthma', defaultName: 'Asthma' },
  { id: 'heart', key: 'disease_heart', defaultName: 'Heart Disease' },
  { id: 'thyroid', key: 'disease_thyroid', defaultName: 'Thyroid' },
  { id: 'arthritis', key: 'disease_arthritis', defaultName: 'Arthritis' },
  { id: 'migraine', key: 'disease_migraine', defaultName: 'Migraine' },
  { id: 'kidney', key: 'disease_kidney', defaultName: 'Kidney Disease' },
  { id: 'liver', key: 'disease_liver', defaultName: 'Liver Disease' },
  { id: 'cholesterol', key: 'disease_cholesterol', defaultName: 'High Cholesterol' },
  { id: 'obesity', key: 'disease_obesity', defaultName: 'Obesity' },
  { id: 'cancer', key: 'disease_cancer', defaultName: 'Cancer' },
  { id: 'dengue', key: 'disease_dengue', defaultName: 'Dengue' },
  { id: 'malaria', key: 'disease_malaria', defaultName: 'Malaria' },
  { id: 'typhoid', key: 'disease_typhoid', defaultName: 'Typhoid' },
  { id: 'covid', key: 'disease_covid', defaultName: 'COVID-19' },
  { id: 'custom', key: 'disease_custom', defaultName: 'Custom Disease' }
];

const SYMPTOMS_LIST = [
  { id: 'fever', key: 'symptom_fever', defaultName: 'Fever' },
  { id: 'headache', key: 'symptom_headache', defaultName: 'Headache' },
  { id: 'cough', key: 'symptom_cough', defaultName: 'Cough' },
  { id: 'pain', key: 'symptom_pain', defaultName: 'Pain' },
  { id: 'fatigue', key: 'symptom_fatigue', defaultName: 'Fatigue' },
  { id: 'weakness', key: 'symptom_weakness', defaultName: 'Weakness' },
  { id: 'dizziness', key: 'symptom_dizziness', defaultName: 'Dizziness' },
  { id: 'swelling', key: 'symptom_swelling', defaultName: 'Swelling' },
  { id: 'vomiting', key: 'symptom_vomiting', defaultName: 'Vomiting' },
  { id: 'nausea', key: 'symptom_nausea', defaultName: 'Nausea' },
  { id: 'breathlessness', key: 'symptom_breathlessness', defaultName: 'Breathlessness' },
  { id: 'chestPain', key: 'symptom_chestPain', defaultName: 'Chest Pain' },
  { id: 'other', key: 'symptom_other', defaultName: 'Other' }
];

const translations: Record<TrackerLanguage, Record<string, string>> = {
  English: {
    languageLabel: 'Language',
    addDiseaseTitle: 'Add Disease',
    addDiseaseSubtitle: 'Register and track a new health condition',
    backToDashboard: 'Back to Tracker',
    
    // Section 1
    sectionSelection: '1. Disease Selection',
    searchDiseasePlaceholder: 'Search or select disease...',
    selectDiseaseLabel: 'Select Common Disease',
    customDiseaseOption: 'Custom Disease',
    
    disease_diabetes: 'Diabetes',
    disease_hypertension: 'Hypertension (Blood Pressure)',
    disease_asthma: 'Asthma',
    disease_heart: 'Heart Disease',
    disease_thyroid: 'Thyroid',
    disease_arthritis: 'Arthritis',
    disease_migraine: 'Migraine',
    disease_kidney: 'Kidney Disease',
    disease_liver: 'Liver Disease',
    disease_cholesterol: 'High Cholesterol',
    disease_obesity: 'Obesity',
    disease_cancer: 'Cancer',
    disease_dengue: 'Dengue',
    disease_malaria: 'Malaria',
    disease_typhoid: 'Typhoid',
    disease_covid: 'COVID-19',
    disease_custom: 'Custom Disease',

    // Section 2
    sectionDetails: '2. Disease Details',
    diseaseNameLabel: 'Disease Name *',
    diseaseNamePlaceholder: 'e.g. Type II Diabetes',
    diagnosisDateLabel: 'Diagnosis Date *',
    stageLabel: 'Current Stage (Optional)',
    stagePlaceholder: 'e.g. Stage 1, Mild, Chronic',
    doctorLabel: 'Treating Doctor (Optional)',
    doctorPlaceholder: 'e.g. Dr. Rajesh Sharma',
    hospitalLabel: 'Hospital / Clinic (Optional)',
    hospitalPlaceholder: 'e.g. Apollo Hospital',

    // Section 3
    sectionMedicines: '3. Current Medicines',
    addMedicineBtn: '+ Add Medicine',
    medicineNameLabel: 'Medicine Name',
    medicineNamePlaceholder: 'e.g. Metformin',
    strengthLabel: 'Strength',
    strengthPlaceholder: 'e.g. 500mg, 10ml',
    doseLabel: 'Dose',
    dosePlaceholder: 'e.g. 1 Tablet, 5ml',
    frequencyLabel: 'Frequency',
    notesLabel: 'Notes (Optional)',
    notesPlaceholder: 'e.g. Take after food',
    addedMedicinesList: 'Added Medicines List',
    noMedicinesAdded: 'No medicines added yet.',
    removeBtn: 'Remove',
    saveMedicineItem: 'Add to List',

    freq_once: 'Once Daily',
    freq_twice: 'Twice Daily',
    freq_thrice: 'Three Times Daily',
    freq_every8: 'Every 8 Hours',
    freq_asNeeded: 'As Needed',

    // Section 4
    sectionParameters: '4. Health Parameters',
    heightLabel: 'Height (cm)',
    weightLabel: 'Weight (kg)',
    bmiLabel: 'Calculated BMI',
    bpLabel: 'Blood Pressure (Optional)',
    bpPlaceholder: 'e.g. 120/80 mmHg',
    sugarLabel: 'Blood Sugar (Optional)',
    sugarPlaceholder: 'e.g. 110 mg/dL',
    heartRateLabel: 'Heart Rate (Optional)',
    heartRatePlaceholder: 'e.g. 72 bpm',
    tempLabel: 'Body Temperature (Optional)',
    tempPlaceholder: 'e.g. 98.6 °F',
    spo2Label: 'Oxygen Saturation SpO₂ (Optional)',
    spo2Placeholder: 'e.g. 98%',

    // Section 5
    sectionSymptoms: '5. Current Symptoms',
    selectSymptomsSubtitle: 'Select all symptoms currently experienced',
    symptom_fever: 'Fever',
    symptom_headache: 'Headache',
    symptom_cough: 'Cough',
    symptom_pain: 'Pain',
    symptom_fatigue: 'Fatigue',
    symptom_weakness: 'Weakness',
    symptom_dizziness: 'Dizziness',
    symptom_swelling: 'Swelling',
    symptom_vomiting: 'Vomiting',
    symptom_nausea: 'Nausea',
    symptom_breathlessness: 'Breathlessness',
    symptom_chestPain: 'Chest Pain',
    symptom_other: 'Other',

    // Section 6
    sectionSave: '6. Save Disease',
    saveButton: 'Save Disease',
    validationError: 'Please fill in required fields: Disease Name & Diagnosis Date.',
    successMessage: 'Disease added successfully.',

    bmiUnderweight: 'Underweight (<18.5)',
    bmiNormal: 'Normal weight (18.5–24.9)',
    bmiOverweight: 'Overweight (25–29.9)',
    bmiObese: 'Obese (≥30)'
  },
  Hindi: {
    languageLabel: 'भाषा',
    addDiseaseTitle: 'बीमारी जोड़ें',
    addDiseaseSubtitle: 'अपनी स्वास्थ्य स्थिति दर्ज और ट्रैक करें',
    backToDashboard: 'ट्रैकर पर वापस जाएं',
    
    // Section 1
    sectionSelection: '1. बीमारी का चयन',
    searchDiseasePlaceholder: 'बीमारी खोजें या चुनें...',
    selectDiseaseLabel: 'सामान्य बीमारी चुनें',
    customDiseaseOption: 'अन्य बीमारी (Custom)',
    
    disease_diabetes: 'डायबिटीज (मधुमेह)',
    disease_hypertension: 'हाइपरटेंशन (उच्च रक्तचाप)',
    disease_asthma: 'अस्थमा (दमा)',
    disease_heart: 'हृदय रोग (Heart Disease)',
    disease_thyroid: 'थायराइड',
    disease_arthritis: 'गठिया (Arthritis)',
    disease_migraine: 'माइग्रेन',
    disease_kidney: 'किडनी की बीमारी',
    disease_liver: 'लिवर की बीमारी',
    disease_cholesterol: 'हाई कोलेस्ट्रॉल',
    disease_obesity: 'मोटापा (Obesity)',
    disease_cancer: 'कैंसर',
    disease_dengue: 'डेंगू',
    disease_malaria: 'मलेरिया',
    disease_typhoid: 'टाइफाइड',
    disease_covid: 'कोविड-19',
    disease_custom: 'अन्य बीमारी',

    // Section 2
    sectionDetails: '2. बीमारी का विवरण',
    diseaseNameLabel: 'बीमारी का नाम *',
    diseaseNamePlaceholder: 'जैसे: टाइप २ डायबिटीज',
    diagnosisDateLabel: 'निदान की तारीख (Diagnosis Date) *',
    stageLabel: 'वर्तमान चरण (वैकल्पिक)',
    stagePlaceholder: 'जैसे: चरण १, हल्का, क्रोनिक',
    doctorLabel: 'इलाज करने वाले डॉक्टर (वैकल्पिक)',
    doctorPlaceholder: 'जैसे: डॉ. राजेश शर्मा',
    hospitalLabel: 'अस्पताल / क्लिनिक (वैकल्पिक)',
    hospitalPlaceholder: 'जैसे: अपोलो अस्पताल',

    // Section 3
    sectionMedicines: '3. वर्तमान दवाइयां',
    addMedicineBtn: '+ दवाई जोड़ें',
    medicineNameLabel: 'दवाई का नाम',
    medicineNamePlaceholder: 'जैसे: मेटफॉर्मिन',
    strengthLabel: 'शक्ति (Strength)',
    strengthPlaceholder: 'जैसे: 500mg, 10ml',
    doseLabel: 'खुराक (Dose)',
    dosePlaceholder: 'जैसे: १ गोली, ५ मि.ली.',
    frequencyLabel: 'आवृत्ति (Frequency)',
    notesLabel: 'नोट्स (वैकल्पिक)',
    notesPlaceholder: 'जैसे: खाने के बाद लें',
    addedMedicinesList: 'जोड़ी गई दवाइयां',
    noMedicinesAdded: 'अभी तक कोई दवाई नहीं जोड़ी गई।',
    removeBtn: 'हटाएं',
    saveMedicineItem: 'सूची में जोड़ें',

    freq_once: 'दिन में एक बार',
    freq_twice: 'दिन में दो बार',
    freq_thrice: 'दिन में तीन बार',
    freq_every8: 'हर ८ घंटे में',
    freq_asNeeded: 'आवश्यकतानुसार',

    // Section 4
    sectionParameters: '4. स्वास्थ्य पैरामीटर',
    heightLabel: 'ऊंचाई (सेमी / cm)',
    weightLabel: 'वजन (किग्रा / kg)',
    bmiLabel: 'गणना की गई बीएमआई (BMI)',
    bpLabel: 'रक्तचाप (Blood Pressure)',
    bpPlaceholder: 'जैसे: 120/80 mmHg',
    sugarLabel: 'ब्लड शुगर (Blood Sugar)',
    sugarPlaceholder: 'जैसे: 110 mg/dL',
    heartRateLabel: 'हृदय गति (Heart Rate)',
    heartRatePlaceholder: 'जैसे: 72 bpm',
    tempLabel: 'शरीर का तापमान',
    tempPlaceholder: 'जैसे: 98.6 °F',
    spo2Label: 'ऑक्सीजन स्तर SpO₂',
    spo2Placeholder: 'जैसे: 98%',

    // Section 5
    sectionSymptoms: '5. वर्तमान लक्षण',
    selectSymptomsSubtitle: 'वर्तमान में महसूस हो रहे सभी लक्षणों को चुनें',
    symptom_fever: 'बुखार (Fever)',
    symptom_headache: 'सिरदर्द (Headache)',
    symptom_cough: 'खांसी (Cough)',
    symptom_pain: 'दर्द (Pain)',
    symptom_fatigue: 'थकान (Fatigue)',
    symptom_weakness: 'कमजोरी (Weakness)',
    symptom_dizziness: 'चक्कर आना (Dizziness)',
    symptom_swelling: 'सूजन (Swelling)',
    symptom_vomiting: 'उल्टी (Vomiting)',
    symptom_nausea: 'जी मिचलाना (Nausea)',
    symptom_breathlessness: 'सांस लेने में तकलीफ',
    symptom_chestPain: 'छाती में दर्द (Chest Pain)',
    symptom_other: 'अन्य (Other)',

    // Section 6
    sectionSave: '6. बीमारी सहेजें',
    saveButton: 'बीमारी सहेजें (Save Disease)',
    validationError: 'कृपया आवश्यक फ़ील्ड भरें: बीमारी का नाम और निदान की तारीख।',
    successMessage: 'बीमारी सफलतापूर्वक जोड़ी गई।',

    bmiUnderweight: 'कम वजन (<18.5)',
    bmiNormal: 'सामान्य वजन (18.5–24.9)',
    bmiOverweight: 'अधिक वजन (25–29.9)',
    bmiObese: 'मोटापा (≥30)'
  },
  Marathi: {
    languageLabel: 'भाषा',
    addDiseaseTitle: 'आजार जोडा',
    addDiseaseSubtitle: 'तुमची आरोग्य स्थिती नोंदवा आणि ट्रॅक करा',
    backToDashboard: 'ट्रॅकरवर परत जा',
    
    // Section 1
    sectionSelection: '1. आजाराची निवड',
    searchDiseasePlaceholder: 'आजार शोधा किंवा निवडा...',
    selectDiseaseLabel: 'सामान्य आजार निवडा',
    customDiseaseOption: 'इतर आजार (Custom)',
    
    disease_diabetes: 'डायबिटीज (मधुमेह)',
    disease_hypertension: 'हायपरटेंशन (रक्तदाब)',
    disease_asthma: 'अस्थमा (दमा)',
    disease_heart: 'हृदयरोग (Heart Disease)',
    disease_thyroid: 'थायरॉईड',
    disease_arthritis: 'सांधेदुखी (Arthritis)',
    disease_migraine: 'मायग्रेन',
    disease_kidney: 'मूत्रपिंडाचा आजार (Kidney)',
    disease_liver: 'यकृत आजार (Liver)',
    disease_cholesterol: 'हाय कोलेस्टेरॉल',
    disease_obesity: 'लठ्ठपणा (Obesity)',
    disease_cancer: 'कर्करोग (Cancer)',
    disease_dengue: 'डेन्ग्यू',
    disease_malaria: 'मलेरिया',
    disease_typhoid: 'टायफॉईड',
    disease_covid: 'कोव्हिड-१९',
    disease_custom: 'इतर आजार',

    // Section 2
    sectionDetails: '2. आजाराचा तपशील',
    diseaseNameLabel: 'आजाराचे नाव *',
    diseaseNamePlaceholder: 'उदा. टाईप २ मधुमेह',
    diagnosisDateLabel: 'निदानाची तारीख (Diagnosis Date) *',
    stageLabel: 'सध्याचा टप्पा (पर्यायी)',
    stagePlaceholder: 'उदा. टप्पा १, सौम्य, क्रॉनिक',
    doctorLabel: 'उपचार करणारे डॉक्टर (पर्यायी)',
    doctorPlaceholder: 'उदा. डॉ. राजेश शर्मा',
    hospitalLabel: 'रुग्णालय / क्लिनिक (पर्यायी)',
    hospitalPlaceholder: 'उदा. अपोलो हॉस्पिटल',

    // Section 3
    sectionMedicines: '3. सध्याची औषधे',
    addMedicineBtn: '+ औषध जोडा',
    medicineNameLabel: 'औषधाचे नाव',
    medicineNamePlaceholder: 'उदा. मेटफॉर्मिन',
    strengthLabel: 'शक्ती (Strength)',
    strengthPlaceholder: 'उदा. 500mg, 10ml',
    doseLabel: 'मात्रा (Dose)',
    dosePlaceholder: 'उदा. १ गोळी, ५ मिली',
    frequencyLabel: 'वारंवारता (Frequency)',
    notesLabel: 'टीप (पर्यायी)',
    notesPlaceholder: 'उदा. जेवणानंतर घ्या',
    addedMedicinesList: 'जोडलेली औषधे',
    noMedicinesAdded: 'अद्याप कोणतेही औषध जोडलेले नाही.',
    removeBtn: 'काढून टाका',
    saveMedicineItem: 'यादीत जोडा',

    freq_once: 'दिवसातून एकदा',
    freq_twice: 'दिवसातून दोनदा',
    freq_thrice: 'दिवसातून तीनदा',
    freq_every8: 'प्रत्येक ८ तासांनी',
    freq_asNeeded: 'गरजेनुसार',

    // Section 4
    sectionParameters: '4. आरोग्य घटक (Health Parameters)',
    heightLabel: 'उंची (सेंमी / cm)',
    weightLabel: 'वजन (किग्रॅ / kg)',
    bmiLabel: 'गणना केलेले बीएमआय (BMI)',
    bpLabel: 'रक्तदाब (Blood Pressure)',
    bpPlaceholder: 'उदा. 120/80 mmHg',
    sugarLabel: 'ब्लड शुगर (Blood Sugar)',
    sugarPlaceholder: 'उदा. 110 mg/dL',
    heartRateLabel: 'हृदयाचे ठोके (Heart Rate)',
    heartRatePlaceholder: 'उदा. 72 bpm',
    tempLabel: 'शरीराचे तापमान',
    tempPlaceholder: 'उदा. 98.6 °F',
    spo2Label: 'ऑक्सिजन पातळी SpO₂',
    spo2Placeholder: 'उदा. 98%',

    // Section 5
    sectionSymptoms: '5. सध्याची लक्षणे',
    selectSymptomsSubtitle: 'सध्या जाणवणारी सर्व लक्षणे निवडा',
    symptom_fever: 'ताप (Fever)',
    symptom_headache: 'डोकेदुखी (Headache)',
    symptom_cough: 'खोकला (Cough)',
    symptom_pain: 'दुखणे / वेदना (Pain)',
    symptom_fatigue: 'थकवा (Fatigue)',
    symptom_weakness: 'अशक्तपणा (Weakness)',
    symptom_dizziness: 'चक्कर येणे (Dizziness)',
    symptom_swelling: 'सुज (Swelling)',
    symptom_vomiting: 'उलट्या (Vomiting)',
    symptom_nausea: 'मळमळ (Nausea)',
    symptom_breathlessness: 'दम लागणे',
    symptom_chestPain: 'छातीत दुखणे (Chest Pain)',
    symptom_other: 'इतर (Other)',

    // Section 6
    sectionSave: '6. आजार जतन करा',
    saveButton: 'आजार जतन करा (Save Disease)',
    validationError: 'कृपया आवश्यक माहिती भरा: आजाराचे नाव आणि निदानाची तारीख।',
    successMessage: 'आजार यशस्वीरित्या जोडला गेला.',

    bmiUnderweight: 'कमी वजन (<18.5)',
    bmiNormal: 'सामान्य वजन (18.5–24.9)',
    bmiOverweight: 'जास्त वजन (25–29.9)',
    bmiObese: 'लठ्ठपणा (≥30)'
  }
};

export const AddDiseasePage: React.FC<AddDiseasePageProps> = ({ onBack, initialDisease, onSaveSuccess }) => {
  const [language, setLanguage] = useState<TrackerLanguage>('English');
  const t = translations[language];

  // 1. Disease Selection State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDiseaseId, setSelectedDiseaseId] = useState<string>('');

  // 2. Disease Details State
  const [diseaseName, setDiseaseName] = useState(initialDisease?.diseaseName || '');
  const [diagnosisDate, setDiagnosisDate] = useState<string>(
    initialDisease?.diagnosisDate || new Date().toISOString().split('T')[0]
  );
  const [currentStage, setCurrentStage] = useState(initialDisease?.currentStage || '');
  const [treatingDoctor, setTreatingDoctor] = useState(initialDisease?.treatingDoctor || '');
  const [hospitalClinic, setHospitalClinic] = useState(initialDisease?.hospitalClinic || '');

  // 3. Current Medicines State
  const [medicinesList, setMedicinesList] = useState<MedicineEntry[]>(initialDisease?.medicines || []);
  const [showMedForm, setShowMedForm] = useState(false);
  const [medName, setMedName] = useState('');
  const [medStrength, setMedStrength] = useState('');
  const [medDose, setMedDose] = useState('');
  const [medFrequency, setMedFrequency] = useState('freq_once');
  const [medNotes, setMedNotes] = useState('');

  // 4. Health Parameters State
  const [heightCm, setHeightCm] = useState<string>(
    initialDisease?.healthParameters?.heightCm ? String(initialDisease.healthParameters.heightCm) : ''
  );
  const [weightKg, setWeightKg] = useState<string>(
    initialDisease?.healthParameters?.weightKg ? String(initialDisease.healthParameters.weightKg) : ''
  );
  const [bloodPressure, setBloodPressure] = useState(initialDisease?.healthParameters?.bloodPressure || '');
  const [bloodSugar, setBloodSugar] = useState(initialDisease?.healthParameters?.bloodSugar || '');
  const [heartRate, setHeartRate] = useState(initialDisease?.healthParameters?.heartRate || '');
  const [bodyTemp, setBodyTemp] = useState(initialDisease?.healthParameters?.bodyTemp || '');
  const [oxygenSpo2, setOxygenSpo2] = useState(initialDisease?.healthParameters?.oxygenSpo2 || '');

  // 5. Current Symptoms State
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(
    initialDisease?.symptomKeys || []
  );

  // Feedback State
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Filtered Common Diseases
  const filteredDiseases = useMemo(() => {
    if (!searchQuery.trim()) return COMMON_DISEASES;
    const q = searchQuery.toLowerCase();
    return COMMON_DISEASES.filter((item) => {
      const translatedName = t[item.key] || item.defaultName;
      return (
        translatedName.toLowerCase().includes(q) ||
        item.defaultName.toLowerCase().includes(q)
      );
    });
  }, [searchQuery, t]);

  // Handle Common Disease Selection
  const handleSelectDisease = (diseaseItem: typeof COMMON_DISEASES[0]) => {
    setSelectedDiseaseId(diseaseItem.id);
    if (diseaseItem.id === 'custom') {
      setDiseaseName('');
    } else {
      const name = t[diseaseItem.key] || diseaseItem.defaultName;
      setDiseaseName(name);
    }
  };

  // Add Medicine Item to List
  const handleAddMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!medName.trim()) return;

    const newMed: MedicineEntry = {
      id: Date.now().toString(),
      name: medName.trim(),
      strength: medStrength.trim(),
      dose: medDose.trim(),
      frequency: t[medFrequency] || medFrequency,
      notes: medNotes.trim()
    };

    setMedicinesList((prev) => [...prev, newMed]);
    setMedName('');
    setMedStrength('');
    setMedDose('');
    setMedFrequency('freq_once');
    setMedNotes('');
    setShowMedForm(false);
  };

  const handleRemoveMedicine = (id: string) => {
    setMedicinesList((prev) => prev.filter((m) => m.id !== id));
  };

  // Auto calculate BMI
  const bmiCalculation = useMemo(() => {
    const h = parseFloat(heightCm);
    const w = parseFloat(weightKg);
    if (!h || !w || h <= 0 || w <= 0) return null;
    const heightInMeters = h / 100;
    const bmiVal = w / (heightInMeters * heightInMeters);
    const bmiFixed = bmiVal.toFixed(1);

    let category = t.bmiNormal;
    let badgeColor = 'bg-emerald-100 text-emerald-800 border-emerald-300';

    if (bmiVal < 18.5) {
      category = t.bmiUnderweight;
      badgeColor = 'bg-amber-100 text-amber-800 border-amber-300';
    } else if (bmiVal >= 18.5 && bmiVal <= 24.9) {
      category = t.bmiNormal;
      badgeColor = 'bg-emerald-100 text-emerald-800 border-emerald-300';
    } else if (bmiVal >= 25 && bmiVal <= 29.9) {
      category = t.bmiOverweight;
      badgeColor = 'bg-orange-100 text-orange-800 border-orange-300';
    } else {
      category = t.bmiObese;
      badgeColor = 'bg-rose-100 text-rose-800 border-rose-300';
    }

    return { val: bmiFixed, category, badgeColor };
  }, [heightCm, weightKg, t]);

  // Toggle Symptom Selection
  const toggleSymptom = (symptomKey: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(symptomKey)
        ? prev.filter((s) => s !== symptomKey)
        : [...prev, symptomKey]
    );
  };

  // Save Disease
  const handleSave = () => {
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!diseaseName.trim() || !diagnosisDate) {
      setErrorMessage(t.validationError);
      return;
    }

    const diseaseRecord = {
      id: initialDisease ? initialDisease.id : 'disease_' + Date.now(),
      diseaseName: diseaseName.trim(),
      diagnosisDate,
      currentStage: currentStage.trim(),
      treatingDoctor: treatingDoctor.trim(),
      hospitalClinic: hospitalClinic.trim(),
      medicines: medicinesList,
      healthParameters: {
        heightCm: heightCm ? parseFloat(heightCm) : undefined,
        weightKg: weightKg ? parseFloat(weightKg) : undefined,
        bmi: bmiCalculation ? parseFloat(bmiCalculation.val) : undefined,
        bloodPressure: bloodPressure.trim(),
        bloodSugar: bloodSugar.trim(),
        heartRate: heartRate.trim(),
        bodyTemp: bodyTemp.trim(),
        oxygenSpo2: oxygenSpo2.trim()
      },
      symptoms: selectedSymptoms.map((k) => t[k] || k),
      symptomKeys: selectedSymptoms,
      createdAt: initialDisease?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Store in localStorage securely
    try {
      const existingStr = localStorage.getItem('saved_disease_records');
      let existing = existingStr ? JSON.parse(existingStr) : [];
      if (initialDisease) {
        existing = existing.map((d: any) => (d.id === initialDisease.id ? diseaseRecord : d));
      } else {
        existing.unshift(diseaseRecord);
      }
      localStorage.setItem('saved_disease_records', JSON.stringify(existing));
    } catch (err) {
      console.error('Error saving disease record:', err);
    }

    setSuccessMessage(t.successMessage);
    if (onSaveSuccess) {
      onSaveSuccess();
    }

    // Scroll to top to highlight success message
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      {/* Top Bar with Title and Language Toggle */}
      <TopAppBar
        title={t.addDiseaseTitle}
        subtitle={t.addDiseaseSubtitle}
        onBack={onBack}
      />

      <div className="p-4 sm:p-6 max-w-3xl mx-auto w-full space-y-6">
        
        {/* Language Selection Header Bar */}
        <div className="bg-white rounded-2xl p-3 border border-slate-200/90 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-700 font-extrabold text-xs sm:text-sm">
            <Globe className="w-4 h-4 text-teal-700" />
            <span>{t.languageLabel}:</span>
          </div>
          <div className="flex items-center bg-slate-100 p-1 rounded-xl gap-1">
            {(['English', 'Hindi', 'Marathi'] as TrackerLanguage[]).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => setLanguage(lang)}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all ${
                  language === lang
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
              </button>
            ))}
          </div>
        </div>

        {/* Validation Error Alert */}
        {errorMessage && (
          <div className="bg-rose-50 border border-rose-300 text-rose-800 p-4 rounded-2xl flex items-center gap-3 animate-in fade-in">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span className="text-xs sm:text-sm font-bold">{errorMessage}</span>
          </div>
        )}

        {/* Success Banner */}
        {successMessage && (
          <div className="bg-emerald-50 border-2 border-emerald-400 text-emerald-900 p-4 rounded-2xl flex items-center justify-between gap-3 animate-in fade-in shadow-sm">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
              <div>
                <h4 className="font-extrabold text-sm">{successMessage}</h4>
                <p className="text-xs text-emerald-700 font-medium">
                  Disease data is securely recorded for tracking and progress reports.
                </p>
              </div>
            </div>
            <button
              onClick={onBack}
              className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all whitespace-nowrap"
            >
              {t.backToDashboard}
            </button>
          </div>
        )}

        {/* SECTION 1: DISEASE SELECTION */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
            <div className="p-2 bg-teal-50 text-teal-700 rounded-xl">
              <Stethoscope className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900">
              {t.sectionSelection}
            </h3>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchDiseasePlaceholder}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 font-medium text-slate-900"
            />
          </div>

          {/* Common Diseases Chips */}
          <div>
            <label className="block text-xs font-bold text-slate-600 mb-2">
              {t.selectDiseaseLabel}:
            </label>
            <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto pr-1">
              {filteredDiseases.map((item) => {
                const isSelected = selectedDiseaseId === item.id;
                const label = t[item.key] || item.defaultName;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectDisease(item)}
                    className={`px-3 py-2 rounded-xl text-xs font-extrabold transition-all border ${
                      isSelected
                        ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* SECTION 2: DISEASE DETAILS */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
            <div className="p-2 bg-blue-50 text-blue-700 rounded-xl">
              <Activity className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900">
              {t.sectionDetails}
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Disease Name */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.diseaseNameLabel}
              </label>
              <input
                type="text"
                value={diseaseName}
                onChange={(e) => setDiseaseName(e.target.value)}
                placeholder={t.diseaseNamePlaceholder}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* Diagnosis Date */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.diagnosisDateLabel}
              </label>
              <input
                type="date"
                value={diagnosisDate}
                onChange={(e) => setDiagnosisDate(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* Current Stage */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.stageLabel}
              </label>
              <input
                type="text"
                value={currentStage}
                onChange={(e) => setCurrentStage(e.target.value)}
                placeholder={t.stagePlaceholder}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* Treating Doctor */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.doctorLabel}
              </label>
              <input
                type="text"
                value={treatingDoctor}
                onChange={(e) => setTreatingDoctor(e.target.value)}
                placeholder={t.doctorPlaceholder}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* Hospital / Clinic */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.hospitalLabel}
              </label>
              <input
                type="text"
                value={hospitalClinic}
                onChange={(e) => setHospitalClinic(e.target.value)}
                placeholder={t.hospitalPlaceholder}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
          </div>
        </div>

        {/* SECTION 3: CURRENT MEDICINES */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                <Pill className="w-5 h-5" />
              </div>
              <h3 className="font-extrabold text-base text-slate-900">
                {t.sectionMedicines}
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setShowMedForm(!showMedForm)}
              className="px-3 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-xl text-xs font-extrabold transition-all flex items-center gap-1"
            >
              <Plus className="w-4 h-4" />
              <span>{t.addMedicineBtn}</span>
            </button>
          </div>

          {/* Add Medicine Inline Form */}
          {showMedForm && (
            <form onSubmit={handleAddMedicine} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 animate-in fade-in">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t.medicineNameLabel} *
                  </label>
                  <input
                    type="text"
                    required
                    value={medName}
                    onChange={(e) => setMedName(e.target.value)}
                    placeholder={t.medicineNamePlaceholder}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t.strengthLabel}
                  </label>
                  <input
                    type="text"
                    value={medStrength}
                    onChange={(e) => setMedStrength(e.target.value)}
                    placeholder={t.strengthPlaceholder}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t.doseLabel}
                  </label>
                  <input
                    type="text"
                    value={medDose}
                    onChange={(e) => setMedDose(e.target.value)}
                    placeholder={t.dosePlaceholder}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t.frequencyLabel}
                  </label>
                  <select
                    value={medFrequency}
                    onChange={(e) => setMedFrequency(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900"
                  >
                    <option value="freq_once">{t.freq_once}</option>
                    <option value="freq_twice">{t.freq_twice}</option>
                    <option value="freq_thrice">{t.freq_thrice}</option>
                    <option value="freq_every8">{t.freq_every8}</option>
                    <option value="freq_asNeeded">{t.freq_asNeeded}</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t.notesLabel}
                  </label>
                  <input
                    type="text"
                    value={medNotes}
                    onChange={(e) => setMedNotes(e.target.value)}
                    placeholder={t.notesPlaceholder}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowMedForm(false)}
                  className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-extrabold shadow-xs"
                >
                  {t.saveMedicineItem}
                </button>
              </div>
            </form>
          )}

          {/* List of Added Medicines */}
          <div>
            <label className="block text-xs font-bold text-slate-600 mb-2">
              {t.addedMedicinesList}:
            </label>
            {medicinesList.length === 0 ? (
              <p className="text-xs text-slate-400 italic bg-slate-50 p-3 rounded-2xl text-center border border-dashed border-slate-200">
                {t.noMedicinesAdded}
              </p>
            ) : (
              <div className="space-y-2">
                {medicinesList.map((med) => (
                  <div
                    key={med.id}
                    className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200/80 rounded-2xl text-xs"
                  >
                    <div>
                      <span className="font-extrabold text-slate-900 block text-sm">
                        {med.name} {med.strength && `(${med.strength})`}
                      </span>
                      <span className="text-slate-600 font-medium">
                        {med.dose && `${med.dose} • `}
                        {med.frequency}
                        {med.notes && ` • ${med.notes}`}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveMedicine(med.id)}
                      className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                      title={t.removeBtn}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* SECTION 4: HEALTH PARAMETERS */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
            <div className="p-2 bg-purple-50 text-purple-700 rounded-xl">
              <Heart className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900">
              {t.sectionParameters}
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Height */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.heightLabel}
              </label>
              <input
                type="number"
                value={heightCm}
                onChange={(e) => setHeightCm(e.target.value)}
                placeholder="e.g. 170"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Weight */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.weightLabel}
              </label>
              <input
                type="number"
                value={weightKg}
                onChange={(e) => setWeightKg(e.target.value)}
                placeholder="e.g. 68"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Calculated BMI Display Card */}
            {bmiCalculation && (
              <div className="sm:col-span-2 p-3.5 bg-purple-50/60 border border-purple-200 rounded-2xl flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-purple-900 block">
                    {t.bmiLabel}
                  </span>
                  <span className="text-xl font-black text-purple-950">
                    {bmiCalculation.val} kg/m²
                  </span>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-black border ${bmiCalculation.badgeColor}`}>
                  {bmiCalculation.category}
                </span>
              </div>
            )}

            {/* Blood Pressure */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.bpLabel}
              </label>
              <input
                type="text"
                value={bloodPressure}
                onChange={(e) => setBloodPressure(e.target.value)}
                placeholder={t.bpPlaceholder}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Blood Sugar */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.sugarLabel}
              </label>
              <input
                type="text"
                value={bloodSugar}
                onChange={(e) => setBloodSugar(e.target.value)}
                placeholder={t.sugarPlaceholder}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Heart Rate */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.heartRateLabel}
              </label>
              <input
                type="text"
                value={heartRate}
                onChange={(e) => setHeartRate(e.target.value)}
                placeholder={t.heartRatePlaceholder}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Body Temperature */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.tempLabel}
              </label>
              <input
                type="text"
                value={bodyTemp}
                onChange={(e) => setBodyTemp(e.target.value)}
                placeholder={t.tempPlaceholder}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Oxygen SpO2 */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t.spo2Label}
              </label>
              <input
                type="text"
                value={oxygenSpo2}
                onChange={(e) => setOxygenSpo2(e.target.value)}
                placeholder={t.spo2Placeholder}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>
        </div>

        {/* SECTION 5: CURRENT SYMPTOMS */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
            <div className="p-2 bg-amber-50 text-amber-700 rounded-xl">
              <Thermometer className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900">
                {t.sectionSymptoms}
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                {t.selectSymptomsSubtitle}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {SYMPTOMS_LIST.map((sym) => {
              const isSelected = selectedSymptoms.includes(sym.key);
              const name = t[sym.key] || sym.defaultName;
              return (
                <button
                  key={sym.id}
                  type="button"
                  onClick={() => toggleSymptom(sym.key)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-extrabold transition-all border ${
                    isSelected
                      ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {isSelected ? '✓ ' : '+ '}
                  {name}
                </button>
              );
            })}
          </div>
        </div>

        {/* SECTION 6: SAVE DISEASE */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleSave}
            className="w-full py-4 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-sm sm:text-base rounded-2xl shadow-md shadow-teal-700/20 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-5 h-5" />
            <span>{t.saveButton}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
