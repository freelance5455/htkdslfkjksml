import { useEffect, useState } from 'react';
import { cn } from '@/utils/cn';

export function useIsTouch() {
  const [touch, setTouch] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia('(pointer: coarse)');
    setTouch(mq.matches);
    const h = (e: MediaQueryListEvent) => setTouch(e.matches);
    mq.addEventListener('change', h);
    return () => mq.removeEventListener('change', h);
  }, []);
  return touch;
}

export default function ControlsHint({ compact = false, className }: { compact?: boolean; className?: string }) {
  const touch = useIsTouch();
  const items = touch
    ? [
        { icon: '⇆', label: 'Swipe left / right', sub: 'switch lanes' },
        { icon: '⇡', label: 'Swipe up', sub: 'jump hurdles' },
        { icon: '◉', label: 'Tap an answer', sub: 'pick that lane' },
      ]
    : [
        { icon: 'keys', label: '← →  or  1 2 3', sub: 'switch lanes' },
        { icon: 'keys', label: '↑  Space  W', sub: 'jump hurdles' },
        { icon: 'keys', label: 'P  or  Esc', sub: 'pause' },
      ];
  return (
    <div className={cn('grid gap-2', compact ? 'grid-cols-3' : 'grid-cols-1 sm:grid-cols-3', className)}>
      {items.map((it) => (
        <div
          key={it.label}
          className={cn(
            'flex items-center gap-3 rounded-xl border border-gold-dark/40 bg-ink/40 px-3 py-2 text-left backdrop-blur-sm',
            compact && 'flex-col gap-1 px-2 py-2 text-center',
          )}
        >
          {it.icon === 'keys' ? (
            <div className="flex shrink-0 gap-1">
              {it.label.split(/\s{2}or\s{2}|\s{2}/).map((k) => (
                <span key={k} className="key">
                  {k}
                </span>
              ))}
            </div>
          ) : (
            <span className="text-2xl leading-none text-gold">{it.icon}</span>
          )}
          <div className={cn('leading-tight', compact && 'text-[11px]')}>
            {it.icon !== 'keys' && <div className="text-xs font-black text-parchment">{it.label}</div>}
            <div className="text-[11px] font-bold uppercase tracking-wider text-gold-light/80">{it.sub}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
