import React, { useState } from 'react';
import { SaleInvoice, CartItem, PaymentMethod, Customer, Product } from '../types/business';
import { StorageService } from '../db/storage';
import { X, Trash2, Plus, AlertCircle, CheckCircle2 } from 'lucide-react';

interface EditSaleModalProps {
  invoice: SaleInvoice;
  lang: 'bn' | 'en';
  onClose: () => void;
  onSaveSuccess: (updatedInvoice: SaleInvoice) => void;
}

export const EditSaleModal: React.FC<EditSaleModalProps> = ({
  invoice,
  lang,
  onClose,
  onSaveSuccess,
}) => {
  const [customers] = useState<Customer[]>(StorageService.getCustomers());
  const [products] = useState<Product[]>(StorageService.getProducts());

  const [customerId, setCustomerId] = useState(invoice.customerId);
  const [customerName, setCustomerName] = useState(invoice.customerName);
  const [customerPhone, setCustomerPhone] = useState(invoice.customerPhone);
  const [items, setItems] = useState<CartItem[]>(invoice.items);
  const [discount, setDiscount] = useState<number | ''>(invoice.discount);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(invoice.paymentMethod);
  const [paidAmount, setPaidAmount] = useState<number | ''>(invoice.paidAmount);
  const [dueDate, setDueDate] = useState(invoice.dueDate || '');
  const [error, setError] = useState('');

  // Handle customer change
  const handleCustomerChange = (cId: string) => {
    setCustomerId(cId);
    if (cId === 'walk-in') {
      setCustomerName(lang === 'bn' ? 'নগদ ক্রেতা' : 'Walk-in Customer');
      setCustomerPhone('');
    } else {
      const c = customers.find((cust) => cust.id === cId);
      if (c) {
        setCustomerName(c.name);
        setCustomerPhone(c.phone);
      }
    }
  };

  // Modify quantity in items
  const handleUpdateQty = (productId: string, newQty: number) => {
    if (newQty <= 0) {
      setItems(items.filter((i) => i.productId !== productId));
      return;
    }
    const updated = items.map((item) => {
      if (item.productId === productId) {
        const totalPrice = newQty * item.unitPrice;
        const profit = (item.unitPrice - item.purchasePrice) * newQty;
        return { ...item, quantity: newQty, totalPrice, profit };
      }
      return item;
    });
    setItems(updated);
  };

  // Modify price in items
  const handleUpdatePrice = (productId: string, newPrice: number) => {
    const updated = items.map((item) => {
      if (item.productId === productId) {
        const safePrice = Math.max(0, newPrice);
        const totalPrice = item.quantity * safePrice;
        const profit = (safePrice - item.purchasePrice) * item.quantity;
        return { ...item, unitPrice: safePrice, totalPrice, profit };
      }
      return item;
    });
    setItems(updated);
  };

  // Calculation
  const totalSales = items.reduce((sum, i) => sum + i.totalPrice, 0);
  const finalPayable = Math.max(0, totalSales - (Number(discount) || 0));
  const currentPaid = paidAmount === '' ? 0 : Number(paidAmount);
  const due = Math.max(0, finalPayable - currentPaid);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) {
      setError(lang === 'bn' ? 'চালানে অন্তত একটি পণ্য থাকতে হবে' : 'At least one item required');
      return;
    }

    const updated = StorageService.updateSaleInvoice(invoice.id, {
      customerId,
      customerName,
      customerPhone,
      items,
      discount: Number(discount) || 0,
      paymentMethod,
      paidAmount: currentPaid,
      dueDate: due > 0 ? dueDate : undefined,
    });

    if (updated) {
      onSaveSuccess(updated);
    } else {
      setError('Failed to update invoice');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base">
              {lang === 'bn' ? 'বিক্রয় চালান সম্পাদনা (Edit Sale)' : 'Edit Sale Invoice'}
            </h3>
            <span className="text-xs text-slate-400 font-mono">{invoice.invoiceNumber}</span>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-50 text-red-700 text-xs font-semibold rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          {/* Customer */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">কাস্টমার</label>
            <select
              value={customerId}
              onChange={(e) => handleCustomerChange(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
            >
              <option value="walk-in">নগদ ক্রেতা (Walk-in)</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.phone})
                </option>
              ))}
            </select>
          </div>

          {/* Items List */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">চালানের পণ্যসমূহ</label>
            <div className="space-y-2">
              {items.map((item) => (
                <div key={item.productId} className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3 text-xs">
                  <div className="flex-1 min-w-0">
                    <span className="font-bold text-slate-900 block truncate">
                      {item.brand} {item.modelNumber}
                    </span>
                    <span className="text-slate-400 text-[10px]">{item.category}</span>
                  </div>

                  {/* Quantity */}
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleUpdateQty(item.productId, item.quantity - 1)}
                      className="w-5 h-5 rounded bg-white border border-slate-300 font-bold"
                    >
                      -
                    </button>
                    <span className="w-6 text-center font-bold">{item.quantity}</span>
                    <button
                      type="button"
                      onClick={() => handleUpdateQty(item.productId, item.quantity + 1)}
                      className="w-5 h-5 rounded bg-white border border-slate-300 font-bold"
                    >
                      +
                    </button>
                  </div>

                  {/* Price */}
                  <div className="flex items-center gap-1">
                    <span>৳</span>
                    <input
                      type="number"
                      value={item.unitPrice}
                      onChange={(e) => handleUpdatePrice(item.productId, Number(e.target.value) || 0)}
                      className="w-16 px-1.5 py-0.5 rounded border border-slate-200 text-right font-bold"
                    />
                  </div>

                  <span className="font-bold text-slate-900 w-16 text-right">
                    ৳{item.totalPrice}
                  </span>

                  <button
                    type="button"
                    onClick={() => handleUpdateQty(item.productId, 0)}
                    className="text-red-500 hover:text-red-700 p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Discount & Totals */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
            <div className="flex justify-between">
              <span>সাবটোটাল:</span>
              <span className="font-bold">৳{totalSales.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span>ডিসকাউন্ট (৳):</span>
              <input
                type="number"
                value={discount}
                onChange={(e) => setDiscount(e.target.value === '' ? '' : Number(e.target.value))}
                className="w-20 px-2 py-0.5 rounded border border-slate-200 text-right font-bold"
              />
            </div>
            <div className="flex justify-between font-bold text-sm text-slate-900 pt-1 border-t border-slate-200">
              <span>সর্বমোট প্রদেয়:</span>
              <span>৳{finalPayable.toLocaleString()}</span>
            </div>
          </div>

          {/* Payment & Due */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">পরিশোধ মাধ্যম</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-2.5 py-2 rounded-xl border border-slate-200 font-bold"
              >
                <option value="Cash">Cash</option>
                <option value="bKash">bKash</option>
                <option value="Nagad">Nagad</option>
                <option value="Bank">Bank</option>
                <option value="Due">Due</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">জমা / পেইড (৳)</label>
              <input
                type="number"
                value={paidAmount}
                onChange={(e) => setPaidAmount(e.target.value === '' ? '' : Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-xl border border-slate-200 font-bold text-emerald-700"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-100 font-bold text-xs"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/20"
            >
              আপডেট সংরক্ষণ করুন
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
