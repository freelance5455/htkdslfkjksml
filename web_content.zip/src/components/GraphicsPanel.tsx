import React from 'react';
import { GraphicsSettings } from '../types';
import { X, Sliders, Eye, Sparkles, Volume2, VolumeX, Crosshair, Activity } from 'lucide-react';
import { soundEngine } from '../audio/soundEngine';

interface GraphicsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GraphicsSettings;
  onSaveSettings: (newSettings: GraphicsSettings) => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const GraphicsPanel: React.FC<GraphicsPanelProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  isMuted,
  onToggleMute,
}) => {
  if (!isOpen) return null;

  const handlePresetSelect = (preset: GraphicsSettings['preset']) => {
    let updated: GraphicsSettings;
    if (preset === 'low') {
      updated = {
        ...settings,
        preset: 'low',
        particleQuality: 'low',
        bloodDecals: false,
        lightingEffects: false,
        screenShake: 0,
        targetFps: 30,
        damageNumbers: false,
      };
    } else if (preset === 'medium') {
      updated = {
        ...settings,
        preset: 'medium',
        particleQuality: 'medium',
        bloodDecals: true,
        lightingEffects: false,
        screenShake: 0.5,
        targetFps: 60,
        damageNumbers: true,
      };
    } else if (preset === 'high') {
      updated = {
        ...settings,
        preset: 'high',
        particleQuality: 'high',
        bloodDecals: true,
        lightingEffects: true,
        screenShake: 1,
        targetFps: 60,
        damageNumbers: true,
      };
    } else {
      // ultra
      updated = {
        ...settings,
        preset: 'ultra',
        particleQuality: 'high',
        bloodDecals: true,
        lightingEffects: true,
        screenShake: 1,
        targetFps: 120,
        damageNumbers: true,
      };
    }
    onSaveSettings(updated);
  };

  return (
    <div
      id="graphics-panel-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="graphics-panel-modal"
        className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-zinc-900 border border-zinc-700/80 rounded-2xl shadow-2xl overflow-hidden text-zinc-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-red-500/20 text-red-400 border border-red-500/30">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-display uppercase tracking-wider text-zinc-100">
                Grafika va Oʻyin Sozlamalari
              </h2>
              <p className="text-xs text-zinc-400">
                Telefoningiz imkoniyatiga moslashtiring va FPS tezligini oshiring
              </p>
            </div>
          </div>
          <button
            id="graphics-close-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Quick Presets */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-2.5 block">
              Tayyor Rejimlar (Presets)
            </label>
            <div className="grid grid-cols-4 gap-2.5">
              {(['low', 'medium', 'high', 'ultra'] as const).map((preset) => {
                const isSelected = settings.preset === preset;
                const labels = {
                  low: 'Past (30 FPS)',
                  medium: "O'rta (60 FPS)",
                  high: 'Yuqori',
                  ultra: 'Ultra (120 FPS)',
                };
                return (
                  <button
                    key={preset}
                    id={`preset-${preset}-btn`}
                    onClick={() => handlePresetSelect(preset)}
                    className={`py-2.5 px-3 rounded-xl font-bold text-xs uppercase tracking-wider border transition-all ${
                      isSelected
                        ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-950/50'
                        : 'bg-zinc-800/80 hover:bg-zinc-800 border-zinc-700/60 text-zinc-300'
                    }`}
                  >
                    {labels[preset]}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Granular Graphics Controls */}
          <div className="space-y-4">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Kengaytirilgan Vizual Parametrlar
            </h3>

            {/* Particles */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-950/40 border border-zinc-800">
              <div className="flex items-center gap-3">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <div>
                  <div className="text-sm font-semibold">Zarrachalar Sifati (Particles)</div>
                  <div className="text-xs text-zinc-400">Uchqunlar, oʻt va portlash effektlari</div>
                </div>
              </div>
              <div className="flex gap-1">
                {(['low', 'medium', 'high'] as const).map((q) => (
                  <button
                    key={q}
                    id={`particle-${q}-btn`}
                    onClick={() => onSaveSettings({ ...settings, particleQuality: q })}
                    className={`px-3 py-1 text-xs rounded-lg font-medium border ${
                      settings.particleQuality === q
                        ? 'bg-red-500/20 border-red-500 text-red-300'
                        : 'bg-zinc-800 border-transparent text-zinc-400'
                    }`}
                  >
                    {q === 'low' ? 'Kam' : q === 'medium' ? "O'rtacha" : "Ko'p"}
                  </button>
                ))}
              </div>
            </div>

            {/* Blood & Decals */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-950/40 border border-zinc-800">
              <div className="flex items-center gap-3">
                <Activity className="w-4 h-4 text-red-400" />
                <div>
                  <div className="text-sm font-semibold">Qon va Dogʻlar (Blood Decals)</div>
                  <div className="text-xs text-zinc-400">Zoʻmbilar oʻlganda yerdagi qon izlari</div>
                </div>
              </div>
              <button
                id="toggle-blood-btn"
                onClick={() => onSaveSettings({ ...settings, bloodDecals: !settings.bloodDecals })}
                className={`px-4 py-1.5 text-xs font-bold rounded-lg border transition ${
                  settings.bloodDecals
                    ? 'bg-red-600 border-red-500 text-white'
                    : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                }`}
              >
                {settings.bloodDecals ? 'YOQIQ' : "O'CHIQ"}
              </button>
            </div>

            {/* Lighting Effects */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-950/40 border border-zinc-800">
              <div className="flex items-center gap-3">
                <Eye className="w-4 h-4 text-cyan-400" />
                <div>
                  <div className="text-sm font-semibold">Yorugʻlik va Qorongʻulik (Lighting)</div>
                  <div className="text-xs text-zinc-400">Fonar nuri, qorongʻu tun va atmosfera</div>
                </div>
              </div>
              <button
                id="toggle-lighting-btn"
                onClick={() =>
                  onSaveSettings({ ...settings, lightingEffects: !settings.lightingEffects })
                }
                className={`px-4 py-1.5 text-xs font-bold rounded-lg border transition ${
                  settings.lightingEffects
                    ? 'bg-red-600 border-red-500 text-white'
                    : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                }`}
              >
                {settings.lightingEffects ? 'YOQIQ' : "O'CHIQ"}
              </button>
            </div>

            {/* Screen Shake */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-950/40 border border-zinc-800">
              <div>
                <div className="text-sm font-semibold">Ekran Titrashi (Screen Shake)</div>
                <div className="text-xs text-zinc-400">Portlash va zarbalarda ekran silkinishi</div>
              </div>
              <div className="flex gap-1">
                {[0, 0.5, 1].map((val) => (
                  <button
                    key={val}
                    id={`shake-${val}-btn`}
                    onClick={() => onSaveSettings({ ...settings, screenShake: val })}
                    className={`px-3 py-1 text-xs rounded-lg font-medium border ${
                      settings.screenShake === val
                        ? 'bg-red-500/20 border-red-500 text-red-300'
                        : 'bg-zinc-800 border-transparent text-zinc-400'
                    }`}
                  >
                    {val === 0 ? "O'chiq" : val === 0.5 ? '50%' : '100%'}
                  </button>
                ))}
              </div>
            </div>

            {/* Mobile Auto Aim */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-950/40 border border-zinc-800">
              <div className="flex items-center gap-3">
                <Crosshair className="w-4 h-4 text-emerald-400" />
                <div>
                  <div className="text-sm font-semibold">Avtomatik Nishonga Olish (Auto-Aim)</div>
                  <div className="text-xs text-zinc-400">Telefonda nishonga olishni osonlashtirish</div>
                </div>
              </div>
              <button
                id="toggle-autoaim-btn"
                onClick={() => onSaveSettings({ ...settings, autoAim: !settings.autoAim })}
                className={`px-4 py-1.5 text-xs font-bold rounded-lg border transition ${
                  settings.autoAim
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                }`}
              >
                {settings.autoAim ? 'YOQIQ' : "O'CHIQ"}
              </button>
            </div>

            {/* Audio Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-950/40 border border-zinc-800">
              <div className="flex items-center gap-3">
                {isMuted ? (
                  <VolumeX className="w-4 h-4 text-zinc-400" />
                ) : (
                  <Volume2 className="w-4 h-4 text-amber-400" />
                )}
                <div>
                  <div className="text-sm font-semibold">Oʻyin Ovoz Effektlari</div>
                  <div className="text-xs text-zinc-400">Otishmalar, zoʻmbi tovushlari va portlashlar</div>
                </div>
              </div>
              <button
                id="toggle-audio-btn"
                onClick={onToggleMute}
                className={`px-4 py-1.5 text-xs font-bold rounded-lg border transition ${
                  !isMuted
                    ? 'bg-amber-600 border-amber-500 text-white'
                    : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                }`}
              >
                {!isMuted ? 'YOQIQ' : "O'CHIQ"}
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-zinc-800 bg-zinc-950/80 flex justify-end">
          <button
            id="graphics-done-btn"
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm uppercase tracking-wider shadow-lg shadow-red-900/30 transition active:scale-95"
          >
            Tayyor (Saqlash)
          </button>
        </div>
      </div>
    </div>
  );
};
