import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowUp,
  Hexagon,
  Lock,
  LogOut,
  Menu,
  MessageSquare,
  Mic,
  MicOff,
  RotateCcw,
  Smile,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { EmoteId, FaceExpression, FriendProfile, GameStats, LightingPreset, WorldConfig } from '../types/game';
import { EMOTE_LIST, FACE_EXPRESSIONS } from '../data/pickareData';
import { soundEngine } from '../engine/audio';
import { voiceEngine } from '../engine/voice';

interface InGameHudProps {
  world: WorldConfig;
  playerName: string;
  isPlus?: boolean;
  partyMembers?: FriendProfile[];
  stats: GameStats;
  lighting: LightingPreset;
  activeEmote: EmoteId | null;
  unlockedEmotes: EmoteId[];
  faceExpression?: FaceExpression;
  voiceActive: boolean;
  voiceSimulated?: boolean;
  showTouchControls: boolean;
  touchInputRef: React.MutableRefObject<{ moveX: number; moveZ: number; jump: boolean; sprint: boolean }>;
  onToggleVoice: () => void;
  onSelectEmote: (emote: EmoteId | null) => void;
  onSelectExpression?: (expr: FaceExpression) => void;
  onLockedEmote: (label: string) => void;
  onSendChat: (text: string) => void;
  onChangeLighting: (p: LightingPreset) => void;
  onReset: () => void;
  onExitGame: () => void;
}

function formatDuration(totalSeconds: number): string {
  const mins = Math.floor(totalSeconds / 60);
  const secs = Math.floor(totalSeconds % 60);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export const InGameHud: React.FC<InGameHudProps> = ({
  world,
  playerName,
  isPlus = false,
  partyMembers = [],
  stats,
  lighting,
  activeEmote,
  unlockedEmotes,
  faceExpression = 'auto',
  voiceActive,
  voiceSimulated,
  showTouchControls,
  touchInputRef,
  onToggleVoice,
  onSelectEmote,
  onSelectExpression,
  onLockedEmote,
  onSendChat,
  onChangeLighting,
  onReset,
  onExitGame,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [emoteOpen, setEmoteOpen] = useState(false);
  const [exprOpen, setExprOpen] = useState(false);
  const [showChat, setShowChat] = useState(true);
  const [voiceBars, setVoiceBars] = useState<[number, number, number, number, number]>([0.15, 0.2, 0.25, 0.2, 0.15]);
  const [musicOn, setMusicOn] = useState(soundEngine.musicEnabled);
  const [chatLines, setChatLines] = useState<string[]>(() =>
    partyMembers.length > 0
      ? [
          ...partyMembers.slice(-3).map((pm) => `${pm.name} bergabung ke Party Mabar`),
          `${playerName} bergabung (Total ${1 + partyMembers.length} pemain)`,
        ]
      : ['rusia4644 bergabung', 'AIM bergabung', '111 bergabung', `${playerName} bergabung`]
  );
  const [chatDraft, setChatDraft] = useState('');

  useEffect(() => {
    if (!voiceActive) {
      setVoiceBars([0.12, 0.12, 0.12, 0.12, 0.12]);
      return;
    }
    const id = window.setInterval(() => {
      const sample = voiceEngine.sample(0.06);
      setVoiceBars(sample.bars);
    }, 60);
    return () => window.clearInterval(id);
  }, [voiceActive]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.code === 'KeyE') {
        soundEngine.playClick();
        setEmoteOpen((o) => !o);
        return;
      }
      const idx = ['Digit1', 'Digit2', 'Digit3', 'Digit4', 'Digit5', 'Digit6'].indexOf(e.code);
      if (idx !== -1 && EMOTE_LIST[idx]) {
        const chosen = EMOTE_LIST[idx];
        if (!unlockedEmotes.includes(chosen.id)) {
          onLockedEmote(chosen.label);
          return;
        }
        onSelectEmote(activeEmote === chosen.id ? null : chosen.id);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeEmote, unlockedEmotes, onSelectEmote, onLockedEmote]);

  const toggleMusic = () => {
    const next = !musicOn;
    setMusicOn(next);
    soundEngine.setMusicEnabled(next);
  };

  const sendChat = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = chatDraft.trim();
    if (!msg) return;
    setChatLines((prev) => [...prev.slice(-4), `${playerName}: ${msg}`]);
    onSendChat(msg);
    setChatDraft('');
  };

  return (
    <>
      {/* Top In-Game Bar */}
      <div className="pointer-events-none absolute top-3 inset-x-3 z-20 flex items-center justify-between gap-3">
        <div className="pointer-events-auto flex items-center gap-2">
          <motion.button
            whileTap={{ scale: 0.92 }}
            type="button"
            onClick={() => {
              soundEngine.playClick();
              setMenuOpen((o) => !o);
            }}
            aria-label="Menu Game"
            className="w-10 h-10 rounded-full bg-zinc-950/92 border border-white/25 text-white flex items-center justify-center hover:bg-zinc-800 cursor-pointer shadow-lg"
          >
            <Hexagon className="w-5 h-5" />
          </motion.button>

          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-zinc-950/92 border border-white/25 text-white shadow-lg">
            <button
              type="button"
              onClick={() => {
                soundEngine.playClick();
                setMenuOpen((o) => !o);
              }}
              aria-label="Buka Opsi"
              className="p-1 hover:text-zinc-300 cursor-pointer"
            >
              <Menu className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setShowChat((c) => !c)}
              aria-label="Tampilkan Chat"
              className={`p-1 cursor-pointer ${showChat ? 'text-white' : 'text-zinc-500'}`}
            >
              <MessageSquare className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => {
                soundEngine.playClick();
                onToggleVoice();
              }}
              aria-label="Voice Chat"
              title={voiceActive ? 'Matikan Voice Chat' : 'Nyalakan Voice Chat'}
              className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full cursor-pointer transition-colors ${
                voiceActive ? 'bg-emerald-500 text-black font-bold' : 'text-zinc-500 hover:text-zinc-200'
              }`}
            >
              {voiceActive ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
              {voiceActive && (
                <span className="inline-flex items-end gap-0.5 h-3.5" aria-hidden="true">
                  {voiceBars.map((bar, idx) => (
                    <span
                      key={idx}
                      style={{ height: `${Math.max(22, Math.round(bar * 100))}%` }}
                      className="w-0.5 rounded-full bg-black transition-all duration-75"
                    />
                  ))}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={toggleMusic}
              aria-label="Backsound Musik"
              title={musicOn ? 'Matikan Backsound' : 'Nyalakan Backsound'}
              className={`p-1 cursor-pointer ${musicOn ? 'text-white' : 'text-zinc-500'}`}
            >
              {musicOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={() => {
                soundEngine.playClick();
                setExprOpen(false);
                setEmoteOpen((o) => !o);
              }}
              aria-label="Emote"
              className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold cursor-pointer transition-colors ${
                emoteOpen || activeEmote ? 'bg-white text-black' : 'bg-zinc-800 text-white hover:bg-zinc-700'
              }`}
            >
              <Smile className="w-3.5 h-3.5" />
              <span>Emote</span>
            </button>
            {onSelectExpression && (
              <button
                type="button"
                onClick={() => {
                  soundEngine.playClick();
                  setEmoteOpen(false);
                  setExprOpen((o) => !o);
                }}
                aria-label="Ekspresi Wajah"
                className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold cursor-pointer transition-colors ${
                  exprOpen || faceExpression !== 'auto'
                    ? 'bg-white text-black'
                    : 'bg-zinc-800 text-white hover:bg-zinc-700'
                }`}
              >
                <span>Ekspresi</span>
              </button>
            )}
          </div>

          {voiceActive && (
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-950/92 border border-emerald-400/50 text-white shadow-lg">
              <Mic className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="text-[11px] font-bold text-emerald-300 whitespace-nowrap">
                {voiceSimulated ? 'Voice Demo' : 'Voice Live'}
              </span>
              <div className="flex items-end gap-0.5 h-4">
                {voiceBars.map((bar, idx) => (
                  <div
                    key={idx}
                    style={{ height: `${Math.max(20, Math.round(bar * 100))}%` }}
                    className="w-1 rounded-full bg-emerald-400 transition-all duration-75"
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Center Health Bar */}
        <div className="hidden sm:flex items-center justify-center w-48 h-6 rounded-full bg-zinc-950/90 border border-white/25 overflow-hidden relative shadow">
          <div
            style={{ width: `${stats.health}%` }}
            className="h-full bg-white transition-all duration-150"
          />
          <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-zinc-900 mix-blend-difference font-mono-num">
            {stats.health}
          </span>
        </div>

        {/* Right Online / Party Mabar Players */}
        <div className="pointer-events-auto flex items-center gap-2">
          {isPlus && (
            <span className="px-2.5 py-1.5 rounded-full bg-amber-300 text-black text-[11px] font-black shadow whitespace-nowrap">
              SLAPBOX+
            </span>
          )}
          <div className="px-3.5 py-1.5 rounded-full bg-white text-black text-xs font-bold shadow whitespace-nowrap">
            {partyMembers.length > 0
              ? `Party Mabar · ${1 + partyMembers.length} pemain`
              : `Online · ${Math.max(4, world.activePlayers)} pemain`}
          </div>
        </div>
      </div>

      {/* Emote Picker Tray */}
      <AnimatePresence>
        {emoteOpen && (
          <motion.div
            initial={{ y: -12, opacity: 0, scale: 0.96 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: -10, opacity: 0, scale: 0.96 }}
            transition={{ duration: 0.16 }}
            className="pointer-events-auto absolute top-16 left-1/2 -translate-x-1/2 z-30 flex flex-wrap items-center justify-center gap-1.5 px-3 py-2 rounded-2xl bg-zinc-950/95 border border-white/20 shadow-2xl max-w-[92vw]"
          >
            {EMOTE_LIST.map((em) => {
              const unlocked = unlockedEmotes.includes(em.id);
              const active = activeEmote === em.id;
              return (
                <button
                  key={em.id}
                  type="button"
                  onClick={() => {
                    if (!unlocked) {
                      onLockedEmote(em.label);
                      return;
                    }
                    onSelectEmote(active ? null : em.id);
                    setEmoteOpen(false);
                  }}
                  className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                    !unlocked
                      ? 'bg-zinc-900 text-zinc-500 border border-zinc-800'
                      : active
                      ? 'bg-white text-black'
                      : 'bg-zinc-800 hover:bg-zinc-700 text-white'
                  }`}
                >
                  {!unlocked && <Lock className="w-3 h-3" />}
                  <span className="opacity-60 font-mono-num">[{em.key}]</span>
                  <span>{em.label}</span>
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Face Expression Picker Tray */}
      <AnimatePresence>
        {exprOpen && onSelectExpression && (
          <motion.div
            initial={{ y: -12, opacity: 0, scale: 0.96 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: -10, opacity: 0, scale: 0.96 }}
            transition={{ duration: 0.16 }}
            className="pointer-events-auto absolute top-16 left-1/2 -translate-x-1/2 z-30 flex flex-wrap items-center justify-center gap-1.5 px-3 py-2 rounded-2xl bg-zinc-950/95 border border-white/20 shadow-2xl max-w-[92vw]"
          >
            {FACE_EXPRESSIONS.map((fe) => {
              const active = faceExpression === fe.id;
              return (
                <button
                  key={fe.id}
                  type="button"
                  onClick={() => {
                    onSelectExpression(fe.id);
                    setExprOpen(false);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                    active ? 'bg-white text-black' : 'bg-zinc-800 hover:bg-zinc-700 text-white'
                  }`}
                >
                  {fe.short}
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Left System Chat Log + Stats */}
      {showChat && (
        <div className="pointer-events-none absolute top-16 left-4 z-10 max-w-xs space-y-1.5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-zinc-950/85 text-xs font-mono-num text-white border border-white/15">
            <span>Tahap {stats.stage}/{stats.totalStages}</span>
            <span>·</span>
            <span>Koin {stats.coins}/{stats.totalCoins}</span>
            <span>·</span>
            <span className="text-zinc-300">{formatDuration(stats.elapsedSeconds)}</span>
          </div>
          <div className="space-y-0.5 text-xs font-semibold text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)]">
            {chatLines.map((line, i) => (
              <div key={i}>{line}</div>
            ))}
          </div>
          <form onSubmit={sendChat} className="pointer-events-auto flex gap-1.5 pt-1">
            <input
              type="text"
              value={chatDraft}
              onChange={(e) => setChatDraft(e.target.value)}
              placeholder="Ketik pesan di atas kepala..."
              className="w-44 sm:w-52 px-2.5 py-1 rounded-lg bg-zinc-950/90 border border-white/25 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-white"
            />
            <button
              type="submit"
              className="px-2.5 py-1 rounded-lg bg-white hover:bg-zinc-200 text-black text-xs font-bold cursor-pointer"
            >
              Kirim
            </button>
          </form>
        </div>
      )}

      {/* Pause / Menu Overlay */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ x: -16, opacity: 0, scale: 0.96 }}
            animate={{ x: 0, opacity: 1, scale: 1 }}
            exit={{ x: -16, opacity: 0, scale: 0.96 }}
            transition={{ duration: 0.16 }}
            className="absolute top-16 left-3 z-30 w-64 rounded-2xl bg-zinc-950/95 border border-white/20 p-4 space-y-3 shadow-2xl"
          >
            <div className="font-display font-bold text-sm text-white">{world.name}</div>
            <div className="space-y-1.5">
              <div className="text-[11px] text-zinc-400">Suasana Langit</div>
              <div className="grid grid-cols-3 gap-1">
                {(['day', 'sunset', 'night'] as LightingPreset[]).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => onChangeLighting(p)}
                    className={`py-1.5 text-[11px] font-semibold rounded cursor-pointer ${
                      lighting === p ? 'bg-white text-black' : 'bg-zinc-900 text-zinc-300 border border-white/10'
                    }`}
                  >
                    {p === 'day' ? 'Siang' : p === 'sunset' ? 'Senja' : 'Malam'}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={toggleMusic}
              className="w-full inline-flex items-center justify-center gap-2 py-2 rounded-xl bg-zinc-900 border border-white/15 hover:bg-zinc-800 text-xs font-semibold text-white cursor-pointer"
            >
              {musicOn ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              Backsound: {musicOn ? 'Nyala' : 'Mati'}
            </button>

            <button
              type="button"
              onClick={() => {
                onReset();
                setMenuOpen(false);
              }}
              className="w-full inline-flex items-center justify-center gap-2 py-2 rounded-xl bg-zinc-900 border border-white/15 hover:bg-zinc-800 text-xs font-semibold text-white cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Karakter
            </button>
            <button
              type="button"
              onClick={onExitGame}
              className="w-full inline-flex items-center justify-center gap-2 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-white cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              Keluar ke Beranda
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Victory Banner */}
      <AnimatePresence>
        {stats.completed && (
          <motion.div
            initial={{ y: -24, opacity: 0, scale: 0.92 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="absolute top-24 left-1/2 -translate-x-1/2 z-30 w-[min(380px,92vw)] rounded-2xl bg-zinc-950/95 border border-white/30 p-6 text-center shadow-2xl"
          >
            <h2 className="font-display text-2xl font-extrabold text-white">Puncak Tercapai!</h2>
            <p className="mt-1 text-xs text-zinc-300 font-mono-num">
              Waktu {formatDuration(stats.elapsedSeconds)} · Koin {stats.coins}/{stats.totalCoins} · +500 Slapbux
            </p>
            <div className="mt-4 flex gap-2.5 justify-center">
              <button
                type="button"
                onClick={onReset}
                className="px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
              >
                Main Lagi
              </button>
              <button
                type="button"
                onClick={onExitGame}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-white cursor-pointer"
              >
                Beranda
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* On-screen Joystick + Jump Button */}
      {showTouchControls && (
        <div className="pointer-events-none absolute inset-x-5 bottom-6 z-20 flex items-end justify-between">
          <div className="pointer-events-auto grid grid-cols-3 gap-1 w-32 h-32 rounded-full bg-zinc-950/70 border border-white/25 p-2.5">
            <div />
            <button
              type="button"
              aria-label="Maju"
              onPointerDown={() => { touchInputRef.current.moveZ = -1; }}
              onPointerUp={() => { touchInputRef.current.moveZ = 0; }}
              onPointerLeave={() => { touchInputRef.current.moveZ = 0; }}
              className="rounded-lg bg-white/25 active:bg-white/60 text-white font-bold text-xs"
            >
              ▲
            </button>
            <div />
            <button
              type="button"
              aria-label="Kiri"
              onPointerDown={() => { touchInputRef.current.moveX = -1; }}
              onPointerUp={() => { touchInputRef.current.moveX = 0; }}
              onPointerLeave={() => { touchInputRef.current.moveX = 0; }}
              className="rounded-lg bg-white/25 active:bg-white/60 text-white font-bold text-xs"
            >
              ◀
            </button>
            <div className="rounded-full bg-white/40" />
            <button
              type="button"
              aria-label="Kanan"
              onPointerDown={() => { touchInputRef.current.moveX = 1; }}
              onPointerUp={() => { touchInputRef.current.moveX = 0; }}
              onPointerLeave={() => { touchInputRef.current.moveX = 0; }}
              className="rounded-lg bg-white/25 active:bg-white/60 text-white font-bold text-xs"
            >
              ▶
            </button>
            <div />
            <button
              type="button"
              aria-label="Mundur"
              onPointerDown={() => { touchInputRef.current.moveZ = 1; }}
              onPointerUp={() => { touchInputRef.current.moveZ = 0; }}
              onPointerLeave={() => { touchInputRef.current.moveZ = 0; }}
              className="rounded-lg bg-white/25 active:bg-white/60 text-white font-bold text-xs"
            >
              ▼
            </button>
            <div />
          </div>

          <button
            type="button"
            aria-label="Lompat"
            onPointerDown={() => { touchInputRef.current.jump = true; }}
            className="pointer-events-auto w-20 h-20 rounded-full bg-zinc-950/75 active:bg-white active:text-black border-2 border-white/60 text-white flex items-center justify-center shadow-lg"
          >
            <ArrowUp className="w-8 h-8" />
          </button>
        </div>
      )}

      {/* Bottom Controls Legend */}
      <div className="pointer-events-none hidden md:block absolute bottom-3 left-1/2 -translate-x-1/2 z-10 px-3.5 py-1 rounded-full bg-zinc-950/85 border border-white/15 text-[11px] text-zinc-200 whitespace-nowrap">
        WASD / Panah: Gerak · Spasi: Lompat · E / 1-6: Emote · Seret Mouse: Kamera
      </div>
    </>
  );
};
