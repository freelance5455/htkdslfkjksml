import { bostaMessages, bostaTotals, BROWS, copyText } from "@/lib/hub/domain";
import { useHub } from "@/components/hub/provider";
import { Button, Card } from "@/components/hub/ui";
import { cn } from "@/lib/cn";

export function BostaTab() {
  const hub = useHub();
  const b = hub.bosta;
  const totals = bostaTotals(b);
  const msgs = bostaMessages(b);

  const copy = async (text: string) => {
    const ok = await copyText(text);
    hub.notify(ok ? "কপি হয়েছে" : "মেসেজটি সিলেক্ট করে কপি করুন");
  };

  return (
    <div className="flex flex-col gap-3">
      <p className="text-sm text-muted">লেন অনুযায়ী ইন ও আউট। নিচের মেসেজে স্টোর যোগ হয়, টেবিলের মোটে শুধু লেন।</p>
      <label className="block max-w-xs">
        <span className="mb-1.5 block text-xs font-medium text-muted">তারিখ</span>
        <input className="field" type="date" value={b.date} onChange={(e) => hub.setBostaDate(e.target.value)} />
      </label>

      <Card className="px-3 py-3">
        <div className="lanes px-1 pb-2 text-xs font-semibold text-muted">
          <span>লেন</span>
          <span className="text-right">ইন</span>
          <span className="text-right">আউট</span>
        </div>
        <div className="flex flex-col">
          {BROWS.map((name) => {
            const row = b.r[name] || {};
            const quiet = !row.i && !row.o;
            return (
              <div key={name} className={cn("lanes border-t border-line py-1.5", quiet && "text-muted")}>
                <span className="truncate text-sm font-medium">{name}</span>
                <input
                  className="field h-11 text-right tabular-nums"
                  inputMode="numeric"
                  aria-label={`${name} in`}
                  value={row.i || ""}
                  onChange={(e) => hub.setLane(name, "i", e.target.value)}
                />
                <input
                  className="field h-11 text-right tabular-nums"
                  inputMode="numeric"
                  aria-label={`${name} out`}
                  value={row.o || ""}
                  onChange={(e) => hub.setLane(name, "o", e.target.value)}
                />
              </div>
            );
          })}
          <div className="lanes border-t border-line py-1.5">
            <span className="text-sm font-medium">Store in</span>
            <input
              className="field h-11 text-right tabular-nums"
              inputMode="numeric"
              aria-label="Store in"
              value={b.store}
              onChange={(e) => hub.setStore(e.target.value)}
            />
            <span />
          </div>
          <div className="lanes border-t-2 border-ink py-3 text-base font-semibold">
            <span>মোট</span>
            <b className="text-right tabular-nums">{totals.i}</b>
            <b className="text-right tabular-nums">{totals.o}</b>
          </div>
        </div>
      </Card>

      <Button
        variant="ghost"
        size="lg"
        onClick={async () => {
          if (await hub.confirm("সব সংখ্যা মুছে নতুন দিন শুরু করবেন?")) hub.resetBosta();
        }}
      >
        নতুন করুন
      </Button>

      <Message title="হাবে বস্তা এসেছে" text={msgs.inn} onCopy={() => copy(msgs.inn)} />
      <Message title="হাব থেকে বস্তা পাঠানো হয়েছে" text={msgs.out} onCopy={() => copy(msgs.out)} />
    </div>
  );
}

function Message({ title, text, onCopy }: { title: string; text: string; onCopy: () => void }) {
  return (
    <Card>
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold">{title}</h2>
      </div>
      <Button className="mt-3 w-full" size="lg" onClick={onCopy}>
        কপি করুন
      </Button>
      <pre className="mt-3 whitespace-pre-wrap break-words rounded-md bg-elevated p-3 font-sans text-sm leading-relaxed">
        {text}
      </pre>
    </Card>
  );
}
