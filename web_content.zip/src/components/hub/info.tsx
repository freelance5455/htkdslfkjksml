import { useState, type ReactNode } from "react";
import { ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import { copyText, makeBackup } from "@/lib/hub/domain";
import { useHub } from "@/components/hub/provider";
import { Button, Card } from "@/components/hub/ui";

export function InfoTab() {
  const hub = useHub();
  const [backup, setBackup] = useState("");
  const [open, setOpen] = useState(true);

  return (
    <div className="flex flex-col gap-3">
      <div className="flex justify-end">
        <Button variant="ghost" size="sm" onClick={hub.toggleInfoEdit}>
          {hub.infoEdit ? "সম্পাদনা শেষ" : "সম্পাদনা"}
        </Button>
      </div>

      {hub.info.length === 0 ? (
        <Card>
          <p className="text-sm text-muted">কোনো তথ্য নেই। সম্পাদনা চেপে নতুন কার্ড যোগ করুন — নাম, নম্বর, আইডি।</p>
        </Card>
      ) : null}

      {hub.info.map((card, i) =>
        hub.infoEdit ? (
          <Card key={i}>
            <input
              className="field"
              value={card.t}
              placeholder="শিরোনাম"
              aria-label="শিরোনাম"
              onChange={(e) => hub.setInfoCard(i, { t: e.target.value })}
            />
            <textarea
              className="field mt-2"
              rows={Math.max(3, card.b.split("\n").length)}
              value={card.b}
              placeholder="বিবরণ (নাম, নম্বর, আইডি)"
              aria-label="বিবরণ"
              onChange={(e) => hub.setInfoCard(i, { b: e.target.value })}
            />
            <div className="mt-3 flex gap-2">
              <span className="mr-auto" />
              <Button variant="ghost" size="icon" aria-label="উপরে নিন" disabled={i === 0} onClick={() => hub.moveInfo(i, -1)}>
                <ChevronUp className="size-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                aria-label="নিচে নিন"
                disabled={i === hub.info.length - 1}
                onClick={() => hub.moveInfo(i, 1)}
              >
                <ChevronDown className="size-4" />
              </Button>
              <Button
                variant="danger"
                size="icon"
                aria-label="মুছুন"
                onClick={async () => {
                  if (await hub.confirm("এই কার্ডটি মুছে ফেলবেন?")) hub.removeInfo(i);
                }}
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
          </Card>
        ) : (
          <Card key={i}>
            <div className="flex items-start justify-between gap-3">
              <h2 className="font-semibold">{card.t}</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={async () => {
                  const ok = await copyText(`${card.t ? `${card.t}\n` : ""}${card.b}`);
                  hub.notify(ok ? "কপি হয়েছে" : "কপি করা যায়নি");
                }}
              >
                কপি
              </Button>
            </div>
            <RichText text={card.b} />
          </Card>
        ),
      )}

      {hub.infoEdit ? (
        <Button variant="ghost" size="lg" className="w-full border-dashed" onClick={hub.addInfo}>
          নতুন কার্ড যোগ করুন
        </Button>
      ) : null}

      <Card>
        <button type="button" className="flex w-full items-center justify-between text-left font-semibold" onClick={() => setOpen((v) => !v)}>
          ব্যাকআপ ও রিস্টোর
          <span className="text-sm font-medium text-muted">{open ? "বন্ধ" : "খুলুন"}</span>
        </button>
        {open ? (
          <div className="mt-3">
            <p className="text-sm text-muted">
              ড্রাইভার, হেলপার, গাড়ির নম্বর আর তথ্য কার্ড একটা কোডে কপি করে রাখুন। নতুন ফোনে পেস্ট করে রিস্টোর করুন।
            </p>
            <Button
              className="mt-3"
              onClick={async () => {
                const code = makeBackup(hub.info, hub.lists);
                setBackup(code);
                const ok = await copyText(code);
                hub.notify(ok ? "কপি হয়েছে" : "কপি করা যায়নি");
              }}
            >
              ব্যাকআপ কপি করুন
            </Button>
            <textarea
              className="field mt-3"
              rows={4}
              value={backup}
              placeholder="ব্যাকআপ কোড এখানে পেস্ট করুন"
              onChange={(e) => setBackup(e.target.value)}
            />
            <Button
              className="mt-3"
              onClick={async () => {
                const okAsk = await hub.confirm(
                  "রিস্টোর করলে Info কার্ড ব্যাকআপের মতো হবে, আর Driver, Helper, Gari নম্বর আগেরগুলোর সাথে যোগ হবে। সম্মত?",
                );
                if (!okAsk) return;
                const result = hub.restoreBackup(backup);
                if (!result.ok) {
                  hub.notify(result.error);
                  return;
                }
                hub.notify(result.summary);
              }}
            >
              রিস্টোর করুন
            </Button>
          </div>
        ) : null}
      </Card>
    </div>
  );
}

function RichText({ text }: { text: string }) {
  const re = /01[\d-]{9,12}/g;
  const nodes: ReactNode[] = [];
  let last = 0;
  let match: RegExpExecArray | null;
  let k = 0;
  while ((match = re.exec(text))) {
    const digits = match[0].replace(/-/g, "");
    if (digits.length !== 11) continue;
    if (match.index > last) nodes.push(text.slice(last, match.index));
    nodes.push(
      <a key={k++} href={`tel:${digits}`} className="font-semibold text-yes">
        {match[0]}
      </a>,
    );
    last = match.index + match[0].length;
  }
  nodes.push(text.slice(last));
  return <div className="mt-2 whitespace-pre-wrap break-words text-sm leading-relaxed">{nodes}</div>;
}
