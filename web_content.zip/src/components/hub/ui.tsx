import { cva, type VariantProps } from "class-variance-authority";
import { type ButtonHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/cn";

const buttonStyles = cva(
  "press inline-flex touch-manipulation items-center justify-center gap-2 rounded-md font-semibold transition-[background-color,color,border-color,opacity] duration-150 disabled:pointer-events-none disabled:opacity-40",
  {
    variants: {
      variant: {
        primary: "border border-transparent bg-accent text-accent-ink",
        ghost: "border border-line bg-transparent text-ink",
        danger: "border border-no bg-transparent text-no",
        quiet: "border border-transparent bg-transparent text-muted",
      },
      size: {
        md: "h-11 px-4 text-sm",
        lg: "h-12 px-4 text-base",
        sm: "h-9 px-3 text-sm",
        icon: "size-11",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonStyles>;

export function Button({ className, variant, size, type = "button", ...props }: ButtonProps) {
  return <button type={type} className={cn(buttonStyles({ variant, size }), className)} {...props} />;
}

export function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-1.5 block text-xs font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-xl border border-line bg-surface p-4", className)}>{children}</section>
  );
}

export function SectionTitle({ children }: { children: ReactNode }) {
  return <h2 className="text-sm font-semibold tracking-tight text-ink">{children}</h2>;
}

export function Choice({
  pressed,
  tone,
  children,
  onClick,
}: {
  pressed: boolean;
  tone: "yes" | "no";
  children: ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onClick}
      className={cn(
        "press h-12 flex-1 rounded-md border text-base font-semibold transition-[background-color,color,border-color] duration-150",
        pressed && tone === "yes" && "border-yes bg-yes-bg text-yes",
        pressed && tone === "no" && "border-no bg-no-bg text-no",
        !pressed && "border-line bg-transparent text-ink",
      )}
    >
      {children}
    </button>
  );
}
