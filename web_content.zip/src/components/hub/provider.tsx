import {
  createContext,
  use,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  addCars,
  addPeople,
  defaultQuestions,
  emptyGari,
  KEYS,
  loadBosta,
  loadChecklist,
  loadDuty,
  loadGari,
  loadImages,
  loadInfo,
  loadLists,
  loadTab,
  loadTheme,
  mergeLists,
  operationalToday,
  parseBackup,
  rememberCar,
  shrinkImage,
  uid,
  withUpsert,
  writeJSON,
  type Answer,
  type BostaState,
  type ChecklistState,
  type DutyStore,
  type GariState,
  type ImageMap,
  type InfoCard,
  type Lists,
  type TabId,
  type ThemeMode,
} from "@/lib/hub/domain";

type ConfirmState = { message: string; resolve: (ok: boolean) => void } | null;

type HubContextValue = {
  ready: boolean;
  tab: TabId;
  setTab: (tab: TabId) => void;
  theme: ThemeMode;
  toggleTheme: () => void;
  checklist: ChecklistState;
  checkEdit: boolean;
  toggleCheckEdit: () => void;
  setCheckDate: (value: string) => void;
  setCheckTime: (value: string) => void;
  setAnswer: (id: string, value: Answer) => void;
  setQuestionText: (id: string, text: string) => void;
  setQuestionCritical: (id: string, critical: boolean) => void;
  moveQuestion: (id: string, dir: -1 | 1) => void;
  removeQuestion: (id: string) => void;
  addQuestion: () => void;
  restoreQuestions: () => void;
  resetChecklist: () => void;
  bosta: BostaState;
  setBostaDate: (value: string) => void;
  setLane: (name: string, key: "i" | "o", value: string) => void;
  setStore: (value: string) => void;
  resetBosta: () => void;
  gari: GariState;
  setGariField: (key: keyof GariState, value: string) => void;
  setGariCrew: (who: "d" | "h", person: { n: string; i: string; p: string }) => void;
  resetGari: () => void;
  rememberCrew: () => void;
  lists: Lists;
  addBulk: (key: "d" | "h" | "c", text: string) => number;
  removeListItem: (key: "d" | "h" | "c", index: number) => void;
  info: InfoCard[];
  infoEdit: boolean;
  toggleInfoEdit: () => void;
  setInfoCard: (index: number, patch: Partial<InfoCard>) => void;
  moveInfo: (index: number, dir: -1 | 1) => void;
  removeInfo: (index: number) => void;
  addInfo: () => void;
  restoreBackup: (raw: string) => { ok: true; summary: string } | { ok: false; error: string };
  duty: DutyStore;
  dutyDate: string;
  setDutyDate: (value: string) => void;
  shiftDuty: (days: number) => void;
  jumpToday: () => void;
  saveDutyMonth: (month: string, a: string, b: string) => void;
  deleteDutyMonth: (month: string) => boolean;
  images: ImageMap;
  setImageFile: (slot: "1" | "2", file: File) => Promise<string | null>;
  clearImage: (slot: "1" | "2") => void;
  toast: string;
  notify: (message: string) => void;
  confirm: (message: string) => Promise<boolean>;
  confirmState: ConfirmState;
  closeConfirm: (ok: boolean) => void;
};

const HubContext = createContext<HubContextValue | null>(null);

export function useHub() {
  const ctx = use(HubContext);
  if (!ctx) throw new Error("Hub context missing");
  return ctx;
}

const blankCheck = (): ChecklistState => ({ date: "", time: "", qs: [] });

export function HubProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [tab, setTabState] = useState<TabId>("p1");
  const [theme, setTheme] = useState<ThemeMode>("dark");
  const [checklist, setChecklist] = useState<ChecklistState>(blankCheck);
  const [bosta, setBosta] = useState<BostaState>({ date: "", r: {}, store: "" });
  const [gari, setGari] = useState<GariState>(emptyGari());
  const [lists, setLists] = useState<Lists>({ d: [], h: [], c: [] });
  const [info, setInfo] = useState<InfoCard[]>([]);
  const [duty, setDuty] = useState<DutyStore>({});
  const [images, setImages] = useState<ImageMap>({});
  const [dutyDate, setDutyDate] = useState("");
  const [checkEdit, setCheckEdit] = useState(false);
  const [infoEdit, setInfoEdit] = useState(false);
  const [toast, setToast] = useState("");
  const [confirmState, setConfirmState] = useState<ConfirmState>(null);
  const toastTimer = useRef(0);

  useLayoutEffect(() => {
    const today = operationalToday();
    setChecklist(loadChecklist());
    setBosta(loadBosta());
    setGari(loadGari());
    setLists(loadLists());
    setInfo(loadInfo());
    setDuty(loadDuty());
    setImages(loadImages());
    setTabState(loadTab());
    setTheme(loadTheme());
    setDutyDate(today);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    writeJSON(KEYS.check, checklist);
  }, [ready, checklist]);
  useEffect(() => {
    if (!ready) return;
    writeJSON(KEYS.bosta, bosta);
  }, [ready, bosta]);
  useEffect(() => {
    if (!ready) return;
    writeJSON(KEYS.gari, gari);
  }, [ready, gari]);
  useEffect(() => {
    if (!ready) return;
    writeJSON(KEYS.lists, lists);
  }, [ready, lists]);
  useEffect(() => {
    if (!ready) return;
    writeJSON(KEYS.info, info);
  }, [ready, info]);
  useEffect(() => {
    if (!ready) return;
    writeJSON(KEYS.duty, duty);
  }, [ready, duty]);
  useEffect(() => {
    if (!ready) return;
    writeJSON(KEYS.images, images);
  }, [ready, images]);
  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(KEYS.tab, tab);
  }, [ready, tab]);
  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(KEYS.theme, theme);
    document.documentElement.dataset.theme = theme;
  }, [ready, theme]);

  useEffect(() => {
    if (!ready) return;
    const sync = () => {
      const a = operationalToday();
      const next = (o: { date: string; dm?: string; da?: string }) => {
        const d = o.dm && o.da === a ? o.dm : a;
        return d === o.date ? o.date : d;
      };
      setChecklist((s) => {
        const d = next(s);
        return d === s.date ? s : { ...s, date: d };
      });
      setBosta((s) => {
        const d = next(s);
        return d === s.date ? s : { ...s, date: d };
      });
      setGari((s) => {
        const d = next(s);
        return d === s.date ? s : { ...s, date: d };
      });
    };
    const id = window.setInterval(sync, 60_000);
    const onVis = () => {
      if (!document.hidden) sync();
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("focus", sync);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("focus", sync);
    };
  }, [ready]);

  const notify = (message: string) => {
    setToast(message);
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 2200);
  };

  const confirm = (message: string) =>
    new Promise<boolean>((resolve) => {
      setConfirmState({ message, resolve });
    });

  const closeConfirm = (ok: boolean) => {
    confirmState?.resolve(ok);
    setConfirmState(null);
  };

  const stamp = (value: string) => ({ dm: value, da: operationalToday() });

  const value: HubContextValue = {
    ready,
    tab,
    setTab: setTabState,
    theme,
    toggleTheme: () => setTheme((t) => (t === "dark" ? "light" : "dark")),
    checklist,
    checkEdit,
    toggleCheckEdit: () => {
      if (checkEdit) {
        setChecklist((s) => ({ ...s, qs: s.qs.filter((q) => q.t.trim()) }));
      }
      setCheckEdit((v) => !v);
    },
    setCheckDate: (date) => setChecklist((s) => ({ ...s, date, ...stamp(date) })),
    setCheckTime: (time) => setChecklist((s) => ({ ...s, time })),
    setAnswer: (id, v) =>
      setChecklist((s) => ({
        ...s,
        qs: s.qs.map((q) => (q.id === id ? { ...q, v: q.v === v ? "" : v } : q)),
      })),
    setQuestionText: (id, t) =>
      setChecklist((s) => ({ ...s, qs: s.qs.map((q) => (q.id === id ? { ...q, t } : q)) })),
    setQuestionCritical: (id, c) =>
      setChecklist((s) => ({ ...s, qs: s.qs.map((q) => (q.id === id ? { ...q, c } : q)) })),
    moveQuestion: (id, dir) =>
      setChecklist((s) => {
        const i = s.qs.findIndex((q) => q.id === id);
        const j = i + dir;
        if (i < 0 || j < 0 || j >= s.qs.length) return s;
        const qs = s.qs.slice();
        const a = qs[i]!;
        const b = qs[j]!;
        qs[i] = b;
        qs[j] = a;
        return { ...s, qs };
      }),
    removeQuestion: (id) => setChecklist((s) => ({ ...s, qs: s.qs.filter((q) => q.id !== id) })),
    addQuestion: () =>
      setChecklist((s) => ({ ...s, qs: [...s.qs, { id: uid(), t: "", c: false, v: "" }] })),
    restoreQuestions: () => setChecklist((s) => ({ ...s, qs: defaultQuestions() })),
    resetChecklist: () =>
      setChecklist((s) => ({
        ...s,
        qs: s.qs.map((q) => ({ ...q, v: "" })),
        dm: "",
        da: "",
        date: operationalToday(),
        time: "",
      })),
    bosta,
    setBostaDate: (date) => setBosta((s) => ({ ...s, date, ...stamp(date) })),
    setLane: (name, key, raw) =>
      setBosta((s) => {
        const value = raw.replace(/[^\d]/g, "").slice(0, 6);
        return { ...s, r: { ...s.r, [name]: { ...s.r[name], [key]: value } } };
      }),
    setStore: (raw) => setBosta((s) => ({ ...s, store: raw.replace(/[^\d]/g, "").slice(0, 6) })),
    resetBosta: () => setBosta({ date: operationalToday(), r: {}, store: "" }),
    gari,
    setGariField: (key, raw) =>
      setGari((s) => {
        if (key === "dp" || key === "hp" || key === "car") {
          return { ...s, [key]: awaitFormat(key, raw) };
        }
        if (key === "b" || key === "big" || key === "tq") {
          return { ...s, [key]: raw.replace(/[^\d]/g, "").slice(0, 6) };
        }
        if (key === "date") return { ...s, date: raw, ...stamp(raw) };
        return { ...s, [key]: raw };
      }),
    setGariCrew: (who, person) =>
      setGari((s) =>
        who === "d"
          ? { ...s, dn: person.n, di: person.i, dp: person.p }
          : { ...s, hn: person.n, hi: person.i, hp: person.p },
      ),
    resetGari: () =>
      setGari((s) => ({ ...emptyGari(s.date), date: s.date, dm: s.dm, da: s.da })),
    rememberCrew: () =>
      setLists((prev) => ({
        d: withUpsert(prev.d, gari.dn, gari.di, gari.dp),
        h: withUpsert(prev.h, gari.hn, gari.hi, gari.hp),
        c: rememberCar(prev.c, gari.car),
      })),
    lists,
    addBulk: (key, text) => {
      if (key === "c") {
        const result = addCars(lists.c, text);
        if (result.count) setLists((s) => ({ ...s, c: result.list }));
        return result.count;
      }
      const source = key === "d" ? lists.d : lists.h;
      const result = addPeople(source, text);
      if (result.count) setLists((s) => ({ ...s, [key]: result.list }));
      return result.count;
    },
    removeListItem: (key, index) =>
      setLists((s) => ({ ...s, [key]: s[key].filter((_, i) => i !== index) })),
    info,
    infoEdit,
    toggleInfoEdit: () => {
      if (infoEdit) setInfo((cards) => cards.filter((c) => c.t.trim() || c.b.trim()));
      setInfoEdit((v) => !v);
    },
    setInfoCard: (index, patch) =>
      setInfo((cards) => cards.map((c, i) => (i === index ? { ...c, ...patch } : c))),
    moveInfo: (index, dir) =>
      setInfo((cards) => {
        const j = index + dir;
        if (j < 0 || j >= cards.length) return cards;
        const next = cards.slice();
        const a = next[index]!;
        const b = next[j]!;
        next[index] = b;
        next[j] = a;
        return next;
      }),
    removeInfo: (index) => setInfo((cards) => cards.filter((_, i) => i !== index)),
    addInfo: () => setInfo((cards) => [...cards, { t: "", b: "" }]),
    restoreBackup: (raw) => {
      const parsed = parseBackup(raw);
      if (!parsed.ok) return parsed;
      const nextInfo = parsed.info ?? info;
      if (parsed.info) {
        setInfo(parsed.info);
        setInfoEdit(false);
      }
      const nextLists = mergeLists(lists, parsed.lists);
      setLists(nextLists);
      return {
        ok: true as const,
        summary: `রিস্টোর হয়েছে: Driver ${nextLists.d.length}, Helper ${nextLists.h.length}, Gari ${nextLists.c.length}, Info ${nextInfo.length}`,
      };
    },
    duty,
    dutyDate,
    setDutyDate: (value) => setDutyDate(value),
    shiftDuty: (days) => setDutyDate((d) => shiftDateSafe(d, days)),
    jumpToday: () => setDutyDate(operationalToday()),
    saveDutyMonth: (month, a, b) => setDuty((s) => ({ ...s, [month]: { a, b } })),
    deleteDutyMonth: (month) => {
      if (!duty[month]) return false;
      setDuty((s) => {
        const next = { ...s };
        delete next[month];
        return next;
      });
      return true;
    },
    images,
    setImageFile: async (slot, file) => {
      const data = await shrinkImage(file);
      if (!data) return "ছবি পড়া যায়নি";
      const next = { ...images, [slot]: data };
      if (!writeJSON(KEYS.images, next)) {
        return "জায়গা কম, ছবি সেভ হয়নি";
      }
      setImages(next);
      return null;
    },
    clearImage: (slot) =>
      setImages((s) => {
        const next = { ...s };
        delete next[slot];
        return next;
      }),
    toast,
    notify,
    confirm,
    confirmState,
    closeConfirm,
  };

  return <HubContext value={value}>{children}</HubContext>;
}

function awaitFormat(key: "dp" | "hp" | "car", raw: string) {
  if (key === "car") {
    const d = raw.replace(/\D/g, "").slice(0, 6);
    return d.length > 2 ? `${d.slice(0, 2)}-${d.slice(2)}` : d;
  }
  return raw.replace(/\D/g, "").slice(0, 11);
}

function shiftDateSafe(ds: string, n: number) {
  const base = ds || operationalToday();
  const d = new Date(`${base}T00:00:00`);
  d.setDate(d.getDate() + n);
  const p = (x: number) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
