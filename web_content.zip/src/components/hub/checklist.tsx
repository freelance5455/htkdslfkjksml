import { useEffect, useRef } from "react";
import { ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import { bn, closeReport, copyText } from "@/lib/hub/domain";
import { useHub } from "@/components/hub/provider";
import { Button, Card, Choice } from "@/components/hub/ui";
import { cn } from "@/lib/cn";

export function ChecklistTab() {
  const hub = useHub();
  const { checklist: s, checkEdit } = hub;
  const done = s.qs.filter((q) => q.v).length;
  const pct = s.qs.length ? (done / s.qs.length) * 100 : 0;
  const criticalOpen = s.qs.some((q) => q.c && q.v !== "yes");
  const prevLen = useRef(s.qs.length);

  useEffect(() => {
    if (checkEdit && s.qs.length > prevLen.current) {
      const inputs = document.querySelectorAll<HTMLInputElement>("[data-q-input]");
      inputs[inputs.length - 1]?.focus();
    }
    prevLen.current = s.qs.length;
  }, [s.qs.length, checkEdit]);

  const report = closeReport(s);

  return (
    <div className="flex flex-col gap-3">
      <p className="text-sm text-muted">সকাল ৯টার আগে আগের দিনের হিসাব থাকে। মেসেজ গ্রুপে যাবে নিচের টেক্সট।</p>
      <div className="grid grid-cols-2 gap-3">
        <label className="block">
          <span className="mb-1.5 block text-xs font-medium text-muted">তারিখ</span>
          <input className="field" type="date" value={s.date} onChange={(e) => hub.setCheckDate(e.target.value)} />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-medium text-muted">সময়</span>
          <input className="field" type="time" value={s.time} onChange={(e) => hub.setCheckTime(e.target.value)} />
        </label>
      </div>

      <div className="sticky top-[4.5rem] z-10 -mx-4 border-b border-line bg-bg px-4 py-3 md:top-0">
        <div className="h-2 overflow-hidden rounded-full bg-line">
          <div className="h-full rounded-full bg-yes" style={{ width: `${pct}%` }} />
        </div>
        <div className="mt-2 flex items-center justify-between gap-3 text-sm">
          <p className="text-muted">
            <span className="font-semibold tabular-nums text-ink">
              {bn(done)}/{bn(s.qs.length)}
            </span>{" "}
            উত্তর
          </p>
          {criticalOpen ? <p className="font-medium text-no">জরুরি এখনো বাকি</p> : <p className="font-medium text-yes">জরুরি মিলেছে</p>}
        </div>
      </div>

      <div className="flex justify-end">
        <Button variant="ghost" size="sm" onClick={hub.toggleCheckEdit}>
          {checkEdit ? "সম্পাদনা শেষ" : "প্রশ্ন সম্পাদনা"}
        </Button>
      </div>

      <div className="flex flex-col gap-3">
        {s.qs.map((q, i) => (
          <Card
            key={q.id}
            className={cn(q.c && "border-l-4 border-l-no", !checkEdit && q.v === "yes" && "border-yes")}
          >
            <div className="flex gap-3">
              <span className="w-8 shrink-0 font-semibold tabular-nums text-muted">{bn(i + 1)}.</span>
              {checkEdit ? (
                <input
                  data-q-input
                  className="field"
                  value={q.t}
                  placeholder="প্রশ্ন লিখুন"
                  aria-label={`প্রশ্ন ${bn(i + 1)}`}
                  onChange={(e) => hub.setQuestionText(q.id, e.target.value)}
                />
              ) : (
                <p className="font-semibold">
                  {q.t}
                  {q.c ? <span className="ml-2 text-xs font-semibold text-no">জরুরি</span> : null}
                </p>
              )}
            </div>
            {checkEdit ? (
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <label className="mr-auto flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    className="size-4 accent-accent"
                    checked={q.c}
                    onChange={(e) => hub.setQuestionCritical(q.id, e.target.checked)}
                  />
                  জরুরি
                </label>
                <Button variant="ghost" size="icon" aria-label="উপরে নিন" disabled={i === 0} onClick={() => hub.moveQuestion(q.id, -1)}>
                  <ChevronUp className="size-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="নিচে নিন"
                  disabled={i === s.qs.length - 1}
                  onClick={() => hub.moveQuestion(q.id, 1)}
                >
                  <ChevronDown className="size-4" />
                </Button>
                <Button
                  variant="danger"
                  size="icon"
                  aria-label="মুছুন"
                  onClick={async () => {
                    if (await hub.confirm("এই প্রশ্নটি মুছে ফেলবেন?")) hub.removeQuestion(q.id);
                  }}
                >
                  <Trash2 className="size-4" />
                </Button>
              </div>
            ) : (
              <div className="mt-3 flex gap-2">
                <Choice pressed={q.v === "yes"} tone="yes" onClick={() => hub.setAnswer(q.id, "yes")}>
                  হ্যাঁ
                </Choice>
                <Choice pressed={q.v === "no"} tone="no" onClick={() => hub.setAnswer(q.id, "no")}>
                  না
                </Choice>
              </div>
            )}
          </Card>
        ))}
      </div>

      {checkEdit ? (
        <div className="flex flex-col gap-2">
          <Button variant="ghost" size="lg" className="w-full border-dashed" onClick={hub.addQuestion}>
            নতুন প্রশ্ন যোগ করুন
          </Button>
          <button
            type="button"
            className="mx-auto text-sm text-muted underline"
            onClick={async () => {
              if (await hub.confirm("সব প্রশ্ন মুছে আগের ৮টি প্রশ্ন ফিরিয়ে আনবেন?")) hub.restoreQuestions();
            }}
          >
            আগের ৮টি প্রশ্ন ফিরিয়ে আনুন
          </button>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_auto]">
            <Button
              size="lg"
              onClick={async () => {
                const ok = await copyText(report);
                hub.notify(ok ? "কপি হয়েছে" : "মেসেজটি সিলেক্ট করে কপি করুন");
              }}
            >
              হাব ক্লোজ মেসেজ কপি করুন
            </Button>
            <Button
              variant="ghost"
              size="lg"
              onClick={async () => {
                if (await hub.confirm("সব উত্তর মুছে নতুন চেকলিস্ট শুরু করবেন? (প্রশ্নগুলো থাকবে)")) {
                  hub.resetChecklist();
                }
              }}
            >
              নতুন করুন
            </Button>
          </div>
          <Card>
            <p className="text-xs font-medium text-muted">গ্রুপে যাবে</p>
            <pre className="mt-2 whitespace-pre-wrap break-words font-sans text-sm leading-relaxed">{report}</pre>
          </Card>
        </>
      )}
    </div>
  );
}
