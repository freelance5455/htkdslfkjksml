import { useEffect, useState } from "react";
import {
  CalendarDays,
  ClipboardCheck,
  Info,
  Moon,
  Package,
  Sun,
  Truck,
} from "lucide-react";
import { fmtClock, fmtOpsDay, operationalToday, type TabId } from "@/lib/hub/domain";
import { cn } from "@/lib/cn";
import { useHub } from "@/components/hub/provider";
import { ChecklistTab } from "@/components/hub/checklist";
import { BostaTab } from "@/components/hub/bosta";
import { GariTab } from "@/components/hub/gari";
import { DutyTab } from "@/components/hub/duty";
import { InfoTab } from "@/components/hub/info";

const NAV: { id: TabId; short: string; label: string; icon: typeof Info }[] = [
  { id: "p1", short: "ক্লোজ", label: "হাব ক্লোজ", icon: ClipboardCheck },
  { id: "p2", short: "বস্তা", label: "বস্তা হিসাব", icon: Package },
  { id: "p4", short: "গাড়ি", label: "গাড়ি এন্ট্রি", icon: Truck },
  { id: "p5", short: "ডিউটি", label: "ডিউটি চার্ট", icon: CalendarDays },
  { id: "p3", short: "তথ্য", label: "তথ্য", icon: Info },
];

const TITLES: Record<TabId, string> = {
  p1: "হাব ক্লোজ",
  p2: "আজকের বস্তা",
  p4: "গাড়ি এন্ট্রি",
  p5: "ডিউটি চার্ট",
  p3: "তথ্য ও ব্যাকআপ",
};

function Mark() {
  return (
    <svg viewBox="0 0 32 32" className="size-6" aria-hidden="true">
      <path
        fill="currentColor"
        d="M4 24V6h5.2l6.8 12.4L22.8 6H28v18h-4.2V13.2L18.2 24h-4.4l-5.6-10.8V24H4z"
      />
    </svg>
  );
}

export function HubShell() {
  const hub = useHub();
  const [clock, setClock] = useState(() => fmtClock());
  const [ops, setOps] = useState(() => operationalToday());

  useEffect(() => {
    const tick = () => {
      setClock(fmtClock());
      setOps(operationalToday());
    };
    const id = window.setInterval(tick, 15000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (!hub.ready) return;
    window.scrollTo(0, 0);
  }, [hub.tab, hub.ready]);

  if (!hub.ready) {
    return (
      <div className="grid min-h-dvh place-items-center bg-bg px-6 text-ink">
        <div className="text-center">
          <div className="mx-auto grid size-12 place-items-center rounded-md bg-accent text-accent-ink">
            <Mark />
          </div>
          <p className="mt-4 text-lg font-semibold">কামরাঙ্গীরচর হাব</p>
          <p className="text-sm text-muted">অপারেশন ডেস্ক খুলছে</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-bg text-ink">
      <div className="mx-auto flex min-h-dvh w-full max-w-6xl">
        <aside className="sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-r border-line px-3 py-5 md:flex">
          <div className="flex items-center gap-3 px-2">
            <div className="grid size-11 place-items-center rounded-md bg-accent text-accent-ink">
              <Mark />
            </div>
            <div>
              <div className="text-xs font-medium text-muted">অপারেশন</div>
              <div className="font-semibold leading-tight">কামরাঙ্গীরচর</div>
            </div>
          </div>
          <nav className="mt-8 flex flex-col gap-1" aria-label="বিভাগ">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = hub.tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-current={active ? "page" : undefined}
                  onClick={() => hub.setTab(item.id)}
                  className={cn(
                    "flex h-12 items-center gap-3 rounded-md px-3 text-left text-sm font-semibold",
                    active ? "bg-elevated text-ink" : "text-muted",
                  )}
                >
                  <Icon className="size-5" strokeWidth={1.75} />
                  {item.label}
                </button>
              );
            })}
          </nav>
          <p className="mt-auto px-3 text-xs leading-relaxed text-subtle">
            সকাল ৯টার আগে আগের দিনের হিসাব। ফোনেই সেভ থাকে।
          </p>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-20 border-b border-line bg-bg pt-[env(safe-area-inset-top)]">
            <div className="flex items-center gap-3 px-4 py-3 md:px-8">
              <div className="grid size-11 shrink-0 place-items-center rounded-md bg-accent text-accent-ink md:hidden">
                <Mark />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-medium text-muted">কামরাঙ্গীরচর হাব · {fmtOpsDay(ops)}</p>
                <h1 className="truncate text-lg font-semibold leading-tight tracking-tight">{TITLES[hub.tab]}</h1>
              </div>
              <div className="text-right">
                <div className="text-base font-semibold tabular-nums">{clock}</div>
                <button
                  type="button"
                  onClick={hub.toggleTheme}
                  aria-label={hub.theme === "dark" ? "লাইট থিম" : "ডার্ক থিম"}
                  className="press mt-0.5 inline-flex h-8 items-center gap-1 text-xs font-medium text-muted"
                >
                  {hub.theme === "dark" ? <Sun className="size-3.5" /> : <Moon className="size-3.5" />}
                  {hub.theme === "dark" ? "লাইট" : "ডার্ক"}
                </button>
              </div>
            </div>
          </header>

          <main className="mx-auto w-full max-w-2xl flex-1 px-4 pt-4 pb-28 md:px-8 md:pb-12">
            <div className={hub.tab === "p1" ? "tab-enter" : "hidden"}>
              <ChecklistTab />
            </div>
            <div className={hub.tab === "p2" ? "tab-enter" : "hidden"}>
              <BostaTab />
            </div>
            <div className={hub.tab === "p4" ? "tab-enter" : "hidden"}>
              <GariTab />
            </div>
            <div className={hub.tab === "p5" ? "tab-enter" : "hidden"}>
              <DutyTab />
            </div>
            <div className={hub.tab === "p3" ? "tab-enter" : "hidden"}>
              <InfoTab />
            </div>
          </main>
        </div>
      </div>

      <nav
        className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] md:hidden"
        aria-label="বিভাগ"
      >
        <div className="mx-auto grid max-w-lg grid-cols-5">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = hub.tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-current={active ? "page" : undefined}
                aria-label={item.label}
                onClick={() => hub.setTab(item.id)}
                className={cn(
                  "flex h-16 flex-col items-center justify-center gap-1 text-xs font-semibold",
                  active ? "text-accent" : "text-muted",
                )}
              >
                <Icon className="size-5" strokeWidth={1.75} />
                {item.short}
              </button>
            );
          })}
        </div>
      </nav>

      {hub.toast ? (
        <div className="pointer-events-none fixed inset-x-0 bottom-24 z-40 flex justify-center px-4 md:bottom-8" role="status">
          <p className="rounded-full bg-ink px-4 py-2 text-sm font-semibold text-bg">{hub.toast}</p>
        </div>
      ) : null}

      {hub.confirmState ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/40 px-5" role="presentation">
          <div
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="confirm-title"
            className="modal-pop w-full max-w-sm rounded-xl border border-line bg-surface p-5 text-ink"
          >
            <p id="confirm-title" className="text-base leading-relaxed">
              {hub.confirmState.message}
            </p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button
                type="button"
                autoFocus
                className="press h-12 rounded-md border border-line font-semibold"
                onClick={() => hub.closeConfirm(false)}
              >
                না, থাক
              </button>
              <button
                type="button"
                className="press h-12 rounded-md bg-accent font-semibold text-accent-ink"
                onClick={() => hub.closeConfirm(true)}
              >
                হ্যাঁ
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
