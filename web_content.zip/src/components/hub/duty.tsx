import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Phone } from "lucide-react";
import {
  bn,
  DRIVER_CODES,
  DT,
  dutyCode,
  dutyMonth,
  MONTHS,
  nextOpenMonth,
  operationalToday,
  WEEKDAYS,
  type DriverCode,
} from "@/lib/hub/domain";
import { cn } from "@/lib/cn";
import { useHub } from "@/components/hub/provider";
import { Button, Card, Field } from "@/components/hub/ui";

export function DutyTab() {
  const hub = useHub();
  const ds = hub.dutyDate || operationalToday();
  const today = operationalToday();
  const code = dutyCode(ds, hub.duty);
  const mk = ds.slice(0, 7);
  const monthRows = dutyMonth(mk, hub.duty) || [];
  const monthTitle = monthRows.length ? `${MONTHS[Number(mk.slice(5)) - 1]} ${bn(mk.slice(0, 4))}` : "";
  const parts = ds.split("-");
  const headingWd = WEEKDAYS[new Date(`${ds}T00:00:00`).getDay()];
  const heading = `${headingWd}, ${bn(`${parts[2]}/${parts[1]}/${parts[0]}`)}`;

  return (
    <div className="flex flex-col gap-3">
      <p className="text-sm text-muted">শুক্রবার বন্ধ। রাত ১২টা ও রাত ২টার ডিউটি। হেলপার ড্রাইভারের সাথে থাকে।</p>
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" aria-label="আগের দিন" onClick={() => hub.shiftDuty(-1)}>
          <ChevronLeft className="size-5" />
        </Button>
        <input className="field" type="date" value={ds} onChange={(e) => e.target.value && hub.setDutyDate(e.target.value)} />
        <Button variant="ghost" size="icon" aria-label="পরের দিন" onClick={() => hub.shiftDuty(1)}>
          <ChevronRight className="size-5" />
        </Button>
        <Button variant="ghost" onClick={hub.jumpToday}>
          আজ
        </Button>
      </div>

      <Card>
        <h2 className="font-semibold">{ds === today ? `আজকের ডিউটি — ${heading}` : heading}</h2>
        {code === null ? (
          <p className="mt-2 text-sm text-muted">এই মাসের চার্ট এখনো বানানো হয়নি। নিচে ১ ও ২ তারিখের ডিউটি দিয়ে বানান।</p>
        ) : code === "X" ? (
          <p className="mt-2 text-sm font-medium text-muted">বন্ধ (শুক্রবার)</p>
        ) : (
          <div className="mt-3 grid gap-2">
            <Shift title="রাত ১২টা" code={code[0]} />
            <Shift title="রাত ২টা" code={code[1]} />
          </div>
        )}
      </Card>

      {monthTitle ? <h2 className="text-sm font-semibold">{monthTitle}</h2> : null}
      {monthRows.length ? (
        <div>
          <div className="roster px-2 pb-2 text-xs font-semibold text-muted">
            <span>তারিখ</span>
            <span>রাত ১২টা</span>
            <span>রাত ২টা</span>
          </div>
          {monthRows.map((row, i) => {
            const day = i + 1;
            const key = `${mk}-${String(day).padStart(2, "0")}`;
            const wd = WEEKDAYS[new Date(`${key}T00:00:00`).getDay()];
            const names = row === "X" ? ["বন্ধ", "বন্ধ"] : [crewName(row[0]), crewName(row[1])];
            return (
              <button
                key={key}
                type="button"
                onClick={() => {
                  hub.setDutyDate(key);
                  window.scrollTo(0, 0);
                }}
                className={cn(
                  "roster w-full border-t border-line px-2 py-3 text-left text-sm",
                  key === ds && "rounded-md bg-yes-bg font-semibold",
                  row === "X" && "text-muted",
                )}
              >
                <span>
                  {bn(`${String(day).padStart(2, "0")}/${mk.slice(5)}`)} {wd}
                </span>
                <span>{names[0]}</span>
                <span>{names[1]}</span>
              </button>
            );
          })}
        </div>
      ) : null}

      <Builder />
    </div>
  );
}

function crewName(code: string | undefined) {
  if (!code || !(code in DT)) return "—";
  return DT[code as DriverCode].bn;
}

function Shift({ title, code }: { title: string; code: string | undefined }) {
  if (!code || !(code in DT)) return null;
  const t = DT[code as DriverCode];
  return (
    <div className="rounded-md border border-line bg-elevated p-3">
      <p className="text-xs font-medium text-muted">{title}</p>
      <p className="mt-1 font-semibold">
        {t.bn} <span className="font-medium text-muted">({t.d})</span>
      </p>
      <a href={`tel:${t.dp}`} className="mt-1 inline-flex items-center gap-2 text-sm font-semibold text-yes">
        <Phone className="size-4" />
        {t.dp}
        {t.da ? ` / ${t.da}` : ""}
      </a>
      <p className="mt-3 text-sm">
        হেলপার · {t.h}
        {t.ha ? ` / ${t.ha}` : ""}
      </p>
      <a href={`tel:${t.hp}`} className="inline-flex items-center gap-2 text-sm font-semibold text-yes">
        <Phone className="size-4" />
        {t.hp}
      </a>
    </div>
  );
}

function Builder() {
  const hub = useHub();
  const [open, setOpen] = useState(false);
  const [month, setMonth] = useState("");
  const [d1a, setD1a] = useState<DriverCode>("S");
  const [d1b, setD1b] = useState<DriverCode>("L");
  const [d2a, setD2a] = useState<DriverCode>("L");
  const [d2b, setD2b] = useState<DriverCode>("B");

  useEffect(() => {
    if (!hub.ready || month) return;
    setMonth(nextOpenMonth(hub.duty));
  }, [hub.ready, hub.duty, month]);

  const onMonth = (value: string) => {
    setMonth(value);
    const saved = hub.duty[value];
    if (!saved) return;
    setD1a(saved.a[0] as DriverCode);
    setD1b(saved.a[1] as DriverCode);
    setD2a(saved.b[0] as DriverCode);
    setD2b(saved.b[1] as DriverCode);
  };

  return (
    <Card>
      <button type="button" className="flex w-full items-center justify-between text-left font-semibold" onClick={() => setOpen((v) => !v)}>
        নতুন মাসের চার্ট
        <span className="text-sm font-medium text-muted">{open ? "বন্ধ" : "খুলুন"}</span>
      </button>
      {open ? (
        <div className="mt-3">
          <p className="text-sm text-muted">
            ১ ও ২ তারিখ দিন। বাকি দিন একই নিয়মে সাজবে, শুক্রবার বন্ধ থাকবে। নভেম্বর ২০২৬ আগে থেকে সাজানো।
          </p>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <Field label="মাস" className="col-span-2">
              <input className="field" type="month" value={month} onChange={(e) => onMonth(e.target.value)} />
            </Field>
            <p className="col-span-2 text-sm font-semibold">১ তারিখ</p>
            <CrewSelect label="রাত ১২টা" value={d1a} onChange={setD1a} />
            <CrewSelect label="রাত ২টা" value={d1b} onChange={setD1b} />
            <p className="col-span-2 text-sm font-semibold">২ তারিখ</p>
            <CrewSelect label="রাত ১২টা" value={d2a} onChange={setD2a} />
            <CrewSelect label="রাত ২টা" value={d2b} onChange={setD2b} />
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Button
              onClick={() => {
                if (!month) {
                  hub.notify("মাস বেছে নিন");
                  return;
                }
                if (d1a === d1b || d2a === d2b) {
                  hub.notify("রাত ১২টা ও রাত ২টায় একই জন দেওয়া যাবে না");
                  return;
                }
                hub.saveDutyMonth(month, d1a + d1b, d2a + d2b);
                hub.setDutyDate(`${month}-01`);
                hub.notify("চার্ট বানানো হয়েছে");
                window.scrollTo(0, 0);
              }}
            >
              চার্ট বানান
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                if (!hub.deleteDutyMonth(month)) {
                  hub.notify("এই মাসের জন্য বানানো চার্ট নেই");
                  return;
                }
                if (month) hub.setDutyDate(`${month}-01`);
                hub.notify("মুছে ফেলা হয়েছে");
              }}
            >
              এই মাস মুছুন
            </Button>
          </div>
        </div>
      ) : null}
    </Card>
  );
}

function CrewSelect({
  label,
  value,
  onChange,
}: {
  label: string;
  value: DriverCode;
  onChange: (v: DriverCode) => void;
}) {
  return (
    <Field label={label}>
      <select className="field" value={value} onChange={(e) => onChange(e.target.value as DriverCode)}>
        {DRIVER_CODES.map((c) => (
          <option key={c} value={c}>
            {DT[c].bn}
          </option>
        ))}
      </select>
    </Field>
  );
}
