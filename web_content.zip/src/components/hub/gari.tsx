import { useRef, useState } from "react";
import { ImagePlus, Trash2, Video } from "lucide-react";
import {
  copyText,
  gariProgress,
  gariReport,
  openWhatsApp,
  suggestCars,
  suggestPeople,
  TRIPS,
  WAREHOUSES,
  bn,
  type Person,
} from "@/lib/hub/domain";
import { cn } from "@/lib/cn";
import { useHub } from "@/components/hub/provider";
import { Button, Card, Field } from "@/components/hub/ui";

export function GariTab() {
  const hub = useHub();
  const g = hub.gari;
  const progress = gariProgress(g);
  const tone = progress.done >= progress.total ? "ok" : progress.done === progress.total - 1 ? "near" : "bad";
  const [video, setVideo] = useState<{ file: File; url: string; name: string; size: number } | null>(null);
  const [viewer, setViewer] = useState<string | null>(null);
  const img1 = useRef<HTMLInputElement>(null);
  const img2 = useRef<HTMLInputElement>(null);
  const vid = useRef<HTMLInputElement>(null);
  const report = gariReport(g);

  const clearVideo = () => {
    setVideo((current) => {
      if (current) URL.revokeObjectURL(current.url);
      return null;
    });
  };

  const onImage = async (slot: "1" | "2", file: File | undefined) => {
    if (!file) return;
    const err = await hub.setImageFile(slot, file);
    if (err) hub.notify(err);
  };

  const copy = async () => {
    hub.rememberCrew();
    const ok = await copyText(report);
    hub.notify(ok ? "কপি হয়েছে" : "কপি করা যায়নি");
  };

  const send = async () => {
    hub.rememberCrew();
    const ok = await copyText(report);
    if (video) {
      const file = new File([video.file], video.file.name || "video.mp4", {
        type: video.file.type || "video/mp4",
      });
      const shareData: ShareData = { files: [file], text: report };
      if (navigator.share) {
        try {
          await navigator.share(shareData);
        } catch (e) {
          if (!(e instanceof Error) || e.name !== "AbortError") {
            hub.notify("মেসেজ কপি হয়েছে — WhatsApp-এ ভিডিও বেছে ক্যাপশনে পেস্ট করুন");
          }
        }
      } else {
        hub.notify("মেসেজ কপি হয়েছে — WhatsApp-এ ভিডিও বেছে ক্যাপশনে পেস্ট করুন");
      }
      return;
    }
    if (!ok) hub.notify("কপি করা যায়নি");
    if (navigator.share) {
      try {
        await navigator.share({ text: report });
      } catch (e) {
        if (!(e instanceof Error) || e.name !== "AbortError") openWhatsApp(report);
      }
    } else {
      openWhatsApp(report);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <p className="text-sm text-muted">কপি করলে ড্রাইভার, হেলপার আর গাড়ির নম্বর তালিকায় থেকে যায়।</p>
      <Card>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date" className="col-span-2">
            <input className="field" type="date" value={g.date} onChange={(e) => hub.setGariField("date", e.target.value)} />
          </Field>
          <Field label="Kamrangirchar hub to">
            <Select value={g.wh} onChange={(v) => hub.setGariField("wh", v)} options={WAREHOUSES} />
          </Field>
          <Field label="Trip no.">
            <Select value={g.no} onChange={(v) => hub.setGariField("no", v)} options={TRIPS} />
          </Field>
          <p className="col-span-2 mt-1 text-sm font-semibold">Driver</p>
          <PersonInput
            label="Name"
            value={g.dn}
            people={hub.lists.d}
            onChange={(v) => hub.setGariField("dn", v)}
            onPick={(p) => hub.setGariCrew("d", p)}
          />
          <PersonInput
            label="ID"
            value={g.di}
            people={hub.lists.d}
            align="end"
            inputMode="numeric"
            onChange={(v) => hub.setGariField("di", v)}
            onPick={(p) => hub.setGariCrew("d", p)}
          />
          <Field label="Number" className="col-span-2">
            <input
              className="field tabular-nums"
              inputMode="numeric"
              maxLength={11}
              value={g.dp}
              onChange={(e) => hub.setGariField("dp", e.target.value)}
            />
          </Field>
          <p className="col-span-2 mt-1 text-sm font-semibold">Helper</p>
          <PersonInput
            label="Name"
            value={g.hn}
            people={hub.lists.h}
            onChange={(v) => hub.setGariField("hn", v)}
            onPick={(p) => hub.setGariCrew("h", p)}
          />
          <PersonInput
            label="ID"
            value={g.hi}
            people={hub.lists.h}
            align="end"
            inputMode="numeric"
            onChange={(v) => hub.setGariField("hi", v)}
            onPick={(p) => hub.setGariCrew("h", p)}
          />
          <Field label="Number" className="col-span-2">
            <input
              className="field tabular-nums"
              inputMode="numeric"
              maxLength={11}
              value={g.hp}
              onChange={(e) => hub.setGariField("hp", e.target.value)}
            />
          </Field>
          <p className="col-span-2 mt-1 text-sm font-semibold">Gari</p>
          <Field label="In time">
            <input className="field" type="time" value={g.tin} onChange={(e) => hub.setGariField("tin", e.target.value)} />
          </Field>
          <Field label="Out time">
            <input className="field" type="time" value={g.tout} onChange={(e) => hub.setGariField("tout", e.target.value)} />
          </Field>
          <Field label="Bosta">
            <input className="field text-right tabular-nums" inputMode="numeric" value={g.b} onChange={(e) => hub.setGariField("b", e.target.value)} />
          </Field>
          <Field label="Big">
            <input className="field text-right tabular-nums" inputMode="numeric" value={g.big} onChange={(e) => hub.setGariField("big", e.target.value)} />
          </Field>
          <Field label="Total Quantity (নিজে লিখুন)" className="col-span-2">
            <input className="field text-right tabular-nums" inputMode="numeric" value={g.tq} onChange={(e) => hub.setGariField("tq", e.target.value)} />
          </Field>
          <div className="relative col-span-2">
            <CarField />
          </div>
        </div>
      </Card>

      <div
        className={cn(
          "mx-auto flex w-full max-w-md flex-col items-center rounded-lg border px-4 py-2 text-center",
          tone === "ok" && "border-yes bg-yes-bg text-yes",
          tone === "near" && "border-warn bg-warn-bg text-warn",
          tone === "bad" && "border-no bg-no-bg text-no",
        )}
        role="status"
      >
        <b className="tabular-nums">
          {bn(progress.done)}/{bn(progress.total)}
        </b>
        <span className="text-xs font-medium">
          {progress.missing.length ? `বাকি: ${progress.missing.join(", ")}` : "সব ঘর পূরণ হয়েছে"}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Button size="lg" onClick={copy}>
          কপি করুন
        </Button>
        <Button
          variant="ghost"
          size="lg"
          onClick={async () => {
            if (await hub.confirm("সব তথ্য মুছে নতুন গাড়ির জন্য শুরু করবেন? (তারিখ থাকবে)")) {
              hub.resetGari();
              clearVideo();
            }
          }}
        >
          নতুন গাড়ি
        </Button>
      </div>
      <Button size="lg" className="w-full" onClick={send}>
        WhatsApp-এ পাঠান
      </Button>

      <Card>
        <p className="text-xs font-medium text-muted">মেসেজ</p>
        <pre className="mt-2 whitespace-pre-wrap break-words font-sans text-sm leading-relaxed">{report}</pre>
      </Card>

      <div>
        <h2 className="mb-2 text-sm font-semibold">গাড়ির ছবি</h2>
        <div className="grid grid-cols-2 gap-2">
          <ImageSlot
            n="1"
            src={hub.images["1"]}
            onAdd={() => img1.current?.click()}
            onClear={() => hub.clearImage("1")}
            onOpen={() => hub.images["1"] && setViewer(hub.images["1"]!)}
          />
          <ImageSlot
            n="2"
            src={hub.images["2"]}
            onAdd={() => img2.current?.click()}
            onClear={() => hub.clearImage("2")}
            onOpen={() => hub.images["2"] && setViewer(hub.images["2"]!)}
          />
        </div>
        <input
          ref={img1}
          hidden
          type="file"
          accept="image/*"
          onChange={(e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            void onImage("1", file);
          }}
        />
        <input
          ref={img2}
          hidden
          type="file"
          accept="image/*"
          onChange={(e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            void onImage("2", file);
          }}
        />
      </div>

      <div>
        <h2 className="mb-2 text-sm font-semibold">ভিডিও</h2>
        {video ? (
          <div>
            <video className="max-h-64 w-full rounded-lg bg-ink" src={video.url} controls playsInline preload="metadata" />
            <p className="mt-1 text-center text-xs text-muted">
              {video.name} · {(video.size / 1048576).toFixed(1)} MB
            </p>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <Button variant="ghost" onClick={() => vid.current?.click()}>
                বদলান
              </Button>
              <Button variant="danger" onClick={clearVideo}>
                মুছুন
              </Button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => vid.current?.click()}
            className="press flex h-28 w-full flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-subtle text-sm font-semibold"
          >
            <Video className="size-5" />
            ভিডিও যোগ করুন
          </button>
        )}
        <input
          ref={vid}
          hidden
          type="file"
          accept="video/*"
          onChange={(e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            if (!file) return;
            clearVideo();
            setVideo({ file, url: URL.createObjectURL(file), name: file.name, size: file.size });
          }}
        />
      </div>

      <Directory />

      {viewer ? (
        <div className="fixed inset-0 z-50 overflow-auto bg-ink" role="dialog" aria-modal="true">
          <button
            type="button"
            className="fixed top-[calc(env(safe-area-inset-top)+8px)] right-3 z-10 rounded-md bg-surface px-4 py-2 text-sm font-semibold text-ink"
            onClick={() => setViewer(null)}
          >
            বন্ধ
          </button>
          <img src={viewer} alt="" className="w-full" />
        </div>
      ) : null}
    </div>
  );
}

function ImageSlot({
  n,
  src,
  onAdd,
  onClear,
  onOpen,
}: {
  n: string;
  src?: string;
  onAdd: () => void;
  onClear: () => void;
  onOpen: () => void;
}) {
  if (!src) {
    return (
      <button
        type="button"
        onClick={onAdd}
        className="press flex h-36 flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-subtle text-sm font-semibold"
      >
        <ImagePlus className="size-5" />
        ছবি {bn(n)}
      </button>
    );
  }
  return (
    <div>
      <button type="button" onClick={onOpen} className="block w-full">
        <img src={src} alt={`ছবি ${bn(n)}`} className="h-44 w-full rounded-lg border border-line bg-surface object-contain" />
      </button>
      <div className="mt-2 grid grid-cols-2 gap-2">
        <Button variant="ghost" size="sm" onClick={onAdd}>
          বদলান
        </Button>
        <Button variant="danger" size="sm" onClick={onClear}>
          মুছুন
        </Button>
      </div>
    </div>
  );
}

function Select({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: readonly string[];
}) {
  return (
    <select className="field" value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">—</option>
      {options.map((o) => (
        <option key={o}>{o}</option>
      ))}
    </select>
  );
}

function PersonInput({
  label,
  value,
  people,
  onChange,
  onPick,
  align,
  inputMode,
}: {
  label: string;
  value: string;
  people: Person[];
  onChange: (v: string) => void;
  onPick: (p: Person) => void;
  align?: "end";
  inputMode?: "numeric";
}) {
  const [open, setOpen] = useState(false);
  const items = suggestPeople(people, value);
  return (
    <div className="relative">
      <Field label={label}>
        <input
          className="field"
          value={value}
          autoComplete="off"
          inputMode={inputMode}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setOpen(true)}
          onBlur={() => window.setTimeout(() => setOpen(false), 160)}
        />
      </Field>
      {open && items.length > 0 ? (
        <div className={cn("sug", align === "end" && "end")} role="listbox">
          {items.map((e, i) => (
            <button
              key={`${e.n}-${e.i}-${i}`}
              type="button"
              className="block w-full border-b border-line px-3 py-2 text-left last:border-b-0"
              onMouseDown={(ev) => ev.preventDefault()}
              onClick={() => {
                onPick(e);
                setOpen(false);
              }}
            >
              <span className="block text-sm font-medium">{e.n}{e.i ? ` / ${e.i}` : ""}</span>
              {e.p ? <span className="block text-xs text-muted">{e.p}</span> : null}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function CarField() {
  const hub = useHub();
  const [open, setOpen] = useState(false);
  const items = suggestCars(hub.lists.c, hub.gari.car);
  return (
    <>
      <Field label="Gari number">
        <input
          className="field tabular-nums"
          inputMode="numeric"
          placeholder="12-3456"
          maxLength={7}
          value={hub.gari.car}
          autoComplete="off"
          onChange={(e) => hub.setGariField("car", e.target.value)}
          onFocus={() => setOpen(true)}
          onBlur={() => window.setTimeout(() => setOpen(false), 160)}
        />
      </Field>
      {open && items.length > 0 ? (
        <div className="sug" role="listbox">
          {items.map((c) => (
            <button
              key={c}
              type="button"
              className="block w-full border-b border-line px-3 py-2 text-left text-sm font-medium tabular-nums last:border-b-0"
              onMouseDown={(ev) => ev.preventDefault()}
              onClick={() => {
                hub.setGariField("car", c);
                setOpen(false);
              }}
            >
              {c}
            </button>
          ))}
        </div>
      ) : null}
    </>
  );
}

function Directory() {
  const hub = useHub();
  const [open, setOpen] = useState(false);
  return (
    <Card>
      <button type="button" className="flex w-full items-center justify-between text-left font-semibold" onClick={() => setOpen((v) => !v)}>
        সেভ করা তালিকা
        <span className="text-sm font-medium text-muted">{open ? "বন্ধ" : "খুলুন"}</span>
      </button>
      {open ? (
        <div className="mt-3 flex flex-col gap-4">
          <p className="text-sm text-muted">কপি করলে নিজে সেভ হয়। একসাথে যোগ করতে প্রতি লাইনে একজন লিখুন।</p>
          <Bulk keyName="d" title="Driver" hint="Name / ID / Number" count={hub.lists.d.length} />
          <Bulk keyName="h" title="Helper" hint="Name / ID / Number" count={hub.lists.h.length} />
          <Bulk keyName="c" title="Gari number" hint="12-3456" count={hub.lists.c.length} />
        </div>
      ) : null}
    </Card>
  );
}

function Bulk({
  keyName,
  title,
  hint,
  count,
}: {
  keyName: "d" | "h" | "c";
  title: string;
  hint: string;
  count: number;
}) {
  const hub = useHub();
  const [text, setText] = useState("");
  const rows = hub.lists[keyName];
  return (
    <div>
      <h3 className="text-sm font-semibold">
        {title} ({count})
      </h3>
      <textarea
        className="field mt-2"
        rows={3}
        value={text}
        placeholder={keyName === "c" ? `প্রতি লাইনে বা কমা দিয়ে: ${hint}` : `প্রতি লাইনে একজন: ${hint}`}
        aria-label={`${title} যোগ করুন`}
        onChange={(e) => setText(e.target.value)}
      />
      <Button
        className="mt-2"
        size="sm"
        onClick={() => {
          const n = hub.addBulk(keyName, text);
          if (n) {
            setText("");
            hub.notify(`${n}টি যোগ হয়েছে`);
          }
        }}
      >
        যোগ করুন
      </Button>
      <div className="mt-2 max-h-44 overflow-auto">
        {rows.map((entry, idx) => {
          const label = typeof entry === "string" ? entry : `${entry.n}${entry.i ? ` / ${entry.i}` : ""}${entry.p ? ` · ${entry.p}` : ""}`;
          return (
            <div key={`${label}-${idx}`} className="flex items-center justify-between gap-2 border-b border-line py-2 text-sm">
              <span className="min-w-0 break-words">{label}</span>
              <button type="button" aria-label="মুছুন" className="text-no" onClick={() => hub.removeListItem(keyName, idx)}>
                <Trash2 className="size-4" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
