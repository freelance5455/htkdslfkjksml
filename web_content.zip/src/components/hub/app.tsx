import { HubProvider } from "@/components/hub/provider";
import { HubShell } from "@/components/hub/shell";

export function HubApp() {
  return (
    <HubProvider>
      <HubShell />
    </HubProvider>
  );
}
