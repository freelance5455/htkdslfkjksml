import React, { useState } from 'react';
import { PoketSafeData, Commitment, Debt, Loan } from '../types/budget';
import { 
  Building2, 
  CreditCard, 
  Users, 
  Plus, 
  Check, 
  Trash2, 
  Info, 
  X,
  AlertCircle
} from 'lucide-react';

interface PaymentsPageProps {
  data: PoketSafeData;
  onToggleCommitment: (id: string) => void;
  onDeleteCommitment: (id: string) => void;
  onAddCommitment: (name: string, amount: number, dueDate: string) => void;
  onToggleDebt: (id: string) => void;
  onDeleteDebt: (id: string) => void;
  onAddDebt: (person: string, amount: number, type: 'i_owe' | 'they_owe', reason: string) => void;
  onOpenLoanModal: () => void;
  onDeleteLoan: (id: string) => void;
}

export const PaymentsPage: React.FC<PaymentsPageProps> = ({
  data,
  onToggleCommitment,
  onDeleteCommitment,
  onAddCommitment,
  onToggleDebt,
  onDeleteDebt,
  onAddDebt,
  onOpenLoanModal,
  onDeleteLoan,
}) => {
  // Inline forms toggles
  const [showAddComm, setShowAddComm] = useState(false);
  const [commName, setCommName] = useState('');
  const [commAmount, setCommAmount] = useState('');
  const [commDue, setCommDue] = useState('15th of every month');

  const [showAddDebt, setShowAddDebt] = useState(false);
  const [debtPerson, setDebtPerson] = useState('');
  const [debtAmount, setDebtAmount] = useState('');
  const [debtType, setDebtType] = useState<'i_owe' | 'they_owe'>('i_owe');
  const [debtReason, setDebtReason] = useState('');

  // Payment Details Modal
  const [selectedPaymentDetail, setSelectedPaymentDetail] = useState<{
    type: 'commitment' | 'loan' | 'debt';
    item: Commitment | Loan | Debt;
  } | null>(null);

  const handleCreateCommitment = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(commAmount);
    if (!commName.trim() || isNaN(amt) || amt <= 0) return;
    onAddCommitment(commName.trim(), amt, commDue.trim() || '15th of every month');
    setCommName('');
    setCommAmount('');
    setCommDue('15th of every month');
    setShowAddComm(false);
  };

  const handleCreateDebt = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(debtAmount);
    if (!debtPerson.trim() || isNaN(amt) || amt <= 0) return;
    onAddDebt(debtPerson.trim(), amt, debtType, debtReason.trim() || 'Split bill');
    setDebtPerson('');
    setDebtAmount('');
    setDebtReason('');
    setShowAddDebt(false);
  };

  const unpaidCommitments = (data.commitments || [])
    .filter(c => !c.isPaidThisCycle)
    .reduce((sum, c) => sum + c.amount, 0);

  const totalMonthlyLoans = (data.loans || [])
    .filter(l => !l.isPaidThisCycle)
    .reduce((sum, l) => sum + l.monthlyPayment, 0);

  const totalDebtsOwed = (data.debts || [])
    .filter(d => d.type === 'i_owe' && !d.isSettled)
    .reduce((sum, d) => sum + d.amount, 0);

  const totalMonthlyOutflow = unpaidCommitments;

  return (
    <div className="space-y-4 pb-6">
      {/* 1. PAYMENTS TOTAL OVERVIEW */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-xl">
        <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
          Total Pending Commitments & Debts
        </div>

        <div className="flex items-baseline gap-2 my-1">
          <span className="text-sm font-bold text-blue-400">RM</span>
          <span className="text-3xl sm:text-4xl font-extrabold font-mono text-white tabular-nums">
            {(totalMonthlyOutflow + totalDebtsOwed).toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>

        <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 font-mono">
          <span>Commitments: <strong className="text-blue-300">RM {totalMonthlyOutflow.toFixed(2)}</strong></span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span>Debts I Owe: <strong className="text-amber-300">RM {totalDebtsOwed.toFixed(2)}</strong></span>
        </div>
      </div>

      {/* 3 QUICK ACTION SHORTCUTS */}
      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={() => {
            setShowAddComm(!showAddComm);
            setShowAddDebt(false);
          }}
          className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
        >
          <Building2 className="w-3.5 h-3.5 text-blue-400" />
          <span>+ Commitment</span>
        </button>

        <button
          onClick={onOpenLoanModal}
          className="p-2.5 rounded-xl bg-purple-950/40 border border-purple-500/30 hover:border-purple-400/50 text-purple-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
        >
          <CreditCard className="w-3.5 h-3.5 text-purple-400" />
          <span>+ Add Loan</span>
        </button>

        <button
          onClick={() => {
            setShowAddDebt(!showAddDebt);
            setShowAddComm(false);
          }}
          className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
        >
          <Users className="w-3.5 h-3.5 text-amber-400" />
          <span>+ Add Debt</span>
        </button>
      </div>

      {/* INLINE FORM: ADD COMMITMENT */}
      {showAddComm && (
        <form onSubmit={handleCreateCommitment} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3 text-xs">
          <div className="flex items-center justify-between font-semibold text-white">
            <span>Add Recurring Commitment</span>
            <button type="button" onClick={() => setShowAddComm(false)} className="text-slate-400 hover:text-white">Cancel</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input
              type="text"
              placeholder="Name (e.g. SPayLater, Rent)"
              value={commName}
              onChange={e => setCommName(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-white"
              autoFocus
              required
            />
            <input
              type="number"
              step="any"
              placeholder="Amount (RM)"
              value={commAmount}
              onChange={e => setCommAmount(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono"
              required
            />
            <input
              type="text"
              placeholder="Due date (e.g. 15th of every month, Every Friday)"
              value={commDue}
              onChange={e => setCommDue(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-white"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full py-2 bg-blue-500 hover:bg-blue-400 text-white font-bold rounded-xl transition-colors"
          >
            Save Commitment
          </button>
        </form>
      )}

      {/* INLINE FORM: ADD DEBT */}
      {showAddDebt && (
        <form onSubmit={handleCreateDebt} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3 text-xs">
          <div className="flex items-center justify-between font-semibold text-white">
            <span>Record Personal Debt / IOU</span>
            <button type="button" onClick={() => setShowAddDebt(false)} className="text-slate-400 hover:text-white">Cancel</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
            <select
              value={debtType}
              onChange={e => setDebtType(e.target.value as any)}
              className="px-2 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-white text-xs"
            >
              <option value="i_owe">I Owe</option>
              <option value="they_owe">They Owe Me</option>
            </select>
            <input
              type="text"
              placeholder="Person (e.g. Amir)"
              value={debtPerson}
              onChange={e => setDebtPerson(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-white"
              autoFocus
              required
            />
            <input
              type="number"
              step="any"
              placeholder="Amount (RM)"
              value={debtAmount}
              onChange={e => setDebtAmount(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono"
              required
            />
            <input
              type="text"
              placeholder="Reason (e.g. Dinner share)"
              value={debtReason}
              onChange={e => setDebtReason(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-white"
            />
          </div>
          <button
            type="submit"
            className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition-colors"
          >
            Save Debt
          </button>
        </form>
      )}

      {/* 2. UPCOMING COMMITMENTS */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-400" />
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">Upcoming Commitments</h3>
          </div>
          <span className="text-xs font-mono font-bold text-blue-400">
            RM {unpaidCommitments.toFixed(0)} pending
          </span>
        </div>

        {(data.commitments || []).length === 0 ? (
          <p className="text-xs text-slate-500 py-1">No commitments added yet.</p>
        ) : (
          <div className="divide-y divide-slate-800">
            {(data.commitments || []).map(c => (
              <div key={c.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5 min-w-0">
                  <button
                    onClick={() => onToggleCommitment(c.id)}
                    className={`w-4 h-4 rounded flex items-center justify-center transition-colors ${
                      c.isPaidThisCycle ? 'bg-emerald-500 text-slate-950' : 'border border-slate-600'
                    }`}
                  >
                    {c.isPaidThisCycle && <Check className="w-3 h-3 stroke-[3]" />}
                  </button>
                  <div 
                    onClick={() => setSelectedPaymentDetail({ type: 'commitment', item: c })}
                    className="min-w-0 cursor-pointer"
                  >
                    <p className={`font-medium truncate hover:text-blue-300 transition-colors ${c.isPaidThisCycle ? 'line-through text-slate-500' : 'text-white'}`}>
                      {c.name}
                    </p>
                    <span className="text-[10px] text-slate-400">{c.dueDate}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 shrink-0">
                  <span className={`font-mono font-bold ${c.isPaidThisCycle ? 'text-slate-500' : 'text-slate-200'}`}>
                    RM {c.amount.toFixed(0)}
                  </span>
                  <button
                    onClick={() => setSelectedPaymentDetail({ type: 'commitment', item: c })}
                    className="text-slate-500 hover:text-slate-300 p-1"
                    title="View Details"
                  >
                    <Info className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteCommitment(c.id)}
                    className="text-slate-500 hover:text-rose-400 p-1"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 3. ACTIVE LOANS & INSTALLMENT PLANS */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-purple-400" />
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">Active Loans & Installments</h3>
          </div>
          <span className="text-xs font-mono font-bold text-purple-400">
            RM {totalMonthlyLoans.toFixed(0)}/mo
          </span>
        </div>

        {(data.loans || []).length === 0 ? (
          <div className="py-2 text-center">
            <p className="text-xs text-slate-500 mb-2">No active installment plans (SPayLater, devices, education).</p>
            <button
              onClick={onOpenLoanModal}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-purple-300 rounded-lg text-xs font-semibold border border-purple-500/20"
            >
              + Create Loan with Templates
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-800">
            {(data.loans || []).map(loan => (
              <div key={loan.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                <div 
                  onClick={() => setSelectedPaymentDetail({ type: 'loan', item: loan })}
                  className="min-w-0 cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white truncate hover:text-purple-300 transition-colors">{loan.name}</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] bg-slate-800 text-purple-300 border border-purple-500/20">
                      {loan.installmentType || '0% Interest'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 flex flex-wrap items-center gap-1.5">
                    <span>Total: RM {loan.totalAmount.toFixed(0)}</span>
                    <span>•</span>
                    <span>{loan.durationMonths} Mo</span>
                    <span>•</span>
                    <span className="text-slate-300">{loan.dueDate}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 shrink-0">
                  <span className="font-mono font-bold text-purple-400 text-sm">
                    RM {loan.monthlyPayment.toFixed(2)}/mo
                  </span>
                  <button
                    onClick={() => setSelectedPaymentDetail({ type: 'loan', item: loan })}
                    className="text-slate-500 hover:text-slate-300 p-1"
                    title="View Details"
                  >
                    <Info className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteLoan(loan.id)}
                    className="text-slate-500 hover:text-rose-400 p-1"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 4. PERSONAL DEBTS */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">Personal Debts & IOUs</h3>
          </div>
          <span className="text-xs font-mono font-bold text-amber-400">
            RM {totalDebtsOwed.toFixed(0)} owed
          </span>
        </div>

        {(data.debts || []).length === 0 ? (
          <p className="text-xs text-slate-500 py-1">No personal debts recorded.</p>
        ) : (
          <div className="divide-y divide-slate-800">
            {(data.debts || []).map(d => (
              <div key={d.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                <div 
                  onClick={() => setSelectedPaymentDetail({ type: 'debt', item: d })}
                  className="min-w-0 cursor-pointer"
                >
                  <p className={`font-medium truncate hover:text-amber-300 transition-colors ${d.isSettled ? 'line-through text-slate-500' : 'text-white'}`}>
                    {d.person} · <span className="text-slate-400">{d.reason}</span>
                  </p>
                  <span className="text-[10px] text-slate-500">
                    {d.type === 'i_owe' ? 'I owe them' : 'They owe me'} {d.isSettled ? '(Settled)' : ''}
                  </span>
                </div>

                <div className="flex items-center gap-2.5 shrink-0">
                  <span
                    className={`font-mono font-bold ${
                      d.isSettled ? 'text-slate-500' : d.type === 'i_owe' ? 'text-amber-400' : 'text-cyan-400'
                    }`}
                  >
                    {d.type === 'i_owe' ? '-' : '+'}RM {d.amount.toFixed(0)}
                  </span>
                  <button
                    onClick={() => onToggleDebt(d.id)}
                    className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      d.isSettled ? 'bg-slate-800 text-slate-400' : 'bg-slate-800 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {d.isSettled ? 'Undo' : 'Settle'}
                  </button>
                  <button
                    onClick={() => onDeleteDebt(d.id)}
                    className="text-slate-500 hover:text-rose-400 p-1"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 5. PAYMENT DETAILS MODAL */}
      {selectedPaymentDetail && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-blue-400" />
                <h4 className="font-bold text-white text-sm">Payment Details</h4>
              </div>
              <button
                onClick={() => setSelectedPaymentDetail(null)}
                className="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {selectedPaymentDetail.type === 'commitment' && (() => {
              const item = selectedPaymentDetail.item as Commitment;
              return (
                <div className="space-y-3 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">Commitment Name</span>
                    <p className="text-white font-bold text-base mt-0.5">{item.name}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <div>
                      <span className="text-[10px] text-slate-500 block">Amount</span>
                      <span className="font-mono font-bold text-blue-400 text-sm">RM {item.amount.toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Status</span>
                      <span className={`font-semibold ${item.isPaidThisCycle ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {item.isPaidThisCycle ? 'Paid This Cycle' : 'Pending Payment'}
                      </span>
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">Due Schedule</span>
                    <p className="text-slate-300 mt-0.5 font-medium">{item.dueDate}</p>
                  </div>
                  <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-800">
                    Deducted from Safe To Spend calculation until marked as paid.
                  </div>
                </div>
              );
            })()}

            {selectedPaymentDetail.type === 'loan' && (() => {
              const item = selectedPaymentDetail.item as Loan;
              return (
                <div className="space-y-3 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">Loan Plan</span>
                    <p className="text-white font-bold text-base mt-0.5">{item.name}</p>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-purple-300 border border-purple-500/20 inline-block mt-1">
                      {item.category} • {item.installmentType || '0% Interest'}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 p-3 bg-slate-950 rounded-xl border border-slate-800 text-center">
                    <div>
                      <span className="text-[10px] text-slate-500 block">Total</span>
                      <span className="font-mono font-bold text-white">RM {item.totalAmount.toFixed(0)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Duration</span>
                      <span className="font-bold text-blue-300">{item.durationMonths} Mo</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Monthly</span>
                      <span className="font-mono font-bold text-purple-400">RM {item.monthlyPayment.toFixed(2)}</span>
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">Due Date</span>
                    <p className="text-slate-300 mt-0.5 font-medium">{item.dueDate}</p>
                  </div>
                  {item.customNotes && (
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold">Notes</span>
                      <p className="text-slate-300 mt-0.5">{item.customNotes}</p>
                    </div>
                  )}
                  {item.additionalMonthlyCharge && item.additionalMonthlyCharge > 0 && (
                    <div className="text-slate-400 text-[11px]">
                      Includes extra monthly charge of RM {item.additionalMonthlyCharge.toFixed(2)}
                    </div>
                  )}
                </div>
              );
            })()}

            {selectedPaymentDetail.type === 'debt' && (() => {
              const item = selectedPaymentDetail.item as Debt;
              return (
                <div className="space-y-3 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">Debt Contact</span>
                    <p className="text-white font-bold text-base mt-0.5">{item.person}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <div>
                      <span className="text-[10px] text-slate-500 block">Amount</span>
                      <span className={`font-mono font-bold text-sm ${item.type === 'i_owe' ? 'text-amber-400' : 'text-cyan-400'}`}>
                        RM {item.amount.toFixed(2)}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Type</span>
                      <span className="font-semibold text-slate-300">
                        {item.type === 'i_owe' ? 'I Owe Them' : 'They Owe Me'}
                      </span>
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">Reason</span>
                    <p className="text-slate-300 mt-0.5 font-medium">{item.reason || 'General debt / split bill'}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">Settlement</span>
                    <p className={item.isSettled ? 'text-emerald-400 font-semibold' : 'text-amber-400 font-semibold'}>
                      {item.isSettled ? 'Settled' : 'Active / Unsettled'}
                    </p>
                  </div>
                </div>
              );
            })()}

            <button
              onClick={() => setSelectedPaymentDetail(null)}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl text-xs transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
