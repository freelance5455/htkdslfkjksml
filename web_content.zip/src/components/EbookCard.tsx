import React from 'react';
import { useApp } from '../context/AppContext';
import { Ebook } from '../types';
import {
  Star,
  ShoppingCart,
  Heart,
  Eye,
  BookOpen,
  FileCheck,
  Download,
  Share2
} from 'lucide-react';
import { downloadEbookAsHtml } from '../utils/htmlDownloader';

interface EbookCardProps {
  ebook: Ebook;
  variant?: 'standard' | 'compact' | 'horizontal';
}

export const EbookCard: React.FC<EbookCardProps> = ({ ebook, variant = 'standard' }) => {
  const {
    setSelectedEbook,
    addToCart,
    toggleWishlist,
    isWishlisted,
    hasAccessToBook,
    setReaderEbook,
    showToast
  } = useApp();

  const isFav = isWishlisted(ebook.id);
  const isOwned = hasAccessToBook(ebook.id);

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.clipboard) {
      navigator.clipboard.writeText(
        `Check out "${ebook.title}" on NEXA EXAM BOOKS - Best study material for ${ebook.targetExam}!`
      );
      showToast('Book details link copied to clipboard!', 'info');
    }
  };

  const handleDownloadOffline = (e: React.MouseEvent) => {
    e.stopPropagation();
    downloadEbookAsHtml(ebook, isOwned);
    showToast(`Downloading offline HTML study material for "${ebook.title.substring(0, 24)}..."`, 'success');
  };

  return (
    <div
      onClick={() => setSelectedEbook(ebook)}
      className="group relative bg-white rounded-2xl border border-slate-200/90 hover:border-amber-400 hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden cursor-pointer h-full"
    >
      {/* Top Banner Tag / Badges */}
      <div className="absolute top-2.5 left-2.5 z-10 flex flex-col gap-1 items-start">
        {ebook.isFree && (
          <span className="bg-emerald-600 text-white font-extrabold text-[10px] tracking-wider uppercase px-2 py-0.5 rounded-md shadow-md">
            100% FREE
          </span>
        )}
        {ebook.isBestseller && !ebook.isFree && (
          <span className="bg-amber-500 text-slate-950 font-extrabold text-[10px] tracking-wider uppercase px-2 py-0.5 rounded-md shadow-md">
            BESTSELLER
          </span>
        )}
        {ebook.isNewArrival && !ebook.isBestseller && !ebook.isFree && (
          <span className="bg-indigo-600 text-white font-extrabold text-[10px] tracking-wider uppercase px-2 py-0.5 rounded-md shadow-md">
            NEW 2026
          </span>
        )}
        {ebook.isComboOffer && (
          <span className="bg-rose-600 text-white font-extrabold text-[10px] tracking-wider uppercase px-2 py-0.5 rounded-md shadow-md">
            COMBO PACK
          </span>
        )}
      </div>

      {/* Top Right Wishlist & Share buttons */}
      <div className="absolute top-2.5 right-2.5 z-10 flex items-center gap-1">
        <button
          onClick={handleShare}
          className="w-7 h-7 rounded-full bg-white/90 backdrop-blur-xs text-slate-600 hover:text-amber-600 hover:bg-white flex items-center justify-center shadow-md transition-transform hover:scale-110"
          title="Share Book"
        >
          <Share2 className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(ebook.id);
          }}
          className={`w-7 h-7 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center shadow-md transition-transform hover:scale-110 ${
            isFav ? 'text-rose-500' : 'text-slate-500 hover:text-rose-500 hover:bg-white'
          }`}
          title="Add to Wishlist"
        >
          <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500' : ''}`} />
        </button>
      </div>

      {/* Book Realistic 3D Cover Display */}
      <div className="p-4 pt-5 pb-3 bg-gradient-to-b from-slate-100 to-white flex items-center justify-center relative overflow-hidden">
        {/* Subtle patterned background */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#0B192C_1px,transparent_1px)] [background-size:12px_12px]" />

        {/* The 3D Ebook Visual */}
        <div className="relative w-36 h-48 sm:w-40 sm:h-52 perspective-1000 group-hover:scale-105 transition-transform duration-300">
          {/* Ebook Spine and Surface */}
          <div
            className={`w-full h-full rounded-r-lg rounded-l-xs bg-gradient-to-tr ${ebook.coverGradient} text-white p-3 flex flex-col justify-between shadow-lg shadow-slate-400/40 border-l-[6px] border-l-black/40 relative overflow-hidden`}
          >
            {/* Spine Highlight */}
            <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-gradient-to-r from-white/30 to-transparent" />

            {/* Header info on cover */}
            <div>
              <div className="flex items-center justify-between text-[8px] font-black uppercase tracking-wider text-amber-300">
                <span className="truncate max-w-[90px]">{ebook.targetExam}</span>
                <span className="bg-black/40 px-1 py-0.2 rounded text-[7px] text-white">
                  {ebook.format}
                </span>
              </div>
              <p className="text-[7px] text-slate-300 font-mono mt-0.5">
                NEXA PUBLICATION
              </p>
            </div>

            {/* Title on cover */}
            <div className="my-auto py-2">
              <h3 className="text-xs sm:text-[13px] font-extrabold leading-tight text-white line-clamp-3">
                {ebook.title}
              </h3>
              <p className="text-[8px] text-amber-300/90 font-medium line-clamp-2 mt-1">
                {ebook.subtitle}
              </p>
            </div>

            {/* Footer on cover */}
            <div className="border-t border-white/20 pt-1 flex items-center justify-between text-[8px] text-slate-200">
              <span className="font-semibold">{ebook.language}</span>
              <span className="text-amber-300 font-bold">{ebook.pageCount}P</span>
            </div>
          </div>
        </div>
      </div>

      {/* Book Metadata & Body */}
      <div className="p-3.5 sm:p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Tags */}
          <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
            <span className="text-[10px] font-bold text-amber-800 bg-amber-50 border border-amber-200/80 px-2 py-0.5 rounded-full">
              {ebook.targetExam}
            </span>
            <span className="text-[10px] font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">
              {ebook.language}
            </span>
          </div>

          {/* Book Title */}
          <h3 className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-blue-900 transition-colors line-clamp-2 leading-snug">
            {ebook.title}
          </h3>

          {/* Publisher & Pages */}
          <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
            {ebook.publisher}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-1.5 mt-1.5">
            <div className="flex items-center text-amber-500">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="text-xs font-bold text-slate-800 ml-1">{ebook.rating}</span>
            </div>
            <span className="text-[10px] text-slate-400">
              ({ebook.ratingCount.toLocaleString('en-IN')})
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-[10px] text-slate-500 font-medium">
              {ebook.fileSize}
            </span>
          </div>
        </div>

        {/* Pricing & Actions */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex flex-col gap-2.5">
          {/* Price display */}
          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline gap-1.5">
              {ebook.isFree ? (
                <span className="text-base sm:text-lg font-extrabold text-emerald-600">
                  FREE
                </span>
              ) : (
                <>
                  <span className="text-base sm:text-lg font-extrabold text-[#0B192C]">
                    ₹{ebook.price}
                  </span>
                  <span className="text-xs text-slate-400 line-through">
                    ₹{ebook.originalPrice}
                  </span>
                </>
              )}
            </div>

            {!ebook.isFree && ebook.discountPercent > 0 && (
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded">
                {ebook.discountPercent}% OFF
              </span>
            )}
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-1.5">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setSelectedEbook(ebook);
              }}
              className="w-full flex items-center justify-center gap-1 py-1.5 px-2 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
            >
              <Eye className="w-3.5 h-3.5 text-slate-500" />
              <span>Details</span>
            </button>

            {isOwned ? (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setReaderEbook(ebook);
                }}
                className="w-full flex items-center justify-center gap-1 py-1.5 px-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-xs"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Read</span>
              </button>
            ) : (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  addToCart(ebook);
                }}
                className="w-full flex items-center justify-center gap-1 py-1.5 px-2 rounded-xl text-xs font-extrabold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-colors shadow-xs"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            )}
          </div>

          {/* Quick Download Offline HTML trigger */}
          <button
            onClick={handleDownloadOffline}
            className="text-[10px] text-slate-600 hover:text-amber-800 flex items-center justify-center gap-1 pt-0.5 group/dl"
            title="Download offline study file (HTML/PDF ready)"
          >
            <Download className="w-3 h-3 text-slate-400 group-hover/dl:text-amber-600" />
            <span>Download Offline HTML</span>
          </button>
        </div>
      </div>
    </div>
  );
};
