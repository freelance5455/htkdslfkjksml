"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMindStore, useHydrateMind } from "@/lib/store";

const LINKS = [
  { href: "/", label: "THE CORE" },
  { href: "/descent", label: "DESCENT" },
  { href: "/crucible", label: "CRUCIBLE" },
  { href: "/hall", label: "HALL OF MINDS" },
];

export function Nav() {
  const pathname = usePathname();
  useHydrateMind();
  const mind = useMindStore((s) => s.mind);
  const hydrated = useMindStore((s) => s.hydrated);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b hairline bg-void/60 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3">
        <Link href="/" className="font-display text-xl tracking-[0.3em] text-ivory">
          AXIO<span className="text-violet-x">M</span>
        </Link>
        <nav className="hidden items-center gap-6 md:flex">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`font-mono text-[11px] tracking-[0.22em] transition-colors ${
                pathname === l.href ? "text-violet-x" : "text-ash hover:text-ivory"
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3 font-mono text-[11px] tracking-widest">
          {hydrated && mind ? (
            <div className="flex items-center gap-3 border hairline px-3 py-1.5">
              <span className="max-w-[110px] truncate text-ivory">{mind.alias.toUpperCase()}</span>
              <span className="text-violet-x">◈ {mind.mindIndex}</span>
            </div>
          ) : (
            <span className="border hairline px-3 py-1.5 text-ash">UNFORMED</span>
          )}
        </div>
      </div>
    </header>
  );
}

export function PillarBar({ label, value, glyph, color }: { label: string; value: number; glyph: string; color: string }) {
  const pct = Math.min(100, Math.round((value / 1000) * 100));
  return (
    <div className="flex items-center gap-3">
      <span className="w-5 text-center" style={{ color }}>{glyph}</span>
      <div className="flex-1">
        <div className="flex items-baseline justify-between font-mono text-[10px] tracking-[0.2em]">
          <span className="text-ash">{label}</span>
          <span className="text-ivory">{value}</span>
        </div>
        <div className="mt-1 h-[3px] w-full bg-edge">
          <div
            className="h-full transition-all duration-700"
            style={{ width: `${pct}%`, background: color, boxShadow: `0 0 12px ${color}` }}
          />
        </div>
      </div>
    </div>
  );
}
