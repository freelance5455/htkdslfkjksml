import { useRef, useState, type ReactNode } from "react";
import {
  AudioLines,
  Boxes,
  ChevronLeft,
  CircleHelp,
  Download,
  FileVideo2,
  FlaskConical,
  FolderOpen,
  Home,
  LayoutTemplate,
  Menu,
  MoreHorizontal,
  Play,
  Save,
  Sparkles,
  Upload,
  Video,
  X,
} from "lucide-react";
import type { ViewKey } from "@/types";
import { useStudio } from "@/store/StudioContext";
import { cn } from "@/utils/cn";
import { Button } from "@/components/ui";
import { aspectLabel, formatDuration } from "@/data/defaults";
import { buildTimeline } from "@/lib/timeline";

export const NAV_ITEMS: { key: ViewKey; label: string; short: string; icon: typeof Home; group: "studio" | "output" }[] = [
  { key: "dashboard", label: "نظرة عامة", short: "الرئيسية", icon: Home, group: "studio" },
  { key: "questions", label: "الأسئلة والأجوبة", short: "الأسئلة", icon: Boxes, group: "studio" },
  { key: "audio", label: "الصوت والتوقيت", short: "الصوت", icon: AudioLines, group: "studio" },
  { key: "design", label: "التصميم المرئي", short: "التصميم", icon: LayoutTemplate, group: "studio" },
  { key: "preview", label: "المعاينة الحية", short: "المعاينة", icon: Play, group: "studio" },
  { key: "export", label: "تصدير الفيديو", short: "التصدير", icon: FileVideo2, group: "output" },
  { key: "selftest", label: "اختبار المحرك", short: "الاختبار", icon: FlaskConical, group: "output" },
  { key: "help", label: "الدليل وتقرير الاختبار", short: "الدليل", icon: CircleHelp, group: "output" },
];

const MOBILE_NAV: { key: ViewKey; label: string; icon: typeof Home }[] = [
  { key: "dashboard", label: "الرئيسية", icon: Home },
  { key: "questions", label: "الأسئلة", icon: Boxes },
  { key: "design", label: "التصميم", icon: LayoutTemplate },
  { key: "export", label: "التصدير", icon: FileVideo2 },
];

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#f4e5b8] via-[#e0c27a] to-[#b88d2f] shadow-[0_8px_24px_-8px_rgba(217,182,90,0.55)]">
        <svg viewBox="0 0 24 24" className="h-5 w-5 text-[#171307]" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M6 4h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z" />
          <path d="m10 9 5 3-5 3V9Z" fill="currentColor" stroke="none" />
        </svg>
        <Sparkles size={10} className="absolute -left-1 -top-1 text-[#eedaa2]" />
      </div>
      {!compact ? (
        <div>
          <div className="font-display text-[16px] font-bold leading-none text-white">
            Quiz Studio <span className="gold-text">Pro</span>
          </div>
          <div className="mt-1.5 text-[9px] font-medium uppercase tracking-[0.24em] text-[#77755f]">Arabic Quiz Video Engine</div>
        </div>
      ) : null}
    </div>
  );
}

function ProjectMiniCard({ onNavigate }: { onNavigate: (view: ViewKey) => void }) {
  const { project } = useStudio();
  const timeline = buildTimeline(project);
  return (
    <button
      type="button"
      onClick={() => onNavigate("dashboard")}
      className="group w-full rounded-xl border border-white/[0.08] bg-white/[0.025] p-3 text-right transition hover:border-[#d9b65a]/25 hover:bg-white/[0.04]"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[9px] font-medium uppercase tracking-[0.16em] text-[#77777f]">المشروع الحالي</p>
          <p className="mt-1 truncate text-[12px] font-semibold text-white">{project.name}</p>
        </div>
        <ChevronLeft size={14} className="mt-1 shrink-0 text-[#676770] transition group-hover:text-[#e7cf94]" />
      </div>
      <div className="mt-2.5 flex flex-wrap items-center gap-1.5 text-[10px] text-[#8f8f99]">
        <span className="rounded-md bg-white/[0.05] px-1.5 py-0.5">{project.questions.length} أسئلة</span>
        <span className="rounded-md bg-white/[0.05] px-1.5 py-0.5">{formatDuration(timeline.totalDuration)}</span>
        <span className="rounded-md bg-[#d9b65a]/10 px-1.5 py-0.5 text-[#e3ca90]">{aspectLabel(project.exportSettings.width, project.exportSettings.height)}</span>
      </div>
    </button>
  );
}

function NavList({ view, onNavigate }: { view: ViewKey; onNavigate: (view: ViewKey) => void }) {
  const { project } = useStudio();
  return (
    <nav className="space-y-5" aria-label="التنقل الرئيسي">
      {(["studio", "output"] as const).map((group) => (
        <div key={group}>
          <p className="mb-1.5 px-3 text-[9px] font-semibold uppercase tracking-[0.2em] text-[#61616b]">
            {group === "studio" ? "استوديو الإنتاج" : "الإخراج والنشر"}
          </p>
          <div className="space-y-0.5">
            {NAV_ITEMS.filter((item) => item.group === group).map((item) => {
              const active = view === item.key;
              return (
                <button key={item.key} type="button" data-active={active} className="nav-item w-full text-right" onClick={() => onNavigate(item.key)}>
                  <item.icon size={16} className={active ? "text-[#e3ca90]" : "text-[#7e7e89]"} />
                  <span className="flex-1">{item.label}</span>
                  {item.key === "questions" ? (
                    <span className="rounded-md border border-white/10 bg-white/[0.04] px-1.5 py-0.5 text-[10px] tabular-nums text-[#9c9ca6]">
                      {project.questions.length}
                    </span>
                  ) : null}
                  {item.key === "export" ? <span className="h-1.5 w-1.5 rounded-full bg-[#57dc96] shadow-[0_0_8px_rgba(87,220,150,0.8)]" /> : null}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );
}

function EngineMiniCard({ onNavigate }: { onNavigate: (view: ViewKey) => void }) {
  const engine = typeof VideoEncoder !== "undefined";
  return (
    <button
      type="button"
      onClick={() => onNavigate("selftest")}
      className="w-full rounded-xl border border-white/[0.08] bg-gradient-to-br from-white/[0.04] to-transparent p-3 text-right transition hover:border-[#57dc96]/25"
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className={cn("h-1.5 w-1.5 rounded-full", engine ? "bg-[#57dc96] shadow-[0_0_8px_rgba(87,220,150,0.8)]" : "bg-amber-400")} />
          <span className="text-[11px] font-semibold text-[#e6e6ec]">محرك MP4</span>
        </div>
        <FlaskConical size={13} className="text-[#777781]" />
      </div>
      <p className="mt-1.5 text-[10px] leading-5 text-[#83838d]">
        {engine ? "WebCodecs جاهز · ترميز H.264/AAC داخل المتصفح" : "WebCodecs غير متوفر — استخدم متصفحًا حديثًا"}
      </p>
    </button>
  );
}

export function Shell({
  view,
  onNavigate,
  children,
}: {
  view: ViewKey;
  onNavigate: (view: ViewKey) => void;
  children: ReactNode;
}) {
  const { project, dirty, saving, lastSavedAt, saveNow, importProjectZip, exportProjectZip } = useStudio();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [busy, setBusy] = useState<"import" | "export" | null>(null);
  const importRef = useRef<HTMLInputElement>(null);
  const current = NAV_ITEMS.find((item) => item.key === view);

  const handleImport = async (file: File | undefined) => {
    if (!file) return;
    setBusy("import");
    try {
      await importProjectZip(file);
      onNavigate("questions");
    } catch {
      /* يعرض السياق الرسالة */
    } finally {
      setBusy(null);
      if (importRef.current) importRef.current.value = "";
    }
  };

  const navigate = (next: ViewKey) => {
    onNavigate(next);
    setDrawerOpen(false);
  };

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="px-5 pt-5">
        <Brand />
      </div>
      <div className="px-4 pt-6">
        <ProjectMiniCard onNavigate={navigate} />
      </div>
      <div className="mobile-hide-scroll flex-1 overflow-y-auto px-3 py-5">
        <NavList view={view} onNavigate={navigate} />
      </div>
      <div className="space-y-2 border-t border-white/[0.06] px-3 py-3">
        <EngineMiniCard onNavigate={navigate} />
        <div className="flex items-center justify-between px-1 text-[10px] text-[#777781]">
          <span className="flex items-center gap-1.5">
            <span className={cn("h-1.5 w-1.5 rounded-full", dirty ? "bg-[#e0b95e]" : saving ? "bg-sky-400" : "bg-[#57dc96]")} />
            {saving ? "جارٍ الحفظ…" : dirty ? "تغييرات غير محفوظة" : lastSavedAt ? "محفوظ تلقائيًا" : "محلي"}
          </span>
          <button type="button" onClick={() => void saveNow()} className="text-[#a3a3ad] transition hover:text-white" disabled={saving}>
            حفظ الآن
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-dvh" dir="rtl">
      <input
        ref={importRef}
        type="file"
        accept=".zip,application/zip"
        className="hidden"
        onChange={(event) => void handleImport(event.target.files?.[0])}
      />
      <aside className="fixed inset-y-0 right-0 z-30 hidden w-[266px] border-l border-white/[0.07] bg-[#0a0a0d]/95 backdrop-blur lg:block">
        {sidebar}
      </aside>

      {drawerOpen ? (
        <div className="fixed inset-0 z-[70] lg:hidden">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setDrawerOpen(false)} aria-hidden="true" />
          <div className="absolute inset-y-0 right-0 w-[86%] max-w-[320px] border-l border-white/10 bg-[#0b0b0e] shadow-2xl">
            <button
              type="button"
              onClick={() => setDrawerOpen(false)}
              className="absolute left-3 top-5 z-10 rounded-lg p-2 text-[#9a9aa4] hover:bg-white/5 hover:text-white"
              aria-label="إغلاق القائمة"
            >
              <X size={18} />
            </button>
            {sidebar}
            <div className="absolute bottom-16 right-0 left-0 px-4">
              <Button variant="ghost" className="w-full" onClick={() => { setDrawerOpen(false); importRef.current?.click(); }} loading={busy === "import"}>
                <Upload size={14} /> استيراد مشروع ZIP
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      <div className="lg:mr-[266px]">
        <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-[#09090c]/85 backdrop-blur-xl">
          <div className="mx-auto flex h-[62px] max-w-[1480px] items-center gap-3 px-4 sm:px-6">
            <button type="button" className="rounded-lg p-2 text-[#b3b3bd] hover:bg-white/5 hover:text-white lg:hidden" onClick={() => setDrawerOpen(true)} aria-label="فتح القائمة">
              <Menu size={19} />
            </button>
            <div className="lg:hidden">
              <Brand compact />
            </div>
            <span className="font-display text-[13px] font-bold text-white lg:hidden">Quiz Studio <span className="gold-text">Pro</span></span>
            <div className="hidden min-w-0 items-center gap-2 text-[11px] text-[#7e7e88] lg:flex">
              <FolderOpen size={13} />
              <span className="max-w-[220px] truncate">{project.name}</span>
              <ChevronLeft size={12} className="text-[#52525a]" />
              <span className="text-[#c8c8d0]">{current?.label}</span>
              <span className="mr-1 flex items-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.025] px-2 py-0.5 text-[9px]">
                <span className={cn("h-1 w-1 rounded-full", dirty ? "bg-[#e0b95e]" : "bg-[#57dc96]")} />
                {saving ? "حفظ" : dirty ? "غير محفوظ" : "محفوظ"}
              </span>
            </div>
            <div className="flex flex-1 items-center justify-end gap-1.5">
              <Button variant="quiet" className="hidden gap-1.5 px-2.5 text-[11px] sm:inline-flex" onClick={() => void saveNow()} disabled={saving} title="حفظ المشروع الآن">
                <Save size={14} /> <span className="hidden md:inline">حفظ</span>
              </Button>
              <Button variant="quiet" className="hidden gap-1.5 px-2.5 text-[11px] md:inline-flex" onClick={() => importRef.current?.click()} loading={busy === "import"} title="استيراد حزمة مشروع">
                <Upload size={14} /> <span className="hidden xl:inline">استيراد مشروع</span>
              </Button>
              <Button
                variant="quiet"
                className="hidden gap-1.5 px-2.5 text-[11px] md:inline-flex"
                loading={busy === "export"}
                title="تصدير حزمة المشروع"
                onClick={async () => {
                  setBusy("export");
                  try {
                    await exportProjectZip();
                  } finally {
                    setBusy(null);
                  }
                }}
              >
                <Download size={14} /> <span className="hidden xl:inline">حزمة المشروع</span>
              </Button>
              <div className="mx-1 hidden h-5 w-px bg-white/10 sm:block" />
              <Button variant="primary" className="!px-3 !py-2 text-[11px] sm:!px-4" onClick={() => navigate("export")}>
                <Video size={14} /> <span className="hidden sm:inline">إنشاء الفيديو</span>
                <span className="sm:hidden">تصدير</span>
              </Button>
            </div>
          </div>
        </header>

        <main className="mx-auto w-full max-w-[1480px] px-4 pb-28 pt-5 sm:px-6 sm:pt-7 lg:pb-12">{children}</main>

        <nav className="safe-bottom fixed bottom-0 left-0 right-0 z-50 border-t border-white/[0.08] bg-[#0a0a0d]/95 backdrop-blur-xl lg:hidden" aria-label="تنقل الهاتف">
          <div className="flex items-stretch justify-around px-1 pt-1.5">
            {MOBILE_NAV.map((item) => {
              const active = view === item.key;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => navigate(item.key)}
                  className={cn("flex flex-1 flex-col items-center gap-1 rounded-lg py-1.5 text-[10px]", active ? "text-[#e7cf94]" : "text-[#85858f]")}
                >
                  <span className={cn("flex h-7 w-10 items-center justify-center rounded-lg", active && "bg-[#d9b65a]/10")}>
                    <item.icon size={18} />
                  </span>
                  {item.label}
                </button>
              );
            })}
            <button
              type="button"
              onClick={() => setDrawerOpen(true)}
              className={cn("flex flex-1 flex-col items-center gap-1 rounded-lg py-1.5 text-[10px]", ["audio", "preview", "selftest", "help"].includes(view) ? "text-[#e7cf94]" : "text-[#85858f]")}
            >
              <span className="flex h-7 w-10 items-center justify-center rounded-lg">
                <MoreHorizontal size={18} />
              </span>
              المزيد
            </button>
          </div>
        </nav>
      </div>
    </div>
  );
}
