import React, { useEffect, useState } from 'react';
import { useGame } from '../context/GameContext';

interface FrenzyEmber {
  id: number;
  left: number; // percentage
  top: number; // percentage
  size: number;
  duration: number;
  delay: number;
  glyph: string;
  colorClass: string;
}

const GLYPHS = ['⚡', '✦', '✧', '★', '◆', '✶', '⚡'];
const COLOR_CLASSES = [
  'text-amber-300 [text-shadow:0_0_8px_rgba(251,191,36,0.8)]',
  'text-yellow-200 [text-shadow:0_0_8px_rgba(254,240,138,0.8)]',
  'text-amber-400 [text-shadow:0_0_8px_rgba(245,158,11,0.8)]',
  'text-cyan-300 [text-shadow:0_0_8px_rgba(103,232,249,0.8)]',
];

export function ArcaneFrenzyEffects() {
  const { isFrenzyActive } = useGame();
  const [embers, setEmbers] = useState<FrenzyEmber[]>([]);

  useEffect(() => {
    if (isFrenzyActive) {
      // Generate lightweight mobile-safe floating embers
      const newEmbers: FrenzyEmber[] = Array.from({ length: 16 }).map((_, i) => ({
        id: i,
        left: Math.random() * 90 + 5,
        top: Math.random() * 75 + 15,
        size: Math.floor(Math.random() * 8 + 14),
        duration: Number((Math.random() * 1.5 + 1.8).toFixed(2)),
        delay: Number((Math.random() * 1.5).toFixed(2)),
        glyph: GLYPHS[Math.floor(Math.random() * GLYPHS.length)],
        colorClass: COLOR_CLASSES[Math.floor(Math.random() * COLOR_CLASSES.length)],
      }));
      setEmbers(newEmbers);
    } else {
      setEmbers([]);
    }
  }, [isFrenzyActive]);

  if (!isFrenzyActive) return null;

  return (
    <div
      className="fixed inset-0 pointer-events-none z-40 overflow-hidden select-none"
      style={{ backgroundColor: 'transparent' }}
      aria-hidden="true"
    >
      {/* Radiant Golden Arcane Border around Viewport (GPU-safe border without expensive raster blur filters) */}
      <div
        className="absolute inset-0 border-2 border-amber-400/60 animate-pulse pointer-events-none will-change-opacity"
        style={{ transform: 'translate3d(0, 0, 0)', contain: 'paint' }}
      />

      {/* Floating Arcane Embers & Sparks */}
      {embers.map((ember) => (
        <div
          key={ember.id}
          className={`absolute font-cinzel select-none animate-float-ember will-change-transform ${ember.colorClass}`}
          style={{
            left: `${ember.left}%`,
            top: `${ember.top}%`,
            fontSize: `${ember.size}px`,
            animationDuration: `${ember.duration}s`,
            animationDelay: `${ember.delay}s`,
            transform: 'translate3d(0, 0, 0)',
            willChange: 'transform, opacity',
          }}
        >
          {ember.glyph}
        </div>
      ))}
    </div>
  );
}
