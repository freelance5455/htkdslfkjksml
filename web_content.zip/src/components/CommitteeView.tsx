import React, { useMemo, useState } from 'react';
import { ArrowDownLeft, ArrowUpRight, Edit2, Plus, Search, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  calculateCommitteeSummary,
  calculateOverallCommitteeTotals,
  formatDisplayDate,
  formatMoney,
} from '../engine/calculations';
import type { Committee, CommitteeFrequency, CommitteeTransaction } from '../types/app';
import { ConfirmDialog } from './ConfirmDialog';

export const CommitteeView: React.FC = () => {
  const {
    snapshot,
    saveCommittee,
    deleteCommittee,
    saveCommitteeTransaction,
    deleteCommitteeTransaction,
    notify,
  } = useApp();
  const { committees, committeeTransactions, settings } = snapshot;

  const [activeTab, setActiveTab] = useState<'ledger' | 'person-ledger' | 'installment' | 'payout' | 'history'>('ledger');
  const [filterCommitteeId, setFilterCommitteeId] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Committee Create / Edit modal
  const [showCommitteeModal, setShowCommitteeModal] = useState(false);
  const [editingCommittee, setEditingCommittee] = useState<Committee | null>(null);
  const [cName, setCName] = useState('');
  const [cPerson, setCPerson] = useState('');
  const [cOpening, setCOpening] = useState('0');
  const [cTotal, setCTotal] = useState('');
  const [cInstallment, setCInstallment] = useState('');
  const [cStartDate, setCStartDate] = useState(new Date().toISOString().slice(0, 10));
  const [cEndDate, setCEndDate] = useState('');
  const [cFreq, setCFreq] = useState<CommitteeFrequency>('Monthly');
  const [cRemarks, setCRemarks] = useState('');

  // Installment & Payout forms
  const [editingTx, setEditingTx] = useState<CommitteeTransaction | null>(null);
  const [txCommitteeId, setTxCommitteeId] = useState('');
  const [txPersonName, setTxPersonName] = useState('');
  const [txAmount, setTxAmount] = useState('');
  const [txDate, setTxDate] = useState(new Date().toISOString().slice(0, 10));
  const [txMethod, setTxMethod] = useState('Cash');
  const [txRef, setTxRef] = useState('');
  const [txRemarks, setTxRemarks] = useState('');

  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({ open: false, title: '', message: '', onConfirm: () => {} });

  const activeCommittees = useMemo(
    () => committees.filter((c) => !c.archived).sort((a, b) => a.name.localeCompare(b.name)),
    [committees]
  );

  const totals = useMemo(
    () => calculateOverallCommitteeTotals(committees, committeeTransactions),
    [committees, committeeTransactions]
  );

  const committeeSummaries = useMemo(() => {
    return activeCommittees
      .map((c) => calculateCommitteeSummary(c, committeeTransactions))
      .filter((s) => {
        if (filterCommitteeId !== 'all' && s.committee.id !== filterCommitteeId) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          return (
            s.committee.name.toLowerCase().includes(q) ||
            s.committee.personName.toLowerCase().includes(q)
          );
        }
        return true;
      });
  }, [activeCommittees, committeeTransactions, filterCommitteeId, searchQuery]);

  // Person-wise aggregated Committee Ledger
  const personLedgers = useMemo(() => {
    const map = new Map<
      string,
      { personName: string; installmentsPaid: number; payoutsReceived: number; netBalance: number; txCount: number }
    >();
    for (const c of activeCommittees) {
      const key = c.personName.trim();
      const entry = map.get(key) || {
        personName: key,
        installmentsPaid: Number(c.openingBalance) || 0,
        payoutsReceived: 0,
        netBalance: Number(c.openingBalance) || 0,
        txCount: 0,
      };
      map.set(key, entry);
    }
    for (const tx of committeeTransactions) {
      const key = tx.personName.trim();
      const entry = map.get(key) || {
        personName: key,
        installmentsPaid: 0,
        payoutsReceived: 0,
        netBalance: 0,
        txCount: 0,
      };
      if (tx.type === 'installment') {
        entry.installmentsPaid += tx.amount;
        entry.netBalance += tx.amount;
      } else {
        entry.payoutsReceived += tx.amount;
        entry.netBalance -= tx.amount;
      }
      entry.txCount += 1;
      map.set(key, entry);
    }
    return Array.from(map.values()).filter((p) =>
      searchQuery.trim() ? p.personName.toLowerCase().includes(searchQuery.toLowerCase()) : true
    );
  }, [activeCommittees, committeeTransactions, searchQuery]);

  const filteredTx = useMemo(() => {
    const cMap = new Map(committees.map((c) => [c.id, c.name]));
    return committeeTransactions
      .filter((tx) => {
        if (filterCommitteeId !== 'all' && tx.committeeId !== filterCommitteeId) return false;
        if (dateFrom && tx.date < dateFrom) return false;
        if (dateTo && tx.date > dateTo) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const cNameStr = (cMap.get(tx.committeeId) || '').toLowerCase();
          return (
            cNameStr.includes(q) ||
            tx.personName.toLowerCase().includes(q) ||
            tx.remarks.toLowerCase().includes(q) ||
            (tx.paymentRef || '').toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => (b.date !== a.date ? b.date.localeCompare(a.date) : b.createdAt.localeCompare(a.createdAt)));
  }, [committeeTransactions, committees, filterCommitteeId, dateFrom, dateTo, searchQuery]);

  const openNewCommittee = () => {
    setEditingCommittee(null);
    setCName('');
    setCPerson('');
    setCOpening('0');
    setCTotal('');
    setCInstallment('');
    setCStartDate(new Date().toISOString().slice(0, 10));
    setCEndDate('');
    setCFreq('Monthly');
    setCRemarks('');
    setShowCommitteeModal(true);
  };

  const openEditCommittee = (c: Committee) => {
    setEditingCommittee(c);
    setCName(c.name);
    setCPerson(c.personName);
    setCOpening(String(c.openingBalance));
    setCTotal(String(c.totalCommitteeAmount));
    setCInstallment(String(c.installmentAmount));
    setCStartDate(c.startDate);
    setCEndDate(c.endDate);
    setCFreq(c.paymentFrequency);
    setCRemarks(c.remarks);
    setShowCommitteeModal(true);
  };

  const handleSaveCommittee = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await saveCommittee({
      id: editingCommittee?.id,
      name: cName,
      personName: cPerson,
      openingBalance: Number(cOpening) || 0,
      totalCommitteeAmount: Number(cTotal) || 0,
      installmentAmount: Number(cInstallment) || 0,
      startDate: cStartDate,
      endDate: cEndDate,
      paymentFrequency: cFreq,
      remarks: cRemarks,
    });
    if (!res.ok) {
      notify(res.error || 'Could not save committee', 'error');
      return;
    }
    notify(editingCommittee ? 'Committee updated' : 'Committee created');
    if (res.data && !txCommitteeId) {
      setTxCommitteeId(res.data.id);
      setTxPersonName(res.data.personName);
    }
    setShowCommitteeModal(false);
  };

  const handleSelectCommitteeForTx = (cid: string) => {
    setTxCommitteeId(cid);
    const found = activeCommittees.find((c) => c.id === cid);
    if (found) {
      setTxPersonName(found.personName);
      if (activeTab === 'installment' && !txAmount && found.installmentAmount > 0) {
        setTxAmount(String(found.installmentAmount));
      }
    }
  };

  const handleSaveTx = async (e: React.FormEvent, type: 'installment' | 'payout') => {
    e.preventDefault();
    const res = await saveCommitteeTransaction({
      id: editingTx?.type === type ? editingTx.id : undefined,
      committeeId: txCommitteeId,
      personName: txPersonName,
      type,
      amount: Number(txAmount),
      date: txDate,
      paymentMethod: type === 'installment' ? txMethod : '',
      paymentRef: type === 'payout' ? txRef : '',
      remarks: txRemarks,
    });
    if (!res.ok) {
      notify(res.error || 'Could not save transaction', 'error');
      return;
    }
    notify(
      editingTx
        ? 'Committee transaction updated'
        : type === 'installment'
          ? 'Installment recorded'
          : 'Payout recorded'
    );
    setEditingTx(null);
    setTxAmount('');
    setTxRef('');
    setTxRemarks('');
    setActiveTab('ledger');
  };

  return (
    <div className="space-y-6">
      {/* Committee KPI Strip (Strictly isolated from Loan Payable) */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Opening Balance</div>
          <div className="mt-1 font-mono-num text-lg font-bold text-slate-900">
            {formatMoney(totals.totalOpeningBalance, settings)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Installments Paid</div>
          <div className="mt-1 font-mono-num text-lg font-bold text-blue-700">
            {formatMoney(totals.totalInstallmentsPaid, settings)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Payouts Received</div>
          <div className="mt-1 font-mono-num text-lg font-bold text-emerald-700">
            {formatMoney(totals.totalPayouts, settings)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Total Receivable</div>
          <div className="mt-1 font-mono-num text-lg font-bold text-teal-700">
            {formatMoney(totals.totalReceivable, settings)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 col-span-2 lg:col-span-1">
          <div className="text-xs text-slate-500">Remaining Payable</div>
          <div className="mt-1 font-mono-num text-lg font-bold text-amber-700">
            {formatMoney(totals.totalPayable, settings)}
          </div>
        </div>
      </div>

      {/* Tabs & Primary Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg" role="tablist">
          {[
            { id: 'ledger', label: 'Committee Ledger' },
            { id: 'person-ledger', label: 'Person-wise Ledger' },
            { id: 'installment', label: 'Add Installment' },
            { id: 'payout', label: 'Add Payout' },
            { id: 'history', label: 'Date-wise History' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={activeTab === tab.id}
              onClick={() => {
                setActiveTab(tab.id as typeof activeTab);
                if (tab.id !== 'installment' && tab.id !== 'payout') setEditingTx(null);
              }}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={openNewCommittee}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>New Committee</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setEditingTx(null);
              setActiveTab('installment');
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 cursor-pointer whitespace-nowrap"
          >
            <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Installment Paid</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setEditingTx(null);
              setActiveTab('payout');
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer whitespace-nowrap"
          >
            <ArrowDownLeft className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Payout Received</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      {(activeTab === 'ledger' || activeTab === 'person-ledger' || activeTab === 'history') && (
        <div className="rounded-xl border border-slate-200 bg-white p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <label htmlFor="comm-search" className="block text-xs font-medium text-slate-600 mb-1">
              Search Committee or Person
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" aria-hidden="true" />
              <input
                id="comm-search"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search..."
                className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
          </div>
          <div>
            <label htmlFor="comm-filter" className="block text-xs font-medium text-slate-600 mb-1">
              Filter by Committee
            </label>
            <select
              id="comm-filter"
              value={filterCommitteeId}
              onChange={(e) => setFilterCommitteeId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
            >
              <option value="all">All Committees</option>
              {activeCommittees.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.personName})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="comm-date-from" className="block text-xs font-medium text-slate-600 mb-1">
              From Date
            </label>
            <input
              id="comm-date-from"
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
          <div>
            <label htmlFor="comm-date-to" className="block text-xs font-medium text-slate-600 mb-1">
              To Date
            </label>
            <input
              id="comm-date-to"
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
            />
          </div>
        </div>
      )}

      {/* TAB 1: Committee-wise Ledger */}
      {activeTab === 'ledger' && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-display text-sm font-bold text-slate-900">Committee-wise Ledger</h2>
            <span className="text-xs text-slate-500">
              Closing = Opening + Installments Paid − Payouts
            </span>
          </div>
          {committeeSummaries.length === 0 ? (
            <div className="p-10 text-center">
              <p className="text-sm text-slate-600">No committees created yet.</p>
              <button
                type="button"
                onClick={openNewCommittee}
                className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Create First Committee</span>
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Committee / Person</th>
                    <th className="py-3 px-4 text-right">Total Pool</th>
                    <th className="py-3 px-4 text-right">Paid In</th>
                    <th className="py-3 px-4 text-right">Payouts</th>
                    <th className="py-3 px-4 text-right">Closing Balance</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {committeeSummaries.map((s) => (
                    <tr key={s.committee.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{s.committee.name}</div>
                        <div className="text-xs text-slate-500">
                          {s.committee.personName} · {s.committee.paymentFrequency} · Inst. {formatMoney(s.installmentAmount, settings)}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono-num text-slate-700">
                        {formatMoney(s.totalCommitteeAmount, settings)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-num text-blue-700 font-medium">
                        {formatMoney(s.totalInstallmentsPaid, settings)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-num text-emerald-700 font-medium">
                        {formatMoney(s.totalPayouts, settings)}
                      </td>
                      <td
                        className={`py-3 px-4 text-right font-mono-num font-bold ${
                          s.closingBalance > 0
                            ? 'text-teal-700 bg-teal-50/50'
                            : s.closingBalance < 0
                              ? 'text-amber-700 bg-amber-50/50'
                              : 'text-slate-700'
                        }`}
                      >
                        {formatMoney(s.closingBalance, settings)}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            aria-label={`Edit committee ${s.committee.name}`}
                            onClick={() => openEditCommittee(s.committee)}
                            className="p-1.5 rounded text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            aria-label={`Delete committee ${s.committee.name}`}
                            onClick={() =>
                              setConfirmState({
                                open: true,
                                title: `Delete ${s.committee.name}?`,
                                message: `Move "${s.committee.name}" and its ${s.transactionCount} transaction(s) to Recycle Bin?`,
                                onConfirm: async () => {
                                  await deleteCommittee(s.committee.id);
                                  notify(`Moved ${s.committee.name} to Recycle Bin`);
                                  setConfirmState((p) => ({ ...p, open: false }));
                                },
                              })
                            }
                            className="p-1.5 rounded text-red-500 hover:text-red-700 hover:bg-red-50 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Person-wise Committee Ledger */}
      {activeTab === 'person-ledger' && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100">
            <h2 className="font-display text-sm font-bold text-slate-900">Person-wise Committee Ledger</h2>
          </div>
          {personLedgers.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">No person committee records found.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Person Name</th>
                    <th className="py-3 px-4 text-right">Transactions</th>
                    <th className="py-3 px-4 text-right">Installments Paid</th>
                    <th className="py-3 px-4 text-right">Payouts Received</th>
                    <th className="py-3 px-4 text-right">Net Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {personLedgers.map((p) => (
                    <tr key={p.personName}>
                      <td className="py-3 px-4 font-semibold text-slate-900">{p.personName}</td>
                      <td className="py-3 px-4 text-right font-mono-num text-slate-600">{p.txCount}</td>
                      <td className="py-3 px-4 text-right font-mono-num text-blue-700">
                        {formatMoney(p.installmentsPaid, settings)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-num text-emerald-700">
                        {formatMoney(p.payoutsReceived, settings)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-num font-bold text-slate-900">
                        {formatMoney(p.netBalance, settings)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Installment / Payment Form */}
      {activeTab === 'installment' && (
        <form
          onSubmit={(e) => handleSaveTx(e, 'installment')}
          className="rounded-xl border border-slate-200 bg-white p-6 max-w-2xl space-y-4"
        >
          <h2 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
            {editingTx ? 'Edit Installment Payment' : 'Record Committee Installment (Outgoing)'}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="inst-comm" className="block text-xs font-semibold text-slate-700 mb-1">
                Committee Name *
              </label>
              <select
                id="inst-comm"
                required
                value={txCommitteeId}
                onChange={(e) => handleSelectCommitteeForTx(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
              >
                <option value="">Select Committee...</option>
                {activeCommittees.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="inst-person" className="block text-xs font-semibold text-slate-700 mb-1">
                Person Name *
              </label>
              <input
                id="inst-person"
                type="text"
                required
                value={txPersonName}
                onChange={(e) => setTxPersonName(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label htmlFor="inst-date" className="block text-xs font-semibold text-slate-700 mb-1">
                Date *
              </label>
              <input
                id="inst-date"
                type="date"
                required
                value={txDate}
                onChange={(e) => setTxDate(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label htmlFor="inst-amount" className="block text-xs font-semibold text-slate-700 mb-1">
                Amount ({settings.currency}) *
              </label>
              <input
                id="inst-amount"
                type="number"
                step="0.01"
                min="0.01"
                required
                value={txAmount}
                onChange={(e) => setTxAmount(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label htmlFor="inst-method" className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Method
              </label>
              <select
                id="inst-method"
                value={txMethod}
                onChange={(e) => setTxMethod(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
              >
                <option value="Cash">Cash</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Easypaisa / JazzCash">Easypaisa / JazzCash</option>
                <option value="Cheque">Cheque</option>
              </select>
            </div>
            <div>
              <label htmlFor="inst-remarks" className="block text-xs font-semibold text-slate-700 mb-1">
                Remarks
              </label>
              <input
                id="inst-remarks"
                type="text"
                value={txRemarks}
                onChange={(e) => setTxRemarks(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="submit"
              className="px-5 py-2 rounded-lg text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 cursor-pointer"
            >
              {editingTx ? 'Update Installment' : 'Save Installment'}
            </button>
          </div>
        </form>
      )}

      {/* TAB 4: Payout / Received Amount Form */}
      {activeTab === 'payout' && (
        <form
          onSubmit={(e) => handleSaveTx(e, 'payout')}
          className="rounded-xl border border-slate-200 bg-white p-6 max-w-2xl space-y-4"
        >
          <h2 className="font-display text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
            {editingTx ? 'Edit Payout Received' : 'Record Committee Payout (Incoming)'}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="pay-comm" className="block text-xs font-semibold text-slate-700 mb-1">
                Committee Name *
              </label>
              <select
                id="pay-comm"
                required
                value={txCommitteeId}
                onChange={(e) => handleSelectCommitteeForTx(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
              >
                <option value="">Select Committee...</option>
                {activeCommittees.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="pay-person" className="block text-xs font-semibold text-slate-700 mb-1">
                Person Name *
              </label>
              <input
                id="pay-person"
                type="text"
                required
                value={txPersonName}
                onChange={(e) => setTxPersonName(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label htmlFor="pay-date" className="block text-xs font-semibold text-slate-700 mb-1">
                Date *
              </label>
              <input
                id="pay-date"
                type="date"
                required
                value={txDate}
                onChange={(e) => setTxDate(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label htmlFor="pay-amount" className="block text-xs font-semibold text-slate-700 mb-1">
                Amount Received ({settings.currency}) *
              </label>
              <input
                id="pay-amount"
                type="number"
                step="0.01"
                min="0.01"
                required
                value={txAmount}
                onChange={(e) => setTxAmount(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
              />
            </div>
            <div>
              <label htmlFor="pay-ref" className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Reference
              </label>
              <input
                id="pay-ref"
                type="text"
                value={txRef}
                onChange={(e) => setTxRef(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div>
              <label htmlFor="pay-remarks" className="block text-xs font-semibold text-slate-700 mb-1">
                Remarks
              </label>
              <input
                id="pay-remarks"
                type="text"
                value={txRemarks}
                onChange={(e) => setTxRemarks(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="submit"
              className="px-5 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
            >
              {editingTx ? 'Update Payout' : 'Save Payout'}
            </button>
          </div>
        </form>
      )}

      {/* TAB 5: Installment & Payout History */}
      {activeTab === 'history' && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-display text-sm font-bold text-slate-900">
              Installment &amp; Payout History
            </h2>
            <span className="text-xs text-slate-500">{filteredTx.length} record(s)</span>
          </div>
          {filteredTx.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">No committee transactions found.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Committee</th>
                    <th className="py-3 px-4">Person</th>
                    <th className="py-3 px-4">Direction</th>
                    <th className="py-3 px-4">Method / Ref</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredTx.map((tx) => {
                    const comm = committees.find((c) => c.id === tx.committeeId);
                    return (
                      <tr key={tx.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono-num text-xs text-slate-600 whitespace-nowrap">
                          {formatDisplayDate(tx.date, settings.dateFormat)}
                        </td>
                        <td className="py-3 px-4 font-medium text-slate-900">{comm?.name || 'Unknown'}</td>
                        <td className="py-3 px-4 text-slate-700">{tx.personName}</td>
                        <td className="py-3 px-4 text-xs">
                          <span
                            className={`font-semibold ${
                              tx.type === 'installment' ? 'text-blue-700' : 'text-emerald-700'
                            }`}
                          >
                            {tx.type === 'installment' ? 'Installment Paid (Out)' : 'Payout Received (In)'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-500">
                          {tx.paymentMethod || tx.paymentRef || '-'}
                        </td>
                        <td
                          className={`py-3 px-4 text-right font-mono-num font-semibold ${
                            tx.type === 'installment' ? 'text-blue-700' : 'text-emerald-700'
                          }`}
                        >
                          {formatMoney(tx.amount, settings)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              aria-label={`Edit committee transaction ${tx.id}`}
                              onClick={() => {
                                setEditingTx(tx);
                                setTxCommitteeId(tx.committeeId);
                                setTxPersonName(tx.personName);
                                setTxAmount(String(tx.amount));
                                setTxDate(tx.date);
                                setTxMethod(tx.paymentMethod || 'Cash');
                                setTxRef(tx.paymentRef || '');
                                setTxRemarks(tx.remarks);
                                setActiveTab(tx.type === 'installment' ? 'installment' : 'payout');
                              }}
                              className="p-1.5 rounded text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              aria-label={`Delete committee transaction ${tx.id}`}
                              onClick={() =>
                                setConfirmState({
                                  open: true,
                                  title: 'Delete Committee Transaction?',
                                  message: `Delete ${tx.type} of ${formatMoney(tx.amount, settings)}?`,
                                  onConfirm: async () => {
                                    await deleteCommitteeTransaction(tx.id);
                                    notify('Committee transaction moved to Recycle Bin');
                                    setConfirmState((p) => ({ ...p, open: false }));
                                  },
                                })
                              }
                              className="p-1.5 rounded text-red-500 hover:text-red-700 hover:bg-red-50 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Create / Edit Committee Modal */}
      {showCommitteeModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="comm-modal-title"
        >
          <form
            onSubmit={handleSaveCommittee}
            className="w-full max-w-lg rounded-xl bg-white border border-slate-200 shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <h3 id="comm-modal-title" className="font-display text-base font-bold text-slate-900">
              {editingCommittee ? 'Edit Committee' : 'Create New Committee'}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="c-name" className="block text-xs font-semibold text-slate-700 mb-1">
                  Committee Name *
                </label>
                <input
                  id="c-name"
                  type="text"
                  required
                  value={cName}
                  onChange={(e) => setCName(e.target.value)}
                  placeholder="e.g. Office Gold Committee"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
                />
              </div>
              <div>
                <label htmlFor="c-person" className="block text-xs font-semibold text-slate-700 mb-1">
                  Person / Organizer Name *
                </label>
                <input
                  id="c-person"
                  type="text"
                  required
                  value={cPerson}
                  onChange={(e) => setCPerson(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
                />
              </div>
              <div>
                <label htmlFor="c-opening" className="block text-xs font-semibold text-slate-700 mb-1">
                  Opening Balance ({settings.currency})
                </label>
                <input
                  id="c-opening"
                  type="number"
                  step="0.01"
                  value={cOpening}
                  onChange={(e) => setCOpening(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
                />
              </div>
              <div>
                <label htmlFor="c-total" className="block text-xs font-semibold text-slate-700 mb-1">
                  Total Committee Amount *
                </label>
                <input
                  id="c-total"
                  type="number"
                  step="0.01"
                  required
                  value={cTotal}
                  onChange={(e) => setCTotal(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
                />
              </div>
              <div>
                <label htmlFor="c-inst" className="block text-xs font-semibold text-slate-700 mb-1">
                  Installment Amount *
                </label>
                <input
                  id="c-inst"
                  type="number"
                  step="0.01"
                  required
                  value={cInstallment}
                  onChange={(e) => setCInstallment(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 font-mono-num"
                />
              </div>
              <div>
                <label htmlFor="c-freq" className="block text-xs font-semibold text-slate-700 mb-1">
                  Payment Frequency
                </label>
                <select
                  id="c-freq"
                  value={cFreq}
                  onChange={(e) => setCFreq(e.target.value as CommitteeFrequency)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
                >
                  {['Daily', 'Weekly', 'Bi-Weekly', 'Monthly', 'Quarterly', 'Custom'].map((f) => (
                    <option key={f} value={f}>
                      {f}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="c-start" className="block text-xs font-semibold text-slate-700 mb-1">
                  Start Date
                </label>
                <input
                  id="c-start"
                  type="date"
                  value={cStartDate}
                  onChange={(e) => setCStartDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
                />
              </div>
              <div>
                <label htmlFor="c-end" className="block text-xs font-semibold text-slate-700 mb-1">
                  End Date
                </label>
                <input
                  id="c-end"
                  type="date"
                  value={cEndDate}
                  onChange={(e) => setCEndDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
                />
              </div>
            </div>
            <div>
              <label htmlFor="c-remarks" className="block text-xs font-semibold text-slate-700 mb-1">
                Remarks
              </label>
              <input
                id="c-remarks"
                type="text"
                value={cRemarks}
                onChange={(e) => setCRemarks(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCommitteeModal(false)}
                className="px-4 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer"
              >
                Save Committee
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog
        open={confirmState.open}
        title={confirmState.title}
        message={confirmState.message}
        destructive
        confirmLabel="Delete"
        onConfirm={confirmState.onConfirm}
        onCancel={() => setConfirmState((p) => ({ ...p, open: false }))}
      />
    </div>
  );
};
