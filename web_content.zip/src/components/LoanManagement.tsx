import React, { useState, useMemo } from 'react';
import {
  CreditCard,
  Plus,
  Search,
  Download,
  AlertCircle,
  ArrowDownLeft,
  ArrowUpRight,
  User,
  Trash2,
  Edit2,
  ShieldAlert,
  Wallet,
  TrendingDown,
  Clock,
  Layers,
} from 'lucide-react';
import { AppSettings, LoanRecord, LoanType } from '../types';
import { translations } from '../utils/translations';
import { calculateLoanPayable, calculateLoanReceivable } from '../utils/calculations';
import { StorageService } from '../utils/storage';

interface LoanManagementProps {
  records: LoanRecord[];
  onUpdateRecords: (records: LoanRecord[]) => void;
  settings: AppSettings;
}

export const LoanManagement: React.FC<LoanManagementProps> = ({
  records,
  onUpdateRecords,
  settings,
}) => {
  const t = translations[settings.language];
  const [activeTab, setActiveTab] = useState<'payable' | 'receivable'>('payable');
  const [search, setSearch] = useState('');
  const [personFilter, setPersonFilter] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<LoanRecord | null>(null);

  // Form State
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [person, setPerson] = useState('');
  const [transactionType, setTransactionType] = useState<LoanType>('Loan Received');
  const [amount, setAmount] = useState<number | ''>('');
  const [paymentMethod, setPaymentMethod] = useState('Bank Transfer');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [remarks, setRemarks] = useState('');

  // Calculations for Payable (Money I owe)
  const payableCalc = useMemo(() => {
    return calculateLoanPayable(records);
  }, [records]);

  // Calculations for Receivable (Money owed to me)
  const receivableCalc = useMemo(() => {
    return calculateLoanReceivable(records);
  }, [records]);

  // Filtered list
  const activeRecords = useMemo(() => {
    const isRec = activeTab === 'receivable';
    return records
      .filter((r) => !r.isDeleted && (isRec ? !!r.isReceivable : !r.isReceivable))
      .filter((r) => {
        const matchesSearch =
          search === '' ||
          r.person.toLowerCase().includes(search.toLowerCase()) ||
          (r.remarks && r.remarks.toLowerCase().includes(search.toLowerCase())) ||
          (r.referenceNumber && r.referenceNumber.toLowerCase().includes(search.toLowerCase()));
        const matchesPerson = personFilter === '' || r.person === personFilter;
        return matchesSearch && matchesPerson;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [records, activeTab, search, personFilter]);

  // Unique persons
  const uniquePersons = useMemo(() => {
    const isRec = activeTab === 'receivable';
    const set = new Set<string>();
    records
      .filter((r) => !r.isDeleted && (isRec ? !!r.isReceivable : !r.isReceivable))
      .forEach((r) => set.add(r.person));
    return Array.from(set);
  }, [records, activeTab]);

  const handleOpenAdd = () => {
    setEditingRecord(null);
    setDate(new Date().toISOString().slice(0, 10));
    setPerson('');
    setTransactionType(activeTab === 'payable' ? 'Loan Received' : 'Loan Received');
    setAmount('');
    setPaymentMethod('Bank Transfer');
    setReferenceNumber('');
    setRemarks('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (rec: LoanRecord) => {
    setEditingRecord(rec);
    setDate(rec.date);
    setPerson(rec.person);
    setTransactionType(rec.transactionType);
    setAmount(rec.amount);
    setPaymentMethod(rec.paymentMethod);
    setReferenceNumber(rec.referenceNumber || '');
    setRemarks(rec.remarks || '');
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(amount);
    if (!person.trim()) {
      alert('Person / Lender name is required');
      return;
    }
    if (amt <= 0) {
      alert('Amount must be greater than zero');
      return;
    }

    const isRec = activeTab === 'receivable';

    if (editingRecord) {
      const old = { ...editingRecord };
      const updated: LoanRecord = {
        ...editingRecord,
        date,
        person: person.trim(),
        transactionType,
        amount: amt,
        paymentMethod,
        referenceNumber: referenceNumber.trim(),
        remarks: remarks.trim(),
        isReceivable: isRec,
        updatedAt: new Date().toISOString(),
      };
      const updatedList = records.map((r) => (r.id === editingRecord.id ? updated : r));
      onUpdateRecords(updatedList);
      StorageService.saveLoans(updatedList);
      StorageService.addAuditLog('UPDATE', isRec ? 'Loan Receivable' : 'Loan Payable', `Updated transaction for ${person}`, old, updated);
    } else {
      const newRec: LoanRecord = {
        id: `loan_${Date.now()}`,
        date,
        person: person.trim(),
        transactionType,
        amount: amt,
        paymentMethod,
        referenceNumber: referenceNumber.trim(),
        remarks: remarks.trim(),
        isReceivable: isRec,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const updatedList = [newRec, ...records];
      onUpdateRecords(updatedList);
      StorageService.saveLoans(updatedList);
      StorageService.addAuditLog(
        'CREATE',
        isRec ? 'Loan Receivable' : 'Loan Payable',
        `${transactionType} of Rs. ${amt} with ${person}`,
        null,
        newRec
      );
    }

    setIsModalOpen(false);
  };

  const handleDelete = (rec: LoanRecord) => {
    if (window.confirm(t.confirmDelete)) {
      const updated = records.map((r) => (r.id === rec.id ? { ...r, isDeleted: true } : r));
      onUpdateRecords(updated);
      StorageService.saveLoans(updated);
      StorageService.moveToRecycleBin(
        rec.isReceivable ? 'Loan Receivable' : 'Loan Payable',
        rec.id,
        `${rec.transactionType}: Rs. ${rec.amount} (${rec.person})`,
        rec
      );
    }
  };

  const handleExportCSV = () => {
    const rows = activeRecords.map((r) => ({
      Date: r.date,
      Person: r.person,
      'Transaction Type': r.transactionType,
      Amount: r.amount,
      'Payment Method': r.paymentMethod,
      'Reference Number': r.referenceNumber || '',
      Remarks: r.remarks || '',
    }));
    StorageService.exportToCsv(`${activeTab === 'payable' ? 'Loan_Payable' : 'Loan_Receivable'}_Export`, rows);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-400 rounded-lg">
            <CreditCard className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              {activeTab === 'payable' ? t.loanPayable : t.loanReceivable}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {activeTab === 'payable' ? t.payableRuleNotice : 'Money given to others and awaiting recovery'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Tab Selector: Payable vs Receivable */}
          <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveTab('payable')}
              className={`px-3 py-1.5 rounded-md transition ${
                activeTab === 'payable'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Loan Payable (I Owe)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('receivable')}
              className={`px-3 py-1.5 rounded-md transition ${
                activeTab === 'receivable'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Loan Receivable (Others Owe Me)
            </button>
          </div>

          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>{t.exportCsv}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addLoan}</span>
          </button>
        </div>
      </div>

      {/* Critical Business Rule Banner */}
      <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-xl flex items-center justify-between text-xs text-amber-900 dark:text-amber-200">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
          <span>
            <strong>Crucial Rule:</strong> Loan Payable = Total Loan Received − Total Loan Repaid. Committee transactions are strictly isolated and never touch these balances.
          </span>
        </div>
        <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
          Balance Isolated
        </span>
      </div>

      {/* KPI Balances */}
      {activeTab === 'payable' ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
              <span>{t.totalBorrowed}</span>
              <ArrowDownLeft className="w-4 h-4 text-rose-500" />
            </div>
            <div className="mt-2 text-2xl font-bold text-rose-600 dark:text-rose-400">
              {settings.currencySymbol} {payableCalc.totalReceived.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">Loan Received (Increases liability)</p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
              <span>{t.totalRepaid}</span>
              <ArrowUpRight className="w-4 h-4 text-emerald-500" />
            </div>
            <div className="mt-2 text-2xl font-bold text-emerald-600 dark:text-emerald-400">
              {settings.currencySymbol} {payableCalc.totalRepaid.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">Loan Repaid (Decreases liability)</p>
          </div>

          <div className="bg-rose-50 dark:bg-rose-950/40 p-4 rounded-xl border border-rose-200 dark:border-rose-900/60 shadow-xs">
            <div className="flex items-center justify-between text-rose-700 dark:text-rose-300 text-xs font-bold">
              <span>{t.remainingPayable}</span>
              <Wallet className="w-4 h-4 text-rose-600" />
            </div>
            <div className="mt-2 text-3xl font-extrabold text-rose-700 dark:text-rose-300">
              {settings.currencySymbol} {payableCalc.remainingPayable.toLocaleString()}
            </div>
            <p className="text-[11px] text-rose-600/80 dark:text-rose-400/80 mt-0.5 font-medium">
              Net balance still to return
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
              <span>Total Given</span>
              <ArrowUpRight className="w-4 h-4 text-blue-500" />
            </div>
            <div className="mt-2 text-2xl font-bold text-blue-600 dark:text-blue-400">
              {settings.currencySymbol} {receivableCalc.totalGiven.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">Money lent to others</p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
              <span>Total Recovered</span>
              <ArrowDownLeft className="w-4 h-4 text-emerald-500" />
            </div>
            <div className="mt-2 text-2xl font-bold text-emerald-600 dark:text-emerald-400">
              {settings.currencySymbol} {receivableCalc.totalRecovered.toLocaleString()}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">Amount received back</p>
          </div>

          <div className="bg-emerald-50 dark:bg-emerald-950/40 p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/60 shadow-xs">
            <div className="flex items-center justify-between text-emerald-700 dark:text-emerald-300 text-xs font-bold">
              <span>Remaining Receivable</span>
              <Wallet className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="mt-2 text-3xl font-extrabold text-emerald-700 dark:text-emerald-300">
              {settings.currencySymbol} {receivableCalc.remainingReceivable.toLocaleString()}
            </div>
            <p className="text-[11px] text-emerald-600/80 dark:text-emerald-400/80 mt-0.5 font-medium">
              Awaiting collection
            </p>
          </div>
        </div>
      )}

      {/* Person-Wise Ledger Summary Cards (for Payable) */}
      {activeTab === 'payable' && Object.keys(payableCalc.personWise).length > 0 && (
        <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
          <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <User className="w-4 h-4 text-rose-500" />
            Person-Wise Balance Ledger
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {Object.entries(payableCalc.personWise).map(([personName, stat]) => (
              <div
                key={personName}
                className="bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-xs space-y-1.5"
              >
                <div className="flex justify-between items-center font-bold">
                  <span className="text-slate-900 dark:text-white truncate">{personName}</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] ${
                      stat.payable > 0
                        ? 'bg-rose-100 dark:bg-rose-950 text-rose-700'
                        : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700'
                    }`}
                  >
                    {stat.payable > 0 ? 'Payable' : 'Cleared'}
                  </span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Total Borrowed:</span>
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    {settings.currencySymbol} {stat.received.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Total Repaid:</span>
                  <span className="font-medium text-emerald-600">
                    {settings.currencySymbol} {stat.repaid.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between font-bold border-t border-slate-100 dark:border-slate-800 pt-1 text-slate-900 dark:text-white">
                  <span>Balance Due:</span>
                  <span className={stat.payable > 0 ? 'text-rose-600' : 'text-slate-400'}>
                    {settings.currencySymbol} {stat.payable.toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 rtl:left-auto rtl:right-3" />
          <input
            type="text"
            placeholder="Search person, reference, remarks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 rtl:pl-3 rtl:pr-9 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 border-0"
          />
        </div>

        <select
          value={personFilter}
          onChange={(e) => setPersonFilter(e.target.value)}
          className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 border-0"
        >
          <option value="">All Persons</option>
          {uniquePersons.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </select>
      </div>

      {/* Records Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider font-semibold">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">{t.lender}</th>
                <th className="px-4 py-3">{t.loanType}</th>
                <th className="px-4 py-3">{t.amount}</th>
                <th className="px-4 py-3">{t.paymentMethod}</th>
                <th className="px-4 py-3">Reference #</th>
                <th className="px-4 py-3">{t.remarks}</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {activeRecords.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                    No loan records found.
                  </td>
                </tr>
              ) : (
                activeRecords.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition">
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-slate-200 whitespace-nowrap">
                      {r.date}
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                      {r.person}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${
                          r.transactionType === 'Loan Received'
                            ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                            : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                        }`}
                      >
                        {r.transactionType === 'Loan Received' ? (
                          <ArrowDownLeft className="w-3 h-3" />
                        ) : (
                          <ArrowUpRight className="w-3 h-3" />
                        )}
                        {r.transactionType}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-extrabold text-slate-900 dark:text-white whitespace-nowrap">
                      {settings.currencySymbol} {r.amount.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {r.paymentMethod}
                    </td>
                    <td className="px-4 py-3 text-slate-500 font-mono text-[11px]">
                      {r.referenceNumber || '—'}
                    </td>
                    <td className="px-4 py-3 text-slate-500 max-w-xs truncate">
                      {r.remarks || '—'}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(r)}
                          className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="Edit"
                          aria-label={`Edit transaction with ${r.person}`}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(r)}
                          className="p-1 rounded text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50"
                          title="Delete"
                          aria-label={`Delete transaction with ${r.person}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Loan Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-rose-600" />
                {editingRecord
                  ? 'Edit Transaction'
                  : activeTab === 'payable'
                  ? 'Add Loan Transaction (Payable)'
                  : 'Add Loan Transaction (Receivable)'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Transaction Type *
                  </label>
                  <select
                    value={transactionType}
                    onChange={(e) => setTransactionType(e.target.value as LoanType)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-semibold"
                  >
                    <option value="Loan Received">
                      {activeTab === 'payable' ? 'Loan Received (+ Payable)' : 'Loan Given (+ Receivable)'}
                    </option>
                    <option value="Loan Repaid">
                      {activeTab === 'payable' ? 'Loan Repaid (- Payable)' : 'Loan Recovered (- Receivable)'}
                    </option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  {t.lender} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Uncle Tariq or Haji Aslam"
                  value={person}
                  onChange={(e) => setPerson(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Amount ({settings.currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    placeholder="100000"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-bold text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Payment Method
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  >
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cash">Cash</option>
                    <option value="Cheque">Cheque</option>
                    <option value="EasyPaisa">EasyPaisa</option>
                    <option value="JazzCash">JazzCash</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Reference / Cheque #
                  </label>
                  <input
                    type="text"
                    placeholder="TXN-XXXX"
                    value={referenceNumber}
                    onChange={(e) => setReferenceNumber(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Remarks
                  </label>
                  <input
                    type="text"
                    placeholder="Terms, return promise, etc."
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm transition"
                >
                  {editingRecord ? 'Update Transaction' : t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
