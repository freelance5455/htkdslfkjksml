import React, { useEffect, useRef, memo } from 'react';
import L from 'leaflet';
import {
  AirportCity,
  Plane,
  CITY_MAP,
  INITIAL_CITIES,
  interpolateLatLng,
  calculateBearing,
  LIVERY_MAP
} from '../game/flightLogic';
import { sound } from '../game/sound';
import { ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';

function getPlaneMarkup(liveryId: string | undefined, isSelected: boolean): string {
  const livery = LIVERY_MAP.get(liveryId || 'default');
  const id = livery?.id || 'default';

  if (id === 'christmas') {
    return `
      <div style="width: 38px; height: 38px; display: flex; align-items: center; justify-content: center; pointer-events: none;">
        <img 
          src="/assets/aistudio/file_00000000eaf88211a0090db038da8bda_6d662669.png" 
          alt="Christmas Flight skin 2026"
          style="width: 38px; height: 38px; object-fit: contain; filter: drop-shadow(0 0 6px rgba(220, 38, 38, 0.95)) drop-shadow(0 0 2px rgba(255, 255, 255, 0.8)); transform: translate3d(0, 0, 0);" 
        />
      </div>
    `;
  }

  // Standard Titanium Tactical
  return `
    <svg width="24" height="24" viewBox="0 0 24 24" style="filter: drop-shadow(0 0 4px rgba(0,0,0,0.8));">
      <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" 
        fill="${isSelected ? '#ffffff' : '#f4f4f5'}" stroke="#000000" stroke-width="1.2" />
    </svg>
  `;
}

interface RealWorldMapProps {
  unlockedCityIds: string[];
  planes: Plane[];
  planesRef?: React.RefObject<Plane[]>;
  selectedCityId: string | null;
  selectedPlaneId: string | null;
  cash: number;
  onSelectCity: (city: AirportCity) => void;
  onSelectPlane: (planeId: string) => void;
  onUnlockCity: (city: AirportCity) => void;
}

export const RealWorldMap: React.FC<RealWorldMapProps> = memo(({
  unlockedCityIds,
  planes,
  planesRef,
  selectedCityId,
  selectedPlaneId,
  cash,
  onSelectCity,
  onSelectPlane,
  onUnlockCity
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);

  // Dedicated layer groups
  const cityMarkersGroupRef = useRef<L.LayerGroup | null>(null);
  const flightRoutesGroupRef = useRef<L.LayerGroup | null>(null);
  const planeMarkersGroupRef = useRef<L.LayerGroup | null>(null);

  // Persistent map of plane markers to avoid DOM re-creation on every tick
  const planeMarkerMapRef = useRef<Map<string, {
    marker: L.Marker;
    svgEl: HTMLElement | null;
    labelEl: HTMLElement | null;
    lastLiveryId?: string;
    lastSelected?: boolean;
  }>>(new Map());

  // Track active routes signature to prevent clearing & recreating polylines during zooming
  const lastRoutesSignatureRef = useRef<string>('');

  // Store latest callbacks and props in refs to prevent map rebuilds
  const propsRef = useRef({
    unlockedCityIds,
    cash,
    selectedCityId,
    selectedPlaneId,
    onSelectCity,
    onSelectPlane,
    onUnlockCity
  });
  propsRef.current = {
    unlockedCityIds,
    cash,
    selectedCityId,
    selectedPlaneId,
    onSelectCity,
    onSelectPlane,
    onUnlockCity
  };

  // Initialize Leaflet Map once with hardware acceleration
  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    // Center on Western USA (between San Francisco and Los Angeles)
    const initialCenter: L.LatLngExpression = [36.2, -120.0];
    const initialZoom = 6;

    const map = L.map(mapContainerRef.current, {
      center: initialCenter,
      zoom: initialZoom,
      minZoom: 2,
      maxZoom: 16,
      zoomControl: false,
      attributionControl: false,
      zoomAnimation: true,
      fadeAnimation: true,
      preferCanvas: true
    });

    // Real-world Esri Dark Gray Base
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
      maxZoom: 16,
      minZoom: 2,
      noWrap: false,
      updateWhenIdle: true,
      keepBuffer: 3
    }).addTo(map);

    // Initialize layer groups in proper z-index order
    flightRoutesGroupRef.current = L.layerGroup().addTo(map);
    cityMarkersGroupRef.current = L.layerGroup().addTo(map);
    planeMarkersGroupRef.current = L.layerGroup().addTo(map);

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Update Airport Nodes on map (Only when unlockedCityIds or selectedCityId changes, NOT every dollar earned!)
  useEffect(() => {
    const group = cityMarkersGroupRef.current;
    if (!group) return;

    group.clearLayers();

    INITIAL_CITIES.forEach(city => {
      const isUnlocked = unlockedCityIds.includes(city.id);
      const isSelected = selectedCityId === city.id;

      const html = isUnlocked
        ? `
          <div class="relative flex items-center justify-center cursor-pointer select-none" style="transform: translate(-50%, -50%);">
            <div class="w-3.5 h-3.5 rounded-full ${isSelected ? 'bg-white ring-2 ring-white scale-125' : 'bg-[#f4f4f5] ring-1 ring-zinc-400'} shadow-lg transition-transform"></div>
            <div class="absolute -top-7 px-1.5 py-0.5 rounded bg-[#090a0f] border ${isSelected ? 'border-white text-white font-bold' : 'border-[#3f3f46] text-[#e4e4e7]'} text-[10px] font-mono whitespace-nowrap shadow-md pointer-events-none">
              ${city.code}
            </div>
            <div class="absolute top-4 text-[10px] font-semibold text-[#f4f4f5] drop-shadow-[0_2px_4px_rgba(0,0,0,1)] whitespace-nowrap pointer-events-none">
              ${city.name}
            </div>
          </div>
        `
        : `
          <div class="relative flex items-center justify-center cursor-pointer select-none opacity-85 hover:opacity-100 transition-opacity" style="transform: translate(-50%, -50%);">
            <div class="w-2.5 h-2.5 rounded-full bg-[#18181b] border border-[#a1a1aa]"></div>
            <div class="absolute -top-6 px-1.5 py-0.5 rounded bg-[#121316] border border-[#3f3f46] text-white font-semibold text-[9px] font-mono whitespace-nowrap pointer-events-none">
              $${city.unlockCost >= 1000 ? `${(city.unlockCost / 1000).toFixed(0)}k` : city.unlockCost}
            </div>
            <div class="absolute top-3.5 text-[9px] text-[#a1a1aa] drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] whitespace-nowrap pointer-events-none">
              ${city.name}
            </div>
          </div>
        `;

      const customIcon = L.divIcon({
        className: 'custom-city-marker',
        html,
        iconSize: [0, 0]
      });

      const marker = L.marker([city.lat, city.lng], { icon: customIcon });

      marker.on('click', () => {
        if (isUnlocked) {
          propsRef.current.onSelectCity(city);
        } else {
          propsRef.current.onUnlockCity(city);
        }
        sound.playClick();
      });

      group.addLayer(marker);
    });
  }, [unlockedCityIds, selectedCityId]);

  // Update Flight Routes (Straight lines between origin and destination!)
  // ONLY updates when route pairs actually change!
  useEffect(() => {
    const routesGroup = flightRoutesGroupRef.current;
    if (!routesGroup) return;

    // Generate unique route signature
    const routePairs: { fromId: string; toId: string; from: AirportCity; to: AirportCity }[] = [];
    const drawnPairs = new Set<string>();

    const activePlanes = planesRef?.current || planes;

    activePlanes.forEach(plane => {
      const from = CITY_MAP.get(plane.fromCityId);
      const to = CITY_MAP.get(plane.toCityId);
      if (!from || !to) return;

      const pairKey = [from.id, to.id].sort().join('-');
      if (drawnPairs.has(pairKey)) return;
      drawnPairs.add(pairKey);
      routePairs.push({ fromId: from.id, toId: to.id, from, to });
    });

    const newSignature = routePairs.map(r => `${r.fromId}-${r.toId}`).sort().join(';');
    if (newSignature === lastRoutesSignatureRef.current) {
      return;
    }

    lastRoutesSignatureRef.current = newSignature;
    routesGroup.clearLayers();

    routePairs.forEach(r => {
      const latlngs: L.LatLngExpression[] = [
        [r.from.lat, r.from.lng],
        [r.to.lat, r.to.lng]
      ];

      // Subtle underglow shadow
      const shadowLine = L.polyline(latlngs, {
        color: '#000000',
        weight: 3.5,
        opacity: 0.9,
        interactive: false
      });

      // Crisp straight white dotted flight line
      const activeLine = L.polyline(latlngs, {
        color: '#ffffff',
        weight: 1.5,
        opacity: 0.8,
        dashArray: '6, 6',
        interactive: false
      });

      routesGroup.addLayer(shadowLine);
      routesGroup.addLayer(activeLine);
    });
  }, [planes]);

  // 60 FPS Butter-Smooth Plane Marker RAF Animation Loop
  // Updates lat/lng and rotation directly on markers without React re-rendering churn!
  useEffect(() => {
    let animId: number;

    const animatePlanes = () => {
      const planesGroup = planeMarkersGroupRef.current;
      if (planesGroup) {
        const currentMarkerMap = planeMarkerMapRef.current;
        const currentPlanes = planesRef?.current || planes;
        const activeIds = new Set(currentPlanes.map(p => p.id));

        // Remove old markers
        currentMarkerMap.forEach((entry, id) => {
          if (!activeIds.has(id)) {
            planesGroup.removeLayer(entry.marker);
            currentMarkerMap.delete(id);
          }
        });

        // Smoothly position and rotate each plane
        currentPlanes.forEach(plane => {
          const from = CITY_MAP.get(plane.fromCityId);
          const to = CITY_MAP.get(plane.toCityId);
          if (!from || !to) return;

          // Straight line interpolation
          const effectiveProgress = plane.isReturning ? 1 - plane.progress : plane.progress;
          const currentPos = interpolateLatLng(from.lat, from.lng, to.lat, to.lng, effectiveProgress);

          // Straight line bearing
          let bearing = calculateBearing(from.lat, from.lng, to.lat, to.lng);
          if (plane.isReturning) {
            bearing = (bearing + 180) % 360;
          }

          const isSelected = propsRef.current.selectedPlaneId === plane.id;
          const planeLiveryId = plane.liveryId || 'default';
          const isChristmas = planeLiveryId === 'christmas';
          const labelPrefix = isChristmas ? '🎄 ' : '';
          const labelColorClass = isChristmas
            ? 'border-red-500/80 text-red-200 bg-[#160606]'
            : (isSelected ? 'border-white text-white bg-[#090a0f]' : 'border-[#3f3f46] text-[#a1a1aa] bg-[#090a0f]');

          let entry = currentMarkerMap.get(plane.id);

          if (!entry) {
            const planeHtml = `
              <div class="plane-container relative flex items-center justify-center cursor-pointer select-none" style="transform: translate(-50%, -50%);">
                <div class="plane-svg" style="transform: rotate(${bearing}deg); will-change: transform;">
                  ${getPlaneMarkup(planeLiveryId, isSelected)}
                </div>
                <div class="plane-label absolute -top-5 left-4 px-1.5 py-0.5 rounded border ${labelColorClass} text-[9px] font-mono font-bold whitespace-nowrap shadow-md pointer-events-none">
                  ${labelPrefix}${plane.name}
                </div>
              </div>
            `;

            const icon = L.divIcon({
              className: 'plane-custom-marker',
              html: planeHtml,
              iconSize: [0, 0]
            });

            const marker = L.marker([currentPos.lat, currentPos.lng], { icon });
            marker.on('click', () => {
              propsRef.current.onSelectPlane(plane.id);
              sound.playClick();
            });

            planesGroup.addLayer(marker);

            const iconElement = marker.getElement();
            const svgEl = iconElement?.querySelector('.plane-svg') as HTMLElement | null;
            const labelEl = iconElement?.querySelector('.plane-label') as HTMLElement | null;

            entry = {
              marker,
              svgEl,
              labelEl,
              lastLiveryId: planeLiveryId,
              lastSelected: isSelected
            };
            currentMarkerMap.set(plane.id, entry);
          } else {
            // Update marker coordinates at 60 FPS
            entry.marker.setLatLng([currentPos.lat, currentPos.lng]);

            if (!entry.svgEl || !entry.labelEl) {
              const el = entry.marker.getElement();
              entry.svgEl = el?.querySelector('.plane-svg') as HTMLElement | null;
              entry.labelEl = el?.querySelector('.plane-label') as HTMLElement | null;
            }

            if (entry.lastLiveryId !== planeLiveryId || entry.lastSelected !== isSelected) {
              entry.lastLiveryId = planeLiveryId;
              entry.lastSelected = isSelected;
              if (entry.svgEl) {
                entry.svgEl.innerHTML = getPlaneMarkup(planeLiveryId, isSelected);
              }
              if (entry.labelEl) {
                entry.labelEl.innerHTML = `${labelPrefix}${plane.name}`;
                entry.labelEl.className = `plane-label absolute -top-5 left-4 px-1.5 py-0.5 rounded border ${labelColorClass} text-[9px] font-mono font-bold whitespace-nowrap shadow-md pointer-events-none`;
              }
            }

            if (entry.svgEl) {
              entry.svgEl.style.transform = `rotate(${bearing}deg)`;
            }
          }
        });
      }

      animId = requestAnimationFrame(animatePlanes);
    };

    animId = requestAnimationFrame(animatePlanes);
    return () => cancelAnimationFrame(animId);
  }, []);

  // Camera focus controls
  const handleZoomIn = () => {
    mapRef.current?.zoomIn();
    sound.playClick();
  };

  const handleZoomOut = () => {
    mapRef.current?.zoomOut();
    sound.playClick();
  };

  const handleFocusUSA = () => {
    mapRef.current?.flyTo([37.0, -96.0], 4, { duration: 1 });
    sound.playRadarPing();
  };

  const handleFocusCalifornia = () => {
    mapRef.current?.flyTo([35.8, -120.4], 6.5, { duration: 1 });
    sound.playRadarPing();
  };

  const handleWorldView = () => {
    mapRef.current?.flyTo([25.0, 10.0], 2.2, { duration: 1.2 });
    sound.playRadarPing();
  };

  return (
    <div className="relative w-full h-full bg-[#07080b] select-none" data-testid="real-world-map">
      {/* Real-world Leaflet Map Surface */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Floating Tactical Map Controls (Right Side) */}
      <div className="absolute bottom-6 right-6 flex flex-col gap-2 z-20">
        <button
          onClick={handleZoomIn}
          aria-label="Zoom In"
          className="p-2.5 bg-[#0e0f14]/95 hover:bg-[#1f2029] text-white border border-[#27272a] rounded-lg shadow-xl transition-colors cursor-pointer"
        >
          <ZoomIn size={18} />
        </button>
        <button
          onClick={handleZoomOut}
          aria-label="Zoom Out"
          className="p-2.5 bg-[#0e0f14]/95 hover:bg-[#1f2029] text-white border border-[#27272a] rounded-lg shadow-xl transition-colors cursor-pointer"
        >
          <ZoomOut size={18} />
        </button>
        <button
          onClick={handleFocusCalifornia}
          aria-label="Focus California Starter Route"
          title="California (SFO - LAX)"
          className="p-2.5 bg-[#0e0f14]/95 hover:bg-[#1f2029] text-white border border-[#27272a] rounded-lg shadow-xl transition-colors font-mono text-xs font-bold cursor-pointer"
        >
          CA
        </button>
        <button
          onClick={handleFocusUSA}
          aria-label="Focus USA Map"
          title="USA National View"
          className="p-2.5 bg-[#0e0f14]/95 hover:bg-[#1f2029] text-white border border-[#27272a] rounded-lg shadow-xl transition-colors font-mono text-xs font-bold cursor-pointer"
        >
          USA
        </button>
        <button
          onClick={handleWorldView}
          aria-label="Full World Map View"
          title="World View"
          className="p-2.5 bg-[#0e0f14]/95 hover:bg-[#1f2029] text-white border border-[#27272a] rounded-lg shadow-xl transition-colors cursor-pointer"
        >
          <Maximize2 size={18} />
        </button>
      </div>

      {/* Real-time Cartographic Status Bar (Bottom Left) */}
      <div className="absolute bottom-6 left-6 z-20 hidden md:flex items-center gap-3 px-3.5 py-2 bg-[#090a0f]/95 border border-[#27272a] rounded-lg text-xs font-mono text-[#a1a1aa] shadow-xl">
        <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
        <span>REAL WORLD MAP · AIRPORT CITIES ONLY · STRAIGHT AIRWAYS</span>
      </div>
    </div>
  );
});
