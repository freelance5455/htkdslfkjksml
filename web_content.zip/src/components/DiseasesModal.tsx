/**
 * HELENA - Biblioteca de Doenças & Patologias Veterinárias
 * Guia clínico completo com etiologia, fisiopatologia, sinais clínicos,
 * métodos diagnósticos, protocolos terapêuticos e medidas profiláticas.
 * Otimizado para celular com filtros por espécie, busca em tempo real e síntese de voz.
 */

import React, { useState, useMemo } from 'react';
import { 
  Stethoscope, 
  Search, 
  Filter, 
  X, 
  Volume2, 
  VolumeX, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  ChevronRight, 
  ChevronDown, 
  ChevronUp, 
  Pill, 
  Microscope, 
  Syringe, 
  FileText,
  BadgeAlert
} from 'lucide-react';
import { VeterinaryDiseaseItem } from '../types';
import { VETERINARY_DISEASES } from '../services/diseasesData';

interface DiseasesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSpeak: (text: string) => void;
}

export const DiseasesModal: React.FC<DiseasesModalProps> = ({
  isOpen,
  onClose,
  onSpeak,
}) => {
  const [searchText, setSearchText] = useState('');
  const [selectedSpecies, setSelectedSpecies] = useState<string>('todas');
  const [selectedCategory, setSelectedCategory] = useState<string>('todas');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Filtered diseases
  const filteredDiseases = useMemo(() => {
    return VETERINARY_DISEASES.filter((d) => {
      // Text search
      const textMatch = !searchText.trim() || 
        d.nome.toLowerCase().includes(searchText.toLowerCase()) ||
        (d.nomeCientifico && d.nomeCientifico.toLowerCase().includes(searchText.toLowerCase())) ||
        d.causa.toLowerCase().includes(searchText.toLowerCase()) ||
        d.tratamento.toLowerCase().includes(searchText.toLowerCase()) ||
        d.sinaisClinicos.some(s => s.toLowerCase().includes(searchText.toLowerCase()));

      // Species filter
      const speciesMatch = selectedSpecies === 'todas' || 
        d.especies.some(esp => esp.toLowerCase() === selectedSpecies.toLowerCase());

      // Category filter
      const categoryMatch = selectedCategory === 'todas' || 
        d.categoria.toLowerCase() === selectedCategory.toLowerCase();

      return textMatch && speciesMatch && categoryMatch;
    });
  }, [searchText, selectedSpecies, selectedCategory]);

  if (!isOpen) return null;

  const handleSpeakSummary = (disease: VeterinaryDiseaseItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const summary = `${disease.nome}. Causa: ${disease.causa} Principais sinais: ${disease.sinaisClinicos.slice(0, 2).join(' ')} Tratamento principal: ${disease.tratamento.slice(0, 300)}`;
    onSpeak(summary);
  };

  const getSeverityBadge = (gravidade: string) => {
    switch (gravidade) {
      case 'Urgência':
        return 'bg-rose-950/50 text-rose-300 border-rose-800';
      case 'Alta':
        return 'bg-amber-950/50 text-amber-300 border-amber-800';
      case 'Moderada':
        return 'bg-yellow-950/40 text-yellow-300 border-yellow-800/60';
      default:
        return 'bg-[#0E7A3D]/40 text-[#2FD16F] border-[#0E7A3D]';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in font-sans">
      <div 
        className="w-full max-w-3xl max-h-[94dvh] flex flex-col rounded-2xl bg-[#030d06] border border-[#14502D] text-[#CDEBD8] shadow-2xl overflow-hidden"
        style={{ borderColor: 'var(--cor-borda)' }}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between px-4 sm:px-5 py-3.5 border-b border-[#14502D]/60 bg-[#06180c]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0E7A3D]/20 border border-[#0E7A3D] flex items-center justify-center text-[#2FD16F] shrink-0">
              <Stethoscope size={22} />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-semibold tracking-wide text-white">
                Guia Clínico de Doenças Veterinárias
              </h2>
              <p className="text-[11px] sm:text-xs text-[#CDEBD8]/70">
                Etiologia, diagnóstico, tratamentos e protocolos de manejo
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#CDEBD8]/70 hover:text-white hover:bg-[#14502D]/40 transition min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
            aria-label="Fechar"
          >
            <X size={20} />
          </button>
        </div>

        {/* Search & Filter Section */}
        <div className="p-3 sm:p-4 border-b border-[#14502D]/50 bg-black/40 space-y-3">
          {/* Search bar */}
          <div className="relative">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#CDEBD8]/50" />
            <input
              type="text"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              placeholder="Buscar por doença, bactéria, vírus, sintomas ou remédio..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/60 border border-[#14502D] text-[#CDEBD8] placeholder-[#CDEBD8]/40 text-sm focus:outline-none focus:border-[#2FD16F] min-h-[44px]"
            />
            {searchText && (
              <button
                onClick={() => setSearchText('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#CDEBD8]/50 hover:text-white"
              >
                Limpar
              </button>
            )}
          </div>

          {/* Filter Chips */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-[11px] text-[#CDEBD8]/60 mr-1 flex items-center gap-1">
              <Filter size={12} /> Espécie:
            </span>
            {['todas', 'cão', 'gato', 'cavalo', 'bovino'].map((esp) => (
              <button
                key={esp}
                onClick={() => setSelectedSpecies(esp)}
                className={`px-3 py-1.5 rounded-lg capitalize transition min-h-[38px] cursor-pointer ${
                  selectedSpecies === esp
                    ? 'bg-[#0E7A3D] text-white border border-[#2FD16F] font-semibold'
                    : 'bg-black/50 text-[#CDEBD8]/70 border border-[#14502D] hover:bg-[#14502D]/40'
                }`}
              >
                {esp}
              </button>
            ))}

            <span className="text-[11px] text-[#CDEBD8]/60 ml-2 mr-1">Categoria:</span>
            {['todas', 'Infecciosa', 'Parasitária', 'Metabólica', 'Gastrointestinal', 'Osteoarticular'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg capitalize transition min-h-[38px] cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#0E7A3D] text-white border border-[#2FD16F] font-semibold'
                    : 'bg-black/50 text-[#CDEBD8]/70 border border-[#14502D] hover:bg-[#14502D]/40'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Diseases List */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-3">
          {filteredDiseases.length === 0 ? (
            <div className="py-12 px-4 rounded-xl border border-dashed border-[#14502D] text-center space-y-2">
              <p className="text-sm text-[#CDEBD8]/70">Nenhuma patologia encontrada com os termos filtrados.</p>
              <button
                onClick={() => {
                  setSearchText('');
                  setSelectedSpecies('todas');
                  setSelectedCategory('todas');
                }}
                className="px-4 py-2 rounded-xl bg-[#0E7A3D] text-white text-xs font-semibold hover:bg-[#17B35A] transition min-h-[44px]"
              >
                Limpar todos os filtros
              </button>
            </div>
          ) : (
            filteredDiseases.map((d) => {
              const isExpanded = expandedId === d.id;
              return (
                <div
                  key={d.id}
                  className="rounded-2xl border border-[#14502D] bg-[#05140a] hover:border-[#2FD16F]/70 transition overflow-hidden shadow-lg"
                >
                  {/* Card Header (Tap to expand) */}
                  <div
                    onClick={() => setExpandedId(isExpanded ? null : d.id)}
                    className="p-4 cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#06190d]/60 hover:bg-[#092212] transition"
                  >
                    <div className="space-y-1 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-sm sm:text-base font-bold text-white tracking-wide">
                          {d.nome}
                        </h3>

                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono border ${getSeverityBadge(d.gravidade)}`}>
                          {d.gravidade}
                        </span>

                        {d.notificacaoObrigatoria && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-red-950/60 text-red-300 border border-red-700 flex items-center gap-1">
                            <BadgeAlert size={12} /> Notificação Obrigatória
                          </span>
                        )}
                      </div>

                      {d.nomeCientifico && (
                        <p className="text-xs text-[#2FD16F] italic font-mono">
                          {d.nomeCientifico}
                        </p>
                      )}

                      <div className="flex items-center gap-2 pt-0.5">
                        <span className="text-[11px] text-[#CDEBD8]/60 capitalize">
                          Espécie(s): <strong className="text-white">{d.especies.join(', ')}</strong>
                        </span>
                        <span className="text-[#14502D]">•</span>
                        <span className="text-[11px] text-[#CDEBD8]/60">
                          {d.categoria}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-auto">
                      <button
                        type="button"
                        onClick={(e) => handleSpeakSummary(d, e)}
                        className="p-2.5 rounded-xl bg-[#0E7A3D]/30 hover:bg-[#0E7A3D] text-[#2FD16F] hover:text-white border border-[#0E7A3D] transition min-h-[42px] min-w-[42px] flex items-center justify-center"
                        title="Ouvir resumo com a voz da HELENA"
                        aria-label="Ouvir com a voz da HELENA"
                      >
                        <Volume2 size={16} />
                      </button>

                      <div className="p-2 text-[#CDEBD8]/60 hover:text-white transition">
                        {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                      </div>
                    </div>
                  </div>

                  {/* Expanded Clinical Details */}
                  {isExpanded && (
                    <div className="p-4 sm:p-5 border-t border-[#14502D]/60 space-y-4 bg-black/50 text-xs sm:text-sm animate-fade-in">
                      {/* Etiologia / Causa */}
                      <div className="space-y-1">
                        <h4 className="text-xs font-semibold text-[#2FD16F] uppercase tracking-wider flex items-center gap-1.5">
                          <Microscope size={14} /> Etiologia & Causa:
                        </h4>
                        <p className="text-xs sm:text-sm text-[#CDEBD8]/90 leading-relaxed pl-5">
                          {d.causa}
                        </p>
                      </div>

                      {/* Transmissão */}
                      {d.transmissao && (
                        <div className="space-y-1">
                          <h4 className="text-xs font-semibold text-[#2FD16F] uppercase tracking-wider flex items-center gap-1.5">
                            <FileText size={14} /> Transmissão & Epidemiologia:
                          </h4>
                          <p className="text-xs sm:text-sm text-[#CDEBD8]/90 leading-relaxed pl-5">
                            {d.transmissao}
                          </p>
                        </div>
                      )}

                      {/* Sinais Clínicos */}
                      <div className="space-y-1.5">
                        <h4 className="text-xs font-semibold text-[#2FD16F] uppercase tracking-wider flex items-center gap-1.5">
                          <AlertTriangle size={14} className="text-amber-400" /> Sinais Clínicos & Sintomas:
                        </h4>
                        <ul className="space-y-1 pl-5">
                          {d.sinaisClinicos.map((s, idx) => (
                            <li key={idx} className="text-xs sm:text-sm text-[#CDEBD8]/90 list-disc list-outside">
                              {s}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Diagnóstico */}
                      <div className="space-y-1">
                        <h4 className="text-xs font-semibold text-[#2FD16F] uppercase tracking-wider flex items-center gap-1.5">
                          <CheckCircle2 size={14} /> Métodos de Diagnóstico:
                        </h4>
                        <p className="text-xs sm:text-sm text-[#CDEBD8]/90 leading-relaxed pl-5">
                          {d.diagnostico}
                        </p>
                      </div>

                      {/* Tratamento & Protocolo Clínico */}
                      <div className="p-3.5 rounded-xl bg-[#061f0e] border border-[#17B35A]/50 space-y-1.5">
                        <h4 className="text-xs font-semibold text-[#2FD16F] uppercase tracking-wider flex items-center gap-1.5">
                          <Pill size={15} /> Tratamento & Conduta Clínica:
                        </h4>
                        <p className="text-xs sm:text-sm text-white leading-relaxed pl-5">
                          {d.tratamento}
                        </p>
                      </div>

                      {/* Prevenção e Profilaxia */}
                      <div className="space-y-1">
                        <h4 className="text-xs font-semibold text-[#2FD16F] uppercase tracking-wider flex items-center gap-1.5">
                          <Syringe size={14} /> Prevenção & Profilaxia:
                        </h4>
                        <p className="text-xs sm:text-sm text-[#CDEBD8]/90 leading-relaxed pl-5">
                          {d.prevencao}
                        </p>
                      </div>

                      {/* Aviso Legal */}
                      <p className="text-[10px] text-[#CDEBD8]/50 pt-2 border-t border-[#14502D]/40 font-mono">
                        Orientação técnica para apoio à decisão clínica. Prescrição privativa do Médico Veterinário com CRMV ativo.
                      </p>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#14502D]/60 bg-[#06180c] flex items-center justify-between text-xs text-[#CDEBD8]/70">
          <span>{filteredDiseases.length} patologias cadastradas</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-black/60 hover:bg-[#14502D]/40 border border-[#14502D] text-xs text-[#CDEBD8] transition min-h-[40px] cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
