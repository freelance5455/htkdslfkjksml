import { useRef, useState } from "react";
import { useStore } from "../lib/store";
import { emptyFS, seedFS } from "../lib/fs";
import { canPickDirectory, importFiles, pickDirectory } from "../lib/workspace";
import { Button, Field, Icon, Sheet } from "./ui";

export default function WorkspaceSheet({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const {
    s,
    importWorkspace,
    exportWorkspace,
    showToast,
    disconnectWorkspace,
  } = useStore();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [name, setName] = useState("");
  const [creating, setCreating] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const choose = async () => {
    setError("");
    setBusy(true);
    try {
      const picked = await pickDirectory();
      if (importWorkspace(picked.fs, "device", picked.handle)) {
        onClose();
        showToast(
          `Connected to ${picked.name}. Writes go directly to this folder.`,
        );
      }
    } catch (e) {
      if (!(e instanceof DOMException && e.name === "AbortError"))
        setError(
          e instanceof Error ? e.message : "Could not open this folder.",
        );
    } finally {
      setBusy(false);
    }
  };
  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Your workspace"
      subtitle="One folder. Everything you need to build."
    >
      <div className="px-5 pb-5">
        <div className="mb-5 flex items-center gap-3 border-b border-line pb-5">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-accentsoft text-accent">
            <Icon name="folderOpen" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate font-medium">{s.workspacePath}</div>
            <div className="mt-1 text-xs text-muted">
              {s.workspaceMode === "device"
                ? "Device folder / direct write"
                : s.workspaceMode === "imported"
                  ? "Imported snapshot / export to save elsewhere"
                  : "Example project / saved in this browser"}
            </div>
          </div>
          <Icon name="check" className="h-4 w-4 text-accent" />
        </div>
        <div className="space-y-1">
          <WorkspaceOption
            icon="folderOpen"
            title={busy ? "Opening folder..." : "Open a device folder"}
            desc={
              canPickDirectory()
                ? "Choose a folder and grant read/write access."
                : "Not supported here. Use Import folder below."
            }
            disabled={busy || !canPickDirectory()}
            onClick={choose}
          />
          <WorkspaceOption
            icon="upload"
            title="Import a folder"
            desc="Edit a local copy, then download your work as ZIP."
            disabled={busy}
            onClick={() => input.current?.click()}
          />
          <WorkspaceOption
            icon="folderPlus"
            title="New workspace"
            desc="Start with an empty folder in this browser."
            onClick={() => setCreating(!creating)}
          />
        </div>
        <input
          ref={(el) => {
            input.current = el;
            el?.setAttribute("webkitdirectory", "");
          }}
          type="file"
          multiple
          className="hidden"
          aria-label="Import workspace folder"
          onChange={async (e) => {
            const files = Array.from(e.target.files ?? []);
            if (!files.length) return;
            setBusy(true);
            setError("");
            try {
              const fs = await importFiles(files);
              importWorkspace(fs, "imported");
              onClose();
              showToast(
                "Folder imported. The original device files are unchanged.",
              );
            } catch (e) {
              setError(e instanceof Error ? e.message : "Import failed.");
            } finally {
              setBusy(false);
              if (input.current) input.current.value = "";
            }
          }}
        />
        {creating && (
          <form
            className="mt-3 flex items-end gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (!/^[\w -]{1,60}$/.test(name.trim())) {
                setError(
                  "Use a name with letters, numbers, spaces, or dashes.",
                );
                return;
              }
              importWorkspace(emptyFS(name.trim()), "demo");
              setCreating(false);
              setName("");
              onClose();
            }}
          >
            <div className="min-w-0 flex-1">
              <Field
                label="Folder name"
                autoFocus
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="my-next-project"
              />
            </div>
            <Button variant="primary" type="submit" className="h-11">
              Create
            </Button>
          </form>
        )}
        {error && (
          <p
            role="alert"
            className="mt-3 rounded-xl bg-dangersoft p-3 text-xs leading-relaxed text-danger"
          >
            {error}
          </p>
        )}
        <div className="mt-4 border-t border-line pt-3">
          <WorkspaceOption
            icon="download"
            title="Export workspace"
            desc="Download all text files as a ZIP archive."
            onClick={exportWorkspace}
          />
          {s.workspaceMode === "device" && (
            <WorkspaceOption
              icon="lock"
              title="Disconnect device folder"
              desc="Keep a snapshot without further device writes."
              onClick={() => {
                disconnectWorkspace();
                onClose();
              }}
            />
          )}
          <button
            onClick={() => {
              importWorkspace(seedFS(), "demo");
              onClose();
            }}
            className="mt-3 text-xs text-muted underline decoration-line2 underline-offset-4 hover:text-fg"
          >
            Open the example project
          </button>
        </div>
        <p className="mt-4 text-[11px] leading-relaxed text-muted">
          Folder access depends on your browser. This is the web build, not an
          APK. Native Android storage and shell execution require a separate
          Android runtime. Binary, dependency and large files are excluded from
          text imports.
        </p>
      </div>
    </Sheet>
  );
}

function WorkspaceOption({
  icon,
  title,
  desc,
  onClick,
  disabled,
}: {
  icon: string;
  title: string;
  desc: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="tap flex w-full items-start gap-3 rounded-xl px-2 py-3 text-left hover:bg-surface2 disabled:opacity-40"
    >
      <Icon name={icon} className="mt-0.5 h-[18px] w-[18px] text-muted" />
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-medium">{title}</span>
        <span className="mt-1 block text-xs leading-relaxed text-muted">
          {desc}
        </span>
      </span>
      <Icon name="chevronRight" className="mt-0.5 h-4 w-4 text-muted" />
    </button>
  );
}
