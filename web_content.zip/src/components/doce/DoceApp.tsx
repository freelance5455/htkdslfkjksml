import { useMemo, useState, type FormEvent, type ReactNode } from "react";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Home as HomeIcon,
  Package,
  Plus,
  Trash2,
  Users,
  Wallet,
} from "lucide-react";
import {
  addMove,
  addOrder,
  adjustStock,
  closeCash,
  dateKey,
  deleteActivity,
  deleteClient,
  deleteOrder,
  deleteStock,
  deliverOrder,
  fmtLong,
  fmtShort,
  lucro,
  money,
  openCash,
  orderPhrase,
  parseDate,
  removeMove,
  reopenCash,
  saveActivity,
  saveClient,
  saveStock,
  setClientStatus,
  toggleActivity,
  troco,
  useDB,
  type Activity,
  type CashDay,
  type ClientStatus,
  type OrderLine,
  type StockKind,
} from "@/lib/doce-store";

type Tab = "inicio" | "caixa" | "clientes" | "estoque" | "agenda";

const STATUS: { id: ClientStatus; label: string }[] = [
  { id: "ok", label: "OK" },
  { id: "devendo", label: "Devendo" },
  { id: "pendente", label: "Pedido pendente" },
];

function statusClass(s: ClientStatus) {
  if (s === "ok") return "bg-good/10 text-good";
  if (s === "devendo") return "bg-blush text-primary";
  return "bg-gold/15 text-gold";
}

export function DoceApp() {
  const [tab, setTab] = useState<Tab>("inicio");
  const db = useDB();
  const today = dateKey();
  const open = db.cash.find((c) => !c.closed) ?? null;

  return (
    <div className="mx-auto min-h-dvh max-w-lg pb-28">
      <header className="px-5 pt-6 pb-2">
        <p className="font-display text-xl text-wine">Doce Confeito</p>
        <p className="text-sm text-muted">{fmtLong(today)}</p>
      </header>
      <main className="px-4">
        {tab === "inicio" && <Inicio db={db} open={open} today={today} go={setTab} />}
        {tab === "caixa" && <Caixa db={db} open={open} today={today} />}
        {tab === "clientes" && <Clientes db={db} />}
        {tab === "estoque" && <Estoque db={db} />}
        {tab === "agenda" && <Agenda db={db} today={today} />}
      </main>
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-paper/95 backdrop-blur">
        <div className="mx-auto grid max-w-lg grid-cols-5 pb-[env(safe-area-inset-bottom)]">
          {(
            [
              ["inicio", "Início", HomeIcon],
              ["caixa", "Caixa", Wallet],
              ["clientes", "Clientes", Users],
              ["estoque", "Estoque", Package],
              ["agenda", "Agenda", CalendarDays],
            ] as const
          ).map(([id, label, Icon]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`flex min-h-16 flex-col items-center justify-center gap-1 text-xs ${
                tab === id ? "font-semibold text-primary" : "text-muted"
              }`}
            >
              <Icon size={20} strokeWidth={tab === id ? 2.4 : 1.8} />
              {label}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

function Inicio({
  db,
  open,
  today,
  go,
}: {
  db: ReturnType<typeof useDB>;
  open: CashDay | null;
  today: string;
  go: (t: Tab) => void;
}) {
  const todayActs = db.activities
    .filter((a) => a.date === today && !a.done)
    .sort((a, b) => (a.time || "99").localeCompare(b.time || "99"));
  const pending = db.orders.filter((o) => o.status === "pendente");
  const low = db.stock.filter((s) => s.qty <= 2);
  const closedToday = db.cash.find((c) => c.date === today && c.closed);

  return (
    <div className="space-y-4">
      <h1 className="mt-2 text-3xl text-wine">Hoje na loja</h1>
      <button type="button" onClick={() => go("caixa")} className="card w-full text-left">
        <p className="text-xs font-semibold tracking-wide text-muted uppercase">Fluxo de caixa</p>
        {open ? (
          <>
            <p className="mt-1 font-display text-2xl text-wine">{money(troco(open))}</p>
            <p className="text-sm text-muted">
              Troco em caixa · aberto em {fmtLong(open.date)} · inicial {money(open.initial)}
            </p>
          </>
        ) : closedToday ? (
          <>
            <p className="mt-1 font-display text-2xl text-good">
              Lucro {money(lucro(closedToday) ?? 0)}
            </p>
            <p className="text-sm text-muted">Caixa de hoje já fechado</p>
          </>
        ) : (
          <p className="mt-2 text-base">Caixa ainda não aberto. Toque para começar o dia.</p>
        )}
      </button>
      <div className="grid grid-cols-2 gap-3">
        <button type="button" onClick={() => go("clientes")} className="card text-left">
          <p className="text-xs text-muted">Pedidos pendentes</p>
          <p className="font-display text-2xl text-wine">{pending.length}</p>
        </button>
        <button type="button" onClick={() => go("estoque")} className="card text-left">
          <p className="text-xs text-muted">Estoque baixo</p>
          <p className="font-display text-2xl text-wine">{low.length}</p>
        </button>
      </div>
      <section>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-xl text-wine">Agenda de hoje</h2>
          <button type="button" className="text-sm font-semibold text-primary" onClick={() => go("agenda")}>
            Ver tudo
          </button>
        </div>
        {todayActs.length === 0 ? (
          <p className="card text-sm text-muted">Nada marcado para hoje.</p>
        ) : (
          todayActs.map((a) => (
            <article key={a.id} className="card mb-2">
              <p className="font-semibold">{a.title}</p>
              <p className="text-sm text-muted">
                {a.time || "Sem horário"} · {a.type}
              </p>
            </article>
          ))
        )}
      </section>
    </div>
  );
}

function Caixa({
  db,
  open,
  today,
}: {
  db: ReturnType<typeof useDB>;
  open: CashDay | null;
  today: string;
}) {
  const [date, setDate] = useState(today);
  const [initial, setInitial] = useState("");
  const [sheet, setSheet] = useState<null | "compra" | "venda" | "fechar">(null);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [counted, setCounted] = useState("");

  const history = db.cash.filter((c) => c.closed);

  function submitOpen(e: FormEvent) {
    e.preventDefault();
    const value = Number(initial.replace(",", "."));
    if (!date || Number.isNaN(value) || value < 0) return;
    openCash(date, value);
    setInitial("");
  }

  function submitMove(e: FormEvent) {
    e.preventDefault();
    if (!open || !sheet || sheet === "fechar") return;
    const value = Number(amount.replace(",", "."));
    if (!value || value <= 0) return;
    addMove(open.date, sheet, value, note);
    setAmount("");
    setNote("");
    setSheet(null);
  }

  function submitClose(e: FormEvent) {
    e.preventDefault();
    if (!open) return;
    const value = Number(counted.replace(",", "."));
    if (Number.isNaN(value) || value < 0) return;
    closeCash(open.date, value);
    setCounted("");
    setSheet(null);
  }

  return (
    <div>
      <h1 className="mt-2 mb-1 text-3xl text-wine">Caixa</h1>
      <p className="mb-4 text-sm text-muted">Abre de manhã e fecha à noite. O lucro é o que tem agora menos o caixa inicial.</p>

      {!open ? (
        <form onSubmit={submitOpen} className="card space-y-3">
          <p className="font-semibold text-wine">Abrir fluxo de caixa</p>
          <label className="block text-sm font-semibold text-wine">
            Dia
            <input className="field mt-1" type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
          </label>
          <label className="block text-sm font-semibold text-wine">
            Caixa inicial (R$)
            <input
              className="field mt-1"
              inputMode="decimal"
              placeholder="0,00"
              value={initial}
              onChange={(e) => setInitial(e.target.value)}
              required
            />
          </label>
          <button className="btn" type="submit">
            Abrir caixa
          </button>
        </form>
      ) : (
        <section className="space-y-3">
          {open.date !== today && (
            <p className="rounded-2xl bg-blush px-4 py-3 text-sm text-wine">
              Este caixa é de {fmtLong(open.date)}. Feche para começar o de hoje.
            </p>
          )}
          <div className="card">
            <p className="text-xs font-semibold tracking-wide text-muted uppercase">Troco em caixa</p>
            <p className="font-display text-4xl text-wine">{money(troco(open))}</p>
            <p className="mt-1 text-sm text-muted">
              Inicial {money(open.initial)} · {fmtLong(open.date)}
            </p>
            <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
              <p>
                Compras{" "}
                <b>
                  {money(open.moves.filter((m) => m.kind === "compra").reduce((s, m) => s + m.amount, 0))}
                </b>
              </p>
              <p>
                Vendas{" "}
                <b>
                  {money(open.moves.filter((m) => m.kind === "venda").reduce((s, m) => s + m.amount, 0))}
                </b>
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" className="btn" onClick={() => setSheet("compra")}>
              Compra
            </button>
            <button type="button" className="btn-ghost" onClick={() => setSheet("venda")}>
              Venda
            </button>
          </div>
          <button type="button" className="btn" onClick={() => setSheet("fechar")}>
            Fechar caixa
          </button>
          <div>
            {open.moves.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted">Nenhuma compra ou venda ainda.</p>
            ) : (
              open.moves.map((m) => (
                <article key={m.id} className="card mb-2 flex items-center justify-between gap-3">
                  <div>
                    <p className="font-semibold">{m.note || (m.kind === "compra" ? "Compra de ingredientes" : "Venda")}</p>
                    <p className="text-sm text-muted">{m.kind === "compra" ? "Saída" : "Entrada"}</p>
                  </div>
                  <div className="text-right">
                    <p className={m.kind === "compra" ? "font-semibold text-primary" : "font-semibold text-good"}>
                      {m.kind === "compra" ? "−" : "+"} {money(m.amount)}
                    </p>
                    <button type="button" className="text-xs text-muted" onClick={() => removeMove(open.date, m.id)}>
                      Apagar
                    </button>
                  </div>
                </article>
              ))
            )}
          </div>
        </section>
      )}

      {history.length > 0 && (
        <section className="mt-6">
          <h2 className="mb-2 text-xl text-wine">Dias fechados</h2>
          {history.map((day) => {
            const gain = lucro(day) ?? 0;
            return (
              <article key={day.date} className="card mb-2">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold capitalize">{fmtLong(day.date)}</p>
                    <p className="text-sm text-muted">
                      Inicial {money(day.initial)} · fechou com {money(day.counted ?? 0)}
                    </p>
                  </div>
                  <p className={gain >= 0 ? "font-semibold text-good" : "font-semibold text-primary"}>
                    {gain >= 0 ? "+" : ""}
                    {money(gain)}
                  </p>
                </div>
                {!db.cash.some((c) => !c.closed) && (
                  <button type="button" className="mt-2 text-sm font-semibold text-primary" onClick={() => reopenCash(day.date)}>
                    Reabrir este dia
                  </button>
                )}
              </article>
            );
          })}
        </section>
      )}

      {sheet === "compra" || sheet === "venda" ? (
        <Sheet title={sheet === "compra" ? "Compra de ingredientes" : "Venda / entrada"} onClose={() => setSheet(null)}>
          <form onSubmit={submitMove} className="space-y-3">
            <label className="block text-sm font-semibold text-wine">
              Valor (R$)
              <input className="field mt-1" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} required autoFocus />
            </label>
            <label className="block text-sm font-semibold text-wine">
              O que foi
              <input
                className="field mt-1"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder={sheet === "compra" ? "Ex: leite condensado" : "Ex: encomenda de trufas"}
              />
            </label>
            <button className="btn" type="submit">
              Lançar
            </button>
          </form>
        </Sheet>
      ) : null}

      {sheet === "fechar" && open ? (
        <Sheet title="Fechar caixa" onClose={() => setSheet(null)}>
          <form onSubmit={submitClose} className="space-y-3">
            <p className="text-sm text-muted">
              Conte o dinheiro que tem agora. O lucro do dia é esse valor menos o caixa inicial ({money(open.initial)}).
            </p>
            <label className="block text-sm font-semibold text-wine">
              Quanto tem agora no caixa?
              <input className="field mt-1" inputMode="decimal" value={counted} onChange={(e) => setCounted(e.target.value)} required autoFocus />
            </label>
            {counted !== "" && !Number.isNaN(Number(counted.replace(",", "."))) && (
              <p className="font-display text-2xl text-wine">
                Lucro {money(Number(counted.replace(",", ".")) - open.initial)}
              </p>
            )}
            <button className="btn" type="submit">
              Fechar o dia
            </button>
          </form>
        </Sheet>
      ) : null}
    </div>
  );
}

function Clientes({ db }: { db: ReturnType<typeof useDB> }) {
  const [part, setPart] = useState<"pessoas" | "pedidos">("pessoas");
  const [clientSheet, setClientSheet] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [statusFor, setStatusFor] = useState<string | null>(null);
  const [wizard, setWizard] = useState(false);

  function openNew() {
    setEditId(null);
    setName("");
    setPhone("");
    setClientSheet(true);
  }

  function openEdit(id: string) {
    const c = db.clients.find((x) => x.id === id);
    if (!c) return;
    setEditId(id);
    setName(c.name);
    setPhone(c.phone);
    setClientSheet(true);
  }

  function submitClient(e: FormEvent) {
    e.preventDefault();
    saveClient({ id: editId ?? undefined, name, phone });
    setClientSheet(false);
  }

  return (
    <div>
      <div className="mt-2 mb-3 flex items-end justify-between gap-3">
        <h1 className="text-3xl text-wine">Clientes</h1>
        {part === "pessoas" ? (
          <button type="button" className="btn w-auto px-4" onClick={openNew}>
            <Plus size={18} /> Novo
          </button>
        ) : (
          <button type="button" className="btn w-auto px-4" onClick={() => setWizard(true)} disabled={!db.clients.length}>
            <Plus size={18} /> Pedido
          </button>
        )}
      </div>
      <div className="mb-4 flex gap-2">
        <button type="button" className={part === "pessoas" ? "pill on" : "pill"} onClick={() => setPart("pessoas")}>
          Clientes
        </button>
        <button type="button" className={part === "pedidos" ? "pill on" : "pill"} onClick={() => setPart("pedidos")}>
          Pedidos
        </button>
      </div>

      {part === "pessoas" &&
        (db.clients.length === 0 ? (
          <p className="card text-sm text-muted">Nenhum cliente ainda. Comece pelo nome. O telefone é opcional.</p>
        ) : (
          db.clients.map((c) => (
            <article key={c.id} className="card mb-2">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate font-semibold">{c.name}</p>
                  <p className="text-sm text-muted">{c.phone || "Sem telefone"}</p>
                </div>
                <button
                  type="button"
                  className={`shrink-0 rounded-full px-3 py-2 text-xs font-bold ${statusClass(c.status)}`}
                  onClick={() => setStatusFor(c.id)}
                >
                  {STATUS.find((s) => s.id === c.status)?.label}
                </button>
              </div>
              <div className="mt-3 flex gap-2">
                <button type="button" className="btn-ghost" onClick={() => openEdit(c.id)}>
                  Editar
                </button>
                <button
                  type="button"
                  className="btn-ghost"
                  onClick={() => {
                    if (confirm("Apagar este cliente e os pedidos dele?")) deleteClient(c.id);
                  }}
                >
                  Apagar
                </button>
              </div>
            </article>
          ))
        ))}

      {part === "pedidos" &&
        (db.orders.length === 0 ? (
          <p className="card text-sm text-muted">Nenhum pedido. O pedido pega o cliente salvo e os itens do estoque.</p>
        ) : (
          db.orders.map((o) => {
            const client = db.clients.find((c) => c.id === o.clientId);
            return (
              <article key={o.id} className="card mb-2">
                <p className="text-xs font-semibold text-muted uppercase">{o.status === "pendente" ? "Pedido pendente" : "Entregue"}</p>
                <p className="mt-1 font-semibold">Pedido para {client?.name || "cliente"}</p>
                <p className="text-sm">{orderPhrase(o.lines)}</p>
                <p className="mt-1 font-display text-xl text-wine">{money(o.total)}</p>
                <p className="text-xs text-muted">{fmtShort(o.date)}</p>
                <div className="mt-3 flex gap-2">
                  {o.status === "pendente" && (
                    <button type="button" className="btn" onClick={() => deliverOrder(o.id)}>
                      Entregue
                    </button>
                  )}
                  <button
                    type="button"
                    className="btn-ghost"
                    onClick={() => {
                      if (confirm("Apagar este pedido?")) deleteOrder(o.id);
                    }}
                  >
                    Apagar
                  </button>
                </div>
              </article>
            );
          })
        ))}

      {clientSheet && (
        <Sheet title={editId ? "Editar cliente" : "Novo cliente"} onClose={() => setClientSheet(false)}>
          <form onSubmit={submitClient} className="space-y-3">
            <label className="block text-sm font-semibold text-wine">
              Nome
              <input className="field mt-1" value={name} onChange={(e) => setName(e.target.value)} required autoFocus />
            </label>
            <label className="block text-sm font-semibold text-wine">
              Telefone (opcional)
              <input className="field mt-1" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </label>
            <button className="btn" type="submit">
              Salvar
            </button>
          </form>
        </Sheet>
      )}

      {statusFor && (
        <Sheet title="Situação do cliente" onClose={() => setStatusFor(null)}>
          <div className="space-y-2">
            {STATUS.map((s) => (
              <button
                key={s.id}
                type="button"
                className="btn-ghost justify-start"
                onClick={() => {
                  setClientStatus(statusFor, s.id);
                  setStatusFor(null);
                }}
              >
                {s.label}
              </button>
            ))}
          </div>
        </Sheet>
      )}

      {wizard && <PedidoWizard db={db} onClose={() => setWizard(false)} />}
    </div>
  );
}

function PedidoWizard({ db, onClose }: { db: ReturnType<typeof useDB>; onClose: () => void }) {
  const [step, setStep] = useState<"cliente" | "item" | "mais" | "valor">("cliente");
  const [clientId, setClientId] = useState(db.clients[0]?.id ?? "");
  const [lines, setLines] = useState<OrderLine[]>([]);
  const [stockId, setStockId] = useState(db.stock[0]?.id ?? "");
  const [qty, setQty] = useState("1");
  const [total, setTotal] = useState("");

  function addLine() {
    const item = db.stock.find((s) => s.id === stockId);
    const n = Number(qty.replace(",", "."));
    if (!item || !n || n <= 0) return;
    setLines((prev) => {
      const found = prev.find((l) => l.stockId === item.id);
      if (found) return prev.map((l) => (l.stockId === item.id ? { ...l, qty: l.qty + n } : l));
      return [...prev, { stockId: item.id, name: item.name, qty: n }];
    });
    setQty("1");
    setStep("mais");
  }

  function finish(e: FormEvent) {
    e.preventDefault();
    const value = Number(total.replace(",", "."));
    if (Number.isNaN(value) || value < 0 || !lines.length) return;
    addOrder(clientId, lines, value);
    onClose();
  }

  const client = db.clients.find((c) => c.id === clientId);

  return (
    <Sheet title="Adicionar pedido" onClose={onClose}>
      {step === "cliente" && (
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-wine">
            De quem é o pedido?
            <select className="field mt-1" value={clientId} onChange={(e) => setClientId(e.target.value)}>
              {db.clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </label>
          <button type="button" className="btn" onClick={() => setStep("item")} disabled={!clientId}>
            Continuar
          </button>
        </div>
      )}
      {step === "item" && (
        <div className="space-y-3">
          {db.stock.length === 0 ? (
            <p className="text-sm text-muted">Cadastre o estoque antes. O pedido escolhe o que já está lá.</p>
          ) : (
            <>
              <label className="block text-sm font-semibold text-wine">
                O que vai querer?
                <select className="field mt-1" value={stockId} onChange={(e) => setStockId(e.target.value)}>
                  {db.stock.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.qty} {s.unit})
                    </option>
                  ))}
                </select>
              </label>
              <label className="block text-sm font-semibold text-wine">
                Quantos?
                <input className="field mt-1" inputMode="decimal" value={qty} onChange={(e) => setQty(e.target.value)} />
              </label>
              <button type="button" className="btn" onClick={addLine}>
                Adicionar
              </button>
            </>
          )}
        </div>
      )}
      {step === "mais" && (
        <div className="space-y-3">
          <p className="text-sm">
            Pedido para <b>{client?.name}</b>: {orderPhrase(lines)}
          </p>
          <p className="font-display text-2xl text-wine">Quer mais alguma coisa?</p>
          <button type="button" className="btn" onClick={() => setStep("item")}>
            Sim, quero mais
          </button>
          <button type="button" className="btn-ghost" onClick={() => setStep("valor")}>
            Não, é só isso
          </button>
        </div>
      )}
      {step === "valor" && (
        <form onSubmit={finish} className="space-y-3">
          <p className="text-sm">
            Pedido para {client?.name}, {orderPhrase(lines)}.
          </p>
          <label className="block text-sm font-semibold text-wine">
            Valor (R$)
            <input className="field mt-1" inputMode="decimal" value={total} onChange={(e) => setTotal(e.target.value)} required autoFocus />
          </label>
          <button className="btn" type="submit">
            Salvar pedido pendente
          </button>
        </form>
      )}
    </Sheet>
  );
}

function Estoque({ db }: { db: ReturnType<typeof useDB> }) {
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [qty, setQty] = useState("0");
  const [unit, setUnit] = useState("un");
  const [kind, setKind] = useState<StockKind>("trufa");

  function startNew() {
    setEditId(null);
    setName("");
    setQty("0");
    setUnit("un");
    setKind("trufa");
    setOpen(true);
  }

  function startEdit(id: string) {
    const s = db.stock.find((x) => x.id === id);
    if (!s) return;
    setEditId(id);
    setName(s.name);
    setQty(String(s.qty));
    setUnit(s.unit);
    setKind(s.kind);
    setOpen(true);
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    const n = Number(qty.replace(",", "."));
    if (Number.isNaN(n) || n < 0) return;
    saveStock({ id: editId ?? undefined, name, qty: n, unit, kind });
    setOpen(false);
  }

  const groups: { id: StockKind; label: string }[] = [
    { id: "trufa", label: "Trufas" },
    { id: "ingrediente", label: "Ingredientes" },
    { id: "outro", label: "Outros" },
  ];

  return (
    <div>
      <div className="mt-2 mb-4 flex items-end justify-between">
        <div>
          <h1 className="text-3xl text-wine">Estoque</h1>
          <p className="text-sm text-muted">Qualquer ingrediente ou trufa, com a quantidade.</p>
        </div>
        <button type="button" className="btn w-auto px-4" onClick={startNew}>
          <Plus size={18} /> Item
        </button>
      </div>
      {db.stock.length === 0 && <p className="card text-sm text-muted">Nada no estoque. Exemplo: leite condensado, creme de leite, trufa de chocolate.</p>}
      {groups.map((g) => {
        const items = db.stock.filter((s) => s.kind === g.id);
        if (!items.length) return null;
        return (
          <section key={g.id} className="mb-4">
            <h2 className="mb-2 text-lg text-wine">{g.label}</h2>
            {items.map((s) => (
              <article key={s.id} className="card mb-2 flex items-center gap-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{s.name}</p>
                  <p className={`text-sm ${s.qty <= 2 ? "text-primary" : "text-muted"}`}>
                    {s.qty} {s.unit}
                  </p>
                </div>
                <button type="button" className="iconbtn" onClick={() => adjustStock(s.id, -1)} aria-label="Diminuir">
                  −
                </button>
                <button type="button" className="iconbtn" onClick={() => adjustStock(s.id, 1)} aria-label="Aumentar">
                  +
                </button>
                <button type="button" className="text-sm font-semibold text-primary" onClick={() => startEdit(s.id)}>
                  Editar
                </button>
                <button
                  type="button"
                  aria-label="Apagar"
                  className="text-muted"
                  onClick={() => {
                    if (confirm("Apagar este item?")) deleteStock(s.id);
                  }}
                >
                  <Trash2 size={18} />
                </button>
              </article>
            ))}
          </section>
        );
      })}
      {open && (
        <Sheet title={editId ? "Editar item" : "Novo item"} onClose={() => setOpen(false)}>
          <form onSubmit={submit} className="space-y-3">
            <label className="block text-sm font-semibold text-wine">
              Nome
              <input className="field mt-1" value={name} onChange={(e) => setName(e.target.value)} placeholder="Trufa de chocolate" required autoFocus />
            </label>
            <label className="block text-sm font-semibold text-wine">
              Tipo
              <select className="field mt-1" value={kind} onChange={(e) => setKind(e.target.value as StockKind)}>
                <option value="trufa">Trufa</option>
                <option value="ingrediente">Ingrediente</option>
                <option value="outro">Outro</option>
              </select>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <label className="block text-sm font-semibold text-wine">
                Quantidade
                <input className="field mt-1" inputMode="decimal" value={qty} onChange={(e) => setQty(e.target.value)} required />
              </label>
              <label className="block text-sm font-semibold text-wine">
                Unidade
                <input className="field mt-1" value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="un, g, ml" />
              </label>
            </div>
            <button className="btn" type="submit">
              Salvar
            </button>
          </form>
        </Sheet>
      )}
    </div>
  );
}

function Agenda({ db, today }: { db: ReturnType<typeof useDB>; today: string }) {
  const [mode, setMode] = useState<"day" | "week" | "month">("day");
  const [cursor, setCursor] = useState(today);
  const [sheet, setSheet] = useState(false);
  const [edit, setEdit] = useState<Activity | null>(null);
  const [title, setTitle] = useState("");
  const [date, setDate] = useState(today);
  const [time, setTime] = useState("");
  const [type, setType] = useState<Activity["type"]>("Tarefa");
  const [category, setCategory] = useState("Empresa");
  const [notes, setNotes] = useState("");

  function shift(n: number) {
    const d = parseDate(cursor);
    if (mode === "month") d.setMonth(d.getMonth() + n);
    else d.setDate(d.getDate() + n * (mode === "week" ? 7 : 1));
    setCursor(dateKey(d));
  }

  function openNew(day = cursor, t = "") {
    setEdit(null);
    setTitle("");
    setDate(day);
    setTime(t);
    setType("Tarefa");
    setCategory("Empresa");
    setNotes("");
    setSheet(true);
  }

  function openEdit(a: Activity) {
    setEdit(a);
    setTitle(a.title);
    setDate(a.date);
    setTime(a.time);
    setType(a.type);
    setCategory(a.category);
    setNotes(a.notes);
    setSheet(true);
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    saveActivity({ id: edit?.id, title, date, time, type, category, notes });
    setSheet(false);
  }

  const dayItems = db.activities
    .filter((a) => a.date === cursor)
    .sort((a, b) => (a.time || "99").localeCompare(b.time || "99"));

  const monthCells = useMemo(() => {
    const d = parseDate(cursor);
    const first = new Date(d.getFullYear(), d.getMonth(), 1);
    const start = new Date(first);
    start.setDate(1 - first.getDay());
    return Array.from({ length: 42 }, (_, i) => {
      const x = new Date(start);
      x.setDate(start.getDate() + i);
      return dateKey(x);
    });
  }, [cursor]);

  const week = useMemo(() => {
    const d = parseDate(cursor);
    const start = new Date(d);
    start.setDate(d.getDate() - d.getDay());
    return Array.from({ length: 7 }, (_, i) => {
      const x = new Date(start);
      x.setDate(start.getDate() + i);
      return dateKey(x);
    });
  }, [cursor]);

  const titleText =
    mode === "day"
      ? parseDate(cursor).toLocaleDateString("pt-BR", { weekday: "short", day: "numeric", month: "short" })
      : parseDate(cursor).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

  return (
    <div>
      <div className="mt-2 mb-3 flex items-end justify-between">
        <h1 className="text-3xl text-wine">Agenda</h1>
        <button type="button" className="btn w-auto px-4" onClick={() => openNew()}>
          <Plus size={18} /> Novo
        </button>
      </div>
      <div className="mb-3 flex gap-2">
        {(
          [
            ["day", "Dia"],
            ["week", "Semana"],
            ["month", "Mês"],
          ] as const
        ).map(([id, label]) => (
          <button key={id} type="button" className={mode === id ? "pill on" : "pill"} onClick={() => setMode(id)}>
            {label}
          </button>
        ))}
      </div>
      <div className="mb-3 flex items-center justify-between">
        <button type="button" className="iconbtn" onClick={() => shift(-1)} aria-label="Anterior">
          <ChevronLeft size={18} />
        </button>
        <p className="font-display text-lg capitalize text-wine">{titleText}</p>
        <button type="button" className="iconbtn" onClick={() => shift(1)} aria-label="Próximo">
          <ChevronRight size={18} />
        </button>
      </div>
      <button type="button" className="mb-3 text-sm font-semibold text-primary" onClick={() => setCursor(today)}>
        Ir para hoje
      </button>

      {mode === "month" && (
        <div className="grid grid-cols-7 gap-1">
          {["D", "S", "T", "Q", "Q", "S", "S"].map((d, i) => (
            <p key={d + i} className="py-1 text-center text-xs text-muted">
              {d}
            </p>
          ))}
          {monthCells.map((key) => {
            const count = db.activities.filter((a) => a.date === key).length;
            const outside = parseDate(key).getMonth() !== parseDate(cursor).getMonth();
            return (
              <button
                key={key}
                type="button"
                onClick={() => {
                  setCursor(key);
                  setMode("day");
                }}
                className={`min-h-12 rounded-xl border text-sm ${
                  key === cursor ? "border-primary bg-primary text-paper" : "border-line bg-paper text-ink"
                } ${outside ? "opacity-40" : ""}`}
              >
                {parseDate(key).getDate()}
                {count > 0 && <span className="mt-1 block text-xs leading-none">{count}</span>}
              </button>
            );
          })}
        </div>
      )}

      {mode === "week" && (
        <div className="grid grid-cols-7 gap-1">
          {week.map((key, i) => {
            const items = db.activities.filter((a) => a.date === key);
            return (
              <button
                key={key}
                type="button"
                onClick={() => {
                  setCursor(key);
                  setMode("day");
                }}
                className="min-h-28 rounded-xl border border-line bg-paper p-1 text-center"
              >
                <b className="text-xs text-wine">{["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SÁB"][i]}</b>
                <span className="block text-xs text-muted">{parseDate(key).getDate()}</span>
                {items.slice(0, 3).map((a) => (
                  <span key={a.id} className="mt-1 block truncate rounded bg-blush px-1 text-xs text-wine">
                    {a.title}
                  </span>
                ))}
              </button>
            );
          })}
        </div>
      )}

      {mode === "day" && (
        <div>
          {dayItems.length === 0 && <p className="card text-sm text-muted">Nada neste dia.</p>}
          {dayItems.map((a) => (
            <article key={a.id} className="card mb-2 flex gap-3">
              <input
                type="checkbox"
                className="mt-1 size-5 accent-primary"
                checked={a.done}
                onChange={() => toggleActivity(a.id)}
                aria-label="Concluir"
              />
              <div className="min-w-0 flex-1">
                <p className={`font-semibold ${a.done ? "text-muted line-through" : ""}`}>{a.title}</p>
                <p className="text-sm text-muted">
                  {a.time || "Sem horário"} · {a.type} · {a.category}
                </p>
                {a.notes && <p className="text-sm">{a.notes}</p>}
                <div className="mt-2 flex gap-2">
                  <button type="button" className="text-sm font-semibold text-primary" onClick={() => openEdit(a)}>
                    Editar
                  </button>
                  <button
                    type="button"
                    className="text-sm text-muted"
                    onClick={() => {
                      if (confirm("Apagar esta atividade?")) deleteActivity(a.id);
                    }}
                  >
                    Apagar
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {sheet && (
        <Sheet title={edit ? "Editar" : "Nova atividade"} onClose={() => setSheet(false)}>
          <form onSubmit={submit} className="space-y-3">
            <div className="flex gap-2">
              <button type="button" className={type === "Tarefa" ? "pill on" : "pill"} onClick={() => setType("Tarefa")}>
                Tarefa
              </button>
              <button type="button" className={type === "Compromisso" ? "pill on" : "pill"} onClick={() => setType("Compromisso")}>
                Compromisso
              </button>
            </div>
            <label className="block text-sm font-semibold text-wine">
              Título
              <input className="field mt-1" value={title} onChange={(e) => setTitle(e.target.value)} required autoFocus />
            </label>
            <div className="grid grid-cols-2 gap-2">
              <label className="block text-sm font-semibold text-wine">
                Data
                <input className="field mt-1" type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
              </label>
              <label className="block text-sm font-semibold text-wine">
                Horário
                <input className="field mt-1" type="time" value={time} onChange={(e) => setTime(e.target.value)} />
              </label>
            </div>
            <label className="block text-sm font-semibold text-wine">
              Categoria
              <select className="field mt-1" value={category} onChange={(e) => setCategory(e.target.value)}>
                <option>Empresa</option>
                <option>Faculdade</option>
                <option>Clientes</option>
                <option>Pessoal</option>
              </select>
            </label>
            <label className="block text-sm font-semibold text-wine">
              Anotação
              <textarea className="field mt-1 min-h-20" value={notes} onChange={(e) => setNotes(e.target.value)} />
            </label>
            <button className="btn" type="submit">
              Salvar
            </button>
          </form>
        </Sheet>
      )}
    </div>
  );
}

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-ink/40" onClick={onClose}>
      <div
        className="max-h-[90dvh] w-full max-w-lg overflow-auto rounded-t-3xl bg-paper p-5 pb-8"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-line" />
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-2xl text-wine">{title}</h2>
          <button type="button" className="iconbtn" onClick={onClose} aria-label="Fechar">
            ×
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
