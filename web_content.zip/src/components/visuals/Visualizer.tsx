import { useMemo, useState } from "react";
import type { ComputedResult, Formula, VariableInput } from "../../data/types";
import { VariableSlider, ResultCard } from "./Controls";
import { fmt } from "../../utils/format";

// ---------- small math/geometry helpers ----------
function findInput(inputs: VariableInput[], symbol: string): VariableInput | undefined {
  return inputs.find((i) => i.symbol === symbol);
}
function lerp(value: number, inMin: number, inMax: number, outMin: number, outMax: number) {
  if (inMax === inMin) return (outMin + outMax) / 2;
  const t = (value - inMin) / (inMax - inMin);
  const clamped = Math.max(0, Math.min(1, t));
  return outMin + clamped * (outMax - outMin);
}
function toPx(inputs: VariableInput[], symbol: string, value: number, outMin: number, outMax: number, fallback: [number, number] = [0, 10]) {
  const inp = findInput(inputs, symbol);
  const [mn, mx] = inp ? [inp.min, inp.max] : fallback;
  return lerp(value, mn, mx, outMin, outMax);
}
const SX = (x: number) => 150 + x * 13;
const SY = (y: number) => 150 - y * 13;

function clipLine(m: number, c: number, lim = 10): [[number, number], [number, number]] | null {
  const candidates = [-lim, lim];
  if (m !== 0) {
    candidates.push((-lim - c) / m);
    candidates.push((lim - c) / m);
  }
  const pts = candidates
    .map((x) => ({ x, y: m * x + c }))
    .filter((p) => p.x >= -lim - 1e-6 && p.x <= lim + 1e-6 && p.y >= -lim - 1e-6 && p.y <= lim + 1e-6);
  if (pts.length < 2) return null;
  pts.sort((a, b) => a.x - b.x);
  return [
    [pts[0].x, pts[0].y],
    [pts[pts.length - 1].x, pts[pts.length - 1].y],
  ];
}

function Grid() {
  const lines = [];
  for (let i = -10; i <= 10; i += 2) {
    lines.push(<line key={`v${i}`} x1={SX(i)} y1={SY(-10)} x2={SX(i)} y2={SY(10)} stroke="#e2e8f0" strokeWidth={1} />);
    lines.push(<line key={`h${i}`} x1={SX(-10)} y1={SY(i)} x2={SX(10)} y2={SY(i)} stroke="#e2e8f0" strokeWidth={1} />);
  }
  return (
    <g className="dark:opacity-20">
      {lines}
      <line x1={SX(-10)} y1={SY(0)} x2={SX(10)} y2={SY(0)} stroke="#94a3b8" strokeWidth={1.5} />
      <line x1={SX(0)} y1={SY(-10)} x2={SX(0)} y2={SY(10)} stroke="#94a3b8" strokeWidth={1.5} />
    </g>
  );
}

function Stage({ children, height = "h-56 sm:h-72" }: { children: React.ReactNode; height?: string }) {
  return (
    <div className={`w-full ${height} rounded-xl border border-slate-200 bg-slate-50/70 dark:border-slate-700 dark:bg-slate-900/40`}>
      <svg viewBox="0 0 300 300" className="h-full w-full">
        {children}
      </svg>
    </div>
  );
}

const C1 = "#6366f1"; // indigo
const C2 = "#a855f7"; // purple
const C3 = "#22c55e"; // green
const C4 = "#f59e0b"; // amber
const C5 = "#ef4444"; // red

// ---------- main dispatcher ----------
export function VisualStage({
  formula,
  values,
  results,
}: {
  formula: Formula;
  values: Record<string, number>;
  results: ComputedResult[];
}) {
  const { kind, mode, shape } = formula.visual;
  const inputs = formula.interactive.inputs;

  switch (kind) {
    case "circle":
      return <CircleViz inputs={inputs} values={values} mode={mode} />;
    case "rect-square":
      return <RectViz inputs={inputs} values={values} shape={shape} />;
    case "triangle":
      return <TriangleViz inputs={inputs} values={values} mode={mode} />;
    case "parallelogram":
      return <ParallelogramViz inputs={inputs} values={values} />;
    case "trapezium":
      return <TrapeziumViz inputs={inputs} values={values} />;
    case "rhombus":
      return <RhombusViz inputs={inputs} values={values} />;
    case "polygon":
      return <PolygonViz inputs={inputs} values={values} mode={mode} />;
    case "identity-square":
      return <IdentitySquareViz values={values} mode={mode} />;
    case "solid3d":
      return <Solid3DViz inputs={inputs} values={values} shape={shape} />;
    case "linear-graph":
      return <LinearGraphViz values={values} mode={mode} />;
    case "quadratic-graph":
      return <QuadraticGraphViz values={values} />;
    case "inverse-graph":
      return <InverseGraphViz values={values} />;
    case "coordinate-geometry":
      return <CoordinateGeometryViz values={values} mode={mode} />;
    case "number-line":
      return <NumberLineViz values={values} mode={mode} results={results} />;
    case "ap-sequence":
      return <ApSequenceViz values={values} mode={mode} />;
    case "trig-circle":
      return <TrigCircleViz values={values} mode={mode} />;
    case "heights-distances":
      return <HeightsDistancesViz inputs={inputs} values={values} results={results} />;
    case "motion":
      return <MotionViz inputs={inputs} values={values} mode={mode} />;
    case "ohms-law":
      return <OhmsLawViz values={values} results={results} />;
    case "resistance-combo":
      return <ResistanceComboViz values={values} mode={mode} results={results} />;
    case "mirror-lens":
      return <MirrorLensViz values={values} results={results} mode={mode} />;
    case "refraction":
      return <RefractionViz values={values} />;
    case "sound-wave":
      return <SoundWaveViz inputs={inputs} values={values} mode={mode} results={results} />;
    case "density":
      return <DensityViz results={results} mode={mode} />;
    case "stats":
      return <StatsViz values={values} mode={mode} />;
    case "probability":
      return <ProbabilityViz values={values} results={results} />;
    case "mole":
      return <MoleViz results={results} mode={mode} />;
    case "interest-growth":
      return <InterestGrowthViz values={values} mode={mode} />;
    case "percentage-bar":
      return <PercentageBarViz results={results} />;
    case "sdt-triangle":
      return <SdtTriangleViz values={values} results={results} />;
    case "valency":
      return <ValencyViz values={values} results={results} />;
    case "reaction-explorer":
      return <ReactionExplorerViz values={values} />;
    default:
      return <CalculatorViz formula={formula} values={values} results={results} />;
  }
}

// ---------- Geometry visuals ----------
function CircleViz({ inputs, values, mode }: { inputs: VariableInput[]; values: Record<string, number>; mode?: string }) {
  const r = toPx(inputs, "r", values.r, 25, 95, [1, 20]);
  const cx = 150,
    cy = 150;

  if (mode === "sector" || mode === "arc" || mode === "segment") {
    const theta = values.theta ?? 90;
    const rad = (theta * Math.PI) / 180;
    const p1 = [cx, cy - r];
    const p2 = [cx + r * Math.sin(rad), cy - r * Math.cos(rad)];
    const largeArc = theta > 180 ? 1 : 0;
    return (
      <Stage>
        <circle cx={cx} cy={cy} r={r} fill="none" stroke="#cbd5e1" strokeWidth={1.5} />
        {mode === "arc" ? (
          <>
            <path d={`M ${p1[0]} ${p1[1]} A ${r} ${r} 0 ${largeArc} 1 ${p2[0]} ${p2[1]}`} fill="none" stroke={C1} strokeWidth={5} strokeLinecap="round" />
            <line x1={cx} y1={cy} x2={p1[0]} y2={p1[1]} stroke="#94a3b8" strokeDasharray="4 3" />
            <line x1={cx} y1={cy} x2={p2[0]} y2={p2[1]} stroke="#94a3b8" strokeDasharray="4 3" />
          </>
        ) : (
          <>
            <path d={`M ${cx} ${cy} L ${p1[0]} ${p1[1]} A ${r} ${r} 0 ${largeArc} 1 ${p2[0]} ${p2[1]} Z`} fill={mode === "segment" ? "rgba(99,102,241,0.18)" : "rgba(99,102,241,0.35)"} stroke={C1} strokeWidth={2} />
            {mode === "segment" && <path d={`M ${cx} ${cy} L ${p1[0]} ${p1[1]} L ${p2[0]} ${p2[1]} Z`} fill="rgba(245,158,11,0.45)" stroke={C4} strokeWidth={1.5} />}
          </>
        )}
        <circle cx={cx} cy={cy} r={2.5} fill="#334155" />
        <text x={cx + 6} y={cy - 6} fontSize={11} fill="#475569">θ={fmt(theta, 0)}°</text>
      </Stage>
    );
  }

  if (mode === "tangent") {
    const d = values.d ?? 13;
    const rVal = values.r ?? 5;
    const dPx = toPx(inputs, "d", d, r + 30, 230, [2, 30]);
    const px = cx + dPx;
    const alpha = Math.acos(Math.min(1, rVal / d));
    const tx = cx + r * Math.cos(alpha);
    const ty = cy - r * Math.sin(alpha);
    return (
      <Stage>
        <circle cx={cx} cy={cy} r={r} fill="rgba(99,102,241,0.12)" stroke={C1} strokeWidth={2} />
        <circle cx={cx} cy={cy} r={2.5} fill="#334155" />
        <line x1={cx} y1={cy} x2={px} y2={cy} stroke="#94a3b8" strokeDasharray="4 3" />
        <line x1={cx} y1={cy} x2={tx} y2={ty} stroke={C3} strokeWidth={2} />
        <line x1={px} y1={cy} x2={tx} y2={ty} stroke={C4} strokeWidth={3} />
        <circle cx={px} cy={cy} r={3} fill="#334155" />
        <circle cx={tx} cy={ty} r={3} fill={C4} />
        <text x={px - 10} y={cy + 18} fontSize={11} fill="#475569">external pt</text>
        <text x={(px + tx) / 2 + 5} y={(cy + ty) / 2} fontSize={11} fill="#b45309">tangent</text>
      </Stage>
    );
  }

  // default: area / circumference
  const filled = mode !== "circumference";
  return (
    <Stage>
      <circle cx={cx} cy={cy} r={r} fill={filled ? "rgba(99,102,241,0.25)" : "none"} stroke={C1} strokeWidth={filled ? 2 : 4} />
      <line x1={cx} y1={cy} x2={cx + r} y2={cy} stroke="#475569" strokeWidth={2} strokeDasharray="5 4" />
      <circle cx={cx} cy={cy} r={2.5} fill="#334155" />
      <text x={cx + r / 2 - 6} y={cy - 6} fontSize={12} fill="#334155">r</text>
    </Stage>
  );
}

function RectViz({ inputs, values, shape }: { inputs: VariableInput[]; values: Record<string, number>; shape?: string }) {
  const isSquare = shape === "square";
  const w = isSquare ? toPx(inputs, "a", values.a, 40, 190, [1, 20]) : toPx(inputs, "l", values.l, 40, 190, [1, 20]);
  const h = isSquare ? w : toPx(inputs, "b", values.b, 30, 160, [1, 20]);
  const x = 150 - w / 2;
  const y = 150 - h / 2;
  return (
    <Stage>
      <rect x={x} y={y} width={w} height={h} fill="rgba(99,102,241,0.25)" stroke={C1} strokeWidth={2} rx={2} />
      <text x={150} y={y - 10} textAnchor="middle" fontSize={12} fill="#334155">{isSquare ? "a" : "l"}</text>
      <text x={x - 14} y={150} textAnchor="middle" fontSize={12} fill="#334155">{isSquare ? "a" : "b"}</text>
    </Stage>
  );
}

function TriangleViz({ inputs, values, mode }: { inputs: VariableInput[]; values: Record<string, number>; mode?: string }) {
  if (mode === "pythagoras") {
    const scale = 60 / Math.max(values.a, values.b, 6);
    const a = values.a * scale;
    const b = values.b * scale;
    const x0 = 110,
      y0 = 190;
    const p1 = [x0, y0];
    const p2 = [x0 + b, y0];
    const p3 = [x0, y0 - a];
    const dx = p3[0] - p2[0],
      dy = p3[1] - p2[1];
    const hyp = Math.sqrt(dx * dx + dy * dy);
    let nx = -dy / hyp,
      ny = dx / hyp;
    const mid = [(p2[0] + p3[0]) / 2, (p2[1] + p3[1]) / 2];
    const awayX = mid[0] - p1[0],
      awayY = mid[1] - p1[1];
    if (nx * awayX + ny * awayY < 0) {
      nx = -nx;
      ny = -ny;
    }
    const p4 = [p2[0] + nx * hyp, p2[1] + ny * hyp];
    const p5 = [p3[0] + nx * hyp, p3[1] + ny * hyp];
    return (
      <Stage height="h-64 sm:h-80">
        {/* square on b (base) */}
        <polygon points={`${p1[0]},${p1[1]} ${p2[0]},${p2[1]} ${p2[0]},${p2[1] + b} ${p1[0]},${p1[1] + b}`} fill="rgba(34,197,94,0.25)" stroke={C3} strokeWidth={1.5} />
        {/* square on a (left) */}
        <polygon points={`${p1[0]},${p1[1]} ${p3[0]},${p3[1]} ${p3[0] - a},${p3[1]} ${p1[0] - a},${p1[1]}`} fill="rgba(245,158,11,0.25)" stroke={C4} strokeWidth={1.5} />
        {/* square on hypotenuse */}
        <polygon points={`${p2[0]},${p2[1]} ${p3[0]},${p3[1]} ${p5[0]},${p5[1]} ${p4[0]},${p4[1]}`} fill="rgba(99,102,241,0.25)" stroke={C1} strokeWidth={1.5} />
        {/* triangle */}
        <polygon points={`${p1[0]},${p1[1]} ${p2[0]},${p2[1]} ${p3[0]},${p3[1]}`} fill="white" fillOpacity={0.6} stroke="#334155" strokeWidth={2} />
        <rect x={p1[0]} y={p1[1] - 10} width={10} height={10} fill="none" stroke="#334155" />
        <text x={(p1[0] + p2[0]) / 2} y={p1[1] + 14} fontSize={12} fill="#334155">b</text>
        <text x={p1[0] - 14} y={(p1[1] + p3[1]) / 2} fontSize={12} fill="#334155">a</text>
        <text x={(p2[0] + p3[0]) / 2 + 6} y={(p2[1] + p3[1]) / 2 - 4} fontSize={12} fill="#334155">c</text>
      </Stage>
    );
  }

  if (mode === "heron") {
    const a = values.a,
      b = values.b,
      c = values.c;
    const scale = 150 / Math.max(a, b, c, 1);
    const A = a * scale,
      B = b * scale,
      C = c * scale;
    const P1 = [60, 220];
    const P2 = [60 + C, 220];
    const cosA = (B * B + C * C - A * A) / (2 * B * C || 1);
    const angle = Math.acos(Math.max(-1, Math.min(1, cosA)));
    const P3 = [P1[0] + B * Math.cos(angle), P1[1] - B * Math.sin(angle)];
    return (
      <Stage>
        <polygon points={`${P1[0]},${P1[1]} ${P2[0]},${P2[1]} ${P3[0]},${P3[1]}`} fill="rgba(99,102,241,0.2)" stroke={C1} strokeWidth={2} />
        <text x={(P1[0] + P2[0]) / 2} y={P1[1] + 16} fontSize={12} fill="#334155">c = {fmt(c)}</text>
        <text x={(P1[0] + P3[0]) / 2 - 18} y={(P1[1] + P3[1]) / 2} fontSize={12} fill="#334155">b = {fmt(b)}</text>
        <text x={(P2[0] + P3[0]) / 2 + 6} y={(P2[1] + P3[1]) / 2} fontSize={12} fill="#334155">a = {fmt(a)}</text>
      </Stage>
    );
  }

  if (mode === "angles" || mode === "exterior-angle") {
    const P1 = [60, 230];
    const P2 = [240, 230];
    const P3 = [140, 90];
    const extend = mode === "exterior-angle" ? [280, 230] : null;
    return (
      <Stage>
        <polygon points={`${P1[0]},${P1[1]} ${P2[0]},${P2[1]} ${P3[0]},${P3[1]}`} fill="rgba(99,102,241,0.15)" stroke={C1} strokeWidth={2} />
        {extend && <line x1={P2[0]} y1={P2[1]} x2={extend[0]} y2={extend[1]} stroke="#334155" strokeWidth={2} strokeDasharray="5 3" />}
        <text x={P1[0] - 8} y={P1[1] + 18} fontSize={12} fill="#334155">{mode === "angles" ? `${fmt(values.A,0)}°` : `${fmt(values.A,0)}°`}</text>
        <text x={P2[0] - 20} y={P2[1] + 18} fontSize={12} fill="#334155">{`${fmt(values.B,0)}°`}</text>
        {mode === "angles" ? (
          <text x={P3[0] - 6} y={P3[1] - 10} fontSize={12} fill={C3} fontWeight={600}>{`${fmt(180 - values.A - values.B,0)}°`}</text>
        ) : (
          <text x={P2[0] + 10} y={P2[1] - 10} fontSize={12} fill={C3} fontWeight={600}>{`ext=${fmt(values.A + values.B,0)}°`}</text>
        )}
      </Stage>
    );
  }

  if (mode === "similar") {
    const s1 = toPx(inputs, "s1", values.s1, 20, 60, [1, 20]);
    const s2 = toPx(inputs, "s2", values.s2, 20, 100, [1, 20]);
    return (
      <Stage>
        <polygon points={`60,220 ${60 + s1},220 60,${220 - s1}`} fill="rgba(99,102,241,0.3)" stroke={C1} strokeWidth={2} />
        <polygon points={`150,220 ${150 + s2},220 150,${220 - s2}`} fill="rgba(168,85,247,0.25)" stroke={C2} strokeWidth={2} />
        <text x={70} y={240} fontSize={11} fill="#334155">side={fmt(values.s1)}</text>
        <text x={160} y={240} fontSize={11} fill="#334155">side={fmt(values.s2)}</text>
      </Stage>
    );
  }

  // base-height (default)
  const b = toPx(inputs, "b", values.b, 50, 220, [2, 20]);
  const h = toPx(inputs, "h", values.h, 30, 170, [2, 20]);
  const x0 = 150 - b / 2;
  const y0 = 230;
  const apexX = x0 + b * 0.35;
  return (
    <Stage>
      <polygon points={`${x0},${y0} ${x0 + b},${y0} ${apexX},${y0 - h}`} fill="rgba(99,102,241,0.25)" stroke={C1} strokeWidth={2} />
      <line x1={apexX} y1={y0 - h} x2={apexX} y2={y0} stroke="#475569" strokeDasharray="4 3" />
      <rect x={apexX - 6} y={y0 - 6} width={6} height={6} fill="none" stroke="#475569" />
      <text x={(x0 + x0 + b) / 2} y={y0 + 16} fontSize={12} fill="#334155">base = {fmt(values.b)}</text>
      <text x={apexX + 8} y={y0 - h / 2} fontSize={12} fill="#334155">h = {fmt(values.h)}</text>
    </Stage>
  );
}

function ParallelogramViz({ inputs, values }: { inputs: VariableInput[]; values: Record<string, number> }) {
  const b = toPx(inputs, "b", values.b, 60, 200, [2, 20]);
  const h = toPx(inputs, "h", values.h, 30, 150, [2, 20]);
  const skew = 40;
  const x0 = 70,
    y0 = 220;
  const p1 = [x0, y0],
    p2 = [x0 + b, y0],
    p3 = [x0 + b + skew, y0 - h],
    p4 = [x0 + skew, y0 - h];
  return (
    <Stage>
      <polygon points={`${p1},${p2},${p3},${p4}`.split(",").join(" ")} fill="none" />
      <polygon points={`${p1[0]},${p1[1]} ${p2[0]},${p2[1]} ${p3[0]},${p3[1]} ${p4[0]},${p4[1]}`} fill="rgba(99,102,241,0.25)" stroke={C1} strokeWidth={2} />
      <line x1={p4[0]} y1={p4[1]} x2={p4[0]} y2={y0} stroke="#475569" strokeDasharray="4 3" />
      <rect x={p4[0] - 6} y={y0 - 6} width={6} height={6} fill="none" stroke="#475569" />
      <text x={(p1[0] + p2[0]) / 2} y={y0 + 16} fontSize={12} fill="#334155">b = {fmt(values.b)}</text>
      <text x={p4[0] - 18} y={(p4[1] + y0) / 2} fontSize={12} fill="#334155">h = {fmt(values.h)}</text>
    </Stage>
  );
}

function TrapeziumViz({ inputs, values }: { inputs: VariableInput[]; values: Record<string, number> }) {
  const a = toPx(inputs, "a", values.a, 60, 200, [2, 20]);
  const b = toPx(inputs, "b", values.b, 40, 160, [2, 20]);
  const h = toPx(inputs, "h", values.h, 30, 150, [2, 20]);
  const x0 = 150 - a / 2;
  const y0 = 220;
  const offset = (a - b) / 2;
  const p1 = [x0, y0],
    p2 = [x0 + a, y0],
    p3 = [x0 + a - offset, y0 - h],
    p4 = [x0 + offset, y0 - h];
  return (
    <Stage>
      <polygon points={`${p1[0]},${p1[1]} ${p2[0]},${p2[1]} ${p3[0]},${p3[1]} ${p4[0]},${p4[1]}`} fill="rgba(99,102,241,0.25)" stroke={C1} strokeWidth={2} />
      <line x1={p4[0]} y1={p4[1]} x2={p4[0]} y2={y0} stroke="#475569" strokeDasharray="4 3" />
      <text x={(p1[0] + p2[0]) / 2} y={y0 + 16} fontSize={12} fill="#334155">a = {fmt(values.a)}</text>
      <text x={(p3[0] + p4[0]) / 2} y={p3[1] - 8} fontSize={12} fill="#334155">b = {fmt(values.b)}</text>
      <text x={p4[0] - 18} y={(p4[1] + y0) / 2} fontSize={12} fill="#334155">h = {fmt(values.h)}</text>
    </Stage>
  );
}

function RhombusViz({ inputs, values }: { inputs: VariableInput[]; values: Record<string, number> }) {
  const d1 = toPx(inputs, "d1", values.d1, 60, 220, [2, 20]);
  const d2 = toPx(inputs, "d2", values.d2, 50, 180, [2, 20]);
  const cx = 150,
    cy = 150;
  const pts = [
    [cx - d1 / 2, cy],
    [cx, cy - d2 / 2],
    [cx + d1 / 2, cy],
    [cx, cy + d2 / 2],
  ];
  return (
    <Stage>
      <polygon points={pts.map((p) => p.join(",")).join(" ")} fill="rgba(99,102,241,0.25)" stroke={C1} strokeWidth={2} />
      <line x1={pts[0][0]} y1={pts[0][1]} x2={pts[2][0]} y2={pts[2][1]} stroke="#475569" strokeDasharray="4 3" />
      <line x1={pts[1][0]} y1={pts[1][1]} x2={pts[3][0]} y2={pts[3][1]} stroke="#475569" strokeDasharray="4 3" />
      <text x={cx} y={cy + d2 / 2 + 18} textAnchor="middle" fontSize={12} fill="#334155">d1 = {fmt(values.d1)}</text>
      <text x={cx + d1 / 2 + 8} y={cy} fontSize={12} fill="#334155">d2 = {fmt(values.d2)}</text>
    </Stage>
  );
}

function PolygonViz({ values, mode }: { inputs: VariableInput[]; values: Record<string, number>; mode?: string }) {
  const n = mode === "quad" ? 4 : Math.max(3, Math.round(values.n));
  const R = 85;
  const cx = 150,
    cy = 155;
  const pts = Array.from({ length: n }, (_, i) => {
    const angle = -Math.PI / 2 + (i * 2 * Math.PI) / n;
    return [cx + R * Math.cos(angle), cy + R * Math.sin(angle)];
  });
  return (
    <Stage>
      <polygon points={pts.map((p) => p.join(",")).join(" ")} fill="rgba(99,102,241,0.2)" stroke={C1} strokeWidth={2} />
      {pts.map((p, i) => (
        <circle key={i} cx={p[0]} cy={p[1]} r={3} fill="#334155" />
      ))}
      <text x={cx} y={cy} textAnchor="middle" fontSize={12} fill="#334155">n = {n}</text>
    </Stage>
  );
}

function IdentitySquareViz({ values, mode }: { values: Record<string, number>; mode?: string }) {
  const s1 = mode === "diff" ? Math.max(values.a - values.b, 0.5) : values.a;
  const s2 = values.b;
  const scale = 160 / (s1 + s2 || 1);
  const A = s1 * scale,
    B = s2 * scale;
  const x0 = 70,
    y0 = 70;
  return (
    <Stage>
      <rect x={x0} y={y0} width={A} height={A} fill="rgba(99,102,241,0.3)" stroke={C1} />
      <rect x={x0 + A} y={y0} width={B} height={A} fill="rgba(168,85,247,0.3)" stroke={C2} />
      <rect x={x0} y={y0 + A} width={A} height={B} fill="rgba(168,85,247,0.3)" stroke={C2} />
      <rect x={x0 + A} y={y0 + A} width={B} height={B} fill="rgba(34,197,94,0.3)" stroke={C3} />
      <text x={x0 + A / 2} y={y0 + A / 2} textAnchor="middle" fontSize={12} fill="#334155">{mode === "diff" ? "(a−b)²" : "a²"}</text>
      <text x={x0 + A + B / 2} y={y0 + A / 2} textAnchor="middle" fontSize={11} fill="#334155">{mode === "diff" ? "(a−b)b" : "ab"}</text>
      <text x={x0 + A / 2} y={y0 + A + B / 2} textAnchor="middle" fontSize={11} fill="#334155">{mode === "diff" ? "(a−b)b" : "ab"}</text>
      <text x={x0 + A + B / 2} y={y0 + A + B / 2} textAnchor="middle" fontSize={12} fill="#334155">b²</text>
    </Stage>
  );
}

// ---------- 3D-ish solids ----------
function Solid3DViz({ inputs, values, shape }: { inputs: VariableInput[]; values: Record<string, number>; shape?: string }) {
  const grad = (
    <defs>
      <linearGradient id="faceTop" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#c7d2fe" />
        <stop offset="100%" stopColor="#a5b4fc" />
      </linearGradient>
      <linearGradient id="faceFront" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#818cf8" />
        <stop offset="100%" stopColor="#6366f1" />
      </linearGradient>
      <linearGradient id="faceSide" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%" stopColor="#4f46e5" />
        <stop offset="100%" stopColor="#4338ca" />
      </linearGradient>
      <radialGradient id="sphereShade" cx="35%" cy="30%" r="70%">
        <stop offset="0%" stopColor="#c7d2fe" />
        <stop offset="100%" stopColor="#4338ca" />
      </radialGradient>
    </defs>
  );

  if (shape === "cube" || shape === "cuboid") {
    const w = shape === "cube" ? toPx(inputs, "a", values.a, 50, 120, [1, 12]) : toPx(inputs, "l", values.l, 50, 130, [1, 12]);
    const h = shape === "cube" ? w : toPx(inputs, "h", values.h, 40, 100, [1, 12]);
    const depth = shape === "cube" ? w * 0.5 : toPx(inputs, "b", values.b, 20, 60, [1, 12]);
    const x0 = 80,
      y0 = 200;
    const skx = depth * 0.6,
      sky = depth * 0.45;
    return (
      <Stage>
        {grad}
        <polygon points={`${x0},${y0 - h} ${x0 + w},${y0 - h} ${x0 + w + skx},${y0 - h - sky} ${x0 + skx},${y0 - h - sky}`} fill="url(#faceTop)" stroke="#4338ca" />
        <polygon points={`${x0 + w},${y0} ${x0 + w},${y0 - h} ${x0 + w + skx},${y0 - h - sky} ${x0 + w + skx},${y0 - sky}`} fill="url(#faceSide)" stroke="#4338ca" />
        <rect x={x0} y={y0 - h} width={w} height={h} fill="url(#faceFront)" stroke="#4338ca" />
        <text x={x0 + w / 2} y={y0 + 16} textAnchor="middle" fontSize={11} fill="#334155">{shape === "cube" ? `a=${fmt(values.a)}` : `l=${fmt(values.l)}`}</text>
        {shape === "cuboid" && <text x={x0 - 16} y={y0 - h / 2} fontSize={11} fill="#334155">h={fmt(values.h)}</text>}
        {shape === "cuboid" && <text x={x0 + w + skx / 2} y={y0 - sky - 4} fontSize={11} fill="#334155">b={fmt(values.b)}</text>}
      </Stage>
    );
  }

  if (shape === "cylinder") {
    const r = toPx(inputs, "r", values.r, 30, 80, [1, 15]);
    const h = toPx(inputs, "h", values.h, 50, 150, [1, 20]);
    const cx = 150,
      topY = 90;
    return (
      <Stage>
        <rect x={cx - r} y={topY} width={r * 2} height={h} fill="url(#faceFront)" />
        {grad}
        <ellipse cx={cx} cy={topY + h} rx={r} ry={r * 0.3} fill="#4338ca" stroke="#312e81" />
        <ellipse cx={cx} cy={topY} rx={r} ry={r * 0.3} fill="url(#faceTop)" stroke="#4338ca" />
        <text x={cx} y={topY + h + r * 0.3 + 18} textAnchor="middle" fontSize={11} fill="#334155">r={fmt(values.r)}, h={fmt(values.h)}</text>
      </Stage>
    );
  }

  if (shape === "cone") {
    const r = toPx(inputs, "r", values.r, 30, 80, [1, 15]);
    const h = toPx(inputs, "h", values.h, 60, 170, [1, 20]);
    const cx = 150,
      baseY = 220;
    return (
      <Stage>
        {grad}
        <polygon points={`${cx - r},${baseY} ${cx + r},${baseY} ${cx},${baseY - h}`} fill="url(#faceFront)" stroke="#312e81" />
        <ellipse cx={cx} cy={baseY} rx={r} ry={r * 0.3} fill="#4338ca" stroke="#312e81" />
        <text x={cx} y={baseY + r * 0.3 + 18} textAnchor="middle" fontSize={11} fill="#334155">r={fmt(values.r)}, h={fmt(values.h)}</text>
      </Stage>
    );
  }

  if (shape === "sphere" || shape === "hemisphere") {
    const r = toPx(inputs, "r", values.r, 40, 95, [1, 15]);
    const cx = 150,
      cy = shape === "hemisphere" ? 190 : 150;
    return (
      <Stage>
        {grad}
        {shape === "sphere" ? (
          <>
            <circle cx={cx} cy={cy} r={r} fill="url(#sphereShade)" />
            <ellipse cx={cx} cy={cy + r * 0.55} rx={r * 0.85} ry={r * 0.22} fill="none" stroke="#4338ca" strokeDasharray="3 3" opacity={0.6} />
          </>
        ) : (
          <>
            <path d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy} Z`} fill="url(#sphereShade)" />
            <ellipse cx={cx} cy={cy} rx={r} ry={r * 0.28} fill="#4338ca" stroke="#312e81" />
          </>
        )}
        <text x={cx} y={cy + r + 24} textAnchor="middle" fontSize={11} fill="#334155">r = {fmt(values.r)}</text>
      </Stage>
    );
  }

  if (shape === "frustum") {
    const r1 = toPx(inputs, "r1", values.r1, 40, 90, [2, 20]);
    const r2 = toPx(inputs, "r2", values.r2, 20, 60, [1, 19]);
    const h = toPx(inputs, "h", values.h, 60, 150, [1, 20]);
    const cx = 150,
      baseY = 220;
    return (
      <Stage>
        {grad}
        <polygon points={`${cx - r1},${baseY} ${cx + r1},${baseY} ${cx + r2},${baseY - h} ${cx - r2},${baseY - h}`} fill="url(#faceFront)" stroke="#312e81" />
        <ellipse cx={cx} cy={baseY} rx={r1} ry={r1 * 0.28} fill="#4338ca" stroke="#312e81" />
        <ellipse cx={cx} cy={baseY - h} rx={r2} ry={r2 * 0.28} fill="url(#faceTop)" stroke="#312e81" />
        <text x={cx} y={baseY + r1 * 0.28 + 18} textAnchor="middle" fontSize={11} fill="#334155">r1={fmt(values.r1)}, r2={fmt(values.r2)}, h={fmt(values.h)}</text>
      </Stage>
    );
  }
  return null;
}

// ---------- Graphs ----------
function LinearGraphViz({ values, mode }: { values: Record<string, number>; mode?: string }) {
  const m1 = values.m ?? values.m1 ?? 1;
  const c1 = values.c ?? values.c1 ?? 0;
  const seg1 = clipLine(m1, c1);
  const seg2 = mode === "pair" ? clipLine(values.m2 ?? 1, values.c2 ?? 0) : null;
  const root = mode === "root" && m1 !== 0 ? -c1 / m1 : null;
  return (
    <Stage>
      <Grid />
      {seg1 && <line x1={SX(seg1[0][0])} y1={SY(seg1[0][1])} x2={SX(seg1[1][0])} y2={SY(seg1[1][1])} stroke={C1} strokeWidth={3} />}
      {seg2 && <line x1={SX(seg2[0][0])} y1={SY(seg2[0][1])} x2={SX(seg2[1][0])} y2={SY(seg2[1][1])} stroke={C2} strokeWidth={3} />}
      {root !== null && Math.abs(root) <= 10 && (
        <>
          <circle cx={SX(root)} cy={SY(0)} r={5} fill={C5} />
          <text x={SX(root) + 8} y={SY(0) - 8} fontSize={11} fill={C5}>x = {fmt(root)}</text>
        </>
      )}
    </Stage>
  );
}

function QuadraticGraphViz({ values }: { values: Record<string, number> }) {
  const { a, b, c } = values;
  const pts: string[] = [];
  for (let x = -10; x <= 10; x += 0.4) {
    const y = a * x * x + b * x + c;
    const yc = Math.max(-14, Math.min(14, y));
    pts.push(`${SX(x)},${SY(yc)}`);
  }
  const D = b * b - 4 * a * c;
  const roots = D >= 0 && a !== 0 ? [(-b + Math.sqrt(D)) / (2 * a), (-b - Math.sqrt(D)) / (2 * a)] : [];
  return (
    <Stage>
      <Grid />
      <polyline points={pts.join(" ")} fill="none" stroke={C1} strokeWidth={3} />
      {roots.map((r, i) =>
        Math.abs(r) <= 10 ? <circle key={i} cx={SX(r)} cy={SY(0)} r={5} fill={C5} /> : null
      )}
    </Stage>
  );
}

function InverseGraphViz({ values }: { values: Record<string, number> }) {
  const { k, x } = values;
  const pts: string[] = [];
  for (let xi = 0.5; xi <= 20; xi += 0.3) {
    const yi = k / xi;
    const sx = 20 + xi * 12;
    const sy = 280 - Math.min(yi, 24) * 10;
    pts.push(`${sx},${sy}`);
  }
  const y = k / x;
  const px = 20 + x * 12;
  const py = 280 - Math.min(y, 24) * 10;
  return (
    <Stage>
      <line x1={20} y1={280} x2={280} y2={280} stroke="#94a3b8" strokeWidth={1.5} />
      <line x1={20} y1={20} x2={20} y2={280} stroke="#94a3b8" strokeWidth={1.5} />
      <polyline points={pts.join(" ")} fill="none" stroke={C1} strokeWidth={3} />
      <circle cx={px} cy={py} r={5} fill={C5} />
      <text x={px + 8} y={py - 6} fontSize={11} fill={C5}>({fmt(x)}, {fmt(y)})</text>
    </Stage>
  );
}

function CoordinateGeometryViz({ values, mode }: { values: Record<string, number>; mode?: string }) {
  const p1: [number, number] = [values.x1 ?? 0, values.y1 ?? 0];
  const p2: [number, number] = [values.x2 ?? 0, values.y2 ?? 0];
  const p3: [number, number] | null = mode === "area" ? [values.x3 ?? 0, values.y3 ?? 0] : null;
  const m = values.m,
    n = values.n;
  const section: [number, number] | null =
    mode === "section" && m !== undefined && n !== undefined
      ? [(m * p2[0] + n * p1[0]) / (m + n), (m * p2[1] + n * p1[1]) / (m + n)]
      : mode === "midpoint"
      ? [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2]
      : null;
  return (
    <Stage>
      <Grid />
      {p3 ? (
        <polygon points={`${SX(p1[0])},${SY(p1[1])} ${SX(p2[0])},${SY(p2[1])} ${SX(p3[0])},${SY(p3[1])}`} fill="rgba(99,102,241,0.2)" stroke={C1} strokeWidth={2} />
      ) : (
        <line x1={SX(p1[0])} y1={SY(p1[1])} x2={SX(p2[0])} y2={SY(p2[1])} stroke={C1} strokeWidth={2.5} />
      )}
      <circle cx={SX(p1[0])} cy={SY(p1[1])} r={4.5} fill="#334155" />
      <circle cx={SX(p2[0])} cy={SY(p2[1])} r={4.5} fill="#334155" />
      {p3 && <circle cx={SX(p3[0])} cy={SY(p3[1])} r={4.5} fill="#334155" />}
      {section && <circle cx={SX(section[0])} cy={SY(section[1])} r={5.5} fill={C5} />}
      <text x={SX(p1[0]) + 6} y={SY(p1[1]) - 6} fontSize={10} fill="#334155">({fmt(p1[0])},{fmt(p1[1])})</text>
      <text x={SX(p2[0]) + 6} y={SY(p2[1]) - 6} fontSize={10} fill="#334155">({fmt(p2[0])},{fmt(p2[1])})</text>
      {p3 && <text x={SX(p3[0]) + 6} y={SY(p3[1]) - 6} fontSize={10} fill="#334155">({fmt(p3[0])},{fmt(p3[1])})</text>}
    </Stage>
  );
}

function NumberLineViz({ values, mode }: { values: Record<string, number>; mode?: string; results: ComputedResult[] }) {
  if (mode === "ph") {
    const ph = values.exponent;
    const px = 20 + (ph / 14) * 260;
    const color = ph < 7 ? C5 : ph === 7 ? C3 : C1;
    return (
      <Stage height="h-40">
        <defs>
          <linearGradient id="phgrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#ef4444" />
            <stop offset="50%" stopColor="#22c55e" />
            <stop offset="100%" stopColor="#6366f1" />
          </linearGradient>
        </defs>
        <rect x={20} y={140} width={260} height={14} rx={7} fill="url(#phgrad)" opacity={0.6} />
        {[0, 7, 14].map((v) => (
          <text key={v} x={20 + (v / 14) * 260} y={175} fontSize={11} fill="#334155" textAnchor="middle">{v}</text>
        ))}
        <circle cx={px} cy={147} r={8} fill={color} stroke="white" strokeWidth={2} />
        <text x={px} y={130} fontSize={12} fontWeight={600} textAnchor="middle" fill={color}>pH {fmt(ph)}</text>
      </Stage>
    );
  }
  if (mode === "temperature") {
    const c = values.C;
    const f = (9 / 5) * c + 32;
    const pxC = 20 + ((c + 20) / 120) * 260;
    const pxF = 20 + ((f + 4) / 236) * 260;
    return (
      <Stage height="h-48">
        <text x={20} y={70} fontSize={11} fill="#334155">Celsius</text>
        <line x1={20} y1={90} x2={280} y2={90} stroke="#94a3b8" strokeWidth={2} />
        <circle cx={pxC} cy={90} r={7} fill={C1} />
        <text x={pxC} y={78} fontSize={11} textAnchor="middle" fill={C1}>{fmt(c)}°C</text>
        <text x={20} y={150} fontSize={11} fill="#334155">Fahrenheit</text>
        <line x1={20} y1={170} x2={280} y2={170} stroke="#94a3b8" strokeWidth={2} />
        <circle cx={Math.max(20, Math.min(280, pxF))} cy={170} r={7} fill={C4} />
        <text x={Math.max(20, Math.min(280, pxF))} y={190} fontSize={11} textAnchor="middle" fill={C4}>{fmt(f)}°F</text>
      </Stage>
    );
  }
  return (
    <Stage height="h-32">
      <line x1={20} y1={100} x2={280} y2={100} stroke="#94a3b8" strokeWidth={2} />
      <circle cx={150} cy={100} r={6} fill={C1} />
    </Stage>
  );
}

function ApSequenceViz({ values, mode }: { values: Record<string, number>; mode?: string }) {
  const { a, d } = values;
  const n = Math.round(values.n ?? 5);
  const count = Math.min(n, 10);
  const terms = Array.from({ length: count }, (_, i) => a + i * d);
  return (
    <Stage height="h-40">
      {terms.map((t, i) => {
        const x = 30 + i * 26;
        const highlight = mode === "nth-term" && i === count - 1 && n <= 10;
        return (
          <g key={i}>
            <circle cx={x} cy={100} r={12} fill={highlight ? C5 : mode === "sum" ? C3 : C1} opacity={mode === "sum" ? 0.3 + (0.7 * i) / count : 1} />
            <text x={x} y={104} fontSize={9} textAnchor="middle" fill="white">{fmt(t, 0)}</text>
          </g>
        );
      })}
      {n > 10 && <text x={270} y={104} fontSize={14} fill="#334155">…</text>}
      <text x={150} y={140} textAnchor="middle" fontSize={11} fill="#334155">
        {mode === "sum" ? `Sum of ${n} terms shown cumulatively` : `a=${fmt(a)}, d=${fmt(d)}, n=${n}`}
      </text>
    </Stage>
  );
}

function TrigCircleViz({ values, mode }: { values: Record<string, number>; mode?: string }) {
  const theta = values.theta;
  const rad = (theta * Math.PI) / 180;
  const R = 85;
  const cx = 150,
    cy = 170;
  const px = cx + R * Math.cos(rad);
  const py = cy - R * Math.sin(rad);
  const table = [0, 30, 45, 60, 90];
  const nearest = table.reduce((p, c) => (Math.abs(c - theta) < Math.abs(p - theta) ? c : p));
  const trigVal = (ang: number, fn: "sin" | "cos" | "tan") => {
    const r = (ang * Math.PI) / 180;
    if (fn === "sin") return Math.sin(r);
    if (fn === "cos") return Math.cos(r);
    return ang === 90 ? NaN : Math.tan(r);
  };
  return (
    <div className="space-y-2">
      <Stage>
        <circle cx={cx} cy={cy} r={R} fill="none" stroke="#cbd5e1" strokeWidth={1.5} />
        <line x1={cx - R - 10} y1={cy} x2={cx + R + 10} y2={cy} stroke="#94a3b8" />
        <line x1={cx} y1={cy - R - 10} x2={cx} y2={cy + 10} stroke="#94a3b8" />
        <line x1={cx} y1={cy} x2={px} y2={py} stroke={C1} strokeWidth={2.5} />
        <line x1={px} y1={py} x2={px} y2={cy} stroke={C5} strokeWidth={2} strokeDasharray="4 3" />
        <line x1={cx} y1={cy} x2={px} y2={cy} stroke={C3} strokeWidth={2} strokeDasharray="4 3" />
        <text x={px + 6} y={(py + cy) / 2} fontSize={11} fill={C5}>sin</text>
        <text x={(cx + px) / 2} y={cy + 16} fontSize={11} fill={C3}>cos</text>
        <text x={px + 6} y={py - 6} fontSize={11} fill="#334155">θ={fmt(theta,0)}°</text>
      </Stage>
      {mode === "table" && (
        <table className="w-full text-center text-xs">
          <thead>
            <tr className="text-slate-500 dark:text-slate-400">
              <th></th>
              {table.map((t) => (
                <th key={t} className={t === nearest ? "text-indigo-600 dark:text-indigo-400" : ""}>{t}°</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(["sin", "cos", "tan"] as const).map((fn) => (
              <tr key={fn}>
                <td className="pr-2 font-medium text-slate-600 dark:text-slate-300">{fn}</td>
                {table.map((t) => (
                  <td key={t} className={t === nearest ? "font-semibold text-indigo-600 dark:text-indigo-400" : "text-slate-500 dark:text-slate-400"}>
                    {Number.isNaN(trigVal(t, fn)) ? "∞" : fmt(trigVal(t, fn), 3)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function HeightsDistancesViz({ values, results }: { inputs: VariableInput[]; values: Record<string, number>; results: ComputedResult[] }) {
  const heightResult = results.find((r) => r.label === "Height")?.value ?? 0;
  const scale = 140 / Math.max(values.distance, heightResult, 10);
  const d = values.distance * scale;
  const h = heightResult * scale;
  const groundY = 230,
    originX = 40;
  return (
    <Stage>
      <line x1={originX} y1={groundY} x2={originX + d + 20} y2={groundY} stroke="#94a3b8" strokeWidth={2} />
      <line x1={originX + d} y1={groundY} x2={originX + d} y2={groundY - h} stroke={C1} strokeWidth={4} />
      <line x1={originX} y1={groundY} x2={originX + d} y2={groundY - h} stroke={C4} strokeWidth={2} strokeDasharray="5 3" />
      <circle cx={originX} cy={groundY} r={4} fill="#334155" />
      <text x={originX - 4} y={groundY + 16} fontSize={10} fill="#334155">observer</text>
      <text x={originX + d - 10} y={groundY - h - 8} fontSize={10} fill="#334155">height={fmt(heightResult)}</text>
      <text x={(originX + originX + d) / 2 - 10} y={groundY + 16} fontSize={10} fill="#334155">d={fmt(values.distance)}</text>
      <text x={originX + 20} y={groundY - 12} fontSize={10} fill={C4}>θ={fmt(values.theta,0)}°</text>
    </Stage>
  );
}

// ---------- Physics visuals ----------
function MotionViz({ values, mode }: { inputs: VariableInput[]; values: Record<string, number>; mode?: string }) {
  const u = values.u ?? 0;
  const a = values.a ?? 0;
  const t = values.t ?? 1;
  const v = u + a * t;
  const s = u * t + 0.5 * a * t * t;
  const trackW = 240;
  const key = `${u}-${a}-${t}`;
  const dur = Math.max(1, Math.min(4, t / 3 + 1));
  return (
    <div className="space-y-3">
      <Stage height="h-28">
        <line x1={20} y1={60} x2={280} y2={60} stroke="#cbd5e1" strokeWidth={3} strokeDasharray="2 6" />
        <circle key={key} cx={20} cy={60} r={9} fill={C1}>
          <animateMotion dur={`${dur}s`} repeatCount="indefinite" path={`M 0 0 L ${trackW} 0`} keyPoints="0;1" keyTimes="0;1" calcMode="linear" />
        </circle>
        <text x={20} y={40} fontSize={10} fill="#334155">start</text>
        <text x={270} y={40} fontSize={10} fill="#334155" textAnchor="end">s = {fmt(s)} m</text>
      </Stage>
      {mode === "equations" && (
        <Stage height="h-32">
          <line x1={30} y1={160} x2={270} y2={160} stroke="#94a3b8" />
          <line x1={30} y1={20} x2={30} y2={160} stroke="#94a3b8" />
          <line
            x1={30}
            y1={160 - Math.min(140, Math.max(0, u) * 4)}
            x2={270}
            y2={160 - Math.min(140, Math.max(0, v) * 4)}
            stroke={C3}
            strokeWidth={3}
          />
          <text x={32} y={14} fontSize={10} fill="#334155">velocity (v) vs time (t)</text>
          <text x={32} y={160 - Math.min(140, Math.max(0, u) * 4) - 6} fontSize={10} fill={C3}>u={fmt(u)}</text>
          <text x={225} y={160 - Math.min(140, Math.max(0, v) * 4) - 6} fontSize={10} fill={C3}>v={fmt(v)}</text>
        </Stage>
      )}
    </div>
  );
}

function OhmsLawViz({ values, results }: { values: Record<string, number>; results: ComputedResult[] }) {
  const I = results.find((r) => r.label === "Current")?.value ?? values.V / values.R;
  const dur = Math.max(0.4, Math.min(4, 3 / Math.max(I, 0.1)));
  const path = "M 40 150 L 40 60 L 260 60 L 260 150 Z";
  return (
    <Stage>
      <rect x={40} y={55} width={220} height={100} fill="none" stroke="#475569" strokeWidth={3} rx={4} />
      <rect x={120} y={140} width={60} height={20} fill="#fbbf24" stroke="#92400e" />
      {Array.from({ length: 6 }).map((_, i) => (
        <line key={i} x1={130 + i * 8} y1={140} x2={138 + i * 8} y2={160} stroke="#92400e" strokeWidth={2} />
      ))}
      <text x={150} y={178} textAnchor="middle" fontSize={11} fill="#334155">R = {fmt(values.R)} Ω</text>
      <line x1={40} y1={90} x2={40} y2={70} stroke="#334155" strokeWidth={4} />
      <line x1={30} y1={70} x2={50} y2={70} stroke="#334155" strokeWidth={3} />
      <line x1={35} y1={60} x2={45} y2={60} stroke="#334155" strokeWidth={5} />
      <text x={10} y={65} fontSize={11} fill="#334155">V={fmt(values.V)}V</text>
      {[0, 0.33, 0.66].map((off, i) => (
        <circle key={i} r={5} fill={C4}>
          <animateMotion key={`${values.V}-${values.R}-${i}`} dur={`${dur}s`} begin={`${off * dur}s`} repeatCount="indefinite" path={path} />
        </circle>
      ))}
      <text x={150} y={40} textAnchor="middle" fontSize={13} fontWeight={600} fill={C1}>I = {fmt(I)} A</text>
    </Stage>
  );
}

function ResistanceComboViz({ values, mode }: { values: Record<string, number>; mode?: string; results: ComputedResult[] }) {
  const zigzag = (x: number, y: number) =>
    `M ${x} ${y} l 8 -10 l 10 20 l 10 -20 l 10 20 l 10 -20 l 8 10`;
  if (mode === "parallel") {
    return (
      <Stage>
        <line x1={30} y1={80} x2={30} y2={220} stroke="#475569" strokeWidth={3} />
        <line x1={270} y1={80} x2={270} y2={220} stroke="#475569" strokeWidth={3} />
        <line x1={30} y1={110} x2={80} y2={110} stroke="#475569" strokeWidth={2} />
        <path d={zigzag(80, 110)} fill="none" stroke={C1} strokeWidth={2} />
        <line x1={148} y1={110} x2={270} y2={110} stroke="#475569" strokeWidth={2} />
        <line x1={30} y1={190} x2={80} y2={190} stroke="#475569" strokeWidth={2} />
        <path d={zigzag(80, 190)} fill="none" stroke={C2} strokeWidth={2} />
        <line x1={148} y1={190} x2={270} y2={190} stroke="#475569" strokeWidth={2} />
        <text x={95} y={95} fontSize={11} fill={C1}>R₁={fmt(values.R1)}Ω</text>
        <text x={95} y={215} fontSize={11} fill={C2}>R₂={fmt(values.R2)}Ω</text>
      </Stage>
    );
  }
  return (
    <Stage>
      <line x1={20} y1={150} x2={60} y2={150} stroke="#475569" strokeWidth={2} />
      <path d={zigzag(60, 150)} fill="none" stroke={C1} strokeWidth={2} />
      <line x1={128} y1={150} x2={160} y2={150} stroke="#475569" strokeWidth={2} />
      <path d={zigzag(160, 150)} fill="none" stroke={C2} strokeWidth={2} />
      <line x1={228} y1={150} x2={270} y2={150} stroke="#475569" strokeWidth={2} />
      <text x={65} y={130} fontSize={11} fill={C1}>R₁={fmt(values.R1)}Ω</text>
      <text x={165} y={130} fontSize={11} fill={C2}>R₂={fmt(values.R2)}Ω</text>
    </Stage>
  );
}

function MirrorLensViz({ values, results, mode }: { values: Record<string, number>; results: ComputedResult[]; mode?: string }) {
  const v = results.find((r) => r.label.includes("Image Distance"))?.value ?? 0;
  const u = values.u ?? -30;
  const scale = 1.5;
  const cx = 150,
    axisY = 150;
  const objX = cx + u * scale * 0.5;
  const imgX = cx + v * scale * 0.5;
  const objH = 30;
  const m = mode === "lens" ? v / u : -v / u;
  const imgH = Math.max(-80, Math.min(80, objH * m));
  return (
    <Stage>
      <line x1={20} y1={axisY} x2={280} y2={axisY} stroke="#94a3b8" />
      {mode === "lens" ? (
        <line x1={cx} y1={60} x2={cx} y2={240} stroke={C1} strokeWidth={3} />
      ) : (
        <path d={`M ${cx} 60 Q ${cx - 18} 150 ${cx} 240`} fill="none" stroke={C1} strokeWidth={3} />
      )}
      <line x1={objX} y1={axisY} x2={objX} y2={axisY - objH} stroke={C3} strokeWidth={3} markerEnd="url(#arrow)" />
      <line x1={imgX} y1={axisY} x2={imgX} y2={axisY - imgH} stroke={C5} strokeWidth={3} />
      <defs>
        <marker id="arrow" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
          <path d="M0,0 L6,3 L0,6 Z" fill={C3} />
        </marker>
      </defs>
      <text x={objX - 10} y={axisY - objH - 6} fontSize={10} fill={C3}>object</text>
      <text x={imgX - 10} y={axisY - imgH - 6} fontSize={10} fill={C5}>image</text>
      <text x={150} y={270} textAnchor="middle" fontSize={11} fill="#334155">u={fmt(values.u ?? u)} f={fmt(values.f)} → v={fmt(v)}</text>
    </Stage>
  );
}

function RefractionViz({ values }: { values: Record<string, number> }) {
  const { i, r } = values;
  const cx = 150,
    cy = 150,
    L = 100;
  const ir = (i * Math.PI) / 180,
    rr = (r * Math.PI) / 180;
  return (
    <Stage>
      <line x1={40} y1={cy} x2={260} y2={cy} stroke="#334155" strokeWidth={2} />
      <line x1={cx} y1={cy - 90} x2={cx} y2={cy + 90} stroke="#94a3b8" strokeDasharray="4 3" />
      <line x1={cx - L * Math.sin(ir)} y1={cy - L * Math.cos(ir)} x2={cx} y2={cy} stroke={C1} strokeWidth={2.5} />
      <line x1={cx} y1={cy} x2={cx + L * Math.sin(rr)} y2={cy + L * Math.cos(rr)} stroke={C4} strokeWidth={2.5} />
      <text x={cx - L * Math.sin(ir) - 10} y={cy - L * Math.cos(ir)} fontSize={10} fill={C1}>incident (i={fmt(i,0)}°)</text>
      <text x={cx + L * Math.sin(rr) - 20} y={cy + L * Math.cos(rr) + 14} fontSize={10} fill={C4}>refracted (r={fmt(r,0)}°)</text>
      <rect x={40} y={cy} width={220} height={90} fill="rgba(99,102,241,0.08)" />
      <text x={45} y={cy + 20} fontSize={10} fill="#334155">denser medium</text>
    </Stage>
  );
}

function SoundWaveViz({ values, mode }: { inputs: VariableInput[]; values: Record<string, number>; mode?: string; results: ComputedResult[] }) {
  if (mode === "echo") {
    const dist = (values.speed * values.time) / 2;
    const px = Math.min(240, 20 + dist / 4);
    return (
      <Stage height="h-40">
        <line x1={20} y1={150} x2={px + 20} y2={150} stroke="#94a3b8" strokeWidth={2} />
        <circle cx={20} cy={150} r={6} fill={C1} />
        <rect x={px + 10} y={100} width={10} height={60} fill="#475569" />
        <text x={20} y={170} fontSize={10} fill="#334155">source</text>
        <text x={px + 5} y={95} fontSize={10} fill="#334155">obstacle</text>
        <text x={(px + 30) / 2} y={135} textAnchor="middle" fontSize={11} fill={C1}>d = {fmt(dist)} m</text>
      </Stage>
    );
  }
  const lambda = values.lambda ?? 1 / (values.f || 1);
  const cyclesVisible = 3;
  const wavelengthPx = 260 / cyclesVisible;
  const pts: string[] = [];
  for (let x = 0; x <= 260; x += 4) {
    const y = 20 * Math.sin((2 * Math.PI * x) / wavelengthPx);
    pts.push(`${20 + x},${100 + y}`);
  }
  return (
    <Stage height="h-40">
      <line x1={20} y1={100} x2={280} y2={100} stroke="#cbd5e1" />
      <polyline points={pts.join(" ")} fill="none" stroke={C1} strokeWidth={2.5} />
      <line x1={20} y1={60} x2={20 + wavelengthPx} y2={60} stroke={C4} strokeWidth={1.5} />
      <text x={20 + wavelengthPx / 2} y={50} textAnchor="middle" fontSize={11} fill={C4}>λ = {fmt(lambda)} m</text>
    </Stage>
  );
}

function DensityViz({ results, mode }: { results: ComputedResult[]; mode?: string }) {
  const density = results.find((r) => r.label === "Density")?.value ?? results[0]?.value ?? 1000;
  const waterLevel = 180;
  const sinks = density > 1000;
  const blockY = sinks ? 220 : 120;
  if (mode === "buoyancy") {
    const buoyant = results.find((r) => r.label.includes("Buoyant"))?.value ?? 0;
    return (
      <Stage>
        <rect x={40} y={60} width={220} height={160} fill="rgba(56,189,248,0.15)" stroke="#0ea5e9" />
        <rect x={120} y={120} width={60} height={60} fill="rgba(99,102,241,0.5)" stroke={C1} strokeWidth={2} />
        <line x1={150} y1={120} x2={150} y2={70} stroke={C5} strokeWidth={3} markerEnd="url(#up)" />
        <line x1={150} y1={180} x2={150} y2={220} stroke="#334155" strokeWidth={3} />
        <defs>
          <marker id="up" markerWidth="8" markerHeight="8" refX="4" refY="0" orient="auto">
            <path d="M0,8 L4,0 L8,8 Z" fill={C5} />
          </marker>
        </defs>
        <text x={160} y={65} fontSize={11} fill={C5}>F = {fmt(buoyant)} N</text>
      </Stage>
    );
  }
  return (
    <Stage>
      <rect x={40} y={60} width={220} height={160} fill="rgba(56,189,248,0.15)" stroke="#0ea5e9" />
      <line x1={40} y1={waterLevel} x2={260} y2={waterLevel} stroke="#0ea5e9" strokeWidth={2} strokeDasharray="4 3" />
      <rect x={120} y={blockY - 25} width={60} height={50} fill={sinks ? "rgba(239,68,68,0.5)" : "rgba(34,197,94,0.5)"} stroke={sinks ? C5 : C3} strokeWidth={2} />
      <text x={150} y={45} textAnchor="middle" fontSize={11} fill="#334155">density = {fmt(density)} {mode === "relative" ? "kg/m³" : ""}</text>
      <text x={150} y={240} textAnchor="middle" fontSize={11} fill="#334155">{sinks ? "sinks (denser than water)" : "floats (less dense than water)"}</text>
    </Stage>
  );
}

function StatsViz({ values, mode }: { values: Record<string, number>; mode?: string }) {
  if (mode?.startsWith("grouped")) {
    const bars = [
      { x: values.x1, f: values.f1 },
      { x: values.x2, f: values.f2 },
      { x: values.x3, f: values.f3 },
    ].filter((b) => b.x !== undefined);
    const maxF = Math.max(...bars.map((b) => b.f), 1);
    return (
      <Stage height="h-44">
        {bars.map((b, i) => {
          const h = (b.f / maxF) * 140;
          const x = 50 + i * 80;
          return (
            <g key={i}>
              <rect x={x} y={200 - h} width={50} height={h} fill={C1} opacity={0.7} />
              <text x={x + 25} y={215} fontSize={10} textAnchor="middle" fill="#334155">x={fmt(b.x)}</text>
              <text x={x + 25} y={195 - h} fontSize={10} textAnchor="middle" fill="#334155">f={fmt(b.f)}</text>
            </g>
          );
        })}
      </Stage>
    );
  }
  const vals = [values.v1, values.v2, values.v3, values.v4, values.v5].filter((v) => v !== undefined);
  const maxV = Math.max(...vals, 1);
  const mean = vals.reduce((s, v) => s + v, 0) / vals.length;
  const sorted = [...vals].sort((a, b) => a - b);
  return (
    <Stage height="h-44">
      {vals.map((v, i) => {
        const h = (v / maxV) * 140;
        const x = 30 + i * 48;
        const isMedian = mode === "median" && sorted[Math.floor(sorted.length / 2)] === v;
        return (
          <g key={i}>
            <rect x={x} y={200 - h} width={34} height={h} fill={isMedian ? C5 : C1} opacity={0.75} />
            <text x={x + 17} y={215} fontSize={10} textAnchor="middle" fill="#334155">{fmt(v)}</text>
          </g>
        );
      })}
      {mode === "mean" && <line x1={20} y1={200 - (mean / maxV) * 140} x2={270} y2={200 - (mean / maxV) * 140} stroke={C3} strokeWidth={2} strokeDasharray="5 3" />}
      {mode === "mean" && <text x={270} y={200 - (mean / maxV) * 140 - 6} fontSize={10} fill={C3} textAnchor="end">mean={fmt(mean)}</text>}
      {mode === "range" && (
        <>
          <text x={150} y={20} textAnchor="middle" fontSize={11} fill={C4}>range = max − min = {fmt(Math.max(...vals) - Math.min(...vals))}</text>
        </>
      )}
    </Stage>
  );
}

function ProbabilityViz({ values, results }: { values: Record<string, number>; results: ComputedResult[] }) {
  const p = results[0]?.value ?? 0;
  const angle = Math.max(0, Math.min(1, p)) * 360;
  const cx = 150,
    cy = 150,
    r = 80;
  const rad = (angle * Math.PI) / 180;
  const large = angle > 180 ? 1 : 0;
  const x = cx + r * Math.sin(rad);
  const y = cy - r * Math.cos(rad);
  return (
    <Stage>
      <circle cx={cx} cy={cy} r={r} fill="#e2e8f0" />
      {angle > 0 && <path d={`M ${cx} ${cy} L ${cx} ${cy - r} A ${r} ${r} 0 ${large} 1 ${x} ${y} Z`} fill={C1} />}
      <text x={cx} y={cy + r + 24} textAnchor="middle" fontSize={13} fontWeight={600} fill={C1}>
        P(E) = {fmt(p, 3)}
      </text>
      <text x={cx} y={cy} textAnchor="middle" fontSize={10} fill="#1e293b">
        {values.fav ?? values.trialsWithE}/{values.total ?? values.totalTrials}
      </text>
    </Stage>
  );
}

function MoleViz({ results, mode }: { results: ComputedResult[]; mode?: string }) {
  const moles = results.find((r) => r.unit === "mol")?.value ?? results[0]?.value ?? 0;
  const count = Math.max(1, Math.min(48, Math.round(moles * 12)));
  const cols = 8;
  return (
    <Stage height="h-44">
      {Array.from({ length: count }).map((_, i) => (
        <circle key={i} cx={40 + (i % cols) * 28} cy={50 + Math.floor(i / cols) * 28} r={8} fill={C1} opacity={0.8} />
      ))}
      <text x={150} y={250} textAnchor="middle" fontSize={11} fill="#334155">
        {mode === "molarity" ? "Each dot ≈ a portion of solute" : `≈ ${fmt(moles, 3)} mol represented`}
      </text>
    </Stage>
  );
}

function InterestGrowthViz({ values, mode }: { values: Record<string, number>; mode?: string }) {
  const P = values.P,
    R = values.R;
  const T = values.T ?? values.n;
  const points = (compound: boolean) =>
    Array.from({ length: Math.round(T) + 1 }, (_, t) => {
      const amt = compound ? P * Math.pow(1 + R / 100, t) : P + (P * R * t) / 100;
      return { t, amt };
    });
  const si = points(false);
  const ci = points(true);
  const maxAmt = Math.max(...si.map((p) => p.amt), ...ci.map((p) => p.amt));
  const sx = (t: number) => 30 + (t / Math.max(T, 1)) * 240;
  const sy = (amt: number) => 230 - (amt / maxAmt) * 190;
  const toPath = (pts: { t: number; amt: number }[]) => pts.map((p) => `${sx(p.t)},${sy(p.amt)}`).join(" ");
  return (
    <Stage>
      <line x1={30} y1={230} x2={280} y2={230} stroke="#94a3b8" />
      <line x1={30} y1={30} x2={30} y2={230} stroke="#94a3b8" />
      <polyline points={toPath(si)} fill="none" stroke={C3} strokeWidth={2.5} />
      <polyline points={toPath(ci)} fill="none" stroke={C1} strokeWidth={2.5} />
      <text x={35} y={24} fontSize={10} fill={C3}>Simple Interest</text>
      <text x={150} y={24} fontSize={10} fill={C1}>Compound Interest</text>
      <text x={150} y={248} textAnchor="middle" fontSize={10} fill="#334155">
        {mode === "simple" ? "Straight growth" : "Grows faster than simple interest"} over {fmt(T,0)} years
      </text>
    </Stage>
  );
}

function PercentageBarViz({ results }: { results: ComputedResult[] }) {
  const pct = results.find((r) => r.unit === "%")?.value ?? 0;
  const clamped = Math.max(0, Math.min(100, pct));
  return (
    <Stage height="h-28">
      <rect x={20} y={70} width={260} height={28} rx={14} fill="#e2e8f0" />
      <rect x={20} y={70} width={(clamped / 100) * 260} height={28} rx={14} fill={C1} />
      <text x={150} y={89} textAnchor="middle" fontSize={12} fontWeight={600} fill="white">
        {fmt(pct)}%
      </text>
    </Stage>
  );
}

function SdtTriangleViz({ values, results }: { values: Record<string, number>; results: ComputedResult[] }) {
  const speed = results[0]?.value ?? 0;
  return (
    <Stage height="h-44">
      <polygon points="150,30 60,180 240,180" fill="rgba(99,102,241,0.15)" stroke={C1} strokeWidth={2} />
      <line x1={60} y1={110} x2={240} y2={110} stroke={C1} strokeWidth={1.5} />
      <line x1={150} y1={110} x2={150} y2={180} stroke={C1} strokeWidth={1.5} />
      <text x={150} y={85} textAnchor="middle" fontSize={14} fontWeight={600} fill="#1e293b">S</text>
      <text x={105} y={150} textAnchor="middle" fontSize={14} fontWeight={600} fill="#1e293b">D</text>
      <text x={195} y={150} textAnchor="middle" fontSize={14} fontWeight={600} fill="#1e293b">T</text>
      <text x={150} y={205} textAnchor="middle" fontSize={11} fill="#334155">Speed = {fmt(speed)} (cover D with your finger: S = D/T)</text>
      <text x={150} y={20} textAnchor="middle" fontSize={10} fill="#64748b">d={fmt(values.d)} , t={fmt(values.t)}</text>
    </Stage>
  );
}

function ValencyViz({ values, results }: { values: Record<string, number>; results: ComputedResult[] }) {
  const subA = results.find((r) => r.label.includes("A"))?.value ?? 1;
  const subB = results.find((r) => r.label.includes("B"))?.value ?? 1;
  return (
    <Stage height="h-44">
      <rect x={40} y={70} width={80} height={60} rx={8} fill="rgba(99,102,241,0.2)" stroke={C1} strokeWidth={2} />
      <text x={80} y={105} textAnchor="middle" fontSize={16} fontWeight={700} fill={C1}>A{values.vA}</text>
      <rect x={180} y={70} width={80} height={60} rx={8} fill="rgba(168,85,247,0.2)" stroke={C2} strokeWidth={2} />
      <text x={220} y={105} textAnchor="middle" fontSize={16} fontWeight={700} fill={C2}>B{values.vB}</text>
      <line x1={120} y1={80} x2={180} y2={120} stroke="#64748b" strokeDasharray="4 3" />
      <line x1={120} y1={120} x2={180} y2={80} stroke="#64748b" strokeDasharray="4 3" />
      <text x={150} y={160} textAnchor="middle" fontSize={16} fontWeight={700} fill="#1e293b">
        A{subA > 1 ? subB : ""}B{subA > 1 ? subA : ""}
      </text>
      <text x={150} y={180} textAnchor="middle" fontSize={10} fill="#64748b">criss-cross the valencies</text>
    </Stage>
  );
}

const REACTIONS = [
  { title: "Metal + Acid", eq: "Metal + Dilute Acid → Salt + Hydrogen (H₂↑)", note: "e.g. Zn + H₂SO₄ → ZnSO₄ + H₂" },
  { title: "Metal + Oxygen", eq: "Metal + Oxygen → Metal Oxide", note: "e.g. 2Mg + O₂ → 2MgO" },
  { title: "Displacement", eq: "Metal A + Salt of B → Salt of A + Metal B", note: "e.g. Zn + CuSO₄ → ZnSO₄ + Cu (if A is more reactive than B)" },
];
function ReactionExplorerViz({ values }: { values: Record<string, number> }) {
  const r = REACTIONS[Math.min(2, Math.max(0, Math.round(values.type)))];
  return (
    <Stage height="h-40">
      <text x={150} y={70} textAnchor="middle" fontSize={13} fontWeight={700} fill={C1}>{r.title}</text>
      <text x={150} y={110} textAnchor="middle" fontSize={12} fill="#1e293b">{r.eq}</text>
      <text x={150} y={145} textAnchor="middle" fontSize={11} fill="#64748b">{r.note}</text>
    </Stage>
  );
}

function CalculatorViz({ formula, values, results }: { formula: Formula; values: Record<string, number>; results: ComputedResult[] }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-gradient-to-br from-indigo-50 to-purple-50 p-5 dark:border-slate-700 dark:from-indigo-500/10 dark:to-purple-500/10">
      <div className="mb-3 text-center font-mono text-base text-slate-700 dark:text-slate-200">{formula.expression}</div>
      <div className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-3">
        {formula.interactive.inputs.map((inp) => (
          <div key={inp.symbol} className="rounded-lg bg-white/70 px-2 py-1 text-center dark:bg-slate-800/60">
            <span className="text-slate-400">{inp.symbol} = </span>
            <span className="font-mono font-medium text-indigo-600 dark:text-indigo-300">{fmt(values[inp.symbol])}</span>
          </div>
        ))}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
        {results.map((r) => (
          <ResultCard key={r.label} label={r.label} value={r.value} unit={r.unit} />
        ))}
      </div>
    </div>
  );
}

// ---------- top-level interactive panel ----------
export default function Visualizer({ formula }: { formula: Formula }) {
  const [values, setValues] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    formula.interactive.inputs.forEach((i) => (init[i.symbol] = i.default));
    return init;
  });

  const results = useMemo(() => {
    try {
      return formula.interactive.compute(values);
    } catch {
      return [] as ComputedResult[];
    }
  }, [formula, values]);

  const steps = useMemo(() => {
    try {
      return formula.interactive.steps?.(values, results);
    } catch {
      return undefined;
    }
  }, [formula, values, results]);

  const showResultCards = formula.visual.kind !== "calculator";

  return (
    <div className="space-y-5">
      <VisualStage formula={formula} values={values} results={results} />

      <div className="grid gap-4 sm:grid-cols-2">
        {formula.interactive.inputs.map((inp) => (
          <VariableSlider key={inp.symbol} input={inp} value={values[inp.symbol]} onChange={(v) => setValues((old) => ({ ...old, [inp.symbol]: v }))} />
        ))}
      </div>

      {showResultCards && results.length > 0 && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {results.map((r) => (
            <ResultCard key={r.label} label={r.label} value={r.value} unit={r.unit} />
          ))}
        </div>
      )}

      {steps && steps.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm dark:border-slate-700 dark:bg-slate-900/50">
          <div className="mb-2 font-semibold text-slate-600 dark:text-slate-300">Step-by-step</div>
          <ol className="list-decimal space-y-1 pl-4 font-mono text-slate-600 dark:text-slate-300">
            {steps.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ol>
        </div>
      )}
    </div>
  );
}
