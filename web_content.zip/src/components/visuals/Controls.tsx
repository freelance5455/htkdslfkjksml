import type { VariableInput } from "../../data/types";
import { fmt } from "../../utils/format";

export function VariableSlider({
  input,
  value,
  onChange,
}: {
  input: VariableInput;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium text-slate-700 dark:text-slate-200">{input.label}</span>
        <span className="rounded-md bg-indigo-50 px-2 py-0.5 font-mono text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300">
          {fmt(value, 3)}
          {input.unit ? ` ${input.unit}` : ""}
        </span>
      </div>
      <input
        type="range"
        min={input.min}
        max={input.max}
        step={input.step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full"
      />
      <div className="flex justify-between text-[11px] text-slate-400 dark:text-slate-500">
        <span>{input.min}</span>
        <span>{input.max}</span>
      </div>
    </div>
  );
}

export function ResultCard({ label, value, unit }: { label: string; value: number; unit?: string }) {
  const display = Number.isFinite(value) ? fmt(value, 4) : "—";
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-3 text-center shadow-sm dark:border-slate-700 dark:bg-slate-800">
      <div className="text-[11px] uppercase tracking-wide text-slate-400 dark:text-slate-500">{label}</div>
      <div className="mt-1 font-mono text-lg font-semibold text-indigo-600 dark:text-indigo-400">
        {display}
        {unit ? <span className="ml-1 text-sm font-normal text-slate-500 dark:text-slate-400">{unit}</span> : null}
      </div>
    </div>
  );
}

export const palette = {
  stroke: "#6366f1",
  fill: "rgba(99,102,241,0.14)",
  accent: "#a855f7",
  accent2: "#22c55e",
  grid: "#cbd5e1",
};
