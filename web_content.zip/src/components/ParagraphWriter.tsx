import React, { useState } from 'react';
import { StudentProfile, ParagraphResult, SavedHistoryItem, ActiveTab } from '../types';
import {
  FileText,
  Sparkles,
  Sliders,
  Copy,
  Volume2,
  VolumeX,
  Printer,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  Layers,
  Wand2,
  Quote,
  Zap,
  RotateCcw
} from 'lucide-react';
import { fireCelebration } from '../utils/confetti';

interface ParagraphWriterProps {
  profile: StudentProfile;
  onSaveHistory: (item: Omit<SavedHistoryItem, 'id' | 'timestamp'>) => void;
  onUpdateStats: (key: keyof StudentProfile) => void;
  setActiveTab: (tab: ActiveTab) => void;
  onSendToGrammar: (text: string) => void;
}

export const ParagraphWriter: React.FC<ParagraphWriterProps> = ({
  profile,
  onSaveHistory,
  onUpdateStats,
  setActiveTab,
  onSendToGrammar,
}) => {
  const [topic, setTopic] = useState('');
  const [wordCount, setWordCount] = useState<number>(120);
  const [paragraphType, setParagraphType] = useState('Expository');
  const [tone, setTone] = useState('Academic');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ParagraphResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [viewMode, setViewMode] = useState<'standard' | 'breakdown'>('standard');

  const topicSuggestions = [
    'How gravity keeps planets in orbit',
    'Why schools should start later in the morning',
    'The importance of biodiversity in the Amazon rainforest',
    'How social media influences teenage self-image',
    'The symbolism of the green light in The Great Gatsby',
    'Why regular exercise boosts memory and brain function',
  ];

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!topic.trim()) {
      setError('Please enter a paragraph topic.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/generate-paragraph', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic.trim(),
          wordCount,
          paragraphType,
          tone,
          grade: profile.grade,
          studentName: profile.name,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate paragraph.');
      }

      setResult(data.data);
      onUpdateStats('writtenParagraphsCount');
      fireCelebration();

      onSaveHistory({
        type: 'paragraph',
        title: topic.trim(),
        data: data.data,
        gradeWhenCreated: profile.grade,
      });
    } catch (err: any) {
      setError(err.message || 'Something went wrong while generating the paragraph.');
    } finally {
      setLoading(false);
    }
  };

  const copyText = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.paragraph);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleSpeech = () => {
    if (!result || !('speechSynthesis' in window)) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(result.paragraph);
      utterance.rate = 0.95;
      utterance.onend = () => setSpeaking(false);
      utterance.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(utterance);
      setSpeaking(true);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-violet-100 text-violet-700 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
            <FileText className="w-3.5 h-3.5" />
            Paragraph Writing Assistant
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Grade-Calibrated Paragraph Generator
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Input any topic and exact word count. Generates cohesive writing structured for{' '}
            <span className="font-semibold text-violet-600">{profile.grade}</span> with topic sentences & vocabulary.
          </p>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-700 text-sm rounded-2xl flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-rose-500 hover:text-rose-700 font-bold">
            ✕
          </button>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Form Controls */}
        <div className="lg:col-span-5 space-y-6">
          <form
            onSubmit={handleGenerate}
            className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-5"
          >
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center justify-between">
              <span>Paragraph Parameters</span>
              <span className="text-[11px] text-violet-600 font-bold px-2 py-0.5 bg-violet-50 rounded-full">
                {profile.grade}
              </span>
            </h3>

            {/* Topic Input */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Paragraph Topic or Prompt
              </label>
              <textarea
                rows={3}
                required
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Why the water cycle is essential for life on Earth, or The central theme of Romeo & Juliet..."
                className="w-full px-4 py-3 rounded-2xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-violet-600/30 focus:border-violet-600 text-slate-800 text-xs sm:text-sm transition resize-none"
              />
            </div>

            {/* Quick Suggestions */}
            <div>
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
                Suggested Prompts
              </span>
              <div className="flex flex-wrap gap-1.5">
                {topicSuggestions.map((sug, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setTopic(sug)}
                    className="text-[11px] px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-violet-50 hover:text-violet-700 text-slate-600 border border-slate-200/60 transition cursor-pointer"
                  >
                    {sug}
                  </button>
                ))}
              </div>
            </div>

            {/* Target Word Count Slider & Presets */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-violet-600" />
                  Target Word Count
                </label>
                <span className="text-xs font-extrabold text-violet-700 bg-violet-100 px-2 py-0.5 rounded-lg">
                  {wordCount} words
                </span>
              </div>
              <input
                type="range"
                min="50"
                max="300"
                step="10"
                value={wordCount}
                onChange={(e) => setWordCount(Number(e.target.value))}
                className="w-full accent-violet-600 cursor-pointer"
              />
              <div className="flex justify-between items-center mt-2 gap-1">
                {[60, 100, 120, 150, 200, 250].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setWordCount(preset)}
                    className={`text-[10px] font-bold px-2 py-1 rounded-lg transition cursor-pointer ${
                      wordCount === preset
                        ? 'bg-violet-600 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {preset}w
                  </button>
                ))}
              </div>
            </div>

            {/* Paragraph Type */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Paragraph Type
              </label>
              <select
                value={paragraphType}
                onChange={(e) => setParagraphType(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-violet-600/30 cursor-pointer"
              >
                <option value="Expository">Expository (Informational & Factual)</option>
                <option value="Persuasive">Persuasive (Argument & Convincing)</option>
                <option value="Narrative">Narrative (Storytelling & Experience)</option>
                <option value="Descriptive">Descriptive (Sensory & Vivid Details)</option>
                <option value="Compare & Contrast">Compare & Contrast</option>
                <option value="Cause & Effect">Cause & Effect</option>
              </select>
            </div>

            {/* Tone Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Writing Tone
              </label>
              <div className="grid grid-cols-2 gap-2">
                {['Academic', 'Creative', 'Formal', 'Conversational'].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTone(t)}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border transition cursor-pointer ${
                      tone === t
                        ? 'border-violet-600 bg-violet-50 text-violet-700 font-bold'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading || !topic.trim()}
              className={`w-full py-3.5 px-6 rounded-2xl font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition cursor-pointer ${
                loading || !topic.trim()
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                  : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white shadow-violet-500/25'
              }`}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Drafting paragraph for {profile.grade}...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Generate Grade-Tailored Paragraph</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Column: Generated Paragraph & Structural Analysis */}
        <div className="lg:col-span-7 space-y-6">
          {!result && !loading && (
            <div className="bg-white rounded-3xl p-10 border border-slate-200 text-center flex flex-col items-center justify-center min-h-[420px] shadow-xs">
              <div className="w-16 h-16 rounded-3xl bg-violet-50 text-violet-600 flex items-center justify-center mb-4">
                <Quote className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">
                Ready to craft your paragraph
              </h3>
              <p className="text-sm text-slate-500 max-w-md mt-1">
                Enter your topic and desired word count on the left. The AI will produce a well-structured paragraph with topic sentence, supporting proof, and conclusion calibrated for {profile.grade}.
              </p>
            </div>
          )}

          {loading && (
            <div className="bg-white rounded-3xl p-12 border border-slate-200 text-center flex flex-col items-center justify-center min-h-[420px] shadow-xs space-y-4">
              <div className="relative w-16 h-16 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full border-4 border-violet-100 border-t-violet-600 animate-spin" />
                <Sparkles className="w-6 h-6 text-amber-500 absolute animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">
                  Writing and Polishing Your Paragraph
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Aligning sentence complexity, transition words, and topic depth to {profile.grade} curriculum standards...
                </p>
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* Generated Paragraph Card */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-violet-100 text-violet-700 text-xs font-bold uppercase tracking-wide">
                      {paragraphType}
                    </span>
                    <span className="text-xs font-bold text-slate-600">
                      Target: {wordCount}w • Actual: {result.actualWordCount}w
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* View mode toggle */}
                    <div className="flex bg-slate-100 p-0.5 rounded-xl text-[11px] font-bold">
                      <button
                        onClick={() => setViewMode('standard')}
                        className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                          viewMode === 'standard' ? 'bg-white text-violet-700 shadow-2xs' : 'text-slate-600'
                        }`}
                      >
                        Paragraph
                      </button>
                      <button
                        onClick={() => setViewMode('breakdown')}
                        className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                          viewMode === 'breakdown' ? 'bg-white text-violet-700 shadow-2xs' : 'text-slate-600'
                        }`}
                      >
                        Structure Breakdown
                      </button>
                    </div>

                    <button
                      onClick={toggleSpeech}
                      className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition cursor-pointer"
                      title={speaking ? 'Stop speech' : 'Read aloud'}
                    >
                      {speaking ? <VolumeX className="w-4 h-4 text-rose-600" /> : <Volume2 className="w-4 h-4" />}
                    </button>

                    <button
                      onClick={copyText}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      {copied ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                </div>

                {/* Paragraph Content */}
                {viewMode === 'standard' ? (
                  <div className="p-6 bg-slate-50/70 rounded-2xl border border-slate-200/80 leading-relaxed text-slate-800 text-sm sm:text-base font-serif">
                    {result.paragraph}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 block mb-1">
                        Topic Sentence (Hook & Main Claim)
                      </span>
                      <p className="text-xs sm:text-sm font-semibold text-blue-950 font-serif">
                        {result.topicSentence}
                      </p>
                    </div>

                    <div className="p-4 rounded-xl bg-violet-50/70 border border-violet-200 space-y-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-violet-700 block">
                        Supporting Evidence & Elaboration
                      </span>
                      {result.supportingSentences?.map((sentence, idx) => (
                        <p key={idx} className="text-xs sm:text-sm text-slate-800 font-serif">
                          • {sentence}
                        </p>
                      ))}
                    </div>

                    <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block mb-1">
                        Concluding / Clincher Sentence
                      </span>
                      <p className="text-xs sm:text-sm font-semibold text-emerald-950 font-serif">
                        {result.concludingSentence}
                      </p>
                    </div>
                  </div>
                )}

                {/* Grade Alignment Note */}
                <div className="bg-violet-50/50 border border-violet-100 rounded-2xl p-4 flex items-start gap-3">
                  <div className="p-1.5 bg-violet-100 text-violet-700 rounded-lg shrink-0 mt-0.5">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-violet-900 block">
                      Grade-Level Analysis ({profile.grade})
                    </span>
                    <p className="text-xs text-slate-600 mt-0.5">
                      {result.gradeLevelAnalysis}
                    </p>
                  </div>
                </div>

                {/* Transition Words */}
                {result.transitionWords && result.transitionWords.length > 0 && (
                  <div>
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                      Transition Words Used
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {result.transitionWords.map((word, idx) => (
                        <span
                          key={idx}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-semibold border border-slate-200/60"
                        >
                          {word}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Vocabulary Highlights */}
                {result.vocabularyHighlights && result.vocabularyHighlights.length > 0 && (
                  <div className="space-y-2 pt-2">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                      Featured Academic Vocabulary
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {result.vocabularyHighlights.map((vocab, idx) => (
                        <div
                          key={idx}
                          className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1 text-xs"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-violet-700 capitalize text-sm">
                              {vocab.word}
                            </span>
                            <span className="text-[10px] text-slate-400 font-medium">Academic term</span>
                          </div>
                          <p className="text-slate-600 font-medium">{vocab.definition}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Actions: Send to Grammar Checker or Essay Writer */}
                <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs text-slate-500">Want to revise or expand?</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        onSendToGrammar(result.paragraph);
                        setActiveTab('grammar');
                      }}
                      className="px-4 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-bold border border-amber-200 transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5" /> Check with Grammar Coach
                    </button>
                    <button
                      onClick={() => setActiveTab('essay')}
                      className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                    >
                      Expand to Full Essay <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
