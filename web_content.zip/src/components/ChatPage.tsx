import React, { useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  BookOpen,
  Calculator,
  Camera,
  Check,
  Copy,
  FileText,
  Globe,
  ImagePlus,
  Lightbulb,
  PenLine,
  Plus,
  RefreshCw,
  SendHorizontal,
  Square,
  X,
} from "lucide-react";
import type {
  ChatMessage,
  ImageAttachment,
  LanguagePreference,
  ServerHealth,
} from "../types/chat";
import { formatBytes, processImageFile } from "../utils/storage";
import { BrandLogo } from "./BrandLogo";
import { CameraModal } from "./CameraModal";
import { MarkdownRenderer } from "./MarkdownRenderer";

interface ChatPageProps {
  messages: ChatMessage[];
  isStreaming: boolean;
  errorBanner: string | null;
  onDismissError: () => void;
  health: ServerHealth | null;
  language: LanguagePreference;
  onSendMessage: (text: string, image?: ImageAttachment) => void;
  onStopStreaming: () => void;
  onRegenerateLast: () => void;
  onNewChat: () => void;
  onOpenAbout: () => void;
}

const SUGGESTED_PROMPTS = [
  {
    id: "study",
    category: "Study Help",
    icon: <BookOpen className="w-4 h-4 text-blue-600 dark:text-blue-400" />,
    title: "Explain a science topic clearly",
    prompt:
      "Explain how cellular respiration works step by step in simple language, and summarize the main stages.",
  },
  {
    id: "math",
    category: "Mathematics",
    icon: <Calculator className="w-4 h-4 text-blue-600 dark:text-blue-400" />,
    title: "Solve an equation step by step",
    prompt:
      "Solve the quadratic equation 2x^2 - 5x - 3 = 0 step by step and show how to verify both roots.",
  },
  {
    id: "gk",
    category: "General Knowledge",
    icon: <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />,
    title: "Understand why seasons change",
    prompt:
      "Why do seasons change on Earth? Explain how axial tilt affects sunlight and day length.",
  },
  {
    id: "writing",
    category: "Writing",
    icon: <PenLine className="w-4 h-4 text-blue-600 dark:text-blue-400" />,
    title: "Draft and polish an email",
    prompt:
      "Help me write a clear, polite email to a teacher asking for feedback on my project outline.",
  },
  {
    id: "image",
    category: "Image Understanding",
    icon: <FileText className="w-4 h-4 text-blue-600 dark:text-blue-400" />,
    title: "Analyze a photo, note, or diagram",
    prompt:
      "Please read the text or problem in this photo and explain the answer step by step.",
    triggersUpload: true,
  },
];

export const ChatPage: React.FC<ChatPageProps> = ({
  messages,
  isStreaming,
  errorBanner,
  onDismissError,
  health,
  language,
  onSendMessage,
  onStopStreaming,
  onRegenerateLast,
  onNewChat,
  onOpenAbout,
}) => {
  const [inputText, setInputText] = useState("");
  const [attachment, setAttachment] = useState<ImageAttachment | null>(null);
  const [attachmentError, setAttachmentError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [cameraModalOpen, setCameraModalOpen] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const mobileCameraInputRef = useRef<HTMLInputElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, isStreaming]);

  // Auto-resize textarea cleanly
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
  }, [inputText]);

  const handleFileSelected = async (file: File | undefined | null) => {
    if (!file) return;
    setAttachmentError(null);
    try {
      const processed = await processImageFile(file);
      setAttachment(processed);
      textareaRef.current?.focus();
    } catch (err) {
      setAttachmentError(
        err instanceof Error ? err.message : "Could not attach this image."
      );
    }
  };

  const handleCameraClick = () => {
    setAttachmentError(null);
    const isCoarsePointer =
      typeof window !== "undefined" &&
      window.matchMedia &&
      window.matchMedia("(pointer: coarse)").matches;

    if (isCoarsePointer) {
      mobileCameraInputRef.current?.click();
    } else {
      setCameraModalOpen(true);
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isStreaming) return;
    const trimmed = inputText.trim();
    if (!trimmed && !attachment) return;

    const textToSend = trimmed;
    const imageToSend = attachment || undefined;

    setInputText("");
    setAttachment(null);
    setAttachmentError(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }

    onSendMessage(textToSend, imageToSend);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleCopyAnswer = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId((curr) => (curr === id ? null : curr)), 1800);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handlePromptCard = (card: (typeof SUGGESTED_PROMPTS)[number]) => {
    if (card.triggersUpload) {
      setInputText(card.prompt);
      galleryInputRef.current?.click();
      return;
    }
    onSendMessage(card.prompt);
  };

  const lastModelMessageIndex = (() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === "model") return i;
    }
    return -1;
  })();

  const languageLabel =
    language === "bn"
      ? "বাংলা"
      : language === "hi"
      ? "हिन्दी"
      : language === "en"
      ? "English"
      : "Auto-detect (EN · বাংলা · हिन्दी)";

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-slate-50 dark:bg-slate-950">
      {/* Main Scrollable Thread */}
      <div className="flex-1 overflow-y-auto mih-scroll">
        <div className="max-w-3xl mx-auto px-3.5 sm:px-6 py-5 sm:py-8">
          {/* Honest Setup Banner when GEMINI_API_KEY is not configured */}
          {health && !health.aiConfigured && (
            <div className="mb-6 rounded-2xl border border-amber-300 dark:border-amber-800/80 bg-amber-50 dark:bg-amber-950/40 p-4 sm:p-5 text-sm text-amber-950 dark:text-amber-100">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1.5">
                  <div className="font-semibold">
                    Gemini AI API is not configured yet
                  </div>
                  <p className="text-amber-900/90 dark:text-amber-200/90 leading-relaxed">
                    MIH.AI never generates fake AI replies. To enable live text
                    and photo answers, add{" "}
                    <code className="font-mono text-xs px-1.5 py-0.5 rounded bg-amber-200/60 dark:bg-amber-900/60">
                      GEMINI_API_KEY
                    </code>{" "}
                    in <strong>Settings &gt; Secrets</strong> (or your server{" "}
                    <code className="font-mono text-xs px-1.5 py-0.5 rounded bg-amber-200/60 dark:bg-amber-900/60">
                      .env
                    </code>
                    ) and restart the app.
                  </p>
                  <button
                    type="button"
                    onClick={onOpenAbout}
                    className="text-xs font-semibold underline underline-offset-2 hover:opacity-80"
                  >
                    View setup instructions
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Empty State / Welcome View */}
          {messages.length === 0 ? (
            <div className="py-4 sm:py-8 space-y-8">
              <div className="text-center space-y-3 max-w-xl mx-auto">
                <div className="inline-flex justify-center">
                  <BrandLogo size="md" showSubtitle />
                </div>
                <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white pt-2 [text-wrap:balance]">
                  Hello! How can I help you today?
                </h2>
                <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 leading-relaxed">
                  Type a question or attach a photo of handwritten notes,
                  diagrams, or math problems. Reply mode:{" "}
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    {languageLabel}
                  </span>
                  .
                </p>
              </div>

              {/* 5 Suggested Prompt Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {SUGGESTED_PROMPTS.map((card, idx) => (
                  <button
                    key={card.id}
                    type="button"
                    onClick={() => handlePromptCard(card)}
                    className={`group text-left rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-600 p-4 transition-all hover:shadow-sm active:scale-[0.99] flex flex-col justify-between gap-2.5 ${
                      idx === SUGGESTED_PROMPTS.length - 1
                        ? "sm:col-span-2 lg:col-span-1"
                        : ""
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-blue-600 dark:text-blue-400">
                        {card.category}
                      </span>
                      <span className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center group-hover:bg-blue-50 dark:group-hover:bg-blue-950/50 transition-colors">
                        {card.icon}
                      </span>
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                        {card.title}
                      </div>
                      <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                        {card.prompt}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Conversation Messages */
            <div className="space-y-6">
              {messages.map((msg, index) => {
                const isUser = msg.role === "user";
                const isLastModel = index === lastModelMessageIndex;
                const isCurrentlyStreaming = isLastModel && isStreaming;

                if (isUser) {
                  return (
                    <div key={msg.id} className="flex justify-end">
                      <div className="max-w-[88%] sm:max-w-[78%] space-y-2">
                        {msg.image && (
                          <div className="flex justify-end">
                            <button
                              type="button"
                              onClick={() =>
                                setLightboxImage(
                                  `data:${msg.image!.mimeType};base64,${msg.image!.data}`
                                )
                              }
                              className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-xs hover:opacity-95 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
                              aria-label="Enlarge uploaded image"
                            >
                              <img
                                src={`data:${msg.image.mimeType};base64,${msg.image.data}`}
                                alt={msg.image.name || "Uploaded photo"}
                                className="max-h-64 w-auto object-contain"
                              />
                            </button>
                          </div>
                        )}
                        {msg.text && (
                          <div className="rounded-2xl rounded-tr-sm bg-blue-600 text-white px-4 py-3 text-[15px] leading-relaxed whitespace-pre-wrap break-words shadow-xs">
                            {msg.text}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                }

                return (
                  <div key={msg.id} className="flex items-start gap-3 sm:gap-3.5">
                    <div
                      className="w-8 h-8 rounded-xl bg-slate-900 dark:bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold font-display"
                      aria-hidden="true"
                    >
                      M
                    </div>
                    <div className="flex-1 min-w-0 space-y-2.5">
                      <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <span className="font-semibold text-slate-900 dark:text-slate-100">
                          MIH.AI
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">
                          {new Date(msg.createdAt).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>

                      {msg.error ? (
                        <div className="rounded-2xl border border-red-200 dark:border-red-900/70 bg-red-50 dark:bg-red-950/40 px-4 py-3 text-sm text-red-800 dark:text-red-200 space-y-2">
                          <div className="flex items-start gap-2">
                            <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
                            <span>{msg.error}</span>
                          </div>
                          {isLastModel && !isStreaming && (
                            <button
                              type="button"
                              onClick={onRegenerateLast}
                              className="inline-flex items-center gap-1.5 text-xs font-semibold text-red-700 dark:text-red-300 hover:underline"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              <span>Try again</span>
                            </button>
                          )}
                        </div>
                      ) : msg.text ? (
                        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 px-4 sm:px-5 py-3.5 sm:py-4">
                          <MarkdownRenderer content={msg.text} />
                        </div>
                      ) : (
                        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 px-4 py-3.5 inline-flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                          <Lightbulb className="w-4 h-4 text-blue-600 dark:text-blue-400 animate-pulse" />
                          <span>Thinking…</span>
                        </div>
                      )}

                      {/* Response Actions: Copy, Regenerate, New Chat */}
                      {!isCurrentlyStreaming && msg.text && !msg.error && (
                        <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                          <button
                            type="button"
                            onClick={() => handleCopyAnswer(msg.id, msg.text)}
                            className="min-h-[36px] px-2.5 py-1 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200/60 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 transition-colors"
                          >
                            {copiedId === msg.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                                <span>Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copy answer</span>
                              </>
                            )}
                          </button>

                          {isLastModel && (
                            <button
                              type="button"
                              onClick={onRegenerateLast}
                              className="min-h-[36px] px-2.5 py-1 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200/60 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 transition-colors"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              <span>Regenerate</span>
                            </button>
                          )}

                          {isLastModel && (
                            <button
                              type="button"
                              onClick={onNewChat}
                              className="min-h-[36px] px-2.5 py-1 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200/60 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 transition-colors"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>New chat</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
      </div>

      {/* Bottom Message Composer (Text + Photo ONLY — Zero Audio Controls) */}
      <div className="shrink-0 bg-white/95 dark:bg-slate-950/95 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800/80 px-3 sm:px-6 py-2.5 sm:py-3.5 pb-safe">
        <div className="max-w-3xl mx-auto space-y-2">
          {/* Error / Attachment Feedback */}
          {(attachmentError || errorBanner) && (
            <div className="rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/50 px-3.5 py-2.5 text-xs sm:text-sm text-red-700 dark:text-red-200 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 min-w-0">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span className="truncate sm:whitespace-normal">
                  {attachmentError || errorBanner}
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setAttachmentError(null);
                  onDismissError();
                }}
                className="p-1 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/50 shrink-0"
                aria-label="Dismiss error"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Image Attachment Preview */}
          {attachment && (
            <div className="flex items-center gap-3 p-2 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-fit max-w-full">
              <img
                src={attachment.previewUrl}
                alt="Attached preview"
                className="w-12 h-12 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
              />
              <div className="min-w-0 pr-1">
                <div className="text-xs font-medium text-slate-900 dark:text-slate-100 truncate max-w-[180px] sm:max-w-[260px]">
                  {attachment.name}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                  {formatBytes(attachment.sizeBytes)}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setAttachment(null)}
                className="min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors shrink-0"
                aria-label="Remove attached image"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Hidden File Inputs (Gallery & Mobile Camera) */}
          <input
            ref={galleryInputRef}
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp"
            className="hidden"
            onChange={(e) => {
              handleFileSelected(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
          <input
            ref={mobileCameraInputRef}
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp"
            capture="environment"
            className="hidden"
            onChange={(e) => {
              handleFileSelected(e.target.files?.[0]);
              e.target.value = "";
            }}
          />

          {/* Composer Input Bar */}
          <form
            onSubmit={handleSubmit}
            className="flex items-end gap-1.5 sm:gap-2 rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/20 p-1.5 sm:p-2 transition-all"
          >
            {/* Gallery Attachment Button */}
            <button
              type="button"
              onClick={() => galleryInputRef.current?.click()}
              disabled={isStreaming}
              className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 disabled:opacity-40 transition-colors shrink-0"
              aria-label="Attach image from gallery"
              title="Upload image (JPG, PNG, WEBP)"
            >
              <ImagePlus className="w-5 h-5" />
            </button>

            {/* Camera Upload Button */}
            <button
              type="button"
              onClick={handleCameraClick}
              disabled={isStreaming}
              className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 disabled:opacity-40 transition-colors shrink-0"
              aria-label="Take a photo with camera"
              title="Take photo with camera"
            >
              <Camera className="w-5 h-5" />
            </button>

            {/* Text Input */}
            <textarea
              ref={textareaRef}
              rows={1}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask MIH.AI anything or attach a photo…"
              aria-label="Ask MIH.AI"
              className="flex-1 min-w-0 max-h-40 bg-transparent px-2 py-2.5 text-[15px] text-slate-900 dark:text-slate-100 placeholder:text-slate-500 dark:placeholder:text-slate-400 resize-none focus:outline-none leading-snug"
            />

            {/* Send or Stop Button */}
            {isStreaming ? (
              <button
                type="button"
                onClick={onStopStreaming}
                className="min-h-[44px] min-w-[44px] px-3 rounded-xl bg-slate-900 dark:bg-slate-200 text-white dark:text-slate-900 hover:opacity-90 flex items-center justify-center gap-1.5 text-sm font-medium transition-opacity shrink-0"
                aria-label="Stop generating"
              >
                <Square className="w-4 h-4 fill-current" />
                <span className="hidden sm:inline">Stop</span>
              </button>
            ) : (
              <button
                type="submit"
                disabled={!inputText.trim() && !attachment}
                className="min-h-[44px] min-w-[44px] px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 dark:disabled:bg-slate-800 disabled:text-slate-500 dark:disabled:text-slate-600 text-white flex items-center justify-center gap-1.5 text-sm font-semibold transition-colors shrink-0"
                aria-label="Send message"
              >
                <SendHorizontal className="w-4 h-4" />
                <span className="hidden sm:inline">Send</span>
              </button>
            )}
          </form>

          <p className="text-[11px] text-center text-slate-500 dark:text-slate-400">
            Supports JPG, PNG, WEBP up to 5 MB · Text &amp; photo input only · Verify important answers.
          </p>
        </div>
      </div>

      {/* Desktop / Browser Camera Capture Modal */}
      <CameraModal
        open={cameraModalOpen}
        onClose={() => setCameraModalOpen(false)}
        onCaptureFile={(file) => handleFileSelected(file)}
        onFallbackFilePick={() => mobileCameraInputRef.current?.click()}
      />

      {/* Image Lightbox Preview */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setLightboxImage(null)}
          role="dialog"
          aria-modal="true"
          aria-label="Image preview"
        >
          <button
            type="button"
            onClick={() => setLightboxImage(null)}
            className="absolute top-4 right-4 min-h-[44px] min-w-[44px] rounded-xl bg-slate-900/80 text-white flex items-center justify-center hover:bg-slate-800"
            aria-label="Close image preview"
          >
            <X className="w-5 h-5" />
          </button>
          <img
            src={lightboxImage}
            alt="Full preview"
            className="max-w-full max-h-[88vh] rounded-2xl object-contain shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
};
