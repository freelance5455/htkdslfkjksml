import React, { useMemo, useState } from 'react';
import { Download } from 'lucide-react';
import type { ComputedDay, DayStatus } from '../types';
import {
  exportDaysToCSV,
  formatArabicDateShort,
  getStatusLabelAr,
  getWeekdayName,
} from '../utils/attendance';

interface AttendanceLogTableProps {
  days: ComputedDay[];
  returnStartDate: string;
  todayKey: string;
  saving: boolean;
  onQuickSetStatus: (day: ComputedDay, nextStatus: DayStatus) => Promise<void>;
}

type FilterMode = 'all' | 'work' | 'annual';

export const AttendanceLogTable: React.FC<AttendanceLogTableProps> = ({
  days,
  returnStartDate,
  todayKey,
  saving,
  onQuickSetStatus,
}) => {
  const [filter, setFilter] = useState<FilterMode>('all');

  const orderedDays = useMemo(() => {
    const reversed = [...days].reverse();
    if (filter === 'all') return reversed;
    return reversed.filter((d) => d.status === filter);
  }, [days, filter]);

  const workCount = useMemo(() => days.filter((d) => d.status === 'work').length, [days]);
  const annualCount = useMemo(() => days.filter((d) => d.status === 'annual').length, [days]);

  const handleExport = () => {
    if (days.length === 0) return;
    exportDaysToCSV(days, `eladawy-attendance-${returnStartDate || todayKey}.csv`);
  };

  return (
    <section id="records" className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="p-5 sm:p-6 border-b border-slate-200 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900">
            سجل أيام الحضور والإجازة الاعتيادي
          </h2>
          <p className="text-xs text-slate-500 mt-1 tabular-nums">
            {days.length > 0
              ? `إجمالي السجل: ${days.length} يوم (${workCount} حضور · ${annualCount} اعتيادي)`
              : 'يظهر هنا السجل اليومي تلقائياً عند تسجيل أول يوم عودة أو تسجيل أيام الإجازة الاعتيادي.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                filter === 'all'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              الكل ({days.length})
            </button>
            <button
              type="button"
              onClick={() => setFilter('work')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                filter === 'work'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              الحضور ({workCount})
            </button>
            <button
              type="button"
              onClick={() => setFilter('annual')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                filter === 'annual'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              اعتيادي ({annualCount})
            </button>
          </div>

          <button
            type="button"
            onClick={handleExport}
            disabled={days.length === 0}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            <span>تصدير CSV</span>
          </button>
        </div>
      </div>

      {orderedDays.length === 0 ? (
        <div className="p-10 text-center text-sm text-slate-500">
          لا توجد أيام مسجلة في هذا العرض حالياً.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th className="py-3 px-4">التاريخ</th>
                <th className="py-3 px-4">اليوم</th>
                <th className="py-3 px-4">الحالة</th>
                <th className="py-3 px-4 hidden sm:table-cell">الاحتساب</th>
                <th className="py-3 px-4 hidden md:table-cell">ملاحظة</th>
                <th className="py-3 px-4 text-left">تعديل سريع</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {orderedDays.map((day) => {
                const nextStatus: DayStatus = day.status === 'work' ? 'annual' : 'work';
                const statusColor = day.status === 'work' ? 'text-emerald-700' : 'text-sky-700';

                return (
                  <tr key={day.date} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono-num tabular-nums text-slate-900 whitespace-nowrap">
                      {formatArabicDateShort(day.date)}
                    </td>
                    <td className="py-3 px-4 text-slate-700 whitespace-nowrap">
                      {getWeekdayName(day.date)}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className={`font-semibold ${statusColor}`}>
                        {getStatusLabelAr(day.status)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-500 hidden sm:table-cell whitespace-nowrap">
                      {day.source === 'manual' ? 'تسجيل يدوي' : 'تلقائي'}
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-600 hidden md:table-cell max-w-[240px] truncate">
                      {day.note || '—'}
                    </td>
                    <td className="py-3 px-4 text-left whitespace-nowrap">
                      <button
                        type="button"
                        disabled={saving}
                        onClick={() => void onQuickSetStatus(day, nextStatus)}
                        className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                      >
                        {day.status === 'work' ? 'تحويل لإجازة اعتيادي' : 'تحويل لحضور'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
};
