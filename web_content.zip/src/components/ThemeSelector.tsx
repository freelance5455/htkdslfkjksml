import React, { useState } from 'react';
import { ClockTheme, FontStyle } from '../types/clock';
import { PRESET_THEMES } from '../data/themes';
import { Palette, Sparkles, Sliders, Check } from 'lucide-react';

interface ThemeSelectorProps {
  currentTheme: ClockTheme;
  onSelectTheme: (theme: ClockTheme) => void;
  onUpdateCustomTheme: (updates: Partial<ClockTheme>) => void;
}

const FONT_OPTIONS: { id: FontStyle; name: string; sample: string }[] = [
  { id: 'segment', name: '7-Segment LED', sample: '08:45' },
  { id: 'jetbrains', name: 'Modern Mono', sample: '08:45' },
  { id: 'orbitron', name: 'Orbitron Sci-Fi', sample: '08:45' },
  { id: 'jakarta', name: 'Clean Sans', sample: '08:45' },
  { id: 'bebas', name: 'Bebas Condensed', sample: '08:45' },
  { id: 'vt323', name: 'CRT Terminal', sample: '08:45' },
];

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({
  currentTheme,
  onSelectTheme,
  onUpdateCustomTheme,
}) => {
  const [activeTab, setActiveTab] = useState<'presets' | 'customizer'>('presets');

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6">
      {/* Tab Switcher */}
      <div className="flex items-center justify-between border-b pb-4" style={{ borderColor: currentTheme.border }}>
        <div>
          <h2 className="text-lg font-semibold tracking-tight" style={{ color: currentTheme.textPrimary }}>
            Clock Themes
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Choose curated visual styles or create your bespoke aesthetic.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-neutral-900 border border-neutral-800">
          <button
            onClick={() => setActiveTab('presets')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              activeTab === 'presets'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Presets</span>
          </button>
          <button
            onClick={() => setActiveTab('customizer')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              activeTab === 'customizer'
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Customizer</span>
          </button>
        </div>
      </div>

      {/* Presets Gallery */}
      {activeTab === 'presets' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3.5">
          {PRESET_THEMES.map((theme) => {
            const isSelected = currentTheme.id === theme.id;
            return (
              <div
                key={theme.id}
                onClick={() => onSelectTheme(theme)}
                className={`group relative p-4 rounded-2xl border text-left cursor-pointer transition-all duration-200 hover:-translate-y-0.5 ${
                  isSelected ? 'ring-2' : 'hover:border-slate-500'
                }`}
                style={{
                  backgroundColor: theme.surfaceBg,
                  borderColor: isSelected ? theme.textAccent : theme.border,
                }}
              >
                {/* Theme miniature preview card */}
                <div
                  className="w-full h-20 rounded-xl mb-3 flex flex-col items-center justify-center p-2 relative overflow-hidden border"
                  style={{
                    backgroundColor: theme.background,
                    borderColor: theme.border,
                  }}
                >
                  <span
                    className="text-2xl font-bold tracking-tight select-none"
                    style={{
                      color: theme.textPrimary,
                      filter: theme.displayGlow ? `drop-shadow(0 0 6px ${theme.glowColor})` : undefined,
                    }}
                  >
                    10:42
                  </span>
                  <div className="flex gap-1 mt-1">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: theme.textPrimary }} />
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: theme.textAccent }} />
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: theme.textSecondary }} />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold tracking-tight" style={{ color: theme.textPrimary }}>
                    {theme.name}
                  </h4>
                  {isSelected && (
                    <div
                      className="w-5 h-5 rounded-full flex items-center justify-center text-white"
                      style={{ backgroundColor: theme.textAccent }}
                    >
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </div>

                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {theme.description}
                </p>
              </div>
            );
          })}
        </div>
      )}

      {/* Live Customizer */}
      {activeTab === 'customizer' && (
        <div
          className="p-6 rounded-2xl border space-y-6"
          style={{
            backgroundColor: currentTheme.surfaceBg,
            borderColor: currentTheme.border,
          }}
        >
          {/* Font Selector */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
              Typography Style
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {FONT_OPTIONS.map((font) => (
                <button
                  key={font.id}
                  type="button"
                  onClick={() => onUpdateCustomTheme({ fontStyle: font.id })}
                  className="p-3 rounded-xl border text-left transition-all hover:bg-white/5"
                  style={{
                    backgroundColor: currentTheme.fontStyle === font.id ? currentTheme.background : 'transparent',
                    borderColor: currentTheme.fontStyle === font.id ? currentTheme.textAccent : currentTheme.border,
                  }}
                >
                  <div className="text-xs font-semibold text-slate-300">{font.name}</div>
                  <div
                    className="text-lg font-bold mt-1"
                    style={{ color: currentTheme.textPrimary }}
                  >
                    {font.sample}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Color Palettes */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
              Color Palette
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Digit Primary Color */}
              <div className="p-3.5 rounded-xl border" style={{ borderColor: currentTheme.border }}>
                <span className="block text-xs font-medium text-slate-300 mb-2">Digits Primary</span>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={currentTheme.textPrimary.startsWith('#') ? currentTheme.textPrimary : '#00f5d4'}
                    onChange={(e) => onUpdateCustomTheme({ textPrimary: e.target.value })}
                    className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                  />
                  <span className="text-xs font-mono tabular-nums text-slate-400 uppercase">
                    {currentTheme.textPrimary}
                  </span>
                </div>
              </div>

              {/* Accent Color */}
              <div className="p-3.5 rounded-xl border" style={{ borderColor: currentTheme.border }}>
                <span className="block text-xs font-medium text-slate-300 mb-2">Accent / Highlights</span>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={currentTheme.textAccent.startsWith('#') ? currentTheme.textAccent : '#ff007f'}
                    onChange={(e) => onUpdateCustomTheme({ textAccent: e.target.value })}
                    className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                  />
                  <span className="text-xs font-mono tabular-nums text-slate-400 uppercase">
                    {currentTheme.textAccent}
                  </span>
                </div>
              </div>

              {/* Background Color */}
              <div className="p-3.5 rounded-xl border" style={{ borderColor: currentTheme.border }}>
                <span className="block text-xs font-medium text-slate-300 mb-2">Canvas Background</span>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={currentTheme.background.startsWith('#') ? currentTheme.background : '#000000'}
                    onChange={(e) => onUpdateCustomTheme({ background: e.target.value })}
                    className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                  />
                  <span className="text-xs font-mono tabular-nums text-slate-400 uppercase">
                    {currentTheme.background}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Glow & Backdrop Effects */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border" style={{ borderColor: currentTheme.border }}>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-semibold" style={{ color: currentTheme.textPrimary }}>
                    Display Glow Aura
                  </div>
                  <div className="text-xs text-slate-400">Radiant phosphor glow around digits</div>
                </div>
                <button
                  type="button"
                  onClick={() => onUpdateCustomTheme({ displayGlow: !currentTheme.displayGlow })}
                  className="w-11 h-6 rounded-full relative transition-colors"
                  style={{
                    backgroundColor: currentTheme.displayGlow ? currentTheme.textAccent : 'rgba(255,255,255,0.15)',
                  }}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                      currentTheme.displayGlow ? 'translate-x-5' : 'translate-x-0.5'
                    } mt-0.5`}
                  />
                </button>
              </div>
            </div>

            {/* Pattern Effect */}
            <div className="p-4 rounded-xl border" style={{ borderColor: currentTheme.border }}>
              <span className="block text-xs font-medium text-slate-300 mb-2">Backdrop Texture</span>
              <div className="grid grid-cols-4 gap-1.5">
                {(['none', 'dots', 'grid', 'scanlines'] as const).map((pat) => (
                  <button
                    key={pat}
                    type="button"
                    onClick={() => onUpdateCustomTheme({ pattern: pat })}
                    className="py-1.5 text-xs font-medium rounded-lg border capitalize transition-colors text-center"
                    style={{
                      backgroundColor: currentTheme.pattern === pat ? currentTheme.textAccent : 'transparent',
                      color: currentTheme.pattern === pat ? '#fff' : currentTheme.textSecondary,
                      borderColor: currentTheme.pattern === pat ? currentTheme.textAccent : currentTheme.border,
                    }}
                  >
                    {pat}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
