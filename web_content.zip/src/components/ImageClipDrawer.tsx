import React, { useRef } from "react";
import {
  X,
  Image as ImageIcon,
  Plus,
  Trash2,
  Download,
  ArrowRightCircle,
  UploadCloud,
  Layers
} from "lucide-react";
import { ImageClip } from "../types";
import { downloadFile, compressImageFile } from "../utils/storage";

interface ImageClipDrawerProps {
  isOpen: boolean;
  clips: ImageClip[];
  onClose: () => void;
  onAddClip: (clip: ImageClip) => void;
  onDeleteClip: (id: string) => void;
  onInsertIntoNote?: (imageUrl: string) => void;
  isNoteEditorOpen?: boolean;
}

export const ImageClipDrawer: React.FC<ImageClipDrawerProps> = ({
  isOpen,
  clips,
  onClose,
  onAddClip,
  onDeleteClip,
  onInsertIntoNote,
  isNoteEditorOpen,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleDeviceUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const compressed = await compressImageFile(file, 1600, 0.82);
      const newClip: ImageClip = {
        id: `clip-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        name: file.name || "Yüklenen Fotoğraf",
        data: compressed.dataUrl,
        createdAt: new Date().toISOString(),
      };
      onAddClip(newClip);
    } catch (err) {
      console.warn("Clip upload error:", err);
    }
    e.target.value = "";
  };

  const handleDownload = (clip: ImageClip) => {
    // Determine extension or default to png
    const filename = `${clip.name.replace(/\.[^/.]+$/, "") || "noteflow-enstantane"}.png`;
    const link = document.createElement("a");
    link.href = clip.data;
    link.download = filename;
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end bg-slate-900/50 backdrop-blur-xs animate-in fade-in">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 h-[100dvh] shadow-2xl border-l border-slate-200 dark:border-slate-800 flex flex-col transform transition-transform duration-300 safe-bottom modal-overscroll-contain">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-100 dark:bg-teal-950/80 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Görsel & Enstantane Galerisi
              </h3>
              <p className="text-[11px] text-slate-500">
                {clips.length} adet görsel kayıtlı
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload banner */}
        <div className="p-3.5 bg-teal-50/70 dark:bg-teal-950/30 border-b border-teal-100 dark:border-teal-900/50 flex items-center justify-between gap-3">
          <div className="text-xs text-teal-900 dark:text-teal-200">
            <span className="font-bold">Cihazdan Fotoğraf Ekle:</span>
            <p className="text-[11px] text-teal-700 dark:text-teal-300">
              Galerinizden fotoğraf yükleyip notlara ekleyin
            </p>
          </div>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1 px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all whitespace-nowrap"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Fotoğraf Yükle</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleDeviceUpload}
          />
        </div>

        {/* Informative banner about text-to-photo feature */}
        <div className="px-4 py-2 bg-slate-100 dark:bg-slate-800/80 text-[11px] text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
          💡 <strong>İpucu:</strong> Not yazarken önemli bir kısmı seçip <strong>"Kareye Al ve Fotoğraf Olarak Kaydet"</strong> butonuna bastığınızda fotoğrafı burada listelenir!
        </div>

        {/* Clips Grid */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {clips.length === 0 ? (
            <div className="text-center py-20 px-4 text-slate-400">
              <ImageIcon className="w-12 h-12 mx-auto mb-2 opacity-30" />
              <p className="text-xs font-semibold">Henüz galeriye görsel kaydedilmedi.</p>
              <p className="text-[11px] text-slate-400 mt-1 max-w-xs mx-auto">
                Yukarıdaki butondan galerinizden fotoğraf yükleyebilir veya not penceresindeki "Kare İçine Alıp Fotoğraf Kaydet" özelliğini kullanabilirsiniz.
              </p>
            </div>
          ) : (
            clips.map((clip) => (
              <div
                key={clip.id}
                className="group relative bg-slate-50 dark:bg-slate-800/70 rounded-2xl border border-slate-200 dark:border-slate-700 p-2.5 overflow-hidden shadow-xs hover:shadow-md transition-all space-y-2"
              >
                {/* Image Thumbnail */}
                <div className="relative rounded-xl overflow-hidden bg-slate-200 dark:bg-slate-700 aspect-video flex items-center justify-center">
                  <img
                    src={clip.data}
                    alt={clip.name}
                    className="w-full h-full object-contain"
                  />
                </div>

                {/* Info and Actions */}
                <div className="flex items-center justify-between gap-2 pt-1">
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {clip.name}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {new Date(clip.createdAt).toLocaleDateString("tr-TR", {
                        day: "numeric",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    {/* Insert into note button */}
                    {onInsertIntoNote && (
                      <button
                        onClick={() => {
                          onInsertIntoNote(clip.data);
                        }}
                        title="Bu Fotoğrafı Nota Ekle"
                        className="flex items-center gap-1 px-2.5 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all"
                      >
                        <ArrowRightCircle className="w-3.5 h-3.5" />
                        <span>Metne Ekle</span>
                      </button>
                    )}

                    {/* Download */}
                    <button
                      onClick={() => handleDownload(clip)}
                      title="Cihaza İndir"
                      className="p-1.5 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => onDeleteClip(clip.id)}
                      title="Galeriden Sil"
                      className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
