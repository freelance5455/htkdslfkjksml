import React from 'react';
import { 
  Layers, 
  Headphones, 
  Wrench, 
  Cpu, 
  Zap, 
  Unlock, 
  Smartphone, 
  CreditCard, 
  Languages, 
  CheckCircle2, 
  Sparkles, 
  PhoneCall, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  LayoutTemplate
} from 'lucide-react';

interface ShopServicesProps {
  onShowSplash: () => void;
}

const servicesList = [
  {
    id: 'parts',
    title: 'قطع غيار أصلية',
    subtitle: 'شاشات وكاميرات وبطاريات وكوابل فلكس',
    icon: Layers,
    details: 'نوفر قطع غيار أصلية ومضمونة من وكالات معتمدة لجميع أنواع الهواتف (آيفون، سامسونج، شاومي، هواوي، إنفينيكس وغيرها) مع اختبار دقيق قبل التركيب.',
  },
  {
    id: 'accessories',
    title: 'إكسسوارات',
    subtitle: 'حمايات شاشة وشواحن وسماعات وكفرات',
    icon: Headphones,
    details: 'أحدث ملحقات الحماية الزجاجية المقاومة للصدمات، كابلات الشحن السريع المعتمدة، شواحن أصلية، وبطاريات متنقلة متوافقة تماماً مع أجهزتكم.',
  },
  {
    id: 'hardware',
    title: 'صيانة (هاردوير)',
    subtitle: 'إصلاح أعطال اللوحة الأم والآيسيات والماء',
    icon: Wrench,
    details: 'ورشة مجهزة بأحدث أجهزة الفحص المجهري (Microscope)، اللحام الحراري الدقيق، تبديل منفذ الشحن والشاشات، وإصلاح هواتف السقوط في الماء.',
  },
  {
    id: 'software',
    title: 'برمجة (سوفتوير)',
    subtitle: 'تفليش رسمي وإصلاح البوت والموت المفاجئ',
    icon: Cpu,
    details: 'تثبيت وتحديث الرومات الرسمية والمعدلة، حل مشكلات إعادة التشغيل التلقائي (Bootloop)، تجاوز حماية جوجل (FRP)، وإصلاح السيريال والـ IMEI.',
  },
  {
    id: 'instant-recharge',
    title: 'شحن فوري',
    subtitle: 'رصيد وباقات لجميع شركات الاتصالات',
    icon: Zap,
    details: 'شحن مباشر وفوري لجميع الشبكات المحلية والإنترنت، تفعيل الباقات الشهرية والأسبوعية بسرعة فائقة دون أي تأخير.',
  },
  {
    id: 'network-unlock',
    title: 'فك شفرات',
    subtitle: 'فتح الشبكات الدولية والمحلية لجميع الأجهزة',
    icon: Unlock,
    details: 'فك شفرات الشبكات المغلقة (Carrier Unlock) للهواتف القادمة من الخارج (أمريكا، أوروبا، الخليج) لتعمل على كل الشرائح المحلية بكفاءة.',
  },
  {
    id: 'sims',
    title: 'شرائح',
    subtitle: 'تفعيل شرائح جديدة وبدل فاقد ونقل ملكية',
    icon: Smartphone,
    details: 'خدمات إصدار وتفعيل شرائح الاتصال الجديدة، استخراج بدل فاقد معتمد، والتحويل بين الباقات والشركات بكل سهولة.',
  },
  {
    id: 'cards',
    title: 'كروت',
    subtitle: 'بطاقات شحن الألعاب والإنترنت والمتاجر',
    icon: CreditCard,
    details: 'كروت شحن الإنترنت، كروت منصات الألعاب (PlayStation, PUBG, FreeFire)، بطاقات Google Play و iTunes بأفضل الأسعار المعتمدة.',
  },
  {
    id: 'arabization',
    title: 'تعريب',
    subtitle: 'تعريب شامل للنظام والقوائم والكيبورد',
    icon: Languages,
    details: 'تعريب كامل واحترافي لجميع إصدارات أندرويد المستوردة والأجهزة التي لا تدعم اللغة العربية في قوائمها الأصلية، بخطوط عربية أصيلة وجميلة.',
  },
];

export const ShopServices: React.FC<ShopServicesProps> = ({ onShowSplash }) => {
  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div className="relative bg-gradient-to-r from-red-800 via-red-700 to-red-900 border border-red-600 rounded-3xl p-6 sm:p-8 text-white shadow-xl overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-white border border-white/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>المركز المعتمد لصيانة وبرمجة الهواتف</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black font-heading tracking-tight">
              العجردي لصيانة وبرمجة الجوال
            </h2>
            <p className="text-sm sm:text-base text-red-100 max-w-xl leading-relaxed">
              خبرة عريقة في معالجة أصعب الأعطال الفنية، برمجة الأجهزة الحديثة، وتوفير قطع الغيار الموثوقة بأعلى معايير الدقة والجودة.
            </p>
          </div>

          {/* Quick Action: Re-view billboard ad */}
          <button
            onClick={onShowSplash}
            className="inline-flex items-center justify-center gap-2 bg-white hover:bg-red-50 text-red-700 font-black text-xs px-5 py-3.5 rounded-2xl shadow-lg transition-all active:scale-95 cursor-pointer shrink-0"
          >
            <LayoutTemplate className="w-4 h-4" />
            <span>عرض لوحة المحل الرسمية</span>
          </button>
        </div>

        {/* Decorative corner glow */}
        <div className="absolute -top-10 -left-10 w-44 h-44 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Services Grid (All 9 services) */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-red-500" />
            <span>خدماتنا التسع المتكاملة في المحل</span>
          </h3>
          <span className="text-xs text-slate-400">
            ضمان وثقة تامة
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {servicesList.map((service, idx) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                className="bg-slate-900 border border-slate-800 hover:border-red-900/60 rounded-3xl p-5 transition-all shadow-md flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-2xl bg-red-600/10 text-red-500 group-hover:bg-red-600 group-hover:text-white transition-colors flex items-center justify-center font-bold shrink-0">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-base font-bold text-white group-hover:text-red-400 transition-colors">
                        {service.title}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        {service.subtitle}
                      </p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {service.details}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1 text-emerald-400 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    خدمة متوفرة يومياً
                  </span>
                  <span className="font-mono text-slate-500">#{idx + 1}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Workstation Snapshot & Customer Service Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <div className="relative rounded-2xl overflow-hidden h-48 sm:h-56 bg-slate-950 border border-slate-800">
            <img
              src="/src/assets/images/alajradi_phone_repair_1793106557031.jpg"
              alt="طاولة صيانة العجردي"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4">
              <span className="text-xs font-bold text-white bg-red-600/90 px-3 py-1 rounded-md">
                طاولة الفحص الميكانيكي والإلكتروني
              </span>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-lg font-bold text-white">
              لماذا يختار العملاء «العجردي»؟
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              نحن نؤمن بأن الصيانة ليست مجرد استبدال قطع عشوائي، بل تشخيص علمي دقيق لدائرة العطل الكهربائية والبرمجية، واستخدام أدوات أصلية تحمي بيانات العميل وتحافظ على عمر جهازه الافتراضي.
            </p>
            <div className="space-y-2 pt-1 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-red-500 shrink-0" />
                <span>حفظ تام لسرية وخصوصية الصور والملفات الشخصية أثناء الصيانة.</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-red-500 shrink-0" />
                <span>ضمان حقيقي ومكتوب على كافة قطع الغيار المستبدلة.</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-red-500 shrink-0" />
                <span>سرعة قياسية في الإنجاز (استلام معظم الأجهزة في نفس اليوم).</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
