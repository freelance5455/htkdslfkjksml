import React from "react";

interface MenuSkeletonProps {
  viewMode?: "detailed" | "compact";
  count?: number;
}

export const MenuSkeleton: React.FC<MenuSkeletonProps> = ({
  viewMode = "detailed",
  count = 6,
}) => {
  const items = Array.from({ length: count }, (_, i) => i);

  if (viewMode === "compact") {
    return (
      <div className="space-y-6" aria-busy="true" aria-label="Loading dishes">
        {/* Section Title Skeleton */}
        <div className="border-b border-[#D8D0C2]/80 pb-3 flex items-end justify-between">
          <div className="space-y-2">
            <div className="w-48 h-7 rounded-xs skeleton-shimmer" />
            <div className="w-72 h-3.5 rounded-xs skeleton-shimmer" />
          </div>
          <div className="w-16 h-4 rounded-full skeleton-shimmer" />
        </div>

        {/* Compact Table / List Rows */}
        <div className="divide-y divide-[#D8D0C2]/40 bg-[#FDFBF7] rounded-sm border border-[#D8D0C2]/60 overflow-hidden shadow-xs">
          {items.map((i) => (
            <div
              key={`skeleton-compact-${i}`}
              className="p-3.5 sm:p-4 flex items-center justify-between gap-4 animate-pulse"
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                {/* Veg/Non-Veg Dot Placeholder */}
                <div className="w-4 h-4 rounded-[2px] border border-[#D8D0C2] flex items-center justify-center shrink-0">
                  <div className="w-2 h-2 rounded-full skeleton-shimmer" />
                </div>

                {/* Title & Excerpt */}
                <div className="space-y-1.5 min-w-0 flex-1">
                  <div
                    className="h-4 rounded-xs skeleton-shimmer"
                    style={{ width: `${60 + (i % 3) * 15}%` }}
                  />
                  <div className="w-3/5 h-3 rounded-xs skeleton-shimmer hidden sm:block" />
                </div>
              </div>

              {/* Badges and Price */}
              <div className="flex items-center gap-3 shrink-0">
                <div className="w-16 h-4 rounded-full skeleton-shimmer hidden md:block" />
                <div className="w-12 h-5 rounded-xs skeleton-shimmer" />
                <div className="w-6 h-6 rounded-full skeleton-shimmer" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8" aria-busy="true" aria-label="Loading menu section">
      {/* Category Header Shimmer */}
      <div className="border-b border-[#D8D0C2]/80 pb-3 flex items-end justify-between">
        <div className="space-y-2">
          <div className="w-56 h-8 rounded-xs skeleton-shimmer" />
          <div className="w-80 h-3.5 rounded-xs skeleton-shimmer" />
        </div>
        <div className="w-20 h-5 rounded-full skeleton-shimmer" />
      </div>

      {/* Detailed Card Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
        {items.map((i) => (
          <div
            key={`skeleton-detailed-${i}`}
            className="flex flex-col justify-between bg-[#FDFBF7] border border-[#D8D0C2]/80 rounded-sm p-4 sm:p-5 relative shadow-xs"
          >
            <div>
              {/* Card Header: Dietary dot, Tag, Price */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-[2px] border border-[#D8D0C2] flex items-center justify-center shrink-0">
                    <div className="w-2 h-2 rounded-full skeleton-shimmer" />
                  </div>
                  <div className="w-20 h-4.5 rounded-full skeleton-shimmer" />
                </div>
                <div className="w-14 h-5 rounded-xs skeleton-shimmer" />
              </div>

              {/* Title Shimmer */}
              <div
                className="h-5 rounded-xs skeleton-shimmer mb-2.5"
                style={{ width: `${70 + (i % 4) * 8}%` }}
              />

              {/* Description Lines */}
              <div className="space-y-1.5 mb-4">
                <div className="w-full h-3.5 rounded-xs skeleton-shimmer" />
                <div
                  className="h-3.5 rounded-xs skeleton-shimmer"
                  style={{ width: `${80 - (i % 3) * 10}%` }}
                />
              </div>

              {/* Macro Indicators Shimmer */}
              <div className="flex items-center gap-1.5 py-1">
                <div className="w-16 h-3.5 rounded-xs skeleton-shimmer" />
                <div className="w-14 h-3.5 rounded-xs skeleton-shimmer" />
                <div className="w-14 h-3.5 rounded-xs skeleton-shimmer" />
              </div>
            </div>

            {/* Card Footer Line */}
            <div className="mt-4 pt-3 border-t border-[#D8D0C2]/50 flex items-center justify-between">
              <div className="w-36 h-3 rounded-xs skeleton-shimmer" />
              <div className="w-4 h-4 rounded-full skeleton-shimmer" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const CategoryRailSkeleton: React.FC = () => {
  return (
    <div className="flex items-center gap-2 overflow-hidden py-1">
      {Array.from({ length: 8 }).map((_, i) => (
        <div
          key={`rail-skeleton-${i}`}
          className="h-8 rounded-full skeleton-shimmer shrink-0"
          style={{ width: `${85 + (i % 4) * 18}px` }}
        />
      ))}
    </div>
  );
};
