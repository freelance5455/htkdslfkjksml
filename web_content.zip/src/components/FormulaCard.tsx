import type { Formula } from "../data/types";
import { useAppState } from "../state/AppState";

const subjectStyles: Record<string, string> = {
  Mathematics: "from-indigo-500 to-blue-500",
  Physics: "from-purple-500 to-fuchsia-500",
  Chemistry: "from-emerald-500 to-teal-500",
};

export default function FormulaCard({ formula }: { formula: Formula }) {
  const { navigate, isFavorite, toggleFavorite } = useAppState();
  const fav = isFavorite(formula.id);

  return (
    <button
      onClick={() => navigate({ name: "formula", id: formula.id })}
      className="group relative flex flex-col gap-2 rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
    >
      <div className="flex items-start justify-between gap-2">
        <span className={`inline-block rounded-md bg-gradient-to-r ${subjectStyles[formula.subject]} px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-white`}>
          Class {formula.classLevel} · {formula.subject}
        </span>
        <span
          role="button"
          tabIndex={0}
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(formula.id);
          }}
          className={`shrink-0 text-lg transition ${fav ? "text-amber-400" : "text-slate-300 group-hover:text-slate-400 dark:text-slate-700"}`}
          aria-label="Toggle favorite"
        >
          {fav ? "★" : "☆"}
        </span>
      </div>
      <h3 className="font-semibold text-slate-800 dark:text-slate-100">{formula.name}</h3>
      <p className="truncate font-mono text-sm text-indigo-600 dark:text-indigo-400">{formula.expression}</p>
      <p className="text-xs text-slate-400 dark:text-slate-500">{formula.chapter} · {formula.topic}</p>
    </button>
  );
}
