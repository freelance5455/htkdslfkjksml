import React, { useState } from 'react';
import { 
  ReceiptText, 
  Search, 
  Download, 
  ExternalLink, 
  CheckCircle2, 
  Clock, 
  ShoppingBag,
  CreditCard,
  Phone,
  ArrowRight,
  Wallet
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Order } from '../types';

export const OrdersList: React.FC = () => {
  const { orders, setCurrentView, addToast } = useStore();
  const [search, setSearch] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const filteredOrders = orders.filter(o => 
    o.id.toLowerCase().includes(search.toLowerCase()) ||
    o.transactionRef.toLowerCase().includes(search.toLowerCase()) ||
    o.customer.fullName.toLowerCase().includes(search.toLowerCase()) ||
    o.customer.email.toLowerCase().includes(search.toLowerCase())
  );

  const totalSalesRevenue = orders.reduce((sum, o) => sum + o.total, 0);

  return (
    <div className="space-y-6 pb-16 max-w-5xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600">
            <ReceiptText className="w-4 h-4" />
            <span>Painel Financeiro & Vendas</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Pedidos & Vendas Registradas
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Histórico completo de pagamentos liquidados via M-Pesa, e-Mola e cartões com baixa no estoque.
          </p>
        </div>

        {/* Revenue KPI banner & Payout CTA */}
        <div className="flex items-center gap-2.5">
          <div className="px-3.5 py-2 bg-emerald-50 rounded-xl border border-emerald-200">
            <div className="text-[10px] text-emerald-700 font-medium">Receita Liquidada</div>
            <div className="text-base font-bold font-mono text-emerald-800 tabular-nums">
              Mt {totalSalesRevenue.toLocaleString('pt-MZ')},00 MZN
            </div>
          </div>

          <button
            onClick={() => setCurrentView('payouts')}
            className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
          >
            <Wallet className="w-4 h-4" />
            <span>Sacar Dinheiro</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Pesquisar por Código de Pedido, Transação, Nome ou Email..."
          className="w-full pl-10 pr-4 py-2.5 text-xs bg-white border border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs"
        />
      </div>

      {/* Orders List or Empty state */}
      {filteredOrders.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 space-y-3">
          <div className="w-14 h-14 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <ShoppingBag className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-semibold text-slate-800">Nenhum pedido encontrado</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Ainda não há vendas registradas ou nenhum pedido corresponde à pesquisa. Faz uma compra de teste no checkout!
          </p>
          <button
            onClick={() => setCurrentView('store')}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold inline-flex items-center gap-2 transition-colors"
          >
            <span>Ir para a Loja</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredOrders.map((order) => (
            <div 
              key={order.id}
              className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs hover:border-slate-300 transition-all space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-900 font-mono">
                        {order.id}
                      </span>
                      <span className="text-slate-300">·</span>
                      <span className="text-[11px] font-mono text-slate-500">
                        {order.transactionRef}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500">
                      {order.customer.fullName} ({order.customer.email})
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end sm:self-auto">
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 uppercase">
                    {order.paymentMethod} • Pago
                  </span>
                  <div className="text-right">
                    <div className="font-mono font-bold text-slate-900 text-sm tabular-nums">
                      Mt {order.total.toLocaleString('pt-MZ')},00 MZN
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {new Date(order.createdAt).toLocaleDateString('pt-MZ')} às {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Items List in this Order */}
              <div className="divide-y divide-slate-100 bg-slate-50/50 rounded-lg p-2 text-xs">
                {order.items.map((item, idx) => (
                  <div key={idx} className="py-1.5 px-2 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-emerald-700 font-bold">{item.quantity}x</span>
                      <span className="font-medium text-slate-800">{item.productName}</span>
                      <span className="text-slate-400 font-mono text-[11px]">({item.sku})</span>
                    </div>
                    <div className="font-mono text-slate-700 tabular-nums">
                      {(item.price * item.quantity).toLocaleString('pt-MZ')} MT
                    </div>
                  </div>
                ))}
              </div>

              {/* Action row */}
              <div className="flex items-center justify-between text-xs pt-1">
                <div className="text-[11px] text-slate-500 flex items-center gap-2">
                  <span>Entrega:</span>
                  <strong className="text-slate-700">
                    {order.deliveryStatus === 'delivered' ? 'Liberado Imediatamente' : 'Em processamento'}
                  </strong>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      alert(`Comprovativo do Pedido #${order.id}\nCliente: ${order.customer.fullName}\nTotal: ${order.total} MT\nTransação: ${order.transactionRef}`);
                    }}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Recibo</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
