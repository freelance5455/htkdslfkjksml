import React, { useState, useMemo, useRef } from 'react';
import {
  Search,
  X,
  Bookmark,
  ChevronRight,
  Filter,
  Sparkles,
  Volume2
} from 'lucide-react';
import { WordData, FilterCategory, PosFilter, CognitiveStatus } from '../types';
import { EXAM_HOT_SET } from '../data/lexicon';
import { speakWord } from '../services/sound';

interface WordbookTabProps {
  words: WordData[];
  masteredWords: string[];
  reviseWords: string[];
  learnWords: string[];
  savedWords: string[];
  activeFilterCategory: FilterCategory;
  onSelectFilterCategory: (category: FilterCategory) => void;
  onOpenWordDetail: (word: WordData) => void;
  onToggleSave: (word: string) => void;
  voiceLang?: 'en-US' | 'en-GB';
}

export const WordbookTab: React.FC<WordbookTabProps> = ({
  words,
  masteredWords,
  reviseWords,
  learnWords,
  savedWords,
  activeFilterCategory,
  onSelectFilterCategory,
  onOpenWordDetail,
  onToggleSave,
  voiceLang = 'en-US',
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [posFilter, setPosFilter] = useState<PosFilter>('all');
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const getStatus = (word: string): CognitiveStatus => {
    if (masteredWords.includes(word)) return 'mastered';
    if (reviseWords.includes(word)) return 'revise';
    if (learnWords.includes(word)) return 'learn';
    return 'unassigned';
  };

  // Filtered and searched words
  const filteredWords = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    return words.filter((item) => {
      const status = getStatus(item.word);
      const isHot = EXAM_HOT_SET.has(item.word);
      const isSaved = savedWords.includes(item.word);

      // Category filter
      if (activeFilterCategory === 'hot' && !isHot) return false;
      if (activeFilterCategory === 'saved' && !isSaved) return false;
      if (activeFilterCategory === 'mastered' && status !== 'mastered') return false;
      if (activeFilterCategory === 'revise' && status !== 'revise') return false;
      if (activeFilterCategory === 'learn' && status !== 'learn') return false;

      // Part of speech filter
      if (posFilter !== 'all') {
        const itemPos = item.pos.toLowerCase();
        if (posFilter === 'noun' && !itemPos.includes('noun')) return false;
        if (posFilter === 'verb' && !itemPos.includes('verb')) return false;
        if (posFilter === 'adjective' && !itemPos.includes('adj')) return false;
        if (posFilter === 'adverb' && !itemPos.includes('adv')) return false;
      }

      // Letter filter
      if (selectedLetter && !item.word.toUpperCase().startsWith(selectedLetter)) {
        return false;
      }

      // Search query filter (matches English word, Bengali translation, Bengali pronunciation, English definition)
      if (query) {
        const matchWord = item.word.toLowerCase().includes(query);
        const matchBengali = item.bengali && item.bengali.toLowerCase().includes(query);
        const matchBengaliPron = item.bengaliPron && item.bengaliPron.toLowerCase().includes(query);
        const matchDef = item.simpleDef && item.simpleDef.toLowerCase().includes(query);
        const matchPos = item.pos && item.pos.toLowerCase().includes(query);

        if (!matchWord && !matchBengali && !matchBengaliPron && !matchDef && !matchPos) {
          return false;
        }
      }

      return true;
    });
  }, [words, searchQuery, activeFilterCategory, posFilter, selectedLetter, masteredWords, reviseWords, learnWords, savedWords]);

  const handleClearSearch = () => {
    setSearchQuery('');
    searchInputRef.current?.focus();
  };

  const handleResetAllFilters = () => {
    setSearchQuery('');
    setPosFilter('all');
    setSelectedLetter(null);
    onSelectFilterCategory('all');
  };

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  return (
    <div className="flex-1 flex flex-col overflow-hidden max-w-md mx-auto w-full">
      
      {/* Search and Filters Header */}
      <div className="p-3 bg-white dark:bg-[#111827] border-b border-slate-200 dark:border-slate-800 space-y-2.5 shrink-0">
        
        {/* Search Input Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search words, বাংলা অর্থ, or definition..."
            className="w-full pl-9 pr-9 py-2 bg-slate-100 dark:bg-slate-800 border border-transparent focus:border-emerald-500 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white transition-all font-medium"
          />
          {searchQuery && (
            <button
              onClick={handleClearSearch}
              className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              title="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Primary Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs font-bold pb-0.5">
          <button
            onClick={() => onSelectFilterCategory('all')}
            className={`px-3 py-1 rounded-xl shrink-0 transition-all ${
              activeFilterCategory === 'all'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            All ({words.length})
          </button>

          <button
            onClick={() => onSelectFilterCategory('hot')}
            className={`px-3 py-1 rounded-xl shrink-0 transition-all flex items-center gap-1 ${
              activeFilterCategory === 'hot'
                ? 'bg-amber-500 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            🔥 Priority ({EXAM_HOT_SET.size})
          </button>

          <button
            onClick={() => onSelectFilterCategory('saved')}
            className={`px-3 py-1 rounded-xl shrink-0 transition-all flex items-center gap-1 ${
              activeFilterCategory === 'saved'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-amber-700 dark:text-amber-400 hover:bg-slate-200'
            }`}
          >
            <Bookmark className="w-3 h-3 fill-current" /> Saved ({savedWords.length})
          </button>

          <button
            onClick={() => onSelectFilterCategory('mastered')}
            className={`px-3 py-1 rounded-xl shrink-0 transition-all ${
              activeFilterCategory === 'mastered'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-emerald-700 dark:text-emerald-400 hover:bg-slate-200'
            }`}
          >
            ✓ Known ({masteredWords.length})
          </button>

          <button
            onClick={() => onSelectFilterCategory('revise')}
            className={`px-3 py-1 rounded-xl shrink-0 transition-all ${
              activeFilterCategory === 'revise'
                ? 'bg-amber-500 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-amber-700 dark:text-amber-400 hover:bg-slate-200'
            }`}
          >
            ⚡ Revise ({reviseWords.length})
          </button>

          <button
            onClick={() => onSelectFilterCategory('learn')}
            className={`px-3 py-1 rounded-xl shrink-0 transition-all ${
              activeFilterCategory === 'learn'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-rose-700 dark:text-rose-400 hover:bg-slate-200'
            }`}
          >
            🎯 Learn ({learnWords.length})
          </button>
        </div>

        {/* Secondary Filters: Parts of Speech */}
        <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 pt-0.5">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            <span className="text-slate-400 flex items-center gap-1 shrink-0 font-bold">
              <Filter className="w-3 h-3" /> POS:
            </span>
            {(['all', 'noun', 'verb', 'adjective', 'adverb'] as PosFilter[]).map((pos) => (
              <button
                key={pos}
                onClick={() => setPosFilter(pos)}
                className={`px-2 py-0.5 rounded-lg capitalize transition-colors ${
                  posFilter === pos
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                }`}
              >
                {pos === 'all' ? 'All' : pos}
              </button>
            ))}
          </div>

          <span className="text-slate-400 font-mono text-[10px] shrink-0 ml-2">
            Showing {filteredWords.length}
          </span>
        </div>

        {/* Alphabet Scroller Ribbon */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar text-xs font-mono font-bold text-slate-500 pt-0.5">
          <button
            onClick={() => setSelectedLetter(null)}
            className={`px-2 py-0.5 rounded-lg transition-colors ${
              selectedLetter === null
                ? 'bg-emerald-600 text-white font-black'
                : 'bg-slate-100 dark:bg-slate-800 hover:bg-emerald-600 hover:text-white'
            }`}
          >
            A-Z
          </button>
          {alphabet.map((char) => {
            const isSelected = selectedLetter === char;
            return (
              <button
                key={char}
                onClick={() => setSelectedLetter(isSelected ? null : char)}
                className={`px-2 py-0.5 rounded-lg transition-colors ${
                  isSelected
                    ? 'bg-emerald-600 text-white font-black'
                    : 'bg-slate-100 dark:bg-slate-800 hover:bg-emerald-600 hover:text-white'
                }`}
              >
                {char}
              </button>
            );
          })}
        </div>

      </div>

      {/* Word Cards List Container */}
      <div className="flex-1 smooth-scroll p-3 space-y-2 pb-28">
        {filteredWords.length === 0 ? (
          <div className="p-10 text-center text-slate-400 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 mx-auto flex items-center justify-center text-slate-400">
              <Search className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-700 dark:text-slate-200">No words match your filters</h4>
              <p className="text-xs text-slate-400 mt-0.5">Try clearing the search query or changing your filter criteria.</p>
            </div>
            <button
              onClick={handleResetAllFilters}
              className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-sm hover:bg-emerald-700 active:scale-95 transition-all"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          filteredWords.map((item) => {
            const status = getStatus(item.word);
            const isHot = EXAM_HOT_SET.has(item.word);
            const isSaved = savedWords.includes(item.word);

            let statusBadge = null;
            if (status === 'mastered') {
              statusBadge = (
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  ✓ Known
                </span>
              );
            } else if (status === 'revise') {
              statusBadge = (
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                  ⚡ Revise
                </span>
              );
            } else if (status === 'learn') {
              statusBadge = (
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
                  🎯 Learn
                </span>
              );
            }

            return (
              <div
                key={item.word}
                onClick={() => onOpenWordDetail(item)}
                className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-2xl p-3 shadow-sm hover:border-emerald-400 dark:hover:border-emerald-600 flex items-center justify-between cursor-pointer active:scale-[0.99] transition-all group"
              >
                <div className="min-w-0 pr-2 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-black text-sm text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                      {item.word}
                    </span>
                    <span className="text-[10px] font-bold text-slate-400 font-mono uppercase">
                      {item.pos.slice(0, 3)}
                    </span>
                    {isHot && (
                      <span className="text-[9px] font-extrabold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/80 px-1.5 py-0.2 rounded border border-amber-200 dark:border-amber-800">
                        PRIORITY
                      </span>
                    )}
                    {statusBadge}
                  </div>

                  <div className="text-xs font-bengali font-bold text-emerald-800 dark:text-emerald-300 truncate mt-0.5">
                    {item.bengali.split('(')[0]}
                  </div>

                  <div className="text-[11px] text-slate-400 truncate mt-0.5">
                    {item.simpleDef}
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => speakWord(item.word, voiceLang)}
                    className="p-2 rounded-xl text-slate-400 hover:text-emerald-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
                    title="Pronounce word"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onToggleSave(item.word)}
                    className={`p-2 rounded-xl transition-all ${
                      isSaved
                        ? 'text-amber-500 bg-amber-50 dark:bg-amber-950/60'
                        : 'text-slate-300 dark:text-slate-600 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                    title={isSaved ? 'Remove from saved' : 'Save to Bookmarks'}
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-current' : ''}`} />
                  </button>

                  <ChevronRight className="w-4 h-4 text-slate-300 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
