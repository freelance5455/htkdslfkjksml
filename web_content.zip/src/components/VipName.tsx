import React from 'react';

interface VipNameProps {
  name: string;
  vipLevel?: number | string;
  isFounder?: boolean;
  className?: string;
  showBadge?: boolean;
}

export const VipName: React.FC<VipNameProps> = ({
  name,
  vipLevel = 0,
  isFounder = false,
  className = '',
  showBadge = true
}) => {
  const numericVip = typeof vipLevel === 'number' ? vipLevel : parseInt(String(vipLevel || '0'), 10) || 0;
  const v = isFounder ? Math.max(numericVip, 20) : numericVip;

  const getStyle = (): React.CSSProperties => {
    if (v === 1) return { color: '#cd7f32', fontWeight: 800, textShadow: '0 0 6px rgba(205, 127, 50, 0.4)' };
    if (v === 2) return { color: '#1E90FF', fontWeight: 800, textShadow: '0 0 6px rgba(30, 144, 255, 0.4)' };
    if (v === 3) return { color: '#DC143C', fontWeight: 800, textShadow: '0 0 6px rgba(220, 20, 60, 0.4)' };
    if (v === 4) return { color: '#2ecc71', fontWeight: 800, textShadow: '0 0 6px rgba(46, 204, 113, 0.4)' };
    return { fontWeight: 700 };
  };

  const isRainbow = v >= 5;

  return (
    <span className={`inline-flex items-center gap-1.5 flex-wrap ${className}`}>
      {isRainbow ? (
        <span className="rainbow-name">{name}</span>
      ) : (
        <span style={getStyle()}>{name}</span>
      )}

      {showBadge && v > 0 && (
        <span className="vip-badge-style">
          {v >= 20 ? '👑 VIP 20' : `⭐ VIP ${v}`}
        </span>
      )}
    </span>
  );
};
