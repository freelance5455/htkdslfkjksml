import React from 'react';
import { X, CheckCircle, ShieldCheck, Zap, Wallet, Users } from 'lucide-react';
import { triggerHaptic } from '../utils/audio';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
            </div>
            <h2 className="text-base font-extrabold text-white font-display">
              How Tap Tap Cash Works
            </h2>
          </div>
          <button
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3 text-xs text-slate-300">
          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-1">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <Zap className="w-3.5 h-3.5" />
              <span>1. Tap & Mine Coins</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Tap the central gold coin on mobile screen with multiple fingers. Upgrade miners in Boost tab to generate passive income even when app is closed.
            </p>
          </div>

          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-1">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <Wallet className="w-3.5 h-3.5" />
              <span>2. Convert to Real Cash (PKR)</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Exchange rate is simple: <strong className="text-white">100 Coins = 1 PKR</strong>. For example, 5,000 Coins = Rs. 50.
            </p>
          </div>

          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-1">
            <div className="flex items-center gap-2 text-cyan-400 font-bold">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>3. Easypaisa & JazzCash Payouts</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Provide your 11-digit active mobile number and account title. Withdrawals are processed instantly with 0% transaction deduction.
            </p>
          </div>

          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-1">
            <div className="flex items-center gap-2 text-purple-400 font-bold">
              <Users className="w-3.5 h-3.5" />
              <span>4. Referral Multiplier</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Invite friends to get 5,000 Coins (Rs. 50) instantly plus 10% commission on every tap they mine forever.
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            triggerHaptic('light');
            onClose();
          }}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-xs hover:brightness-105 transition-all shadow-md"
        >
          Got It, Let's Play!
        </button>
      </div>
    </div>
  );
};
