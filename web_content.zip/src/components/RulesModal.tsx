import React from 'react';
import { X } from 'lucide-react';

interface RulesModalProps {
  open: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ open, onClose }) => {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="rules-title"
    >
      <div
        className="w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-2xl bg-stone-900 border border-white/15 p-6 text-stone-100 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <h2 id="rules-title" className="font-display text-2xl font-bold text-white">
            Cara Main UNO Flip
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 rounded-lg flex items-center justify-center text-stone-400 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Tutup panduan"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-5 text-sm leading-relaxed text-stone-300">
          <p>
            Setiap kartu di UNO Flip memiliki <strong className="text-white">dua sisi</strong>:
            <span className="text-emerald-300 font-semibold"> Sisi Terang (Light)</span> dan{' '}
            <span className="text-pink-300 font-semibold">Sisi Gelap (Dark)</span>. Permainan
            selalu dimulai di Sisi Terang. Saat kartu <strong className="text-amber-300">FLIP</strong> dimainkan,
            seluruh tumpukan kartu dan tangan semua pemain langsung dibalik!
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="rounded-xl bg-stone-800/70 border border-emerald-500/25 p-4 space-y-2.5">
              <h3 className="font-display font-bold text-base text-emerald-300">
                Kartu Sisi Terang
              </h3>
              <ul className="space-y-1.5 text-xs sm:text-sm">
                <li><strong className="text-white">Ambil +1:</strong> Pemain berikutnya tarik 1 kartu &amp; dilewati.</li>
                <li><strong className="text-white">Skip:</strong> Pemain berikutnya kehilangan giliran.</li>
                <li><strong className="text-white">Putar Balik:</strong> Arah giliran berbalik (2 pemain: main lagi).</li>
                <li><strong className="text-white">Wild +2:</strong> Pilih warna baru, lawan tarik 2 kartu &amp; dilewati.</li>
                <li><strong className="text-amber-300">FLIP:</strong> Balik meja ke Sisi Gelap!</li>
              </ul>
            </div>

            <div className="rounded-xl bg-stone-950/80 border border-pink-500/30 p-4 space-y-2.5">
              <h3 className="font-display font-bold text-base text-pink-300">
                Kartu Sisi Gelap
              </h3>
              <ul className="space-y-1.5 text-xs sm:text-sm">
                <li><strong className="text-white">Ambil +5:</strong> Pemain berikutnya tarik 5 kartu &amp; dilewati!</li>
                <li><strong className="text-white">Skip Semua:</strong> Semua lawan dilewati, kamu langsung main lagi!</li>
                <li><strong className="text-white">Putar Balik:</strong> Arah giliran berbalik.</li>
                <li><strong className="text-white">Wild +Warna:</strong> Pilih warna gelap; lawan tarik kartu terus hingga mendapat warna tersebut.</li>
                <li><strong className="text-amber-300">FLIP:</strong> Balik meja kembali ke Sisi Terang!</li>
              </ul>
            </div>
          </div>

          <div className="rounded-xl bg-stone-800/50 border border-white/10 p-4 space-y-1.5">
            <h3 className="font-display font-bold text-sm text-white">Aturan UNO &amp; Tangkap</h3>
            <p className="text-xs sm:text-sm text-stone-300">
              Saat kartu kamu tersisa 2 dan hendak memainkan 1 kartu (atau tepat setelah tersisa 1 kartu),
              segera tekan tombol <strong className="text-amber-300">UNO!</strong> (atau tombol <kbd className="px-1.5 py-0.5 bg-stone-700 rounded text-xs">U</kbd>).
              Jika lupa sebelum pemain lain bertindak, lawan bisa menekan <strong className="text-rose-300">Tangkap UNO</strong> dan kamu kena penalti +2 kartu!
            </p>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-lg bg-amber-400 text-stone-950 font-semibold text-sm hover:bg-amber-300 transition-colors whitespace-nowrap"
          >
            Mengerti, Ayo Main
          </button>
        </div>
      </div>
    </div>
  );
};
