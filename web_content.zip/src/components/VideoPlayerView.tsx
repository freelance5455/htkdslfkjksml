import React, { useRef, useState, useEffect } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  FolderOpen,
  Languages,
  Subtitles,
  Mic,
  FileVideo,
  Settings,
  Sparkles,
  Volume1,
  RotateCcw,
} from 'lucide-react';
import { SubtitleCue, AudioTrackMode, ModularPluginConfig } from '../types';
import { formatTime } from '../services/subtitleParser';
import { hindiTtsService, TtsVoiceInfo } from '../services/ttsService';
import { SAMPLE_VIDEOS } from '../services/sampleData';

interface VideoPlayerViewProps {
  videoSrc: string;
  videoName: string;
  subtitles: SubtitleCue[];
  audioMode: AudioTrackMode;
  setAudioMode: (mode: AudioTrackMode) => void;
  onSelectVideo: (file: File) => void;
  onOpenTranslateModal: () => void;
  onSelectSampleVideo: (sampleUrl: string, sampleTitle: string) => void;
  pluginConfig: ModularPluginConfig;
  setPluginConfig: React.Dispatch<React.SetStateAction<ModularPluginConfig>>;
}

export const VideoPlayerView: React.FC<VideoPlayerViewProps> = ({
  videoSrc,
  videoName,
  subtitles,
  audioMode,
  setAudioMode,
  onSelectVideo,
  onOpenTranslateModal,
  onSelectSampleVideo,
  pluginConfig,
  setPluginConfig,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolume] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [activeCue, setActiveCue] = useState<SubtitleCue | null>(null);
  const [lastSpokenCueId, setLastSpokenCueId] = useState<number>(-1);
  const [isTtsSpeaking, setIsTtsSpeaking] = useState<boolean>(false);
  const [currentSpokenText, setCurrentSpokenText] = useState<string>('');
  const [availableVoices, setAvailableVoices] = useState<TtsVoiceInfo[]>([]);
  const [showSettingsDrawer, setShowSettingsDrawer] = useState<boolean>(false);
  const [subtitleSize, setSubtitleSize] = useState<'sm' | 'md' | 'lg'>('md');

  // Load available TTS voices on mount
  useEffect(() => {
    hindiTtsService.getAvailableVoices().then((voices) => {
      setAvailableVoices(voices);
      if (!pluginConfig.selectedVoice && voices.length > 0) {
        const hindi = voices.find((v) => v.isHindi);
        if (hindi) {
          setPluginConfig((prev) => ({ ...prev, selectedVoice: hindi.name }));
        }
      }
    });

    hindiTtsService.setOnStateChange((speaking, text) => {
      setIsTtsSpeaking(speaking);
      setCurrentSpokenText(text);

      // Handle audio ducking: when TTS speaks, lower video volume
      if (videoRef.current && audioMode === 'hindi_dubbed') {
        if (speaking) {
          videoRef.current.volume = pluginConfig.duckOriginalAudio ? pluginConfig.duckingLevel : 0;
        } else {
          videoRef.current.volume = isMuted ? 0 : volume;
        }
      }
    });

    return () => {
      hindiTtsService.stop();
    };
  }, [audioMode, volume, isMuted, pluginConfig.duckOriginalAudio, pluginConfig.duckingLevel]);

  // Adjust video volume whenever audioMode changes
  useEffect(() => {
    if (!videoRef.current) return;
    if (audioMode === 'original' || audioMode === 'subtitles') {
      videoRef.current.volume = isMuted ? 0 : volume;
      hindiTtsService.stop();
    } else if (audioMode === 'hindi_dubbed') {
      // If currently speaking, duck; otherwise full
      if (isTtsSpeaking) {
        videoRef.current.volume = pluginConfig.duckOriginalAudio ? pluginConfig.duckingLevel : 0;
      } else {
        videoRef.current.volume = isMuted ? 0 : volume;
      }
    }
  }, [audioMode, volume, isMuted, isTtsSpeaking, pluginConfig.duckOriginalAudio, pluginConfig.duckingLevel]);

  // Handle Play/Pause
  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
      hindiTtsService.stop();
    }
  };

  // Video time update handler (Subtitle matching and TTS trigger)
  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const time = videoRef.current.currentTime;
    setCurrentTime(time);

    // Match subtitle cue
    const matched = subtitles.find((cue) => time >= cue.startTime && time <= cue.endTime);
    setActiveCue(matched || null);

    // If Hindi Dubbed Audio is active, speak the new cue
    if (audioMode === 'hindi_dubbed' && matched) {
      if (matched.id !== lastSpokenCueId) {
        setLastSpokenCueId(matched.id);
        hindiTtsService.speakHindiText(matched.hindiText, {
          rate: pluginConfig.speechRate,
          pitch: pluginConfig.speechPitch,
          voiceName: pluginConfig.selectedVoice,
        });
      }
    } else if (!matched && lastSpokenCueId !== -1) {
      // In gap between cues, reset spoken tracker
      setLastSpokenCueId(-1);
    }
  };

  // Seek bar
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const target = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = target;
      setCurrentTime(target);
      hindiTtsService.stop();
      setLastSpokenCueId(-1);
    }
  };

  // Jump to specific cue
  const jumpToCue = (cue: SubtitleCue) => {
    if (videoRef.current) {
      videoRef.current.currentTime = cue.startTime;
      setCurrentTime(cue.startTime);
      if (videoRef.current.paused) {
        videoRef.current.play();
        setIsPlaying(true);
      }
      setLastSpokenCueId(-1);
    }
  };

  // Handle Local File Selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onSelectVideo(file);
      setIsPlaying(false);
      setLastSpokenCueId(-1);
      hindiTtsService.stop();
    }
  };

  // Fullscreen toggle
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Main Video Screen with ExoPlayer styling */}
      <div
        ref={containerRef}
        className="relative group rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-2xl flex flex-col justify-end"
      >
        {/* Video Element */}
        <div className="relative w-full aspect-video bg-black flex items-center justify-center">
          <video
            ref={videoRef}
            src={videoSrc}
            playsInline
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={() => {
              if (videoRef.current) setDuration(videoRef.current.duration);
            }}
            onEnded={() => {
              setIsPlaying(false);
              hindiTtsService.stop();
            }}
            onClick={togglePlay}
            className="w-full h-full object-contain cursor-pointer"
          />

          {/* Subtitle Overlay (Shown when audioMode is subtitles or hindi_dubbed) */}
          {audioMode !== 'original' && activeCue && (
            <div className="absolute bottom-16 left-4 right-4 flex justify-center pointer-events-none transition-all">
              <div
                className={`max-w-[92%] px-4 py-2 bg-slate-950/85 backdrop-blur-sm border border-slate-700/60 rounded-xl text-center shadow-lg transition-all ${
                  subtitleSize === 'sm'
                    ? 'text-sm'
                    : subtitleSize === 'lg'
                    ? 'text-xl font-bold'
                    : 'text-base font-semibold'
                }`}
              >
                <p className="font-hindi text-yellow-300 drop-shadow-md leading-relaxed">
                  {activeCue.hindiText}
                </p>
                {activeCue.originalText && (
                  <p className="text-xs text-slate-300/80 mt-0.5 tracking-tight">
                    {activeCue.originalText}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Live TTS Speaking Wave Indicator */}
          {audioMode === 'hindi_dubbed' && isTtsSpeaking && (
            <div className="absolute top-4 left-4 z-20 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-orange-600/90 backdrop-blur-md text-white text-xs font-semibold shadow-md border border-orange-400/40 animate-pulse">
              <Mic className="w-3.5 h-3.5 text-white" />
              <span>हिंदी डबिंग चालू (TTS Dubbing Active)</span>
              <div className="flex items-center gap-0.5 h-3">
                <span className="w-1 bg-white rounded-full animate-bounce h-2" />
                <span className="w-1 bg-white rounded-full animate-bounce h-3" />
                <span className="w-1 bg-white rounded-full animate-bounce h-1.5" />
              </div>
            </div>
          )}
        </div>

        {/* Video Controls Bar (ExoPlayer Jetpack Compose styling) */}
        <div className="p-3 bg-gradient-to-t from-slate-950 via-slate-950/95 to-slate-950/40 border-t border-slate-800/80 flex flex-col gap-2">
          {/* Seek Bar */}
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-slate-400 w-12 text-right">
              {formatTime(currentTime)}
            </span>
            <input
              type="range"
              min={0}
              max={duration || 100}
              step={0.1}
              value={currentTime}
              onChange={handleSeek}
              className="flex-1 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
            />
            <span className="text-xs font-mono text-slate-400 w-12">
              {formatTime(duration)}
            </span>
          </div>

          {/* Primary Controls Row */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <button
                onClick={togglePlay}
                title={isPlaying ? 'विराम (Pause)' : 'चलाएं (Play)'}
                className="w-9 h-9 rounded-lg bg-orange-600 hover:bg-orange-500 text-white flex items-center justify-center transition-transform active:scale-95 shadow-sm"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
              </button>

              <button
                onClick={() => {
                  if (videoRef.current) {
                    videoRef.current.currentTime = 0;
                    setCurrentTime(0);
                    setLastSpokenCueId(-1);
                    hindiTtsService.stop();
                  }
                }}
                title="प्रारंभ से पुनः चलाएं (Restart)"
                className="w-9 h-9 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 flex items-center justify-center transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {/* Volume / Ducking */}
              <div className="flex items-center gap-1 text-slate-400 pl-1">
                <button
                  onClick={() => {
                    const next = !isMuted;
                    setIsMuted(next);
                    if (videoRef.current) videoRef.current.muted = next;
                  }}
                  className="p-1 hover:text-white transition-colors"
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-4 h-4 text-red-400" />
                  ) : volume < 0.5 ? (
                    <Volume1 className="w-4 h-4" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={isMuted ? 0 : volume}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setVolume(val);
                    setIsMuted(false);
                    if (videoRef.current) {
                      videoRef.current.volume = val;
                      videoRef.current.muted = false;
                    }
                  }}
                  className="w-16 h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-slate-300"
                />
              </div>

              {/* Current Active Mode Badge */}
              <div className="hidden sm:flex items-center gap-1.5 ml-2 text-xs px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-slate-300">
                <span className="text-slate-500">ट्रैक:</span>
                <span className="font-semibold text-orange-400">
                  {audioMode === 'original' && 'मूल ऑडियो'}
                  {audioMode === 'subtitles' && 'हिंदी उपशीर्षक'}
                  {audioMode === 'hindi_dubbed' && 'हिंदी डब ऑडियो'}
                </span>
              </div>
            </div>

            {/* Right Controls */}
            <div className="flex items-center gap-2">
              {/* Playback speed */}
              <select
                value={playbackSpeed}
                onChange={(e) => {
                  const spd = parseFloat(e.target.value);
                  setPlaybackSpeed(spd);
                  if (videoRef.current) videoRef.current.playbackRate = spd;
                }}
                className="bg-slate-900 border border-slate-800 text-slate-300 text-xs rounded-lg px-2 py-1.5 focus:outline-none focus:border-orange-500"
              >
                <option value={0.75}>0.75x</option>
                <option value={1}>1.0x (सामान्य)</option>
                <option value={1.25}>1.25x</option>
                <option value={1.5}>1.5x</option>
              </select>

              {/* Subtitle size */}
              <button
                onClick={() => {
                  setSubtitleSize((prev) => (prev === 'sm' ? 'md' : prev === 'md' ? 'lg' : 'sm'));
                }}
                title="उपशीर्षक आकार बदलें"
                className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold rounded-lg transition-colors"
              >
                क {subtitleSize.toUpperCase()}
              </button>

              {/* TTS Voice Settings */}
              <button
                onClick={() => setShowSettingsDrawer(!showSettingsDrawer)}
                title="TTS आवाज सेटिंग्स"
                className={`p-2 rounded-lg border transition-colors ${
                  showSettingsDrawer
                    ? 'bg-orange-500/10 border-orange-500/50 text-orange-400'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <Settings className="w-4 h-4" />
              </button>

              {/* Fullscreen */}
              <button
                onClick={toggleFullscreen}
                className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
              >
                <Maximize className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* TTS Settings Drawer */}
      {showSettingsDrawer && (
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2">
              <Mic className="w-4 h-4 text-orange-400" />
              <span>एंड्रॉइड / वेब टेक्स्ट-टू-स्पीच सेटिंग्स (Hindi TTS Settings)</span>
            </h4>
            <span className="text-xs text-slate-400">
              {availableVoices.filter((v) => v.isHindi).length} हिंदी आवाज़ें उपलब्ध
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-slate-400 mb-1 block">हिंदी आवाज़ (Voice):</label>
              <select
                value={pluginConfig.selectedVoice}
                onChange={(e) => setPluginConfig((prev) => ({ ...prev, selectedVoice: e.target.value }))}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg p-2"
              >
                {availableVoices.map((v) => (
                  <option key={v.name} value={v.name}>
                    {v.isHindi ? '🇮🇳 ' : ''}
                    {v.name} ({v.lang})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span>बोलने की गति (Speech Rate):</span>
                <span className="font-mono text-orange-400">{pluginConfig.speechRate}x</span>
              </div>
              <input
                type="range"
                min={0.7}
                max={1.5}
                step={0.1}
                value={pluginConfig.speechRate}
                onChange={(e) =>
                  setPluginConfig((prev) => ({ ...prev, speechRate: parseFloat(e.target.value) }))
                }
                className="w-full h-1.5 bg-slate-800 rounded accent-orange-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span>मूल ऑडियो डकिंग (Audio Ducking):</span>
                <span className="font-mono text-orange-400">
                  {Math.round(pluginConfig.duckingLevel * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={0.3}
                step={0.05}
                value={pluginConfig.duckingLevel}
                onChange={(e) =>
                  setPluginConfig((prev) => ({ ...prev, duckingLevel: parseFloat(e.target.value) }))
                }
                className="w-full h-1.5 bg-slate-800 rounded accent-orange-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* Clean Hindi Action Buttons (Strictly per user requirements) */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">
            मुख्य क्रियाएं (Primary Actions):
          </span>
          <span className="text-xs text-slate-500 truncate max-w-[200px]">{videoName}</span>
        </div>

        {/* 5 Specific Buttons demanded by the user prompt */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {/* Button 1: Select Video */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-semibold text-xs transition-colors shadow-sm"
          >
            <FolderOpen className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">वीडियो चुनें</span>
          </button>

          {/* Button 2: Translate to Hindi */}
          <button
            onClick={onOpenTranslateModal}
            className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-500 active:bg-orange-700 text-white font-semibold text-xs transition-colors shadow-sm"
          >
            <Languages className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">हिंदी में अनुवाद करें</span>
          </button>

          {/* Button 3: Hindi Subtitles */}
          <button
            onClick={() => setAudioMode('subtitles')}
            className={`flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border font-semibold text-xs transition-colors ${
              audioMode === 'subtitles'
                ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/60 shadow-sm'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <Subtitles className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">हिंदी उपशीर्षक</span>
          </button>

          {/* Button 4: Hindi Dubbed Audio */}
          <button
            onClick={() => setAudioMode('hindi_dubbed')}
            className={`flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border font-semibold text-xs transition-colors ${
              audioMode === 'hindi_dubbed'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/60 shadow-sm ring-1 ring-emerald-500/40'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <Mic className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">हिंदी डब ऑडियो</span>
          </button>

          {/* Button 5: Original Audio */}
          <button
            onClick={() => setAudioMode('original')}
            className={`col-span-2 sm:col-span-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border font-semibold text-xs transition-colors ${
              audioMode === 'original'
                ? 'bg-purple-500/20 text-purple-300 border-purple-500/60 shadow-sm'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <Volume2 className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">मूल ऑडियो</span>
          </button>
        </div>
      </div>

      {/* Quick Sample Video Loader (for immediate testing without upload) */}
      <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400">
        <FileVideo className="w-4 h-4 text-orange-400 shrink-0" />
        <span className="whitespace-nowrap font-medium text-slate-300">तुरंत परीक्षण करें (Quick Test):</span>
        <div className="flex items-center gap-2 overflow-x-auto py-0.5">
          {SAMPLE_VIDEOS.map((sample) => (
            <button
              key={sample.id}
              onClick={() => onSelectSampleVideo(sample.url, sample.title)}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors whitespace-nowrap text-xs border border-slate-700/60"
            >
              {sample.title}
            </button>
          ))}
        </div>
      </div>

      {/* Subtitles Cue Bar with Interactive Jump */}
      <div className="flex flex-col gap-2 p-4 rounded-xl bg-slate-900/40 border border-slate-800">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-semibold text-slate-300 flex items-center gap-2">
            <Subtitles className="w-3.5 h-3.5 text-orange-400" />
            <span>समकालिक उपशीर्षक सूची ({subtitles.length} खंड) - किसी भी खंड पर कूदें:</span>
          </h4>
          <span className="text-xs text-slate-500">
            {activeCue ? `सक्रिय: ${formatTime(activeCue.startTime)}s` : 'कोई सक्रिय नहीं'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
          {subtitles.map((cue) => {
            const isActive = activeCue?.id === cue.id;
            return (
              <div
                key={cue.id}
                onClick={() => jumpToCue(cue)}
                className={`p-2.5 rounded-lg border text-left cursor-pointer transition-all flex items-start justify-between gap-2 ${
                  isActive
                    ? 'bg-orange-950/40 border-orange-500/70 text-orange-100 shadow-md ring-1 ring-orange-500/30'
                    : 'bg-slate-900/80 border-slate-800/80 hover:bg-slate-800/80 text-slate-300'
                }`}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-orange-400 font-semibold">
                      {formatTime(cue.startTime)} - {formatTime(cue.endTime)}
                    </span>
                    {cue.romanizedHindi && (
                      <span className="text-[10px] text-slate-500 truncate">
                        {cue.romanizedHindi}
                      </span>
                    )}
                  </div>
                  <p className="font-hindi text-xs font-medium text-slate-100 line-clamp-2">
                    {cue.hindiText}
                  </p>
                  {cue.originalText && (
                    <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1 italic">
                      {cue.originalText}
                    </p>
                  )}
                </div>

                <button
                  type="button"
                  title="इस खंड को बोलकर सुनें"
                  onClick={(e) => {
                    e.stopPropagation();
                    hindiTtsService.speakHindiText(cue.hindiText, {
                      rate: pluginConfig.speechRate,
                      pitch: pluginConfig.speechPitch,
                      voiceName: pluginConfig.selectedVoice,
                    });
                  }}
                  className="p-1.5 rounded-md bg-slate-800 hover:bg-orange-600 text-slate-300 hover:text-white transition-colors shrink-0"
                >
                  <Play className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
