import React, { useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { audioEngine } from '../lib/audioEngine';

interface VerticalVolumeSliderProps {
  volume: number;
  isMuted: boolean;
  onVolumeChange: (vol: number) => void;
  onToggleMute: () => void;
}

export const VerticalVolumeSlider: React.FC<VerticalVolumeSliderProps> = ({
  volume,
  isMuted,
  onVolumeChange,
  onToggleMute,
}) => {
  const [showSlider, setShowSlider] = useState(false);

  return (
    <div
      className="relative flex items-center"
      onMouseEnter={() => setShowSlider(true)}
      onMouseLeave={() => setShowSlider(false)}
    >
      <button
        onClick={onToggleMute}
        className="p-2 rounded-xl text-slate-400 hover:text-amber-300 transition-colors"
        title="Volume & Mute"
      >
        {isMuted || volume === 0 ? (
          <VolumeX className="w-4 h-4 text-rose-400" />
        ) : (
          <Volume2 className="w-4 h-4 text-amber-400" />
        )}
      </button>

      {showSlider && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 p-3 bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl flex flex-col items-center space-y-2 animate-fadeIn z-50">
          <span className="text-[10px] font-mono text-amber-300 font-bold">
            {Math.round((isMuted ? 0 : volume) * 100)}%
          </span>
          <div className="h-32 w-6 flex items-center justify-center py-1">
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={isMuted ? 0 : volume}
              onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
              className="h-28 w-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400 [writing-mode:vertical-lr] [direction:rtl]"
            />
          </div>
        </div>
      )}
    </div>
  );
};
