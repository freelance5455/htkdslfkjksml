import { lazy, Suspense, useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Activity,
  ArrowLeft,
  ArrowUpRight,
  AudioLines,
  Check,
  ChevronRight,
  CircleHelp,
  Columns2,
  Compass,
  Footprints,
  Glasses,
  Headphones,
  Heart,
  Leaf,
  Maximize,
  Menu,
  Minimize,
  Monitor,
  Pause,
  Play,
  RotateCcw,
  Settings2,
  SlidersHorizontal,
  Smartphone,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { NatureAudio } from '../audio/NatureAudio';
import { loadSettings, worlds } from '../data/worlds';
import type { Settings, WorldId } from '../data/worlds';
import { useVibrationDetection } from '../hooks/useVibrationDetection';
import { Brand, Dialog, LandscapeDrawing, LeafMark, Waveform } from './Interface';
import { GuidePanel, SettingsPanel, SoundPanel } from './Panels';
import { VRCardboardMask } from './VRCardboardMask';

const Scene3D = lazy(() => import('./Scene3D'));
type Page = 'explore' | 'sounds' | 'settings' | 'guide';
type Modal = 'guide' | 'settings' | 'sensor' | null;
const pageNames: Record<Page, string> = {
  explore: 'Explore',
  sounds: 'Nature Sounds',
  settings: 'Settings',
  guide: 'Guide',
};
const fadeIn = { initial: { opacity: 0, y: 12 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: -5 } };

async function requestLookPermission(): Promise<boolean> {
  if (!('DeviceOrientationEvent' in window) || !window.isSecureContext) return false;
  const Orientation = window.DeviceOrientationEvent as typeof DeviceOrientationEvent & { requestPermission?: () => Promise<string> };
  try {
    return Orientation.requestPermission ? await Orientation.requestPermission() === 'granted' : true;
  } catch {
    return false;
  }
}

function loadFavorites(): WorldId[] {
  try {
    const saved = JSON.parse(localStorage.getItem('rimba-favorites') || '[]') as unknown;
    return Array.isArray(saved) ? saved.filter((id): id is WorldId => worlds.some(world => world.id === id)) : [];
  } catch { return []; }
}

function duration(seconds: number) {
  return `${Math.floor(seconds / 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;
}

export default function VRGame() {
  const [page, setPage] = useState<Page>('explore');
  const [selectedId, setSelectedId] = useState<WorldId>('summit');
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [favorites, setFavorites] = useState<WorldId[]>(loadFavorites);
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [paused, setPaused] = useState(false);
  const [modal, setModal] = useState<Modal>(null);
  const [sceneReady, setSceneReady] = useState(false);
  const [orientationAllowed, setOrientationAllowed] = useState(false);
  const [manualForward, setManualForward] = useState(false);
  const [distance, setDistance] = useState(0);
  const [walking, setWalking] = useState(false);
  const [resetKey, setResetKey] = useState(0);
  const [audioPlaying, setAudioPlaying] = useState(false);
  const [audioSeconds, setAudioSeconds] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [toast, setToast] = useState('');
  const audio = useRef<NatureAudio | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const sensor = useVibrationDetection(settings.sensitivity);
  const selectedWorld = worlds.find(world => world.id === selectedId) ?? worlds[0];
  const gameSuspended = paused || modal !== null;

  useEffect(() => {
    audio.current = new NatureAudio();
    return () => { audio.current?.dispose(); audio.current = null; };
  }, []);
  useEffect(() => {
    try { localStorage.setItem('rimba-settings', JSON.stringify(settings)); } catch { /* Storage disabled */ }
    audio.current?.update(settings);
  }, [settings]);
  useEffect(() => {
    try { localStorage.setItem('rimba-favorites', JSON.stringify(favorites)); } catch { /* Favorites retained */ }
  }, [favorites]);
  useEffect(() => () => { if (toastTimer.current) clearTimeout(toastTimer.current); }, []);

  const notify = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 3500);
  }, []);

  const startAudio = useCallback(async () => {
    try {
      if (!audio.current) audio.current = new NatureAudio();
      await audio.current.start(settings);
      setAudioPlaying(true);
    } catch {
      setAudioPlaying(false);
      notify('Audio cannot be played yet. Check your browser sound permissions.');
    }
  }, [settings, notify]);

  const toggleAudio = () => {
    if (audioPlaying) { audio.current?.pause(); setAudioPlaying(false); }
    else void startAudio();
  };

  useEffect(() => {
    if (!playing || !audioPlaying) return;
    if (gameSuspended) audio.current?.pause();
    else void audio.current?.start(settings).catch(() => setAudioPlaying(false));
  }, [playing, gameSuspended, audioPlaying, settings]);

  useEffect(() => {
    if (!audioPlaying || (playing && gameSuspended)) return;
    const timer = setInterval(() => setAudioSeconds(value => value + 1), 1000);
    return () => clearInterval(timer);
  }, [audioPlaying, playing, gameSuspended]);

  const updateSettings = (patch: Partial<Settings>) => {
    setSettings(previous => ({ ...previous, ...patch }));
    if (playing && patch.motionEnabled !== undefined) {
      if (patch.motionEnabled) void sensor.requestPermission();
      else sensor.stop();
    }
    if (playing && patch.headTracking) void requestLookPermission().then(setOrientationAllowed);
  };

  const navigate = (next: Page) => {
    setPage(next);
    setMobileMenu(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const startGame = () => {
    // Permission requests must originate from this click gesture on mobile browsers
    if (settings.motionEnabled) void sensor.requestPermission();
    if (settings.headTracking) void requestLookPermission().then(setOrientationAllowed);
    void startAudio();
    setSceneReady(false);
    setDistance(0);
    setWalking(false);
    setManualForward(false);
    setPaused(false);
    setModal(null);
    setPlaying(true);
  };

  const leaveGame = () => {
    sensor.stop();
    audio.current?.pause();
    setAudioPlaying(false);
    setPlaying(false);
    setPaused(false);
    setModal(null);
    setManualForward(false);
    if (document.fullscreenElement) void document.exitFullscreen().catch(() => undefined);
  };

  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else {
        await document.documentElement.requestFullscreen();
        const orientation = screen.orientation as ScreenOrientation & { lock?: (mode: string) => Promise<void> };
        void orientation.lock?.('landscape').catch(() => undefined);
      }
    } catch { notify('Fullscreen is not supported on this browser. Rotate your phone manually.'); }
  };

  useEffect(() => {
    const handleFullscreen = () => setFullscreen(Boolean(document.fullscreenElement));
    const handleVisibility = () => { if (document.hidden && playing) { setPaused(true); setManualForward(false); } };
    const handleBlur = () => setManualForward(false);
    const handleKey = (event: KeyboardEvent) => {
      if (event.code !== 'Escape' || modal || event.defaultPrevented) return;
      if (playing) { setPaused(value => !value); setManualForward(false); }
      else setMobileMenu(false);
    };
    document.addEventListener('fullscreenchange', handleFullscreen);
    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('blur', handleBlur);
    window.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreen);
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('blur', handleBlur);
      window.removeEventListener('keydown', handleKey);
    };
  }, [playing, modal]);

  const onProgress = useCallback((value: number, moving: boolean) => { setDistance(value); setWalking(moving); }, []);
  const onStep = useCallback(() => audio.current?.footstep(), []);
  const onReady = useCallback(() => setSceneReady(true), []);

  const toggleFavorite = (id: WorldId) => {
    setFavorites(previous => previous.includes(id) ? previous.filter(value => value !== id) : [...previous, id]);
  };

  const renderModal = () => {
    if (!modal) return null;
    return (
      <Dialog
        title={modal === 'guide' ? 'Visitor Guide' : modal === 'settings' ? 'Expedition Settings' : 'Movement Sensor'}
        onClose={() => setModal(null)}
        wide={modal !== 'sensor'}
      >
        {modal === 'guide' && <GuidePanel onStart={startGame} />}
        {modal === 'settings' && (
          <>
            <div className="modal-title">
              <h2>Tailor Your Experience.</h2>
              <p>Adjust visual modes and motion comfort, then return to your peaceful escape.</p>
            </div>
            <SettingsPanel
              settings={settings}
              onChange={updateSettings}
              onReset={() => notify('Settings reset to default options.')}
            />
          </>
        )}
        {modal === 'sensor' && (
          <div className="sensor-panel">
            <Activity size={32} />
            <h2>{sensor.status === 'active' ? 'Motion Sensor Connected' : 'Ready When You Are'}</h2>
            <p>{sensor.debugInfo}</p>
            <div className="sensor-reading">
              <strong>{sensor.magnitude.toFixed(2)}</strong>
              <span>m/s²</span>
              <div className="sensor-meter">
                <span style={{ width: `${Math.min(100, (sensor.magnitude / 6) * 100)}%` }} />
              </div>
            </div>
            <p className="sensor-detail">
              The sensor detects physical movement from walking or stepping in place. If sensors are unavailable, hold the Walk button or use W / Space.
            </p>
            <button
              className="primary-button"
              onClick={() => {
                void sensor.requestPermission();
                notify('Requesting sensor access. Move your phone gently.');
              }}
            >
              Re-activate Sensor <RotateCcw size={16} />
            </button>
          </div>
        )}
      </Dialog>
    );
  };

  const toastElement = (
    <AnimatePresence>
      {toast && (
        <motion.div className="toast" role="status" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}>
          <Check size={17} />
          <span>{toast}</span>
          <button aria-label="Dismiss notification" onClick={() => setToast('')}>
            <X size={15} />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );

  if (playing) {
    return (
      <div className={`game-shell ${settings.displayMode === 'stereo' ? 'stereo-mode' : ''}`}>
        <Suspense fallback={<div className="scene-loading"><Brand light /><p>Opening path to nature...</p></div>}>
          <Scene3D
            world={selectedId}
            settings={settings}
            sensorMoving={sensor.isMovingNow}
            manualForward={manualForward}
            paused={gameSuspended}
            orientationAllowed={orientationAllowed}
            resetKey={resetKey}
            onProgress={onProgress}
            onStep={onStep}
            onReady={onReady}
          />
        </Suspense>
        {!sceneReady && (
          <div className="scene-loading">
            <Brand light />
            <span className="loading-line" />
            <p>Rendering natural scenery...</p>
          </div>
        )}
        {settings.displayMode === 'stereo' && (
          <>
            <div className="stereo-divider" aria-hidden="true" />
            <VRCardboardMask />
          </>
        )}
        <header className="game-header">
          <div className="game-location">
            <button className="game-icon" aria-label="Return to menu" onClick={leaveGame}>
              <ArrowLeft size={20} />
            </button>
            <span>
              <strong>{selectedWorld.name}</strong>
              <small>RIMBA / IMMERSIVE VR</small>
            </span>
          </div>
          <span className="game-wordmark">rimba.</span>
          <div className="game-actions">
            <button
              className="game-icon display-switch"
              aria-label={settings.displayMode === 'stereo' ? 'Switch to Single Screen' : 'Switch to VR Dual View'}
              title={settings.displayMode === 'stereo' ? 'VR Dual Lens active' : 'Single screen active'}
              onClick={() => updateSettings({ displayMode: settings.displayMode === 'stereo' ? 'single' : 'stereo' })}
            >
              {settings.displayMode === 'stereo' ? <Columns2 size={19} /> : <Monitor size={19} />}
            </button>
            <button
              className="game-icon"
              aria-label={audioPlaying ? 'Mute ambient sound' : 'Unmute ambient sound'}
              onClick={toggleAudio}
            >
              {audioPlaying ? <Volume2 size={19} /> : <VolumeX size={19} />}
            </button>
            <button
              className="game-icon"
              aria-label="In-game settings"
              onClick={() => { setManualForward(false); setModal('settings'); }}
            >
              <SlidersHorizontal size={19} />
            </button>
            <button
              className="game-icon fullscreen-button"
              aria-label={fullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
              onClick={() => void toggleFullscreen()}
            >
              {fullscreen ? <Minimize size={19} /> : <Maximize size={19} />}
            </button>
            <button
              className="game-icon"
              aria-label="Pause journey"
              onClick={() => { setPaused(true); setManualForward(false); }}
            >
              <Pause size={19} />
            </button>
          </div>
        </header>

        <div className="portrait-hint">
          <Smartphone size={20} />
          <span>Rotate phone horizontally to landscape for VR goggles.</span>
        </div>

        <footer className="game-footer">
          <div className="game-sensor">
            <button
              onClick={() => setModal('sensor')}
              className={sensor.status === 'active' ? 'sensor-active' : ''}
            >
              <Activity size={17} />
              <span>{settings.motionEnabled && sensor.status === 'active' ? 'Step Motion Active' : 'Manual Controls Ready'}</span>
              <CircleHelp size={13} />
            </button>
            <p>Drag to look around. Press W / Space to walk forward.</p>
          </div>
          <button
            className={`walk-button ${manualForward ? 'is-walking' : ''}`}
            disabled={gameSuspended}
            onPointerDown={event => {
              event.currentTarget.setPointerCapture(event.pointerId);
              setManualForward(true);
            }}
            onPointerUp={() => setManualForward(false)}
            onPointerCancel={() => setManualForward(false)}
            onLostPointerCapture={() => setManualForward(false)}
            onKeyDown={event => {
              if (event.code === 'Space' || event.code === 'Enter') {
                event.preventDefault();
                setManualForward(true);
              }
            }}
            onKeyUp={() => setManualForward(false)}
            onBlur={() => setManualForward(false)}
          >
            <Footprints size={18} />
            {walking ? 'Walking forward...' : 'Hold to Walk'}
          </button>
          <div className="game-distance">
            <span className={`walking-dot ${walking ? 'active' : ''}`} />
            <strong data-testid="distance">{distance.toFixed(1)} <small>m</small></strong>
            <button
              aria-label="Reset to starting viewpoint"
              title="Reset to starting viewpoint"
              onClick={() => {
                setResetKey(value => value + 1);
                setDistance(0);
                notify('Returned to starting point. Enjoy another path.');
              }}
            >
              <RotateCcw size={17} />
            </button>
          </div>
        </footer>

        <AnimatePresence>
          {paused && (
            <motion.div className="pause-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <LeafMark size={36} />
              <span className="eyebrow">NO NEED TO HURRY</span>
              <h1>Pause and Breathe.</h1>
              <p>The natural world will be right here when you return.</p>
              <button className="primary-button light" onClick={() => setPaused(false)}>
                <Play size={16} fill="currentColor" />
                Resume Journey
              </button>
              <button className="pause-back" onClick={leaveGame}>
                Back to Menu <ArrowUpRight size={15} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
        {renderModal()}
        {toastElement}
      </div>
    );
  }

  return (
    <div className="app-shell">
      {mobileMenu && (
        <button className="sidebar-scrim" aria-label="Close navigation menu" onClick={() => setMobileMenu(false)} />
      )}
      <aside className={`sidebar ${mobileMenu ? 'menu-open' : ''}`}>
        <button className="brand-button" aria-label="Rimba Home" onClick={() => navigate('explore')}>
          <Brand />
        </button>
        <button
          className="mobile-menu-button icon-button"
          aria-label={mobileMenu ? 'Close menu' : 'Open menu'}
          aria-expanded={mobileMenu}
          onClick={() => setMobileMenu(value => !value)}
        >
          {mobileMenu ? <X size={22} /> : <Menu size={22} />}
        </button>
        <div className="sidebar-content">
          <span className="nav-caption">YOUR SANCTUARY</span>
          <nav aria-label="Primary Navigation">
            {[
              { id: 'explore' as const, label: 'Explore', icon: Compass },
              { id: 'sounds' as const, label: 'Nature Sounds', icon: AudioLines },
              { id: 'settings' as const, label: 'Settings', icon: SlidersHorizontal },
            ].map(item => (
              <button
                key={item.id}
                className={`nav-item ${page === item.id ? 'active' : ''}`}
                aria-current={page === item.id ? 'page' : undefined}
                onClick={() => navigate(item.id)}
              >
                <item.icon size={19} strokeWidth={1.6} />
                <span>{item.label}</span>
                {page === item.id && <span className="nav-dot" />}
              </button>
            ))}
          </nav>
          <div className="sidebar-divider" />
          <button className={`nav-item ${page === 'guide' ? 'active' : ''}`} onClick={() => navigate('guide')}>
            <CircleHelp size={19} strokeWidth={1.6} />
            <span>Guide & VR Setup</span>
            <ArrowUpRight size={14} className="nav-end-icon" />
          </button>
          <div className="sidebar-breath">
            <Leaf size={20} strokeWidth={1.2} />
            <span>TAKE A LITTLE BREATH</span>
            <p>You don't have to travel far<br />to feel away.</p>
            <LandscapeDrawing />
          </div>
          <div className="sidebar-bottom">
            <span>RIMBA VR <small>v.2.1</small></span>
            <span className="nature-online"><i />Connected with nature</span>
          </div>
        </div>
      </aside>

      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumb">
            <span>Virtual Nature</span>
            <ChevronRight size={13} />
            <strong>{pageNames[page]}</strong>
          </div>
          <div className="topbar-actions">
            <button className="vr-mode-button" onClick={() => navigate('settings')}>
              <Glasses size={18} strokeWidth={1.5} />
              <span>{settings.displayMode === 'stereo' ? 'VR Dual View Ready' : 'Single Screen Mode'}</span>
              <span className="status-dot" />
            </button>
            <span className="topbar-separator" />
            <button className="icon-button" aria-label="Open User Guide" onClick={() => setModal('guide')}>
              <CircleHelp size={19} strokeWidth={1.5} />
            </button>
            <div className="profile-mark" title="Welcome, Explorer">
              <LeafMark size={20} />
            </div>
          </div>
        </header>

        <main>
          <motion.div key={page} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.22 }}>
            {page === 'explore' && (
              <>
                <section className="hero" aria-label="Welcome to Rimba Nature Experience">
                  <AnimatePresence initial={false}>
                    <motion.img
                      key={selectedWorld.image}
                      className="hero-image"
                      src={selectedWorld.image}
                      alt={`Scenic panoramic view of ${selectedWorld.name}`}
                      initial={{ opacity: 0, scale: 1.05 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ opacity: { duration: 0.7 }, scale: { duration: 8, ease: 'easeOut' } }}
                    />
                  </AnimatePresence>
                  <div className="hero-shade" />
                  <div className="hero-content">
                    <motion.span {...fadeIn} transition={{ delay: 0.1, duration: 0.6 }} className="hero-eyebrow">
                      A PAUSE. A SANCTUARY.
                    </motion.span>
                    <motion.h1 {...fadeIn} transition={{ delay: 0.2, duration: 0.7 }}>
                      <span className="hero-brand">rimba<span>.</span></span>
                      <span className="hero-title">Step into nature.</span>
                    </motion.h1>
                    <motion.p {...fadeIn} transition={{ delay: 0.3, duration: 0.7 }}>
                      Far from the noise, close to serenity.<br />
                      A living 3D natural realm moving with your footsteps.
                    </motion.p>
                    <motion.div {...fadeIn} transition={{ delay: 0.4, duration: 0.7 }} className="hero-buttons">
                      <button className="primary-button light" onClick={startGame}>
                        <Play size={14} fill="currentColor" />
                        Explore in VR
                        <ArrowUpRight size={16} />
                      </button>
                      <button className="hero-guide" onClick={() => setModal('guide')}>
                        How to Play <ArrowUpRight size={14} />
                      </button>
                    </motion.div>
                  </div>
                </section>

                <section className="destinations" aria-labelledby="destinations-heading">
                  <div className="section-heading">
                    <div>
                      <span className="eyebrow">CHOOSE YOUR RETREAT</span>
                      <h2 id="destinations-heading">Where shall we journey today?</h2>
                    </div>
                    <button
                      className={`favorite-filter ${favoritesOnly ? 'is-active' : ''}`}
                      aria-pressed={favoritesOnly}
                      onClick={() => setFavoritesOnly(value => !value)}
                    >
                      <Heart size={15} fill={favoritesOnly ? 'currentColor' : 'none'} />
                      {favoritesOnly ? 'All Destinations' : 'Saved Favorites'}
                      {favorites.length > 0 && !favoritesOnly && <span>{favorites.length}</span>}
                    </button>
                  </div>

                  <div className="destination-grid">
                    {worlds
                      .filter(world => !favoritesOnly || favorites.includes(world.id))
                      .map((world, i) => (
                        <motion.article
                          className={`destination ${selectedId === world.id ? 'is-selected' : ''}`}
                          key={world.id}
                          initial={{ opacity: 0, y: 18 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          viewport={{ once: true, amount: 0.2 }}
                          transition={{ duration: 0.55, delay: i * 0.1 }}
                        >
                          <div className="destination-visual">
                            <button
                              className="destination-select"
                              aria-label={`Select ${world.name}`}
                              aria-pressed={selectedId === world.id}
                              onClick={() => setSelectedId(world.id)}
                            >
                              <img src={world.image} alt={world.name} loading="lazy" />
                              <span className="destination-image-shade" />
                              {selectedId === world.id && (
                                <span className="selected-indicator">
                                  <Check size={13} />
                                  <span>Selected</span>
                                </span>
                              )}
                              <span className="destination-index">0{i + 1}</span>
                            </button>
                            <button
                              className={`favorite-button ${favorites.includes(world.id) ? 'is-favorite' : ''}`}
                              aria-label={`${favorites.includes(world.id) ? 'Remove' : 'Save'} ${world.name} ${favorites.includes(world.id) ? 'from' : 'to'} favorites`}
                              aria-pressed={favorites.includes(world.id)}
                              onClick={() => toggleFavorite(world.id)}
                            >
                              <Heart size={15} fill={favorites.includes(world.id) ? 'currentColor' : 'none'} />
                            </button>
                          </div>
                          <button className="destination-info" onClick={() => setSelectedId(world.id)}>
                            <span className="destination-category">{world.category}</span>
                            <span className="destination-name">
                              {world.name}
                              <ArrowUpRight size={18} strokeWidth={1.4} />
                            </span>
                            <span className="destination-description">{world.shortDescription}</span>
                          </button>
                        </motion.article>
                      ))}
                  </div>

                  {favoritesOnly && favorites.length === 0 && (
                    <div className="empty-favorites">
                      <Heart size={27} strokeWidth={1.2} />
                      <h3>Save destinations that bring you peace.</h3>
                      <p>Tap the heart icon on any world to find it easily right here.</p>
                      <button className="text-button" onClick={() => setFavoritesOnly(false)}>
                        View All Worlds <ArrowUpRight size={15} />
                      </button>
                    </div>
                  )}

                  <div className="destinations-note">
                    <Leaf size={13} strokeWidth={1.5} />
                    <span>No destinations to conquer. Simply arrive, breathe, and explore.</span>
                    <span className="world-count">{worlds.length} worlds, endless serenity</span>
                  </div>
                </section>
              </>
            )}

            {page === 'sounds' && (
              <div className="inner-page">
                <span className="page-overline">NATURE ACOUSTICS</span>
                <SoundPanel
                  settings={settings}
                  onChange={updateSettings}
                  playing={audioPlaying}
                  onToggle={toggleAudio}
                />
              </div>
            )}

            {page === 'settings' && (
              <div className="inner-page">
                <div className="page-intro">
                  <span className="eyebrow">CUSTOMIZE EXPEDITION</span>
                  <h1>Comfort, on your terms.</h1>
                  <p>Fine-tune VR views, display modes, sensor sensitivity, and ambient lighting.</p>
                </div>
                <SettingsPanel
                  settings={settings}
                  onChange={updateSettings}
                  onReset={() => notify('Settings reset to default options.')}
                />
              </div>
            )}

            {page === 'guide' && (
              <div className="inner-page">
                <GuidePanel onStart={startGame} />
              </div>
            )}
          </motion.div>
        </main>

        <footer className="ambient-player" aria-label="Ambient Sound Player">
          <div className="player-track">
            <img src={selectedWorld.image} alt="" />
            <span>
              <strong>{selectedWorld.name}</strong>
              <small>{selectedWorld.sounds}</small>
            </span>
          </div>
          <div className="player-controls">
            <button
              className={`player-play ${audioPlaying ? 'playing' : ''}`}
              aria-label={audioPlaying ? 'Pause nature sounds' : 'Play nature sounds'}
              onClick={toggleAudio}
            >
              {audioPlaying ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />}
            </button>
            <Waveform small playing={audioPlaying} />
            <span className="player-time">{duration(audioSeconds)}</span>
          </div>
          <div className="player-volume">
            <span className="headphone-tip">
              <Headphones size={15} />
              <span>Immersive with headphones</span>
            </span>
            <Volume2 size={16} strokeWidth={1.5} />
            <input
              type="range"
              aria-label="Master volume"
              min="0"
              max="100"
              value={settings.volume}
              onChange={event => updateSettings({ volume: Number(event.target.value) })}
              style={{ '--range-progress': `${settings.volume}%` } as React.CSSProperties}
            />
            <button className="icon-button" aria-label="Configure nature sounds" onClick={() => navigate('sounds')}>
              <Settings2 size={17} strokeWidth={1.5} />
            </button>
          </div>
        </footer>
      </div>

      {renderModal()}
      {toastElement}
    </div>
  );
}
