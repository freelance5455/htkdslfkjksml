import React, { useRef, useEffect, useState, useCallback } from 'react';
import { PenTool, RotateCcw, Check, User, ShieldCheck } from 'lucide-react';

interface Props {
  initialSignature?: string;
  initialSignerName?: string;
  initialSignerRole?: string;
  initialDate?: string;
  onChange: (data: {
    signatureDataUrl: string;
    signerName: string;
    signerRole: string;
    signedAt: string;
  }) => void;
  readOnly?: boolean;
}

export const FingerSignatureCanvas: React.FC<Props> = ({
  initialSignature,
  initialSignerName = '',
  initialSignerRole = 'Operatore',
  initialDate = new Date().toISOString().slice(0, 10),
  onChange,
  readOnly = false
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(Boolean(initialSignature));
  const [signerName, setSignerName] = useState(initialSignerName);
  const [signerRole, setSignerRole] = useState(initialSignerRole);
  const [signedAt, setSignedAt] = useState(initialDate);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions based on CSS display size for crisp lines
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = (rect.width || 360) * dpr;
    canvas.height = (rect.height || 140) * dpr;
    ctx.scale(dpr, dpr);

    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = '#0f172a';

    // If there is an initial signature, load it into canvas
    if (initialSignature) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, rect.width || 360, rect.height || 140);
        setHasDrawn(true);
      };
      img.src = initialSignature;
    }
  }, [initialSignature]);

  const getCanvasCoords = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    if ('touches' in e) {
      if (e.touches.length === 0) return { x: 0, y: 0 };
      const touch = e.touches[0];
      return {
        x: touch.clientX - rect.left,
        y: touch.clientY - rect.top
      };
    } else {
      return {
        x: (e as React.MouseEvent).clientX - rect.left,
        y: (e as React.MouseEvent).clientY - rect.top
      };
    }
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    if (readOnly) return;
    // Prevent default scroll on touch
    if ('touches' in e && e.cancelable) {
      e.preventDefault();
    }
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCanvasCoords(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
    setHasDrawn(true);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || readOnly) return;
    if ('touches' in e && e.cancelable) {
      e.preventDefault();
    }
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCanvasCoords(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    onChange({
      signatureDataUrl: dataUrl,
      signerName,
      signerRole,
      signedAt
    });
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.clearRect(0, 0, rect.width, rect.height);
    setHasDrawn(false);
    onChange({
      signatureDataUrl: '',
      signerName,
      signerRole,
      signedAt
    });
  };

  const handleNameChange = (val: string) => {
    setSignerName(val);
    const canvas = canvasRef.current;
    const dataUrl = canvas ? canvas.toDataURL('image/png') : (initialSignature || '');
    onChange({
      signatureDataUrl: hasDrawn ? dataUrl : '',
      signerName: val,
      signerRole,
      signedAt
    });
  };

  const handleRoleChange = (val: string) => {
    setSignerRole(val);
    const canvas = canvasRef.current;
    const dataUrl = canvas ? canvas.toDataURL('image/png') : (initialSignature || '');
    onChange({
      signatureDataUrl: hasDrawn ? dataUrl : '',
      signerName,
      signerRole: val,
      signedAt
    });
  };

  const handleDateChange = (val: string) => {
    setSignedAt(val);
    const canvas = canvasRef.current;
    const dataUrl = canvas ? canvas.toDataURL('image/png') : (initialSignature || '');
    onChange({
      signatureDataUrl: hasDrawn ? dataUrl : '',
      signerName,
      signerRole,
      signedAt: val
    });
  };

  return (
    <div className="bg-neutral-50 border border-neutral-300 rounded-2xl p-3.5 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <PenTool className="w-4 h-4 text-neutral-800" />
          <span className="text-xs font-bold text-neutral-900 uppercase tracking-wide">
            Firma con il dito
          </span>
          {hasDrawn && (
            <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
              <Check className="w-3 h-3" />
              Firma acquisita
            </span>
          )}
        </div>
        {!readOnly && (
          <button
            type="button"
            onClick={handleClear}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-neutral-600 hover:text-red-600 hover:bg-neutral-200/60 rounded-lg transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            Cancella
          </button>
        )}
      </div>

      {/* Signature Canvas Pad */}
      <div className="relative bg-white border-2 border-dashed border-neutral-300 rounded-xl overflow-hidden shadow-inner">
        <canvas
          ref={canvasRef}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          onTouchCancel={stopDrawing}
          style={{ touchAction: 'none' }}
          className={`w-full h-32 cursor-crosshair block ${readOnly ? 'pointer-events-none' : ''}`}
        />
        {!hasDrawn && !readOnly && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-neutral-400 text-xs font-medium">
            <span className="bg-white/90 px-3 py-1 rounded-full shadow-2xs border border-neutral-200">
              Traccia la tua firma qui con il dito ✍️
            </span>
          </div>
        )}
        <div className="absolute bottom-2 left-4 right-4 border-b border-neutral-200/80 pointer-events-none" />
      </div>

      {/* Signer Details Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-xs">
        <div>
          <label className="text-[10px] font-bold text-neutral-600 uppercase block mb-1">
            Nome e Cognome Firmatario
          </label>
          <input
            type="text"
            disabled={readOnly}
            value={signerName}
            onChange={(e) => handleNameChange(e.target.value)}
            placeholder="es. Mario Rossi"
            className="w-full text-xs px-2.5 py-1.5 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-neutral-900 disabled:bg-neutral-100"
          />
        </div>

        <div>
          <label className="text-[10px] font-bold text-neutral-600 uppercase block mb-1">
            Ruolo / Qualifica
          </label>
          <input
            type="text"
            disabled={readOnly}
            value={signerRole}
            onChange={(e) => handleRoleChange(e.target.value)}
            placeholder="es. Operatore / Cliente / QA"
            className="w-full text-xs px-2.5 py-1.5 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-neutral-900 disabled:bg-neutral-100"
          />
        </div>

        <div>
          <label className="text-[10px] font-bold text-neutral-600 uppercase block mb-1">
            Data Firma
          </label>
          <input
            type="date"
            disabled={readOnly}
            value={signedAt}
            onChange={(e) => handleDateChange(e.target.value)}
            className="w-full text-xs px-2.5 py-1.5 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-neutral-900 disabled:bg-neutral-100"
          />
        </div>
      </div>
    </div>
  );
};
