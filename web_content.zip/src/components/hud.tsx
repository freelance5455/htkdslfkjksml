import type { ReactNode } from "react";
import {
  ClipboardList,
  DoorOpen,
  Package,
  Pause,
  Sparkles,
  Star,
  Store,
  Users,
  Wallet,
} from "lucide-react";
import type { HudSnap, PanelId } from "@/game/types";

type Props = {
  hud: HudSnap;
  toast: string | null;
  panel: PanelId;
  onPanel: (p: PanelId) => void;
  onOpen: () => void;
  onPause: () => void;
  onInteract: () => void;
  onSprint: (v: boolean) => void;
  portrait: boolean;
};

export function Hud({
  hud,
  toast,
  panel,
  onPanel,
  onOpen,
  onPause,
  onInteract,
  onSprint,
  portrait,
}: Props) {
  const toggle = (id: Exclude<PanelId, null>) => onPanel(panel === id ? null : id);
  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between p-3 sm:p-4">
      {portrait ? (
        <div className="pointer-events-auto mx-auto mb-2 max-w-sm rounded-xl border border-border bg-surface/90 px-4 py-2 text-center text-xs text-muted">
          Rotate to landscape for the full aisle view.
        </div>
      ) : null}

      <div className="flex items-start justify-between gap-3">
        <div className="pointer-events-auto flex flex-wrap items-center gap-2 rounded-2xl border border-border bg-surface/85 px-3 py-2 backdrop-blur-sm">
          <Chip icon={<Wallet className="size-3.5 text-money" />} label={fmtMoney(hud.money)} />
          <Chip icon={<Star className="size-3.5 text-warn" />} label={hud.rating.toFixed(1)} />
          <Chip
            icon={<Store className="size-3.5 text-accent" />}
            label={`Day ${hud.day} · ${hud.clock}`}
          />
          <span className="hidden text-xs text-muted sm:inline">
            {hud.customers} in store
            {hud.queue ? ` · ${hud.queue} in queue` : ""}
          </span>
        </div>
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            type="button"
            onClick={onOpen}
            className={`inline-flex h-11 items-center gap-2 rounded-xl px-4 text-sm font-semibold transition-transform active:scale-[0.98] ${
              hud.open ? "bg-success text-accent-fg" : "bg-elevated text-fg border border-border-strong"
            }`}
          >
            <DoorOpen className="size-4" />
            {hud.open ? "Open" : "Closed"}
          </button>
          <button
            type="button"
            onClick={onPause}
            className="grid size-11 place-items-center rounded-xl border border-border-strong bg-surface text-fg"
            aria-label="Pause"
          >
            <Pause className="size-4" />
          </button>
        </div>
      </div>

      <div className="flex flex-1 flex-col items-center justify-center pointer-events-none">
        {hud.event ? (
          <div className="rounded-full border border-danger/40 bg-danger/15 px-4 py-1.5 text-xs font-medium text-danger">
            {hud.event}
          </div>
        ) : null}
        {toast ? (
          <div className="mt-3 rounded-xl border border-border bg-elevated/90 px-4 py-2 text-sm text-fg">
            {toast}
          </div>
        ) : null}
        {hud.tutorial ? (
          <div className="mt-3 max-w-md rounded-xl border border-accent/30 bg-surface/90 px-4 py-2 text-sm text-fg">
            {hud.tutorial}
          </div>
        ) : null}
        {hud.prompt ? (
          <div className="mt-4 rounded-full border border-border-strong bg-bg/75 px-4 py-2 text-sm font-medium text-fg">
            <span className="mr-2 text-accent">E</span>
            {hud.prompt}
          </div>
        ) : null}
        {hud.holding ? (
          <div className="mt-2 text-xs text-muted">
            Holding {hud.holding.qty} {hud.holding.name}
          </div>
        ) : null}
      </div>

      <div className="flex items-end justify-between gap-3">
        <div className="hidden w-[116px] md:block" />
        <nav className="pointer-events-auto mx-auto flex items-center gap-1 rounded-2xl border border-border bg-surface/90 p-1.5 backdrop-blur-sm">
          <Dock icon={<Package className="size-4" />} label="Stock" onClick={() => toggle("stock")} active={panel === "stock"} />
          <Dock icon={<Sparkles className="size-4" />} label="Order" onClick={() => toggle("order")} active={panel === "order"} />
          <Dock icon={<Store className="size-4" />} label="Upgrade" onClick={() => toggle("shop")} active={panel === "shop"} />
          <Dock icon={<Users className="size-4" />} label="Staff" onClick={() => toggle("staff")} active={panel === "staff"} />
          <Dock
            icon={<ClipboardList className="size-4" />}
            label="Jobs"
            onClick={() => toggle("missions")}
            active={panel === "missions"}
          />
        </nav>
        <div className="pointer-events-auto flex flex-col gap-2 md:hidden">
          <button
            type="button"
            onPointerDown={() => onSprint(true)}
            onPointerUp={() => onSprint(false)}
            onPointerCancel={() => onSprint(false)}
            className="grid size-14 place-items-center rounded-full border border-border-strong bg-elevated text-xs font-semibold text-fg"
          >
            Run
          </button>
          <button
            type="button"
            onClick={onInteract}
            className="grid size-14 place-items-center rounded-full bg-accent text-xs font-semibold text-accent-fg"
          >
            Use
          </button>
        </div>
      </div>
    </div>
  );
}

function Chip({ icon, label }: { icon: ReactNode; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-sm font-medium tabular-nums text-fg">
      {icon}
      {label}
    </span>
  );
}

function Dock({
  icon,
  label,
  onClick,
  active,
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  active: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex min-w-14 flex-col items-center gap-0.5 rounded-xl px-3 py-2 text-[10px] font-medium uppercase tracking-wide ${
        active ? "bg-elevated text-accent" : "text-muted"
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

export function fmtMoney(n: number): string {
  const sign = n < 0 ? "-" : "";
  return `${sign}$${Math.abs(n).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
}
