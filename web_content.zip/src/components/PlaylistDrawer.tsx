/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef } from 'react';
import {
  Music2,
  Upload,
  Mic,
  MicOff,
  Disc,
  Play,
  Pause,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Track } from '../types';

interface PlaylistDrawerProps {
  tracks: Track[];
  currentTrack: Track;
  isPlaying: boolean;
  onSelectTrack: (track: Track) => void;
  onImportTrack: (newTrack: Track) => void;
  isMicActive: boolean;
  onToggleMic: () => void;
  onOpenAIStudio: () => void;
}

export const PlaylistDrawer: React.FC<PlaylistDrawerProps> = ({
  tracks,
  currentTrack,
  isPlaying,
  onSelectTrack,
  onImportTrack,
  isMicActive,
  onToggleMic,
  onOpenAIStudio,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileUrl = URL.createObjectURL(file);
    const fileNameWithoutExt = file.name.replace(/\.[^/.]+$/, '');

    const customTrack: Track = {
      id: `custom-${Date.now()}`,
      title: fileNameWithoutExt,
      artist: 'User Track / Import',
      album: 'Custom Import',
      duration: 210, // estimated or read on metadata load
      bpm: 128,
      genre: 'Custom Audio',
      coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
      audioUrl: fileUrl,
      isCustom: true,
    };

    onImportTrack(customTrack);
    onSelectTrack(customTrack);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="p-4 rounded-3xl bg-[#0c0d18]/95 border border-purple-500/25 shadow-[0_10px_35px_rgba(0,0,0,0.8)]">
      {/* Header with Import and Mic Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-purple-500/20">
        <div className="flex items-center gap-2">
          <Music2 className="w-4 h-4 text-purple-400" />
          <span className="text-[12px] font-bold tracking-widest text-purple-300 font-dj uppercase">
            DJ PLAYLIST &amp; AUDIO CRATE
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-950/60 text-purple-300 border border-purple-500/40 font-mono">
            {tracks.length} TRACKS
          </span>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* AI Cover Art Studio Button */}
          <button
            onClick={onOpenAIStudio}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white text-[11px] font-bold font-dj uppercase hover:brightness-110 shadow-[0_0_12px_rgba(176,38,255,0.4)] active:scale-95 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI ART STUDIO</span>
          </button>

          {/* Live Mic Toggle */}
          <button
            onClick={onToggleMic}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold font-dj uppercase active:scale-95 transition-all ${
              isMicActive
                ? 'bg-red-500 text-white shadow-[0_0_15px_#ff0055] animate-pulse'
                : 'bg-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-700'
            }`}
            title="Visualize Live Microphone or Club Feed"
          >
            {isMicActive ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
            <span>{isMicActive ? 'MIC LIVE' : 'LIVE MIC'}</span>
          </button>

          {/* Import Audio File */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="audio/*"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-cyan-300 border border-cyan-500/30 text-[11px] font-bold font-dj uppercase active:scale-95 transition-all shadow-[0_0_10px_rgba(0,240,255,0.2)]"
            title="Load your own MP3 / WAV audio"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>IMPORT MP3</span>
          </button>
        </div>
      </div>

      {/* Tracks List */}
      <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-1">
        {tracks.map((track, idx) => {
          const isSelected = track.id === currentTrack.id;
          return (
            <div
              key={track.id}
              onClick={() => onSelectTrack(track)}
              className={`flex items-center justify-between p-2.5 rounded-2xl cursor-pointer transition-all duration-150 ${
                isSelected
                  ? 'bg-gradient-to-r from-cyan-950/60 via-purple-950/40 to-transparent border border-cyan-400/50 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                  : 'bg-zinc-900/40 hover:bg-zinc-800/60 border border-transparent hover:border-zinc-700/50'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                {/* Track Number / Play Indicator */}
                <div className="w-7 h-7 rounded-lg bg-black/60 flex items-center justify-center shrink-0 border border-zinc-700">
                  {isSelected && isPlaying ? (
                    <Disc className="w-4 h-4 text-cyan-400 animate-spin" />
                  ) : isSelected ? (
                    <Play className="w-3 h-3 text-cyan-400 fill-cyan-400" />
                  ) : (
                    <span className="text-[10px] font-mono text-zinc-400 font-bold">
                      {idx + 1}
                    </span>
                  )}
                </div>

                {/* Track Thumbnail */}
                <div className="w-9 h-9 rounded-lg overflow-hidden border border-zinc-700 shrink-0">
                  <img src={track.coverUrl} alt={track.title} className="w-full h-full object-cover" />
                </div>

                {/* Info */}
                <div className="min-w-0">
                  <h5
                    className={`text-[12px] font-bold truncate font-dj tracking-wide ${
                      isSelected ? 'text-cyan-300' : 'text-zinc-200'
                    }`}
                  >
                    {track.title}
                  </h5>
                  <p className="text-[10px] text-zinc-400 truncate">
                    {track.artist} • <span className="text-zinc-500">{track.genre}</span>
                  </p>
                </div>
              </div>

              {/* BPM & Duration */}
              <div className="flex items-center gap-3 shrink-0 text-[10px] font-mono text-zinc-400">
                <span className="px-2 py-0.5 rounded bg-zinc-800/80 text-cyan-300 font-bold border border-zinc-700">
                  {track.bpm} BPM
                </span>
                <div className="flex items-center gap-1 text-zinc-500">
                  <Clock className="w-3 h-3" />
                  <span>{formatTime(track.duration)}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
