import React, { useState, useRef, useEffect } from "react";
import { Send, Mic, MicOff, Volume2, VolumeX, Copy, Check, Sparkles, Zap, RotateCcw, Brain } from "lucide-react";
import { ChatMessage, Language, UserMemory } from "../types";
import { speakText, stopSpeaking, isSpeechRecognitionSupported, createSpeechRecognizer } from "../utils/speech";
import { getOfflineAnswer } from "../utils/offlineEngine";

interface SmartChatProps {
  language: Language;
  memory: UserMemory;
  isOffline: boolean;
  onSendToImagePrompt?: (prompt: string) => void;
}

const SAMPLE_PROMPTS = [
  { label: "কোডিং সাহায্য", prompt: "একটি সুন্দর React ও Tailwind কার্ড কম্পোনেন্টের কোড দাও।" },
  { label: "গল্প লেখা", prompt: "বর্ষার সন্ধ্যায় কলকাতা নিয়ে একটি সুন্দর মিষ্টি ছোট গল্প লেখো।" },
  { label: "পড়াশোনা", prompt: "পমোডোরো টেকনিক দিয়ে কীভাবে দ্রুত কঠিন বিষয় মনে রাখা যায়?" },
  { label: "আইডিয়া", prompt: "২০২৬ সালে সেরা ৩টি ইউনিক এআই মোবাইল অ্যাপ আইডিয়া বলো।" },
  { label: "তুমি কে?", prompt: "তুমি কে এবং তোমাকে কে তৈরি করেছে?" },
];

export const SmartChat: React.FC<SmartChatProps> = ({
  language,
  memory,
  isOffline,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const isApni = memory.addressingMode === "apni";
    return [
      {
        id: "welcome-msg",
        role: "assistant",
        text: isApni
          ? `নমস্কার! আমি **Ranabir**, আপনাকে সাহায্য করার জন্যই তৈরি।\nসর্বদা সাহায্য করার জন্য প্রস্তুত — পড়াশোনা, কোডিং, গল্প লেখা, বা যেকোনো আইডিয়ার প্রশ্ন নির্দ্বিধায় করতে পারেন।`
          : `নমস্কার! আমি **Ranabir**, তোমাকে সাহায্য করার জন্যই তৈরি।\nসর্বদা সাহায্য করার জন্য প্রস্তুত — পড়াশোনা, কোডিং, গল্প লেখা, বা যেকোনো আইডিয়ার প্রশ্ন নির্দ্বিধায় করতে পারো।`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        durationMs: 400,
      },
    ];
  });

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const recognizerRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || loading) return;

    setInput("");

    const userMessage: ChatMessage = {
      id: "msg-" + Date.now(),
      role: "user",
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setLoading(true);

    const startTime = Date.now();

    // If offline mode is toggled, process directly with local on-device engine
    if (isOffline) {
      setTimeout(() => {
        const offlineReply = getOfflineAnswer(query, memory.addressingMode);
        const durationMs = Date.now() - startTime;
        const assistantMessage: ChatMessage = {
          id: "msg-" + Date.now() + "-reply",
          role: "assistant",
          text: offlineReply,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          durationMs,
          offline: true,
        };
        setMessages((prev) => [...prev, assistantMessage]);
        setLoading(false);
      }, 350);
      return;
    }

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: query,
          history: messages.slice(-6).map((m) => ({ role: m.role, text: m.text })),
          memory,
          language,
        }),
      });

      const data = await response.json();
      const durationMs = data.durationMs || Date.now() - startTime;

      const assistantMessage: ChatMessage = {
        id: "msg-" + Date.now() + "-reply",
        role: "assistant",
        text: data.reply || (memory.addressingMode === "apni" ? "আমি Ranabir, আপনাকে সাহায্য করার জন্যই তৈরি।" : "আমি Ranabir, তোমাকে সাহায্য করার জন্যই তৈরি।"),
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        durationMs,
        offline: data.offlineFallback,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err) {
      console.error("Chat request error, falling back to on-device engine:", err);
      const offlineReply = getOfflineAnswer(query, memory.addressingMode);
      const durationMs = Date.now() - startTime;
      const assistantMessage: ChatMessage = {
        id: "msg-" + Date.now() + "-reply",
        role: "assistant",
        text: offlineReply,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        durationMs,
        offline: true,
      };
      setMessages((prev) => [...prev, assistantMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleVoiceToggle = () => {
    if (isListening) {
      if (recognizerRef.current) {
        recognizerRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    if (!isSpeechRecognitionSupported()) {
      alert("Speech recognition is not supported in this browser environment. You can type your question!");
      return;
    }

    const rec = createSpeechRecognizer(
      language,
      (transcript, isFinal) => {
        setInput(transcript);
        if (isFinal) {
          setIsListening(false);
          handleSendMessage(transcript);
        }
      },
      (error) => {
        console.warn("Speech error:", error);
        setIsListening(false);
      },
      () => {
        setIsListening(false);
      }
    );

    if (rec) {
      recognizerRef.current = rec;
      rec.start();
      setIsListening(true);
    }
  };

  const handleSpeak = (msg: ChatMessage) => {
    if (speakingId === msg.id) {
      stopSpeaking();
      setSpeakingId(null);
      return;
    }

    setSpeakingId(msg.id);
    speakText(
      msg.text,
      language,
      () => {},
      () => setSpeakingId(null)
    );
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-w-4xl mx-auto w-full px-2 sm:px-4">
      {/* Suggestion Chips */}
      <div className="flex items-center gap-2 overflow-x-auto py-2 no-scrollbar">
        {SAMPLE_PROMPTS.map((item, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(item.prompt)}
            className="text-xs px-3 py-1.5 rounded-xl glass-panel hover:border-indigo-500/50 hover:text-indigo-200 text-slate-300 whitespace-nowrap transition-all duration-200 flex items-center gap-1.5 shrink-0"
          >
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span>{item.label}</span>
          </button>
        ))}
      </div>

      {/* Message List */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-1 py-2">
        {messages.map((msg) => {
          const isAssistant = msg.role === "assistant";
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isAssistant ? "items-start" : "items-end"} gap-1`}
            >
              <div
                className={`max-w-[90%] sm:max-w-[80%] rounded-2xl p-3.5 sm:p-4 transition-all duration-200 ${
                  isAssistant
                    ? "glass-panel text-slate-100 border border-white/10 rounded-tl-sm shadow-md"
                    : "bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-tr-sm shadow-lg shadow-indigo-600/20"
                }`}
              >
                {/* Assistant header banner */}
                {isAssistant && (
                  <div className="flex items-center justify-between gap-3 pb-2 mb-2 border-b border-white/5 text-xs text-slate-400">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                      <span className="font-semibold text-slate-300">Ranabir</span>
                      {msg.offline && (
                        <span className="px-1.5 py-0.2 text-[10px] rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          Offline Engine
                        </span>
                      )}
                    </div>
                    {msg.durationMs !== undefined && (
                      <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-mono">
                        <Zap className="w-3 h-3" />
                        <span>{(msg.durationMs / 1000).toFixed(1)}s</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Message Content */}
                <div className="text-sm leading-relaxed whitespace-pre-wrap select-text font-normal">
                  {msg.text}
                </div>

                {/* Assistant Action Buttons */}
                {isAssistant && (
                  <div className="flex items-center gap-2 pt-2.5 mt-2 border-t border-white/5">
                    <button
                      onClick={() => handleSpeak(msg)}
                      className={`p-1.5 rounded-lg text-xs flex items-center gap-1 transition-colors ${
                        speakingId === msg.id
                          ? "bg-cyan-500/20 text-cyan-300"
                          : "hover:bg-white/5 text-slate-400 hover:text-slate-200"
                      }`}
                      title={speakingId === msg.id ? "Stop voice" : "Read aloud (Text to Voice)"}
                    >
                      {speakingId === msg.id ? (
                        <>
                          <VolumeX className="w-3.5 h-3.5" />
                          <span className="text-[11px]">Speaking...</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5" />
                          <span className="text-[11px]">Voice</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => handleCopy(msg.id, msg.text)}
                      className="p-1.5 rounded-lg text-xs flex items-center gap-1 hover:bg-white/5 text-slate-400 hover:text-slate-200 transition-colors"
                      title="Copy response"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-[11px] text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span className="text-[11px]">Copy</span>
                        </>
                      )}
                    </button>

                    {memory.facts && memory.facts.length > 0 && (
                      <span className="ml-auto text-[10px] text-slate-500 flex items-center gap-1">
                        <Brain className="w-3 h-3 text-indigo-400" />
                        <span>Memory Linked</span>
                      </span>
                    )}
                  </div>
                )}
              </div>

              <span className="text-[10px] text-slate-500 px-1 font-mono">
                {msg.timestamp}
              </span>
            </div>
          );
        })}

        {loading && (
          <div className="flex items-start gap-2">
            <div className="glass-panel rounded-2xl rounded-tl-sm p-3.5 flex items-center gap-3 border border-indigo-500/20">
              <div className="flex space-x-1.5">
                <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce"></div>
                <div className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce [animation-delay:0.15s]"></div>
                <div className="w-2 h-2 rounded-full bg-cyan-300 animate-bounce [animation-delay:0.3s]"></div>
              </div>
              <span className="text-xs text-slate-400 font-medium">
                Ranabir চিন্তা করছে (&lt;2s)...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Dock */}
      <div className="pt-2 pb-16 sm:pb-20">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="relative flex items-center gap-2 glass-panel-elevated rounded-2xl p-1.5 sm:p-2 border border-white/15 shadow-xl"
        >
          <button
            type="button"
            onClick={handleVoiceToggle}
            className={`p-2.5 rounded-xl transition-all duration-200 shrink-0 ${
              isListening
                ? "bg-rose-500 text-white animate-pulse shadow-lg shadow-rose-500/40"
                : "hover:bg-white/10 text-slate-400 hover:text-white"
            }`}
            title={isListening ? "Listening... click to stop" : "Speak to Ranabir"}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              isListening
                ? "বলুন... শুনছি..."
                : "Ranabir কে যেকোনো প্রশ্ন করুন (কোডিং, পড়াশোনা, গল্প)..."
            }
            className="flex-1 bg-transparent border-0 text-sm sm:text-base text-white placeholder-slate-400 focus:outline-none px-2 py-1.5"
          />

          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white font-semibold transition-all duration-200 shrink-0 shadow-md shadow-indigo-600/30"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
