import React, { useState, useEffect } from 'react';
import { Product, ProductCategory, BrandName } from '../types/business';
import { StorageService } from '../db/storage';
import {
  Plus,
  Search,
  Filter,
  Package,
  Edit2,
  Trash2,
  PlusCircle,
  Camera,
  Upload,
  X,
  CheckCircle,
  AlertTriangle,
  ArrowLeft,
  Layers,
} from 'lucide-react';

interface ProductManagementProps {
  lang: 'bn' | 'en';
  onBack: () => void;
  initialStockAddId?: string;
}

const CATEGORIES: ProductCategory[] = [
  'LCD/Display',
  'Touch/Glass',
  'Battery',
  'Charging Ribbon',
  'Housing/Body',
  'Camera',
  'IC/Motherboard Parts',
  'Tools',
  'Other',
];

const BRANDS: BrandName[] = [
  'Samsung',
  'Xiaomi / Redmi',
  'Oppo',
  'Vivo',
  'Realme',
  'Apple',
  'Infinix',
  'Tecno',
  'OnePlus',
  'Honor / Huawei',
  'Motorola',
  'Nokia',
  'Other',
];

export const ProductManagement: React.FC<ProductManagementProps> = ({
  lang,
  onBack,
  initialStockAddId,
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedBrand, setSelectedBrand] = useState<string>('All');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [stockAddProduct, setStockAddProduct] = useState<Product | null>(null);
  const [deleteCandidate, setDeleteCandidate] = useState<Product | null>(null);

  // Form states for new/edit product
  const [formCategory, setFormCategory] = useState<ProductCategory>('LCD/Display');
  const [formBrand, setFormBrand] = useState<BrandName>('Samsung');
  const [formModel, setFormModel] = useState('');
  const [formSupportedModels, setFormSupportedModels] = useState('');
  const [formCondition, setFormCondition] = useState<'New' | 'Used'>('New');
  const [formStock, setFormStock] = useState<number | ''>(10);
  const [formPurchasePrice, setFormPurchasePrice] = useState<number | ''>(1000);
  const [formRetailPrice, setFormRetailPrice] = useState<number | ''>(1500);
  const [formWholesalePrice, setFormWholesalePrice] = useState<number | ''>(1300);
  const [formAlertLimit, setFormAlertLimit] = useState<number | ''>(4);
  const [formFrontPhoto, setFormFrontPhoto] = useState('');
  const [formBackPhoto, setFormBackPhoto] = useState('');
  const [formError, setFormError] = useState('');

  // Stock Add modal states
  const [stockAddQty, setStockAddQty] = useState<number | ''>(5);
  const [stockAddCost, setStockAddCost] = useState<number | ''>('');
  const [stockAddNote, setStockAddNote] = useState('');

  const refreshProducts = () => {
    setProducts(StorageService.getProducts());
  };

  useEffect(() => {
    refreshProducts();
    if (initialStockAddId) {
      const p = StorageService.getProductById(initialStockAddId);
      if (p) {
        setStockAddProduct(p);
        setStockAddCost(p.purchasePrice);
      }
    }
  }, [initialStockAddId]);

  // Image Upload Handler
  const handlePhotoUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (val: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert(lang === 'bn' ? 'ছবির সাইজ ২MB এর বেশি হওয়া যাবে না' : 'Image size must be under 2MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setter(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Open Add Product
  const handleOpenAdd = () => {
    setEditingProduct(null);
    setFormCategory('LCD/Display');
    setFormBrand('Samsung');
    setFormModel('');
    setFormSupportedModels('');
    setFormCondition('New');
    setFormStock(10);
    setFormPurchasePrice(1000);
    setFormRetailPrice(1500);
    setFormWholesalePrice(1300);
    setFormAlertLimit(4);
    setFormFrontPhoto('');
    setFormBackPhoto('');
    setFormError('');
    setShowAddModal(true);
  };

  // Open Edit Product
  const handleOpenEdit = (product: Product) => {
    setEditingProduct(product);
    setFormCategory(product.category);
    setFormBrand(product.brand);
    setFormModel(product.modelNumber);
    setFormSupportedModels(product.supportedModels);
    setFormCondition(product.condition);
    setFormStock(product.stockQuantity);
    setFormPurchasePrice(product.purchasePrice);
    setFormRetailPrice(product.retailPrice);
    setFormWholesalePrice(product.wholesalePrice);
    setFormAlertLimit(product.alertLimit);
    setFormFrontPhoto(product.frontPhoto || '');
    setFormBackPhoto(product.backPhoto || '');
    setFormError('');
    setShowAddModal(true);
  };

  // Save Product (New or Edit)
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formModel.trim()) {
      setFormError(lang === 'bn' ? 'মডেল নম্বর পূরণ করুন' : 'Model number is required');
      return;
    }
    if (formPurchasePrice === '' || formPurchasePrice < 0) {
      setFormError(lang === 'bn' ? 'সঠিক ক্রয় মূল্য দিন' : 'Enter valid purchase price');
      return;
    }
    if (formRetailPrice === '' || formRetailPrice < 0) {
      setFormError(lang === 'bn' ? 'সঠিক খুচরা বিক্রয় মূল্য দিন' : 'Enter valid retail price');
      return;
    }

    const name = `${formBrand} ${formModel.trim()} ${formCategory}`;

    if (editingProduct) {
      // Update existing
      StorageService.updateProduct({
        ...editingProduct,
        name,
        category: formCategory,
        brand: formBrand,
        modelNumber: formModel.trim(),
        supportedModels: formSupportedModels.trim(),
        condition: formCondition,
        stockQuantity: Number(formStock) || 0,
        purchasePrice: Number(formPurchasePrice) || 0,
        retailPrice: Number(formRetailPrice) || 0,
        wholesalePrice: Number(formWholesalePrice) || Number(formRetailPrice) || 0,
        alertLimit: Number(formAlertLimit) || 3,
        frontPhoto: formFrontPhoto,
        backPhoto: formBackPhoto,
      });
    } else {
      // Check for duplicate model in same category to adhere to specification:
      // "একই product আবার stock এলে নতুন product তৈরি করা যাবে না। Existing product-এর ভিতরে Stock Add ব্যবহার করে quantity বাড়াতে হবে।"
      const existing = products.find(
        (p) =>
          p.brand.toLowerCase() === formBrand.toLowerCase() &&
          p.modelNumber.toLowerCase() === formModel.trim().toLowerCase() &&
          p.category === formCategory
      );

      if (existing) {
        setFormError(
          lang === 'bn'
            ? 'এই মডেলটি ইতোমধ্যেই তালিকায় বিদ্যমান আছে! নতুন তৈরি না করে পণ্যটির "+ স্টক" বাটনে ক্লিক করে পরিমাণ বৃদ্ধি করুন।'
            : 'This model already exists in inventory! Please use "+ Stock Add" on the existing item.'
        );
        return;
      }

      // Add New
      StorageService.addProduct({
        name,
        category: formCategory,
        brand: formBrand,
        modelNumber: formModel.trim(),
        supportedModels: formSupportedModels.trim(),
        condition: formCondition,
        stockQuantity: Number(formStock) || 0,
        purchasePrice: Number(formPurchasePrice) || 0,
        retailPrice: Number(formRetailPrice) || 0,
        wholesalePrice: Number(formWholesalePrice) || Number(formRetailPrice) || 0,
        alertLimit: Number(formAlertLimit) || 3,
        frontPhoto: formFrontPhoto,
        backPhoto: formBackPhoto,
      });
    }

    setShowAddModal(false);
    refreshProducts();
  };

  // Submit Stock Add
  const handleStockAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stockAddProduct) return;
    const qty = Number(stockAddQty);
    if (!qty || qty <= 0) return;

    StorageService.addStockToProduct(
      stockAddProduct.id,
      qty,
      Number(stockAddCost) || stockAddProduct.purchasePrice,
      stockAddNote.trim()
    );

    setStockAddProduct(null);
    setStockAddQty(5);
    setStockAddNote('');
    refreshProducts();
  };

  // Execute Delete
  const handleConfirmDelete = () => {
    if (deleteCandidate) {
      StorageService.deleteProduct(deleteCandidate.id);
      setDeleteCandidate(null);
      refreshProducts();
    }
  };

  // Filter products
  const filteredProducts = products.filter((p) => {
    const q = searchQuery.toLowerCase();
    const matchSearch =
      p.name.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.modelNumber.toLowerCase().includes(q) ||
      p.supportedModels.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q);

    const matchCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchBrand = selectedBrand === 'All' || p.brand === selectedBrand;

    return matchSearch && matchCategory && matchBrand;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Top Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                {lang === 'bn' ? 'পণ্য ও স্টক পরিচালনা' : 'Product & Stock Management'}
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn'
                  ? `মোট ${products.length} টি পার্টস রেজিস্টার্ড রয়েছে`
                  : `Total ${products.length} parts registered`}
              </p>
            </div>
          </div>

          <button
            onClick={handleOpenAdd}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm flex items-center gap-2 shadow-md shadow-blue-500/20 active:scale-95 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'bn' ? 'নতুন পণ্য যোগ' : 'Add New Product'}</span>
          </button>
        </div>

        {/* Filter & Search Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 border-t border-slate-100 flex flex-col md:flex-row items-stretch md:items-center gap-3">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                lang === 'bn'
                  ? 'ক্যাটাগরি, ব্র্যান্ড, মডেল বা সাপোর্টেড মডেল খুঁজুন...'
                  : 'Search category, brand, model, supported model...'
              }
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 focus:outline-none"
            >
              <option value="All">{lang === 'bn' ? 'সব ক্যাটাগরি' : 'All Categories'}</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            {/* Brand Filter */}
            <select
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="px-3 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 focus:outline-none"
            >
              <option value="All">{lang === 'bn' ? 'সব ব্র্যান্ড' : 'All Brands'}</option>
              {BRANDS.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Product List */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-sm max-w-md mx-auto">
            <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
              <Package className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-slate-800">
              {lang === 'bn' ? 'কোন পণ্য পাওয়া যায়নি' : 'No Products Found'}
            </h3>
            <p className="text-xs text-slate-500 mt-1 mb-5">
              {lang === 'bn'
                ? 'আপনার সার্চ ফিল্টারে কোন পণ্য মিলেনি অথবা এখনো পণ্য যোগ করা হয়নি।'
                : 'Try adjusting your search or add a new mobile part to inventory.'}
            </p>
            <button
              onClick={handleOpenAdd}
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer inline-flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>{lang === 'bn' ? 'পণ্য যোগ করুন' : 'Add Product'}</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredProducts.map((p) => {
              const isStockOut = p.stockQuantity === 0;
              const isLimited = p.stockQuantity > 0 && p.stockQuantity <= p.alertLimit;

              return (
                <div
                  key={p.id}
                  className={`bg-white rounded-2xl border transition-all shadow-xs hover:shadow-md flex flex-col justify-between overflow-hidden ${
                    isStockOut
                      ? 'border-red-300 ring-1 ring-red-200'
                      : isLimited
                      ? 'border-amber-300 ring-1 ring-amber-200'
                      : 'border-slate-200'
                  }`}
                >
                  {/* Card Header with Badges */}
                  <div className="p-4 pb-2">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className="px-2.5 py-0.5 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-[11px] border border-indigo-100">
                        {p.brand}
                      </span>
                      {isStockOut ? (
                        <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 font-extrabold text-[10px] animate-pulse">
                          🔴 Stock Out
                        </span>
                      ) : isLimited ? (
                        <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold text-[10px]">
                          🟠 Limited Stock ({p.stockQuantity})
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-semibold text-[10px] border border-emerald-200">
                          🟢 In Stock ({p.stockQuantity})
                        </span>
                      )}
                    </div>

                    {/* Photos Preview */}
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-16 h-16 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                        {p.frontPhoto ? (
                          <img src={p.frontPhoto} alt="Front" className="w-full h-full object-cover" />
                        ) : (
                          <Package className="w-7 h-7 text-slate-400" />
                        )}
                      </div>
                      {p.backPhoto && (
                        <div className="w-16 h-16 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                          <img src={p.backPhoto} alt="Back" className="w-full h-full object-cover" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                          {p.category}
                        </span>
                        <h3 className="font-bold text-slate-900 text-sm leading-snug line-clamp-2">
                          {p.modelNumber}
                        </h3>
                        {p.supportedModels && (
                          <p className="text-[11px] text-slate-500 truncate mt-0.5">
                            সাপোর্ট: {p.supportedModels}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Pricing Grid */}
                    <div className="grid grid-cols-3 gap-1.5 p-2 rounded-xl bg-slate-50 border border-slate-100 text-center text-xs mb-1">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">ক্রয়</span>
                        <span className="font-bold text-slate-700">৳{p.purchasePrice}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">খুচরা</span>
                        <span className="font-bold text-emerald-600">৳{p.retailPrice}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">পাইকারি</span>
                        <span className="font-bold text-blue-600">৳{p.wholesalePrice}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div className="px-4 py-2.5 bg-slate-50/70 border-t border-slate-100 flex items-center justify-between gap-1">
                    {/* Stock Add Button */}
                    <button
                      onClick={() => {
                        setStockAddProduct(p);
                        setStockAddCost(p.purchasePrice);
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 shadow-2xs cursor-pointer"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>+ স্টক</span>
                    </button>

                    <div className="flex items-center gap-1">
                      {/* Edit */}
                      <button
                        onClick={() => handleOpenEdit(p)}
                        className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 transition-colors shadow-2xs cursor-pointer"
                        title="Edit"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>

                      {/* Delete */}
                      <button
                        onClick={() => setDeleteCandidate(p)}
                        className="p-1.5 rounded-lg bg-white border border-slate-200 text-red-600 hover:bg-red-50 transition-colors shadow-2xs cursor-pointer"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ADD / EDIT PRODUCT MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-8">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-base flex items-center gap-2">
                <Package className="w-5 h-5 text-blue-400" />
                <span>
                  {editingProduct
                    ? (lang === 'bn' ? 'পণ্য তথ্য সম্পাদনা' : 'Edit Product')
                    : (lang === 'bn' ? 'নতুন পণ্য যোগ করুন' : 'Add New Product')}
                </span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              {formError && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-500" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Front and Back Photos */}
              <div className="grid grid-cols-2 gap-4 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                {/* Front Photo */}
                <div className="text-center">
                  <span className="block text-xs font-semibold text-slate-700 mb-1">
                    Front Photo (সামনের ছবি)
                  </span>
                  <div className="w-20 h-20 mx-auto rounded-xl bg-white border border-slate-300 overflow-hidden flex items-center justify-center relative group">
                    {formFrontPhoto ? (
                      <img src={formFrontPhoto} alt="Front" className="w-full h-full object-cover" />
                    ) : (
                      <Camera className="w-6 h-6 text-slate-400" />
                    )}
                    <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer text-white text-[10px]">
                      আপলোড
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handlePhotoUpload(e, setFormFrontPhoto)}
                      />
                    </label>
                  </div>
                </div>

                {/* Back Photo */}
                <div className="text-center">
                  <span className="block text-xs font-semibold text-slate-700 mb-1">
                    Back Photo (পেছনের ছবি)
                  </span>
                  <div className="w-20 h-20 mx-auto rounded-xl bg-white border border-slate-300 overflow-hidden flex items-center justify-center relative group">
                    {formBackPhoto ? (
                      <img src={formBackPhoto} alt="Back" className="w-full h-full object-cover" />
                    ) : (
                      <Camera className="w-6 h-6 text-slate-400" />
                    )}
                    <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer text-white text-[10px]">
                      আপলোড
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handlePhotoUpload(e, setFormBackPhoto)}
                      />
                    </label>
                  </div>
                </div>
              </div>

              {/* Category & Brand */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ক্যাটাগরি *
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as ProductCategory)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ব্র্যান্ড *
                  </label>
                  <select
                    value={formBrand}
                    onChange={(e) => setFormBrand(e.target.value as BrandName)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                  >
                    {BRANDS.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Model Number & Supported Models */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    মডেল নম্বর * (যেমন: Galaxy A12)
                  </label>
                  <input
                    type="text"
                    required
                    value={formModel}
                    onChange={(e) => setFormModel(e.target.value)}
                    placeholder="e.g. Galaxy A12 / A125F"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    সাপোর্টেড মডেলসমূহ (যেমন: A12, M12, A02s)
                  </label>
                  <input
                    type="text"
                    value={formSupportedModels}
                    onChange={(e) => setFormSupportedModels(e.target.value)}
                    placeholder="e.g. A12 / M12 / A02s"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>

              {/* Condition & Stock Quantity */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    কন্ডিশন
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setFormCondition('New')}
                      className={`flex-1 py-1.5 rounded-xl text-xs font-bold border cursor-pointer ${
                        formCondition === 'New'
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-slate-50 text-slate-600 border-slate-200'
                      }`}
                    >
                      New (নতুন)
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormCondition('Used')}
                      className={`flex-1 py-1.5 rounded-xl text-xs font-bold border cursor-pointer ${
                        formCondition === 'Used'
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-slate-50 text-slate-600 border-slate-200'
                      }`}
                    >
                      Used (ব্যবহৃত)
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    প্রাথমিক স্টক পরিমাণ (পিস) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formStock}
                    onChange={(e) => setFormStock(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>

              {/* Pricing Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ক্রয় মূল্য (৳) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formPurchasePrice}
                    onChange={(e) => setFormPurchasePrice(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    খুচরা বিক্রয় মূল্য (৳) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formRetailPrice}
                    onChange={(e) => setFormRetailPrice(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    পাইকারি বিক্রয় মূল্য (৳)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formWholesalePrice}
                    onChange={(e) => setFormWholesalePrice(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>

              {/* Alert Limit */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  স্টক অ্যালার্ট লিমিট (পিস) — এই সংখ্যার নিচে নামলে সতর্কবার্তা দিবে
                </label>
                <input
                  type="number"
                  min="1"
                  value={formAlertLimit}
                  onChange={(e) => setFormAlertLimit(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              {/* Modal Buttons */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/20 cursor-pointer"
                >
                  {editingProduct ? 'আপডেট সংরক্ষণ' : 'পণ্য সংরক্ষণ করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* STOCK ADD MODAL (On Existing Product) */}
      {stockAddProduct && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
            <div className="px-6 py-4 bg-emerald-600 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <PlusCircle className="w-5 h-5" />
                <span>মজুদ বৃদ্ধি / Stock Add</span>
              </h3>
              <button
                onClick={() => setStockAddProduct(null)}
                className="text-emerald-100 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleStockAddSubmit} className="p-6 space-y-4">
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400">
                  {stockAddProduct.brand} • {stockAddProduct.category}
                </span>
                <h4 className="font-bold text-slate-800 text-sm mt-0.5">
                  {stockAddProduct.modelNumber}
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  বর্তমান মজুদ: <span className="font-bold text-slate-800">{stockAddProduct.stockQuantity} পিস</span>
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  নতুন যোগ করার পরিমাণ (পিস) *
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={stockAddQty}
                  onChange={(e) => setStockAddQty(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="5"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  নতুন লটের ক্রয় মূল্য (৳ / পিস)
                </label>
                <input
                  type="number"
                  min="0"
                  value={stockAddCost}
                  onChange={(e) => setStockAddCost(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder={`আগের ক্রয়: ৳${stockAddProduct.purchasePrice}`}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  সাপ্লায়ার বা মন্তব্য (ঐচ্ছিক)
                </label>
                <input
                  type="text"
                  value={stockAddNote}
                  onChange={(e) => setStockAddNote(e.target.value)}
                  placeholder="যেমন: ঢাকা স্টেডিয়াম মার্কেট"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setStockAddProduct(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-500/20 cursor-pointer"
                >
                  স্টক নিশ্চিত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 text-center border border-slate-100">
            <div className="w-14 h-14 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-slate-900 text-base">
              {lang === 'bn' ? 'আপনি কি এই পণ্যটি মুছে ফেলতে চান?' : 'Delete this product?'}
            </h3>
            <p className="text-xs text-slate-500 mt-2 mb-6">
              {deleteCandidate.brand} {deleteCandidate.modelNumber} ({deleteCandidate.category})
              <br />
              <span className="text-slate-400 text-[11px]">
                (পূর্বের সকল বিক্রয় রেকর্ড ও ইনভয়েস ইতিহাস অক্ষত থাকবে)
              </span>
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setDeleteCandidate(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
              >
                {lang === 'bn' ? 'Cancel' : 'Cancel'}
              </button>
              <button
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-500/20 cursor-pointer"
              >
                {lang === 'bn' ? 'Delete / মুছে ফেলুন' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
