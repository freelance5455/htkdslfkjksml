import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Square,
  Volume2,
  VolumeX,
  Search,
  Edit2,
  Trash2,
  Download,
  AlertCircle,
  Activity,
  Sliders,
  Sparkles,
} from 'lucide-react';
import { SoundItem } from '../types';
import { updateSoundName, deleteSoundFromDB } from '../utils/audioStorage';

interface SoundboardGridProps {
  sounds: SoundItem[];
  onRefreshSounds: () => void;
  masterVolume: number;
  onMasterVolumeChange: (vol: number) => void;
  onPlayStateChange?: (isPlaying: boolean, currentSound: SoundItem | null) => void;
}

export const SoundboardGrid: React.FC<SoundboardGridProps> = ({
  sounds,
  onRefreshSounds,
  masterVolume,
  onMasterVolumeChange,
  onPlayStateChange,
}) => {
  const [activeSoundId, setActiveSoundId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingItem, setEditingItem] = useState<SoundItem | null>(null);
  const [editNameText, setEditNameText] = useState('');
  const [deletingItem, setDeletingItem] = useState<SoundItem | null>(null);

  // Audio player reference
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Stop playback when soundboard is unmounted or reset
  const stopAllPlayback = () => {
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current.currentTime = 0;
      currentAudioRef.current = null;
    }
    setActiveSoundId(null);
    onPlayStateChange?.(false, null);
  };

  // Keep volume synced
  useEffect(() => {
    if (currentAudioRef.current) {
      currentAudioRef.current.volume = masterVolume;
    }
  }, [masterVolume]);

  const toggleSound = (sound: SoundItem) => {
    // If tapping the currently playing sound, stop it
    if (activeSoundId === sound.id) {
      stopAllPlayback();
      return;
    }

    // Stop previous sound immediately (Strict Single Playback rule)
    stopAllPlayback();

    if (!sound.url) {
      alert('সাউন্ড ফাইলটি পাওয়া যায়নি!');
      return;
    }

    try {
      const audio = new Audio(sound.url);
      audio.volume = masterVolume;

      audio.onended = () => {
        setActiveSoundId(null);
        currentAudioRef.current = null;
        onPlayStateChange?.(false, null);
      };

      audio.onerror = (e) => {
        console.error('Playback error', e);
        stopAllPlayback();
      };

      audio.play().then(() => {
        currentAudioRef.current = audio;
        setActiveSoundId(sound.id);
        onPlayStateChange?.(true, sound);
      }).catch((err) => {
        console.error('Audio play error:', err);
        stopAllPlayback();
      });
    } catch (err) {
      console.error('Error starting audio', err);
      stopAllPlayback();
    }
  };

  const handleSaveRename = async () => {
    if (!editingItem) return;
    const trimmed = editNameText.trim();
    if (!trimmed) return;

    await updateSoundName(editingItem.id, trimmed);
    setEditingItem(null);
    onRefreshSounds();
  };

  const handleConfirmDelete = async () => {
    if (!deletingItem) return;
    if (activeSoundId === deletingItem.id) {
      stopAllPlayback();
    }
    await deleteSoundFromDB(deletingItem.id);
    setDeletingItem(null);
    onRefreshSounds();
  };

  const filteredSounds = sounds.filter((s) =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  const activeSound = sounds.find((s) => s.id === activeSoundId);

  return (
    <div className="flex flex-col gap-6">
      {/* Top Gaming Control Bar: Stop All + Master Volume + Search */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 p-4 rounded-2xl bg-[#0e101a] border border-slate-800/90 shadow-xl">
        {/* Stop All Emergency Button */}
        <div className="md:col-span-3 flex items-center">
          <button
            onClick={stopAllPlayback}
            className={`w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-orbitron font-bold text-sm tracking-wider uppercase transition-all duration-200 ${
              activeSoundId
                ? 'bg-red-600 text-white shadow-[0_0_20px_rgba(255,30,68,0.5)] hover:bg-red-500 animate-pulse'
                : 'bg-red-950/40 text-red-400/80 border border-red-900/40 hover:bg-red-900/30'
            }`}
          >
            <Square className="w-4 h-4 fill-current" />
            <span>Stop All</span>
          </button>
        </div>

        {/* Master Volume Slider */}
        <div className="md:col-span-5 flex items-center gap-3 px-3 py-2 rounded-xl bg-[#141724] border border-slate-800">
          <button
            onClick={() => onMasterVolumeChange(masterVolume > 0 ? 0 : 0.85)}
            className="text-slate-400 hover:text-cyan-400 transition-colors"
            title="Mute / Unmute"
          >
            {masterVolume === 0 ? (
              <VolumeX className="w-5 h-5 text-red-500" />
            ) : (
              <Volume2 className="w-5 h-5 text-cyan-400" />
            )}
          </button>

          <div className="flex-1 flex flex-col gap-1">
            <div className="flex justify-between items-center text-[11px] font-mono">
              <span className="text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <Sliders className="w-3 h-3 text-cyan-400" /> Master Volume
              </span>
              <span className="font-bold text-cyan-400 font-mono">
                {Math.round(masterVolume * 100)}%
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={masterVolume}
              onChange={(e) => onMasterVolumeChange(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-700/80 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
          </div>
        </div>

        {/* Quick Search Field */}
        <div className="md:col-span-4 relative flex items-center">
          <Search className="absolute left-3.5 w-4 h-4 text-slate-500 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search sounds..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#141724] border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all font-chakra"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 text-xs text-slate-400 hover:text-white"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Live Status Ticker */}
      <div className="flex items-center justify-between px-2 text-xs">
        <div className="flex items-center gap-2">
          <div
            className={`w-2.5 h-2.5 rounded-full ${
              activeSoundId ? 'bg-red-500 animate-ping' : 'bg-slate-600'
            }`}
          />
          <span className="font-chakra tracking-wider text-slate-300">
            {activeSound ? (
              <span className="text-red-400 font-bold">
                NOW PLAYING: <span className="text-white underline">{activeSound.name}</span>
              </span>
            ) : (
              <span className="text-slate-400">STATUS: READY • SINGLE PLAYBACK MODE</span>
            )}
          </span>
        </div>
        <div className="text-slate-400 font-mono text-[11px]">
          Showing <span className="text-cyan-400 font-bold">{filteredSounds.length}</span> of{' '}
          <span className="text-slate-300">{sounds.length}</span> sound buttons
        </div>
      </div>

      {/* Soundboard Buttons Grid */}
      {filteredSounds.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 rounded-2xl bg-[#0b0c13] border border-dashed border-slate-800 text-center">
          <AlertCircle className="w-10 h-10 text-slate-600 mb-3" />
          <h4 className="font-chakra text-lg font-bold text-slate-300">
            {sounds.length === 0 ? 'সাউন্ডবোর্ড খালি (No Sounds Yet)' : 'কোনো সাউন্ড মেলেনি'}
          </h4>
          <p className="text-xs text-slate-500 max-w-sm mt-1">
            {sounds.length === 0
              ? 'উপরের ড্রপজোনে আপনার প্রিয় গেম সাউন্ড এফেক্ট (MP3, WAV) ফাইল আপলোড করুন।'
              : `"${searchQuery}" এর সাথে কোনো সাউন্ড পাওয়া যায়নি। সার্চ ফিল্টার ক্লিয়ার করুন।`}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredSounds.map((sound) => {
            const isPlaying = activeSoundId === sound.id;

            return (
              <div
                key={sound.id}
                className={`group relative flex flex-col justify-between rounded-2xl border transition-all duration-300 overflow-hidden ${
                  isPlaying
                    ? 'border-red-500 bg-gradient-to-b from-[#2a0e14] via-[#1e0a10] to-[#120508] shadow-[0_0_25px_rgba(255,30,68,0.35)] scale-[1.02]'
                    : 'border-slate-800/80 bg-[#10121d] hover:border-cyan-500/50 hover:bg-[#141725] hover:shadow-[0_0_15px_rgba(0,229,255,0.15)]'
                }`}
              >
                {/* Top Corner Badge: Format or Duration */}
                <div className="absolute top-2.5 right-3 flex items-center gap-1.5 z-10 pointer-events-none">
                  {sound.duration ? (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-black/60 text-slate-400 border border-slate-800">
                      {Math.round(sound.duration * 10) / 10}s
                    </span>
                  ) : null}
                  {isPlaying && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold font-mono bg-red-600 text-white animate-pulse">
                      PLAYING
                    </span>
                  )}
                </div>

                {/* Big Tactile Play / Stop Touch Surface */}
                <button
                  onClick={() => toggleSound(sound)}
                  className="w-full text-left p-4 pb-3 flex flex-col justify-between min-h-[120px] transition-all relative overflow-hidden focus:outline-none"
                >
                  {/* Subtle Background Waveform Visualizer on Active */}
                  {isPlaying && (
                    <div className="absolute inset-0 flex items-end justify-center gap-1 px-4 pb-2 opacity-25 pointer-events-none">
                      {[40, 75, 95, 60, 85, 45, 90, 70, 30, 80, 50, 100].map((h, i) => (
                        <div
                          key={i}
                          className="w-1.5 bg-red-400 rounded-t animate-pulse"
                          style={{
                            height: `${h}%`,
                            animationDelay: `${(i * 0.08).toFixed(2)}s`,
                            animationDuration: '0.6s',
                          }}
                        />
                      ))}
                    </div>
                  )}

                  {/* Header Row: Play Icon + Sound Name */}
                  <div className="flex items-start gap-3 z-10">
                    <div
                      className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl transition-all ${
                        isPlaying
                          ? 'bg-red-500 text-white shadow-[0_0_15px_rgba(255,30,68,0.8)]'
                          : 'bg-[#1b1e2e] text-cyan-400 group-hover:bg-cyan-500 group-hover:text-black'
                      }`}
                    >
                      {isPlaying ? (
                        <Square className="h-5 w-5 fill-current" />
                      ) : (
                        <Play className="h-5 w-5 fill-current ml-0.5" />
                      )}
                    </div>

                    <div className="flex-1 pr-6">
                      <h3
                        className={`font-chakra font-bold text-base leading-tight transition-colors line-clamp-2 ${
                          isPlaying
                            ? 'text-red-300 drop-shadow-[0_0_8px_rgba(255,30,68,0.5)]'
                            : 'text-slate-100 group-hover:text-cyan-300'
                        }`}
                      >
                        {sound.name}
                      </h3>
                      <p className="text-[11px] text-slate-400 mt-1">
                        {isPlaying ? 'ট্যাপ করুন বন্ধ করতে (Tap to Stop)' : 'ট্যাপ করুন বাজাতে (Tap to Play)'}
                      </p>
                    </div>
                  </div>

                  {/* Bottom EQ Indicator */}
                  <div className="mt-3 flex items-center justify-between z-10">
                    <div className="flex items-center gap-1 text-[11px] font-mono text-slate-500">
                      <Activity className={`w-3.5 h-3.5 ${isPlaying ? 'text-red-400 animate-spin' : ''}`} />
                      <span>{isPlaying ? 'ACTIVE' : 'IDLE'}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono uppercase">
                      {sound.type.replace('audio/', '') || 'AUDIO'}
                    </span>
                  </div>
                </button>

                {/* Action Toolbar: Rename, Delete, Download */}
                <div className="flex items-center justify-between border-t border-slate-800/80 bg-black/40 px-3 py-2 text-xs">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingItem(sound);
                      setEditNameText(sound.name);
                    }}
                    className="flex items-center gap-1 text-slate-400 hover:text-cyan-400 transition-colors py-1 px-1.5 rounded hover:bg-white/5"
                    title="Rename Sound"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Rename</span>
                  </button>

                  <div className="flex items-center gap-1">
                    {sound.url && (
                      <a
                        href={sound.url}
                        download={`${sound.name}.mp3`}
                        onClick={(e) => e.stopPropagation()}
                        className="text-slate-400 hover:text-slate-200 p-1 rounded hover:bg-white/5"
                        title="Download audio file"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </a>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeletingItem(sound);
                      }}
                      className="text-slate-400 hover:text-red-400 p-1 rounded hover:bg-red-950/40 transition-colors"
                      title="Delete Sound"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Rename Dialog Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl border border-cyan-500/40 bg-[#0f111c] p-6 shadow-2xl">
            <h3 className="font-orbitron text-lg font-bold text-white mb-2 flex items-center gap-2">
              <Edit2 className="w-5 h-5 text-cyan-400" /> Rename Sound
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              গেমে দ্রুত চেনার সুবিধার্থে সাউন্ডের নাম পরিবর্তন করুন:
            </p>
            <input
              type="text"
              value={editNameText}
              onChange={(e) => setEditNameText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSaveRename()}
              autoFocus
              className="w-full px-4 py-3 rounded-xl bg-[#161928] border border-slate-700 text-white font-chakra text-base focus:outline-none focus:border-cyan-400 mb-5"
            />
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setEditingItem(null)}
                className="px-4 py-2 rounded-xl text-slate-400 hover:text-white font-chakra text-sm"
              >
                বাতিল (Cancel)
              </button>
              <button
                onClick={handleSaveRename}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 font-chakra font-bold text-black text-sm hover:from-cyan-400 hover:to-blue-500 shadow-[0_0_15px_rgba(0,229,255,0.4)]"
              >
                সেভ করুন (Save)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl border border-red-500/50 bg-[#110d12] p-6 shadow-2xl">
            <h3 className="font-orbitron text-lg font-bold text-red-400 mb-2 flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-red-500" /> সাউন্ড মুছবেন?
            </h3>
            <p className="text-sm text-slate-300 mb-4">
              আপনি কি নিশ্চিত যে <span className="font-bold text-white">"{deletingItem.name}"</span> সাউন্ডটি ডিলিট করতে চান?
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setDeletingItem(null)}
                className="px-4 py-2 rounded-xl text-slate-400 hover:text-white font-chakra text-sm"
              >
                বাতিল
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 font-chakra font-bold text-white text-sm shadow-[0_0_15px_rgba(255,30,68,0.5)]"
              >
                ডিলিট করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
