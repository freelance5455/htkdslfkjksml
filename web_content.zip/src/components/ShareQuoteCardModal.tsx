import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Share2, 
  Copy, 
  Download, 
  Check, 
  Sparkles, 
  ExternalLink 
} from 'lucide-react';

export const ShareQuoteCardModal: React.FC = () => {
  const { 
    isShareModalOpen, 
    setIsShareModalOpen, 
    shareTargetConfession 
  } = useApp();

  const [copied, setCopied] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isShareModalOpen || !shareTargetConfession) return null;

  const shareText = `"${shareTargetConfession.content}"\n\n— Confessed anonymously by ${shareTargetConfession.authorAvatarName} on Secret Gossip (#${shareTargetConfession.collegeCode})\nRead more secrets: https://secretgossip.app/c/${shareTargetConfession.id}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Secret Gossip Whisper',
          text: `"${shareTargetConfession.content.slice(0, 100)}..."`,
          url: window.location.href,
        });
      } catch (err) {
        handleCopyLink();
      }
    } else {
      handleCopyLink();
    }
  };

  const handleDownloadCard = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#0e111d] border border-cyan-500/40 rounded-3xl p-5 shadow-2xl shadow-cyan-900/40 relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            <h3 className="font-display font-bold text-base text-slate-100">
              Viral Story & Card Generator
            </h3>
          </div>
          <button
            onClick={() => setIsShareModalOpen(false)}
            className="p-1.5 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* The Viral Aesthetic Story Card Preview */}
        <div className="my-4">
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0c0f1d] via-[#120f26] to-[#0a1424] border border-cyan-500/40 p-6 text-slate-100 shadow-xl neon-glow-cyan">
            
            {/* Background cyber accent mesh */}
            <div className="absolute top-0 right-0 -mr-8 -mt-8 w-36 h-36 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 -ml-8 -mb-8 w-36 h-36 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />

            {/* Top Brand Watermark on Card */}
            <div className="flex items-center justify-between mb-5 relative z-10">
              <div className="flex items-center gap-2">
                <span className="text-xl">🤫</span>
                <span className="font-display font-black text-sm tracking-tight bg-gradient-to-r from-pink-400 to-cyan-400 bg-clip-text text-transparent">
                  Secret Gossip
                </span>
              </div>
              <span className="text-[10px] font-mono tracking-wider text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 rounded-full px-2 py-0.5">
                {shareTargetConfession.collegeCode}
              </span>
            </div>

            {/* Quote Mark */}
            <span className="text-4xl leading-none text-cyan-500/30 font-serif select-none block mb-1">“</span>

            {/* Confession Text */}
            <p className="text-slate-100 text-sm sm:text-base font-medium leading-relaxed my-2 relative z-10 font-sans italic">
              {shareTargetConfession.content}
            </p>

            <span className="text-4xl leading-none text-cyan-500/30 font-serif select-none block text-right mt-1">”</span>

            {/* Bottom Card Footer */}
            <div className="flex items-center justify-between pt-4 mt-2 border-t border-slate-800/80 relative z-10 text-xs">
              <div className="flex items-center gap-2">
                <span className="text-base">{shareTargetConfession.authorAvatarEmoji}</span>
                <div>
                  <p className="text-xs font-semibold text-slate-200">
                    {shareTargetConfession.authorAvatarName}
                  </p>
                  <p className="text-[10px] text-slate-400">
                    {shareTargetConfession.collegeName.split(' ')[0]}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-pink-400 font-mono">100% Anonymous</p>
                <p className="text-[9px] text-slate-500">secretgossip.app</p>
              </div>
            </div>

          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-1">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleCopyLink}
              className="py-2.5 px-3 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-cyan-500/50 text-xs font-semibold text-slate-200 transition-all flex items-center justify-center gap-1.5"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-cyan-400" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Confession'}</span>
            </button>

            <button
              onClick={handleDownloadCard}
              className="py-2.5 px-3 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-cyan-500/50 text-xs font-semibold text-slate-200 transition-all flex items-center justify-center gap-1.5"
            >
              {downloadSuccess ? <Check className="w-4 h-4 text-emerald-400" /> : <Download className="w-4 h-4 text-purple-400" />}
              <span>{downloadSuccess ? 'Card Saved!' : 'Save Story Card'}</span>
            </button>
          </div>

          <button
            onClick={handleNativeShare}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-cyan-500/25 flex items-center justify-center gap-2"
          >
            <Share2 className="w-4 h-4" />
            <span>Share to Instagram / WhatsApp</span>
          </button>
        </div>

      </div>
    </div>
  );
};
