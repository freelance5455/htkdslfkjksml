import React from 'react';
import { MessageSquare, Music, Video, Camera } from 'lucide-react';
import { ActiveTab } from '../types.ts';

interface BottomDockProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
}

export const BottomDock: React.FC<BottomDockProps> = ({ activeTab, onSelectTab }) => {
  const tabs = [
    { id: 'chat' as ActiveTab, label: 'Chat', icon: MessageSquare, emoji: '💬' },
    { id: 'music' as ActiveTab, label: 'Music', icon: Music, emoji: '🎵' },
    { id: 'video' as ActiveTab, label: 'Video', icon: Video, emoji: '🎬' },
    { id: 'photo' as ActiveTab, label: 'Photo', icon: Camera, emoji: '📸' },
  ];

  return (
    <footer className="shrink-0 bg-[#140628]/95 backdrop-blur-lg border-t border-[#d4af37]/30 px-3 py-1.5 safe-bottom z-30">
      <nav className="flex items-center justify-around max-w-lg mx-auto">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex-1 py-1 px-2 flex flex-col items-center justify-center transition-all duration-200 relative group active:scale-95 ${
                isActive ? 'text-[#fae48c]' : 'text-[#a28cb8] hover:text-[#d4af37]/80'
              }`}
            >
              {/* Active top glow indicator */}
              {isActive && (
                <span className="absolute -top-1.5 w-8 h-1 rounded-full bg-gradient-to-r from-[#d4af37] to-[#fae48c] shadow-[0_0_10px_#fae48c]" />
              )}

              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200 ${
                  isActive
                    ? 'bg-gradient-to-br from-[#d4af37]/25 to-[#fae48c]/10 text-[#fae48c] shadow-[inset_0_1px_1px_rgba(250,228,140,0.4)]'
                    : 'text-[#a28cb8]'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
              </div>

              <span
                className={`text-[11px] font-semibold tracking-wide transition-colors ${
                  isActive ? 'gold-gradient-text' : 'text-[#a28cb8]'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </nav>
    </footer>
  );
};
