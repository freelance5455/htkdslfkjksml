import React from 'react';
import { Search, X, Loader2 } from 'lucide-react';

export interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  onClear?: () => void;
  isLoading?: boolean;
  autoFocus?: boolean;
  onSubmit?: () => void;
  resultCount?: number;
  size?: 'sm' | 'md' | 'lg';
}

export const SearchBar: React.FC<SearchBarProps> = ({
  value,
  onChange,
  placeholder = 'Search events, venues, or cities...',
  className = '',
  onClear,
  isLoading = false,
  autoFocus = false,
  onSubmit,
  resultCount,
  size = 'md',
}) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && onSubmit) {
      e.preventDefault();
      onSubmit();
    }
    if (e.key === 'Escape' && value) {
      e.preventDefault();
      if (onClear) onClear();
      else onChange('');
    }
  };

  const handleClear = () => {
    if (onClear) {
      onClear();
    } else {
      onChange('');
    }
  };

  const sizeClasses =
    size === 'sm'
      ? 'h-9 pl-9 pr-14 text-xs rounded-xl'
      : size === 'lg'
      ? 'h-13 sm:h-14 pl-12 pr-24 text-sm sm:text-base rounded-2xl'
      : 'h-11 sm:h-12 pl-10 sm:pl-11 pr-20 text-xs sm:text-sm rounded-2xl';

  const iconLeftClass = size === 'sm' ? 'left-2.5' : size === 'lg' ? 'left-4' : 'left-3.5 sm:left-4';
  const iconSizeClass = size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4';

  return (
    <div className={`relative flex items-center w-full ${className}`}>
      {/* Search Icon or Loading Spinner */}
      <div className={`absolute ${iconLeftClass} pointer-events-none text-neutral-400 dark:text-neutral-500 flex items-center justify-center`}>
        {isLoading ? (
          <Loader2 className={`${iconSizeClass} animate-spin text-emerald-500`} />
        ) : (
          <Search className={`${iconSizeClass} transition-colors`} />
        )}
      </div>

      {/* Input Field */}
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        autoFocus={autoFocus}
        className={`w-full ${sizeClasses} text-neutral-900 dark:text-white bg-white dark:bg-neutral-900/90 border border-neutral-200/80 dark:border-neutral-800 shadow-2xs hover:border-neutral-300 dark:hover:border-neutral-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500/60 dark:focus:border-emerald-400/60 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 transition-all font-normal`}
      />

      {/* Trailing actions: Results count badge + Clear button */}
      <div className="absolute right-2.5 flex items-center gap-1.5">
        {resultCount !== undefined && value.trim().length > 0 && (
          <span className="text-[10px] font-mono font-bold text-neutral-400 dark:text-neutral-500 px-1.5 py-0.5 rounded-md bg-neutral-100 dark:bg-neutral-800">
            {resultCount}
          </span>
        )}

        {value && (
          <button
            type="button"
            onClick={handleClear}
            className="w-6 h-6 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 flex items-center justify-center text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 transition-colors cursor-pointer"
            title="Clear search"
            aria-label="Clear search"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
