import type { ReactNode } from 'react';
import { cn } from '../../utils/format';

export function Card({
  children,
  className,
  as: Tag = 'div',
}: {
  children: ReactNode;
  className?: string;
  as?: 'div' | 'section' | 'article' | 'li';
}) {
  return <Tag className={cn('card p-4 sm:p-5', className)}>{children}</Tag>;
}

export function SectionHeader({
  title,
  hint,
  action,
  className,
}: {
  title: string;
  hint?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('mb-3 flex items-end justify-between gap-3', className)}>
      <div>
        <h2 className="font-display text-lg text-[var(--ink)] sm:text-xl">{title}</h2>
        {hint ? <p className="mt-0.5 text-xs text-[var(--ink-soft)]">{hint}</p> : null}
      </div>
      {action}
    </div>
  );
}

export function ProgressBar({
  value,
  color,
  height = 8,
  label,
  className,
}: {
  value: number;
  color?: string;
  height?: number;
  label?: string;
  className?: string;
}) {
  const safe = Math.max(0, Math.min(100, value));
  return (
    <div
      className={cn('w-full overflow-hidden rounded-full bg-[var(--surface-2)]', className)}
      style={{ height }}
      role="progressbar"
      aria-valuenow={Math.round(safe)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label ?? 'نسبة الإنجاز'}
    >
      <div
        className="h-full rounded-full transition-[width] duration-500 ease-out"
        style={{
          width: `${safe}%`,
          background: color ?? 'linear-gradient(90deg, var(--gold), #f7d089)',
        }}
      />
    </div>
  );
}

export function Chip({
  children,
  active,
  onClick,
  className,
}: {
  children: ReactNode;
  active?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  const base = cn(
    'focus-ring inline-flex h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-3 text-xs font-medium transition-colors',
    active
      ? 'border-transparent bg-[var(--brand)] text-[var(--brand-ink)]'
      : 'border-[var(--line)] bg-[var(--surface)] text-[var(--ink-soft)] hover:text-[var(--ink)]',
    className,
  );
  if (!onClick) return <span className={cn(base, className)}>{children}</span>;
  return (
    <button type="button" onClick={onClick} className={cn(base, className)} aria-pressed={active}>
      {children}
    </button>
  );
}
