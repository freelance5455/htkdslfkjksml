import { useEffect, type ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { cn } from '../../utils/format';

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn('animate-pulse rounded-xl bg-[var(--surface-2)]', className)}
      aria-hidden="true"
    />
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center rounded-3xl border border-dashed border-[var(--line)] px-6 py-10 text-center',
        className,
      )}
    >
      {icon ? (
        <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--surface-2)] text-[var(--ink-soft)]">
          {icon}
        </div>
      ) : null}
      <p className="font-display text-base text-[var(--ink)]">{title}</p>
      {description ? (
        <p className="mt-1 max-w-sm text-sm leading-relaxed text-[var(--ink-soft)]">{description}</p>
      ) : null}
      {action ? <div className="mt-4">{action}</div> : null}
    </div>
  );
}

export function Badge({
  children,
  tone = 'neutral',
  className,
}: {
  children: ReactNode;
  tone?: 'neutral' | 'gold' | 'success' | 'danger' | 'brand';
  className?: string;
}) {
  const tones: Record<string, string> = {
    neutral: 'bg-[var(--surface-2)] text-[var(--ink-soft)]',
    gold: 'bg-[var(--gold-soft)] text-[#8a5b06]',
    success: 'bg-[#e6f7ef] text-[#0b6b4f] dark:bg-[#0e3a2f] dark:text-[#6fe3bd]',
    danger: 'bg-[#fdece2] text-[#a63a12] dark:bg-[#3a1c12] dark:text-[#f5a67f]',
    brand: 'bg-[var(--brand)] text-[var(--brand-ink)]',
  };
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[0.68rem] font-medium',
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  size = 'md',
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'md' | 'lg';
}) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          className="fixed inset-0 z-[80] flex items-end justify-center bg-black/45 p-0 backdrop-blur-[2px] sm:items-center sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          role="presentation"
        >
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={title ?? 'نافذة'}
            initial={{ y: 24, opacity: 0.9, scale: 0.99 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 16, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 320, damping: 32 }}
            onClick={(e) => e.stopPropagation()}
            className={cn(
              'max-h-[88dvh] w-full overflow-y-auto rounded-t-3xl bg-[var(--surface)] p-5 shadow-2xl sm:rounded-3xl',
              size === 'lg' ? 'sm:max-w-2xl' : 'sm:max-w-md',
            )}
          >
            <div className="mb-3 flex items-center justify-between gap-3">
              {title ? <h3 className="font-display text-base text-[var(--ink)]">{title}</h3> : <span />}
              <button
                type="button"
                onClick={onClose}
                aria-label="إغلاق"
                className="focus-ring -me-1 flex h-9 w-9 items-center justify-center rounded-full text-[var(--ink-soft)] hover:bg-[var(--surface-2)]"
              >
                ✕
              </button>
            </div>
            {children}
            {footer ? <div className="mt-4">{footer}</div> : null}
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
