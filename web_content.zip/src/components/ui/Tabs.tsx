import { motion } from 'framer-motion';
import { cn } from '../../utils/format';

export interface TabItem {
  id: string;
  label: string;
  badge?: number | string;
}

export function Tabs({
  items,
  value,
  onChange,
  className,
}: {
  items: TabItem[];
  value: string;
  onChange: (id: string) => void;
  className?: string;
}) {
  return (
    <div
      className={cn('no-scrollbar -mx-1 flex gap-1 overflow-x-auto px-1', className)}
      role="tablist"
      aria-label="تبويبات"
    >
      {items.map((item) => {
        const active = item.id === value;
        return (
          <button
            key={item.id}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(item.id)}
            className={cn(
              'focus-ring relative shrink-0 rounded-full px-3.5 py-2 text-[0.82rem] font-medium transition-colors',
              active ? 'text-[var(--brand-ink)]' : 'text-[var(--ink-soft)] hover:text-[var(--ink)]',
            )}
          >
            {active ? (
              <motion.span
                layoutId="tab-pill"
                className="absolute inset-0 rounded-full bg-[var(--brand)]"
                transition={{ type: 'spring', stiffness: 380, damping: 34 }}
              />
            ) : null}
            <span className="relative z-10 whitespace-nowrap">
              {item.label}
              {item.badge !== undefined && item.badge !== 0 ? (
                <span
                  className={cn(
                    'ms-1.5 rounded-full px-1.5 py-0.5 text-[0.65rem]',
                    active ? 'bg-white/20' : 'bg-[var(--surface-2)] text-[var(--ink-soft)]',
                  )}
                >
                  {item.badge}
                </span>
              ) : null}
            </span>
          </button>
        );
      })}
    </div>
  );
}
