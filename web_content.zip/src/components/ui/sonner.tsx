import { Toaster as Sonner } from "sonner";

export function Toaster() {
  return (
    <Sonner
      theme="dark"
      position="bottom-center"
      toastOptions={{
        classNames: {
          toast: "bg-elevated text-fg border-border shadow-[var(--shadow-float)]",
        },
      }}
    />
  );
}
