import { Toaster as Sonner } from "sonner";

function Toaster() {
  return (
    <Sonner
      theme="dark"
      position="bottom-center"
      toastOptions={{
        classNames: {
          toast: "bg-card text-card-foreground shadow-border border-0",
          description: "text-muted-foreground",
        },
      }}
    />
  );
}

export { Toaster };
