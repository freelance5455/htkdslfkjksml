"use client";

import type { SVGProps } from "react";

export type IconName =
  | "home"
  | "ledger"
  | "calendar"
  | "chart"
  | "bolt"
  | "settings"
  | "plus"
  | "minus"
  | "up"
  | "down"
  | "lock"
  | "key"
  | "trash"
  | "download"
  | "upload"
  | "sun"
  | "moon"
  | "monitor"
  | "check"
  | "close"
  | "left"
  | "right"
  | "chevron"
  | "google"
  | "spark"
  | "wallet"
  | "shield"
  | "edit"
  | "user"
  | "logout"
  | "refresh"
  | "alert"
  | "clock"
  | "droplet"
  | "flame"
  | "wifi"
  | "house"
  | "phone"
  | "bank"
  | "sliders"
  | "search"
  | "eye"
  | "coins"
  | "target"
  | "info"
  | "food"
  | "car"
  | "bag"
  | "heart"
  | "ticket"
  | "book"
  | "chip"
  | "dots"
  | "case"
  | "laptop"
  | "store"
  | "trend"
  | "gift"
  | "undo"
  | "calendarPlus"
  | "finger"
  | "backspace";

const P: Record<IconName, string> = {
  home: "M4 10.6 12 4l8 6.6V20a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z",
  ledger:
    "M6 3h9l4 4v14H6zM9 9h6M9 13h6M9 17h4M15 3v4h4",
  calendar: "M4 6.5h16V20H4zM4 10.5h16M8.5 3.5v4M15.5 3.5v4",
  chart: "M4 20V4M4 20h16M8 17V11M12.5 17V7M17 17v-4",
  bolt: "M13.5 3 6 13.2h4.4L10 21l7.6-10.4h-4.5z",
  settings:
    "M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4M4 12h2.2M17.8 12H20M12 4v2.2M12 17.8V20M6.3 6.3l1.6 1.6M16.1 16.1l1.6 1.6M17.7 6.3l-1.6 1.6M7.9 16.1l-1.6 1.6",
  plus: "M12 5v14M5 12h14",
  minus: "M5 12h14",
  up: "M12 19V6M6.5 11.5 12 5.5l5.5 6",
  down: "M12 5v13M6.5 12.5 12 18.5l5.5-6",
  lock: "M6.5 10.5h11V20h-11zM8.8 10.5V7.8a3.2 3.2 0 0 1 6.4 0v2.7M12 14.2v2.6",
  key: "M15.5 3.5a5 5 0 1 1-3.3 8.8L4 20.5l-1-3 8.2-8.2A5 5 0 0 1 15.5 3.5M16 8h.01",
  trash: "M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13M10.5 10.5v6M13.5 10.5v6",
  download: "M12 4v10.5M7.5 10.5 12 15l4.5-4.5M5 19h14",
  upload: "M12 15.5V5M7.5 9 12 4.5 16.5 9M5 19h14",
  sun: "M12 16.5a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M18.7 5.3l-1.4 1.4M6.7 17.3l-1.4 1.4",
  moon: "M20 14.2A8.2 8.2 0 0 1 9.8 4a8.4 8.4 0 1 0 10.2 10.2",
  monitor: "M3.5 5h17v11h-17zM8.5 20h7M12 16v4",
  check: "M5 12.8 9.6 17.4 19 7.6",
  close: "M6 6l12 12M18 6 6 18",
  left: "M14.5 5.5 8 12l6.5 6.5",
  right: "M9.5 5.5 16 12l-6.5 6.5",
  chevron: "M6.5 9.5 12 15l5.5-5.5",
  google:
    "M12 4.6c1.9 0 3.6.7 4.9 1.9l2.6-2.6A9.6 9.6 0 0 0 12 2a10 10 0 1 0 9.7 12.5H12v-3.6h6.2A6.4 6.4 0 1 1 12 4.6",
  spark: "M12 3.5 13.8 9 19.5 10.8 13.8 12.6 12 18.2 10.2 12.6 4.5 10.8 10.2 9zM18.5 17l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z",
  wallet: "M3.5 7.5A2 2 0 0 1 5.5 5.5h11a2 2 0 0 1 2 2M3.5 7.5v10a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2v-3M3.5 7.5h15.9a1 1 0 0 1 1 1v2.2a1 1 0 0 1-1 1H17a2.2 2.2 0 1 1 0-4.2h3.4M17.4 12h.01",
  shield: "M12 3.5 19 6v6c0 4-3 7-7 8.5C8 19 5 16 5 12V6zM9.4 12.2l1.9 1.9 3.5-3.7",
  edit: "M4.5 19.5h4L19 9a2.5 2.5 0 0 0-3.5-3.5L5 16v3.5M14.5 6.8l3 3",
  user: "M12 12.2a3.8 3.8 0 1 0 0-7.6 3.8 3.8 0 0 0 0 7.6M4.8 20c1-3.4 3.8-5.2 7.2-5.2s6.2 1.8 7.2 5.2",
  logout: "M15 8V5.5H4.5v13H15V16M9.5 12H20M16.5 8.5 20 12l-3.5 3.5",
  refresh: "M20 12a8 8 0 1 1-2.6-5.9M20 4v4.5h-4.5",
  alert: "M12 4.5 21 19.5H3zM12 10v4M12 16.8h.01",
  clock: "M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17M12 7.5V12l3 2",
  droplet: "M12 3.5s6 6.2 6 10.1a6 6 0 0 1-12 0C6 9.7 12 3.5 12 3.5",
  flame: "M12 3s1.5 3.2-.8 5.6C9 11 8 12.4 8 14.4a4 4 0 0 0 8 0c0-1.4-.6-2.6-1.4-3.6.6 2.4-.8 3-1.6 2.6 1-2.6-.6-5.6-1-6.4-.4 1.6-1.4 2-2 3 .2-3 2-4.4 2-7",
  wifi: "M4 9.5a12 12 0 0 1 16 0M7 13a7.5 7.5 0 0 1 10 0M10 16.4a3 3 0 0 1 4 0M12 19.8h.01",
  house: "M4 10.6 12 4l8 6.6V20a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1zM9.5 21v-6h5v6",
  phone: "M7.5 3h9v18h-9zM11 18.5h2",
  bank: "M4 10h16M12 3.5 21 9H3zM6.5 10v8M10 10v8M14 10v8M17.5 10v8M4 21h16",
  sliders: "M5 7h9M17.5 7H19M5 12h3M11.5 12H19M5 17h9M17.5 17H19M15.5 4.8v4.4M7 9.8v4.4M15.5 14.8v4.4",
  search: "M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14M16.2 16.2 21 21",
  eye: "M2.8 12S6.5 5.8 12 5.8 21.2 12 21.2 12 17.5 18.2 12 18.2 2.8 12 2.8 12M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6",
  coins: "M9 11.5c3 0 5.5-1.1 5.5-2.5S12 6.5 9 6.5 3.5 7.6 3.5 9s2.5 2.5 5.5 2.5M3.5 9v6c0 1.4 2.5 2.5 5.5 2.5s5.5-1.1 5.5-2.5V9M14.5 12.4c2.9.1 6 1.2 6 2.6 0 1.4-2.5 2.5-5.5 2.5-1.6 0-3-.3-4-.8M15 9.4c1.3-.3 3-.1 3.5.6",
  target: "M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8M12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2",
  info: "M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17M12 11v5.5M12 7.8h.01",
  food: "M6 3.5v6a2.6 2.6 0 0 0 5.2 0v-6M8.6 9.5V20M16.5 3.5c1.6 1 2.4 2.6 2.4 4.6 0 2.2-1 3.6-2.4 4v8",
  car: "M4.5 16.5v2.2h2.6v-2.2M16.9 16.5v2.2h2.6v-2.2M3.5 16.5h17v-4l-1.6-1-1.8-4A1.6 1.6 0 0 0 15.6 6H8.4a1.6 1.6 0 0 0-1.5 1.5l-1.8 4-1.6 1zM6.8 14.2h.01M17.2 14.2h.01M7.2 10.4h9.6",
  bag: "M5.5 8h13l1 12.5h-15zM9 8V6a3 3 0 0 1 6 0v2",
  heart: "M12 20s-7.5-4.4-7.5-9.4A4.1 4.1 0 0 1 12 7.6a4.1 4.1 0 0 1 7.5 3c0 5-7.5 9.4-7.5 9.4",
  ticket: "M4 8.5h16v3a2 2 0 0 0 0 4v-3M4 12.5v3M4 8.5V12M20 8.5V12M8 12h6",
  book: "M5 4.5h9.5a3 3 0 0 1 3 3V20H8a3 3 0 0 1-3-3zM5 17.5h12.5",
  chip: "M7.5 7.5h9v9h-9zM9.5 4v3.5M14.5 4v3.5M9.5 16.5V20M14.5 16.5V20M4 9.5h3.5M4 14.5h3.5M16.5 9.5H20M16.5 14.5H20",
  dots: "M6.5 12h.01M12 12h.01M17.5 12h.01",
  case: "M3.5 8.5h17V19h-17zM9 8.5V6a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 6v2.5M3.5 13h17",
  laptop: "M4.5 6h15v9.5h-15zM2.5 18.5h19",
  store: "M4 9.5h16V20H4zM4 9.5 5.6 4.5h12.8L20 9.5M9.5 20v-5h5v5M4 9.5a2.4 2.4 0 0 0 4 0 2.4 2.4 0 0 0 4 0 2.4 2.4 0 0 0 4 0 2.4 2.4 0 0 0 4 0",
  trend: "M4 16.5 9.5 11l3.5 3.5L20 7.5M20 7.5h-4.5M20 7.5V12",
  gift: "M4.5 9.5h15V20h-15zM4.5 14h15M12 9.5V20M12 9.5S10.8 5 8.6 5a2.1 2.1 0 0 0 0 4.5M12 9.5s1.2-4.5 3.4-4.5a2.1 2.1 0 0 1 0 4.5",
  undo: "M8 9.5H4.5V6M4.8 9.8A8 8 0 1 1 12 20a8 8 0 0 1-6.4-3.2",
  calendarPlus: "M4 6.5h16V20H4zM4 10.5h16M8.5 3.5v4M15.5 3.5v4M12 13v4.5M9.8 15.2h4.4",
  finger:
    "M12 4.5a7.5 7.5 0 0 1 7.5 7.5v2M12 4.5A7.5 7.5 0 0 0 4.5 12v3.5M12 8a4 4 0 0 1 4 4v3.5c0 2-.6 3.6-1.6 5M12 8a4 4 0 0 0-4 4v2.8c0 2.4.8 4.4 2 6M12 11.6a.5.5 0 0 1 .5.5V19a4 4 0 0 1-.9 2.5",
  backspace: "M9 5.5h11v13H9L2.5 12zM13 9.5l5 5M18 9.5l-5 5",
};

interface Props extends Omit<SVGProps<SVGSVGElement>, "name"> {
  name: IconName;
  size?: number;
  filled?: boolean;
}

export function Icon({ name, size = 20, filled, className, ...rest }: Props) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className={className}
      {...rest}
    >
      <path d={P[name]} />
    </svg>
  );
}

export const CATEGORY_ICON: Record<string, IconName> = {
  Food: "food",
  Transport: "car",
  Shopping: "bag",
  Bills: "bolt",
  Health: "heart",
  Fun: "ticket",
  Home: "house",
  Education: "book",
  Tech: "chip",
  Other: "dots",
  Salary: "case",
  Freelance: "laptop",
  Business: "store",
  Investment: "trend",
  Gift: "gift",
  Refund: "undo",
  Electricity: "bolt",
  Water: "droplet",
  Fuel: "flame",
  Internet: "wifi",
  Rent: "house",
  Phone: "phone",
  Insurance: "shield",
  Subscription: "ticket",
  Loan: "bank",
  Custom: "sliders",
};
