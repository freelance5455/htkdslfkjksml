import * as React from "react";
import { cn } from "@/lib/utils";

export const Textarea = React.forwardRef<HTMLTextAreaElement, React.ComponentProps<"textarea">>(
  ({ className, ...props }, ref) => (
    <textarea
      ref={ref}
      className={cn(
        "min-h-48 w-full resize-y rounded-xl bg-ink-2 px-4 py-3 text-base leading-relaxed text-cream shadow-border",
        "placeholder:text-muted outline-none transition-[box-shadow] duration-150",
        "focus-visible:shadow-ring",
        className,
      )}
      {...props}
    />
  ),
);
Textarea.displayName = "Textarea";
