import { cn } from "@/lib/utils";

export function ProgressBar({
  value,
  max = 200,
  className,
  delayMs = 0,
}: {
  value: number;
  max?: number;
  className?: string;
  delayMs?: number;
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div className={cn("h-2 w-full overflow-hidden rounded-full bg-surface-2/80", className)}>
      <div
        className="bar-fill h-full rounded-full bg-primary"
        style={{ width: `${pct}%`, animationDelay: `${delayMs}ms` }}
      />
    </div>
  );
}
