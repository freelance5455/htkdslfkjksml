import { cn } from "@/lib/utils";
import type { ButtonHTMLAttributes, HTMLAttributes } from "react";

export function Card({
  className,
  accent,
  ...props
}: HTMLAttributes<HTMLDivElement> & { accent?: "gold" | "teal" | "ok" | "warn" | "line" }) {
  const ring =
    accent === "teal"
      ? "shadow-[0_0_0_1px_rgba(106,143,138,0.45)]"
      : accent === "ok"
        ? "shadow-[0_0_0_1px_rgba(125,155,115,0.4)]"
        : accent === "warn"
          ? "shadow-[0_0_0_1px_rgba(196,160,90,0.45)]"
          : accent === "line"
            ? "shadow-[0_0_0_1px_rgba(255,255,255,0.08)]"
            : "shadow-[0_0_0_1px_rgba(198,161,91,0.28)]";
  return (
    <div
      className={cn("rounded-[20px] bg-surface p-4", ring, className)}
      {...props}
    />
  );
}

export function Btn({
  className,
  variant = "primary",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "gold" | "danger" }) {
  const v =
    variant === "ghost"
      ? "bg-surface-2 text-ivory"
      : variant === "danger"
        ? "bg-danger text-ivory"
        : variant === "gold"
          ? "bg-gold text-bg"
          : "bg-ivory text-bg";
  return (
    <button
      className={cn(
        "press inline-flex min-h-11 items-center justify-center gap-2 rounded-[12px] px-4 text-[15px] font-medium",
        "disabled:opacity-40",
        v,
        className,
      )}
      {...props}
    />
  );
}

export function Badge({
  status,
  children,
}: {
  status: "active" | "stable" | "late" | "neutral";
  children: string;
}) {
  const c =
    status === "active"
      ? "bg-ok/20 text-ok"
      : status === "late"
        ? "bg-warn/20 text-warn"
        : status === "stable"
          ? "bg-white/8 text-muted"
          : "bg-white/8 text-muted";
  return (
    <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-semibold tracking-[0.12em]", c)}>
      {children}
    </span>
  );
}
