"use client";

import { AnimatePresence, motion } from "framer-motion";
import type { ReactNode } from "react";
import { useEffect } from "react";
import { Icon, type IconName } from "./Icon";
import { pushToast, useToasts } from "@/lib/toast";

export { pushToast };

/* ------------------------------- buttons ------------------------------- */

type BtnVariant = "brand" | "outline" | "ghost" | "soft" | "danger" | "earn" | "spend";
type BtnSize = "sm" | "md" | "lg";

const VARIANTS: Record<BtnVariant, string> = {
  brand: "bg-brand text-brandink hover:brightness-105 shadow-[0_10px_30px_-12px_var(--c-brand)]",
  outline: "border border-line text-ink hover:bg-surface2",
  ghost: "text-ink2 hover:text-ink hover:bg-surface2",
  soft: "bg-surface2 text-ink border border-line hover:border-ink3",
  danger: "bg-spend/15 text-spend border border-spend/35 hover:bg-spend/25",
  earn: "bg-earn/15 text-earn border border-earn/35 hover:bg-earn/25",
  spend: "bg-spend/15 text-spend border border-spend/35 hover:bg-spend/25",
};

const SIZES: Record<BtnSize, string> = {
  sm: "h-9 px-3 text-[13px] rounded-xl gap-1.5",
  md: "h-11 px-4 text-sm rounded-2xl gap-2",
  lg: "h-13 px-5 text-[15px] rounded-2xl gap-2",
};

export function Btn({
  children,
  onClick,
  variant = "soft",
  size = "md",
  icon,
  iconRight,
  full,
  disabled,
  type = "button",
  className = "",
  title,
}: {
  children?: ReactNode;
  onClick?: () => void;
  variant?: BtnVariant;
  size?: BtnSize;
  icon?: IconName;
  iconRight?: IconName;
  full?: boolean;
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
  title?: string;
}) {
  return (
    <motion.button
      type={type}
      title={title}
      whileTap={disabled ? undefined : { scale: 0.96 }}
      transition={{ type: "spring", stiffness: 500, damping: 30 }}
      onClick={disabled ? undefined : onClick}
      className={`press inline-flex items-center justify-center font-semibold tracking-[-0.01em] disabled:cursor-not-allowed disabled:opacity-40 ${
        VARIANTS[variant]
      } ${SIZES[size]} ${full ? "w-full" : ""} ${className}`}
    >
      {icon ? <Icon name={icon} size={size === "sm" ? 15 : 17} /> : null}
      {children}
      {iconRight ? <Icon name={iconRight} size={size === "sm" ? 15 : 17} /> : null}
    </motion.button>
  );
}

export function IconBtn({
  name,
  onClick,
  label,
  active,
  tone = "default",
  size = 40,
}: {
  name: IconName;
  onClick?: () => void;
  label: string;
  active?: boolean;
  tone?: "default" | "danger";
  size?: number;
}) {
  return (
    <motion.button
      type="button"
      aria-label={label}
      title={label}
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
      className={`press grid place-items-center rounded-full border ${
        active
          ? "border-brand/60 bg-brand/15 text-brandtext"
          : tone === "danger"
            ? "border-line bg-surface2 text-spend hover:border-spend/40"
            : "border-line bg-surface2 text-ink2 hover:text-ink"
      }`}
      style={{ width: size, height: size }}
    >
      <Icon name={name} size={size > 36 ? 19 : 16} />
    </motion.button>
  );
}

/* ------------------------------- layout -------------------------------- */

export function Screen({
  title,
  subtitle,
  right,
  onBack,
  children,
  pad = true,
}: {
  title: string;
  subtitle?: ReactNode;
  right?: ReactNode;
  onBack?: () => void;
  children: ReactNode;
  pad?: boolean;
}) {
  return (
    <div className="flex h-full flex-col">
      <header
        className={`sticky top-0 z-20 shrink-0 border-b border-line/70 bg-bg/80 px-4 pb-3 pt-4 backdrop-blur-xl ${
          pad ? "" : ""
        }`}
      >
        <div className="flex items-center gap-3">
          {onBack ? (
            <IconBtn name="left" label="Go back" onClick={onBack} size={36} />
          ) : null}
          <div className="min-w-0 flex-1">
            <h1 className="truncate font-display text-[22px] font-extrabold leading-tight tracking-[-0.02em]">
              {title}
            </h1>
            {subtitle ? (
              <p className="truncate font-mono text-[11px] uppercase tracking-[0.14em] text-ink3">
                {subtitle}
              </p>
            ) : null}
          </div>
          {right}
        </div>
      </header>
      <div className="thin-scroll min-h-0 flex-1 overflow-y-auto overscroll-contain">{children}</div>
    </div>
  );
}

export function Card({
  children,
  className = "",
  onClick,
  highlight,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  highlight?: boolean;
}) {
  const Comp: any = onClick ? motion.div : "div";
  return (
    <Comp
      onClick={onClick}
      whileTap={onClick ? { scale: 0.985 } : undefined}
      className={`${highlight ? "card-hi" : "card"} ${onClick ? "press cursor-pointer" : ""} ${className}`}
    >
      {children}
    </Comp>
  );
}

export function SectionTitle({
  children,
  action,
  className = "",
}: {
  children: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={`mb-2.5 flex items-end justify-between gap-3 ${className}`}>
      <h2 className="font-display text-[15px] font-bold uppercase tracking-[0.1em] text-ink2">
        {children}
      </h2>
      {action}
    </div>
  );
}

export function Chip({
  children,
  tone = "neutral",
  active,
  onClick,
  icon,
}: {
  children: ReactNode;
  tone?: "neutral" | "earn" | "spend" | "bill" | "brand";
  active?: boolean;
  onClick?: () => void;
  icon?: IconName;
}) {
  const tones: Record<string, string> = {
    neutral: "border-line bg-surface2 text-ink2",
    earn: "border-earn/35 bg-earn/12 text-earn",
    spend: "border-spend/35 bg-spend/12 text-spend",
    bill: "border-bill/35 bg-bill/12 text-bill",
    brand: "border-brand/45 bg-brand/15 text-brandtext",
  };
  return (
    <motion.span
      whileTap={onClick ? { scale: 0.94 } : undefined}
      onClick={onClick}
      className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[10.5px] uppercase tracking-[0.12em] ${
        active ? "border-brand bg-brand text-brandink" : tones[tone]
      } ${onClick ? "press cursor-pointer" : ""}`}
    >
      {icon ? <Icon name={icon} size={12} /> : null}
      {children}
    </motion.span>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  id,
  className = "",
}: {
  options: { value: T; label: string; icon?: IconName }[];
  value: T;
  onChange: (v: T) => void;
  id: string;
  className?: string;
}) {
  return (
    <div
      className={`relative flex rounded-2xl border border-line bg-surface2 p-1 ${className}`}
      role="tablist"
    >
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(o.value)}
            className={`press relative z-10 flex flex-1 items-center justify-center gap-1.5 rounded-xl px-2 py-2 text-[12.5px] font-bold transition-colors ${
              active ? "text-brandink" : "text-ink2 hover:text-ink"
            }`}
          >
            {active ? (
              <motion.span
                layoutId={`seg-${id}`}
                transition={{ type: "spring", stiffness: 480, damping: 38 }}
                className="absolute inset-0 z-[-1] rounded-xl bg-brand"
              />
            ) : null}
            {o.icon ? <Icon name={o.icon} size={14} /> : null}
            <span className="truncate">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`press relative h-7 w-12 shrink-0 rounded-full border transition-colors ${
        checked ? "border-brand bg-brand" : "border-line bg-surface2"
      }`}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 600, damping: 34 }}
        className={`absolute top-1/2 h-5 w-5 -translate-y-1/2 rounded-full shadow ${
          checked ? "bg-brandink" : "bg-ink3"
        }`}
        style={{ left: checked ? 26 : 4 }}
      />
    </button>
  );
}

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink3">
        {label}
      </span>
      {children}
      {hint ? <span className="mt-1 block text-[11.5px] text-ink3">{hint}</span> : null}
    </label>
  );
}

export function EmptyState({
  icon,
  title,
  body,
  action,
}: {
  icon: IconName;
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="card flex flex-col items-center gap-3 px-6 py-10 text-center">
      <div className="grid h-14 w-14 place-items-center rounded-2xl border border-line bg-surface2 text-ink3">
        <Icon name={icon} size={24} />
      </div>
      <div>
        <p className="font-display text-[17px] font-bold">{title}</p>
        <p className="mx-auto mt-1 max-w-[34ch] text-[13px] leading-relaxed text-ink2">{body}</p>
      </div>
      {action}
    </div>
  );
}

export function Progress({
  value,
  tone = "brand",
  height = 6,
}: {
  value: number;
  tone?: "brand" | "earn" | "spend" | "bill";
  height?: number;
}) {
  const colors: Record<string, string> = {
    brand: "var(--c-brand)",
    earn: "var(--c-earn)",
    spend: "var(--c-spend)",
    bill: "var(--c-bill)",
  };
  return (
    <div
      className="w-full overflow-hidden rounded-full bg-surface2"
      style={{ height, border: "1px solid var(--c-line)" }}
    >
      <div
        className="h-full rounded-full transition-[width] duration-700 ease-out"
        style={{
          width: `${Math.max(0, Math.min(100, value))}%`,
          background: colors[tone],
          boxShadow: `0 0 14px ${colors[tone]}`,
        }}
      />
    </div>
  );
}

/* -------------------------------- sheet -------------------------------- */

export function Sheet({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open ? (
        <motion.div className="absolute inset-0 z-50 flex flex-col justify-end" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-[3px]"
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
          <motion.div
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.6 }}
            onDragEnd={(_, info) => {
              if (info.offset.y > 90) onClose();
            }}
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 420, damping: 40 }}
            className="relative flex max-h-[92%] flex-col rounded-t-[26px] border border-line bg-bg shadow-[0_-30px_80px_-20px_var(--c-shadow)]"
          >
            <div className="flex items-start gap-3 px-5 pb-2 pt-3">
              <div className="flex-1">
                <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-ink3/50" />
                <h3 className="font-display text-[19px] font-extrabold tracking-[-0.02em]">{title}</h3>
                {subtitle ? (
                  <p className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-ink3">
                    {subtitle}
                  </p>
                ) : null}
              </div>
              <IconBtn name="close" label="Close" onClick={onClose} size={34} />
            </div>
            <div className="thin-scroll min-h-0 flex-1 overflow-y-auto px-5 pb-4">{children}</div>
            {footer ? (
              <div className="shrink-0 border-t border-line bg-bg/95 px-5 py-3 pb-safe">{footer}</div>
            ) : null}
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

/* -------------------------------- toasts ------------------------------- */

export function Toaster() {
  const toasts = useToasts();
  return (
    <div className="pointer-events-none absolute inset-x-0 top-2 z-[60] flex flex-col items-center gap-2 px-4">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            layout
            initial={{ opacity: 0, y: -18, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.96 }}
            transition={{ type: "spring", stiffness: 420, damping: 32 }}
            className={`pointer-events-auto flex max-w-full items-center gap-2 rounded-full border px-3.5 py-2 text-[12.5px] font-semibold shadow-lg backdrop-blur-xl ${
              t.tone === "earn"
                ? "border-earn/40 bg-earn/15 text-earn"
                : t.tone === "spend"
                  ? "border-spend/40 bg-spend/15 text-spend"
                  : t.tone === "error"
                    ? "border-spend/50 bg-spend/20 text-spend"
                    : "border-line bg-surface2/95 text-ink"
            }`}
          >
            <Icon
              name={
                t.tone === "error" ? "alert" : t.tone === "earn" ? "up" : t.tone === "spend" ? "down" : "spark"
              }
              size={14}
            />
            <span className="truncate">{t.text}</span>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------ confirm -------------------------------- */

export function Confirm({
  open,
  title,
  body,
  confirmLabel = "Confirm",
  tone = "danger",
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  body: string;
  confirmLabel?: string;
  tone?: "danger" | "brand";
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <Sheet open={open} onClose={onCancel} title={title} subtitle="This needs your confirmation">
      <p className="mb-5 text-[13.5px] leading-relaxed text-ink2">{body}</p>
      <div className="flex gap-2">
        <Btn variant="outline" full onClick={onCancel}>
          Cancel
        </Btn>
        <Btn variant={tone === "danger" ? "danger" : "brand"} full onClick={onConfirm}>
          {confirmLabel}
        </Btn>
      </div>
    </Sheet>
  );
}
