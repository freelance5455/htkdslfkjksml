import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-bg hover:opacity-90",
        ghost:
          "bg-transparent text-fg hover:bg-primary/10",
        outline:
          "bg-transparent text-primary shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_40%,transparent)] hover:bg-primary/10",
        hud: "bg-surface-2 text-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_28%,transparent)] hover:bg-surface",
      },
      size: {
        default: "h-11 rounded-md px-4 text-base",
        sm: "h-9 rounded-sm px-3 text-sm",
        icon: "size-11 rounded-md",
        chip: "h-9 rounded-full px-3.5 text-sm",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp className={cn(buttonVariants({ variant, size, className }))} {...props} />
  );
}

export { Button, buttonVariants };
