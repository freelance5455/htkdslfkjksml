import { type ButtonHTMLAttributes, forwardRef } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-semibold transition-opacity duration-(--motion-quick) ease-(--ease-out) focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass disabled:pointer-events-none disabled:opacity-45",
  {
    variants: {
      variant: {
        ink: "bg-ink text-paper border border-ink hover:opacity-90",
        brass: "bg-brass text-white border border-brass hover:opacity-90",
        secondary: "bg-transparent text-ink border border-line font-medium hover:bg-paper-alt",
        ghost: "bg-transparent text-ink-soft border-0 font-medium hover:text-ink",
      },
      size: {
        default: "min-h-11 px-4 text-sm rounded-md",
        sm: "min-h-10 px-3 text-[13px] rounded-sm",
      },
    },
    defaultVariants: {
      variant: "ink",
      size: "default",
    },
  },
);

export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants>;

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  function Button({ className, variant, size, type = "button", ...props }, ref) {
    return (
      <button
        ref={ref}
        type={type}
        className={cn(buttonVariants({ variant, size }), className)}
        {...props}
      />
    );
  },
);

export { buttonVariants };
