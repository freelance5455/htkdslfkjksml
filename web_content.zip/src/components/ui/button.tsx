import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

type Variant = "primary" | "quiet" | "alarm" | "ghost";

const STYLES: Record<Variant, string> = {
  primary: "bg-fg text-bg",
  quiet: "border border-border bg-elevated text-fg",
  alarm: "bg-alarm text-alarm-fg",
  ghost: "text-fg",
};

export function Button({
  variant = "quiet",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-3 text-sm font-medium press disabled:cursor-not-allowed disabled:opacity-40",
        STYLES[variant],
        className,
      )}
      {...props}
    />
  );
}
