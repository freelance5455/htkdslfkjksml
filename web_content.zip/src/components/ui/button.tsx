import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost";
};

export function Button({ className, variant = "primary", type = "button", ...props }: Props) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center rounded-md px-4 text-center text-sm font-medium disabled:cursor-not-allowed disabled:opacity-45",
        variant === "primary" && "bg-accent text-accent-fg",
        variant === "secondary" && "border border-line bg-surface text-ink",
        variant === "ghost" && "bg-transparent text-ink",
        className,
      )}
      {...props}
    />
  );
}
