import type { ButtonHTMLAttributes } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/cn";

const variants = cva(
  "inline-flex items-center justify-center gap-2 rounded-md font-sans text-sm font-medium transition-colors duration-200 disabled:pointer-events-none disabled:opacity-40 min-h-11 px-3",
  {
    variants: {
      tone: {
        wax: "bg-wax text-wax-ink hover:bg-wax/90",
        quiet: "border border-line bg-sheet text-ink hover:border-ink",
        ghost: "bg-transparent text-ink hover:bg-sheet",
      },
    },
    defaultVariants: { tone: "quiet" },
  },
);

export function Button({
  tone,
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof variants>) {
  return <button type={type} className={cn(variants({ tone }), className)} {...props} />;
}
