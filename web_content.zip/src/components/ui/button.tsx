import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold min-h-11 transition-[transform,background-color,opacity] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)] active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal",
  {
    variants: {
      variant: {
        primary: "bg-teal text-card hover:bg-teal-deep",
        secondary: "border border-line bg-card text-ink hover:bg-paper",
        ghost: "bg-transparent text-ink hover:bg-paper-2",
        danger: "bg-danger text-card hover:opacity-90",
      },
      size: {
        md: "",
        block: "w-full",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export function Button({
  className,
  variant,
  size,
  asChild = false,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp className={cn(buttonVariants({ variant, size }), className)} type={asChild ? undefined : type} {...props} />
  );
}
