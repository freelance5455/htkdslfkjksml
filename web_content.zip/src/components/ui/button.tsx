import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-display font-medium tracking-tight transition-[opacity,transform,background-color,box-shadow,color] duration-150 ease-out select-none active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sage",
  {
    variants: {
      variant: {
        primary: "bg-cream text-ink hover:opacity-90",
        sage: "bg-sage text-ink hover:bg-sage-dim",
        ghost: "bg-transparent text-cream/90 hover:bg-cream/8",
        outline: "bg-transparent text-cream shadow-border hover:shadow-border-hover",
        danger: "bg-danger text-cream hover:opacity-90",
        paper: "bg-ink text-paper hover:opacity-90",
        quiet: "bg-transparent text-ink/70 hover:bg-ink/6",
      },
      size: {
        default: "h-11 px-5 rounded-lg text-sm",
        lg: "h-12 px-6 rounded-xl text-base",
        sm: "h-9 px-3.5 rounded-md text-sm",
        icon: "size-11 rounded-lg",
        "icon-sm": "size-9 rounded-md",
      },
    },
    defaultVariants: { variant: "primary", size: "default" },
  },
);

export type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants>;

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, type = "button", ...props }, ref) => (
    <button
      ref={ref}
      type={type}
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  ),
);
Button.displayName = "Button";

export { buttonVariants };
