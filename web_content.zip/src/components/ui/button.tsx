import type { ButtonHTMLAttributes } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/cn";

const buttonStyles = cva(
  "inline-flex shrink-0 items-center justify-center gap-2 font-medium select-none transition-[opacity,background-color,color] duration-150 ease-smooth hover:opacity-90 active:opacity-80 disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
  {
    variants: {
      variant: {
        primary: "h-11 rounded-full bg-accent px-4 text-accent-fg",
        quiet: "h-11 rounded-full bg-blush px-4 text-ink",
        ghost: "h-11 rounded-full px-3 text-ink hover:bg-blush",
        danger: "h-11 rounded-full border border-line bg-card px-4 text-accent",
      },
      size: {
        md: "",
        icon: "size-11 px-0",
      },
    },
    defaultVariants: { variant: "quiet", size: "md" },
  },
);

type Props = ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonStyles>;

export function Button({ className, variant, size, type = "button", ...props }: Props) {
  return <button type={type} className={cn(buttonStyles({ variant, size }), className)} {...props} />;
}
