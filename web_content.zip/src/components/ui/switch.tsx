import { cn } from "@/lib/utils";

export function Switch({
  checked,
  onCheckedChange,
  label,
}: {
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
  label?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onCheckedChange(!checked)}
      className={cn(
        "relative h-7 w-12 shrink-0 rounded-full border transition-colors",
        checked ? "border-accent bg-accent" : "border-border bg-elevated",
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 size-5 rounded-full bg-fg shadow-sm transition-transform",
          checked ? "left-6" : "left-0.5",
        )}
      />
    </button>
  );
}
