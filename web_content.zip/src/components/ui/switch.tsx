import * as SwitchPrimitive from "@radix-ui/react-switch";
import { cn } from "@/lib/utils";

export function Switch({
  checked,
  onCheckedChange,
  label,
}: {
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <label className="flex min-h-11 items-center justify-between gap-4">
      <span className="text-sm text-foreground">{label}</span>
      <SwitchPrimitive.Root
        checked={checked}
        onCheckedChange={onCheckedChange}
        className={cn(
          "relative h-6 w-10 rounded-full bg-card-2 shadow-[var(--shadow-border)] transition-colors duration-150",
          "data-[state=checked]:bg-primary",
        )}
      >
        <SwitchPrimitive.Thumb
          className="block size-5 translate-x-0.5 rounded-full bg-foreground transition-transform duration-150 data-[state=checked]:translate-x-[18px] data-[state=checked]:bg-primary-foreground"
        />
      </SwitchPrimitive.Root>
    </label>
  );
}
