import { cn } from "@/lib/cn";

export function Skeleton({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      className={cn("animate-pulse rounded-md bg-elevated shadow-[var(--shadow-border)]", className)}
      {...props}
    />
  );
}
