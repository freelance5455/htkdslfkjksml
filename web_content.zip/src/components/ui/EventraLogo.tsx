import React from 'react';

interface EventraLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export const EventraLogo: React.FC<EventraLogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
}) => {
  const iconDimensions = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-11 h-11',
  }[size];

  const textStyles = {
    sm: 'text-sm font-extrabold tracking-tight',
    md: 'text-base font-extrabold tracking-tight',
    lg: 'text-xl font-black tracking-tight',
  }[size];

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Eventra Iconic Geometric Pass / Prism Emblem */}
      <div
        className={`${iconDimensions} rounded-xl bg-neutral-900 dark:bg-[#12151b] border border-neutral-200 dark:border-neutral-800 flex items-center justify-center shrink-0 shadow-xs relative overflow-hidden group`}
      >
        <svg
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-5/6 h-5/6 transition-transform group-hover:scale-105"
        >
          {/* Subtle gradient definitions */}
          <defs>
            <linearGradient id="eventra-emerald" x1="4" y1="4" x2="28" y2="28" gradientUnits="userSpaceOnUse">
              <stop stopColor="#34d399" />
              <stop offset="1" stopColor="#059669" />
            </linearGradient>
            <linearGradient id="eventra-subtle" x1="16" y1="8" x2="28" y2="24" gradientUnits="userSpaceOnUse">
              <stop stopColor="#10b981" stopOpacity="0.8" />
              <stop offset="1" stopColor="#047857" stopOpacity="0.4" />
            </linearGradient>
          </defs>

          {/* Faceted 'E' Ticket Core */}
          <path
            d="M7 8C7 6.89543 7.89543 6 9 6H23C24.1046 6 25 6.89543 25 8V11C25 11.5523 24.5523 12 24 12H13V14H21C21.5523 14 22 14.4477 22 15V17C22 17.5523 21.5523 18 21 18H13V20H24C24.5523 20 25 20.4477 25 21V24C25 25.1046 24.1046 26 23 26H9C7.89543 26 7 25.1046 7 24V8Z"
            fill="url(#eventra-emerald)"
          />

          {/* Precision Pass Notch Indicator */}
          <circle cx="20.5" cy="11.5" r="1.5" fill="#f4f4f6" />
        </svg>
      </div>

      {showText && (
        <span className={`text-neutral-900 dark:text-[#f4f4f6] ${textStyles} font-sans`}>
          Eventra
        </span>
      )}
    </div>
  );
};
