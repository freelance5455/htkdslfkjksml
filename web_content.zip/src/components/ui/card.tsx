import { cn } from "@/lib/utils";

export function Card({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      className={cn(
        "rounded-[24px] border border-line bg-paper p-5 shadow-[var(--shadow-card)]",
        className,
      )}
      {...props}
    />
  );
}

export function Badge({
  className,
  tone = "default",
  ...props
}: React.ComponentProps<"span"> & { tone?: "default" | "gold" | "ok" | "warn" | "danger" | "navy" }) {
  const tones = {
    default: "bg-secondary text-ink",
    gold: "bg-gold/15 text-navy",
    ok: "bg-success/12 text-success",
    warn: "bg-warn/12 text-warn",
    danger: "bg-danger/12 text-danger",
    navy: "bg-navy text-cream",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium",
        tones[tone],
        className,
      )}
      {...props}
    />
  );
}
