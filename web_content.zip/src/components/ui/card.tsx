import * as React from "react";
import { cn } from "@/lib/utils";

function Card({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      className={cn(
        "rounded-3xl border border-border bg-card p-4 text-card-foreground",
        className,
      )}
      {...props}
    />
  );
}

export { Card };
