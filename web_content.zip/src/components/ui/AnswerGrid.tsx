import React from 'react';
import { Subject, AnswerOption } from '../../types';
import { SUBJECT_RANGES, SUBJECTS } from '../../lib/scoring';
import { cn } from '../../lib/utils';

interface AnswerGridProps {
  answers: Record<number, AnswerOption>;
  onChange?: (q: number, ans: AnswerOption) => void;
  readonly?: boolean;
  highlightMismatchesWith?: Record<number, AnswerOption>; // Optional key for comparison
}

export const AnswerGrid: React.FC<AnswerGridProps> = ({ 
  answers, 
  onChange, 
  readonly = false,
  highlightMismatchesWith
}) => {
  const cycleAnswer = (q: number) => {
    if (readonly || !onChange) return;
    const current = answers[q] || '';
    const nextMap: Record<AnswerOption, AnswerOption> = {
      '': 'A', 'A': 'B', 'B': 'C', 'C': 'D', 'D': ''
    };
    onChange(q, nextMap[current]);
  };

  return (
    <div className="space-y-8">
      {SUBJECTS.map(subject => {
        const [start, end] = SUBJECT_RANGES[subject];
        const questions = Array.from({ length: end - start + 1 }, (_, i) => start + i);
        
        return (
          <div key={subject} className="bg-white/40 rounded-xl p-4 sm:p-6 border border-slate-100">
            <h3 className="text-xl font-semibold text-slate-800 mb-4">{subject} <span className="text-sm font-normal text-slate-500">({start}-{end})</span></h3>
            
            <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-9 gap-2 sm:gap-3">
              {questions.map(q => {
                const currentAns = answers[q] || '';
                const comparisonAns = highlightMismatchesWith ? highlightMismatchesWith[q] || '' : null;
                const isMismatch = highlightMismatchesWith && currentAns !== comparisonAns && currentAns !== '';
                const isCorrect = highlightMismatchesWith && currentAns === comparisonAns && currentAns !== '';
                const isSkipped = currentAns === '';

                return (
                  <button
                    key={q}
                    onClick={() => cycleAnswer(q)}
                    disabled={readonly}
                    className={cn(
                      "flex flex-col items-center justify-center p-2 rounded-xl transition-all duration-200 border",
                      readonly ? "cursor-default" : "cursor-pointer hover:bg-white hover:shadow-sm active:scale-95",
                      currentAns ? (
                        isMismatch ? "bg-rose-50 border-rose-200 text-rose-700" :
                        isCorrect ? "bg-emerald-50 border-emerald-200 text-emerald-700" :
                        "bg-indigo-50 border-indigo-200 text-indigo-700"
                      ) : "bg-slate-50/50 border-slate-200 text-slate-400"
                    )}
                  >
                    <span className="text-[10px] font-medium opacity-70 mb-1">Q.{q}</span>
                    <span className="text-sm font-bold h-5 flex items-center justify-center">
                      {currentAns || '-'}
                    </span>
                  </button>
                )
              })}
            </div>
          </div>
        )
      })}
    </div>
  );
};
