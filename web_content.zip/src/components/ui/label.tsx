import type { LabelHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Label({
  className,
  ...props
}: LabelHTMLAttributes<HTMLLabelElement>) {
  return (
    <label
      className={cn(
        "mb-2 flex items-center gap-1.5 text-xs font-bold tracking-wider text-muted",
        className,
      )}
      {...props}
    />
  );
}
