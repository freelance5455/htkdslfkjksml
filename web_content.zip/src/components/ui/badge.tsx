import type { ComponentProps } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-full whitespace-nowrap px-2.5 py-0.5 text-xs font-medium",
  {
    variants: {
      variant: {
        default: "bg-primary/10 text-primary",
        excellence: "bg-primary text-primary-fg",
        "very-good": "bg-accent/15 text-accent",
        good: "bg-success/10 text-success",
        fair: "bg-warn/10 text-warn",
        fail: "bg-danger/10 text-danger",
        muted: "bg-surface-2 text-muted",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

export function Badge({
  className,
  variant,
  ...props
}: ComponentProps<"span"> & VariantProps<typeof badgeVariants>) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
