import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function StatusPill({
  tone,
  children,
  className,
}: {
  tone: "available" | "rented" | "pending" | "paid";
  children: ReactNode;
  className?: string;
}) {
  const tones = {
    available: "bg-green-bg text-green",
    paid: "bg-green-bg text-green",
    rented: "bg-rust-bg text-rust",
    pending: "bg-rust-bg text-rust",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
