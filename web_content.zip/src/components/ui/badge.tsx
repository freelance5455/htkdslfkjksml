import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/cn";

const badgeVariants = cva(
  "inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold tracking-wide uppercase",
  {
    variants: {
      tone: {
        muted: "bg-elevated text-muted shadow-[var(--shadow-border)]",
        live: "bg-live/15 text-live",
        hot: "bg-hot/15 text-hot",
        accent: "bg-accent/15 text-accent",
        warn: "bg-warm/15 text-warm",
      },
    },
    defaultVariants: { tone: "muted" },
  },
);

export function Badge({
  className,
  tone,
  ...props
}: React.ComponentProps<"span"> & VariantProps<typeof badgeVariants>) {
  return <span className={cn(badgeVariants({ tone }), className)} {...props} />;
}
