import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  className,
  tone = "muted",
  children,
}: {
  className?: string;
  tone?: "muted" | "ok" | "warn" | "danger" | "accent";
  children: ReactNode;
}) {
  const tones = {
    muted: "bg-elevated text-muted border-border",
    ok: "bg-ok/15 text-ok border-ok/25",
    warn: "bg-warn/15 text-warn border-warn/25",
    danger: "bg-danger/15 text-danger border-danger/25",
    accent: "bg-accent/15 text-accent border-accent/25",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium tracking-wide",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
