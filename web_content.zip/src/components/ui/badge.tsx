import type { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  className,
  ...props
}: HTMLAttributes<HTMLSpanElement>) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold text-accent shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-accent)_40%,transparent)] bg-accent/10",
        className,
      )}
      {...props}
    />
  );
}
