import * as React from "react";
import { cn } from "@/lib/utils";

export const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<"input">>(
  ({ className, type, ...props }, ref) => (
    <input
      type={type}
      ref={ref}
      className={cn(
        "flex h-11 w-full rounded-md bg-surface px-3 text-base text-fg shadow-nijo outline-none placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-primary/70",
        className,
      )}
      {...props}
    />
  ),
);
Input.displayName = "Input";
