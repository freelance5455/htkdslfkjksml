import * as React from "react";
import { cn } from "@/lib/utils";

function Input({ className, type, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      type={type}
      className={cn(
        "flex h-12 w-full rounded-xl bg-card px-4 text-base text-foreground shadow-border outline-none transition-[box-shadow] duration-150 ease-out placeholder:text-muted-foreground",
        "focus-visible:shadow-border-hover focus-visible:ring-2 focus-visible:ring-ring/20",
        "disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      {...props}
    />
  );
}

function Textarea({ className, ...props }: React.ComponentProps<"textarea">) {
  return (
    <textarea
      className={cn(
        "flex min-h-24 w-full rounded-xl bg-card px-4 py-3 text-base text-foreground shadow-border outline-none transition-[box-shadow] duration-150 ease-out placeholder:text-muted-foreground",
        "focus-visible:shadow-border-hover focus-visible:ring-2 focus-visible:ring-ring/20",
        "disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      {...props}
    />
  );
}

export { Input, Textarea };
