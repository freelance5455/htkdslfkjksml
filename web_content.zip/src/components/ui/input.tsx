import * as React from "react";
import { cn } from "@/lib/utils";

export function Input({ className, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      className={cn(
        "flex h-12 w-full rounded-lg bg-surface-2 px-4 text-sm text-fg outline-none",
        "placeholder:text-subtle shadow-[var(--shadow-border)]",
        "focus-visible:shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-accent)_55%,transparent)]",
        "disabled:opacity-40",
        className,
      )}
      {...props}
    />
  );
}
