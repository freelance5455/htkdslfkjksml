import React, { ReactNode } from 'react';

export interface EmptyStateProps {
  icon: ReactNode;
  title: string;
  description: string;
  actionText?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionText,
  actionLabel,
  onAction,
  className = '',
}) => {
  const buttonLabel = actionLabel || actionText;

  return (
    <div
      className={`p-8 sm:p-12 text-center rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 shadow-2xs space-y-3 max-w-md mx-auto ${className}`}
    >
      <div className="w-12 h-12 rounded-2xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center mx-auto text-neutral-400 dark:text-neutral-500">
        {icon}
      </div>
      <div className="space-y-1">
        <h3 className="text-sm sm:text-base font-bold text-neutral-900 dark:text-white">
          {title}
        </h3>
        <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto leading-relaxed">
          {description}
        </p>
      </div>

      {buttonLabel && onAction && (
        <div className="pt-2">
          <button
            onClick={onAction}
            className="px-4 py-2 rounded-full bg-neutral-900 dark:bg-white text-white dark:text-neutral-950 text-xs font-bold hover:opacity-90 active:scale-95 transition-all cursor-pointer shadow-sm"
          >
            {buttonLabel}
          </button>
        </div>
      )}
    </div>
  );
};
