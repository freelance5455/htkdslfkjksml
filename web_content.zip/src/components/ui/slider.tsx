import * as SliderPrimitive from "@radix-ui/react-slider";

type SliderProps = {
  value: number;
  min: number;
  max: number;
  step: number;
  label: string;
  onChange: (value: number) => void;
};

export function Slider({ value, min, max, step, label, onChange }: SliderProps) {
  return (
    <SliderPrimitive.Root
      className="relative flex h-11 w-full touch-none items-center select-none"
      min={min}
      max={max}
      step={step}
      value={[value]}
      aria-label={label}
      onValueChange={(next) => {
        const v = next[0];
        if (typeof v === "number") onChange(v);
      }}
    >
      <SliderPrimitive.Track className="relative h-1.5 w-full grow overflow-hidden rounded-full bg-field">
        <SliderPrimitive.Range className="absolute h-full bg-paper" />
      </SliderPrimitive.Track>
      <SliderPrimitive.Thumb className="slider-thumb focus-visible:ring-2 focus-visible:ring-paper/40 focus-visible:outline-none" />
    </SliderPrimitive.Root>
  );
}
