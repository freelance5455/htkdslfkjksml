"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Icon } from "./Icon";
import { formatCompact, formatMoney, monthShort, relativeDay } from "@/lib/calendar";
import type { DayPoint, MonthPoint, CategorySlice } from "@/lib/stats";

function useMounted(delay = 60) {
  const [m, setM] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setM(true), delay);
    return () => clearTimeout(t);
  }, [delay]);
  return m;
}

/* ------------------------- mirrored daily bars ------------------------- */

export function MirrorBars({
  days,
  currency,
  onSelect,
}: {
  days: DayPoint[];
  currency: string;
  onSelect?: (day: DayPoint) => void;
}) {
  const mounted = useMounted();
  const [active, setActive] = useState<number | null>(null);
  const max = Math.max(1, ...days.map((d) => Math.max(d.earn, d.spend)));
  const shown = days.slice(-21);

  return (
    <div>
      <div className="mb-2 flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.14em] text-ink3">
        <span className="text-earn">▲ earnings</span>
        <span>last {shown.length} days</span>
        <span className="text-spend">▼ spendings</span>
      </div>
      <div className="relative flex h-[132px] items-center gap-[3px]">
        <div className="pointer-events-none absolute inset-x-0 top-1/2 h-px bg-line" />
        {shown.map((d, i) => {
          const eh = (d.earn / max) * 50;
          const sh = (d.spend / max) * 50;
          const isActive = active === i;
          return (
            <button
              key={d.day}
              onClick={() => {
                setActive(i);
                onSelect?.(d);
              }}
              className="press relative flex h-full flex-1 flex-col justify-center gap-[2px]"
              aria-label={`${d.day}: earned ${d.earn}, spent ${d.spend}`}
            >
              <div className="flex h-1/2 items-end justify-center">
                <div
                  className="w-full max-w-[13px] rounded-t-[3px] transition-all duration-700 ease-out"
                  style={{
                    height: mounted ? `${Math.max(eh, d.earn > 0 ? 3 : 0)}%` : "0%",
                    background: isActive
                      ? "var(--c-earn)"
                      : "color-mix(in oklab, var(--c-earn) 65%, transparent)",
                    boxShadow: isActive ? "0 0 14px var(--c-earn)" : "none",
                  }}
                />
              </div>
              <div className="flex h-1/2 items-start justify-center">
                <div
                  className="w-full max-w-[13px] rounded-b-[3px] transition-all duration-700 ease-out"
                  style={{
                    height: mounted ? `${Math.max(sh, d.spend > 0 ? 3 : 0)}%` : "0%",
                    background: isActive
                      ? "var(--c-spend)"
                      : "color-mix(in oklab, var(--c-spend) 65%, transparent)",
                    boxShadow: isActive ? "0 0 14px var(--c-spend)" : "none",
                  }}
                />
              </div>
            </button>
          );
        })}
      </div>
      <div className="mt-2 h-11 rounded-xl border border-line bg-surface2 px-3 py-1.5">
        {active === null ? (
          <p className="text-[11.5px] leading-snug text-ink3">
            Tap a bar to inspect a day · peak spend{" "}
            <span className="font-mono text-spend">
              {formatCompact(Math.max(0, ...shown.map((d) => d.spend)), currency)}
            </span>
          </p>
        ) : (
          (() => {
            const d = shown[active]!;
            return (
              <div className="flex items-center justify-between gap-2 text-[11.5px]">
                <span className="font-semibold">{relativeDay(d.day)}</span>
                <span className="font-mono text-earn">+{formatCompact(d.earn, currency)}</span>
                <span className="font-mono text-spend">−{formatCompact(d.spend, currency)}</span>
                <span className="font-mono text-ink2">{d.count} entries</span>
              </div>
            );
          })()
        )}
      </div>
    </div>
  );
}

/* --------------------------- monthly grouped --------------------------- */

export function MonthBars({
  months,
  currency,
  height = 150,
}: {
  months: MonthPoint[];
  currency: string;
  height?: number;
}) {
  const mounted = useMounted(90);
  const [active, setActive] = useState(months.length - 1);
  const max = Math.max(1, ...months.flatMap((m) => [m.earn, m.spend]));
  const cur = months[active] ?? months[months.length - 1];

  return (
    <div>
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink3">
            {cur ? monthShort(cur.month) + " detail" : ""}
          </p>
          <p className="font-display text-[15px] font-bold">
            <span className="text-earn">{cur ? formatCompact(cur.earn, currency) : ""}</span>
            <span className="mx-1.5 text-ink3">in /</span>
            <span className="text-spend">{cur ? formatCompact(cur.spend, currency) : ""}</span>
            <span className="mx-1 text-ink3">out</span>
          </p>
        </div>
        <span
          className={`rounded-full border px-2 py-1 font-mono text-[10.5px] ${
            (cur?.net ?? 0) >= 0
              ? "border-earn/35 bg-earn/12 text-earn"
              : "border-spend/35 bg-spend/12 text-spend"
          }`}
        >
          net {cur ? formatMoney(cur.net, currency, { sign: true }) : ""}
        </span>
      </div>
      <div className="relative flex items-end gap-2" style={{ height }}>
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-line" />
        <div className="pointer-events-none absolute inset-x-0 top-1/2 h-px bg-line" />
        {months.map((m, i) => {
          const isActive = i === active;
          return (
            <button
              key={m.month}
              onClick={() => setActive(i)}
              className="press group relative flex h-full flex-1 flex-col justify-end gap-1"
            >
              <div className="flex h-full items-end justify-center gap-[3px]">
                <div
                  className="w-[9px] rounded-t-[4px] transition-all duration-700 ease-out"
                  style={{
                    height: mounted ? `${Math.max((m.earn / max) * 100, m.earn > 0 ? 3 : 1)}%` : "0%",
                    background: isActive
                      ? "var(--c-earn)"
                      : "color-mix(in oklab, var(--c-earn) 55%, transparent)",
                    boxShadow: isActive ? "0 0 16px color-mix(in oklab, var(--c-earn) 60%, transparent)" : "none",
                  }}
                />
                <div
                  className="w-[9px] rounded-t-[4px] transition-all duration-700 ease-out"
                  style={{
                    height: mounted ? `${Math.max((m.spend / max) * 100, m.spend > 0 ? 3 : 1)}%` : "0%",
                    background: isActive
                      ? "var(--c-spend)"
                      : "color-mix(in oklab, var(--c-spend) 55%, transparent)",
                    boxShadow: isActive ? "0 0 16px color-mix(in oklab, var(--c-spend) 60%, transparent)" : "none",
                  }}
                />
              </div>
              <span
                className={`font-mono text-[10px] uppercase transition-colors ${
                  isActive ? "text-ink" : "text-ink3"
                }`}
              >
                {monthShort(m.month)}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* -------------------------------- donut -------------------------------- */

const SLICE_COLORS = [
  "var(--c-brand)",
  "var(--c-spend)",
  "var(--c-bill)",
  "var(--c-earn)",
  "#7dd3fc",
  "#c4a7ff",
  "#f9a8d4",
  "#86efac",
];

export function Donut({
  slices,
  currency,
  size = 148,
  thickness = 15,
  centerLabel,
  centerValue,
}: {
  slices: CategorySlice[];
  currency: string;
  size?: number;
  thickness?: number;
  centerLabel: string;
  centerValue: string;
}) {
  const mounted = useMounted(120);
  const total = slices.reduce((s, x) => s + x.total, 0);
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  let acc = 0;

  return (
    <div className="flex items-center gap-4">
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke="var(--c-surface2)"
            strokeWidth={thickness}
          />
          {slices.slice(0, 8).map((s, i) => {
            const frac = total > 0 ? s.total / total : 0;
            const dash = frac * c;
            const offset = acc * c;
            acc += frac;
            return (
              <circle
                key={s.category}
                cx={size / 2}
                cy={size / 2}
                r={r}
                fill="none"
                stroke={SLICE_COLORS[i % SLICE_COLORS.length]}
                strokeWidth={thickness}
                strokeLinecap="butt"
                strokeDasharray={`${mounted ? dash : 0} ${c}`}
                strokeDashoffset={-offset}
                style={{ transition: `stroke-dasharray 900ms cubic-bezier(.22,1,.36,1) ${i * 70}ms` }}
              />
            );
          })}
        </svg>
        <div className="absolute inset-0 grid place-items-center text-center">
          <div>
            <p className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-ink3">
              {centerLabel}
            </p>
            <p className="font-display text-[17px] font-extrabold tracking-[-0.02em]">
              {centerValue}
            </p>
          </div>
        </div>
      </div>
      <ul className="min-w-0 flex-1 space-y-1.5">
        {slices.slice(0, 6).map((s, i) => (
          <li key={s.category} className="flex items-center gap-2 text-[12.5px]">
            <span
              className="h-2.5 w-2.5 shrink-0 rounded-[3px]"
              style={{ background: SLICE_COLORS[i % SLICE_COLORS.length] }}
            />
            <span className="min-w-0 flex-1 truncate font-semibold">{s.category}</span>
            <span className="font-mono text-[11.5px] text-ink2">
              {formatCompact(s.total, currency)}
            </span>
            <span className="w-9 text-right font-mono text-[10.5px] text-ink3">{s.share}%</span>
          </li>
        ))}
        {!slices.length ? <li className="text-[12.5px] text-ink3">Nothing recorded yet.</li> : null}
      </ul>
    </div>
  );
}

/* ------------------------------- dial --------------------------------- */

export function MonthDial({
  earn,
  spend,
  currency,
  size = 132,
}: {
  earn: number;
  spend: number;
  currency: string;
  size?: number;
}) {
  const mounted = useMounted(80);
  const ratio = earn > 0 ? spend / earn : spend > 0 ? 1.4 : 0;
  const clamped = Math.max(0, Math.min(1, ratio));
  const thickness = 11;
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  const tone = ratio <= 0.7 ? "var(--c-earn)" : ratio <= 1 ? "var(--c-bill)" : "var(--c-spend)";
  const net = earn - spend;

  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--c-surface2)" strokeWidth={thickness} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={tone}
          strokeWidth={thickness}
          strokeLinecap="round"
          strokeDasharray={`${mounted ? clamped * c : 0} ${c}`}
          style={{ transition: "stroke-dasharray 1000ms cubic-bezier(.22,1,.36,1)", filter: `drop-shadow(0 0 8px ${tone})` }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">
        <div>
          <p className="font-mono text-[9px] uppercase tracking-[0.14em] text-ink3">out ÷ in</p>
          <p className="font-display text-[22px] font-extrabold leading-none tracking-[-0.03em]">
            {earn > 0 ? `${Math.round(ratio * 100)}%` : "—"}
          </p>
          <p
            className="mt-1 font-mono text-[11px]"
            style={{ color: net >= 0 ? "var(--c-earn)" : "var(--c-spend)" }}
          >
            {formatMoney(net, currency, { sign: true })}
          </p>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------- extremes row ---------------------------- */

export function ExtremeRow({
  icon,
  label,
  value,
  sub,
  tone,
}: {
  icon: Parameters<typeof Icon>[0]["name"];
  label: string;
  value: string;
  sub?: string;
  tone: "earn" | "spend" | "bill" | "neutral";
}) {
  const tones: Record<string, string> = {
    earn: "text-earn border-earn/30 bg-earn/10",
    spend: "text-spend border-spend/30 bg-spend/10",
    bill: "text-bill border-bill/30 bg-bill/10",
    neutral: "text-ink2 border-line bg-surface2",
  };
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ type: "spring", stiffness: 260, damping: 26 }}
      className="card flex items-center gap-3 p-3"
    >
      <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl border ${tones[tone]}`}>
        <Icon name={icon} size={16} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-ink3">{label}</p>
        <p className="truncate font-display text-[15px] font-bold tracking-[-0.01em]">{value}</p>
      </div>
      {sub ? (
        <span className="shrink-0 font-mono text-[10.5px] uppercase text-ink3">{sub}</span>
      ) : null}
    </motion.div>
  );
}
