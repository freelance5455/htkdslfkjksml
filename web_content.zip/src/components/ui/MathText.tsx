import { useMemo } from 'react';
import katex from 'katex';
import { tokenizeMath } from '../../utils/math';
import { cn } from '../../utils/format';

/** يعرض نصاً قد يحتوي معادلات LaTeX (بين ‎$...$‎ أو ‎$$...$$‎) */
export function MathText({ text, className }: { text: string; className?: string }) {
  const tokens = useMemo(() => tokenizeMath(text), [text]);

  return (
    <div className={cn('text-[0.95rem] leading-[1.85] text-[var(--ink)]', className)}>
      {tokens.map((token, index) => {
        if (token.type === 'text') {
          const blocks = token.value.split(/\n{2,}/).filter((b) => b.trim().length > 0);
          return (
            <span key={index}>
              {blocks.map((block, i) => (
                <span key={i} className="block">
                  {renderInline(block)}
                </span>
              ))}
            </span>
          );
        }
        let html = '';
        try {
          html = katex.renderToString(token.value, {
            displayMode: token.type === 'block',
            throwOnError: false,
            strict: false,
            output: 'html',
          });
        } catch {
          html = token.value;
        }
        return (
          <span
            key={index}
            className={token.type === 'block' ? 'my-1 block overflow-x-auto' : 'inline-block align-middle'}
            dangerouslySetInnerHTML={{ __html: html }}
          />
        );
      })}
    </div>
  );
}

/** تنسيق خفيف: **عريض** و `كود` */
function renderInline(text: string) {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).filter(Boolean);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return (
        <strong key={i} className="font-semibold text-[var(--ink)]">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith('`') && part.endsWith('`')) {
      return (
        <code key={i} className="rounded bg-[var(--surface-2)] px-1 py-0.5 text-[0.85em]">
          {part.slice(1, -1)}
        </code>
      );
    }
    return <span key={i}>{part}</span>;
  });
}
