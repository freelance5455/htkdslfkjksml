import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { cn } from '../../utils/format';

type Variant = 'primary' | 'gold' | 'outline' | 'ghost' | 'soft' | 'danger';
type Size = 'sm' | 'md' | 'lg';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  block?: boolean;
  icon?: ReactNode;
}

const variants: Record<Variant, string> = {
  primary:
    'bg-[var(--brand)] text-[var(--brand-ink)] hover:opacity-92 active:scale-[0.985] shadow-[0_10px_24px_-16px_rgba(11,42,63,0.9)]',
  gold: 'bg-[var(--gold)] text-[#3a2606] hover:brightness-105 active:scale-[0.985] shadow-[0_10px_24px_-16px_rgba(230,165,46,0.9)]',
  outline: 'border border-[var(--line)] bg-transparent text-[var(--ink)] hover:bg-[var(--surface-2)]',
  ghost: 'bg-transparent text-[var(--ink)] hover:bg-[var(--surface-2)]',
  soft: 'bg-[var(--surface-2)] text-[var(--ink)] hover:brightness-[0.98]',
  danger: 'bg-[var(--danger)] text-white hover:brightness-105',
};

const sizes: Record<Size, string> = {
  sm: 'h-9 px-3 text-[0.8rem] rounded-xl gap-1.5',
  md: 'h-11 px-4 text-sm rounded-2xl gap-2',
  lg: 'h-13 px-6 text-base rounded-2xl gap-2.5',
};

export function Button({
  variant = 'primary',
  size = 'md',
  block,
  icon,
  className,
  children,
  ...rest
}: ButtonProps) {
  return (
    <button
      type={rest.type ?? 'button'}
      className={cn(
        'focus-ring inline-flex select-none items-center justify-center font-medium transition-[transform,background,opacity,box-shadow] duration-150 disabled:cursor-not-allowed disabled:opacity-45',
        variants[variant],
        sizes[size],
        block && 'w-full',
        className,
      )}
      {...rest}
    >
      {icon}
      {children}
    </button>
  );
}

interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  children: ReactNode;
  tone?: 'light' | 'dark';
}

/** زر أيقونة بمساحة لمس ٤٤px وتسمية aria عربية إلزامية */
export function IconButton({ label, children, className, tone = 'dark', ...rest }: IconButtonProps) {
  return (
    <button
      type={rest.type ?? 'button'}
      aria-label={label}
      title={label}
      className={cn(
        'focus-ring inline-flex h-11 w-11 items-center justify-center rounded-full transition-colors',
        tone === 'dark' ? 'text-white/85 hover:bg-white/12 hover:text-white' : 'text-[var(--ink)] hover:bg-[var(--surface-2)]',
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}
