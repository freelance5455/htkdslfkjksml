import * as React from "react";
import { Drawer } from "vaul";
import { cn } from "@/lib/utils";

export function Sheet({
  open,
  onOpenChange,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: React.ReactNode;
}) {
  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange} shouldScaleBackground={false}>
      {children}
    </Drawer.Root>
  );
}

export function SheetContent({
  children,
  className,
  title,
}: {
  children: React.ReactNode;
  className?: string;
  title: string;
}) {
  return (
    <Drawer.Portal>
      <Drawer.Overlay className="fixed inset-0 z-50 bg-black/50" />
      <Drawer.Content
        className={cn(
          "fixed inset-x-0 bottom-0 z-50 flex max-h-[88dvh] flex-col rounded-t-xl bg-elevated pb-[env(safe-area-inset-bottom)] text-fg shadow-nijo outline-none",
          className,
        )}
      >
        <div className="mx-auto mt-2 h-1 w-10 rounded-full bg-border-strong" />
        <Drawer.Title className="px-5 pb-2 pt-4 text-base font-medium tracking-tight">{title}</Drawer.Title>
        <div className="min-h-0 flex-1 overflow-y-auto px-5 pb-5">{children}</div>
      </Drawer.Content>
    </Drawer.Portal>
  );
}
