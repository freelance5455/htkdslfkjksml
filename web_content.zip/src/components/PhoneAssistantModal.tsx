import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Battery,
  BatteryCharging,
  Wifi,
  PhoneCall,
  MessageSquare,
  Clock,
  Plus,
  Trash2,
  CheckCircle,
  FileText,
  X,
  Sparkles,
  Zap
} from 'lucide-react';
import { DeviceInfo, ReminderItem } from '../types';

interface PhoneAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendPrompt: (prompt: string) => void;
}

export const PhoneAssistantModal: React.FC<PhoneAssistantModalProps> = ({
  isOpen,
  onClose,
  onSendPrompt,
}) => {
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo>({
    batteryLevel: null,
    isCharging: null,
    isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    screenResolution: typeof window !== 'undefined' ? `${window.screen.width}x${window.screen.height}` : '1920x1080',
    deviceMemory: (navigator as unknown as { deviceMemory?: number }).deviceMemory || null,
    platform: typeof navigator !== 'undefined' ? navigator.platform : 'Unknown',
  });

  const [callNumber, setCallNumber] = useState('');
  const [smsNumber, setSmsNumber] = useState('');
  const [smsText, setSmsText] = useState('');

  // Reminders
  const [reminders, setReminders] = useState<ReminderItem[]>(() => {
    try {
      const saved = localStorage.getItem('nova_phone_reminders');
      return saved ? JSON.parse(saved) : [
        { id: '1', text: 'Important task review', time: '14:00', done: false },
        { id: '2', text: 'Drink water & stretch', time: '16:00', done: false },
      ];
    } catch {
      return [];
    }
  });
  const [newReminderText, setNewReminderText] = useState('');
  const [newReminderTime, setNewReminderTime] = useState('');

  // Scratchpad
  const [notes, setNotes] = useState(() => {
    try {
      return localStorage.getItem('nova_phone_scratchpad') || 'Meri quick notes yahan save rehti hain...';
    } catch {
      return '';
    }
  });

  // Listen for external updates (e.g., custom voice command clearing tasks)
  useEffect(() => {
    const handleRemindersUpdate = () => {
      try {
        const saved = localStorage.getItem('nova_phone_reminders');
        setReminders(saved ? JSON.parse(saved) : []);
      } catch {}
    };

    window.addEventListener('nova_reminders_updated', handleRemindersUpdate);
    return () => window.removeEventListener('nova_reminders_updated', handleRemindersUpdate);
  }, []);

  // Battery API
  useEffect(() => {
    if ('getBattery' in navigator) {
      (navigator as unknown as { getBattery: () => Promise<{ level: number; charging: boolean; addEventListener: (event: string, handler: () => void) => void }> })
        .getBattery()
        .then((battery) => {
          setDeviceInfo((prev) => ({
            ...prev,
            batteryLevel: Math.round(battery.level * 100),
            isCharging: battery.charging,
          }));

          battery.addEventListener('levelchange', () => {
            setDeviceInfo((prev) => ({ ...prev, batteryLevel: Math.round(battery.level * 100) }));
          });
          battery.addEventListener('chargingchange', () => {
            setDeviceInfo((prev) => ({ ...prev, isCharging: battery.charging }));
          });
        })
        .catch(() => {});
    }

    const handleOnline = () => setDeviceInfo((prev) => ({ ...prev, isOnline: true }));
    const handleOffline = () => setDeviceInfo((prev) => ({ ...prev, isOnline: false }));

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const saveReminders = (updated: ReminderItem[]) => {
    setReminders(updated);
    try {
      localStorage.setItem('nova_phone_reminders', JSON.stringify(updated));
    } catch {}
  };

  const addReminder = () => {
    if (!newReminderText.trim()) return;
    const newItem: ReminderItem = {
      id: Date.now().toString(),
      text: newReminderText.trim(),
      time: newReminderTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      done: false,
    };
    saveReminders([...reminders, newItem]);
    setNewReminderText('');
    setNewReminderTime('');
  };

  const toggleReminder = (id: string) => {
    saveReminders(
      reminders.map((r) => (r.id === id ? { ...r, done: !r.done } : r))
    );
  };

  const deleteReminder = (id: string) => {
    saveReminders(reminders.filter((r) => r.id !== id));
  };

  const handleNotesChange = (val: string) => {
    setNotes(val);
    try {
      localStorage.setItem('nova_phone_scratchpad', val);
    } catch {}
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-cyan-950/50 via-slate-900 to-violet-950/50 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Phone & Device Assistant
                <span className="text-xs font-normal px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Toolkit
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Live device sensors, quick call/SMS deep-links, reminders & scratchpad
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-sm text-slate-200">
          {/* Live Device Status Cards */}
          <div>
            <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-400 mb-2.5 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-yellow-400" /> Live Device Health & Sensors
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {/* Battery */}
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>Battery</span>
                  {deviceInfo.isCharging ? (
                    <BatteryCharging className="w-4 h-4 text-emerald-400 animate-pulse" />
                  ) : (
                    <Battery className="w-4 h-4 text-cyan-400" />
                  )}
                </div>
                <div className="mt-2 text-lg sm:text-xl font-bold text-white">
                  {deviceInfo.batteryLevel !== null ? `${deviceInfo.batteryLevel}%` : 'Normal'}
                </div>
                <span className="text-[11px] text-slate-400">
                  {deviceInfo.isCharging ? 'Charging ⚡' : 'Discharging'}
                </span>
              </div>

              {/* Network */}
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>Network</span>
                  <Wifi className={`w-4 h-4 ${deviceInfo.isOnline ? 'text-emerald-400' : 'text-red-400'}`} />
                </div>
                <div className="mt-2 text-lg sm:text-xl font-bold text-white">
                  {deviceInfo.isOnline ? 'Online' : 'Offline'}
                </div>
                <span className="text-[11px] text-emerald-400">High Speed Active</span>
              </div>

              {/* Screen */}
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>Display</span>
                  <Smartphone className="w-4 h-4 text-violet-400" />
                </div>
                <div className="mt-2 text-sm sm:text-base font-semibold text-white truncate">
                  {deviceInfo.screenResolution}
                </div>
                <span className="text-[11px] text-slate-400 truncate">{deviceInfo.platform}</span>
              </div>

              {/* Memory / CPU */}
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>RAM / System</span>
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="mt-2 text-base sm:text-lg font-bold text-white">
                  {deviceInfo.deviceMemory ? `${deviceInfo.deviceMemory} GB+` : 'Optimized'}
                </div>
                <span className="text-[11px] text-cyan-400">Hardware Accel</span>
              </div>
            </div>
          </div>

          {/* Quick Phone Call & SMS Links */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Quick Call */}
            <div className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/50 space-y-2">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <PhoneCall className="w-3.5 h-3.5 text-emerald-400" /> 1-Click Dial / Call
              </label>
              <div className="flex gap-2">
                <input
                  type="tel"
                  placeholder="e.g. 9876543210"
                  value={callNumber}
                  onChange={(e) => setCallNumber(e.target.value)}
                  className="flex-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
                <a
                  href={callNumber ? `tel:${callNumber}` : '#'}
                  onClick={(e) => {
                    if (!callNumber) {
                      e.preventDefault();
                      alert('Pehle phone number enter karein');
                    }
                  }}
                  className={`px-3 py-1.5 rounded-lg font-medium text-xs flex items-center gap-1 transition ${
                    callNumber
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer shadow-md'
                      : 'bg-slate-700 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <PhoneCall className="w-3.5 h-3.5" /> Call
                </a>
              </div>
            </div>

            {/* Quick SMS */}
            <div className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/50 space-y-2">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-cyan-400" /> Quick SMS Draft
              </label>
              <div className="flex gap-2">
                <input
                  type="tel"
                  placeholder="Number..."
                  value={smsNumber}
                  onChange={(e) => setSmsNumber(e.target.value)}
                  className="w-1/3 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
                <input
                  type="text"
                  placeholder="Message..."
                  value={smsText}
                  onChange={(e) => setSmsText(e.target.value)}
                  className="flex-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
                <a
                  href={smsNumber ? `sms:${smsNumber}?body=${encodeURIComponent(smsText)}` : '#'}
                  onClick={(e) => {
                    if (!smsNumber) {
                      e.preventDefault();
                      alert('Pehle recipient number enter karein');
                    }
                  }}
                  className={`px-3 py-1.5 rounded-lg font-medium text-xs flex items-center gap-1 transition ${
                    smsNumber
                      ? 'bg-cyan-600 hover:bg-cyan-500 text-white cursor-pointer shadow-md'
                      : 'bg-slate-700 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <MessageSquare className="w-3.5 h-3.5" /> SMS
                </a>
              </div>
            </div>
          </div>

          {/* Quick AI Phone Prompts */}
          <div>
            <span className="text-xs font-semibold text-slate-400 mb-2 block">
              ⚡ Ask AI to automate Phone & Daily tasks:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {[
                '📱 Phone ki battery save karne ke best settings batao',
                '✉️ WhatsApp ke liye ek professional leave message draft karo',
                '🎉 Ek funny birthday wish message likho dost ke liye',
                '📅 Mere din ka productive schedule plan karke do',
                '📞 Ek polite business inquiry call script prepare karo',
              ].map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    onSendPrompt(p);
                    onClose();
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-cyan-900/40 hover:text-cyan-200 border border-slate-700/60 hover:border-cyan-500/40 text-xs text-slate-300 transition text-left cursor-pointer"
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Smart Reminders & Tasks */}
          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/50 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-yellow-400" /> Phone Reminders & Alarms
              </label>
              <span className="text-[11px] text-slate-400">{reminders.filter((r) => !r.done).length} Pending</span>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="New reminder (e.g. Call client / Take medicine)..."
                value={newReminderText}
                onChange={(e) => setNewReminderText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addReminder()}
                className="flex-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
              <input
                type="time"
                value={newReminderTime}
                onChange={(e) => setNewReminderTime(e.target.value)}
                className="px-2 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-cyan-500"
              />
              <button
                onClick={addReminder}
                className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs flex items-center gap-1 cursor-pointer transition shadow"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>

            <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
              {reminders.length === 0 ? (
                <div className="text-xs text-slate-500 py-2 text-center">No reminders set. Add one above!</div>
              ) : (
                reminders.map((r) => (
                  <div
                    key={r.id}
                    className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition ${
                      r.done
                        ? 'bg-slate-900/40 text-slate-500 line-through'
                        : 'bg-slate-900/80 text-slate-200 border border-slate-800'
                    }`}
                  >
                    <div
                      onClick={() => toggleReminder(r.id)}
                      className="flex items-center gap-2 cursor-pointer flex-1"
                    >
                      <CheckCircle
                        className={`w-4 h-4 ${r.done ? 'text-emerald-500' : 'text-slate-600 hover:text-cyan-400'}`}
                      />
                      <span>{r.text}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono">
                        {r.time}
                      </span>
                    </div>
                    <button
                      onClick={() => deleteReminder(r.id)}
                      className="text-slate-500 hover:text-red-400 p-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Persistent Scratchpad / Quick Notes */}
          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/50 space-y-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-violet-400" /> Phone Scratchpad & Quick Memo (Auto-saved)
            </label>
            <textarea
              value={notes}
              onChange={(e) => handleNotesChange(e.target.value)}
              placeholder="Jot down numbers, thoughts, shopping items..."
              rows={3}
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-sans"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Phone Assistant Toolkit Active</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
