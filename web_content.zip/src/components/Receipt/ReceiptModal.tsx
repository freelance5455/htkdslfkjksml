import React from 'react';
import { 
  Printer, 
  Share2, 
  Copy, 
  Check, 
  X, 
  Store, 
  Phone, 
  MapPin, 
  PlusCircle, 
  Clock, 
  User,
  ShoppingBag
} from 'lucide-react';
import { SaleInvoice, StoreProfile } from '../../types';
import { formatBengaliDateTime, toBnNum } from '../../utils/formatters';

interface ReceiptModalProps {
  invoice: SaleInvoice | null;
  isOpen: boolean;
  onClose: () => void;
  onNewSale: () => void;
  storeProfile: StoreProfile;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  invoice,
  isOpen,
  onClose,
  onNewSale,
  storeProfile,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen || !invoice) return null;

  // Direct Browser Print
  const handlePrint = () => {
    window.print();
  };

  // WhatsApp formatted message share
  const handleWhatsAppShare = () => {
    if (!invoice) return;
    const itemList = invoice.items
      .map(
        (i, idx) =>
          `${idx + 1}. ${i.nameBn}: ${i.quantity} ${i.unit} × ৳${i.sellPrice} = ৳${i.lineTotal}`
      )
      .join('\n');

    const message = `*${storeProfile.name}*
${storeProfile.address} | ফোন: ${storeProfile.phone}
----------------------------------
মেমো নং: ${invoice.invoiceNo}
তারিখ: ${new Date(invoice.createdAt).toLocaleDateString('bn-BD')}
ক্রেতা: ${invoice.customerName || 'সম্মানিত ক্রেতা'}
----------------------------------
*ক্রয়কৃত পণ্যসমূহ:*
${itemList}
----------------------------------
সর্বমোট বিল: ৳${invoice.subtotal}
${invoice.discount > 0 ? `বিশেষ ছাড়: ৳${invoice.discount}\n` : ''}মোট প্রদেয়: ৳${invoice.netTotal}
পরিশোধিত টাকা: ৳${invoice.paidAmount}
${invoice.changeAmount > 0 ? `*ফেরত টাকা:* ৳${invoice.changeAmount}\n` : ''}${invoice.dueAmount > 0 ? `*বকেয়া / বাকি:* ৳${invoice.dueAmount}\n` : ''}----------------------------------
${storeProfile.receiptFooterMessage}`;

    const encoded = encodeURIComponent(message);
    const phone = invoice.customerPhone ? invoice.customerPhone.replace(/[^0-9]/g, '') : '';
    const url = phone ? `https://wa.me/88${phone}?text=${encoded}` : `https://wa.me/?text=${encoded}`;
    window.open(url, '_blank');
  };

  // Copy text memo
  const handleCopyText = () => {
    const itemList = invoice.items
      .map(
        (i, idx) =>
          `${idx + 1}. ${i.nameBn} - ${i.quantity} ${i.unit} = ৳${i.lineTotal}`
      )
      .join('\n');

    const text = `=== ${storeProfile.name} ===
মেমো নং: ${invoice.invoiceNo}
তারিখ: ${new Date(invoice.createdAt).toLocaleString('bn-BD')}
-------------------------------
${itemList}
-------------------------------
মোট প্রদেয়: ৳${invoice.netTotal}
কাস্টমার দিল: ৳${invoice.paidAmount}
ফেরত পাবে: ৳${invoice.changeAmount}
${invoice.dueAmount > 0 ? `বাকি: ৳${invoice.dueAmount}\n` : ''}ধন্যবাদ!`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200">
        
        {/* Modal Top Control Bar (Hidden when printing) */}
        <div className="bg-emerald-800 text-white p-3.5 flex items-center justify-between no-print">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-emerald-300" />
            <span className="font-semibold text-sm sm:text-base">সুপারশপ ক্যাশ মেমো / রিসিট</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Receipt Area */}
        <div className="p-4 sm:p-6 max-h-[75vh] overflow-y-auto bg-slate-50">
          
          {/* Printable Receipt Container */}
          <div 
            id="printable-receipt" 
            className="bg-white p-5 rounded-xl shadow-xs border border-slate-200 text-slate-800 font-sans mx-auto max-w-[380px]"
          >
            {/* Store Header */}
            <div className="text-center pb-3 border-b border-dashed border-slate-300">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <Store className="w-4 h-4 text-emerald-700" />
                <h2 className="font-bold text-lg text-slate-900 leading-tight">
                  {storeProfile.name}
                </h2>
              </div>
              <p className="text-xs text-slate-600 mb-0.5">{storeProfile.tagline}</p>
              <div className="text-[11px] text-slate-500 flex items-center justify-center gap-1">
                <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                <span>{storeProfile.address}</span>
              </div>
              <div className="text-[11px] text-slate-500 flex items-center justify-center gap-1 mt-0.5">
                <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                <span>হেল্পলাইন: {storeProfile.phone}</span>
              </div>
            </div>

            {/* Invoice Meta */}
            <div className="py-2.5 text-[11px] text-slate-600 border-b border-dashed border-slate-300 space-y-1">
              <div className="flex justify-between">
                <span>মেমো নং: <strong className="text-slate-900">{invoice.invoiceNo}</strong></span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {formatBengaliDateTime(invoice.createdAt)}
                </span>
              </div>
              {invoice.customerName && (
                <div className="flex justify-between items-center text-slate-800 font-medium">
                  <span className="flex items-center gap-1">
                    <User className="w-3 h-3 text-emerald-600" />
                    ক্রেতা: {invoice.customerName}
                  </span>
                  {invoice.customerPhone && (
                    <span className="text-slate-500">{invoice.customerPhone}</span>
                  )}
                </div>
              )}
              <div className="flex justify-between text-slate-500">
                <span>ক্যাশিয়ার: {invoice.cashierName}</span>
                <span>মাধ্যম: {invoice.paymentMethod === 'CASH' ? 'নগদ ক্যাশ' : invoice.paymentMethod === 'BKASH' ? 'বিকাশ / এমএফএস' : invoice.paymentMethod === 'DUE' ? 'বাকিতে বিক্রয়' : 'অন্যান্য'}</span>
              </div>
            </div>

            {/* Items Table */}
            <div className="py-2.5">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-300 text-slate-600">
                    <th className="text-left py-1 font-semibold">পণ্য</th>
                    <th className="text-center py-1 font-semibold">পরিমাণ</th>
                    <th className="text-right py-1 font-semibold">দর</th>
                    <th className="text-right py-1 font-semibold">মোট</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {invoice.items.map((item, idx) => (
                    <tr key={idx} className="py-1">
                      <td className="py-1 text-slate-800 font-medium">
                        <div>{item.nameBn}</div>
                        {item.nameEn && <div className="text-[10px] text-slate-600">{item.nameEn}</div>}
                      </td>
                      <td className="py-1 text-center font-mono tabular-nums text-slate-700">
                        {toBnNum(item.quantity)} {item.unit}
                      </td>
                      <td className="py-1 text-right font-mono tabular-nums text-slate-600">
                        ৳{toBnNum(item.sellPrice)}
                      </td>
                      <td className="py-1 text-right font-mono tabular-nums font-semibold text-slate-900">
                        ৳{toBnNum(item.lineTotal)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Calculation Breakdown */}
            <div className="pt-2 border-t border-dashed border-slate-300 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>সর্বমোট আইটেম মূল্য:</span>
                <span className="font-mono tabular-nums">৳ {toBnNum(invoice.subtotal)}</span>
              </div>

              {invoice.discount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>বিশেষ ছাড় (ডিসকাউন্ট):</span>
                  <span className="font-mono tabular-nums">- ৳ {toBnNum(invoice.discount)}</span>
                </div>
              )}

              <div className="flex justify-between text-sm font-bold text-slate-900 pt-1 border-t border-slate-200">
                <span>মোট প্রদেয় বিল:</span>
                <span className="font-mono tabular-nums text-emerald-800">৳ {toBnNum(invoice.netTotal)}</span>
              </div>

              {/* Cash Paid by Customer */}
              <div className="flex justify-between text-xs text-slate-700 pt-0.5">
                <span>কাস্টমার পরিশোধ করল (Cash):</span>
                <span className="font-mono tabular-nums font-semibold">৳ {toBnNum(invoice.paidAmount)}</span>
              </div>

              {/* Highlighted Change Return to Customer */}
              {invoice.changeAmount > 0 && (
                <div className="flex justify-between items-center p-2 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-900 font-bold text-sm my-1">
                  <span>কাস্টমার ফেরত পাবে:</span>
                  <span className="text-base font-mono tabular-nums text-emerald-700">
                    ৳ {toBnNum(invoice.changeAmount)}
                  </span>
                </div>
              )}

              {/* Due Warning if Customer paid less */}
              {invoice.dueAmount > 0 && (
                <div className="flex justify-between items-center p-2 rounded-lg bg-amber-50 border border-amber-300 text-amber-900 font-bold text-xs my-1">
                  <span>বকেয়া / বাকি টাকা:</span>
                  <span className="font-mono tabular-nums text-amber-800">
                    ৳ {toBnNum(invoice.dueAmount)}
                  </span>
                </div>
              )}
            </div>

            {/* Barcode Mock & Thank you note */}
            <div className="mt-4 pt-3 text-center border-t border-dashed border-slate-300 space-y-1.5">
              {/* Pseudo Barcode Visual */}
              <div className="flex justify-center items-center gap-[2px] h-7 px-4">
                {[4, 2, 6, 2, 8, 4, 2, 7, 3, 5, 2, 6, 4, 3, 7, 2, 5, 2, 8, 3, 4].map((h, i) => (
                  <div
                    key={i}
                    style={{ height: `${h * 3}px` }}
                    className="w-[2px] bg-slate-800"
                  />
                ))}
              </div>
              <p className="text-[10px] font-mono text-slate-500 tracking-wider">
                {invoice.invoiceNo}
              </p>
              <p className="text-[11px] text-slate-600 font-medium">
                {storeProfile.receiptFooterMessage}
              </p>
              <div className="pt-2 text-[9px] text-slate-400 font-sans tracking-wide">
                Designed and Developed with ❤️ by Sheikh Akash
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons Panel (Hidden in print) */}
        <div className="p-3.5 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 no-print">
          <div className="flex items-center gap-1.5">
            {/* Print Button */}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 text-white rounded-lg hover:bg-emerald-800 text-xs sm:text-sm font-semibold shadow-sm transition"
            >
              <Printer className="w-4 h-4" />
              <span>প্রিন্ট রসিদ</span>
            </button>

            {/* WhatsApp Share */}
            <button
              onClick={handleWhatsAppShare}
              className="flex items-center gap-1.5 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-xs sm:text-sm font-medium transition"
              title="হোয়াটসঅ্যাপে ডিজিটাল কপি পাঠান"
            >
              <Share2 className="w-4 h-4" />
              <span className="hidden sm:inline">হোয়াটসঅ্যাপ</span>
            </button>

            {/* Copy Text */}
            <button
              onClick={handleCopyText}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 text-xs sm:text-sm font-medium transition"
              title="রিসিট টেক্সট কপি করুন"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              <span className="hidden sm:inline">{copied ? 'কপি হয়েছে' : 'কপি'}</span>
            </button>
          </div>

          {/* New Sale Button */}
          <button
            onClick={() => {
              onClose();
              onNewSale();
            }}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 text-xs sm:text-sm font-semibold transition ml-auto"
          >
            <PlusCircle className="w-4 h-4 text-emerald-400" />
            <span>নতুন কাস্টমার / বিক্রয়</span>
          </button>
        </div>

      </div>
    </div>
  );
};
