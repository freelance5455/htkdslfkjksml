import React, { useState } from 'react';
import {
  AlertCircle,
  Check,
  Copy,
  Eye,
  FileCode2,
  FolderCheck,
  KeyRound,
} from 'lucide-react';
import type { ChatMessage } from '../types/mycode';
import { parseResponseSegments } from '../utils/codeParser';
import { HighlightedCode } from '../utils/syntaxHighlight';

interface ChatThreadProps {
  messages: ChatMessage[];
  desktopView: boolean;
  onOpenFileInWorkspace: (filePath: string) => void;
  onSaveSnippetToWorkspace: (filePath: string, code: string, language: string) => void;
  onOpenApiKeys: () => void;
}

function renderInlineFormatting(text: string): React.ReactNode[] {
  // Split inline code `...` and bold **...** cleanly
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*)/g);
  return parts.map((part, idx) => {
    if (part.startsWith('`') && part.endsWith('`') && part.length >= 2) {
      return (
        <code
          key={idx}
          className="rounded bg-[#F3F4F6] px-1.5 py-0.5 font-mono text-[0.86em] text-[#111827]"
        >
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith('**') && part.endsWith('**') && part.length >= 4) {
      return (
        <strong key={idx} className="font-semibold text-[#111827]">
          {part.slice(2, -2)}
        </strong>
      );
    }
    return <React.Fragment key={idx}>{part}</React.Fragment>;
  });
}

function MarkdownProse({ text, compact }: { text: string; compact: boolean }) {
  const lines = text.trim().split('\n');
  if (lines.length === 1 && !lines[0]) return null;

  return (
    <div className={`space-y-2 text-[#111827] ${compact ? 'text-[13px] leading-6' : 'text-[15px] leading-relaxed'}`}>
      {lines.map((line, idx) => {
        const trimmed = line.trim();
        if (!trimmed) {
          return <div key={idx} className="h-1" />;
        }
        if (trimmed.startsWith('### ')) {
          return (
            <h4 key={idx} className="pt-2 font-display text-[14px] font-semibold text-[#111827]">
              {renderInlineFormatting(trimmed.slice(4))}
            </h4>
          );
        }
        if (trimmed.startsWith('## ')) {
          return (
            <h3 key={idx} className="pt-2 font-display text-[15px] font-semibold text-[#111827]">
              {renderInlineFormatting(trimmed.slice(3))}
            </h3>
          );
        }
        if (trimmed.startsWith('# ')) {
          return (
            <h2 key={idx} className="pt-2 font-display text-[17px] font-bold text-[#111827]">
              {renderInlineFormatting(trimmed.slice(2))}
            </h2>
          );
        }
        if (/^[-*]\s+/.test(trimmed)) {
          return (
            <div key={idx} className="flex items-start gap-2 pl-1">
              <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-[#6B7280]" aria-hidden="true" />
              <span>{renderInlineFormatting(trimmed.replace(/^[-*]\s+/, ''))}</span>
            </div>
          );
        }
        if (/^\d+\.\s+/.test(trimmed)) {
          const numMatch = trimmed.match(/^(\d+\.)\s+(.*)$/);
          if (numMatch) {
            return (
              <div key={idx} className="flex items-start gap-2 pl-1">
                <span className="font-mono text-[12px] text-[#6B7280] tabular-nums mt-0.5">
                  {numMatch[1]}
                </span>
                <span>{renderInlineFormatting(numMatch[2])}</span>
              </div>
            );
          }
        }
        return <p key={idx}>{renderInlineFormatting(line)}</p>;
      })}
    </div>
  );
}

function CodeBlockCard({
  code,
  language,
  filePath,
  isClosed,
  compact,
  onOpenFileInWorkspace,
  onSaveSnippetToWorkspace,
}: {
  code: string;
  language: string;
  filePath: string | null;
  isClosed: boolean;
  compact: boolean;
  onOpenFileInWorkspace: (path: string) => void;
  onSaveSnippetToWorkspace: (path: string, code: string, language: string) => void;
}) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Fallback ignored
    }
  };

  const displayTitle = filePath || language || 'snippet';

  return (
    <div className="my-3 overflow-hidden rounded-xl border border-[#E5E7EB] bg-[#FAFAFA]">
      <div className="flex items-center justify-between gap-2 border-b border-[#E5E7EB] bg-[#F9FAFB] px-3 py-2">
        <div className="flex min-w-0 items-center gap-2">
          <FileCode2 className="h-3.5 w-3.5 shrink-0 text-[#4B5563]" />
          <span className="truncate font-mono text-[12px] font-medium text-[#111827]">
            {displayTitle}
          </span>
          {filePath && language && (
            <span className="hidden sm:inline text-[11px] text-[#6B7280] whitespace-nowrap">
              {language}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {filePath && isClosed && (
            <button
              type="button"
              onClick={() => {
                onSaveSnippetToWorkspace(filePath, code, language);
                onOpenFileInWorkspace(filePath);
              }}
              className="inline-flex items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-2 py-1 text-[11px] font-medium text-[#111827] hover:bg-[#F3F4F6] transition-colors whitespace-nowrap"
            >
              <Eye className="h-3 w-3 text-[#4B5563]" />
              <span>View</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-2 py-1 text-[11px] font-medium text-[#111827] hover:bg-[#F3F4F6] transition-colors whitespace-nowrap"
          >
            {copied ? (
              <>
                <Check className="h-3 w-3 text-[#047857]" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="h-3 w-3 text-[#4B5563]" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
      </div>

      <HighlightedCode
        code={code}
        language={language}
        showLineNumbers={compact}
        compact={compact}
      />
    </div>
  );
}

export function ChatThread({
  messages,
  desktopView,
  onOpenFileInWorkspace,
  onSaveSnippetToWorkspace,
  onOpenApiKeys,
}: ChatThreadProps) {
  return (
    <div
      className={`mx-auto w-full ${
        desktopView ? 'max-w-none px-4 py-4 space-y-5' : 'max-w-3xl px-4 py-6 space-y-7'
      }`}
    >
      {messages.map((msg) => {
        if (msg.role === 'user') {
          return (
            <div key={msg.id} className="flex justify-end">
              <div
                className={`max-w-[88%] sm:max-w-[78%] rounded-2xl border border-[#E5E7EB] bg-[#F9FAFB] px-4 py-3 text-[#111827] ${
                  desktopView ? 'text-[13px]' : 'text-[15px]'
                }`}
              >
                {msg.attachments && msg.attachments.length > 0 && (
                  <div className="mb-2 flex flex-wrap gap-2">
                    {msg.attachments.map((att) =>
                      att.kind === 'image' && att.previewUrl ? (
                        <img
                          key={att.id}
                          src={att.previewUrl}
                          alt={att.name}
                          referrerPolicy="no-referrer"
                          className="h-16 w-16 rounded-lg border border-[#E5E7EB] object-cover"
                        />
                      ) : (
                        <span
                          key={att.id}
                          className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5E7EB] bg-white px-2.5 py-1 font-mono text-[11px] text-[#374151]"
                        >
                          <FileCode2 className="h-3 w-3 text-[#6B7280]" />
                          <span className="truncate max-w-[160px]">{att.name}</span>
                        </span>
                      )
                    )}
                  </div>
                )}
                {msg.content && <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>}
              </div>
            </div>
          );
        }

        const segments = parseResponseSegments(msg.content);
        const showKeyShortcut =
          msg.error &&
          (msg.error.toLowerCase().includes('api key') ||
            msg.error.toLowerCase().includes('missing') ||
            msg.error.toLowerCase().includes('401') ||
            msg.error.toLowerCase().includes('403'));

        return (
          <div key={msg.id} className="space-y-2">
            <div className="flex items-center gap-2 text-[12px] text-[#6B7280]">
              <span className="font-display font-semibold text-[#111827]">MyCode</span>
              {msg.modelLabel && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{msg.modelLabel}</span>
                </>
              )}
              {msg.isStreaming && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>Generating...</span>
                </>
              )}
            </div>

            {segments.map((seg, idx) =>
              seg.type === 'markdown' ? (
                <MarkdownProse key={idx} text={seg.text} compact={desktopView} />
              ) : (
                <CodeBlockCard
                  key={idx}
                  code={seg.code}
                  language={seg.language}
                  filePath={seg.filePath}
                  isClosed={seg.isClosed}
                  compact={desktopView}
                  onOpenFileInWorkspace={onOpenFileInWorkspace}
                  onSaveSnippetToWorkspace={onSaveSnippetToWorkspace}
                />
              )
            )}

            {msg.isStreaming && segments.length === 0 && (
              <div className="py-2 text-[13px] text-[#6B7280]">Thinking...</div>
            )}

            {msg.syncedFiles && msg.syncedFiles.length > 0 && !msg.isStreaming && (
              <div className="pt-1 flex flex-wrap items-center gap-1.5 text-[12px] text-[#4B5563]">
                <FolderCheck className="h-3.5 w-3.5 text-[#047857]" />
                <span>Saved to workspace:</span>
                {msg.syncedFiles.map((path, i) => (
                  <React.Fragment key={path}>
                    <button
                      type="button"
                      onClick={() => onOpenFileInWorkspace(path)}
                      className="font-mono text-[12px] font-medium text-[#111827] underline decoration-[#D1D5DB] underline-offset-2 hover:decoration-[#111827]"
                    >
                      {path}
                    </button>
                    {i < msg.syncedFiles!.length - 1 && <span aria-hidden="true">·</span>}
                  </React.Fragment>
                ))}
              </div>
            )}

            {msg.error && (
              <div className="mt-2 rounded-xl border border-[#FECACA] bg-[#FEF2F2] p-3.5 text-[13px] text-[#991B1B]">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-[#DC2626]" />
                  <div className="flex-1 space-y-2">
                    <p>{msg.error}</p>
                    {showKeyShortcut && (
                      <button
                        type="button"
                        onClick={onOpenApiKeys}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-[#FCA5A5] bg-white px-3 py-1.5 text-[12px] font-medium text-[#991B1B] hover:bg-[#FEF2F2] transition-colors"
                      >
                        <KeyRound className="h-3.5 w-3.5" />
                        <span>Open API Keys & Models</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
