import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft, Search, MoreVertical, Send, Image as ImageIcon, Smile,
  CornerUpLeft, Trash2, Check, CheckCheck, X, ShieldAlert,
  VolumeX, Volume2, ShieldBan, Flag, Phone, Video,
  Paperclip, Package, Download, Smartphone, CheckCircle2, FileText, Share2
} from 'lucide-react';
import type { User, Chat, Message } from '../types/index.ts';
import { api, wsClient } from '../services/api.ts';
import { BlueTick } from './BlueTick.tsx';

interface ChatThreadProps {
  chat: Chat;
  currentUser: User;
  onBack: () => void;
  onOpenReport: (reportedUserId: string, reportedUsername: string, messageId?: string, evidence?: string) => void;
  onOpenWhatsApp: () => void;
  onStartCall?: (targetUser: User, isVideo: boolean) => void;
}

const GAMING_EMOJIS = ['🔥', '⚡', '🎯', '👑', '💀', '🏆', 'GG', '💯', '🎮', '⚔️', '🛡️', '💣', '🚀', '😎', '👍', '❤️'];

export const ChatThread: React.FC<ChatThreadProps> = ({
  chat,
  currentUser,
  onBack,
  onOpenReport,
  onOpenWhatsApp,
  onStartCall,
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [searchInChat, setSearchInChat] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);
  const [activeTyping, setActiveTyping] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedMessageForAction, setSelectedMessageForAction] = useState<Message | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const apkInputRef = useRef<HTMLInputElement>(null);
  const genericFileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimerRef = useRef<any>(null);

  // Determine chat title & other participant for DMs
  const isDirect = chat.type === 'direct';
  const otherUserId = isDirect ? chat.participants.find(p => p !== currentUser.id) : null;
  const [otherUser, setOtherUser] = useState<User | null>(null);

  useEffect(() => {
    if (isDirect && otherUserId) {
      api.getUserById(otherUserId).then((u: User) => setOtherUser(u));
    }
  }, [isDirect, otherUserId]);

  const loadMessages = async () => {
    try {
      const msgs = await api.getMessages(chat.id, currentUser.id);
      setMessages(msgs);
      // Mark read
      await api.markChatRead(chat.id, currentUser.id);
    } catch (e) {
      console.error('Failed to load messages', e);
    }
  };

  useEffect(() => {
    loadMessages();

    // WS listeners
    const unsubMsg = wsClient.on('message:new', (data) => {
      if (data.chatId === chat.id) {
        setMessages(prev => {
          if (prev.some(m => m.id === data.message.id)) return prev;
          return [...prev, data.message];
        });
        api.markChatRead(chat.id, currentUser.id);
      }
    });

    const unsubRead = wsClient.on('message:read_receipt', (data) => {
      if (data.chatId === chat.id) {
        setMessages(prev => prev.map(m => {
          if (data.messageIds?.includes(m.id)) {
            const readBy = m.readBy.includes(data.readByUserId) ? m.readBy : [...m.readBy, data.readByUserId];
            return { ...m, readBy };
          }
          return m;
        }));
      }
    });

    const unsubTyping = wsClient.on('chat:typing', (data) => {
      if (data.chatId === chat.id && data.userId !== currentUser.id) {
        if (data.isTyping) {
          setActiveTyping(data.username);
        } else {
          setActiveTyping(null);
        }
      }
    });

    const unsubDeleted = wsClient.on('message:deleted_for_everyone', (data) => {
      setMessages(prev => prev.map(m => {
        if (m.id === data.messageId) {
          return {
            ...m,
            isDeletedForEveryone: true,
            text: '🚫 This message was deleted',
            mediaUrl: undefined,
            mediaType: undefined,
          };
        }
        return m;
      }));
    });

    return () => {
      unsubMsg();
      unsubRead();
      unsubTyping();
      unsubDeleted();
    };
  }, [chat.id, currentUser.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);

    // Broadcast typing indicator
    wsClient.send({
      type: 'chat:typing',
      chatId: chat.id,
      userId: currentUser.id,
      username: currentUser.username,
      participants: chat.participants,
      isTyping: true,
    });

    clearTimeout(typingTimerRef.current);
    typingTimerRef.current = setTimeout(() => {
      wsClient.send({
        type: 'chat:typing',
        chatId: chat.id,
        userId: currentUser.id,
        username: currentUser.username,
        participants: chat.participants,
        isTyping: false,
      });
    }, 1500);
  };

  const handleSendMessage = async (
    mediaUrl?: string,
    mediaType?: 'image' | 'file' | 'apk',
    fileName?: string,
    fileSize?: string
  ) => {
    if (!inputText.trim() && !mediaUrl) return;

    const payload = {
      senderId: currentUser.id,
      text: inputText.trim(),
      mediaUrl,
      mediaType,
      fileName,
      fileSize,
      replyTo: replyingTo ? {
        id: replyingTo.id,
        text: replyingTo.text || (
          replyingTo.mediaType === 'image' ? '📷 Image' :
          replyingTo.mediaType === 'apk' ? `📦 APK: ${replyingTo.fileName || 'App Package'}` :
          '📎 Attachment'
        ),
        senderName: replyingTo.senderName,
      } : undefined,
    };

    setInputText('');
    setReplyingTo(null);
    setShowEmojiPicker(false);
    setShowAttachMenu(false);

    try {
      const res = await api.sendMessage(chat.id, payload);
      if (res.success && res.message) {
        setMessages(prev => {
          if (prev.some(m => m.id === res.message.id)) return prev;
          return [...prev, res.message];
        });
      }
    } catch (e: any) {
      alert(e.message || 'Failed to send message');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setShowAttachMenu(false);
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      handleSendMessage(dataUrl, 'image', file.name);
    };
    reader.readAsDataURL(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleApkUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setShowAttachMenu(false);
    const formattedSize = file.size >= 1048576
      ? (file.size / (1024 * 1024)).toFixed(1) + ' MB'
      : (file.size / 1024).toFixed(1) + ' KB';

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      handleSendMessage(
        dataUrl,
        'apk',
        file.name.toLowerCase().endsWith('.apk') ? file.name : `${file.name}.apk`,
        formattedSize
      );
    };
    reader.readAsDataURL(file);
    if (apkInputRef.current) apkInputRef.current.value = '';
  };

  const handleGenericFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setShowAttachMenu(false);
    if (file.name.toLowerCase().endsWith('.apk')) {
      handleApkUpload(e);
      return;
    }

    const formattedSize = file.size >= 1048576
      ? (file.size / (1024 * 1024)).toFixed(1) + ' MB'
      : (file.size / 1024).toFixed(1) + ' KB';

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      handleSendMessage(dataUrl, 'file', file.name, formattedSize);
    };
    reader.readAsDataURL(file);
    if (genericFileInputRef.current) genericFileInputRef.current.value = '';
  };

  const handleShareOfficialAPK = () => {
    setShowAttachMenu(false);
    // Create pre-packaged official Unknown Gamer Android APK package representation
    const manifestInfo = `Unknown Gamer Esports Android v2.4.0 (Anti-Ban Enabled, 120 FPS Scrims Mode)\nPackage: com.unknowngamer.esports\nBuild: Release-2026-Arm64`;
    const blob = new Blob([manifestInfo], { type: 'application/vnd.android.package-archive' });
    const reader = new FileReader();
    reader.onload = () => {
      handleSendMessage(
        reader.result as string,
        'apk',
        'UnknownGamer_v2.4.0_Official.apk',
        '18.6 MB'
      );
    };
    reader.readAsDataURL(blob);
  };

  const handleDownloadFile = (url: string, filename: string) => {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDownloadAPK = (msg: Message) => {
    const filename = msg.fileName || 'UnknownGamer_app.apk';
    if (msg.mediaUrl && msg.mediaUrl.startsWith('data:')) {
      handleDownloadFile(msg.mediaUrl, filename);
      return;
    }
    const sampleBytes = `PK\x03\x04...UnknownGamer Esports Android v2.4.0 APK Package...`;
    const blob = new Blob([sampleBytes], { type: 'application/vnd.android.package-archive' });
    const url = URL.createObjectURL(blob);
    handleDownloadFile(url, filename);
    setTimeout(() => URL.revokeObjectURL(url), 3000);
  };

  const handleDeleteMessage = async (msg: Message, forEveryone: boolean) => {
    const res = await api.deleteMessage(msg.id, currentUser.id, forEveryone);
    if (res.success) {
      if (forEveryone) {
        setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, isDeletedForEveryone: true, text: '🚫 This message was deleted', mediaUrl: undefined } : m));
      } else {
        setMessages(prev => prev.filter(m => m.id !== msg.id));
      }
    } else {
      alert(res.error || 'Failed to delete message');
    }
    setSelectedMessageForAction(null);
  };

  const filteredMessages = messages.filter(m => {
    if (!searchQuery.trim()) return true;
    return m.text?.toLowerCase().includes(searchQuery.toLowerCase()) ||
           m.senderName?.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const chatTitle = isDirect ? (otherUser?.fullName || 'Gamer') : chat.name;
  const chatAvatar = isDirect ? (otherUser?.avatarUrl || 'https://api.dicebear.com/7.x/bottts/svg?seed=user') : chat.avatar;
  const isVerified = isDirect ? Boolean(otherUser?.verifiedBlueTick) : false;

  return (
    <div className="flex-1 flex flex-col h-full bg-[#080b12] text-slate-100 overflow-hidden relative">
      {/* Top Action Bar */}
      <header className="h-16 px-4 bg-[#0a0f18] border-b border-cyan-500/20 flex items-center justify-between shrink-0 z-20">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onBack}
            className="p-2 -ml-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-850 transition-colors cursor-pointer"
            aria-label="Back to chats"
          >
            <ArrowLeft size={20} />
          </button>

          <div className="relative shrink-0">
            <img
              src={chatAvatar}
              alt={chatTitle}
              className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-700 object-cover"
            />
            {isDirect && otherUser?.online && (
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-[#0a0f18]" />
            )}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5 font-bold text-white text-sm truncate">
              <span className="truncate">{chatTitle}</span>
              {isVerified && <BlueTick size="sm" />}
            </div>
            <div className="text-[11px] text-cyan-400 truncate">
              {activeTyping ? (
                <span className="animate-pulse">{activeTyping} is typing...</span>
              ) : isDirect ? (
                otherUser?.online ? 'Online' : 'Offline'
              ) : (
                `${chat.participants.length} Squad Members`
              )}
            </div>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1 relative">
          {isDirect && otherUser && onStartCall && (
            <>
              <button
                onClick={() => onStartCall(otherUser, false)}
                className="p-2 rounded-xl text-slate-400 hover:text-cyan-400 hover:bg-slate-900 transition-colors"
                title="Voice Call"
              >
                <Phone size={18} />
              </button>

              <button
                onClick={() => onStartCall(otherUser, true)}
                className="p-2 rounded-xl text-slate-400 hover:text-cyan-400 hover:bg-slate-900 transition-colors"
                title="Video Call"
              >
                <Video size={18} />
              </button>
            </>
          )}

          <button
            onClick={() => setSearchInChat(!searchInChat)}
            className="p-2 rounded-xl text-slate-400 hover:text-cyan-400 hover:bg-slate-900 transition-colors"
            title="Search in conversation"
          >
            <Search size={18} />
          </button>

          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 transition-colors"
            aria-label="Chat options"
          >
            <MoreVertical size={18} />
          </button>

          {/* Chat Dropdown Menu */}
          {menuOpen && (
            <div className="absolute right-0 top-12 w-48 rounded-xl bg-[#0c121e] border border-cyan-500/30 p-1.5 shadow-2xl z-30 text-xs">
              <button
                onClick={() => {
                  setIsMuted(!isMuted);
                  setMenuOpen(false);
                }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-left"
              >
                {isMuted ? <Volume2 size={15} /> : <VolumeX size={15} />}
                <span>{isMuted ? 'Unmute Chat' : 'Mute Notifications'}</span>
              </button>

              {isDirect && otherUser && (
                <>
                  <button
                    onClick={() => {
                      setIsBlocked(!isBlocked);
                      setMenuOpen(false);
                      alert(isBlocked ? `Unblocked @${otherUser.username}` : `Blocked @${otherUser.username}`);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-left"
                  >
                    <ShieldBan size={15} className="text-amber-400" />
                    <span>{isBlocked ? 'Unblock User' : 'Block User'}</span>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onOpenReport(otherUser.id, otherUser.username);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-red-400 hover:text-red-300 hover:bg-red-950/40 transition-colors text-left"
                  >
                    <Flag size={15} />
                    <span>Report Gamer</span>
                  </button>
                </>
              )}

              <div className="my-1 border-t border-slate-800" />

              <button
                onClick={() => {
                  setMenuOpen(false);
                  handleShareOfficialAPK();
                }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-cyan-300 hover:text-cyan-200 hover:bg-cyan-950/40 transition-colors text-left font-medium"
              >
                <Package size={15} className="text-cyan-400" />
                <span>Share Unknown Gamer APK</span>
              </button>

              <button
                onClick={() => {
                  setMenuOpen(false);
                  onOpenWhatsApp();
                }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/40 transition-colors text-left"
              >
                <Phone size={15} />
                <span>WhatsApp Service</span>
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Optional Search in Chat Bar */}
      {searchInChat && (
        <div className="px-4 py-2 bg-[#090d15] border-b border-slate-800 flex items-center gap-2 shrink-0">
          <Search size={16} className="text-slate-400" />
          <input
            type="text"
            placeholder="Search messages..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 bg-transparent text-xs text-white placeholder-slate-500 outline-none"
            autoFocus
          />
          <button
            onClick={() => {
              setSearchInChat(false);
              setSearchQuery('');
            }}
            className="p-1 text-slate-400 hover:text-white"
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {filteredMessages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 p-6">
            <div className="w-12 h-12 rounded-2xl bg-cyan-950/40 border border-cyan-500/20 flex items-center justify-center text-cyan-400 mb-2">
              <Smile size={24} />
            </div>
            <p className="text-xs text-slate-300 font-semibold">No messages yet</p>
            <p className="text-[11px] text-slate-500 mt-1">Start chatting in Unknown Gamer arena!</p>
          </div>
        ) : (
          filteredMessages.map((msg) => {
            const isMe = msg.senderId === currentUser.id;
            const isRead = msg.readBy.length > 1;
            const isDelivered = msg.deliveredTo.length > 1;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} group`}
              >
                {/* Chat Bubble */}
                <div
                  onClick={() => setSelectedMessageForAction(msg)}
                  className={`relative max-w-[82%] sm:max-w-md rounded-2xl px-3.5 py-2 text-xs transition-all shadow-md cursor-pointer ${
                    isMe
                      ? 'bg-gradient-to-tr from-blue-700 via-sky-600 to-cyan-600 text-white rounded-tr-xs'
                      : 'bg-[#151c28] border border-cyan-950/60 text-slate-100 rounded-tl-xs'
                  }`}
                >
                  {/* Sender Name in Group Chat */}
                  {!isDirect && !isMe && (
                    <div className="text-[10px] font-bold text-cyan-400 mb-1 flex items-center gap-1">
                      <span>@{msg.senderName}</span>
                    </div>
                  )}

                  {/* Quoted Reply */}
                  {msg.replyTo && (
                    <div className={`mb-1.5 p-2 rounded-lg border-l-2 text-[11px] ${
                      isMe ? 'bg-black/25 border-cyan-300 text-cyan-100' : 'bg-black/40 border-cyan-500 text-slate-300'
                    }`}>
                      <div className="font-semibold text-[10px] text-cyan-300">
                        {msg.replyTo.senderName}
                      </div>
                      <div className="truncate text-slate-200">{msg.replyTo.text}</div>
                    </div>
                  )}

                  {/* Image Attachment */}
                  {msg.mediaUrl && msg.mediaType === 'image' && (
                    <div className="mb-2 rounded-xl overflow-hidden max-h-60 bg-black/40">
                      <img
                        src={msg.mediaUrl}
                        alt="Shared media"
                        className="w-full h-auto object-cover cursor-pointer hover:opacity-95"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedImage(msg.mediaUrl!);
                        }}
                      />
                    </div>
                  )}

                  {/* APK Android Package Attachment Card */}
                  {msg.mediaType === 'apk' && (
                    <div className="mb-2 p-3 rounded-xl bg-gradient-to-br from-[#06101c] via-[#091526] to-[#071220] border border-cyan-400/40 shadow-[0_0_18px_rgba(0,210,255,0.18)] flex flex-col gap-2.5">
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-cyan-600/25 to-blue-600/25 border border-cyan-400/50 flex items-center justify-center text-cyan-300 shrink-0 shadow-[0_0_12px_rgba(0,210,255,0.35)]">
                          <Smartphone size={22} className="text-cyan-400 animate-pulse" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="font-mono font-bold text-white text-xs truncate">
                            {msg.fileName || 'UnknownGamer_v2.4.0.apk'}
                          </div>
                          <div className="flex items-center gap-2 text-[10px] text-cyan-300 font-mono mt-0.5">
                            <span className="px-1.5 py-0.2 rounded bg-cyan-400/15 border border-cyan-400/30 text-[9px] font-bold text-cyan-200">
                              APK PACKAGE
                            </span>
                            {msg.fileSize && <span>{msg.fileSize}</span>}
                            <span className="text-emerald-400 font-semibold flex items-center gap-0.5">
                              <CheckCircle2 size={11} /> Verified
                            </span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDownloadAPK(msg);
                        }}
                        className="w-full py-2 px-3 rounded-lg bg-gradient-to-r from-cyan-500 via-sky-400 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-cyan-500/25 active:scale-98 transition-all cursor-pointer"
                      >
                        <Download size={15} />
                        <span>Install / Download APK</span>
                      </button>
                    </div>
                  )}

                  {/* Generic File Attachment */}
                  {msg.mediaType === 'file' && (
                    <div className="mb-2 p-2.5 rounded-xl bg-slate-900/90 border border-slate-700/80 flex items-center justify-between gap-2.5">
                      <div className="flex items-center gap-2 min-w-0">
                        <FileText size={18} className="text-cyan-400 shrink-0" />
                        <div className="min-w-0">
                          <div className="text-xs truncate font-mono text-white font-medium">
                            {msg.fileName || 'Document'}
                          </div>
                          {msg.fileSize && (
                            <div className="text-[10px] text-slate-400 font-mono">
                              {msg.fileSize}
                            </div>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDownloadFile(msg.mediaUrl || '', msg.fileName || 'file');
                        }}
                        className="p-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-colors cursor-pointer shrink-0"
                        title="Download File"
                      >
                        <Download size={14} />
                      </button>
                    </div>
                  )}

                  {/* Message Text */}
                  <div className={`whitespace-pre-wrap break-words leading-relaxed ${msg.isDeletedForEveryone ? 'italic opacity-60' : ''}`}>
                    {msg.text}
                  </div>

                  {/* Timestamp & Status Ticks */}
                  <div className={`flex items-center justify-end gap-1 mt-1 text-[10px] ${isMe ? 'text-cyan-100/80' : 'text-slate-400'}`}>
                    <span>{new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    {isMe && !msg.isDeletedForEveryone && (
                      <span className="ml-0.5">
                        {isRead ? (
                          <CheckCheck size={14} className="text-cyan-300" />
                        ) : isDelivered ? (
                          <CheckCheck size={14} className="text-slate-300" />
                        ) : (
                          <Check size={14} className="text-slate-300" />
                        )}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Reply Preview Bar */}
      {replyingTo && (
        <div className="px-4 py-2 bg-[#0c121e] border-t border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 truncate">
            <CornerUpLeft size={16} className="text-cyan-400 shrink-0" />
            <div className="truncate">
              <span className="font-bold text-cyan-300">Replying to @{replyingTo.senderName}: </span>
              <span className="text-slate-400">{replyingTo.text}</span>
            </div>
          </div>
          <button onClick={() => setReplyingTo(null)} className="p-1 text-slate-400 hover:text-white">
            <X size={15} />
          </button>
        </div>
      )}

      {/* Quick Emojis Drawer */}
      {showEmojiPicker && (
        <div className="p-3 bg-[#0a0f18] border-t border-slate-800 flex flex-wrap gap-2 animate-in slide-in-from-bottom-2 duration-150">
          {GAMING_EMOJIS.map((emoji) => (
            <button
              key={emoji}
              onClick={() => {
                setInputText(prev => prev + ' ' + emoji);
              }}
              className="text-lg p-2 rounded-xl bg-slate-900 hover:bg-slate-800 hover:scale-110 active:scale-95 transition-transform"
            >
              {emoji}
            </button>
          ))}
        </div>
      )}

      {/* Attachment Options Drawer (APK, Game Files, Photos) */}
      {showAttachMenu && (
        <div className="p-3 bg-[#0a0f18] border-t border-cyan-500/30 grid grid-cols-2 sm:grid-cols-4 gap-2 animate-in slide-in-from-bottom-2 duration-150 z-20">
          <button
            onClick={() => apkInputRef.current?.click()}
            className="p-2.5 rounded-xl bg-gradient-to-br from-cyan-950/80 to-[#0e1626] border border-cyan-500/40 hover:border-cyan-400 flex items-center gap-2 text-left cursor-pointer transition-all group shadow-sm hover:shadow-[0_0_10px_rgba(0,210,255,0.2)]"
          >
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform shrink-0">
              <Package size={16} />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-white group-hover:text-cyan-300 truncate">Share Any APK</div>
              <div className="text-[10px] text-slate-400 truncate">Select .apk file</div>
            </div>
          </button>

          <button
            onClick={handleShareOfficialAPK}
            className="p-2.5 rounded-xl bg-gradient-to-br from-blue-950/80 to-[#0c1a2e] border border-blue-500/40 hover:border-blue-400 flex items-center gap-2 text-left cursor-pointer transition-all group shadow-sm hover:shadow-[0_0_10px_rgba(59,130,246,0.2)]"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 border border-blue-400/50 flex items-center justify-center text-blue-400 group-hover:scale-105 transition-transform shrink-0">
              <Smartphone size={16} />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-white group-hover:text-blue-300 truncate">Unknown Gamer APK</div>
              <div className="text-[10px] text-cyan-400 font-mono truncate">v2.4.0 (1-Tap Share)</div>
            </div>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-2.5 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-slate-500 flex items-center gap-2 text-left cursor-pointer transition-all group"
          >
            <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform shrink-0">
              <ImageIcon size={16} />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-white truncate">Photos & Media</div>
              <div className="text-[10px] text-slate-400 truncate">Screenshots, game art</div>
            </div>
          </button>

          <button
            onClick={() => genericFileInputRef.current?.click()}
            className="p-2.5 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-slate-500 flex items-center gap-2 text-left cursor-pointer transition-all group"
          >
            <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform shrink-0">
              <FileText size={16} />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-white truncate">Files & Docs</div>
              <div className="text-[10px] text-slate-400 truncate">Any file attachment</div>
            </div>
          </button>
        </div>
      )}

      {/* Hidden File Inputs */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleImageUpload}
        accept="image/*"
        className="hidden"
      />
      <input
        type="file"
        ref={apkInputRef}
        onChange={handleApkUpload}
        accept=".apk,application/vnd.android.package-archive"
        className="hidden"
      />
      <input
        type="file"
        ref={genericFileInputRef}
        onChange={handleGenericFileUpload}
        accept="*/*"
        className="hidden"
      />

      {/* Bottom Input Field */}
      <footer className="p-3 bg-[#0a0f18] border-t border-slate-800/80 flex items-center gap-2 shrink-0">
        <button
          onClick={() => {
            setShowEmojiPicker(!showEmojiPicker);
            setShowAttachMenu(false);
          }}
          className={`p-2 rounded-xl transition-colors cursor-pointer ${showEmojiPicker ? 'bg-cyan-950 text-cyan-400' : 'text-slate-400 hover:text-slate-200'}`}
          title="Emojis"
        >
          <Smile size={20} />
        </button>

        {/* Attachment Button */}
        <button
          onClick={() => {
            setShowAttachMenu(!showAttachMenu);
            setShowEmojiPicker(false);
          }}
          className={`p-2 rounded-xl transition-colors cursor-pointer ${showAttachMenu ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/40 shadow-[0_0_8px_rgba(0,210,255,0.3)]' : 'text-slate-400 hover:text-slate-200'}`}
          title="Share APK, Files or Photos"
        >
          <Paperclip size={20} />
        </button>

        {/* Quick APK Share Shortcut Button */}
        <button
          onClick={() => apkInputRef.current?.click()}
          className="p-2 rounded-xl text-cyan-400/80 hover:text-cyan-300 hover:bg-cyan-950/40 transition-colors cursor-pointer hidden sm:flex items-center gap-1 text-[11px] font-mono border border-cyan-500/20"
          title="Share APK directly"
        >
          <Package size={16} />
          <span className="font-bold">APK</span>
        </button>

        <input
          type="text"
          value={inputText}
          onChange={handleInputChange}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSendMessage();
            }
          }}
          placeholder="Type message in arena (or attach APK / game file)..."
          className="flex-1 px-4 py-2.5 rounded-xl bg-[#0e1524] border border-slate-700/80 text-white placeholder-slate-500 text-xs focus:border-cyan-400 outline-none transition-all"
        />

        <button
          onClick={() => handleSendMessage()}
          disabled={!inputText.trim()}
          className="w-10 h-10 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 flex items-center justify-center shadow-lg shadow-cyan-500/20 active:scale-95 transition-all cursor-pointer disabled:opacity-40"
        >
          <Send size={18} />
        </button>
      </footer>

      {/* MESSAGE ACTION MODAL (Reply / Delete / Report) */}
      {selectedMessageForAction && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-sm rounded-2xl bg-[#0c121e] border border-cyan-500/30 p-4 space-y-2 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400">
              <span className="font-semibold text-white">Message Options</span>
              <button onClick={() => setSelectedMessageForAction(null)}>
                <X size={16} />
              </button>
            </div>

            <button
              onClick={() => {
                setReplyingTo(selectedMessageForAction);
                setSelectedMessageForAction(null);
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl hover:bg-slate-800 text-slate-200"
            >
              <CornerUpLeft size={16} className="text-cyan-400" />
              <span>Reply to Message</span>
            </button>

            <button
              onClick={() => {
                navigator.clipboard.writeText(selectedMessageForAction.text);
                alert('Copied message');
                setSelectedMessageForAction(null);
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl hover:bg-slate-800 text-slate-200"
            >
              <Check size={16} className="text-emerald-400" />
              <span>Copy Text</span>
            </button>

            <button
              onClick={() => handleDeleteMessage(selectedMessageForAction, false)}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl hover:bg-slate-800 text-slate-200"
            >
              <Trash2 size={16} className="text-slate-400" />
              <span>Delete for Me</span>
            </button>

            {selectedMessageForAction.senderId === currentUser.id && (
              <button
                onClick={() => handleDeleteMessage(selectedMessageForAction, true)}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl hover:bg-red-950/50 text-red-400"
              >
                <Trash2 size={16} className="text-red-400" />
                <span>Delete for Everyone</span>
              </button>
            )}

            {selectedMessageForAction.senderId !== currentUser.id && (
              <button
                onClick={() => {
                  onOpenReport(
                    selectedMessageForAction.senderId,
                    selectedMessageForAction.senderName,
                    selectedMessageForAction.id,
                    selectedMessageForAction.text
                  );
                  setSelectedMessageForAction(null);
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl hover:bg-red-950/50 text-red-400"
              >
                <Flag size={16} className="text-red-400" />
                <span>Report Message</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Full Screen Image Viewer Modal */}
      {selectedImage && (
        <div
          onClick={() => setSelectedImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 cursor-zoom-out"
        >
          <img src={selectedImage} alt="Full view" className="max-w-full max-h-[90vh] rounded-xl object-contain" />
        </div>
      )}
    </div>
  );
};
