interface Props {
  /** оценка в пешках с точки зрения белых */
  pawns: number | null;
  /** мат: >0 — мат ставят белые за N ходов, <0 — чёрные, 0 — мат на доске */
  mate: number | null;
  /** кто выиграл при мате на доске (для mate === 0) */
  whiteWon?: boolean;
  flipped: boolean;
}

// Сжатие шкалы: 1 пешка ≈ 29%, 3 ≈ 55%, 9 ≈ 78% от половины шкалы
const squash = (p: number) => Math.sign(p) * (Math.abs(p) / (Math.abs(p) + 2.5));
const TICKS = [1, 2, 3, 5, 9];

export default function EvalBar({ pawns, mate, whiteWon, flipped }: Props) {
  const mateWhite = mate === null ? null : mate === 0 ? !!whiteWon : mate > 0;
  const whiteFrac = mateWhite !== null ? (mateWhite ? 1 : 0) : pawns === null ? 0.5 : 0.5 + 0.5 * squash(pawns);
  const label =
    mate !== null
      ? mate === 0
        ? '#'
        : `M${Math.abs(mate)}`
      : pawns === null
        ? '—'
        : `${pawns > 0 ? '+' : ''}${pawns.toFixed(1)}`;
  const whiteLeads = mateWhite !== null ? mateWhite : (pawns ?? 0) >= 0;

  const tickPos = (p: number) => 0.5 + 0.5 * squash(p);
  const whiteOnBottom = !flipped;
  const labelAtBottom = whiteLeads === whiteOnBottom;

  return (
    <div
      className="relative shrink-0 overflow-hidden rounded-md bg-zinc-800 shadow-lg ring-1 ring-black/40"
      style={{ width: 'clamp(28px, calc(var(--bs) / 8 * 0.5), 38px)', height: 'var(--bs)' }}
      title="Шкала пешечного эквивалента (в пешках)"
    >
      <div className="absolute inset-0 bg-zinc-800" />
      <div
        className="absolute left-0 right-0 bg-zinc-100 transition-all duration-500 ease-out"
        style={{ height: `${whiteFrac * 100}%`, [whiteOnBottom ? 'bottom' : 'top']: 0 }}
      />
      {[...TICKS, ...TICKS.map((t) => -t)].map((t) => {
        const frac = tickPos(t);
        const pos = whiteOnBottom ? (1 - frac) * 100 : frac * 100;
        return (
          <div key={t} className="absolute left-0 right-0 mix-blend-difference" style={{ top: `${pos}%` }}>
            <div className="h-px w-1/3 bg-white/90" />
            <span className="absolute -top-[5px] left-[38%] text-[8px] font-semibold leading-none text-white/90">
              {Math.abs(t)}
            </span>
          </div>
        );
      })}
      <div className="absolute left-0 right-0 top-1/2 h-px bg-emerald-500/90" />
      <div
        className={`absolute left-0 right-0 text-center text-[10px] font-bold leading-none ${
          whiteLeads ? 'text-zinc-900' : 'text-zinc-100'
        }`}
        style={labelAtBottom ? { bottom: 3 } : { top: 3 }}
      >
        {label}
      </div>
    </div>
  );
}
