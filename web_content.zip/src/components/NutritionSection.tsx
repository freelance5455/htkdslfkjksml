import React from "react";
import { Sparkles, Check } from "lucide-react";

export const NutritionSection: React.FC = () => {
  return (
    <section className="py-24 sm:py-32 px-6 bg-[#FDFBF7] border-b border-[#D8D0C2]/70">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column */}
          <div className="lg:col-span-6 space-y-6">
            <div className="text-xs font-semibold tracking-[0.25em] uppercase text-[#9BAF82]">
              TRANSPARENT NOURISHMENT
            </div>

            <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-[#17201C] leading-[1.05] tracking-tight">
              KNOW WHAT&apos;S
              <br />
              <span className="italic font-light">ON YOUR PLATE.</span>
            </h2>

            <p className="text-base sm:text-lg text-[#17201C]/80 font-sans leading-relaxed">
              &ldquo;Where available, we keep nutritional information clear so you can choose what works for you.&rdquo;
            </p>

            <p className="text-sm text-[#17201C]/70 font-sans leading-relaxed">
              We do not treat food as mere metrics. Rather, we view transparency as an extension of hospitality. Whether you are balancing protein intake or keeping an eye on dietary preferences, our kitchen ledger provides honest, verified clarity on printed cards.
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex items-start gap-3 text-sm text-[#17201C]/80">
                <span className="w-5 h-5 rounded-full bg-[#9BAF82]/20 flex items-center justify-center flex-shrink-0 mt-0.5 text-[#17201C]">
                  <Check className="w-3 h-3" />
                </span>
                <span>Unprocessed whole grains and sprouted pulses</span>
              </div>
              <div className="flex items-start gap-3 text-sm text-[#17201C]/80">
                <span className="w-5 h-5 rounded-full bg-[#9BAF82]/20 flex items-center justify-center flex-shrink-0 mt-0.5 text-[#17201C]">
                  <Check className="w-3 h-3" />
                </span>
                <span>Clean preparation without industrial seed oils or synthetic thickeners</span>
              </div>
              <div className="flex items-start gap-3 text-sm text-[#17201C]/80">
                <span className="w-5 h-5 rounded-full bg-[#9BAF82]/20 flex items-center justify-center flex-shrink-0 mt-0.5 text-[#17201C]">
                  <Check className="w-3 h-3" />
                </span>
                <span>Verified macronutrient breakdowns published where verified</span>
              </div>
            </div>
          </div>

          {/* Right Column: Quiet, Refined Editorial Metric Cards (Not a fitness dashboard!) */}
          <div className="lg:col-span-6 bg-[#F4F0E7] p-8 sm:p-10 rounded-sm border border-[#D8D0C2] paper-frame">
            <div className="flex items-center justify-between pb-6 border-b border-[#D8D0C2]/70 mb-6">
              <div className="font-serif italic text-lg text-[#17201C]">
                The Wholesome Standard
              </div>
              <span className="text-[11px] uppercase tracking-widest text-[#9BAF82] font-semibold flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Transparent Ledger
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4 sm:gap-6">
              <div className="p-5 bg-[#FDFBF7] border border-[#D8D0C2]/80 rounded-xs">
                <div className="text-xs uppercase tracking-widest text-[#17201C]/60 font-medium">
                  CALORIES
                </div>
                <div className="font-serif text-3xl text-[#17201C] mt-2 mb-1">
                  Balanced
                </div>
                <p className="text-[11px] text-[#17201C]/60 font-sans leading-tight">
                  Dishes calibrated for sustainable energy without midday slumps.
                </p>
              </div>

              <div className="p-5 bg-[#FDFBF7] border border-[#D8D0C2]/80 rounded-xs">
                <div className="text-xs uppercase tracking-widest text-[#17201C]/60 font-medium">
                  PROTEIN
                </div>
                <div className="font-serif text-3xl text-[#17201C] mt-2 mb-1">
                  Clean
                </div>
                <p className="text-[11px] text-[#17201C]/60 font-sans leading-tight">
                  Locally sourced coastal seafood, farm paneer, eggs, and sprouted legumes.
                </p>
              </div>

              <div className="p-5 bg-[#FDFBF7] border border-[#D8D0C2]/80 rounded-xs">
                <div className="text-xs uppercase tracking-widest text-[#17201C]/60 font-medium">
                  CARBOHYDRATES
                </div>
                <div className="font-serif text-3xl text-[#17201C] mt-2 mb-1">
                  Complex
                </div>
                <p className="text-[11px] text-[#17201C]/60 font-sans leading-tight">
                  Long-fermented wild sourdoughs, millets, and unpolished coastal grains.
                </p>
              </div>

              <div className="p-5 bg-[#FDFBF7] border border-[#D8D0C2]/80 rounded-xs">
                <div className="text-xs uppercase tracking-widest text-[#17201C]/60 font-medium">
                  FAT
                </div>
                <div className="font-serif text-3xl text-[#17201C] mt-2 mb-1">
                  Unrefined
                </div>
                <p className="text-[11px] text-[#17201C]/60 font-sans leading-tight">
                  Cold-pressed organic sesame, virgin olive oil, and crushed nuts.
                </p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#D8D0C2]/60 text-[11px] text-[#17201C]/50 font-sans text-center">
              Individual nutritional breakdowns for specific dishes are accessible within our dedicated interactive menu.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
