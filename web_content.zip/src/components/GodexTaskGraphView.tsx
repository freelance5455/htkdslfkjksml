import React from 'react';
import { 
  GitBranch, 
  Sparkles, 
  Cpu, 
  Code2, 
  Zap, 
  ShieldCheck, 
  Rocket, 
  CheckCircle2, 
  Clock, 
  Play, 
  RotateCcw,
  ArrowRight
} from 'lucide-react';
import { TaskState } from '../types';

interface GodexTaskGraphViewProps {
  taskState: TaskState;
  onPromptAgent: (prompt: string) => void;
  onRunVerification: () => void;
}

export const GodexTaskGraphView: React.FC<GodexTaskGraphViewProps> = ({
  taskState,
  onPromptAgent,
  onRunVerification
}) => {
  const pipelinePhases = [
    {
      id: 'phase-understand',
      title: 'Phase 1: Understand',
      desc: 'Ingest prompt, extract explicit intent, identify target components & constraints.',
      status: 'completed',
      agent: 'Understanding Agent',
      icon: Sparkles,
      color: 'text-emerald-400',
      border: 'border-emerald-500/40'
    },
    {
      id: 'phase-architect',
      title: 'Phase 2: Architect',
      desc: 'Design system topology, verify invariants, prepare DAG mutation plan.',
      status: 'completed',
      agent: 'Architect',
      icon: Cpu,
      color: 'text-cyan-400',
      border: 'border-cyan-500/40'
    },
    {
      id: 'phase-implement',
      title: 'Phase 3: Safely Mutate',
      desc: 'Execute atomic AST mutations with Mutation Firewall pre-flight checks.',
      status: 'in_progress',
      agent: 'Coding Agent',
      icon: Code2,
      color: 'text-amber-400',
      border: 'border-amber-500/50'
    },
    {
      id: 'phase-test',
      title: 'Phase 4: Chaos & Test',
      desc: 'Inject edge cases, stress UI fuzzer, evaluate boundary assertion rules.',
      status: 'pending',
      agent: 'Tester',
      icon: Zap,
      color: 'text-blue-400',
      border: 'border-blue-500/40'
    },
    {
      id: 'phase-verify',
      title: 'Phase 5: Visual & AST Verify',
      desc: 'Perceptual diff baseline comparison, layout stability, accessibility checks.',
      status: 'pending',
      agent: 'Verification Agent',
      icon: ShieldCheck,
      color: 'text-purple-400',
      border: 'border-purple-500/40'
    },
    {
      id: 'phase-certify',
      title: 'Phase 6: Certify & Deploy',
      desc: 'Seal cryptographic dossier, verify zero-drift reality parity, publish sandbox.',
      status: 'pending',
      agent: 'Final Verifier',
      icon: Rocket,
      color: 'text-teal-400',
      border: 'border-teal-500/40'
    }
  ];

  return (
    <div className="flex-1 h-full flex flex-col bg-[#0A0F1C] overflow-y-auto font-sans p-6 space-y-6 select-none">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-[#18233C]">
        <div>
          <div className="flex items-center gap-2">
            <GitBranch className="w-5 h-5 text-cyan-400" />
            <h1 className="text-xl font-bold text-white font-mono">TASK GRAPH ORCHESTRATOR</h1>
            <span className="px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-mono">
              DAG Flow Active
            </span>
          </div>
          <p className="text-xs text-neutral-400 mt-1">
            Deterministic execution pipeline from natural language prompt to certified production artifact.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onRunVerification}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-mono flex items-center gap-1.5 transition-all shadow-md"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Run Pipeline Gate</span>
          </button>
        </div>
      </div>

      {/* Visual Pipeline Phase Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {pipelinePhases.map((phase, idx) => {
          const Icon = phase.icon;
          return (
            <div
              key={phase.id}
              className={`p-5 rounded-2xl bg-[#0F1629] border ${phase.border} shadow-xl flex flex-col justify-between space-y-4 relative overflow-hidden`}
            >
              {/* Step indicator badge */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className={`w-8 h-8 rounded-lg bg-[#141E36] flex items-center justify-center ${phase.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white font-mono">{phase.title}</div>
                    <div className="text-[10px] font-mono text-neutral-400">{phase.agent}</div>
                  </div>
                </div>

                {phase.status === 'completed' && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/40">
                    <CheckCircle2 className="w-3 h-3" />
                    Passed
                  </span>
                )}
                {phase.status === 'in_progress' && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-mono text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-500/40 animate-pulse">
                    <Clock className="w-3 h-3" />
                    Executing
                  </span>
                )}
                {phase.status === 'pending' && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-mono text-neutral-500 bg-[#0A0E1A] px-2 py-0.5 rounded border border-[#1A243B]">
                    Pending
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {phase.desc}
              </p>

              <div className="pt-3 border-t border-[#1A243B] flex items-center justify-between text-xs font-mono">
                <span className="text-neutral-400">Step {idx + 1} of 6</span>
                <button
                  onClick={() => onPromptAgent(`Execute phase: ${phase.title}`)}
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
                >
                  <span>Trigger</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
