import React, { useState } from 'react';
import { SharedPreferences, DeviceSettings, LocalRoomDatabase } from '../db/localDatabase';
import { Topic, SubjectCategory, MotivationalReminder } from '../types';
import { X, HardDrive, ShieldCheck, Download, Sliders, Database, Check, Smartphone, FileCode } from 'lucide-react';

interface DeviceStorageModalProps {
  isOpen: boolean;
  onClose: () => void;
  topics: Topic[];
  categories: SubjectCategory[];
  reminders: MotivationalReminder[];
  onSettingsUpdated: (newSettings: DeviceSettings) => void;
}

export const DeviceStorageModal: React.FC<DeviceStorageModalProps> = ({
  isOpen,
  onClose,
  topics,
  categories,
  reminders,
  onSettingsUpdated,
}) => {
  const [settings, setSettings] = useState<DeviceSettings>(() => SharedPreferences.getSettings());
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const totalCards = topics.reduce((acc, t) => acc + (t.flashcards?.length || 0), 0);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = SharedPreferences.setSettings(settings);
    onSettingsUpdated(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleExportDatabase = async () => {
    const dump = await LocalRoomDatabase.exportDatabaseDump();
    const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `recallcurve_room_db_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="storage-modal-title"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-xl overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 id="storage-modal-title" className="text-base font-semibold text-slate-900 dark:text-slate-100">
                On-Device Database & SharedPreferences
              </h2>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                100% Local Device Storage · Zero Cloud Backend · No Firebase
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Privacy & Zero-Cloud Guarantee Banner */}
          <div className="p-4 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-xl space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-300">
              <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Strict On-Device Architecture</span>
            </div>
            <p className="text-xs text-emerald-700/90 dark:text-emerald-400/90 leading-relaxed">
              All study topics, flashcards, review histories, and categories are stored in your device's
              local database tables. Simple user preferences are managed via SharedPreferences. No data
              ever leaves your browser.
            </p>
          </div>

          {/* APK & Source Code Download */}
          <div className="p-4 bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span className="text-xs font-semibold text-indigo-900 dark:text-indigo-200">
                  Convert to Android APK
                </span>
              </div>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 font-semibold">
                Offline Ready
              </span>
            </div>
            <p className="text-xs text-indigo-800/80 dark:text-indigo-300/80 leading-relaxed">
              Download the complete project source code as a clean ZIP archive. Pre-configured with <code className="font-mono text-[11px] bg-white/70 dark:bg-slate-900/70 px-1 py-0.5 rounded">capacitor.config.json</code> and <code className="font-mono text-[11px] bg-white/70 dark:bg-slate-900/70 px-1 py-0.5 rounded">README_APK_BUILD.md</code> for immediate Android Studio APK generation.
            </p>
            <div className="flex items-center justify-between pt-1">
              <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                <FileCode className="w-3.5 h-3.5" />
                <span>recallcurve-source.zip (~86 KB)</span>
              </div>
              <a
                href="/recallcurve-source.zip"
                download="recallcurve-source.zip"
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Source ZIP</span>
              </a>
            </div>
          </div>

          {/* Local Room Database Tables Overview */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-indigo-500" />
              <span>Local Database Tables (`RecallCurve_RoomDB`)</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 rounded-xl text-center">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">`topics`</div>
                <div className="text-lg font-bold font-mono text-slate-900 dark:text-slate-100 mt-0.5">
                  {topics.length}
                </div>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 rounded-xl text-center">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">`flashcards`</div>
                <div className="text-lg font-bold font-mono text-slate-900 dark:text-slate-100 mt-0.5">
                  {totalCards}
                </div>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 rounded-xl text-center">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">`categories`</div>
                <div className="text-lg font-bold font-mono text-slate-900 dark:text-slate-100 mt-0.5">
                  {categories.length}
                </div>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 rounded-xl text-center">
                <div className="text-[11px] text-slate-500 dark:text-slate-400">`reminders`</div>
                <div className="text-lg font-bold font-mono text-slate-900 dark:text-slate-100 mt-0.5">
                  {reminders.length}
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={handleExportDatabase}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Local Database Dump (JSON)</span>
              </button>
            </div>
          </div>

          {/* SharedPreferences Config Form */}
          <form
            onSubmit={handleSaveSettings}
            className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 rounded-xl space-y-4"
          >
            <div className="flex items-center justify-between text-xs font-semibold text-slate-800 dark:text-slate-200">
              <div className="flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-indigo-500" />
                <span>Device SharedPreferences</span>
              </div>
              {savedSuccess && (
                <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-normal text-[11px]">
                  <Check className="w-3.5 h-3.5" /> Saved to Device
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Focus Sprint Duration (Minutes)
                </label>
                <input
                  type="number"
                  min={5}
                  max={90}
                  value={settings.timerDurationMinutes}
                  onChange={(e) =>
                    setSettings({ ...settings, timerDurationMinutes: Number(e.target.value) || 25 })
                  }
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Break Duration (Minutes)
                </label>
                <input
                  type="number"
                  min={1}
                  max={30}
                  value={settings.breakDurationMinutes}
                  onChange={(e) =>
                    setSettings({ ...settings, breakDurationMinutes: Number(e.target.value) || 5 })
                  }
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 font-mono"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-1 text-xs">
              <div>
                <div className="font-medium text-slate-800 dark:text-slate-200">
                  Audio Chimes & Notification Sounds
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  Web Audio synthesizer for study sprint completion
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.soundEnabled}
                onChange={(e) => setSettings({ ...settings, soundEnabled: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded-sm border-slate-300 focus:ring-indigo-500"
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-xs"
              >
                Save Preferences
              </button>
            </div>
          </form>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
