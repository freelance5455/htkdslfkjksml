import { useEffect, useState } from "react";
import { store, useStore, MARS_HP, MARS_PENALTY } from "../lib/store";
import { FIGHT_SECONDS, FLIGHT_SECONDS, MARS_TICKET, WEAPONS } from "../lib/world";
import { marsInput } from "../lib/marsInput";
import { toFa } from "../lib/fa";
import { boop } from "../lib/sound";
import { Btn } from "./Hud";
import { CoinIcon } from "./icons";

/** matches the shared bottom dock used by every other map */
function Dock({ children }: { children: React.ReactNode }) {
  return (
    <div className="pointer-events-none flex justify-center px-2 pb-2 sm:px-3 sm:pb-3">
      <div
        className="card no-scrollbar pointer-events-auto flex w-full max-w-md flex-col gap-2 overflow-y-auto rounded-3xl p-2.5"
        style={{ maxHeight: "min(46dvh, 340px)" }}
      >
        {children}
      </div>
    </div>
  );
}

function useTicker(active: boolean, ms = 200) {
  const [, setN] = useState(0);
  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setN((v) => v + 1), ms);
    return () => window.clearInterval(id);
  }, [active, ms]);
}

/* ================================================================== */
/*  LAUNCH / RETURN — flight progress                                  */
/* ================================================================== */
function FlightDock({ mode }: { mode: "launch" | "return" | "crash" }) {
  const startedAt = useStore((s) => s.mars?.startedAt ?? 0);
  useTicker(true, 120);

  const elapsed = (Date.now() - startedAt) / 1000;
  const pct = Math.min(100, (elapsed / FLIGHT_SECONDS) * 100);
  const left = Math.max(0, Math.ceil(FLIGHT_SECONDS - elapsed));

  const label =
    mode === "launch"
      ? "🚀 در حال پرتاب به مریخ"
      : mode === "crash"
        ? "💥 سقوط به سمت زمین"
        : "🌍 در حال بازگشت به زمین";

  return (
    <Dock>
      <div className="flex items-center gap-2">
        <span className="text-xl">{mode === "launch" ? "🚀" : mode === "crash" ? "💥" : "🌍"}</span>
        <div className="min-w-0 flex-1">
          <div className="text-[12px] font-black text-amber-950">{label}</div>
          <div className="text-[10px] font-bold text-amber-900/55">
            {toFa(left)} ثانیه تا رسیدن
          </div>
        </div>
        <div className="text-xl font-black tabular-nums text-amber-700">{toFa(left)}</div>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-white/14">
        <div
          className={`h-full rounded-full transition-[width] duration-150 ${
            mode === "crash"
              ? "bg-gradient-to-l from-rose-400 to-rose-600"
              : "bg-gradient-to-l from-sky-400 to-indigo-500"
          }`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </Dock>
  );
}

/* ================================================================== */
/*  SURFACE — the two choices                                          */
/* ================================================================== */
function SurfaceDock() {
  return (
    <Dock>
      <div className="flex items-center gap-2 rounded-2xl bg-orange-500/20 px-3 py-2">
        <span className="text-xl">🔴</span>
        <div className="min-w-0 flex-1">
          <div className="text-[12px] font-black text-orange-900">جیکو روی مریخه!</div>
          <div className="text-[10px] font-bold text-orange-800/65">حالا چیکار کنیم؟</div>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-1.5">
        <Btn full tone="cool" onClick={() => store.marsReturn(false)}>
          🌍 برگشت به زمین
        </Btn>
        <Btn full tone="danger" onClick={() => store.marsArm()}>
          👽 فایت با فضایی
        </Btn>
      </div>
    </Dock>
  );
}

/* ================================================================== */
/*  ARM — buy / pick a weapon                                          */
/* ================================================================== */
function ArmDock() {
  const owned = useStore((s) => s.marsWeapons);
  const picked = useStore((s) => s.marsWeapon);
  const points = useStore((s) => s.points);

  return (
    <Dock>
      <div className="flex items-center gap-2">
        <span className="text-lg">🔫</span>
        <div className="min-w-0 flex-1 text-[11.5px] font-black text-amber-950">
          اول باید اسلحه بخری
        </div>
        <span className="inline-flex items-center gap-1 rounded-full bg-amber-950/90 px-2 py-1 text-[10.5px] font-black tabular-nums text-amber-100">
          <CoinIcon className="size-3 text-amber-300" />
          {toFa(points)}
        </span>
      </div>

      <div className="flex flex-col gap-1.5">
        {WEAPONS.map((w) => {
          const have = owned.includes(w.id);
          const active = picked === w.id;
          const afford = points >= w.price;
          return (
            <button
              key={w.id}
              type="button"
              disabled={!have && !afford}
              onClick={() => {
                if (have) store.marsSelectWeapon(w.id);
                else store.marsBuyWeapon(w.id);
                boop();
              }}
              className={`flex items-center gap-2 rounded-2xl p-2 text-right transition ${
                active
                  ? "bg-amber-100 ring-2 ring-amber-500"
                  : "tile hover:brightness-[1.03]"
              } ${!have && !afford ? "opacity-45" : ""}`}
            >
              <span
                className="grid size-9 shrink-0 place-items-center rounded-xl text-lg"
                style={{ background: w.color }}
              >
                {w.emoji}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[11.5px] font-black text-amber-950">{w.name}</span>
                <span className="block text-[9.5px] leading-4 font-bold text-amber-900/55">
                  {w.desc}
                </span>
              </span>
              {have ? (
                <span className="shrink-0 text-[10px] font-black text-emerald-700">
                  {active ? "انتخاب‌شده ✓" : "انتخاب"}
                </span>
              ) : (
                <span className="inline-flex shrink-0 items-center gap-0.5 text-[10.5px] font-black text-amber-900">
                  <CoinIcon className="size-3" />
                  {toFa(w.price)}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-2 gap-1.5">
        <Btn full tone="ghost" onClick={() => store.marsCancelArm()}>
          بی‌خیال
        </Btn>
        <Btn full tone="danger" disabled={!picked} onClick={() => store.marsFight()}>
          شروع فایت
        </Btn>
      </div>
    </Dock>
  );
}

/* ================================================================== */
/*  FIGHT — live controls                                              */
/* ================================================================== */
function FightDock() {
  const mars = useStore((s) => s.mars);
  const weaponId = useStore((s) => s.marsWeapon);
  const weapon = WEAPONS.find((w) => w.id === weaponId) ?? WEAPONS[2];
  useTicker(true, 150);

  // keyboard support alongside the on-screen pad
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === "ArrowLeft" || e.code === "KeyA") marsInput.left = true;
      if (e.code === "ArrowRight" || e.code === "KeyD") marsInput.right = true;
      if (e.code === "Space") {
        e.preventDefault();
        marsInput.firing = true;
        marsInput.fire++;
      }
    };
    const up = (e: KeyboardEvent) => {
      if (e.code === "ArrowLeft" || e.code === "KeyA") marsInput.left = false;
      if (e.code === "ArrowRight" || e.code === "KeyD") marsInput.right = false;
      if (e.code === "Space") marsInput.firing = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  if (!mars) return null;
  const elapsed = (Date.now() - mars.startedAt) / 1000;
  const left = Math.max(0, Math.ceil(FIGHT_SECONDS - elapsed));
  const hpPct = (mars.hp / MARS_HP) * 100;

  /** press-and-hold binding that survives pointer leaving the button */
  const hold = (key: "left" | "right") => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      marsInput[key] = true;
    },
    onPointerUp: () => {
      marsInput[key] = false;
    },
    onPointerLeave: () => {
      marsInput[key] = false;
    },
    onPointerCancel: () => {
      marsInput[key] = false;
    },
  });

  return (
    <Dock>
      <div className="flex items-center gap-2">
        <span className="shrink-0 text-[10px] font-black text-rose-600">
          ❤️ {toFa(mars.hp)}
        </span>
        <div className="h-2 min-w-0 flex-1 overflow-hidden rounded-full bg-white/14">
          <div
            className={`h-full rounded-full transition-[width] duration-200 ${
              hpPct > 50
                ? "bg-gradient-to-l from-emerald-400 to-emerald-600"
                : hpPct > 25
                  ? "bg-gradient-to-l from-amber-400 to-amber-600"
                  : "bg-gradient-to-l from-rose-400 to-rose-600"
            }`}
            style={{ width: `${hpPct}%` }}
          />
        </div>
        <span className="shrink-0 text-[10px] font-black text-amber-900">
          👽 {toFa(mars.kills)}
        </span>
        <span className="shrink-0 text-[13px] font-black tabular-nums text-amber-950">
          {toFa(left)}
        </span>
      </div>

      <div className="grid grid-cols-4 gap-1.5">
        <button
          type="button"
          aria-label="عقب"
          {...hold("right")}
          className="grid h-14 touch-none place-items-center rounded-2xl bg-white/12 text-2xl font-black text-violet-50 ring-1 ring-white/15 select-none active:bg-fuchsia-500/40"
        >
          ▶
        </button>
        <button
          type="button"
          aria-label="جلو"
          {...hold("left")}
          className="grid h-14 touch-none place-items-center rounded-2xl bg-white/12 text-2xl font-black text-violet-50 ring-1 ring-white/15 select-none active:bg-fuchsia-500/40"
        >
          ◀
        </button>
        <button
          type="button"
          aria-label="شلیک"
          onPointerDown={(e) => {
            e.preventDefault();
            marsInput.firing = true;
            marsInput.fire++;
          }}
          onPointerUp={() => (marsInput.firing = false)}
          onPointerLeave={() => (marsInput.firing = false)}
          onPointerCancel={() => (marsInput.firing = false)}
          className="col-span-2 grid h-14 touch-none place-items-center rounded-2xl text-[13px] font-black text-white shadow-lg select-none active:brightness-110"
          style={{ background: `linear-gradient(180deg, ${weapon.color}, #B3261E)` }}
        >
          {weapon.emoji} شلیک
        </button>
      </div>
    </Dock>
  );
}

/* ================================================================== */
/*  RESULT                                                             */
/* ================================================================== */
function ResultDock({ won }: { won: boolean }) {
  const mars = useStore((s) => s.mars);
  if (!mars) return null;

  return (
    <Dock>
      <div
        className={`flex flex-col items-center gap-1 rounded-2xl px-3 py-3 text-center ${
          won ? "bg-emerald-100" : "bg-rose-100"
        }`}
      >
        <span className="text-3xl">{won ? "🏆" : "😖"}</span>
        <div className={`text-[13px] font-black ${won ? "text-emerald-700" : "text-rose-700"}`}>
          {won ? "زنده موندی!" : "فضایی‌ها کتکت زدن!"}
        </div>
        <div className="flex gap-3 text-[10.5px] font-bold text-amber-900/70">
          <span>👽 {toFa(mars.kills)} کشته</span>
          <span>❤️ {toFa(mars.hp)} سلامتی</span>
        </div>
        <div
          className={`text-xl font-black tabular-nums ${
            won ? "text-emerald-600" : "text-rose-600"
          }`}
        >
          {won ? `+${toFa(mars.reward)}` : `−${toFa(MARS_PENALTY)}`}
        </div>
      </div>

      {won ? (
        <Btn full onClick={() => store.marsBackToSurface()}>
          برگشت به سطح مریخ
        </Btn>
      ) : (
        <Btn full tone="danger" onClick={() => store.marsReturn(true)}>
          💥 سقوط به زمین
        </Btn>
      )}
    </Dock>
  );
}

/* ================================================================== */
export function MarsDock() {
  const phase = useStore((s) => s.mars?.phase ?? null);
  if (!phase) return null;

  switch (phase) {
    case "launch":
      return <FlightDock mode="launch" />;
    case "return":
      return <FlightDock mode="return" />;
    case "crash":
      return <FlightDock mode="crash" />;
    case "surface":
      return <SurfaceDock />;
    case "arm":
      return <ArmDock />;
    case "fight":
      return <FightDock />;
    case "win":
      return <ResultDock won />;
    case "lose":
      return <ResultDock won={false} />;
    default:
      return null;
  }
}

/** The ticket counter shown inside the main panel. */
export function MarsTicket() {
  const points = useStore((s) => s.points);
  const afford = points >= MARS_TICKET;

  return (
    <div className="flex flex-col gap-3">
      {/* a 3D-looking boarding pass */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800 via-indigo-900 to-slate-900 p-4 text-white shadow-[0_18px_40px_-16px_rgba(30,27,75,0.9)]">
        <div className="absolute -top-8 -right-8 size-28 rounded-full bg-orange-500/25 blur-2xl" />
        <div className="absolute -bottom-10 -left-6 size-24 rounded-full bg-sky-400/20 blur-2xl" />

        <div className="relative flex items-start justify-between">
          <div>
            <div className="text-[9px] font-bold tracking-widest opacity-70">BOARDING PASS</div>
            <div className="mt-0.5 text-[15px] font-black">سفر به مریخ 🔴</div>
          </div>
          <span className="text-3xl">🚀</span>
        </div>

        <div className="relative my-3 flex items-center gap-2">
          <div className="text-center">
            <div className="text-xl font-black">🌍</div>
            <div className="text-[9px] font-bold opacity-70">زمین</div>
          </div>
          <div className="relative flex-1">
            <div className="h-px w-full border-t border-dashed border-white/40" />
            <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs">✈️</span>
          </div>
          <div className="text-center">
            <div className="text-xl font-black">🔴</div>
            <div className="text-[9px] font-bold opacity-70">مریخ</div>
          </div>
        </div>

        {/* perforation */}
        <div className="relative -mx-4 flex items-center">
          <span className="size-4 shrink-0 rounded-full bg-[#fffaf0]" />
          <span className="flex-1 border-t border-dashed border-white/30" />
          <span className="size-4 shrink-0 rounded-full bg-[#fffaf0]" />
        </div>

        <div className="relative mt-3 flex items-end justify-between">
          <div className="text-[9px] leading-4 font-bold opacity-70">
            پرواز: {toFa(FLIGHT_SECONDS)} ثانیه
            <br />
            گیت: JK-۰۱
          </div>
          <div className="text-left">
            <div className="text-[9px] font-bold opacity-70">قیمت بلیط</div>
            <div className="inline-flex items-center gap-1 text-lg font-black tabular-nums">
              <CoinIcon className="size-4 text-amber-300" />
              {toFa(MARS_TICKET)}
            </div>
          </div>
        </div>
      </div>

      <div className="tile rounded-2xl p-3">
        <div className="mb-1.5 text-[12px] font-black text-amber-950">توی این سفر چی می‌شه؟</div>
        <ul className="flex flex-col gap-1 text-[10.5px] leading-5 font-medium text-amber-900/65">
          <li>🚀 جیکو سوار موشک می‌شه و {toFa(FLIGHT_SECONDS)} ثانیه توی آسمون شب اوج می‌گیره</li>
          <li>🔴 روی خاک سرخ مریخ با دهانه‌ها و صخره‌ها فرود میاد</li>
          <li>👽 می‌تونی با فضایی‌ها بجنگی — اول باید اسلحه بخری</li>
          <li>🏆 برد = پوینت بر اساس تعداد کشته و سلامتی باقی‌مونده</li>
          <li>💥 باخت = {toFa(MARS_PENALTY)} پوینت جریمه و سقوط به زمین</li>
        </ul>
      </div>

      <Btn full size="lg" disabled={!afford} onClick={() => store.marsBuyTicket()}>
        {afford ? `🎟️ خرید بلیط و پرتاب — ${toFa(MARS_TICKET)}` : "پوینت کافی نداری"}
      </Btn>
    </div>
  );
}
