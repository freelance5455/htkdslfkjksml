import React, { useState, useEffect } from 'react';
import { Wifi, ShieldCheck, BatteryCharging, ShieldAlert } from 'lucide-react';

interface AndroidStatusBarProps {
  isShieldActive: boolean;
  isTorActive: boolean;
  isIncognito?: boolean;
}

export const AndroidStatusBar: React.FC<AndroidStatusBarProps> = ({
  isShieldActive,
  isTorActive,
}) => {
  const [time, setTime] = useState('09:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full h-8 px-4 flex items-center justify-between text-xs font-semibold select-none text-slate-300 bg-slate-950/80 backdrop-blur-md z-40 border-b border-slate-800/40">
      {/* Left: Time & Privacy Indicators */}
      <div className="flex items-center gap-2">
        <span className="tracking-tight text-[13px] text-slate-100 font-medium">{time}</span>
        {isTorActive && (
          <span className="flex items-center gap-1 text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-purple-950/70 text-purple-300 border border-purple-700/50">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse" />
            TOR ONION
          </span>
        )}
        {isShieldActive ? (
          <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">AEGIS SHIELD</span>
          </span>
        ) : (
          <span className="flex items-center gap-1 text-[10px] font-bold text-amber-400">
            <ShieldAlert className="w-3.5 h-3.5" />
          </span>
        )}
      </div>

      {/* Center: Subtle Android Camera Notch / Punch Hole Placeholder */}
      <div className="w-3.5 h-3.5 rounded-full bg-black/90 border border-slate-700/60 shadow-inner flex items-center justify-center">
        <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
      </div>

      {/* Right: Network, 5G, Battery */}
      <div className="flex items-center gap-2 text-slate-300">
        <span className="text-[10px] font-bold tracking-wider text-slate-400">5G-E</span>
        <Wifi className="w-3.5 h-3.5 text-slate-200" />
        <div className="flex items-center gap-1">
          <span className="text-[11px] font-mono text-slate-300">96%</span>
          <div className="relative w-5 h-2.5 rounded-sm border border-slate-400 p-0.5 flex items-center">
            <div className="w-3.5 h-1.5 bg-emerald-400 rounded-2xs" />
            <div className="absolute -right-1 w-0.5 h-1 bg-slate-400 rounded-r-xs" />
          </div>
        </div>
      </div>
    </div>
  );
};
