import React, { useEffect, useState } from 'react';
import { Wifi, Signal, Battery, Bell } from 'lucide-react';

export const AndroidStatusBar: React.FC<{ hasNotifications?: boolean }> = ({ hasNotifications = false }) => {
  const [time, setTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
          hour12: false,
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-[#d9262c] text-white px-4 pt-1.5 pb-1 flex items-center justify-between text-xs font-medium tracking-tight select-none">
      <div className="flex items-center gap-2">
        <span className="font-semibold tracking-normal text-[13px]">{time}</span>
        {hasNotifications && (
          <Bell className="w-3 h-3 text-white/90 fill-white/80 animate-pulse" />
        )}
      </div>

      <div className="flex items-center gap-2.5">
        <span className="text-[10px] font-bold tracking-wider px-1 py-0.5 rounded bg-white/20">5G</span>
        <Signal className="w-3.5 h-3.5" />
        <Wifi className="w-3.5 h-3.5" />
        <div className="flex items-center gap-0.5">
          <Battery className="w-4 h-4 fill-white" />
        </div>
      </div>
    </div>
  );
};
