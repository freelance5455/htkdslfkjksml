/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Wifi, Signal, BatteryMedium } from 'lucide-react';

export const AndroidStatusBar: React.FC = () => {
  const [timeStr, setTimeStr] = useState('10:42');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    updateTime();
    const timer = setInterval(updateTime, 10000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full flex items-center justify-between px-6 py-2 select-none text-xs font-medium text-slate-300 z-30">
      {/* Time on Android left */}
      <div className="flex items-center gap-1.5 font-semibold text-slate-200 tracking-tight">
        <span>{timeStr}</span>
        <span className="text-[10px] text-cyan-400 font-mono">5G+</span>
      </div>

      {/* Camera punch hole spacer if rendered in phone frame */}
      <div className="w-4 h-4 rounded-full bg-slate-900 border border-slate-800 hidden sm:block shadow-inner" />

      {/* Android System Icons */}
      <div className="flex items-center gap-2 text-slate-300">
        <Wifi className="w-3.5 h-3.5 text-cyan-400" />
        <Signal className="w-3.5 h-3.5 text-slate-300" />
        <div className="flex items-center gap-1">
          <span className="text-[11px] font-mono text-slate-300">88%</span>
          <BatteryMedium className="w-4 h-4 text-emerald-400" />
        </div>
      </div>
    </div>
  );
};
