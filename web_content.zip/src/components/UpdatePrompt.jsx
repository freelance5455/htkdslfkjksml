import { useState } from 'react'
import { registerSW } from 'virtual:pwa-register'

export default function UpdatePrompt() {
  const [mode, setMode] = useState(null)
  const updateSW = registerSW({
    onNeedRefresh: () => setMode('refresh'),
    onOfflineReady: () => setMode('ready'),
  })

  if (!mode) return null

  return (
    <div className="update-banner" role="status">
      {mode === 'ready' ? (
        <span>App offline ke liye ready hai ✓</span>
      ) : (
        <>
          <span>Naya version aaya hai — update karke latest le lo</span>
          <div className="update-actions">
            <button
              className="btn btn-primary btn-small"
              onClick={() => updateSW(true)}
            >
              Update karo
            </button>
            <button className="btn btn-ghost btn-small" onClick={() => setMode(null)}>
              Baad me
            </button>
          </div>
        </>
      )}
    </div>
  )
}