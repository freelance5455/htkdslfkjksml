import {
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type { ActiveVideo, Settings, SubtitleSet } from "../types";
import { fmtClock, isUrduScript, parseSubtitles, toSRT, toVTT, downloadText, guessLang } from "../lib/subtitles";
import { uid, translateCuesToUrdu } from "../lib/pipeline";
import { idbDel, idbGet, idbPut } from "../lib/db";
import { Btn, Card, Chip, Empty, Icon, Seg, useToast } from "./ui";
import { fmtBytes, storageInfo } from "../lib/modelManager";

const SIZE_PX = { S: 14, M: 19, L: 27 } as const;

interface Props {
  video: ActiveVideo | null;
  onPick: (file: File) => void;
  onDuration: (d: number) => void;
  sets: SubtitleSet[];
  activeId: string | null;
  onActive: (id: string | null) => void;
  settings: Settings;
  onSettings: (p: Partial<Settings>) => void;
  onGenerate: () => void;
  onChange: () => void;
}

export default function PlayerTab({
  video,
  onPick,
  onDuration,
  sets,
  activeId,
  onActive,
  settings,
  onSettings,
  onGenerate,
  onChange,
}: Props) {
  const toast = useToast();
  const vRef = useRef<HTMLVideoElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const subRef = useRef<HTMLInputElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [t, setT] = useState(0);
  const [dur, setDur] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [saved, setSaved] = useState(false);
  const [importing, setImporting] = useState(false);

  useEffect(() => {
    if (!video) return;
    setPlaying(false);
    setT(0);
    idbGet("files", `${video.name}|${video.size}`).then((f) => setSaved(!!f));
  }, [video]);

  const activeSet = useMemo(
    () => sets.find((s) => s.id === activeId) ?? null,
    [sets, activeId]
  );

  useEffect(() => {
    let raf = 0;
    const tick = () => {
      const v = vRef.current;
      if (v) setT(v.currentTime);
      raf = requestAnimationFrame(tick);
    };
    if (playing) raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing]);

  const cue = useMemo(() => {
    if (!activeSet || !settings.subsOn) return null;
    return (
      activeSet.cues.find((c) => t >= c.start && t <= c.end + 0.05) ?? null
    );
  }, [activeSet, t, settings.subsOn]);

  const toggle = () => {
    const v = vRef.current;
    if (!v) return;
    if (v.paused) v.play().catch(() => toast("Playback blocked by the browser", "warn"));
    else v.pause();
  };

  const seek = (val: number) => {
    const v = vRef.current;
    if (!v) return;
    v.currentTime = val;
    setT(val);
  };

  const pickSub = async (f: File) => {
    setImporting(true);
    try {
      const text = await f.text();
      const { cues } = parseSubtitles(text);
      if (!cues.length) {
        toast("No cues found — is this a valid SRT / VTT / ASS file?", "err");
        return;
      }
      if (!video) return;
      const ns: SubtitleSet = {
        id: uid(),
        videoKey: `${video.name}|${video.size}`,
        videoName: video.name,
        title: f.name.replace(/\.(srt|vtt|ass|ssa)$/i, ""),
        sourceLang: "import",
        targetLang: "orig",
        kind: "imported",
        cues,
        srt: toSRT(cues),
        vtt: toVTT(cues),
        failedCount: 0,
        createdAt: Date.now(),
      };
      await idbPut("subtitles", ns);
      onActive(ns.id);
      onChange();
      toast(`Imported ${cues.length} cues from ${f.name}`, "ok");
    } catch (e: any) {
      toast("Import failed: " + String(e?.message || e), "err");
    } finally {
      setImporting(false);
    }
  };

  const saveFile = async () => {
    if (!video) return;
    const est = await storageInfo();
    if (est.quota > 0 && video.size > (est.quota - est.usage) * 0.7) {
      toast(
        "Not enough storage to keep the video file here. Subtitles are still saved — re-select the video next time.",
        "warn"
      );
      return;
    }
    try {
      const key = `${video.name}|${video.size}`;
      await idbPut("files", { key, name: video.name, size: video.size, blob: video.blob, addedAt: Date.now() });
      await idbPut("videos", { key, name: video.name, size: video.size, lastUsed: Date.now(), hasBlob: true, ...(video.duration ? { duration: video.duration } : {}) });
      setSaved(true);
      onChange();
      toast("Video file stored on this device — it opens offline next time", "ok");
    } catch (e: any) {
      toast("Could not store the video file: " + String(e?.message || e), "err");
    }
  };

  const translateSet = async (set: SubtitleSet) => {
    if (!settings.installed[settings.mtModel]) {
      toast("Install a translation model first (Models tab)", "warn");
      onGenerate();
      return;
    }
    toast("Translating subtitles to Urdu…", "warn");
    try {
      const src = set.cues.map((c) => c.text).join(" ");
      const { cues, failed, detected } = await translateCuesToUrdu(
        set.cues,
        settings.mtModel,
        guessLang(src),
        () => {}
      );
      const ns: SubtitleSet = {
        id: uid(),
        videoKey: set.videoKey,
        videoName: set.videoName,
        title: `${set.title} → اردو`,
        sourceLang: detected,
        targetLang: "ur",
        kind: "translated",
        cues,
        srt: toSRT(cues),
        vtt: toVTT(cues),
        failedCount: failed,
        createdAt: Date.now(),
      };
      await idbPut("subtitles", ns);
      onActive(ns.id);
      onChange();
      toast(
        failed
          ? `Translated ${cues.length} cues (${failed} failed — original kept)`
          : `Translated ${cues.length} cues into Urdu`,
        failed ? "warn" : "ok"
      );
    } catch (e: any) {
      toast("Translation failed: " + String(e?.message || e), "err");
    }
  };

  const deleteSet = async (set: SubtitleSet) => {
    await idbDel("subtitles", set.id);
    if (activeId === set.id) onActive(null);
    onChange();
    toast("Subtitle set deleted", "ok");
  };

  if (!video) {
    return (
      <div className="space-y-4">
        <input
          ref={fileRef}
          type="file"
          accept="video/*,audio/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onPick(f);
            e.target.value = "";
          }}
        />
        <Empty
          icon="film"
          title="Choose a video to play"
          sub="Local files only — nothing is uploaded. MP4, WebM, MKV, MP3, WAV and more. Saved Urdu subtitles reload automatically when you re-open the same file."
        >
          <Btn onClick={() => fileRef.current?.click()}>
            <Icon name="folder" className="h-4 w-4" /> Choose video / audio file
          </Btn>
        </Empty>
        <Card className="p-4">
          <div className="flex items-start gap-3">
            <Icon name="shield" className="mt-0.5 h-5 w-5 text-jade-400" />
            <div className="text-xs leading-relaxed text-mist-400">
              <span className="font-semibold text-mist-200">Everything stays on this device.</span>{" "}
              Playback, speech recognition and Urdu translation run locally with the models you
              install in <span className="text-brass-400">Models</span>. No cloud API is ever called.
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* player */}
      <div ref={wrapRef} className="overflow-hidden rounded-xl border border-ink-700 bg-black">
        <div className="relative">
          <video
            ref={vRef}
            src={video.url}
            playsInline
            className="aspect-video w-full bg-black"
            onClick={toggle}
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
            onEnded={() => setPlaying(false)}
            onLoadedMetadata={(e) => {
              const d = e.currentTarget.duration;
              setDur(d);
              if (d && isFinite(d)) onDuration(d);
            }}
            onTimeUpdate={(e) => !playing && setT(e.currentTarget.currentTime)}
          />
          {cue && settings.subsOn && (
            <div className="pointer-events-none absolute inset-x-0 bottom-10 flex justify-center px-4">
              <div
                dir={isUrduScript(cue.text) ? "rtl" : "auto"}
                className={
                  "subtitle-shadow max-w-[92%] rounded bg-black/45 px-3 py-1 text-center font-semibold text-white " +
                  (isUrduScript(cue.text) ? "urdu" : "")
                }
                style={{ fontSize: SIZE_PX[settings.subsSize] }}
              >
                {cue.text}
              </div>
            </div>
          )}
          {playing && (
            <div className="pointer-events-none absolute left-2 top-2 flex items-center gap-1.5 rounded-full bg-black/60 px-2 py-1 text-[10px] font-bold text-jade-300">
              <span className="pulsedot h-1.5 w-1.5 rounded-full bg-jade-400" />
              PLAYING
            </div>
          )}
        </div>
        {/* controls */}
        <div className="space-y-2 border-t border-ink-800 bg-ink-900 px-3 py-2.5">
          <div className="flex items-center gap-3">
            <Btn size="sm" variant="outline" onClick={toggle} className="h-9 w-9 !p-0" aria-label="play pause">
              <Icon name={playing ? "pause" : "play"} className="h-4.5 w-4.5" />
            </Btn>
            <span className="font-display w-10 text-right text-xs tabular-nums text-mist-400">
              {fmtClock(t)}
            </span>
            <input
              type="range"
              min={0}
              max={dur || 0}
              step={0.1}
              value={Math.min(t, dur || 0)}
              onChange={(e) => seek(parseFloat(e.target.value))}
              className="h-1.5 flex-1"
            />
            <span className="font-display w-10 text-xs tabular-nums text-mist-400">
              {fmtClock(dur)}
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Btn
              size="sm"
              variant={settings.subsOn && activeSet ? "jade" : "outline"}
              onClick={() => {
                if (!activeSet) {
                  toast("No subtitle set active — generate or import one first", "warn");
                  return;
                }
                onSettings({ subsOn: !settings.subsOn });
              }}
            >
              <Icon name="cc" className="h-4 w-4" />
              {settings.subsOn && activeSet ? "CC on" : "CC off"}
            </Btn>
            <Seg
              options={[
                { v: "S", label: "S" },
                { v: "M", label: "M" },
                { v: "L", label: "L" },
              ]}
              value={settings.subsSize}
              onChange={(v) => onSettings({ subsSize: v })}
              className="w-28"
            />
            <Btn
              size="sm"
              variant="outline"
              onClick={() => wrapRef.current?.requestFullscreen?.().catch(() => {})}
              className="ml-auto"
            >
              <Icon name="expand" className="h-4 w-4" /> Full
            </Btn>
          </div>
        </div>
      </div>

      {/* file meta */}
      <Card className="space-y-3 p-3.5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate font-display text-sm font-semibold text-mist-100">{video.name}</p>
            <p className="mt-0.5 text-[11px] text-mist-500">
              {fmtBytes(video.size)}
              {video.duration ? ` · ${fmtClock(video.duration)}` : ""}
            </p>
          </div>
          <div className="flex shrink-0 gap-2">
            <Btn size="sm" variant="ghost" onClick={() => fileRef.current?.click()}>
              Replace
            </Btn>
            {saved ? (
              <Chip tone="moss">
                <Icon name="save" className="h-3 w-3" /> stored
              </Chip>
            ) : (
              <Btn size="sm" variant="outline" onClick={saveFile}>
                <Icon name="save" className="h-4 w-4" /> Store file
              </Btn>
            )}
          </div>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="video/*,audio/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onPick(f);
            e.target.value = "";
          }}
        />
        <Btn size="sm" onClick={onGenerate} className="w-full">
          <Icon name="sparkles" className="h-4 w-4" /> Generate Urdu subtitles
        </Btn>
      </Card>

      {/* subtitle sets */}
      <div>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-display text-sm font-semibold tracking-wide text-mist-300 uppercase">
            Subtitles for this video
          </h2>
          <Btn size="sm" variant="ghost" onClick={() => subRef.current?.click()}>
            <Icon name="upload" className="h-4 w-4" />
            {importing ? "Importing…" : "Import SRT/VTT/ASS"}
          </Btn>
        </div>
        <input
          ref={subRef}
          type="file"
          accept=".srt,.vtt,.ass,.ssa,.txt"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void pickSub(f);
            e.target.value = "";
          }}
        />
        {sets.length === 0 ? (
          <Empty
            icon="cc"
            title="No subtitles yet"
            sub="Generate Urdu subtitles from the speech, or import an existing SRT / VTT / ASS file and translate it to Urdu."
          />
        ) : (
          <div className="space-y-2.5">
            {sets.map((s) => {
              const active = s.id === activeId;
              return (
                <Card
                  key={s.id}
                  className={
                    "p-3.5 transition-colors " + (active ? "border-jade-500/60 bg-ink-850" : "")
                  }
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate font-display text-sm font-semibold text-mist-100" dir="auto">
                        {s.title}
                      </p>
                      <p className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-mist-500">
                        <Chip tone={s.kind === "generated" ? "brass" : s.kind === "translated" ? "jade" : "mist"}>
                          {s.kind}
                        </Chip>
                        {s.cues.length} cues
                        {s.failedCount > 0 && (
                          <Chip tone="rust">{s.failedCount} failed</Chip>
                        )}
                        <span>{new Date(s.createdAt).toLocaleDateString()}</span>
                      </p>
                    </div>
                    <Btn size="sm" variant={active ? "jade" : "outline"} onClick={() => onActive(s.id)}>
                      {active ? (
                        <>
                          <Icon name="check" className="h-4 w-4" /> Active
                        </>
                      ) : (
                        "Apply"
                      )}
                    </Btn>
                  </div>
                  <div className="mt-2.5 flex flex-wrap gap-2">
                    {s.kind === "imported" && (
                      <Btn size="sm" variant="outline" onClick={() => void translateSet(s)}>
                        <Icon name="wand" className="h-4 w-4" /> Translate to Urdu
                      </Btn>
                    )}
                    <Btn
                      size="sm"
                      variant="ghost"
                      onClick={() =>
                        downloadText(
                          `${video.name.replace(/\.[^.]+$/, "")}-${s.title.replace(/\s+/g, "_")}.srt`,
                          s.srt
                        )
                      }
                    >
                      <Icon name="download" className="h-4 w-4" /> SRT
                    </Btn>
                    <Btn
                      size="sm"
                      variant="ghost"
                      onClick={() =>
                        downloadText(
                          `${video.name.replace(/\.[^.]+$/, "")}-${s.title.replace(/\s+/g, "_")}.vtt`,
                          s.vtt
                        )
                      }
                    >
                      <Icon name="download" className="h-4 w-4" /> VTT
                    </Btn>
                    <Btn size="sm" variant="ghost" className="text-rust-400" onClick={() => void deleteSet(s)}>
                      <Icon name="trash" className="h-4 w-4" />
                    </Btn>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
      {activeSet && settings.subsOn && (
        <div className="flex items-center gap-2 rounded-lg border border-ink-700 bg-ink-900 px-3 py-2 text-[11px] text-mist-500">
          <Icon name="cc" className="h-4 w-4 text-jade-400" />
          Showing {activeSet.cues.length} cues · size {settings.subsSize} · RTL renders in Noto
          Nastaliq Urdu
        </div>
      )}
    </div>
  );
}
