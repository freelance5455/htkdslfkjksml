import { cn } from "@/lib/cn";
import type { LiveItem, OuLine } from "@/lib/engine/types";
import { TeamCrest } from "@/components/team-crest";

function marketTone(v: number | null | undefined) {
  if (v == null) return "cool";
  if (v >= 70) return "hot";
  if (v >= 50) return "warm";
  return "cool";
}

function MarketChip({ label, value, done }: { label: string; value: number | null | undefined; done?: boolean }) {
  const tone = done ? "hot" : marketTone(value);
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium",
        tone === "hot" && "bg-hot/12 text-hot shadow-[0_0_0_1px_rgb(61_154_122/0.22)]",
        tone === "warm" && "bg-elevated text-warm shadow-[var(--shadow-border)]",
        tone === "cool" && "bg-elevated/70 text-muted shadow-[var(--shadow-border)]",
      )}
    >
      <span className="text-muted">{label}</span>
      <b className="font-mono font-semibold tabular-nums">
        {done ? "já" : value == null ? "—" : `${Math.round(value)}%`}
      </b>
    </span>
  );
}

function lineOf(lines: OuLine[] | undefined, n: number) {
  return lines?.find((x) => x.line === n);
}

export function MatchRow({
  item,
  selected,
  onSelect,
}: {
  item: LiveItem;
  selected: boolean;
  onSelect: () => void;
}) {
  const { match, pred } = item;
  const gh = match.score.fullTime.home;
  const ga = match.score.fullTime.away;
  const isHt = match.period === "ht";
  const o05 = pred.pAny;
  const o15 = lineOf(pred.ouLines, 1.5);
  const btts = pred.bttsDone ? 100 : pred.bttsYes;
  const ht05 = lineOf(pred.ouLinesHT, 0.5);

  return (
    <article
      className={cn(
        "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)] transition-[box-shadow,background-color] duration-150",
        selected && "bg-elevated shadow-[0_0_0_1px_rgb(200_204_212/0.28)]",
      )}
    >
      <button
        type="button"
        onClick={onSelect}
        className="grid w-full grid-cols-[52px_minmax(0,1fr)_auto] items-center gap-3 px-3 py-3 text-left"
      >
        <span
          className={cn(
            "flex size-12 items-center justify-center rounded-full bg-bg font-mono text-[15px] font-semibold tabular-nums shadow-[var(--shadow-border)]",
            isHt ? "text-muted text-xs" : "text-live",
            String(match.minuteDisplay).length > 3 && "text-xs",
          )}
        >
          {isHt ? "INT" : match.minuteDisplay}
        </span>
        <div className="min-w-0 space-y-2">
          <div className="flex min-w-0 items-center gap-2">
            <TeamCrest name={match.homeTeam.name} src={match.homeTeam.logo} />
            <span className="truncate text-[13.5px] font-semibold">{match.homeTeam.name}</span>
          </div>
          <div className="flex min-w-0 items-center gap-2">
            <TeamCrest name={match.awayTeam.name} src={match.awayTeam.logo} />
            <span className="truncate text-[13.5px] font-semibold">{match.awayTeam.name}</span>
          </div>
        </div>
        <div className="flex min-w-8 flex-col overflow-hidden rounded-[10px] bg-bg shadow-[var(--shadow-border)]">
          <b className={cn("px-2.5 py-1 text-center font-mono text-lg font-bold tabular-nums", gh > ga && "text-accent")}>
            {gh}
          </b>
          <b className={cn("border-t border-border px-2.5 py-1 text-center font-mono text-lg font-bold tabular-nums", ga > gh && "text-accent")}>
            {ga}
          </b>
        </div>
      </button>
      {pred.has && (
        <div className="flex flex-wrap gap-1.5 px-3 pb-3">
          <MarketChip label="O0.5 resto" value={o05} />
          <MarketChip label="O1.5" value={o15?.over} done={o15?.done} />
          <MarketChip label="BTTS" value={btts} done={pred.bttsDone} />
          {ht05 && !ht05.unknown ? (
            <MarketChip label="1H 0.5" value={ht05.over} done={ht05.done} />
          ) : null}
          {pred.verdict?.key === "alta" ? (
            <MarketChip label="Golo" value={Math.round(pred.verdict.p * 100)} />
          ) : null}
        </div>
      )}
    </article>
  );
}
