import React, { useRef, useEffect, useState, useCallback } from "react";
import {
  StylusToolType,
  StylusPoint,
  StylusStroke,
  StylusSettings,
  BoundedFrame,
} from "../types";
import {
  StylusSettingsManager,
  DigitalInkRecognitionEngine,
} from "../utils/digitalInkEngine";
import { CanvasDrawingEngine } from "../utils/canvasDrawingEngine";
import { StylusEngine } from "../utils/stylusEngine";
import { calculateCanvasHiDpiMatrix, useDisplayScale } from "../utils/displayScaleManager";
import { Sparkles, Eye, EyeOff, ZoomIn, ZoomOut, Maximize2, Shield, Layers } from "lucide-react";

interface StylusCanvasOverlayProps {
  activeTool: StylusToolType;
  color: string;
  strokeSize: number;
  opacity: number;
  isEnabled: boolean;
  onStrokesUpdated?: (strokes: StylusStroke[], recognizedText?: string) => void;
  initialStrokes?: StylusStroke[];
  onToggleTool?: () => void;
  onUndo?: () => void;
  onSelectBidirectionalLink?: (linkTitle: string) => void;
}

export const StylusCanvasOverlay: React.FC<StylusCanvasOverlayProps> = ({
  activeTool,
  color,
  strokeSize,
  opacity,
  isEnabled,
  onStrokesUpdated,
  initialStrokes = [],
  onToggleTool,
  onUndo,
  onSelectBidirectionalLink,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [strokes, setStrokes] = useState<StylusStroke[]>(initialStrokes);
  const [currentPoints, setCurrentPoints] = useState<StylusPoint[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [settings, setSettings] = useState<StylusSettings>(
    StylusSettingsManager.getSettings()
  );
  const [palmBlockedNotice, setPalmBlockedNotice] = useState<boolean>(false);
  const [lastTapTime, setLastTapTime] = useState<number>(0);
  const [ocrText, setOcrText] = useState<string | null>(null);
  const [isRecognizing, setIsRecognizing] = useState<boolean>(false);
  const { scaleConfig } = useDisplayScale();

  // Infinite Canvas Pan & Zoom state
  const [zoom, setZoom] = useState<number>(1.0);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Bounded Frames inside canvas
  const [frames, setFrames] = useState<BoundedFrame[]>(() => {
    if (settings.activeFramePreset === "a4") {
      return [
        { id: "frame-1", type: "a4", title: "Sayfa 1", x: 40, y: 40, width: 794, height: 1123, pageNumber: 1 },
      ];
    }
    if (settings.activeFramePreset === "b5") {
      return [
        { id: "frame-1", type: "b5", title: "Sayfa 1", x: 40, y: 40, width: 665, height: 945, pageNumber: 1 },
      ];
    }
    return [];
  });

  // Subscribe to settings changes
  useEffect(() => {
    const unsub = StylusSettingsManager.subscribe((newSettings) => {
      setSettings(newSettings);
      if (newSettings.activeFramePreset === "a4") {
        setFrames([
          { id: "frame-1", type: "a4", title: "Sayfa 1", x: 40, y: 40, width: 794, height: 1123, pageNumber: 1 },
        ]);
      } else if (newSettings.activeFramePreset === "b5") {
        setFrames([
          { id: "frame-1", type: "b5", title: "Sayfa 1", x: 40, y: 40, width: 665, height: 945, pageNumber: 1 },
        ]);
      } else if (newSettings.activeFramePreset === "infinite") {
        setFrames([]);
      }
    });
    return unsub;
  }, []);

  // Update strokes when initialStrokes change
  useEffect(() => {
    if (initialStrokes && initialStrokes.length > 0) {
      setStrokes(initialStrokes);
    }
  }, [initialStrokes]);

  // Handle Resize and Canvas GPU Scaling
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const { bufferWidth, bufferHeight, effectiveDpr } = calculateCanvasHiDpiMatrix(
      rect.width,
      rect.height,
      scaleConfig.canvasScale
    );
    const isDark = typeof document !== "undefined" && document.documentElement.classList.contains("dark");

    canvas.width = bufferWidth;
    canvas.height = bufferHeight;
    canvas.style.width = `${rect.width}px`;
    canvas.style.height = `${rect.height}px`;

    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";

    ctx.scale(effectiveDpr, effectiveDpr);
    ctx.clearRect(0, 0, rect.width, rect.height);

    // Apply Pan and Zoom Transformation
    ctx.save();
    ctx.translate(pan.x, pan.y);
    ctx.scale(zoom, zoom);

    // Z=0: Draw Bounded Frames (A4, B5, PDF)
    if (frames.length > 0) {
      CanvasDrawingEngine.drawBoundedFrames(ctx, frames, isDark);
    }

    // Draw grid alignment lines if grid snapping is enabled
    if (settings.gridSnapping) {
      ctx.save();
      ctx.strokeStyle = isDark ? "rgba(148, 163, 184, 0.1)" : "rgba(148, 163, 184, 0.18)";
      ctx.lineWidth = 1;
      const gridSize = Math.round(24 * scaleConfig.canvasScale);
      const maxW = Math.max(rect.width * 2, 2400);
      const maxH = Math.max(rect.height * 2, 3000);
      for (let x = -600; x < maxW; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, -600);
        ctx.lineTo(x, maxH);
        ctx.stroke();
      }
      for (let y = -600; y < maxH; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(-600, y);
        ctx.lineTo(maxW, y);
        ctx.stroke();
      }
      ctx.restore();
    }

    // Render Layer Hierarchy:
    // Z=1: Highlighter -> Z=3: Ink strokes -> Z=4: Active Recall Tapes
    CanvasDrawingEngine.renderLayerHierarchical(ctx, strokes, settings, isDark);

    // Render active stroke in progress
    if (isDrawing && currentPoints.length > 0) {
      const activeStroke: StylusStroke = {
        id: "active_preview",
        tool: activeTool,
        color,
        size: strokeSize,
        opacity,
        points: currentPoints,
        isRecallTape: activeTool === "recall_tape",
        isRevealed: false,
      };
      CanvasDrawingEngine.drawSmoothStroke(ctx, activeStroke, settings, isDark);
    }

    ctx.restore();
  }, [strokes, isDrawing, currentPoints, activeTool, color, strokeSize, opacity, settings, frames, pan, zoom, scaleConfig.canvasScale]);

  useEffect(() => {
    redrawCanvas();
  }, [redrawCanvas]);

  // Window Resize listener
  useEffect(() => {
    const handleResize = () => redrawCanvas();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [redrawCanvas]);

  // Perform ML Kit Digital Ink Recognition automatically when stroke finishes
  const triggerOCRRecognition = async (updatedStrokes: StylusStroke[]) => {
    if (!settings.autoOCR || updatedStrokes.length === 0) return;
    setIsRecognizing(true);
    try {
      const result = await DigitalInkRecognitionEngine.recognizeStrokes(updatedStrokes);
      if (result && result.text) {
        setOcrText(result.text);
        if (onStrokesUpdated) {
          onStrokesUpdated(updatedStrokes, result.text);
        }
      }
    } catch (err) {
      console.warn("ML Kit Digital Ink OCR failed", err);
    } finally {
      setIsRecognizing(false);
    }
  };

  // Toggle All Active Recall Tapes
  const handleToggleAllTapes = () => {
    const hasConcealed = strokes.some((s) => s.tool === "recall_tape" && !s.isRevealed);
    const updated = strokes.map((s) => {
      if (s.tool === "recall_tape") {
        return { ...s, isRevealed: hasConcealed };
      }
      return s;
    });
    setStrokes(updated);
    if (onStrokesUpdated) {
      onStrokesUpdated(updated);
    }
  };

  // Pointer Down (Check Recall Tape Hit, Palm Rejection & Eraser)
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isEnabled) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const isStylus = e.pointerType === "pen" || (e as any).pressure > 0.05;

    // Palm Rejection & Touch Pan Mode:
    if (!isStylus && e.pointerType === "touch") {
      if (settings.palmRejection === "strict") {
        setPalmBlockedNotice(true);
        setTimeout(() => setPalmBlockedNotice(false), 1500);
        return;
      }
      if (settings.palmRejection === "balanced") {
        // Balanced: Touch acts as Pan navigation
        setIsPanning(true);
        setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
        return;
      }
    }

    const localX = (e.clientX - rect.left - pan.x) / zoom;
    const localY = (e.clientY - rect.top - pan.y) / zoom;

    // 1. Check if user tapped on an existing Active Recall Tape to toggle reveal/conceal
    const hitTape = CanvasDrawingEngine.findRecallTapeHit(localX, localY, strokes);
    if (hitTape) {
      const updated = strokes.map((s) =>
        s.id === hitTape.id ? { ...s, isRevealed: !s.isRevealed } : s
      );
      setStrokes(updated);
      if (onStrokesUpdated) {
        onStrokesUpdated(updated);
      }
      return;
    }

    // 2. Smart Eraser Action on Pointer Down
    if (activeTool === "eraser") {
      const filterMode = settings.activeEraserFilter || "all";
      const remaining = CanvasDrawingEngine.filterStrokesWithSmartEraser(
        strokes,
        localX,
        localY,
        strokeSize * 6,
        filterMode
      );
      if (remaining.length !== strokes.length) {
        setStrokes(remaining);
        if (onStrokesUpdated) onStrokesUpdated(remaining);
      }
      setIsDrawing(true);
      return;
    }

    // Double Tap gesture detection
    const now = Date.now();
    if (isStylus && now - lastTapTime < 280) {
      if (settings.doubleTapAction === "eraser" && onToggleTool) {
        onToggleTool();
      } else if (settings.doubleTapAction === "undo" && onUndo) {
        onUndo();
      }
      setLastTapTime(0);
      return;
    }
    setLastTapTime(now);

    canvas.setPointerCapture(e.pointerId);
    setIsDrawing(true);

    const initialPoint: StylusPoint = {
      x: localX,
      y: localY,
      pressure: e.pressure > 0 ? e.pressure : 0.5,
      tiltX: e.tiltX || 0,
      tiltY: e.tiltY || 0,
      timestamp: Date.now(),
    };
    setCurrentPoints([initialPoint]);
  };

  // Pointer Move (Collect Points, Eraser Filtering or Pan)
  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isEnabled) return;

    if (isPanning) {
      setPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      });
      return;
    }

    if (!isDrawing) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const isStylus = e.pointerType === "pen" || (e as any).pressure > 0.05;

    if (settings.palmRejection !== "disabled" && !isStylus && e.pointerType === "touch") {
      return;
    }

    const localX = (e.clientX - rect.left - pan.x) / zoom;
    const localY = (e.clientY - rect.top - pan.y) / zoom;

    // Smart Eraser Live Erase Dragging
    if (activeTool === "eraser") {
      const filterMode = settings.activeEraserFilter || "all";
      const remaining = CanvasDrawingEngine.filterStrokesWithSmartEraser(
        strokes,
        localX,
        localY,
        strokeSize * 6,
        filterMode
      );
      if (remaining.length !== strokes.length) {
        setStrokes(remaining);
        if (onStrokesUpdated) onStrokesUpdated(remaining);
      }
      return;
    }

    const newPt: StylusPoint = {
      x: localX,
      y: localY,
      pressure: e.pressure > 0 ? e.pressure : 0.5,
      tiltX: e.tiltX || 0,
      tiltY: e.tiltY || 0,
      timestamp: Date.now(),
    };

    setCurrentPoints((prev) => [...prev, newPt]);
  };

  // Pointer Up (Finalize Stroke)
  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (isPanning) {
      setIsPanning(false);
      return;
    }

    if (!isDrawing) return;

    const canvas = canvasRef.current;
    if (canvas && canvas.hasPointerCapture(e.pointerId)) {
      canvas.releasePointerCapture(e.pointerId);
    }

    setIsDrawing(false);

    if (activeTool === "eraser") {
      return;
    }

    if (currentPoints.length > 0) {
      // Smart Shape Auto-Snap Check
      let finalPoints = currentPoints;
      if (activeTool !== "recall_tape" && activeTool !== "lasso_cut") {
        const shapeResult = StylusEngine.detectAndSnapShape(currentPoints);
        if (shapeResult.shapeType) {
          finalPoints = shapeResult.snappedPoints;
          StylusEngine.triggerHapticPulse();
        }
      }

      const newStroke: StylusStroke = {
        id: `stroke_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
        tool: activeTool,
        color: activeTool === "recall_tape" ? settings.recallTapeColor || "#F59E0B" : color,
        size: activeTool === "recall_tape" ? Math.max(strokeSize * 2.8, 22) : strokeSize,
        opacity: activeTool === "recall_tape" ? 1.0 : opacity,
        points: finalPoints,
        isRecallTape: activeTool === "recall_tape",
        isRevealed: false,
        createdAt: Date.now(),
      };

      const updatedStrokes = [...strokes, newStroke];
      setStrokes(updatedStrokes);
      setCurrentPoints([]);

      if (onStrokesUpdated) {
        onStrokesUpdated(updatedStrokes);
      }

      // Trigger background ML Kit OCR transcription
      if (activeTool !== "recall_tape" && activeTool !== "lasso_cut") {
        triggerOCRRecognition(updatedStrokes);
      }
    }
  };

  if (!isEnabled) return null;

  const recallTapeCount = strokes.filter((s) => s.tool === "recall_tape").length;

  return (
    <div className="absolute inset-0 z-30 pointer-events-auto overflow-hidden select-none">
      {/* GPU Accelerated Hardware Canvas Overlay */}
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="w-full h-full touch-none cursor-crosshair block"
        style={{
          touchAction: "none",
        }}
      />

      {/* Infinite Canvas Pan & Zoom Floating HUD */}
      <div className="absolute bottom-4 right-4 z-40 flex items-center gap-1.5 p-1.5 rounded-2xl bg-slate-900/85 backdrop-blur-md border border-slate-700/80 shadow-2xl text-white text-xs font-mono">
        <button
          type="button"
          onClick={() => setZoom((z) => Math.max(0.4, Number((z - 0.15).toFixed(2))))}
          className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
          title="Uzaklaş (Zoom Out)"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
        <span className="px-1 text-[11px] font-bold text-amber-300">{(zoom * 100).toFixed(0)}%</span>
        <button
          type="button"
          onClick={() => setZoom((z) => Math.min(2.8, Number((z + 0.15).toFixed(2))))}
          className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
          title="Yakınlaş (Zoom In)"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          onClick={() => {
            setZoom(1.0);
            setPan({ x: 0, y: 0 });
          }}
          className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-teal-400 transition-colors cursor-pointer"
          title="Merkeze Sıfırla (Reset Pan/Zoom)"
        >
          <Maximize2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Active Recall Tape Global Toggle HUD (if recall tapes exist) */}
      {recallTapeCount > 0 && (
        <div className="absolute top-4 right-4 z-40 flex items-center gap-2 p-2 rounded-2xl bg-amber-500/95 text-slate-950 text-xs font-black shadow-2xl backdrop-blur-md border border-amber-300 animate-in fade-in">
          <EyeOff className="w-4 h-4 text-slate-950" />
          <span>Hafıza Bandı: {recallTapeCount} Bant</span>
          <button
            type="button"
            onClick={handleToggleAllTapes}
            className="px-2 py-1 rounded-xl bg-slate-950 text-amber-300 hover:text-white text-[10px] font-bold transition-colors cursor-pointer ml-1"
          >
            Tümünü Aç / Kapat
          </button>
        </div>
      )}

      {/* Palm Rejection Active Indicator Badge */}
      {palmBlockedNotice && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-amber-500/90 text-white text-[11px] font-black px-3.5 py-1.5 rounded-full shadow-lg backdrop-blur-md border border-amber-300/40 animate-in fade-in zoom-in-95 pointer-events-none flex items-center gap-1.5 z-40">
          <Shield className="w-3.5 h-3.5 text-white" />
          <span>Avuç İçi Engellendi (Parmak Çizimi Kilitli)</span>
        </div>
      )}

      {/* Digital Ink OCR Live Recognition Floating Tag */}
      {ocrText && (
        <div className="absolute bottom-4 left-4 bg-slate-900/90 text-white text-xs font-bold px-3.5 py-2 rounded-2xl shadow-2xl backdrop-blur-md border border-teal-500/40 flex items-center gap-2 animate-in slide-in-from-bottom-2 z-40">
          <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
          <div className="flex flex-col">
            <span className="text-[9px] font-black uppercase tracking-wider text-teal-400">
              ML Kit El Yazısı Tanındı:
            </span>
            <span className="text-white font-mono">{ocrText}</span>
          </div>
          <button
            onClick={() => setOcrText(null)}
            className="ml-2 text-slate-400 hover:text-white p-1"
            title="Kapat"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
};

