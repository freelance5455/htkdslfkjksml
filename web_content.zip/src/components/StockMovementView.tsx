import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Sparkles } from 'lucide-react';
import { ALL_UNITS, fmtQty, getCategoryTemplate } from '../categoryTemplates';
import type { MovementType, Product, StoreData } from '../types';
import { findProductByBarcodeOrSku, fmtDateTime, fmtMoney, uid } from '../utils';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { Icon } from './Icon';
import { CustomSelect, SmartComboField, ToggleSwitch } from './SharedUI';

interface StockMovementViewProps {
  data: StoreData;
  t: Record<string, string>;
  onRecordMovement: (payload: { productId: string; type: MovementType; delta: number; reason: string }) => void;
  onQuickCreateProduct: (prod: Product, recordStockIn: boolean) => void;
  notify: (msg: string, type?: 'success' | 'error') => void;
}

const roundQty = (n: number) => Math.max(0, Math.round(n * 1000) / 1000);
const isWeightedUnit = (u?: string) => ['kg', 'g', 'l', 'ml', 'meter'].includes((u || '').toLowerCase());

export const StockMovementView: React.FC<StockMovementViewProps> = ({
  data,
  t,
  onRecordMovement,
  onQuickCreateProduct,
  notify,
}) => {
  const [productId, setProductId] = useState(data.products[0]?.id || '');
  const [filterCat, setFilterCat] = useState('all');
  const [filterSubCat, setFilterSubCat] = useState('all');
  const [filterBrand, setFilterBrand] = useState('all');
  const [barcodeQuery, setBarcodeQuery] = useState('');
  const [scannerOpen, setScannerOpen] = useState(false);
  const [type, setType] = useState<MovementType>('stock_in');
  const [adjDir, setAdjDir] = useState<'increase' | 'decrease'>('increase');
  const [qty, setQty] = useState('1');
  const [reason, setReason] = useState('');
  const [autoScanApply, setAutoScanApply] = useState(false);

  // Quick-create state when adding new product or scanning unrecognized barcode
  const [unmatchedBarcode, setUnmatchedBarcode] = useState<string | null>(null);
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState(data.categories[0]?.name || 'Mobile & Gadgets');
  const [newProdSubCat, setNewProdSubCat] = useState('');
  const [newProdBrand, setNewProdBrand] = useState('');
  const [newProdModel, setNewProdModel] = useState('');
  const [newProdVariant, setNewProdVariant] = useState('');
  const [newProdUnit, setNewProdUnit] = useState('pcs');
  const [newProdPurchase, setNewProdPurchase] = useState('');
  const [newProdSelling, setNewProdSelling] = useState('');
  const [newProdQty, setNewProdQty] = useState('1');

  const qtyInputRef = useRef<HTMLInputElement>(null);
  const newNameInputRef = useRef<HTMLInputElement>(null);

  const productMap = useMemo(() => new Map(data.products.map((p) => [p.id, p])), [data.products]);

  // Hierarchical product filtering (Category -> Sub-Category -> Brand)
  const catFilteredProducts = useMemo(
    () => (filterCat === 'all' ? data.products : data.products.filter((p) => p.category === filterCat)),
    [data.products, filterCat]
  );

  const availableFilterSubCats = useMemo(() => {
    const set = new Set<string>();
    catFilteredProducts.forEach((p) => {
      if (p.subCategory?.trim()) set.add(p.subCategory.trim());
    });
    return Array.from(set);
  }, [catFilteredProducts]);

  const availableFilterBrands = useMemo(() => {
    const set = new Set<string>();
    catFilteredProducts.forEach((p) => {
      if (filterSubCat !== 'all' && p.subCategory !== filterSubCat) return;
      if (p.brand?.trim()) set.add(p.brand.trim());
    });
    return Array.from(set);
  }, [catFilteredProducts, filterSubCat]);

  const filteredProducts = useMemo(() => {
    return catFilteredProducts.filter((p) => {
      if (filterSubCat !== 'all' && p.subCategory !== filterSubCat) return false;
      if (filterBrand !== 'all' && p.brand !== filterBrand) return false;
      return true;
    });
  }, [catFilteredProducts, filterSubCat, filterBrand]);

  useEffect(() => {
    if (filteredProducts.length > 0 && !filteredProducts.some((p) => p.id === productId)) {
      setProductId(filteredProducts[0].id);
    } else if (!productId && data.products.length > 0) {
      setProductId(data.products[0].id);
    }
  }, [filteredProducts, data.products, productId]);

  const selectedProduct = useMemo(
    () => data.products.find((p) => p.id === productId) || null,
    [data.products, productId]
  );

  const newProdTemplate = useMemo(
    () => getCategoryTemplate(newProdCategory, data.categories),
    [newProdCategory, data.categories]
  );

  const newProdModelSuggestions = useMemo(() => {
    const brandModels =
      newProdBrand && newProdTemplate.modelsByBrand?.[newProdBrand]
        ? newProdTemplate.modelsByBrand[newProdBrand]
        : [];
    return Array.from(new Set([...brandModels, ...newProdTemplate.genericModels]));
  }, [newProdBrand, newProdTemplate]);

  const unitOptions = useMemo(() => {
    const ordered = Array.from(new Set([...newProdTemplate.units, ...ALL_UNITS]));
    return ordered.map((u) => ({ value: u, label: u }));
  }, [newProdTemplate.units]);

  const productOptions = useMemo(
    () =>
      filteredProducts.map((p) => {
        const metaParts = [p.brand, p.subCategory, p.model, p.variantSpec].filter(Boolean).join(' · ');
        return {
          value: p.id,
          label: `${p.name} (${fmtQty(p.quantity, p.unit)})`,
          sublabel: `${p.category}${metaParts ? ` · ${metaParts}` : ''}${p.barcode ? ` · ${p.barcode}` : ''}`,
        };
      }),
    [filteredProducts]
  );

  const filterCategoryOptions = useMemo(
    () => [
      { value: 'all', label: `${t.allCategories} (${data.products.length})` },
      ...data.categories.map((c) => ({ value: c.name, label: c.name })),
    ],
    [data.categories, data.products.length, t.allCategories]
  );

  const categoryOptions = useMemo(
    () =>
      data.categories.length > 0
        ? data.categories.map((c) => ({ value: c.name, label: c.name }))
        : [{ value: 'General', label: 'General' }],
    [data.categories]
  );

  const adjDirOptions = useMemo(
    () => [
      { value: 'increase', label: t.increaseStock },
      { value: 'decrease', label: t.decreaseStock },
    ],
    [t]
  );

  const handleCategoryChange = (catName: string) => {
    const tmpl = getCategoryTemplate(catName, data.categories);
    setNewProdCategory(catName);
    setNewProdSubCat('');
    setNewProdBrand('');
    setNewProdModel('');
    setNewProdVariant('');
    setNewProdUnit(tmpl.defaultUnit);
  };

  const buildSuggestedName = () => {
    const parts = [newProdBrand, newProdModel, newProdSubCat, newProdVariant].map((s) => s.trim()).filter(Boolean);
    if (parts.length === 0) {
      notify('Pick a Brand, Type, or Model first to auto-fill name', 'error');
      return;
    }
    setNewProdName(parts.join(' '));
  };

  const openQuickCreateForCode = (code: string) => {
    const startCat = filterCat !== 'all' ? filterCat : data.categories[0]?.name || 'Mobile & Gadgets';
    const tmpl = getCategoryTemplate(startCat, data.categories);
    setUnmatchedBarcode(code);
    setNewProdName('');
    setNewProdCategory(startCat);
    setNewProdSubCat('');
    setNewProdBrand('');
    setNewProdModel('');
    setNewProdVariant('');
    setNewProdUnit(tmpl.defaultUnit);
    setNewProdPurchase('');
    setNewProdSelling('');
    setNewProdQty(qty && Number(qty) > 0 ? qty : '1');
    setTimeout(() => newNameInputRef.current?.focus(), 80);
  };

  const applyScannedProduct = (matched: Product) => {
    setUnmatchedBarcode(null);
    setFilterCat('all');
    setFilterSubCat('all');
    setFilterBrand('all');
    setProductId(matched.id);
    setBarcodeQuery('');

    if (autoScanApply && (type === 'stock_in' || type === 'stock_out')) {
      const parsed = roundQty(parseFloat(qty || '1'));
      const step = parsed > 0 ? parsed : 1;
      if (type === 'stock_out' && step > matched.quantity) {
        notify(`${matched.name}: ${t.cannotExceedStock}`, 'error');
        return;
      }
      const delta = type === 'stock_out' ? -step : step;
      onRecordMovement({
        productId: matched.id,
        type,
        delta,
        reason: reason.trim() || `Barcode Scan (${matched.barcode || matched.sku})`,
      });
      notify(
        `${matched.name}: ${delta > 0 ? `+${step}` : `-${step}`} ${matched.unit || ''} (Stock: ${fmtQty(
          roundQty(matched.quantity + delta),
          matched.unit
        )})`
      );
      return;
    }

    notify(`${matched.name} (${t.qty}: ${fmtQty(matched.quantity, matched.unit)})`);
    setTimeout(() => {
      qtyInputRef.current?.focus();
      qtyInputRef.current?.select();
    }, 60);
  };

  const findProductByCode = (rawCode: string, promptCreateIfMissing = true) => {
    const clean = rawCode.trim();
    if (!clean) return false;
    const matched = findProductByBarcodeOrSku(data.products, clean);
    if (matched) {
      applyScannedProduct(matched);
      return true;
    }
    setBarcodeQuery(clean);
    if (promptCreateIfMissing) {
      openQuickCreateForCode(clean);
      notify(`New barcode "${clean}" — select category details & save to stock.`, 'success');
    }
    return false;
  };

  const handleBarcodeInputChange = (val: string) => {
    setBarcodeQuery(val);
    const trimmed = val.trim();
    if (!trimmed) return;
    const exactMatch = data.products.find(
      (p) => (p.barcode || '').trim().toLowerCase() === trimmed.toLowerCase()
    );
    if (exactMatch) {
      applyScannedProduct(exactMatch);
    }
  };

  const handleBarcodeKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      findProductByCode(barcodeQuery, true);
    }
  };

  const handleQuickCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedBarcode = (unmatchedBarcode || barcodeQuery || '').trim();
    const autoFallback = [newProdBrand, newProdModel, newProdSubCat].map((s) => s.trim()).filter(Boolean).join(' ');
    const trimmedName = newProdName.trim() || autoFallback;
    const purchase = Number(newProdPurchase || 0);
    const selling = Number(newProdSelling || 0);
    const initialQty = roundQty(parseFloat(newProdQty || '0') || 0);

    if (!trimmedName || newProdPurchase === '' || newProdSelling === '') {
      notify(t.fillRequiredFields, 'error');
      return;
    }

    const existingDup = trimmedBarcode
      ? data.products.find((p) => (p.barcode || '').trim().toLowerCase() === trimmedBarcode.toLowerCase())
      : undefined;
    if (existingDup) {
      notify(`${t.duplicateBarcodeWarning} (${existingDup.name})`, 'error');
      setProductId(existingDup.id);
      setUnmatchedBarcode(null);
      return;
    }

    const newProduct: Product = {
      id: uid(),
      name: trimmedName,
      sku: trimmedBarcode ? `SKU-${trimmedBarcode.slice(-6).toUpperCase()}` : `SKU-${Date.now().toString().slice(-5)}`,
      barcode: trimmedBarcode,
      category: newProdCategory || data.categories[0]?.name || 'General',
      subCategory: newProdSubCat.trim(),
      brand: newProdBrand.trim(),
      model: newProdModel.trim(),
      variantSpec: newProdVariant.trim(),
      unit: newProdUnit || newProdTemplate.defaultUnit || 'pcs',
      purchasePrice: Math.max(0, purchase),
      sellingPrice: Math.max(0, selling),
      quantity: initialQty,
      minStock: data.settings.defaultLowStockLimit ?? 5,
      supplier: '',
      notes: 'Added via Stock Movement',
    };

    onQuickCreateProduct(newProduct, initialQty > 0);
    setFilterCat('all');
    setFilterSubCat('all');
    setFilterBrand('all');
    setProductId(newProduct.id);
    setUnmatchedBarcode(null);
    setBarcodeQuery('');
    setNewProdName('');
    setNewProdSubCat('');
    setNewProdBrand('');
    setNewProdModel('');
    setNewProdVariant('');
    setNewProdPurchase('');
    setNewProdSelling('');
    setNewProdQty('1');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const product = data.products.find((p) => p.id === productId);
    const amount = roundQty(parseFloat(qty || '0') || 0);
    if (!product || amount <= 0) {
      notify(t.fillRequiredFields, 'error');
      return;
    }

    const isDecrease = type === 'stock_out' || (type === 'adjustment' && adjDir === 'decrease');
    if (isDecrease && amount > product.quantity + 0.0001) {
      notify(t.cannotExceedStock, 'error');
      return;
    }
    onRecordMovement({ productId, type, delta: isDecrease ? -amount : amount, reason: reason.trim() });
    setQty('1');
    setReason('');
  };

  const statusColor = (tp: MovementType) => {
    if (tp === 'stock_in' || tp === 'sale_return') return 'text-emerald-700';
    if (tp === 'stock_out' || tp === 'sale') return 'text-rose-700';
    return 'text-amber-700';
  };

  const qtyPresets = isWeightedUnit(selectedProduct?.unit) ? [0.25, 0.5, 1, 5, 10, 25] : [1, 5, 10, 20];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <div className="lg:col-span-5 space-y-4">
        <div className="surface-card p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-bold text-slate-900">{t.recordMovement}</h3>
            <button
              type="button"
              onClick={() => openQuickCreateForCode(barcodeQuery.trim())}
              className="btn-secondary px-2.5 py-1.5 text-[11px] text-blue-700"
            >
              <Icon name="plus" className="w-3.5 h-3.5" />
              <span>New Product</span>
            </button>
          </div>

          {/* Movement Mode Segmented Tabs */}
          <div className="segmented-bar w-full grid grid-cols-3">
            {(
              [
                ['stock_in', t.stock_in],
                ['stock_out', t.stock_out],
                ['adjustment', t.adjustment],
              ] as const
            ).map(([mVal, mLabel]) => (
              <button
                type="button"
                key={mVal}
                onClick={() => setType(mVal)}
                className={`segmented-option text-center !px-2 ${
                  type === mVal
                    ? `segmented-option-active ${
                        mVal === 'stock_in' ? '!text-emerald-700' : mVal === 'stock_out' ? '!text-rose-700' : '!text-amber-700'
                      }`
                    : ''
                }`}
              >
                {mLabel}
              </button>
            ))}
          </div>

          {/* Barcode Scan / Quick Lookup for Stock In & Out */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/90 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <label className="block text-xs font-semibold text-slate-700">{t.scanBarcode}</label>
              {type !== 'adjustment' && (
                <div className="inline-flex items-center gap-2 text-[11px] font-semibold text-slate-600">
                  <span>{t.autoScanMode}</span>
                  <ToggleSwitch checked={autoScanApply} onChange={setAutoScanApply} label={t.autoScanMode} />
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={barcodeQuery}
                onChange={(e) => handleBarcodeInputChange(e.target.value)}
                onKeyDown={handleBarcodeKeyDown}
                placeholder={t.scanOrTypeBarcode}
                className="flex-1 min-w-0 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-mono outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
              <button
                type="button"
                onClick={() => setScannerOpen(true)}
                className="btn-dark px-3.5 py-2 text-xs shrink-0"
              >
                <Icon name="barcode" className="w-4 h-4" />
                <span>Scan</span>
              </button>
            </div>
          </div>

          {/* Inline Guided Category-Driven New Product Creation Panel */}
          {unmatchedBarcode !== null && (
            <form
              noValidate
              onSubmit={handleQuickCreateSubmit}
              className="p-4 rounded-2xl bg-blue-50/75 border-2 border-blue-200 space-y-3"
            >
              <div className="flex items-center justify-between gap-2">
                <div>
                  <p className="text-xs font-extrabold text-blue-900">{t.quickCreateBarcodeTitle}</p>
                  <p className="text-[11px] text-blue-700 mt-0.5">
                    Pick a category — fields adapt automatically for phone models, drinks, or kg items.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setUnmatchedBarcode(null)}
                  className="p-1.5 rounded-lg text-blue-700 hover:bg-blue-100"
                  title={t.close}
                >
                  <Icon name="x" className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t.category} *</label>
                  <CustomSelect value={newProdCategory} onChange={handleCategoryChange} options={categoryOptions} searchable />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t.barcode}</label>
                  <input
                    value={unmatchedBarcode}
                    onChange={(e) => setUnmatchedBarcode(e.target.value)}
                    placeholder="Optional barcode..."
                    className="w-full rounded-xl border border-blue-200 bg-white px-3 py-2.5 text-xs font-mono outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              {/* Dynamic Sub-Category & Brand */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">{newProdTemplate.subCategoryLabel}</label>
                  <SmartComboField
                    value={newProdSubCat}
                    onChange={setNewProdSubCat}
                    suggestions={newProdTemplate.subCategories}
                    placeholder="Tap or type 2 letters..."
                    quickChipsCount={3}
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">{newProdTemplate.brandLabel}</label>
                  <SmartComboField
                    value={newProdBrand}
                    onChange={setNewProdBrand}
                    suggestions={newProdTemplate.brands}
                    placeholder="e.g. Samsung, Apple, Frutika..."
                    quickChipsCount={4}
                  />
                </div>
              </div>

              {/* Dynamic Model / Phone Model & Variant */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">{newProdTemplate.modelLabel}</label>
                  <SmartComboField
                    value={newProdModel}
                    onChange={setNewProdModel}
                    suggestions={newProdModelSuggestions}
                    placeholder="Tap or type model / weight..."
                    quickChipsCount={4}
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">{newProdTemplate.variantLabel}</label>
                  <SmartComboField
                    value={newProdVariant}
                    onChange={setNewProdVariant}
                    suggestions={newProdTemplate.variants}
                    placeholder="Color, flavor, material..."
                    quickChipsCount={3}
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between gap-2 mb-1">
                  <label className="block text-[11px] font-semibold text-slate-700">{t.productName} *</label>
                  <button
                    type="button"
                    onClick={buildSuggestedName}
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 hover:underline"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Auto-fill Name</span>
                  </button>
                </div>
                <input
                  ref={newNameInputRef}
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder="Enter product name (or tap Auto-fill Name)..."
                  className="w-full rounded-xl border border-blue-200 bg-white px-3 py-2 text-sm font-semibold outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Unit</label>
                  <CustomSelect value={newProdUnit} onChange={setNewProdUnit} options={unitOptions} compact />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t.purchasePrice} *</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={newProdPurchase}
                    onChange={(e) => setNewProdPurchase(e.target.value)}
                    placeholder="0"
                    className="w-full rounded-xl border border-blue-200 bg-white px-2.5 py-2 text-xs font-bold tabular-nums outline-none focus:border-blue-500 min-h-[42px]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t.sellingPrice} *</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={newProdSelling}
                    onChange={(e) => setNewProdSelling(e.target.value)}
                    placeholder="0"
                    className="w-full rounded-xl border border-blue-200 bg-white px-2.5 py-2 text-xs font-bold tabular-nums outline-none focus:border-blue-500 min-h-[42px]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {t.quantity} ({newProdUnit}) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0"
                    value={newProdQty}
                    onChange={(e) => setNewProdQty(e.target.value)}
                    className="w-full rounded-xl border border-blue-200 bg-white px-2.5 py-2 text-xs font-bold tabular-nums outline-none focus:border-blue-500 min-h-[42px]"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={() => setUnmatchedBarcode(null)} className="btn-secondary px-3 py-2 text-xs">
                  {t.cancel}
                </button>
                <button type="submit" className="btn-primary px-4 py-2 text-xs">
                  {t.saveAndStockIn}
                </button>
              </div>
            </form>
          )}

          {/* Existing Product Stock In / Out Form with Hierarchical Category -> Sub-Category -> Brand Filter */}
          <form noValidate onSubmit={handleSubmit} className="space-y-4">
            <div className="p-3 rounded-xl bg-slate-50/80 border border-slate-200/80 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wide">Browse Stock by Category</span>
                {(filterCat !== 'all' || filterSubCat !== 'all' || filterBrand !== 'all') && (
                  <button
                    type="button"
                    onClick={() => {
                      setFilterCat('all');
                      setFilterSubCat('all');
                      setFilterBrand('all');
                    }}
                    className="text-[11px] font-bold text-blue-600 hover:underline"
                  >
                    Clear Filter
                  </button>
                )}
              </div>

              <CustomSelect
                value={filterCat}
                onChange={(val) => {
                  setFilterCat(val);
                  setFilterSubCat('all');
                  setFilterBrand('all');
                }}
                options={filterCategoryOptions}
                searchable
                compact
              />

              {filterCat !== 'all' && availableFilterSubCats.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setFilterSubCat('all');
                      setFilterBrand('all');
                    }}
                    className={`option-chip text-[11px] ${filterSubCat === 'all' ? 'option-chip-active' : ''}`}
                  >
                    All Types
                  </button>
                  {availableFilterSubCats.map((sc) => (
                    <button
                      type="button"
                      key={sc}
                      onClick={() => {
                        setFilterSubCat(sc);
                        setFilterBrand('all');
                      }}
                      className={`option-chip text-[11px] ${filterSubCat === sc ? 'option-chip-active' : ''}`}
                    >
                      {sc}
                    </button>
                  ))}
                </div>
              )}

              {filterCat !== 'all' && availableFilterBrands.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setFilterBrand('all')}
                    className={`option-chip text-[11px] ${filterBrand === 'all' ? 'option-chip-active' : ''}`}
                  >
                    All Brands
                  </button>
                  {availableFilterBrands.map((b) => (
                    <button
                      type="button"
                      key={b}
                      onClick={() => setFilterBrand(b)}
                      className={`option-chip text-[11px] ${filterBrand === b ? 'option-chip-active' : ''}`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                {t.selectProduct} ({filteredProducts.length})
              </label>
              <CustomSelect value={productId} onChange={setProductId} options={productOptions} searchable />
              {selectedProduct && (
                <div className="mt-2 px-3.5 py-2.5 rounded-xl bg-blue-50/75 border border-blue-100 flex items-center justify-between gap-2 text-xs tabular-nums">
                  <div className="min-w-0">
                    <p className="font-bold text-slate-900 truncate">{selectedProduct.name}</p>
                    <p className="text-[11px] text-slate-500 truncate">
                      {selectedProduct.category}
                      {selectedProduct.subCategory ? ` · ${selectedProduct.subCategory}` : ''}
                      {selectedProduct.brand ? ` · ${selectedProduct.brand}` : ''}
                      {selectedProduct.model ? ` · ${selectedProduct.model}` : ''}
                      {selectedProduct.barcode ? ` · ${selectedProduct.barcode}` : ''} · {fmtMoney(selectedProduct.sellingPrice)}
                    </p>
                  </div>
                  <span className="font-bold text-blue-700 whitespace-nowrap">
                    {t.inStock}: {fmtQty(selectedProduct.quantity, selectedProduct.unit)}
                  </span>
                </div>
              )}
            </div>

            {type === 'adjustment' && (
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.adjustmentDirection}</label>
                <CustomSelect value={adjDir} onChange={(v) => setAdjDir(v as 'increase' | 'decrease')} options={adjDirOptions} />
              </div>
            )}

            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                <label className="block text-xs font-semibold text-slate-600">
                  {t.quantity} {selectedProduct?.unit ? `(${selectedProduct.unit})` : ''} *
                </label>
                <div className="flex flex-wrap gap-1">
                  {qtyPresets.map((preset) => (
                    <button
                      type="button"
                      key={preset}
                      onClick={() => setQty(String(preset))}
                      className={`px-2 py-0.5 rounded-md text-[11px] font-bold border ${
                        qty === String(preset)
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
              <input
                ref={qtyInputRef}
                type="number"
                step="any"
                min="0.001"
                value={qty}
                onChange={(e) => setQty(e.target.value)}
                placeholder="1"
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-bold tabular-nums outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.reason}</label>
              <input
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Restock, damaged, audit..."
                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
            </div>

            <button
              type="submit"
              className={`w-full py-3 text-sm ${type === 'stock_in' ? 'btn-emerald' : type === 'stock_out' ? 'btn-dark' : 'btn-primary'}`}
            >
              {t.save} ({t[type] || type})
            </button>
          </form>
        </div>
      </div>

      <div className="lg:col-span-7">
        <div className="surface-card overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between gap-2">
            <h3 className="font-bold text-slate-900">{t.movementHistory}</h3>
            <span className="text-xs font-semibold text-slate-400 tabular-nums">{data.movements.length} logs</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left tabular-nums">
              <thead className="bg-slate-50 text-xs font-semibold text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3 whitespace-nowrap">{t.date}</th>
                  <th className="px-4 py-3 whitespace-nowrap">{t.productName}</th>
                  <th className="px-4 py-3 whitespace-nowrap">{t.movementType}</th>
                  <th className="px-4 py-3 text-right whitespace-nowrap">{t.prevQty}</th>
                  <th className="px-4 py-3 text-right whitespace-nowrap">{t.change}</th>
                  <th className="px-4 py-3 text-right whitespace-nowrap">{t.newQty}</th>
                  <th className="px-4 py-3 whitespace-nowrap">{t.reason}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.movements.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-10 text-slate-400">
                      {t.noData}
                    </td>
                  </tr>
                ) : (
                  data.movements.map((m) => {
                    const pUnit = productMap.get(m.productId)?.unit;
                    const roundedDelta = roundQty(Math.abs(m.delta));
                    return (
                      <tr key={m.id} className="hover:bg-slate-50/70">
                        <td className="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">{fmtDateTime(m.date)}</td>
                        <td className="px-4 py-3 font-semibold text-slate-800 whitespace-nowrap">{m.productName}</td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className={`text-xs font-bold ${statusColor(m.type)}`}>{t[m.type] || m.type}</span>
                        </td>
                        <td className="px-4 py-3 text-right text-slate-500">{fmtQty(m.prevQty, pUnit)}</td>
                        <td className={`px-4 py-3 text-right font-bold ${m.delta >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {m.delta >= 0 ? `+${roundedDelta}` : `-${roundedDelta}`}
                        </td>
                        <td className="px-4 py-3 text-right font-bold">{fmtQty(m.newQty, pUnit)}</td>
                        <td className="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">{m.reason || '-'}</td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <BarcodeScannerModal
        open={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onDetected={(code) => findProductByCode(code, true)}
        title={`${t.scanBarcode} — ${t.stockMovement}`}
        t={t}
        products={data.products}
      />
    </div>
  );
};

