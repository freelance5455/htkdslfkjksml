import React, { useState } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import { ClimbingClub, ClimbingStyle } from '../types/climbing';
import { MapPin, Plus, Edit2, Trash2, X, Building, AlertCircle, Phone, Smartphone, Mail, Globe } from 'lucide-react';

interface ClubManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectClub?: (clubId: string) => void;
}

export const ClubManagerModal: React.FC<ClubManagerModalProps> = ({
  isOpen,
  onClose,
  onSelectClub
}) => {
  const { clubs, addClub, updateClub, deleteClub, climbs } = useClimbing();
  const [searchTerm, setSearchTerm] = useState('');
  const [editingClubId, setEditingClubId] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [formData, setFormData] = useState<{
    name: string;
    location: string;
    region: string;
    wallTypes: ClimbingStyle[];
    isOfficialNicasCentre: boolean;
    notes: string;
    phone: string;
    mobile: string;
    email: string;
    website: string;
  }>({
    name: '',
    location: '',
    region: 'London & South East',
    wallTypes: ['Top Rope', 'Bouldering'],
    isOfficialNicasCentre: true,
    notes: '',
    phone: '',
    mobile: '',
    email: '',
    website: ''
  });

  if (!isOpen) return null;

  const filteredClubs = clubs.filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.region.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleStartCreate = () => {
    setEditingClubId(null);
    setFormData({
      name: '',
      location: '',
      region: 'London & South East',
      wallTypes: ['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'],
      isOfficialNicasCentre: true,
      notes: '',
      phone: '',
      mobile: '',
      email: '',
      website: ''
    });
    setErrorMessage(null);
    setIsCreating(true);
  };

  const handleStartEdit = (club: ClimbingClub) => {
    setIsCreating(false);
    setEditingClubId(club.id);
    setFormData({
      name: club.name,
      location: club.location,
      region: club.region,
      wallTypes: club.wallTypes,
      isOfficialNicasCentre: club.isOfficialNicasCentre,
      notes: club.notes || '',
      phone: club.phone || '',
      mobile: club.mobile || '',
      email: club.email || club.contactEmail || '',
      website: club.website || ''
    });
    setErrorMessage(null);
  };

  const handleToggleStyle = (style: ClimbingStyle) => {
    setFormData(prev => {
      const exists = prev.wallTypes.includes(style);
      return {
        ...prev,
        wallTypes: exists
          ? prev.wallTypes.filter(s => s !== style)
          : [...prev.wallTypes, style]
      };
    });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      setErrorMessage('Club or Wall name is required.');
      return;
    }
    if (!formData.location.trim()) {
      setErrorMessage('Location / Address is required.');
      return;
    }

    if (isCreating) {
      const created = addClub(formData);
      setIsCreating(false);
      if (onSelectClub) {
        onSelectClub(created.id);
      }
    } else if (editingClubId) {
      updateClub(editingClubId, formData);
      setEditingClubId(null);
    }
    setErrorMessage(null);
  };

  const handleDelete = (club: ClimbingClub) => {
    const climbsCount = climbs.filter(c => c.clubId === club.id).length;
    if (climbsCount > 0) {
      alert(`Cannot delete "${club.name}" because it has ${climbsCount} logged climbs associated with it. Please reassign those climbs first.`);
      return;
    }

    if (confirm(`Are you sure you want to remove "${club.name}" from your lookup database?`)) {
      deleteClub(club.id);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-xl shadow-xl w-full max-w-2xl max-h-[92vh] flex flex-col border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-orange-600" />
            <h2 className="text-sm sm:text-base font-bold">Centres & Walls Database</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {/* Create or Edit Form */}
          {(isCreating || editingClubId) ? (
            <form onSubmit={handleSave} className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3.5">
              <div className="flex items-center justify-between">
                <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                  {isCreating ? 'Add Climbing Centre' : 'Edit Climbing Centre'}
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    setIsCreating(false);
                    setEditingClubId(null);
                    setErrorMessage(null);
                  }}
                  className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                >
                  Cancel
                </button>
              </div>

              {errorMessage && (
                <div className="flex items-center gap-2 p-2.5 bg-red-50 text-red-700 rounded-lg text-xs border border-red-200">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Centre Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Castle Climbing Centre"
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Region</label>
                  <input
                    type="text"
                    placeholder="e.g. Greater London, North West"
                    value={formData.region}
                    onChange={e => setFormData({ ...formData, region: e.target.value })}
                    className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Location / Address *</label>
                <input
                  type="text"
                  required
                  placeholder="Street address, city, postcode"
                  value={formData.location}
                  onChange={e => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
                />
              </div>

              {/* Contact Details Section: Phone, Mobile, Email, Website */}
              <div className="pt-1 border-t border-slate-200 dark:border-slate-700">
                <span className="text-[11px] font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider block mb-2">
                  Contact Information
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                      <Phone className="w-3 h-3 text-orange-600" />
                      <span>Phone Number</span>
                    </label>
                    <input
                      type="tel"
                      placeholder="e.g. 020 8211 7000"
                      value={formData.phone}
                      onChange={e => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                      <Smartphone className="w-3 h-3 text-orange-600" />
                      <span>Mobile Number</span>
                    </label>
                    <input
                      type="tel"
                      placeholder="e.g. 07700 900142"
                      value={formData.mobile}
                      onChange={e => setFormData({ ...formData, mobile: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                      <Mail className="w-3 h-3 text-orange-600" />
                      <span>Email Address</span>
                    </label>
                    <input
                      type="email"
                      placeholder="e.g. reception@centre.co.uk"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                      <Globe className="w-3 h-3 text-orange-600" />
                      <span>Website URL</span>
                    </label>
                    <input
                      type="url"
                      placeholder="e.g. https://centre.co.uk"
                      value={formData.website}
                      onChange={e => setFormData({ ...formData, website: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Wall Types */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Available Disciplines</label>
                <div className="flex flex-wrap gap-1.5">
                  {(['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'] as ClimbingStyle[]).map(style => {
                    const active = formData.wallTypes.includes(style);
                    return (
                      <button
                        key={style}
                        type="button"
                        onClick={() => handleToggleStyle(style)}
                        className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-colors ${
                          active
                            ? 'bg-orange-600 text-white border-orange-600'
                            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                        }`}
                      >
                        {style}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setIsCreating(false);
                    setEditingClubId(null);
                  }}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs"
                >
                  {isCreating ? 'Save Centre' : 'Update Centre'}
                </button>
              </div>
            </form>
          ) : (
            <div className="flex items-center justify-between gap-2">
              <input
                type="text"
                placeholder="Search centres..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="flex-1 px-3 py-1.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-900 dark:text-white"
              />
              <button
                type="button"
                onClick={handleStartCreate}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
          )}

          {/* List of Clubs */}
          <div className="space-y-2">
            {filteredClubs.map(club => {
              return (
                <div
                  key={club.id}
                  className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-orange-300 dark:hover:border-orange-700 transition-colors flex items-center justify-between gap-2"
                >
                  <div
                    className="min-w-0 flex-1 cursor-pointer"
                    onClick={() => {
                      if (onSelectClub) {
                        onSelectClub(club.id);
                        onClose();
                      }
                    }}
                  >
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                        {club.name}
                      </span>
                      {club.isOfficialNicasCentre && (
                        <span className="text-[9px] font-bold text-orange-800 dark:text-orange-300 bg-orange-50 dark:bg-orange-950/60 border border-orange-200 dark:border-orange-800 px-1 py-0.2 rounded">
                          NICAS
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                      <span className="truncate">{club.location}</span>
                    </div>
                    {(club.phone || club.email) && (
                      <div className="text-[10px] text-slate-400 font-mono truncate">
                        {club.phone ? `Tel: ${club.phone}` : ''} {club.email ? `· ${club.email}` : ''}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    {onSelectClub && (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectClub(club.id);
                          onClose();
                        }}
                        className="px-2 py-1 text-[11px] font-semibold text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-950/50 rounded border border-orange-200 dark:border-orange-800"
                      >
                        Select
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleStartEdit(club)}
                      className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(club)}
                      className="p-1 text-slate-400 hover:text-red-600 rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-4 sm:px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-slate-900 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
