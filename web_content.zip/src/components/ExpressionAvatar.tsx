import React from 'react';
import { ExpressionType, MoodTheme } from '../types';

interface ExpressionAvatarProps {
  expression: ExpressionType;
  commentary?: string;
  theme: MoodTheme;
  isSpeaking: boolean;
}

const expressionDetails: Record<
  ExpressionType,
  { emoji: string; label: string; vibe: string; quote: string }
> = {
  smirk: {
    emoji: '😏',
    label: 'Smirking',
    vibe: 'Feeling Sassy',
    quote: 'Oh, you really thought?',
  },
  wink: {
    emoji: '😉',
    label: 'Winking',
    vibe: 'Cheeky & In On It',
    quote: 'Consider it done, darling.',
  },
  laugh: {
    emoji: '😆',
    label: 'Giggling',
    vibe: 'Can’t Even',
    quote: 'You are too funny, honestly.',
  },
  blush: {
    emoji: '😳',
    label: 'Blushing',
    vibe: 'Flustered & Coy',
    quote: 'Wait... are you flirting with me?',
  },
  fire: {
    emoji: '🔥',
    label: 'Feisty',
    vibe: 'Unapologetic Attitude',
    quote: 'Serving pure confidence.',
  },
  pout: {
    emoji: '😒',
    label: 'Side-Eye',
    vibe: 'Giving Reality Check',
    quote: 'Be so for real right now.',
  },
  heart: {
    emoji: '💖',
    label: 'Charmed',
    vibe: 'Soft Spot Activated',
    quote: 'Okay, that was actually sweet.',
  },
  neutral: {
    emoji: '💅',
    label: 'Poised',
    vibe: 'Listening & Confident',
    quote: 'I’m all ears. What’s next?',
  },
};

export const ExpressionAvatar: React.FC<ExpressionAvatarProps> = ({
  expression,
  commentary,
  theme,
  isSpeaking,
}) => {
  const current = expressionDetails[expression] || expressionDetails.neutral;

  return (
    <div className="flex flex-col items-center gap-2 select-none pointer-events-none">
      {/* Central Emoji & Aura */}
      <div className="relative">
        <div
          className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center text-3xl sm:text-4xl backdrop-blur-md bg-black/40 border border-white/20 shadow-2xl transition-transform duration-300 ${
            isSpeaking ? 'scale-110 animate-bounce' : 'scale-100'
          }`}
        >
          <span>{current.emoji}</span>
        </div>

        {/* Glow Ring */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-pink-500/30 to-purple-500/30 blur-md -z-10 animate-pulse" />
      </div>

      {/* Vibe Pill */}
      <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs text-white/90 shadow-md">
        <span className="w-2 h-2 rounded-full bg-pink-400 animate-ping" />
        <span className="font-semibold tracking-wide uppercase text-[10px] text-pink-300">
          {current.vibe}
        </span>
      </div>

      {/* Spoken Commentary or Quote */}
      {commentary ? (
        <div className="text-xs font-medium text-pink-200/90 text-center max-w-[260px] italic px-2 py-0.5 rounded bg-black/30 border border-pink-500/20">
          "{commentary}"
        </div>
      ) : null}
    </div>
  );
};
