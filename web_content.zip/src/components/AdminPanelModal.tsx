import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Ebook } from '../types';
import {
  X,
  TrendingUp,
  ShoppingBag,
  BookOpen,
  Users,
  Plus,
  Trash2,
  Edit,
  CheckCircle2,
  AlertTriangle,
  Server,
  Key,
  Database,
  Shield,
  Download,
  Calendar,
  Layers,
  Sparkles
} from 'lucide-react';

export const AdminPanelModal: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    ebooks,
    orders,
    addEbook,
    deleteEbook,
    updateEbook,
    categories,
    examUpdates,
    addExamUpdate,
    showToast
  } = useApp();

  const [adminTab, setAdminTab] = useState<'dashboard' | 'ebooks' | 'add-ebook' | 'orders' | 'architecture'>('dashboard');

  // New Ebook Form State
  const [newTitle, setNewTitle] = useState('');
  const [newSubtitle, setNewSubtitle] = useState('');
  const [newExam, setNewExam] = useState('Assam Direct Recruitment (ADRE)');
  const [newCategory, setNewCategory] = useState('assam-govt-jobs');
  const [newLanguage, setNewLanguage] = useState<'Assamese' | 'English' | 'Hindi' | 'Bengali'>('Assamese');
  const [newPrice, setNewPrice] = useState(149);
  const [newOriginalPrice, setNewOriginalPrice] = useState(399);
  const [newAuthor, setNewAuthor] = useState('Nexa Assam Exam Faculty');
  const [newPublisher, setNewPublisher] = useState('Nexa Exam Publications');
  const [newPages, setNewPages] = useState(380);
  const [newDescription, setNewDescription] = useState('Comprehensive preparation guide with chapter-wise MCQs and solved past papers.');
  const [isFree, setIsFree] = useState(false);
  const [isBestseller, setIsBestseller] = useState(true);
  const [isNewArrival, setIsNewArrival] = useState(false);

  // Calculate dashboard metrics
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalOrdersCount = orders.length;
  const totalBooksCount = ebooks.length;
  const activeStudentsEstimate = 12450;

  const handleCreateEbook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      alert('Please enter an ebook title.');
      return;
    }

    addEbook({
      title: newTitle,
      subtitle: newSubtitle || `Complete syllabus study material for ${newExam}`,
      author: newAuthor,
      publisher: newPublisher,
      categoryId: newCategory,
      subCategory: newExam,
      targetExam: newExam,
      language: newLanguage,
      price: isFree ? 0 : Number(newPrice),
      originalPrice: Number(newOriginalPrice),
      discountPercent: isFree ? 100 : Math.round(((newOriginalPrice - newPrice) / newOriginalPrice) * 100),
      isFree,
      isBestseller,
      isNewArrival,
      rating: 4.9,
      ratingCount: 1,
      pageCount: Number(newPages),
      fileSize: '16.5 MB',
      format: 'PDF',
      coverGradient: 'from-[#0B192C] via-[#1E3E62] to-[#0F172A]',
      coverAccent: '#F59E0B',
      description: newDescription,
      features: [
        `Strictly aligned with latest ${newExam} syllabus`,
        'Includes chapter-wise multiple choice questions with answers',
        'Solved past papers with detailed explanations',
        'Formula and memory recall revision sheet'
      ],
      tableOfContents: [
        { chapterNumber: 1, title: 'Introduction & Exam Blueprint', pages: '1-20', isSample: true },
        { chapterNumber: 2, title: 'Core Subject Concepts & Theory', pages: '21-160', isSample: true },
        { chapterNumber: 3, title: 'Question Bank & Explanations', pages: '161-320' },
        { chapterNumber: 4, title: 'Model Practice Papers', pages: '321-380' }
      ],
      sampleContent: {
        title: 'Chapter 1: Official Exam Scheme & Foundation',
        chapterName: 'Sample: Strategic Overview',
        text: `Foundational study notes prepared for ${newExam}. Candidates should practice daily MCQs and focus on high-yield topic weightages.`,
        sampleQuestions: [
          {
            q: `Sample diagnostic question for ${newExam}?`,
            a: 'Correct conceptual answer',
            explanation: 'Detailed explanation derived from standard curriculum.'
          }
        ]
      },
      hasPdfUploaded: true,
      pdfFileName: `${newTitle.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`,
      lastUpdated: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
      edition: '2026 Admin Release'
    });

    // Reset form
    setNewTitle('');
    setNewSubtitle('');
    setAdminTab('ebooks');
  };

  const handleExportOrders = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      ['Order ID,Customer,Phone,Amount,Status,Date']
        .concat(
          orders.map(
            (o) =>
              `"${o.orderNumber}","${o.customerName}","${o.customerPhone}","₹${o.total}","${o.paymentStatus}","${o.createdAt}"`
          )
        )
        .join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `NEXA_Orders_Report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Orders report exported as CSV!', 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 sm:py-8">
      {/* Top Banner */}
      <div className="bg-[#0B192C] text-white rounded-2xl p-5 sm:p-7 mb-6 border border-[#1E3E62] shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/20 uppercase tracking-wider">
              Super Admin Console
            </span>
            <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
              <Shield className="w-3.5 h-3.5" /> Authenticated Session
            </span>
          </div>
          <h1 className="text-xl sm:text-3xl font-black text-white">
            NEXA EXAM BOOKS Management Console
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Publish study materials, monitor verified student orders, manage discount coupons, and verify system architecture.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('home')}
          className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-4 py-2 rounded-xl border border-slate-700 transition-colors"
        >
          Exit to Storefront
        </button>
      </div>

      {/* Admin Sub Navigation */}
      <div className="border-b border-slate-200 mb-6">
        <nav className="flex items-center gap-2 sm:gap-4 overflow-x-auto text-xs sm:text-sm">
          {[
            { id: 'dashboard', label: 'Executive Dashboard', icon: TrendingUp },
            { id: 'ebooks', label: `Ebooks Inventory (${ebooks.length})`, icon: BookOpen },
            { id: 'add-ebook', label: '+ Add New Ebook', icon: Plus },
            { id: 'orders', label: `Orders & Revenue (${orders.length})`, icon: ShoppingBag },
            { id: 'architecture', label: 'Backend Architecture Guide', icon: Server },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = adminTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setAdminTab(tab.id as any)}
                className={`py-3 font-bold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
                  isActive
                    ? 'border-amber-500 text-amber-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-500' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Tab 1: Executive Dashboard */}
      {adminTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Key Metric Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 p-4 sm:p-5 rounded-2xl shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase block">Total Sales Revenue</span>
              <div className="text-2xl sm:text-3xl font-black text-[#0B192C] mt-1">₹{totalRevenue.toLocaleString('en-IN')}</div>
              <span className="text-[11px] font-semibold text-emerald-600 mt-1 block">Verified payments</span>
            </div>

            <div className="bg-white border border-slate-200 p-4 sm:p-5 rounded-2xl shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase block">Orders Placed</span>
              <div className="text-2xl sm:text-3xl font-black text-[#0B192C] mt-1">{totalOrdersCount}</div>
              <span className="text-[11px] font-semibold text-blue-600 mt-1 block">100% Digital Delivery</span>
            </div>

            <div className="bg-white border border-slate-200 p-4 sm:p-5 rounded-2xl shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase block">Active Catalog Size</span>
              <div className="text-2xl sm:text-3xl font-black text-[#0B192C] mt-1">{totalBooksCount}</div>
              <span className="text-[11px] font-semibold text-amber-600 mt-1 block">Railway, Police, ADRE, SSC</span>
            </div>

            <div className="bg-white border border-slate-200 p-4 sm:p-5 rounded-2xl shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase block">Active Aspirants</span>
              <div className="text-2xl sm:text-3xl font-black text-[#0B192C] mt-1">{activeStudentsEstimate.toLocaleString('en-IN')}+</div>
              <span className="text-[11px] font-semibold text-emerald-600 mt-1 block">Across Assam & India</span>
            </div>
          </div>

          {/* Quick Actions & Recent Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="text-xs font-bold text-[#0B192C] uppercase tracking-wider">
                  Recent Verified Purchases & Invoices
                </h3>
                <button
                  onClick={handleExportOrders}
                  className="text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" /> Export CSV
                </button>
              </div>

              <div className="divide-y divide-slate-100 mt-2">
                {orders.slice(0, 5).map((ord) => (
                  <div key={ord.id} className="py-3 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-bold text-slate-900">{ord.customerName} ({ord.customerPhone})</p>
                      <p className="text-[11px] text-slate-500">Order #{ord.orderNumber} • {ord.items.length} Books • {ord.createdAt}</p>
                    </div>
                    <div className="text-right">
                      <span className="font-black text-[#0B192C] block">₹{ord.total}</span>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded">
                        {ord.paymentStatus}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-4 bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-3">
              <h3 className="text-xs font-bold text-[#0B192C] uppercase tracking-wider">
                Quick Shortcuts
              </h3>
              <button
                onClick={() => setAdminTab('add-ebook')}
                className="w-full text-left p-3 rounded-xl bg-white border border-slate-200 hover:border-amber-400 font-bold text-xs text-slate-800 flex items-center justify-between transition-colors"
              >
                <span>Publish New Ebook Guide</span>
                <Plus className="w-4 h-4 text-amber-500" />
              </button>
              <button
                onClick={() => setAdminTab('architecture')}
                className="w-full text-left p-3 rounded-xl bg-white border border-slate-200 hover:border-amber-400 font-bold text-xs text-slate-800 flex items-center justify-between transition-colors"
              >
                <span>Production Database Specs</span>
                <Server className="w-4 h-4 text-blue-500" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Ebooks Inventory */}
      {adminTab === 'ebooks' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-[#0B192C] uppercase tracking-wider">
              Manage Ebook Catalog ({ebooks.length} Active Titles)
            </h3>
            <button
              onClick={() => setAdminTab('add-ebook')}
              className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Add New Ebook
            </button>
          </div>

          <div className="divide-y divide-slate-100 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold">
                  <th className="p-3">Ebook Details</th>
                  <th className="p-3">Exam Category</th>
                  <th className="p-3">Language</th>
                  <th className="p-3">Price</th>
                  <th className="p-3">Tags</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ebooks.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50">
                    <td className="p-3 font-semibold text-slate-900 max-w-xs">
                      <p className="line-clamp-1">{b.title}</p>
                      <p className="text-[10px] text-slate-400 font-normal">{b.publisher} • {b.pageCount} Pages</p>
                    </td>
                    <td className="p-3 text-slate-600">{b.targetExam}</td>
                    <td className="p-3">
                      <span className="bg-slate-100 px-2 py-0.5 rounded font-medium text-slate-700">
                        {b.language}
                      </span>
                    </td>
                    <td className="p-3 font-bold text-[#0B192C]">
                      {b.isFree ? <span className="text-emerald-600 font-extrabold">FREE</span> : `₹${b.price}`}
                    </td>
                    <td className="p-3">
                      <div className="flex gap-1 flex-wrap">
                        {b.isBestseller && <span className="text-[9px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded">Bestseller</span>}
                        {b.isNewArrival && <span className="text-[9px] font-bold bg-blue-100 text-blue-800 px-1.5 py-0.2 rounded">New</span>}
                      </div>
                    </td>
                    <td className="p-3 text-right space-x-1">
                      <button
                        onClick={() => {
                          const newP = prompt('Update selling price (₹):', b.price.toString());
                          if (newP && !isNaN(Number(newP))) {
                            updateEbook(b.id, { price: Number(newP) });
                          }
                        }}
                        className="p-1.5 text-slate-500 hover:text-amber-600 rounded hover:bg-slate-100"
                        title="Edit Price"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Delete "${b.title}" from catalog?`)) {
                            deleteEbook(b.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded hover:bg-red-50"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Add Ebook Form */}
      {adminTab === 'add-ebook' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs max-w-3xl space-y-5">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-[#0B192C] uppercase tracking-wider">
              Publish New Ebook to NEXA Catalog
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Enter comprehensive syllabus and pricing metadata.
            </p>
          </div>

          <form onSubmit={handleCreateEbook} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Full Ebook Title *
              </label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Assam Police UB Constable 2026 Ultimate Guide"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium outline-none focus:border-amber-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Subtitle / Exam Highlight
              </label>
              <input
                type="text"
                value={newSubtitle}
                onChange={(e) => setNewSubtitle(e.target.value)}
                placeholder="e.g. 5000+ Chapter-wise MCQs & 5 Solved OMR Papers"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium outline-none focus:border-amber-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Category *
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Target Exam *
                </label>
                <input
                  type="text"
                  value={newExam}
                  onChange={(e) => setNewExam(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Content Language *
                </label>
                <select
                  value={newLanguage}
                  onChange={(e) => setNewLanguage(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                >
                  <option value="Assamese">Assamese (অসমীয়া)</option>
                  <option value="English">English</option>
                  <option value="Hindi">Hindi (हिंदी)</option>
                  <option value="Bengali">Bengali (বাংলা)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Page Count
                </label>
                <input
                  type="number"
                  value={newPages}
                  onChange={(e) => setNewPages(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Selling Price (₹)
                </label>
                <input
                  type="number"
                  disabled={isFree}
                  value={newPrice}
                  onChange={(e) => setNewPrice(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium disabled:opacity-50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Original MRP (₹)
                </label>
                <input
                  type="number"
                  value={newOriginalPrice}
                  onChange={(e) => setNewOriginalPrice(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
                />
              </div>
            </div>

            {/* Checkbox badges */}
            <div className="flex items-center gap-4 pt-2">
              <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold text-emerald-800">
                <input
                  type="checkbox"
                  checked={isFree}
                  onChange={(e) => setIsFree(e.target.checked)}
                />
                <span>Mark as 100% Free Ebook</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold text-amber-800">
                <input
                  type="checkbox"
                  checked={isBestseller}
                  onChange={(e) => setIsBestseller(e.target.checked)}
                />
                <span>Bestseller Tag</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold text-blue-800">
                <input
                  type="checkbox"
                  checked={isNewArrival}
                  onChange={(e) => setIsNewArrival(e.target.checked)}
                />
                <span>New Arrival 2026</span>
              </label>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Ebook Description
              </label>
              <textarea
                rows={3}
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs px-6 py-3 rounded-xl transition-colors shadow-md"
              >
                Publish Ebook to Live App Catalog
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tab 4: Orders & Revenue Log */}
      {adminTab === 'orders' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-[#0B192C] uppercase tracking-wider">
              Student Orders & Verified Payment Logs ({orders.length})
            </h3>
            <button
              onClick={handleExportOrders}
              className="text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" /> Download Report (CSV)
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold">
                  <th className="p-3">Order Number</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Method</th>
                  <th className="p-3">Amount</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-50">
                    <td className="p-3 font-mono font-bold text-slate-800">{ord.orderNumber}</td>
                    <td className="p-3 text-slate-500">{ord.createdAt}</td>
                    <td className="p-3">
                      <p className="font-bold text-slate-900">{ord.customerName}</p>
                      <p className="text-[10px] text-slate-500">{ord.customerPhone} • {ord.state}</p>
                    </td>
                    <td className="p-3 font-medium text-slate-700">{ord.paymentMethod}</td>
                    <td className="p-3 font-black text-[#0B192C]">₹{ord.total}</td>
                    <td className="p-3">
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                        {ord.paymentStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 5: Real Backend & Database Architecture Instructions */}
      {adminTab === 'architecture' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-6 max-w-4xl">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-[#0B192C] uppercase tracking-wider flex items-center gap-2">
              <Server className="w-4 h-4 text-amber-500" />
              NEXA EXAM BOOKS Backend Architecture & Integration Guide
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Production guidelines for integrating Supabase / Firebase, Razorpay webhooks, and private PDF buckets.
            </p>
          </div>

          <div className="space-y-4 text-xs text-slate-700 leading-relaxed">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                <Database className="w-4 h-4 text-blue-600" /> 1. Database Entities & Schemas
              </h4>
              <p>
                In production, tables are provisioned with Row-Level Security (RLS):
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-600">
                <li><code>profiles</code>: id (UUID), full_name, email, phone, state, role ('student' | 'admin').</li>
                <li><code>ebooks</code>: id, title, subtitle, category_id, target_exam, language, price, file_storage_path.</li>
                <li><code>orders</code> & <code>order_items</code>: order_number, user_id, subtotal, discount, total, payment_status.</li>
                <li><code>purchases</code>: user_id, ebook_id, order_id, unlocked_at. Enforces that only verified buyers can request file download URLs.</li>
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                <Key className="w-4 h-4 text-amber-600" /> 2. Indian Payment Verification (Razorpay / Cashfree)
              </h4>
              <p>
                To prevent fraud, payment status must never be trusted from client browser callbacks alone:
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-600">
                <li>The frontend initializes checkout using an order created on <code>/api/create-payment-order</code>.</li>
                <li>Upon student payment in PhonePe/UPI, Razorpay dispatches a secure cryptographic webhook signature (HMAC SHA-256) to <code>/api/payment-webhook</code>.</li>
                <li>The server verifies <code>razorpay_signature</code> with <code>RAZORPAY_WEBHOOK_SECRET</code>. Only then is the record inserted into <code>purchases</code>.</li>
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-emerald-600" /> 3. Protected PDF Cloud Storage & Downloads
              </h4>
              <p>
                Private PDF files are never kept in public storage buckets:
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-600">
                <li>Files are stored in private Cloud Storage with restricted access.</li>
                <li>When the user clicks "Download PDF" or "Read Online", an authenticated endpoint <code>/api/download-ebook/:id</code> validates the user's active session and purchase table record.</li>
                <li>A signed URL valid for 15 minutes is generated or the stream is securely piped.</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
