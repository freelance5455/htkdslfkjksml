import React, { useState, useEffect } from 'react';
import {
  X,
  Shield,
  Trash2,
  Lock,
  Search,
  Users,
  MessageSquare,
  Activity,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  LogOut,
  Calendar,
} from 'lucide-react';

interface AdminUser {
  id: string;
  username: string;
  email: string;
  displayName: string;
  avatar: string;
  bio?: string;
  theme?: string;
  createdAt: string;
  stats?: {
    totalChats: number;
    totalMessages: number;
  };
}

interface AdminStats {
  totalUsers: number;
  totalChats: number;
  totalMessages: number;
  activeSessions: number;
  serverTime: string;
}

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUserDeleted?: (deletedUserId: string) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  onUserDeleted,
}) => {
  const [adminToken, setAdminToken] = useState<string | null>(() =>
    sessionStorage.getItem('sosiska_admin_token')
  );
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);

  // Dashboard state
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loadingData, setLoadingData] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(
    null
  );

  // Deletion modal state
  const [userToDelete, setUserToDelete] = useState<AdminUser | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Verify stored token or fetch data on open
  useEffect(() => {
    if (isOpen && adminToken) {
      fetchAdminData(adminToken);
    }
  }, [isOpen, adminToken]);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthLoading(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Неверный пароль администратора');
      }

      setAdminToken(data.adminToken);
      sessionStorage.setItem('sosiska_admin_token', data.adminToken);
      setPassword('');
      fetchAdminData(data.adminToken);
    } catch (err: any) {
      setAuthError(err.message || 'Ошибка авторизации администратора');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleAdminLogout = () => {
    setAdminToken(null);
    sessionStorage.removeItem('sosiska_admin_token');
    setUsers([]);
    setStats(null);
  };

  const fetchAdminData = async (token: string) => {
    setLoadingData(true);
    try {
      const [usersRes, statsRes] = await Promise.all([
        fetch('/api/admin/users', {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch('/api/admin/stats', {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (usersRes.status === 401 || statsRes.status === 401) {
        handleAdminLogout();
        return;
      }

      if (usersRes.ok) {
        const usersData = await usersRes.json();
        setUsers(usersData.users || []);
      }

      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData.stats || null);
      }
    } catch (err) {
      console.error('Error fetching admin data:', err);
    } finally {
      setLoadingData(false);
    }
  };

  const confirmDeleteUser = async () => {
    if (!userToDelete || !adminToken) return;

    setDeletingId(userToDelete.id);
    try {
      const res = await fetch(`/api/admin/users/${userToDelete.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` },
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Ошибка при удалении профиля');
      }

      setUsers((prev) => prev.filter((u) => u.id !== userToDelete.id));
      setNotification({
        type: 'success',
        message: `Профиль @${userToDelete.username} (${userToDelete.displayName}) успешно удален`,
      });

      // Update stats count
      setStats((prev) =>
        prev
          ? {
              ...prev,
              totalUsers: Math.max(0, prev.totalUsers - 1),
              totalChats: Math.max(0, prev.totalChats - (userToDelete.stats?.totalChats || 0)),
              totalMessages: Math.max(0, prev.totalMessages - (userToDelete.stats?.totalMessages || 0)),
            }
          : null
      );

      onUserDeleted?.(userToDelete.id);
      setUserToDelete(null);

      setTimeout(() => {
        setNotification(null);
      }, 4000);
    } catch (err: any) {
      setNotification({
        type: 'error',
        message: err.message || 'Не удалось удалить профиль',
      });
    } finally {
      setDeletingId(null);
    }
  };

  if (!isOpen) return null;

  const filteredUsers = users.filter((u) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      u.username.toLowerCase().includes(q) ||
      u.displayName.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      u.id.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 shadow-inner">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  Панель администратора
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  ROOT
                </span>
              </div>
              <p className="text-xs text-neutral-400">Управление пользователями и базой данных</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {adminToken && (
              <>
                <button
                  onClick={() => fetchAdminData(adminToken)}
                  disabled={loadingData}
                  className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-xl transition-colors cursor-pointer"
                  title="Обновить список"
                >
                  <RefreshCw className={`w-4 h-4 ${loadingData ? 'animate-spin text-orange-400' : ''}`} />
                </button>
                <button
                  onClick={handleAdminLogout}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs text-neutral-300 hover:text-white transition-colors cursor-pointer"
                  title="Выйти из админки"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Выход</span>
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {!adminToken ? (
            /* ================= ADMIN LOGIN SCREEN ================= */
            <div className="max-w-sm mx-auto py-10 text-center">
              <div className="w-16 h-16 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-center text-rose-400 mx-auto mb-4 shadow-xl">
                <Lock className="w-7 h-7" />
              </div>

              <h4 className="text-xl font-bold text-white mb-1.5">Требуется доступ администратора</h4>
              <p className="text-xs text-neutral-400 mb-6">
                Введите пароль для входа в панель управления и удаления профилей
              </p>

              {authError && (
                <div className="mb-4 p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs flex items-center gap-2 text-left">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{authError}</span>
                </div>
              )}

              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div className="relative text-left">
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Пароль администратора
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-500">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      type="password"
                      autoFocus
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Введите пароль..."
                      className="w-full pl-9 pr-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={authLoading || !password}
                  className="w-full py-2.5 px-4 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-medium text-sm rounded-xl shadow-lg shadow-rose-600/20 disabled:opacity-50 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  {authLoading ? (
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Shield className="w-4 h-4" />
                      <span>Войти в админ-панель</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          ) : (
            /* ================= ADMIN DASHBOARD ================= */
            <>
              {/* Notification Banner */}
              {notification && (
                <div
                  className={`p-3.5 rounded-2xl text-xs flex items-center gap-2.5 animate-fadeIn ${
                    notification.type === 'success'
                      ? 'bg-emerald-950/40 border border-emerald-800/60 text-emerald-300'
                      : 'bg-rose-950/40 border border-rose-800/60 text-rose-300'
                  }`}
                >
                  {notification.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  )}
                  <span>{notification.message}</span>
                </div>
              )}

              {/* Statistics Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 bg-neutral-950/70 border border-neutral-800 rounded-2xl">
                  <div className="flex items-center justify-between text-neutral-400 mb-1">
                    <span className="text-xs">Пользователей</span>
                    <Users className="w-4 h-4 text-orange-400" />
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {stats?.totalUsers ?? users.length}
                  </div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">В базе данных</div>
                </div>

                <div className="p-3.5 bg-neutral-950/70 border border-neutral-800 rounded-2xl">
                  <div className="flex items-center justify-between text-neutral-400 mb-1">
                    <span className="text-xs">Диалогов</span>
                    <MessageSquare className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="text-2xl font-bold text-white">{stats?.totalChats ?? 0}</div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">Всех сессий чата</div>
                </div>

                <div className="p-3.5 bg-neutral-950/70 border border-neutral-800 rounded-2xl">
                  <div className="flex items-center justify-between text-neutral-400 mb-1">
                    <span className="text-xs">Сообщений</span>
                    <Activity className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-2xl font-bold text-white">{stats?.totalMessages ?? 0}</div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">Сгенерировано</div>
                </div>

                <div className="p-3.5 bg-neutral-950/70 border border-neutral-800 rounded-2xl">
                  <div className="flex items-center justify-between text-neutral-400 mb-1">
                    <span className="text-xs">Статус системы</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  </div>
                  <div className="text-sm font-bold text-emerald-400 mt-1">Работает штатно</div>
                  <div className="text-[10px] text-neutral-500 mt-1">Доступ защищен</div>
                </div>
              </div>

              {/* Users search and table header */}
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Поиск по логину, имени, email или ID..."
                      className="w-full pl-9 pr-3 py-2 bg-neutral-950/80 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-neutral-700"
                    />
                  </div>
                  <div className="text-xs text-neutral-400 self-center">
                    Найдено: <strong className="text-white">{filteredUsers.length}</strong> из {users.length}
                  </div>
                </div>

                {/* Users List */}
                <div className="space-y-2.5">
                  {loadingData ? (
                    <div className="p-8 text-center text-xs text-neutral-400 animate-pulse">
                      Загрузка профилей пользователей...
                    </div>
                  ) : filteredUsers.length === 0 ? (
                    <div className="p-8 text-center text-xs text-neutral-500 bg-neutral-950/40 rounded-2xl border border-neutral-800">
                      Пользователи не найдены
                    </div>
                  ) : (
                    filteredUsers.map((userItem) => {
                      const regDate = new Date(userItem.createdAt).toLocaleDateString('ru-RU', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      });

                      const isGuest = userItem.username.startsWith('guest_');

                      return (
                        <div
                          key={userItem.id}
                          className="p-3.5 sm:p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800 hover:border-neutral-700 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                        >
                          {/* User info */}
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-11 h-11 rounded-2xl bg-neutral-800/80 border border-neutral-700 flex items-center justify-center text-2xl shrink-0 shadow-sm">
                              {userItem.avatar || '👤'}
                            </div>

                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-white text-sm truncate">
                                  {userItem.displayName}
                                </span>
                                <span className="text-xs text-orange-400 font-mono">
                                  @{userItem.username}
                                </span>
                                {isGuest && (
                                  <span className="px-1.5 py-0.2 rounded text-[10px] bg-neutral-800 text-neutral-400">
                                    Демо
                                  </span>
                                )}
                              </div>

                              <div className="text-xs text-neutral-400 truncate mt-0.5">
                                {userItem.email}
                              </div>

                              <div className="flex items-center gap-3 text-[11px] text-neutral-500 mt-1">
                                <span className="flex items-center gap-1">
                                  <Calendar className="w-3 h-3" />
                                  <span>{regDate}</span>
                                </span>
                                <span>•</span>
                                <span>{userItem.stats?.totalChats ?? 0} диалогов</span>
                                <span>•</span>
                                <span>{userItem.stats?.totalMessages ?? 0} сообщений</span>
                              </div>
                            </div>
                          </div>

                          {/* Delete Action Button */}
                          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                            <button
                              onClick={() => setUserToDelete(userItem)}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 border border-rose-500/30 text-xs font-medium transition-all cursor-pointer group shadow-sm"
                              title="Удалить профиль пользователя"
                            >
                              <Trash2 className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
                              <span>Удалить профиль</span>
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* ================= CONFIRM DELETE POPUP MODAL ================= */}
      {userToDelete && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-neutral-900 border border-rose-900/60 rounded-3xl shadow-2xl p-6 text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto mb-4">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <h4 className="text-lg font-bold text-white mb-2">
              Удалить профиль @{userToDelete.username}?
            </h4>

            <p className="text-xs text-neutral-300 mb-4 leading-relaxed">
              Вы собираетесь безвозвратно удалить аккаунт{' '}
              <strong className="text-white">«{userToDelete.displayName}»</strong>.
              <br />
              Все связанные диалоги ({userToDelete.stats?.totalChats ?? 0}), сообщения и токены авторизации будут стёрты из базы данных.
            </p>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="flex-1 py-2.5 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium transition-colors cursor-pointer"
              >
                Отмена
              </button>
              <button
                type="button"
                disabled={deletingId === userToDelete.id}
                onClick={confirmDeleteUser}
                className="flex-1 py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-lg shadow-rose-600/30 transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                {deletingId === userToDelete.id ? (
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Да, удалить</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
