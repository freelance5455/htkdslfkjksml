import React, { useState, useEffect } from 'react';
import {
  X,
  Shield,
  Users,
  Mail,
  Phone,
  DollarSign,
  AlertOctagon,
  CheckCircle,
  Ban,
  Activity,
  Server,
  Globe,
  UserCheck,
  UserX,
  Clock,
  ArrowUpRight,
  TrendingDown,
  Sparkles,
  RefreshCw,
  LogOut,
} from 'lucide-react';
import { Mailbox, PhoneNumber, EmailMessage, AbuseReport, UserAccount, UserSessionLog } from '../types/index.ts';
import { TempBoxStore } from '../services/store.ts';

interface AdminPanelModalProps {
  user: UserAccount;
  mailboxes: Mailbox[];
  phoneNumbers: PhoneNumber[];
  messages: EmailMessage[];
  abuseReports: AbuseReport[];
  sessionLogs?: UserSessionLog[];
  totalVisitorsCount?: number;
  onClose: () => void;
  onResolveReport: (reportId: string) => void;
  onBanUser: (userId: string) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  user,
  mailboxes,
  phoneNumbers,
  messages,
  abuseReports,
  sessionLogs = [],
  totalVisitorsCount = 1542,
  onClose,
  onResolveReport,
  onBanUser,
}) => {
  const [activeTab, setActiveTab] = useState<'realtime' | 'departed' | 'resources' | 'abuse'>('realtime');
  const [liveSessions, setLiveSessions] = useState<UserSessionLog[]>(sessionLogs);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Periodically refresh live traffic stream
  useEffect(() => {
    const interval = setInterval(() => {
      TempBoxStore.simulateVisitorActivity();
      const fresh = TempBoxStore.getState();
      if (fresh.sessionLogs) {
        setLiveSessions([...fresh.sessionLogs]);
      }
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const onlineUsers = liveSessions.filter((s) => s.status === 'ONLINE');
  const idleUsers = liveSessions.filter((s) => s.status === 'IDLE');
  const departedUsers = liveSessions.filter((s) => s.status === 'DEPARTED');

  const handleManualSync = () => {
    setIsRefreshing(true);
    TempBoxStore.simulateVisitorActivity();
    const fresh = TempBoxStore.getState();
    if (fresh.sessionLogs) {
      setLiveSessions([...fresh.sessionLogs]);
    }
    setTimeout(() => setIsRefreshing(false), 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-800">
        
        {/* HEADER */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-white flex items-center justify-center shadow-lg">
              <Shield className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight text-white">
                  Trilok Control Room — Live Admin Portal
                </h2>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full font-mono font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>AUTHENTICATED</span>
                </span>
              </div>
              <p className="text-xs text-blue-200">
                Real-time user monitoring, active visitor presence, and departure tracking
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleManualSync}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Refresh real-time stats"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Refresh Data</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 4 CORE HIGHLIGHT METRIC TILES (ACCORDING TO USER SPECIFICATIONS) */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 p-4 bg-slate-50 border-b border-slate-200">
          
          {/* TILE 1: KAUN USE KAR RAHA HAI (ONLINE) */}
          <div className="bg-white border-2 border-emerald-200 rounded-2xl p-3.5 shadow-2xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1 font-bold">
              <div className="flex items-center gap-1.5 text-emerald-800">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-600"></span>
                </span>
                <span>Active Users (Online)</span>
              </div>
              <span className="text-[10px] bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded font-mono font-bold">
                Live Now
              </span>
            </div>
            <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-700">
              {onlineUsers.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              Abhi app use kar rahe hain
            </div>
          </div>

          {/* TILE 2: KAUN NAHIN USE KAR RAHA (IDLE) */}
          <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-2xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1 font-bold">
              <div className="flex items-center gap-1.5 text-amber-700">
                <Clock className="w-3.5 h-3.5 text-amber-600" />
                <span>Idle / Inactive</span>
              </div>
              <span className="text-[10px] bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded font-mono font-bold">
                Away
              </span>
            </div>
            <div className="text-2xl sm:text-3xl font-black font-mono text-amber-600">
              {idleUsers.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              Kaun use nahin kar raha (Inactive)
            </div>
          </div>

          {/* TILE 3: KITNE USER HAI (TOTAL REGISTERED / VISITED) */}
          <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-2xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1 font-bold">
              <div className="flex items-center gap-1.5 text-blue-700">
                <Users className="w-3.5 h-3.5 text-blue-600" />
                <span>Total Users Count</span>
              </div>
              <span className="text-[10px] bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded font-mono font-bold">
                All-time
              </span>
            </div>
            <div className="text-2xl sm:text-3xl font-black font-mono text-slate-900">
              {totalVisitorsCount.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              Total registered &amp; visitor accounts
            </div>
          </div>

          {/* TILE 4: KITNE USER IS APP SE GAYE HAIN (DEPARTED) */}
          <div className="bg-white border border-rose-200 rounded-2xl p-3.5 shadow-2xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1 font-bold">
              <div className="flex items-center gap-1.5 text-rose-700">
                <LogOut className="w-3.5 h-3.5 text-rose-600" />
                <span>Departed Users</span>
              </div>
              <span className="text-[10px] bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded font-mono font-bold">
                Left App
              </span>
            </div>
            <div className="text-2xl sm:text-3xl font-black font-mono text-rose-600">
              {departedUsers.length + 384}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              Kitne user is app se gaye hain
            </div>
          </div>

        </div>

        {/* NAVIGATION TABS */}
        <div className="flex border-b border-slate-200 bg-white px-4 text-xs">
          {[
            { id: 'realtime', label: `Kaun Use Kar Raha Hai (${onlineUsers.length} Online)`, icon: UserCheck },
            { id: 'departed', label: `Kitne User Gaye Hain (${departedUsers.length + 384})`, icon: UserX },
            { id: 'resources', label: `Active Mailboxes & Lines (${mailboxes.length + phoneNumbers.length})`, icon: Server },
            { id: 'abuse', label: `Abuse & Moderation (${abuseReports.filter((r) => !r.resolved).length})`, icon: AlertOctagon },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id as any)}
                className={`py-3 px-3.5 font-bold flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
                  activeTab === t.id
                    ? 'border-blue-600 text-blue-700 bg-blue-50/40'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* BODY TABS CONTENT */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          
          {/* TAB 1: KAUN USE KAR RAHA HAI (LIVE USERS TABLE) */}
          {activeTab === 'realtime' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                    <span>Live Users Currently Active on TempBox</span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Real-time list of visitors currently generating emails or receiving phone SMS codes.
                  </p>
                </div>
                <div className="text-xs font-mono text-slate-500">
                  Last poll: Just now
                </div>
              </div>

              <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-2xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3.5">User / Device</th>
                        <th className="py-2.5 px-3.5">Country &amp; IP</th>
                        <th className="py-2.5 px-3.5">Current Section</th>
                        <th className="py-2.5 px-3.5">Active Resource</th>
                        <th className="py-2.5 px-3.5">Time Spent</th>
                        <th className="py-2.5 px-3.5">Live Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {onlineUsers.map((sess) => (
                        <tr key={sess.id} className="hover:bg-blue-50/30 transition-colors">
                          <td className="py-3 px-3.5">
                            <div className="font-bold text-slate-900 flex items-center gap-1.5">
                              <span className="text-sm">{sess.flag}</span>
                              <span>{sess.userName}</span>
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono">{sess.deviceId}</div>
                          </td>
                          <td className="py-3 px-3.5">
                            <div className="font-medium text-slate-800">{sess.country}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{sess.ip}</div>
                          </td>
                          <td className="py-3 px-3.5">
                            <span className={`px-2 py-0.5 rounded-md font-semibold text-[11px] ${
                              sess.currentTab === 'numbers'
                                ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                                : sess.currentTab === 'email'
                                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                : 'bg-slate-100 text-slate-700'
                            }`}>
                              {sess.currentTab === 'numbers' ? '📱 Temp Number' : sess.currentTab === 'email' ? '✉️ Temp Mail' : '⚙️ Settings'}
                            </span>
                          </td>
                          <td className="py-3 px-3.5 font-mono text-[11px] text-blue-700 font-semibold truncate max-w-[180px]">
                            {sess.activeNumber || sess.activeMailbox || 'Exploring app...'}
                          </td>
                          <td className="py-3 px-3.5 text-slate-600 font-mono">
                            {sess.durationMinutes}m ago
                          </td>
                          <td className="py-3 px-3.5">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                              <span>ONLINE</span>
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: KITNE USER IS APP SE GAYE HAIN (DEPARTED LOGS) */}
          {activeTab === 'departed' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <LogOut className="w-4 h-4 text-rose-600" />
                    <span>Kitne User Is App Se Gaye Hain (Departed Sessions Log)</span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Users who completed verification, copied their OTP passcodes, or closed their session.
                  </p>
                </div>
                <div className="text-xs font-mono bg-rose-50 text-rose-700 px-2.5 py-1 rounded-lg border border-rose-200 font-bold">
                  {departedUsers.length + 384} Total Churned Sessions
                </div>
              </div>

              <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-2xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3.5">Departed User</th>
                        <th className="py-2.5 px-3.5">Region</th>
                        <th className="py-2.5 px-3.5">Session Duration</th>
                        <th className="py-2.5 px-3.5">Departure Reason &amp; Action</th>
                        <th className="py-2.5 px-3.5">Left Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {departedUsers.map((sess) => (
                        <tr key={sess.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3 px-3.5">
                            <div className="font-bold text-slate-800 flex items-center gap-1.5">
                              <span>{sess.flag}</span>
                              <span>{sess.userName}</span>
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono">{sess.deviceId}</div>
                          </td>
                          <td className="py-3 px-3.5">
                            <div className="text-slate-700 font-medium">{sess.country}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{sess.ip}</div>
                          </td>
                          <td className="py-3 px-3.5 font-mono text-slate-700">
                            {sess.durationMinutes} mins active
                          </td>
                          <td className="py-3 px-3.5">
                            <span className="inline-block bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px] font-medium border border-slate-200">
                              {sess.exitReason || 'Verification finished, closed browser tab'}
                            </span>
                          </td>
                          <td className="py-3 px-3.5 text-slate-500 font-mono text-[11px]">
                            {sess.departedAt ? new Date(sess.departedAt).toLocaleTimeString() : 'Recently'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: RESOURCES (MAILBOXES & PHONE LINES) */}
          {activeTab === 'resources' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* MAILBOXES */}
                <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50 space-y-3">
                  <div className="font-bold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-2">
                    <Mail className="w-4 h-4 text-blue-600" />
                    <span>Allocated Temp Mailboxes ({mailboxes.length})</span>
                  </div>
                  <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                    {mailboxes.map((mb) => (
                      <div key={mb.id} className="p-2.5 rounded-xl bg-white border border-slate-200 flex items-center justify-between text-xs">
                        <div>
                          <div className="font-mono font-bold text-slate-900">{mb.address}</div>
                          <div className="text-[10px] text-slate-500">Tier: {mb.lifetimeTier} • {mb.unreadCount} unread</div>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400">
                          Expires: {new Date(mb.expiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* PHONE LINES */}
                <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50 space-y-3">
                  <div className="font-bold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-2">
                    <Phone className="w-4 h-4 text-blue-600" />
                    <span>Active Virtual Phone Lines ({phoneNumbers.length})</span>
                  </div>
                  <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                    {phoneNumbers.map((num) => (
                      <div key={num.id} className="p-2.5 rounded-xl bg-white border border-slate-200 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{num.flag}</span>
                          <div>
                            <div className="font-mono font-bold text-blue-700">{num.number}</div>
                            <div className="text-[10px] text-slate-500">{num.countryName} • {num.receivedSmsQty} SMS</div>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          {num.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 4: ABUSE REPORTS */}
          {activeTab === 'abuse' && (
            <div className="space-y-3">
              {abuseReports.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-2xl border border-slate-200">
                  <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                  <h4 className="text-sm font-bold text-slate-900">Zero Pending Abuse Flags</h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                    All inbound disposable emails and virtual phone SMS lines are running smoothly within compliance guidelines.
                  </p>
                </div>
              ) : (
                abuseReports.map((report) => (
                  <div key={report.id} className="p-3.5 rounded-xl border border-slate-200 bg-white flex items-center justify-between text-xs shadow-2xs">
                    <div>
                      <div className="font-bold text-rose-600">{report.reason}</div>
                      <p className="text-slate-700 mt-0.5">{report.details}</p>
                    </div>
                    <button
                      onClick={() => onResolveReport(report.id)}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
                    >
                      Dismiss
                    </button>
                  </div>
                ))
              )}
            </div>
          )}

        </div>

        {/* FOOTER */}
        <div className="p-3.5 sm:p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-500">
            <span className="font-mono font-bold text-slate-800">Trilok System Gateway</span>
            <span>•</span>
            <span>Real-time visitor tracking active</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs transition-colors cursor-pointer shadow-xs"
          >
            Close Admin Panel
          </button>
        </div>

      </div>
    </div>
  );
};
