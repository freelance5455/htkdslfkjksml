"use client";
import { useEffect, useRef, useState } from "react";
import type { Settings, Tab } from "@/lib/store";
import { Icon, IconButton, Markdown } from "./ui";

type Msg = { id?: number; role: string; content: string; sources?: { title: string; url: string }[] };
type Conv = { id: number; title: string; updatedAt: string };
type Task = "chat" | "summarize" | "translate" | "page" | "tabs" | "code";

export type AIChatHandle = { ask: (text: string, task?: Task) => void };

export function AIChat({
  settings,
  activeTab,
  tabs,
  getPageText,
  onOpenUrl,
  pendingPrompt,
  onPromptConsumed,
}: {
  settings: Settings;
  activeTab: Tab | undefined;
  tabs: Tab[];
  getPageText: () => Promise<{ title: string; url: string; text: string } | null>;
  onOpenUrl: (url: string) => void;
  pendingPrompt: { text: string; task: Task; nonce: number } | null;
  onPromptConsumed: () => void;
}) {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [convId, setConvId] = useState<number | null>(null);
  const [convs, setConvs] = useState<Conv[]>([]);
  const [showConvs, setShowConvs] = useState(false);
  const [provider, setProvider] = useState<string>("");
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [useSearch, setUseSearch] = useState(settings.aiSearch);
  const bottomRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    fetch("/api/ai/providers").then((r) => r.json()).then((d) => setProvider(d.active)).catch(() => {});
    loadConvs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, busy]);

  useEffect(() => {
    if (pendingPrompt) {
      send(pendingPrompt.text, pendingPrompt.task);
      onPromptConsumed();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingPrompt?.nonce]);

  async function loadConvs() {
    try {
      const r = await fetch(`/api/ai/conversations?profileId=${settings.profileId}`);
      setConvs(await r.json());
    } catch {
      /* ignore */
    }
  }

  async function openConv(id: number) {
    const r = await fetch(`/api/ai/conversations/${id}`);
    setMsgs(await r.json());
    setConvId(id);
    setShowConvs(false);
  }

  async function deleteConv(id: number) {
    await fetch(`/api/ai/conversations/${id}`, { method: "DELETE" });
    if (convId === id) {
      setConvId(null);
      setMsgs([]);
    }
    loadConvs();
  }

  function speak(text: string) {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const clean = text.replace(/[*_`#>\[\]()]/g, "").replace(/https?:\/\/\S+/g, "");
    const u = new SpeechSynthesisUtterance(clean.slice(0, 2000));
    u.lang = /[а-яё]/i.test(clean) ? "ru-RU" : "en-US";
    u.onend = () => setSpeaking(false);
    setSpeaking(true);
    window.speechSynthesis.speak(u);
  }

  function stopSpeak() {
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }

  function startVoice() {
    const W = window as unknown as { webkitSpeechRecognition?: new () => SR; SpeechRecognition?: new () => SR };
    const Ctor = W.SpeechRecognition || W.webkitSpeechRecognition;
    if (!Ctor) return alert("Голосовой ввод не поддерживается");
    const rec = new Ctor();
    rec.lang = "ru-RU";
    rec.onresult = (e) => {
      const t = e.results[0][0].transcript;
      setInput(t);
      send(t, "chat");
    };
    rec.onend = () => setListening(false);
    setListening(true);
    rec.start();
  }

  async function send(text: string, task: Task = "chat") {
    const t = text.trim();
    if (!t || busy) return;
    setInput("");
    setBusy(true);
    setMsgs((m) => [...m, { role: "user", content: t }]);
    try {
      let page: { url: string; title: string; text?: string } | null = null;
      if (activeTab && activeTab.url !== "nova://home") {
        page = { url: activeTab.url, title: activeTab.title };
        if (task === "summarize" || task === "page" || task === "translate" || /стран|page|здесь|это/i.test(t)) {
          const pt = await getPageText();
          if (pt?.text) page.text = pt.text;
        }
      }
      const r = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          conversationId: convId,
          message: t,
          task,
          useSearch,
          provider: settings.aiProvider,
          page,
          tabs: task === "tabs" ? tabs.filter((x) => !x.incognito).map((x) => ({ url: x.url, title: x.title })) : undefined,
          profileId: settings.profileId,
        }),
      });
      const d = await r.json();
      if (d.error) throw new Error(d.error);
      setConvId(d.conversationId);
      setProvider(d.provider);
      setMsgs((m) => [...m, { role: "assistant", content: d.message.content, sources: d.sources }]);
      if (settings.tts) speak(d.message.content);
      loadConvs();
    } catch (e) {
      setMsgs((m) => [...m, { role: "assistant", content: "⚠️ " + (e instanceof Error ? e.message : "Ошибка") }]);
    } finally {
      setBusy(false);
    }
  }

  const hasPage = activeTab && activeTab.url !== "nova://home";
  const quick: { label: string; icon: string; task: Task; text: string; needPage?: boolean }[] = [
    { label: "Суммаризировать страницу", icon: "doc", task: "summarize", text: "Сделай краткое содержание этой страницы", needPage: true },
    { label: "Спросить про страницу", icon: "sparkles", task: "page", text: "О чём эта страница? Какие главные тезисы?", needPage: true },
    { label: "Перевести страницу", icon: "translate", task: "translate", text: "Переведи основной текст этой страницы на русский язык", needPage: true },
    { label: "Анализ вкладок", icon: "tabs", task: "tabs", text: "Проанализируй мои открытые вкладки" },
    { label: "Помощь с кодом", icon: "code", task: "code", text: "Помоги мне с кодом: " },
  ];

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-12 items-center gap-1 border-b border-black/5 px-2 dark:border-white/10">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-400 text-white">
          <Icon name="sparkles" size={15} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold leading-none">Nova AI</div>
          <div className="truncate text-[10px] text-slate-400">
            {provider === "local" ? "автономный режим" : provider ? `провайдер: ${provider}` : "…"} · поиск {useSearch ? "вкл" : "выкл"}
          </div>
        </div>
        <IconButton icon="globe" label="Веб-поиск в реальном времени" active={useSearch} onClick={() => setUseSearch((v) => !v)} />
        <IconButton icon="history" label="История диалогов" active={showConvs} onClick={() => setShowConvs((v) => !v)} />
        <IconButton
          icon="plus"
          label="Новый диалог"
          onClick={() => {
            setConvId(null);
            setMsgs([]);
            setShowConvs(false);
          }}
        />
      </div>

      {showConvs ? (
        <div className="min-h-0 flex-1 overflow-y-auto p-2 scrollbar-thin">
          {convs.length === 0 && <div className="p-6 text-center text-sm text-slate-400">Диалогов пока нет</div>}
          {convs.map((c) => (
            <div key={c.id} className={`group flex items-center gap-2 rounded-xl px-3 py-2 hover:bg-black/5 dark:hover:bg-white/10 ${c.id === convId ? "bg-black/5 dark:bg-white/10" : ""}`}>
              <button type="button" onClick={() => openConv(c.id)} className="min-w-0 flex-1 text-left">
                <div className="truncate text-sm">{c.title}</div>
                <div className="text-[10px] text-slate-400">{new Date(c.updatedAt).toLocaleString("ru-RU")}</div>
              </button>
              <IconButton icon="trash" label="Удалить" size={14} className="!h-7 !w-7 opacity-0 group-hover:opacity-100" onClick={() => deleteConv(c.id)} />
            </div>
          ))}
        </div>
      ) : (
        <div className="min-h-0 flex-1 overflow-y-auto px-3 py-3 scrollbar-thin">
          {msgs.length === 0 && (
            <div className="space-y-3">
              <div className="rounded-2xl bg-gradient-to-br from-indigo-500/10 to-cyan-400/10 p-4 text-sm">
                <div className="mb-1 font-semibold">Привет! Я Nova AI 👋</div>
                <div className="text-slate-600 dark:text-slate-300">Отвечаю на вопросы с поиском в интернете, суммаризирую страницы, перевожу, помогаю с кодом и анализирую вкладки.</div>
              </div>
              <div className="grid gap-1.5">
                {quick.map((qk) => (
                  <button
                    key={qk.label}
                    type="button"
                    disabled={qk.needPage && !hasPage}
                    onClick={() => (qk.task === "code" ? (setInput(qk.text), taRef.current?.focus()) : send(qk.text, qk.task))}
                    className="flex items-center gap-2 rounded-xl border border-black/5 bg-white px-3 py-2 text-left text-sm hover:bg-black/5 disabled:opacity-40 dark:border-white/10 dark:bg-white/5 dark:hover:bg-white/10"
                  >
                    <Icon name={qk.icon} size={16} className="accent-text" /> {qk.label}
                  </button>
                ))}
              </div>
              {hasPage && <div className="truncate px-1 text-[11px] text-slate-400">Текущая страница: {activeTab?.title}</div>}
            </div>
          )}
          {msgs.map((m, i) => (
            <div key={i} className={`mb-3 flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[92%] rounded-2xl px-3.5 py-2.5 ${m.role === "user" ? "accent-bg text-white" : "bg-white shadow-sm dark:bg-white/10"}`}>
                {m.role === "user" ? (
                  <div className="whitespace-pre-wrap text-[13.5px]">{m.content}</div>
                ) : (
                  <div
                    onClick={(e) => {
                      const a = (e.target as HTMLElement).closest("a[data-nova-link]") as HTMLAnchorElement | null;
                      if (a) {
                        e.preventDefault();
                        onOpenUrl(a.href);
                      }
                    }}
                  >
                    <Markdown text={m.content} />
                    {m.sources && m.sources.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1 border-t border-black/5 pt-2 dark:border-white/10">
                        {m.sources.map((s, j) => (
                          <button key={j} type="button" onClick={() => onOpenUrl(s.url)} title={s.url} className="max-w-[160px] truncate rounded-full bg-black/5 px-2 py-0.5 text-[10px] hover:bg-black/10 dark:bg-white/10 dark:hover:bg-white/20">
                            [{j + 1}] {s.title || s.url}
                          </button>
                        ))}
                      </div>
                    )}
                    <div className="mt-1 flex gap-1 opacity-60">
                      <IconButton icon="copy" label="Копировать" size={13} className="!h-6 !w-6" onClick={() => navigator.clipboard?.writeText(m.content)} />
                      <IconButton icon={speaking ? "stop" : "speaker"} label="Озвучить" size={13} className="!h-6 !w-6" onClick={() => (speaking ? stopSpeak() : speak(m.content))} />
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          {busy && (
            <div className="mb-3 flex items-center gap-2 text-xs text-slate-400">
              <span className="h-3 w-3 animate-spin rounded-full border-2 border-slate-300 border-t-[var(--accent)]" /> Nova AI думает{useSearch ? " и ищет в интернете" : ""}…
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      )}

      {!showConvs && (
        <div className="border-t border-black/5 p-2 dark:border-white/10">
          {hasPage && msgs.length > 0 && (
            <div className="mb-1.5 flex gap-1 overflow-x-auto no-scrollbar">
              <button type="button" onClick={() => send("Сделай краткое содержание этой страницы", "summarize")} className="shrink-0 rounded-full bg-black/5 px-2.5 py-1 text-[11px] hover:bg-black/10 dark:bg-white/10">
                📄 Суммаризировать
              </button>
              <button type="button" onClick={() => send("Переведи основной текст страницы на русский", "translate")} className="shrink-0 rounded-full bg-black/5 px-2.5 py-1 text-[11px] hover:bg-black/10 dark:bg-white/10">
                🌐 Перевести
              </button>
              <button type="button" onClick={() => send("Проанализируй мои открытые вкладки", "tabs")} className="shrink-0 rounded-full bg-black/5 px-2.5 py-1 text-[11px] hover:bg-black/10 dark:bg-white/10">
                🗂 Вкладки
              </button>
            </div>
          )}
          <div className="accent-ring flex items-end gap-1 rounded-2xl border border-black/5 bg-white p-1 dark:border-white/10 dark:bg-white/5">
            <textarea
              ref={taRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                }
              }}
              rows={1}
              placeholder="Спросите Nova AI…"
              className="max-h-32 min-h-[36px] flex-1 resize-none bg-transparent px-2 py-2 text-sm outline-none"
            />
            <IconButton icon="mic" label="Голосовой ввод" onClick={startVoice} className={listening ? "animate-pulse accent-text" : ""} />
            <button type="button" onClick={() => send(input)} disabled={busy || !input.trim()} className="accent-bg flex h-9 w-9 items-center justify-center rounded-full text-white disabled:opacity-40">
              <Icon name="send" size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

type SR = {
  lang: string;
  start: () => void;
  onresult: ((e: { results: { [i: number]: { [j: number]: { transcript: string } } } }) => void) | null;
  onend: (() => void) | null;
};
