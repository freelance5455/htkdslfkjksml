import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { BellRing, ShieldAlert, CheckCircle2, Sliders, TrendingUp, TrendingDown, RefreshCw, Zap } from 'lucide-react';

interface AutoAlertManagerProps {
  currentTotalUsd: number;
  onShowToast?: (msg: string) => void;
}

export const AutoAlertManager: React.FC<AutoAlertManagerProps> = ({ currentTotalUsd, onShowToast }) => {
  const [isEnabled, setIsEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('juhnkrix_auto_alert_enabled');
    return saved !== null ? JSON.parse(saved) : true;
  });
  const [thresholdPercent, setThresholdPercent] = useState<number>(() => {
    const saved = localStorage.getItem('juhnkrix_auto_alert_threshold');
    return saved !== null ? parseFloat(saved) : 10;
  });
  const [lastCheckedValue, setLastCheckedValue] = useState<number>(() => {
    const saved = localStorage.getItem('juhnkrix_auto_alert_baseline');
    return saved !== null ? parseFloat(saved) : currentTotalUsd;
  });
  const [alertStatus, setAlertStatus] = useState<string>('Monitoring active (24h window)');

  useEffect(() => {
    localStorage.setItem('juhnkrix_auto_alert_enabled', JSON.stringify(isEnabled));
    localStorage.setItem('juhnkrix_auto_alert_threshold', thresholdPercent.toString());
  }, [isEnabled, thresholdPercent]);

  useEffect(() => {
    if (!isEnabled) return;
    if (lastCheckedValue <= 0) {
      setLastCheckedValue(currentTotalUsd);
      localStorage.setItem('juhnkrix_auto_alert_baseline', currentTotalUsd.toString());
      return;
    }

    const percentChange = ((currentTotalUsd - lastCheckedValue) / lastCheckedValue) * 100;
    if (Math.abs(percentChange) >= thresholdPercent) {
      const direction = percentChange > 0 ? 'rose' : 'dropped';
      const msg = `🚨 Auto-Alert Manager: Your total wallet value ${direction} by ${Math.abs(percentChange).toFixed(1)}% in the last 24h!`;
      setAlertStatus(msg);
      if (onShowToast) onShowToast(msg);
      // Update baseline to prevent spamming
      setLastCheckedValue(currentTotalUsd);
      localStorage.setItem('juhnkrix_auto_alert_baseline', currentTotalUsd.toString());
    }
  }, [currentTotalUsd, isEnabled, thresholdPercent, lastCheckedValue]);

  const handleResetBaseline = () => {
    setLastCheckedValue(currentTotalUsd);
    localStorage.setItem('juhnkrix_auto_alert_baseline', currentTotalUsd.toString());
    setAlertStatus('Baseline successfully reset to current portfolio value.');
    if (onShowToast) onShowToast('✓ Auto-Alert baseline reset to current portfolio value.');
  };

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-amber-500/20 pb-5">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-lg">
            <BellRing className="w-6 h-6 text-amber-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/30">
                REAL-TIME GROWTH GUARD
              </span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold font-serif text-amber-100 mt-1">
              Wallet Auto-Alert Manager
            </h3>
            <p className="text-xs text-slate-400">
              Sends automated push notifications and alerts if your total wallet value drops or rises by more than {thresholdPercent}% within a 24-hour period.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={isEnabled}
              onChange={(e) => setIsEnabled(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
            <span className="ml-3 text-xs font-bold text-amber-200">
              {isEnabled ? 'Alerts Active' : 'Alerts Disabled'}
            </span>
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-slate-950/80 p-5 rounded-2xl border border-amber-500/20 space-y-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Trigger Threshold</span>
          <div className="flex items-center space-x-3">
            <input
              type="range"
              min="2"
              max="25"
              step="1"
              value={thresholdPercent}
              onChange={(e) => setThresholdPercent(parseInt(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <span className="text-base font-black text-amber-300 font-mono">±{thresholdPercent}%</span>
          </div>
          <p className="text-[10px] text-slate-400">Triggers if 24h variation exceeds this percentage.</p>
        </div>

        <div className="bg-slate-950/80 p-5 rounded-2xl border border-amber-500/20 space-y-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">24h Baseline Value</span>
          <div className="text-lg font-bold text-amber-100 font-mono">
            ${lastCheckedValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <button
            onClick={handleResetBaseline}
            className="text-[11px] text-amber-400 hover:text-amber-300 underline flex items-center space-x-1 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Reset Baseline to Current</span>
          </button>
        </div>

        <div className="bg-slate-950/80 p-5 rounded-2xl border border-amber-500/20 space-y-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Status & Log</span>
          <div className="text-xs text-amber-200 font-mono bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 truncate">
            {alertStatus}
          </div>
          <span className="text-[10px] text-emerald-400 font-mono flex items-center">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping mr-1.5" />
            Active Surveillance Guard
          </span>
        </div>
      </div>
    </div>
  );
};
