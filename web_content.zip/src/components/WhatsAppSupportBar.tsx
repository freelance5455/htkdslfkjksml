import React from 'react';
import { MessageCircle, Phone, HelpCircle, ShieldAlert } from 'lucide-react';

export const WhatsAppSupportBar: React.FC = () => {
  return (
    <div className="space-y-4">
      {/* WhatsApp Button matching user's exact specification */}
      <a
        href="https://wa.me/923333997576?text=Hello%20JazzCash%20CNIC%20Support%2C%20I%20have%20an%20inquiry%20regarding%20batch%20verification."
        target="_blank"
        rel="noopener noreferrer"
        className="w-full py-4 px-6 rounded-xl bg-[#159b50] hover:bg-[#128846] text-white font-bold text-base sm:text-lg flex items-center justify-center gap-3 shadow-md hover:shadow-lg transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-center"
      >
        <MessageCircle className="w-6 h-6 fill-white/20 shrink-0" />
        <span>WHATSAPP SUPPORT: 03333997576</span>
      </a>

      {/* Helpful Agent Instructions / Hotline Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="bg-white rounded-xl p-3.5 border border-slate-200/80 shadow-2xs text-xs text-slate-600 flex items-start gap-2.5">
          <Phone className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-slate-800 block">Agent Helpline</span>
            <span>Dial <strong className="text-slate-900 font-mono">0333-3997576</strong> for bulk business onboarding & biometric clearance assistance.</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-3.5 border border-slate-200/80 shadow-2xs text-xs text-slate-600 flex items-start gap-2.5">
          <HelpCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-slate-800 block">NADRA Biometric Requirement</span>
            <span>Unregistered CNICs must visit nearest JazzCash retail franchise for thumbprint verification.</span>
          </div>
        </div>
      </div>

      {/* Compliance Disclaimer matching user's exact snippet */}
      <div className="text-center text-slate-500 text-xs py-3 px-4 border-t border-slate-200/70">
        <p className="font-semibold text-slate-700">
          CNIC Checker | Authorized verification required
        </p>
        <p className="text-slate-400 mt-0.5 text-[11px] leading-relaxed">
          This tool does not access JazzCash account records or private citizen biometric archives without authorized agent credentials.
        </p>
      </div>
    </div>
  );
};
