import React, { useState } from 'react';
import { UserProfile, ChatRoom } from '../types';
import { Shield, ShieldAlert, UserMinus, UserPlus, X, Crown, Check } from 'lucide-react';
import { VipName } from './VipName';
import { playAppSound } from '../utils/audio';

interface GroupMembersModalProps {
  chat: ChatRoom;
  currentUser: UserProfile;
  allUsersMap: Record<string, UserProfile>;
  onUpdateGroup: (chatId: string, updatedData: Partial<ChatRoom>) => Promise<void>;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const GroupMembersModal: React.FC<GroupMembersModalProps> = ({
  chat,
  currentUser,
  allUsersMap,
  onUpdateGroup,
  onClose,
  onToast
}) => {
  const [activeTab, setActiveTab] = useState<'list' | 'add'>('list');
  const [searchAddQuery, setSearchAddQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const members = chat.members || [];
  const admins = chat.admins || (chat.createdBy ? [chat.createdBy] : []);
  const ownerId = chat.createdBy || '';
  const isOwner = currentUser.id === ownerId;
  const isAdmin = admins.includes(currentUser.id) || isOwner;

  // Add member
  const handleAddMember = async (userId: string) => {
    if (!isAdmin) {
      onToast('إضافة أعضاء مقتصرة على مشرفي المجموعة');
      return;
    }
    if (members.includes(userId)) {
      onToast('المستخدم عضو في المجموعة بالفعل');
      return;
    }
    setIsProcessing(true);
    try {
      const newMembers = [...members, userId];
      await onUpdateGroup(chat.id, { members: newMembers });
      playAppSound('click');
      onToast('تمت إضافة العضو إلى المجموعة الملكية بنجاح 🚀');
    } catch {
      onToast('حدث خطأ في إضافة العضو');
    } finally {
      setIsProcessing(false);
    }
  };

  // Remove member
  const handleRemoveMember = async (targetId: string) => {
    if (!isAdmin) return;
    if (targetId === ownerId) {
      onToast('لا يمكن طرد مالك ومؤسس المجموعة');
      return;
    }
    setIsProcessing(true);
    try {
      const newMembers = members.filter((id) => id !== targetId);
      const newAdmins = admins.filter((id) => id !== targetId);
      await onUpdateGroup(chat.id, { members: newMembers, admins: newAdmins });
      playAppSound('click');
      onToast('تمت إزالة العضو من المجموعة');
    } catch {
      onToast('تعذر إزالة العضو');
    } finally {
      setIsProcessing(false);
    }
  };

  // Toggle admin
  const handleToggleAdmin = async (targetId: string) => {
    if (!isOwner) {
      onToast('تعيين المشرفين مقتصر على مالك المجموعة فقط 👑');
      return;
    }
    setIsProcessing(true);
    try {
      let newAdmins = [...admins];
      if (admins.includes(targetId)) {
        newAdmins = newAdmins.filter((id) => id !== targetId);
        onToast('تم تنزيل رتبة المشرف إلى عضو عادي');
      } else {
        newAdmins.push(targetId);
        onToast('تمت ترقية العضو إلى مشرف في المجموعة 🛡️');
      }
      await onUpdateGroup(chat.id, { admins: newAdmins });
      playAppSound('click');
    } catch {
      onToast('حدث خطأ في تعديل الرتبة');
    } finally {
      setIsProcessing(false);
    }
  };

  // Filter candidates to add
  const availableUsers = Object.values(allUsersMap).filter((u) => {
    if (members.includes(u.id)) return false;
    if (!searchAddQuery.trim()) return true;
    const q = searchAddQuery.toLowerCase().trim();
    return (
      u.name.toLowerCase().includes(q) ||
      u.username.toLowerCase().includes(q) ||
      u.id.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-[99999] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-md glass-panel-heavy rounded-2xl border border-white/10 p-5 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center pb-3 border-b border-white/10 mb-3">
          <div>
            <h3 className="font-extrabold text-base text-[#25d366] flex items-center gap-1.5">
              <span>👥</span> {chat.groupName || 'المجموعة الملكية'}
            </h3>
            <p className="text-[11px] text-gray-400 mt-0.5">
              إدارة الأعضاء والصلاحيات ({members.length} عضو)
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-3 bg-black/40 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('list')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'list'
                ? 'bg-[#00a884] text-white shadow'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            قائمة الأعضاء ({members.length})
          </button>
          {isAdmin && (
            <button
              onClick={() => setActiveTab('add')}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 ${
                activeTab === 'add'
                  ? 'bg-[#00a884] text-white shadow'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>إضافة عضو جديد</span>
            </button>
          )}
        </div>

        {/* Tab 1: Member list */}
        {activeTab === 'list' && (
          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {members.map((mId) => {
              const userObj = allUsersMap[mId] || {
                id: mId,
                name: mId === currentUser.id ? currentUser.name : `عضو (${mId})`,
                username: 'user',
                vipLevel: 0,
                pass: '',
                points: 0
              };
              const isTargetOwner = mId === ownerId;
              const isTargetAdmin = admins.includes(mId);

              return (
                <div
                  key={mId}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-white/5 border border-white/5 hover:border-white/10"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-full bg-[#1f2c34] flex items-center justify-center font-bold text-white text-xs shrink-0 overflow-hidden border border-white/10">
                      {userObj.avatar ? (
                        <img src={userObj.avatar} alt="" className="w-full h-full object-cover" />
                      ) : (
                        (userObj.name[0] || 'A').toUpperCase()
                      )}
                    </div>
                    <div className="min-w-0">
                      <VipName
                        name={userObj.name}
                        vipLevel={userObj.vipLevel}
                        isFounder={userObj.id === 'ASEF-777777'}
                        className="text-xs"
                      />
                      <div className="flex items-center gap-2 text-[10px] text-gray-400 mt-0.5">
                        <span>{userObj.id}</span>
                        {isTargetOwner && (
                          <span className="text-[#ffd700] font-bold flex items-center gap-0.5">
                            <Crown className="w-3 h-3" /> مالك
                          </span>
                        )}
                        {isTargetAdmin && !isTargetOwner && (
                          <span className="text-[#25d366] font-bold flex items-center gap-0.5">
                            <Shield className="w-3 h-3" /> مشرف
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions if caller is admin/owner and not modifying self */}
                  {mId !== currentUser.id && (
                    <div className="flex items-center gap-1 shrink-0">
                      {isOwner && (
                        <button
                          onClick={() => handleToggleAdmin(mId)}
                          disabled={isProcessing}
                          title={isTargetAdmin ? 'إلغاء الإشراف' : 'ترقية لمشرف'}
                          className={`p-1.5 rounded-lg text-xs ${
                            isTargetAdmin
                              ? 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30'
                              : 'bg-white/10 text-gray-300 hover:bg-white/20'
                          }`}
                        >
                          <Shield className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {isAdmin && (!isTargetOwner || isOwner) && (
                        <button
                          onClick={() => handleRemoveMember(mId)}
                          disabled={isProcessing}
                          title="طرد العضو من المجموعة"
                          className="p-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-400 text-xs"
                        >
                          <UserMinus className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Tab 2: Add member */}
        {activeTab === 'add' && (
          <div className="flex-1 overflow-y-auto flex flex-col pr-1">
            <input
              type="text"
              placeholder="ابحث بالاسم أو اسم المستخدم أو المعرّف..."
              value={searchAddQuery}
              onChange={(e) => setSearchAddQuery(e.target.value)}
              className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white mb-2.5 outline-none focus:border-[#25d366]"
            />

            <div className="flex-1 overflow-y-auto space-y-2">
              {availableUsers.length === 0 ? (
                <div className="text-center py-6 text-gray-400 text-xs">
                  لا يوجد مستخدمون مطابقون للإضافة
                </div>
              ) : (
                availableUsers.map((u) => (
                  <div
                    key={u.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-white/5 border border-white/5"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-[#1f2c34] flex items-center justify-center font-bold text-white text-xs shrink-0 overflow-hidden">
                        {u.avatar ? (
                          <img src={u.avatar} alt="" className="w-full h-full object-cover" />
                        ) : (
                          (u.name[0] || 'A').toUpperCase()
                        )}
                      </div>
                      <div className="min-w-0">
                        <VipName name={u.name} vipLevel={u.vipLevel} className="text-xs" />
                        <div className="text-[10px] text-gray-400">@{u.username} • {u.id}</div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleAddMember(u.id)}
                      disabled={isProcessing}
                      className="px-3 py-1.5 rounded-xl bg-[#25d366] hover:bg-[#20ba59] text-black font-extrabold text-xs transition flex items-center gap-1"
                    >
                      <UserPlus className="w-3 h-3" />
                      <span>إضافة</span>
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Close button */}
        <button
          onClick={onClose}
          className="w-full mt-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 font-bold text-xs transition"
        >
          إغلاق
        </button>
      </div>
    </div>
  );
};
