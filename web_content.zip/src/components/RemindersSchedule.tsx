import React, { useState } from 'react';
import { 
  AlarmClock, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Trash2, 
  Clock, 
  Calendar,
  Check
} from 'lucide-react';
import { ReminderItem, SupportedLanguage } from '../types/assistant';

interface RemindersScheduleProps {
  reminders: ReminderItem[];
  language: SupportedLanguage;
  onAddReminder: (text: string, targetTime?: string) => void;
  onToggleReminder: (id: string) => void;
  onDeleteReminder: (id: string) => void;
}

export const RemindersSchedule: React.FC<RemindersScheduleProps> = ({
  reminders,
  language,
  onAddReminder,
  onToggleReminder,
  onDeleteReminder,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [taskText, setTaskText] = useState('');
  const [targetTime, setTargetTime] = useState('');

  const completedCount = reminders.filter((r) => r.isCompleted).length;
  const pendingCount = reminders.length - completedCount;

  const handleSaveReminder = () => {
    if (!taskText.trim()) return;
    onAddReminder(taskText.trim(), targetTime.trim() || undefined);
    setTaskText('');
    setTargetTime('');
    setShowAddModal(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-[#0d1629] to-[#1e1526] border border-amber-500/30 p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-950/80 border border-amber-500/40 text-amber-300 text-xs font-mono-tech mb-1">
            <AlarmClock className="w-3.5 h-3.5 text-amber-400" />
            <span>JARVIS TIME TRACKER</span>
          </div>
          <h2 className="text-2xl font-orbitron font-extrabold tracking-wide text-white">
            REMINDERS & SCHEDULE
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm">
            {pendingCount} Pending · {completedCount} Completed
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-orbitron font-bold text-xs tracking-wider transition-all flex items-center gap-2 shadow-lg shadow-amber-500/20 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>NEW REMINDER</span>
        </button>
      </div>

      {/* Reminders List */}
      {reminders.length === 0 ? (
        <div className="rounded-3xl bg-slate-950/80 border border-slate-800 p-12 text-center space-y-3">
          <Clock className="w-12 h-12 text-slate-600 mx-auto" />
          <p className="text-slate-300 font-semibold text-sm">No scheduled tasks or reminders, Boss.</p>
          <p className="text-slate-500 text-xs max-w-xs mx-auto">
            Add a reminder now or command Rubel Boss AI via voice.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {reminders.map((item) => (
            <div
              key={item.id}
              className={`rounded-2xl border p-4 transition-all flex items-center justify-between gap-4 ${
                item.isCompleted
                  ? 'bg-slate-950/50 border-slate-800/80 opacity-60'
                  : 'bg-[#0a1122]/90 border-cyan-900/50 hover:border-amber-500/40 shadow-md'
              }`}
            >
              <div
                onClick={() => onToggleReminder(item.id)}
                className="flex items-center gap-3.5 flex-1 cursor-pointer"
              >
                <button
                  type="button"
                  className="text-amber-400 hover:scale-110 transition-transform shrink-0"
                >
                  {item.isCompleted ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Circle className="w-5 h-5 text-amber-400" />
                  )}
                </button>

                <div className="space-y-0.5">
                  <p
                    className={`text-sm font-semibold transition-all ${
                      item.isCompleted
                        ? 'line-through text-slate-500'
                        : 'text-slate-100'
                    }`}
                  >
                    {item.text}
                  </p>
                  {item.targetTime && (
                    <div className="flex items-center gap-1.5 text-xs text-amber-400/90 font-mono-tech">
                      <Clock className="w-3 h-3" />
                      <span>{item.targetTime}</span>
                    </div>
                  )}
                </div>
              </div>

              <button
                onClick={() => onDeleteReminder(item.id)}
                title="Delete"
                className="p-2 rounded-xl text-slate-500 hover:text-red-400 hover:bg-red-950/40 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Add Reminder Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#090f1f] border border-amber-500/50 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-amber-900/40 pb-3">
              <h3 className="font-orbitron font-bold text-sm text-amber-300 tracking-wide">
                SET NEW REMINDER
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-xs font-mono-tech"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-mono-tech text-slate-400">Task / Directives *</label>
                <input
                  type="text"
                  value={taskText}
                  onChange={(e) => setTaskText(e.target.value)}
                  placeholder="e.g. Server maintenance & backup check"
                  className="w-full mt-1 bg-slate-950 text-slate-100 text-sm px-3.5 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="text-xs font-mono-tech text-slate-400">Target Time / Deadline (Optional)</label>
                <input
                  type="text"
                  value={targetTime}
                  onChange={(e) => setTargetTime(e.target.value)}
                  placeholder="e.g. Today at 6:30 PM, or Tomorrow morning"
                  className="w-full mt-1 bg-slate-950 text-slate-100 text-sm px-3.5 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-mono-tech text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveReminder}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs tracking-wider font-orbitron shadow-md shadow-amber-500/30"
              >
                SET REMINDER
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
