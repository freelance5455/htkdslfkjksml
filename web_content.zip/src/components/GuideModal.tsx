import React from 'react';
import { X, Play, Sparkles, Compass, Trash2, CheckCircle2 } from 'lucide-react';

interface GuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPrompt: (prompt: string) => void;
}

export const GuideModal: React.FC<GuideModalProps> = ({
  isOpen,
  onClose,
  onSelectPrompt,
}) => {
  if (!isOpen) return null;

  const testSteps = [
    {
      step: '1',
      title: 'Ujian Loghat Utara (Ciri Istimewa)',
      desc: 'Uji kebolehan HANN AI memahami dan membalas dalam loghat utara tulen.',
      prompt: 'Hang sapa sebenarnya? Awat sempoi sangat loghat hang?',
      badge: 'Loghat Utara',
    },
    {
      step: '2',
      title: 'Ujian Cadangan Makanan & Budaya',
      desc: 'Tanya pasal tempat makan sedap atau masakan popular utara.',
      prompt: 'Habaq mai sat mana port nasi kandar paling padu kat Penang atau Kedah!',
      badge: 'Makanan & Travel',
    },
    {
      step: '3',
      title: 'Ujian Bahasa Melayu Santai',
      desc: 'Berbual santai tentang tips kehidupan atau nasihat harian.',
      prompt: 'Bagi tips macam mana nak elak rasa mengantuk waktu buat kerja petang-petang.',
      badge: 'Santai Harian',
    },
    {
      step: '4',
      title: 'Ujian Kepintaran & Fakta Ilmiah',
      desc: 'Buktikan HANN AI bersambung kepada AI sebenar (Gemini) dan mampu menjawab isu teknikal.',
      prompt: 'Awat langit warna biru waktu siang tapi jadi merah oren waktu senja? Terangkan secara ringkas.',
      badge: 'Sains & Fakta',
    },
    {
      step: '5',
      title: 'Ujian Padam Chat & Ruang Menaip',
      desc: 'Taip soalan sendiri di bahagian bawah, tekan butang Hantar, dan cuba butang Padam Chat (ikon tong sampah) di bahagian atas.',
      prompt: 'Bagi resepi laksa Kedah yang kuah pekat dan sedap berlemun.',
      badge: 'Fitur Sistem',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div 
        className="relative w-full max-w-xl max-h-[90vh] overflow-hidden rounded-2xl bg-[#110726] border border-purple-500/40 shadow-[0_0_50px_rgba(168,85,247,0.3)] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-purple-900/40 bg-purple-950/30">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-600 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-purple-600/30">
              <Compass className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white tracking-wide">Arahan Menguji HANN AI</h3>
              <p className="text-xs text-purple-300">Panduan langkah demi langkah untuk menguji chatbot</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-purple-900/30 transition-colors"
            title="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-slate-200">
          <div className="p-3.5 rounded-xl bg-purple-900/20 border border-purple-500/20 text-xs text-purple-200 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
            <p>
              HANN AI disambungkan secara terus ke model <strong>Gemini 3.8 Flash</strong> di bahagian server.
              Klik butang <strong>"Cuba Soalan Ni"</strong> di bawah untuk memasukkan soalan ujian serta-merta ke dalam chat!
            </p>
          </div>

          <div className="space-y-3">
            {testSteps.map((item) => (
              <div
                key={item.step}
                className="p-4 rounded-xl bg-[#180a33]/90 border border-purple-900/50 hover:border-purple-500/40 transition-all flex flex-col gap-2.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-purple-600/40 text-purple-200 text-xs font-bold flex items-center justify-center border border-purple-500/40">
                      {item.step}
                    </span>
                    <h4 className="font-semibold text-sm text-purple-100">{item.title}</h4>
                  </div>
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-purple-900/50 text-purple-300 border border-purple-700/30">
                    {item.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-300 pl-8">{item.desc}</p>
                
                <div className="ml-8 mt-1 p-2.5 rounded-lg bg-black/40 border border-purple-900/60 flex items-center justify-between gap-3">
                  <span className="text-xs text-purple-200 italic font-mono truncate">
                    "{item.prompt}"
                  </span>
                  <button
                    onClick={() => {
                      onSelectPrompt(item.prompt);
                      onClose();
                    }}
                    className="shrink-0 flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-lg bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white shadow-md shadow-purple-900/40 transition-all"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Cuba Sekarang</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/40 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <Trash2 className="w-4 h-4 text-purple-400" />
              <span>Nak mula semula dari awal? Tekan butang Padam Chat di bar atas.</span>
            </div>
            <div className="flex items-center gap-1 text-green-400 text-[11px] font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Server Selamat</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-purple-900/40 bg-[#0c041c] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-purple-900/40 hover:bg-purple-800/50 text-xs font-semibold text-purple-200 border border-purple-700/40 transition-colors"
          >
            Faham & Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
