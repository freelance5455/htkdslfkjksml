import React, { useState, useEffect } from 'react';
import { MarketplaceItem } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api, ANGOLA_PROVINCES } from '../../services/api';
import {
  ShoppingBag, Plus, Search, MapPin, Tag,
  Phone, MessageSquare, CheckCircle, Trash2, Filter
} from 'lucide-react';
import { CreateListingModal } from './CreateListingModal';

interface MarketplaceViewProps {
  onStartChatWithSeller: (sellerId: string) => void;
}

const CATEGORIES = [
  'Todas',
  'Moda & Beleza',
  'Telefones & Tecnologia',
  'Veículos',
  'Imóveis',
  'Casa & Móveis',
  'Serviços',
  'Emprego'
];

export const MarketplaceView: React.FC<MarketplaceViewProps> = ({ onStartChatWithSeller }) => {
  const { currentUser } = useAuth();
  const [items, setItems] = useState<MarketplaceItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('Todas');
  const [selectedProvince, setSelectedProvince] = useState('Todas');
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const loadItems = async () => {
    try {
      setIsLoading(true);
      const res = await api.getMarketplace({
        category: selectedCategory !== 'Todas' ? selectedCategory : undefined,
        province: selectedProvince !== 'Todas' ? selectedProvince : undefined,
        q: searchQuery || undefined
      });
      setItems(res.items || []);
    } catch (err) {
      console.error('Erro ao carregar artigos:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadItems();
  }, [selectedCategory, selectedProvince, searchQuery]);

  const handleToggleSold = async (item: MarketplaceItem) => {
    if (!currentUser) return;
    try {
      await api.toggleMarketplaceSold(item.id, currentUser.id);
      loadItems();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    if (!currentUser) return;
    if (!window.confirm('Tem a certeza de que deseja eliminar este anúncio?')) return;
    try {
      await api.deleteMarketplaceItem(itemId, currentUser.id, currentUser.isAdmin);
      loadItems();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white font-display flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-emerald-400" />
            <span>Mercado Angola — Compra & Venda</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Transações locais em Kwanzas (AOA) e USD entre angolanos e compradores de todo o mundo.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Publicar Anúncio</span>
        </button>
      </div>

      {/* Categories Bar */}
      <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1 scrollbar-none">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-full whitespace-nowrap shrink-0 transition-colors ${
              selectedCategory === cat
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Search & Province Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Pesquisar artigos no marketplace..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300">
          <MapPin className="w-4 h-4 text-amber-500 shrink-0" />
          <select
            value={selectedProvince}
            onChange={(e) => setSelectedProvince(e.target.value)}
            className="bg-transparent text-xs text-white focus:outline-none"
          >
            {ANGOLA_PROVINCES.map((p) => (
              <option key={p} value={p} className="bg-slate-900 text-white">
                {p === 'Todas' ? 'Todas as Províncias' : p}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Grid of Listings */}
      {isLoading ? (
        <div className="p-12 text-center text-slate-500 text-xs">A carregar artigos do marketplace...</div>
      ) : items.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
          <ShoppingBag className="w-8 h-8 text-emerald-400/60 mx-auto mb-2" />
          <p className="text-sm font-semibold text-white">Nenhum artigo encontrado</p>
          <p className="text-xs text-slate-500 mt-1">Seja o primeiro a publicar nesta categoria!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {items.map((item) => {
            const isSeller = currentUser?.id === item.sellerId;
            const seller = item.seller;

            return (
              <div
                key={item.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl overflow-hidden shadow-sm flex flex-col group transition-all"
              >
                {/* Image */}
                <div className="relative aspect-4/3 w-full bg-slate-950 overflow-hidden">
                  <img
                    src={item.images[0] || '/src/assets/images/angola_samakaka_fashion_1793388060870.jpg'}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {item.sold && (
                    <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center">
                      <span className="px-3 py-1 bg-red-600 text-white font-bold text-xs uppercase tracking-wider rounded-lg">
                        Vendido
                      </span>
                    </div>
                  )}
                  <span className="absolute top-2.5 right-2.5 px-2.5 py-1 bg-slate-950/80 backdrop-blur-md border border-white/10 rounded-lg text-[10px] font-semibold text-emerald-400">
                    {item.condition}
                  </span>
                </div>

                {/* Content */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-baseline justify-between gap-2 mb-1">
                      <span className="text-base font-extrabold text-amber-400 font-display tabular-nums">
                        {item.price.toLocaleString('pt-AO')} {item.currency}
                      </span>
                      <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
                        <MapPin className="w-3 h-3 text-amber-500" />
                        {item.province}
                      </span>
                    </div>

                    <h3 className="font-bold text-sm text-white line-clamp-1 group-hover:text-amber-400 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  {/* Seller & Action */}
                  <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <div className="flex items-center gap-1.5 truncate">
                        <img
                          src={seller?.avatar || '/src/assets/images/angola_user_maria_1793388059496.jpg'}
                          className="w-5 h-5 rounded-full object-cover"
                        />
                        <span className="truncate">{seller?.name || 'Vendedor'}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {new Date(item.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    {isSeller ? (
                      <div className="flex items-center gap-1.5 pt-1">
                        <button
                          onClick={() => handleToggleSold(item)}
                          className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold rounded-lg text-slate-200 transition-colors"
                        >
                          {item.sold ? 'Marcar Disponível' : 'Marcar como Vendido'}
                        </button>
                        <button
                          onClick={() => handleDeleteItem(item.id)}
                          className="p-1.5 bg-red-950/40 text-red-400 hover:bg-red-900/60 rounded-lg transition-colors"
                          title="Eliminar"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => onStartChatWithSeller(item.sellerId)}
                        className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Falar no Chat</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal */}
      <CreateListingModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onCreated={loadItems}
      />

    </div>
  );
};
