import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api, ANGOLA_PROVINCES } from '../../services/api';
import { X, Image as ImageIcon, RefreshCw, ShoppingBag } from 'lucide-react';

interface CreateListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: () => void;
}

const CATEGORIES = [
  'Moda & Beleza',
  'Telefones & Tecnologia',
  'Veículos',
  'Imóveis',
  'Casa & Móveis',
  'Serviços',
  'Emprego'
];

export const CreateListingModal: React.FC<CreateListingModalProps> = ({
  isOpen,
  onClose,
  onCreated
}) => {
  const { currentUser } = useAuth();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [currency, setCurrency] = useState<'AOA' | 'USD'>('AOA');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [province, setProvince] = useState(currentUser?.province || 'Luanda');
  const [condition, setCondition] = useState<'Novo' | 'Usado como novo' | 'Bom estado'>('Novo');
  const [contactPhone, setContactPhone] = useState(currentUser?.phone || '+244');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen || !currentUser) return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const uploadRes = await api.uploadFile(base64, file.name);
        setImageUrl(uploadRes.url);
      } catch (err: any) {
        setErrorMsg('Erro no envio da foto: ' + err.message);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!title.trim() || !price || isNaN(Number(price))) {
      setErrorMsg('Título e preço válido são necessários.');
      return;
    }

    try {
      setIsSubmitting(true);
      await api.createMarketplaceItem({
        sellerId: currentUser.id,
        title: title.trim(),
        description: description.trim(),
        price: Number(price),
        currency,
        category,
        province,
        condition,
        contactPhone,
        images: imageUrl ? [imageUrl] : ['/src/assets/images/angola_samakaka_fashion_1793388060870.jpg']
      });

      onCreated();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-slate-100 max-h-[90vh] overflow-y-auto animate-in zoom-in-95">

        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <h3 className="font-bold text-base text-white font-display flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-emerald-400" />
            <span>Publicar Anúncio no Mercado Angola</span>
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
          {errorMsg && (
            <p className="text-xs text-red-400 bg-red-950/40 p-2.5 rounded-xl border border-red-800/60">{errorMsg}</p>
          )}

          {/* Photo */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Foto do Artigo</label>
            {imageUrl ? (
              <div className="relative h-40 rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
                <img src={imageUrl} alt="Artigo" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => setImageUrl(null)}
                  className="absolute top-2 right-2 p-1 bg-black/70 hover:bg-black rounded text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-slate-700 hover:border-emerald-500 rounded-xl cursor-pointer bg-slate-950 p-4">
                <ImageIcon className="w-8 h-8 text-emerald-400 mb-1" />
                <span className="text-xs font-semibold text-slate-300">Carregar foto do produto</span>
                <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              </label>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Título do Artigo</label>
            <input
              type="text"
              placeholder="Ex: Fato Tradicional Samakaka / iPhone 15 Pro"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Preço</label>
              <input
                type="number"
                placeholder="45000"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Moeda</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="AOA">Kwanzas (AOA 🇦🇴)</option>
                <option value="USD">Dólares (USD $)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Categoria</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Província</label>
              <select
                value={province}
                onChange={(e) => setProvince(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                {ANGOLA_PROVINCES.filter(p => p !== 'Todas').map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Descrição Detalhada</label>
            <textarea
              rows={3}
              placeholder="Descreva o estado do produto, tamanho, garantia..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-emerald-500 resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Condição</label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="Novo">Novo</option>
                <option value="Usado como novo">Usado como novo</option>
                <option value="Bom estado">Bom estado</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Contacto Telefónico</label>
              <input
                type="text"
                placeholder="+244 923 000 000"
                value={contactPhone}
                onChange={(e) => setContactPhone(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full h-11 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all active:scale-[0.98] disabled:opacity-50 mt-2"
          >
            {isSubmitting ? (
              <RefreshCw className="w-4 h-4 animate-spin text-white" />
            ) : (
              <span>Publicar Artigo no Mercado</span>
            )}
          </button>
        </form>

      </div>
    </div>
  );
};
