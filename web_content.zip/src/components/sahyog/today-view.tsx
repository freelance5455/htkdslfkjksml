import { Plus } from "@/components/sahyog/icons";
import { useState } from "react";
import { TaskDialog } from "@/components/sahyog/dialogs";
import { useHouseReady } from "@/components/sahyog/ready";
import { groupTasks, PageHead, PersonFace, StatusButton, TaskRow } from "@/components/sahyog/ui";
import {
  greeting,
  householdPay,
  inr,
  isDone,
  isoDate,
  leadCopy,
  longDate,
  monthKey,
  roleLabel,
  tasksOn,
} from "@/lib/sahyog/model";
import { useSahyog } from "@/lib/sahyog/store";

export function TodayView() {
  const ready = useHouseReady();
  if (!ready) return <PageHead title="Today" lede="Opening the house…" />;
  return <TodayBody today={isoDate()} />;
}

function TodayBody({ today }: { today: string }) {
  const people = useSahyog((s) => s.people);
  const tasks = useSahyog((s) => s.tasks);
  const attendance = useSahyog((s) => s.attendance);
  const payments = useSahyog((s) => s.payments);
  const welcomed = useSahyog((s) => s.welcomed);
  const dismiss = useSahyog((s) => s.dismissWelcome);
  const note = useSahyog((s) => s.notes[today] ?? "");
  const setNote = useSahyog((s) => s.setNote);
  const [addOpen, setAddOpen] = useState(false);

  const list = tasksOn(tasks, today);
  const done = list.filter((t) => isDone(t, today)).length;
  const inside = people.filter((p) => {
    const row = attendance.find((a) => a.personId === p.id && a.date === today);
    return row?.status === "present" || row?.status === "half";
  }).length;
  const pay = householdPay(people, payments, monthKey(today));
  const groups = groupTasks(list);

  return (
    <div>
      <PageHead
        eyebrow={longDate(today)}
        title={greeting()}
        lede={leadCopy(people, tasks, attendance, today)}
        action={
          <button type="button" className="btn btn-primary" onClick={() => setAddOpen(true)} disabled={people.length === 0}>
            <Plus className="size-4" aria-hidden="true" />
            Add work
          </button>
        }
      />

      {!welcomed ? (
        <p className="mb-4 text-sm text-muted">
          Sample household loaded. Change anything — it stays on this device.
          <button type="button" className="ml-2 font-semibold text-ink underline" onClick={dismiss}>
            Got it
          </button>
        </p>
      ) : null}

      <dl className="stats">
        <div className="stat">
          <dt>In today</dt>
          <dd>
            {inside}
            <span className="text-muted">/{people.length}</span>
          </dd>
        </div>
        <div className="stat">
          <dt>Still to do</dt>
          <dd>{Math.max(0, list.length - done)}</dd>
        </div>
        <div className="stat">
          <dt>Left to give</dt>
          <dd className="truncate">{inr(pay.due)}</dd>
        </div>
      </dl>

      <section className="mt-8">
        <h2 className="font-display text-2xl">Who is in</h2>
        {people.length === 0 ? (
          <p className="mt-2 text-muted">No one yet. Add them under People.</p>
        ) : (
          <ul className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {people.map((person) => (
              <li key={person.id} className="card p-3">
                <div className="flex items-center gap-2">
                  <PersonFace name={person.name} />
                  <div className="min-w-0">
                    <p className="truncate font-medium">{person.name}</p>
                    <p className="truncate text-sm text-muted">{roleLabel(person.role)}</p>
                  </div>
                </div>
                <p className="mt-2 truncate text-sm text-muted">{person.shift || "Shift not set"}</p>
                <div className="mt-3">
                  <StatusButton personId={person.id} today={today} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="mt-8">
        <div className="mb-3 flex items-baseline justify-between gap-3">
          <h2 className="font-display text-2xl">Today’s work</h2>
          <p className="text-sm text-muted tabular-nums">
            {done} of {list.length} done
          </p>
        </div>
        {groups.length === 0 ? (
          <div className="card p-5 text-muted">Nothing on the list. Add the first job for the house.</div>
        ) : (
          <div className="flex flex-col gap-4">
            {groups.map((group) => (
              <section key={group.part}>
                <h3 className="mb-1 text-sm font-medium text-muted">{group.part}</h3>
                <div className="card px-4">
                  {group.items.map((task) => (
                    <TaskRow key={task.id} task={task} today={today} />
                  ))}
                </div>
              </section>
            ))}
          </div>
        )}
      </section>

      <section className="mt-8">
        <h2 className="font-display text-2xl">Note for the house</h2>
        <p className="mt-1 mb-3 text-sm text-muted">Guests, allergies, anything the help should know today.</p>
        <textarea
          className="note"
          value={note}
          maxLength={500}
          onChange={(e) => setNote(today, e.target.value)}
          aria-label="Note for the house today"
        />
      </section>

      <TaskDialog open={addOpen} onOpenChange={setAddOpen} presetKind="once" />
    </div>
  );
}
