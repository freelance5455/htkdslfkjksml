import type { ComponentType, SVGProps } from "react";

export type LucideIcon = ComponentType<SVGProps<SVGSVGElement> & { size?: number | string; strokeWidth?: number | string }>;

export { default as Baby } from "lucide-react/dist/esm/icons/baby";
export { default as Bath } from "lucide-react/dist/esm/icons/bath";
export { default as BedDouble } from "lucide-react/dist/esm/icons/bed-double";
export { default as Check } from "lucide-react/dist/esm/icons/check";
export { default as Clock } from "lucide-react/dist/esm/icons/clock";
export { default as Flower2 } from "lucide-react/dist/esm/icons/flower-2";
export { default as House } from "lucide-react/dist/esm/icons/house";
export { default as ListChecks } from "lucide-react/dist/esm/icons/list-checks";
export { default as Pencil } from "lucide-react/dist/esm/icons/pencil";
export { default as Phone } from "lucide-react/dist/esm/icons/phone";
export { default as Plus } from "lucide-react/dist/esm/icons/plus";
export { default as Shirt } from "lucide-react/dist/esm/icons/shirt";
export { default as ShoppingBag } from "lucide-react/dist/esm/icons/shopping-bag";
export { default as Sofa } from "lucide-react/dist/esm/icons/sofa";
export { default as Trash2 } from "lucide-react/dist/esm/icons/trash-2";
export { default as Users } from "lucide-react/dist/esm/icons/users";
export { default as UtensilsCrossed } from "lucide-react/dist/esm/icons/utensils-crossed";
export { default as Wallet } from "lucide-react/dist/esm/icons/wallet";
export { default as X } from "lucide-react/dist/esm/icons/x";
