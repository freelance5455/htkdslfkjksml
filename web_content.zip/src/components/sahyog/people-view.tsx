import { Link } from "@tanstack/react-router";
import { Clock, Pencil, Phone, Plus } from "@/components/sahyog/icons";
import { useState } from "react";
import { PersonDialog } from "@/components/sahyog/dialogs";
import { useHouseReady } from "@/components/sahyog/ready";
import { PageHead, PersonFace, StatusButton, WeekDots } from "@/components/sahyog/ui";
import { formatDays, formatPhone, inr, isoDate, roleLabel, telHref, type Person } from "@/lib/sahyog/model";
import { useSahyog } from "@/lib/sahyog/store";

export function PeopleView() {
  const ready = useHouseReady();
  if (!ready) return <PageHead title="People" lede="Opening the household…" />;
  return <PeopleBody today={isoDate()} />;
}

function PeopleBody({ today }: { today: string }) {
  const people = useSahyog((s) => s.people);
  const resetSample = useSahyog((s) => s.resetSample);
  const [editing, setEditing] = useState<Person | null>(null);
  const [open, setOpen] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  return (
    <div>
      <PageHead
        eyebrow="Household"
        title="People"
        lede="Cooks, housekeeping, childcare, drivers — whoever keeps the house going."
        action={
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus className="size-4" aria-hidden="true" />
            Add person
          </button>
        }
      />

      {people.length === 0 ? (
        <div className="card p-6">
          <p>No one is on the household yet.</p>
          <button
            type="button"
            className="btn btn-primary mt-4"
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            Add the first person
          </button>
        </div>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2">
          {people.map((person) => {
            const tel = telHref(person.phone);
            return (
              <li key={person.id} className="card p-4">
                <div className="flex items-start gap-3">
                  <PersonFace name={person.name} />
                  <div className="min-w-0 flex-1">
                    <h2 className="font-display text-3xl leading-none">{person.name}</h2>
                    <p className="mt-1 text-sm text-muted">{roleLabel(person.role)}</p>
                  </div>
                  <button
                    type="button"
                    className="icon-btn"
                    aria-label={`Edit ${person.name}`}
                    onClick={() => {
                      setEditing(person);
                      setOpen(true);
                    }}
                  >
                    <Pencil className="size-4" />
                  </button>
                </div>
                <div className="mt-4 flex flex-col gap-1.5 text-sm">
                  {tel ? (
                    <a className="phone-link inline-flex items-center gap-2" href={`tel:${tel}`}>
                      <Phone className="size-4" aria-hidden="true" />
                      {formatPhone(person.phone)}
                    </a>
                  ) : (
                    <p className="text-muted">No phone saved</p>
                  )}
                  <p className="flex items-center gap-2 text-muted">
                    <Clock className="size-4 shrink-0" aria-hidden="true" />
                    <span>{person.shift || "Shift not set"}</span>
                  </p>
                </div>
                <div className="mt-4 flex items-end justify-between gap-3">
                  <div>
                    <p className="text-sm text-muted">{formatDays(person.days)}</p>
                    <p className="font-medium tabular-nums">{inr(person.salary)} / month</p>
                  </div>
                  <WeekDots personId={person.id} today={today} />
                </div>
                {person.note ? <p className="mt-3 text-sm text-muted">{person.note}</p> : null}
                <div className="mt-4">
                  <StatusButton personId={person.id} today={today} />
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <div className="mt-8">
        {confirmReset ? (
          <div className="card p-4">
            <p>Replace people, work, attendance, and pay with the sample household?</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => {
                  resetSample();
                  setConfirmReset(false);
                }}
              >
                Restore sample
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setConfirmReset(false)}>
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <button type="button" className="text-sm font-medium text-muted underline" onClick={() => setConfirmReset(true)}>
            Restore sample household
          </button>
        )}
        <p className="mt-3 text-sm text-muted">
          Pay for the month lives on <Link to="/pay" className="font-semibold text-ink underline">Pay</Link>.
        </p>
      </div>

      <PersonDialog
        open={open}
        person={editing}
        onOpenChange={(next) => {
          setOpen(next);
          if (!next) setEditing(null);
        }}
      />
    </div>
  );
}
