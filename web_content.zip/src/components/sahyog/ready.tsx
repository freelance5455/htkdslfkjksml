import { createContext, useContext } from "react";

export const HouseReadyContext = createContext(false);

export function useHouseReady(): boolean {
  return useContext(HouseReadyContext);
}
