import { Link } from "@tanstack/react-router";
import { Plus } from "@/components/sahyog/icons";
import { useState } from "react";
import { TaskDialog } from "@/components/sahyog/dialogs";
import { useHouseReady } from "@/components/sahyog/ready";
import { PageHead, TaskRow } from "@/components/sahyog/ui";
import { AREAS, isoDate, tasksOn, type AreaId, type Task } from "@/lib/sahyog/model";
import { useSahyog } from "@/lib/sahyog/store";

export function WorkView() {
  const ready = useHouseReady();
  if (!ready) return <PageHead title="Work" lede="Opening the list…" />;
  return <WorkBody today={isoDate()} />;
}

function WorkBody({ today }: { today: string }) {
  const people = useSahyog((s) => s.people);
  const tasks = useSahyog((s) => s.tasks);
  const [personId, setPersonId] = useState("all");
  const [area, setArea] = useState<"all" | AreaId>("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);

  const list = tasksOn(tasks, today).filter((task) => {
    if (personId !== "all" && task.personId !== personId) return false;
    if (area !== "all" && task.area !== area) return false;
    return true;
  });

  return (
    <div>
      <PageHead
        eyebrow="Routines"
        title="Work"
        lede="Daily routines, plus anything that is only for today."
        action={
          <button
            type="button"
            className="btn btn-primary"
            disabled={people.length === 0}
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus className="size-4" aria-hidden="true" />
            Add work
          </button>
        }
      />

      {people.length === 0 ? (
        <div className="card p-6">
          <p>Add someone before you assign work.</p>
          <Link to="/people" className="btn btn-primary mt-4">
            Go to people
          </Link>
        </div>
      ) : (
        <>
          <div className="mb-4 flex flex-col gap-3">
            <div className="filters" aria-label="Filter by person">
              <button type="button" className="filter-chip" data-on={personId === "all" ? "true" : "false"} onClick={() => setPersonId("all")}>
                Everyone
              </button>
              {people.map((person) => (
                <button
                  key={person.id}
                  type="button"
                  className="filter-chip"
                  data-on={personId === person.id ? "true" : "false"}
                  onClick={() => setPersonId(person.id)}
                >
                  {person.name}
                </button>
              ))}
            </div>
            <label className="block max-w-xs">
              <span className="sr-only">Filter by area</span>
              <select className="field" value={area} onChange={(e) => setArea(e.target.value as "all" | AreaId)}>
                <option value="all">All areas</option>
                {AREAS.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
          </div>

          {list.length === 0 ? (
            <div className="card p-5 text-muted">Nothing matches this filter.</div>
          ) : (
            <div className="card px-4">
              {list.map((task) => (
                <TaskRow
                  key={task.id}
                  task={task}
                  today={today}
                  onEdit={() => {
                    setEditing(task);
                    setOpen(true);
                  }}
                />
              ))}
            </div>
          )}
        </>
      )}

      <TaskDialog
        open={open}
        task={editing}
        onOpenChange={(next) => {
          setOpen(next);
          if (!next) setEditing(null);
        }}
      />
    </div>
  );
}
