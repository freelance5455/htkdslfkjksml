import type { ReactNode } from "react";
import {
  Baby,
  Bath,
  BedDouble,
  Check,
  Flower2,
  Pencil,
  Shirt,
  ShoppingBag,
  Sofa,
  UtensilsCrossed,
  type LucideIcon,
} from "@/components/sahyog/icons";
import {
  areaLabel,
  attendanceView,
  dayPart,
  formatTime,
  initials,
  isDone,
  recentDates,
  shortDate,
  type AreaId,
  type DayPart,
  type Task,
} from "@/lib/sahyog/model";
import { useSahyog } from "@/lib/sahyog/store";

const AREA_ICON: Record<AreaId, LucideIcon> = {
  kitchen: UtensilsCrossed,
  living: Sofa,
  bedrooms: BedDouble,
  bathrooms: Bath,
  laundry: Shirt,
  outdoor: Flower2,
  errand: ShoppingBag,
  childcare: Baby,
};

export function Mark({ className = "mark" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <rect width="32" height="32" rx="9" fill="currentColor" className="text-primary" />
      <path
        d="M8.5 17.8 16 10.2l7.5 7.6"
        fill="none"
        stroke="var(--color-primary-ink)"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12 17.2V23h8v-5.8"
        fill="none"
        stroke="var(--color-primary-ink)"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function PageHead({
  eyebrow,
  title,
  lede,
  action,
}: {
  eyebrow?: string;
  title: string;
  lede?: string;
  action?: ReactNode;
}) {
  return (
    <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        {eyebrow ? <p className="text-sm text-muted">{eyebrow}</p> : null}
        <h1 className="font-display text-4xl leading-none text-ink md:text-5xl">{title}</h1>
        {lede ? <p className="mt-2 max-w-xl text-muted">{lede}</p> : null}
      </div>
      {action}
    </header>
  );
}

export function StatusButton({ personId, today }: { personId: string; today: string }) {
  const person = useSahyog((s) => s.people.find((p) => p.id === personId));
  const attendance = useSahyog((s) => s.attendance);
  const cycle = useSahyog((s) => s.cycleAttendance);
  if (!person) return null;
  const view = attendanceView(person, today, attendance);
  return (
    <button
      type="button"
      className="status"
      data-status={view.key}
      onClick={() => cycle(personId, today)}
      aria-label={`${person.name}: ${view.label}. Tap to change.`}
    >
      {view.action}
    </button>
  );
}

export function WeekDots({ personId, today }: { personId: string; today: string }) {
  const person = useSahyog((s) => s.people.find((p) => p.id === personId));
  const attendance = useSahyog((s) => s.attendance);
  if (!person) return null;
  const days = recentDates(today, 7);
  return (
    <div className="flex items-center gap-1.5" aria-label="Last 7 days">
      {days.map((date) => {
        const view = attendanceView(person, date, attendance);
        return (
          <span
            key={date}
            className="dot"
            data-status={view.key}
            title={`${shortDate(date)}: ${view.label}`}
          >
            <span className="sr-only">
              {shortDate(date)} {view.label}
            </span>
          </span>
        );
      })}
    </div>
  );
}

export function TaskRow({
  task,
  today,
  onEdit,
}: {
  task: Task;
  today: string;
  onEdit?: () => void;
}) {
  const person = useSahyog((s) => s.people.find((p) => p.id === task.personId));
  const toggle = useSahyog((s) => s.toggleTask);
  const done = isDone(task, today);
  const Icon = AREA_ICON[task.area];
  return (
    <div className="task-row">
      <button
        type="button"
        className="check"
        data-on={done ? "true" : "false"}
        aria-pressed={done}
        aria-label={done ? `Mark not done: ${task.title}` : `Mark done: ${task.title}`}
        onClick={() => toggle(task.id, today)}
      >
        {done ? <Check className="size-4" strokeWidth={2.6} /> : null}
      </button>
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline justify-between gap-3">
          <p className={done ? "text-muted line-through" : "font-medium text-ink"}>{task.title}</p>
          <p className="shrink-0 text-sm text-muted tabular-nums">{task.time ? formatTime(task.time) : ""}</p>
        </div>
        <p className="mt-0.5 flex items-center gap-1.5 text-sm text-muted">
          <Icon className="size-3.5 shrink-0" aria-hidden="true" />
          <span className="truncate">
            {person?.name ?? "Unassigned"}
            {" · "}
            {areaLabel(task.area)}
            {task.kind === "once" ? " · Just today" : ""}
          </span>
        </p>
      </div>
      {onEdit ? (
        <button type="button" className="icon-btn" aria-label={`Edit ${task.title}`} onClick={onEdit}>
          <Pencil className="size-4" />
        </button>
      ) : null}
    </div>
  );
}

export function groupTasks(tasks: Task[]): { part: DayPart; items: Task[] }[] {
  const order: DayPart[] = ["Morning", "Afternoon", "Evening", "Anytime"];
  return order
    .map((part) => ({ part, items: tasks.filter((t) => dayPart(t.time) === part) }))
    .filter((group) => group.items.length > 0);
}

export function PersonFace({ name }: { name: string }) {
  return (
    <span className="avatar" aria-hidden="true">
      {initials(name)}
    </span>
  );
}
