import { Link } from "@tanstack/react-router";
import { Plus, Trash2 } from "@/components/sahyog/icons";
import { useState } from "react";
import { PayDialog } from "@/components/sahyog/dialogs";
import { useHouseReady } from "@/components/sahyog/ready";
import { PageHead } from "@/components/sahyog/ui";
import {
  breakdown,
  displayName,
  householdPay,
  inr,
  isoDate,
  monthKey,
  monthLabel,
  payProgress,
  PAY_KINDS,
  roleLabel,
  shortDate,
} from "@/lib/sahyog/model";
import { useSahyog } from "@/lib/sahyog/store";

export function PayView() {
  const ready = useHouseReady();
  if (!ready) return <PageHead title="Pay" lede="Opening the month…" />;
  return <PayBody today={isoDate()} />;
}

function PayBody({ today }: { today: string }) {
  const people = useSahyog((s) => s.people);
  const payments = useSahyog((s) => s.payments);
  const addPayment = useSahyog((s) => s.addPayment);
  const removePayment = useSahyog((s) => s.removePayment);
  const [open, setOpen] = useState(false);
  const [personId, setPersonId] = useState<string | null>(null);

  const month = monthKey(today);
  const totals = householdPay(people, payments, month);
  const ledger = payments
    .filter((p) => p.date.startsWith(month))
    .slice()
    .sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));

  return (
    <div>
      <PageHead
        eyebrow={monthLabel(month)}
        title="Pay"
        lede="Salary, advances, and what is still to hand over."
        action={
          <button
            type="button"
            className="btn btn-primary"
            disabled={people.length === 0}
            onClick={() => {
              setPersonId(people[0]?.id ?? null);
              setOpen(true);
            }}
          >
            <Plus className="size-4" aria-hidden="true" />
            Record
          </button>
        }
      />

      <section className="card p-5">
        <p className="text-sm text-muted">Still to give this month</p>
        <p className="font-display text-5xl tabular-nums tracking-tight">{inr(totals.due)}</p>
        <p className="mt-2 text-sm text-muted tabular-nums">
          {inr(totals.given)} already given of {inr(totals.owed)} owed
        </p>
      </section>

      {people.length === 0 ? (
        <div className="card mt-4 p-6">
          <p>Add people before you track pay.</p>
          <Link to="/people" className="btn btn-primary mt-4">
            Go to people
          </Link>
        </div>
      ) : (
        <ul className="mt-4 grid gap-3">
          {people.map((person) => {
            const row = breakdown(person, payments, month);
            const pct = payProgress(row);
            const left =
              row.due > 0 ? `${inr(row.due)} still to give` : row.over > 0 ? `${inr(row.over)} over` : "Settled for the month";
            return (
              <li key={person.id} className="card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h2 className="font-display text-3xl leading-none">{person.name}</h2>
                    <p className="mt-1 text-sm text-muted">{roleLabel(person.role)}</p>
                  </div>
                  <p className="text-right text-sm font-medium">{left}</p>
                </div>
                <dl className="mt-4 grid grid-cols-3 gap-2 text-sm">
                  <div>
                    <dt className="text-muted">Month pay</dt>
                    <dd className="font-medium tabular-nums">{inr(row.owed)}</dd>
                  </div>
                  <div>
                    <dt className="text-muted">Given</dt>
                    <dd className="font-medium tabular-nums">{inr(row.given)}</dd>
                  </div>
                  <div>
                    <dt className="text-muted">Left</dt>
                    <dd className="font-semibold tabular-nums">{row.due > 0 ? inr(row.due) : "—"}</dd>
                  </div>
                </dl>
                {(row.bonus > 0 || row.deduction > 0) && (
                  <p className="mt-2 text-sm text-muted">
                    {row.bonus > 0 ? `Includes ${inr(row.bonus)} bonus. ` : ""}
                    {row.deduction > 0 ? `${inr(row.deduction)} deducted.` : ""}
                  </p>
                )}
                <div className="meter mt-3" aria-hidden="true">
                  <span style={{ width: `${pct}%` }} />
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    type="button"
                    className="btn btn-ghost"
                    onClick={() => {
                      setPersonId(person.id);
                      setOpen(true);
                    }}
                  >
                    Record
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary"
                    disabled={row.due <= 0}
                    onClick={() =>
                      addPayment({
                        personId: person.id,
                        personName: person.name,
                        date: today,
                        amount: row.due,
                        kind: "salary",
                        note: `Settled ${monthLabel(month)}`,
                      })
                    }
                  >
                    {row.due > 0 ? `Settle ${inr(row.due)}` : "Settled"}
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <section className="mt-8">
        <h2 className="font-display text-2xl">This month’s record</h2>
        {ledger.length === 0 ? (
          <p className="mt-2 text-muted">Nothing recorded yet. Advances and payouts will sit here.</p>
        ) : (
          <ul className="card mt-3 divide-y divide-line px-4">
            {ledger.map((payment) => (
              <li key={payment.id} className="flex items-start gap-3 py-3">
                <div className="min-w-0 flex-1">
                  <p className="font-medium">
                    {displayName(people, payment)}
                    <span className="font-normal text-muted"> · {PAY_KINDS.find((k) => k.id === payment.kind)?.label}</span>
                  </p>
                  <p className="text-sm text-muted">
                    {shortDate(payment.date)}
                    {payment.note ? ` · ${payment.note}` : ""}
                  </p>
                </div>
                <p className="shrink-0 font-medium tabular-nums">{inr(payment.amount)}</p>
                <button
                  type="button"
                  className="icon-btn"
                  aria-label={`Delete ${payment.kind} for ${displayName(people, payment)}`}
                  onClick={() => removePayment(payment.id)}
                >
                  <Trash2 className="size-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <PayDialog open={open} onOpenChange={setOpen} personId={personId} today={today} />
    </div>
  );
}
