import { Link, Outlet } from "@tanstack/react-router";
import { House, ListChecks, Users, Wallet } from "@/components/sahyog/icons";
import { useEffect, useState } from "react";
import { HomeDialog } from "@/components/sahyog/dialogs";
import { HouseReadyContext } from "@/components/sahyog/ready";
import { Mark } from "@/components/sahyog/ui";
import { useSahyog } from "@/lib/sahyog/store";

const NAV = [
  { to: "/", label: "Today", icon: House, exact: true },
  { to: "/people", label: "People", icon: Users, exact: false },
  { to: "/work", label: "Work", icon: ListChecks, exact: false },
  { to: "/pay", label: "Pay", icon: Wallet, exact: false },
] as const;

export function Shell() {
  const homeName = useSahyog((s) => s.homeName);
  const homePlace = useSahyog((s) => s.homePlace);
  const [ready, setReady] = useState(false);
  const [homeOpen, setHomeOpen] = useState(false);

  useEffect(() => {
    let live = true;
    useSahyog.persist
      .rehydrate()
      .catch(() => undefined)
      .finally(() => {
        if (live) setReady(true);
      });
    return () => {
      live = false;
    };
  }, []);

  return (
    <HouseReadyContext.Provider value={ready}>
      <div className="app-frame">
        <aside className="rail">
          <div className="flex items-center gap-3 px-2">
            <Mark />
            <div>
              <p className="font-display text-2xl leading-none">Sahyog</p>
              <p className="text-sm text-muted">House help, in order.</p>
            </div>
          </div>
          <nav className="mt-8 flex flex-col gap-1" aria-label="Household">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.exact }}
                className="nav-link"
                activeProps={{ "data-active": "true", "aria-current": "page" }}
              >
                <item.icon className="size-5" aria-hidden="true" />
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="mt-auto px-1 pt-6">
            <button type="button" className="home-chip" onClick={() => setHomeOpen(true)}>
              <span className="block truncate font-medium">{homeName}</span>
              <span className="block truncate text-sm text-muted">{homePlace || "Add a place"}</span>
            </button>
            <p className="mt-3 px-2 text-sm text-muted">Saved on this device.</p>
          </div>
        </aside>
        <div className="content-col">
          <header className="mobile-bar">
            <Mark />
            <button type="button" className="min-w-0 text-left" onClick={() => setHomeOpen(true)}>
              <p className="font-display text-xl leading-none">Sahyog</p>
              <p className="truncate text-sm text-muted">{homeName}</p>
            </button>
          </header>
          <main className="main-pad mx-auto w-full max-w-5xl">
            <Outlet />
          </main>
        </div>
        <nav className="tabbar" aria-label="Household">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.exact }}
              className="tab"
              activeProps={{ "data-active": "true", "aria-current": "page" }}
            >
              <item.icon className="size-5" aria-hidden="true" />
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
      <HomeDialog open={homeOpen} onOpenChange={setHomeOpen} />
    </HouseReadyContext.Provider>
  );
}
