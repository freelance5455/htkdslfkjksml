import * as Dialog from "@radix-ui/react-dialog";
import { X } from "@/components/sahyog/icons";
import { useEffect, useId, useState, type ReactNode } from "react";
import {
  AREAS,
  breakdown,
  DAY_LABELS,
  DAY_NAMES,
  monthKey,
  parseMoney,
  PAY_KINDS,
  ROLES,
  type PayKind,
  type Person,
  type PersonInput,
  type RoleId,
  type Task,
  type TaskInput,
} from "@/lib/sahyog/model";
import { useSahyog } from "@/lib/sahyog/store";

function Sheet({
  open,
  onOpenChange,
  title,
  description,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  children: ReactNode;
}) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-ink/40" />
        <Dialog.Content className="sheet-panel">
          <div className="mb-1 flex items-start justify-between gap-3">
            <Dialog.Title className="font-display pr-2 text-3xl leading-none">{title}</Dialog.Title>
            <Dialog.Close className="icon-btn" aria-label="Close">
              <X className="size-5" />
            </Dialog.Close>
          </div>
          <Dialog.Description className="text-sm text-muted">{description}</Dialog.Description>
          {children}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="label">{label}</span>
      {children}
      {hint ? <span className="hint block">{hint}</span> : null}
    </label>
  );
}

export function HomeDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const homeName = useSahyog((s) => s.homeName);
  const homePlace = useSahyog((s) => s.homePlace);
  const setHome = useSahyog((s) => s.setHome);
  const [name, setName] = useState(homeName);
  const [place, setPlace] = useState(homePlace);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    const s = useSahyog.getState();
    setName(s.homeName);
    setPlace(s.homePlace);
    setError("");
  }, [open]);

  return (
    <Sheet open={open} onOpenChange={onOpenChange} title="This house" description="The name on your Sahyog home.">
      <form
        className="mt-5 flex flex-col gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (!name.trim()) {
            setError("Give the home a name.");
            return;
          }
          setHome(name, place);
          onOpenChange(false);
        }}
      >
        <Field label="Home">
          <input className="field" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} />
        </Field>
        <Field label="Place">
          <input className="field" value={place} onChange={(e) => setPlace(e.target.value)} maxLength={40} />
        </Field>
        {error ? <p className="form-error">{error}</p> : null}
        <button type="submit" className="btn btn-primary">
          Save home
        </button>
      </form>
    </Sheet>
  );
}

const EMPTY_PERSON: PersonInput = {
  name: "",
  role: "housekeeping",
  phone: "",
  salary: 10000,
  shift: "",
  days: [1, 2, 3, 4, 5, 6],
  note: "",
};

export function PersonDialog({
  open,
  onOpenChange,
  person,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  person?: Person | null;
}) {
  const addPerson = useSahyog((s) => s.addPerson);
  const updatePerson = useSahyog((s) => s.updatePerson);
  const removePerson = useSahyog((s) => s.removePerson);
  const [draft, setDraft] = useState<PersonInput>(EMPTY_PERSON);
  const [salary, setSalary] = useState("10000");
  const [error, setError] = useState("");
  const [confirmRemove, setConfirmRemove] = useState(false);
  const baseId = useId();

  useEffect(() => {
    if (!open) return;
    const next = person
      ? {
          name: person.name,
          role: person.role,
          phone: person.phone,
          salary: person.salary,
          shift: person.shift,
          days: person.days,
          note: person.note,
        }
      : EMPTY_PERSON;
    setDraft(next);
    setSalary(String(next.salary));
    setError("");
    setConfirmRemove(false);
  }, [open, person]);

  return (
    <Sheet
      open={open}
      onOpenChange={onOpenChange}
      title={person ? person.name : "Add a person"}
      description={person ? "Shift, pay, and the days they come." : "Someone who works in this house."}
    >
      <form
        className="mt-5 flex flex-col gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (!draft.name.trim()) {
            setError("Name is required.");
            return;
          }
          const amount = Number(salary);
          if (!Number.isFinite(amount) || amount < 0) {
            setError("Monthly pay needs a number, or 0.");
            return;
          }
          const input = { ...draft, salary: amount };
          if (person) updatePerson(person.id, input);
          else addPerson(input);
          onOpenChange(false);
        }}
      >
        <Field label="Name">
          <input
            className="field"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            maxLength={60}
            autoComplete="name"
          />
        </Field>
        <Field label="Role">
          <select
            className="field"
            value={draft.role}
            onChange={(e) => setDraft({ ...draft, role: e.target.value as RoleId })}
          >
            {ROLES.map((role) => (
              <option key={role.id} value={role.id}>
                {role.label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Phone">
          <input
            className="field"
            inputMode="tel"
            autoComplete="tel"
            value={draft.phone}
            onChange={(e) => setDraft({ ...draft, phone: e.target.value })}
            maxLength={16}
            placeholder="10-digit mobile"
          />
        </Field>
        <Field label="Monthly pay (₹)">
          <input
            className="field tabular-nums"
            inputMode="numeric"
            value={salary}
            onChange={(e) => setSalary(e.target.value)}
          />
        </Field>
        <Field label="Shift" hint="For example, 9:00–2:00">
          <input
            className="field"
            value={draft.shift}
            onChange={(e) => setDraft({ ...draft, shift: e.target.value })}
            maxLength={48}
          />
        </Field>
        <fieldset>
          <legend className="label">Days they come</legend>
          <div className="day-row">
            {DAY_LABELS.map((label, index) => {
              const on = draft.days.includes(index);
              return (
                <button
                  key={label}
                  type="button"
                  className="day-dot"
                  aria-pressed={on}
                  aria-label={DAY_NAMES[index]}
                  onClick={() =>
                    setDraft({
                      ...draft,
                      days: on ? draft.days.filter((d) => d !== index) : [...draft.days, index],
                    })
                  }
                >
                  {label}
                </button>
              );
            })}
          </div>
          <p className="hint">Leave every day off if they come only when called.</p>
        </fieldset>
        <Field label="Note for the house">
          <textarea
            className="note"
            value={draft.note}
            onChange={(e) => setDraft({ ...draft, note: e.target.value })}
            maxLength={240}
          />
        </Field>
        {error ? <p className="form-error">{error}</p> : null}
        <button type="submit" className="btn btn-primary">
          {person ? "Save person" : "Add person"}
        </button>
        {person ? (
          confirmRemove ? (
            <div className="card p-3">
              <p className="text-sm">
                Remove {person.name}? Their work leaves the list. Pay history stays.
              </p>
              <div className="mt-3 flex gap-2">
                <button
                  type="button"
                  className="btn btn-primary"
                  id={`${baseId}-remove`}
                  onClick={() => {
                    removePerson(person.id);
                    onOpenChange(false);
                  }}
                >
                  Remove
                </button>
                <button type="button" className="btn btn-ghost" onClick={() => setConfirmRemove(false)}>
                  Keep
                </button>
              </div>
            </div>
          ) : (
            <button type="button" className="btn btn-ghost" onClick={() => setConfirmRemove(true)}>
              Remove from household
            </button>
          )
        ) : null}
      </form>
    </Sheet>
  );
}

export function TaskDialog({
  open,
  onOpenChange,
  task,
  presetKind,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task?: Task | null;
  presetKind?: "daily" | "once";
}) {
  const people = useSahyog((s) => s.people);
  const addTask = useSahyog((s) => s.addTask);
  const updateTask = useSahyog((s) => s.updateTask);
  const removeTask = useSahyog((s) => s.removeTask);
  const [draft, setDraft] = useState<TaskInput>({
    title: "",
    personId: "",
    area: "kitchen",
    kind: "daily",
    date: "",
    time: "",
  });
  const [error, setError] = useState("");
  const [confirmRemove, setConfirmRemove] = useState(false);

  useEffect(() => {
    if (!open) return;
    const s = useSahyog.getState();
    const today = new Date();
    const iso = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
    if (task) {
      setDraft({
        title: task.title,
        personId: task.personId,
        area: task.area,
        kind: task.kind,
        date: task.date || iso,
        time: task.time,
      });
    } else {
      setDraft({
        title: "",
        personId: s.people[0]?.id ?? "",
        area: "kitchen",
        kind: presetKind ?? "daily",
        date: iso,
        time: "",
      });
    }
    setError("");
    setConfirmRemove(false);
  }, [open, task, presetKind]);

  return (
    <Sheet
      open={open}
      onOpenChange={onOpenChange}
      title={task ? "Edit work" : "Add work"}
      description="A job for someone in the house, daily or just once."
    >
      <form
        className="mt-5 flex flex-col gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (!draft.title.trim()) {
            setError("Say what needs doing.");
            return;
          }
          if (!draft.personId) {
            setError("Choose who does it.");
            return;
          }
          const input: TaskInput = {
            ...draft,
            title: draft.title.trim(),
            date: draft.kind === "once" ? draft.date : "",
          };
          if (task) updateTask(task.id, input);
          else addTask(input);
          onOpenChange(false);
        }}
      >
        <Field label="What">
          <input
            className="field"
            value={draft.title}
            onChange={(e) => setDraft({ ...draft, title: e.target.value })}
            maxLength={120}
          />
        </Field>
        <Field label="Who">
          <select
            className="field"
            value={draft.personId}
            onChange={(e) => setDraft({ ...draft, personId: e.target.value })}
          >
            {people.length === 0 ? <option value="">Add a person first</option> : null}
            {people.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Where">
          <select
            className="field"
            value={draft.area}
            onChange={(e) => setDraft({ ...draft, area: e.target.value as TaskInput["area"] })}
          >
            {AREAS.map((area) => (
              <option key={area.id} value={area.id}>
                {area.label}
              </option>
            ))}
          </select>
        </Field>
        <div>
          <span className="label">Repeats</span>
          <div className="segment" role="group" aria-label="Repeats">
            <button
              type="button"
              aria-pressed={draft.kind === "daily"}
              onClick={() => setDraft({ ...draft, kind: "daily" })}
            >
              Every workday
            </button>
            <button
              type="button"
              aria-pressed={draft.kind === "once"}
              onClick={() => setDraft({ ...draft, kind: "once" })}
            >
              Just one day
            </button>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Time">
            <input
              className="field"
              type="time"
              value={draft.time}
              onChange={(e) => setDraft({ ...draft, time: e.target.value })}
            />
          </Field>
          {draft.kind === "once" ? (
            <Field label="Date">
              <input
                className="field"
                type="date"
                value={draft.date}
                onChange={(e) => setDraft({ ...draft, date: e.target.value })}
                required
              />
            </Field>
          ) : (
            <div />
          )}
        </div>
        {error ? <p className="form-error">{error}</p> : null}
        <button type="submit" className="btn btn-primary" disabled={people.length === 0}>
          {task ? "Save work" : "Add work"}
        </button>
        {task ? (
          confirmRemove ? (
            <div className="card bg-bg p-3">
              <p className="text-sm">Delete “{task.title}” from the list?</p>
              <div className="mt-3 flex gap-2">
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={() => {
                    removeTask(task.id);
                    onOpenChange(false);
                  }}
                >
                  Delete
                </button>
                <button type="button" className="btn btn-ghost" onClick={() => setConfirmRemove(false)}>
                  Keep
                </button>
              </div>
            </div>
          ) : (
            <button type="button" className="btn btn-ghost" onClick={() => setConfirmRemove(true)}>
              Delete this work
            </button>
          )
        ) : null}
      </form>
    </Sheet>
  );
}

export function PayDialog({
  open,
  onOpenChange,
  personId,
  today,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  personId?: string | null;
  today: string;
}) {
  const people = useSahyog((s) => s.people);
  const payments = useSahyog((s) => s.payments);
  const addPayment = useSahyog((s) => s.addPayment);
  const [who, setWho] = useState("");
  const [kind, setKind] = useState<PayKind>("advance");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(today);
  const [note, setNote] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    const s = useSahyog.getState();
    const id = personId || s.people[0]?.id || "";
    setWho(id);
    setKind("advance");
    setDate(today);
    setNote("");
    setError("");
    const person = s.people.find((p) => p.id === id);
    const due = person ? breakdown(person, s.payments, monthKey(today)).due : 0;
    setAmount(due > 0 ? String(due) : "");
  }, [open, personId, today]);

  const person = people.find((p) => p.id === who);
  const hint = PAY_KINDS.find((k) => k.id === kind)?.hint ?? "";
  const due = person ? breakdown(person, payments, monthKey(today)).due : 0;

  return (
    <Sheet open={open} onOpenChange={onOpenChange} title="Record money" description="An advance, a payout, a bonus, or a deduction.">
      <form
        className="mt-5 flex flex-col gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          const value = parseMoney(amount);
          if (!who || !person) {
            setError("Choose a person.");
            return;
          }
          if (value == null) {
            setError("Enter an amount above zero.");
            return;
          }
          if (!date) {
            setError("Pick a date.");
            return;
          }
          addPayment({
            personId: who,
            personName: person.name,
            date,
            amount: value,
            kind,
            note,
          });
          onOpenChange(false);
        }}
      >
        <Field label="Person">
          <select className="field" value={who} onChange={(e) => setWho(e.target.value)}>
            {people.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </Field>
        <div>
          <span className="label">Kind</span>
          <div className="segment" role="group" aria-label="Kind of payment">
            {PAY_KINDS.map((item) => (
              <button key={item.id} type="button" aria-pressed={kind === item.id} onClick={() => setKind(item.id)}>
                {item.label}
              </button>
            ))}
          </div>
          <p className="hint">{hint}</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Amount (₹)" hint={due > 0 ? `${person?.name.split(" ")[0] ?? "They"} still to give: check the card.` : undefined}>
            <input className="field tabular-nums" inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </Field>
          <Field label="Date">
            <input className="field" type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
          </Field>
        </div>
        <Field label="Note">
          <input className="field" value={note} onChange={(e) => setNote(e.target.value)} maxLength={140} />
        </Field>
        {error ? <p className="form-error">{error}</p> : null}
        <button type="submit" className="btn btn-primary" disabled={people.length === 0}>
          Save record
        </button>
      </form>
    </Sheet>
  );
}
