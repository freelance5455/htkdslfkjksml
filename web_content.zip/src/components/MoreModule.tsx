import React, { useState, useMemo } from 'react';
import {
  Download,
  Upload,
  FileSpreadsheet,
  Database,
  Smartphone,
  Copy,
  Check,
  Edit3,
  Trash2,
  Plus,
  RotateCcw,
  X,
} from 'lucide-react';
import {
  Account,
  AccountType,
  CustomCategory,
  DebtRecord,
  SubscriptionRecord,
  TransactionRecord,
} from '../types/finance';
import {
  formatBDT,
  formatDateBnEn,
  getCurrentYearMonth,
  paisaToInputString,
  parseAmountToPaisa,
} from '../utils/money';
import { buildUnifiedLedger, UnifiedLedgerItem } from '../utils/unifiedLedger';
import { ANDROID_KOTLIN_FILES } from '../data/androidKotlinSource';
import {
  BACKUP_FORMAT_VERSION,
  FullBackupPayload,
  validateAndDeduplicatePayload,
} from '../utils/cryptoBackup';
import { GoogleDriveBackupSection } from './GoogleDriveBackupSection';
import { ConfirmDialog } from './ConfirmDialog';

interface MoreModuleProps {
  accounts: Account[];
  accountBalances: Record<string, number>;
  transactions: TransactionRecord[];
  debts: DebtRecord[];
  subscriptions: SubscriptionRecord[];
  categories: CustomCategory[];
  useBengaliDigits: boolean;
  onSaveAccount: (
    accData: Omit<Account, 'id' | 'createdAt'>,
    existingId?: string
  ) => void;
  onDeleteAccount: (acc: Account) => void;
  onAddCategory: (cat: CustomCategory) => void;
  onUpdateCategory: (catId: string, newNameBn: string) => void;
  onDeleteCategory: (catId: string) => void;
  onExportCSV: (items: UnifiedLedgerItem[]) => void;
  onExportBackupJSON: () => void;
  onRestoreBackupJSON: (rawJson: string) => { ok: boolean; message: string };
  onLoadDemoData: () => void;
  onClearDemoData: () => void;
  onResetAllData: () => void;
}

type SubView = 'ACCOUNTS' | 'CATEGORIES' | 'REPORTS' | 'BACKUP' | 'ANDROID_KOTLIN';

export const MoreModule: React.FC<MoreModuleProps> = ({
  accounts,
  accountBalances,
  transactions,
  debts,
  subscriptions,
  categories,
  useBengaliDigits,
  onSaveAccount,
  onAddCategory,
  onUpdateCategory,
  onDeleteCategory,
  onExportCSV,
  onExportBackupJSON,
  onRestoreBackupJSON,
  onLoadDemoData,
  onClearDemoData,
  onResetAllData,
}) => {
  const [activeSubView, setActiveSubView] = useState<SubView>('ACCOUNTS');

  const [selectedLedgerAccountId, setSelectedLedgerAccountId] = useState<string>(
    accounts[0]?.id ?? ''
  );

  const [showAccModal, setShowAccModal] = useState(false);
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [accNameBn, setAccNameBn] = useState('');
  const [accType, setAccType] = useState<AccountType>('CASH');
  const [openingBalanceInput, setOpeningBalanceInput] = useState('0');
  const [accError, setAccError] = useState<string | null>(null);

  const [catTabType, setCatTabType] = useState<'INCOME' | 'EXPENSE'>('EXPENSE');
  const [newCatName, setNewCatName] = useState('');
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editingCatName, setEditingCatName] = useState('');

  const currentYM = getCurrentYearMonth();
  const [reportMonth, setReportMonth] = useState(currentYM);

  const [restoreFeedback, setRestoreFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [pendingLocalRestoreContent, setPendingLocalRestoreContent] = useState<{
    rawJson: string;
    summaryBn: string;
  } | null>(null);

  const [selectedAndroidFileIndex, setSelectedAndroidFileIndex] = useState(0);
  const [copiedFile, setCopiedFile] = useState(false);

  const unifiedLedger = useMemo(
    () =>
      buildUnifiedLedger({
        transactions,
        debts,
        subscriptions,
        accounts,
      }),
    [transactions, debts, subscriptions, accounts]
  );

  const openEditAccountModal = (acc: Account) => {
    setEditingAccount(acc);
    setAccNameBn(acc.nameBn);
    setAccType(acc.type);
    setOpeningBalanceInput(paisaToInputString(acc.openingBalancePaisa));
    setAccError(null);
    setShowAccModal(true);
  };

  const handleSaveAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAccError(null);

    if (!accNameBn.trim()) {
      setAccError('অনুগ্রহ করে হিসাবের নাম লিখুন।');
      return;
    }

    const parsedOpening = parseAmountToPaisa(openingBalanceInput || '0');
    if (parsedOpening === null) {
      setAccError('অনুগ্রহ করে সঠিক ব্যালেন্স লিখুন।');
      return;
    }

    onSaveAccount(
      {
        nameBn: accNameBn.trim(),
        nameEn: accNameBn.trim(),
        type: accType,
        openingBalancePaisa: parsedOpening,
      },
      editingAccount?.id
    );
    setShowAccModal(false);
  };

  const handleAddCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newCatName.trim();
    if (!trimmed) return;
    onAddCategory({
      id: `cat-custom-${Date.now()}`,
      nameBn: trimmed,
      nameEn: trimmed,
      applicableTo: [catTabType],
    });
    setNewCatName('');
  };

  const handleSaveCategoryEdit = (catId: string) => {
    const trimmed = editingCatName.trim();
    if (!trimmed) return;
    onUpdateCategory(catId, trimmed);
    setEditingCatId(null);
    setEditingCatName('');
  };

  const filteredCategories = useMemo(
    () => categories.filter((c) => c.applicableTo.includes(catTabType)),
    [categories, catTabType]
  );

  const accountLedgerEntries = useMemo(() => {
    const targetId = selectedLedgerAccountId || accounts[0]?.id;
    if (!targetId) return [];

    return unifiedLedger.filter((item) => item.accountId === targetId);
  }, [unifiedLedger, selectedLedgerAccountId, accounts]);

  const reportStats = useMemo(() => {
    let mIncome = 0;
    let mExpense = 0;

    for (const tx of transactions) {
      if (tx.type === 'TRANSFER') continue;
      const isInflow = tx.type === 'INCOME' || tx.type === 'SALE';

      if (tx.date.startsWith(reportMonth)) {
        if (isInflow) mIncome += tx.amountPaisa;
        else mExpense += tx.amountPaisa;
      }
    }

    return {
      mIncome,
      mExpense,
      mNet: mIncome - mExpense,
    };
  }, [transactions, reportMonth]);

  const buildCurrentFullPayload = (): FullBackupPayload => ({
    schemaVersion: 1,
    appName: 'HisabKhata',
    backupVersion: BACKUP_FORMAT_VERSION,
    exportedAt: new Date().toISOString(),
    currency: 'BDT',
    accounts,
    transactions,
    debts,
    subscriptions,
    categories,
    settings: {
      useBengaliDigits,
      autoBackupEnabled: true,
    },
  });

  const handleFileUploadRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const content = String(reader.result ?? '');
      try {
        const parsed = JSON.parse(content);
        const validated = validateAndDeduplicatePayload(parsed);
        setPendingLocalRestoreContent({
          rawJson: JSON.stringify(validated),
          summaryBn: `${validated.transactions.length}টি লেনদেন, ${validated.debts.length}টি দেনা-পাওনা এবং ${validated.subscriptions.length}টি নিয়মিত বিল`,
        });
      } catch (err: any) {
        setRestoreFeedback({
          type: 'error',
          text:
            err?.message ||
            'অবৈধ বা ক্ষতিগ্রস্ত ব্যাকআপ ফাইল! অনুগ্রহ করে সঠিক ব্যাকআপ ফাইল নির্বাচন করুন।',
        });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleConfirmLocalRestore = () => {
    if (!pendingLocalRestoreContent) return;
    const res = onRestoreBackupJSON(pendingLocalRestoreContent.rawJson);
    setRestoreFeedback({
      type: res.ok ? 'success' : 'error',
      text: res.message,
    });
    setPendingLocalRestoreContent(null);
  };

  const handleCopyAndroidCode = () => {
    const activeFile = ANDROID_KOTLIN_FILES[selectedAndroidFileIndex];
    if (!activeFile) return;
    navigator.clipboard.writeText(activeFile.code);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 1800);
  };

  const hasDemoItems =
    accounts.some((a) => a.isDemo) ||
    transactions.some((t) => t.isDemo) ||
    debts.some((d) => d.isDemo);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            হিসাব, খাত, প্রতিবেদন ও ব্যাকআপ
          </h1>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
            হিসাবের নাম ও ব্যালেন্স সম্পাদনা, খাত ব্যবস্থাপনা এবং প্রতিবেদন
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-white/80 dark:bg-slate-800 backdrop-blur-xs border border-slate-200/80 dark:border-slate-700 rounded-xl overflow-x-auto">
          {(
            [
              { id: 'ACCOUNTS', label: 'হিসাবসমূহ' },
              { id: 'CATEGORIES', label: 'খাতসমূহ' },
              { id: 'REPORTS', label: 'প্রতিবেদন' },
              { id: 'BACKUP', label: 'ব্যাকআপ' },
              { id: 'ANDROID_KOTLIN', label: 'অ্যান্ড্রয়েড কোড' },
            ] as { id: SubView; label: string }[]
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveSubView(tab.id)}
              className={`min-h-[38px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                activeSubView === tab.id
                  ? 'bg-emerald-700 text-white dark:bg-emerald-600 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* SUBVIEW 1: ACCOUNTS */}
      {activeSubView === 'ACCOUNTS' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {accounts.map((acc) => {
              const currentBalance =
                accountBalances[acc.id] ?? acc.openingBalancePaisa;
              const isSelected =
                (selectedLedgerAccountId || accounts[0]?.id) === acc.id;

              return (
                <div
                  key={acc.id}
                  onClick={() => setSelectedLedgerAccountId(acc.id)}
                  className={`rounded-2xl p-5 border transition-colors cursor-pointer backdrop-blur-md shadow-xs ${
                    isSelected
                      ? 'bg-emerald-50/90 dark:bg-emerald-950/40 border-emerald-600 dark:border-emerald-500'
                      : 'bg-white/90 dark:bg-slate-900/90 border-slate-200/90 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 truncate">
                      {acc.nameBn}
                    </h3>
                    <div
                      className="flex items-center gap-1 shrink-0"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        type="button"
                        onClick={() => openEditAccountModal(acc)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 dark:hover:text-white"
                        title="হিসাব সম্পাদনা"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <p className="mt-4 text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                    {formatBDT(currentBalance, { useBengaliDigits })}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Account-wise Unified Transaction History */}
          <section className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  হিসাব ভিত্তিক লেনদেন বিবরণী
                </h3>
                <p className="text-xs text-slate-500">
                  নির্বাচিত হিসাবের সকল আয়, ব্যয়, দেনা-পাওনা ও বিলের তালিকা
                </p>
              </div>
              <select
                value={selectedLedgerAccountId || accounts[0]?.id || ''}
                onChange={(e) => setSelectedLedgerAccountId(e.target.value)}
                className="min-h-[40px] px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-medium text-slate-900 dark:text-slate-100"
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.nameBn}
                  </option>
                ))}
              </select>
            </div>

            {accountLedgerEntries.length === 0 ? (
              <p className="py-8 text-center text-xs text-slate-500">
                এই হিসাবে এখনো কোনো লেনদেন হয়নি।
              </p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800 mt-2">
                {accountLedgerEntries.map((item) => {
                  const isInflow = item.flowDirection === 'IN';

                  return (
                    <div
                      key={item.id}
                      className="py-3 flex items-center justify-between gap-4 text-xs"
                    >
                      <div>
                        <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                          {item.titleBn}
                        </p>
                        <p className="text-slate-500 mt-0.5">
                          {item.typeLabelBn} · {item.categoryBn} ·{' '}
                          {formatDateBnEn(item.date, useBengaliDigits)}
                        </p>
                      </div>
                      <span
                        className={`text-sm font-bold font-mono tabular-nums ${
                          isInflow
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : 'text-red-600 dark:text-red-400'
                        }`}
                      >
                        {isInflow ? '+' : '-'}
                        {formatBDT(item.amountPaisa, { useBengaliDigits })}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </div>
      )}

      {/* SUBVIEW 2: CATEGORIES MANAGEMENT */}
      {activeSubView === 'CATEGORIES' && (
        <section className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 space-y-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                খাত ব্যবস্থাপনা
              </h2>
              <p className="text-xs text-slate-500">
                আয় ও ব্যয়ের খাত যোগ, নাম পরিবর্তন ও মুছে ফেলার সুবিধা
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-full sm:w-64">
              <button
                type="button"
                onClick={() => {
                  setCatTabType('INCOME');
                  setEditingCatId(null);
                }}
                className={`min-h-[38px] px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  catTabType === 'INCOME'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                আয়ের খাত
              </button>
              <button
                type="button"
                onClick={() => {
                  setCatTabType('EXPENSE');
                  setEditingCatId(null);
                }}
                className={`min-h-[38px] px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  catTabType === 'EXPENSE'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                ব্যয়ের খাত
              </button>
            </div>
          </div>

          <form
            onSubmit={handleAddCategorySubmit}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3"
          >
            <input
              type="text"
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              placeholder={
                catTabType === 'INCOME'
                  ? 'নতুন আয়ের খাতের নাম লিখুন...'
                  : 'নতুন ব্যয়ের খাতের নাম লিখুন...'
              }
              className="flex-1 min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
            <button
              type="submit"
              className="min-h-[44px] px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন খাত যোগ করুন</span>
            </button>
          </form>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredCategories.length === 0 ? (
              <p className="py-8 text-center text-xs text-slate-500">
                কোনো খাত পাওয়া যায়নি। উপরে নতুন খাতের নাম লিখে যোগ করুন।
              </p>
            ) : (
              filteredCategories.map((cat) => {
                const isEditing = editingCatId === cat.id;
                return (
                  <div
                    key={cat.id}
                    className="py-3 flex items-center justify-between gap-4"
                  >
                    {isEditing ? (
                      <div className="flex-1 flex items-center gap-2">
                        <input
                          type="text"
                          value={editingCatName}
                          onChange={(e) => setEditingCatName(e.target.value)}
                          className="flex-1 min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveCategoryEdit(cat.id)}
                          className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium flex items-center gap-1"
                        >
                          <Check className="w-4 h-4" />
                          <span>সংরক্ষণ</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingCatId(null)}
                          className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium"
                        >
                          বাতিল
                        </button>
                      </div>
                    ) : (
                      <>
                        <span className="text-sm font-medium text-slate-900 dark:text-slate-100">
                          {cat.nameBn}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingCatId(cat.id);
                              setEditingCatName(cat.nameBn);
                            }}
                            className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
                            title="সম্পাদনা"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteCategory(cat.id)}
                            className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </section>
      )}

      {/* SUBVIEW 3: REPORTS */}
      {activeSubView === 'REPORTS' && (
        <div className="space-y-6">
          <section className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  মাসিক প্রতিবেদন
                </h2>
                <p className="text-xs text-slate-500">
                  মাস নির্বাচন করে আয় ও ব্যয়ের সারসংক্ষেপ দেখুন
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <input
                  type="month"
                  value={reportMonth}
                  onChange={(e) => setReportMonth(e.target.value)}
                  className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
                />
                <button
                  type="button"
                  onClick={() => onExportCSV(unifiedLedger)}
                  className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>সিএসভি ডাউনলোড</span>
                </button>
              </div>
            </div>

            <div className="mt-6 max-w-xl">
              <div className="p-5 rounded-xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 space-y-3">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  মাসিক প্রতিবেদন ({reportMonth})
                </h3>
                <div className="space-y-2.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-400">
                      মোট আয়:
                    </span>
                    <span className="font-mono tabular-nums font-semibold text-emerald-700 dark:text-emerald-400">
                      {formatBDT(reportStats.mIncome, { useBengaliDigits })}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-400">
                      মোট ব্যয়:
                    </span>
                    <span className="font-mono tabular-nums font-semibold text-red-600 dark:text-red-400">
                      {formatBDT(reportStats.mExpense, { useBengaliDigits })}
                    </span>
                  </div>
                  <div className="pt-2.5 border-t border-slate-200 dark:border-slate-700 flex justify-between text-sm font-bold">
                    <span>মাসিক নিট উদ্বৃত্ত:</span>
                    <span
                      className={`font-mono tabular-nums ${
                        reportStats.mNet >= 0
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : 'text-red-600 dark:text-red-400'
                      }`}
                    >
                      {formatBDT(reportStats.mNet, {
                        useBengaliDigits,
                        showSign: true,
                      })}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      )}

      {/* SUBVIEW 4: BACKUP & DEMO */}
      {activeSubView === 'BACKUP' && (
        <div className="space-y-6">
          <GoogleDriveBackupSection
            buildCurrentPayload={buildCurrentFullPayload}
            onApplyRestoredPayload={(payload) => {
              onRestoreBackupJSON(JSON.stringify(payload));
            }}
            useBengaliDigits={useBengaliDigits}
          />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 space-y-4 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 flex items-center justify-center shrink-0">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                    স্থানীয় ফাইল এক্সপোর্ট ও রিস্টোর (JSON)
                  </h2>
                  <p className="text-xs text-slate-500">
                    অফলাইনে নিজের ডিভাইসে আলাদা ব্যাকআপ ফাইল সংরক্ষণ করুন
                  </p>
                </div>
              </div>

              {restoreFeedback && (
                <div
                  className={`p-3 rounded-xl text-xs border ${
                    restoreFeedback.type === 'success'
                      ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
                      : 'bg-red-50 dark:bg-red-950/50 border-red-200 dark:border-red-800 text-red-700 dark:text-red-300'
                  }`}
                >
                  {restoreFeedback.text}
                </div>
              )}

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={onExportBackupJSON}
                  className="min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <Download className="w-4 h-4" />
                  <span>ব্যাকআপ ফাইল এক্সপোর্ট</span>
                </button>

                <label className="min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0">
                  <Upload className="w-4 h-4" />
                  <span>ব্যাকআপ ফাইল রিস্টোর</span>
                  <input
                    type="file"
                    accept=".json,application/json"
                    onChange={handleFileUploadRestore}
                    className="hidden"
                  />
                </label>
              </div>
            </section>

            <section className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 space-y-4 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 flex items-center justify-center shrink-0">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                    নমুনা তথ্য ও রিসেট
                  </h2>
                  <p className="text-xs text-slate-500">
                    নমুনা তথ্য লোড করুন অথবা মুছে নিজস্ব হিসাব শুরু করুন
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={onLoadDemoData}
                  className="min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 whitespace-nowrap shrink-0"
                >
                  নমুনা তথ্য লোড করুন
                </button>

                {hasDemoItems && (
                  <button
                    type="button"
                    onClick={onClearDemoData}
                    className="min-h-[44px] px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-medium whitespace-nowrap shrink-0"
                  >
                    নমুনা তথ্য মুছে ফেলুন
                  </button>
                )}

                <button
                  type="button"
                  onClick={onResetAllData}
                  className="min-h-[44px] px-4 py-2.5 rounded-xl border border-red-200 dark:border-red-900/60 hover:bg-red-50 dark:hover:bg-red-950/40 text-red-600 dark:text-red-400 text-xs font-medium whitespace-nowrap shrink-0"
                >
                  সব তথ্য রিসেট করুন
                </button>
              </div>
            </section>
          </div>

          <ConfirmDialog
            open={Boolean(pendingLocalRestoreContent)}
            titleBn="ব্যাকআপ ফাইল থেকে রিস্টোর নিশ্চিত করুন"
            messageBn={
              pendingLocalRestoreContent
                ? `ব্যাকআপ ফাইলের অখণ্ডতা যাচাই সফল হয়েছে (${pendingLocalRestoreContent.summaryBn})। রিস্টোর করলে আপনার বর্তমান তথ্যের স্থলে এই ব্যাকআপটি প্রতিস্থাপিত হবে।`
                : ''
            }
            confirmLabelBn="হ্যাঁ, রিস্টোর করুন"
            danger={true}
            onConfirm={handleConfirmLocalRestore}
            onCancel={() => setPendingLocalRestoreContent(null)}
          />
        </div>
      )}

      {/* SUBVIEW 5: ANDROID KOTLIN */}
      {activeSubView === 'ANDROID_KOTLIN' && (
        <div className="space-y-6">
          <section className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 shadow-xs">
            <div className="flex items-center gap-3 pb-5 border-b border-slate-200 dark:border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  অ্যান্ড্রয়েড সোর্স কোড
                </h2>
                <p className="text-xs text-slate-500">
                  অ্যান্ড্রয়েড ফোনে ইনস্টল ও ব্যবহারের জন্য সোর্স কোড
                </p>
              </div>
            </div>

            <div className="mt-6">
              <div className="flex items-center justify-between gap-2 flex-wrap mb-3">
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  {ANDROID_KOTLIN_FILES.map((file, idx) => (
                    <button
                      key={file.path}
                      type="button"
                      onClick={() => setSelectedAndroidFileIndex(idx)}
                      className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-mono transition-colors whitespace-nowrap shrink-0 ${
                        selectedAndroidFileIndex === idx
                          ? 'bg-slate-900 text-white dark:bg-emerald-600'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {file.titleBn}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={handleCopyAndroidCode}
                  className="min-h-[36px] px-3.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  {copiedFile ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>কপি হয়েছে</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>কোড কপি করুন</span>
                    </>
                  )}
                </button>
              </div>

              <div className="rounded-xl bg-slate-950 text-slate-100 p-4 overflow-x-auto border border-slate-800">
                <pre className="text-xs font-mono leading-relaxed">
                  <code>
                    {ANDROID_KOTLIN_FILES[selectedAndroidFileIndex]?.code}
                  </code>
                </pre>
              </div>
            </div>
          </section>
        </div>
      )}

      {/* Edit Account Name & Balance Modal */}
      {showAccModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="w-full max-w-md rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border-t sm:border border-slate-200 dark:border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                হিসাব সম্পাদনা
              </h3>
              <button
                type="button"
                onClick={() => setShowAccModal(false)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAccountSubmit} className="mt-4 space-y-4">
              {accError && (
                <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300">
                  {accError}
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  হিসাবের নাম *
                </label>
                <input
                  type="text"
                  value={accNameBn}
                  onChange={(e) => setAccNameBn(e.target.value)}
                  required
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ব্যালেন্স (৳) *
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={openingBalanceInput}
                  onChange={(e) => setOpeningBalanceInput(e.target.value)}
                  required
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono tabular-nums text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAccModal(false)}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
