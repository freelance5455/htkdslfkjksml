import React, { useState, useEffect, useRef } from 'react';
import {
  HelpCircle,
  Trophy,
  Award,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  RotateCcw,
  Globe,
  Share2,
  Download,
  Sparkles,
  Zap,
  BarChart2,
  Check,
  ChevronRight,
  Flame,
  ShieldCheck,
  Medal,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopAppBar } from './TopAppBar';
import {
  QuizLanguage,
  QuizDifficulty,
  QuizCategoryMeta,
  QuizQuestion,
  QuizResultRecord,
  UserQuizProgress
} from '../types/quiz';
import {
  QUIZ_CATEGORIES,
  QUIZ_LEVELS,
  getQuizQuestions,
  getDailyQuizQuestions
} from '../data/quizData';

interface HealthQuizViewProps {
  onBack: () => void;
}

export const HealthQuizView: React.FC<HealthQuizViewProps> = ({ onBack }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<QuizLanguage>('English');
  const [currentScreen, setCurrentScreen] = useState<
    'home' | 'level-select' | 'active-quiz' | 'quiz-results' | 'certificate'
  >('home');

  const [selectedCategory, setSelectedCategory] = useState<QuizCategoryMeta | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<QuizDifficulty>('Beginner');
  const [activeQuestions, setActiveQuestions] = useState<QuizQuestion[]>([]);
  const [isDailyQuiz, setIsDailyQuiz] = useState<boolean>(false);

  // Active quiz state
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState<boolean>(false);
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>([]);
  const [timerSeconds, setTimerSeconds] = useState<number>(0);

  // Certificate state
  const [recipientName, setRecipientName] = useState<string>('Health Explorer');
  const [copiedShare, setCopiedShare] = useState<boolean>(false);
  const certificateRef = useRef<HTMLDivElement>(null);

  // Stats & Progress State from LocalStorage
  const [progressStats, setProgressStats] = useState<UserQuizProgress>({
    completedQuizzesCount: 0,
    highestScorePercentage: 0,
    averageScorePercentage: 0,
    totalQuizTimeSeconds: 0,
    quizHistory: []
  });

  // Load progress from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('mediguide_quiz_progress_v1');
      if (saved) {
        setProgressStats(JSON.parse(saved));
      }
    } catch (e) {
      console.warn('Failed to load quiz progress:', e);
    }
  }, []);

  // Timer effect for active quiz
  useEffect(() => {
    let interval: any = null;
    if (currentScreen === 'active-quiz') {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [currentScreen]);

  // Start a category quiz
  const handleStartCategoryQuiz = (category: QuizCategoryMeta, level: QuizDifficulty) => {
    setSelectedCategory(category);
    setSelectedLevel(level);
    setIsDailyQuiz(false);

    const questions = getQuizQuestions(category.id, level);
    setActiveQuestions(questions);
    setCurrentQuestionIndex(0);
    setSelectedOptionIndex(null);
    setIsAnswerSubmitted(false);
    setUserAnswers(new Array(questions.length).fill(null));
    setTimerSeconds(0);
    setCurrentScreen('active-quiz');
  };

  // Start Daily Health Quiz
  const handleStartDailyQuiz = () => {
    const dailyCat: QuizCategoryMeta = {
      id: 'daily-quiz',
      emoji: '⚡',
      iconBg: 'bg-gradient-to-br from-amber-500 to-rose-600',
      badgeBg: 'bg-amber-100 text-amber-800 border-amber-200',
      nameEn: 'Daily Health Challenge',
      nameHi: 'दैनिक स्वास्थ्य चुनौती',
      nameMr: 'दैनंदिन आरोग्य आव्हान',
      descriptionEn: '10 fresh questions covering key health topics for today.',
      descriptionHi: 'आज की 10 महत्वपूर्ण स्वास्थ्य प्रश्नोत्तरी।',
      descriptionMr: 'आजचे १० महत्त्वाचे आरोग्य प्रश्न.'
    };

    setSelectedCategory(dailyCat);
    setSelectedLevel('Intermediate');
    setIsDailyQuiz(true);

    const questions = getDailyQuizQuestions();
    setActiveQuestions(questions);
    setCurrentQuestionIndex(0);
    setSelectedOptionIndex(null);
    setIsAnswerSubmitted(false);
    setUserAnswers(new Array(questions.length).fill(null));
    setTimerSeconds(0);
    setCurrentScreen('active-quiz');
  };

  // Answer selection & submission
  const handleOptionSelect = (optionIdx: number) => {
    if (isAnswerSubmitted) return;
    setSelectedOptionIndex(optionIdx);
  };

  const handleSubmitAnswer = () => {
    if (selectedOptionIndex === null) return;
    setIsAnswerSubmitted(true);

    const updated = [...userAnswers];
    updated[currentQuestionIndex] = selectedOptionIndex;
    setUserAnswers(updated);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex + 1 < activeQuestions.length) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedOptionIndex(null);
      setIsAnswerSubmitted(false);
    } else {
      // Complete quiz
      finishQuiz();
    }
  };

  // Calculate & Save Results
  const finishQuiz = () => {
    let correctCount = 0;
    activeQuestions.forEach((q, idx) => {
      const uAns = userAnswers[idx];
      const correctIdx = q.content[selectedLanguage]?.correctAnswer ?? q.content.English.correctAnswer;
      if (uAns === correctIdx) {
        correctCount++;
      }
    });

    const total = activeQuestions.length;
    const wrong = total - correctCount;
    const percentage = Math.round((correctCount / total) * 100);

    let rating: 'Excellent' | 'Very Good' | 'Good' | 'Needs Improvement' = 'Needs Improvement';
    if (percentage >= 90) rating = 'Excellent';
    else if (percentage >= 75) rating = 'Very Good';
    else if (percentage >= 50) rating = 'Good';

    const catName = selectedCategory?.nameEn || 'Health Challenge';

    const resultRecord: QuizResultRecord = {
      id: `res-${Date.now()}`,
      categoryId: selectedCategory?.id || 'daily',
      categoryName: catName,
      level: selectedLevel,
      score: correctCount,
      totalQuestions: total,
      percentage,
      correctAnswers: correctCount,
      wrongAnswers: wrong,
      timeTakenSeconds: timerSeconds,
      performanceRating: rating,
      completedAt: new Date().toISOString()
    };

    // Update LocalStorage Stats
    const history = [resultRecord, ...progressStats.quizHistory];
    const totalCount = history.length;
    const maxScore = Math.max(...history.map((h) => h.percentage), percentage);
    const avgScore = Math.round(history.reduce((acc, h) => acc + h.percentage, 0) / totalCount);
    const totalTime = progressStats.totalQuizTimeSeconds + timerSeconds;

    const newProgress: UserQuizProgress = {
      completedQuizzesCount: totalCount,
      highestScorePercentage: maxScore,
      averageScorePercentage: avgScore,
      totalQuizTimeSeconds: totalTime,
      lastAttempt: {
        quizTitle: `${catName} (${selectedLevel})`,
        scorePercentage: percentage,
        completedAt: new Date().toLocaleDateString()
      },
      quizHistory: history.slice(0, 30)
    };

    setProgressStats(newProgress);
    try {
      localStorage.setItem('mediguide_quiz_progress_v1', JSON.stringify(newProgress));
    } catch (e) {
      console.warn('Failed to save progress:', e);
    }

    setCurrentScreen('quiz-results');
  };

  // Format time in minutes and seconds
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins}m ${remainingSecs}s`;
  };

  // Certificate printing / download handler
  const handlePrintCertificate = () => {
    window.print();
  };

  const handleShareCertificate = async () => {
    const text = `🏆 I scored ${latestResult?.percentage}% on the ${latestResult?.categoryName} Quiz on MediGuide AI Health!`;
    if (navigator.share) {
      try {
        await navigator.share({ title: 'MediGuide Health Quiz Certificate', text, url: window.location.href });
        return;
      } catch (e) {}
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    } catch (e) {}
  };

  const latestResult = progressStats.quizHistory[0];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      <TopAppBar
        title="Health Quiz"
        subtitle="Test Your Health IQ & Earn Certificates"
        onBack={
          currentScreen === 'home'
            ? onBack
            : () => setCurrentScreen(currentScreen === 'active-quiz' ? 'level-select' : 'home')
        }
        badge="Material Design 3"
        badgeColor="bg-rose-100 text-rose-800 border-rose-200"
      />

      <div className="p-4 max-w-4xl mx-auto w-full space-y-5">
        {/* Language Switcher Bar */}
        <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
            <Globe className="w-4 h-4 text-rose-600" />
            <span>Quiz Language:</span>
          </div>

          <div className="flex bg-slate-100 p-1 rounded-xl gap-1 border border-slate-200/80">
            {(['English', 'Hindi', 'Marathi'] as QuizLanguage[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setSelectedLanguage(lang)}
                className={`px-3 py-1 rounded-lg text-xs font-black transition-all cursor-pointer ${
                  selectedLanguage === lang
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
              </button>
            ))}
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* VIEW 1: HOME SCREEN */}
        {/* ------------------------------------------------------------- */}
        {currentScreen === 'home' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
            {/* Daily Quiz Banner */}
            <div className="bg-gradient-to-r from-rose-700 via-pink-700 to-indigo-900 text-white p-6 rounded-3xl shadow-lg relative overflow-hidden space-y-4">
              <div className="flex items-start justify-between gap-4 relative z-10">
                <div className="space-y-1.5">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-black uppercase tracking-wider text-rose-100 border border-white/20">
                    <Flame className="w-3.5 h-3.5 text-amber-300" />
                    <span>Daily Health Quiz</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black tracking-tight">
                    {selectedLanguage === 'Hindi'
                      ? 'आज की दैनिक स्वास्थ्य प्रश्नोत्तरी'
                      : selectedLanguage === 'Marathi'
                      ? 'आजचे दैनिक आरोग्य आव्हान'
                      : 'Today’s Daily Health IQ Challenge'}
                  </h2>
                  <p className="text-xs text-rose-100 max-w-md font-medium leading-relaxed">
                    {selectedLanguage === 'Hindi'
                      ? '10 नए यादृच्छिक प्रश्नों का उत्तर देकर अपना स्वास्थ्य स्कोर बढ़ाएं और प्रमाण पत्र जीतें।'
                      : selectedLanguage === 'Marathi'
                      ? '१० नवीन प्रश्नांची उत्तरे द्या आणि तुमचे आरोग्य विषयक ज्ञान तपासा.'
                      : 'Answer 10 mixed health questions today to test your medical knowledge and build your health streak.'}
                  </p>
                </div>

                <div className="hidden sm:flex p-4 bg-white/10 rounded-2xl backdrop-blur-md border border-white/20 text-white shrink-0 items-center justify-center">
                  <Sparkles className="w-8 h-8 text-amber-300 animate-pulse" />
                </div>
              </div>

              <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-white/20 relative z-10 text-xs">
                <div className="flex items-center gap-3 font-semibold text-rose-100">
                  <span className="flex items-center gap-1">
                    <HelpCircle className="w-4 h-4 text-amber-300" /> 10 Questions
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4 text-rose-200" /> ~5 Mins
                  </span>
                </div>

                <button
                  onClick={handleStartDailyQuiz}
                  className="px-5 py-2.5 bg-white text-rose-950 hover:bg-rose-50 font-black rounded-2xl shadow-md transition-all cursor-pointer flex items-center gap-2 hover:scale-105"
                >
                  <span>Start Daily Quiz</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Progress & Stats Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
                <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Completed</p>
                <p className="text-xl font-black text-slate-900">{progressStats.completedQuizzesCount}</p>
                <p className="text-[11px] text-slate-500 font-medium">Quizzes taken</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
                <p className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-600">Highest Score</p>
                <p className="text-xl font-black text-emerald-700">{progressStats.highestScorePercentage}%</p>
                <p className="text-[11px] text-slate-500 font-medium">Personal Best</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
                <p className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600">Average Score</p>
                <p className="text-xl font-black text-indigo-700">{progressStats.averageScorePercentage}%</p>
                <p className="text-[11px] text-slate-500 font-medium">Overall Accuracy</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
                <p className="text-[10px] font-extrabold uppercase tracking-wider text-rose-600">Total Quiz Time</p>
                <p className="text-xl font-black text-rose-700">{formatTime(progressStats.totalQuizTimeSeconds)}</p>
                <p className="text-[11px] text-slate-500 font-medium">Time Spent</p>
              </div>
            </div>

            {/* Categories Section */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
                  {selectedLanguage === 'Hindi'
                    ? 'प्रश्नोत्तरी श्रेणियां (Select Category)'
                    : selectedLanguage === 'Marathi'
                    ? 'क्विझ वर्गवारी (Select Category)'
                    : 'Quiz Categories'}
                </h3>
                <span className="text-xs text-rose-600 font-bold">10 Categories Available</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {QUIZ_CATEGORIES.map((cat) => {
                  const title =
                    selectedLanguage === 'Hindi'
                      ? cat.nameHi
                      : selectedLanguage === 'Marathi'
                      ? cat.nameMr
                      : cat.nameEn;

                  const desc =
                    selectedLanguage === 'Hindi'
                      ? cat.descriptionHi
                      : selectedLanguage === 'Marathi'
                      ? cat.descriptionMr
                      : cat.descriptionEn;

                  return (
                    <motion.div
                      key={cat.id}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      onClick={() => {
                        setSelectedCategory(cat);
                        setCurrentScreen('level-select');
                      }}
                      className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-rose-300 hover:shadow-md transition-all cursor-pointer flex items-start justify-between gap-4 group"
                    >
                      <div className="flex items-start gap-3.5">
                        <div
                          className={`w-12 h-12 rounded-2xl ${cat.iconBg} text-white flex items-center justify-center text-2xl shadow-inner shrink-0 group-hover:scale-110 transition-transform`}
                        >
                          <span>{cat.emoji}</span>
                        </div>

                        <div className="space-y-1">
                          <h4 className="font-extrabold text-sm text-slate-900 group-hover:text-rose-700 transition-colors">
                            {title}
                          </h4>
                          <p className="text-xs text-slate-500 leading-relaxed font-medium line-clamp-2">{desc}</p>

                          <div className="pt-2 flex items-center gap-2 text-[11px] font-bold text-slate-400">
                            <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">3 Difficulty Levels</span>
                            <span>•</span>
                            <span className="text-rose-600">10-20 Questions</span>
                          </div>
                        </div>
                      </div>

                      <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center shrink-0 group-hover:bg-rose-600 group-hover:text-white transition-colors">
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 2: LEVEL SELECTION */}
        {/* ------------------------------------------------------------- */}
        {currentScreen === 'level-select' && selectedCategory && (
          <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="space-y-5">
            {/* Category Header */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-center gap-3">
                <div
                  className={`w-14 h-14 rounded-2xl ${selectedCategory.iconBg} text-white flex items-center justify-center text-3xl shadow-md`}
                >
                  <span>{selectedCategory.emoji}</span>
                </div>
                <div>
                  <h2 className="text-xl font-black text-slate-900">
                    {selectedLanguage === 'Hindi'
                      ? selectedCategory.nameHi
                      : selectedLanguage === 'Marathi'
                      ? selectedCategory.nameMr
                      : selectedCategory.nameEn}
                  </h2>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    {selectedLanguage === 'Hindi'
                      ? selectedCategory.descriptionHi
                      : selectedLanguage === 'Marathi'
                      ? selectedCategory.descriptionMr
                      : selectedCategory.descriptionEn}
                  </p>
                </div>
              </div>
            </div>

            {/* Difficulty Cards */}
            <div className="space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 px-1">
                Select Difficulty Level
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {QUIZ_LEVELS.map((lvl) => {
                  const levelTitle =
                    selectedLanguage === 'Hindi'
                      ? lvl.nameHi
                      : selectedLanguage === 'Marathi'
                      ? lvl.nameMr
                      : lvl.nameEn;

                  return (
                    <motion.div
                      key={lvl.level}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleStartCategoryQuiz(selectedCategory, lvl.level)}
                      className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs hover:border-rose-400 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between space-y-4 group"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-2xl">{lvl.emoji}</span>
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black border ${lvl.badgeColor}`}>
                            {lvl.level}
                          </span>
                        </div>

                        <h4 className="font-extrabold text-base text-slate-900 group-hover:text-rose-700 transition-colors">
                          {levelTitle}
                        </h4>
                      </div>

                      <div className="space-y-2 pt-2 border-t border-slate-100 text-xs text-slate-600 font-medium">
                        <div className="flex items-center justify-between">
                          <span>Total Questions:</span>
                          <strong className="text-slate-900">{lvl.totalQuestions} MCQs</strong>
                        </div>

                        <div className="flex items-center justify-between">
                          <span>Estimated Time:</span>
                          <strong className="text-slate-900">~{lvl.estimatedMinutes} Mins</strong>
                        </div>

                        <div className="flex items-center justify-between">
                          <span>Certificate Eligible:</span>
                          <strong className="text-emerald-700 font-black">≥ 80% Score</strong>
                        </div>
                      </div>

                      <button className="w-full py-2.5 bg-slate-900 text-white group-hover:bg-rose-600 font-bold rounded-2xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5">
                        <span>Start Quiz</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 3: ACTIVE QUIZ SCREEN */}
        {/* ------------------------------------------------------------- */}
        {currentScreen === 'active-quiz' && activeQuestions.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
            {/* Header Status & Progress Bar */}
            <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-600">
                <span className="flex items-center gap-1.5">
                  <span className="text-lg">{selectedCategory?.emoji || '❓'}</span>
                  <span>
                    {selectedCategory?.nameEn} ({selectedLevel})
                  </span>
                </span>

                <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 rounded-xl font-black text-rose-700">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{formatTime(timerSeconds)}</span>
                </span>
              </div>

              {/* Progress Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-extrabold text-slate-500">
                  <span>
                    Question {currentQuestionIndex + 1} of {activeQuestions.length}
                  </span>
                  <span>{Math.round(((currentQuestionIndex + 1) / activeQuestions.length) * 100)}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-rose-500 to-pink-600 transition-all duration-300"
                    style={{ width: `${((currentQuestionIndex + 1) / activeQuestions.length) * 100}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Active Question Card */}
            {(() => {
              const currentQ = activeQuestions[currentQuestionIndex];
              const qData = currentQ.content[selectedLanguage] || currentQ.content.English;

              return (
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
                  {/* Question Title */}
                  <div className="space-y-2">
                    <span className="inline-block px-2.5 py-1 bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-black uppercase rounded-lg">
                      Question #{currentQuestionIndex + 1}
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-slate-900 leading-snug">{qData.question}</h3>
                  </div>

                  {/* 4 Multiple Choice Options */}
                  <div className="space-y-3">
                    {qData.options.map((optionText, optIdx) => {
                      const isSelected = selectedOptionIndex === optIdx;
                      const isCorrect = optIdx === qData.correctAnswer;

                      let buttonStyles =
                        'border-slate-200 bg-white text-slate-800 hover:border-slate-300 hover:bg-slate-50';

                      if (isAnswerSubmitted) {
                        if (isCorrect) {
                          buttonStyles = 'border-emerald-500 bg-emerald-50 text-emerald-950 font-bold ring-2 ring-emerald-500/20';
                        } else if (isSelected) {
                          buttonStyles = 'border-rose-500 bg-rose-50 text-rose-950 font-bold ring-2 ring-rose-500/20';
                        } else {
                          buttonStyles = 'border-slate-200 bg-slate-50 text-slate-400 opacity-60';
                        }
                      } else if (isSelected) {
                        buttonStyles = 'border-rose-600 bg-rose-50 text-rose-950 font-extrabold ring-2 ring-rose-600/20';
                      }

                      return (
                        <button
                          key={optIdx}
                          disabled={isAnswerSubmitted}
                          onClick={() => handleOptionSelect(optIdx)}
                          className={`w-full p-4 rounded-2xl border text-left text-xs sm:text-sm font-medium transition-all flex items-center justify-between cursor-pointer ${buttonStyles}`}
                        >
                          <div className="flex items-center gap-3">
                            <span
                              className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs shrink-0 ${
                                isAnswerSubmitted && isCorrect
                                  ? 'bg-emerald-600 text-white'
                                  : isAnswerSubmitted && isSelected
                                  ? 'bg-rose-600 text-white'
                                  : isSelected
                                  ? 'bg-rose-600 text-white'
                                  : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {String.fromCharCode(65 + optIdx)}
                            </span>
                            <span>{optionText}</span>
                          </div>

                          {isAnswerSubmitted && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />}
                          {isAnswerSubmitted && isSelected && !isCorrect && (
                            <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Immediate Explanation Box After Answer */}
                  {isAnswerSubmitted && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className={`p-4 rounded-2xl border text-xs space-y-2 ${
                        selectedOptionIndex === qData.correctAnswer
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                          : 'bg-amber-50 border-amber-200 text-amber-900'
                      }`}
                    >
                      <div className="flex items-center gap-2 font-black">
                        {selectedOptionIndex === qData.correctAnswer ? (
                          <>
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            <span>✅ Correct Answer!</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-4 h-4 text-amber-600" />
                            <span>❌ Incorrect</span>
                          </>
                        )}
                      </div>
                      <p className="text-xs font-medium leading-relaxed pl-6">{qData.explanation}</p>
                    </motion.div>
                  )}

                  {/* Bottom Action Control */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-end">
                    {!isAnswerSubmitted ? (
                      <button
                        disabled={selectedOptionIndex === null}
                        onClick={handleSubmitAnswer}
                        className={`px-6 py-3 font-bold rounded-2xl text-xs transition-all cursor-pointer ${
                          selectedOptionIndex !== null
                            ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-md'
                            : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                        }`}
                      >
                        Submit Answer
                      </button>
                    ) : (
                      <button
                        onClick={handleNextQuestion}
                        className="px-6 py-3 bg-slate-900 hover:bg-black text-white font-black rounded-2xl text-xs transition-all cursor-pointer flex items-center gap-2 shadow-md hover:scale-105"
                      >
                        <span>
                          {currentQuestionIndex + 1 === activeQuestions.length
                            ? 'See Final Results'
                            : 'Next Question'}
                        </span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })()}
          </motion.div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 4: FINAL RESULTS SCREEN */}
        {/* ------------------------------------------------------------- */}
        {currentScreen === 'quiz-results' && latestResult && (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="space-y-5">
            {/* Trophy Header */}
            <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-md text-center space-y-4 relative overflow-hidden">
              <div className="w-20 h-20 rounded-full bg-amber-100 text-amber-600 border border-amber-200 flex items-center justify-center mx-auto shadow-inner">
                <Trophy className="w-10 h-10" />
              </div>

              <div className="space-y-1">
                <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-black uppercase">
                  {latestResult.performanceRating}
                </span>
                <h2 className="text-2xl font-black text-slate-900 pt-1">Quiz Completed!</h2>
                <p className="text-xs text-slate-500 font-medium">
                  {latestResult.categoryName} ({latestResult.level})
                </p>
              </div>

              {/* Big Percentage Score */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 max-w-xs mx-auto">
                <p className="text-4xl font-black text-rose-600">{latestResult.percentage}%</p>
                <p className="text-xs font-bold text-slate-600 mt-1">
                  Score: {latestResult.score} / {latestResult.totalQuestions}
                </p>
              </div>

              {/* Certificate Award Eligibility */}
              {latestResult.percentage >= 80 ? (
                <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl text-emerald-950 text-xs space-y-2 max-w-md mx-auto">
                  <div className="flex items-center justify-center gap-1.5 font-black text-emerald-800">
                    <Award className="w-5 h-5 text-emerald-600" />
                    <span>🏆 Certificate Unlocked!</span>
                  </div>
                  <p className="font-medium">
                    Congratulations! You passed with over 80% accuracy and earned an official Health Certificate.
                  </p>
                  <button
                    onClick={() => setCurrentScreen('certificate')}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl transition-all cursor-pointer shadow-md inline-flex items-center gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    <span>View / Download Digital Certificate</span>
                  </button>
                </div>
              ) : (
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  Score 80% or higher to unlock your official Health Achievement Certificate.
                </p>
              )}
            </div>

            {/* Score Breakdown Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-white p-4 rounded-2xl border border-slate-200 text-center space-y-1">
                <p className="text-[10px] font-extrabold uppercase text-slate-400">Correct</p>
                <p className="text-xl font-black text-emerald-600">{latestResult.correctAnswers}</p>
                <p className="text-[10px] text-slate-400">Answers</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 text-center space-y-1">
                <p className="text-[10px] font-extrabold uppercase text-slate-400">Wrong</p>
                <p className="text-xl font-black text-rose-600">{latestResult.wrongAnswers}</p>
                <p className="text-[10px] text-slate-400">Answers</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 text-center space-y-1">
                <p className="text-[10px] font-extrabold uppercase text-slate-400">Time Taken</p>
                <p className="text-xl font-black text-slate-800">{formatTime(latestResult.timeTakenSeconds)}</p>
                <p className="text-[10px] text-slate-400">Total duration</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 text-center space-y-1">
                <p className="text-[10px] font-extrabold uppercase text-slate-400">Performance</p>
                <p className="text-xl font-black text-indigo-600">{latestResult.percentage}%</p>
                <p className="text-[10px] text-slate-400">{latestResult.performanceRating}</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={() => {
                  if (selectedCategory) {
                    handleStartCategoryQuiz(selectedCategory, selectedLevel);
                  } else {
                    handleStartDailyQuiz();
                  }
                }}
                className="px-5 py-3 bg-white border border-slate-200 hover:bg-slate-100 text-slate-800 font-bold rounded-2xl text-xs transition-all cursor-pointer flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4 text-slate-500" />
                <span>Retake Quiz</span>
              </button>

              <button
                onClick={() => setCurrentScreen('home')}
                className="px-6 py-3 bg-slate-900 hover:bg-black text-white font-black rounded-2xl text-xs transition-all cursor-pointer flex items-center gap-2 shadow-md"
              >
                <span>Choose Another Quiz</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 5: DIGITAL CERTIFICATE */}
        {/* ------------------------------------------------------------- */}
        {currentScreen === 'certificate' && latestResult && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
            {/* Customize Name Control */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="space-y-0.5">
                <span className="font-bold text-slate-700">Customize Certificate Name:</span>
                <p className="text-[11px] text-slate-400">Enter the exact name to display on your certificate.</p>
              </div>
              <input
                type="text"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                placeholder="Enter Your Full Name"
                className="px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 w-full sm:w-64"
              />
            </div>

            {/* Printable Digital Certificate */}
            <div
              ref={certificateRef}
              className="bg-white p-8 sm:p-12 rounded-3xl border-4 border-amber-400 shadow-xl space-y-6 text-center relative overflow-hidden bg-gradient-to-b from-amber-50/50 via-white to-rose-50/30"
            >
              {/* Decorative Corner Seals */}
              <div className="flex justify-between items-center">
                <div className="p-3 bg-amber-500 text-white rounded-2xl shadow-md">
                  <Award className="w-8 h-8" />
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-black uppercase text-amber-700 tracking-widest">MediGuide AI Health</p>
                  <p className="text-[9px] text-slate-400">Verified Certificate ID: MG-CERT-2026</p>
                </div>
              </div>

              {/* Title Header */}
              <div className="space-y-2 pt-2">
                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-wide font-serif">
                  Certificate of Health Achievement
                </h1>
                <p className="text-xs uppercase tracking-widest text-slate-500 font-bold">
                  This official certificate is proudly presented to
                </p>
              </div>

              {/* Name */}
              <div className="py-2 border-b-2 border-amber-400 inline-block px-8">
                <h2 className="text-2xl sm:text-3xl font-black text-rose-700 font-serif italic">{recipientName}</h2>
              </div>

              {/* Statement */}
              <p className="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto leading-relaxed font-medium">
                For successfully demonstrating medical health literacy and passing the{' '}
                <strong className="text-slate-900 font-extrabold">{latestResult.categoryName} ({latestResult.level})</strong>{' '}
                examination with an outstanding score of{' '}
                <strong className="text-rose-700 font-black">{latestResult.percentage}%</strong>.
              </p>

              {/* Signature & Seal Footer */}
              <div className="pt-6 border-t border-slate-200 grid grid-cols-2 gap-4 text-xs items-center max-w-md mx-auto">
                <div className="space-y-1">
                  <p className="font-extrabold text-slate-900">{new Date().toLocaleDateString()}</p>
                  <p className="text-[10px] uppercase text-slate-400 font-bold">Date Issued</p>
                </div>

                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-black border border-emerald-300">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Verified Doctor Approved</span>
                  </div>
                  <p className="text-[10px] uppercase text-slate-400 font-bold">MediGuide AI Education</p>
                </div>
              </div>
            </div>

            {/* Print / Download / Share Actions */}
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={handlePrintCertificate}
                className="px-6 py-3 bg-rose-600 hover:bg-rose-700 text-white font-black rounded-2xl text-xs transition-all cursor-pointer flex items-center gap-2 shadow-md"
              >
                <Download className="w-4 h-4" />
                <span>Print / Download Certificate</span>
              </button>

              <button
                onClick={handleShareCertificate}
                className="px-5 py-3 bg-white border border-slate-200 hover:bg-slate-100 text-slate-800 font-bold rounded-2xl text-xs transition-all cursor-pointer flex items-center gap-2"
              >
                {copiedShare ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-4 h-4 text-slate-500" />
                    <span>Share Certificate</span>
                  </>
                )}
              </button>

              <button
                onClick={() => setCurrentScreen('home')}
                className="px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-all cursor-pointer"
              >
                Back to Quizzes
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};
