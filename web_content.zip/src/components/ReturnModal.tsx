import React, { useState } from 'react';
import { X, Undo2, Check, AlertCircle } from 'lucide-react';
import { Customer, Product } from '../db/indexedDB';
import { formatMoney } from '../utils/calc';
import { sound } from '../utils/sound';

interface ReturnModalProps {
  customer: Customer | null;
  products: Product[];
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (data: {
    customerId: string;
    productId: string;
    qty: number;
    price: number;
    amount: number;
    type: string;
    destination: string;
    refundType: string;
    invoiceNo: string;
    reason: string;
  }) => Promise<void>;
}

export const ReturnModal: React.FC<ReturnModalProps> = ({
  customer,
  products,
  isOpen,
  onClose,
  onConfirm,
}) => {
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [qty, setQty] = useState(1);
  const [type, setType] = useState('سليم');
  const [destination, setDestination] = useState('السيارة');
  const [refundType, setRefundType] = useState('آجل');
  const [invoiceNo, setInvoiceNo] = useState('');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !customer) return null;

  const currentProduct = products.find((p) => p.id === selectedProductId) || products[0];
  const unitPrice = currentProduct?.price || 0;
  const totalAmount = Math.max(0, qty * unitPrice);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!currentProduct) {
      setError('يرجى اختيار الصنف');
      return;
    }
    if (qty <= 0) {
      setError('يرجى تحديد كمية صحيحة أكبر من صفر');
      return;
    }
    if (refundType === 'آجل' && totalAmount > Number(customer.balance || 0)) {
      setError('قيمة المرتجع أكبر من إجمالي مديونية العميل الحالية');
      sound.playError();
      return;
    }

    try {
      setLoading(true);
      await onConfirm({
        customerId: customer.id,
        productId: currentProduct.id,
        qty,
        price: unitPrice,
        amount: totalAmount,
        type,
        destination,
        refundType,
        invoiceNo,
        reason,
      });
      sound.playSuccess();
      onClose();
    } catch {
      setError('تعذر اعتماد المرتجع');
      sound.playError();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden text-right flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 bg-slate-800/80 border-b border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <Undo2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">تسجيل مرتجع متطور</h3>
              <p className="text-xs text-slate-400">{customer.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-700/60 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-3.5">
          {/* Product selector */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">الصنف المرتجع *</label>
            <select
              value={selectedProductId}
              onChange={(e) => setSelectedProductId(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-rose-500"
            >
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} — سعر: {formatMoney(p.price)} ج.م ({p.group})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">الكمية المرتجعة *</label>
              <input
                type="number"
                min="1"
                value={qty}
                onChange={(e) => setQty(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full font-mono bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">حالة الصنف</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-500"
              >
                <option value="سليم">سليم - يعود للرصيد</option>
                <option value="تالف">تالف - مخزن الهوالك</option>
                <option value="منتهي">منتهي الصلاحية</option>
                <option value="خطأ توريد">خطأ توريد</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">الجهة المستلمة</label>
              <select
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-500"
              >
                <option value="السيارة">حمولة السيارة (تضاف للسيارة)</option>
                <option value="المخزن">المخزن الرئيسي</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">طريقة التسوية المالية</label>
              <select
                value={refundType}
                onChange={(e) => setRefundType(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-500"
              >
                <option value="آجل">خصم من مديونية العميل</option>
                <option value="كاش">رد نقدي من الخزنة</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">رقم الفاتورة الأصلية</label>
              <input
                type="text"
                value={invoiceNo}
                onChange={(e) => setInvoiceNo(e.target.value)}
                placeholder="INV-..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">سبب الإرجاع</label>
              <input
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="تالف / زائد عن الحاجة..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          {/* Amount summary card */}
          <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-center justify-between">
            <span className="text-xs text-rose-300">إجمالي قيمة المرتجع المستحقة:</span>
            <span className="text-base font-black text-rose-400 font-mono">
              {formatMoney(totalAmount)} ج.م
            </span>
          </div>

          {error && (
            <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl flex items-center gap-2 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-3 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 active:scale-95 transition shadow-lg shadow-rose-950"
            >
              <Check className="w-4 h-4" />
              <span>{loading ? 'جاري الاعتماد…' : 'اعتماد المرتجع وتحديث المخزون'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs active:scale-95 transition"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
