import React, { useEffect, useState } from 'react';
import { Battery, BatteryCharging, Compass, Eye, ShieldCheck, Timer } from 'lucide-react';
import { batteryService, BatteryState } from '../utils/battery';
import { orientationService, OrientationData } from '../utils/orientation';

interface StatusHudProps {
  wakeLockActive: boolean;
  timerSecondsRemaining: number | null;
  onOpenTimer: () => void;
  torchActive: boolean;
  torchSupported: boolean | null;
}

export const StatusHud: React.FC<StatusHudProps> = ({
  wakeLockActive,
  timerSecondsRemaining,
  onOpenTimer,
  torchActive,
  torchSupported,
}) => {
  const [battery, setBattery] = useState<BatteryState>(batteryService.getState());
  const [orientation, setOrientation] = useState<OrientationData>({
    heading: null,
    cardinal: 'S',
    supported: false,
  });

  useEffect(() => {
    const unsubBattery = batteryService.subscribe(setBattery);
    const unsubOrientation = orientationService.subscribe(setOrientation);
    orientationService.startListening();

    return () => {
      unsubBattery();
      unsubOrientation();
      orientationService.stopListening();
    };
  }, []);

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 w-full max-w-xl mx-auto px-4 py-2">
      {/* Battery indicator */}
      <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-slate-900/70 border border-slate-800/80">
        {battery.charging ? (
          <BatteryCharging className="w-4 h-4 text-emerald-400 shrink-0" />
        ) : (
          <Battery className="w-4 h-4 text-slate-400 shrink-0" />
        )}
        <div className="flex flex-col min-w-0">
          <span className="text-[10px] text-slate-500 uppercase font-semibold tracking-wider">
            Baterie
          </span>
          <span className="text-xs font-semibold text-slate-200 tabular-nums truncate">
            {battery.supported ? `${battery.level}%` : 'Napájeno'}
          </span>
        </div>
      </div>

      {/* Compass / Orientation */}
      <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-slate-900/70 border border-slate-800/80">
        <Compass className="w-4 h-4 text-sky-400 shrink-0" />
        <div className="flex flex-col min-w-0">
          <span className="text-[10px] text-slate-500 uppercase font-semibold tracking-wider">
            Azimut
          </span>
          <span className="text-xs font-semibold text-slate-200 tabular-nums truncate">
            {orientation.heading !== null
              ? `${orientation.heading}° · ${orientation.cardinal}`
              : 'Senzor aktivní'}
          </span>
        </div>
      </div>

      {/* Sleep Timer status button */}
      <button
        onClick={onOpenTimer}
        className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-slate-900/70 border border-slate-800/80 hover:border-slate-700 transition-colors cursor-pointer text-left"
      >
        <Timer
          className={`w-4 h-4 shrink-0 ${
            timerSecondsRemaining !== null ? 'text-amber-400 animate-pulse' : 'text-slate-400'
          }`}
        />
        <div className="flex flex-col min-w-0">
          <span className="text-[10px] text-slate-500 uppercase font-semibold tracking-wider">
            Časovač
          </span>
          <span className="text-xs font-semibold text-slate-200 tabular-nums truncate">
            {timerSecondsRemaining !== null ? formatTimer(timerSecondsRemaining) : 'Nastavit'}
          </span>
        </div>
      </button>

      {/* Hardware Torch / Screen status */}
      <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-slate-900/70 border border-slate-800/80">
        {torchActive ? (
          <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
        ) : (
          <Eye className="w-4 h-4 text-slate-400 shrink-0" />
        )}
        <div className="flex flex-col min-w-0">
          <span className="text-[10px] text-slate-500 uppercase font-semibold tracking-wider">
            Režim světla
          </span>
          <span className="text-xs font-semibold text-slate-200 truncate">
            {torchActive
              ? 'LED + Displej'
              : torchSupported
              ? 'Připraveno'
              : 'Světlo displeje'}
          </span>
        </div>
      </div>
    </div>
  );
};
