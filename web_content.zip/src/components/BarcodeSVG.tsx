import React from 'react';
import type { Product, StoreSettings } from '../types';
import { fmtMoney } from '../utils';

// ISO/IEC 16388 Code 39 Barcode Generator (100% Offline SVG)
const CODE39_MAP: Record<string, string> = {
  '0': 'nnnwwnwnn', '1': 'wnnwnnnnw', '2': 'nnwwnnnnw', '3': 'wnwwnnnnn',
  '4': 'nnnwwnnnw', '5': 'wnnwwnnnn', '6': 'nnwwwnnnn', '7': 'nnnwnnwnw',
  '8': 'wnnwnnwnn', '9': 'nnwwnnwnn', A: 'wnnnnwnnw', B: 'nnwnnwnnw',
  C: 'wnwnnwnnn', D: 'nnnnwwnnw', E: 'wnnnwwnnn', F: 'nnwnwwnnn',
  G: 'nnnnnwwnw', H: 'wnnnnwwnn', I: 'nnwnnwwnn', J: 'nnnnwwwnn',
  K: 'wnnnnnnww', L: 'nnwnnnnww', M: 'wnwnnnnwn', N: 'nnnnwnnww',
  O: 'wnnnwnnwn', P: 'nnwnwnnwn', Q: 'nnnnnnwww', R: 'wnnnnnwwn',
  S: 'nnwnnnwwn', T: 'nnnnwnwwn', U: 'wwnnnnnnw', V: 'nwwnnnnnw',
  W: 'wwwnnnnnn', X: 'nwnnwnnnw', Y: 'wwnnwnnnn', Z: 'nwwnwnnnn',
  '-': 'nwnnnnwnw', '.': 'wwnnnnwnn', ' ': 'nwwnnnwnn', '*': 'nwnnwnwnn',
  $: 'nwnwnwnnn', '/': 'nwnwnnnwn', '+': 'nwnnnwnwn', '%': 'nnnwnwnwn',
};

export const BarcodeSVG: React.FC<{ value?: string; height?: number }> = ({ value, height = 42 }) => {
  const clean = String(value || '')
    .toUpperCase()
    .split('')
    .filter((ch) => CODE39_MAP[ch] && ch !== '*')
    .join('');

  if (!clean) return null;

  const full = `*${clean}*`;
  const narrow = 1.6;
  const wide = 4.2;
  const gap = 1.6;
  let x = 10;
  const rects: { x: number; w: number }[] = [];

  for (let i = 0; i < full.length; i++) {
    const pat = CODE39_MAP[full[i]];
    for (let j = 0; j < 9; j++) {
      const w = pat[j] === 'w' ? wide : narrow;
      if (j % 2 === 0) rects.push({ x, w });
      x += w;
    }
    if (i < full.length - 1) x += gap;
  }

  const totalWidth = x + 10;

  return (
    <svg viewBox={`0 0 ${totalWidth} ${height}`} className="w-full max-w-[200px] mx-auto" style={{ height: `${height}px` }}>
      <rect x="0" y="0" width={totalWidth} height={height} fill="#ffffff" />
      {rects.map((r, idx) => (
        <rect key={idx} x={r.x} y={2} width={r.w} height={height - 4} fill="#000000" />
      ))}
    </svg>
  );
};

interface BarcodeLabelSheetProps {
  items: Product[];
  settings: StoreSettings;
  showPrice: boolean;
  showStore: boolean;
}

export const BarcodeLabelSheet: React.FC<BarcodeLabelSheetProps> = ({ items, settings, showPrice, showStore }) => (
  <div className="grid grid-cols-3 gap-3 p-2">
    {items.map((item, idx) => (
      <div key={idx} className="border border-dashed border-slate-400 rounded-lg p-2.5 text-center bg-white break-inside-avoid">
        {showStore && <p className="text-[10px] font-bold uppercase tracking-wider text-slate-700 truncate">{settings.storeName}</p>}
        <p className="text-[11px] font-bold text-slate-900 truncate mt-0.5">
          {item.name}
          {item.model ? ` (${item.model})` : ''}
        </p>
        <div className="my-1">
          <BarcodeSVG value={item.barcode || item.sku} height={38} />
        </div>
        <p className="text-[10px] font-mono tracking-widest text-slate-700 tabular-nums">{item.barcode || item.sku}</p>
        {showPrice && <p className="text-xs font-extrabold text-slate-900 mt-0.5 tabular-nums">{fmtMoney(item.sellingPrice)}</p>}
      </div>
    ))}
  </div>
);
