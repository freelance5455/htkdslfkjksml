import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Package, 
  Truck, 
  CheckCircle, 
  Clock, 
  MessageCircle, 
  RotateCcw, 
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  MapPin,
  ShoppingBag
} from 'lucide-react';
import { OrderRecord, CartItem } from '../types/ecommerce';
import { WHATSAPP_SUPPORT_NUMBER } from '../data/mockData';

interface OrdersHistoryScreenProps {
  orders: OrderRecord[];
  onBack: () => void;
  onReorder: (items: CartItem[]) => void;
  onOpenWhatsAppHelp: (orderNumber: string) => void;
  onContinueShopping: () => void;
}

export const OrdersHistoryScreen: React.FC<OrdersHistoryScreenProps> = ({
  orders,
  onBack,
  onReorder,
  onOpenWhatsAppHelp,
  onContinueShopping
}) => {
  const [filter, setFilter] = useState<'All' | 'Processing' | 'Out for Delivery' | 'Delivered'>('All');
  const [selectedTrackingOrder, setSelectedTrackingOrder] = useState<OrderRecord | null>(null);

  const filteredOrders = filter === 'All' 
    ? orders 
    : orders.filter(o => o.status === filter);

  const getStatusBadge = (status: OrderRecord['status']) => {
    switch (status) {
      case 'Delivered':
        return (
          <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1">
            <CheckCircle className="w-3 h-3 text-emerald-600" />
            <span>Delivered</span>
          </span>
        );
      case 'Out for Delivery':
        return (
          <span className="bg-blue-100 text-blue-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1">
            <Truck className="w-3 h-3 text-blue-600" />
            <span>Out for Delivery</span>
          </span>
        );
      case 'Shipped':
        return (
          <span className="bg-purple-100 text-purple-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1">
            <Package className="w-3 h-3 text-purple-600" />
            <span>Shipped</span>
          </span>
        );
      case 'Processing':
      default:
        return (
          <span className="bg-amber-100 text-amber-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1">
            <Clock className="w-3 h-3 text-amber-600" />
            <span>Processing</span>
          </span>
        );
    }
  };

  return (
    <div className="pb-24 bg-slate-100 min-h-screen">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md px-3 py-3 border-b border-slate-200 flex items-center justify-between">
        <button
          onClick={onBack}
          className="p-1 rounded-full hover:bg-slate-100 text-slate-700 transition-colors"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="text-sm font-bold text-slate-900">My Order History</h2>
        <div className="w-5"></div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white border-b border-slate-200 px-2 py-2 flex gap-1.5 overflow-x-auto scrollbar-none sticky top-12 z-20">
        {(['All', 'Processing', 'Out for Delivery', 'Delivered'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              filter === tab
                ? 'bg-[#FF6600] text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="p-2.5 space-y-3">
        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 shadow-2xs my-4">
            <div className="w-14 h-14 rounded-full bg-orange-100 text-[#FF6600] flex items-center justify-center mx-auto mb-3">
              <Package className="w-7 h-7" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">No Orders in this Status</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              Explore today&apos;s deals on SEWORA MART and enjoy fast delivery directly to your home.
            </p>
            <button
              onClick={onContinueShopping}
              className="mt-4 bg-[#FF6600] text-white text-xs font-bold px-5 py-2 rounded-xl shadow-md hover:bg-orange-600 transition-colors"
            >
              Start Shopping
            </button>
          </div>
        ) : (
          filteredOrders.map((order) => (
            <div
              key={order.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden"
            >
              {/* Order Card Header */}
              <div className="p-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <span className="font-mono font-bold text-slate-900">{order.orderNumber}</span>
                  <span className="text-[11px] text-slate-400 block">{order.date}</span>
                </div>
                {getStatusBadge(order.status)}
              </div>

              {/* Items List */}
              <div className="divide-y divide-slate-100 p-3 space-y-2.5">
                {order.items.map((it) => (
                  <div key={it.id} className="flex items-center gap-2.5 pt-1">
                    <img
                      src={it.product.images[0]}
                      alt={it.product.title}
                      className="w-12 h-12 rounded-lg object-cover border border-slate-200 shrink-0"
                    />
                    <div className="flex-1 min-w-0 text-xs">
                      <h4 className="font-semibold text-slate-900 truncate">{it.product.title}</h4>
                      <p className="text-[10px] text-slate-400">
                        Qty: {it.quantity} · {it.selectedColor || ''} {it.selectedSize ? `(${it.selectedSize})` : ''}
                      </p>
                      <span className="font-bold text-slate-800 tabular-nums">
                        Rs. {(it.product.price * it.quantity).toLocaleString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Order Total & Actions */}
              <div className="px-3 py-2.5 bg-slate-50/50 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Total Paid</span>
                  <div className="font-extrabold text-sm text-[#FF6600] tabular-nums">
                    Rs. {order.totalAmount.toLocaleString()}
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {/* WhatsApp Support Button */}
                  <button
                    onClick={() => onOpenWhatsAppHelp(order.orderNumber)}
                    className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 transition-colors flex items-center gap-1 text-[11px] font-bold"
                    title="Ask on WhatsApp"
                  >
                    <MessageCircle className="w-3.5 h-3.5 fill-[#25D366] text-[#25D366]" />
                    <span className="hidden sm:inline">WhatsApp Help</span>
                  </button>

                  {/* Track Timeline Button */}
                  <button
                    onClick={() => setSelectedTrackingOrder(order)}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-[11px] font-bold transition-colors flex items-center gap-1"
                  >
                    <Truck className="w-3 h-3" />
                    <span>Track</span>
                  </button>

                  {/* Reorder Button */}
                  <button
                    onClick={() => onReorder(order.items)}
                    className="px-2.5 py-1.5 rounded-lg bg-orange-50 hover:bg-orange-100 text-[#FF6600] border border-orange-200 text-[11px] font-bold transition-colors flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reorder</span>
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Live Tracking Modal */}
      {selectedTrackingOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl relative space-y-4">
            <button
              onClick={() => setSelectedTrackingOrder(null)}
              className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 p-1"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <div>
              <span className="text-[10px] font-mono font-bold text-[#FF6600] uppercase">Live Tracking</span>
              <h3 className="text-sm font-black text-slate-900">
                Order {selectedTrackingOrder.orderNumber}
              </h3>
              <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                Tracking: {selectedTrackingOrder.trackingNumber}
              </p>
            </div>

            {/* Vertical timeline */}
            <div className="relative pl-6 space-y-4 pt-1">
              <div className="absolute left-2.5 top-3 bottom-3 w-0.5 bg-slate-200"></div>

              {[
                { title: 'Order Confirmed', time: 'Oct 31, 10:14 AM', done: true, icon: CheckCircle },
                { title: 'Warehouse Processing & Quality Check', time: 'Oct 31, 01:30 PM', done: true, icon: Package },
                { title: 'Dispatched with Courier Partner', time: 'In Transit', done: selectedTrackingOrder.status !== 'Processing', icon: Truck },
                { title: 'Delivered to Doorstep', time: 'Pending Delivery', done: selectedTrackingOrder.status === 'Delivered', icon: MapPin }
              ].map((step, idx) => {
                const Icon = step.icon;
                return (
                  <div key={idx} className="relative flex items-start gap-3">
                    <div className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center z-10 ${
                      step.done ? 'bg-[#FF6600] text-white shadow-xs' : 'bg-slate-200 text-slate-400'
                    }`}>
                      <Icon className="w-3 h-3" />
                    </div>
                    <div>
                      <div className={`text-xs font-bold ${step.done ? 'text-slate-900' : 'text-slate-400'}`}>
                        {step.title}
                      </div>
                      <div className="text-[10px] text-slate-400">{step.time}</div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl text-[11px] text-slate-600">
              📍 Destination: <strong>{selectedTrackingOrder.address.name}</strong>, {selectedTrackingOrder.address.addressLine}, {selectedTrackingOrder.address.city}.
            </div>

            <button
              onClick={() => setSelectedTrackingOrder(null)}
              className="w-full py-2.5 bg-slate-900 text-white text-xs font-bold rounded-xl"
            >
              Close Tracking
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
