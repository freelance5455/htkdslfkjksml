/**
 * GODEX Phase 3 - Flagship AI Command Center & Coding Agent Interface
 * Features:
 * 1. Conversational Chat Stream (Grounded answers, epistemic summary, progress)
 * 2. Structured Task Plan (Plan visualization, DAG phases, step statuses)
 * 3. Safe Approval & Boundary Controls (Apply, Reject, Rollback, Stale-safe)
 * 4. Diff & Patch Viewer (Unified diffs, +additions / -deletions, secret masking)
 * 5. Deterministic Simulation & Test Suite (10-point test matrix runner)
 * 6. Context Inspector & AI Request Telemetry
 * 7. Multi-Agent Matrix
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  ListChecks, 
  Activity, 
  Users, 
  Play, 
  CheckCircle2, 
  Circle, 
  AlertCircle, 
  Zap, 
  Layers, 
  Cpu, 
  ShieldAlert, 
  FileCode, 
  TerminalSquare, 
  Clock, 
  Plus, 
  Check, 
  RotateCcw,
  MessageSquarePlus,
  ChevronRight,
  ChevronDown,
  Filter,
  Copy,
  ExternalLink,
  ShieldCheck,
  Brain as BrainIcon,
  Compass,
  FileSearch,
  Hash,
  FileText,
  Sliders,
  HelpCircle,
  Code,
  GitPullRequest,
  CheckCheck,
  XCircle,
  Undo2,
  TestTube
} from 'lucide-react';
import { 
  ChatMessage, 
  TaskState, 
  ExecutionMode, 
  ActivityLogItem, 
  AICenterTab, 
  GodexAgentDefinition, 
  AgentTask as UiAgentTask, 
  VerificationReport 
} from '../types';
import { Brain } from '../intelligence/godexBrain';
import { ContextPack, AIRequestInspectData } from '../intelligence/contextTypes';
import { CodingAgent } from '../coding/codingAgent';
import { AgentTask as CodingTask, FileEditOperation, ValidationResult } from '../coding/agentTypes';
import { SimulationTestSuite, FullTestSuiteResult } from '../coding/simulationTest';
import { GodexOrchestrator } from '../orchestration/orchestrator';
import { 
  OrchestrationSession, 
  OrchestrationTask, 
  AgentArtifact, 
  AgentConflict, 
  TaskGraphNode, 
  AgentDefinition 
} from '../orchestration/orchestrationTypes';
import { SimulationOrchestrationTestSuite, OrchestrationTestSuiteSummary } from '../orchestration/simulationOrchestrationTest';
import { GodexControlPlane } from '../godex/godexControlPlane';
import { OperationState, OperationTaskItem, OperationAgentItem } from '../godex/operationState';
import { GodexEventBus } from '../godex/godexEventBus';
import { GodexChatView } from './GodexChatView';

interface GodexAICenterProps {
  messages: ChatMessage[];
  taskState: TaskState;
  executionMode: ExecutionMode;
  activityLogs: ActivityLogItem[];
  verificationReport: VerificationReport | null;
  onSendMessage: (prompt: string) => void;
  onClearChat: () => void;
  onToggleExecutionMode: () => void;
  onSelectFile?: (path: string) => void;
  onFilesModified?: (newFiles: Record<string, string>, diffs: any[]) => void;
  projectFiles?: Record<string, string>;
}

export const GodexAICenter: React.FC<GodexAICenterProps> = ({
  messages,
  taskState,
  executionMode,
  activityLogs,
  verificationReport,
  onSendMessage,
  onClearChat,
  onToggleExecutionMode,
  onSelectFile,
  onFilesModified,
  projectFiles = {}
}) => {
  const [activeTab, setActiveTab] = useState<AICenterTab>('chat');
  const [inputText, setInputText] = useState('');
  const [expandedTaskId, setExpandedTaskId] = useState<string | null>('step-1');
  const [activityFilter, setActivityFilter] = useState<'all' | 'mutation' | 'ast' | 'verify'>('all');
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);
  const [latestContextPack, setLatestContextPack] = useState<ContextPack | null>(null);
  const [latestInspectData, setLatestInspectData] = useState<AIRequestInspectData | null>(null);
  const [expandedFileWhy, setExpandedFileWhy] = useState<string | null>(null);
  
  // Authoritative Phase 9 Control Plane State
  const [controlPlaneState, setControlPlaneState] = useState<OperationState>(() => {
    return GodexControlPlane.getInstance().getState();
  });

  // Phase 3 Coding Agent State
  const [codingTask, setCodingTask] = useState<CodingTask | null>(null);
  const [selectedDiffOpId, setSelectedDiffOpId] = useState<string | null>(null);
  const [testSuiteResult, setTestSuiteResult] = useState<FullTestSuiteResult | null>(null);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [rollbackStatusMessage, setRollbackStatusMessage] = useState<string | null>(null);

  // Phase 6 Multi-Agent Orchestration State
  const [orchestrationSession, setOrchestrationSession] = useState<OrchestrationSession | null>(() => {
    return GodexOrchestrator.getInstance().getActiveSession();
  });
  const [selectedOrchTaskId, setSelectedOrchTaskId] = useState<string | null>(null);
  const [selectedOrchArtifactId, setSelectedOrchArtifactId] = useState<string | null>(null);
  const [orchestrationSuiteResult, setOrchestrationSuiteResult] = useState<OrchestrationTestSuiteSummary | null>(null);
  const [isRunningOrchSuite, setIsRunningOrchSuite] = useState(false);
  const [customOrchObjective, setCustomOrchObjective] = useState('');
  const [isStartingOrchestration, setIsStartingOrchestration] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isWorking = taskState !== 'IDLE' && taskState !== 'COMPLETED' && taskState !== 'FAILED';

  useEffect(() => {
    // Subscribe to Authoritative Control Plane
    const unsubControlPlane = GodexControlPlane.getInstance().subscribe((state) => {
      setControlPlaneState(state);
    });

    // Initial sync with Brain
    const latest = Brain.getLatestResult();
    if (latest) {
      if (latest.contextPack) setLatestContextPack(latest.contextPack);
      if (latest.inspectData) setLatestInspectData(latest.inspectData);
    }

    // Subscribe to Brain events
    const unsubBrain = Brain.subscribeEvents(() => {
      const updated = Brain.getLatestResult();
      if (updated) {
        if (updated.contextPack) setLatestContextPack(updated.contextPack);
        if (updated.inspectData) setLatestInspectData(updated.inspectData);
      }
    });

    // Subscribe to Phase 3 Coding Agent events
    const unsubCoding = CodingAgent.subscribe((task) => {
      setCodingTask(task);
      if (task.proposedChanges.length > 0 && !selectedDiffOpId) {
        setSelectedDiffOpId(task.proposedChanges[0].id);
      }
    });

    // Subscribe to Phase 6 Multi-Agent Orchestrator events
    const orchestrator = GodexOrchestrator.getInstance();
    const unsubOrch = orchestrator.subscribe((session) => {
      setOrchestrationSession(session);
      const taskIds = Object.keys(session.taskGraph.nodes);
      if (taskIds.length > 0 && !selectedOrchTaskId) {
        setSelectedOrchTaskId(taskIds[0]);
      }
    });

    return () => {
      unsubControlPlane();
      unsubBrain();
      unsubCoding();
      unsubOrch();
    };
  }, [selectedDiffOpId, selectedOrchTaskId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, taskState, codingTask]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isWorking) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 1500);
  };

  const handleApproveChanges = async () => {
    try {
      const cp = GodexControlPlane.getInstance();
      const res = cp.approvePendingEdits();
      if (res.updatedFiles && onFilesModified) {
        onFilesModified(res.updatedFiles, []);
      }
      if (codingTask) {
        await CodingAgent.approvePendingChanges(projectFiles);
      }
    } catch (err: any) {
      alert(`Approval execution failed: ${err.message}`);
    }
  };

  const handleRejectChanges = () => {
    GodexControlPlane.getInstance().rejectPendingEdits();
    CodingAgent.rejectPendingChanges();
  };

  const handleRollback = () => {
    const res = GodexControlPlane.getInstance().rollbackLastOperation(projectFiles);
    setRollbackStatusMessage(res.message);
    if (res.success && onFilesModified) {
      onFilesModified(res.restoredFiles, []);
    }
    CodingAgent.rollbackCurrentTask(projectFiles);
    setTimeout(() => setRollbackStatusMessage(null), 4000);
  };

  const handleRunSimulationTests = async () => {
    setIsRunningTests(true);
    try {
      const results = await SimulationTestSuite.runAllTests();
      setTestSuiteResult(results);
      GodexControlPlane.getInstance().runTestSuite(projectFiles);
    } finally {
      setIsRunningTests(false);
    }
  };

  const handleRunOrchestrationSuite = async () => {
    setIsRunningOrchSuite(true);
    try {
      const results = await SimulationOrchestrationTestSuite.runAllTests();
      setOrchestrationSuiteResult(results);
    } finally {
      setIsRunningOrchSuite(false);
    }
  };

  const handleStartCustomOrchestration = async () => {
    if (!customOrchObjective.trim() || isStartingOrchestration) return;
    setIsStartingOrchestration(true);
    try {
      const cp = GodexControlPlane.getInstance();
      const res = await cp.executeOperation(customOrchObjective.trim(), projectFiles, {
        onFilesMutated: (newFiles, diffs) => {
          if (onFilesModified) {
            onFilesModified(newFiles, diffs.map(d => ({ path: d.filePath, additions: d.additions, deletions: d.deletions })));
          }
        }
      });
      setCustomOrchObjective('');
    } catch (err: any) {
      alert(`Orchestration failed: ${err.message}`);
    } finally {
      setIsStartingOrchestration(false);
    }
  };

  const handleApproveOrchTask = async (taskId: string) => {
    const orchestrator = GodexOrchestrator.getInstance();
    await orchestrator.approveTask(taskId, projectFiles, (newFiles) => {
      if (onFilesModified) {
        onFilesModified(newFiles, []);
      }
    });
  };

  const handleRejectOrchTask = (taskId: string) => {
    const orchestrator = GodexOrchestrator.getInstance();
    orchestrator.rejectTask(taskId);
  };

  // Agent Matrix definitions
  const godexAgents: GodexAgentDefinition[] = [
    {
      id: 'agent-nlu',
      name: 'Understanding Agent',
      role: 'Understanding Agent',
      title: 'Intent & Task Extractor',
      description: 'Understands multi-turn natural language instructions, detects language, extracts target entities and user goals.',
      capabilities: ['Intent Classification', 'Anaphora Resolution', 'Constraint Detection'],
      status: taskState === 'ANALYZING' ? 'active' : 'idle',
      color: 'border-cyan-500/40 text-cyan-300 bg-cyan-950/30',
      iconName: 'bot',
      model: 'gemini-3.7-flash'
    },
    {
      id: 'agent-planner',
      name: 'Planner Agent',
      role: 'Planner',
      title: 'DAG Task Planner',
      description: 'Formulates structured, reversible implementation plans with explicit step-by-step verification milestones.',
      capabilities: ['Step Decomposition', 'Dependency Mapping', 'Risk Assessment'],
      status: taskState === 'PLANNING' ? 'active' : 'idle',
      color: 'border-amber-500/40 text-amber-300 bg-amber-950/30',
      iconName: 'list',
      model: 'gemini-3.7-flash'
    },
    {
      id: 'agent-coder',
      name: 'Coding Agent',
      role: 'Coding Agent',
      title: 'Safe Edit Engine',
      description: 'Executes atomic patches, verifies hash baselines, detects stale edits, and prevents unapproved destructive changes.',
      capabilities: ['Atomic Patching', 'Stale Edit Protection', 'Style Preservation'],
      status: taskState === 'CODING' || codingTask?.status === 'EDITING' ? 'active' : 'idle',
      color: 'border-indigo-500/40 text-indigo-300 bg-indigo-950/30',
      iconName: 'code',
      model: 'gemini-3.7-flash'
    },
    {
      id: 'agent-verifier',
      name: 'Validation & Verification Agent',
      role: 'Final Verifier',
      title: 'Evidence Gatekeeper',
      description: 'Runs AST syntax checks, TypeScript module resolution, real package scripts, and root-cause failure diagnosis.',
      capabilities: ['AST Integrity', 'Script Discovery', 'Failure Diagnosis'],
      status: taskState === 'VERIFYING' || codingTask?.status === 'VALIDATING' ? 'active' : 'idle',
      color: 'border-emerald-500/40 text-emerald-300 bg-emerald-950/30',
      iconName: 'shield',
      model: 'gemini-3.7-flash'
    }
  ];

  const samplePrompts = [
    { label: 'Add validateUser() Function', text: 'Add a validateUser() function to validate user email and name structure.' },
    { label: 'Password Reset Service', text: 'Implement a secure password reset token service with expiry and token validation.' },
    { label: 'Responsive Notes App', text: 'Build a full responsive notes application with categories, search, pinned notes, and color themes' }
  ];

  const getStateBadge = () => {
    const s = codingTask?.status || taskState;
    switch (s) {
      case 'IDLE': return { label: 'Ready', color: 'bg-emerald-950/60 text-emerald-300 border-emerald-800/80' };
      case 'COMPLETED': return { label: 'Completed', color: 'bg-emerald-950/60 text-emerald-300 border-emerald-800/80' };
      case 'FAILED': return { label: 'Failed', color: 'bg-rose-950/60 text-rose-300 border-rose-800/80' };
      case 'AWAITING_APPROVAL': return { label: 'Approval Required', color: 'bg-amber-950/90 text-amber-300 border-amber-600 animate-pulse' };
      case 'EDITING': return { label: 'Applying Edits', color: 'bg-indigo-950/60 text-indigo-300 border-indigo-800/80' };
      case 'VALIDATING': return { label: 'Running Validations', color: 'bg-cyan-950/60 text-cyan-300 border-cyan-800/80' };
      case 'DIFF_READY': return { label: 'Diff Ready', color: 'bg-blue-950/60 text-blue-300 border-blue-800/80' };
      default: return { label: s, color: 'bg-cyan-950/60 text-cyan-300 border-cyan-800/80' };
    }
  };

  const currentBadge = getStateBadge();

  // Filtered activity logs
  const filteredActivityLogs = activityLogs.filter(log => {
    if (activityFilter === 'mutation') return log.diff || log.action.toLowerCase().includes('file') || log.action.toLowerCase().includes('write');
    if (activityFilter === 'ast') return log.action.toLowerCase().includes('ast') || log.action.toLowerCase().includes('build') || log.action.toLowerCase().includes('transpile');
    if (activityFilter === 'verify') return log.action.toLowerCase().includes('verify') || log.action.toLowerCase().includes('test') || log.action.toLowerCase().includes('dom');
    return true;
  });

  const activeDiffOp = codingTask?.proposedChanges.find(op => op.id === selectedDiffOpId) || codingTask?.proposedChanges[0];

  return (
    <div className="flex-1 h-full flex flex-col bg-[#090B10] border-l border-[#1A2234] overflow-hidden select-none font-sans">
      {/* AI Command Center Header */}
      <div className="h-10 border-b border-[#1A2234] bg-[#0C1018] px-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-md bg-gradient-to-tr from-cyan-600 via-indigo-600 to-blue-700 flex items-center justify-center text-white shadow-xs">
            <Bot className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-bold text-white tracking-wide">AI COMMAND CENTER</span>
          <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded border text-[10px] font-mono font-semibold ${currentBadge.color}`}>
            <span className={`w-1.5 h-1.5 rounded-full bg-current ${isWorking ? 'animate-ping' : ''}`} />
            <span>{currentBadge.label}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {codingTask?.rollbackAvailable && (
            <button
              onClick={handleRollback}
              className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-rose-950/60 border border-rose-800 text-rose-300 hover:bg-rose-900 transition-colors"
              title="Rollback last task to pre-execution state"
            >
              <Undo2 className="w-3 h-3 text-rose-400" />
              <span>ROLLBACK</span>
            </button>
          )}

          <button
            onClick={onToggleExecutionMode}
            className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-medium border transition-colors ${
              executionMode === 'autopilot'
                ? 'bg-cyan-950/60 border-cyan-700/60 text-cyan-300'
                : 'bg-neutral-900 border-neutral-700 text-neutral-400'
            }`}
            title="Toggle Autopilot / Copilot"
          >
            <Zap className="w-3 h-3 text-cyan-400" />
            <span>{executionMode.toUpperCase()}</span>
          </button>

          <button
            onClick={onClearChat}
            className="p-1 rounded hover:bg-[#161F2E] text-neutral-400 hover:text-neutral-200 transition-colors"
            title="New Chat Session"
          >
            <MessageSquarePlus className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Sub-View Tabs */}
      <div className="h-8 border-b border-[#182030] bg-[#0A0D15] px-2 flex items-center gap-1 shrink-0 font-mono text-[11px] overflow-x-auto">
        <button
          onClick={() => setActiveTab('orchestration')}
          className={`flex items-center gap-1 px-2 py-1 rounded transition-colors whitespace-nowrap ${
            activeTab === 'orchestration'
              ? 'bg-[#151D2C] text-cyan-300 font-bold border border-cyan-500/40 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Cpu className="w-3 h-3 text-cyan-400" />
          <span>Orchestration</span>
          {orchestrationSession && (
            <span className={`text-[9px] px-1 rounded-full border ${
              orchestrationSession.status === 'COMPLETED'
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800/40'
                : orchestrationSession.status === 'AWAITING_APPROVAL'
                ? 'bg-amber-950/60 text-amber-300 border-amber-800/40 animate-pulse'
                : 'bg-cyan-950/60 text-cyan-300 border-cyan-800/40'
            }`}>
              {orchestrationSession.status}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('chat')}
          className={`flex items-center gap-1 px-2 py-1 rounded transition-colors whitespace-nowrap ${
            activeTab === 'chat'
              ? 'bg-[#151D2C] text-cyan-300 font-bold border border-cyan-500/40 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Sparkles className="w-3 h-3 text-cyan-400" />
          <span>Chat</span>
        </button>

        <button
          onClick={() => setActiveTab('plan')}
          className={`flex items-center gap-1 px-2 py-1 rounded transition-colors whitespace-nowrap ${
            activeTab === 'plan'
              ? 'bg-[#151D2C] text-cyan-300 font-bold border border-cyan-500/40 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <ListChecks className="w-3 h-3 text-amber-400" />
          <span>Task Tree</span>
          {codingTask?.plan && (
            <span className="text-[9px] px-1 rounded-full bg-amber-950/60 text-amber-300 border border-amber-800/40">
              {codingTask.plan.steps.filter(s => s.status === 'completed').length}/{codingTask.plan.steps.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('diff')}
          className={`flex items-center gap-1 px-2 py-1 rounded transition-colors whitespace-nowrap ${
            activeTab === 'diff'
              ? 'bg-[#151D2C] text-cyan-300 font-bold border border-cyan-500/40 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <GitPullRequest className="w-3 h-3 text-indigo-400" />
          <span>Diff & Safe Edits</span>
          {codingTask?.proposedChanges && codingTask.proposedChanges.length > 0 && (
            <span className="text-[9px] px-1 rounded-full bg-indigo-950/60 text-indigo-300 border border-indigo-800/40">
              {codingTask.proposedChanges.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('simulation')}
          className={`flex items-center gap-1 px-2 py-1 rounded transition-colors whitespace-nowrap ${
            activeTab === 'simulation'
              ? 'bg-[#151D2C] text-cyan-300 font-bold border border-cyan-500/40 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <TestTube className="w-3 h-3 text-emerald-400" />
          <span>Test Suite</span>
        </button>

        <button
          onClick={() => setActiveTab('context')}
          className={`flex items-center gap-1 px-2 py-1 rounded transition-colors whitespace-nowrap ${
            activeTab === 'context'
              ? 'bg-[#151D2C] text-cyan-300 font-bold border border-cyan-500/40 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Compass className="w-3 h-3 text-emerald-400" />
          <span>Context</span>
        </button>

        <button
          onClick={() => setActiveTab('activity')}
          className={`flex items-center gap-1 px-2 py-1 rounded transition-colors whitespace-nowrap ${
            activeTab === 'activity'
              ? 'bg-[#151D2C] text-cyan-300 font-bold border border-cyan-500/40 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Activity className="w-3 h-3 text-purple-400" />
          <span>Telemetry</span>
        </button>

        <button
          onClick={() => setActiveTab('agents')}
          className={`flex items-center gap-1 px-2 py-1 rounded transition-colors whitespace-nowrap ${
            activeTab === 'agents'
              ? 'bg-[#151D2C] text-cyan-300 font-bold border border-cyan-500/40 shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Users className="w-3 h-3 text-indigo-400" />
          <span>Matrix</span>
        </button>
      </div>

      {/* Security Approval Banner */}
      {codingTask?.status === 'AWAITING_APPROVAL' && (
        <div className="p-3 bg-amber-950/70 border-b border-amber-600/80 text-amber-200 space-y-2 shrink-0">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
            <div className="text-xs font-bold font-sans">
              Approval Required: {codingTask.plan?.approvalReason || 'Destructive or large change proposed'}
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] font-mono pt-1">
            <span>
              Targeting: <strong className="text-white">{codingTask.proposedChanges.map(c => c.target).join(', ')}</strong>
            </span>
            <span className="text-emerald-400 font-bold">
              +{codingTask.proposedChanges.reduce((a, b) => a + b.additions, 0)} / -{codingTask.proposedChanges.reduce((a, b) => a + b.deletions, 0)} lines
            </span>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleApproveChanges}
              className="flex-1 py-1 px-2.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1 shadow-sm"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Approve & Apply</span>
            </button>

            <button
              onClick={handleRejectChanges}
              className="py-1 px-3 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-semibold transition-colors flex items-center gap-1"
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>Reject</span>
            </button>

            <button
              onClick={() => setActiveTab('diff')}
              className="py-1 px-2.5 rounded bg-amber-900/60 hover:bg-amber-800 border border-amber-700 text-amber-200 text-xs font-semibold transition-colors"
            >
              Inspect Diff
            </button>
          </div>
        </div>
      )}

      {/* Rollback Notification */}
      {rollbackStatusMessage && (
        <div className="p-2.5 bg-rose-950/80 border-b border-rose-700 text-rose-200 text-xs font-mono flex items-center gap-2">
          <RotateCcw className="w-3.5 h-3.5 text-rose-400 shrink-0" />
          <span>{rollbackStatusMessage}</span>
        </div>
      )}

      {/* Tab 0: Phase 6 Multi-Agent Orchestration Control Plane */}
      {activeTab === 'orchestration' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4 font-sans text-xs select-text">
          {/* Header & Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#182030]">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-white text-sm flex items-center gap-1.5">
                  <Cpu className="w-4 h-4 text-cyan-400" />
                  <span>Engineering Control Plane</span>
                </span>
                {orchestrationSession && (
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                    orchestrationSession.status === 'COMPLETED'
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700'
                      : orchestrationSession.status === 'AWAITING_APPROVAL'
                      ? 'bg-amber-950/80 text-amber-300 border-amber-600 animate-pulse'
                      : orchestrationSession.status === 'FAILED'
                      ? 'bg-rose-950/80 text-rose-300 border-rose-700'
                      : 'bg-cyan-950/80 text-cyan-300 border-cyan-700'
                  }`}>
                    {orchestrationSession.status}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-neutral-400 font-sans mt-0.5">
                Central DAG Orchestrator governing 7 specialized agents with capability policies, resource locks, and truth verification.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleRunOrchestrationSuite}
                disabled={isRunningOrchSuite}
                className="py-1.5 px-3 rounded-lg bg-[#141C2B] hover:bg-[#1D273B] text-cyan-300 hover:text-cyan-200 border border-cyan-800/60 font-bold text-[11px] font-mono transition-colors inline-flex items-center gap-1.5"
                title="Run Deterministic 12-point Quality Gate"
              >
                <TestTube className="w-3.5 h-3.5 text-cyan-400" />
                <span>{isRunningOrchSuite ? 'Testing...' : 'Run Phase 6 Suite'}</span>
              </button>
            </div>
          </div>

          {/* Test Suite Results Banner */}
          {orchestrationSuiteResult && (
            <div className="p-3.5 rounded-xl bg-[#0B0F19] border border-cyan-900/60 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-white text-xs">Phase 6 Multi-Agent Quality Gate</span>
                </div>
                <div className="flex items-center gap-2 font-mono text-[11px]">
                  <span className="text-emerald-400 font-bold">{orchestrationSuiteResult.passedTests}/{orchestrationSuiteResult.totalTests} Passed</span>
                  <span className="text-neutral-500">({orchestrationSuiteResult.durationMs}ms)</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                {orchestrationSuiteResult.cases.map(c => (
                  <div
                    key={c.id}
                    className="p-2 rounded-lg bg-[#090C14] border border-[#161E2E] flex items-start gap-2 text-[10px]"
                  >
                    {c.passed ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-neutral-200 truncate">{c.name}</div>
                      <div className="text-neutral-500 text-[9px] line-clamp-1">{c.details}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Start New Orchestration Dispatcher */}
          <div className="p-3 rounded-xl bg-[#0C101A] border border-[#1A2336] space-y-2">
            <div className="text-[11px] font-bold text-neutral-200">Dispatch Multi-Agent Engineering Objective</div>
            <div className="flex gap-2">
              <input
                type="text"
                value={customOrchObjective}
                onChange={(e) => setCustomOrchObjective(e.target.value)}
                placeholder="e.g. Implement thread-safe token manager with failure retry..."
                className="flex-1 px-3 py-1.5 rounded-lg bg-[#070A10] border border-[#1C263A] text-neutral-200 text-xs focus:outline-none focus:border-cyan-500 font-sans"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleStartCustomOrchestration();
                }}
              />
              <button
                onClick={handleStartCustomOrchestration}
                disabled={!customOrchObjective.trim() || isStartingOrchestration}
                className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-bold text-xs transition-colors inline-flex items-center gap-1.5 shrink-0"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>{isStartingOrchestration ? 'Dispatching...' : 'Dispatch Swarm'}</span>
              </button>
            </div>
          </div>

          {/* Active Session Content */}
          {!orchestrationSession ? (
            <div className="p-8 text-center space-y-3 rounded-xl border border-dashed border-[#182234] bg-[#080B12]">
              <Cpu className="w-8 h-8 text-neutral-500 mx-auto" />
              <div className="space-y-1">
                <div className="font-bold text-neutral-300 text-sm">No Active Multi-Agent Session</div>
                <p className="text-[11px] text-neutral-500 max-w-sm mx-auto">
                  Type an engineering objective above or run the Phase 6 test suite to observe deterministic agent collaboration.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Human Approval Gate Alert */}
              {orchestrationSession.status === 'AWAITING_APPROVAL' && (
                <div className="p-3.5 rounded-xl bg-amber-950/70 border border-amber-600/80 space-y-2.5">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                    <div className="font-bold text-amber-200 text-xs font-sans">
                      Human Review Gate: High-Risk / Security Sensitive Operation
                    </div>
                  </div>
                  <p className="text-[11px] text-amber-300/90 leading-relaxed font-sans">
                    The orchestrator has paused execution because one or more tasks target security-sensitive modules or high-risk mutations.
                  </p>

                  <div className="flex items-center gap-2 pt-1">
                    {(Object.values(orchestrationSession.taskGraph.nodes) as TaskGraphNode[])
                      .filter(n => n.task.approvalRequired && !n.task.approved)
                      .map(n => (
                        <div key={n.task.id} className="flex items-center gap-2">
                          <button
                            onClick={() => handleApproveOrchTask(n.task.id)}
                            className="py-1 px-3 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors inline-flex items-center gap-1 shadow-xs"
                          >
                            <CheckCheck className="w-3.5 h-3.5" />
                            <span>Approve '{n.task.title}'</span>
                          </button>
                          <button
                            onClick={() => handleRejectOrchTask(n.task.id)}
                            className="py-1 px-2.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs transition-colors inline-flex items-center gap-1"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {/* Resource Conflict Warning */}
              {orchestrationSession.conflicts.length > 0 && (
                <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700/80 space-y-1.5">
                  <div className="flex items-center gap-2 text-rose-300 font-bold text-xs">
                    <AlertCircle className="w-4 h-4 text-rose-400" />
                    <span>Resource Conflicts Detected ({orchestrationSession.conflicts.length})</span>
                  </div>
                  <div className="space-y-1 font-mono text-[10px]">
                    {orchestrationSession.conflicts.map((conf, ci) => (
                      <div key={ci} className="p-1.5 rounded bg-[#100A12] border border-rose-900/60 text-rose-200 flex items-center justify-between">
                        <span>[{conf.type}] {conf.resourceId || (conf as any).resource}</span>
                        <span className="text-neutral-400">{conf.resolution || (conf as any).resolutionStrategy || 'SERIALIZE'}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 7 Specialized Agents Status Matrix */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-neutral-200">Active Specialized Agents</span>
                  <span className="text-neutral-500 font-mono">Max Concurrency: {orchestrationSession.maxConcurrentAgents}</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-1.5 font-mono text-[10px]">
                  {(Object.values(orchestrationSession.activeAgents) as AgentDefinition[]).map(ag => (
                    <div
                      key={ag.id}
                      className={`p-2 rounded-lg border transition-all ${
                        ag.status === 'RUNNING'
                          ? 'bg-cyan-950/50 border-cyan-500 text-cyan-200 shadow-xs'
                          : ag.status === 'COMPLETED'
                          ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                          : ag.status === 'BLOCKED'
                          ? 'bg-amber-950/40 border-amber-600 text-amber-300'
                          : ag.status === 'FAILED'
                          ? 'bg-rose-950/40 border-rose-700 text-rose-300'
                          : 'bg-[#0A0D15] border-[#182030] text-neutral-400'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold">{ag.role}</span>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          ag.status === 'RUNNING' ? 'bg-cyan-400 animate-ping' : ag.status === 'COMPLETED' ? 'bg-emerald-400' : 'bg-neutral-600'
                        }`} />
                      </div>
                      <div className="text-[9px] text-neutral-500 pt-0.5 truncate">{ag.status}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* DAG Task Graph */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-neutral-200">Task Dependency Graph (DAG)</span>
                  <span className="text-neutral-400 font-mono text-[10px]">
                    {(Object.values(orchestrationSession.taskGraph.nodes) as TaskGraphNode[]).filter(n => n.task.status === 'COMPLETED').length} / {Object.keys(orchestrationSession.taskGraph.nodes).length} Done
                  </span>
                </div>

                <div className="space-y-2">
                  {(Object.values(orchestrationSession.taskGraph.nodes) as TaskGraphNode[]).map(node => {
                    const isSelected = selectedOrchTaskId === node.task.id;
                    return (
                      <div
                        key={node.task.id}
                        onClick={() => setSelectedOrchTaskId(node.task.id)}
                        className={`p-3 rounded-xl border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#111726] border-cyan-500 shadow-md ring-1 ring-cyan-500/50'
                            : 'bg-[#0B0E16] border-[#182030] hover:border-[#222E44]'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2">
                            {node.task.status === 'COMPLETED' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                            {node.task.status === 'RUNNING' && <Circle className="w-4 h-4 text-cyan-400 animate-pulse shrink-0" />}
                            {node.task.status === 'READY' && <Play className="w-4 h-4 text-amber-400 shrink-0" />}
                            {node.task.status === 'QUEUED' && <Clock className="w-4 h-4 text-neutral-500 shrink-0" />}
                            {node.task.status === 'BLOCKED' && <AlertCircle className="w-4 h-4 text-amber-500 shrink-0" />}
                            {node.task.status === 'FAILED' && <XCircle className="w-4 h-4 text-rose-500 shrink-0" />}

                            <div>
                              <div className="font-bold text-white text-xs">{node.task.title}</div>
                              <div className="text-[10px] text-neutral-400 font-mono">
                                Role: <strong className="text-cyan-300">{node.task.role}</strong> · Priority: {node.task.priority} · Risk: {node.task.risk}
                              </div>
                            </div>
                          </div>

                          <span className={`text-[9px] font-mono px-2 py-0.5 rounded uppercase font-bold border ${
                            node.task.status === 'COMPLETED'
                              ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                              : node.task.status === 'RUNNING'
                              ? 'bg-cyan-950/60 text-cyan-300 border-cyan-800 animate-pulse'
                              : node.task.status === 'BLOCKED'
                              ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                              : node.task.status === 'FAILED'
                              ? 'bg-rose-950/60 text-rose-300 border-rose-800'
                              : 'bg-neutral-900 text-neutral-400 border-neutral-700'
                          }`}>
                            {node.task.status}
                          </span>
                        </div>

                        {node.task.dependencies.length > 0 && (
                          <div className="flex flex-wrap items-center gap-1.5 pt-2 text-[10px] font-mono text-neutral-500">
                            <span>Requires:</span>
                            {node.task.dependencies.map((dep, di) => (
                              <span key={di} className="px-1.5 py-0.2 rounded bg-[#101420] text-neutral-300 border border-[#1C2538]">
                                {dep.taskId}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Task Detail & Artifact Inspector */}
              {selectedOrchTaskId && orchestrationSession.taskGraph.nodes[selectedOrchTaskId] && (
                <div className="p-3.5 rounded-xl bg-[#090C14] border border-[#1B2438] space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-[#182030]">
                    <div className="font-bold text-white text-xs flex items-center gap-2">
                      <FileText className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Task Inspector: {orchestrationSession.taskGraph.nodes[selectedOrchTaskId].task.title}</span>
                    </div>
                    <span className="text-[10px] font-mono text-neutral-400">
                      ID: {selectedOrchTaskId}
                    </span>
                  </div>

                  <div className="space-y-2 text-[11px] font-sans text-neutral-300">
                    <p>{orchestrationSession.taskGraph.nodes[selectedOrchTaskId].task.description}</p>
                    
                    {orchestrationSession.taskGraph.nodes[selectedOrchTaskId].task.statusMessage && (
                      <div className="p-2 rounded bg-[#0D121D] border border-[#1C263A] text-neutral-300 font-mono text-[10px]">
                        Status: {orchestrationSession.taskGraph.nodes[selectedOrchTaskId].task.statusMessage}
                      </div>
                    )}
                  </div>

                  {/* Artifacts Produced */}
                  <div className="space-y-1.5 pt-1">
                    <div className="font-bold text-neutral-300 text-[11px]">Artifacts Produced</div>
                    {(Object.values(orchestrationSession.artifacts) as AgentArtifact[]).filter(a => a.taskId === selectedOrchTaskId).length === 0 ? (
                      <div className="text-[10px] text-neutral-500 font-mono">No artifacts emitted yet.</div>
                    ) : (
                      <div className="space-y-1.5 font-mono text-[10px]">
                        {(Object.values(orchestrationSession.artifacts) as AgentArtifact[])
                          .filter(a => a.taskId === selectedOrchTaskId)
                          .map(art => (
                            <div key={art.id} className="p-2 rounded bg-[#0D111A] border border-[#1A2234] space-y-1">
                              <div className="flex items-center justify-between text-cyan-400 font-bold">
                                <span>[{art.type}] {art.title}</span>
                                <span className="text-neutral-500 font-normal">{new Date(art.timestamp).toLocaleTimeString()}</span>
                              </div>
                              <pre className="p-1.5 rounded bg-[#06080E] text-neutral-300 text-[9px] overflow-x-auto whitespace-pre-wrap">
                                {typeof art.content === 'string' ? art.content : JSON.stringify(art.content, null, 2)}
                              </pre>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Final Verification Report */}
              {orchestrationSession.verificationReport && (
                <div className="p-4 rounded-xl bg-[#090D18] border border-emerald-700/80 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-emerald-400" />
                      <span className="font-bold text-white text-sm">Evidence-Grounded Verification Report</span>
                    </div>
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700">
                      {orchestrationSession.verificationReport.finalState}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-lg bg-[#060810] border border-[#141D2D] font-mono text-[11px] space-y-1.5">
                    <div className="text-neutral-300">{orchestrationSession.verificationReport.evidenceSummary}</div>
                    <div className="flex items-center justify-between text-neutral-500 text-[10px] pt-1 border-t border-[#141C2A]">
                      <span>Tests: {orchestrationSession.verificationReport.testsPassed ? 'PASSED' : 'PENDING'}</span>
                      <span>Security: {orchestrationSession.verificationReport.securityViolations.length === 0 ? 'SAFE' : `${orchestrationSession.verificationReport.securityViolations.length} VIOLATIONS`}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Tab 1: Conversational Chat */}
      {activeTab === 'chat' && (
        <GodexChatView
          messages={messages}
          taskState={taskState}
          executionMode={executionMode}
          activityLogs={activityLogs}
          verificationReport={verificationReport}
          onSendMessage={onSendMessage}
          onClearChat={onClearChat}
          onToggleExecutionMode={onToggleExecutionMode}
          onSelectFile={onSelectFile}
        />
      )}

      {/* Tab 2: Structured Task Plan */}
      {activeTab === 'plan' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-3 font-sans text-xs select-text">
          <div className="flex items-center justify-between pb-2 border-b border-[#182030]">
            <div>
              <span className="font-bold text-neutral-100">Structured Task Tree</span>
              <p className="text-[10px] text-neutral-400 font-mono">
                {controlPlaneState.operationId ? `Operation: ${controlPlaneState.operationId}` : 'Sequential Phase DAG & Verification Gates'}
              </p>
            </div>
            {controlPlaneState.tasks.length > 0 && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#131926] text-cyan-300 border border-[#202B3F] font-bold">
                {controlPlaneState.tasks.filter(t => t.status === 'COMPLETED').length}/{controlPlaneState.tasks.length} TASKS COMPLETED
              </span>
            )}
          </div>

          {controlPlaneState.tasks.length > 0 ? (
            <div className="space-y-2.5">
              {controlPlaneState.tasks.map((task, idx) => {
                const isDone = task.status === 'COMPLETED';
                const isRun = task.status === 'RUNNING';
                const isFailed = task.status === 'FAILED';
                const isExpanded = expandedTaskId === task.id;

                return (
                  <div
                    key={task.id}
                    className={`rounded-xl border transition-all overflow-hidden ${
                      isRun ? 'bg-[#101726] border-cyan-500/60 shadow-md ring-1 ring-cyan-500/30' :
                      isDone ? 'bg-[#0B0E16] border-[#182232]' :
                      isFailed ? 'bg-rose-950/30 border-rose-800/80' :
                      'bg-[#080A10] border-[#141A26] opacity-80'
                    }`}
                  >
                    <div 
                      onClick={() => setExpandedTaskId(isExpanded ? null : task.id)}
                      className="p-3 flex items-start gap-2.5 cursor-pointer hover:bg-[#131A28]/50 transition-colors"
                    >
                      <div className="mt-0.5 shrink-0">
                        {isDone ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        ) : isRun ? (
                          <span className="w-3.5 h-3.5 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin inline-block" />
                        ) : isFailed ? (
                          <AlertCircle className="w-4 h-4 text-rose-400" />
                        ) : (
                          <Circle className="w-3.5 h-3.5 text-neutral-500" />
                        )}
                      </div>

                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className={`text-xs font-bold truncate ${isDone ? 'text-neutral-300' : isRun ? 'text-cyan-300' : isFailed ? 'text-rose-300' : 'text-neutral-200'}`}>
                            {idx + 1}. {task.title}
                          </h4>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-[9px] font-mono uppercase px-1.5 py-0.2 rounded bg-[#131926] text-cyan-300 border border-[#1E2738]">
                              {task.agentRole}
                            </span>
                            <span className={`text-[9px] font-mono uppercase px-1.5 py-0.2 rounded font-bold ${
                              isDone ? 'bg-emerald-950 text-emerald-400' : isRun ? 'bg-cyan-950 text-cyan-400' : 'bg-neutral-900 text-neutral-500'
                            }`}>
                              {task.status}
                            </span>
                            {isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-neutral-500" /> : <ChevronRight className="w-3.5 h-3.5 text-neutral-500" />}
                          </div>
                        </div>
                        <p className="text-[11px] text-neutral-400 leading-relaxed font-sans">{task.description}</p>
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="p-3 pt-0 border-t border-[#161F2E] bg-[#07090F] space-y-2 text-[11px] font-mono">
                        <div className="text-neutral-400 text-[10px] uppercase font-bold pt-2">Target Files</div>
                        <div className="flex flex-wrap gap-1.5">
                          {task.files.map((file, fi) => (
                            <button
                              key={fi}
                              onClick={() => onSelectFile?.(file)}
                              className="px-2 py-0.5 rounded bg-[#0F1420] hover:bg-[#161F30] text-cyan-300 border border-[#1E293E] text-[10px] flex items-center gap-1 transition-colors"
                            >
                              <FileCode className="w-3 h-3 text-cyan-400" />
                              <span>{file}</span>
                            </button>
                          ))}
                        </div>
                        {task.dependencies.length > 0 && (
                          <div className="text-neutral-500 text-[10px]">
                            Dependencies: {task.dependencies.join(', ')}
                          </div>
                        )}
                        {task.error && (
                          <div className="text-rose-400 text-[10px] bg-rose-950/40 p-1.5 rounded border border-rose-900">
                            {task.error}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : codingTask?.plan ? (
            <div className="space-y-2.5">
              {codingTask.plan.steps.map((step, idx) => {
                const isDone = step.status === 'completed';
                const isRun = step.status === 'in_progress';
                const isFailed = step.status === 'failed';
                const isExpanded = expandedTaskId === step.id;

                return (
                  <div
                    key={step.id}
                    className={`rounded-xl border transition-all overflow-hidden ${
                      isRun ? 'bg-[#101726] border-cyan-500/60 shadow-md' :
                      isDone ? 'bg-[#0B0E16] border-[#182232]' :
                      isFailed ? 'bg-rose-950/30 border-rose-800/80' :
                      'bg-[#080A10] border-[#141A26] opacity-75'
                    }`}
                  >
                    <div 
                      onClick={() => setExpandedTaskId(isExpanded ? null : step.id)}
                      className="p-3 flex items-start gap-2.5 cursor-pointer hover:bg-[#131A28]/50 transition-colors"
                    >
                      <div className="mt-0.5 shrink-0">
                        {isDone ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        ) : isRun ? (
                          <span className="w-3.5 h-3.5 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin inline-block" />
                        ) : isFailed ? (
                          <AlertCircle className="w-4 h-4 text-rose-400" />
                        ) : (
                          <Circle className="w-3.5 h-3.5 text-neutral-500" />
                        )}
                      </div>

                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className={`text-xs font-bold truncate ${isDone ? 'text-neutral-300' : isRun ? 'text-cyan-300' : isFailed ? 'text-rose-300' : 'text-neutral-200'}`}>
                            {idx + 1}. {step.title}
                          </h4>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-[9px] font-mono uppercase px-1.5 py-0.2 rounded bg-[#131926] text-neutral-400 border border-[#1E2738]">
                              {step.agent || 'Coding Agent'}
                            </span>
                            {isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-neutral-500" /> : <ChevronRight className="w-3.5 h-3.5 text-neutral-500" />}
                          </div>
                        </div>
                        <p className="text-[11px] text-neutral-400 leading-relaxed font-sans">{step.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center text-xs text-neutral-500 font-sans border border-dashed border-[#1E2738] rounded-xl bg-[#090C14]">
              No active task plan. Send a request in Chat to initialize the real operation pipeline.
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Diff & Safe Edit Viewer */}
      {activeTab === 'diff' && (
        <div className="flex-1 flex flex-col overflow-hidden select-text font-mono text-xs">
          <div className="p-3 border-b border-[#182030] bg-[#0B0E16] flex items-center justify-between shrink-0">
            <div>
              <span className="font-bold text-white flex items-center gap-1.5">
                <GitPullRequest className="w-4 h-4 text-indigo-400" />
                <span>Authoritative Diff & Safe Edit Inspector</span>
              </span>
              <p className="text-[10px] text-neutral-400 font-mono">
                {controlPlaneState.operationId ? `Op: ${controlPlaneState.operationId}` : 'Atomic Patches & Secret Redaction Protected'}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                <span>Safe Edit Verified</span>
              </span>
            </div>
          </div>

          {/* Safe Edit Control Bar */}
          {controlPlaneState.edit && (
            <div className="p-2.5 bg-[#0D121F] border-b border-[#1A2337] flex items-center justify-between font-sans text-xs">
              <div className="flex items-center gap-3 font-mono text-[11px]">
                <span>Target: <strong className="text-cyan-300">{controlPlaneState.edit.targetFile}</strong></span>
                <span>Risk: <strong className="text-emerald-400">{controlPlaneState.edit.risk}</strong></span>
                <span>Approval: <strong className="text-purple-300">{controlPlaneState.edit.approval}</strong></span>
                <span>Fingerprint: <span className="text-neutral-400">{controlPlaneState.edit.fingerprint}</span></span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleApproveChanges}
                  className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] font-mono transition-colors"
                >
                  Approve
                </button>
                <button
                  onClick={handleRejectChanges}
                  className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-[10px] font-mono transition-colors"
                >
                  Reject
                </button>
                <button
                  onClick={handleRollback}
                  className="px-2.5 py-1 rounded bg-rose-950 hover:bg-rose-900 border border-rose-800 text-rose-300 font-bold text-[10px] font-mono transition-colors"
                >
                  Rollback
                </button>
              </div>
            </div>
          )}

          {/* File Selector Pills */}
          {controlPlaneState.diff?.fileDiffs && controlPlaneState.diff.fileDiffs.length > 0 ? (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="p-2 border-b border-[#161D2C] bg-[#080B12] flex items-center gap-1.5 overflow-x-auto">
                {controlPlaneState.diff.fileDiffs.map((op) => (
                  <button
                    key={op.filePath}
                    onClick={() => setSelectedDiffOpId(op.filePath)}
                    className={`px-2.5 py-1 rounded text-[11px] font-mono flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                      (selectedDiffOpId === op.filePath || (!selectedDiffOpId && controlPlaneState.diff?.fileDiffs[0]?.filePath === op.filePath))
                        ? 'bg-[#151E2E] text-cyan-300 border border-cyan-500/50 font-bold'
                        : 'bg-[#0E131E] text-neutral-400 hover:text-neutral-200 border border-[#1A2334]'
                    }`}
                  >
                    <span className="text-emerald-400 font-bold">Δ</span>
                    <span>{op.filePath}</span>
                    <span className="text-[9px] text-emerald-400">+{op.additions}</span>
                    <span className="text-[9px] text-rose-400">-{op.deletions}</span>
                  </button>
                ))}
              </div>

              {/* Active Diff Content */}
              <div className="flex-1 overflow-y-auto p-4 bg-[#06080E] font-mono text-[11px] space-y-1">
                {(() => {
                  const targetDiff = controlPlaneState.diff.fileDiffs.find(d => d.filePath === selectedDiffOpId) || controlPlaneState.diff.fileDiffs[0];
                  if (!targetDiff) return <div className="text-neutral-500">Select a file diff above.</div>;
                  return (
                    <div>
                      <div className="pb-2 text-[10px] text-neutral-400 flex items-center justify-between border-b border-[#151D2A] mb-2">
                        <span>File: <strong className="text-white">{targetDiff.filePath}</strong></span>
                        <span>Status: <strong className={targetDiff.status === 'APPLIED' ? 'text-emerald-400' : 'text-amber-400'}>{targetDiff.status}</strong></span>
                      </div>

                      <pre className="whitespace-pre overflow-x-auto font-mono text-[11px] leading-relaxed">
                        {targetDiff.unifiedDiff ? (
                          targetDiff.unifiedDiff.split('\n').map((line, idx) => {
                            const isAdd = line.startsWith('+');
                            const isDel = line.startsWith('-');
                            const isHunk = line.startsWith('@@');

                            return (
                              <div
                                key={idx}
                                className={`px-1 rounded-xs ${
                                  isAdd ? 'bg-emerald-950/40 text-emerald-300 font-medium' :
                                  isDel ? 'bg-rose-950/40 text-rose-300' :
                                  isHunk ? 'text-cyan-400 bg-[#0E1524] font-bold' :
                                  'text-neutral-400'
                                }`}
                              >
                                {line}
                              </div>
                            );
                          })
                        ) : (
                          <div className="text-neutral-500">No line differences detected.</div>
                        )}
                      </pre>
                    </div>
                  );
                })()}
              </div>
            </div>
          ) : codingTask?.proposedChanges && codingTask.proposedChanges.length > 0 ? (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="p-2 border-b border-[#161D2C] bg-[#080B12] flex items-center gap-1.5 overflow-x-auto">
                {codingTask.proposedChanges.map((op) => (
                  <button
                    key={op.id}
                    onClick={() => setSelectedDiffOpId(op.id)}
                    className={`px-2.5 py-1 rounded text-[11px] font-mono flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                      (activeDiffOp?.id === op.id)
                        ? 'bg-[#151E2E] text-cyan-300 border border-cyan-500/50 font-bold'
                        : 'bg-[#0E131E] text-neutral-400 hover:text-neutral-200 border border-[#1A2334]'
                    }`}
                  >
                    <span className={op.operation === 'CREATE_FILE' ? 'text-emerald-400' : op.operation === 'DELETE_FILE' ? 'text-rose-400' : 'text-amber-400'}>
                      {op.operation === 'CREATE_FILE' ? '+' : op.operation === 'DELETE_FILE' ? 'x' : 'Δ'}
                    </span>
                    <span>{op.target}</span>
                    <span className="text-[9px] text-emerald-400">+{op.additions}</span>
                    <span className="text-[9px] text-rose-400">-{op.deletions}</span>
                  </button>
                ))}
              </div>

              {/* Active Diff Content */}
              <div className="flex-1 overflow-y-auto p-4 bg-[#06080E] font-mono text-[11px] space-y-1">
                {activeDiffOp ? (
                  <div>
                    <div className="pb-2 text-[10px] text-neutral-400 flex items-center justify-between border-b border-[#151D2A] mb-2">
                      <span>Operation: <strong>{activeDiffOp.operation}</strong></span>
                      <span>Status: <strong className={activeDiffOp.status === 'applied' ? 'text-emerald-400' : 'text-amber-400'}>{activeDiffOp.status.toUpperCase()}</strong></span>
                    </div>

                    <pre className="whitespace-pre overflow-x-auto font-mono text-[11px] leading-relaxed">
                      {activeDiffOp.unifiedDiff ? (
                        activeDiffOp.unifiedDiff.split('\n').map((line, idx) => {
                          const isAdd = line.startsWith('+');
                          const isDel = line.startsWith('-');
                          const isHunk = line.startsWith('@@');

                          return (
                            <div
                              key={idx}
                              className={`px-1 rounded-xs ${
                                isAdd ? 'bg-emerald-950/40 text-emerald-300 font-medium' :
                                isDel ? 'bg-rose-950/40 text-rose-300' :
                                isHunk ? 'text-cyan-400 bg-[#0E1524] font-bold' :
                                'text-neutral-400'
                              }`}
                            >
                              {line}
                            </div>
                          );
                        })
                      ) : (
                        <div className="text-neutral-500">No line differences detected.</div>
                      )}
                    </pre>
                  </div>
                ) : (
                  <div className="text-neutral-500">Select a file diff above.</div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-xs text-neutral-500 font-sans border border-dashed border-[#1E2738] rounded-xl bg-[#090C14] m-4">
              No recent file edits. Send a request in Chat to generate real workspace diffs.
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Deterministic Simulation Test Suite */}
      {activeTab === 'simulation' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4 font-sans text-xs select-text">
          <div className="flex items-center justify-between pb-2 border-b border-[#182030]">
            <div>
              <span className="font-bold text-white flex items-center gap-1.5">
                <TestTube className="w-4 h-4 text-emerald-400" />
                <span>Deterministic Test Matrix</span>
              </span>
              <p className="text-[10px] text-neutral-400 font-mono">10-Point Phase 3 Architecture Test Suite</p>
            </div>

            <button
              onClick={handleRunSimulationTests}
              disabled={isRunningTests}
              className="py-1 px-3 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs transition-colors flex items-center gap-1.5 shadow-sm"
            >
              {isRunningTests ? (
                <span className="w-3 h-3 rounded-full border-2 border-white border-t-transparent animate-spin inline-block" />
              ) : (
                <Play className="w-3 h-3" />
              )}
              <span>{isRunningTests ? 'Running Suite...' : 'Run All Tests'}</span>
            </button>
          </div>

          {testSuiteResult ? (
            <div className="space-y-3">
              {/* Summary Bar */}
              <div className={`p-3 rounded-xl border flex items-center justify-between font-mono text-xs ${
                testSuiteResult.passed ? 'bg-emerald-950/50 border-emerald-700 text-emerald-200' : 'bg-rose-950/50 border-rose-700 text-rose-200'
              }`}>
                <div className="flex items-center gap-2">
                  {testSuiteResult.passed ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <AlertCircle className="w-5 h-5 text-rose-400" />}
                  <span className="font-bold">
                    {testSuiteResult.passed ? 'ALL PHASE 3 TESTS PASSED' : `${testSuiteResult.failedCount} TESTS FAILED`}
                  </span>
                </div>
                <span className="text-[11px]">
                  {testSuiteResult.passedCount} / {testSuiteResult.total} PASSED (100% Deterministic)
                </span>
              </div>

              {/* Test List */}
              <div className="space-y-2 font-mono text-[11px]">
                {testSuiteResult.results.map((t) => (
                  <div
                    key={t.id}
                    className={`p-3 rounded-xl border space-y-1 ${
                      t.passed ? 'bg-[#0B0E16] border-[#182232]' : 'bg-rose-950/30 border-rose-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {t.passed ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-rose-400" />
                        )}
                        <span className="font-bold text-neutral-200">{t.name}</span>
                      </div>
                      <span className="text-[10px] text-neutral-500">{t.durationMs}ms</span>
                    </div>
                    <div className="text-[11px] text-neutral-400 pl-5.5 font-sans">
                      {t.message}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center space-y-3 border border-dashed border-[#1E2738] rounded-xl bg-[#090C14]">
              <TestTube className="w-8 h-8 text-neutral-500 mx-auto" />
              <div className="space-y-1">
                <h4 className="text-xs font-semibold text-neutral-300">Phase 3 Verification Matrix</h4>
                <p className="text-[11px] text-neutral-500 max-w-xs mx-auto">
                  Click "Run All Tests" to deterministically test state machine transitions, patch application, stale edit protection, rollbacks, tool permissions, and simulation flow.
                </p>
              </div>
              <button
                onClick={handleRunSimulationTests}
                className="py-1.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors inline-flex items-center gap-1.5"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Execute Test Suite</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 5: Context Inspector */}
      {activeTab === 'context' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4 font-sans text-xs select-text">
          <div className="flex items-center justify-between pb-2 border-b border-[#182030]">
            <div>
              <span className="font-bold text-neutral-100 flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-emerald-400" />
                <span>Context Inspector</span>
              </span>
              <p className="text-[10px] text-neutral-400 font-mono">AST Relevance Grounding & Budget Engine</p>
            </div>
            {(controlPlaneState.context || latestContextPack) && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800 font-bold">
                {controlPlaneState.context ? 'GROUNDED AST' : latestContextPack?.taskIntent}
              </span>
            )}
          </div>

          {controlPlaneState.context ? (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-[#0B0E16] border border-[#1A2334] space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-neutral-400">Context Budget Utilization</span>
                  <span className="text-cyan-300 font-bold">
                    {Math.round((controlPlaneState.context.tokenUsage / controlPlaneState.context.tokenBudget) * 100)}% ({controlPlaneState.context.tokenUsage} / {controlPlaneState.context.tokenBudget} tokens)
                  </span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-[#141B2A] overflow-hidden">
                  <div 
                    className="h-full rounded-full bg-emerald-400 transition-all"
                    style={{ width: `${Math.min(100, Math.round((controlPlaneState.context.tokenUsage / controlPlaneState.context.tokenBudget) * 100))}%` }}
                  />
                </div>
              </div>

              {/* Epistemic Summary */}
              <div className="p-3 rounded-xl bg-[#0B0E16] border border-[#1A2334] space-y-2 font-mono text-[11px]">
                <div className="font-bold text-neutral-200">Epistemic Breakdown</div>
                <div className="text-emerald-400">
                  <span className="font-bold">KNOWN:</span> {controlPlaneState.context.epistemicSummary.known.join(', ')}
                </div>
                <div className="text-cyan-300">
                  <span className="font-bold">LIKELY:</span> {controlPlaneState.context.epistemicSummary.likely.join(', ')}
                </div>
              </div>

              {/* Relevant Files */}
              <div className="space-y-2">
                <div className="font-bold text-neutral-200">Grounded Files ({controlPlaneState.context.files.length})</div>
                <div className="space-y-1.5 font-mono text-[11px]">
                  {controlPlaneState.context.files.map((rf, rfi) => (
                    <div key={rfi} className="p-2 rounded-lg bg-[#0C1018] border border-[#182030] flex items-center justify-between">
                      <span className="text-cyan-300">{rf.path}</span>
                      <span className="text-[10px] text-neutral-500">{rf.tokens} tok</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Symbols */}
              {controlPlaneState.context.symbols.length > 0 && (
                <div className="space-y-2">
                  <div className="font-bold text-neutral-200">Extracted AST Symbols ({controlPlaneState.context.symbols.length})</div>
                  <div className="space-y-1.5 font-mono text-[11px] max-h-40 overflow-y-auto">
                    {controlPlaneState.context.symbols.map((sym, si) => (
                      <div key={si} className="p-1.5 rounded bg-[#0C1018] border border-[#182030] flex items-center justify-between">
                        <span className="text-white font-bold">{sym.name}</span>
                        <span className="text-[9px] text-cyan-400 uppercase">{sym.kind} (L{sym.line})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : latestContextPack ? (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-[#0B0E16] border border-[#1A2334] space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-neutral-400">Context Budget Utilization</span>
                  <span className="text-cyan-300 font-bold">{latestContextPack.budgetUsagePercent}% ({latestContextPack.totalTokensEstimate} tokens)</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-[#141B2A] overflow-hidden">
                  <div 
                    className="h-full rounded-full bg-emerald-400 transition-all"
                    style={{ width: `${Math.min(100, latestContextPack.budgetUsagePercent)}%` }}
                  />
                </div>
              </div>

              {/* Relevant Files */}
              <div className="space-y-2">
                <div className="font-bold text-neutral-200">Grounded Target Files ({latestContextPack.relevantFiles.length})</div>
                <div className="space-y-1.5 font-mono text-[11px]">
                  {latestContextPack.relevantFiles.map((rf, rfi) => (
                    <div key={rfi} className="p-2 rounded-lg bg-[#0C1018] border border-[#182030] flex items-center justify-between">
                      <span className="text-cyan-300">{rf.path}</span>
                      <span className="text-[10px] text-neutral-500">{rf.layer}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="h-48 flex flex-col items-center justify-center text-center p-6 space-y-2 border border-dashed border-[#1E2738] rounded-xl bg-[#090C14]">
              <Compass className="w-6 h-6 text-neutral-500" />
              <div className="text-xs font-semibold text-neutral-300">No Active ContextPack</div>
              <p className="text-[11px] text-neutral-500 max-w-xs">
                Run any query or request in Chat. The Context Engine will retrieve relevant AST files, symbols, and token budgets in real-time.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Tab 6: Technical Activity Stream */}
      {activeTab === 'activity' && (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="p-2 border-b border-[#182030] bg-[#0B0E16] flex items-center gap-1 font-mono text-[10px]">
            <button
              onClick={() => setActivityFilter('all')}
              className={`px-2 py-0.5 rounded transition-colors ${activityFilter === 'all' ? 'bg-[#151E2E] text-cyan-300 border border-cyan-500/40 font-bold' : 'text-neutral-400 hover:text-neutral-200'}`}
            >
              ALL ({controlPlaneState.telemetry.length || activityLogs.length})
            </button>
            <button
              onClick={() => setActivityFilter('mutation')}
              className={`px-2 py-0.5 rounded transition-colors ${activityFilter === 'mutation' ? 'bg-[#151E2E] text-cyan-300 border border-cyan-500/40 font-bold' : 'text-neutral-400 hover:text-neutral-200'}`}
            >
              MUTATIONS
            </button>
            <button
              onClick={() => setActivityFilter('ast')}
              className={`px-2 py-0.5 rounded transition-colors ${activityFilter === 'ast' ? 'bg-[#151E2E] text-cyan-300 border border-cyan-500/40 font-bold' : 'text-neutral-400 hover:text-neutral-200'}`}
            >
              AST & BUILD
            </button>
            <button
              onClick={() => setActivityFilter('verify')}
              className={`px-2 py-0.5 rounded transition-colors ${activityFilter === 'verify' ? 'bg-[#151E2E] text-cyan-300 border border-cyan-500/40 font-bold' : 'text-neutral-400 hover:text-neutral-200'}`}
            >
              VERIFICATION
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-2 font-mono text-[11px]">
            {controlPlaneState.telemetry.length > 0 ? (
              controlPlaneState.telemetry.map((t, idx) => (
                <div
                  key={t.id ? `${t.id}-${idx}` : `tel-${idx}`}
                  className="p-2.5 rounded-lg bg-[#0C1018] border border-[#1A2230] space-y-1 hover:border-[#263550] transition-colors"
                >
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-cyan-400 font-bold">[{t.subsystem}]</span>
                    <span className="text-neutral-500">{new Date(t.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div className="text-neutral-200 font-medium">{t.message}</div>
                  {t.operationId && (
                    <div className="text-neutral-500 text-[9px]">
                      Operation: {t.operationId} {t.taskId ? `· Task: ${t.taskId}` : ''}
                    </div>
                  )}
                </div>
              ))
            ) : filteredActivityLogs.length > 0 ? (
              filteredActivityLogs.map((log, idx) => (
                <div
                  key={log.id ? `${log.id}-${idx}` : `act-${idx}`}
                  className="p-2.5 rounded-lg bg-[#0C1018] border border-[#1A2230] space-y-1 hover:border-[#263550] transition-colors"
                >
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-cyan-400 font-bold">[{log.role}]</span>
                    <span className="text-neutral-500">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div className="text-neutral-200 font-medium">{log.action}</div>
                  {log.details && (
                    <div className="text-neutral-400 text-[10px] break-words bg-[#080A10] p-1.5 rounded border border-[#141A26]">
                      {log.details}
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-xs text-neutral-500 font-sans">
                No recent tool executions or mutation events.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 7: Multi-Agent Matrix */}
      {activeTab === 'agents' && (
        <div className="flex-1 overflow-y-auto p-3 space-y-3 font-sans text-xs select-text">
          <div className="pb-2 border-b border-[#182030] flex items-center justify-between">
            <div>
              <span className="font-bold text-white">Multi-Agent Coordination Matrix</span>
              <p className="text-[11px] text-neutral-400 font-sans mt-0.5">
                Specialized autonomous agents operating with clear separation of concerns.
              </p>
            </div>
            <span className="text-[10px] font-mono text-cyan-300">
              {controlPlaneState.agents.filter(a => a.status === 'WORKING').length} Active
            </span>
          </div>

          <div className="space-y-3">
            {controlPlaneState.agents.map((ag) => (
              <div
                key={ag.id}
                className="p-3 rounded-xl bg-[#0B0E16] border border-[#1A2232] space-y-2 group hover:border-[#28354D] transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{ag.name}</span>
                    <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#121824] text-neutral-400 border border-[#1E2738]">
                      {ag.model}
                    </span>
                  </div>
                  <span className={`text-[9px] font-mono uppercase px-2 py-0.5 rounded font-bold border ${ag.color}`}>
                    {ag.status}
                  </span>
                </div>

                <p className="text-[11px] text-neutral-400 leading-relaxed font-sans">{ag.description}</p>

                <div className="flex flex-wrap gap-1 pt-1 font-mono text-[10px]">
                  {ag.capabilities.map((cap, ci) => (
                    <span key={ci} className="px-1.5 py-0.5 rounded bg-[#101420] text-neutral-300 border border-[#1A2333]">
                      {cap}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
