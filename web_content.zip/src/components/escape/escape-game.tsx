import { useEffect, useRef, useState, type Dispatch, type ReactNode, type SetStateAction } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import {
  BookOpen,
  Clock3,
  Compass,
  Crown,
  Delete,
  DoorClosed,
  Droplets,
  Feather,
  FileText,
  Flower2,
  Frame,
  Gem,
  KeyRound,
  Lamp,
  Map,
  Moon,
  PenLine,
  Scale,
  ScrollText,
  Shield,
  Shirt,
  Stamp,
  Star,
  Sun,
  Telescope,
  TreePine,
  Umbrella,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import type { HotspotIcon, Lock, Room } from "@/game/types";
import { roomByNumber, ROOMS, WINGS, wingFor } from "@/game/rooms";
import { emptyAttempt, isCorrect, type Attempt } from "@/game/logic";
import { formatDuration, freshSave, loadSave, writeSave, type Save } from "@/game/save";
import { playSfx, resumeAudio, setAudioMuted, unlockAudio } from "@/game/audio";

const ICONS: Record<HotspotIcon, typeof Frame> = {
  frame: Frame,
  scroll: ScrollText,
  shirt: Shirt,
  umbrella: Umbrella,
  clock: Clock3,
  lamp: Lamp,
  book: BookOpen,
  feather: Feather,
  flower: Flower2,
  drop: Droplets,
  sun: Sun,
  moon: Moon,
  star: Star,
  scope: Telescope,
  key: KeyRound,
  scale: Scale,
  shield: Shield,
  file: FileText,
  crown: Crown,
  gem: Gem,
  tree: TreePine,
  compass: Compass,
  stamp: Stamp,
  pen: PenLine,
  door: DoorClosed,
};

type Phase = "title" | "play" | "victory";

export function EscapeGame() {
  const [phase, setPhase] = useState<Phase>("title");
  const [save, setSave] = useState<Save>(() => freshSave());
  const [ready, setReady] = useState(false);
  const [mapOpen, setMapOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  useEffect(() => {
    const loaded = loadSave();
    setSave(loaded);
    setAudioMuted(loaded.mute);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    writeSave(save);
    setAudioMuted(save.mute);
  }, [save, ready]);

  useEffect(() => {
    if (phase !== "play" || save.frontier > 50) return;
    const id = window.setInterval(() => {
      if (document.visibilityState !== "visible") return;
      setSave((s) => ({ ...s, elapsedMs: s.elapsedMs + 1000 }));
    }, 1000);
    return () => window.clearInterval(id);
  }, [phase, save.frontier]);

  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === "visible") resumeAudio();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  function toggleMute() {
    unlockAudio();
    setSave((s) => ({ ...s, mute: !s.mute }));
  }

  function begin(mode: "continue" | "new") {
    unlockAudio();
    if (mode === "new") {
      setSave((s) => ({ ...freshSave(), mute: s.mute, started: true }));
      setPhase("play");
      return;
    }
    if (save.frontier > 50) {
      setPhase("victory");
      return;
    }
    setSave((s) => ({
      ...s,
      started: true,
      viewing: Math.min(s.frontier, 50),
    }));
    setPhase("play");
  }

  function resetRun() {
    unlockAudio();
    setSave((s) => ({ ...freshSave(), mute: s.mute, started: true }));
    setConfirmReset(false);
    setMenuOpen(false);
    setMapOpen(false);
    setPhase("play");
  }

  if (phase === "title") {
    return (
      <TitleScreen
        save={save}
        onContinue={() => begin("continue")}
        onNew={() => begin("new")}
        onMute={toggleMute}
      />
    );
  }

  if (phase === "victory") {
    return <Victory save={save} onAgain={resetRun} onMute={toggleMute} />;
  }

  const room = roomByNumber(save.viewing);

  return (
    <Play
      room={room}
      save={save}
      setSave={setSave}
      mapOpen={mapOpen}
      setMapOpen={setMapOpen}
      menuOpen={menuOpen}
      setMenuOpen={setMenuOpen}
      confirmReset={confirmReset}
      setConfirmReset={setConfirmReset}
      onMute={toggleMute}
      onTitle={() => {
        setMenuOpen(false);
        setPhase("title");
      }}
      onReset={resetRun}
      onVictory={() => setPhase("victory")}
    />
  );
}

function TitleScreen({
  save,
  onContinue,
  onNew,
  onMute,
}: {
  save: Save;
  onContinue: () => void;
  onNew: () => void;
  onMute: () => void;
}) {
  const hasRun = save.started && (save.frontier > 1 || save.elapsedMs > 0);
  return (
    <main className="grid min-h-dvh bg-walnut text-cream md:grid-cols-2">
      <div className="relative min-h-80 md:min-h-dvh">
        <div className="absolute inset-0">
          <RoomScene wing="foyer" open={false} hotspots={[]} selected={null} seen={[]} onSelect={() => {}} />
        </div>
      </div>
      <section className="flex items-center px-6 py-10 md:px-12">
        <div className="mx-auto w-full max-w-md">
          <p className="text-xs tracking-widest text-brass uppercase">A house puzzle</p>
          <h1 className="mt-3 font-display text-5xl text-cream">Fifty Locks</h1>
          <p className="mt-4 max-w-sm text-mist">
            Fifty rooms, one after another. Examine what was left behind, open the lock, and step through.
          </p>
          <ul className="mt-6 space-y-2 text-sm text-cream">
            <li>Tap the room. Read what you find.</li>
            <li>Open the lock, then the next door.</li>
            <li>Ask the house if you stall. The third hint names the answer.</li>
          </ul>
          <div className="mt-8 flex flex-col gap-3">
            {hasRun ? (
              <>
                <button type="button" className="btn btn-brass" onClick={onContinue}>
                  {save.frontier > 50 ? "Return to the last door" : `Continue · room ${Math.min(save.frontier, 50)}`}
                </button>
                <button type="button" className="btn btn-ghost" onClick={onNew}>
                  Start over
                </button>
              </>
            ) : (
              <button type="button" className="btn btn-brass" onClick={onNew}>
                Begin at the first door
              </button>
            )}
            <button
              type="button"
              className="btn btn-ghost self-start"
              onClick={onMute}
              aria-label={save.mute ? "Unmute" : "Mute"}
            >
              {save.mute ? <VolumeX aria-hidden /> : <Volume2 aria-hidden />}
              <span>{save.mute ? "Sound off" : "Sound on"}</span>
            </button>
          </div>
          <p className="mt-8 text-sm text-mist">Progress stays on this device.</p>
        </div>
      </section>
    </main>
  );
}

function Victory({ save, onAgain, onMute }: { save: Save; onAgain: () => void; onMute: () => void }) {
  const hints = Object.values(save.hints).reduce((sum, n) => sum + n, 0);
  return (
    <main className="grid min-h-dvh place-items-center bg-walnut px-6 py-12 text-cream">
      <div className="w-full max-w-md">
        <p className="text-xs tracking-widest text-brass uppercase">Outside</p>
        <h1 className="mt-3 font-display text-5xl">The house lets you go</h1>
        <p className="mt-4 text-mist">
          The street air is ordinary, which is the point. Fifty locks, and none of them yours anymore.
        </p>
        <dl className="mt-8 grid grid-cols-2 gap-3">
          <Stat label="Time" value={formatDuration(save.elapsedMs)} />
          <Stat label="Hints asked" value={String(hints)} />
        </dl>
        <div className="mt-8 flex flex-col gap-3">
          <button type="button" className="btn btn-brass" onClick={onAgain}>
            Walk the house again
          </button>
          <button type="button" className="btn btn-ghost self-start" onClick={onMute}>
            {save.mute ? <VolumeX aria-hidden /> : <Volume2 aria-hidden />}
            <span>{save.mute ? "Sound off" : "Sound on"}</span>
          </button>
        </div>
      </div>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-line bg-surface px-4 py-3">
      <dt className="text-xs tracking-widest text-mist uppercase">{label}</dt>
      <dd className="mt-1 font-display text-3xl text-cream tabular-nums">{value}</dd>
    </div>
  );
}

function Play({
  room,
  save,
  setSave,
  mapOpen,
  setMapOpen,
  menuOpen,
  setMenuOpen,
  confirmReset,
  setConfirmReset,
  onMute,
  onTitle,
  onReset,
  onVictory,
}: {
  room: Room;
  save: Save;
  setSave: Dispatch<SetStateAction<Save>>;
  mapOpen: boolean;
  setMapOpen: (open: boolean) => void;
  menuOpen: boolean;
  setMenuOpen: (open: boolean) => void;
  confirmReset: boolean;
  setConfirmReset: (open: boolean) => void;
  onMute: () => void;
  onTitle: () => void;
  onReset: () => void;
  onVictory: () => void;
}) {
  const lock = room.lock;
  const [attempt, setAttempt] = useState<Attempt>(() => emptyAttempt(lock));
  const [selected, setSelected] = useState<string | null>(null);
  const [justSolved, setJustSolved] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [misses, setMisses] = useState(0);
  const [shake, setShake] = useState(0);
  const [signalLit, setSignalLit] = useState<string | null>(null);
  const [signalBusy, setSignalBusy] = useState(false);
  const orderRef = useRef<string[]>([]);
  const signalRef = useRef<string[]>([]);
  const watchRef = useRef(0);

  useEffect(() => {
    setAttempt(emptyAttempt(room.lock));
    orderRef.current = [];
    signalRef.current = [];
    watchRef.current += 1;
    setSelected(null);
    setJustSolved(false);
    setNotice(null);
    setMisses(0);
    setSignalLit(null);
    setSignalBusy(false);
  }, [room.n, room.lock]);

  const open = room.n < save.frontier || justSolved;
  const wing = wingFor(room.n);
  const revealed = save.hints[String(room.n)] ?? 0;
  const spot = room.hotspots.find((item) => item.id === selected) ?? null;
  const seenHere = room.hotspots.filter((item) => save.seen.includes(`${room.n}:${item.id}`));
  const furthest = Math.min(save.frontier, 50);

  function inspect(id: string) {
    unlockAudio();
    playSfx("note");
    setSelected(id);
    const key = `${room.n}:${id}`;
    setSave((s) => (s.seen.includes(key) ? s : { ...s, seen: [...s.seen, key] }));
  }

  function resolve(ok: boolean) {
    if (ok) {
      playSfx("open");
      setJustSolved(true);
      setNotice(null);
      setSave((s) => ({ ...s, frontier: Math.max(s.frontier, room.n + 1), started: true }));
      return;
    }
    playSfx("fail");
    setMisses((m) => m + 1);
    setNotice(misses + 1 >= 3 ? "The lock refuses. The house will hint, if you ask." : "The lock refuses.");
    setShake((k) => k + 1);
    if (lock.kind === "order" || lock.kind === "signal") {
      orderRef.current = [];
      signalRef.current = [];
      setAttempt((a) => ({ ...a, order: [], signal: [] }));
    }
  }

  function submit() {
    if (open) return;
    unlockAudio();
    resolve(isCorrect(lock, attempt));
  }

  function clearOrder() {
    orderRef.current = [];
    setAttempt((a) => ({ ...a, order: [] }));
    setNotice(null);
  }

  function pushOrder(id: string) {
    if (lock.kind !== "order" || open) return;
    if (orderRef.current.includes(id)) return;
    const order = [...orderRef.current, id];
    orderRef.current = order;
    setAttempt((a) => ({ ...a, order }));
    setNotice(null);
    if (order.length === lock.answer.length) {
      const ok = order.every((step, i) => step === lock.answer[i]);
      if (!ok) orderRef.current = [];
      resolve(ok);
    } else {
      playSfx("tick");
    }
  }

  function pushSignal(id: string) {
    if (lock.kind !== "signal" || open || signalBusy) return;
    const signal = [...signalRef.current, id];
    signalRef.current = signal;
    setAttempt((a) => ({ ...a, signal }));
    setNotice(null);
    if (signal.length === lock.answer.length) {
      const ok = signal.every((step, i) => step === lock.answer[i]);
      if (!ok) signalRef.current = [];
      resolve(ok);
    } else {
      playSfx("tick");
    }
  }

  function watchSignal() {
    if (lock.kind !== "signal" || open) return;
    unlockAudio();
    const seq = lock.answer;
    const token = ++watchRef.current;
    signalRef.current = [];
    setAttempt((a) => ({ ...a, signal: [] }));
    setSignalBusy(true);
    setNotice(null);
    let i = 0;
    const tick = () => {
      if (watchRef.current !== token) return;
      if (i >= seq.length) {
        setSignalLit(null);
        setSignalBusy(false);
        return;
      }
      setSignalLit(seq[i] ?? null);
      window.setTimeout(() => {
        if (watchRef.current !== token) return;
        setSignalLit(null);
        i += 1;
        window.setTimeout(tick, 160);
      }, 480);
    };
    tick();
  }

  function askHint() {
    unlockAudio();
    playSfx("hint");
    setSave((s) => {
      const cur = s.hints[String(room.n)] ?? 0;
      if (cur >= 3) return s;
      return { ...s, hints: { ...s.hints, [String(room.n)]: cur + 1 } };
    });
  }

  function goOn() {
    unlockAudio();
    playSfx("tick");
    if (save.frontier > 50 && room.n === 50) {
      onVictory();
      return;
    }
    setSave((s) => ({ ...s, viewing: Math.min(s.frontier, 50) }));
  }

  let onward = "Enter the next room";
  if (save.frontier > 50 && room.n === 50) onward = "Step outside";
  else if (room.n + 1 < save.frontier) onward = `Return to room ${furthest}`;

  return (
    <main className="flex min-h-dvh flex-col bg-walnut text-cream">
      <header className="flex items-center gap-2 border-b border-line px-4 py-3">
        <div className="min-w-0 flex-1">
          <p className="text-xs tracking-widest text-brass uppercase">Fifty Locks</p>
          <p className="font-display text-lg tabular-nums">
            {room.n}
            <span className="text-mist"> / 50</span>
            <span className="mx-2 text-mist">·</span>
            <span className="text-base">{formatDuration(save.elapsedMs)}</span>
          </p>
        </div>
        <button type="button" className="btn btn-ghost btn-icon" onClick={() => setMapOpen(true)} aria-label="House map">
          <Map aria-hidden />
        </button>
        <button type="button" className="btn btn-ghost btn-icon" onClick={onMute} aria-label={save.mute ? "Unmute" : "Mute"}>
          {save.mute ? <VolumeX aria-hidden /> : <Volume2 aria-hidden />}
        </button>
        <button type="button" className="btn btn-ghost" onClick={() => setMenuOpen(true)}>
          Menu
        </button>
      </header>
      <div className="px-4 pt-3">
        <div className="flex gap-0.5" aria-hidden>
          {ROOMS.map((item) => (
            <span
              key={item.n}
              className={`h-1 min-w-0 flex-1 rounded-full ${
                item.n < save.frontier ? "bg-brass" : item.n === room.n ? "bg-cream" : "bg-line"
              }`}
            />
          ))}
        </div>
        <p className="mt-3 text-xs tracking-widest text-brass uppercase">{wing.name}</p>
        <h1 className="font-display text-3xl text-cream">{room.name}</h1>
      </div>
      <div className="flex min-h-0 flex-1 flex-col md:grid md:grid-cols-[minmax(0,1.35fr)_minmax(20rem,26rem)]">
        <div className="flex min-h-72 flex-1 flex-col md:min-h-0">
          <RoomScene
            wing={room.wing}
            open={open}
            hotspots={room.hotspots}
            selected={selected}
            seen={save.seen.filter((key) => key.startsWith(`${room.n}:`)).map((key) => key.split(":")[1] ?? "")}
            onSelect={inspect}
            card={
              spot ? (
                <article className="note-card">
                  <div className="flex items-start justify-between gap-3">
                    <h2 className="font-display text-xl text-ink">{spot.label}</h2>
                    <button type="button" className="btn btn-ink btn-icon" onClick={() => setSelected(null)} aria-label="Close note">
                      <X aria-hidden />
                    </button>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-ink">{spot.text}</p>
                </article>
              ) : room.n === 1 && !open && seenHere.length === 0 ? (
                <p className="absolute bottom-4 left-4 rounded-full bg-paper px-3 py-2 text-sm text-ink">Tap an object in the room.</p>
              ) : null
            }
          />
        </div>
        <aside className="border-t border-line px-4 py-4 md:overflow-y-auto md:border-t-0 md:border-l">
          <p className="text-sm text-mist">{room.line}</p>
          <section className="mt-4">
            <h2 className="text-xs tracking-widest text-brass uppercase">Journal</h2>
            {seenHere.length === 0 ? (
              <p className="mt-2 text-sm text-mist">Nothing noted yet. Examine the room.</p>
            ) : (
              <ul className="mt-2 space-y-2">
                {seenHere.map((item) => (
                  <li key={item.id}>
                    <button
                      type="button"
                      className="w-full rounded-lg border border-line bg-surface px-3 py-2 text-left text-sm"
                      onClick={() => inspect(item.id)}
                    >
                      <span className="block text-brass">{item.label}</span>
                      <span className="mt-0.5 block text-cream">{item.note}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
          <section key={shake} className={`mt-4 rounded-xl bg-paper p-4 text-ink ${shake ? "lock-shake" : ""}`}>
            {open ? (
              <div>
                <h2 className="font-display text-2xl">The lock is open</h2>
                <p className="mt-2 text-sm leading-relaxed">{justSolved ? room.yield : "You have already opened this one."}</p>
                <button type="button" className="btn btn-ink mt-4 w-full" onClick={goOn}>
                  {onward}
                </button>
              </div>
            ) : (
              <LockControls
                lock={lock}
                attempt={attempt}
                setAttempt={setAttempt}
                signalLit={signalLit}
                signalBusy={signalBusy}
                onSubmit={submit}
                onOrder={pushOrder}
                onSignal={pushSignal}
                onWatch={watchSignal}
                onClearOrder={clearOrder}
                onEdit={() => setNotice(null)}
              />
            )}
            <p role="status" className="mt-3 min-h-5 text-sm text-wax">
              {open ? "" : (notice ?? "")}
            </p>
          </section>
          {!open && (
            <section className="mt-4">
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-xs tracking-widest text-brass uppercase">Hints</h2>
                <button type="button" className="btn btn-ghost" onClick={askHint} disabled={revealed >= 3}>
                  {revealed >= 3 ? "No further hints" : "Ask the house"}
                </button>
              </div>
              {revealed === 0 ? (
                <p className="mt-2 text-sm text-mist">Three hints. The last one names the answer.</p>
              ) : (
                <ol className="mt-2 space-y-2">
                  {room.hints.slice(0, revealed).map((hint, i) => (
                    <li key={hint} className="rounded-lg border border-line bg-surface px-3 py-2 text-sm text-cream">
                      <span className="text-brass tabular-nums">{i + 1}. </span>
                      {hint}
                    </li>
                  ))}
                </ol>
              )}
            </section>
          )}
        </aside>
      </div>

      <HouseMap
        open={mapOpen}
        onOpenChange={setMapOpen}
        frontier={save.frontier}
        viewing={room.n}
        onPick={(n) => {
          setSave((s) => ({ ...s, viewing: n }));
          setMapOpen(false);
        }}
      />

      <Dialog.Root open={menuOpen} onOpenChange={setMenuOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-40 bg-walnut/80" />
          <Dialog.Content className="fixed top-1/2 left-1/2 z-50 w-[min(24rem,calc(100%-2rem))] -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-line bg-surface p-5 text-cream">
            <Dialog.Title className="font-display text-2xl">House menu</Dialog.Title>
            <Dialog.Description className="mt-2 text-sm text-mist">
              Leaving for the front door keeps your progress.
            </Dialog.Description>
            <div className="mt-5 flex flex-col gap-3">
              <button type="button" className="btn btn-brass" onClick={onTitle}>
                Front door
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setConfirmReset(true)}>
                Start over
              </button>
              <Dialog.Close className="btn btn-ghost">Close</Dialog.Close>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root open={confirmReset} onOpenChange={setConfirmReset}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-40 bg-walnut/80" />
          <Dialog.Content className="fixed top-1/2 left-1/2 z-50 w-[min(24rem,calc(100%-2rem))] -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-line bg-surface p-5 text-cream">
            <Dialog.Title className="font-display text-2xl">Start over?</Dialog.Title>
            <Dialog.Description className="mt-2 text-sm text-mist">
              This forgets the room you have reached, the journal, and the clock.
            </Dialog.Description>
            <div className="mt-5 flex flex-col gap-3">
              <button type="button" className="btn btn-brass" onClick={onReset}>
                Forget this run
              </button>
              <Dialog.Close className="btn btn-ghost">Keep going</Dialog.Close>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </main>
  );
}

function RoomScene({
  wing,
  open,
  hotspots,
  selected,
  seen,
  onSelect,
  card,
}: {
  wing: Room["wing"];
  open: boolean;
  hotspots: Room["hotspots"];
  selected: string | null;
  seen: string[];
  onSelect: (id: string) => void;
  card?: ReactNode;
}) {
  return (
    <div className="scene flex-1" data-wing={wing}>
      <div className="scene-wall" />
      <div className="scene-floor" />
      <div className="scene-board" />
      <div className="scene-window" />
      <div className="scene-shelf" />
      <div className="scene-rug" />
      <div className={`scene-door ${open ? "open" : ""}`} aria-hidden>
        <i />
        <b />
        <span />
      </div>
      {hotspots.map((item) => {
        const Icon = ICONS[item.icon];
        return (
          <button
            key={item.id}
            type="button"
            className="hotspot"
            style={{ ["--x" as string]: item.x, ["--y" as string]: item.y }}
            data-on={selected === item.id}
            onClick={() => onSelect(item.id)}
            aria-pressed={selected === item.id}
          >
            <Icon aria-hidden className={`size-5 ${seen.includes(item.id) ? "text-brass" : "text-cream"}`} />
            <small>{item.label}</small>
          </button>
        );
      })}
      {card}
    </div>
  );
}

function LockControls({
  lock,
  attempt,
  setAttempt,
  signalLit,
  signalBusy,
  onSubmit,
  onOrder,
  onSignal,
  onWatch,
  onClearOrder,
  onEdit,
}: {
  lock: Lock;
  attempt: Attempt;
  setAttempt: Dispatch<SetStateAction<Attempt>>;
  signalLit: string | null;
  signalBusy: boolean;
  onSubmit: () => void;
  onOrder: (id: string) => void;
  onSignal: (id: string) => void;
  onWatch: () => void;
  onClearOrder: () => void;
  onEdit: () => void;
}) {
  return (
    <div>
      <h2 className="font-display text-2xl">The lock</h2>
      <p className="mt-1 text-sm leading-relaxed">{lock.prompt}</p>
      {lock.kind === "code" && (
        <CodeLock
          length={lock.answer.length}
          value={attempt.code}
          onChange={(code) => {
            onEdit();
            setAttempt((a) => ({ ...a, code }));
          }}
          onSubmit={onSubmit}
        />
      )}
      {lock.kind === "word" && (
        <form
          className="mt-4"
          onSubmit={(event) => {
            event.preventDefault();
            onSubmit();
          }}
        >
          <label className="block text-xs tracking-widest text-brass-deep uppercase" htmlFor="word-lock">
            {lock.answer.length} letters
          </label>
          <input
            id="word-lock"
            value={attempt.word}
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="characters"
            spellCheck={false}
            maxLength={lock.answer.length}
            onChange={(event) => {
              onEdit();
              setAttempt((a) => ({
                ...a,
                word: event.target.value.toUpperCase().replace(/[^A-Z]/g, ""),
              }));
            }}
            className="mt-2 w-full rounded-lg border border-brass-deep bg-paper-dim px-3 py-3 text-center font-display text-2xl tracking-widest text-ink uppercase"
          />
          <button type="submit" className="btn btn-ink mt-4 w-full" disabled={attempt.word.length !== lock.answer.length}>
            Try the lock
          </button>
        </form>
      )}
      {lock.kind === "order" && (
        <div className="mt-4">
          <div className="grid gap-2">
            {lock.steps.map((step) => {
              const pos = attempt.order.indexOf(step.id);
              return (
                <button key={step.id} type="button" className="btn btn-ink justify-between" onClick={() => onOrder(step.id)}>
                  <span>{step.label}</span>
                  <span className="tabular-nums text-brass">{pos >= 0 ? pos + 1 : ""}</span>
                </button>
              );
            })}
          </div>
          <button type="button" className="btn btn-ghost mt-3 w-full border-line text-ink" onClick={onClearOrder}>
            Reset order
          </button>
        </div>
      )}
      {lock.kind === "dials" && (
        <div className="mt-4 grid gap-3">
          {lock.dials.map((dial, index) => {
            const value = dial.options[attempt.dials[index] ?? 0] ?? dial.options[0];
            return (
              <button
                key={dial.id}
                type="button"
                className="btn btn-ink justify-between"
                onClick={() => {
                  onEdit();
                  setAttempt((a) => {
                    const dials = [...a.dials];
                    dials[index] = ((dials[index] ?? 0) + 1) % dial.options.length;
                    return { ...a, dials };
                  });
                }}
              >
                <span>{dial.label}</span>
                <span className="font-display text-xl text-brass">{value}</span>
              </button>
            );
          })}
          <button type="button" className="btn btn-brass" onClick={onSubmit}>
            Try the lock
          </button>
        </div>
      )}
      {lock.kind === "pick" && (
        <div className="mt-4 grid gap-2">
          {lock.options.map((option) => (
            <button
              key={option.id}
              type="button"
              className={`rounded-lg border px-3 py-3 text-left ${
                attempt.pick === option.id ? "border-brass-deep bg-paper-dim" : "border-line bg-paper"
              }`}
              onClick={() => {
                onEdit();
                setAttempt((a) => ({ ...a, pick: option.id }));
              }}
              aria-pressed={attempt.pick === option.id}
            >
              <span className="block font-medium">{option.label}</span>
              <span className="mt-1 block text-sm opacity-80">{option.detail}</span>
            </button>
          ))}
          <button type="button" className="btn btn-ink mt-2" onClick={onSubmit} disabled={!attempt.pick}>
            Try the lock
          </button>
        </div>
      )}
      {lock.kind === "signal" && (
        <div className="mt-4">
          <button type="button" className="btn btn-ink w-full" onClick={onWatch} disabled={signalBusy}>
            {signalBusy ? "Watching…" : "Watch the signal"}
          </button>
          <p className="mt-3 min-h-6 text-center text-sm tracking-wide text-ink">
            {attempt.signal.map((id) => lock.pads.find((pad) => pad.id === id)?.label ?? id).join(" · ") || "Repeat the flashes."}
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {lock.pads.map((pad) => {
              const lit = signalLit === pad.id;
              return (
                <button
                  key={pad.id}
                  type="button"
                  className={`btn btn-ink ${lit ? "bg-brass text-ink" : ""}`}
                  onClick={() => onSignal(pad.id)}
                  disabled={signalBusy}
                >
                  {pad.label}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function CodeLock({
  length,
  value,
  onChange,
  onSubmit,
}: {
  length: number;
  value: string;
  onChange: (next: string) => void;
  onSubmit: () => void;
}) {
  const keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];
  return (
    <div className="mt-4">
      <div className="flex justify-center gap-2" aria-hidden>
        {Array.from({ length }, (_, i) => (
          <div
            key={i}
            className="flex h-12 w-10 items-center justify-center rounded-lg bg-paper-dim font-display text-2xl text-ink tabular-nums"
          >
            {value[i] ?? ""}
          </div>
        ))}
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        {keys.map((key) => (
          <button
            key={key}
            type="button"
            className="btn btn-ink"
            onClick={() => {
              if (value.length >= length) return;
              onChange(value + key);
              playSfx("tick");
            }}
          >
            {key}
          </button>
        ))}
        <button type="button" className="btn btn-ghost border-line text-ink" onClick={() => onChange("")}>
          Clear
        </button>
        <button
          type="button"
          className="btn btn-ink"
          onClick={() => {
            if (value.length >= length) return;
            onChange(value + "0");
            playSfx("tick");
          }}
        >
          0
        </button>
        <button
          type="button"
          className="btn btn-ghost border-line text-ink"
          onClick={() => onChange(value.slice(0, -1))}
          aria-label="Backspace"
        >
          <Delete aria-hidden />
        </button>
      </div>
      <button type="button" className="btn btn-brass mt-3 w-full" onClick={onSubmit} disabled={value.length !== length}>
        Try the lock
      </button>
    </div>
  );
}

function HouseMap({
  open,
  onOpenChange,
  frontier,
  viewing,
  onPick,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  frontier: number;
  viewing: number;
  onPick: (n: number) => void;
}) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-walnut/80" />
        <Dialog.Content className="fixed top-1/2 left-1/2 z-50 max-h-[min(40rem,calc(100%-2rem))] w-[min(36rem,calc(100%-2rem))] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-2xl border border-line bg-surface p-5 text-cream">
          <div className="flex items-start justify-between gap-3">
            <div>
              <Dialog.Title className="font-display text-2xl">The house</Dialog.Title>
              <Dialog.Description className="mt-1 text-sm text-mist">
                Open rooms can be revisited. Locked rooms wait.
              </Dialog.Description>
            </div>
            <Dialog.Close className="btn btn-ghost btn-icon" aria-label="Close map">
              <X aria-hidden />
            </Dialog.Close>
          </div>
          <div className="mt-5 space-y-5">
            {WINGS.map((wing) => (
              <section key={wing.id}>
                <h3 className="text-xs tracking-widest text-brass uppercase">{wing.name}</h3>
                <p className="mt-1 text-sm text-mist">{wing.motto}</p>
                <div className="mt-2 grid grid-cols-5 gap-2">
                  {ROOMS.filter((item) => item.wing === wing.id).map((item) => {
                    const locked = item.n > frontier;
                    const current = item.n === viewing;
                    return (
                      <button
                        key={item.n}
                        type="button"
                        disabled={locked}
                        onClick={() => onPick(item.n)}
                        className={`btn min-w-0 px-0 tabular-nums ${
                          current ? "btn-brass" : locked ? "btn-ghost" : "btn-ghost border-brass text-brass"
                        }`}
                        aria-label={`${locked ? "Locked room" : "Room"} ${item.n}, ${item.name}`}
                      >
                        {item.n}
                      </button>
                    );
                  })}
                </div>
              </section>
            ))}
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
