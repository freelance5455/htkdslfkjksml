import { BookOpen, Calculator, FlaskConical, Landmark, Languages, Map } from "lucide-react";
import type { SubjectIcon } from "@/content/catalog";

const icons = {
  calculator: Calculator,
  languages: Languages,
  book: BookOpen,
  flask: FlaskConical,
  map: Map,
  landmark: Landmark,
};

export function SubjectGlyph({ name, className }: { name: SubjectIcon; className?: string }) {
  const Icon = icons[name];
  return <Icon className={className} strokeWidth={1.75} aria-hidden="true" />;
}
