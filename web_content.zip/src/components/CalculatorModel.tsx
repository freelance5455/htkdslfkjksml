"use client";

// Realistic ClassWiz-style (fx-991CW inspired) scientific calculator in 3D.
// Every key is a real clickable mesh, the LCD is a live canvas texture.

import { useEffect, useMemo, useRef, useState } from "react";
import { useFrame, type ThreeEvent } from "@react-three/fiber";
import * as THREE from "three";
import { BODY_H, BODY_W, KEY_DEFS, type KeyDef, type KeyShape, type KeyTone } from "@/lib/calc-keys";
import type { ScreenData } from "@/lib/calculator";

const FRONT_Z = 0.21;

/* ------------------------------------------------------------------ theme */

export type CalcTheme = ReturnType<typeof makeTheme>;

export function makeTheme(bodyColor: string) {
  const c = new THREE.Color(bodyColor);
  const lum = 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b; // linear luminance
  const light = lum > 0.3;
  const mix = (target: string, t: number) => "#" + c.clone().lerp(new THREE.Color(target), t).getHexString();
  if (light) {
    return {
      light,
      body: bodyColor,
      key: mix("#ffffff", 0.38),
      func: mix("#ffffff", 0.22),
      nav: mix("#ffffff", 0.3),
      keyText: "#2b1d24",
      funcText: "#3a2a33",
      brand: "#3b2a33",
      print: "#5b4650",
      shiftText: "#9a5b00",
      bezel: mix("#000000", 0.6),
      dpad: mix("#000000", 0.07),
    };
  }
  return {
    light,
    body: bodyColor,
    key: mix("#ffffff", 0.11),
    func: mix("#ffffff", 0.07),
    nav: mix("#ffffff", 0.09),
    keyText: "#f8fafc",
    funcText: "#e2e8f0",
    brand: "#f1f5f9",
    print: "#aab3c2",
    shiftText: "#e3b341",
    bezel: "#07080b",
    dpad: mix("#ffffff", 0.045),
  };
}

/* ------------------------------------------------------------- geometries */

const geoCache = new Map<string, THREE.BufferGeometry>();

function roundedRect(w: number, h: number, r: number, depth: number, bevel = 0.02): THREE.BufferGeometry {
  const key = `rr|${w}|${h}|${r}|${depth}|${bevel}`;
  const cached = geoCache.get(key);
  if (cached) return cached;
  const x = -w / 2 + bevel;
  const y = -h / 2 + bevel;
  const ww = w - 2 * bevel;
  const hh = h - 2 * bevel;
  const rr = Math.min(r, ww / 2, hh / 2);
  const s = new THREE.Shape();
  s.moveTo(x + rr, y);
  s.lineTo(x + ww - rr, y);
  s.absarc(x + ww - rr, y + rr, rr, -Math.PI / 2, 0, false);
  s.lineTo(x + ww, y + hh - rr);
  s.absarc(x + ww - rr, y + hh - rr, rr, 0, Math.PI / 2, false);
  s.lineTo(x + rr, y + hh);
  s.absarc(x + rr, y + hh - rr, rr, Math.PI / 2, Math.PI, false);
  s.lineTo(x, y + rr);
  s.absarc(x + rr, y + rr, rr, Math.PI, Math.PI * 1.5, false);
  const g = new THREE.ExtrudeGeometry(s, {
    depth: Math.max(0.001, depth - 2 * bevel),
    bevelEnabled: bevel > 0,
    bevelThickness: bevel,
    bevelSize: bevel,
    bevelSegments: 3,
    curveSegments: 10,
  });
  g.center();
  geoCache.set(key, g);
  return g;
}

function disc(r: number, depth: number): THREE.BufferGeometry {
  const key = `disc|${r}|${depth}`;
  const cached = geoCache.get(key);
  if (cached) return cached;
  const g = new THREE.CylinderGeometry(r, r, depth, 40);
  g.rotateX(Math.PI / 2);
  geoCache.set(key, g);
  return g;
}

type ShapeInfo = { geometry: THREE.BufferGeometry; depth: number; face: [number, number]; raised: number };

function shapeInfo(shape: KeyShape): ShapeInfo {
  switch (shape) {
    case "round":
      return { geometry: disc(0.17, 0.12), depth: 0.12, face: [0.3, 0.3], raised: 0 };
    case "rocker":
      return { geometry: disc(0.155, 0.1), depth: 0.1, face: [0.26, 0.26], raised: 0.06 };
    case "ok":
      return { geometry: disc(0.2, 0.1), depth: 0.1, face: [0.32, 0.32], raised: 0.06 };
    case "arrow-up":
    case "arrow-down":
      return { geometry: roundedRect(0.34, 0.22, 0.08, 0.1, 0.02), depth: 0.1, face: [0.3, 0.2], raised: 0.06 };
    case "arrow-left":
    case "arrow-right":
      return { geometry: roundedRect(0.22, 0.34, 0.08, 0.1, 0.02), depth: 0.1, face: [0.2, 0.3], raised: 0.06 };
    case "pill":
      return { geometry: roundedRect(0.5, 0.32, 0.15, 0.12, 0.025), depth: 0.12, face: [0.48, 0.3], raised: 0 };
    case "main":
    default:
      return { geometry: roundedRect(0.64, 0.48, 0.22, 0.13, 0.03), depth: 0.13, face: [0.6, 0.44], raised: 0 };
  }
}

/* --------------------------------------------------------------- textures */

const texCache = new Map<string, THREE.CanvasTexture>();

function labelTexture(text: string, color: string, aspect: number): THREE.CanvasTexture {
  const key = `${text}|${color}|${aspect.toFixed(2)}`;
  const cached = texCache.get(key);
  if (cached) return cached;
  const cw = 256;
  const ch = Math.max(64, Math.round(cw / aspect));
  const canvas = document.createElement("canvas");
  canvas.width = cw;
  canvas.height = ch;
  const ctx = canvas.getContext("2d")!;
  let size = Math.round(ch * (Array.from(text).length <= 2 ? 0.6 : 0.46));
  do {
    ctx.font = `700 ${size}px Arial, Helvetica, sans-serif`;
    if (ctx.measureText(text).width <= cw * 0.84) break;
    size -= 2;
  } while (size > 10);
  ctx.fillStyle = color;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, cw / 2, ch / 2 + size * 0.05);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  texCache.set(key, tex);
  return tex;
}

function solarTexture(): THREE.CanvasTexture {
  const cached = texCache.get("__solar");
  if (cached) return cached;
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 170;
  const ctx = canvas.getContext("2d")!;
  const g = ctx.createLinearGradient(0, 0, 0, 170);
  g.addColorStop(0, "#3a2620");
  g.addColorStop(1, "#160c0a");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 512, 170);
  ctx.strokeStyle = "rgba(120,80,70,0.55)";
  ctx.lineWidth = 3;
  for (let i = 1; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo((512 / 4) * i, 0);
    ctx.lineTo((512 / 4) * i, 170);
    ctx.stroke();
  }
  const hl = ctx.createLinearGradient(0, 0, 512, 170);
  hl.addColorStop(0, "rgba(255,255,255,0.12)");
  hl.addColorStop(0.5, "rgba(255,255,255,0)");
  ctx.fillStyle = hl;
  ctx.fillRect(0, 0, 512, 170);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  texCache.set("__solar", tex);
  return tex;
}

function printTexture(theme: CalcTheme, accent: string, modelLabel: string): THREE.CanvasTexture {
  const PW = 1024;
  const PH = Math.round((1024 * BODY_H) / BODY_W);
  const canvas = document.createElement("canvas");
  canvas.width = PW;
  canvas.height = PH;
  const ctx = canvas.getContext("2d")!;
  const px = (x: number, y: number): [number, number] => [
    ((x + BODY_W / 2) / BODY_W) * PW,
    ((BODY_H / 2 - y) / BODY_H) * PH,
  ];
  ctx.textBaseline = "middle";

  // brand
  ctx.fillStyle = theme.brand;
  ctx.font = "900 60px 'Arial Black', Arial, sans-serif";
  ctx.textAlign = "left";
  const [bx, by] = px(-1.78, 3.9);
  ctx.fillText("CALCORA", bx, by);
  ctx.fillStyle = theme.print;
  ctx.font = "600 24px Arial, sans-serif";
  const [mx, my] = px(-1.78, 3.6);
  ctx.fillText(modelLabel, mx, my);

  // CLASSPRO wordmark (letter-spaced)
  ctx.font = "italic 600 26px Arial, sans-serif";
  const word = "CLASSPRO";
  const spacing = 12;
  const widths = word.split("").map((ch) => ctx.measureText(ch).width);
  const total = widths.reduce((a, b) => a + b, 0) + spacing * (word.length - 1);
  let [wx] = px(1.86, 1.67);
  const [, wy] = px(1.86, 1.67);
  wx -= total;
  word.split("").forEach((ch, i) => {
    ctx.fillText(ch, wx, wy);
    wx += widths[i] + spacing;
  });

  // futuristic accent line
  const [lx1, ly] = px(-1.86, 1.67);
  const [lx2] = px(0.25, 1.67);
  const lg = ctx.createLinearGradient(lx1, 0, lx2, 0);
  lg.addColorStop(0, accent);
  lg.addColorStop(1, "rgba(0,0,0,0)");
  ctx.strokeStyle = lg;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(lx1, ly);
  ctx.lineTo(lx2, ly);
  ctx.stroke();

  // gold SHIFT labels above keys
  ctx.textAlign = "center";
  ctx.fillStyle = theme.shiftText;
  ctx.font = "700 23px Arial, sans-serif";
  for (const k of KEY_DEFS) {
    if (!k.shiftLabel) continue;
    const off = k.shape === "pill" ? 0.26 : 0.34;
    const [sx, sy] = px(k.x, k.y + off);
    ctx.fillText(k.shiftLabel, sx, sy);
  }

  // tiny captions
  ctx.fillStyle = theme.print;
  ctx.font = "600 18px Arial, sans-serif";
  const [hx, hy] = px(1.6, 1.62);
  ctx.fillText("HISTORY", hx, hy - 0);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

/* ------------------------------------------------------------------- LCD */

const LCD_W = 1024;
const LCD_H = 410;

function drawLCD(ctx: CanvasRenderingContext2D, d: ScreenData, blink: boolean) {
  const g = ctx.createLinearGradient(0, 0, 0, LCD_H);
  g.addColorStop(0, "#d6dfcd");
  g.addColorStop(1, "#b7c3ad");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, LCD_W, LCD_H);
  const sg = ctx.createLinearGradient(0, 0, 0, 46);
  sg.addColorStop(0, "rgba(0,0,0,0.2)");
  sg.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = sg;
  ctx.fillRect(0, 0, LCD_W, 46);

  const ink = "#1a211c";
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  ctx.font = "700 30px Arial, sans-serif";
  let x = 22;
  const tag = (t: string, inverted: boolean) => {
    const w = ctx.measureText(t).width + 16;
    if (inverted) {
      ctx.fillStyle = ink;
      ctx.fillRect(x, 14, w, 40);
      ctx.fillStyle = "#d6dfcd";
    } else ctx.fillStyle = ink;
    ctx.fillText(t, x + 8, 35);
    x += w + 12;
  };
  if (d.shift) tag("S", true);
  tag(d.angle === "DEG" ? "D" : "R", true);
  tag("Math", false);
  if (d.fraction) tag("a/b", false);
  ctx.fillStyle = ink;
  ctx.textAlign = "right";
  ctx.fillText("▲▼", LCD_W - 22, 35);
  ctx.textAlign = "left";

  if (d.error) {
    ctx.textAlign = "center";
    ctx.font = "700 72px Arial, sans-serif";
    ctx.fillText(d.error, LCD_W / 2, 185);
    ctx.font = "600 32px Arial, sans-serif";
    ctx.fillText("[AC] :Cancel     [◀][▶] :Goto", LCD_W / 2, 300);
    ctx.textAlign = "left";
    return;
  }

  // expression line (monospace grid)
  ctx.font = "600 62px 'Courier New', Courier, monospace";
  const cw = ctx.measureText("0").width;
  const chars = Array.from(d.expression);
  const maxChars = Math.floor((LCD_W - 50) / cw);
  let start = 0;
  if (d.cursor !== null && d.cursor > maxChars - 1) start = d.cursor - (maxChars - 1);
  const visible = chars.slice(start, start + maxChars);
  visible.forEach((ch, i) => ctx.fillText(ch, 24 + i * cw, 122));
  if (d.cursor !== null && blink) {
    const cx = 24 + (d.cursor - start) * cw;
    ctx.fillRect(cx - 2, 86, 5, 72);
  }

  // result line
  if (d.result) {
    let size = 106;
    ctx.textAlign = "right";
    do {
      ctx.font = `700 ${size}px Arial, sans-serif`;
      if (ctx.measureText(d.result).width < LCD_W - 60) break;
      size -= 6;
    } while (size > 36);
    ctx.fillText(d.result, LCD_W - 30, 318);
    ctx.textAlign = "left";
  }
}

function Screen({ data }: { data: ScreenData }) {
  const canvas = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = LCD_W;
    c.height = LCD_H;
    return c;
  }, []);
  const texture = useMemo(() => {
    const t = new THREE.CanvasTexture(canvas);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    return t;
  }, [canvas]);
  const [blink, setBlink] = useState(true);
  const hasCursor = data.cursor !== null;

  useEffect(() => {
    if (!hasCursor) return;
    const id = setInterval(() => setBlink((b) => !b), 530);
    return () => clearInterval(id);
  }, [hasCursor]);

  useEffect(() => {
    drawLCD(canvas.getContext("2d")!, data, blink);
    texture.needsUpdate = true;
  }, [data, blink, canvas, texture]);

  useEffect(() => () => texture.dispose(), [texture]);

  return (
    <mesh position={[0, 2.72, FRONT_Z + 0.023]}>
      <planeGeometry args={[3.66, 1.47]} />
      <meshStandardMaterial
        map={texture}
        emissive="#ffffff"
        emissiveMap={texture}
        emissiveIntensity={0.42}
        roughness={0.28}
        metalness={0.05}
      />
    </mesh>
  );
}

/* ------------------------------------------------------------------ keys */

function toneColors(tone: KeyTone, theme: CalcTheme, accent: string) {
  switch (tone) {
    case "func":
      return { body: theme.func, text: theme.funcText, emissive: accent, glow: 0 };
    case "nav":
      return { body: theme.nav, text: theme.funcText, emissive: accent, glow: 0 };
    case "shift":
      return { body: theme.light ? "#8b5cf6" : "#c9a227", text: theme.light ? "#ffffff" : "#1a1405", emissive: theme.light ? "#8b5cf6" : "#f5c542", glow: 0.12 };
    case "danger":
      return { body: theme.key, text: theme.light ? "#be123c" : "#fda4af", emissive: "#fb7185", glow: 0.06 };
    case "exe":
      return { body: accent, text: "#ffffff", emissive: accent, glow: 0.45 };
    case "base":
    default:
      return { body: theme.key, text: theme.keyText, emissive: accent, glow: 0 };
  }
}

function Key({
  def,
  theme,
  accent,
  pressed,
  active,
  onKey,
}: {
  def: KeyDef;
  theme: CalcTheme;
  accent: string;
  pressed: boolean;
  active: boolean;
  onKey?: (id: string) => void;
}) {
  const inner = useRef<THREE.Group>(null);
  const [hover, setHover] = useState(false);
  const info = shapeInfo(def.shape);
  const colors = toneColors(def.tone, theme, accent);
  const tex = useMemo(
    () => labelTexture(def.label, colors.text, info.face[0] / info.face[1]),
    [def.label, colors.text, info.face],
  );
  const baseZ = FRONT_Z + info.raised + info.depth / 2;

  useFrame((_, dt) => {
    const g = inner.current;
    if (!g) return;
    const target = pressed ? -0.055 : hover ? 0.015 : 0;
    g.position.z = THREE.MathUtils.damp(g.position.z, target, 24, dt);
  });

  const intensity = pressed ? 1 : active ? 0.85 : hover && onKey ? 0.38 : colors.glow;

  return (
    <group position={[def.x, def.y, baseZ]}>
      <group
        ref={inner}
        onClick={(e: ThreeEvent<MouseEvent>) => {
          e.stopPropagation();
          if (!onKey || e.delta > 8) return;
          onKey(def.id);
        }}
        onPointerOver={(e: ThreeEvent<PointerEvent>) => {
          e.stopPropagation();
          setHover(true);
          if (onKey) document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          setHover(false);
          document.body.style.cursor = "auto";
        }}
      >
        <mesh geometry={info.geometry}>
          <meshPhysicalMaterial
            color={colors.body}
            roughness={0.42}
            metalness={0.12}
            clearcoat={0.5}
            clearcoatRoughness={0.4}
            emissive={colors.emissive}
            emissiveIntensity={intensity}
          />
        </mesh>
        <mesh position={[0, 0, info.depth / 2 + 0.004]}>
          <planeGeometry args={info.face} />
          <meshBasicMaterial map={tex} transparent depthWrite={false} toneMapped={false} />
        </mesh>
      </group>
    </group>
  );
}

/* ------------------------------------------------------------------ body */

export type CalculatorModelProps = {
  screen: ScreenData;
  bodyColor?: string;
  accent?: string;
  modelLabel?: string;
  onKey?: (id: string) => void;
  pressedId?: string | null;
};

export default function CalculatorModel({
  screen,
  bodyColor = "#1c1d22",
  accent = "#8b5cf6",
  modelLabel = "CLC-991CW",
  onKey,
  pressedId = null,
}: CalculatorModelProps) {
  const theme = useMemo(() => makeTheme(bodyColor), [bodyColor]);
  const bodyGeo = useMemo(() => roundedRect(BODY_W, BODY_H, 0.62, 0.42, 0.07), []);
  const rimGeo = useMemo(() => roundedRect(BODY_W + 0.14, BODY_H + 0.14, 0.69, 0.26, 0.04), []);
  const bezelGeo = useMemo(() => roundedRect(3.94, 1.8, 0.14, 0.03, 0.008), []);
  const rockerGeo = useMemo(() => roundedRect(0.42, 0.9, 0.21, 0.06, 0.01), []);
  const print = useMemo(() => printTexture(theme, accent, modelLabel), [theme, accent, modelLabel]);
  const solar = useMemo(() => solarTexture(), []);

  useEffect(() => () => print.dispose(), [print]);

  return (
    <group>
      {/* glowing futuristic rim */}
      <mesh geometry={rimGeo} position={[0, 0, -0.06]}>
        <meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={1.1} toneMapped={false} />
      </mesh>

      {/* plastic body */}
      <mesh geometry={bodyGeo}>
        <meshPhysicalMaterial
          color={theme.body}
          roughness={0.48}
          metalness={0.1}
          clearcoat={0.55}
          clearcoatRoughness={0.38}
        />
      </mesh>

      {/* printed labels (brand, CLASSPRO, gold SHIFT labels) */}
      <mesh position={[0, 0, FRONT_Z + 0.002]}>
        <planeGeometry args={[BODY_W, BODY_H]} />
        <meshBasicMaterial map={print} transparent depthWrite={false} toneMapped={false} />
      </mesh>

      {/* solar panel */}
      <mesh position={[0.98, 3.87, FRONT_Z + 0.004]}>
        <planeGeometry args={[1.5, 0.5]} />
        <meshStandardMaterial map={solar} roughness={0.15} metalness={0.45} />
      </mesh>

      {/* screen bezel + live LCD */}
      <mesh geometry={bezelGeo} position={[0, 2.72, FRONT_Z + 0.008]}>
        <meshStandardMaterial color={theme.bezel} roughness={0.22} metalness={0.35} />
      </mesh>
      <Screen data={screen} />

      {/* D-pad disc & history rocker base */}
      <mesh geometry={disc(0.64, 0.06)} position={[0, 0.96, FRONT_Z + 0.03]}>
        <meshPhysicalMaterial color={theme.dpad} roughness={0.35} metalness={0.2} clearcoat={0.6} />
      </mesh>
      <mesh geometry={rockerGeo} position={[1.6, 1.11, FRONT_Z + 0.03]}>
        <meshPhysicalMaterial color={theme.dpad} roughness={0.35} metalness={0.2} clearcoat={0.6} />
      </mesh>

      {KEY_DEFS.map((def) => (
        <Key
          key={def.id}
          def={def}
          theme={theme}
          accent={accent}
          pressed={pressedId === def.id}
          active={def.id === "shift" && screen.shift}
          onKey={onKey}
        />
      ))}
    </group>
  );
}
