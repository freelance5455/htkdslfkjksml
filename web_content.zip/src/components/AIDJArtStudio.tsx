/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Image as ImageIcon,
  Disc,
  Maximize,
  Download,
  Check,
  AlertCircle,
  Loader2,
} from 'lucide-react';

interface AIDJArtStudioProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyCover: (url: string) => void;
  onApplyBackdrop: (url: string) => void;
}

export const AIDJArtStudio: React.FC<AIDJArtStudioProps> = ({
  isOpen,
  onClose,
  onApplyCover,
  onApplyBackdrop,
}) => {
  const [prompt, setPrompt] = useState(
    'DJ SUNNY futuristic cyberpunk EDM stage with neon laser beams, magenta and cyan lighting, giant LED sound system'
  );
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [aspectRatio, setAspectRatio] = useState<
    '1:1' | '2:3' | '3:2' | '3:4' | '4:3' | '9:16' | '16:9' | '21:9'
  >('1:1');
  const [model, setModel] = useState<'gemini-3-pro-image' | 'gemini-nano-banana-2.1'>(
    'gemini-3-pro-image'
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const presets = [
    {
      title: 'Cyberpunk DJ Stage',
      prompt: 'DJ SUNNY futuristic cyberpunk concert stage with neon laser beams, magenta & cyan lighting, giant LED skull and sound systems',
    },
    {
      title: 'Holographic Vinyl Disc',
      prompt: 'Holographic DJ vinyl turntable disc floating in deep ultraviolet space with glowing neon soundwaves',
    },
    {
      title: 'Bass Drop Shockwave',
      prompt: 'Epic EDM music festival explosion with laser pyrotechnics, neon smoke, and pulsing bass speakers',
    },
    {
      title: 'Retro Outrun Grid',
      prompt: 'Synthwave 80s neon grid highway with sunset synth sun and glowing neon equalizer towers',
    },
    {
      title: 'Android DJ Robot',
      prompt: 'Futuristic robotic android DJ wearing glowing neon headphones spinning records on dual turntables',
    },
  ];

  const handleGenerate = async () => {
    setIsGenerating(true);
    setErrorMsg(null);
    setGeneratedImageUrl(null);

    try {
      const res = await fetch('/api/generate-cover', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          aspectRatio,
          imageSize,
          model,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate image');
      }

      setGeneratedImageUrl(data.imageUrl);
      setToastMsg('✨ Artwork generated successfully!');
      setTimeout(() => setToastMsg(null), 3500);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(
        err.message ||
          'Could not generate artwork. Ensure GEMINI_API_KEY is configured in your Settings > Secrets panel.'
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleApplyVinyl = () => {
    if (!generatedImageUrl) return;
    onApplyCover(generatedImageUrl);
    setToastMsg('🎵 Applied as Vinyl Disc Label!');
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleApplyBackdrop = () => {
    if (!generatedImageUrl) return;
    onApplyBackdrop(generatedImageUrl);
    setToastMsg('🌌 Applied as Stage Visualizer Backdrop!');
    setTimeout(() => setToastMsg(null), 3000);
  };

  const aspectRatios: Array<'1:1' | '2:3' | '3:2' | '3:4' | '4:3' | '9:16' | '16:9' | '21:9'> = [
    '1:1',
    '2:3',
    '3:2',
    '3:4',
    '4:3',
    '9:16',
    '16:9',
    '21:9',
  ];

  const imageSizes: Array<'1K' | '2K' | '4K'> = ['1K', '2K', '4K'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-3xl bg-[#0e0f1c] border border-cyan-500/40 p-6 shadow-[0_0_60px_rgba(0,240,255,0.25)]">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-cyan-500 to-purple-600 shadow-[0_0_15px_#00f0ff]">
            <Sparkles className="w-6 h-6 text-black" />
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-white font-dj tracking-wider">
              AI DJ ART &amp; STAGE STUDIO
            </h3>
            <p className="text-xs text-cyan-300">
              Generate studio-grade DJ album art, vinyl center labels &amp; stage backdrops
            </p>
          </div>
        </div>

        {/* Prompt Presets */}
        <div className="mb-4">
          <label className="block text-[11px] font-bold font-dj uppercase text-zinc-300 mb-2">
            QUICK DJ STAGE PRESETS
          </label>
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {presets.map((item, idx) => (
              <button
                key={idx}
                onClick={() => setPrompt(item.prompt)}
                className="shrink-0 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-700/80 hover:border-cyan-400 text-zinc-300 hover:text-cyan-300 text-xs font-medium transition-all"
              >
                {item.title}
              </button>
            ))}
          </div>
        </div>

        {/* Prompt Input */}
        <div className="mb-4">
          <label className="block text-[11px] font-bold font-dj uppercase text-zinc-300 mb-1.5">
            ARTWORK PROMPT
          </label>
          <textarea
            rows={3}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your DJ artwork, concert visuals, neon lighting effects..."
            className="w-full px-3.5 py-2.5 rounded-2xl bg-black/60 border border-zinc-700 focus:border-cyan-400 text-sm text-white outline-none transition-colors"
          />
        </div>

        {/* Affordances: Image Size & Aspect Ratio Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
          
          {/* Image Size Affordance (1K, 2K, 4K) */}
          <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold font-dj uppercase text-cyan-300">
                IMAGE SIZE / RESOLUTION
              </span>
              <span className="text-[10px] text-zinc-400 font-mono">Ultra HD</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {imageSizes.map((size) => (
                <button
                  key={size}
                  onClick={() => setImageSize(size)}
                  className={`py-2 rounded-xl text-xs font-bold font-mono transition-all ${
                    imageSize === size
                      ? 'bg-cyan-500 text-black shadow-[0_0_12px_#00f0ff]'
                      : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Ratio Affordance (1:1, 2:3, 3:2, 3:4, 4:3, 9:16, 16:9, 21:9) */}
          <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold font-dj uppercase text-purple-300">
                ASPECT RATIO
              </span>
              <span className="text-[10px] text-zinc-400 font-mono">{aspectRatio}</span>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {aspectRatios.map((ratio) => (
                <button
                  key={ratio}
                  onClick={() => setAspectRatio(ratio)}
                  className={`py-1.5 rounded-lg text-[10px] font-bold font-mono transition-all ${
                    aspectRatio === ratio
                      ? 'bg-purple-600 text-white shadow-[0_0_10px_#b026ff]'
                      : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                  }`}
                >
                  {ratio}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Model Selection Affordance */}
        <div className="mb-5 p-3 rounded-2xl bg-zinc-900/40 border border-zinc-800 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold font-dj text-zinc-300 uppercase">
              AI MODEL ENGINE:
            </span>
            <p className="text-[10px] text-zinc-500">
              High-Fidelity Studio Generation
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setModel('gemini-3-pro-image')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                model === 'gemini-3-pro-image'
                  ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-black font-bold shadow-[0_0_10px_#00f0ff]'
                  : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              gemini-3-pro-image
            </button>
            <button
              onClick={() => setModel('gemini-nano-banana-2.1')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                model === 'gemini-nano-banana-2.1'
                  ? 'bg-purple-600 text-white font-bold shadow-[0_0_10px_#b026ff]'
                  : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              nano-banana-2.1
            </button>
          </div>
        </div>

        {/* Generate Button */}
        <button
          onClick={handleGenerate}
          disabled={isGenerating || !prompt.trim()}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 text-black font-extrabold text-sm font-dj tracking-widest uppercase hover:brightness-110 active:scale-98 transition-all disabled:opacity-50 shadow-[0_0_20px_rgba(0,240,255,0.4)] flex items-center justify-center gap-2"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin text-black" />
              <span>GENERATING STUDIO ARTWORK ({imageSize})...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 text-black" />
              <span>GENERATE HIGH-RES ARTWORK ({imageSize} • {aspectRatio})</span>
            </>
          )}
        </button>

        {/* Error Notice */}
        {errorMsg && (
          <div className="mt-4 p-3.5 rounded-2xl bg-red-950/40 border border-red-500/50 flex items-start gap-2.5 text-xs text-red-300">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Success Toast */}
        {toastMsg && (
          <div className="mt-3 p-3 rounded-2xl bg-emerald-950/50 border border-emerald-500/50 flex items-center gap-2 text-xs text-emerald-300">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{toastMsg}</span>
          </div>
        )}

        {/* Generated Image Showcase & Actions */}
        {generatedImageUrl && (
          <div className="mt-5 p-4 rounded-3xl bg-black/70 border border-cyan-400/50 shadow-[0_0_25px_rgba(0,240,255,0.25)] animate-fade-in">
            <div className="relative rounded-2xl overflow-hidden max-h-[340px] flex items-center justify-center bg-zinc-950">
              <img
                src={generatedImageUrl}
                alt="Generated DJ Art"
                className="max-h-[340px] w-auto object-contain rounded-2xl shadow-2xl"
              />
            </div>

            {/* Action Bar */}
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                onClick={handleApplyVinyl}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-300 text-xs font-bold font-dj uppercase active:scale-95 transition-all shadow-[0_0_10px_rgba(0,240,255,0.3)]"
              >
                <Disc className="w-4 h-4" />
                <span>APPLY TO VINYL</span>
              </button>

              <button
                onClick={handleApplyBackdrop}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 border border-purple-400 text-purple-300 text-xs font-bold font-dj uppercase active:scale-95 transition-all shadow-[0_0_10px_rgba(176,38,255,0.3)]"
              >
                <Maximize className="w-4 h-4" />
                <span>STAGE BACKDROP</span>
              </button>

              <a
                href={generatedImageUrl}
                download={`dj-sunny-artwork-${Date.now()}.png`}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 text-xs font-bold font-dj uppercase active:scale-95 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>SAVE IMAGE</span>
              </a>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
