import React, { useEffect, useRef } from 'react';
import { Music, Radio } from 'lucide-react';

interface AudioVisualizerProps {
  isPlaying: boolean;
  isGenerating: boolean;
  audioRef: React.RefObject<HTMLAudioElement | null>;
  analyserNode?: AnalyserNode | null;
}

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({
  isPlaying,
  isGenerating,
  audioRef,
  analyserNode,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let time = 0;
    const barCount = 42;
    const dataArray = new Uint8Array(64);

    const render = () => {
      time += 0.08;
      const width = canvas.width;
      const height = canvas.height;

      ctx.clearRect(0, 0, width, height);

      // If we have an AnalyserNode and audio is playing, pull frequency data
      if (analyserNode && isPlaying) {
        analyserNode.getByteFrequencyData(dataArray);
      }

      const barWidth = width / barCount - 2;
      const centerY = height / 2;

      for (let i = 0; i < barCount; i++) {
        let normalizedHeight = 0.08; // baseline

        if (isPlaying) {
          if (analyserNode) {
            // Map frequency bin to bar
            const freqVal = dataArray[i % dataArray.length] / 255;
            normalizedHeight = Math.max(0.12, freqVal * 0.95);
          } else {
            // Realistic simulated speech waveform
            const wave1 = Math.sin(time * 2.5 + i * 0.35);
            const wave2 = Math.cos(time * 1.8 - i * 0.2);
            const wave3 = Math.sin(time * 4.0 + i * 0.6) * 0.5;
            normalizedHeight = Math.max(0.15, Math.abs(wave1 * 0.45 + wave2 * 0.35 + wave3 * 0.2));
          }
        } else if (isGenerating) {
          // Energetic pulsing loading wave
          normalizedHeight = Math.abs(Math.sin(time * 3 + i * 0.25)) * 0.7 + 0.15;
        }

        const barHeight = Math.max(4, normalizedHeight * (height - 12));
        const x = i * (barWidth + 2) + 2;
        const y = centerY - barHeight / 2;

        // Color gradient for bars (Indigo -> Violet -> Cyan)
        const gradient = ctx.createLinearGradient(0, y, 0, y + barHeight);
        if (isGenerating) {
          gradient.addColorStop(0, '#a855f7');
          gradient.addColorStop(1, '#6366f1');
        } else if (isPlaying) {
          gradient.addColorStop(0, '#818cf8');
          gradient.addColorStop(0.5, '#6366f1');
          gradient.addColorStop(1, '#38bdf8');
        } else {
          gradient.addColorStop(0, '#374151');
          gradient.addColorStop(1, '#1f2937');
        }

        ctx.fillStyle = gradient;
        // Rounded bar
        ctx.beginPath();
        const radius = Math.min(barWidth / 2, 3);
        ctx.roundRect(x, y, barWidth, barHeight, radius);
        ctx.fill();
      }

      animationFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, isGenerating, analyserNode]);

  // Adjust canvas pixel density
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * (window.devicePixelRatio || 1);
      canvas.height = rect.height * (window.devicePixelRatio || 1);
    };
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  return (
    <div className="relative h-24 bg-gray-950/80 border border-gray-800/80 rounded-xl p-2.5 flex items-center justify-center overflow-hidden shadow-inner group">
      <canvas
        ref={canvasRef}
        className="w-full h-full block"
        style={{ width: '100%', height: '100%' }}
      />

      {!isPlaying && !isGenerating && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-950/50 backdrop-blur-[2px] text-gray-400 text-xs gap-1.5 transition-opacity duration-300">
          <div className="w-8 h-8 rounded-full bg-indigo-950/70 border border-indigo-800/40 flex items-center justify-center text-indigo-400">
            <Music className="w-4 h-4 opacity-80" />
          </div>
          <span className="font-medium text-gray-300">
            Press &quot;Generate Voice&quot; to preview high-fidelity audio
          </span>
        </div>
      )}

      {isGenerating && (
        <div className="absolute top-2 right-3 flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-indigo-950/80 border border-indigo-700/60 text-[10px] text-indigo-300 font-mono">
          <Radio className="w-3 h-3 text-indigo-400 animate-spin" />
          <span>Synthesizing Voice...</span>
        </div>
      )}
    </div>
  );
};
