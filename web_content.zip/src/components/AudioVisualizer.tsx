import React, { useEffect, useRef } from 'react';
import { SessionState, MoodTheme } from '../types';

interface AudioVisualizerProps {
  state: SessionState;
  theme: MoodTheme;
  getMicLevel: () => number;
  getSpeakerLevel: () => number;
  getMicFrequencies: (array: Uint8Array) => void;
  getSpeakerFrequencies: (array: Uint8Array) => void;
  onClickCenter?: () => void;
}

const themeColorPalettes: Record<
  MoodTheme,
  { primary: string; secondary: string; glow: string; particle: string }
> = {
  'cyber-rose': {
    primary: '#ec4899',
    secondary: '#f43f5e',
    glow: 'rgba(236, 72, 153, 0.45)',
    particle: '#f472b6',
  },
  'electric-violet': {
    primary: '#a855f7',
    secondary: '#6366f1',
    glow: 'rgba(168, 85, 247, 0.45)',
    particle: '#c084fc',
  },
  'midnight-emerald': {
    primary: '#10b981',
    secondary: '#14b8a6',
    glow: 'rgba(16, 185, 129, 0.45)',
    particle: '#34d399',
  },
  'solar-amber': {
    primary: '#f59e0b',
    secondary: '#f97316',
    glow: 'rgba(245, 158, 11, 0.45)',
    particle: '#fbbf24',
  },
  'hyper-cyan': {
    primary: '#06b6d4',
    secondary: '#3b82f6',
    glow: 'rgba(6, 182, 212, 0.45)',
    particle: '#22d3ee',
  },
};

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({
  state,
  theme,
  getMicLevel,
  getSpeakerLevel,
  getMicFrequencies,
  getSpeakerFrequencies,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameId = useRef<number | null>(null);
  const rotationAngle = useRef<number>(0);
  const smoothVolume = useRef<number>(0);

  const freqBuffer = useRef<Uint8Array>(new Uint8Array(64));

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let dpr = window.devicePixelRatio || 1;
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };
    resize();
    window.addEventListener('resize', resize);

    const palette = themeColorPalettes[theme] || themeColorPalettes['cyber-rose'];

    const render = () => {
      const rect = canvas.getBoundingClientRect();
      const width = rect.width;
      const height = rect.height;
      const centerX = width / 2;
      const centerY = height / 2;
      const baseRadius = Math.min(width, height) * 0.28;

      ctx.clearRect(0, 0, width, height);

      // Determine current audio level based on state
      let targetVol = 0;
      if (state === 'speaking') {
        targetVol = getSpeakerLevel();
        getSpeakerFrequencies(freqBuffer.current);
      } else if (state === 'listening') {
        targetVol = getMicLevel();
        getMicFrequencies(freqBuffer.current);
      } else if (state === 'connecting') {
        targetVol = 0.25;
      }

      // Smooth volume interpolation
      smoothVolume.current += (targetVol - smoothVolume.current) * 0.25;
      const vol = smoothVolume.current;

      rotationAngle.current += 0.015 + vol * 0.03;

      const currentPalette = themeColorPalettes[theme];

      // Draw background ambient radial glow
      const radialGlow = ctx.createRadialGradient(
        centerX,
        centerY,
        baseRadius * 0.3,
        centerX,
        centerY,
        baseRadius * 1.8
      );
      const glowOpacity = state === 'speaking' ? 0.35 + vol * 0.3 : state === 'listening' ? 0.2 + vol * 0.25 : 0.1;
      radialGlow.addColorStop(0, currentPalette.glow.replace('0.45', String(glowOpacity)));
      radialGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');

      ctx.save();
      ctx.fillStyle = radialGlow;
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * 1.8, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Outer futuristic dashed orbit ring
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(rotationAngle.current * 0.6);
      ctx.beginPath();
      ctx.strokeStyle = currentPalette.primary;
      ctx.globalAlpha = 0.3 + vol * 0.4;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 8, 12, 8]);
      ctx.arc(0, 0, baseRadius * 1.35 + vol * 15, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Inner counter-rotating ring
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(-rotationAngle.current * 0.8);
      ctx.beginPath();
      ctx.strokeStyle = currentPalette.secondary;
      ctx.globalAlpha = 0.25 + vol * 0.3;
      ctx.lineWidth = 1;
      ctx.setLineDash([6, 14]);
      ctx.arc(0, 0, baseRadius * 1.18 + vol * 10, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Audio Frequency reactive wave circle
      const numPoints = 48;
      const step = (Math.PI * 2) / numPoints;
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(rotationAngle.current * 0.4);

      ctx.beginPath();
      for (let i = 0; i <= numPoints; i++) {
        const theta = i * step;
        const binIndex = i % freqBuffer.current.length;
        const freqAmp = (freqBuffer.current[binIndex] / 255) * (baseRadius * 0.45);
        const dynamicRadius =
          baseRadius +
          (state === 'speaking' || state === 'listening' ? freqAmp * 0.85 : Math.sin(theta * 4 + rotationAngle.current * 2) * 4);

        const x = Math.cos(theta) * dynamicRadius;
        const y = Math.sin(theta) * dynamicRadius;

        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.closePath();

      // Gradient for waveform line
      const lineGrad = ctx.createLinearGradient(
        -baseRadius,
        -baseRadius,
        baseRadius,
        baseRadius
      );
      lineGrad.addColorStop(0, currentPalette.primary);
      lineGrad.addColorStop(1, currentPalette.secondary);

      ctx.strokeStyle = lineGrad;
      ctx.lineWidth = 2.5 + vol * 3;
      ctx.shadowColor = currentPalette.primary;
      ctx.shadowBlur = 12 + vol * 20;
      ctx.stroke();

      // Inner glowing core
      ctx.beginPath();
      const coreRadius = baseRadius * 0.65 + vol * 14;
      ctx.arc(0, 0, coreRadius, 0, Math.PI * 2);

      const coreGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, coreRadius);
      coreGrad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
      coreGrad.addColorStop(0.3, currentPalette.primary);
      coreGrad.addColorStop(0.8, currentPalette.secondary);
      coreGrad.addColorStop(1, 'rgba(0, 0, 0, 0.6)');

      ctx.fillStyle = coreGrad;
      ctx.fill();

      // Holographic cyber points
      for (let j = 0; j < 8; j++) {
        const dotAngle = (j * Math.PI) / 4 + rotationAngle.current;
        const dist = baseRadius * 1.45 + Math.sin(rotationAngle.current * 3 + j) * 8;
        const px = Math.cos(dotAngle) * dist;
        const py = Math.sin(dotAngle) * dist;

        ctx.beginPath();
        ctx.arc(px, py, 2.5 + vol * 2, 0, Math.PI * 2);
        ctx.fillStyle = currentPalette.particle;
        ctx.fill();
      }

      ctx.restore();

      animFrameId.current = requestAnimationFrame(render);
    };

    animFrameId.current = requestAnimationFrame(render);

    return () => {
      if (animFrameId.current) cancelAnimationFrame(animFrameId.current);
      window.removeEventListener('resize', resize);
    };
  }, [state, theme, getMicLevel, getSpeakerLevel, getMicFrequencies, getSpeakerFrequencies]);

  return (
    <div className="relative w-full aspect-square max-w-[340px] sm:max-w-[400px] flex items-center justify-center">
      <canvas
        ref={canvasRef}
        className="w-full h-full pointer-events-none select-none"
      />
    </div>
  );
};
