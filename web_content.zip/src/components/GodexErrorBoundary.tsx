import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertOctagon, RefreshCw, Layers, Terminal, Copy, Check } from 'lucide-react';
import { PreviewRuntimeHealth } from '../services/previewRuntimeHealth';

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  copied: boolean;
}

export class GodexErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      copied: false
    };
  }

  public static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('GodexErrorBoundary caught an error:', error, errorInfo);
    PreviewRuntimeHealth.getInstance().recordError(`${error.name}: ${error.message}`);
    this.setState({ errorInfo });
  }

  private handleCopy = () => {
    const details = `Error: ${this.state.error?.message}\n\nStack: ${this.state.error?.stack}\n\nComponent Stack: ${this.state.errorInfo?.componentStack}`;
    navigator.clipboard?.writeText(details);
    this.setState({ copied: true });
    setTimeout(() => this.setState({ copied: false }), 2000);
  };

  private handleReload = () => {
    if (this.props.onReset) {
      this.setState({ hasError: false, error: null, errorInfo: null });
      this.props.onReset();
    } else {
      window.location.reload();
    }
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center p-6 bg-[#08090C] text-[#E2E8F0] font-sans min-h-[400px]">
          <div className="max-w-xl w-full bg-[#0E121A] border border-rose-900/50 rounded-xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-rose-950/80 border border-rose-700/60 flex items-center justify-center text-rose-400">
                <AlertOctagon className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white">
                  {this.props.fallbackTitle || 'Creative Studio Diagnostic Recovery'}
                </h2>
                <p className="text-xs text-neutral-400">
                  A component error occurred during rendering. The safe fallback is active to prevent preview blackout.
                </p>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-[#06080C] border border-rose-900/30 text-rose-300 font-mono text-xs overflow-x-auto max-h-40">
              <p className="font-bold">{this.state.error?.name || 'Error'}: {this.state.error?.message}</p>
              {this.state.error?.stack && (
                <pre className="mt-2 text-[10px] text-neutral-400 whitespace-pre-wrap">
                  {this.state.error.stack.split('\n').slice(0, 6).join('\n')}
                </pre>
              )}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-[#1C2538]">
              <button
                onClick={this.handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#141B2B] hover:bg-[#1E283E] text-xs font-semibold text-neutral-300 border border-[#222E46] transition-colors"
              >
                {this.state.copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{this.state.copied ? 'Copied' : 'Copy Diagnostics'}</span>
              </button>

              <button
                onClick={this.handleReload}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-xs font-bold text-white transition-colors shadow-sm"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Recover & Reload View</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
