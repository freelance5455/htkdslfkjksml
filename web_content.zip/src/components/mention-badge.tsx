import { Badge } from "@/components/ui/badge";
import { mentionFromAverage, type MentionTone } from "@/lib/bac/calc";

const mentionTone: Record<string, MentionTone> = {
  امتياز: "excellence",
  "جيد جداً": "very-good",
  جيد: "good",
  "قريب من الجيد": "fair",
  "بدون تقدير": "fail",
};

export function MentionBadge({
  mention,
  decision,
  average,
}: {
  mention?: string | null;
  decision?: string | null;
  average?: number | null;
}) {
  if (average != null) {
    const computed = mentionFromAverage(average);
    return <Badge variant={computed.tone}>{computed.mention}</Badge>;
  }
  if (!mention && !decision) {
    return <Badge variant="muted">قيد الإدخال</Badge>;
  }
  if (decision === "راسب") {
    return <Badge variant="fail">{mention ?? "راسب"}</Badge>;
  }
  return <Badge variant={mentionTone[mention ?? ""] ?? "default"}>{mention}</Badge>;
}

export function DecisionBadge({ decision }: { decision?: string | null }) {
  if (!decision) return <Badge variant="muted">غير محسوم</Badge>;
  if (decision === "ناجح") return <Badge variant="good">ناجح</Badge>;
  return <Badge variant="fail">راسب</Badge>;
}
