import { useRef } from "react";
import { QRCodeCanvas } from "qrcode.react";
import type { Student } from "../lib/types";
import { qrPayload } from "../lib/types";

/** Renders a student's scannable QR code (encodes the student ID only). */
export function StudentQR({ student, size = 180 }: { student: Student; size?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  return (
    <div
      ref={ref}
      data-qr={student.id}
      className="inline-block rounded-2xl bg-white p-4 shadow-card ring-1 ring-slate-100"
    >
      <QRCodeCanvas
        value={qrPayload(student.studentId)}
        size={size}
        bgColor="#FFFFFF"
        fgColor="#0A1830"
        level="M"
        marginSize={1}
      />
    </div>
  );
}

export function getQRDataURL(student: Student, size = 600): string {
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, size, size);
  // draw the visible-sized QR from the DOM node
  const live = document.querySelector<HTMLCanvasElement>(
    `[data-qr="${student.id}"] canvas`
  );
  if (live) {
    const margin = size * 0.06;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(live, margin, margin, size - margin * 2, size - margin * 2);
  }
  return canvas.toDataURL("image/png");
}

export async function saveQRImage(
  student: Student,
  mode: "download" | "share",
  deptName: string
): Promise<boolean> {
  const size = 640;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size + 130;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const live = document.querySelector<HTMLCanvasElement>(`[data-qr="${student.id}"] canvas`);
  const qSize = size - 80;
  if (live) {
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(live, 40, 30, qSize, qSize);
  }
  ctx.fillStyle = "#0A1830";
  ctx.textAlign = "center";
  ctx.font = "700 30px Cairo, sans-serif";
  ctx.fillText(student.name, size / 2, size + 45);
  ctx.font = "600 22px Cairo, sans-serif";
  ctx.fillStyle = "#5B6B84";
  ctx.fillText(student.studentId, size / 2, size + 80);
  ctx.font = "600 16px Cairo, sans-serif";
  ctx.fillStyle = "#9AA6BB";
  ctx.fillText(deptName, size / 2, size + 110);

  const blob: Blob | null = await new Promise((res) => canvas.toBlob(res, "image/png"));
  if (!blob) return false;
  const fileName = `QR-${student.studentId}.png`;

  if (mode === "share" && navigator.share) {
    try {
      const file = new File([blob], fileName, { type: "image/png" });
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: student.name });
        return true;
      }
    } catch {
      /* user cancelled or unsupported → fall through to download */
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return true;
}
