import React, { useState } from 'react';
import {
  Trophy,
  History,
  Medal,
  Calendar,
  ChevronRight,
  TrendingUp,
  Award,
  Crown,
  Layers,
} from 'lucide-react';
import type { Player, Category, Season, HistoricalRank } from '../types/index.ts';

interface AllTimeRankingViewProps {
  categories: Category[];
  selectedCategoryId: string;
  onSelectCategory: (id: string) => void;
  players: Player[];
  historicalRankings: HistoricalRank[];
  closedSeasons: Season[];
  onOpenPlayerProfile: (playerId: string) => void;
  onSelectPastSeasonDetail: (season: Season) => void;
}

export const AllTimeRankingView: React.FC<AllTimeRankingViewProps> = ({
  categories,
  selectedCategoryId,
  onSelectCategory,
  players,
  historicalRankings,
  closedSeasons,
  onOpenPlayerProfile,
  onSelectPastSeasonDetail,
}) => {
  const [subTab, setSubTab] = useState<'ranking' | 'seasons'>('ranking');

  const activeCategories = categories.filter((c) => c.status === 'active');
  const selectedCat = categories.find((c) => c.id === selectedCategoryId) || activeCategories[0];

  const getPlayer = (id: string): Player | undefined => {
    return players.find((p) => p.id === id);
  };

  return (
    <div className="space-y-6">
      {/* Category selector */}
      <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-xl overflow-x-auto">
        {activeCategories.map((cat) => {
          const isSelected = cat.id === selectedCategoryId;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex-1 min-w-[120px] py-2.5 px-4 rounded-lg font-bold text-xs transition-all flex items-center justify-center gap-2 ${
                isSelected
                  ? 'bg-neutral-800 text-white shadow-sm border border-neutral-700'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800/50'
              }`}
            >
              <span>{cat.name.split(' ')[0]} {cat.name.split(' ')[1]}</span>
              <span className="text-[10px] text-neutral-500 font-mono-numbers">
                ({cat.weightGrams}g)
              </span>
            </button>
          );
        })}
      </div>

      {/* Subtab navigation */}
      <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSubTab('ranking')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              subTab === 'ranking'
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Quadro Histórico Geral
          </button>
          <button
            onClick={() => setSubTab('seasons')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              subTab === 'seasons'
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Semanas Encerradas ({closedSeasons.length})
          </button>
        </div>

        <span className="text-[11px] text-neutral-500 hidden sm:block">
          Apenas temporadas finalizadas oficiais
        </span>
      </div>

      {subTab === 'ranking' ? (
        <div className="space-y-4">
          {/* Header Explanation */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-1">
              <History className="w-4 h-4 text-emerald-400" />
              <h2 className="text-base font-extrabold text-white">
                Ranking de Todos os Tempos — Categoria {selectedCat?.weightGrams}g
              </h2>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Média acumulada das médias semanais oficiais de cada jogador, calculada apenas sobre as semanas já encerradas em que participou.
            </p>
          </div>

          {/* Historical List */}
          {historicalRankings.length === 0 ? (
            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 text-center">
              <Trophy className="w-10 h-10 text-neutral-600 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-neutral-300">Nenhuma temporada encerrada ainda nesta categoria</h3>
              <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
                Assim que a primeira semana for finalizada na virada de domingo para segunda, o histórico imutável começará a ser formado aqui.
              </p>
            </div>
          ) : (
            historicalRankings.map((item) => {
              const player = getPlayer(item.playerId);
              if (!player) return null;

              return (
                <div
                  key={item.playerId}
                  onClick={() => onOpenPlayerProfile(item.playerId)}
                  className="flex items-center justify-between p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-all cursor-pointer"
                  role="button"
                  tabIndex={0}
                  aria-label={`Ver histórico completo de ${player.name}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-neutral-800 border border-neutral-700 text-neutral-300 flex items-center justify-center font-bold text-xs">
                      {item.rank}º
                    </div>

                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm text-white shadow"
                        style={{ backgroundColor: player.color || '#10b981' }}
                      >
                        {player.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">
                            {player.name}
                          </span>
                          {item.championTitlesCount > 0 && (
                            <span className="flex items-center gap-1 text-[10px] font-bold text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800">
                              <Crown className="w-3 h-3 text-amber-400" />
                              <span>{item.championTitlesCount}x</span>
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-neutral-400 flex items-center gap-2 mt-0.5">
                          <span>{item.validWeeksCount} {item.validWeeksCount === 1 ? 'semana' : 'semanas'} disputadas</span>
                          <span aria-hidden="true">·</span>
                          <span>Recorde: {item.allTimeBestStreak}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-neutral-500 uppercase tracking-wider font-semibold block">
                      Média Histórica
                    </span>
                    <span className="text-2xl font-extrabold text-white font-mono-numbers">
                      {item.formattedHistoricalAverage}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      ) : (
        /* List of Closed Seasons */
        <div className="space-y-3">
          {closedSeasons.length === 0 ? (
            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-8 text-center text-neutral-400 text-sm">
              Nenhuma temporada arquivada ainda.
            </div>
          ) : (
            closedSeasons.map((season) => {
              const catSnapshots = season.snapshots?.[selectedCategoryId] || [];
              const championResult = catSnapshots.find((r) => r.isChampion);
              const championPlayer = championResult ? getPlayer(championResult.playerId) : null;

              return (
                <div
                  key={season.id}
                  onClick={() => onSelectPastSeasonDetail(season)}
                  className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-all cursor-pointer flex items-center justify-between"
                  role="button"
                  tabIndex={0}
                  aria-label={`Ver detalhes da ${season.name}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-neutral-400">
                      <Calendar className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-sm">{season.name}</h4>
                      <p className="text-xs text-neutral-400 mt-0.5">
                        {season.startDate} a {season.endDate} · {catSnapshots.length} participantes
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {championPlayer && (
                      <div className="text-right hidden sm:block">
                        <span className="text-[10px] text-amber-400 font-bold block uppercase tracking-wider">
                          Campeão ({selectedCat?.weightGrams}g)
                        </span>
                        <span className="text-xs font-bold text-white">
                          {championPlayer.name} (Média: {championResult?.formattedAverage})
                        </span>
                      </div>
                    )}
                    <ChevronRight className="w-5 h-5 text-neutral-500" />
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
