import React from 'react';
import { Newspaper, Feather, Layers, Code, ShieldCheck, Star } from 'lucide-react';

export const AboutScreen: React.FC = () => {
  return (
    <div className="flex-1 flex flex-col p-4 sm:p-6 max-w-md mx-auto w-full overflow-y-auto">
      {/* Newspaper Header Colophon */}
      <div className="bg-[#f8f4ed] border-2 border-[#2c2c2c] newspaper-border-double p-5 text-center shadow-xs mb-5">
        <Newspaper className="w-8 h-8 text-[#2c2c2c] mx-auto mb-2 opacity-90" />
        <h2 className="newspaper-font text-3xl font-black text-[#1a1a1a] mb-1">
          الكلمات المتقاطعة
        </h2>
        <div className="text-[11px] font-bold text-[#2c2c2c] tracking-widest uppercase border-t border-b border-[#2c2c2c]/30 py-1 my-2">
          الإصدار ١,٠,٠ - طبعة رقمية خاصة
        </div>
        <p className="text-xs text-[#2c2c2c] leading-relaxed font-serif pt-1">
          لعبة الكلمات المتقاطعة العربية التقليدية بتصميم كلاسيكي أصيل يستحضر عبق الصحف والمجلات العربية القديمة.
        </p>
      </div>

      {/* Information Cards */}
      <div className="flex flex-col gap-3 text-xs text-[#2c2c2c]">
        <div className="bg-[#f8f4ed] border border-[#2c2c2c] p-3.5 rounded-xs shadow-2xs">
          <div className="flex items-center gap-2 font-bold text-sm text-[#1a1a1a] mb-1">
            <Star className="w-4 h-4 fill-[#d97706] text-[#b45309]" />
            <span>نظام النجوم والمساعدات</span>
          </div>
          <p className="leading-relaxed text-[#2c2c2c]">
            كل مرحلة تمنحك ٣ نجوم كاملة. يتوفر لديك حتى ٣ مساعدات لكشف الكلمات المستعصية، وكل مساعدة تستخدمها تخصم نجمة واحدة. يمكنك دائماً إعادة لعب أي مرحلة لتحقيق التقييم الكامل ٣ نجوم!
          </p>
        </div>

        <div className="bg-[#f8f4ed] border border-[#2c2c2c] p-3.5 rounded-xs shadow-2xs">
          <div className="flex items-center gap-2 font-bold text-sm text-[#1a1a1a] mb-1">
            <Feather className="w-4 h-4 text-[#1a1a1a]" />
            <span>فلسفة التصميم</span>
          </div>
          <p className="leading-relaxed text-[#2c2c2c]">
            تم تصميم الواجهة بعناية لتشبه الحبر والورق القديم، مبتعدة تماماً عن المؤثرات البصرية الصارخة والألوان النيون، لمنحك تجربة مطالعة وهدوء حقيقيين كأنك تحمل صحيفة ورقية بيدك.
          </p>
        </div>

        <div className="bg-[#f8f4ed] border border-[#2c2c2c] p-3.5 rounded-xs shadow-2xs">
          <div className="flex items-center gap-2 font-bold text-sm text-[#1a1a1a] mb-1">
            <Layers className="w-4 h-4 text-[#2c2c2c]" />
            <span>الهيكلية و ٥٠ مرحلة</span>
          </div>
          <p className="leading-relaxed text-[#2c2c2c]">
            تضم التطبيق بنية متكاملة لـ ٥٠ مرحلة تتسع لـ ١٢٥٠ سؤالاً متقاطعاً. يتطلب فتح المرحلة التالية إكمال جميع أسئلة المرحلة الحالية.
          </p>
        </div>

        <div className="bg-[#f8f4ed] border border-[#2c2c2c] p-3.5 rounded-xs shadow-2xs">
          <div className="flex items-center gap-2 font-bold text-sm text-[#1a1a1a] mb-1">
            <ShieldCheck className="w-4 h-4 text-[#1c4d1f]" />
            <span>حفظ محلي وحفظ أوفلاين</span>
          </div>
          <p className="leading-relaxed text-[#2c2c2c]">
            يعمل التطبيق بالكامل بدون الحاجة لاتصال بالإنترنت، ويقوم بحفظ تقدمك تلقائياً في التخزين المحلي الآمن.
          </p>
        </div>

        <div className="bg-[#f8f4ed] border border-[#2c2c2c] p-3.5 rounded-xs shadow-2xs">
          <div className="flex items-center gap-2 font-bold text-sm text-[#1a1a1a] mb-1">
            <Code className="w-4 h-4 text-[#2c2c2c]" />
            <span>توافق مع الأجهزة المحمولة</span>
          </div>
          <p className="leading-relaxed text-[#2c2c2c]">
            مصمم خصيصاً للهواتف الذكية مع لوحة مفاتيح عربية مدمجة تحافظ على ظهور الرقعة والأسئلة بدون حجب الشاشة.
          </p>
        </div>
      </div>
    </div>
  );
};
