/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { QRCodeDisplay } from './QRCodeDisplay';
import { 
  X, 
  Download, 
  Smartphone, 
  ExternalLink, 
  Copy, 
  Check, 
  CheckCircle2, 
  Terminal, 
  ShieldCheck, 
  Layers,
  ArrowRight
} from 'lucide-react';

interface AndroidApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'direct' | 'pwabuilder' | 'capacitor' | 'sideload'>('direct');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedCapCmd, setCopiedCapCmd] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-dev-wpcpgf7jm4gu62jfbff7yb-657221057012.asia-northeast1.run.app';
  const pwabuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(currentUrl)}`;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const capCommand = `# 1. Install Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Initialize project with package name
npx cap init "NetPulse" "com.netpulse.monitor" --web-dir dist

# 3. Build Web Bundle
npm run build

# 4. Add Android Platform & Open in Android Studio
npx cap add android
npx cap open android

# 5. In Android Studio: Click Build > Build Bundle(s) / APK(s) > Build APK(s)
# Your APK will be at: android/app/build/outputs/apk/debug/app-debug.apk`;

  const handleCopyCapCmd = () => {
    navigator.clipboard.writeText(capCommand);
    setCopiedCapCmd(true);
    setTimeout(() => setCopiedCapCmd(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-5 overflow-y-auto max-h-[92vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>Install NetPulse on Android</span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.2 rounded">
                  APK Center
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Choose your preferred way to install the app on your phone
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-3 gap-1 p-1 my-3 bg-slate-950 border border-slate-800 rounded-xl text-xs">
          <button
            onClick={() => setActiveTab('direct')}
            className={`py-1.5 rounded-lg font-medium transition ${
              activeTab === 'direct'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Direct WebAPK
          </button>
          <button
            onClick={() => setActiveTab('pwabuilder')}
            className={`py-1.5 rounded-lg font-medium transition ${
              activeTab === 'pwabuilder'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Download .APK
          </button>
          <button
            onClick={() => setActiveTab('capacitor')}
            className={`py-1.5 rounded-lg font-medium transition ${
              activeTab === 'capacitor'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Android Studio
          </button>
        </div>

        {/* TAB 1: DIRECT ANDROID WEBAPK (INSTANT) */}
        {activeTab === 'direct' && (
          <div className="space-y-4">
            <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/30">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300 leading-relaxed">
                  <strong className="text-white">Fastest Method (Google Play WebAPK):</strong> On modern Android (Chrome, Samsung Internet, Edge, Brave), tapping Install automatically builds and installs a real native APK directly onto your phone without requiring manual file sideloading.
                </div>
              </div>
            </div>

            {/* Direct Install Button if on Android Browser */}
            {isInstallable && (
              <button
                onClick={async () => {
                  await install();
                  onClose();
                }}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-sm shadow-lg shadow-emerald-950/40 transition active:scale-[0.98]"
              >
                <Download className="w-4 h-4" />
                <span>Tap to Install to This Android Device</span>
              </button>
            )}

            {isInstalled && (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs text-center font-medium">
                ✓ NetPulse is already installed on this device!
              </div>
            )}

            {/* Open on Phone Section with QR */}
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 text-center">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2">
                Open on your Android Phone
              </h4>
              <p className="text-[11px] text-slate-400 mb-3">
                Scan with your phone's camera or browser to open NetPulse directly:
              </p>

              <div className="flex justify-center mb-3">
                <QRCodeDisplay url={currentUrl} size={160} />
              </div>

              {/* URL with Copy Button */}
              <div className="flex items-center gap-1.5 p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                <input
                  type="text"
                  readOnly
                  value={currentUrl}
                  className="bg-transparent text-slate-300 font-mono text-[11px] px-2 flex-1 focus:outline-none truncate"
                />
                <button
                  onClick={handleCopyUrl}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="mt-3 text-[11px] text-slate-400 text-left space-y-1">
                <div>1. Open this link in <strong>Chrome</strong> on your Android phone.</div>
                <div>2. Tap the <strong>three dots menu (⋮)</strong> in Chrome.</div>
                <div>3. Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</div>
                <div>4. NetPulse will appear in your <strong>App Drawer</strong> just like an app installed from Google Play!</div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: DOWNLOAD STANDALONE .APK FILE VIA PWABUILDER */}
        {activeTab === 'pwabuilder' && (
          <div className="space-y-4">
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-1">
                1-Click APK Generator (PWABuilder)
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                PWABuilder is an open-source tool maintained by Microsoft and the Google Chrome team that automatically packages this Progressive Web App into a standalone signed <strong>.APK</strong> file for Android.
              </p>
            </div>

            {/* Steps */}
            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800 flex items-start gap-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-bold text-[11px] shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <div className="font-semibold text-white">Open PWABuilder Generator</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Click the button below. Your app URL and manifest are automatically preloaded.
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800 flex items-start gap-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-bold text-[11px] shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <div className="font-semibold text-white">Click "Package for Android"</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Select <strong>Android</strong> to build a signed APK / AAB package with your app icon and permissions.
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800 flex items-start gap-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-bold text-[11px] shrink-0 mt-0.5">
                  3
                </span>
                <div>
                  <div className="font-semibold text-white">Download & Install the .APK</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Download <code className="text-cyan-300">NetPulse.apk</code> directly to your phone and tap it to install!
                  </div>
                </div>
              </div>
            </div>

            {/* Launch PWABuilder Button */}
            <a
              href={pwabuilderUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg transition active:scale-[0.98]"
            >
              <span>Generate .APK on PWABuilder</span>
              <ExternalLink className="w-4 h-4" />
            </a>

            <div className="text-center">
              <span className="text-[11px] text-slate-500">
                Package ID: <code className="text-slate-400">com.netpulse.monitor</code> · Target: Android 10+
              </span>
            </div>
          </div>
        )}

        {/* TAB 3: CAPACITOR / ANDROID STUDIO BUILD */}
        {activeTab === 'capacitor' && (
          <div className="space-y-4">
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-1">
                Compile Native APK with Android Studio
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                If you have a computer with Android Studio installed, you can build a native signed APK directly using Capacitor:
              </p>
            </div>

            {/* Code Box */}
            <div className="relative">
              <pre className="p-3 rounded-xl bg-black/90 border border-slate-800 text-[10px] font-mono text-emerald-400 overflow-x-auto whitespace-pre leading-relaxed">
                {capCommand}
              </pre>
              <button
                onClick={handleCopyCapCmd}
                className="absolute top-2 right-2 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1 transition"
              >
                {copiedCapCmd ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCapCmd ? 'Copied' : 'Copy Commands'}</span>
              </button>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800 text-xs text-slate-300">
              <div className="font-semibold text-white mb-1">Generated Output:</div>
              <div className="text-[11px] text-slate-400 font-mono">
                android/app/build/outputs/apk/debug/app-debug.apk
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Transfer this file to your phone via USB or Google Drive and tap to install.
              </p>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
