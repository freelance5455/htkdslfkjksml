import React, { useState, useEffect } from 'react';
import {
  X,
  Smartphone,
  Download,
  QrCode,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Zap,
  Terminal,
  Copy,
  Check,
  Sparkles,
  ArrowRight,
  Share2
} from 'lucide-react';
import QRCode from 'qrcode';
import { usePWAInstall } from '../hooks/usePWAInstall.ts';

interface AndroidApkModalProps {
  onClose: () => void;
  appUrl?: string;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({
  onClose,
  appUrl = typeof window !== 'undefined'
    ? window.location.href.split('?')[0]
    : 'https://ais-pre-urijdheqmayfua42nd6zhw-975394252176.asia-southeast1.run.app',
}) => {
  const { isInstallable, isInstalled, isAndroid, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'install' | 'download' | 'qr' | 'build'>('install');
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedCommand, setCopiedCommand] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  // Generate QR Code on mount
  useEffect(() => {
    QRCode.toDataURL(appUrl, {
      width: 280,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    })
      .then((url) => setQrCodeDataUrl(url))
      .catch((err) => console.error('QR generation error:', err));
  }, [appUrl]);

  const handleInstallClick = async () => {
    setIsInstalling(true);
    try {
      const outcome = await install();
      if (outcome) {
        setInstallSuccess(true);
      }
    } catch (e) {
      console.warn('Install error:', e);
    } finally {
      setIsInstalling(false);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  // Pre-configured PWABuilder 1-click cloud APK generator URL
  const pwaBuilderUrl = `https://www.pwabuilder.com/publish?site=${encodeURIComponent(appUrl)}`;

  const gradleCommand = `git clone <repo>\ncd tempbox\nnpx @capacitor/cli add android\nnpm run build\nnpx cap sync\ncd android && ./gradlew assembleDebug\n# Output: android/app/build/outputs/apk/debug/app-debug.apk`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-xs animate-fade-in text-slate-800">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* HEADER */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-800 via-teal-900 to-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 flex items-center justify-center shadow-lg">
              <Smartphone className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight text-white">
                  Android APK &amp; App Hub
                </h2>
                <span className="text-[10px] bg-emerald-400/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full font-mono font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>ANDROID READY</span>
                </span>
              </div>
              <p className="text-xs text-emerald-200">
                Install as native Android WebAPK or generate full .apk package
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TAB NAVIGATION */}
        <div className="flex border-b border-slate-200 bg-slate-50/80 px-4 text-xs font-semibold overflow-x-auto">
          {[
            { id: 'install', label: '1-Click Install (WebAPK)', icon: Zap },
            { id: 'download', label: 'Download .APK File', icon: Download },
            { id: 'qr', label: 'Scan Phone QR', icon: QrCode },
            { id: 'build', label: 'Gradle / CLI Build', icon: Terminal },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-3.5 flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'border-emerald-600 text-emerald-800 bg-white font-bold'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB CONTENTS */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1">
          
          {/* TAB 1: 1-CLICK WEBAPK INSTALLATION */}
          {activeTab === 'install' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div className="text-xs text-emerald-950 space-y-1">
                  <div className="font-bold text-sm">Official Android WebAPK Technology</div>
                  <p className="leading-relaxed">
                    Android Google Chrome and Samsung Internet automatically package this app into a true, native
                    <strong> signed Android APK</strong> on your device without needing unknown source permissions!
                  </p>
                </div>
              </div>

              {isInstalled || installSuccess ? (
                <div className="text-center py-6 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                  <div className="font-extrabold text-slate-900 text-sm">App Already Installed on Device!</div>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    TempBox is installed in standalone mode with home screen shortcut and native notification permissions.
                  </p>
                </div>
              ) : isInstallable ? (
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 text-center space-y-3">
                  <div className="text-xs text-slate-600">
                    Your browser has detected the Android App package and is ready to install.
                  </div>
                  <button
                    onClick={handleInstallClick}
                    disabled={isInstalling}
                    className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm flex items-center justify-center gap-2 mx-auto shadow-md shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>{isInstalling ? 'Installing on Device...' : 'Install TempBox APK on Android'}</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    How to install on any Android phone (Chrome / Samsung Internet):
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                    <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1">
                      <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs">
                        1
                      </div>
                      <div className="font-bold text-slate-900">Open in Chrome</div>
                      <p className="text-slate-500 text-[11px]">
                        Open this URL on your Android phone using Google Chrome browser.
                      </p>
                    </div>

                    <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1">
                      <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs">
                        2
                      </div>
                      <div className="font-bold text-slate-900">Tap 3-Dots Menu</div>
                      <p className="text-slate-500 text-[11px]">
                        Tap the ⋮ (three dots) in the top-right corner of Chrome.
                      </p>
                    </div>

                    <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1">
                      <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs">
                        3
                      </div>
                      <div className="font-bold text-slate-900">Install App</div>
                      <p className="text-slate-500 text-[11px]">
                        Tap <strong>&quot;Install App&quot;</strong> or <strong>&quot;Add to Home Screen&quot;</strong>. Android generates the APK!
                      </p>
                    </div>
                  </div>

                  {/* COPY SHARE LINK */}
                  <div className="flex items-center gap-2 pt-2">
                    <input
                      type="text"
                      readOnly
                      value={appUrl}
                      className="flex-1 px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl text-slate-700 select-all"
                    />
                    <button
                      onClick={handleCopyLink}
                      className="px-3.5 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold flex items-center gap-1.5 hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
                    >
                      {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedUrl ? 'Copied' : 'Copy App URL'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: DOWNLOAD .APK FILE DIRECTLY */}
          {activeTab === 'download' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200 text-xs text-blue-950 space-y-1.5">
                <div className="font-bold text-sm flex items-center gap-1.5 text-blue-900">
                  <Download className="w-4 h-4 text-blue-600" />
                  <span>Download Standalone Android APK (.apk / .aab)</span>
                </div>
                <p className="leading-relaxed text-blue-800">
                  You can generate and download a standalone signed APK file using Microsoft &amp; Google&apos;s
                  official PWABuilder engine configured for TempBox (Package: <code>io.tempbox.mobile</code>).
                </p>
              </div>

              <div className="border border-slate-200 rounded-2xl p-4 bg-white space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-900 text-xs sm:text-sm">
                      PWABuilder Cloud Android APK Generator
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono">
                      Target: Android 14+ (API 34) • Output: .apk &amp; .aab bundle
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                    Cloud Build
                  </span>
                </div>

                <p className="text-xs text-slate-600">
                  Clicking below opens the official PWABuilder package generator pre-filled with this live app.
                  Tap <strong>&quot;Package for Android&quot;</strong> to download the ready-to-install <code>tempbox.apk</code> file!
                </p>

                <div className="pt-1 flex flex-col sm:flex-row gap-2">
                  <a
                    href={pwaBuilderUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Generate &amp; Download APK on PWABuilder</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>

                  <button
                    onClick={handleCopyLink}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy App URL</span>
                  </button>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 space-y-1">
                <div className="font-bold text-slate-800">APK Package Details:</div>
                <div className="grid grid-cols-2 gap-2 font-mono text-[10px] text-slate-700">
                  <div>Package ID: <code>io.tempbox.mobile</code></div>
                  <div>Version: <code>1.0.0</code></div>
                  <div>Theme Color: <code>#1e3a8a</code></div>
                  <div>Architecture: <code>arm64-v8a / universal</code></div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SCAN QR CODE FROM ANDROID PHONE */}
          {activeTab === 'qr' && (
            <div className="flex flex-col items-center justify-center py-2 space-y-4">
              <div className="text-center space-y-1">
                <h4 className="font-extrabold text-slate-900 text-sm">
                  Scan with your Android Phone Camera
                </h4>
                <p className="text-xs text-slate-500 max-w-sm">
                  Point your phone camera or QR scanner at the code below to open TempBox directly on Android.
                </p>
              </div>

              {qrCodeDataUrl ? (
                <div className="p-3 bg-white border-2 border-slate-200 rounded-2xl shadow-md">
                  <img src={qrCodeDataUrl} alt="App QR Code" className="w-56 h-56 object-contain" />
                </div>
              ) : (
                <div className="w-56 h-56 rounded-2xl bg-slate-100 animate-pulse flex items-center justify-center text-xs text-slate-400">
                  Generating QR...
                </div>
              )}

              <div className="flex items-center gap-2 max-w-md w-full">
                <input
                  type="text"
                  readOnly
                  value={appUrl}
                  className="flex-1 px-3 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl text-slate-700"
                />
                <button
                  onClick={handleCopyLink}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-bold flex items-center gap-1.5 hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: GRADLE / CLI BUILD */}
          {activeTab === 'build' && (
            <div className="space-y-3">
              <div className="text-xs text-slate-600">
                To build an APK binary locally on your computer with Android Studio or Gradle:
              </div>

              <div className="relative bg-slate-900 text-slate-100 p-3.5 rounded-2xl font-mono text-[11px] overflow-x-auto">
                <pre>{gradleCommand}</pre>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(gradleCommand);
                    setCopiedCommand(true);
                    setTimeout(() => setCopiedCommand(false), 2000);
                  }}
                  className="absolute top-3 right-3 px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-slate-300 hover:text-white text-[10px] font-sans flex items-center gap-1 cursor-pointer"
                >
                  {copiedCommand ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedCommand ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="text-[11px] text-slate-500">
                The compiled APK file will be located at <code>android/app/build/outputs/apk/debug/app-debug.apk</code>.
              </div>
            </div>
          )}

        </div>

        {/* FOOTER */}
        <div className="p-3.5 sm:p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
            <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
            <span>PWA &amp; WebAPK Manifest Active</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
