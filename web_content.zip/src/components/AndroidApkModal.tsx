import React, { useState } from 'react';
import { Smartphone, Download, X, Check, ExternalLink, ShieldCheck, Terminal, Copy, Info, Sparkles } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Language } from '../translations';

interface AndroidApkModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const { isInstallable, isInstalled, install, isIOS } = usePWAInstall();
  const [copiedStep, setCopiedStep] = useState(false);
  const isBn = language === 'bn';

  if (!isOpen) return null;

  const currentAppUrl = typeof window !== 'undefined' ? window.location.origin : 'https://shield-vpn.app';
  const pwaBuilderUrl = `https://www.pwabuilder.com/?url=${encodeURIComponent(currentAppUrl)}`;

  const capacitorCommands = `npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "ShieldVPN" "com.shieldvpn.app" --web-dir dist
npm run build
npx cap add android
npx cap open android
# Android Studio-তে 'Build' > 'Build APK(s)' সিলেক্ট করুন`;

  const handleCopyCommands = () => {
    navigator.clipboard.writeText(capacitorCommands);
    setCopiedStep(true);
    setTimeout(() => setCopiedStep(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-xl max-h-[90vh] shadow-2xl overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                {isBn ? 'অ্যান্ড্রয়েড অ্যাপ ও APK সমাধান' : 'Android App & APK Solutions'}
              </h2>
              <p className="text-xs text-slate-500">
                {isBn ? 'আপনার মোবাইলে শিল্ডভিপিএন সরাসরি ব্যবহার করুন' : 'Run ShieldVPN natively on Android'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          
          {/* Direct Root APK Download Ready Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-teal-500/10 to-indigo-500/15 border-2 border-emerald-500/40 space-y-3 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">
                ✓ {isBn ? 'অফিসিয়াল APK তৈরি ও সাইন সম্পন্ন' : 'Official APK Built & Signed'}
              </span>
              <span className="text-xs font-mono text-slate-500">205.1 KB · v1, v2, v3 Signed</span>
            </div>

            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {isBn ? 'নতুন সাইন করা app-debug.apk প্রস্তুত' : 'Newly Signed app-debug.apk is ready'}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {isBn
                  ? 'অফিসিয়াল aapt, Google D8 এবং apksigner দিয়ে v1, v2 ও v3 ক্রিপ্টোগ্রাফিক সিগনেচার সহ নতুন করে বিল্ড করা হয়েছে। সরাসরি ডাউনলোড করুন:'
                  : 'Compiled with official aapt, Google D8, and apksigner with v1, v2, and v3 signatures. Download directly below:'}
              </p>
            </div>

            <a
              href="/app-debug.apk"
              download="ShieldVPN-debug.apk"
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-all hover:brightness-105 active:scale-95"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>{isBn ? 'সরাসরি app-debug.apk ডাউনলোড করুন (205 KB)' : 'Download app-debug.apk (205 KB)'}</span>
            </a>

            {/* Android Install Help Box */}
            <div className="mt-2 p-3 rounded-xl bg-white/70 dark:bg-slate-900/70 border border-emerald-500/20 text-[11px] text-slate-700 dark:text-slate-300 space-y-1.5">
              <div className="font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                <span>⚠️</span>
                <span>{isBn ? 'ইনস্টল না হলে বা "Cannot Install" দেখালে করণীয়:' : 'If "Cannot Install" appears on your phone:'}</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-slate-600 dark:text-slate-400 pl-1">
                <li>
                  {isBn ? (
                    <><strong>Unknown Sources:</strong> Chrome বা Files অ্যাপের <em>Settings &gt; Allow from this source</em> চালু করুন।</>
                  ) : (
                    <><strong>Unknown Sources:</strong> Enable <em>Settings &gt; Allow from this source</em> for Chrome or File Manager.</>
                  )}
                </li>
                <li>
                  {isBn ? (
                    <><strong>Play Protect:</strong> ওয়ার্নিং আসলে <em>"More details"</em> চেপে <em>"Install anyway"</em> দিন।</>
                  ) : (
                    <><strong>Play Protect:</strong> If prompted, tap <em>"More details"</em> and select <em>"Install anyway"</em>.</>
                  )}
                </li>
                <li>
                  {isBn ? (
                    <><strong>আগের অ্যাপ আনইনস্টল:</strong> আগে কোনো অসম্পূর্ণ ভার্সন ইনস্টল থাকলে সেটি ডিলিট করে নতুনটি ইনস্টল করুন।</>
                  ) : (
                    <><strong>Uninstall previous version:</strong> If an older version is already installed, uninstall it first.</>
                  )}
                </li>
              </ul>
            </div>
          </div>

          {/* Option 1: Direct PWA 1-Click Install */}
          <div className="p-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/5 dark:bg-emerald-500/10 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block">
                  {isBn ? 'পদ্ধতি ১ (সবচেয়ে দ্রুত ও সহজ)' : 'Method 1 (Instant & Recommended)'}
                </span>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                  {isBn ? 'অ্যান্ড্রয়েড ফোনে সরাসরি ইনস্টল করুন (PWA)' : 'Direct Install to Android Home Screen'}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                  {isBn
                    ? 'কোনো ঝামেলা ছাড়াই সাধারণ APK-র মতোই ফোনের হোমস্ক্রিনে অ্যাপ আইকন সহ ফুলস্ক্রিনে চলবে।'
                    : 'Installs full-screen with native app launcher icon without manual APK download.'}
                </p>
              </div>
            </div>

            {isInstalled ? (
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 p-2.5 rounded-xl border border-emerald-500/20">
                <ShieldCheck className="w-4 h-4" />
                <span>{isBn ? 'অ্যাপটি ইতিমধ্যে সফলভাবে ইনস্টল করা হয়েছে!' : 'Application is already installed!'}</span>
              </div>
            ) : isInstallable ? (
              <button
                onClick={install}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <Download className="w-4 h-4" />
                <span>{isBn ? 'এখনই অ্যান্ড্রয়েড ফোনে ইনস্টল করুন' : 'Install App Now'}</span>
              </button>
            ) : (
              <div className="text-xs text-slate-600 dark:text-slate-400 bg-white/60 dark:bg-slate-900/60 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                {isBn ? (
                  <span>
                    📱 <strong>ফোনে ইনস্টল করার নিয়ম:</strong> আপনার অ্যান্ড্রয়েড ফোনের Chrome ব্রাউজারে এই লিংকটি ওপেন করে উপরের ডানদিকের <strong>থ্রি-ডট (⋮) মেনু</strong> থেকে <strong>'Install app'</strong> বা <strong>'Add to Home screen'</strong> চাপুন।
                  </span>
                ) : (
                  <span>
                    📱 <strong>How to install on phone:</strong> Open this URL in Chrome on Android, tap the <strong>three dots (⋮)</strong> and select <strong>'Install app'</strong> or <strong>'Add to Home screen'</strong>.
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Option 2: 1-Click Online APK Generator via PWABuilder */}
          <div className="p-4 rounded-2xl border border-indigo-500/30 bg-indigo-500/5 dark:bg-indigo-500/10 space-y-3">
            <div>
              <span className="text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider block">
                {isBn ? 'পদ্ধতি ২ (প্রকৃত APK প্যাকেজ তৈরি)' : 'Method 2 (Generate .APK Package)'}
              </span>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                {isBn ? '১-ক্লিকে অনলাইন APK বিল্ডার (PWABuilder)' : '1-Click Online APK Builder'}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {isBn
                  ? 'মাইক্রোসফট ও গুগলের অফিসিয়াল ক্লাউড বিল্ডার ব্যবহার করে এই লাইভ অ্যাপ থেকে রেডি-টু-ইনস্টল .apk ফাইল ডাউনলোড করতে নিচের বাটনে চাপুন।'
                  : 'Generates ready-to-install Android .apk package directly from this live URL using PWABuilder cloud.'}
              </p>
            </div>

            <a
              href={pwaBuilderUrl}
              target="_blank"
              rel="noreferrer noopener"
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <ExternalLink className="w-4 h-4" />
              <span>{isBn ? 'PWABuilder দিয়ে APK তৈরি করুন' : 'Generate APK with PWABuilder'}</span>
            </a>
          </div>

          {/* Option 3: Local Android Studio Build (Capacitor) */}
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                {isBn ? 'পদ্ধতি ৩: লোকাল Android Studio দিয়ে APK বিল্ড' : 'Method 3: Build Locally via Android Studio'}
              </span>
              <button
                onClick={handleCopyCommands}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1 hover:underline"
              >
                {copiedStep ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedStep ? (isBn ? 'কপি হয়েছে' : 'Copied') : (isBn ? 'কমান্ড কপি' : 'Copy Commands')}</span>
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-slate-950 text-slate-300 font-mono text-[11px] overflow-x-auto whitespace-pre leading-relaxed">
              {capacitorCommands}
            </pre>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold transition-colors"
          >
            {isBn ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>

      </div>
    </div>
  );
};
