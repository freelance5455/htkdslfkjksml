import React from 'react';
import { Home, Compass, Library, Plus, Heart, Sparkles, Radio, Music, Flame, Search } from 'lucide-react';
import { useMusic } from '../../context/MusicContext';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenCreatePlaylist: () => void;
  onSelectPlaylist: (playlistId: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  onOpenCreatePlaylist,
  onSelectPlaylist,
}) => {
  const { playlists, likedSongIds } = useMusic();

  const mainNav = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'explore', label: 'Explore', icon: Compass },
    { id: 'search', label: 'Search', icon: Search },
    { id: 'library', label: 'Library', icon: Library },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 h-[calc(100vh-61px)] bg-[#030303] border-r border-white/5 select-none p-3 overflow-y-auto">
      {/* Primary Links */}
      <div className="space-y-1">
        {mainNav.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-sm transition cursor-pointer ${
                isActive
                  ? 'bg-white/10 text-white font-semibold'
                  : 'text-neutral-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-neutral-400'}`} />
                <span>{item.label}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Action: New Playlist */}
      <div className="mt-6 pt-4 border-t border-white/10">
        <button
          onClick={onOpenCreatePlaylist}
          className="w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-neutral-300 hover:text-white hover:bg-white/5 text-sm font-medium transition cursor-pointer"
        >
          <div className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center text-white">
            <Plus className="w-4 h-4" />
          </div>
          <span>New Playlist</span>
        </button>

        {/* Liked Songs Shortcut */}
        <button
          onClick={() => onSelectTab('library')}
          className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl text-neutral-300 hover:text-white hover:bg-white/5 text-sm font-medium transition cursor-pointer mt-1"
        >
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white">
              <Heart className="w-3.5 h-3.5 fill-white" />
            </div>
            <span>Liked Music</span>
          </div>
          <span className="text-xs text-neutral-500">{likedSongIds.size}</span>
        </button>
      </div>

      {/* Playlist List */}
      <div className="mt-4 flex-1">
        <h4 className="px-3.5 text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-2">
          Playlists
        </h4>
        <div className="space-y-0.5">
          {playlists.map((pl) => (
            <button
              key={pl.id}
              onClick={() => {
                onSelectPlaylist(pl.id);
                onSelectTab('playlist-detail');
              }}
              className="w-full text-left px-3.5 py-2 rounded-lg text-sm text-neutral-400 hover:text-white hover:bg-white/5 truncate transition cursor-pointer"
            >
              {pl.title}
            </button>
          ))}
        </div>
      </div>

      {/* Quick Radio & Moods Banner */}
      <div className="mt-4 p-3 rounded-2xl bg-gradient-to-br from-red-950/40 via-neutral-900 to-neutral-900 border border-red-500/20">
        <div className="flex items-center gap-2 text-xs font-semibold text-red-400 mb-1">
          <Radio className="w-3.5 h-3.5 animate-pulse text-red-500" />
          <span>Non-Stop Background Audio</span>
        </div>
        <p className="text-[11px] text-neutral-400 leading-relaxed">
          Plays even when screen is locked or browser is minimized.
        </p>
      </div>
    </aside>
  );
};
