import React, { useState, useRef, useEffect } from 'react';
import { Search, Cast, Code2, Sparkles, User, Settings, Info, Music2, X, ArrowUpRight, TrendingUp, Plus, Minus, Volume2, Power } from 'lucide-react';
import { PWAInstallButton } from '../PWAInstallButton';
import { INITIAL_SONGS } from '../../data/musicCatalog';
import { useMusic } from '../../context/MusicContext';

interface NavbarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenNativeModal: () => void;
}

const POPULAR_SUGGESTIONS = [
  'Arijit Singh romantic hits',
  'Kesariya Brahmastra',
  'Diljit Dosanjh new song',
  'G.O.A.T. Diljit',
  'Starboy The Weeknd',
  'Blinding Lights',
  'Karan Aujla Softly',
  'Tauba Tauba Bad Newz',
  'Sidhu Moose Wala 295',
  'AP Dhillon Brown Munde',
  'Pasoori Ali Sethi',
  'Tum Hi Ho Aashiqui 2',
  'Believer Imagine Dragons',
  'Lofi Girl beats to relax'
];

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  searchQuery,
  onSearchChange,
  onOpenNativeModal,
}) => {
  const { volume, volumeUp, volumeDown, isPlaying, stopMusic } = useMusic();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [isCasting, setIsCasting] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Compute live search suggestions based on input
  const liveSuggestions = searchQuery.trim()
    ? Array.from(
        new Set([
          ...INITIAL_SONGS.filter(
            (s) =>
              s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              s.artist.toLowerCase().includes(searchQuery.toLowerCase())
          ).map((s) => `${s.title} - ${s.artist}`),
          ...POPULAR_SUGGESTIONS.filter((s) =>
            s.toLowerCase().includes(searchQuery.toLowerCase())
          )
        ])
      ).slice(0, 6)
    : POPULAR_SUGGESTIONS.slice(0, 5);

  // Close suggestions dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectSuggestion = (text: string) => {
    onSearchChange(text);
    onSelectTab('search');
    setShowSuggestions(false);
  };

  return (
    <header className="sticky top-0 z-40 flex items-center justify-between px-4 sm:px-6 py-3 bg-[#030303]/95 backdrop-blur-md border-b border-white/5 select-none">
      {/* Brand Logo */}
      <div className="flex items-center gap-6">
        <button
          onClick={() => onSelectTab('home')}
          className="flex items-center gap-2 group cursor-pointer text-left"
        >
          <div className="relative flex items-center justify-center w-8 h-8 rounded-full bg-[#ff0000] text-white shadow-lg shadow-red-600/30 group-hover:scale-105 transition">
            <svg className="w-4 h-4 fill-white ml-0.5" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
            <div className="absolute inset-0 rounded-full border border-white/30 animate-pulse pointer-events-none" />
          </div>
          <div className="flex items-center">
            <span className="font-bold text-lg tracking-tight text-white font-['YouTube_Sans',sans-serif]">
              YouTube Music
            </span>
          </div>
        </button>
      </div>

      {/* Center Search Input with YouTube-style Live Autocomplete Dropdown */}
      <div ref={searchContainerRef} className="flex-1 max-w-xl mx-4 hidden md:block relative">
        <div className="relative flex items-center">
          <Search className="absolute left-3.5 w-4 h-4 text-neutral-400 pointer-events-none" />
          <input
            type="text"
            placeholder="Search songs, albums, artists, Hindi, Punjabi, Pop..."
            value={searchQuery}
            onClick={() => {
              onSelectTab('search');
              setShowSuggestions(true);
            }}
            onFocus={() => {
              onSelectTab('search');
              setShowSuggestions(true);
            }}
            onChange={(e) => {
              onSearchChange(e.target.value);
              onSelectTab('search');
              setShowSuggestions(true);
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                setShowSuggestions(false);
                onSelectTab('search');
              }
            }}
            className="w-full bg-[#1e1e1e] hover:bg-[#282828] focus:bg-[#1a1a1a] text-white text-sm rounded-full pl-10 pr-10 py-2 border border-white/10 focus:border-red-500 focus:outline-none transition shadow-inner placeholder:text-neutral-500"
          />
          {searchQuery && (
            <button
              onClick={() => {
                onSearchChange('');
                setShowSuggestions(false);
              }}
              className="absolute right-3 text-neutral-400 hover:text-white p-1 rounded-full cursor-pointer"
              title="Clear"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* YouTube Autocomplete Suggestions Dropdown */}
        {showSuggestions && liveSuggestions.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1.5 bg-[#212121] rounded-2xl border border-white/10 shadow-2xl py-2 z-50 overflow-hidden">
            <div className="px-3.5 py-1 text-[11px] font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-red-500" />
              <span>YouTube Search Suggestions</span>
            </div>
            {liveSuggestions.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSelectSuggestion(item)}
                className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-white/10 text-left transition cursor-pointer text-sm text-neutral-200 hover:text-white group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <Search className="w-4 h-4 text-neutral-400 group-hover:text-red-400 shrink-0" />
                  <span className="truncate">{item}</span>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-neutral-500 opacity-0 group-hover:opacity-100 transition shrink-0 ml-2" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Mobile Search Icon */}
        <button
          onClick={() => onSelectTab('search')}
          className="md:hidden p-2 rounded-full hover:bg-white/10 text-neutral-300 hover:text-white transition cursor-pointer"
          title="Search"
        >
          <Search className="w-5 h-5" />
        </button>

        {/* Cast Screen / Speaker Simulation */}
        <button
          onClick={() => {
            setIsCasting(!isCasting);
          }}
          className={`p-2 rounded-full transition cursor-pointer ${
            isCasting ? 'text-[#ff0000] bg-red-500/10' : 'text-neutral-300 hover:text-white hover:bg-white/10'
          }`}
          title={isCasting ? 'Casting active' : 'Cast audio'}
        >
          <Cast className="w-5 h-5" />
        </button>

        {/* Sound Up / Down Controls */}
        <div className="hidden sm:flex items-center gap-1 bg-[#1a1a1a] rounded-full border border-white/10 px-1.5 py-0.5 shadow-inner">
          <button
            onClick={volumeDown}
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
            title="Sound Down (-10%)"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <div className="flex items-center gap-1 px-1 text-neutral-300 text-xs font-semibold">
            <Volume2 className="w-3.5 h-3.5 text-red-500" />
            <span className="w-7 text-center">{Math.round(volume * 100)}%</span>
          </div>
          <button
            onClick={volumeUp}
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
            title="Sound Up (+10%)"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Off Music Button */}
        {isPlaying && (
          <button
            onClick={stopMusic}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-950/80 hover:bg-red-600 text-red-300 hover:text-white border border-red-500/50 text-xs font-bold transition cursor-pointer shadow-sm active:scale-95 animate-fade-in"
            title="Turn Off Music"
          >
            <Power className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Off Music</span>
          </button>
        )}

        {/* PWA Install Button */}
        <PWAInstallButton compact />

        {/* Profile Avatar / Settings */}
        <div className="relative">
          <button
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="w-8 h-8 rounded-full bg-gradient-to-tr from-red-600 to-amber-500 text-white font-semibold text-xs flex items-center justify-center ring-2 ring-white/10 hover:ring-white/30 transition cursor-pointer"
            title="Account Menu"
          >
            M
          </button>

          {showProfileMenu && (
            <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-[#1e1e1e] border border-white/10 shadow-2xl py-2 z-50 text-neutral-200">
              <div className="px-4 py-3 border-b border-white/10">
                <p className="text-sm font-semibold text-white">Music Creator</p>
                <p className="text-xs text-neutral-400 truncate">mastitoonstudio10@gmail.com</p>
                <div className="mt-2 flex items-center gap-1 text-[11px] font-medium text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Premium YouTube Music Active</span>
                </div>
              </div>

              <div className="py-1 text-sm">
                <button
                  onClick={() => {
                    onSelectTab('library');
                    setShowProfileMenu(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 hover:bg-white/10 text-left transition"
                >
                  <Music2 className="w-4 h-4 text-neutral-400" />
                  <span>My Offline Downloads</span>
                </button>
                <button
                  onClick={() => {
                    onOpenNativeModal();
                    setShowProfileMenu(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 hover:bg-white/10 text-left transition"
                >
                  <Code2 className="w-4 h-4 text-blue-400" />
                  <span>Android & iOS App Source</span>
                </button>
              </div>

              <div className="border-t border-white/10 pt-1 mt-1 text-xs text-neutral-500 px-4 py-2">
                YouTube Music v2.5 • Audio Pure Mode
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
