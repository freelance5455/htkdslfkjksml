import React from 'react';
import {
  X,
  ShieldCheck,
  AlertTriangle,
  XCircle,
  CheckCircle2,
  ExternalLink,
  Smartphone,
  Cpu,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { ReadinessAuditResult, DevicePermissionItem } from '../utils/devicePermissions';

interface DeviceReadinessReportModalProps {
  isOpen: boolean;
  auditResult: ReadinessAuditResult | null;
  onClose: () => void;
  onOpenSettings: (permission: DevicePermissionItem) => void;
  onGrantAll: () => void;
}

export const DeviceReadinessReportModal: React.FC<DeviceReadinessReportModalProps> = ({
  isOpen,
  auditResult,
  onClose,
  onOpenSettings,
  onGrantAll,
}) => {
  if (!isOpen || !auditResult) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div
        className="relative w-full max-w-xl bg-[#0B111E] border border-cyan-500/40 rounded-2xl shadow-2xl shadow-cyan-950/70 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#070B14]">
          <div className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center border ${
                auditResult.isFullyReady
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                  : auditResult.isCoreReady
                  ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-400'
                  : 'bg-amber-500/20 border-amber-500/40 text-amber-400'
              }`}
            >
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-mono text-cyan-400 tracking-wider font-semibold uppercase">
                Hardware & Subsystem Telemetry
              </div>
              <h2 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
                <span>DEVICE READINESS REPORT</span>
                <span
                  className={`text-xs px-2 py-0.5 rounded-full font-mono font-bold ${
                    auditResult.isFullyReady
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  }`}
                >
                  {auditResult.percentage}% READY
                </span>
              </h2>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Progress meter */}
        <div className="w-full bg-slate-900 h-1.5 overflow-hidden">
          <div
            className={`h-full transition-all duration-500 ${
              auditResult.isFullyReady
                ? 'bg-emerald-400 shadow-[0_0_12px_#34d399]'
                : 'bg-gradient-to-r from-cyan-500 to-emerald-400 shadow-[0_0_12px_#06b6d4]'
            }`}
            style={{ width: `${auditResult.percentage}%` }}
          />
        </div>

        {/* Body content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Executive Summary Card */}
          <div
            className={`p-4 rounded-xl border ${
              auditResult.isFullyReady
                ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
                : auditResult.isCoreReady
                ? 'bg-cyan-950/30 border-cyan-500/40 text-cyan-200'
                : 'bg-amber-950/30 border-amber-500/40 text-amber-200'
            }`}
          >
            <div className="flex items-center gap-2 font-mono font-bold text-xs uppercase tracking-wider mb-1">
              {auditResult.isFullyReady ? (
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-amber-400" />
              )}
              <span>System Readiness Assessment</span>
            </div>
            <p className="text-xs leading-relaxed text-slate-200">
              {auditResult.reportMessage}
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="text-emerald-400 font-bold font-mono text-base">
                ✓ {auditResult.grantedCount}
              </div>
              <div className="text-[10px] text-slate-400 font-mono uppercase">Granted</div>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="text-amber-400 font-bold font-mono text-base">
                ⚠ {auditResult.requiredCount}
              </div>
              <div className="text-[10px] text-slate-400 font-mono uppercase">Required</div>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="text-rose-400 font-bold font-mono text-base">
                ✕ {auditResult.deniedCount}
              </div>
              <div className="text-[10px] text-slate-400 font-mono uppercase">Denied</div>
            </div>
          </div>

          {/* Remaining Items (if any) */}
          {auditResult.remainingItems.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-semibold flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Remaining Items Requiring Attention ({auditResult.remainingItems.length})</span>
                </span>
                <button
                  type="button"
                  onClick={onGrantAll}
                  className="text-[10px] font-mono text-cyan-400 hover:text-cyan-300 underline"
                >
                  Grant All in Simulator
                </button>
              </div>

              <div className="space-y-2">
                {auditResult.remainingItems.map(item => (
                  <div
                    key={item.id}
                    className="p-3 rounded-xl bg-[#0F1626] border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-xs">{item.name}</span>
                        <span
                          className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                            item.status === 'DENIED'
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          }`}
                        >
                          {item.status === 'DENIED' ? '✕ Denied' : '⚠ Required'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        {item.whyNeeded}
                      </p>
                      <div className="text-[10px] font-mono text-slate-400">
                        {item.gracefulFallback}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenSettings(item);
                      }}
                      className="shrink-0 px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-mono font-bold text-[10px] flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>OPEN SETTINGS</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Graceful Degradation Notice */}
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] font-mono text-slate-300 space-y-1.5">
            <div className="flex items-center gap-1.5 text-cyan-400 font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>NON-CRASH RESILIENCE COMMITMENT</span>
            </div>
            <p className="text-slate-400 text-[10px] leading-relaxed">
              In accordance with Android Security Guidelines, JARVIS never forces permission prompts repeatedly or crashes when access is denied. If speech recognition or calendar access is blocked, on-screen text fallbacks ensure seamless continued operation.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-[#070B14] flex items-center justify-between gap-3">
          <div className="text-[10px] font-mono text-slate-400">
            {auditResult.isFullyReady ? 'All 8 Subsystems Verified' : `${auditResult.remainingItems.length} Subsystem(s) Pending`}
          </div>

          <div className="flex items-center gap-2">
            {auditResult.remainingItems.length > 0 && (
              <button
                type="button"
                onClick={onGrantAll}
                className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono font-bold text-xs transition-colors"
              >
                GRANT ALL
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-mono font-semibold text-xs transition-colors"
            >
              CLOSE
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
