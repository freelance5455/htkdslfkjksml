import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
import {
  AUTOMATED_LEVELS,
  CameraMode,
  CinematicCameraAngle,
  GamePhase,
  HYPERCARS,
  LiveTelemetry,
  NetworkMode,
  RaceParticipant,
  ReplayPlaybackState,
  VehicleCustomization,
} from '../types/game';
import {
  buildHypercarRig,
  CarRig,
  configurePaintMaterial,
  updateCarExplodedView,
} from '../three/CarBuilder';
import { buildLevelTrack, BuiltTrack, sampleTrackFrame } from '../three/TrackBuilder';
import { soundEngine } from '../audio/SoundEngine';

// Pre-allocated module-scope math objects (Zero GC in render loop)
const _pos = new THREE.Vector3();
const _tan = new THREE.Vector3();
const _right = new THREE.Vector3();
const _aheadPos = new THREE.Vector3();
const _aheadTan = new THREE.Vector3();
const _aheadRight = new THREE.Vector3();
const _camTargetPos = new THREE.Vector3();
const _camLookAt = new THREE.Vector3();
const _particleDummy = new THREE.Object3D();

function lerpAngle(a: number, b: number, t: number): number {
  let diff = (b - a) % (Math.PI * 2);
  if (diff < -Math.PI) diff += Math.PI * 2;
  if (diff > Math.PI) diff -= Math.PI * 2;
  return a + diff * t;
}

interface ReplayActorFrame {
  id: string;
  x: number;
  y: number;
  z: number;
  heading: number;
  pitch: number;
  roll: number;
  steerAngle: number;
  driftAngle: number;
  speedKmh: number;
  isBraking: boolean;
  isNitro: boolean;
  lap: number;
  trackT: number;
  lateralOffset: number;
}

interface ReplayRecordedSnapshot {
  timestamp: number;
  actors: ReplayActorFrame[];
}

interface ActorRuntime {
  participant: RaceParticipant;
  rig: CarRig;
  trackT: number;
  lap: number;
  lateralOffset: number;
  lateralVel: number;
  speedMs: number;
  steerAngle: number;
  driftAngle: number;
  nitroAmount: number;
  isNitro: boolean;
  isBraking: boolean;
  finished: boolean;
  finishTimeMs: number | null;
  worldPos: THREE.Vector3;
  heading: number;
  aiTargetLane: number;
  aiLaneTimer: number;
}

interface ParticleState {
  active: boolean;
  life: number;
  maxLife: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  scale: number;
}

interface RacingCanvasProps {
  gamePhase: GamePhase;
  levelIndex: number;
  customLaps?: number;
  customization: VehicleCustomization;
  cameraMode: CameraMode;
  autoDrive: boolean;
  autoAdvanceLevels: boolean;
  networkMode: NetworkMode;
  roomCode: string;
  localPlayerName: string;
  participants: RaceParticipant[];
  replayState?: ReplayPlaybackState;
  onTelemetryUpdate: (telemetry: LiveTelemetry) => void;
  onRaceFinished: (
    winnerName: string,
    playerRank: number,
    lapTimeMs: number,
    sessionDistanceMeters: number,
    bestLapMs: number | null
  ) => void;
  onRemotePlayersChange: (peers: Array<{ id: string; name: string; carId: string; lap: number; speedKmh: number }>) => void;
  onCountdownStep: (stepText: string | null) => void;
  onReplayReady?: (duration: number) => void;
  onReplayTimeUpdate?: (currentTime: number) => void;
}

export const RacingCanvas: React.FC<RacingCanvasProps> = ({
  gamePhase,
  levelIndex,
  customLaps,
  customization,
  cameraMode,
  autoDrive,
  networkMode,
  roomCode,
  localPlayerName,
  participants,
  replayState,
  onTelemetryUpdate,
  onRaceFinished,
  onRemotePlayersChange,
  onCountdownStep,
  onReplayReady,
  onReplayTimeUpdate,
}) => {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);

  // Store mutable props in refs so React UI updates never tear down or reset WebGL
  const stateRef = useRef({
    gamePhase,
    levelIndex,
    customLaps,
    customization,
    cameraMode,
    autoDrive,
    networkMode,
    roomCode,
    localPlayerName,
    participants,
    replayState,
    onTelemetryUpdate,
    onRaceFinished,
    onRemotePlayersChange,
    onCountdownStep,
    onReplayReady,
    onReplayTimeUpdate,
  });

  useEffect(() => {
    stateRef.current = {
      gamePhase,
      levelIndex,
      customLaps,
      customization,
      cameraMode,
      autoDrive,
      networkMode,
      roomCode,
      localPlayerName,
      participants,
      replayState,
      onTelemetryUpdate,
      onRaceFinished,
      onRemotePlayersChange,
      onCountdownStep,
      onReplayReady,
      onReplayTimeUpdate,
    };
  }, [
    gamePhase,
    levelIndex,
    customLaps,
    customization,
    cameraMode,
    autoDrive,
    networkMode,
    roomCode,
    localPlayerName,
    participants,
    replayState,
    onTelemetryUpdate,
    onRaceFinished,
    onRemotePlayersChange,
    onCountdownStep,
    onReplayReady,
    onReplayTimeUpdate,
  ]);

  useEffect(() => {
    const container = canvasMountRef.current;
    if (!container) return;

    // 1. Software-WebGL Guard from GPU renderer string
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      62,
      (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight),
      0.2,
      3500
    );
    camera.position.set(0, 4.2, 9.5);

    // 2. Mandatory Studio Environment Reflection (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 3. Balanced 3-Point Studio & Outdoor Rig + Warm/Cool Contrast
    const hemiLight = new THREE.HemisphereLight(0x7dd3fc, 0x1e293b, 0.85);
    hemiLight.position.set(0, 80, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfde68a, 2.2);
    keyLight.position.set(60, 95, 45);
    keyLight.castShadow = !isSoftwareGl;
    if (!isSoftwareGl) {
      keyLight.shadow.mapSize.width = 2048;
      keyLight.shadow.mapSize.height = 2048;
      const d = 85;
      keyLight.shadow.camera.left = -d;
      keyLight.shadow.camera.right = d;
      keyLight.shadow.camera.top = d;
      keyLight.shadow.camera.bottom = -d;
      keyLight.shadow.camera.near = 5;
      keyLight.shadow.camera.far = 260;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);
    scene.add(keyLight.target);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 0.65);
    fillLight.position.set(-55, 40, -45);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xf8fafc, 0.55);
    rimLight.position.set(0, 35, -75);
    scene.add(rimLight);

    // Studio Softboxes for Luxury Automotive Specular Highlights (skip when isSoftwareGl)
    if (!isSoftwareGl) {
      RectAreaLightUniformsLib.init();
      const softbox1 = new THREE.RectAreaLight(0xffffff, 4.5, 8, 3);
      softbox1.position.set(0, 6.5, 0);
      softbox1.lookAt(0, 0, 0);
      scene.add(softbox1);
    }

    // 4. Pooled Instanced Particles for Nitro Sparks & Drift Tire Smoke
    const maxParticles = 80;
    const particleGeo = new THREE.DodecahedronGeometry(0.18, 0);
    const particleMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.75,
    });
    const particleMesh = new THREE.InstancedMesh(particleGeo, particleMat, maxParticles);
    particleMesh.frustumCulled = false;
    scene.add(particleMesh);

    const particles: ParticleState[] = Array.from({ length: maxParticles }, () => ({
      active: false,
      life: 0,
      maxLife: 0.4,
      x: 0,
      y: -100,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      scale: 0.001,
    }));
    let particleCursor = 0;

    function spawnParticle(
      x: number,
      y: number,
      z: number,
      vx: number,
      vy: number,
      vz: number,
      scale: number,
      maxLife: number
    ) {
      const p = particles[particleCursor];
      particleCursor = (particleCursor + 1) % maxParticles;
      p.active = true;
      p.life = 0;
      p.maxLife = maxLife;
      p.x = x;
      p.y = y;
      p.z = z;
      p.vx = vx;
      p.vy = vy;
      p.vz = vz;
      p.scale = scale;
    }

    // Track & Actor State Management
    let currentTrack: BuiltTrack | null = null;
    let builtLevelIdx = -1;
    const actors = new Map<string, ActorRuntime>();
    const remoteActors = new Map<
      string,
      {
        id: string;
        name: string;
        carId: string;
        paintHex: string;
        finishType: string;
        rimHex: string;
        caliperHex: string;
        aeroPreset: string;
        trackProgress: number;
        lap: number;
        lateralOffset: number;
        speedKmh: number;
        rig: CarRig;
      }
    >();

    let raceStartTimestamp = performance.now();
    let bestLapMs: number | null = null;
    let lastLapStartTimestamp = performance.now();
    let p1SessionDistanceMeters = 0;
    let hitstopTimer = 0;
    let cameraShakeIntensity = 0;
    let showroomOrbitAngle = 0.55;
    let lastPhase: GamePhase = stateRef.current.gamePhase;
    let countdownRemaining = 0;
    let lastCountdownInt = -1;

    // Replay 30-second telemetry recording buffer
    const recordedBuffer: ReplayRecordedSnapshot[] = [];
    let lastRecordTime = 0;
    let localReplayTime = 0;
    let lastReplayTimeEmit = 0;
    let p1ContinuousDriftTime = 0;
    let p1MaxDriftTime = 0;

    // Rebuild level track when levelIndex changes
    function syncLevelEnvironment(targetLevelIndex: number) {
      if (builtLevelIdx === targetLevelIndex && currentTrack) return;
      if (currentTrack) {
        scene.remove(currentTrack.group);
        currentTrack.dispose();
      }
      const lvl = AUTOMATED_LEVELS[targetLevelIndex] || AUTOMATED_LEVELS[0];
      builtLevelIdx = targetLevelIndex;

      scene.background = new THREE.Color(lvl.skyColorHex);
      scene.fog = new THREE.FogExp2(lvl.fogColorHex, lvl.fogDensity);
      keyLight.color.set(lvl.sunColorHex);
      keyLight.intensity = lvl.sunIntensity;
      hemiLight.color.set(lvl.hemiSkyHex);
      hemiLight.groundColor.set(lvl.hemiGroundHex);

      currentTrack = buildLevelTrack(lvl, renderer, isSoftwareGl);
      scene.add(currentTrack.group);

      if (!isSoftwareGl) {
        renderer.compile(scene, camera);
      }
    }

    // Rebuild or sync actor meshes with participant roster & customization
    let lastLocalCarSignature = '';

    function syncParticipantsRoster(resetPositions = false) {
      const { participants: roster, customization: cust } = stateRef.current;
      const localSig = `${cust.carId}_${cust.aeroPreset}_${cust.paintHex}`;

      // Remove stale actors not in roster
      for (const [id, act] of actors.entries()) {
        if (!roster.some((p) => p.id === id)) {
          scene.remove(act.rig.root);
          actors.delete(id);
        }
      }

      // If local player changed car model or aero kit, rebuild their rig
      if (localSig !== lastLocalCarSignature && actors.has('local-p1')) {
        const old = actors.get('local-p1')!;
        scene.remove(old.rig.root);
        actors.delete('local-p1');
      }
      lastLocalCarSignature = localSig;

      roster.forEach((p, idx) => {
        let act = actors.get(p.id);
        const isP1 = p.controlType === 'local-p1';
        const carId = isP1 ? cust.carId : p.carId;
        const paintHex = isP1 ? cust.paintHex : p.paintHex;
        const finishType = isP1 ? cust.finishType : p.finishType;
        const rimHex = isP1 ? cust.rimHex : p.rimHex;
        const caliperHex = isP1 ? cust.caliperHex : p.caliperHex;
        const aeroPreset = isP1 ? cust.aeroPreset : p.aeroPreset;

        if (!act) {
          const rig = buildHypercarRig({
            carId,
            paintHex,
            finishType,
            rimHex,
            caliperHex,
            aeroPreset,
            isSoftwareGl,
            driverName: isP1 ? undefined : p.name,
          });
          scene.add(rig.root);

          const startLane = ((idx % 2 === 0 ? -1 : 1) * (1.8 + Math.floor(idx / 2) * 1.6)) % 5.5;
          const startT = Math.max(0, 0.992 - idx * 0.008) % 1;

          act = {
            participant: { ...p },
            rig,
            trackT: idx === 0 ? 0.002 : startT,
            lap: 1,
            lateralOffset: idx === 0 ? 0 : startLane,
            lateralVel: 0,
            speedMs: 0,
            steerAngle: 0,
            driftAngle: 0,
            nitroAmount: 100,
            isNitro: false,
            isBraking: false,
            finished: false,
            finishTimeMs: null,
            worldPos: new THREE.Vector3(),
            heading: 0,
            aiTargetLane: startLane,
            aiLaneTimer: 2 + idx,
          };
          actors.set(p.id, act);
        } else {
          act.participant = { ...p };
          if (isP1) {
            act.rig.paintMaterials.forEach((m) =>
              configurePaintMaterial(m, cust.paintHex, cust.finishType)
            );
            act.rig.rimMaterials.forEach((m) => m.color.set(cust.rimHex));
            act.rig.caliperMaterials.forEach((m) => m.color.set(cust.caliperHex));
          }
        }

        if (resetPositions && act) {
          const startLane = idx === 0 ? -1.8 : (idx % 2 === 0 ? -1 : 1) * (2.2 + (idx % 3) * 1.4);
          act.trackT = 0.001 + idx * 0.006;
          act.lap = 1;
          act.lateralOffset = startLane;
          act.lateralVel = 0;
          act.speedMs = 0;
          act.steerAngle = 0;
          act.driftAngle = 0;
          act.nitroAmount = 100;
          act.isNitro = false;
          act.isBraking = false;
          act.finished = false;
          act.finishTimeMs = null;
        }
      });

      if (resetPositions) {
        recordedBuffer.length = 0;
        localReplayTime = 0;
        lastRecordTime = 0;
        p1ContinuousDriftTime = 0;
        p1MaxDriftTime = 0;
      }
    }

    syncLevelEnvironment(stateRef.current.levelIndex);
    syncParticipantsRoster(true);

    // 5. Responsive Keyboard Input State (Held vs JustPressed + Window Blur Safety)
    const heldKeys = new Set<string>();
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement) return;
      heldKeys.add(e.code);
    };
    const onKeyUp = (e: KeyboardEvent) => {
      heldKeys.delete(e.code);
    };
    const onWindowBlur = () => {
      heldKeys.clear();
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onWindowBlur);

    // 6. Real-Time WebSocket Multiplayer Connection Manager
    let ws: WebSocket | null = null;
    let wsReconnectTimer: number | null = null;
    let activeWsRoom = '';
    const localPeerId = `peer_${Math.random().toString(36).slice(2, 9)}`;
    let lastWsEmitTime = 0;

    function connectWebSocket(targetRoom: string) {
      if (ws) {
        ws.onclose = null;
        ws.close();
        ws = null;
      }
      try {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws`;
        const socket = new WebSocket(wsUrl);
        ws = socket;
        activeWsRoom = targetRoom;

        socket.onopen = () => {
          const { customization: c, localPlayerName: pName } = stateRef.current;
          socket.send(
            JSON.stringify({
              type: 'room:join',
              roomCode: targetRoom,
              player: {
                id: localPeerId,
                name: pName,
                carId: c.carId,
                paintHex: c.paintHex,
                finishType: c.finishType,
                rimHex: c.rimHex,
                caliperHex: c.caliperHex,
                aeroPreset: c.aeroPreset,
                trackProgress: 0,
                lap: 1,
                lateralOffset: 0,
                speedKmh: 0,
              },
            })
          );
        };

        socket.onmessage = (event) => {
          try {
            const msg = JSON.parse(event.data);
            if (msg.type === 'room:init' && Array.isArray(msg.players)) {
              msg.players.forEach((p: any) => {
                if (p.id !== localPeerId) upsertRemotePeer(p);
              });
              notifyRemotePeersList();
            } else if (msg.type === 'player:joined' || msg.type === 'player:updated') {
              if (msg.player && msg.player.id !== localPeerId) {
                upsertRemotePeer(msg.player);
                notifyRemotePeersList();
              }
            } else if (msg.type === 'player:left' && msg.playerId) {
              const existing = remoteActors.get(msg.playerId);
              if (existing) {
                scene.remove(existing.rig.root);
                remoteActors.delete(msg.playerId);
                notifyRemotePeersList();
              }
            }
          } catch {
            // Ignore malformed socket messages
          }
        };

        socket.onclose = () => {
          if (stateRef.current.networkMode === 'multiplayer') {
            wsReconnectTimer = window.setTimeout(() => {
              connectWebSocket(stateRef.current.roomCode);
            }, 2500);
          }
        };
      } catch {
        // Fallback silently if offline
      }
    }

    function upsertRemotePeer(p: any) {
      let peer = remoteActors.get(p.id);
      if (!peer) {
        const rig = buildHypercarRig({
          carId: p.carId || 'valkyrie-amr26',
          paintHex: p.paintHex || '#38BDF8',
          finishType: (p.finishType as any) || 'metallic',
          rimHex: p.rimHex || '#E2E8F0',
          caliperHex: p.caliperHex || '#06B6D4',
          aeroPreset: (p.aeroPreset as any) || 'gt3',
          isSoftwareGl,
          driverName: `${p.name || 'Peer'} [LIVE]`,
        });
        scene.add(rig.root);
        peer = {
          id: p.id,
          name: p.name || 'Peer',
          carId: p.carId || 'valkyrie-amr26',
          paintHex: p.paintHex || '#38BDF8',
          finishType: p.finishType || 'metallic',
          rimHex: p.rimHex || '#E2E8F0',
          caliperHex: p.caliperHex || '#06B6D4',
          aeroPreset: p.aeroPreset || 'gt3',
          trackProgress: Number(p.trackProgress || 0),
          lap: Number(p.lap || 1),
          lateralOffset: Number(p.lateralOffset || 0),
          speedKmh: Number(p.speedKmh || 0),
          rig,
        };
        remoteActors.set(p.id, peer);
      } else {
        peer.trackProgress = Number(p.trackProgress ?? peer.trackProgress);
        peer.lap = Number(p.lap ?? peer.lap);
        peer.lateralOffset = Number(p.lateralOffset ?? peer.lateralOffset);
        peer.speedKmh = Number(p.speedKmh ?? peer.speedKmh);
      }
    }

    function clearRemotePeers() {
      for (const peer of remoteActors.values()) {
        scene.remove(peer.rig.root);
      }
      remoteActors.clear();
      notifyRemotePeersList();
    }

    function notifyRemotePeersList() {
      stateRef.current.onRemotePlayersChange(
        Array.from(remoteActors.values()).map((r) => ({
          id: r.id,
          name: r.name,
          carId: r.carId,
          lap: r.lap,
          speedKmh: Math.round(r.speedKmh),
        }))
      );
    }

    // Resize listener
    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    // 7. Software WebGL Fence-Synced Pacer & Main 60fps Loop
    let frameId = 0;
    let isDisposed = false;
    let lastFrameTime = performance.now();
    let lastHudUpdateTime = 0;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      const poll = () => {
        if (isDisposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (sync && state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (isDisposed) return;
      const now = performance.now();
      const rawDt = (now - lastFrameTime) / 1000;
      lastFrameTime = now;
      const dt = Math.min(rawDt, 0.05); // Clamp frame delta time

      const st = stateRef.current;
      const currentLevel = AUTOMATED_LEVELS[st.levelIndex] || AUTOMATED_LEVELS[0];

      // Sync level or network mode transitions
      syncLevelEnvironment(st.levelIndex);
      syncParticipantsRoster(false);

      if (st.networkMode === 'multiplayer' && activeWsRoom !== st.roomCode) {
        connectWebSocket(st.roomCode);
      } else if (st.networkMode === 'offline' && ws) {
        ws.onclose = null;
        ws.close();
        ws = null;
        activeWsRoom = '';
        clearRemotePeers();
      }

      // Detect phase changes (e.g. starting countdown or restarting race)
      if (st.gamePhase !== lastPhase) {
        if (st.gamePhase === 'countdown') {
          syncParticipantsRoster(true);
          countdownRemaining = 3.2;
          lastCountdownInt = 4;
          bestLapMs = null;
          p1SessionDistanceMeters = 0;
        } else if (st.gamePhase === 'playing' && lastPhase === 'countdown') {
          raceStartTimestamp = now;
          lastLapStartTimestamp = now;
        }
        lastPhase = st.gamePhase;
      }

      // Handle 3-2-1-GO Countdown
      if (st.gamePhase === 'countdown') {
        countdownRemaining -= dt;
        const ceilVal = Math.ceil(countdownRemaining);
        if (ceilVal !== lastCountdownInt) {
          lastCountdownInt = ceilVal;
          if (ceilVal >= 1 && ceilVal <= 3) {
            st.onCountdownStep(String(ceilVal));
            soundEngine.playCountdownBeep(false);
          } else if (ceilVal <= 0) {
            st.onCountdownStep('GO!');
            soundEngine.playCountdownBeep(true);
          }
        }
      }

      const p1Spec = HYPERCARS.find((c) => c.id === st.customization.carId) || HYPERCARS[0];
      const p1Actor = actors.get('local-p1');

      // Update Exploded View smoothly on Player 1 car
      if (p1Actor) {
        const targetExploded =
          st.gamePhase === 'playing' || st.gamePhase === 'countdown'
            ? 0
            : st.customization.explodedView;
        updateCarExplodedView(p1Actor.rig, targetExploded, dt, p1Spec);
      }

      // Simulation Hitstop Decay
      if (hitstopTimer > 0) {
        hitstopTimer -= dt;
      }

      const simDt = hitstopTimer > 0 ? dt * 0.15 : dt;
      const isRacingActive = st.gamePhase === 'playing';

      if (currentTrack) {
        if (st.gamePhase === 'replay') {
          const repState = st.replayState;
          const repSpeed = repState?.playbackSpeed ?? 1.0;
          const bufferLen = recordedBuffer.length;

          if (bufferLen >= 2) {
            const t0 = recordedBuffer[0].timestamp;
            const tEnd = recordedBuffer[bufferLen - 1].timestamp;
            const replayDuration = Math.max(0.1, (tEnd - t0) / 1000);

            if (repState?.isPlaying) {
              localReplayTime += dt * repSpeed;
              if (localReplayTime > replayDuration) {
                localReplayTime = 0;
              }
            }

            if (repState && Math.abs(repState.currentTime - localReplayTime) > 0.45) {
              localReplayTime = THREE.MathUtils.clamp(repState.currentTime, 0, replayDuration);
            }

            if (now - lastReplayTimeEmit > 66) {
              lastReplayTimeEmit = now;
              st.onReplayTimeUpdate?.(localReplayTime);
            }

            const targetTs = t0 + localReplayTime * 1000;
            let low = 0;
            let high = bufferLen - 1;
            while (low <= high) {
              const mid = (low + high) >> 1;
              if (recordedBuffer[mid].timestamp < targetTs) {
                low = mid + 1;
              } else {
                high = mid - 1;
              }
            }
            const s0Idx = Math.max(0, Math.min(bufferLen - 2, high));
            const s1Idx = s0Idx + 1;
            const snap0 = recordedBuffer[s0Idx];
            const snap1 = recordedBuffer[s1Idx];
            const dtSnap = snap1.timestamp - snap0.timestamp;
            const alpha = dtSnap > 0 ? THREE.MathUtils.clamp((targetTs - snap0.timestamp) / dtSnap, 0, 1) : 0;

            for (const act of actors.values()) {
              const f0 = snap0.actors.find((a) => a.id === act.participant.id);
              const f1 = snap1.actors.find((a) => a.id === act.participant.id);

              if (f0 && f1) {
                const curX = THREE.MathUtils.lerp(f0.x, f1.x, alpha);
                const curY = THREE.MathUtils.lerp(f0.y, f1.y, alpha);
                const curZ = THREE.MathUtils.lerp(f0.z, f1.z, alpha);
                const curHeading = lerpAngle(f0.heading, f1.heading, alpha);
                const curPitch = THREE.MathUtils.lerp(f0.pitch, f1.pitch, alpha);
                const curRoll = THREE.MathUtils.lerp(f0.roll, f1.roll, alpha);
                const curSteer = THREE.MathUtils.lerp(f0.steerAngle, f1.steerAngle, alpha);
                const curDrift = THREE.MathUtils.lerp(f0.driftAngle, f1.driftAngle, alpha);
                const curSpeedKmh = THREE.MathUtils.lerp(f0.speedKmh, f1.speedKmh, alpha);
                const curBraking = alpha > 0.5 ? f1.isBraking : f0.isBraking;
                const curNitro = alpha > 0.5 ? f1.isNitro : f0.isNitro;

                act.worldPos.set(curX, curY, curZ);
                act.rig.root.position.copy(act.worldPos);
                act.heading = curHeading;
                act.rig.root.rotation.set(0, curHeading, 0);
                act.rig.chassisGroup.rotation.x = curPitch;
                act.rig.chassisGroup.rotation.z = curRoll;
                act.rig.wheelFL.rotation.y = -curSteer * 0.85;
                act.rig.wheelFR.rotation.y = -curSteer * 0.85;
                act.speedMs = curSpeedKmh / 3.6;
                act.driftAngle = curDrift;
                act.trackT = THREE.MathUtils.lerp(f0.trackT, f1.trackT, alpha);
                act.isBraking = curBraking;
                act.isNitro = curNitro;

                const spinDelta = (act.speedMs * dt * repSpeed) / 0.35;
                act.rig.wheelSpinners.forEach((s) => {
                  s.rotation.x -= spinDelta;
                });
                act.rig.brakeLightMaterial.emissiveIntensity = curBraking ? 4.8 : 1.4;
                act.rig.nitroFlameLeft.visible = curNitro;
                act.rig.nitroFlameRight.visible = curNitro;

                if (curNitro) {
                  const flameScale = 0.85 + Math.random() * 0.45;
                  act.rig.nitroFlameLeft.scale.set(1, 1, flameScale);
                  act.rig.nitroFlameRight.scale.set(1, 1, flameScale);
                  if (Math.random() < 0.4) {
                    spawnParticle(
                      act.worldPos.x + (Math.random() - 0.5) * 0.6,
                      act.worldPos.y + 0.35,
                      act.worldPos.z + (Math.random() - 0.5) * 0.6,
                      (Math.random() - 0.5) * 2,
                      0.8 + Math.random() * 1.2,
                      (Math.random() - 0.5) * 2,
                      0.9,
                      0.28
                    );
                  }
                } else if (Math.abs(curDrift) > 0.14 && curSpeedKmh > 50) {
                  if (Math.random() < 0.35) {
                    spawnParticle(
                      act.worldPos.x + (Math.random() - 0.5) * 1.1,
                      act.worldPos.y + 0.15,
                      act.worldPos.z + (Math.random() - 0.5) * 1.1,
                      (Math.random() - 0.5) * 1.5,
                      0.5 + Math.random() * 0.8,
                      (Math.random() - 0.5) * 1.5,
                      1.15,
                      0.38
                    );
                  }
                }

                if (act.participant.controlType === 'local-p1') {
                  const p1Spec = HYPERCARS.find((c) => c.id === st.customization.carId) || HYPERCARS[0];
                  const speedNorm = Math.min(1, curSpeedKmh / p1Spec.topSpeedKmh);
                  const gear = Math.min(7, Math.max(1, Math.floor(speedNorm * 7) + 1));
                  const gearSpan = 1 / 7;
                  const inGearProgress = (speedNorm % gearSpan) / gearSpan;
                  const rpm =
                    curSpeedKmh < 3
                      ? 1100 + Math.sin(now * 0.01) * 60
                      : Math.round(2800 + inGearProgress * 6100);

                  soundEngine.updateTelemetry(
                    curSpeedKmh,
                    rpm,
                    gear,
                    Math.abs(curDrift) > 0.13,
                    curNitro,
                    repState?.isPlaying ?? false
                  );
                }
              } else if (f0) {
                act.worldPos.set(f0.x, f0.y, f0.z);
                act.rig.root.position.copy(act.worldPos);
                act.heading = f0.heading;
                act.rig.root.rotation.set(0, f0.heading, 0);
              }
            }
          }
        } else {
          const trackLen = currentTrack.totalLength;
          const halfTrackW = currentTrack.trackWidth * 0.45;

        // Advance all local, P2, and AI actors
        for (const [id, act] of actors.entries()) {
          const isP1 = act.participant.controlType === 'local-p1';
          const isP2 = act.participant.controlType === 'local-p2';
          const spec =
            HYPERCARS.find((c) => c.id === (isP1 ? st.customization.carId : act.participant.carId)) ||
            HYPERCARS[0];

          // Calculate upgraded performance stats
          const engineMult = isP1 ? 1 + (st.customization.engineStage - 1) * 0.06 : 1;
          const handlingMult = isP1 ? 1 + (st.customization.suspensionStage - 1) * 0.08 : 1;
          const maxSpeedMs = ((spec.topSpeedKmh * engineMult) / 3.6) * (isP1 || isP2 ? 1.0 : act.participant.skillRating * currentLevel.difficultyMultiplier);
          const accelRate = (34 / spec.accel0to100) * engineMult;

          let throttle = 0;
          let brake = 0;
          let steerInput = 0;
          let handbrake = false;
          let wantNitro = false;

          if (isRacingActive && !act.finished) {
            if (isP1 && !st.autoDrive) {
              const hasP2 = st.participants.some((p) => p.controlType === 'local-p2');
              const upPressed =
                heldKeys.has('KeyW') || (!hasP2 && heldKeys.has('ArrowUp'));
              const downPressed =
                heldKeys.has('KeyS') || (!hasP2 && heldKeys.has('ArrowDown'));
              const leftPressed =
                heldKeys.has('KeyA') || (!hasP2 && heldKeys.has('ArrowLeft'));
              const rightPressed =
                heldKeys.has('KeyD') || (!hasP2 && heldKeys.has('ArrowRight'));

              throttle = upPressed ? 1 : 0;
              brake = downPressed ? 1 : 0;
              steerInput = (leftPressed ? -1 : 0) + (rightPressed ? 1 : 0);
              handbrake = heldKeys.has('Space');
              wantNitro = heldKeys.has('ShiftLeft') || (!hasP2 && heldKeys.has('ShiftRight'));
            } else if (isP2) {
              throttle = heldKeys.has('ArrowUp') ? 1 : 0;
              brake = heldKeys.has('ArrowDown') ? 1 : 0;
              steerInput =
                (heldKeys.has('ArrowLeft') ? -1 : 0) + (heldKeys.has('ArrowRight') ? 1 : 0);
              handbrake = heldKeys.has('Enter');
              wantNitro = heldKeys.has('ShiftRight');
            } else {
              // Autonomous AI Racing Line & Overtake Controller (also powers Auto-Drive assist)
              sampleTrackFrame(currentTrack.curve, act.trackT, _pos, _tan, _right);
              sampleTrackFrame(
                currentTrack.curve,
                (act.trackT + 0.035) % 1,
                _aheadPos,
                _aheadTan,
                _aheadRight
              );
              const cornerSharpness = 1 - Math.max(0, _tan.dot(_aheadTan));

              act.aiLaneTimer -= simDt;
              if (act.aiLaneTimer <= 0) {
                act.aiLaneTimer = 1.8 + Math.random() * 2.5;
                act.aiTargetLane = (Math.random() - 0.5) * (halfTrackW * 1.4);
              }

              const laneErr = act.aiTargetLane - act.lateralOffset;
              steerInput = THREE.MathUtils.clamp(laneErr * 0.45, -0.85, 0.85);
              throttle = cornerSharpness > 0.08 && act.speedMs > maxSpeedMs * 0.78 ? 0.35 : 1.0;
              wantNitro = cornerSharpness < 0.025 && act.nitroAmount > 45;
            }
          } else if (st.gamePhase === 'title' && isP1) {
            // Subtle idle wheel turn in showroom
            steerInput = Math.sin(now * 0.0012) * 0.25;
          }

          // Nitro consumption & regeneration
          if (wantNitro && act.nitroAmount > 4 && throttle > 0) {
            act.isNitro = true;
            const drainRate = isP1 ? 26 - st.customization.turboStage * 3 : 24;
            act.nitroAmount = Math.max(0, act.nitroAmount - drainRate * simDt);
          } else {
            act.isNitro = false;
            const regenRate = handbrake && act.speedMs > 20 ? 18 : 6.5;
            act.nitroAmount = Math.min(100, act.nitroAmount + regenRate * simDt);
          }

          // Longitudinal Velocity Integration
          const effectiveMaxSpeed = act.isNitro ? maxSpeedMs * 1.24 : maxSpeedMs;
          if (throttle > 0) {
            const boostMult = act.isNitro ? 1.65 : 1.0;
            act.speedMs += accelRate * boostMult * throttle * simDt;
          } else if (brake > 0) {
            act.speedMs -= 42 * brake * simDt;
          } else {
            // Aerodynamic drag & rolling resistance
            act.speedMs -= (6.5 + act.speedMs * 0.09) * simDt;
          }

          if (handbrake) {
            act.speedMs -= 18 * simDt;
          }
          act.speedMs = THREE.MathUtils.clamp(act.speedMs, 0, effectiveMaxSpeed);
          act.isBraking = brake > 0 || handbrake;

          // Steering & Drift Kinematics
          const speedFactor = THREE.MathUtils.clamp(act.speedMs / 18, 0, 1);
          const targetSteer = steerInput * 0.48 * handlingMult;
          act.steerAngle = THREE.MathUtils.damp(act.steerAngle, targetSteer, 12, simDt);

          const lateralSpeed = act.steerAngle * Math.min(act.speedMs, 52) * 0.46;
          act.lateralOffset += lateralSpeed * simDt;

          const targetDrift =
            handbrake && Math.abs(steerInput) > 0.1 && act.speedMs > 18
              ? -steerInput * 0.34
              : -act.steerAngle * speedFactor * 0.18;
          act.driftAngle = THREE.MathUtils.damp(act.driftAngle, targetDrift, 8, simDt);

          if (isP1) {
            const isDrifting = Math.abs(act.driftAngle) > 0.13 && act.speedMs > 12;
            if (isRacingActive && isDrifting) {
              p1ContinuousDriftTime += simDt;
              if (p1ContinuousDriftTime > p1MaxDriftTime) {
                p1MaxDriftTime = p1ContinuousDriftTime;
              }
            } else if (isRacingActive) {
              p1ContinuousDriftTime = 0;
            }
          }

          // Off-track curb rumble & guardrail containment
          if (Math.abs(act.lateralOffset) > halfTrackW) {
            act.lateralOffset = Math.sign(act.lateralOffset) * halfTrackW;
            act.speedMs *= Math.pow(0.86, simDt * 10);
            if (isP1 && act.speedMs > 25 && cameraShakeIntensity < 0.15) {
              cameraShakeIntensity = 0.22;
              soundEngine.playCollisionImpact(0.5);
            }
          }

          // Check Nitro Boost Pads on Track
          if (isRacingActive) {
            for (const pad of currentTrack.boostPads) {
              const dtPad = Math.abs(act.trackT - pad.t);
              if (dtPad < 0.012 && Math.abs(act.lateralOffset - pad.lateral) < 2.2) {
                act.nitroAmount = Math.min(100, act.nitroAmount + 35 * simDt);
                act.speedMs = Math.min(effectiveMaxSpeed * 1.12, act.speedMs + 18 * simDt);
              }
            }
          }

          // Advance spline parameter t
          if (isRacingActive) {
            const stepMeters = act.speedMs * simDt;
            if (isP1 && !act.finished) {
              p1SessionDistanceMeters += stepMeters;
            }
            const deltaT = stepMeters / trackLen;
            const prevT = act.trackT;
            act.trackT += deltaT;

            if (act.trackT >= 1.0) {
              act.trackT -= 1.0;
              if (prevT > 0.7) {
                if (isP1) {
                  const lapTime = now - lastLapStartTimestamp;
                  lastLapStartTimestamp = now;
                  if (bestLapMs === null || lapTime < bestLapMs) {
                    bestLapMs = lapTime;
                  }
                }
                const targetLaps = st.customLaps || currentLevel.laps;
                if (act.lap >= targetLaps) {
                  act.finished = true;
                  act.finishTimeMs = now - raceStartTimestamp;
                  if (isP1) {
                    soundEngine.playLapChime(true);
                    // Compute rank
                    const finishedBefore = Array.from(actors.values()).filter(
                      (other) => other.participant.id !== id && other.finished
                    ).length;
                    const replayDur =
                      recordedBuffer.length >= 2
                        ? Math.min(
                            30,
                            (recordedBuffer[recordedBuffer.length - 1].timestamp -
                              recordedBuffer[0].timestamp) /
                              1000
                          )
                        : 30;
                    st.onReplayReady?.(Math.max(1, replayDur));
                    st.onRaceFinished(
                      finishedBefore === 0 ? st.localPlayerName : 'Rival Driver',
                      finishedBefore + 1,
                      act.finishTimeMs,
                      Math.round(p1SessionDistanceMeters),
                      bestLapMs
                    );
                  }
                } else {
                  act.lap += 1;
                  if (isP1) soundEngine.playLapChime(false);
                }
              }
            }
          }

          // Position & Orient 3D Car Rig on Spline
          sampleTrackFrame(currentTrack.curve, act.trackT, _pos, _tan, _right);
          act.worldPos.copy(_pos).addScaledVector(_right, act.lateralOffset);
          act.rig.root.position.copy(act.worldPos);

          const baseHeading = Math.atan2(-_tan.x, -_tan.z);
          act.heading = baseHeading + act.driftAngle;
          act.rig.root.rotation.set(0, act.heading, 0);

          // Chassis suspension pitch & cornering roll
          const targetPitch = throttle > 0 ? -0.018 : brake > 0 ? 0.025 : 0;
          const targetRoll = act.steerAngle * speedFactor * 0.09;
          act.rig.chassisGroup.rotation.x = THREE.MathUtils.damp(
            act.rig.chassisGroup.rotation.x,
            targetPitch,
            10,
            simDt
          );
          act.rig.chassisGroup.rotation.z = THREE.MathUtils.damp(
            act.rig.chassisGroup.rotation.z,
            targetRoll,
            10,
            simDt
          );

          // Front wheel steering & 4-wheel rotation
          act.rig.wheelFL.rotation.y = -act.steerAngle * 0.85;
          act.rig.wheelFR.rotation.y = -act.steerAngle * 0.85;
          const spinDelta = (act.speedMs * simDt) / 0.35;
          act.rig.wheelSpinners.forEach((s) => {
            s.rotation.x -= spinDelta;
          });

          // Dynamic Brake Lights & Nitro Exhaust Flames
          act.rig.brakeLightMaterial.emissiveIntensity = act.isBraking ? 4.8 : 1.4;
          act.rig.nitroFlameLeft.visible = act.isNitro;
          act.rig.nitroFlameRight.visible = act.isNitro;
          if (act.isNitro) {
            const flameScale = 0.85 + Math.random() * 0.45;
            act.rig.nitroFlameLeft.scale.set(1, 1, flameScale);
            act.rig.nitroFlameRight.scale.set(1, 1, flameScale);
            spawnParticle(
              act.worldPos.x + (Math.random() - 0.5) * 0.6,
              act.worldPos.y + 0.35,
              act.worldPos.z + (Math.random() - 0.5) * 0.6,
              (Math.random() - 0.5) * 2,
              0.8 + Math.random() * 1.2,
              (Math.random() - 0.5) * 2,
              0.9,
              0.28
            );
          } else if (Math.abs(act.driftAngle) > 0.14 && act.speedMs > 16) {
            spawnParticle(
              act.worldPos.x + (Math.random() - 0.5) * 1.1,
              act.worldPos.y + 0.15,
              act.worldPos.z + (Math.random() - 0.5) * 1.1,
              (Math.random() - 0.5) * 1.5,
              0.5 + Math.random() * 0.8,
              (Math.random() - 0.5) * 1.5,
              1.15,
              0.38
            );
          }
        }

        // 30-Second Rolling Telemetry Recording Buffer for Cinematic Replay
        if (isRacingActive && now - lastRecordTime >= 33) {
          lastRecordTime = now;
          const snapshotActors: ReplayActorFrame[] = [];
          for (const a of actors.values()) {
            snapshotActors.push({
              id: a.participant.id,
              x: a.worldPos.x,
              y: a.worldPos.y,
              z: a.worldPos.z,
              heading: a.heading,
              pitch: a.rig.chassisGroup.rotation.x,
              roll: a.rig.chassisGroup.rotation.z,
              steerAngle: a.steerAngle,
              driftAngle: a.driftAngle,
              speedKmh: a.speedMs * 3.6,
              isBraking: a.isBraking,
              isNitro: a.isNitro,
              lap: a.lap,
              trackT: a.trackT,
              lateralOffset: a.lateralOffset,
            });
          }
          recordedBuffer.push({
            timestamp: now,
            actors: snapshotActors,
          });
          while (recordedBuffer.length > 1 && now - recordedBuffer[0].timestamp > 30000) {
            recordedBuffer.shift();
          }
        }

        // Pairwise Car-to-Car Bump Collision & Weight-Scaled Hitstop
        const actorList = Array.from(actors.values());
        for (let i = 0; i < actorList.length; i++) {
          for (let j = i + 1; j < actorList.length; j++) {
            const a = actorList[i];
            const b = actorList[j];
            const distSq = a.worldPos.distanceToSquared(b.worldPos);
            if (distSq < 6.2 && distSq > 0.001) {
              const push = a.lateralOffset >= b.lateralOffset ? 1.4 : -1.4;
              a.lateralOffset += push * simDt * 8;
              b.lateralOffset -= push * simDt * 8;

              if (
                a.participant.controlType === 'local-p1' ||
                b.participant.controlType === 'local-p1'
              ) {
                if (hitstopTimer <= 0) {
                  hitstopTimer = 0.045; // 45ms simulation hitstop
                  cameraShakeIntensity = 0.35;
                  soundEngine.playCollisionImpact(0.95);
                }
              }
            }
          }
        }

        // Position Remote WebSocket Peers smoothly on the spline
        for (const peer of remoteActors.values()) {
          sampleTrackFrame(currentTrack.curve, peer.trackProgress, _pos, _tan, _right);
          _pos.addScaledVector(_right, peer.lateralOffset);
          peer.rig.root.position.lerp(_pos, 0.25);
          const peerHeading = Math.atan2(-_tan.x, -_tan.z);
          peer.rig.root.rotation.y = peerHeading;
        }
        }
      }

      // Advance Pooled Instanced Particles
      for (let i = 0; i < maxParticles; i++) {
        const p = particles[i];
        if (p.active) {
          p.life += dt;
          if (p.life >= p.maxLife) {
            p.active = false;
            _particleDummy.position.set(0, -200, 0);
            _particleDummy.scale.setScalar(0.001);
          } else {
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;
            const progress = 1 - p.life / p.maxLife;
            _particleDummy.position.set(p.x, p.y, p.z);
            _particleDummy.scale.setScalar(p.scale * progress);
          }
        } else {
          _particleDummy.position.set(0, -200, 0);
          _particleDummy.scale.setScalar(0.001);
        }
        _particleDummy.updateMatrix();
        particleMesh.setMatrixAt(i, _particleDummy.matrix);
      }
      particleMesh.instanceMatrix.needsUpdate = true;

      // Camera Choreography & Speed-Scaled FOV
      if (p1Actor && currentTrack) {
        const carPos = p1Actor.worldPos;
        const speedKmh = p1Actor.speedMs * 3.6;

        // Keep directional shadow frustum centered on player car
        keyLight.position.set(carPos.x + 50, carPos.y + 85, carPos.z + 40);
        keyLight.target.position.copy(carPos);

        if (st.gamePhase === 'replay') {
          const repState = st.replayState;
          const replayAngle = repState?.cameraAngle || 'broadcast';
          const repSpeed = repState?.playbackSpeed ?? 1.0;
          const forwardX = -Math.sin(p1Actor.heading);
          const forwardZ = -Math.cos(p1Actor.heading);
          const rightX = forwardZ;
          const rightZ = -forwardX;

          if (replayAngle === 'broadcast') {
            // Trackside Broadcast Tower (Telephoto zoom 34 FOV)
            sampleTrackFrame(currentTrack.curve, (p1Actor.trackT + 0.055) % 1.0, _pos, _tan, _right);
            _pos.addScaledVector(_right, 13.5);
            _pos.y += 9.0;
            camera.position.lerp(_pos, 1 - Math.exp(-6 * dt));
            _camLookAt.set(carPos.x, carPos.y + 0.65, carPos.z);
            camera.lookAt(_camLookAt);
            camera.fov = THREE.MathUtils.damp(camera.fov, 34, 6, dt);
            camera.updateProjectionMatrix();
          } else if (replayAngle === 'drone') {
            // Aerial Sweeping Chase Drone
            const droneSway = Math.sin(now * 0.0007) * 7.5;
            _camTargetPos.set(
              carPos.x - forwardX * 13 + rightX * droneSway,
              carPos.y + 7.8,
              carPos.z - forwardZ * 13 + rightZ * droneSway
            );
            camera.position.lerp(_camTargetPos, 1 - Math.exp(-7 * dt));
            _camLookAt.set(carPos.x + forwardX * 4, carPos.y + 0.5, carPos.z + forwardZ * 4);
            camera.lookAt(_camLookAt);
            camera.fov = THREE.MathUtils.damp(camera.fov, 56, 6, dt);
            camera.updateProjectionMatrix();
          } else if (replayAngle === 'bumper') {
            // Ultra-Low Splitter Camera
            camera.position.set(
              carPos.x + forwardX * 1.9,
              carPos.y + 0.38,
              carPos.z + forwardZ * 1.9
            );
            _camLookAt.set(
              carPos.x + forwardX * 32,
              carPos.y + 0.35,
              carPos.z + forwardZ * 32
            );
            camera.lookAt(_camLookAt);
            camera.fov = THREE.MathUtils.damp(camera.fov, 74, 8, dt);
            camera.updateProjectionMatrix();
          } else if (replayAngle === 'orbit') {
            // 360 Continuous Smooth Arc / Dolly
            showroomOrbitAngle += dt * 0.55 * repSpeed;
            const orbitDist = 7.0;
            _camTargetPos.set(
              carPos.x + Math.sin(showroomOrbitAngle) * orbitDist,
              carPos.y + 2.1,
              carPos.z + Math.cos(showroomOrbitAngle) * orbitDist
            );
            camera.position.lerp(_camTargetPos, 1 - Math.exp(-9 * dt));
            _camLookAt.set(carPos.x, carPos.y + 0.7, carPos.z);
            camera.lookAt(_camLookAt);
            camera.fov = THREE.MathUtils.damp(camera.fov, 52, 6, dt);
            camera.updateProjectionMatrix();
          } else if (replayAngle === 'wheel') {
            // Front Right Wheel Cam
            camera.position.set(
              carPos.x + rightX * 1.25 + forwardX * 0.3,
              carPos.y + 0.5,
              carPos.z + rightZ * 1.25 + forwardZ * 0.3
            );
            _camLookAt.set(
              carPos.x + forwardX * 9 + rightX * 0.35,
              carPos.y + 0.35,
              carPos.z + forwardZ * 9 + rightZ * 0.35
            );
            camera.lookAt(_camLookAt);
            camera.fov = THREE.MathUtils.damp(camera.fov, 65, 8, dt);
            camera.updateProjectionMatrix();
          }
        } else if (st.gamePhase === 'title' || st.cameraMode === 'orbit') {
          let camAngle: number;
          let radius: number;
          let camHeight: number;
          let targetFov: number;

          if (st.gamePhase === 'title' && st.cameraMode !== 'orbit') {
            // Iconic 38° Front-Left 3/4 Telephoto Motorsport Framing (Matches McLaren 720S LMGT3 Evo reference photo!)
            camAngle = p1Actor.heading + Math.PI - 0.64 + Math.sin(now * 0.0004) * 0.14;
            radius = 6.8;
            camHeight = 1.24;
            targetFov = 36;
          } else {
            showroomOrbitAngle += dt * 0.42;
            camAngle = showroomOrbitAngle;
            radius = 6.2;
            camHeight = 1.65;
            targetFov = 46;
          }

          _camTargetPos.set(
            carPos.x + Math.sin(camAngle) * radius,
            carPos.y + camHeight,
            carPos.z + Math.cos(camAngle) * radius
          );
          camera.position.lerp(_camTargetPos, 1 - Math.exp(-8 * dt));
          _camLookAt.set(carPos.x, carPos.y + 0.36, carPos.z);
          camera.lookAt(_camLookAt);
          camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 6, dt);
          camera.updateProjectionMatrix();
        } else if (st.cameraMode === 'cockpit') {
          const forwardX = -Math.sin(p1Actor.heading);
          const forwardZ = -Math.cos(p1Actor.heading);
          camera.position.set(
            carPos.x + forwardX * 0.35,
            carPos.y + 1.08,
            carPos.z + forwardZ * 0.35
          );
          _camLookAt.set(
            carPos.x + forwardX * 30,
            carPos.y + 0.9,
            carPos.z + forwardZ * 30
          );
          camera.lookAt(_camLookAt);
          const targetFov = 68 + (speedKmh / 360) * 18 + (p1Actor.isNitro ? 8 : 0);
          camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 8, dt);
          camera.updateProjectionMatrix();
        } else if (st.cameraMode === 'overhead') {
          const forwardX = -Math.sin(p1Actor.heading);
          const forwardZ = -Math.cos(p1Actor.heading);
          _camTargetPos.set(
            carPos.x - forwardX * 14,
            carPos.y + 24,
            carPos.z - forwardZ * 14
          );
          camera.position.lerp(_camTargetPos, 1 - Math.exp(-9 * dt));
          _camLookAt.set(
            carPos.x + forwardX * 8,
            carPos.y + 0.5,
            carPos.z + forwardZ * 8
          );
          camera.lookAt(_camLookAt);
          camera.fov = THREE.MathUtils.damp(camera.fov, 58, 6, dt);
          camera.updateProjectionMatrix();
        } else {
          // Third-Person Chase Camera with Exponential Damping, Shake & FOV Widening
          const forwardX = -Math.sin(p1Actor.heading);
          const forwardZ = -Math.cos(p1Actor.heading);
          const chaseDist = 6.6 + (speedKmh / 400) * 1.1;
          const chaseHeight = 2.35;

          _camTargetPos.set(
            carPos.x - forwardX * chaseDist,
            carPos.y + chaseHeight,
            carPos.z - forwardZ * chaseDist
          );

          if (cameraShakeIntensity > 0.005) {
            _camTargetPos.x += (Math.random() - 0.5) * cameraShakeIntensity;
            _camTargetPos.y += (Math.random() - 0.5) * cameraShakeIntensity * 0.7;
            cameraShakeIntensity = THREE.MathUtils.damp(cameraShakeIntensity, 0, 10, dt);
          }

          camera.position.lerp(_camTargetPos, 1 - Math.exp(-11 * dt));
          _camLookAt.set(
            carPos.x + forwardX * 6.5,
            carPos.y + 0.85,
            carPos.z + forwardZ * 6.5
          );
          camera.lookAt(_camLookAt);

          const targetFov = 60 + (speedKmh / 360) * 16 + (p1Actor.isNitro ? 7 : 0);
          camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 7, dt);
          camera.updateProjectionMatrix();
        }

        // Update Web Audio Synthesizer
        const speedNorm = Math.min(1, speedKmh / p1Spec.topSpeedKmh);
        const gear = Math.min(7, Math.max(1, Math.floor(speedNorm * 7) + 1));
        const gearSpan = 1 / 7;
        const inGearProgress = (speedNorm % gearSpan) / gearSpan;
        const rpm =
          speedKmh < 3
            ? 1100 + Math.sin(now * 0.01) * 60
            : Math.round(2800 + inGearProgress * 6100);

        soundEngine.updateTelemetry(
          speedKmh,
          rpm,
          gear,
          Math.abs(p1Actor.driftAngle) > 0.13,
          p1Actor.isNitro,
          st.gamePhase === 'playing'
        );

        // Emit WebSocket state update at ~15Hz when in multiplayer mode
        if (
          st.networkMode === 'multiplayer' &&
          ws &&
          ws.readyState === WebSocket.OPEN &&
          now - lastWsEmitTime > 65
        ) {
          lastWsEmitTime = now;
          ws.send(
            JSON.stringify({
              type: 'player:update',
              name: st.localPlayerName,
              carId: st.customization.carId,
              paintHex: st.customization.paintHex,
              finishType: st.customization.finishType,
              rimHex: st.customization.rimHex,
              caliperHex: st.customization.caliperHex,
              aeroPreset: st.customization.aeroPreset,
              trackProgress: p1Actor.trackT,
              lap: p1Actor.lap,
              lateralOffset: p1Actor.lateralOffset,
              speedKmh,
              worldX: carPos.x,
              worldY: carPos.y,
              worldZ: carPos.z,
              heading: p1Actor.heading,
              driftAngle: p1Actor.driftAngle,
              isBraking: p1Actor.isBraking,
              isNitro: p1Actor.isNitro,
              finished: p1Actor.finished,
              finishTimeMs: p1Actor.finishTimeMs,
            })
          );
        }

        // Throttle React HUD Telemetry state updates to ~15Hz so React never stalls 60fps loop
        if (now - lastHudUpdateTime > 66) {
          lastHudUpdateTime = now;

          const allEntries = [
            ...Array.from(actors.values()).map((a) => ({
              id: a.participant.id,
              name:
                a.participant.controlType === 'local-p1'
                  ? st.localPlayerName
                  : a.participant.name,
              controlType: a.participant.controlType,
              lap: a.lap,
              progress: a.lap + a.trackT,
              speedKmh: Math.round(a.speedMs * 3.6),
              finished: a.finished,
              finishTimeMs: a.finishTimeMs,
              paintHex:
                a.participant.controlType === 'local-p1'
                  ? st.customization.paintHex
                  : a.participant.paintHex,
            })),
            ...Array.from(remoteActors.values()).map((r) => ({
              id: r.id,
              name: `${r.name} (Online)`,
              controlType: 'remote-peer' as const,
              lap: r.lap,
              progress: r.lap + r.trackProgress,
              speedKmh: Math.round(r.speedKmh),
              finished: false,
              finishTimeMs: null,
              paintHex: r.paintHex,
            })),
          ];

          allEntries.sort((a, b) => b.progress - a.progress);
          const p1Rank = Math.max(
            1,
            allEntries.findIndex((e) => e.id === 'local-p1') + 1
          );
          const p2Act = actors.get('local-p2');
          const p2Rank = p2Act
            ? allEntries.findIndex((e) => e.id === 'local-p2') + 1
            : undefined;

          st.onTelemetryUpdate({
            speedKmh: Math.round(speedKmh),
            rpm,
            gear,
            nitroAmount: Math.round(p1Actor.nitroAmount),
            isDrifting: Math.abs(p1Actor.driftAngle) > 0.13 && speedKmh > 45,
            isNitroActive: p1Actor.isNitro,
            lap: p1Actor.lap,
            totalLaps: st.customLaps || currentLevel.laps,
            position: p1Rank,
            totalRacers: allEntries.length,
            elapsedMs: st.gamePhase === 'playing' ? now - raceStartTimestamp : 0,
            bestLapMs,
            trackProgress: p1Actor.trackT,
            sessionDistanceMeters: Math.round(p1SessionDistanceMeters),
            driftDurationSeconds: Number(p1ContinuousDriftTime.toFixed(1)),
            maxDriftSeconds: Number(p1MaxDriftTime.toFixed(1)),
            p2SpeedKmh: p2Act ? Math.round(p2Act.speedMs * 3.6) : undefined,
            p2Position: p2Rank,
            standings: allEntries,
          });
        }
      }

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    frameId = requestAnimationFrame(tick);

    return () => {
      isDisposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      if (wsReconnectTimer) clearTimeout(wsReconnectTimer);
      if (ws) {
        ws.onclose = null;
        ws.close();
      }
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onWindowBlur);
      window.removeEventListener('resize', onResize);
      if (currentTrack) currentTrack.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={canvasMountRef}
      className="fixed inset-0 w-screen h-screen overflow-hidden z-0"
      aria-label="3D Hypercar Racing Viewport"
    />
  );
};
