import React, { useState } from 'react';
import { BannerFormat, AdCreativeData, ImageModel, ImageSize, AspectRatio } from '../types';
import { BANNER_FORMATS } from '../data/bannerFormats';
import { BannerDisplayCard } from './BannerDisplayCard';
import { RenderOptions, renderBannerToCanvas, downloadCanvasAsPng } from '../utils/canvasRenderer';
import {
  Sparkles,
  Sliders,
  Image as ImageIcon,
  Palette,
  Download,
  Layers,
  RefreshCw,
  Edit3,
  CheckCircle2,
  AlertCircle,
  Code2,
  Maximize2,
} from 'lucide-react';

interface BannerStudioProps {
  creative: AdCreativeData;
  onUpdateCreative: (updated: AdCreativeData) => void;
  onRegenerateImage: (params: {
    model: ImageModel;
    imageSize: ImageSize;
    aspectRatio: AspectRatio;
    prompt: string;
  }) => Promise<void>;
  isGeneratingImage: boolean;
}

export const BannerStudio: React.FC<BannerStudioProps> = ({
  creative,
  onUpdateCreative,
  onRegenerateImage,
  isGeneratingImage,
}) => {
  // Model, Size, and Aspect Ratio Affordances (MANDATORY per feature blocks)
  const [selectedModel, setSelectedModel] = useState<ImageModel>('gemini-3-pro-image-preview');
  const [selectedSize, setSelectedSize] = useState<ImageSize>('2K');
  const [selectedAspect, setSelectedAspect] = useState<AspectRatio>('1:1');
  const [customPrompt, setCustomPrompt] = useState(creative.imagePrompt || '');
  const [activeTab, setActiveTab] = useState<'all' | 'iab' | 'high-impact' | 'mobile' | 'social'>('all');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [inspectFormat, setInspectFormat] = useState<BannerFormat | null>(null);
  const [batchDownloading, setBatchDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<{ current: number; total: number } | null>(null);

  const renderOptions: RenderOptions = {
    pixelRatio: 2,
    bgTheme: 'dark',
    fontFamily: 'sans',
  };

  const filteredFormats = BANNER_FORMATS.filter((f) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'iab') return f.category === 'IAB Standard';
    if (activeTab === 'high-impact') return f.category === 'High Impact';
    if (activeTab === 'mobile') return f.category === 'Mobile';
    if (activeTab === 'social') return f.category === 'Social';
    return true;
  });

  const handleTriggerRegenerate = async () => {
    await onRegenerateImage({
      model: selectedModel,
      imageSize: selectedSize,
      aspectRatio: selectedAspect,
      prompt: customPrompt,
    });
  };

  const handleBatchDownloadAll = async () => {
    try {
      setBatchDownloading(true);
      const total = BANNER_FORMATS.length;
      for (let i = 0; i < total; i++) {
        setDownloadProgress({ current: i + 1, total });
        const format = BANNER_FORMATS[i];
        const canvas = await renderBannerToCanvas(format, creative, renderOptions);
        const filename = `${creative.brandName.toLowerCase().replace(/\s+/g, '-')}-${format.width}x${format.height}-retina.png`;
        downloadCanvasAsPng(canvas, filename);
        // Short pause to give browser download queue room
        await new Promise((r) => setTimeout(r, 250));
      }
    } catch (err) {
      console.error('Batch download failed:', err);
    } finally {
      setBatchDownloading(false);
      setDownloadProgress(null);
    }
  };

  const colorPresets = [
    { name: 'Amber Gold', hex: '#D97706' },
    { name: 'Royal Blue', hex: '#2563EB' },
    { name: 'Emerald', hex: '#059669' },
    { name: 'Crimson', hex: '#E11D48' },
    { name: 'Sunset Orange', hex: '#EA580C' },
    { name: 'Electric Cyan', hex: '#0284C7' },
    { name: 'Violet Luxe', hex: '#7C3AED' },
    { name: 'Dark Slate', hex: '#334155' },
  ];

  return (
    <div className="w-full space-y-6">
      {/* Top Controls Bar: Generation Specs, Model, Image Size, Aspect Ratio */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl backdrop-blur-md">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-blue-400" />
                Banner Ad Creative Suite
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 text-xs font-semibold border border-blue-500/20">
                10 Standard Sizes Generated
              </span>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              Active Brand: <span className="text-white font-medium">{creative.brandName}</span> • 
              Offer: <span className="text-amber-400 font-medium">{creative.offerBadge || 'Active'}</span>
            </p>
          </div>

          {/* Batch Download Action Button */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              id="btn-batch-download"
              onClick={handleBatchDownloadAll}
              disabled={batchDownloading}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-lg shadow-blue-500/25 flex items-center gap-2 transition-all active:scale-95 disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              {batchDownloading
                ? `Downloading (${downloadProgress?.current}/${downloadProgress?.total})...`
                : 'Download All Sizes (.PNG)'}
            </button>
            <button
              id="btn-toggle-editor"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-sm border border-slate-700 flex items-center gap-2 transition-colors"
            >
              <Sliders className="w-4 h-4 text-slate-400" />
              <span>{sidebarOpen ? 'Close Controls' : 'Customize Creative'}</span>
            </button>
          </div>
        </div>

        {/* Studio Image Generation Settings & Affordances */}
        <div className="pt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* 1. Model Selector Affordance */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                Image Model
              </span>
              <span className="text-[10px] text-emerald-400 font-normal">Nano Banana Pro</span>
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                id="model-select-pro"
                type="button"
                onClick={() => setSelectedModel('gemini-3-pro-image-preview')}
                className={`px-3 py-2 rounded-lg text-xs font-medium transition-all text-left flex flex-col ${
                  selectedModel === 'gemini-3-pro-image-preview'
                    ? 'bg-blue-600 text-white shadow-md border border-blue-400/30'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <span className="font-bold">Gemini 3 Pro</span>
                <span className="text-[10px] opacity-80">Studio Quality</span>
              </button>
              <button
                id="model-select-flash"
                type="button"
                onClick={() => setSelectedModel('gemini-3.1-flash-image-preview')}
                className={`px-3 py-2 rounded-lg text-xs font-medium transition-all text-left flex flex-col ${
                  selectedModel === 'gemini-3.1-flash-image-preview'
                    ? 'bg-blue-600 text-white shadow-md border border-blue-400/30'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <span className="font-bold">Gemini 3.1 Flash</span>
                <span className="text-[10px] opacity-80">Fast Iteration</span>
              </button>
            </div>
          </div>

          {/* 2. Image Size Affordance (1K, 2K, 4K) */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
                Image Resolution (Size)
              </span>
              <span className="text-[10px] text-slate-400">Crisp Export</span>
            </label>
            <div className="grid grid-cols-3 gap-1.5">
              {(['1K', '2K', '4K'] as ImageSize[]).map((size) => (
                <button
                  key={size}
                  id={`size-select-${size}`}
                  type="button"
                  onClick={() => setSelectedSize(size)}
                  className={`py-2 px-2 rounded-lg text-xs font-semibold text-center transition-all ${
                    selectedSize === size
                      ? 'bg-indigo-600 text-white shadow-md border border-indigo-400/30'
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* 3. Aspect Ratio Affordance */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Maximize2 className="w-3.5 h-3.5 text-amber-400" />
                Aspect Ratio
              </span>
              <span className="text-[10px] text-slate-400">8 Supported</span>
            </label>
            <div className="grid grid-cols-4 gap-1">
              {(['1:1', '2:3', '3:2', '3:4', '4:3', '9:16', '16:9', '21:9'] as AspectRatio[]).map((ar) => (
                <button
                  key={ar}
                  id={`aspect-select-${ar.replace(':', '-')}`}
                  type="button"
                  onClick={() => setSelectedAspect(ar)}
                  className={`py-1.5 px-1 rounded text-[11px] font-mono font-medium text-center transition-all ${
                    selectedAspect === ar
                      ? 'bg-amber-600 text-white shadow-sm border border-amber-400/40 font-bold'
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800/80'
                  }`}
                >
                  {ar}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Prompt & Regenerate Row */}
        <div className="mt-4 pt-4 border-t border-slate-800 flex flex-col md:flex-row items-center gap-3">
          <div className="relative w-full flex-1">
            <input
              id="input-custom-prompt"
              type="text"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder="Commercial product art direction prompt for Gemini..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 rounded-xl px-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
          <button
            id="btn-regenerate-image"
            onClick={handleTriggerRegenerate}
            disabled={isGeneratingImage}
            className="w-full md:w-auto px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-blue-400 hover:text-blue-300 border border-blue-500/30 text-xs font-semibold flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50 whitespace-nowrap"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingImage ? 'animate-spin' : ''}`} />
            <span>{isGeneratingImage ? 'Generating Image...' : 'Regenerate Hero Image'}</span>
          </button>
        </div>
      </div>

      {/* Slide-out Customization Drawer / Inline Editor */}
      {sidebarOpen && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-200 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Edit3 className="w-4 h-4 text-blue-400" />
              Creative & Brand Adjuster
            </h3>
            <span className="text-xs text-slate-400">Updates live across all 10 banner formats</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Brand Colors */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Primary Brand Accent
              </label>
              <div className="flex items-center gap-2 mb-2">
                <input
                  type="color"
                  value={creative.primaryColor}
                  onChange={(e) =>
                    onUpdateCreative({
                      ...creative,
                      primaryColor: e.target.value,
                    })
                  }
                  className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                />
                <input
                  type="text"
                  value={creative.primaryColor}
                  onChange={(e) =>
                    onUpdateCreative({
                      ...creative,
                      primaryColor: e.target.value,
                    })
                  }
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-200"
                />
              </div>
              <div className="flex flex-wrap gap-1.5">
                {colorPresets.map((c) => (
                  <button
                    key={c.hex}
                    type="button"
                    onClick={() => onUpdateCreative({ ...creative, primaryColor: c.hex })}
                    title={c.name}
                    style={{ backgroundColor: c.hex }}
                    className={`w-5 h-5 rounded-full border border-white/20 transition-transform ${
                      creative.primaryColor === c.hex ? 'scale-110 ring-2 ring-white ring-offset-1 ring-offset-slate-900' : ''
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Brand Name & Badge */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Brand Name
                </label>
                <input
                  type="text"
                  value={creative.brandName}
                  onChange={(e) => onUpdateCreative({ ...creative, brandName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Offer / Promo Badge
                </label>
                <input
                  type="text"
                  value={creative.offerBadge}
                  onChange={(e) => onUpdateCreative({ ...creative, offerBadge: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {/* Headlines */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Primary Headline
                </label>
                <input
                  type="text"
                  value={creative.primaryHeadline}
                  onChange={(e) =>
                    onUpdateCreative({
                      ...creative,
                      primaryHeadline: e.target.value,
                    })
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Subheadline / USP
                </label>
                <input
                  type="text"
                  value={creative.subheadline}
                  onChange={(e) =>
                    onUpdateCreative({
                      ...creative,
                      subheadline: e.target.value,
                    })
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {/* CTA Button & Target URL */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  CTA Button Text
                </label>
                <input
                  type="text"
                  value={creative.ctaText}
                  onChange={(e) => onUpdateCreative({ ...creative, ctaText: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Landing Page URL
                </label>
                <input
                  type="text"
                  value={creative.productUrl || ''}
                  onChange={(e) => onUpdateCreative({ ...creative, productUrl: e.target.value })}
                  placeholder="https://..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Category Filter Tabs */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1 rounded-xl">
          {[
            { id: 'all', label: 'All Formats (10)' },
            { id: 'iab', label: 'IAB Standard' },
            { id: 'high-impact', label: 'High Impact' },
            { id: 'mobile', label: 'Mobile' },
            { id: 'social', label: 'Social & Stories' },
          ].map((tab) => (
            <button
              key={tab.id}
              id={`tab-filter-${tab.id}`}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-md font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="text-xs text-slate-500 font-mono">
          Showing {filteredFormats.length} of {BANNER_FORMATS.length} formats
        </div>
      </div>

      {/* Grid of Standard Banner Ads */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredFormats.map((format) => (
          <BannerDisplayCard
            key={format.id}
            format={format}
            creative={creative}
            options={renderOptions}
            onFocus={(f) => setInspectFormat(f)}
          />
        ))}
      </div>

      {/* Single Format Inspector Modal */}
      {inspectFormat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-lg font-bold text-white">{inspectFormat.name}</h3>
                <span className="text-xs text-slate-400">
                  {inspectFormat.width} × {inspectFormat.height} px • {inspectFormat.category}
                </span>
              </div>
              <button
                onClick={() => setInspectFormat(null)}
                className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg bg-slate-800 text-sm"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300">{inspectFormat.description}</p>

            <div className="p-4 bg-slate-950 rounded-xl flex items-center justify-center overflow-auto max-h-[420px]">
              <div
                style={{
                  width: `${inspectFormat.width}px`,
                  height: `${inspectFormat.height}px`,
                }}
                className="relative overflow-hidden select-none shadow-2xl bg-slate-900 border border-white/10"
              >
                {creative.imageUrl && (
                  <img
                    src={creative.imageUrl}
                    alt={creative.brandName}
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 w-full h-full object-cover opacity-75"
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-slate-950/20" />
                <div className="relative z-10 w-full h-full p-4 flex flex-col justify-between">
                  <span
                    style={{ backgroundColor: creative.primaryColor }}
                    className="self-start px-2 py-0.5 rounded-full text-[10px] font-bold text-white uppercase"
                  >
                    {creative.offerBadge || 'PROMO'}
                  </span>
                  <div>
                    <h4 className="text-white font-bold text-sm leading-tight mb-1">
                      {creative.copyVariations[inspectFormat.shape]?.headline || creative.primaryHeadline}
                    </h4>
                    <p className="text-slate-300 text-xs mb-3 line-clamp-2">
                      {creative.copyVariations[inspectFormat.shape]?.subhead || creative.subheadline}
                    </p>
                    <button
                      style={{ backgroundColor: creative.primaryColor }}
                      className="px-4 py-1.5 rounded text-xs font-bold text-white shadow-md"
                    >
                      {creative.copyVariations[inspectFormat.shape]?.cta || creative.ctaText}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setInspectFormat(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium"
              >
                Close
              </button>
              <button
                onClick={async () => {
                  const canvas = await renderBannerToCanvas(inspectFormat, creative, renderOptions);
                  downloadCanvasAsPng(
                    canvas,
                    `${creative.brandName.toLowerCase()}-${inspectFormat.width}x${inspectFormat.height}.png`
                  );
                }}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Download PNG (Retina 2×)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
