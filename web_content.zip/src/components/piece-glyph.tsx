import bB from "@/assets/pieces/bB.svg?url";
import bK from "@/assets/pieces/bK.svg?url";
import bN from "@/assets/pieces/bN.svg?url";
import bP from "@/assets/pieces/bP.svg?url";
import bQ from "@/assets/pieces/bQ.svg?url";
import bR from "@/assets/pieces/bR.svg?url";
import wB from "@/assets/pieces/wB.svg?url";
import wK from "@/assets/pieces/wK.svg?url";
import wN from "@/assets/pieces/wN.svg?url";
import wP from "@/assets/pieces/wP.svg?url";
import wQ from "@/assets/pieces/wQ.svg?url";
import wR from "@/assets/pieces/wR.svg?url";
import type { BoardPiece } from "@/lib/chess/position";
import { cn } from "@/lib/cn";

const SRC: Record<string, string> = {
  bb: bB,
  bk: bK,
  bn: bN,
  bp: bP,
  bq: bQ,
  br: bR,
  wb: wB,
  wk: wK,
  wn: wN,
  wp: wP,
  wq: wQ,
  wr: wR,
};

export function pieceSrc(piece: BoardPiece) {
  return SRC[`${piece.color}${piece.type}`] ?? wP;
}

export function PieceGlyph({
  piece,
  className,
}: {
  piece: BoardPiece;
  className?: string;
}) {
  return (
    <img
      src={pieceSrc(piece)}
      alt=""
      draggable={false}
      className={cn("piece-shadow pointer-events-none size-full select-none", className)}
    />
  );
}
