import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ArrowLeft,
  Share2,
  Info,
  FolderInput,
  Trash2,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  RotateCcw,
} from 'lucide-react';
import { Foto, Carpeta } from '../types';
import {
  listarFotos,
  obtenerCarpeta,
  listarCarpetas,
  eliminarFoto,
  moverFoto,
  formatearBytes,
  formatearFecha,
} from '../db/storage';
import { ConfirmarDialog, MoverDialog, DetallesDialog } from './Dialogos';

interface VisorViewProps {
  carpetaId: string;
  fotoInicialId: string;
  onVolver: () => void;
}

export const VisorView: React.FC<VisorViewProps> = ({
  carpetaId,
  fotoInicialId,
  onVolver,
}) => {
  const [carpeta, setCarpeta] = useState<Carpeta | null>(null);
  const [todasLasCarpetas, setTodasLasCarpetas] = useState<Carpeta[]>([]);
  const [fotos, setFotos] = useState<Foto[]>([]);
  const [indiceActual, setIndiceActual] = useState(0);

  // Estados de Zoom y Pan Requerimiento 24
  const [escala, setEscala] = useState(1);
  const [posicion, setPosicion] = useState({ x: 0, y: 0 });
  const [arrastrando, setArrastrando] = useState(false);
  const inicioArrastre = useRef({ x: 0, y: 0 });

  // Modales Requerimientos 25, 26, 28
  const [mostrarDetalles, setMostrarDetalles] = useState(false);
  const [mostrarMover, setMostrarMover] = useState(false);
  const [mostrarEliminar, setMostrarEliminar] = useState(false);

  const contenedorRef = useRef<HTMLDivElement>(null);

  const cargarDatos = useCallback(async () => {
    try {
      const c = await obtenerCarpeta(carpetaId);
      if (c) setCarpeta(c);

      const todas = await listarCarpetas();
      setTodasLasCarpetas(todas);

      const lista = await listarFotos(carpetaId);
      setFotos(lista);

      const idx = lista.findIndex((f) => f.id === fotoInicialId);
      if (idx !== -1) {
        setIndiceActual(idx);
      } else if (lista.length === 0) {
        onVolver();
      }
    } catch (err) {
      console.error('Error al cargar datos del visor:', err);
    }
  }, [carpetaId, fotoInicialId, onVolver]);

  useEffect(() => {
    cargarDatos();
  }, [cargarDatos]);

  const fotoActual = fotos[indiceActual];

  // Restablecer zoom al cambiar de foto
  const resetZoom = () => {
    setEscala(1);
    setPosicion({ x: 0, y: 0 });
  };

  const irFotoAnterior = () => {
    if (indiceActual > 0) {
      resetZoom();
      setIndiceActual((i) => i - 1);
    }
  };

  const irFotoSiguiente = () => {
    if (indiceActual < fotos.length - 1) {
      resetZoom();
      setIndiceActual((i) => i + 1);
    }
  };

  // Teclado (flechas, escape)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') irFotoAnterior();
      if (e.key === 'ArrowRight') irFotoSiguiente();
      if (e.key === 'Escape') onVolver();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [indiceActual, fotos.length]);

  // Manejadores de Zoom (Rueda de ratón / Doble clic)
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY * -0.002;
    setEscala((prev) => {
      const nueva = Math.min(Math.max(1, prev + delta), 5);
      if (nueva === 1) setPosicion({ x: 0, y: 0 });
      return nueva;
    });
  };

  const handleDoubleClick = () => {
    if (escala > 1) {
      resetZoom();
    } else {
      setEscala(2.5);
    }
  };

  // Arrastre (Pan) cuando está en zoom
  const handleMouseDown = (e: React.MouseEvent) => {
    if (escala <= 1) return;
    setArrastrando(true);
    inicioArrastre.current = { x: e.clientX - posicion.x, y: e.clientY - posicion.y };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!arrastrando || escala <= 1) return;
    setPosicion({
      x: e.clientX - inicioArrastre.current.x,
      y: e.clientY - inicioArrastre.current.y,
    });
  };

  const handleMouseUp = () => setArrastrando(false);

  // Compartir Foto Requerimiento 27
  const handleCompartir = async () => {
    if (!fotoActual) return;
    try {
      // Convertir dataURL a archivo Blob
      const res = await fetch(fotoActual.dataUrl);
      const blob = await res.blob();
      const file = new File([blob], fotoActual.nombre, { type: 'image/jpeg' });

      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: `Foto ${carpeta?.nombre}`,
          text: `Registro de vehículo: ${carpeta?.nombre}`,
        });
      } else if (navigator.share) {
        await navigator.share({
          title: `Foto ${carpeta?.nombre}`,
          text: `Registro de vehículo: ${carpeta?.nombre}`,
          url: window.location.href,
        });
      } else {
        // Fallback: descargar foto
        const link = document.createElement('a');
        link.href = fotoActual.dataUrl;
        link.download = fotoActual.nombre;
        link.click();
      }
    } catch {
      // Ignorar cancelaciones del diálogo de compartir
    }
  };

  // Eliminar Foto Requerimiento 25
  const handleEliminarFoto = async () => {
    if (!fotoActual) return;
    try {
      await eliminarFoto(fotoActual.id);
      setMostrarEliminar(false);
      const actualizadas = await listarFotos(carpetaId);
      if (actualizadas.length === 0) {
        onVolver();
      } else {
        setFotos(actualizadas);
        setIndiceActual((i) => Math.min(i, actualizadas.length - 1));
        resetZoom();
      }
    } catch (err) {
      console.error('Error al eliminar foto:', err);
    }
  };

  // Mover Foto Requerimiento 26
  const handleMoverFoto = async (nuevaCarpetaId: string) => {
    if (!fotoActual) return;
    try {
      await moverFoto(fotoActual.id, nuevaCarpetaId);
      setMostrarMover(false);
      const actualizadas = await listarFotos(carpetaId);
      if (actualizadas.length === 0) {
        onVolver();
      } else {
        setFotos(actualizadas);
        setIndiceActual((i) => Math.min(i, actualizadas.length - 1));
        resetZoom();
      }
    } catch (err) {
      console.error('Error al mover foto:', err);
    }
  };

  if (!fotoActual) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black text-white flex flex-col justify-between select-none overflow-hidden">
      {/* TopAppBar Requerimiento 23 */}
      <header className="z-30 h-16 px-4 bg-gradient-to-b from-black/90 via-black/50 to-transparent flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onVolver}
            aria-label="Atrás"
            className="p-2 -ml-2 rounded-full hover:bg-white/10 active:scale-95 transition"
          >
            <ArrowLeft size={22} />
          </button>
          <div className="text-left">
            <span className="text-sm font-bold tracking-tight text-white">
              {indiceActual + 1} / {fotos.length}
            </span>
            <p className="text-[11px] text-slate-400 font-mono truncate max-w-[140px] sm:max-w-xs">
              {carpeta?.nombre}
            </p>
          </div>
        </div>

        {/* Acciones de la foto: Compartir, Detalles, Mover, Eliminar */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={handleCompartir}
            title="Compartir foto"
            className="p-2.5 rounded-full hover:bg-white/10 active:scale-95 transition text-white"
          >
            <Share2 size={20} />
          </button>

          <button
            onClick={() => setMostrarDetalles(true)}
            title="Ver detalles"
            className="p-2.5 rounded-full hover:bg-white/10 active:scale-95 transition text-white"
          >
            <Info size={20} />
          </button>

          <button
            onClick={() => setMostrarMover(true)}
            title="Mover a otra carpeta"
            className="p-2.5 rounded-full hover:bg-white/10 active:scale-95 transition text-white"
          >
            <FolderInput size={20} />
          </button>

          <button
            onClick={() => setMostrarEliminar(true)}
            title="Eliminar foto"
            className="p-2.5 rounded-full hover:bg-red-500/20 active:scale-95 transition text-red-400"
          >
            <Trash2 size={20} />
          </button>
        </div>
      </header>

      {/* Visor Central con Zoom y Paneo Requerimiento 24 */}
      <div
        ref={contenedorRef}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onDoubleClick={handleDoubleClick}
        className={`relative flex-1 flex items-center justify-center p-2 overflow-hidden ${
          escala > 1 ? (arrastrando ? 'cursor-grabbing' : 'cursor-grab') : 'cursor-default'
        }`}
      >
        <img
          src={fotoActual.dataUrl}
          alt={fotoActual.nombre}
          draggable={false}
          style={{
            transform: `translate(${posicion.x}px, ${posicion.y}px) scale(${escala})`,
            transition: arrastrando ? 'none' : 'transform 0.15s ease-out',
          }}
          className="max-w-full max-h-full object-contain pointer-events-auto"
        />

        {/* Flecha Anterior */}
        {indiceActual > 0 && escala === 1 && (
          <button
            onClick={irFotoAnterior}
            aria-label="Foto anterior"
            className="absolute left-3 p-3 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur-md text-white transition active:scale-90"
          >
            <ChevronLeft size={28} />
          </button>
        )}

        {/* Flecha Siguiente */}
        {indiceActual < fotos.length - 1 && escala === 1 && (
          <button
            onClick={irFotoSiguiente}
            aria-label="Foto siguiente"
            className="absolute right-3 p-3 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur-md text-white transition active:scale-90"
          >
            <ChevronRight size={28} />
          </button>
        )}
      </div>

      {/* Barra Inferior con controles de Zoom y fecha */}
      <footer className="z-30 h-16 px-4 bg-gradient-to-t from-black/90 via-black/50 to-transparent flex items-center justify-between">
        <div className="text-xs text-slate-400 font-mono">
          {formatearFecha(fotoActual.fecha)}
        </div>

        <div className="flex items-center gap-2 bg-slate-900/80 px-3 py-1.5 rounded-full border border-slate-800 backdrop-blur-md">
          <button
            onClick={() => setEscala((s) => Math.max(1, s - 0.5))}
            disabled={escala <= 1}
            className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-40"
          >
            <ZoomOut size={16} />
          </button>
          <span className="text-xs font-mono font-bold text-amber-400 min-w-[36px] text-center">
            {Math.round(escala * 100)}%
          </span>
          <button
            onClick={() => setEscala((s) => Math.min(5, s + 0.5))}
            disabled={escala >= 5}
            className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-40"
          >
            <ZoomIn size={16} />
          </button>
          {escala > 1 && (
            <button
              onClick={resetZoom}
              title="Restablecer zoom"
              className="p-1 rounded text-slate-400 hover:text-white border-l border-slate-700 pl-2"
            >
              <RotateCcw size={14} />
            </button>
          )}
        </div>
      </footer>

      {/* Diálogos */}
      {mostrarEliminar && (
        <ConfirmarDialog
          titulo="Eliminar foto"
          mensaje="¿Deseas eliminar esta foto definitivamente del vehículo?"
          textoOk="Eliminar"
          textoCancelar="Cancelar"
          esPeligroso={true}
          onOk={handleEliminarFoto}
          onCancelar={() => setMostrarEliminar(false)}
        />
      )}

      {mostrarMover && (
        <MoverDialog
          carpetaActualId={carpetaId}
          todasLasCarpetas={todasLasCarpetas}
          onSeleccionarCarpeta={handleMoverFoto}
          onCancelar={() => setMostrarMover(false)}
        />
      )}

      {mostrarDetalles && (
        <DetallesDialog
          nombreArchivo={fotoActual.nombre}
          nombreCarpeta={carpeta?.nombre || 'Desconocida'}
          fechaTexto={formatearFecha(fotoActual.fecha)}
          tamanoTexto={formatearBytes(fotoActual.tamanoBytes)}
          dimensiones={
            fotoActual.ancho && fotoActual.alto
              ? `${fotoActual.ancho} × ${fotoActual.alto} px`
              : undefined
          }
          onCerrar={() => setMostrarDetalles(false)}
        />
      )}
    </div>
  );
};
