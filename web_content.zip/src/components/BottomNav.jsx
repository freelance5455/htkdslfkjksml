import React from 'react';
import { t } from '../lib/i18n';

const ICONS = {
  "n_home": "M4 11l8-7 8 7v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z M9.8 14.8c.6.8 1.3 1.2 2.2 1.2s1.6-.4 2.2-1.2",
  "n_log": "M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2 M7 2v20 M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3z M21 15v7",
  "n_scan": "M4 8V6a2 2 0 0 1 2-2h2 M16 4h2a2 2 0 0 1 2 2v2 M20 16v2a2 2 0 0 1-2 2h-2 M8 20H6a2 2 0 0 1-2-2v-2 M7 12h10",
  "n_pie": "M21 12c.55 0 1-.45.95-1A10 10 0 0 0 13 2.05c-.55-.05-1 .4-1 .95v8a1 1 0 0 0 1 1z M21.2 15.9A10 10 0 1 1 8 2.8",
  "n_user": "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M4 21c0-4 4-6 8-6s8 2 8 6"
};

/** Floating bottom bar: five round buttons, the active page is filled with the accent colour. */
export default function BottomNav({ active, accent, glow, onNavigate }) {
  const tabs = [
    { key: 'home', route: 'home', label: t('nav.home', 'Home'), icon: 'n_home' },
    { key: 'log', route: 'log', label: t('nav.log', 'Food log'), icon: 'n_log' },
    { key: 'scan', route: 'scanner', label: t('nav.scan', 'Scan a meal'), icon: 'n_scan' },
    { key: 'trends', route: 'trends', label: t('nav.trends', 'Trends'), icon: 'n_pie' },
    { key: 'profile', route: 'profile', label: t('nav.profile', 'Profile'), icon: 'n_user' },
  ];
  return (
    <nav
      className="navbar"
      aria-label="Main"
      style={{
        position: 'absolute', left: 22, right: 22, bottom: 14, height: 60, boxSizing: 'border-box',
        background: 'var(--glass)', border: `1px solid ${glow}`, borderRadius: 30,
        boxShadow: '0 8px 22px var(--sh)', padding: '0 12px', display: 'flex',
        alignItems: 'center', justifyContent: 'space-between', zIndex: 6,
      }}
    >
      {tabs.map((t) => {
        const on = t.key === active;
        return (
          <a
            key={t.key}
            className="navbtn"
            href="#"
            aria-label={t.label}
            aria-current={on ? 'page' : undefined}
            onClick={(e) => { e.preventDefault(); if (onNavigate) onNavigate(t.route); }}
            style={{
              width: 46, height: 46, borderRadius: 23, display: 'flex', alignItems: 'center',
              justifyContent: 'center', flex: 'none', textDecoration: 'none',
              background: on ? accent : 'var(--chip)', color: on ? '#FFFFFF' : 'var(--ink)',
              boxShadow: on ? `0 0 16px ${glow}` : 'none',
            }}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d={ICONS[t.icon]} />
            </svg>
          </a>
        );
      })}
    </nav>
  );
}
