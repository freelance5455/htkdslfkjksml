import React, { useEffect, useRef } from 'react';

export const NeuralNetworkUI: React.FC<{ active: boolean }> = ({ active }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // 3D Neural Brain Matrix Setup
    const numNodes = 45;
    let nodes: { x: number; y: number; z: number; ox: number; oy: number; oz: number; size: number; pulseSpeed: number; pulseVal: number }[] = [];

    const initNodes = () => {
      nodes = Array.from({ length: numNodes }, () => {
        // Distribute in a 3D spherical/brain cluster
        const u = Math.random();
        const v = Math.random();
        const theta = u * 2.0 * Math.PI;
        const phi = Math.acos(2.0 * v - 1.0);
        const r = 80 + Math.random() * 60;
        const x = r * Math.sin(phi) * Math.cos(theta);
        const y = r * Math.sin(phi) * Math.sin(theta);
        const z = r * Math.cos(phi);
        return {
          x, y, z,
          ox: x, oy: y, oz: z,
          size: Math.random() * 2.5 + 1.5,
          pulseSpeed: 0.02 + Math.random() * 0.05,
          pulseVal: Math.random() * Math.PI * 2
        };
      });
    };

    let angleX = 0;
    let angleY = 0;

    const draw = () => {
      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;

      // Clear with dark tech background
      ctx.fillStyle = '#05020a';
      ctx.fillRect(0, 0, width, height);

      // Rotation angles update (continuous 3D rotation horizontal & vertical)
      angleY += active ? 0.015 : 0.005;
      angleX += active ? 0.01 : 0.003;

      const cosY = Math.cos(angleY);
      const sinY = Math.sin(angleY);
      const cosX = Math.cos(angleX);
      const sinX = Math.sin(angleX);

      // Project and transform nodes
      const projected = nodes.map((node) => {
        // Rotate Y (horizontal spin)
        let x1 = node.ox * cosY - node.oz * sinY;
        let z1 = node.oz * cosY + node.ox * sinY;
        let y1 = node.oy;

        // Rotate X (vertical tilt)
        let y2 = y1 * cosX - z1 * sinX;
        let z2 = z1 * cosX + y1 * sinX;
        let x2 = x1;

        // Perspective
        const fov = 300;
        const scale = fov / (fov + z2 + 150);
        const px = centerX + x2 * scale;
        const py = centerY + y2 * scale;

        node.pulseVal += node.pulseSpeed;

        return {
          x: px,
          y: py,
          z: z2,
          scale,
          pulse: Math.sin(node.pulseVal)
        };
      });

      // Draw synaptic connections & electrical pulses
      projected.forEach((p1, i) => {
        projected.slice(i + 1).forEach((p2, j) => {
          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const dist = Math.hypot(dx, dy);

          if (dist < 110) {
            const alpha = (1 - dist / 110) * (active ? 0.6 : 0.15);
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            // Slight organic curve for neural fibers
            const cx = (p1.x + p2.x) / 2 + (Math.sin(i + j) * 10);
            const cy = (p1.y + p2.y) / 2 + (Math.cos(i + j) * 10);
            ctx.quadraticCurveTo(cx, cy, p2.x, p2.y);
            
            ctx.strokeStyle = active 
              ? `rgba(0, 212, 255, ${alpha * 1.5})` 
              : `rgba(157, 0, 255, ${alpha})`;
            ctx.lineWidth = active ? 1.5 : 0.8;
            ctx.stroke();

            // Electrical pulse traveling along synapse when active
            if (active && (i + j) % 3 === 0) {
              const t = ((Date.now() / 300 + i * 15) % 100) / 100;
              const pulseX = p1.x + (p2.x - p1.x) * t;
              const pulseY = p1.y + (p2.y - p1.y) * t;
              ctx.beginPath();
              ctx.arc(pulseX, pulseY, 2.5, 0, Math.PI * 2);
              ctx.fillStyle = '#ffffff';
              ctx.shadowColor = '#00d4ff';
              ctx.shadowBlur = 10;
              ctx.fill();
              ctx.shadowBlur = 0;
            }
          }
        });
      });

      // Draw nodes (neurons)
      projected.forEach((p) => {
        const radius = Math.max(1, (2 + p.pulse * 1.5) * p.scale);
        
        ctx.beginPath();
        ctx.arc(p.x, p.y, radius + (active ? 4 : 2), 0, Math.PI * 2);
        ctx.fillStyle = active ? 'rgba(0, 212, 255, 0.3)' : 'rgba(157, 0, 255, 0.2)';
        ctx.fill();

        ctx.beginPath();
        ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
        ctx.fillStyle = active ? '#ffffff' : '#00d4ff';
        ctx.shadowColor = active ? '#00d4ff' : '#9d00ff';
        ctx.shadowBlur = active ? 15 : 6;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      animationFrameRef.current = requestAnimationFrame(draw);
    };

    const updateSize = () => {
      if (!canvas) return;
      canvas.width = canvas.offsetWidth || 320;
      canvas.height = canvas.offsetHeight || 160;
    };

    updateSize();
    initNodes();
    draw();

    window.addEventListener('resize', updateSize);
    return () => {
      window.removeEventListener('resize', updateSize);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [active]);

  return (
    <div className="relative w-full h-44 rounded-2xl overflow-hidden border border-[#00d4ff]/30 shadow-[0_0_25px_rgba(0,212,255,0.2)] bg-black">
      <canvas ref={canvasRef} className="w-full h-full block" />
      <div className="absolute top-2 left-3 flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-[#00d4ff]/40">
        <span className={`w-2 h-2 rounded-full ${active ? 'bg-[#00d4ff] animate-ping' : 'bg-purple-500'}`} />
        <span className="text-[9px] font-black tracking-widest text-cyan-300 uppercase">
          {active ? 'SONÓ ZERO · SYNAPSE ACTIVE' : 'SONÓ ZERO · NEURAL MESH'}
        </span>
      </div>
    </div>
  );
};
