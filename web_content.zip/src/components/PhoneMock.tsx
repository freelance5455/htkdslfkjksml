import { useEffect, useState } from "react";
import {
  Bell, Clapperboard, Gamepad2, Globe2, Home, MonitorPlay, Music2, Search,
  Settings, Trophy, Wifi, WifiOff, SatelliteDish, Star, Play, CalendarClock, Radio,
} from "lucide-react";
import { useNow } from "../lib/hooks";
import { CHANNELS, MOVIES } from "../lib/data";

type Screen = "inicio" | "worldtv" | "deportes" | "cine";
const SCREENS: { id: Screen; label: string }[] = [
  { id: "inicio", label: "Inicio" },
  { id: "worldtv", label: "World TV" },
  { id: "deportes", label: "Deportes" },
  { id: "cine", label: "Cine" },
];

const SIDE = [
  { icon: Home, label: "Inicio", screen: "inicio" as Screen },
  { icon: Globe2, label: "World TV", screen: "worldtv" as Screen },
  { icon: Trophy, label: "Sports", screen: "deportes" as Screen },
  { icon: Clapperboard, label: "Movies", screen: "cine" as Screen },
  { icon: MonitorPlay, label: "Series", screen: "cine" as Screen },
  { icon: Gamepad2, label: "Games", screen: "inicio" as Screen },
  { icon: Radio, label: "Radio", screen: "inicio" as Screen },
  { icon: Settings, label: "Ajustes", screen: "inicio" as Screen },
];

export default function PhoneMock() {
  const [screen, setScreen] = useState<Screen>("inicio");
  const [auto, setAuto] = useState(true);
  const now = useNow(15000);

  useEffect(() => {
    if (!auto) return;
    const id = window.setInterval(() => {
      setScreen((s) => {
        const order: Screen[] = ["inicio", "worldtv", "deportes", "cine"];
        return order[(order.indexOf(s) + 1) % order.length];
      });
    }, 4200);
    return () => window.clearInterval(id);
  }, [auto]);

  const hh = now.getHours().toString().padStart(2, "0");
  const mm = now.getMinutes().toString().padStart(2, "0");
  const date = now.toLocaleDateString("es-ES", { weekday: "short", day: "numeric", month: "short" });

  return (
    <div
      className="relative mx-auto w-full max-w-[620px]"
      onMouseEnter={() => setAuto(false)}
      onMouseLeave={() => setAuto(true)}
      onFocusCapture={() => setAuto(false)}
      onBlurCapture={() => setAuto(true)}
    >
      {/* ambient glows */}
      <div aria-hidden="true" className="absolute -left-10 top-1/2 h-64 w-64 -translate-y-1/2 rounded-full bg-electric/30 blur-[90px]" />
      <div aria-hidden="true" className="absolute -right-10 top-1/3 h-64 w-64 rounded-full bg-violetx/30 blur-[90px]" />

      {/* floating chips */}
      <div className="absolute -left-2 -top-4 z-20 hidden items-center gap-2 rounded-2xl border border-cyanx/30 bg-[#071231]/90 px-3 py-2 shadow-lg shadow-cyan-500/10 backdrop-blur-md animate-floaty md:flex">
        <SatelliteDish size={15} className="text-cyanx" />
        <div className="leading-tight">
          <p className="text-[10px] font-bold text-white">EPG + M3U integrados</p>
          <p className="text-[8px] text-slate-400">Tus listas, tu control</p>
        </div>
      </div>
      <div className="absolute -right-3 top-16 z-20 hidden items-center gap-2 rounded-2xl border border-violetx/30 bg-[#0f0a2e]/90 px-3 py-2 shadow-lg shadow-violet-500/10 backdrop-blur-md animate-floaty-late md:flex">
        <Gamepad2 size={15} className="text-lilac" />
        <div className="leading-tight">
          <p className="text-[10px] font-bold text-white">Mandos Bluetooth</p>
          <p className="text-[8px] text-slate-400">D-pad · XInput · DInput</p>
        </div>
      </div>
      <div className="absolute -bottom-4 left-8 z-20 hidden items-center gap-2 rounded-2xl border border-emerald-400/30 bg-[#041f1b]/90 px-3 py-2 shadow-lg shadow-emerald-500/10 backdrop-blur-md animate-floaty md:flex" style={{ animationDelay: "2.2s" }}>
        <WifiOff size={15} className="text-emerald-400" />
        <div className="leading-tight">
          <p className="text-[10px] font-bold text-white">100% offline</p>
          <p className="text-[8px] text-slate-400">Tu biblioteca local, siempre</p>
        </div>
      </div>

      {/* phone frame (landscape 16:9) */}
      <div className="relative z-10 rounded-[1.7rem] border border-[#2a3572] bg-gradient-to-b from-[#1a2150] to-[#0a0e28] p-[5px] shadow-[0_40px_90px_-20px_rgba(0,0,0,0.8),0_0_70px_-20px_rgba(56,130,255,0.4)]">
        <div className="phone-scan relative aspect-[16/9] w-full overflow-hidden rounded-[1.35rem] bg-[#050a24]">
          {/* camera punch-hole */}
          <div className="absolute left-1/2 top-1 z-30 h-[5px] w-[5px] -translate-x-1/2 rounded-full bg-[#131a3f] ring-1 ring-[#2c3770]" />

          {/* status bar */}
          <div className="flex h-[7%] items-center justify-between border-b border-white/5 px-3">
            <span className="font-display text-[7px] font-bold text-white/90">TV <span className="text-cyanx">LO3</span></span>
            <div className="flex h-4 w-40 items-center gap-1 rounded-full bg-white/[0.06] px-2 sm:w-48">
              <Search size={6} className="text-slate-400" />
              <span className="text-[6px] text-slate-500">Buscar en TV LO3…</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Wifi size={7} className="text-slate-300" />
              <Bell size={7} className="text-slate-300" />
              <div className="text-right leading-none">
                <p className="text-[7px] font-bold text-white">{hh}:{mm}</p>
                <p className="text-[5px] capitalize text-slate-400">{date}</p>
              </div>
            </div>
          </div>

          <div className="flex h-[93%]">
            {/* sidebar */}
            <div className="flex w-[15%] flex-col items-center gap-[3%] border-r border-white/5 bg-[#070d2c]/80 py-[2%]">
              {SIDE.map((item, i) => {
                const active = item.screen === screen && (screen !== "inicio" || i === 0);
                const Icon = item.icon;
                return (
                  <button
                    key={i}
                    onClick={() => setScreen(item.screen)}
                    aria-label={`Abrir ${item.label}`}
                    className={`flex w-[86%] items-center gap-1 rounded-md px-1 py-[3px] transition-colors ${
                      active ? "bg-gradient-to-r from-electric to-violetx text-white" : "text-slate-400 hover:bg-white/5 hover:text-white"
                    }`}
                  >
                    <Icon size={7} strokeWidth={2.2} className="shrink-0" />
                    <span className="hidden text-[6px] font-semibold leading-none min-[420px]:block">{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* screen body */}
            <div className="relative flex-1 overflow-hidden">
              {screen === "inicio" && (
                <div className="flex h-full flex-col p-[2%]">
                  {/* hero banner */}
                  <div className="relative h-[46%] overflow-hidden rounded-md border border-white/10">
                    <img src="/img/hero-art.jpg" alt="Planeta Tierra desde el espacio — World TV" className="absolute inset-0 h-full w-full object-cover object-center" />
                    <div className="absolute inset-0 bg-gradient-to-r from-[#050a24]/90 via-[#050a24]/40 to-transparent" />
                    <div className="absolute inset-0 flex flex-col justify-center px-[4%]">
                      <p className="font-display text-[13px] font-black italic leading-none text-white min-[420px]:text-[17px]">WORLD <span className="text-cyanx">TV</span></p>
                      <p className="mt-[3px] text-[6px] font-semibold text-slate-200 min-[420px]:text-[7px]">Televisión internacional en directo</p>
                      <span className="mt-[4%] inline-flex w-max items-center gap-1 rounded-full bg-gradient-to-r from-cyan-400 to-blue-600 px-2 py-[3px] text-[6px] font-black text-[#03102a] min-[420px]:text-[7px]">Ver ahora <Play size={6} fill="currentColor" /></span>
                    </div>
                  </div>
                  {/* favorites */}
                  <p className="mt-[3%] flex items-center gap-1 text-[6px] font-bold text-amber-300 min-[420px]:text-[7px]"><Star size={7} fill="currentColor" /> Tus favoritos</p>
                  <div className="mt-[2%] grid grid-cols-6 gap-[3%]">
                    {[
                      { n: "WORLD TV", c: "from-sky-400 to-blue-700", icon: Globe2 },
                      { n: "MOVIES", c: "from-red-500 to-orange-800", icon: Clapperboard },
                      { n: "GAMES", c: "from-amber-400 to-yellow-700", icon: Gamepad2 },
                      { n: "MUSIC", c: "from-violet-500 to-purple-800", icon: Music2 },
                      { n: "RADIO", c: "from-cyan-500 to-blue-800", icon: Radio },
                      { n: "AI", c: "from-fuchsia-500 to-violet-800", icon: Star },
                    ].map((f, i) => (
                      <div key={i} className={`flex h-[300%] max-h-12 flex-col items-center justify-center rounded-md bg-gradient-to-br ${f.c} py-[6px]`}>
                        <f.icon size={8} className="text-white/95" />
                        <span className="mt-[2px] text-[5px] font-black tracking-wide text-white min-[420px]:text-[6px]">{f.n}</span>
                      </div>
                    ))}
                  </div>
                  {/* continue watching */}
                  <p className="mt-[3%] text-[6px] font-bold text-slate-200 min-[420px]:text-[7px]">Continuar viendo</p>
                  <div className="mt-[2%] flex gap-[3%]">
                    {[
                      { img: "/img/art-desert.jpg", t: "Dune: Parte Dos", p: 62 },
                      { img: "/img/poster-oppenheimer.jpg", t: "Oppenheimer", p: 88 },
                    ].map((c, i) => (
                      <div key={i} className="relative h-10 w-28 overflow-hidden rounded-md border border-white/10 min-[420px]:h-12 min-[420px]:w-32">
                        <img src={c.img} alt={c.t} className="absolute inset-0 h-full w-full object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                        <Play size={7} fill="#fff" className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-white" />
                        <div className="absolute bottom-1 left-1 right-1">
                          <p className="truncate text-[5px] font-bold text-white">{c.t}</p>
                          <div className="mt-[2px] h-[2px] w-full rounded bg-white/20"><div className="h-full rounded bg-cyanx" style={{ width: `${c.p}%` }} /></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {screen === "worldtv" && (
                <div className="flex h-full flex-col p-[2.5%]">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-display text-[9px] font-black text-white min-[420px]:text-[11px]">World TV</p>
                      <p className="text-[5.5px] text-slate-400 min-[420px]:text-[6.5px]">Canales internacionales · EPG integrado</p>
                    </div>
                    <div className="flex gap-1">
                      {["Todos", "Europa", "América"].map((f, i) => (
                        <span key={i} className={`rounded-full px-1.5 py-[2px] text-[5px] font-bold min-[420px]:text-[6px] ${i === 0 ? "bg-electric text-white" : "bg-white/5 text-slate-300"}`}>{f}</span>
                      ))}
                    </div>
                  </div>
                  <div className="mt-[3%] grid flex-1 grid-cols-6 grid-rows-2 gap-[4%]">
                    {CHANNELS.slice(0, 12).map((ch) => (
                      <div key={ch.name} className="flex flex-col items-center justify-center rounded-md border border-white/10 p-[3px]" style={{ background: `linear-gradient(150deg, ${ch.from}, ${ch.to})` }}>
                        <span className="text-[7px] font-black tracking-tight text-white drop-shadow min-[420px]:text-[9px]">{ch.abbr}</span>
                        <span className="mt-[2px] hidden max-w-full truncate text-[4.5px] text-white/85 min-[460px]:block">{ch.name}</span>
                      </div>
                    ))}
                  </div>
                  <p className="mt-[2%] text-[5px] text-slate-500">EPG · Favoritos · Último canal · Sintonía automática — IPTV autorizada</p>
                </div>
              )}

              {screen === "deportes" && (
                <div className="flex h-full flex-col p-[2.5%]">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Trophy size={12} className="text-gold" />
                      <div>
                        <p className="font-display text-[9px] font-black text-white min-[420px]:text-[11px]">Sports Center</p>
                        <p className="text-[5.5px] text-slate-400 min-[420px]:text-[6.5px]">Fútbol · NBA · Fórmula 1 · Tenis y más</p>
                      </div>
                    </div>
                    <span className="flex items-center gap-1 rounded-full bg-red-500/15 px-1.5 py-[2px] text-[5.5px] font-black text-red-400 min-[420px]:text-[6px]"><span className="h-1.5 w-1.5 animate-live rounded-full bg-red-500" /> EN VIVO</span>
                  </div>
                  <div className="mt-[4%] grid flex-1 grid-cols-2 content-start gap-[4%]">
                    {[
                      { lg: "LALIGA", a: "RMA", b: "FCB", t: "HOY · 21:00", live: false },
                      { lg: "NBA", a: "LAL", b: "BOS", t: "4T · 05:32", live: true },
                      { lg: "CHAMPIONS", a: "ATM", b: "PSG", t: "MAÑANA · 21:00", live: false },
                      { lg: "NFL", a: "KC", b: "BUF", t: "DOM · 00:25", live: false },
                    ].map((m, i) => (
                      <div key={i} className="rounded-md border border-white/10 bg-[#0d1434] p-[6px]">
                        <div className="flex items-center justify-between">
                          <span className="text-[5.5px] font-black tracking-widest text-cyanx min-[420px]:text-[6px]">{m.lg}</span>
                          {m.live
                            ? <span className="text-[5px] font-bold text-red-400">{m.t}</span>
                            : <span className="flex items-center gap-[2px] text-[5px] text-slate-400"><CalendarClock size={5} />{m.t}</span>}
                        </div>
                        <div className="mt-[6px] space-y-[4px]">
                          {[m.a, m.b].map((team) => (
                            <div key={team} className="flex items-center justify-between">
                              <span className="flex items-center gap-1">
                                <span className="flex h-[9px] w-[9px] items-center justify-center rounded-full bg-white/10 text-[4.5px] font-black text-white">{team[0]}</span>
                                <span className="text-[6.5px] font-bold text-slate-100 min-[420px]:text-[7px]">{team}</span>
                              </span>
                              <span className="text-[6.5px] font-semibold text-slate-500">—</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                  <p className="mt-[2%] text-[5px] text-slate-500">Marcadores reales vía ESPN · Calendarios, clasificaciones y alertas</p>
                </div>
              )}

              {screen === "cine" && (
                <div className="flex h-full flex-col p-[2.5%]">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-display text-[9px] font-black text-white min-[420px]:text-[11px]">Estrenos y clásicos</p>
                      <p className="text-[5.5px] text-slate-400 min-[420px]:text-[6.5px]">Información de TMDB · Subtítulos CC · 4K HDR</p>
                    </div>
                    <span className="rounded-full bg-white/5 px-1.5 py-[2px] text-[5px] font-bold text-slate-300">Ver todo →</span>
                  </div>
                  <div className="mt-[3%] flex flex-1 gap-[3%]">
                    {MOVIES.slice(0, 5).map((m) => (
                      <div key={m.id} className="group relative h-full flex-1 overflow-hidden rounded-md border border-white/10">
                        <img src={m.img} alt={m.title} className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
                        <span className="absolute right-1 top-1 flex items-center gap-[2px] rounded bg-black/60 px-1 py-[1px] text-[4.5px] font-bold text-gold"><Star size={4.5} fill="currentColor" />{m.rating}</span>
                        <p className="absolute bottom-1 left-1 right-1 truncate text-[5px] font-bold text-white min-[420px]:text-[6px]">{m.title}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* screen switcher dots */}
      <div className="mt-3 flex items-center justify-center gap-2" role="tablist" aria-label="Cambiar pantalla de la demo">
        {SCREENS.map((s) => (
          <button
            key={s.id}
            role="tab"
            aria-selected={screen === s.id}
            aria-label={s.label}
            onClick={() => setScreen(s.id)}
            className={`h-2 rounded-full transition-all duration-300 ${screen === s.id ? "w-6 bg-cyanx" : "w-2 bg-white/20 hover:bg-white/40"}`}
          />
        ))}
      </div>
    </div>
  );
}
