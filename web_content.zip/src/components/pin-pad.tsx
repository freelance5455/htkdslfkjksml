import { Delete } from "lucide-react";
import { cn } from "@/lib/utils";

export const PIN_LENGTH = 4;

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "sp", "0", "del"] as const;

export function PinDots({
  value,
  length = PIN_LENGTH,
  shake = false,
}: {
  value: string;
  length?: number;
  shake?: boolean;
}) {
  return (
    <div
      className={cn("flex justify-center gap-4", shake && "shake")}
      aria-live="polite"
      aria-label={`Введено ${value.length} из ${length}`}
    >
      {Array.from({ length }, (_, i) => (
        <span
          key={i}
          className={cn(
            "size-3 rounded-full transition-[background-color,transform] duration-150",
            i < value.length ? "scale-110 bg-sage" : "bg-cream/20",
          )}
        />
      ))}
    </div>
  );
}

export function PinPad({
  value,
  onChange,
  onComplete,
  disabled = false,
  length = PIN_LENGTH,
}: {
  value: string;
  onChange: (next: string) => void;
  onComplete?: (pin: string) => void;
  disabled?: boolean;
  length?: number;
}) {
  function press(digit: string) {
    if (disabled || value.length >= length) return;
    const next = value + digit;
    onChange(next);
    if (next.length === length) onComplete?.(next);
  }

  function backspace() {
    if (disabled) return;
    onChange(value.slice(0, -1));
  }

  return (
    <div className="mx-auto grid w-full max-w-xs grid-cols-3 gap-x-4 gap-y-3">
      {KEYS.map((key) => {
        if (key === "sp") return <span key={key} />;
        if (key === "del") {
          return (
            <button
              key={key}
              type="button"
              aria-label="Стереть"
              disabled={disabled}
              onClick={backspace}
              className="flex h-16 items-center justify-center rounded-full text-cream/80 transition-colors duration-150 active:bg-cream/10 disabled:opacity-40"
            >
              <Delete className="size-6" />
            </button>
          );
        }
        return (
          <button
            key={key}
            type="button"
            disabled={disabled}
            onClick={() => press(key)}
            className="flex h-16 items-center justify-center rounded-full font-display text-2xl text-cream transition-colors duration-150 active:bg-cream/10 disabled:opacity-40"
          >
            {key}
          </button>
        );
      })}
    </div>
  );
}
