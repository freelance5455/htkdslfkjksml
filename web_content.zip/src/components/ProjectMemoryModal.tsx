/**
 * GODEX v0.0.1 - Project Memory & Secret Safety Vault Modal
 */

import React, { useState } from 'react';
import { Database, Shield, Lock, Plus, Trash2, X, Sparkles } from 'lucide-react';
import { ProjectMemoryItem } from '../types';
import { ProjectMemoryService } from '../services/projectMemory';

interface ProjectMemoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProjectMemoryModal: React.FC<ProjectMemoryModalProps> = ({
  isOpen,
  onClose
}) => {
  const [items, setItems] = useState<ProjectMemoryItem[]>(() => ProjectMemoryService.getMemoryItems());
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState<ProjectMemoryItem['category']>('architecture');
  const [isAdding, setIsAdding] = useState(false);

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;
    const added = ProjectMemoryService.saveMemoryItem({
      category: newCategory,
      title: newTitle.trim(),
      content: newContent.trim()
    });
    setItems([added, ...items]);
    setNewTitle('');
    setNewContent('');
    setIsAdding(false);
  };

  const handleDelete = (id: string) => {
    ProjectMemoryService.deleteMemoryItem(id);
    setItems(items.filter(i => i.id !== id));
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none font-mono">
      <div className="w-full max-w-2xl bg-[#090B10] border border-[#1C2230] rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="h-12 px-5 border-b border-[#1C2230] flex items-center justify-between bg-[#0D1017] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded bg-[#101924] border border-cyan-500/50 flex items-center justify-center">
              <Database className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-white flex items-center gap-2">
                PROJECT_MEMORY.VAULT
              </h2>
              <p className="text-[10px] text-neutral-400 font-sans">Contextual architecture memory & automated secret safety sanitizer</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded text-neutral-400 hover:text-white hover:bg-[#161C2A] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#07080D]">
          {/* Secret Redaction Banner */}
          <div className="p-3.5 rounded bg-[#0D1018] border border-[#1C2334] flex items-start gap-3">
            <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5 text-xs">
              <div className="font-bold text-white text-xs">Automated Secret Safety Redactor Active</div>
              <p className="text-[11px] text-neutral-400 leading-relaxed font-sans">
                All logs, prompts, and context transmissions automatically redact Gemini API keys, passwords, and private auth tokens before reaching the AI model.
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
              Memory Items ({items.length})
            </span>
            <button
              onClick={() => setIsAdding(true)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#0E2A38] hover:bg-[#133A4E] border border-cyan-500/60 text-cyan-300 text-xs font-bold transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>ADD_MEMORY_ITEM</span>
            </button>
          </div>

          {/* Add Item Form */}
          {isAdding && (
            <form onSubmit={handleAdd} className="p-3.5 rounded bg-[#0D1018] border border-cyan-500/40 space-y-2.5">
              <div className="flex gap-2">
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="h-8 px-2 rounded bg-[#06070A] border border-[#232F46] text-xs text-white focus:outline-none"
                >
                  <option value="architecture">Architecture</option>
                  <option value="conventions">Conventions</option>
                  <option value="decisions">Decisions</option>
                  <option value="test_expectations">Test Expectations</option>
                </select>
                <input
                  type="text"
                  autoFocus
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Title / Topic"
                  className="flex-1 h-8 px-2.5 rounded bg-[#06070A] border border-[#232F46] text-xs text-white placeholder-neutral-600 focus:outline-none font-sans"
                />
              </div>
              <textarea
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="Details for the AI agent to remember..."
                className="w-full h-16 p-2 rounded bg-[#06070A] border border-[#232F46] text-xs text-white placeholder-neutral-600 focus:outline-none resize-none font-sans"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-2.5 py-1 rounded bg-[#151D2C] hover:bg-[#1C263A] text-xs text-neutral-300 border border-[#232F46]"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-xs font-bold text-white shadow"
                >
                  SAVE_TO_MEMORY
                </button>
              </div>
            </form>
          )}

          {/* Items List */}
          <div className="space-y-2">
            {items.map(item => (
              <div
                key={item.id}
                className="p-3 rounded bg-[#0D1018] border border-[#1B2232] space-y-1"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#161E2E] text-cyan-300 font-mono font-semibold uppercase border border-[#232F46]">
                      {item.category}
                    </span>
                    <span className="text-xs font-bold text-white">{item.title}</span>
                  </div>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="text-neutral-500 hover:text-rose-400 p-1 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-[11px] text-neutral-300 leading-relaxed font-sans">{item.content}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="h-11 px-5 border-t border-[#1C2230] bg-[#0D1017] flex items-center justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-3 py-1 rounded bg-[#151D2C] hover:bg-[#1C263A] border border-[#232F46] text-xs font-semibold text-neutral-200 transition-colors"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
