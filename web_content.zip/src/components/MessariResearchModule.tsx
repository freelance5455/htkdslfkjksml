"use client";

import React, { useState } from "react";
import { CoinTechnicalAnalysis, formatPriceNumber } from "../services/technicalEngine";
import {
  Database,
  GitBranch,
  Wallet,
  Unlock,
  Sparkles,
  ShieldCheck,
  TrendingUp,
} from "lucide-react";

interface MessariCoin extends CoinTechnicalAnalysis {
  nameHe: string;
  sectorHe: string;
  marketCapBillions: number;
  messariMetrics: {
    activeWallets24h: number;
    onChainVolume24hMillions: number;
    supplyInflationAnnualPct: number;
    githubCommits30d: number;
    activeDevelopers: number;
    nextUnlockSummaryHe: string;
    aiSummaryHe: string;
    institutionalRating: string;
  };
}

interface MessariResearchModuleProps {
  coins: MessariCoin[];
  onTradeDemoFromResearch: (coin: MessariCoin) => void;
}

export function MessariResearchModule({
  coins,
  onTradeDemoFromResearch,
}: MessariResearchModuleProps) {
  const safeCoins = Array.isArray(coins) ? coins : [];
  const [selectedSymbol, setSelectedSymbol] = useState<string>(
    safeCoins[0]?.symbol || "BTCUSDT"
  );

  const focusedCoin =
    safeCoins.find((c) => c.symbol === selectedSymbol) || safeCoins[0];

  if (!focusedCoin) return null;

  return (
    <div dir="rtl" className="space-y-6">
      {/* Header */}
      <div className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Database className="h-6 w-6 text-[#3B82F6]" />
              <h2 className="text-xl font-bold text-[#F1F5F9]">
                מחקר עומק פונדמנטלי ונתוני On-Chain (Messari Intelligence)
              </h2>
            </div>
            <p className="mt-1 text-sm text-[#94A3B8]">
              ניתוח מדדי רשת בזמן אמת: ארנקים פעילים, אינפלציית היצע, שחרורי טוקנים
              (Token Unlocks) ופעילות מפתחים ב-GitHub.
            </p>
          </div>

          {/* Quick Asset Selector Pills */}
          <div className="flex flex-wrap gap-1.5">
            {safeCoins.map((c) => (
              <button
                key={c.symbol}
                type="button"
                onClick={() => setSelectedSymbol(c.symbol)}
                className={`rounded-lg px-3 py-1.5 font-mono text-xs font-bold transition ${
                  c.symbol === focusedCoin.symbol
                    ? "bg-[#3B82F6] text-white"
                    : "bg-[#181F2C] text-[#94A3B8] hover:text-white"
                }`}
              >
                {c.baseAsset}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Focused Asset Deep Report Card */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
        {/* Left/Main Fundamental Breakdown (8 cols) */}
        <div className="lg:col-span-8 space-y-4 rounded-xl border border-[#222B3A] bg-[#11161F] p-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#222B3A] pb-4">
            <div>
              <div className="flex items-center gap-3">
                <span className="font-mono text-2xl font-extrabold text-[#F1F5F9]">
                  {focusedCoin.nameHe}
                </span>
                <span className="rounded-full bg-[#00E676]/15 px-3 py-0.5 font-mono text-xs font-extrabold text-[#00E676]">
                  דירוג מוסדי: {focusedCoin.messariMetrics.institutionalRating}
                </span>
              </div>
              <p className="mt-1 text-xs text-[#94A3B8]">
                סקטור: {focusedCoin.sectorHe} • שווי שוק: $
                {focusedCoin.marketCapBillions} מיליארד דולר
              </p>
            </div>
            <div className="text-left font-mono">
              <div className="text-2xl font-extrabold text-[#F1F5F9]">
                ${formatPriceNumber(focusedCoin.currentPrice)}
              </div>
              <span
                className={`text-xs font-bold ${
                  focusedCoin.change24hPct >= 0
                    ? "text-[#00E676]"
                    : "text-[#FF3B69]"
                }`}
              >
                {focusedCoin.change24hPct >= 0 ? "+" : ""}
                {focusedCoin.change24hPct}% (24ש&apos;)
              </span>
            </div>
          </div>

          {/* 4 Fundamental KPI Cards */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
              <div className="flex items-center gap-1.5 text-xs text-[#94A3B8]">
                <Wallet className="h-4 w-4 text-[#3B82F6]" />
                <span>ארנקים פעילים (24ש&apos;)</span>
              </div>
              <div className="mt-2 font-mono text-lg font-extrabold text-[#F1F5F9]">
                {focusedCoin.messariMetrics.activeWallets24h.toLocaleString()}
              </div>
              <span className="text-[11px] text-[#00E676]">
                פעילות משתמשים מאומתת
              </span>
            </div>

            <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
              <div className="flex items-center gap-1.5 text-xs text-[#94A3B8]">
                <TrendingUp className="h-4 w-4 text-[#00E676]" />
                <span>נפח סליקה On-Chain</span>
              </div>
              <div className="mt-2 font-mono text-lg font-extrabold text-[#F1F5F9]">
                ${focusedCoin.messariMetrics.onChainVolume24hMillions.toLocaleString()}M
              </div>
              <span className="text-[11px] text-[#94A3B8]">ב-24 השעות האחרונות</span>
            </div>

            <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
              <div className="flex items-center gap-1.5 text-xs text-[#94A3B8]">
                <Unlock className="h-4 w-4 text-[#F59E0B]" />
                <span>אינפלציית היצע שנתית</span>
              </div>
              <div
                className={`mt-2 font-mono text-lg font-extrabold ${
                  focusedCoin.messariMetrics.supplyInflationAnnualPct <= 1.5
                    ? "text-[#00E676]"
                    : "text-[#F59E0B]"
                }`}
              >
                {focusedCoin.messariMetrics.supplyInflationAnnualPct}%
              </div>
              <span className="text-[11px] text-[#94A3B8]">
                {focusedCoin.messariMetrics.supplyInflationAnnualPct < 0
                  ? "דפלציוני (שריפת היצע)"
                  : "הנפקת מאמתים שנתית"}
              </span>
            </div>

            <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
              <div className="flex items-center gap-1.5 text-xs text-[#94A3B8]">
                <GitBranch className="h-4 w-4 text-[#A855F7]" />
                <span>פיתוח GitHub (30 יום)</span>
              </div>
              <div className="mt-2 font-mono text-lg font-extrabold text-[#F1F5F9]">
                {focusedCoin.messariMetrics.githubCommits30d} Commits
              </div>
              <span className="text-[11px] text-[#94A3B8]">
                {focusedCoin.messariMetrics.activeDevelopers} מפתחי ליבה פעילים
              </span>
            </div>
          </div>

          {/* AI Fundamental Thesis Box */}
          <div className="rounded-xl border border-[#3B82F6]/40 bg-[#3B82F6]/10 p-4">
            <div className="flex items-center gap-2 text-sm font-bold text-[#F1F5F9]">
              <Sparkles className="h-4 w-4 text-[#3B82F6]" />
              <span>תקציר מנהלים AI ומודיעין פרוטוקול (Messari Copilot):</span>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-[#E2E8F0]">
              {focusedCoin.messariMetrics.aiSummaryHe}
            </p>
          </div>

          {/* Tokenomics & Unlock Schedule */}
          <div className="rounded-xl border border-[#222B3A] bg-[#0B0E14] p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#F59E0B]">
                לוח שחרורי טוקנים (Tokenomics &amp; Vesting Unlocks):
              </span>
              <span className="inline-flex items-center gap-1 text-xs text-[#00E676]">
                <ShieldCheck className="h-4 w-4" />
                נבדק מול חוזים חכמים
              </span>
            </div>
            <p className="mt-1.5 text-xs text-[#94A3B8]">
              {focusedCoin.messariMetrics.nextUnlockSummaryHe}
            </p>
          </div>
        </div>

        {/* Right Column: Combined Fundamental + Technical Confluence Verdict (4 cols) */}
        <div className="lg:col-span-4 flex flex-col justify-between rounded-xl border border-[#222B3A] bg-[#11161F] p-6">
          <div className="space-y-4">
            <h3 className="text-base font-bold text-[#F1F5F9]">
              שקלול פונדמנטלי + טכני מאוחד
            </h3>

            <div className="rounded-lg bg-[#0B0E14] p-4">
              <div className="flex items-center justify-between text-xs text-[#94A3B8]">
                <span>ציון קונפלואנס כולל</span>
                <span className="font-mono text-base font-extrabold text-[#00E676]">
                  {focusedCoin.confluenceScore}%
                </span>
              </div>
              <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-[#181F2C]">
                <div
                  className="h-full bg-gradient-to-l from-[#00E676] to-[#3B82F6]"
                  style={{ width: `${focusedCoin.confluenceScore}%` }}
                />
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between border-b border-[#222B3A] pb-2">
                <span className="text-[#94A3B8]">המלצת מנוע AI:</span>
                <span className="font-bold text-[#00E676]">
                  {focusedCoin.recommendationLabelHe}
                </span>
              </div>
              <div className="flex justify-between border-b border-[#222B3A] pb-2">
                <span className="text-[#94A3B8]">גודל פוזיציה מומלץ (Kelly):</span>
                <span className="font-mono font-bold text-[#F1F5F9]">
                  {focusedCoin.kellySizing.positionPctOfBalance}% ($
                  {focusedCoin.kellySizing.marginSizeUsdt})
                </span>
              </div>
              <div className="flex justify-between border-b border-[#222B3A] pb-2">
                <span className="text-[#94A3B8]">מינוף מומלץ:</span>
                <span className="font-mono font-bold text-[#3B82F6]">
                  {focusedCoin.kellySizing.recommendedLeverage}x
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#94A3B8]">נקודת שליטה בנפח (POC):</span>
                <span className="font-mono font-bold text-[#F1F5F9]">
                  ${formatPriceNumber(focusedCoin.volumeProfile.pocPrice)}
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onTradeDemoFromResearch(focusedCoin)}
            className="mt-6 w-full rounded-lg bg-[#00E676] py-3 text-sm font-extrabold text-[#0B0E14] transition hover:brightness-110"
          >
            בצע בעסקת דמו על {focusedCoin.baseAsset} (${focusedCoin.kellySizing.marginSizeUsdt})
          </button>
        </div>
      </div>

      {/* Comparative Fundamental Matrix Table */}
      <div className="overflow-x-auto rounded-xl border border-[#222B3A] bg-[#11161F] p-4">
        <h3 className="mb-3 text-sm font-bold text-[#F1F5F9]">
          טבלת השוואה רוחבית (On-Chain &amp; Developer Matrix)
        </h3>
        <table className="w-full text-right text-xs">
          <thead>
            <tr className="border-b border-[#222B3A] text-[#64748B]">
              <th className="py-2.5 pr-2">נכס</th>
              <th className="py-2.5">סקטור</th>
              <th className="py-2.5">דירוג מוסדי</th>
              <th className="py-2.5">ארנקים פעילים (24ש&apos;)</th>
              <th className="py-2.5">נפח On-Chain</th>
              <th className="py-2.5">אינפלציה שנתית</th>
              <th className="py-2.5">GitHub Commits</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#222B3A]/60 font-mono">
            {safeCoins.map((c) => (
              <tr
                key={c.symbol}
                onClick={() => setSelectedSymbol(c.symbol)}
                className="cursor-pointer transition hover:bg-[#181F2C]"
              >
                <td className="py-2.5 pr-2 font-bold text-[#F1F5F9]">
                  {c.baseAsset}{" "}
                  <span className="font-sans text-[11px] font-normal text-[#94A3B8]">
                    ({c.nameHe})
                  </span>
                </td>
                <td className="py-2.5 font-sans text-[#94A3B8]">{c.sectorHe}</td>
                <td className="py-2.5">
                  <span className="rounded bg-[#00E676]/15 px-2 py-0.5 text-[#00E676] font-bold">
                    {c.messariMetrics.institutionalRating}
                  </span>
                </td>
                <td className="py-2.5 text-[#F1F5F9]">
                  {c.messariMetrics.activeWallets24h.toLocaleString()}
                </td>
                <td className="py-2.5 text-[#F1F5F9]">
                  ${c.messariMetrics.onChainVolume24hMillions.toLocaleString()}M
                </td>
                <td
                  className={`py-2.5 font-bold ${
                    c.messariMetrics.supplyInflationAnnualPct < 0
                      ? "text-[#00E676]"
                      : "text-[#F59E0B]"
                  }`}
                >
                  {c.messariMetrics.supplyInflationAnnualPct}%
                </td>
                <td className="py-2.5 text-[#3B82F6]">
                  {c.messariMetrics.githubCommits30d} ({c.messariMetrics.activeDevelopers} devs)
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
