import React from 'react';
import {
  Shield,
  HeartHandshake,
  Lightbulb,
  Swords,
  Award,
  MessageSquare,
  Anchor,
  PieChart,
  Feather,
  Hourglass,
  Key,
  Scale,
  Smile,
  Users,
  Boxes
} from 'lucide-react';
import { WordData, SemanticPack } from '../types';
import { SEMANTIC_PACKS } from '../data/lexicon';

interface PacksTabProps {
  words: WordData[];
  masteredWords: string[];
  onOpenWordDetail: (word: WordData) => void;
}

export const PacksTab: React.FC<PacksTabProps> = ({
  words,
  masteredWords,
  onOpenWordDetail,
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Shield': return <Shield className="w-5 h-5" />;
      case 'HeartHandshake': return <HeartHandshake className="w-5 h-5" />;
      case 'Lightbulb': return <Lightbulb className="w-5 h-5" />;
      case 'Swords': return <Swords className="w-5 h-5" />;
      case 'Award': return <Award className="w-5 h-5" />;
      case 'MessageSquare': return <MessageSquare className="w-5 h-5" />;
      case 'Anchor': return <Anchor className="w-5 h-5" />;
      case 'PieChart': return <PieChart className="w-5 h-5" />;
      case 'Feather': return <Feather className="w-5 h-5" />;
      case 'Hourglass': return <Hourglass className="w-5 h-5" />;
      case 'Key': return <Key className="w-5 h-5" />;
      case 'Scale': return <Scale className="w-5 h-5" />;
      case 'Smile': return <Smile className="w-5 h-5" />;
      case 'Users': return <Users className="w-5 h-5" />;
      default: return <Boxes className="w-5 h-5" />;
    }
  };

  const getWordObject = (wordName: string): WordData | undefined => {
    return words.find(w => w.word.toLowerCase() === wordName.toLowerCase());
  };

  return (
    <div className="flex-1 smooth-scroll p-4 space-y-3 pb-28 max-w-md mx-auto w-full">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white rounded-3xl p-4 shadow-[0_4px_0_0_#1e40af] space-y-1">
        <h2 className="text-lg font-black flex items-center gap-2">
          <Boxes className="w-5 h-5 text-amber-300" /> Thematic Semantic Clusters
        </h2>
        <p className="text-xs text-blue-100 font-bengali">
          বিসিএস, আইবিএ ও জিআরই পরীক্ষার জন্য অর্থ ও প্রসঙ্গের ভিত্তিতে ১৫+ শব্দ গুচ্ছ সাজানো হয়েছে।
        </p>
      </div>

      {/* Packs List */}
      <div className="space-y-3">
        {SEMANTIC_PACKS.map((pack: SemanticPack) => {
          const knownCount = pack.words.filter(w => masteredWords.includes(w)).length;
          const total = pack.words.length;
          const pct = Math.round((knownCount / total) * 100);

          return (
            <div
              key={pack.id}
              className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className={`w-10 h-10 rounded-2xl bg-gradient-to-tr ${pack.color} text-white flex items-center justify-center font-black shadow-sm`}>
                    {getIcon(pack.icon)}
                  </div>
                  <div>
                    <h3 className="font-black text-sm text-slate-900 dark:text-white">
                      {pack.title}
                    </h3>
                    <p className="text-[11px] font-bengali text-slate-500">
                      {pack.bengaliTitle}
                    </p>
                  </div>
                </div>

                <span className="text-xs font-bold font-mono text-emerald-600 dark:text-emerald-400">
                  {knownCount}/{total}
                </span>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${pct}%` }}
                />
              </div>

              {/* Word Chips */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {pack.words.map((w) => {
                  const isKnown = masteredWords.includes(w);
                  const wordObj = getWordObject(w);

                  return (
                    <button
                      key={w}
                      onClick={() => wordObj && onOpenWordDetail(wordObj)}
                      className={`px-2.5 py-1 rounded-xl text-xs font-semibold active:scale-95 transition-all ${
                        isKnown
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                      }`}
                    >
                      {w}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
