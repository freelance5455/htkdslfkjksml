import { useEffect, useRef, useState } from "react";
import { Download, Share2 } from "lucide-react";
import QRCode from "qrcode";
import { fieldCls, ghostBtn, goldBtn, ScreenScroll } from "@/components/yooyyaa/ui";
import type { View } from "@/components/yooyyaa/view";
import { adminCheck, adminLogin } from "@/lib/yooyyaa/admin.functions";
import { securityGroups, shortKey } from "@/lib/yooyyaa/crypto";
import { t, type Lang } from "@/lib/yooyyaa/i18n";
import { compressImage, safeHttp } from "@/lib/yooyyaa/media";
import { personById, PEOPLE } from "@/lib/yooyyaa/people";
import { activeAds, useYooyyaa, type Account, type LinkMode } from "@/lib/yooyyaa/store";

const ADMIN_TOKEN = "yooyyaa-admin";

function versionTaps(go: (view: View) => void) {
  let taps = 0;
  let at = 0;
  return () => {
    const now = Date.now();
    if (now - at > 2500) taps = 0;
    at = now;
    taps += 1;
    if (taps >= 7) {
      taps = 0;
      go({ name: "admin" });
    }
  };
}

export function SettingsScreen({
  lang,
  account,
  selfie,
  go,
  toast,
}: {
  lang: Lang;
  account: Account | null;
  selfie: string;
  go: (view: View) => void;
  toast: (text: string) => void;
}) {
  const dataSaver = useYooyyaa((s) => s.dataSaver);
  const linkMode = useYooyyaa((s) => s.linkMode);
  const setLang = useYooyyaa((s) => s.setLang);
  const setDataSaver = useYooyyaa((s) => s.setDataSaver);
  const setLinkMode = useYooyyaa((s) => s.setLinkMode);
  const [askErase, setAskErase] = useState(false);
  const onVersion = useRef(versionTaps(go)).current;

  if (!account) return null;

  const modes: { id: LinkMode; label: "pathAuto" | "pathWeak" | "pathOffline" }[] = [
    { id: "auto", label: "pathAuto" },
    { id: "weak", label: "pathWeak" },
    { id: "offline", label: "pathOffline" },
  ];
  const langs: { id: Lang; label: string }[] = [
    { id: "om", label: "Afaan Oromoo" },
    { id: "am", label: "አማርኛ" },
    { id: "en", label: "English" },
  ];

  return (
    <ScreenScroll>
      <h2 className="font-display text-3xl">{t(lang, "settings")}</h2>
      <div className="mt-5 flex items-center gap-3">
        <div className="grid size-16 place-items-center overflow-hidden rounded-full bg-surface-2 text-lg font-semibold text-gold">
          {selfie ? <img src={selfie} alt="" className="size-full object-cover" /> : account.name.slice(0, 1)}
        </div>
        <div>
          <p className="font-display text-2xl">{account.name}</p>
          <p className="text-xs text-muted">{t(lang, "nameLocked")}</p>
        </div>
      </div>
      <p className="mt-6 text-xs font-semibold tracking-wide text-gold uppercase">{t(lang, "languages")}</p>
      <div className="mt-2 grid gap-2">
        {langs.map((item) => (
          <button key={item.id} type="button" aria-pressed={lang === item.id} className={`min-h-11 rounded-xl border px-3 text-left text-sm ${lang === item.id ? "border-gold" : "border-line"}`} onClick={() => setLang(item.id)}>
            {item.label}
          </button>
        ))}
      </div>
      <p className="mt-6 text-xs font-semibold tracking-wide text-gold uppercase">{t(lang, "path")}</p>
      <p className="mt-1 text-sm text-pretty text-muted">{t(lang, "pathHint")}</p>
      <div className="mt-2 grid grid-cols-3 gap-2">
        {modes.map((mode) => (
          <button key={mode.id} type="button" aria-pressed={linkMode === mode.id} className={`min-h-11 rounded-xl border text-sm ${linkMode === mode.id ? "border-gold text-gold" : "border-line"}`} onClick={() => setLinkMode(mode.id)}>
            {t(lang, mode.label)}
          </button>
        ))}
      </div>
      <button type="button" aria-pressed={dataSaver} className="mt-4 flex min-h-11 w-full items-center justify-between rounded-xl border border-line px-3 text-left" onClick={() => setDataSaver(!dataSaver)}>
        <span>
          <span className="block text-sm font-semibold">{t(lang, "dataSaver")}</span>
          <span className="block text-xs text-muted">{t(lang, "dataSaverHint")}</span>
        </span>
        <span className={`rounded-full px-2 py-1 text-xs ${dataSaver ? "bg-gold text-ink" : "bg-surface-2 text-muted"}`}>
          {dataSaver ? t(lang, "live") : t(lang, "paused")}
        </span>
      </button>
      <div className="mt-4 rounded-xl border border-line p-3">
        <p className="text-xs text-muted">{t(lang, "loginKey")}</p>
        <p className="mt-1 font-semibold tabular-nums">{shortKey(account.idHash)}</p>
        <button
          type="button"
          className={`${ghostBtn} mt-3`}
          onClick={() => {
            void navigator.clipboard?.writeText(account.idHash).then(() => toast(t(lang, "keyCopied"))).catch(() => undefined);
          }}
        >
          {t(lang, "copyLink")}
        </button>
      </div>
      <button type="button" className={`${ghostBtn} mt-3 w-full`} onClick={() => go({ name: "share" })}>
        <Share2 className="size-4" />
        {t(lang, "shareRow")}
      </button>
      <div className="mt-6 text-sm leading-6 text-muted">
        <p>{t(lang, "principleScan")}</p>
        <p className="mt-2">{t(lang, "principleLock")}</p>
        <p className="mt-2">{t(lang, "principleQueue")}</p>
      </div>
      {askErase ? (
        <div className="mt-6 rounded-xl border border-line p-3">
          <p className="text-sm text-pretty">{t(lang, "eraseBody")}</p>
          <p className="mt-1 text-xs text-muted">{t(lang, "confirmErase")}</p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button type="button" className={ghostBtn} onClick={() => setAskErase(false)}>
              {t(lang, "cancel")}
            </button>
            <button
              type="button"
              className={goldBtn}
              onClick={() => {
                useYooyyaa.getState().erase();
                sessionStorage.removeItem(ADMIN_TOKEN);
              }}
            >
              {t(lang, "yesErase")}
            </button>
          </div>
        </div>
      ) : (
        <button type="button" className={`${ghostBtn} mt-6 w-full`} onClick={() => setAskErase(true)}>
          {t(lang, "erase")}
        </button>
      )}
      <button type="button" className="mt-8 min-h-11 text-xs text-muted" onClick={onVersion}>
        {t(lang, "version")}
      </button>
    </ScreenScroll>
  );
}

export function ShareScreen({ lang, go, toast }: { lang: Lang; go: (view: View) => void; toast: (text: string) => void }) {
  const [svg, setSvg] = useState("");
  const url = typeof window === "undefined" ? "" : `${window.location.origin}${window.location.pathname}`;
  const blurb = `YOOYYAA — ${url}`;

  useEffect(() => {
    let dead = false;
    void QRCode.toString(url || "https://yooyyaa.app", {
      type: "svg",
      margin: 1,
      color: { dark: "#10211b", light: "#f3ecdf" },
    }).then((value) => {
      if (!dead) setSvg(value);
    }).catch(() => undefined);
    return () => {
      dead = true;
    };
  }, [url]);

  async function shareSystem() {
    if (navigator.share) {
      try {
        await navigator.share({ title: "YOOYYAA", text: blurb, url });
        return;
      } catch {
        return;
      }
    }
    toast(t(lang, "copyLink"));
    await navigator.clipboard?.writeText(blurb);
  }

  return (
    <ScreenScroll>
      <button type="button" className="mb-3 min-h-11 text-sm text-muted" onClick={() => go({ name: "settings" })}>
        {t(lang, "back")}
      </button>
      <h2 className="font-display text-3xl text-balance">{t(lang, "share")}</h2>
      <p className="mt-2 text-sm text-pretty text-muted">{t(lang, "shareBody")}</p>
      {svg ? (
        <div className="mt-5 rounded-2xl bg-fg p-4" dangerouslySetInnerHTML={{ __html: svg }} />
      ) : null}
      <p className="mt-2 text-center text-xs text-muted">{t(lang, "qrCaption")}</p>
      <div className="mt-4 grid gap-2">
        <a className={goldBtn} href="/downloads/YOOYYAA.apk" download>
          <Download className="size-4" />
          {t(lang, "downloadApk")}
        </a>
        <button type="button" className={ghostBtn} onClick={() => void navigator.clipboard?.writeText(url).then(() => toast(t(lang, "copied")))}>
          {t(lang, "copyLink")}
        </button>
        <a className={ghostBtn} href={`https://wa.me/?text=${encodeURIComponent(blurb)}`} target="_blank" rel="noreferrer">
          {t(lang, "whatsapp")}
        </a>
        <a className={ghostBtn} href={`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent("YOOYYAA")}`} target="_blank" rel="noreferrer">
          {t(lang, "telegram")}
        </a>
        <button type="button" className={ghostBtn} onClick={() => void shareSystem()}>
          {t(lang, "systemShare")}
        </button>
      </div>
      <div className="mt-5 rounded-xl border border-line p-3 text-sm text-pretty text-muted">
        <p>{t(lang, "offlineShare")}</p>
        <p className="mt-2">
          {t(lang, "bluetooth")} · {t(lang, "nearby")} · {t(lang, "xender")}
        </p>
        <p className="mt-2">{t(lang, "apkHelp")}</p>
      </div>
    </ScreenScroll>
  );
}

export function VerifyScreen({
  lang,
  contactId,
  idHash,
  verified,
  go,
}: {
  lang: Lang;
  contactId: string;
  idHash: string;
  verified: boolean;
  go: (view: View) => void;
}) {
  const person = personById(contactId);
  const [groups, setGroups] = useState<string[]>([]);
  useEffect(() => {
    if (!idHash) return;
    let dead = false;
    void securityGroups(idHash, contactId).then((value) => {
      if (!dead) setGroups(value);
    });
    return () => {
      dead = true;
    };
  }, [idHash, contactId]);
  if (!person) return null;
  return (
    <ScreenScroll>
      <button type="button" className="mb-3 min-h-11 text-sm text-muted" onClick={() => go({ name: "thread", id: contactId })}>
        {t(lang, "back")}
      </button>
      <h2 className="font-display text-3xl">{t(lang, "security")}</h2>
      <p className="mt-2 text-sm text-pretty text-muted">{person.name}</p>
      <p className="mt-3 text-sm text-pretty text-muted">{t(lang, "securityBody")}</p>
      <div className="mt-5 grid grid-cols-3 gap-2">
        {groups.map((group) => (
          <p key={group} className="rounded-xl bg-surface-2 py-3 text-center font-semibold tabular-nums tracking-wide">
            {group}
          </p>
        ))}
      </div>
      <p className="mt-4 text-sm">{verified ? t(lang, "verifiedDone") : t(lang, "notVerified")}</p>
      <button type="button" className={`${goldBtn} mt-4 w-full`} onClick={() => useYooyyaa.getState().toggleVerified(contactId)}>
        {verified ? t(lang, "verified") : t(lang, "markVerified")}
      </button>
    </ScreenScroll>
  );
}

export function SuspendedScreen({ lang, go }: { lang: Lang; go: (view: View) => void }) {
  const onVersion = useRef(versionTaps(go)).current;
  return (
    <ScreenScroll>
      <h2 className="font-display text-3xl text-balance">{t(lang, "suspendedTitle")}</h2>
      <p className="mt-3 text-sm text-pretty text-muted">{t(lang, "suspendedBody")}</p>
      <button type="button" className="mt-16 min-h-11 text-xs text-muted" onClick={onVersion}>
        {t(lang, "version")}
      </button>
    </ScreenScroll>
  );
}

export function AdminScreen({
  lang,
  go,
  toast,
}: {
  lang: Lang;
  go: (view: View) => void;
  toast: (text: string) => void;
}) {
  const account = useYooyyaa((s) => s.account);
  const messages = useYooyyaa((s) => s.messages);
  const ads = useYooyyaa((s) => s.ads);
  const suspendedContacts = useYooyyaa((s) => s.suspendedContacts);
  const [password, setPassword] = useState("");
  const [token, setToken] = useState<string | null>(null);
  const [expires, setExpires] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  const [link, setLink] = useState("");
  const [days, setDays] = useState("7");
  const [image, setImage] = useState<string | undefined>();
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const saved = sessionStorage.getItem(ADMIN_TOKEN);
    if (!saved) return;
    let dead = false;
    void adminCheck({ data: { token: saved } }).then((res) => {
      if (dead) return;
      if (res.ok) {
        setToken(saved);
        setExpires(res.expiresAt);
      } else sessionStorage.removeItem(ADMIN_TOKEN);
    }).catch(() => undefined);
    return () => {
      dead = true;
    };
  }, []);

  async function unlock() {
    setBusy(true);
    setError(null);
    try {
      const res = await adminLogin({ data: { password } });
      if (res.ok) {
        sessionStorage.setItem(ADMIN_TOKEN, res.token);
        setToken(res.token);
        setExpires(res.expiresAt);
        setPassword("");
      } else if (res.lockedForMs > 0) {
        const mins = Math.max(1, Math.ceil(res.lockedForMs / 60000));
        setError(`${t(lang, "locked")} · ${mins} ${t(lang, "minutes")}`);
      } else {
        setError(`${t(lang, "wrongPassword")} · ${res.attemptsLeft} ${t(lang, "attempts")}`);
      }
    } catch {
      setError(t(lang, "wrongPassword"));
    }
    setBusy(false);
  }

  async function authorized() {
    if (!token) return false;
    const res = await adminCheck({ data: { token } });
    if (!res.ok) {
      sessionStorage.removeItem(ADMIN_TOKEN);
      setToken(null);
      toast(t(lang, "sessionNote"));
      return false;
    }
    return true;
  }

  const queued = messages.filter((m) => m.status === "queued").length;
  const live = activeAds(ads);

  return (
    <ScreenScroll>
      <button type="button" className="mb-3 min-h-11 text-sm text-muted" onClick={() => go(account?.suspended ? { name: "suspended" } : { name: "settings" })}>
        {t(lang, "back")}
      </button>
      <h2 className="font-display text-3xl">{t(lang, "operator")}</h2>
      {!token ? (
        <form
          className="mt-4"
          onSubmit={(e) => {
            e.preventDefault();
            void unlock();
          }}
        >
          <p className="text-sm text-pretty text-muted">{t(lang, "adminBody")}</p>
          <label className="mt-4 block text-xs text-muted" htmlFor="operator-pass">
            {t(lang, "password")}
          </label>
          <input id="operator-pass" type="password" autoComplete="off" value={password} onChange={(e) => setPassword(e.target.value)} className={`${fieldCls} mt-1`} />
          {error ? <p className="mt-2 text-sm text-gold">{error}</p> : null}
          <button type="submit" className={`${goldBtn} mt-4 w-full`} disabled={busy || !password}>
            {busy ? t(lang, "saving") : t(lang, "unlock")}
          </button>
        </form>
      ) : (
        <div className="mt-4">
          <p className="text-sm text-muted">
            {t(lang, "sessionNote")} · {new Date(expires).toLocaleTimeString(lang === "am" ? "am" : "en", { hour: "2-digit", minute: "2-digit" })}
          </p>
          <h3 className="mt-6 font-display text-xl">{t(lang, "broadcast")}</h3>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t(lang, "adTitle")} className={`${fieldCls} mt-3`} />
          <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder={t(lang, "adText")} rows={3} className={`${fieldCls} mt-2 py-3`} />
          <input value={link} onChange={(e) => setLink(e.target.value)} placeholder={t(lang, "adLink")} className={`${fieldCls} mt-2`} />
          <label className="mt-2 block text-xs text-muted" htmlFor="ad-days">
            {t(lang, "adDays")}
          </label>
          <input id="ad-days" inputMode="numeric" value={days} onChange={(e) => setDays(e.target.value)} className={`${fieldCls} mt-1`} />
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (!file) return;
              void compressImage(file, 640, 0.6).then(setImage).catch(() => toast(t(lang, "photoFailed")));
            }}
          />
          <button type="button" className={`${ghostBtn} mt-2`} onClick={() => fileRef.current?.click()}>
            {t(lang, "imageOptional")}
          </button>
          {image ? (
            <div className="mt-2">
              <img src={image} alt="" className="max-h-32 rounded-xl object-cover" />
              <button type="button" className="mt-1 min-h-11 text-sm text-muted" onClick={() => setImage(undefined)}>
                {t(lang, "remove")}
              </button>
            </div>
          ) : null}
          <button
            type="button"
            className={`${goldBtn} mt-3 w-full`}
            onClick={() => {
              void (async () => {
                if (!(await authorized())) return;
                const span = Number(days);
                if (!title.trim() || !text.trim()) {
                  toast(t(lang, "needTitle"));
                  return;
                }
                if (!Number.isInteger(span) || span < 1 || span > 30) {
                  toast(t(lang, "daysInvalid"));
                  return;
                }
                let href: string | undefined;
                if (link.trim()) {
                  const safe = safeHttp(link.trim());
                  if (!safe) {
                    toast(t(lang, "linkBad"));
                    return;
                  }
                  href = safe;
                }
                useYooyyaa.getState().addAd({
                  id: crypto.randomUUID(),
                  title: title.trim(),
                  text: text.trim(),
                  link: href,
                  image,
                  days: span,
                  start: Date.now(),
                  active: true,
                });
                setTitle("");
                setText("");
                setLink("");
                setImage(undefined);
                toast(t(lang, "publishOk"));
              })();
            }}
          >
            {t(lang, "publish")}
          </button>
          <button
            type="button"
            className={`${ghostBtn} mt-2 w-full`}
            onClick={() => {
              void (async () => {
                if (!(await authorized())) return;
                useYooyyaa.getState().stopAds();
                toast(t(lang, "stoppedAds"));
              })();
            }}
          >
            {t(lang, "stopAds")}
          </button>
          <h3 className="mt-8 font-display text-xl">{t(lang, "stats")}</h3>
          <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
            <Stat label={t(lang, "messagesStored")} value={String(messages.length)} />
            <Stat label={t(lang, "queuedNow")} value={String(queued)} />
            <Stat label={t(lang, "peopleHere")} value={String(PEOPLE.length)} />
            <Stat label={t(lang, "activeAds")} value={String(live.length)} />
          </dl>
          {live.length === 0 ? <p className="mt-3 text-sm text-muted">{t(lang, "adEmpty")}</p> : null}
          <h3 className="mt-8 font-display text-xl">{t(lang, "users")}</h3>
          {account ? (
            <div className="mt-3 flex items-center justify-between gap-2 border-b border-line py-3">
              <div>
                <p className="font-semibold">{account.name}</p>
                <p className="text-xs text-muted">{t(lang, "thisPhone")} · {shortKey(account.idHash)}</p>
              </div>
              <button type="button" className={ghostBtn} onClick={() => void authorized().then((ok) => ok && useYooyyaa.getState().setSuspendedSelf(!account.suspended))}>
                {account.suspended ? t(lang, "restoreYou") : t(lang, "pauseYou")}
              </button>
            </div>
          ) : null}
          <ul>
            {PEOPLE.map((person) => {
              const paused = suspendedContacts.includes(person.id);
              return (
                <li key={person.id} className="flex items-center justify-between gap-2 border-b border-line py-3">
                  <div>
                    <p className="text-sm font-semibold">{person.name}</p>
                    <p className="text-xs text-muted">{person.city}</p>
                  </div>
                  <button type="button" className={ghostBtn} onClick={() => void authorized().then((ok) => ok && useYooyyaa.getState().toggleSuspendedContact(person.id))}>
                    {paused ? t(lang, "unsuspend") : t(lang, "suspend")}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </ScreenScroll>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface p-3">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="mt-1 font-display text-2xl tabular-nums">{value}</dd>
    </div>
  );
}
