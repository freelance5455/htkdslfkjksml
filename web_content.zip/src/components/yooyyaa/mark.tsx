export function Mark({ className = "size-12" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <rect width="32" height="32" rx="7" className="fill-bg" />
      <rect x="0.8" y="0.8" width="30.4" height="30.4" rx="6.4" className="fill-none stroke-gold" strokeWidth="1.2" />
      <path
        d="M12.2 6.4C5.2 11 5.2 21 12.2 25.6"
        fill="none"
        className="stroke-gold"
        strokeWidth="2.4"
        strokeLinecap="round"
      />
      <path
        d="M19.8 6.4C26.8 11 26.8 21 19.8 25.6"
        fill="none"
        className="stroke-gold"
        strokeWidth="2.4"
        strokeLinecap="round"
      />
    </svg>
  );
}
