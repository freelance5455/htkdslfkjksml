import { useEffect, useRef, useState } from "react";
import { BadgeCheck, Check, Clock, Image as ImageIcon, Mic, Phone, Search, Send, VideoOff } from "lucide-react";
import { Avatar, fieldCls, ghostBtn, goldBtn, ScreenScroll } from "@/components/yooyyaa/ui";
import type { View } from "@/components/yooyyaa/view";
import type { Payload } from "@/lib/yooyyaa/crypto";
import { t, type Lang } from "@/lib/yooyyaa/i18n";
import { compressImage, stopStream } from "@/lib/yooyyaa/media";
import { personById, PEOPLE } from "@/lib/yooyyaa/people";
import { useYooyyaa, type CallEntry, type MsgKind, type StoredMessage } from "@/lib/yooyyaa/store";
import { sendPayload, type LinkState } from "@/lib/yooyyaa/vault-actions";

function formatWhen(at: number, lang: Lang) {
  const locale = lang === "am" ? "am" : "en";
  const d = new Date(at);
  if (d.toDateString() === new Date().toDateString()) {
    return d.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" });
  }
  return d.toLocaleDateString(locale, { month: "short", day: "numeric" });
}

function clock(seconds: number) {
  return `${Math.floor(seconds / 60)}:${(seconds % 60).toString().padStart(2, "0")}`;
}

function previewText(kind: MsgKind, payload: Payload | undefined, lang: Lang) {
  if (kind === "photo") return t(lang, "photo");
  if (kind === "voice") return t(lang, "voice");
  return payload?.text ?? "…";
}

export function ChatsScreen({
  lang,
  messages,
  plain,
  go,
}: {
  lang: Lang;
  messages: StoredMessage[];
  plain: Record<string, Payload>;
  go: (view: View) => void;
}) {
  const [q, setQ] = useState("");
  const latest = new Map<string, StoredMessage>();
  for (const message of messages) {
    const prev = latest.get(message.contactId);
    if (!prev || message.at > prev.at) latest.set(message.contactId, message);
  }
  const rows = [...latest.values()]
    .sort((a, b) => b.at - a.at)
    .filter((message) => {
      const person = personById(message.contactId);
      const blob = `${person?.name ?? ""} ${person?.city ?? ""} ${previewText(message.kind, plain[message.id], lang)}`.toLowerCase();
      return blob.includes(q.trim().toLowerCase());
    });
  return (
    <ScreenScroll>
      <h2 className="font-display text-3xl">{t(lang, "chats")}</h2>
      <label className="mt-4 flex min-h-11 items-center gap-2 rounded-xl border border-line bg-surface px-3">
        <Search className="size-4 text-muted" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t(lang, "searchChats")}
          className="w-full bg-transparent text-sm text-fg outline-none placeholder:text-muted"
        />
      </label>
      <ul className="mt-4 divide-y divide-line">
        {rows.map((message) => {
          const person = personById(message.contactId);
          if (!person) return null;
          return (
            <li key={message.contactId}>
              <button type="button" className="flex w-full items-center gap-3 py-3 text-left" onClick={() => go({ name: "thread", id: person.id })}>
                <Avatar name={person.name} online={person.online} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-baseline justify-between gap-2">
                    <span className="truncate font-semibold">{person.name}</span>
                    <span className="shrink-0 text-xs text-muted tabular-nums">{formatWhen(message.at, lang)}</span>
                  </span>
                  <span className="mt-0.5 flex items-center gap-1 text-sm text-muted">
                    {message.status === "queued" ? <Clock className="size-3.5" /> : <Check className="size-3.5" />}
                    <span className="truncate">{previewText(message.kind, plain[message.id], lang)}</span>
                  </span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>
      {rows.length === 0 ? <p className="mt-6 text-sm text-muted">{t(lang, "emptySearch")}</p> : null}
    </ScreenScroll>
  );
}

export function ThreadScreen({
  lang,
  contactId,
  link,
  dataSaver,
  messages,
  plain,
  suspended,
  verified,
  go,
  toast,
}: {
  lang: Lang;
  contactId: string;
  link: LinkState;
  dataSaver: boolean;
  messages: StoredMessage[];
  plain: Record<string, Payload>;
  suspended: boolean;
  verified: boolean;
  go: (view: View) => void;
  toast: (text: string) => void;
}) {
  const person = personById(contactId);
  const [text, setText] = useState("");
  const [recording, setRecording] = useState(false);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const sending = useRef(false);
  const mine = messages.filter((m) => m.contactId === contactId);
  const blocked = suspended || busy;

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
  }, [mine.length]);

  useEffect(() => () => stopStream(streamRef.current), []);

  if (!person) return null;

  async function sendText() {
    const value = text.trim();
    if (!value || blocked || sending.current) return;
    sending.current = true;
    setText("");
    setBusy(true);
    await sendPayload(contactId, "text", { text: value }, link, lang);
    setBusy(false);
    sending.current = false;
  }

  async function onPhoto(file: File) {
    try {
      const dataUrl = await compressImage(file, dataSaver ? 480 : 960, dataSaver ? 0.45 : 0.62);
      await sendPayload(contactId, "photo", { dataUrl }, link, lang);
    } catch {
      toast(t(lang, "photoFailed"));
    }
  }

  async function toggleVoice() {
    if (recording) {
      recRef.current?.stop();
      setRecording(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      chunks.current = [];
      const rec = new MediaRecorder(stream, { audioBitsPerSecond: dataSaver ? 8000 : 20000 });
      recRef.current = rec;
      rec.ondataavailable = (ev) => {
        if (ev.data.size) chunks.current.push(ev.data);
      };
      rec.onstop = () => {
        const blob = new Blob(chunks.current, { type: rec.mimeType || "audio/webm" });
        stopStream(stream);
        streamRef.current = null;
        if (blob.size > 280_000) {
          toast(t(lang, "tooBig"));
          return;
        }
        const reader = new FileReader();
        reader.onload = () => {
          const dataUrl = typeof reader.result === "string" ? reader.result : "";
          if (dataUrl) void sendPayload(contactId, "voice", { dataUrl }, link, lang);
        };
        reader.readAsDataURL(blob);
      };
      rec.start();
      setRecording(true);
      window.setTimeout(() => {
        if (rec.state === "recording") rec.stop();
        setRecording(false);
      }, 8000);
    } catch {
      toast(t(lang, "voiceFailed"));
    }
  }

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center gap-3 border-b border-line px-3 py-3">
        <button type="button" className="min-h-11 px-1 text-sm text-muted" onClick={() => go({ name: "chats" })}>
          {t(lang, "back")}
        </button>
        <Avatar name={person.name} online={person.online} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold">{person.name}</p>
          <p className="text-xs text-muted">{person.online ? t(lang, "online") : t(lang, "away")}</p>
        </div>
        <button type="button" className="grid size-11 place-items-center text-gold" aria-label={t(lang, "security")} onClick={() => go({ name: "verify", id: person.id })}>
          {verified ? <BadgeCheck className="size-5" /> : <span className="text-xs">{t(lang, "verifyTitle")}</span>}
        </button>
        <button
          type="button"
          className="grid size-11 place-items-center"
          aria-label={t(lang, "call")}
          onClick={() => {
            if (link === "offline") toast(t(lang, "noRoute"));
            else go({ name: "live", id: person.id });
          }}
        >
          <Phone className="size-5" />
        </button>
      </header>
      <div ref={scroller} className="min-h-0 flex-1 space-y-2 overflow-y-auto px-3 py-4">
        <p className="mb-3 text-center text-xs text-pretty text-muted">{t(lang, "encryptedNote")}</p>
        {mine.length === 0 ? <p className="text-sm text-muted">{t(lang, "emptyThread")}</p> : null}
        {mine.map((message) => {
          const payload = plain[message.id];
          const mineBubble = message.from === "me";
          return (
            <div key={message.id} className={`flex ${mineBubble ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-xs rounded-2xl px-3 py-2 text-sm ${mineBubble ? "rounded-br-md bg-gold text-ink" : "rounded-bl-md bg-surface-2 text-fg"}`}>
                {message.kind === "text" ? <p className="break-words text-pretty">{payload?.text}</p> : null}
                {message.kind === "photo" && payload?.dataUrl ? (
                  <img src={payload.dataUrl} alt={t(lang, "photo")} className="max-h-56 rounded-xl object-cover" />
                ) : null}
                {message.kind === "voice" && payload?.dataUrl ? <audio controls src={payload.dataUrl} className="w-48" /> : null}
                <p className={`mt-1 flex items-center justify-end gap-1 text-xs tabular-nums ${mineBubble ? "text-ink" : "text-muted"}`}>
                  {formatWhen(message.at, lang)}
                  {mineBubble && message.status === "queued" ? <span>{t(lang, "queued")}</span> : null}
                  {mineBubble ? message.status === "queued" ? <Clock className="size-3" /> : <Check className="size-3" /> : null}
                </p>
              </div>
            </div>
          );
        })}
      </div>
      {suspended ? <p className="px-4 py-2 text-sm text-muted">{t(lang, "suspendedContact")}</p> : null}
      <form
        className="flex items-end gap-2 border-t border-line px-3 py-2"
        onSubmit={(e) => {
          e.preventDefault();
          void sendText();
        }}
      >
        <input ref={fileRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) void onPhoto(file);
        }} />
        <button type="button" className="grid size-11 place-items-center text-muted" aria-label={t(lang, "photo")} disabled={blocked} onClick={() => fileRef.current?.click()}>
          <ImageIcon className="size-5" />
        </button>
        <button type="button" className={`grid size-11 place-items-center ${recording ? "text-gold" : "text-muted"}`} aria-label={t(lang, "voice")} disabled={blocked} onClick={() => void toggleVoice()}>
          <Mic className="size-5" />
        </button>
        <textarea
          rows={1}
          value={text}
          disabled={blocked}
          placeholder={recording ? t(lang, "recording") : t(lang, "typeMessage")}
          className={`${fieldCls} max-h-24 resize-none py-3`}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              void sendText();
            }
          }}
        />
        <button type="submit" className="grid size-11 shrink-0 place-items-center rounded-xl bg-gold text-ink disabled:opacity-50" aria-label={t(lang, "send")} disabled={blocked || !text.trim()}>
          <Send className="size-4" />
        </button>
      </form>
    </div>
  );
}

export function PeopleScreen({
  lang,
  verified,
  suspendedContacts,
  link,
  go,
  toast,
}: {
  lang: Lang;
  verified: string[];
  suspendedContacts: string[];
  link: LinkState;
  go: (view: View) => void;
  toast: (text: string) => void;
}) {
  const [q, setQ] = useState("");
  const rows = PEOPLE.filter((p) => `${p.name} ${p.city}`.toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <ScreenScroll>
      <h2 className="font-display text-3xl">{t(lang, "people")}</h2>
      <p className="mt-1 text-sm text-muted">{t(lang, "worldwide")}</p>
      <label className="mt-4 flex min-h-11 items-center gap-2 rounded-xl border border-line bg-surface px-3">
        <Search className="size-4 text-muted" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t(lang, "searchPeople")} className="w-full bg-transparent text-sm outline-none placeholder:text-muted" />
      </label>
      <ul className="mt-3 divide-y divide-line">
        {rows.map((person) => (
          <li key={person.id} className="flex items-center gap-3 py-3">
            <Avatar name={person.name} online={person.online} />
            <div className="min-w-0 flex-1">
              <p className="truncate font-semibold">
                {person.name} {verified.includes(person.id) ? <BadgeCheck className="inline size-4 text-gold" /> : null}
              </p>
              <p className="truncate text-xs text-muted">
                {person.city} · {person.online ? t(lang, "online") : t(lang, "away")}
                {suspendedContacts.includes(person.id) ? ` · ${t(lang, "paused")}` : ""}
              </p>
            </div>
            <button type="button" className="min-h-11 px-2 text-sm text-gold" onClick={() => go({ name: "thread", id: person.id })}>
              {t(lang, "message")}
            </button>
            <button
              type="button"
              className="grid size-11 place-items-center"
              aria-label={t(lang, "call")}
              onClick={() => {
                if (link === "offline") toast(t(lang, "noRoute"));
                else go({ name: "live", id: person.id });
              }}
            >
              <Phone className="size-4" />
            </button>
          </li>
        ))}
      </ul>
      {rows.length === 0 ? <p className="mt-4 text-sm text-muted">{t(lang, "noMatch")}</p> : null}
    </ScreenScroll>
  );
}

export function CallsScreen({
  lang,
  callLog,
  link,
  go,
  toast,
}: {
  lang: Lang;
  callLog: CallEntry[];
  link: LinkState;
  go: (view: View) => void;
  toast: (text: string) => void;
}) {
  return (
    <ScreenScroll>
      <h2 className="font-display text-3xl">{t(lang, "calls")}</h2>
      {callLog.length === 0 ? <p className="mt-4 text-sm text-muted">{t(lang, "emptyCalls")}</p> : null}
      <ul className="mt-3 divide-y divide-line">
        {callLog.map((entry) => {
          const person = personById(entry.contactId);
          if (!person) return null;
          return (
            <li key={entry.id}>
              <button
                type="button"
                className="flex w-full items-center gap-3 py-3 text-left"
                onClick={() => {
                  if (link === "offline") toast(t(lang, "noRoute"));
                  else go({ name: "live", id: person.id });
                }}
              >
                <Avatar name={person.name} online={person.online} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-semibold">{person.name}</span>
                  <span className="text-xs text-muted">
                    {entry.audioOnly ? t(lang, "audioOnly") : t(lang, "call")} · {formatWhen(entry.at, lang)}
                  </span>
                </span>
                <Phone className="size-4 text-gold" />
              </button>
            </li>
          );
        })}
      </ul>
      <h3 className="mt-8 text-sm font-semibold text-muted">{t(lang, "callSomeone")}</h3>
      <ul className="mt-2">
        {PEOPLE.map((person) => (
          <li key={person.id}>
            <button
              type="button"
              className="flex min-h-11 w-full items-center justify-between text-left text-sm"
              onClick={() => {
                if (link === "offline") toast(t(lang, "noRoute"));
                else go({ name: "live", id: person.id });
              }}
            >
              <span>{person.name}</span>
              <span className="text-muted">{person.city}</span>
            </button>
          </li>
        ))}
      </ul>
    </ScreenScroll>
  );
}

export function LiveCall({
  lang,
  contactId,
  link,
  dataSaver,
  go,
}: {
  lang: Lang;
  contactId: string;
  link: LinkState;
  dataSaver: boolean;
  go: (view: View) => void;
}) {
  const person = personById(contactId);
  const audioOnly = link !== "online" || dataSaver;
  const [phase, setPhase] = useState<"setup" | "live">("setup");
  const [muted, setMuted] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [mic, setMic] = useState<"unknown" | "on" | "off">("unknown");
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    let dead = false;
    const wait = window.setTimeout(() => setPhase("live"), 900);
    const constraints: MediaStreamConstraints = audioOnly
      ? { audio: true, video: false }
      : { audio: true, video: { facingMode: "user" } };
    void navigator.mediaDevices
      ?.getUserMedia(constraints)
      .then((stream) => {
        if (dead) {
          stopStream(stream);
          return;
        }
        streamRef.current = stream;
        setMic("on");
        if (videoRef.current && stream.getVideoTracks().length) {
          videoRef.current.srcObject = stream;
          void videoRef.current.play().catch(() => undefined);
        }
      })
      .catch(() => {
        if (!dead) setMic("off");
      });
    return () => {
      dead = true;
      window.clearTimeout(wait);
      stopStream(streamRef.current);
    };
  }, [audioOnly]);

  useEffect(() => {
    if (phase !== "live") return;
    const id = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [phase]);

  useEffect(() => {
    streamRef.current?.getAudioTracks().forEach((track) => {
      track.enabled = !muted;
    });
  }, [muted]);

  if (!person) return null;
  const bars = audioOnly ? 1 : 4;

  function hangup() {
    stopStream(streamRef.current);
    useYooyyaa.getState().addCall({
      id: crypto.randomUUID(),
      contactId,
      at: Date.now(),
      video: !audioOnly,
      audioOnly,
    });
    go({ name: "calls" });
  }

  return (
    <div className="flex h-full flex-col px-5 py-6">
      <p className="text-xs font-semibold tracking-widest text-gold uppercase">{t(lang, "encryptedNote")}</p>
      <div className="flex flex-1 flex-col items-center justify-center text-center">
        <Avatar name={person.name} />
        <h2 className="mt-4 font-display text-3xl text-balance">{person.name}</h2>
        <p className="mt-2 text-sm text-muted">{phase === "live" ? t(lang, "connected") : t(lang, "calling")}</p>
        <p className="mt-2 text-2xl tabular-nums">{clock(seconds)}</p>
        <div className="mt-4 flex items-end gap-1" aria-hidden="true">
          {["h-2", "h-3", "h-4", "h-6"].map((height, i) => (
            <span key={height} className={`w-1.5 rounded-sm ${height} ${i < bars ? "bg-gold" : "bg-line"}`} />
          ))}
        </div>
        {audioOnly ? (
          <p className="mt-4 max-w-xs text-sm text-pretty text-muted">
            <VideoOff className="mr-1 inline size-4" />
            {dataSaver ? t(lang, "dataSaverCall") : t(lang, "audioOnly")}
          </p>
        ) : null}
        {mic === "off" ? <p className="mt-3 max-w-xs text-sm text-muted">{t(lang, "micOff")}</p> : null}
      </div>
      {!audioOnly ? (
        <video ref={videoRef} className="mb-4 ml-auto aspect-square w-28 rounded-xl bg-ink object-cover" playsInline muted />
      ) : (
        <video ref={videoRef} className="hidden" playsInline muted />
      )}
      <div className="grid grid-cols-2 gap-2">
        <button type="button" className={ghostBtn} onClick={() => setMuted((v) => !v)}>
          {muted ? t(lang, "unmute") : t(lang, "mute")}
        </button>
        <button type="button" className={goldBtn} onClick={hangup}>
          {t(lang, "endCall")}
        </button>
      </div>
    </div>
  );
}
