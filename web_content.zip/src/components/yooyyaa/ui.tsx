import type { ReactNode } from "react";
import { ChevronLeft } from "lucide-react";
import { initials } from "@/lib/yooyyaa/people";

export const goldBtn =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-gold px-4 text-sm font-semibold text-ink disabled:opacity-50";
export const ghostBtn =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 text-sm font-medium text-fg disabled:opacity-50";
export const fieldCls =
  "min-h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm text-fg outline-none focus:border-gold";

export function Avatar({
  name,
  online,
  src,
}: {
  name: string;
  online?: boolean;
  src?: string;
}) {
  return (
    <div className="relative grid size-11 shrink-0 place-items-center overflow-hidden rounded-full bg-surface-2 text-sm font-semibold text-gold">
      {src ? <img src={src} alt="" className="size-full object-cover" /> : initials(name)}
      {online === undefined ? null : (
        <span className={`absolute right-0 bottom-0 size-3 rounded-full ring-2 ring-bg ${online ? "bg-gold" : "bg-line"}`} />
      )}
    </div>
  );
}

export function ScreenScroll({ children }: { children: ReactNode }) {
  return <div className="h-full overflow-y-auto px-4 py-5">{children}</div>;
}

export function BackBar({ label, onBack }: { label: string; onBack: () => void }) {
  return (
    <button type="button" className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm text-muted" onClick={onBack}>
      <ChevronLeft className="size-4" />
      {label}
    </button>
  );
}
