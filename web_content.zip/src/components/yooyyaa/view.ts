export type View =
  | { name: "lang" }
  | { name: "scan" }
  | { name: "selfie"; personName: string; idHash: string }
  | { name: "chats" }
  | { name: "thread"; id: string }
  | { name: "people" }
  | { name: "calls" }
  | { name: "live"; id: string }
  | { name: "settings" }
  | { name: "share" }
  | { name: "verify"; id: string }
  | { name: "admin" }
  | { name: "suspended" };
