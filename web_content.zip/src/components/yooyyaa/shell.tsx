import { useEffect, useRef, useState, type ReactNode } from "react";
import { Lock, MessageCircle, Phone, Settings, Shield, Signal, Users } from "lucide-react";
import { CallsScreen, ChatsScreen, LiveCall, PeopleScreen, ThreadScreen } from "@/components/yooyyaa/talk";
import { AdminScreen, SettingsScreen, ShareScreen, SuspendedScreen, VerifyScreen } from "@/components/yooyyaa/desk";
import { Mark } from "@/components/yooyyaa/mark";
import { goldBtn, ghostBtn, ScreenScroll } from "@/components/yooyyaa/ui";
import type { View } from "@/components/yooyyaa/view";
import { idKey, type Payload } from "@/lib/yooyyaa/crypto";
import { t, type Key, type Lang } from "@/lib/yooyyaa/i18n";
import { frameToJpeg, monogramSeal, sampleLuma, stopStream } from "@/lib/yooyyaa/media";
import { activeAds, useYooyyaa, type Account, type Ad } from "@/lib/yooyyaa/store";
import { loadPlain, loadSelfie, openAccount, type LinkState } from "@/lib/yooyyaa/vault-actions";

const CARDS = [
  { id: "fayda", kind: "fayda" as const, personName: "Tigist Alemu", number: "FYD-2048-7715" },
  { id: "passport", kind: "passport" as const, personName: "Gemechu Bekele", number: "EP8841203" },
  { id: "kebele", kind: "kebele" as const, personName: "Chaltu Daba", number: "KB-OR-11842" },
];

function startView(account: Account | null): View {
  if (!account) return { name: "lang" };
  if (account.suspended) return { name: "suspended" };
  return { name: "chats" };
}

export function Shell() {
  const lang = useYooyyaa((s) => s.lang);
  const account = useYooyyaa((s) => s.account);
  const messages = useYooyyaa((s) => s.messages);
  const dataSaver = useYooyyaa((s) => s.dataSaver);
  const linkMode = useYooyyaa((s) => s.linkMode);
  const ads = useYooyyaa((s) => s.ads);
  const verified = useYooyyaa((s) => s.verified);
  const suspendedContacts = useYooyyaa((s) => s.suspendedContacts);
  const callLog = useYooyyaa((s) => s.callLog);
  const [view, setView] = useState<View>(() => startView(useYooyyaa.getState().account));
  const [online, setOnline] = useState(true);
  const [plain, setPlain] = useState<Record<string, Payload>>({});
  const [selfie, setSelfie] = useState("");
  const [note, setNote] = useState<string | null>(null);
  const [flushing, setFlushing] = useState(false);
  const seenAds = useRef(new Set<string>());
  const primed = useRef(false);

  const link: LinkState = !online || linkMode === "offline" ? "offline" : linkMode === "weak" ? "weak" : "online";
  const liveAds = activeAds(ads);
  const banner = liveAds[0];

  useEffect(() => {
    const sync = () => setOnline(navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
    };
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang === "am" ? "am" : lang === "om" ? "om" : "en";
  }, [lang]);

  useEffect(() => {
    if (!account) {
      setPlain({});
      setSelfie("");
      return;
    }
    let dead = false;
    void (async () => {
      const map = await loadPlain(messages, account.idHash);
      const face = await loadSelfie(account.selfieCipher, account.selfieIv, account.idHash);
      if (!dead) {
        setPlain(map);
        setSelfie(face);
      }
    })();
    return () => {
      dead = true;
    };
  }, [account, messages]);

  useEffect(() => {
    if (!account && view.name !== "lang" && view.name !== "scan" && view.name !== "selfie") {
      setView({ name: "lang" });
    }
  }, [account, view.name]);

  useEffect(() => {
    if (account?.suspended && view.name !== "admin" && view.name !== "suspended") {
      setView({ name: "suspended" });
    }
  }, [account, view.name]);

  useEffect(() => {
    if (link === "offline") return;
    if (!messages.some((m) => m.status === "queued")) return;
    setFlushing(true);
    const id = window.setTimeout(() => {
      useYooyyaa.getState().markQueuedSent();
      setFlushing(false);
      setNote(t(lang, "flushNote"));
    }, 800);
    return () => window.clearTimeout(id);
  }, [link, messages, lang]);

  useEffect(() => {
    if (!primed.current) {
      liveAds.forEach((ad) => seenAds.current.add(ad.id));
      primed.current = true;
      return;
    }
    for (const ad of liveAds) {
      if (!seenAds.current.has(ad.id)) {
        seenAds.current.add(ad.id);
        setNote(t(lang, "newNotice"));
      }
    }
  }, [liveAds, lang]);

  const showNav =
    !!account &&
    !account.suspended &&
    (view.name === "chats" || view.name === "people" || view.name === "calls" || view.name === "settings");

  const pathLabel =
    link === "offline"
      ? t(lang, "offlineNow")
      : link === "weak"
        ? t(lang, "weakNow")
        : t(lang, "autoOnline");

  return (
    <div className="bg-bg text-fg lg:flex lg:h-dvh">
      <aside className="hidden h-dvh flex-1 flex-col justify-between overflow-y-auto border-r border-line px-12 py-12 lg:flex">
        <div className="max-w-md">
          <Mark className="size-14" />
          <h1 className="mt-8 font-display text-5xl text-balance">YOOYYAA</h1>
          <p className="mt-4 max-w-sm text-lg text-pretty text-muted">{t(lang, "tagline")}</p>
          <ul className="mt-10 space-y-5 text-sm leading-6">
            <Rail icon={<Shield className="size-5 text-gold" />} text={t(lang, "principleScan")} />
            <Rail icon={<Lock className="size-5 text-gold" />} text={t(lang, "principleLock")} />
            <Rail icon={<Signal className="size-5 text-gold" />} text={t(lang, "principleQueue")} />
          </ul>
        </div>
        <p className="text-sm text-muted">
          {t(lang, "pathNow")}: {pathLabel}
        </p>
      </aside>
      <section className="mx-auto flex h-dvh w-full max-w-lg flex-col lg:mx-0 lg:w-96 lg:max-w-none lg:shrink-0">
        {banner && showNav ? <AdBanner ad={banner} lang={lang} /> : null}
        {link === "offline" && showNav ? <Strip>{t(lang, "offlineBanner")}</Strip> : null}
        {link === "weak" && showNav ? <Strip>{t(lang, "weakBanner")}</Strip> : null}
        {flushing && showNav ? <Strip>{t(lang, "resending")}</Strip> : null}
        <div className="min-h-0 flex-1 overflow-hidden">
          {view.name === "lang" ? <LanguageScreen go={setView} /> : null}
          {view.name === "scan" ? <ScanScreen lang={lang} go={setView} /> : null}
          {view.name === "selfie" ? (
            <SelfieScreen lang={lang} personName={view.personName} idHash={view.idHash} go={setView} />
          ) : null}
          {view.name === "chats" ? <ChatsScreen lang={lang} messages={messages} plain={plain} go={setView} /> : null}
          {view.name === "thread" ? (
            <ThreadScreen
              lang={lang}
              contactId={view.id}
              link={link}
              dataSaver={dataSaver}
              messages={messages}
              plain={plain}
              suspended={suspendedContacts.includes(view.id)}
              verified={verified.includes(view.id)}
              go={setView}
              toast={setNote}
            />
          ) : null}
          {view.name === "people" ? (
            <PeopleScreen lang={lang} verified={verified} suspendedContacts={suspendedContacts} link={link} go={setView} toast={setNote} />
          ) : null}
          {view.name === "calls" ? <CallsScreen lang={lang} callLog={callLog} link={link} go={setView} toast={setNote} /> : null}
          {view.name === "live" ? (
            <LiveCall lang={lang} contactId={view.id} link={link} dataSaver={dataSaver} go={setView} />
          ) : null}
          {view.name === "settings" ? (
            <SettingsScreen lang={lang} account={account} selfie={selfie} go={setView} toast={setNote} />
          ) : null}
          {view.name === "share" ? <ShareScreen lang={lang} go={setView} toast={setNote} /> : null}
          {view.name === "verify" ? (
            <VerifyScreen lang={lang} contactId={view.id} idHash={account?.idHash ?? ""} verified={verified.includes(view.id)} go={setView} />
          ) : null}
          {view.name === "admin" ? <AdminScreen lang={lang} go={setView} toast={setNote} /> : null}
          {view.name === "suspended" ? <SuspendedScreen lang={lang} go={setView} /> : null}
        </div>
        {showNav ? <TabBar lang={lang} view={view.name} go={setView} /> : null}
        {note ? (
          <div className="fixed inset-x-4 bottom-24 z-20 mx-auto max-w-sm">
            <button
              type="button"
              className="flex min-h-11 w-full items-center justify-between gap-3 rounded-xl border border-line bg-surface px-4 text-left text-sm"
              onClick={() => setNote(null)}
            >
              <span>{note}</span>
              <span className="text-muted">{t(lang, "dismiss")}</span>
            </button>
          </div>
        ) : null}
      </section>
    </div>
  );
}

function Rail({ icon, text }: { icon: ReactNode; text: string }) {
  return (
    <li className="flex gap-3">
      <span className="mt-0.5 shrink-0">{icon}</span>
      <span className="text-pretty">{text}</span>
    </li>
  );
}

function Strip({ children }: { children: ReactNode }) {
  return <p className="border-b border-line bg-surface px-4 py-2 text-xs text-muted">{children}</p>;
}

function AdBanner({ ad, lang }: { ad: Ad; lang: Lang }) {
  return (
    <div className="border-b border-line bg-surface px-4 py-3">
      <p className="text-xs font-semibold tracking-wide text-gold uppercase">{t(lang, "fromOperator")}</p>
      <p className="mt-1 font-display text-lg text-balance">{ad.title}</p>
      <p className="mt-1 text-sm text-pretty text-muted">{ad.text}</p>
      {ad.image ? <img src={ad.image} alt="" className="mt-3 max-h-36 w-full rounded-xl object-cover" /> : null}
      {ad.link ? (
        <a className="mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-gold" href={ad.link} target="_blank" rel="noreferrer">
          {t(lang, "openLink")}
        </a>
      ) : null}
    </div>
  );
}

function TabBar({ lang, view, go }: { lang: Lang; view: View["name"]; go: (view: View) => void }) {
  const items: { name: "chats" | "people" | "calls" | "settings"; label: Key; icon: ReactNode }[] = [
    { name: "chats", label: "chats", icon: <MessageCircle className="size-5" /> },
    { name: "people", label: "people", icon: <Users className="size-5" /> },
    { name: "calls", label: "calls", icon: <Phone className="size-5" /> },
    { name: "settings", label: "settings", icon: <Settings className="size-5" /> },
  ];
  return (
    <nav className="grid grid-cols-4 border-t border-line bg-bg">
      {items.map((item) => {
        const on = view === item.name;
        return (
          <button
            key={item.name}
            type="button"
            aria-current={on ? "page" : undefined}
            className={`flex min-h-16 flex-col items-center justify-center gap-1 text-xs ${on ? "text-gold" : "text-muted"}`}
            onClick={() => go({ name: item.name })}
          >
            {item.icon}
            {t(lang, item.label)}
          </button>
        );
      })}
    </nav>
  );
}

function LanguageScreen({ go }: { go: (view: View) => void }) {
  const lang = useYooyyaa((s) => s.lang);
  const setLang = useYooyyaa((s) => s.setLang);
  const options: { id: Lang; label: string }[] = [
    { id: "om", label: "Afaan Oromoo" },
    { id: "am", label: "አማርኛ" },
    { id: "en", label: "English" },
  ];
  return (
    <div className="flex h-full flex-col justify-center overflow-y-auto px-5 py-8">
      <div className="lg:hidden">
        <Mark className="size-12" />
        <h1 className="mt-5 font-display text-4xl">YOOYYAA</h1>
        <p className="mt-2 text-pretty text-muted">{t(lang, "tagline")}</p>
      </div>
      <h2 className="mt-8 font-display text-2xl text-balance lg:mt-2">{t(lang, "languageTitle")}</h2>
      <p className="mt-2 text-sm text-pretty text-muted">{t(lang, "languageBody")}</p>
      <div className="mt-5 grid gap-2">
        {options.map((opt) => (
          <button
            key={opt.id}
            type="button"
            aria-pressed={lang === opt.id}
            className={`min-h-12 rounded-xl border px-4 text-left text-base ${lang === opt.id ? "border-gold bg-surface" : "border-line"}`}
            onClick={() => setLang(opt.id)}
          >
            {opt.label}
          </button>
        ))}
      </div>
      <button type="button" className={`${goldBtn} mt-6 w-full`} onClick={() => go({ name: "scan" })}>
        {t(lang, "continue")}
      </button>
      <ul className="mt-8 space-y-3 text-sm text-muted lg:hidden">
        <li>{t(lang, "principleScan")}</li>
        <li>{t(lang, "principleLock")}</li>
        <li>{t(lang, "principleQueue")}</li>
      </ul>
    </div>
  );
}

function ScanScreen({ lang, go }: { lang: Lang; go: (view: View) => void }) {
  const [cardId, setCardId] = useState(CARDS[0]?.id ?? "fayda");
  const [phase, setPhase] = useState<"pick" | "reading" | "done">("pick");
  const [read, setRead] = useState<{ personName: string; idHash: string } | null>(null);
  const [camOn, setCamOn] = useState(false);
  const [camNote, setCamNote] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const card = CARDS.find((c) => c.id === cardId) ?? CARDS[0];

  useEffect(() => () => stopStream(streamRef.current), []);

  async function readCard() {
    if (!card) return;
    setPhase("reading");
    setCamNote(null);
    const hash = await idKey(card.number);
    window.setTimeout(() => {
      setRead({ personName: card.personName, idHash: hash });
      setPhase("done");
    }, 1100);
  }

  async function openCam() {
    setCamNote(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" }, audio: false });
      streamRef.current = stream;
      setCamOn(true);
      window.setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          void videoRef.current.play().catch(() => undefined);
        }
      }, 0);
    } catch {
      setCamNote(t(lang, "noCamera"));
    }
  }

  function closeCam() {
    stopStream(streamRef.current);
    streamRef.current = null;
    setCamOn(false);
  }

  function shoot() {
    const video = videoRef.current;
    if (!video) return;
    const frame = frameToJpeg(video, 640, 0.5);
    void frame;
    closeCam();
    setCamNote(t(lang, "couldNotRead"));
  }

  if (!card) return null;

  return (
    <ScreenScroll>
      <h2 className="font-display text-3xl text-balance">{t(lang, "scanTitle")}</h2>
      <p className="mt-2 text-sm text-pretty text-muted">{t(lang, "scanBody")}</p>
      <div className="relative mt-5 overflow-hidden rounded-2xl border border-line bg-surface p-4">
        <p className="text-xs font-semibold tracking-widest text-gold uppercase">{t(lang, "practice")}</p>
        <p className="mt-3 text-xs text-muted">{t(lang, card.kind)}</p>
        <p className="mt-1 font-display text-2xl text-balance">{phase === "done" && read ? read.personName : card.personName}</p>
        <p className="mt-4 text-xs text-muted">{phase === "done" ? t(lang, "numberGone") : t(lang, "practiceNote")}</p>
        {phase === "reading" ? <div className="scan-line mt-4 h-0.5 w-full bg-gold" /> : null}
      </div>
      {phase !== "done" ? (
        <>
          <div className="mt-4 grid gap-2">
            {CARDS.map((item) => (
              <button
                key={item.id}
                type="button"
                aria-pressed={item.id === card.id}
                className={`min-h-11 rounded-xl border px-3 text-left text-sm ${item.id === card.id ? "border-gold" : "border-line"}`}
                onClick={() => setCardId(item.id)}
              >
                {t(lang, item.kind)}
              </button>
            ))}
          </div>
          <button type="button" className={`${goldBtn} mt-4 w-full`} disabled={phase === "reading"} onClick={() => void readCard()}>
            {phase === "reading" ? t(lang, "reading") : t(lang, "readCard")}
          </button>
          {camOn ? (
            <div className="mt-4">
              <video ref={videoRef} className="aspect-video w-full rounded-xl bg-ink object-cover" playsInline muted />
              <p className="mt-2 text-xs text-muted">{t(lang, "holdCard")}</p>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button type="button" className={goldBtn} onClick={shoot}>
                  {t(lang, "captured")}
                </button>
                <button type="button" className={ghostBtn} onClick={closeCam}>
                  {t(lang, "closeCamera")}
                </button>
              </div>
            </div>
          ) : (
            <button type="button" className={`${ghostBtn} mt-2 w-full`} onClick={() => void openCam()}>
              {t(lang, "openCamera")}
            </button>
          )}
          {camNote ? <p className="mt-3 text-sm text-muted">{camNote}</p> : null}
        </>
      ) : (
        <div className="mt-5">
          <p className="text-xs font-semibold tracking-wide text-gold uppercase">{t(lang, "nameRead")}</p>
          <p className="mt-1 font-display text-3xl">{read?.personName}</p>
          <p className="mt-2 flex items-center gap-2 text-sm text-muted">
            <Lock className="size-4 text-gold" />
            {t(lang, "nameLocked")}
          </p>
          <button
            type="button"
            className={`${goldBtn} mt-5 w-full`}
            onClick={() => {
              if (read) go({ name: "selfie", personName: read.personName, idHash: read.idHash });
            }}
          >
            {t(lang, "toSelfie")}
          </button>
          <button
            type="button"
            className={`${ghostBtn} mt-2 w-full`}
            onClick={() => {
              setPhase("pick");
              setRead(null);
            }}
          >
            {t(lang, "retake")}
          </button>
        </div>
      )}
    </ScreenScroll>
  );
}

function SelfieScreen({
  lang,
  personName,
  idHash,
  go,
}: {
  lang: Lang;
  personName: string;
  idHash: string;
  go: (view: View) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [status, setStatus] = useState<"starting" | "ready" | "blocked">("starting");
  const [blink, setBlink] = useState(false);
  const [faces, setFaces] = useState<number | null>(null);
  const [shot, setShot] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const baseline = useRef(0);
  const dropped = useRef(0);

  useEffect(() => {
    let dead = false;
    let timer = 0;
    void navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: "user" }, audio: false })
      .then((stream) => {
        if (dead) {
          stopStream(stream);
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          void videoRef.current.play().catch(() => undefined);
        }
        setStatus("ready");
        const Detector = (window as unknown as { FaceDetector?: new (opts?: { fastMode?: boolean; maxDetectedFaces?: number }) => { detect: (src: CanvasImageSource) => Promise<{ boundingBox: DOMRectReadOnly }[]> } }).FaceDetector;
        const detector = Detector ? new Detector({ fastMode: true, maxDetectedFaces: 2 }) : null;
        timer = window.setInterval(() => {
          const video = videoRef.current;
          if (!video || video.readyState < 2) return;
          const luma = sampleLuma(video);
          if (luma !== null) {
            if (!baseline.current) baseline.current = luma;
            baseline.current = baseline.current * 0.92 + luma * 0.08;
            if (luma < baseline.current - 12 && !dropped.current) dropped.current = performance.now();
            if (
              dropped.current &&
              luma > baseline.current - 5 &&
              performance.now() - dropped.current > 50 &&
              performance.now() - dropped.current < 450
            ) {
              setBlink(true);
              dropped.current = 0;
            } else if (dropped.current && performance.now() - dropped.current > 500) {
              dropped.current = 0;
            }
          }
          if (detector) {
            void detector.detect(video).then((found) => {
              if (!dead) setFaces(found.length);
            }).catch(() => undefined);
          }
        }, 140);
      })
      .catch(() => {
        if (!dead) setStatus("blocked");
      });
    return () => {
      dead = true;
      window.clearInterval(timer);
      stopStream(streamRef.current);
    };
  }, []);

  async function keep(image: string) {
    setBusy(true);
    await openAccount({ idHash, personName, selfie: image, lang });
    stopStream(streamRef.current);
    go({ name: "chats" });
  }

  const many = faces !== null && faces > 1;
  const none = faces === 0;

  return (
    <ScreenScroll>
      <h2 className="font-display text-3xl text-balance">{t(lang, "selfieTitle")}</h2>
      <p className="mt-2 text-sm text-pretty text-muted">{t(lang, "selfieBody")}</p>
      <p className="mt-4 font-display text-xl">{personName}</p>
      {status === "ready" ? (
        <>
          <video ref={videoRef} className="mt-4 aspect-square w-full rounded-2xl bg-ink object-cover" playsInline muted />
          <p className="mt-3 text-sm text-muted">
            {many ? t(lang, "oneFace") : none ? t(lang, "lookHere") : blink ? t(lang, "blinkSeen") : t(lang, "blinkPlease")}
          </p>
          <button
            type="button"
            className={`${goldBtn} mt-4 w-full`}
            disabled={!blink || many || busy}
            onClick={() => {
              const image = videoRef.current ? frameToJpeg(videoRef.current, 720, 0.72) : null;
              if (image) void keep(image);
            }}
          >
            {busy ? t(lang, "creating") : t(lang, "capture")}
          </button>
        </>
      ) : null}
      {status === "starting" ? <p className="mt-6 text-sm text-muted">{t(lang, "cameraBusy")}</p> : null}
      {status === "blocked" ? (
        <div className="mt-6">
          <p className="text-sm text-muted">{t(lang, "noCamera")}</p>
          <p className="mt-2 text-sm text-pretty text-muted">{t(lang, "sealNote")}</p>
          <button
            type="button"
            className={`${goldBtn} mt-4 w-full`}
            disabled={busy}
            onClick={() => void keep(monogramSeal(personName))}
          >
            {busy ? t(lang, "creating") : t(lang, "useSeal")}
          </button>
        </div>
      ) : null}
    </ScreenScroll>
  );
}
