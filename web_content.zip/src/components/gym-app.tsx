import type { ReactNode } from "react";
import { addDays, format, startOfWeek } from "date-fns";
import { tr } from "date-fns/locale";
import { Check, Dumbbell, Moon, RotateCcw, Timer } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { RestTimer } from "@/components/rest-timer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { WeekStrip, dateFromKey } from "@/components/week-strip";
import {
  TRAINING_DAYS_PER_WEEK,
  WEEK_RHYTHM,
  formatRest,
  nextTraining,
  sessionForDate,
  sessionVolume,
  type CardioBlock,
  type Exercise,
  type Session,
} from "@/lib/program";
import { useGymStore, type SessionLog } from "@/lib/store";
import { cn, vibrate } from "@/lib/utils";

function todayKey(): string {
  return format(new Date(), "yyyy-MM-dd");
}

function weekDates(anchor: Date): Date[] {
  const start = startOfWeek(anchor, { weekStartsOn: 1 });
  return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}

export function GymApp() {
  const [selectedKey, setSelectedKey] = useState(todayKey);
  const [today, setToday] = useState(todayKey);

  const logs = useGymStore((s) => s.logs);

  useEffect(() => {
    const key = todayKey();
    setToday(key);
    setSelectedKey(key);
    void useGymStore.persist.rehydrate();
  }, []);

  const selected = useMemo(() => dateFromKey(selectedKey), [selectedKey]);
  const days = useMemo(() => weekDates(selected), [selectedKey]);
  const session = useMemo(() => sessionForDate(selected), [selectedKey]);
  const log = logs[selectedKey];
  const isToday = selectedKey === today;

  const weekDone = days.filter((d) => {
    const key = format(d, "yyyy-MM-dd");
    const daySession = sessionForDate(d);
    return daySession.isTraining && logs[key]?.completed;
  }).length;

  return (
    <div className="mx-auto min-h-dvh max-w-md overflow-x-hidden pb-28">
      <header className="sticky top-0 z-20 flex items-end justify-between bg-bg/95 px-4 pb-3 pt-4 backdrop-blur-sm">
        <div>
          <p className="font-display text-2xl leading-none tracking-tight text-fg">SALON</p>
          <p className="mt-1 text-xs text-muted">4 gün · Upper / Lower</p>
        </div>
        <div className="text-right">
          <p className="font-display text-lg tabular-nums leading-none text-fg">
            {weekDone}/{TRAINING_DAYS_PER_WEEK}
          </p>
          <p className="mt-1 text-xs text-muted">bu hafta</p>
        </div>
      </header>

      <main className="px-4">
        <WeekStrip
          days={days}
          selected={selected}
          today={dateFromKey(today)}
          onSelect={(d) => setSelectedKey(format(d, "yyyy-MM-dd"))}
        />

        <Rhythm />

        <SessionHero session={session} date={selected} isToday={isToday} log={log} />

        {session.isTraining ? (
          <TrainingBody dateKey={selectedKey} session={session} log={log} />
        ) : (
          <RestBody from={selected} />
        )}
      </main>

      {session.isTraining ? <SessionDock dateKey={selectedKey} session={session} log={log} /> : null}
      <RestTimer />
    </div>
  );
}

function Rhythm() {
  return (
    <p className="rise-in mt-5 text-center text-xs tracking-wide text-subtle">
      {WEEK_RHYTHM.map((d, i) => (
        <span key={`${d.code}-${i}`}>
          {i > 0 ? <span className="mx-1.5 text-border">→</span> : null}
          <span className={d.code === "OFF" ? "text-subtle" : "text-muted"}>{d.label}</span>
        </span>
      ))}
    </p>
  );
}

function SessionHero({
  session,
  date,
  isToday,
  log,
}: {
  session: Session;
  date: Date;
  isToday: boolean;
  log?: SessionLog;
}) {
  return (
    <section className="rise-in stagger-1 mt-6">
      <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">
        {isToday ? "Bugün" : format(date, "d MMMM", { locale: tr })} · {session.dayName}
      </p>
      <h1 className="font-display text-display mt-2 text-fg uppercase">{session.title}</h1>
      <p className="mt-3 max-w-sm text-sm text-muted">{session.blurb}</p>
      <div className="mt-4 flex flex-wrap gap-2">
        <MetaChip>{session.kicker}</MetaChip>
        {session.isTraining ? <MetaChip>{session.duration}</MetaChip> : <MetaChip>Salon yok</MetaChip>}
        {log?.completed ? <MetaChip accent>Tamamlandı</MetaChip> : null}
      </div>
    </section>
  );
}

function MetaChip({ children, accent = false }: { children: ReactNode; accent?: boolean }) {
  return (
    <span
      className={cn(
        "inline-flex h-8 items-center rounded-full px-3 text-xs font-medium",
        accent ? "bg-accent/15 text-accent" : "bg-surface text-muted shadow-[var(--shadow-border)]",
      )}
    >
      {children}
    </span>
  );
}

function RestBody({ from }: { from: Date }) {
  const next = nextTraining(from);
  const week = weekDates(from);
  return (
    <section className="rise-in stagger-2 mt-8 space-y-4">
      <div className="rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]">
        <div className="flex size-11 items-center justify-center rounded-lg bg-raised text-muted">
          <Moon className="size-5" />
        </div>
        <h2 className="mt-4 font-display text-xl tracking-tight text-fg">Bugün salona gitmiyorsun</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Bu da programın parçası. Protein, uyku, su. İsteğe bağlı kısa yürüyüş — koşu bandına çıkmana gerek yok.
        </p>
      </div>
      <div className="rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]">
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Sıradaki</p>
        <p className="mt-2 font-display text-2xl tracking-tight text-fg">{next.dayName}</p>
        <p className="text-sm text-muted">
          {next.title} · {next.kicker}
        </p>
      </div>
      <div className="rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]">
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Haftalık ritim</p>
        <ul className="mt-3 space-y-2">
          {week.map((d) => {
            const s = sessionForDate(d);
            return (
              <li key={format(d, "yyyy-MM-dd")} className="flex items-center justify-between gap-3 text-sm">
                <span className="text-muted">{s.shortName}</span>
                <span className={cn("truncate", s.isTraining ? "text-fg" : "text-subtle")}>
                  {s.title}
                  {s.cardio ? " + kardiyo" : ""}
                </span>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}

function TrainingBody({ dateKey, session, log }: { dateKey: string; session: Session; log?: SessionLog }) {
  const totalSets = session.exercises.reduce((n, ex) => n + ex.sets, 0) + (session.cardio ? 1 : 0);
  const doneSets =
    (log
      ? session.exercises.reduce((n, ex) => n + (log.sets[ex.id]?.filter((s) => s.done).length ?? 0), 0)
      : 0) + (log?.cardioDone ? 1 : 0);
  const volume = log
    ? session.exercises.reduce((n, ex) => n + sessionVolume(log.sets[ex.id] ?? []), 0)
    : 0;

  return (
    <section className="mt-8 space-y-3">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Hareketler</p>
          <p className="mt-1 text-sm text-subtle tabular-nums">
            {doneSets}/{totalSets} set
            {volume > 0 ? ` · ${Math.round(volume)} kg hacim` : ""}
          </p>
        </div>
        <div className="h-1.5 w-24 overflow-hidden rounded-full bg-raised">
          <div
            className="h-full rounded-full bg-accent transition-[width] duration-200 ease-out"
            style={{ width: `${totalSets === 0 ? 0 : (doneSets / totalSets) * 100}%` }}
          />
        </div>
      </div>

      {session.exercises.map((exercise, i) => (
        <ExerciseCard
          key={exercise.id}
          dateKey={dateKey}
          session={session}
          exercise={exercise}
          log={log}
          index={i}
        />
      ))}

      {session.cardio ? <CardioCard dateKey={dateKey} session={session} cardio={session.cardio} log={log} /> : null}
    </section>
  );
}

function ExerciseCard({
  dateKey,
  session,
  exercise,
  log,
  index,
}: {
  dateKey: string;
  session: Session;
  exercise: Exercise;
  log?: SessionLog;
  index: number;
}) {
  const variants = useGymStore((s) => s.variants);
  const setVariant = useGymStore((s) => s.setVariant);
  const updateSet = useGymStore((s) => s.updateSet);
  const lastWeight = useGymStore((s) => s.lastWeight[exercise.id]);
  const variantIndex = variants[exercise.id] ?? 0;
  const name = exercise.variants?.[variantIndex] ?? exercise.name;
  const sets = log?.sets[exercise.id];
  const doneCount = sets?.filter((s) => s.done).length ?? 0;

  return (
    <article
      className={cn("rise-in rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]", `stagger-${Math.min(index + 2, 8)}`)}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs tabular-nums text-subtle">{String(index + 1).padStart(2, "0")}</p>
          <h3 className="mt-1 font-display text-lg leading-tight tracking-tight text-fg">{name}</h3>
          <p className="mt-1 text-xs text-muted">
            {exercise.sets} × {exercise.reps}
            {exercise.perSide ? " / bacak" : ""}
            <span className="mx-1.5 text-border">·</span>
            {exercise.target}
            <span className="mx-1.5 text-border">·</span>
            {formatRest(exercise.restSec)} dinlenme
          </p>
        </div>
        <span className="pt-1 text-xs tabular-nums text-muted">
          {doneCount}/{exercise.sets}
        </span>
      </div>

      {exercise.variants ? (
        <div className="mt-3 grid grid-cols-2 gap-1 rounded-xl bg-raised p-1">
          {exercise.variants.map((label, i) => (
            <button
              key={label}
              type="button"
              onClick={() => setVariant(exercise.id, i)}
              className={cn(
                "h-9 rounded-lg text-xs font-medium transition-colors duration-150",
                variantIndex === i ? "bg-surface text-fg shadow-[var(--shadow-border)]" : "text-muted",
              )}
            >
              {label}
            </button>
          ))}
        </div>
      ) : null}

      {lastWeight && !sets?.some((s) => s.weight) ? (
        <p className="mt-3 text-xs text-subtle">Son: {lastWeight} kg</p>
      ) : null}

      <ol className="mt-3 space-y-2">
        {Array.from({ length: exercise.sets }, (_, setIndex) => {
          const row = sets?.[setIndex] ?? { weight: lastWeight ?? "", reps: "", done: false };
          return (
            <li key={setIndex} className="grid grid-cols-[2rem_1fr_1fr_2.75rem] items-center gap-2">
              <span className="text-center text-xs tabular-nums text-subtle">{setIndex + 1}</span>
              <label className="sr-only" htmlFor={`${exercise.id}-${setIndex}-kg`}>
                {name} set {setIndex + 1} kilo
              </label>
              <Input
                id={`${exercise.id}-${setIndex}-kg`}
                inputMode="decimal"
                placeholder="kg"
                value={row.weight}
                onChange={(e) => updateSet(dateKey, session, exercise.id, setIndex, { weight: e.target.value })}
              />
              <label className="sr-only" htmlFor={`${exercise.id}-${setIndex}-reps`}>
                {name} set {setIndex + 1} tekrar
              </label>
              <Input
                id={`${exercise.id}-${setIndex}-reps`}
                inputMode="numeric"
                placeholder="tek."
                value={row.reps}
                onChange={(e) => updateSet(dateKey, session, exercise.id, setIndex, { reps: e.target.value })}
              />
              <button
                type="button"
                aria-label={`Set ${setIndex + 1} tamamlandı`}
                aria-pressed={row.done}
                onClick={() => {
                  vibrate(row.done ? 8 : 18);
                  updateSet(dateKey, session, exercise.id, setIndex, { done: !row.done });
                }}
                className={cn(
                  "flex size-11 items-center justify-center rounded-lg transition-colors duration-150",
                  row.done ? "bg-accent text-primary-fg" : "bg-raised text-subtle shadow-[var(--shadow-border)]",
                )}
              >
                <Check className="size-4" strokeWidth={2.5} />
              </button>
            </li>
          );
        })}
      </ol>
    </article>
  );
}

function CardioCard({
  dateKey,
  session,
  cardio,
  log,
}: {
  dateKey: string;
  session: Session;
  cardio: CardioBlock;
  log?: SessionLog;
}) {
  const toggleCardio = useGymStore((s) => s.toggleCardio);
  const done = Boolean(log?.cardioDone);
  const ticks = Array.from({ length: cardio.inclineMax }, (_, i) => i + 1);

  return (
    <article className="rise-in stagger-8 rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Kardiyo</p>
          <h3 className="mt-1 font-display text-lg tracking-tight text-fg">Treadmill</h3>
          <p className="mt-1 text-xs text-muted">
            {cardio.duration} · {cardio.speed} · eğim {cardio.incline}
          </p>
        </div>
        <button
          type="button"
          aria-label="Kardiyo tamamlandı"
          aria-pressed={done}
          onClick={() => {
            vibrate(done ? 8 : 18);
            toggleCardio(dateKey, session);
          }}
          className={cn(
            "flex size-11 shrink-0 items-center justify-center rounded-lg transition-colors duration-150",
            done ? "bg-accent text-primary-fg" : "bg-raised text-subtle shadow-[var(--shadow-border)]",
          )}
        >
          <Check className="size-4" strokeWidth={2.5} />
        </button>
      </div>

      <div className="mt-4">
        <p className="mb-2 text-xs text-subtle">Eğim skalası (1–{cardio.inclineMax})</p>
        <div className="grid grid-cols-12 gap-1">
          {ticks.map((n) => {
            const active = n >= cardio.inclineRange[0] && n <= cardio.inclineRange[1];
            return (
              <div key={n} className="flex flex-col items-center gap-1">
                <div className={cn("h-7 w-full rounded-sm", active ? "bg-primary" : "bg-raised")} />
                <span className={cn("h-3 text-xs tabular-nums", active ? "text-fg" : "text-subtle")}>
                  {n === 1 || n === cardio.inclineRange[0] || n === cardio.inclineRange[1] || n === cardio.inclineMax
                    ? n
                    : ""}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <p className="mt-4 text-sm leading-relaxed text-muted">{cardio.note}</p>
    </article>
  );
}

function SessionDock({ dateKey, session, log }: { dateKey: string; session: Session; log?: SessionLog }) {
  const startSession = useGymStore((s) => s.startSession);
  const completeSession = useGymStore((s) => s.completeSession);
  const resetSession = useGymStore((s) => s.resetSession);

  const started = Boolean(log?.active || log?.completed);
  const completed = Boolean(log?.completed);

  return (
    <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border/80 bg-bg/95 px-4 pt-3 pb-3 backdrop-blur-sm">
      <div className="mx-auto flex max-w-md items-center gap-2">
        {completed ? (
          <>
            <Button type="button" variant="secondary" className="flex-1" onClick={() => resetSession(dateKey, session)}>
              <RotateCcw className="size-4" />
              Sıfırla
            </Button>
            <p className="flex flex-1 items-center justify-center gap-2 text-sm text-accent">
              <Check className="size-4" />
              Seans bitti
            </p>
          </>
        ) : started ? (
          <>
            <Button type="button" variant="ghost" size="icon" aria-label="Seansı sıfırla" onClick={() => resetSession(dateKey, session)}>
              <RotateCcw className="size-4" />
            </Button>
            <Button type="button" size="lg" className="flex-1" onClick={() => completeSession(dateKey)}>
              <Dumbbell className="size-4" />
              Antrenmanı bitir
            </Button>
          </>
        ) : (
          <Button type="button" size="lg" onClick={() => startSession(dateKey, session)}>
            <Timer className="size-4" />
            Antrenmana başla
          </Button>
        )}
      </div>
    </div>
  );
}
