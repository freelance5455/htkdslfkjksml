import React, { useState } from 'react';
import { X, Music, Check, Sparkles } from 'lucide-react';
import { FEATURED_TRACKS } from '../data/spiritualData';
import { offlineCache } from '../lib/offlineCache';

interface CustomPlaylistModalProps {
  onClose: () => void;
  onCreated: () => void;
}

export const CustomPlaylistModal: React.FC<CustomPlaylistModalProps> = ({
  onClose,
  onCreated,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [themeCategory, setThemeCategory] = useState<'Morning Praise' | 'Evening Reflection' | 'Intense Worship' | 'Soaking Meditation' | 'Warfare & Deliverance'>('Morning Praise');
  const [selectedTrackIds, setSelectedTrackIds] = useState<string[]>(['trk-1']);
  const [coverImage, setCoverImage] = useState(
    'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80'
  );

  const toggleTrack = (id: string) => {
    if (selectedTrackIds.includes(id)) {
      if (selectedTrackIds.length > 1) {
        setSelectedTrackIds(selectedTrackIds.filter((tId) => tId !== id));
      }
    } else {
      setSelectedTrackIds([...selectedTrackIds, id]);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    offlineCache.createCustomPlaylist({
      title,
      description: description || 'Anointed curated worship playlist by Prophet JUHNKRIX SYNVAGORD.',
      themeCategory,
      trackIds: selectedTrackIds,
      coverImage,
    });

    onCreated();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-3xl text-amber-100 flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-amber-500/20">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-400/30 text-amber-300">
              <Sparkles className="w-4 h-4 text-amber-400" />
            </div>
            <h3 className="text-lg font-bold font-serif text-amber-100">
              Create Anointed Custom Playlist
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-900 text-slate-300 hover:text-amber-300 border border-amber-500/20"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-4 pt-4">
          {/* Auto-Generate Playlist Moods */}
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-amber-500/20 space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 flex items-center space-x-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Auto-Generate Playlist by Prophetic Mood / Session</span>
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => {
                  setTitle('Morning Glory Awakening');
                  setThemeCategory('Morning Praise');
                  setDescription('Anointed morning praise and soaking tracks curated by Prophet JUHNKRIX for daily breakthrough.');
                  setSelectedTrackIds(FEATURED_TRACKS.slice(0, 3).map(t => t.id));
                }}
                className="px-2.5 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-200 border border-amber-500/30 text-[10px] font-bold text-center transition-all"
              >
                🌅 Morning Awakening
              </button>
              <button
                type="button"
                onClick={() => {
                  setTitle('528Hz Prophetic Soaking');
                  setThemeCategory('Soaking Meditation');
                  setDescription('Deep instrumental soaking and healing frequencies for intimate prayer and meditation.');
                  setSelectedTrackIds(FEATURED_TRACKS.filter(t => t.category === 'Soaking Meditation' || t.category === 'Prophetic Chants').map(t => t.id).slice(0, 3) || ['trk-1']);
                }}
                className="px-2.5 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-200 border border-amber-500/30 text-[10px] font-bold text-center transition-all"
              >
                🕊️ Deep Soaking
              </button>
              <button
                type="button"
                onClick={() => {
                  setTitle('Warfare & Deliverance Fire');
                  setThemeCategory('Warfare & Deliverance');
                  setDescription('Aggressive spiritual warfare chants and deliverance anthems.');
                  setSelectedTrackIds(FEATURED_TRACKS.filter(t => t.category === 'Deliverance & Power' || t.category === 'High Praise').map(t => t.id).slice(0, 3) || ['trk-1']);
                }}
                className="px-2.5 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-200 border border-amber-500/30 text-[10px] font-bold text-center transition-all"
              >
                🔥 Warfare Fire
              </button>
              <button
                type="button"
                onClick={() => {
                  setTitle('Divine Healing Sanctuary');
                  setThemeCategory('Intense Worship');
                  setDescription('Worship anthems focused on supernatural healing, deliverance, and restoration.');
                  setSelectedTrackIds(FEATURED_TRACKS.slice(1, 4).map(t => t.id));
                }}
                className="px-2.5 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-200 border border-amber-500/30 text-[10px] font-bold text-center transition-all"
              >
                ✨ Divine Healing
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
              Playlist Title
            </label>
            <input
              type="text"
              required
              placeholder="e.g., Midnight Prophetic Soaking"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-2.5 text-xs text-amber-100 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
              Theme Category
            </label>
            <select
              value={themeCategory}
              onChange={(e: any) => setThemeCategory(e.target.value)}
              className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-2.5 text-xs text-amber-100 focus:outline-none focus:border-amber-400"
            >
              <option value="Morning Praise">Morning Praise</option>
              <option value="Evening Reflection">Evening Reflection</option>
              <option value="Intense Worship">Intense Worship</option>
              <option value="Soaking Meditation">Soaking Meditation</option>
              <option value="Warfare & Deliverance">Warfare & Deliverance</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
              Description / Intention
            </label>
            <textarea
              rows={2}
              placeholder="Describe the spiritual intention of this playlist..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl px-4 py-2 text-xs text-amber-100 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-amber-400 mb-2">
              Select Worship Tracks ({selectedTrackIds.length} selected)
            </label>
            <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
              {FEATURED_TRACKS.map((trk) => {
                const isSelected = selectedTrackIds.includes(trk.id);
                return (
                  <div
                    key={trk.id}
                    onClick={() => toggleTrack(trk.id)}
                    className={`p-2.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-400 text-amber-100'
                        : 'bg-slate-950/60 border-amber-500/10 text-slate-400 hover:border-amber-500/30'
                    }`}
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <img
                        src={trk.albumArt}
                        alt={trk.title}
                        className="w-8 h-8 rounded-lg object-cover"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-bold truncate">{trk.title}</p>
                        <p className="text-[10px] opacity-70">{trk.category}</p>
                      </div>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-amber-400 flex-shrink-0" />}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 text-slate-950 font-bold text-xs shadow-xl shadow-amber-500/30 hover:scale-[1.02] active:scale-95 transition-all"
            >
              Save Playlist to Sanctuary Profile
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
