import React from 'react';
import { Lock, CheckCircle2, Play, Circle, Trophy, Star } from 'lucide-react';
import { PlayerProgress, StageProgress } from '../types/crossword';
import { convertToArabicNumerals, STAGES_DATABASE } from '../data/sampleStages';
import { soundManager } from '../utils/audio';

interface StagesScreenProps {
  progress: PlayerProgress;
  onSelectStage: (stageId: number) => void;
}

export const StagesScreen: React.FC<StagesScreenProps> = ({
  progress,
  onSelectStage,
}) => {
  // Calculate total completed questions and total stars earned
  let totalCompletedQuestions = 0;
  let totalStarsEarned = 0;
  Object.values(progress.stageProgresses).forEach((stageProg) => {
    const sp = stageProg as StageProgress;
    totalCompletedQuestions += sp?.completedQuestionIds?.length || 0;
    if (sp?.completed && sp?.bestStars !== undefined) {
      totalStarsEarned += sp.bestStars;
    }
  });

  const totalQuestions = 1250; // 50 * 25
  const maxPossibleStars = 150; // 50 * 3

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-5 max-w-xl mx-auto w-full overflow-y-auto">
      {/* Newspaper Overall Progress Card */}
      <div className="bg-[#f8f4ed] border-2 border-[#2c2c2c] newspaper-border-double p-3 sm:p-4 mb-4 shadow-xs text-center">
        <div className="flex items-center justify-center gap-2 mb-1 text-[#2c2c2c]">
          <Trophy className="w-5 h-5" />
          <h2 className="newspaper-font text-lg sm:text-xl font-bold">التقدم والنجوم الكلية</h2>
        </div>
        <div className="flex items-center justify-center gap-4 sm:gap-6 my-2">
          {/* Questions Progress */}
          <div className="text-center">
            <div className="text-xs text-[#2c2c2c]/80 font-semibold mb-0.5">الأسئلة المحلولة</div>
            <div className="flex items-center justify-center gap-1 text-xl sm:text-2xl font-black text-[#1a1a1a]">
              <span>{convertToArabicNumerals(totalCompletedQuestions)}</span>
              <span className="text-sm text-[#2c2c2c]/70 font-normal">/</span>
              <span className="text-base text-[#2c2c2c]/70 font-normal">{convertToArabicNumerals(totalQuestions)}</span>
            </div>
          </div>

          <div className="h-8 w-px bg-[#2c2c2c]/20" />

          {/* Stars Earned */}
          <div className="text-center">
            <div className="text-xs text-[#2c2c2c]/80 font-semibold mb-0.5 flex items-center justify-center gap-1">
              <Star className="w-3.5 h-3.5 fill-[#d97706] text-[#b45309]" />
              <span>النجوم المحققة</span>
            </div>
            <div className="flex items-center justify-center gap-1 text-xl sm:text-2xl font-black text-[#1a1a1a]">
              <span>{convertToArabicNumerals(totalStarsEarned)}</span>
              <span className="text-sm text-[#2c2c2c]/70 font-normal">/</span>
              <span className="text-base text-[#2c2c2c]/70 font-normal">{convertToArabicNumerals(maxPossibleStars)}</span>
            </div>
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-[#ede9e1] h-2.5 rounded-full overflow-hidden border border-[#2c2c2c]/40 mt-2">
          <div
            className="bg-[#1a1a1a] h-full transition-all duration-300"
            style={{ width: `${Math.min(100, (totalCompletedQuestions / totalQuestions) * 100)}%` }}
          />
        </div>
      </div>

      {/* List of 50 Stages - One Stage Per Line */}
      <div className="flex flex-col gap-2.5 pb-6">
        {STAGES_DATABASE.map((stage) => {
          const isUnlocked = stage.id <= progress.unlockedStageId;
          const stageProg = progress.stageProgresses[stage.id];
          const isCompleted = stageProg?.completed || false;
          const completedCount = stageProg?.completedQuestionIds?.length || 0;
          const isInProgress = isUnlocked && !isCompleted && completedCount > 0;
          const bestStars = stageProg?.bestStars;

          // Determine badge state
          let statusLabel = 'مغلقة';
          let statusBg = 'bg-[#ede9e1] text-[#2c2c2c]/60 border-[#2c2c2c]/30';

          if (isCompleted) {
            statusLabel = 'مكتملة';
            statusBg = 'bg-[#dfebd9] text-[#1c4d1f] border-[#2c2c2c]';
          } else if (isInProgress) {
            statusLabel = 'قيد الحل';
            statusBg = 'bg-[#e6d5b8] text-[#1a1a1a] border-[#2c2c2c]';
          } else if (isUnlocked) {
            statusLabel = 'متاحة';
            statusBg = 'bg-[#fdfbf7] text-[#1a1a1a] border-[#2c2c2c]';
          }

          return (
            <button
              key={stage.id}
              type="button"
              disabled={!isUnlocked}
              onClick={() => {
                soundManager.playButtonClick();
                onSelectStage(stage.id);
              }}
              className={`w-full flex items-center justify-between p-3 sm:px-4 sm:py-3.5 rounded-xs border text-right transition-all touch-manipulation gap-3 ${
                isUnlocked
                  ? 'hover:bg-[#e6d5b8] active:bg-[#2c2c2c] active:text-[#fdfbf7] shadow-2xs cursor-pointer'
                  : 'opacity-65 cursor-not-allowed'
              } ${statusBg}`}
            >
              {/* Right Side: Status Icon + Stage Title & Questions Progress */}
              <div className="flex items-center gap-3 min-w-0 flex-1">
                {/* Status Indicator Icon */}
                <div className="shrink-0 flex items-center justify-center">
                  {isCompleted ? (
                    <CheckCircle2 className="w-5 h-5 text-[#1c4d1f]" />
                  ) : !isUnlocked ? (
                    <Lock className="w-4 h-4 text-[#2c2c2c]/60" />
                  ) : isInProgress ? (
                    <Play className="w-4 h-4 text-[#1a1a1a] fill-current" />
                  ) : (
                    <Circle className="w-4 h-4 text-[#2c2c2c]/40" />
                  )}
                </div>

                {/* Stage Title and Subtitle */}
                <div className="flex flex-col min-w-0">
                  <span className="newspaper-font text-base sm:text-lg font-bold truncate">
                    {stage.title}
                  </span>
                  <span className="text-[11px] sm:text-xs text-current/70 font-sans">
                    {statusLabel} • {convertToArabicNumerals(completedCount)} من {convertToArabicNumerals(25)} سؤالاً
                  </span>
                </div>
              </div>

              {/* Left Side: 3 Stars Rating */}
              <div className="shrink-0 flex items-center gap-1.5 px-2.5 py-1 bg-black/5 rounded-xs border border-current/15" style={{ direction: 'ltr' }}>
                {[1, 2, 3].map((starIdx) => {
                  const isEarned = isCompleted && bestStars !== undefined && starIdx <= bestStars;
                  return (
                    <Star
                      key={starIdx}
                      className={`w-4 h-4 ${
                        isEarned
                          ? 'fill-[#d97706] text-[#b45309]'
                          : isUnlocked
                          ? 'text-[#2c2c2c]/30 fill-transparent'
                          : 'text-[#2c2c2c]/20 fill-transparent'
                      }`}
                    />
                  );
                })}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
