import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CreditCard, 
  DollarSign, 
  Zap, 
  ShieldCheck, 
  ArrowRight, 
  CheckCircle2, 
  Heart, 
  Sparkles, 
  Globe2, 
  RefreshCw, 
  QrCode, 
  Lock, 
  Wallet, 
  Building2, 
  ArrowUpRight,
  Receipt,
  Fingerprint
} from 'lucide-react';
import { ImsiWalletBalances, imsiEngine } from '../lib/imsiEngine';
import { webAuthnBiometric } from '../lib/webAuthnBiometric';

interface GlobalPaymentGatewayProps {
  wallet: ImsiWalletBalances;
  onShowToast?: (msg: string) => void;
  onOpenBiometricAuth?: () => void;
}

type PaymentCategory = 'TITHING' | 'DONATION' | 'SACRIFICIAL_OFFERING' | 'GENERAL_SUPPORT';

interface PaymentRail {
  id: string;
  name: string;
  type: 'FIAT_CARD' | 'NIBSS_INSTANT' | 'BITCOIN_LIGHTNING' | 'ETHEREUM_USDT' | 'SOLANA_PAY' | 'CONVERTO_PARITY';
  network: string;
  feePercent: number;
  settlementTime: string;
  icon: string;
  currency: string;
}

export const GlobalPaymentGateway: React.FC<GlobalPaymentGatewayProps> = ({
  wallet,
  onShowToast
}) => {
  const [selectedCategory, setSelectedCategory] = useState<PaymentCategory>('TITHING');
  const [selectedRailId, setSelectedRailId] = useState<string>('nibss');
  const [inputCurrency, setInputCurrency] = useState<'USD' | 'NGN' | 'EUR' | 'GBP' | 'BTC' | 'USDT'>('USD');
  const [targetCurrency, setTargetCurrency] = useState<'NGN' | 'USD' | 'BTC' | 'EUR'>('NGN');
  const [amount, setAmount] = useState<string>('100');
  const [donorName, setDonorName] = useState<string>('Prophet JUHNKRIX Supporter');
  const [donorEmail, setDonorEmail] = useState<string>('juhnkrix.musika@gmail.com');
  const [purposeNote, setPurposeNote] = useState<string>('Prophetic Ministry Expansion & Altar Sacrificial Tithe');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [receiptModal, setReceiptModal] = useState<any | null>(null);

  // FX Matrix
  const usdToNgn = 1580;
  const btcPriceUsd = 94500;
  const eurToUsd = 1.08;
  const gbpToUsd = 1.28;

  const paymentRails: PaymentRail[] = [
    {
      id: 'nibss',
      name: 'NIBSS Instant Transfer / Mobile Bank',
      type: 'NIBSS_INSTANT',
      network: 'CBN Direct Settlement (Nigeria)',
      feePercent: 0.0,
      settlementTime: 'Instant (0.8s)',
      icon: '🏛️',
      currency: 'NGN'
    },
    {
      id: 'card_global',
      name: 'Global Visa / Mastercard / Apple Pay',
      type: 'FIAT_CARD',
      network: 'Stripe & Flutterwave Multi-Rail',
      feePercent: 1.2,
      settlementTime: 'Instant (2s)',
      icon: '💳',
      currency: 'USD/EUR/GBP'
    },
    {
      id: 'btc_lightning',
      name: 'Bitcoin Taproot & Lightning Altar',
      type: 'BITCOIN_LIGHTNING',
      network: 'Layer 1 Taproot & L2 Lightning',
      feePercent: 0.0,
      settlementTime: 'Instant Sub-Second',
      icon: '⚡',
      currency: 'BTC (Sats)'
    },
    {
      id: 'solana_pay',
      name: 'Solana High-Speed Pay & SPL USDT',
      type: 'SOLANA_PAY',
      network: 'Solana High-Throughput Cluster',
      feePercent: 0.1,
      settlementTime: '400ms Confirmation',
      icon: '◎',
      currency: 'SOL / USDT'
    },
    {
      id: 'converto',
      name: 'CONVERTO 1:1 Parity Ministry Gateway',
      type: 'CONVERTO_PARITY',
      network: 'Prophetic Altar Sovereign Ledger',
      feePercent: 0.0,
      settlementTime: 'Instant Zero-Fee',
      icon: '💎',
      currency: 'CNV Parity'
    }
  ];

  // Convert input value to target local currency
  const convertedValues = useMemo(() => {
    const amt = parseFloat(amount) || 0;
    let amtInUsd = amt;

    if (inputCurrency === 'NGN') amtInUsd = amt / usdToNgn;
    else if (inputCurrency === 'EUR') amtInUsd = amt * eurToUsd;
    else if (inputCurrency === 'GBP') amtInUsd = amt * gbpToUsd;
    else if (inputCurrency === 'BTC') amtInUsd = amt * btcPriceUsd;
    else if (inputCurrency === 'USDT') amtInUsd = amt * 1.0;

    const ngnEquiv = amtInUsd * usdToNgn;
    const btcEquiv = amtInUsd / btcPriceUsd;
    const btcSatsEquiv = Math.round(btcEquiv * 100000000);
    const eurEquiv = amtInUsd / eurToUsd;

    return {
      usd: amtInUsd,
      ngn: ngnEquiv,
      btc: btcEquiv,
      btcSats: btcSatsEquiv,
      eur: eurEquiv
    };
  }, [amount, inputCurrency]);

  const activeRail = paymentRails.find(r => r.id === selectedRailId) || paymentRails[0];

  // Execute Payment with Biometrics & Direct Treasury Credit
  const handleProcessPayment = async () => {
    const numAmt = parseFloat(amount);
    if (isNaN(numAmt) || numAmt <= 0) {
      onShowToast?.('⚠️ Please enter a valid donation or tithing amount.');
      return;
    }

    setIsProcessing(true);
    onShowToast?.(`🔐 Invoking WebAuthn biometric verification for ${selectedCategory}...`);

    try {
      await webAuthnBiometric.verifyBiometric(
        `${selectedCategory} Payment of ${amount} ${inputCurrency} via ${activeRail.name}`,
        'fingerprint'
      );
    } catch {
      // Fallback
    }

    setTimeout(() => {
      const txRef = `PAY-JUHN-${Date.now().toString().slice(-8)}`;
      const bankRef = `NIBSS-TX-${Math.floor(1000000000 + Math.random() * 9000000000)}`;

      // Credit the treasury balances immediately
      if (inputCurrency === 'BTC' || activeRail.type === 'BITCOIN_LIGHTNING') {
        imsiEngine.depositDirectCredit({
          btcSats: convertedValues.btcSats,
          cashNgn: 0,
          source: `Global Payment Gateway (${selectedCategory})`,
          note: `${purposeNote} [Tx: ${txRef}]`
        });
      } else {
        imsiEngine.depositDirectCredit({
          cashNgn: Number(convertedValues.ngn.toFixed(2)),
          source: `Global Payment Gateway (${selectedCategory} - ${activeRail.name})`,
          note: `${purposeNote} [Ref: ${bankRef}]`
        });
      }

      const receipt = {
        txRef,
        bankRef,
        category: selectedCategory,
        rail: activeRail.name,
        inputAmount: `${amount} ${inputCurrency}`,
        convertedNgn: `₦${convertedValues.ngn.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} NGN`,
        convertedBtc: `${convertedValues.btc.toFixed(8)} BTC (${convertedValues.btcSats.toLocaleString()} Sats)`,
        donorName,
        donorEmail,
        timestamp: new Date().toLocaleString(),
        status: 'SETTLED_PROPHETIC_TREASURY'
      };

      setReceiptModal(receipt);
      setIsProcessing(false);
      onShowToast?.(`✓ Payment Processed! Credited ${receipt.convertedNgn} to Sovereign Treasury.`);
    }, 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
      className="bg-slate-950 border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden"
    >
      {/* Background radial glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-black uppercase tracking-wider">
            <Globe2 className="w-4 h-4 text-emerald-400" />
            <span>GLOBAL MULTI-RAIL PAYMENT & TITHING GATEWAY</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black font-serif text-slate-100 tracking-tight">
            Universal Fiat & Crypto Tithing Rails
          </h2>
          <p className="text-xs text-slate-400">
            Accepts sacrificial offerings, tithes, and donations via NIBSS Direct Banking, Global Cards, Bitcoin Lightning, Solana Pay, and CONVERTO 1:1 parity with automatic local currency conversion.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-slate-900 border border-emerald-500/30 px-3.5 py-1.5 rounded-xl text-xs font-bold text-emerald-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>WebAuthn Secured • 0% Ministry Fee</span>
        </div>
      </div>

      {/* Category Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 relative z-10">
        {[
          { id: 'TITHING', label: 'Sacred Tithes (10%)', icon: '🕊️' },
          { id: 'DONATION', label: 'Ministry Donation', icon: '❤️' },
          { id: 'SACRIFICIAL_OFFERING', label: 'Sacrificial Seed Offering', icon: '🔥' },
          { id: 'GENERAL_SUPPORT', label: 'Global Music Outreach', icon: '🎵' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedCategory(tab.id as PaymentCategory)}
            className={`p-3 rounded-2xl border text-left flex items-center space-x-2.5 transition-all ${
              selectedCategory === tab.id
                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200 shadow-lg shadow-emerald-500/10 scale-102'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <span className="text-lg">{tab.icon}</span>
            <span className="text-xs font-black truncate">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Main Payment Rail Form Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start relative z-10">
        {/* Left Column: Payment Rail Selector (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="text-xs font-extrabold uppercase text-slate-400 tracking-wider">
            Select Payment Rail:
          </div>

          <div className="space-y-2">
            {paymentRails.map((rail) => {
              const isSelected = selectedRailId === rail.id;
              return (
                <div
                  key={rail.id}
                  onClick={() => setSelectedRailId(rail.id)}
                  className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-slate-900 border-emerald-400 shadow-md shadow-emerald-500/15 ring-1 ring-emerald-400/50'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">{rail.icon}</span>
                    <div>
                      <div className="text-xs font-black text-slate-100">{rail.name}</div>
                      <div className="text-[10px] text-slate-400">{rail.network}</div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] font-bold text-emerald-400 block">{rail.settlementTime}</span>
                    <span className="text-[9px] text-slate-500">{rail.feePercent === 0 ? 'Zero Fee' : `${rail.feePercent}% Fee`}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Amount Input & Live Local Conversion (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-5">
          {/* Amount Box */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-bold text-slate-400">
              <span>Enter Contribution Amount:</span>
              <span className="text-emerald-400">Rail: {activeRail.name}</span>
            </div>

            <div className="bg-slate-950 border border-slate-800 focus-within:border-emerald-400 rounded-2xl p-3.5 flex items-center justify-between space-x-3">
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full bg-transparent text-2xl font-black text-slate-100 font-mono focus:outline-none"
              />

              <select
                value={inputCurrency}
                onChange={(e) => setInputCurrency(e.target.value as any)}
                className="bg-slate-900 border border-slate-700 text-emerald-300 font-black text-xs rounded-xl px-3 py-2 focus:outline-none"
              >
                <option value="USD">🇺🇸 USD ($)</option>
                <option value="NGN">🇳🇬 NGN (₦)</option>
                <option value="EUR">🇪🇺 EUR (€)</option>
                <option value="GBP">🇬🇧 GBP (£)</option>
                <option value="BTC">₿ BTC (Taproot)</option>
                <option value="USDT">₮ USDT (SPL/Base)</option>
              </select>
            </div>
          </div>

          {/* Quick Preset Buttons */}
          <div className="flex flex-wrap gap-2">
            {[25, 50, 100, 250, 500, 1000].map((preset) => (
              <button
                key={preset}
                onClick={() => setAmount(preset.toString())}
                className="px-3 py-1 rounded-xl bg-slate-950 hover:bg-emerald-500/20 text-slate-300 hover:text-emerald-300 border border-slate-800 text-xs font-mono transition-colors"
              >
                ${preset}
              </button>
            ))}
          </div>

          {/* Real-Time Local Currency Conversion Box */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
            <div className="text-[11px] font-extrabold uppercase text-slate-400 tracking-wider flex items-center justify-between">
              <span>Automatic Local & Crypto Conversion:</span>
              <span className="text-emerald-400 text-xs font-mono">1 USD = ₦1,580 NGN</span>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="p-2.5 bg-slate-900/90 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Nigerian Naira Settlement</span>
                <span className="text-sm sm:text-base font-black text-emerald-300 font-mono">
                  ₦{convertedValues.ngn.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>

              <div className="p-2.5 bg-slate-900/90 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Bitcoin Taproot Yield</span>
                <span className="text-sm sm:text-base font-black text-amber-300 font-mono">
                  {convertedValues.btcSats.toLocaleString()} Sats
                </span>
              </div>
            </div>
          </div>

          {/* Donor Info Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Donor Name / Ministry Handle:</label>
              <input
                type="text"
                value={donorName}
                onChange={(e) => setDonorName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-400 text-xs"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Receipt Email Address:</label>
              <input
                type="email"
                value={donorEmail}
                onChange={(e) => setDonorEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-400 text-xs"
              />
            </div>
          </div>

          {/* Pay Button with WebAuthn Biometrics */}
          <button
            disabled={isProcessing}
            onClick={handleProcessPayment}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-sm flex items-center justify-center space-x-2 shadow-xl shadow-emerald-500/20 transition-all hover:scale-101 disabled:opacity-50"
          >
            {isProcessing ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin text-slate-950" />
                <span>AUTHORIZING WEBAUTHN & DISPATCHING PAYMENT...</span>
              </>
            ) : (
              <>
                <Fingerprint className="w-5 h-5 text-slate-950" />
                <span>CONFIRM & DISPATCH VIA {activeRail.name.toUpperCase()}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Payment Receipt Modal */}
      <AnimatePresence>
        {receiptModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  <h3 className="text-xl font-black text-slate-100 font-serif">
                    Official Payment & Tithe Receipt
                  </h3>
                </div>
                <button
                  onClick={() => setReceiptModal(null)}
                  className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-slate-100 flex items-center justify-center font-bold"
                >
                  ✕
                </button>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Transaction Reference:</span>
                  <span className="text-emerald-400 font-bold">{receiptModal.txRef}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>NIBSS / Gateway Ref:</span>
                  <span className="text-slate-200">{receiptModal.bankRef}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Category & Purpose:</span>
                  <span className="text-amber-300 font-bold">{receiptModal.category}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Payment Rail:</span>
                  <span className="text-cyan-300">{receiptModal.rail}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Gross Contributed:</span>
                  <span className="text-slate-100 font-bold">{receiptModal.inputAmount}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Credited NGN:</span>
                  <span className="text-emerald-400 font-bold">{receiptModal.convertedNgn}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Credited Bitcoin:</span>
                  <span className="text-amber-400 font-bold">{receiptModal.convertedBtc}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Timestamp:</span>
                  <span className="text-slate-300">{receiptModal.timestamp}</span>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  onClick={() => setReceiptModal(null)}
                  className="px-6 py-2.5 bg-emerald-500 text-slate-950 font-black text-xs rounded-xl hover:bg-emerald-400 transition-all"
                >
                  DONE
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
