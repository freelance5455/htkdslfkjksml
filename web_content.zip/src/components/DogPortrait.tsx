import React, { useEffect, useRef, useState } from 'react';
import adultFawnImg from '../assets/images/dingo_adult_fawn_1794966295859.jpg';
import adultBlackImg from '../assets/images/dingo_adult_black_1794966295892.jpg';
import adultGrayImg from '../assets/images/dingo_adult_gray_1794966296282.jpg';
import adultWhiteImg from '../assets/images/dingo_adult_white_1794966297375.jpg';
import pupFawnImg from '../assets/images/dingo_pup_fawn_1794966297604.jpg';
import { CoatColor, DogGenetics } from '../types/kennel';

const ADULT_COAT_IMAGES: Record<CoatColor, string> = {
  fawn: adultFawnImg,
  black: adultBlackImg,
  gray: adultGrayImg,
  white: adultWhiteImg,
};

const PUP_BASE_IMAGE = pupFawnImg;

const imageCache = new Map<string, Promise<HTMLImageElement>>();

function loadStudioImage(src: string): Promise<HTMLImageElement> {
  if (!imageCache.has(src)) {
    const promise = new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = (err) => reject(err);
      img.src = src;
    });
    imageCache.set(src, promise);
  }
  return imageCache.get(src)!;
}

function seededRand(seed: number): () => number {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function phaseSeed(seed: number): number {
  return (seed % 360) * 0.01745;
}

// Anatomical coat envelope in unscaled studio image coords [0..1]
function coatEnvelopeWeight(nx: number, ny: number, isPup: boolean): number {
  const ellipses = isPup
    ? [
        { cx: 0.44, cy: 0.56, rx: 0.20, ry: 0.13 }, // pup barrel
        { cx: 0.62, cy: 0.44, rx: 0.085, ry: 0.12 }, // neck/shoulder
        { cx: 0.30, cy: 0.60, rx: 0.075, ry: 0.15 }, // rump/hind leg
        { cx: 0.56, cy: 0.63, rx: 0.055, ry: 0.15 }, // foreleg
      ]
    : [
        { cx: 0.45, cy: 0.50, rx: 0.21, ry: 0.115 }, // adult barrel/flank
        { cx: 0.64, cy: 0.40, rx: 0.08, ry: 0.115 },  // shoulder/neck
        { cx: 0.28, cy: 0.53, rx: 0.075, ry: 0.13 },  // thigh/rump
        { cx: 0.59, cy: 0.61, rx: 0.052, ry: 0.15 },  // upper foreleg
      ];

  let maxW = 0;
  for (const e of ellipses) {
    const dx = (nx - e.cx) / e.rx;
    const dy = (ny - e.cy) / e.ry;
    const d2 = dx * dx + dy * dy;
    if (d2 < 1) {
      const w = Math.pow(1 - d2, 0.75);
      if (w > maxW) maxW = w;
    }
  }
  return maxW;
}

function toUnscaledCoords(
  nx: number,
  ny: number,
  scaleX: number,
  scaleY: number
): [number, number] {
  const anchorX = 0.5;
  const anchorY = 0.86;
  return [
    (nx - anchorX) / scaleX + anchorX,
    (ny - anchorY) / scaleY + anchorY,
  ];
}

function buildPatternAlphaMap(
  width: number,
  height: number,
  genetics: DogGenetics,
  scaleX: number,
  scaleY: number
): Float32Array {
  const map = new Float32Array(width * height);
  if (genetics.pattern === 'patternless') return map;

  const rand = seededRand(genetics.patternSeed);

  if (genetics.pattern === 'black spots') {
    const spots = Array.from({ length: 42 }, () => ({
      x: 0.23 + rand() * 0.46,
      y: 0.37 + rand() * 0.28,
      rx: 0.011 + rand() * 0.017,
      ry: 0.010 + rand() * 0.018,
      rot: rand() * Math.PI,
    }));
    for (let y = 0; y < height; y++) {
      const ny = y / height;
      for (let x = 0; x < width; x++) {
        const nx = x / width;
        const [ux, uy] = toUnscaledCoords(nx, ny, scaleX, scaleY);
        const env = coatEnvelopeWeight(ux, uy, false);
        if (env <= 0.06) continue;
        let hit = 0;
        for (const s of spots) {
          const dx = ux - s.x;
          const dy = uy - s.y;
          const cos = Math.cos(s.rot);
          const sin = Math.sin(s.rot);
          const u = (dx * cos + dy * sin) / s.rx;
          const v = (-dx * sin + dy * cos) / s.ry;
          const d2 = u * u + v * v;
          if (d2 < 1) {
            hit = Math.max(hit, (1 - d2) * 1.4);
          }
        }
        map[y * width + x] = Math.min(1, hit) * Math.min(1, env * 1.6);
      }
    }
  } else if (genetics.pattern === 'striped') {
    const phase = rand() * 6.28;
    const freq = 34 + rand() * 10;
    for (let y = 0; y < height; y++) {
      const ny = y / height;
      for (let x = 0; x < width; x++) {
        const nx = x / width;
        const [ux, uy] = toUnscaledCoords(nx, ny, scaleX, scaleY);
        const env = coatEnvelopeWeight(ux, uy, false);
        if (env <= 0.06) continue;
        const curve = Math.sin(uy * 8.5 + phase) * 0.025 + Math.cos(ux * 14) * 0.008;
        const wave = Math.sin((ux + uy * 0.22 + curve) * freq + phase);
        if (wave > 0.32) {
          const strength = Math.min(1, (wave - 0.32) * 2.1);
          map[y * width + x] = strength * Math.min(1, env * 1.5);
        }
      }
    }
  } else if (genetics.pattern === 'black piebald') {
    // Keep piebald saddle/flank/shoulder patches centered securely inside the coat trunk
    const patches = Array.from({ length: 6 }, () => ({
      x: 0.26 + rand() * 0.40,
      y: 0.39 + rand() * 0.21,
      rx: 0.048 + rand() * 0.052,
      ry: 0.048 + rand() * 0.056,
      rot: rand() * Math.PI,
    }));
    const phase = phaseSeed(genetics.patternSeed);
    for (let y = 0; y < height; y++) {
      const ny = y / height;
      for (let x = 0; x < width; x++) {
        const nx = x / width;
        const [ux, uy] = toUnscaledCoords(nx, ny, scaleX, scaleY);
        const env = coatEnvelopeWeight(ux, uy, false);
        if (env <= 0.08) continue;
        let hit = 0;
        const edgeJitter = Math.sin(ux * 46 + phase) * 0.06;
        for (const p of patches) {
          const dx = ux - p.x;
          const dy = uy - p.y;
          const cos = Math.cos(p.rot);
          const sin = Math.sin(p.rot);
          const u = (dx * cos + dy * sin) / p.rx;
          const v = (-dx * sin + dy * cos) / p.ry;
          const d2 = u * u + v * v + edgeJitter;
          if (d2 < 1) {
            hit = Math.max(hit, Math.min(1, (1 - d2) * 3.2));
          }
        }
        map[y * width + x] = hit * Math.min(1, env * 1.8);
      }
    }
  }

  return map;
}

function isStudioBackgroundPixel(
  r: number,
  g: number,
  b: number,
  rowBgR: number,
  rowBgG: number,
  rowBgB: number,
  coat: CoatColor
): boolean {
  const luma = 0.299 * r + 0.587 * g + 0.114 * b;
  const distToRowBg = Math.abs(r - rowBgR) + Math.abs(g - rowBgG) + Math.abs(b - rowBgB);

  if (coat === 'black') {
    // Black dog coat is strictly dark neutral; studio wall & stone floor are warm light stone
    return luma > 116 || distToRowBg < 65 || r - b > 18;
  }
  if (coat === 'gray') {
    return distToRowBg < 36 || (r - b > 16 && luma > 152);
  }
  if (coat === 'fawn') {
    return distToRowBg < 28 && r - b < 32 && luma > 170;
  }
  // White coat relies mainly on the tight anatomical envelope + faint highlight guard
  return distToRowBg < 14 && luma > 215;
}

interface DogPortraitProps {
  name: string;
  genetics: DogGenetics;
  isPup: boolean;
  className?: string;
  compact?: boolean;
}

export const DogPortrait: React.FC<DogPortraitProps> = ({
  name,
  genetics,
  isPup,
  className = '',
  compact = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');

  useEffect(() => {
    let cancelled = false;
    const src = isPup ? PUP_BASE_IMAGE : ADULT_COAT_IMAGES[genetics.coat];

    setStatus('loading');
    loadStudioImage(src)
      .then((img) => {
        if (cancelled) return;
        const canvas = canvasRef.current;
        if (!canvas) return;
        const W = compact ? 280 : 400;
        const H = compact ? 210 : 300;
        canvas.width = W;
        canvas.height = H;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) return;

        ctx.fillStyle = '#EAE2D3';
        ctx.fillRect(0, 0, W, H);

        const scaleX =
          genetics.bodyType === 'slender' ? 1.055 : genetics.bodyType === 'chubby' ? 0.96 : 1.0;
        const scaleY =
          genetics.bodyType === 'slender' ? 0.91 : genetics.bodyType === 'chubby' ? 1.095 : 1.0;

        ctx.save();
        const anchorX = W * 0.5;
        const anchorY = H * 0.86;
        ctx.translate(anchorX, anchorY);
        ctx.scale(scaleX, scaleY);
        ctx.translate(-anchorX, -anchorY);
        ctx.drawImage(img, 0, 0, W, H);
        ctx.restore();

        const needsPupRegrade = isPup && genetics.coat !== 'fawn';
        const needsAdultPattern = !isPup && genetics.pattern !== 'patternless';

        if (needsPupRegrade || needsAdultPattern) {
          const imgData = ctx.getImageData(0, 0, W, H);
          const data = imgData.data;

          const bgR = data[0];
          const bgG = data[1];
          const bgB = data[2];

          const patternMap = needsAdultPattern
            ? buildPatternAlphaMap(W, H, genetics, scaleX, scaleY)
            : null;

          for (let y = 0; y < H; y++) {
            const ny = y / H;
            // Sample row's left & right edges (studio backdrop at scanline y)
            const leftIdx = (y * W + Math.min(W - 1, Math.floor(W * 0.03))) * 4;
            const rightIdx = (y * W + Math.max(0, Math.floor(W * 0.97))) * 4;
            const rowBgR = (data[leftIdx] + data[rightIdx]) * 0.5;
            const rowBgG = (data[leftIdx + 1] + data[rightIdx + 1]) * 0.5;
            const rowBgB = (data[leftIdx + 2] + data[rightIdx + 2]) * 0.5;

            for (let x = 0; x < W; x++) {
              const nx = x / W;
              const idx = (y * W + x) * 4;
              const r = data[idx];
              const g = data[idx + 1];
              const b = data[idx + 2];

              if (needsPupRegrade) {
                const [ux, uy] = toUnscaledCoords(nx, ny, scaleX, scaleY);
                const inPupBounds = ux > 0.10 && ux < 0.86 && uy > 0.12 && uy < 0.88;
                const warmth = r - b;
                const luma = 0.299 * r + 0.587 * g + 0.114 * b;
                const bgDist = Math.abs(r - bgR) + Math.abs(g - bgG) + Math.abs(b - bgB);
                const isCoatPixel =
                  inPupBounds &&
                  (warmth > 24 || (bgDist > 34 && luma < 220)) &&
                  coatEnvelopeWeight(ux, uy, true) > 0.01;

                const inHeadOrTail =
                  inPupBounds &&
                  ((ux > 0.58 && ux < 0.84 && uy > 0.13 && uy < 0.48) ||
                    (ux > 0.12 && ux < 0.26 && uy > 0.50 && uy < 0.82)) &&
                  warmth > 22 &&
                  luma > 34;

                if (isCoatPixel || inHeadOrTail) {
                  if (genetics.coat === 'black') {
                    const shade = Math.max(18, Math.min(76, luma * 0.34));
                    data[idx] = shade;
                    data[idx + 1] = shade + 1;
                    data[idx + 2] = shade + 3;
                  } else if (genetics.coat === 'gray') {
                    const gray = Math.max(46, Math.min(182, luma * 0.88));
                    data[idx] = gray;
                    data[idx + 1] = gray + 1;
                    data[idx + 2] = gray + 4;
                  } else if (genetics.coat === 'white') {
                    const white = Math.max(188, Math.min(246, 130 + luma * 0.56));
                    data[idx] = white;
                    data[idx + 1] = white - 2;
                    data[idx + 2] = white - 8;
                  }
                }
              }

              if (patternMap) {
                const alpha = patternMap[y * W + x];
                if (alpha > 0.02) {
                  if (isStudioBackgroundPixel(r, g, b, rowBgR, rowBgG, rowBgB, genetics.coat)) {
                    continue;
                  }

                  const luma = 0.299 * r + 0.587 * g + 0.114 * b;
                  const a = Math.min(0.88, alpha);

                  if (genetics.coat === 'black') {
                    if (genetics.pattern === 'black piebald') {
                      // Natural fur-textured ivory-white piebald patches strictly inside black coat
                      const target = Math.min(238, 178 + luma * 0.72);
                      data[idx] = r * (1 - a) + target * a;
                      data[idx + 1] = g * (1 - a) + (target - 3) * a;
                      data[idx + 2] = b * (1 - a) + (target - 10) * a;
                    } else {
                      const shift = genetics.pattern === 'striped' ? 38 : 30;
                      data[idx] = Math.min(255, r + shift * a);
                      data[idx + 1] = Math.min(255, g + (shift + 2) * a);
                      data[idx + 2] = Math.min(255, b + (shift + 6) * a);
                    }
                  } else {
                    const darkFactor = genetics.pattern === 'black piebald' ? 0.16 : 0.24;
                    const tR = r * darkFactor;
                    const tG = g * darkFactor;
                    const tB = b * (darkFactor + 0.02);
                    data[idx] = r * (1 - a) + tR * a;
                    data[idx + 1] = g * (1 - a) + tG * a;
                    data[idx + 2] = b * (1 - a) + tB * a;
                  }
                }
              }
            }
          }

          ctx.putImageData(imgData, 0, 0);
        }

        setStatus('ready');
      })
      .catch(() => {
        if (!cancelled) setStatus('error');
      });

    return () => {
      cancelled = true;
    };
  }, [
    genetics.coat,
    genetics.bodyType,
    genetics.pattern,
    genetics.patternSeed,
    isPup,
    compact,
  ]);

  const description = isPup
    ? `${name}, ${genetics.coat} ${genetics.bodyType} dingo pup (patternless juvenile coat)`
    : `${name}, ${genetics.coat} ${genetics.bodyType} dingo with ${genetics.pattern} coat`;

  return (
    <div
      className={`relative overflow-hidden rounded-xl bg-[#EAE2D3] border border-[#DFDBD0] aspect-[4/3] ${className}`}
      role="img"
      aria-label={description}
    >
      <canvas
        ref={canvasRef}
        className={`w-full h-full object-cover transition-opacity duration-200 ${
          status === 'ready' ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {status !== 'ready' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-gradient-to-br from-[#EFECE4] to-[#E3DDD0] text-[#5C584F]">
          <svg className="w-12 h-12 opacity-40 mb-1" viewBox="0 0 64 64" fill="currentColor" aria-hidden="true">
            <path d="M18 46c2-9 7-15 13-19l5-10 3 3 5-6v9c4 3 8 6 10 9l-6 4c-3 1-6 0-8-2l-4 12h-5l1-10-6 5-2 5h-6z" />
          </svg>
          <span className="text-xs font-medium capitalize">
            {isPup ? `${genetics.coat} pup · patternless` : `${genetics.coat} · ${genetics.pattern}`}
          </span>
        </div>
      )}
    </div>
  );
};
