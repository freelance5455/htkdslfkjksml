import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useVault } from "@/lib/vault-store";

const VaultReadyContext = createContext(false);

export function VaultProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    void Promise.resolve(useVault.persist.rehydrate()).finally(() => setReady(true));
  }, []);

  return <VaultReadyContext.Provider value={ready}>{children}</VaultReadyContext.Provider>;
}

export function useVaultReady() {
  return useContext(VaultReadyContext);
}
