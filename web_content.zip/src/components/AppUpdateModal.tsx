import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  ArrowUpCircle, 
  CheckCircle2, 
  X, 
  DownloadCloud, 
  ShieldCheck, 
  ExternalLink 
} from 'lucide-react';
import { 
  CURRENT_APP_VERSION, 
  fetchLatestVersion, 
  isVersionNewer, 
  VersionInfo 
} from '../utils/versionCheck';

interface AppUpdateModalProps {
  forceOpen?: boolean;
  onClose?: () => void;
}

export const AppUpdateModal: React.FC<AppUpdateModalProps> = ({ 
  forceOpen = false, 
  onClose 
}) => {
  const [updateInfo, setUpdateInfo] = useState<VersionInfo | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);

  useEffect(() => {
    // Check for updates on mount
    fetchLatestVersion().then(info => {
      if (!info) return;
      setUpdateInfo(info);

      const hasNewer = isVersionNewer(info.latestVersion, CURRENT_APP_VERSION);
      if (hasNewer || forceOpen) {
        // Check if user dismissed this specific version in this session (unless force update)
        const dismissed = sessionStorage.getItem(`dismissed_update_${info.latestVersion}`);
        if (!dismissed || info.isForceUpdate || forceOpen) {
          setIsOpen(true);
        }
      }
    });
  }, [forceOpen]);

  if (!isOpen || !updateInfo) return null;

  const handleDismiss = () => {
    if (updateInfo.isForceUpdate) return;
    sessionStorage.setItem(`dismissed_update_${updateInfo.latestVersion}`, 'true');
    setIsOpen(false);
    onClose?.();
  };

  const handleStartUpdate = () => {
    setIsDownloading(true);
    let progress = 10;
    setDownloadProgress(progress);

    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 20) + 15;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        setDownloadProgress(100);
        setTimeout(() => {
          setIsDownloading(false);
          // Trigger APK download / update link
          window.location.href = updateInfo.apkDownloadUrl;
        }, 500);
      } else {
        setDownloadProgress(progress);
      }
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-[100000] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#0f1424] to-[#080a12] border border-cyan-500/30 rounded-3xl p-6 sm:p-7 shadow-[0_0_60px_rgba(6,182,212,0.25)] text-slate-100 overflow-hidden">
        
        {/* Glow ambient bloom */}
        <div className="absolute top-0 right-0 w-44 h-44 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-44 h-44 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button (if not forced) */}
        {!updateInfo.isForceUpdate && (
          <button 
            onClick={handleDismiss}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-900/60 hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Icon & Version Header */}
        <div className="flex items-center gap-3.5 mb-4">
          <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-cyan-500 to-purple-600 p-0.5 shadow-lg shadow-cyan-500/30">
            <div className="w-full h-full rounded-[14px] bg-[#090c16] flex items-center justify-center text-cyan-400">
              <ArrowUpCircle className="w-7 h-7 animate-bounce" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                Update Available
              </span>
              <span className="text-xs text-slate-400 font-mono">
                v{CURRENT_APP_VERSION} → <strong className="text-cyan-400">v{updateInfo.latestVersion}</strong>
              </span>
            </div>
            <h3 className="text-lg font-bold text-white mt-1 flex items-center gap-1.5">
              Secret Gossip Upgrade <Sparkles className="w-4 h-4 text-purple-400" />
            </h3>
          </div>
        </div>

        {/* Release Notes */}
        <div className="my-4 bg-slate-950/70 border border-slate-800/80 rounded-2xl p-4">
          <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" /> What's New in this version
          </h4>
          <ul className="space-y-2 text-xs text-slate-300">
            {updateInfo.releaseNotes.map((note, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>{note}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Download Progress Bar (When downloading) */}
        {isDownloading ? (
          <div className="space-y-2 my-5">
            <div className="flex justify-between text-xs text-slate-400 font-mono">
              <span className="flex items-center gap-1 text-cyan-400">
                <DownloadCloud className="w-3.5 h-3.5 animate-pulse" /> Downloading Package...
              </span>
              <span>{downloadProgress}%</span>
            </div>
            <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div 
                className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 transition-all duration-300 rounded-full"
                style={{ width: `${downloadProgress}%` }}
              />
            </div>
          </div>
        ) : null}

        {/* Actions */}
        <div className="flex items-center gap-3 mt-6">
          {!updateInfo.isForceUpdate && (
            <button
              onClick={handleDismiss}
              disabled={isDownloading}
              className="flex-1 py-3 px-4 rounded-xl text-xs font-medium text-slate-400 bg-slate-900 hover:bg-slate-800 transition-colors"
            >
              Later
            </button>
          )}

          <button
            onClick={handleStartUpdate}
            disabled={isDownloading}
            className="flex-1 py-3 px-4 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-lg shadow-cyan-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isDownloading ? (
              <span>Installing Update...</span>
            ) : (
              <>
                <DownloadCloud className="w-4 h-4" />
                <span>Update Now</span>
              </>
            )}
          </button>
        </div>

        {/* Seamless OTA footnote */}
        <p className="text-[10px] text-center text-slate-500 mt-3.5">
          Fast In-App Update · No data lost · Encrypted transfer
        </p>

      </div>
    </div>
  );
};
