import React, { useState } from 'react';
import { MessageSquare, Copy, Check, Sparkles, AlertCircle, Info, ShieldAlert } from 'lucide-react';
import { ReplyEntry, Language } from '../types';
import { formatCNIC } from '../utils/cnic';
import { t } from '../utils/translations';
import { sounds } from '../utils/audio';

interface ReplyMonitorCardProps {
  replies: ReplyEntry[];
  onSimulateReplyForSelected: () => void;
  hasSelectedCnic: boolean;
  language: Language;
  onShowToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const ReplyMonitorCard: React.FC<ReplyMonitorCardProps> = ({
  replies,
  onSimulateReplyForSelected,
  hasSelectedCnic,
  language,
  onShowToast,
}) => {
  const tr = t[language];
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (reply: ReplyEntry) => {
    navigator.clipboard.writeText(reply.rawText);
    setCopiedId(reply.id);
    sounds.playClick();
    onShowToast(language === 'ur' ? 'جوابی پیغام کاپی کر لیا گیا' : 'Reply copied to clipboard', 'success');
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <div className="card-cyber relative p-5 rounded-2xl border border-[#247ab0] bg-gradient-to-br from-[#172e4d] to-[#0a1425] shadow-[0_5px_25px_rgba(0,30,65,0.45)] transition-all hover:border-[#389bd9]">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#214c77]">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-[#41eaff]" />
          <h3 className="text-base sm:text-lg font-bold text-[#41eaff] tracking-wide m-0">
            {tr.replyMonitor}
          </h3>
        </div>
        {hasSelectedCnic && (
          <button
            type="button"
            onClick={() => {
              onSimulateReplyForSelected();
              sounds.playSuccess();
            }}
            className="text-xs text-cyan-300 hover:text-white flex items-center gap-1.5 bg-[#0e2744] hover:bg-[#14375e] px-2.5 py-1 rounded-lg border border-[#208fc0]/60 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{tr.simulateReplyBtn}</span>
          </button>
        )}
      </div>

      <div
        id="replies"
        className="bg-[#07111f] border border-[#244968] rounded-xl p-3 min-h-[90px] max-h-[300px] overflow-y-auto space-y-3"
      >
        {replies.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-6 text-center text-slate-400 text-xs gap-2">
            <Info className="w-5 h-5 text-cyan-400 opacity-60" />
            <p className="font-mono m-0">{tr.replyWaiting}</p>
            <p className="text-[11px] text-slate-500 max-w-sm m-0">
              Send an inquiry above or click &ldquo;Simulate 668 Response&rdquo; to test the PTA SIM registry parser.
            </p>
          </div>
        ) : (
          replies.map((reply) => {
            const b = reply.parsedBreakdown;
            const quota = b ? b.totalVoice : 0;
            const isAtQuota = quota >= 5;

            return (
              <div
                key={reply.id}
                className="p-3.5 rounded-xl bg-[#09182c] border border-[#1d436a] space-y-2.5 transition-colors hover:border-[#2b659c]"
              >
                {/* Header info */}
                <div className="flex items-center justify-between text-xs border-b border-[#142e4c] pb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-cyan-300 font-mono">
                      CNIC: {formatCNIC(reply.cnic)}
                    </span>
                    <span className="text-slate-500">·</span>
                    <span className="text-slate-400 font-mono text-[11px]">
                      {reply.time}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleCopy(reply)}
                    className="p-1 text-slate-400 hover:text-cyan-300 transition-colors flex items-center gap-1 text-[11px] cursor-pointer"
                    title="Copy response text"
                  >
                    {copiedId === reply.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span className="hidden sm:inline">Copy</span>
                  </button>
                </div>

                {/* Operator Breakdown grid */}
                {b && (
                  <div className="space-y-2">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      <div className="p-2 rounded-lg bg-[#1a1215] border border-red-700/40 text-center">
                        <span className="text-[11px] text-red-400 block font-medium">Jazz / Mobilink</span>
                        <span className="text-base font-bold font-mono text-white tabular-nums">
                          {b.jazz}
                        </span>
                      </div>
                      <div className="p-2 rounded-lg bg-[#0e172a] border border-blue-600/40 text-center">
                        <span className="text-[11px] text-blue-400 block font-medium">Telenor</span>
                        <span className="text-base font-bold font-mono text-white tabular-nums">
                          {b.telenor}
                        </span>
                      </div>
                      <div className="p-2 rounded-lg bg-[#0f2119] border border-emerald-600/40 text-center">
                        <span className="text-[11px] text-emerald-400 block font-medium">Zong 4G</span>
                        <span className="text-base font-bold font-mono text-white tabular-nums">
                          {b.zong}
                        </span>
                      </div>
                      <div className="p-2 rounded-lg bg-[#20180a] border border-amber-600/40 text-center">
                        <span className="text-[11px] text-amber-400 block font-medium">Ufone</span>
                        <span className="text-base font-bold font-mono text-white tabular-nums">
                          {b.ufone}
                        </span>
                      </div>
                    </div>

                    {/* Quota Progress */}
                    <div className="p-2.5 rounded-lg bg-[#0a1524] border border-[#193a5e] text-xs space-y-1.5">
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="flex items-center gap-1.5">
                          {isAtQuota ? (
                            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                          ) : (
                            <AlertCircle className="w-3.5 h-3.5 text-cyan-400" />
                          )}
                          <span>
                            {tr.voiceSims}: <b className="text-white font-mono">{b.totalVoice}</b> / 5 max
                          </span>
                        </span>
                        <span className="text-slate-400 font-mono text-[11px]">
                          {tr.dataSims}: <b className="text-cyan-300">{b.totalData}</b>
                        </span>
                      </div>

                      {/* Bar */}
                      <div className="w-full bg-[#050b14] h-2 rounded-full overflow-hidden border border-[#1b3d63]">
                        <div
                          className={`h-full transition-all duration-500 rounded-full ${
                            isAtQuota ? 'bg-gradient-to-r from-amber-500 to-rose-500' : 'bg-gradient-to-r from-cyan-500 to-emerald-400'
                          }`}
                          style={{ width: `${Math.min(100, (b.totalVoice / 5) * 100)}%` }}
                        />
                      </div>

                      <div className="text-[10px] text-slate-400">
                        {isAtQuota
                          ? (language === 'ur' ? 'انتباہ: وائس سمز کی زیادہ سے زیادہ حد (5) مکمل ہو چکی ہے۔' : 'Notice: Maximum regulatory voice SIM quota (5) reached.')
                          : (language === 'ur' ? `مزید ${5 - b.totalVoice} وائس سمز رجسٹر ہو سکتی ہیں۔` : `${5 - b.totalVoice} remaining voice SIM slot(s) available.`)}
                      </div>
                    </div>
                  </div>
                )}

                {/* Raw SMS Box */}
                <div className="p-2.5 rounded-lg bg-[#050d18] border border-[#16304a] text-[11px] text-slate-300 font-mono leading-relaxed break-words">
                  {reply.rawText}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
