import React, { useState, useRef, useEffect } from 'react';
import {
  Music,
  Grid as GridIcon,
  Volume2,
  Lock,
  Unlock,
  Radio,
  Sliders
} from 'lucide-react';
import { Project, Track, DRUM_VOICES, midiToNoteName, SCALES, DrumSoundType } from '../types/daw';
import { engine, PlayheadState } from '../audio/engine';
import { ActiveVoice } from '../audio/synth';

interface PlayViewProps {
  project: Project;
  playhead: PlayheadState;
  selectedTrackId: string | null;
  onSelectTrack: (trackId: string) => void;
  onUpdateProject: (updater: (prev: Project) => Project) => void;
}

export const PlayView: React.FC<PlayViewProps> = ({
  project,
  playhead,
  selectedTrackId,
  onSelectTrack,
  onUpdateProject,
}) => {
  const [playMode, setPlayMode] = useState<'keys' | 'pads'>('keys');
  const [baseOctave, setBaseOctave] = useState<number>(4); // Octave 4 default (C4 = 60)
  const [sustain, setSustain] = useState<boolean>(false);
  const [scaleLock, setScaleLock] = useState<boolean>(false);
  const [activeScale, setActiveScale] = useState<string>('minor');
  const [pitchBend, setPitchBend] = useState<number>(0); // -100 to +100 cents
  const [modWheel, setModWheel] = useState<number>(0); // 0 to 100%

  // Active track
  const track = project.tracks.find(t => t.id === selectedTrackId) || project.tracks[0];

  // Active voices map for sustain / note release
  const activeVoicesRef = useRef<Map<number, ActiveVoice>>(new Map());

  // Clean up voices on unmount
  useEffect(() => {
    return () => {
      activeVoicesRef.current.forEach(v => v.stop());
      activeVoicesRef.current.clear();
    };
  }, []);

  // Keyboard note trigger
  const triggerNoteOn = (midi: number) => {
    if (!track) return;
    // Detune using pitch bend
    const origDetune = track.synthConfig.detune;
    track.synthConfig.detune = origDetune + pitchBend;

    const voice = engine.playTrackNoteLive(track, midi, 0.85);
    track.synthConfig.detune = origDetune;

    if (voice) {
      // If voice was already playing, stop it
      if (activeVoicesRef.current.has(midi)) {
        activeVoicesRef.current.get(midi)!.stop();
      }
      activeVoicesRef.current.set(midi, voice);
    }
  };

  const triggerNoteOff = (midi: number) => {
    if (sustain) return; // Keep ringing if sustain is enabled
    const voice = activeVoicesRef.current.get(midi);
    if (voice) {
      voice.stop();
      activeVoicesRef.current.delete(midi);
    }
  };

  const releaseAllNotes = () => {
    activeVoicesRef.current.forEach(v => v.stop());
    activeVoicesRef.current.clear();
  };

  // Generate piano keys for 2 octaves (24 semitones)
  const startMidi = baseOctave * 12 + 12; // e.g. Octave 4 -> C4 = 60
  const numKeys = 25; // 2 full octaves + top C

  const isScaleNote = (midi: number) => {
    const semitone = midi % 12;
    const def = SCALES[activeScale];
    if (!def) return true;
    return def.intervals.includes(semitone);
  };

  const isBlackKey = (midi: number) => {
    const n = midi % 12;
    return [1, 3, 6, 8, 10].includes(n);
  };

  // Drum pad trigger
  const [activePad, setActivePad] = useState<DrumSoundType | null>(null);

  const handlePadHit = (drum: DrumSoundType, e: React.PointerEvent) => {
    e.preventDefault();
    const rect = e.currentTarget.getBoundingClientRect();
    const clickY = e.clientY - rect.top;
    // Map vertical position to velocity (top of pad = 1.0, bottom = 0.5)
    const normY = 1 - clickY / rect.height;
    const velocity = 0.5 + normY * 0.5;

    engine.playTrackDrumLive(track, drum, velocity);
    setActivePad(drum);
    setTimeout(() => setActivePad(null), 120);
  };

  // Computer keyboard trigger mapping
  useEffect(() => {
    const keyMap: Record<string, number> = {
      a: 60, // C4
      w: 61, // C#4
      s: 62, // D4
      e: 63, // D#4
      d: 64, // E4
      f: 65, // F4
      t: 66, // F#4
      g: 67, // G4
      y: 68, // G#4
      h: 69, // A4
      u: 70, // A#4
      j: 71, // B4
      k: 72, // C5
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat || e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      const lower = e.key.toLowerCase();
      if (keyMap[lower]) {
        const midi = keyMap[lower] + (baseOctave - 4) * 12;
        triggerNoteOn(midi);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const lower = e.key.toLowerCase();
      if (keyMap[lower]) {
        const midi = keyMap[lower] + (baseOctave - 4) * 12;
        triggerNoteOff(midi);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [baseOctave, sustain, track]);

  return (
    <div className="flex-1 flex flex-col bg-[#11141b] overflow-hidden select-none">
      {/* Play View Top Bar */}
      <div className="h-11 bg-[#161922] border-b border-[#252b37] px-4 flex items-center justify-between gap-3 shrink-0 flex-wrap">
        <div className="flex items-center gap-2">
          {/* Mode Switcher: Keyboard vs Pads */}
          <div className="flex items-center bg-[#1e232e] border border-[#2f3747] rounded-lg p-0.5">
            <button
              onClick={() => setPlayMode('keys')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
                playMode === 'keys'
                  ? 'bg-[#e040fb] text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Music className="w-3.5 h-3.5" />
              <span>Keyboard</span>
            </button>
            <button
              onClick={() => setPlayMode('pads')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
                playMode === 'pads'
                  ? 'bg-[#ff7700] text-black shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <GridIcon className="w-3.5 h-3.5" />
              <span>16 Pads</span>
            </button>
          </div>

          {/* Track Selector */}
          <div className="flex items-center gap-1.5 bg-[#1e232e] border border-[#2f3747] rounded-lg px-2.5 py-1 text-xs">
            <span className="text-slate-400 font-medium">Sound:</span>
            <select
              value={track.id}
              onChange={e => onSelectTrack(e.target.value)}
              className="bg-transparent text-slate-100 font-semibold focus:outline-none cursor-pointer"
            >
              {project.tracks.map(t => (
                <option key={t.id} value={t.id} className="bg-[#1e232e]">
                  {t.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Keyboard options (Octave, Sustain, Scale Lock) */}
        {playMode === 'keys' ? (
          <div className="flex items-center gap-2">
            {/* Octave Controls */}
            <div className="flex items-center bg-[#1e232e] border border-[#2f3747] rounded-lg px-2 py-0.5 gap-1.5 text-xs">
              <span className="text-slate-400 font-medium">Octave:</span>
              <button
                onClick={() => setBaseOctave(o => Math.max(1, o - 1))}
                className="w-5 h-5 rounded bg-[#2b3240] hover:bg-[#384255] text-white font-bold flex items-center justify-center"
              >
                -
              </button>
              <span className="font-mono font-bold text-[#00e5ff] w-4 text-center">
                {baseOctave}
              </span>
              <button
                onClick={() => setBaseOctave(o => Math.min(6, o + 1))}
                className="w-5 h-5 rounded bg-[#2b3240] hover:bg-[#384255] text-white font-bold flex items-center justify-center"
              >
                +
              </button>
            </div>

            {/* Sustain Button */}
            <button
              onClick={() => {
                const next = !sustain;
                setSustain(next);
                if (!next) releaseAllNotes();
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-colors ${
                sustain
                  ? 'bg-[#00e676] text-black border-[#00e676] shadow-sm'
                  : 'bg-[#1e232e] text-slate-400 border-[#2f3747] hover:text-white'
              }`}
            >
              SUSTAIN
            </button>

            {/* Scale Lock Toggle */}
            <div className="hidden sm:flex items-center gap-1.5 bg-[#1e232e] border border-[#2f3747] rounded-lg px-2 py-1 text-xs">
              <button
                onClick={() => setScaleLock(!scaleLock)}
                className={`flex items-center gap-1 font-semibold ${
                  scaleLock ? 'text-[#ffca28]' : 'text-slate-400 hover:text-white'
                }`}
                title="Scale Lock: Only trigger notes in key"
              >
                {scaleLock ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                <span>Lock Scale:</span>
              </button>
              <select
                value={activeScale}
                onChange={e => setActiveScale(e.target.value)}
                className="bg-transparent text-[#00e5ff] font-semibold focus:outline-none cursor-pointer"
              >
                {Object.entries(SCALES).map(([k, s]) => (
                  <option key={k} value={k} className="bg-[#1e232e]">
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        ) : (
          <div className="text-xs text-slate-400 font-medium">
            Touch top for loud (accent), bottom for soft
          </div>
        )}
      </div>

      {/* Main Play Area */}
      <div className="flex-1 flex overflow-hidden p-3 sm:p-5 gap-3">
        {playMode === 'keys' ? (
          <div className="flex-1 flex gap-3 overflow-hidden">
            {/* Left Pitch Bend & Modulation Wheels */}
            <div className="w-20 sm:w-28 bg-[#161a22] border border-[#252b37] rounded-2xl p-2.5 flex flex-col justify-between shrink-0 select-none">
              {/* Pitch Bend */}
              <div className="flex-1 flex flex-col items-center justify-between pb-2 border-b border-[#242935]">
                <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase">
                  Pitch Bend
                </span>
                <input
                  type="range"
                  min="-200"
                  max="200"
                  value={pitchBend}
                  onChange={e => setPitchBend(Number(e.target.value))}
                  onMouseUp={() => setPitchBend(0)}
                  onTouchEnd={() => setPitchBend(0)}
                  className="w-28 -rotate-90 my-auto accent-[#00e5ff] cursor-pointer"
                />
                <span className="text-[9px] font-mono text-[#00e5ff] tabular-nums">
                  {pitchBend > 0 ? `+${pitchBend}` : pitchBend}¢
                </span>
              </div>

              {/* Modulation */}
              <div className="flex-1 flex flex-col items-center justify-between pt-2">
                <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase">
                  Mod Wheel
                </span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={modWheel}
                  onChange={e => setModWheel(Number(e.target.value))}
                  className="w-28 -rotate-90 my-auto accent-[#e040fb] cursor-pointer"
                />
                <span className="text-[9px] font-mono text-[#e040fb] tabular-nums">
                  {modWheel}%
                </span>
              </div>
            </div>

            {/* Piano Keys Surface */}
            <div className="flex-1 bg-[#161922] border border-[#252b37] rounded-2xl p-3 flex flex-col justify-between overflow-x-auto relative">
              <div className="text-[10px] text-slate-400 flex items-center justify-between mb-2">
                <span>Play using mouse, touch, or computer keys (A S D F G H J K)</span>
                <span className="font-mono text-[#00e5ff]">
                  C{baseOctave} - C{baseOctave + 2}
                </span>
              </div>

              {/* Keyboard Container */}
              <div className="flex-1 relative flex h-full min-h-[180px] rounded-xl overflow-hidden shadow-2xl">
                {/* White Keys */}
                {Array.from({ length: numKeys }).map((_, idx) => {
                  const midi = startMidi + idx;
                  const isBlack = isBlackKey(midi);
                  if (isBlack) return null; // black keys overlaid absolute below

                  const inScale = isScaleNote(midi);
                  const isLockedOut = scaleLock && !inScale;

                  return (
                    <button
                      key={midi}
                      onPointerDown={() => !isLockedOut && triggerNoteOn(midi)}
                      onPointerUp={() => !isLockedOut && triggerNoteOff(midi)}
                      onPointerLeave={() => !isLockedOut && triggerNoteOff(midi)}
                      disabled={isLockedOut}
                      className={`flex-1 h-full border-r border-[#cbd5e1] rounded-b-lg flex flex-col justify-end pb-3 items-center text-xs font-mono font-bold transition-all relative ${
                        isLockedOut
                          ? 'bg-[#181c25] text-slate-600 border-[#222834] cursor-not-allowed opacity-40'
                          : 'bg-white hover:bg-slate-100 active:bg-slate-300 text-slate-900 shadow-sm active:translate-y-0.5'
                      }`}
                    >
                      {inScale && !isLockedOut && (
                        <div
                          className="w-2 h-2 rounded-full mb-1"
                          style={{ backgroundColor: track.color }}
                        />
                      )}
                      <span className="truncate">{midiToNoteName(midi)}</span>
                    </button>
                  );
                })}

                {/* Black Keys (Positioned absolutely over white keys) */}
                <div className="absolute inset-0 pointer-events-none flex">
                  {Array.from({ length: numKeys - 1 }).map((_, idx) => {
                    const midi = startMidi + idx;
                    const nextMidi = midi + 1;
                    const isNextBlack = isBlackKey(nextMidi);

                    if (!isNextBlack) return null;

                    // Black key offset calculation
                    const whiteIndex = Array.from({ length: idx + 1 }).filter(
                      (_, i) => !isBlackKey(startMidi + i)
                    ).length;

                    const totalWhites = Array.from({ length: numKeys }).filter(
                      (_, i) => !isBlackKey(startMidi + i)
                    ).length;

                    const leftPercent = (whiteIndex / totalWhites) * 100 - (100 / totalWhites) * 0.35;
                    const widthPercent = (100 / totalWhites) * 0.7;

                    const inScale = isScaleNote(nextMidi);
                    const isLockedOut = scaleLock && !inScale;

                    return (
                      <button
                        key={nextMidi}
                        onPointerDown={() => !isLockedOut && triggerNoteOn(nextMidi)}
                        onPointerUp={() => !isLockedOut && triggerNoteOff(nextMidi)}
                        onPointerLeave={() => !isLockedOut && triggerNoteOff(nextMidi)}
                        disabled={isLockedOut}
                        style={{
                          left: `${leftPercent}%`,
                          width: `${widthPercent}%`,
                          height: '62%',
                        }}
                        className={`absolute top-0 rounded-b-md pointer-events-auto border-x border-b border-[#0f1117] shadow-xl flex flex-col justify-end pb-2 items-center text-[10px] font-mono transition-all z-20 ${
                          isLockedOut
                            ? 'bg-[#12141a] text-slate-700 cursor-not-allowed opacity-30'
                            : 'bg-[#181a22] hover:bg-[#252936] active:bg-[#343b4e] text-slate-300 active:translate-y-0.5'
                        }`}
                      >
                        {inScale && !isLockedOut && (
                          <div
                            className="w-1.5 h-1.5 rounded-full mb-1"
                            style={{ backgroundColor: track.color }}
                          />
                        )}
                        <span className="truncate">{midiToNoteName(nextMidi)}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* 16 MPC Drum Pads Grid (4x4) */
          <div className="flex-1 bg-[#161922] border border-[#252b37] rounded-2xl p-4 sm:p-6 flex flex-col justify-between">
            <div className="grid grid-cols-4 grid-rows-4 gap-2.5 sm:gap-4 flex-1">
              {DRUM_VOICES.concat(DRUM_VOICES).map((voice, idx) => {
                const isHit = activePad === voice.id;

                return (
                  <button
                    key={`${voice.id}_${idx}`}
                    onPointerDown={e => handlePadHit(voice.id, e)}
                    style={{
                      boxShadow: isHit
                        ? `0 0 20px ${voice.color}`
                        : `inset 0 0 10px rgba(0,0,0,0.4)`,
                      borderColor: isHit ? '#ffffff' : `${voice.color}55`,
                    }}
                    className={`rounded-2xl border-2 p-3 flex flex-col justify-between items-start transition-all active:scale-95 cursor-pointer select-none relative overflow-hidden ${
                      isHit
                        ? 'brightness-150 scale-98'
                        : 'bg-[#1e232e] hover:bg-[#262c3b]'
                    }`}
                  >
                    {/* Glowing Accent Corner Indicator */}
                    <div
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: voice.color }}
                    />

                    {/* Pad Title & Sound Type */}
                    <div>
                      <span className="text-[11px] font-bold text-slate-100 block truncate">
                        {voice.name}
                      </span>
                      <span className="text-[9px] font-mono text-slate-400 uppercase">
                        PAD {idx + 1}
                      </span>
                    </div>

                    {/* Velocity gradient visual cue */}
                    <div
                      className="absolute inset-0 opacity-10 pointer-events-none"
                      style={{
                        background: `linear-gradient(to top, ${voice.color}, transparent)`,
                      }}
                    />
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
