import { useMemo, useState, type FormEvent } from "react";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { inspectTarget, verdictLabel, type Verdict } from "@/lib/reputation";
import { useShield } from "@/lib/store";

function toneFor(v: Verdict) {
  if (v === "malicious") return "danger" as const;
  if (v === "suspicious") return "warn" as const;
  if (v === "trusted") return "safe" as const;
  return "muted" as const;
}

export function UrlChecker() {
  const [value, setValue] = useState("");
  const [submitted, setSubmitted] = useState("");
  const ingest = useShield((s) => s.ingest);
  const protectionOn = useShield((s) => s.protectionOn);

  const result = useMemo(
    () => (submitted ? inspectTarget(submitted) : null),
    [submitted],
  );

  function run(e: FormEvent) {
    e.preventDefault();
    const v = value.trim();
    if (!v) return;
    setSubmitted(v);
    if (protectionOn) {
      ingest({
        app: "Prüfung",
        domain: v,
        proto: "HTTPS",
        bytes: 0,
      });
    }
  }

  return (
    <section className="rounded-xl border border-border bg-surface p-4">
      <h2 className="text-sm font-medium">Website prüfen</h2>
      <p className="mt-1 text-xs leading-relaxed text-muted">
        Domain oder Link einfügen. Netzschild bewertet Vertrauenssignale lokal.
      </p>
      <form onSubmit={run} className="mt-3 flex gap-2">
        <label className="sr-only" htmlFor="url-check">
          Adresse
        </label>
        <input
          id="url-check"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="z. B. paypal-konto-update.com"
          autoComplete="off"
          spellCheck={false}
          className="h-11 min-w-0 flex-1 rounded-md border border-border bg-bg px-3 font-mono text-sm text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
        />
        <Button type="submit" size="icon" aria-label="Prüfen">
          <Search />
        </Button>
      </form>
      {result ? (
        <div className="mt-4 space-y-2">
          <div className="flex items-center justify-between gap-3">
            <p className="truncate font-mono text-xs">{result.displayHost}</p>
            <Badge tone={toneFor(result.verdict)}>
              {verdictLabel(result.verdict)}
            </Badge>
          </div>
          <ul className="space-y-1.5">
            {result.findings.map((f) => (
              <li key={f.code} className="text-xs leading-relaxed text-muted">
                <span className="font-medium text-fg">{f.title}.</span> {f.detail}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </section>
  );
}
