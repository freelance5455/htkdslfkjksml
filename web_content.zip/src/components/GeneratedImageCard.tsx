import React, { useState, useEffect } from 'react';
import { GeneratedImagePayload } from '../types';
import { renderHighResVisual, downloadImageFile, shareImageFile } from '../utils/imageGenerator';
import { Download, Share2, Sparkles, Maximize2, X, Check, Copy, Zap, Eye, Trash2, RefreshCw } from 'lucide-react';

interface GeneratedImageCardProps {
  payload: GeneratedImagePayload;
  onDelete?: () => void;
  onRegenerate?: () => void;
}

export const GeneratedImageCard: React.FC<GeneratedImageCardProps> = ({ payload, onDelete, onRegenerate }) => {
  const [dataUrl, setDataUrl] = useState<string>(payload.dataUrl || '');
  const [isGenerating, setIsGenerating] = useState(!payload.dataUrl);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [downloading4k, setDownloading4k] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);

  useEffect(() => {
    let mounted = true;
    if (payload.dataUrl) {
      setDataUrl(payload.dataUrl);
      setIsGenerating(false);
      return;
    }

    renderHighResVisual(payload, 'preview')
      .then(url => {
        if (mounted) {
          setDataUrl(url);
          setIsGenerating(false);
        }
      })
      .catch((err) => {
        console.error('Failed to render visual:', err);
        if (mounted) setIsGenerating(false);
      });

    return () => {
      mounted = false;
    };
  }, [payload.prompt, payload.title, payload.dataUrl]);

  const handleDownloadHd = async () => {
    const hdUrl = await renderHighResVisual(payload, 'hd');
    downloadImageFile(hdUrl, `${payload.title.toLowerCase().replace(/\s+/g, '_')}_1080p.png`);
  };

  const handleDownload4k = async () => {
    setDownloading4k(true);
    try {
      const fourKUrl = await renderHighResVisual(payload, '4k');
      downloadImageFile(fourKUrl, `${payload.title.toLowerCase().replace(/\s+/g, '_')}_4K_ULTRA.png`);
    } finally {
      setDownloading4k(false);
    }
  };

  const handleShare = async () => {
    const shareUrl = dataUrl || (await renderHighResVisual(payload, 'hd'));
    const success = await shareImageFile(
      shareUrl,
      payload.title,
      `Check out this high-CTR image created by ViralSamrat AI: "${payload.prompt}"`
    );
    if (success) {
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 2500);
    }
  };

  return (
    <div className="mt-3 rounded-2xl overflow-hidden border border-cyan-500/30 bg-zinc-950/90 shadow-xl max-w-xl group">
      {/* Top Media Bar */}
      <div className="p-2.5 bg-zinc-900/90 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-[11px] font-mono font-bold text-cyan-300">
            AI_VISUAL_STUDIO • {payload.aspectRatio || '16:9'}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          {onRegenerate && (
            <button
              onClick={onRegenerate}
              title="Re-Generate New Photo"
              className="p-1 rounded-lg text-zinc-400 hover:text-cyan-400 hover:bg-white/10 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          )}
          {onDelete && (
            <button
              onClick={onDelete}
              title="Delete Photo (फोटो हटाएं)"
              className="p-1 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
          <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            4K READY
          </span>
        </div>
      </div>

      {/* Image Preview Area */}
      <div className={`relative ${
        payload.aspectRatio === '9:16'
          ? 'aspect-[9/16] max-h-[460px]'
          : payload.aspectRatio === '1:1'
          ? 'aspect-square max-h-[380px]'
          : 'aspect-video'
      } bg-black flex items-center justify-center overflow-hidden mx-auto w-full`}>
        {isGenerating ? (
          <div className="flex flex-col items-center gap-2 text-zinc-400 p-6 text-center">
            <Sparkles className="w-8 h-8 text-cyan-400 animate-spin" />
            <span className="text-xs font-mono">Generating high-definition visual...</span>
            <span className="text-[10px] text-zinc-500">Creating 8K photorealistic masterpiece</span>
          </div>
        ) : (
          <>
            <img
              src={dataUrl}
              alt={payload.title}
              onLoad={() => setIsGenerating(false)}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.02]"
              referrerPolicy="no-referrer"
            />
            {/* Quick Fullscreen Button */}
            <button
              onClick={() => setIsFullscreen(true)}
              className="absolute top-2 right-2 p-1.5 rounded-xl bg-black/60 hover:bg-black/80 text-white backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </>
        )}
      </div>

      {/* Info & Action Bar */}
      <div className="p-3 bg-zinc-900/70 border-t border-white/5 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <h5 className="text-xs font-bold text-white truncate">
              {payload.title}
            </h5>
            <p className="text-[10px] text-zinc-400 truncate">
              Prompt: "{payload.prompt}"
            </p>
          </div>
        </div>

        {/* Buttons Row */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          {/* Download HD Button */}
          <button
            onClick={handleDownloadHd}
            className="flex-1 min-w-[110px] py-1.5 px-2.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all active:scale-95"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download HD</span>
          </button>

          {/* Download 4K Ultra Button */}
          <button
            onClick={handleDownload4k}
            disabled={downloading4k}
            className="flex-1 min-w-[120px] py-1.5 px-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 transition-all active:scale-95 disabled:opacity-50"
          >
            <Zap className="w-3.5 h-3.5 fill-black" />
            <span>{downloading4k ? 'Upscaling 4K...' : 'Download 4K Ultra'}</span>
          </button>

          {/* Share / CRV Button */}
          <button
            onClick={handleShare}
            className="py-1.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-zinc-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all active:scale-95"
            title="Share (CRV)"
          >
            {shareSuccess ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{shareSuccess ? 'Shared!' : 'Share / CRV'}</span>
          </button>

          {/* Delete Photo Button */}
          {onDelete && (
            <button
              onClick={onDelete}
              className="py-1.5 px-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold flex items-center justify-center gap-1 transition-all active:scale-95 border border-rose-500/20"
              title="Delete Photo (फोटो हटाएं)"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete Photo</span>
            </button>
          )}
        </div>
      </div>

      {/* Fullscreen Lightbox Modal */}
      {isFullscreen && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex flex-col items-center justify-center p-4">
          <div className="w-full max-w-4xl flex items-center justify-between pb-3 text-white">
            <span className="font-bold text-sm tracking-wide">{payload.title}</span>
            <button
              onClick={() => setIsFullscreen(false)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="max-w-4xl max-h-[75vh] rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
            <img src={dataUrl} alt={payload.title} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
          </div>
          <div className="flex items-center gap-3 mt-4">
            <button
              onClick={handleDownloadHd}
              className="py-2 px-4 rounded-xl bg-cyan-500 text-black font-bold text-xs flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" /> Download 1080p HD
            </button>
            <button
              onClick={handleDownload4k}
              className="py-2 px-4 rounded-xl bg-amber-500 text-black font-bold text-xs flex items-center gap-1.5"
            >
              <Zap className="w-4 h-4 fill-black" /> Download 4K Ultra
            </button>
            <button
              onClick={handleShare}
              className="py-2 px-4 rounded-xl bg-white/20 text-white font-semibold text-xs flex items-center gap-1.5"
            >
              <Share2 className="w-4 h-4" /> Share
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
