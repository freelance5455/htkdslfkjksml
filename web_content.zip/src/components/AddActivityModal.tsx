import React, { useState, useEffect } from 'react';
import { X, Trash2, Check, Clock, Calendar, Bell } from 'lucide-react';
import { Activity, ActivityCategory, WorkoutType, MealType, SkincareRoutineType } from '../types';

interface AddActivityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (activity: Activity) => void;
  onDelete?: (id: string) => void;
  editingActivity?: Activity | null;
}

const CATEGORIES: { id: ActivityCategory; label: string }[] = [
  { id: 'workout', label: 'Gym & Workout' },
  { id: 'skincare', label: 'Skincare' },
  { id: 'nutrition', label: 'Diet & Food' },
  { id: 'water', label: 'Water Intake' },
  { id: 'grooming', label: 'Hair & Grooming' },
  { id: 'posture', label: 'Posture & Fitness' },
  { id: 'sleep', label: 'Sleep & Rest' },
];

const DAYS = [
  { day: 0, label: 'Sun' },
  { day: 1, label: 'Mon' },
  { day: 2, label: 'Tue' },
  { day: 3, label: 'Wed' },
  { day: 4, label: 'Thu' },
  { day: 5, label: 'Fri' },
  { day: 6, label: 'Sat' },
];

export const AddActivityModal: React.FC<AddActivityModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  editingActivity,
}) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<ActivityCategory>('workout');
  const [scheduledTime, setScheduledTime] = useState('08:00');
  const [description, setDescription] = useState('');
  const [scheduleType, setScheduleType] = useState<'daily' | 'weekly' | 'custom_days'>('daily');
  const [selectedDays, setSelectedDays] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);
  const [reminderEnabled, setReminderEnabled] = useState(true);

  // Category specific fields
  const [workoutCategory, setWorkoutCategory] = useState<WorkoutType>('Upper Body');
  const [sets, setSets] = useState<number>(3);
  const [reps, setReps] = useState<number>(10);
  const [restSeconds, setRestSeconds] = useState<number>(60);
  const [durationSeconds, setDurationSeconds] = useState<number>(0);

  const [routineType, setRoutineType] = useState<SkincareRoutineType>('morning');
  const [isOptional, setIsOptional] = useState<boolean>(false);

  const [mealType, setMealType] = useState<MealType>('breakfast');
  const [calories, setCalories] = useState<number>(450);
  const [protein, setProtein] = useState<number>(30);
  const [quantity, setQuantity] = useState<string>('');

  const [postureDurationMinutes, setPostureDurationMinutes] = useState<number>(5);

  useEffect(() => {
    if (editingActivity) {
      setName(editingActivity.name);
      setCategory(editingActivity.category);
      setScheduledTime(editingActivity.scheduledTime || '08:00');
      setDescription(editingActivity.description || '');
      setScheduleType(editingActivity.scheduleType || 'daily');
      setSelectedDays(editingActivity.selectedDays || [0, 1, 2, 3, 4, 5, 6]);
      setReminderEnabled(editingActivity.reminderEnabled ?? true);

      // Populate category fields
      if (editingActivity.workoutCategory) setWorkoutCategory(editingActivity.workoutCategory);
      if (editingActivity.sets !== undefined) setSets(editingActivity.sets);
      if (editingActivity.reps !== undefined) setReps(editingActivity.reps);
      if (editingActivity.restSeconds !== undefined) setRestSeconds(editingActivity.restSeconds);
      if (editingActivity.durationSeconds !== undefined) setDurationSeconds(editingActivity.durationSeconds);
      if (editingActivity.routineType) setRoutineType(editingActivity.routineType);
      if (editingActivity.isOptional !== undefined) setIsOptional(editingActivity.isOptional);
      if (editingActivity.mealType) setMealType(editingActivity.mealType);
      if (editingActivity.calories !== undefined) setCalories(editingActivity.calories);
      if (editingActivity.protein !== undefined) setProtein(editingActivity.protein);
      if (editingActivity.quantity) setQuantity(editingActivity.quantity);
      if (editingActivity.postureDurationMinutes !== undefined) setPostureDurationMinutes(editingActivity.postureDurationMinutes);
    } else {
      // Default reset
      setName('');
      setCategory('workout');
      setScheduledTime('08:00');
      setDescription('');
      setScheduleType('daily');
      setSelectedDays([0, 1, 2, 3, 4, 5, 6]);
      setReminderEnabled(true);
      setSets(3);
      setReps(10);
      setRestSeconds(60);
      setCalories(450);
      setProtein(30);
      setQuantity('');
    }
  }, [editingActivity, isOpen]);

  if (!isOpen) return null;

  const toggleDay = (day: number) => {
    if (selectedDays.includes(day)) {
      if (selectedDays.length > 1) {
        setSelectedDays(selectedDays.filter((d) => d !== day));
      }
    } else {
      setSelectedDays([...selectedDays, day].sort());
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const activity: Activity = {
      id: editingActivity ? editingActivity.id : `act_${Date.now()}`,
      name: name.trim(),
      category,
      scheduledTime,
      description: description.trim() || undefined,
      scheduleType,
      selectedDays: scheduleType === 'daily' ? [0, 1, 2, 3, 4, 5, 6] : selectedDays,
      reminderEnabled,
    };

    if (category === 'workout') {
      activity.workoutCategory = workoutCategory;
      activity.sets = sets;
      if (durationSeconds > 0) {
        activity.durationSeconds = durationSeconds;
      } else {
        activity.reps = reps;
      }
      activity.restSeconds = restSeconds;
    } else if (category === 'skincare') {
      activity.routineType = routineType;
      activity.isOptional = isOptional;
    } else if (category === 'nutrition') {
      activity.mealType = mealType;
      activity.calories = calories;
      activity.protein = protein;
      activity.quantity = quantity.trim() || undefined;
    } else if (category === 'posture') {
      activity.postureDurationMinutes = postureDurationMinutes;
    }

    onSave(activity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg rounded-3xl bg-white dark:bg-[#13151B] border border-slate-200 dark:border-slate-800 p-6 shadow-2xl my-8">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {editingActivity ? 'Edit Habit Activity' : 'Add New Habit Activity'}
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Close dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Activity Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Activity Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Chin Tucks, Gua Sha, Squats, Sunscreen"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/30 focus:border-purple-500"
            />
          </div>

          {/* Category Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Habit Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
              {CATEGORIES.map((cat) => (
                <button
                  type="button"
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={`py-2 px-2.5 text-xs font-medium rounded-xl border text-center transition-all truncate ${
                    category === cat.id
                      ? 'bg-purple-600 border-purple-600 text-white shadow-sm'
                      : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Scheduled Time & Reminders */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Scheduled Time
              </label>
              <div className="relative">
                <input
                  type="time"
                  required
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/30 focus:border-purple-500"
                />
                <Clock className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Reminders
              </label>
              <button
                type="button"
                onClick={() => setReminderEnabled(!reminderEnabled)}
                className={`w-full py-2.5 px-3 rounded-xl border flex items-center justify-between text-xs font-medium transition-all ${
                  reminderEnabled
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-300'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500'
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5" />
                  {reminderEnabled ? 'Reminder Active' : 'Reminder Disabled'}
                </span>
                <span className={`w-4 h-4 rounded-full flex items-center justify-center text-white ${reminderEnabled ? 'bg-purple-600' : 'bg-slate-300 dark:bg-slate-600'}`}>
                  {reminderEnabled && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                </span>
              </button>
            </div>
          </div>

          {/* Schedule Frequency */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Frequency
              </label>
              <div className="flex items-center gap-1">
                {(['daily', 'custom_days'] as const).map((mode) => (
                  <button
                    type="button"
                    key={mode}
                    onClick={() => setScheduleType(mode)}
                    className={`text-[11px] px-2.5 py-1 rounded-lg transition-colors ${
                      scheduleType === mode
                        ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-medium'
                        : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {mode === 'daily' ? 'Daily' : 'Selected Days'}
                  </button>
                ))}
              </div>
            </div>

            {scheduleType === 'custom_days' && (
              <div className="grid grid-cols-7 gap-1 pt-1">
                {DAYS.map((d) => (
                  <button
                    type="button"
                    key={d.day}
                    onClick={() => toggleDay(d.day)}
                    className={`py-2 text-xs font-semibold rounded-xl border text-center transition-all ${
                      selectedDays.includes(d.day)
                        ? 'bg-purple-600 border-purple-600 text-white'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Category-Specific Fields */}
          {category === 'workout' && (
            <div className="p-3.5 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/30 space-y-3">
              <div className="text-xs font-semibold text-purple-700 dark:text-purple-300">
                Workout Parameters
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Sets</label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={sets}
                    onChange={(e) => setSets(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Reps</label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={reps}
                    onChange={(e) => setReps(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Rest (sec)</label>
                  <input
                    type="number"
                    min={0}
                    max={300}
                    value={restSeconds}
                    onChange={(e) => setRestSeconds(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                  />
                </div>
              </div>
            </div>
          )}

          {category === 'skincare' && (
            <div className="p-3.5 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/30 space-y-2">
              <div className="text-xs font-semibold text-purple-700 dark:text-purple-300">
                Skincare Routine Slot
              </div>
              <div className="flex items-center gap-2">
                {(['morning', 'night', 'custom'] as const).map((r) => (
                  <button
                    type="button"
                    key={r}
                    onClick={() => setRoutineType(r)}
                    className={`flex-1 py-1.5 text-xs font-medium rounded-lg border capitalize transition-colors ${
                      routineType === r
                        ? 'bg-purple-600 border-purple-600 text-white'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
          )}

          {category === 'nutrition' && (
            <div className="p-3.5 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/30 space-y-2.5">
              <div className="text-xs font-semibold text-purple-700 dark:text-purple-300">
                Meal & Macro Details
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Calories (kcal)</label>
                  <input
                    type="number"
                    min={0}
                    max={3000}
                    value={calories}
                    onChange={(e) => setCalories(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">Protein (grams)</label>
                  <input
                    type="number"
                    min={0}
                    max={200}
                    value={protein}
                    onChange={(e) => setProtein(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">Food / Portions</label>
                <input
                  type="text"
                  placeholder="e.g. 200g grilled salmon + sweet potato"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                />
              </div>
            </div>
          )}

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Instructions / Form Cues (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Keep spine neutral, drink 300ml water after, etc."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-purple-500/30 focus:border-purple-500"
            />
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-between pt-2">
            {editingActivity && onDelete ? (
              <button
                type="button"
                onClick={() => {
                  onDelete(editingActivity.id);
                  onClose();
                }}
                className="py-2.5 px-3 rounded-xl border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            ) : <div />}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="py-2.5 px-4 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="py-2.5 px-5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-md shadow-purple-600/20 active:scale-95 transition-all"
              >
                {editingActivity ? 'Save Changes' : 'Create Activity'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
