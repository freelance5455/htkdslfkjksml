import React from 'react';
import {
  ArrowDown,
  ArrowUp,
  Copy,
  Plus,
  RotateCw,
  Trash2,
  X,
} from 'lucide-react';
import { DetectedPdfFont, PdfPageModel, UILanguage } from '../types/pdf';
import { UI_COPY } from '../utils/i18n';

interface LeftSidebarProps {
  lang: UILanguage;
  isOpen: boolean;
  pages: PdfPageModel[];
  activePageId: string;
  detectedFonts: DetectedPdfFont[];
  onClose: () => void;
  onSelectPage: (pageId: string) => void;
  onRotatePage: (pageId: string) => void;
  onDuplicatePage: (pageId: string) => void;
  onMovePage: (pageId: string, dir: -1 | 1) => void;
  onDeletePage: (pageId: string) => void;
  onAddBlankPage: () => void;
  onOpenFonts: () => void;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  lang,
  isOpen,
  pages,
  activePageId,
  detectedFonts,
  onClose,
  onSelectPage,
  onRotatePage,
  onDuplicatePage,
  onMovePage,
  onDeletePage,
  onAddBlankPage,
  onOpenFonts,
}) => {
  if (!isOpen) return null;
  const t = UI_COPY[lang];

  return (
    <div className="fixed inset-0 z-40 flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/30 backdrop-blur-[1px]"
        onClick={onClose}
      />

      {/* Slide-over Page Manager Drawer */}
      <aside className="relative z-10 w-[240px] max-w-[82vw] bg-[#FAFAFB] border-r border-slate-200 flex flex-col h-full overflow-hidden shadow-xl select-none">
        <div className="px-3.5 py-2.5 border-b border-slate-200 bg-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-800">
              {t.pages}
            </span>
            <span className="text-xs font-mono tabular-nums text-slate-500">
              {pages.length}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            data-tooltip={t.close}
            aria-label={t.close}
            className="p-1 text-slate-500 hover:text-slate-900 rounded hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-2.5 space-y-2.5">
          {pages.map((page, index) => {
            const isActive = page.id === activePageId;
            return (
              <div
                key={page.id}
                onClick={() => {
                  onSelectPage(page.id);
                  onClose();
                }}
                className={`group rounded-lg p-1.5 border transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-white border-blue-600 shadow-xs'
                    : 'bg-white/80 border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="relative bg-white border border-slate-100 rounded overflow-hidden flex items-center justify-center aspect-[3/4]">
                  {page.thumbnailDataUrl ? (
                    <img
                      src={page.thumbnailDataUrl}
                      alt={`Page ${index + 1}`}
                      referrerPolicy="no-referrer"
                      style={{
                        transform: `rotate(${page.rotation}deg)`,
                      }}
                      className="max-w-full max-h-full object-contain transition-transform duration-150"
                    />
                  ) : (
                    <div className="w-full h-full bg-white flex items-center justify-center text-[11px] text-slate-400">
                      Blank
                    </div>
                  )}
                </div>

                <div className="mt-1.5 flex items-center justify-between gap-1">
                  <span className="text-[11px] font-mono tabular-nums text-slate-600">
                    {String(index + 1).padStart(2, '0')}
                  </span>

                  <div
                    className="flex items-center gap-0.5"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      type="button"
                      data-tooltip={t.rotatePage}
                      aria-label={t.rotatePage}
                      onClick={() => onRotatePage(page.id)}
                      className="p-1 text-slate-500 hover:text-slate-900 rounded hover:bg-slate-100 cursor-pointer"
                    >
                      <RotateCw className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      data-tooltip={t.duplicatePage}
                      aria-label={t.duplicatePage}
                      onClick={() => onDuplicatePage(page.id)}
                      className="p-1 text-slate-500 hover:text-slate-900 rounded hover:bg-slate-100 cursor-pointer"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      data-tooltip={t.moveUp}
                      aria-label={t.moveUp}
                      disabled={index === 0}
                      onClick={() => onMovePage(page.id, -1)}
                      className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30 rounded hover:bg-slate-100 cursor-pointer"
                    >
                      <ArrowUp className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      data-tooltip={t.moveDown}
                      aria-label={t.moveDown}
                      disabled={index === pages.length - 1}
                      onClick={() => onMovePage(page.id, 1)}
                      className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30 rounded hover:bg-slate-100 cursor-pointer"
                    >
                      <ArrowDown className="w-3 h-3" />
                    </button>
                    {pages.length > 1 && (
                      <button
                        type="button"
                        data-tooltip={t.deletePage}
                        aria-label={t.deletePage}
                        onClick={() => onDeletePage(page.id)}
                        className="p-1 text-slate-500 hover:text-red-600 rounded hover:bg-red-50 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          <button
            type="button"
            onClick={onAddBlankPage}
            className="w-full py-2 px-2.5 border border-dashed border-slate-300 hover:border-slate-400 rounded-lg text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="truncate">{t.addBlankPage}</span>
          </button>
        </div>

        {detectedFonts.length > 0 && (
          <div className="p-3 border-t border-slate-200 bg-white">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-semibold text-slate-700">
                {t.detectedFonts}
              </span>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenFonts();
                }}
                className="text-[11px] font-medium text-blue-700 hover:underline cursor-pointer"
              >
                {t.fonts}
              </button>
            </div>
            <div className="space-y-1 max-h-24 overflow-y-auto">
              {detectedFonts.slice(0, 4).map((f) => (
                <div
                  key={`${f.rawName}-${f.isBold}-${f.isItalic}`}
                  className="text-[11px] text-slate-600 truncate flex items-center justify-between gap-2"
                >
                  <span className="truncate">
                    {f.displayName}
                    {f.isBold ? ' · B' : ''}
                  </span>
                  <span className="font-mono tabular-nums text-slate-400 shrink-0">
                    {f.count}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </aside>
    </div>
  );
};
