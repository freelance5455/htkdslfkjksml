import { useState, useEffect } from 'react'
import { adjustStock, searchProducts, stockHistory } from '../db/database'
import { inr, fmtQty, fmtDateTime } from '../lib/format'

function typeLabel(t) {
  if (t === 'sale') return 'Beche'
  if (t === 'void') return 'Bill wapas'
  return 'Adjust kiya'
}

export default function Stock({ refreshTick, onChange }) {
  const [items, setItems] = useState([])
  const [query, setQuery] = useState('')
  const [history, setHistory] = useState([])
  const [showHistory, setShowHistory] = useState(false)
  const lowThreshold = 5

  useEffect(() => {
    searchProducts(query).then(setItems)
  }, [query, refreshTick])

  useEffect(() => {
    if (showHistory) stockHistory(50).then(setHistory)
  }, [showHistory, refreshTick])

  async function change(p, delta) {
    await adjustStock(p.id, delta)
    onChange()
  }

  return (
    <div>
      <input
        className="input"
        placeholder="Search…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <p className="muted count">* Stock me jab bhi gila/ekad cheez aaye — + karo, beche to bill se auto minus hota hai.</p>

      <ul className="list">
        {items.map((p) => {
          const low = (p.stock ?? 0) <= lowThreshold
          return (
            <li key={p.id} className="list-item">
              <div className="item-main">
                <div className="item-title">{p.name}</div>
                <div className="item-sub muted">{inr(p.price)} / unit</div>
              </div>
              <div className={`stock-badge ${low ? 'low' : 'ok'}`}>
                {fmtQty(p.stock ?? 0)}
              </div>
              <div className="stepper">
                <button
                  className="btn btn-small"
                  aria-label={`${p.name} stock kam karo`}
                  onClick={() => change(p, -1)}
                >
                  −
                </button>
                <button
                  className="btn btn-small"
                  aria-label={`${p.name} stock badhao`}
                  onClick={() => change(p, 1)}
                >
                  +
                </button>
              </div>
            </li>
          )
        })}
      </ul>

      <button
        className="btn btn-ghost btn-big block"
        onClick={() => setShowHistory((s) => !s)}
      >
        {showHistory ? 'Hide' : '📜 Stock History (kisne kya kiya)'}
      </button>

      {showHistory && (
        <ul className="list">
          {history.length === 0 && <li className="muted">Abhi tak koi activity nahi</li>}
          {history.map((h) => (
            <li key={h.id} className="list-item">
              <div className="item-main">
                <div className="item-title">{h.productName}</div>
                <div className="item-sub muted">
                  {typeLabel(h.type)} · {fmtDateTime(h.createdAt)}
                </div>
              </div>
              <div className={`item-price ${h.qty > 0 ? 'green' : 'balance-due'}`}>
                {h.qty > 0 ? '+' : ''}
                {fmtQty(h.qty)}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}