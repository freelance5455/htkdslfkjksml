/**
 * HELENA - Subtle Side Menu & Navigation
 * Three dots icon at top-right corner (~12% opacity, 100% on hover/tap)
 * Translucent minimalist side drawer with dark green branding.
 */

import React, { useState } from 'react';
import { 
  MoreVertical, 
  Camera, 
  Box, 
  FolderSync, 
  Clock, 
  Sliders, 
  Lock, 
  X,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Stethoscope
} from 'lucide-react';
import { ActiveModal } from '../types';

interface SubtleMenuProps {
  onOpenModal: (modal: ActiveModal) => void;
  isListening: boolean;
  onToggleListening: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const SubtleMenu: React.FC<SubtleMenuProps> = ({
  onOpenModal,
  isListening,
  onToggleListening,
  isMuted,
  onToggleMute,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const menuItems = [
    { id: 'diseases' as ActiveModal, label: 'Doenças & Patologias', icon: Stethoscope, desc: 'Guia clínico: causas, sintomas e tratamentos' },
    { id: 'library' as ActiveModal, label: 'Biblioteca 3D', icon: Box, desc: 'Atlas anatômico veterinário (Tridimensional)' },
    { id: 'image' as ActiveModal, label: 'Imagem de Campo', icon: Camera, desc: 'Análise de fotos de campo veterinário' },
    { id: 'files' as ActiveModal, label: 'Arquivos & Ponte', icon: FolderSync, desc: 'Ponte PC ↔ celular (nuvem & sincronia)' },
    { id: 'history' as ActiveModal, label: 'Histórico', icon: Clock, desc: 'Consultas e diagnósticos anteriores' },
    { id: 'settings' as ActiveModal, label: 'Ajustes', icon: Sliders, desc: 'Voz, velocidade e preferências' },
  ];

  return (
    <>
      {/* Top Right Header Controls */}
      <div className="fixed top-4 right-4 z-30 flex items-center space-x-2">
        {/* Quick Mic Listening indicator */}
        <button
          onClick={onToggleListening}
          className={`p-2.5 rounded-full border transition-all duration-300 min-h-[44px] min-w-[44px] flex items-center justify-center ${
            isListening
              ? 'opacity-90 bg-[#0E7A3D]/40 border-[#2FD16F] text-[#2FD16F]'
              : 'opacity-20 hover:opacity-80 bg-black/40 border-[#14502D] text-[#CDEBD8]'
          }`}
          title={isListening ? 'Microfone ouvindo contínuo' : 'Microfone inativo'}
        >
          {isListening ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
        </button>

        {/* Quick Mute indicator */}
        <button
          onClick={onToggleMute}
          className={`p-2.5 rounded-full border transition-all duration-300 min-h-[44px] min-w-[44px] flex items-center justify-center ${
            isMuted
              ? 'opacity-90 bg-rose-950/50 border-rose-500/50 text-rose-300'
              : 'opacity-20 hover:opacity-80 bg-black/40 border-[#14502D] text-[#CDEBD8]'
          }`}
          title={isMuted ? 'HELENA silenciada' : 'Voz ativa'}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* Subtle Three Dots Icon (~12% opacity -> 100% on hover/touch) */}
        <button
          onClick={() => setIsOpen(true)}
          className="p-2.5 rounded-full bg-black/40 border border-[#14502D]/50 text-[#CDEBD8] opacity-20 hover:opacity-100 focus:opacity-100 transition-opacity duration-300 cursor-pointer backdrop-blur-sm min-h-[44px] min-w-[44px] flex items-center justify-center"
          title="Abrir Menu da HELENA"
        >
          <MoreVertical className="w-5 h-5" />
        </button>
      </div>

      {/* Backdrop overlay */}
      {isOpen && (
        <div
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm transition-opacity"
        />
      )}

      {/* Slide-out translucent minimalist side panel */}
      <div
        className={`fixed top-0 right-0 bottom-0 z-50 w-72 max-w-[85vw] bg-black/92 border-l border-[#14502D] backdrop-blur-xl p-5 flex flex-col justify-between transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="space-y-6">
          {/* Panel Header */}
          <div className="flex items-center justify-between pb-3 border-b border-[#14502D]/60">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#2FD16F] animate-pulse" />
              <span className="text-xs font-mono tracking-widest text-[#2FD16F] uppercase">
                HELENA VET
              </span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-2 text-[#CDEBD8]/70 hover:text-white rounded-lg transition min-h-[40px] min-w-[40px] flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Items */}
          <nav className="space-y-1.5">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setIsOpen(false);
                    onOpenModal(item.id);
                  }}
                  className="w-full flex items-start space-x-3 p-3 rounded-xl text-left hover:bg-[#0E7A3D]/25 hover:border-[#2FD16F]/40 border border-transparent transition-all group min-h-[48px]"
                >
                  <Icon className="w-4 h-4 text-[#2FD16F]/70 group-hover:text-[#2FD16F] mt-0.5 shrink-0 transition-colors" />
                  <div>
                    <p className="text-xs font-medium text-zinc-200 group-hover:text-white tracking-wide">
                      {item.label}
                    </p>
                    <p className="text-[10px] text-[#CDEBD8]/50 font-mono leading-tight">
                      {item.desc}
                    </p>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Admin at the very bottom with a discreet padlock icon */}
        <div className="pt-4 border-t border-[#14502D]/60">
          <button
            onClick={() => {
              setIsOpen(false);
              onOpenModal('admin');
            }}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-[#0E7A3D]/20 border border-transparent hover:border-[#14502D] text-[#CDEBD8]/70 hover:text-white transition-colors opacity-70 hover:opacity-100 min-h-[48px]"
          >
            <div className="flex items-center space-x-2.5">
              <Lock className="w-4 h-4 text-[#2FD16F]/70" />
              <span className="text-xs font-light tracking-wide">Admin</span>
            </div>
            <span className="text-[10px] font-mono text-[#2FD16F]/70">2 Cérebros</span>
          </button>
        </div>
      </div>
    </>
  );
};
