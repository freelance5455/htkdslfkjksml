import { useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import {
  clampHours,
  dayEarning,
  formatHours,
  hoursPhrase,
  inr,
  parseLoose,
  round1,
  sanitizeDecimal,
  sanitizeInt,
} from "@/lib/hajiri/model";
import { useHajiri } from "@/lib/hajiri/store";

type Props = {
  initialDate: string;
  onClose: () => void;
  onSaved: (date: string) => void;
};

function fieldsFrom(worked: number, missed: number, advance: number, note: string) {
  return {
    worked: formatHours(worked),
    missed: formatHours(missed),
    advance: advance ? String(advance) : "",
    note,
  };
}

export function EntryDialog({ initialDate, onClose, onSaved }: Props) {
  const settings = useHajiri((state) => state.settings);
  const upsertEntry = useHajiri((state) => state.upsertEntry);
  const removeEntry = useHajiri((state) => state.removeEntry);

  const existing = useHajiri.getState().entries.find((entry) => entry.date === initialDate);
  const start = existing
    ? fieldsFrom(existing.hoursWorked, existing.hoursMissed, existing.advance, existing.note)
    : fieldsFrom(settings.dailyHours, 0, 0, "");

  const [date, setDate] = useState(initialDate);
  const [editingId, setEditingId] = useState(existing?.id);
  const [worked, setWorked] = useState(start.worked);
  const [missed, setMissed] = useState(start.missed);
  const [advance, setAdvance] = useState(start.advance);
  const [note, setNote] = useState(start.note);
  const [error, setError] = useState("");
  const [confirmDel, setConfirmDel] = useState(false);

  function loadDate(next: string) {
    setDate(next);
    setError("");
    setConfirmDel(false);
    const found = useHajiri.getState().entries.find((entry) => entry.date === next);
    if (found) {
      setEditingId(found.id);
      const filled = fieldsFrom(found.hoursWorked, found.hoursMissed, found.advance, found.note);
      setWorked(filled.worked);
      setMissed(filled.missed);
      setAdvance(filled.advance);
      setNote(filled.note);
      return;
    }
    setEditingId(undefined);
    const blank = fieldsFrom(useHajiri.getState().settings.dailyHours, 0, 0, "");
    setWorked(blank.worked);
    setMissed(blank.missed);
    setAdvance(blank.advance);
    setNote(blank.note);
  }

  function applyPreset(kind: "full" | "half" | "off") {
    const hours = settings.dailyHours;
    if (kind === "full") {
      setWorked(formatHours(hours));
      setMissed("0");
    } else if (kind === "half") {
      const half = round1(hours / 2);
      setWorked(formatHours(half));
      setMissed(formatHours(round1(hours - half)));
    } else {
      setWorked("0");
      setMissed(formatHours(hours));
    }
  }

  function bumpWorked(delta: number) {
    const next = clampHours(parseLoose(worked) + delta);
    setWorked(formatHours(next));
    setMissed(formatHours(clampHours(Math.max(0, round1(settings.dailyHours - next)))));
  }

  function commitWorked() {
    const next = clampHours(parseLoose(worked));
    setWorked(formatHours(next));
    setMissed(formatHours(clampHours(Math.max(0, round1(settings.dailyHours - next)))));
  }

  const workedN = clampHours(parseLoose(worked));
  const missedN = clampHours(parseLoose(missed));
  const half = round1(settings.dailyHours / 2);
  const preset =
    workedN === 0 && missedN === settings.dailyHours
      ? "off"
      : Math.abs(workedN - half) < 0.05 && Math.abs(missedN - round1(settings.dailyHours - half)) < 0.05
        ? "half"
        : Math.abs(workedN - settings.dailyHours) < 0.05 && missedN === 0
          ? "full"
          : "";

  function save() {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      setError("तारीख चुनो।");
      return;
    }
    upsertEntry({
      id: editingId,
      date,
      hoursWorked: workedN,
      hoursMissed: missedN,
      advance: parseLoose(advance),
      note,
    });
    onSaved(date);
  }

  const earning = dayEarning(workedN, settings);

  return (
    <Dialog.Root open onOpenChange={(open) => !open && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-ink/40" />
        <Dialog.Content className="sheet sheet-in fixed inset-x-0 bottom-0 z-50 rounded-t-card border border-line bg-sheet p-4 sm:inset-x-auto sm:bottom-auto sm:left-1/2 sm:top-1/2 sm:w-full sm:max-w-md sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-card sm:p-5">
          <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-line sm:hidden" />
          <div className="flex items-start justify-between gap-3">
            <div>
              <Dialog.Title className="font-display text-3xl leading-none">हाजिरी भरो</Dialog.Title>
              <Dialog.Description className="mt-2 text-sm text-muted">
                एक दिन का हिसाब। तारीख बदल कर दूसरा दिन भी लिख सकते हो।
              </Dialog.Description>
            </div>
            <Dialog.Close className="inline-flex size-11 shrink-0 items-center justify-center rounded-full" aria-label="बंद करो">
              <X className="size-5" />
            </Dialog.Close>
          </div>

          <form
            className="mt-4 grid gap-4"
            onSubmit={(event) => {
              event.preventDefault();
              save();
            }}
          >
            <label className="grid gap-1 text-sm font-medium">
              तारीख
              <input
                className="h-12 rounded-card border border-line bg-sheet px-3 text-base font-normal"
                type="date"
                value={date}
                onChange={(event) => loadDate(event.target.value)}
                required
              />
            </label>

            <div className="grid grid-cols-3 gap-2">
              <PresetButton active={preset === "full"} label="पूरा दिन" hint={hoursPhrase(settings.dailyHours)} onClick={() => applyPreset("full")} />
              <PresetButton active={preset === "half"} label="आधा दिन" hint={hoursPhrase(half)} onClick={() => applyPreset("half")} />
              <PresetButton active={preset === "off"} label="छुट्टी" hint="0 काम" onClick={() => applyPreset("off")} />
            </div>

            <Stepper
              label="कितने घंटे काम किया"
              value={worked}
              onChange={(value) => setWorked(sanitizeDecimal(value))}
              onBlur={commitWorked}
              onStep={bumpWorked}
              step={0.5}
            />
            <Stepper
              label="कितने घंटे नहीं किया"
              hint="घंटे बदलो तो यह अपने आप भरता है। बाद में बदल भी सकते हो।"
              value={missed}
              onChange={(value) => setMissed(sanitizeDecimal(value))}
              onBlur={() => setMissed(formatHours(clampHours(parseLoose(missed))))}
              onStep={(delta) => setMissed(formatHours(clampHours(parseLoose(missed) + delta)))}
              step={0.5}
            />
            <Stepper
              label="एडवांस लिया (₹)"
              value={advance}
              onChange={(value) => setAdvance(sanitizeInt(value))}
              onBlur={() => setAdvance(advance ? String(Math.round(parseLoose(advance))) : "")}
              onStep={(delta) => setAdvance(String(Math.max(0, Math.round(parseLoose(advance) + delta))))}
              step={100}
              placeholder="0"
            />

            <label className="grid gap-1 text-sm font-medium">
              नोट, ज़रूरी नहीं
              <textarea
                className="min-h-20 rounded-card border border-line bg-sheet px-3 py-2 text-base font-normal"
                value={note}
                maxLength={180}
                placeholder="जैसे आधा दिन बारिश"
                onChange={(event) => setNote(event.target.value)}
              />
            </label>

            <div className="rounded-card bg-stamp-soft px-3 py-3 text-sm">
              {settings.dailyWage > 0 ? (
                <p>
                  इस दिन की मज़दूरी <span className="font-semibold text-stamp">{inr(earning)}</span>
                </p>
              ) : (
                <p>सेटिंग में पूरे दिन की मज़दूरी लिखोगे तो बाकी पैसा अपने आप निकलेगा।</p>
              )}
            </div>

            {error ? (
              <p className="text-sm font-medium text-copper" role="alert">
                {error}
              </p>
            ) : null}

            <button className="btn-stamp h-12 text-base" type="submit">
              {editingId ? "बदलाव सेव करो" : "सेव करो"}
            </button>

            {editingId && !confirmDel ? (
              <button
                className="h-11 text-sm font-medium text-copper"
                type="button"
                onClick={() => setConfirmDel(true)}
              >
                इस दिन का हिसाब मिटाओ
              </button>
            ) : null}
            {editingId && confirmDel ? (
              <div className="grid grid-cols-2 gap-2">
                <button className="btn-line h-12" type="button" onClick={() => setConfirmDel(false)}>
                  रहने दो
                </button>
                <button
                  className="btn-copper h-12"
                  type="button"
                  onClick={() => {
                    removeEntry(editingId);
                    onClose();
                  }}
                >
                  हाँ, मिटाओ
                </button>
              </div>
            ) : null}
          </form>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

function PresetButton({
  active,
  label,
  hint,
  onClick,
}: {
  active: boolean;
  label: string;
  hint: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={
        active
          ? "h-14 rounded-card border-2 border-stamp bg-stamp-soft text-stamp"
          : "h-14 rounded-card border-2 border-line bg-sheet text-ink"
      }
    >
      <span className="block text-sm font-semibold">{label}</span>
      <span className="block text-xs">{hint}</span>
    </button>
  );
}

function Stepper({
  label,
  hint,
  value,
  placeholder,
  step,
  onChange,
  onBlur,
  onStep,
}: {
  label: string;
  hint?: string;
  value: string;
  placeholder?: string;
  step: number;
  onChange: (value: string) => void;
  onBlur: () => void;
  onStep: (delta: number) => void;
}) {
  return (
    <div className="grid gap-1">
      <span className="text-sm font-medium">{label}</span>
      {hint ? <span className="text-xs text-muted">{hint}</span> : null}
      <div className="flex items-center gap-2">
        <button className="btn-line size-12 text-xl" type="button" onClick={() => onStep(-step)} aria-label={`${label} घटाओ`}>
          −
        </button>
        <input
          className="h-12 min-w-0 flex-1 rounded-card border border-line bg-sheet px-3 text-center text-lg font-semibold tabular-nums"
          inputMode="decimal"
          value={value}
          placeholder={placeholder}
          onChange={(event) => onChange(event.target.value)}
          onBlur={onBlur}
        />
        <button className="btn-line size-12 text-xl" type="button" onClick={() => onStep(step)} aria-label={`${label} बढ़ाओ`}>
          +
        </button>
      </div>
    </div>
  );
}
