import { useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { clampHours, formatHours, parseLoose, sanitizeDecimal, sanitizeInt } from "@/lib/hajiri/model";
import { useHajiri } from "@/lib/hajiri/store";

export function SettingsDialog({ onClose }: { onClose: () => void }) {
  const settings = useHajiri((state) => state.settings);
  const setSettings = useHajiri((state) => state.setSettings);
  const count = useHajiri((state) => state.entries.length);
  const clearEntries = useHajiri((state) => state.clearEntries);
  const [hours, setHours] = useState(formatHours(settings.dailyHours));
  const [wage, setWage] = useState(settings.dailyWage ? String(settings.dailyWage) : "");
  const [confirmClear, setConfirmClear] = useState(false);

  function commitHours(raw: string) {
    const next = Math.min(16, Math.max(1, clampHours(parseLoose(raw) || 8)));
    const safe = next < 1 ? 1 : next;
    setHours(formatHours(safe));
    setSettings({ dailyHours: safe });
  }

  return (
    <Dialog.Root open onOpenChange={(open) => !open && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-ink/40" />
        <Dialog.Content className="sheet sheet-in fixed inset-x-0 bottom-0 z-50 rounded-t-card border border-line bg-sheet p-4 sm:inset-x-auto sm:bottom-auto sm:left-1/2 sm:top-1/2 sm:w-full sm:max-w-md sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-card sm:p-5">
          <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-line sm:hidden" />
          <div className="flex items-start justify-between gap-3">
            <div>
              <Dialog.Title className="font-display text-3xl leading-none">नाम और मज़दूरी</Dialog.Title>
              <Dialog.Description className="mt-2 text-sm text-muted">
                आधे घंटे पर आधी मज़दूरी गिनी जाएगी। नहीं लिया = मज़दूरी − एडवांस।
              </Dialog.Description>
            </div>
            <Dialog.Close className="inline-flex size-11 shrink-0 items-center justify-center rounded-full" aria-label="बंद करो">
              <X className="size-5" />
            </Dialog.Close>
          </div>

          <div className="mt-4 grid gap-4">
            <label className="grid gap-1 text-sm font-medium">
              आपका नाम
              <input
                className="h-12 rounded-card border border-line bg-sheet px-3 text-base font-normal"
                value={settings.name}
                maxLength={40}
                placeholder="जैसे रमेश"
                onChange={(event) => setSettings({ name: event.target.value })}
              />
            </label>
            <label className="grid gap-1 text-sm font-medium">
              काम या जगह
              <input
                className="h-12 rounded-card border border-line bg-sheet px-3 text-base font-normal"
                value={settings.place}
                maxLength={40}
                placeholder="जैसे साईट, दुकान"
                onChange={(event) => setSettings({ place: event.target.value })}
              />
            </label>

            <div className="grid gap-1">
              <span className="text-sm font-medium">पूरे दिन के घंटे</span>
              <div className="flex items-center gap-2">
                <button
                  className="btn-line size-12 text-xl"
                  type="button"
                  aria-label="घंटे घटाओ"
                  onClick={() => commitHours(String(parseLoose(hours) - 1))}
                >
                  −
                </button>
                <input
                  className="h-12 min-w-0 flex-1 rounded-card border border-line bg-sheet px-3 text-center text-lg font-semibold tabular-nums"
                  inputMode="decimal"
                  value={hours}
                  onChange={(event) => setHours(sanitizeDecimal(event.target.value))}
                  onBlur={() => commitHours(hours)}
                />
                <button
                  className="btn-line size-12 text-xl"
                  type="button"
                  aria-label="घंटे बढ़ाओ"
                  onClick={() => commitHours(String(parseLoose(hours) + 1))}
                >
                  +
                </button>
              </div>
            </div>

            <label className="grid gap-1 text-sm font-medium">
              पूरे दिन की मज़दूरी (₹)
              <input
                className="h-12 rounded-card border border-line bg-sheet px-3 text-base tabular-nums"
                inputMode="numeric"
                placeholder="जैसे 800"
                value={wage}
                onChange={(event) => {
                  const next = sanitizeInt(event.target.value);
                  setWage(next);
                  setSettings({ dailyWage: next ? Number(next) : 0 });
                }}
              />
            </label>

            <p className="text-sm text-muted">
              हिसाब सिर्फ इसी फ़ोन में रहता है। फ़ोन बदलो या डेटा मिटाओ तो हिसाब चला जाएगा — PDF निकाल कर रख
              लो।
            </p>

            {count > 0 && !confirmClear ? (
              <button className="h-11 text-sm font-medium text-copper" type="button" onClick={() => setConfirmClear(true)}>
                सारी हाजिरी मिटाओ
              </button>
            ) : null}
            {confirmClear ? (
              <div className="grid gap-2 rounded-card bg-copper-soft p-3">
                <p className="text-sm">यह वापस नहीं आएगा। नाम और मज़दूरी रह जाएगी। PDF पहले निकाल लो।</p>
                <div className="grid grid-cols-2 gap-2">
                  <button className="btn-line h-12" type="button" onClick={() => setConfirmClear(false)}>
                    रहने दो
                  </button>
                  <button
                    className="btn-copper h-12"
                    type="button"
                    onClick={() => {
                      clearEntries();
                      setConfirmClear(false);
                      onClose();
                    }}
                  >
                    हाँ, मिटा दो
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
