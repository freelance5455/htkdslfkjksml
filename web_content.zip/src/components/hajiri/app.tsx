import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Download, Plus, Settings } from "lucide-react";
import {
  dayBadge,
  dayNumber,
  formatHours,
  formatMonth,
  groupByMonth,
  hoursPhrase,
  inr,
  shiftMonth,
  summarize,
  todayISO,
  weekdayShort,
} from "@/lib/hajiri/model";
import { downloadHajiriPdf } from "@/lib/hajiri/pdf";
import { useHajiri } from "@/lib/hajiri/store";
import { EntryDialog } from "@/components/hajiri/entry-dialog";
import { SettingsDialog } from "@/components/hajiri/settings-dialog";

export function HajiriApp() {
  const settings = useHajiri((state) => state.settings);
  const entries = useHajiri((state) => state.entries);
  const [ready, setReady] = useState(false);
  const [month, setMonth] = useState("");
  const [today, setToday] = useState("");
  const [entryOpen, setEntryOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [draftDate, setDraftDate] = useState("");
  const [session, setSession] = useState(0);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [pdfNote, setPdfNote] = useState("");

  useEffect(() => {
    setToday(todayISO());
    setMonth(todayISO().slice(0, 7));
    const unsub = useHajiri.persist.onFinishHydration(() => setReady(true));
    if (useHajiri.persist.hasHydrated()) setReady(true);
    return unsub;
  }, []);

  const monthEntries = useMemo(
    () =>
      entries
        .filter((entry) => month && entry.date.startsWith(month))
        .slice()
        .sort((a, b) => (a.date < b.date ? 1 : -1)),
    [entries, month],
  );
  const summary = useMemo(() => summarize(monthEntries, settings), [monthEntries, settings]);
  const hasOther = entries.some((entry) => month && !entry.date.startsWith(month));
  const todayFilled = Boolean(today && entries.some((entry) => entry.date === today));
  const wageSet = settings.dailyWage > 0;
  const who = [settings.name, settings.place].filter(Boolean).join(" · ");

  function openDate(iso: string) {
    setDraftDate(iso);
    setSession((value) => value + 1);
    setEntryOpen(true);
    setPdfNote("");
  }

  async function exportPdf(scope: "month" | "book") {
    const sections =
      scope === "month"
        ? [{ month, entries: monthEntries.slice().sort((a, b) => (a.date < b.date ? -1 : 1)) }]
        : groupByMonth(entries);
    const printable = sections.filter((section) => section.entries.length > 0);
    if (printable.length === 0 || pdfBusy) return;
    setPdfBusy(true);
    setPdfNote("");
    try {
      await downloadHajiriPdf({
        filename: scope === "month" ? `hajiri-${month}.pdf` : "hajiri-poori-kitab.pdf",
        name: settings.name,
        place: settings.place,
        settings,
        preparedOn: new Date(),
        sections: printable.map((section) => ({
          monthLabel: formatMonth(section.month),
          entries: section.entries,
          summary: summarize(section.entries, settings),
        })),
      });
      setPdfNote("PDF डाउनलोड हो गई।");
    } catch {
      setPdfNote("PDF नहीं बन पाई। एक बार और दबाओ।");
    } finally {
      setPdfBusy(false);
    }
  }

  return (
    <main className="dock-pad min-h-screen">
      <div className="mx-auto w-full max-w-5xl px-5 py-5 sm:px-8 sm:py-8">
        <header className="flex items-center gap-3">
          <div className="flex size-14 shrink-0 items-center justify-center rounded-full border border-stamp" aria-hidden="true">
            <div className="flex size-11 items-center justify-center rounded-full border border-stamp font-display text-lg leading-none text-stamp">
              हा
            </div>
          </div>
          <div className="min-w-0">
            <h1 className="font-display text-3xl leading-none sm:text-4xl">मेरी हाजिरी</h1>
            <p className="mt-1 truncate text-sm text-muted">{who || "दिन, घंटे और एडवांस का हिसाब"}</p>
          </div>
        </header>

        <div className="mt-5 grid items-start gap-4 lg:grid-cols-3">
          <aside className="book lg:sticky lg:top-4">
            <div className="px-4 py-4">
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  className="inline-flex size-11 items-center justify-center rounded-full border border-line"
                  aria-label="पिछला महीना"
                  disabled={!month}
                  onClick={() => setMonth((value) => shiftMonth(value, -1))}
                >
                  <ChevronLeft className="size-5" />
                </button>
                <div className="text-center">
                  <p className="font-display text-2xl leading-tight">{month ? formatMonth(month) : "…"}</p>
                  {today && month && month !== today.slice(0, 7) ? (
                    <button
                      type="button"
                      className="text-sm font-semibold text-stamp"
                      onClick={() => setMonth(today.slice(0, 7))}
                    >
                      आज पर जाओ
                    </button>
                  ) : null}
                </div>
                <button
                  type="button"
                  className="inline-flex size-11 items-center justify-center rounded-full border border-line"
                  aria-label="अगला महीना"
                  disabled={!month}
                  onClick={() => setMonth((value) => shiftMonth(value, 1))}
                >
                  <ChevronRight className="size-5" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 border-t border-line">
              <Stat label="दिन काम" value={ready ? String(summary.daysWorked) : "—"} />
              <Stat label="दिन छुट्टी" value={ready ? String(summary.daysOff) : "—"} />
              <Stat label="घंटे काम" value={ready ? formatHours(summary.hoursWorked) : "—"} />
              <Stat label="घंटे नहीं" value={ready ? formatHours(summary.hoursMissed) : "—"} />
            </div>

            <div className="grid grid-cols-2">
              <div className="border-r border-line px-4 py-3">
                <p className="text-sm text-muted">एडवांस लिया</p>
                <p className="mt-1 text-xl font-semibold tabular-nums text-copper">
                  {ready ? inr(summary.advance) : "—"}
                </p>
              </div>
              <div className="px-4 py-3">
                <p className="text-sm text-muted">{summary.remaining < 0 && wageSet ? "एडवांस ज़्यादा" : "नहीं लिया"}</p>
                <p className={`mt-1 text-xl font-semibold tabular-nums ${summary.remaining < 0 && wageSet ? "text-copper" : "text-stamp"}`}>
                  {ready && wageSet ? inr(Math.abs(summary.remaining)) : "—"}
                </p>
              </div>
            </div>

            <div className="grid gap-3 border-t border-line px-4 py-4">
              {wageSet ? (
                <p className="text-sm text-muted">
                  मज़दूरी {inr(summary.earned)} − एडवांस {inr(summary.advance)} = बाकी {inr(summary.remaining)}
                </p>
              ) : (
                <p className="text-sm text-muted">बाकी निकालने के लिए पूरे दिन की मज़दूरी लिखो।</p>
              )}
              <button className="btn-line inline-flex h-12 items-center justify-center gap-2" type="button" onClick={() => setSettingsOpen(true)}>
                <Settings className="size-5" />
                नाम और मज़दूरी
              </button>
              <button
                className="btn-stamp inline-flex h-12 items-center justify-center gap-2"
                type="button"
                disabled={!ready || monthEntries.length === 0 || pdfBusy}
                onClick={() => exportPdf("month")}
              >
                <Download className="size-5" />
                इस महीने का PDF
              </button>
              <button
                className="btn-line inline-flex h-12 items-center justify-center gap-2"
                type="button"
                disabled={!ready || entries.length === 0 || pdfBusy}
                onClick={() => exportPdf("book")}
              >
                <Download className="size-5" />
                पूरी किताब का PDF
              </button>
              <p className="text-sm text-muted" role="status">
                {pdfNote || "हिसाब इसी फ़ोन में सेव होता है।"}
              </p>
            </div>
          </aside>

          <section className="book lg:col-span-2" aria-label="इस महीने की हाजिरी">
            <div className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
              <h2 className="font-display text-2xl leading-none">रजिस्टर</h2>
              <button
                className="btn-stamp hidden h-11 items-center gap-2 px-4 lg:inline-flex"
                type="button"
                disabled={!ready}
                onClick={() => openDate(today || todayISO())}
              >
                <Plus className="size-5" />
                {todayFilled ? "आज बदलो" : "आज भरो"}
              </button>
            </div>
            {!ready ? (
              <p className="px-4 py-8 text-sm text-muted">हिसाब खुल रहा है…</p>
            ) : monthEntries.length === 0 ? (
              <div className="px-4 py-10 text-center">
                <p className="font-display text-3xl">अभी खाली है</p>
                <p className="mx-auto mt-2 max-w-xs text-sm text-muted">
                  {hasOther
                    ? "इस महीने कुछ नहीं भरा। ऊपर तीर से दूसरा महीना खोलो।"
                    : "आज की हाजिरी भरो दबाकर पहला दिन लिखो। घंटे, छुट्टी और एडवांस एक साथ रहेंगे।"}
                </p>
              </div>
            ) : (
              <ul>
                {monthEntries.map((entry) => {
                  const badge = dayBadge(entry, settings.dailyHours);
                  const tone =
                    badge.tone === "stamp"
                      ? "bg-stamp-soft text-stamp"
                      : badge.tone === "copper"
                        ? "bg-copper-soft text-copper"
                        : "bg-paper text-ink";
                  return (
                    <li key={entry.id} className="border-b border-line last:border-b-0">
                      <button
                        type="button"
                        className={`flex w-full items-center gap-3 px-4 py-3 text-left ${entry.date === today ? "bg-stamp-soft" : ""}`}
                        onClick={() => openDate(entry.date)}
                      >
                        <span className="w-12 shrink-0 text-center">
                          <span className="block font-display text-3xl leading-none">{dayNumber(entry.date)}</span>
                          <span className="text-xs text-muted">{weekdayShort(entry.date)}</span>
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="flex flex-wrap items-center gap-2">
                            <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${tone}`}>{badge.label}</span>
                            {entry.date === today ? <span className="text-xs font-semibold text-stamp">आज</span> : null}
                            {entry.advance > 0 ? (
                              <span className="text-sm font-medium text-copper">एडवांस {inr(entry.advance)}</span>
                            ) : null}
                          </span>
                          <span className="mt-1 block text-sm text-muted">
                            {hoursPhrase(entry.hoursWorked)} काम · {hoursPhrase(entry.hoursMissed)} नहीं
                          </span>
                          {entry.note ? <span className="mt-0.5 block truncate text-sm">{entry.note}</span> : null}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </div>
      </div>

      {ready && !entryOpen && !settingsOpen ? (
        <div className="dock lg:hidden">
          <button
            className="btn-stamp inline-flex h-12 w-full items-center justify-center gap-2"
            type="button"
            onClick={() => openDate(today || todayISO())}
          >
            <Plus className="size-5" />
            {todayFilled ? "आज की हाजिरी बदलो" : "आज की हाजिरी भरो"}
          </button>
        </div>
      ) : null}

      {entryOpen ? (
        <EntryDialog
          key={session}
          initialDate={draftDate}
          onClose={() => setEntryOpen(false)}
          onSaved={(date) => {
            setMonth(date.slice(0, 7));
            setEntryOpen(false);
          }}
        />
      ) : null}
      {settingsOpen ? <SettingsDialog onClose={() => setSettingsOpen(false)} /> : null}
      {pdfBusy ? (
        <div className="pdf-cover" role="status">
          <p className="font-display text-3xl">PDF बन रही है…</p>
        </div>
      ) : null}
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="border-b border-line px-4 py-3 odd:border-r">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 text-2xl font-semibold tabular-nums leading-none">{value}</p>
    </div>
  );
}
