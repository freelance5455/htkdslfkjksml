import React, { useState } from 'react';
import { 
  Smartphone, 
  Download, 
  Code2, 
  CheckCircle2, 
  ShieldCheck, 
  Zap, 
  WifiOff, 
  Printer, 
  QrCode, 
  Terminal, 
  FileCode,
  Copy,
  Check,
  ExternalLink,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';
import { androidExportService } from '../services/androidExportService';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidApkViewProps {
  language: Language;
}

export const AndroidApkView: React.FC<AndroidApkViewProps> = ({ language }) => {
  const t = translations[language];
  const { isInstallable, isInstalled, install, isIOS } = usePWAInstall();
  const [showKotlinCode, setShowKotlinCode] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const kotlinData = androidExportService.getAndroidKotlinCode();

  const handleCopyCode = () => {
    navigator.clipboard.writeText(kotlinData.mainActivity);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Smartphone className="w-6 h-6 text-emerald-400" />
            <span>{t.androidApkTitle}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Installable Android App package, APK release build, and complete Android Studio Kotlin source project.
          </p>
        </div>

        <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-950 text-emerald-400 border border-emerald-800 self-start md:self-auto flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4" />
          <span>Release v1.0.0 Verified</span>
        </span>
      </div>

      {/* Main Download & Installation Action Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Method 1: Direct WebAPK Install on Android (Fastest & Verified) */}
        <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-850 border border-slate-700/80 shadow-xl flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Recommended for Android Phones
              </span>
              <Smartphone className="w-5 h-5 text-emerald-400" />
            </div>

            <h3 className="text-lg font-bold text-white mt-3">
              1-Click Android WebAPK Installation
            </h3>
            <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
              Instantly installs the verified WebAPK directly on your Android phone home screen with native app icon, offline caching, and fullscreen launcher.
            </p>

            <ul className="mt-4 space-y-2 text-xs text-slate-300">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Zero configuration required – installs in 2 seconds</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Works offline during field collection visits in Champeswar</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Supports Bluetooth / Wi-Fi thermal receipt printing</span>
              </li>
            </ul>
          </div>

          <div className="pt-2">
            {isInstalled ? (
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800 text-center text-xs font-bold text-emerald-300">
                ✓ Already Installed &amp; Running in Standalone App Mode!
              </div>
            ) : isInstallable ? (
              <button
                onClick={install}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-extrabold text-sm shadow-lg shadow-emerald-950/50 transition flex items-center justify-center gap-2 active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>{t.installPwa}</span>
              </button>
            ) : (
              <button
                onClick={() => androidExportService.downloadReleaseApk()}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-extrabold text-sm shadow-lg shadow-emerald-950/50 transition flex items-center justify-center gap-2 active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>Download CCTV_Network_Champeswar.apk</span>
              </button>
            )}
          </div>
        </div>

        {/* Method 2: Android Studio Kotlin Project & Standalone APK */}
        <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-850 border border-slate-700/80 shadow-xl flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                Native Source Code
              </span>
              <Code2 className="w-5 h-5 text-cyan-400" />
            </div>

            <h3 className="text-lg font-bold text-white mt-3">
              Android Studio Project &amp; APK
            </h3>
            <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
              Complete Kotlin project source files with <code>MainActivity.kt</code>, <code>AndroidManifest.xml</code>, Gradle configuration, and native printing bridge.
            </p>

            <ul className="mt-4 space-y-2 text-xs text-slate-300">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Package: <code>com.cctvnetwork.champeswar</code></span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Hardware bridge for Android PrintManager &amp; thermal printers</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Direct intent routing for WhatsApp &amp; UPI payment apps</span>
              </li>
            </ul>
          </div>

          <div className="space-y-2 pt-2">
            <button
              onClick={() => androidExportService.downloadReleaseApk()}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>{t.downloadApk} (v1.0.0)</span>
            </button>

            <button
              onClick={() => androidExportService.downloadAndroidSourceZip()}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-850 hover:bg-slate-800 border border-cyan-900/60 text-cyan-300 font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
            >
              <FileCode className="w-4 h-4 text-cyan-400" />
              <span>{t.androidStudioProject}</span>
            </button>
          </div>
        </div>

      </div>

      {/* APK Step-by-Step Installation Instructions */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Terminal className="w-4 h-4 text-cyan-400" />
          <span>{t.installationGuide}</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          
          <div className="p-4 rounded-xl bg-slate-850 border border-slate-800 space-y-2">
            <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold text-xs">
              1
            </div>
            <h4 className="font-bold text-sm text-slate-100">{t.step1Title}</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              {t.step1Desc}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-850 border border-slate-800 space-y-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs">
              2
            </div>
            <h4 className="font-bold text-sm text-slate-100">{t.step2Title}</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              {t.step2Desc}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-850 border border-slate-800 space-y-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-bold text-xs">
              3
            </div>
            <h4 className="font-bold text-sm text-slate-100">{t.step3Title}</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              {t.step3Desc}
            </p>
          </div>

        </div>
      </div>

      {/* Expandable Source Code Viewer */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Code2 className="w-4 h-4 text-cyan-400" />
              <span>Android Kotlin Code Inspection</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Review MainActivity.kt native bridge and AndroidManifest.xml before compilation.
            </p>
          </div>

          <button
            onClick={() => setShowKotlinCode(!showKotlinCode)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-cyan-300 font-semibold"
          >
            <span>{showKotlinCode ? 'Hide Code' : 'View Code'}</span>
            {showKotlinCode ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {showKotlinCode && (
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono text-cyan-400">app/src/main/java/com/cctvnetwork/champeswar/MainActivity.kt</span>
              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1 text-slate-300 hover:text-white"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCode ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto max-h-80 leading-relaxed">
              {kotlinData.mainActivity}
            </pre>
          </div>
        )}
      </div>

    </div>
  );
};
