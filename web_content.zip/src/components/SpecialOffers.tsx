import React from 'react';
import { useApp } from '../context/AppContext';
import { SPECIAL_OFFERS } from '../data/initialData';
import { Sparkles, MessageCircle, Check, Tag } from 'lucide-react';

export const SpecialOffers: React.FC = () => {
  const { language, t, shopSettings } = useApp();

  const handleEnquireOffer = (title: string, price: number) => {
    const text = encodeURIComponent(
      `नमस्ते A K Golu Computer! मुझे आपके स्पेशल ऑफर पैकेज के बारे में जानना है:\n*${title}*\nऑफर मूल्य: ₹${price.toLocaleString('en-IN')}\nकृपया बुकिंग और समय बताएं।`
    );
    window.open(`https://wa.me/91${shopSettings.phone1}?text=${text}`, '_blank');
  };

  return (
    <section id="offers" className="py-14 sm:py-16 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.specialOffers.badge}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t.specialOffers.title}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            {t.specialOffers.subtitle}
          </p>
        </div>

        {/* Offers Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {SPECIAL_OFFERS.map((offer) => {
            const savings = offer.mrp - offer.price;
            const title = offer.title[language] || offer.title.en;

            return (
              <div
                key={offer.id}
                className="relative p-6 sm:p-7 rounded-2xl bg-slate-900 border border-amber-500/30 shadow-xl overflow-hidden flex flex-col justify-between"
              >
                {/* Glow accent */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none"></div>

                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {offer.tag[language] || offer.tag.en}
                    </span>
                    <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                      {language === 'hi' ? `₹${savings.toLocaleString('en-IN')} की सीधी बचत` : `Save ₹${savings.toLocaleString('en-IN')}`}
                    </span>
                  </div>

                  <h3 className="text-lg sm:text-xl font-bold text-white mb-2 leading-snug">
                    {title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                    {offer.description[language] || offer.description.en}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <div className="text-xs text-slate-400">
                      <span className="line-through mr-1.5">MRP ₹{offer.mrp.toLocaleString('en-IN')}</span>
                      <span className="text-amber-400 font-semibold">{offer.expiryText[language] || offer.expiryText.en}</span>
                    </div>
                    <div className="text-2xl font-black text-white">
                      ₹{offer.price.toLocaleString('en-IN')}
                    </div>
                  </div>

                  <button
                    onClick={() => handleEnquireOffer(title, offer.price)}
                    className="py-2.5 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-emerald-600/30 transition flex items-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{language === 'hi' ? 'व्हाट्सएप पर ऑफर बुक करें' : 'Book on WhatsApp'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
