import React, { useState } from 'react';
import {
  Plus,
  Flame,
  Target,
  Check,
  Edit3,
  Trash2,
  Calendar,
  CheckCircle2,
  Circle,
  TrendingUp,
  Award,
} from 'lucide-react';
import { useApp, getTodayString } from '../../context/AppContext';
import { Habit, Goal } from '../../types';
import { ConfirmationModal } from '../ConfirmationModal';

interface HabitsAndGoalsProps {
  onOpenHabitModal: (habit?: Habit) => void;
  onOpenGoalModal: (goal?: Goal) => void;
}

export const HabitsAndGoals: React.FC<HabitsAndGoalsProps> = ({
  onOpenHabitModal,
  onOpenGoalModal,
}) => {
  const {
    habits,
    goals,
    incrementHabitCount,
    decrementHabitCount,
    deleteHabit,
    deleteGoal,
    toggleGoalMilestone,
    t,
    todayMetrics,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'habits' | 'goals'>('habits');
  const [habitToDelete, setHabitToDelete] = useState<Habit | null>(null);
  const [goalToDelete, setGoalToDelete] = useState<Goal | null>(null);

  const todayStr = getTodayString();

  // Generate last 7 days keys for the weekly dots
  const last7Days: string[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    last7Days.push(
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
    );
  }

  return (
    <div className="space-y-5 pb-8">
      {/* Top Header */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
            {t.navHabits}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {activeTab === 'habits'
              ? `${todayMetrics.habitsDone} / ${habits.length} habits achieved today`
              : `${goals.length} strategic targets in progress`}
          </p>
        </div>

        <button
          onClick={() => (activeTab === 'habits' ? onOpenHabitModal() : onOpenGoalModal())}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold shadow-xs active:scale-95 transition-all"
        >
          <Plus size={16} />
          <span>{activeTab === 'habits' ? t.addHabit : t.addGoal}</span>
        </button>
      </div>

      {/* Habits vs Goals Toggle */}
      <div className="flex p-1 rounded-2xl bg-slate-100 dark:bg-slate-800">
        <button
          onClick={() => setActiveTab('habits')}
          className={`flex-1 py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'habits'
              ? 'bg-white dark:bg-slate-700 text-violet-600 dark:text-violet-300 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Flame size={15} />
          <span>{t.habitSummary}</span>
          <span className="px-1.5 py-0.5 rounded-full bg-violet-100 dark:bg-violet-900/60 text-[10px]">
            {habits.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('goals')}
          className={`flex-1 py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'goals'
              ? 'bg-white dark:bg-slate-700 text-violet-600 dark:text-violet-300 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Target size={15} />
          <span>{t.goalsTitle}</span>
          <span className="px-1.5 py-0.5 rounded-full bg-violet-100 dark:bg-violet-900/60 text-[10px]">
            {goals.length}
          </span>
        </button>
      </div>

      {/* Content for Habits */}
      {activeTab === 'habits' && (
        <div className="space-y-4">
          {/* Streak Banner */}
          <div className="p-4 rounded-3xl bg-linear-to-r from-amber-500/10 via-violet-500/10 to-indigo-500/10 border border-amber-500/20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-amber-500 text-white shadow-xs">
                <Flame size={20} className="fill-white" />
              </div>
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                  {t.currentStreak}
                </h4>
                <p className="text-xl font-extrabold text-slate-900 dark:text-white">
                  {todayMetrics.currentStreak} {t.days}
                </p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 block">
                {t.bestStreak}
              </span>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                {todayMetrics.bestStreak} {t.days}
              </span>
            </div>
          </div>

          {habits.length === 0 ? (
            <div className="text-center py-12 px-6 rounded-3xl bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 shadow-xs">
              <Flame size={36} className="mx-auto text-slate-300 dark:text-slate-600 mb-2" />
              <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                {t.emptyHabitsToday}
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                {t.emptyHabitsTodaySub}
              </p>
              <button
                onClick={() => onOpenHabitModal()}
                className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700 transition-colors"
              >
                <Plus size={14} />
                <span>{t.addHabit}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {habits.map((habit) => {
                const currentToday = habit.history[todayStr] || 0;
                const isComplete = currentToday >= habit.targetCount;
                return (
                  <div
                    key={habit.id}
                    className={`p-4 rounded-3xl border transition-all ${
                      isComplete
                        ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200/80 dark:border-emerald-800/50'
                        : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:shadow-xs'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span
                            className="w-3 h-3 rounded-full shrink-0"
                            style={{ backgroundColor: habit.color || '#7c3aed' }}
                          />
                          <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                            {habit.title}
                          </h4>
                        </div>

                        {habit.description && (
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                            {habit.description}
                          </p>
                        )}

                        {/* 7-Day History Mini-Dots */}
                        <div className="flex items-center gap-1.5 mt-3">
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 mr-1">
                            Past 7d:
                          </span>
                          {last7Days.map((dStr, idx) => {
                            const val = habit.history[dStr] || 0;
                            const done = val >= habit.targetCount;
                            const isToday = dStr === todayStr;
                            return (
                              <div
                                key={idx}
                                title={`${dStr}: ${val}/${habit.targetCount} ${habit.unit}`}
                                className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] transition-all ${
                                  done
                                    ? 'bg-emerald-500 text-white font-bold'
                                    : isToday
                                    ? 'bg-slate-200 dark:bg-slate-700 ring-2 ring-violet-400'
                                    : 'bg-slate-200 dark:bg-slate-800'
                                }`}
                              >
                                {done && <Check size={10} className="stroke-[3]" />}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Right side controls */}
                      <div className="flex flex-col items-end gap-2 shrink-0">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => onOpenHabitModal(habit)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                            title={t.edit}
                          >
                            <Edit3 size={14} />
                          </button>
                          <button
                            onClick={() => setHabitToDelete(habit)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                            title={t.delete}
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>

                        {/* Increment / Decrement Stepper */}
                        <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl">
                          <button
                            onClick={() => decrementHabitCount(habit.id)}
                            disabled={currentToday === 0}
                            className="w-7 h-7 rounded-xl bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 disabled:opacity-40 flex items-center justify-center text-xs font-bold active:scale-90 transition-all"
                            title="Decrement"
                          >
                            -
                          </button>

                          <span className="px-2 font-mono text-xs font-bold text-slate-900 dark:text-white min-w-[42px] text-center">
                            {currentToday}/{habit.targetCount}
                          </span>

                          <button
                            onClick={() => incrementHabitCount(habit.id)}
                            className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold active:scale-90 transition-all ${
                              isComplete
                                ? 'bg-emerald-500 text-white'
                                : 'bg-violet-600 hover:bg-violet-700 text-white shadow-xs'
                            }`}
                            title="Increment"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Content for Goals */}
      {activeTab === 'goals' && (
        <div className="space-y-4">
          {goals.length === 0 ? (
            <div className="text-center py-12 px-6 rounded-3xl bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 shadow-xs">
              <Target size={36} className="mx-auto text-slate-300 dark:text-slate-600 mb-2" />
              <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                {t.emptyGoals}
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                {t.emptyGoalsSub}
              </p>
              <button
                onClick={() => onOpenGoalModal()}
                className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700 transition-colors"
              >
                <Plus size={14} />
                <span>{t.addGoal}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {goals.map((goal) => {
                const completedMilestones = goal.milestones.filter((m) => m.completed).length;
                return (
                  <div
                    key={goal.id}
                    className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span
                            className="w-3 h-3 rounded-full shrink-0"
                            style={{ backgroundColor: goal.color || '#8b5cf6' }}
                          />
                          <h4 className="text-base font-bold text-slate-900 dark:text-white truncate">
                            {goal.title}
                          </h4>
                        </div>
                        {goal.description && (
                          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                            {goal.description}
                          </p>
                        )}
                        <div className="flex items-center gap-3 mt-2 text-xs text-slate-500 dark:text-slate-400">
                          <span className="flex items-center gap-1">
                            <Calendar size={13} />
                            Target: {goal.targetDate}
                          </span>
                          <span className="capitalize px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold">
                            {goal.category}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => onOpenGoalModal(goal)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                          title={t.edit}
                        >
                          <Edit3 size={15} />
                        </button>
                        <button
                          onClick={() => setGoalToDelete(goal)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                          title={t.delete}
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>

                    {/* Progress Bar & Percentage */}
                    <div>
                      <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                        <span className="text-slate-700 dark:text-slate-300">
                          Overall Progress
                        </span>
                        <span className="font-mono text-violet-600 dark:text-violet-400 text-sm">
                          {goal.progress}%
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${goal.progress}%`,
                            backgroundColor: goal.color || '#8b5cf6',
                          }}
                        />
                      </div>
                    </div>

                    {/* Action Milestones */}
                    {goal.milestones.length > 0 && (
                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80">
                        <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-2">
                          <span>{t.milestones}</span>
                          <span>{completedMilestones} / {goal.milestones.length}</span>
                        </div>
                        <div className="space-y-1.5">
                          {goal.milestones.map((m) => (
                            <div
                              key={m.id}
                              onClick={() => toggleGoalMilestone(goal.id, m.id)}
                              className={`flex items-center gap-2.5 p-2 rounded-xl text-xs cursor-pointer transition-colors ${
                                m.completed
                                  ? 'bg-slate-50 dark:bg-slate-800/40 text-slate-400 dark:text-slate-500 line-through'
                                  : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200'
                              }`}
                            >
                              {m.completed ? (
                                <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                              ) : (
                                <Circle size={16} className="text-slate-400 shrink-0" />
                              )}
                              <span className="truncate">{m.title}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Delete Habit Modal */}
      <ConfirmationModal
        isOpen={Boolean(habitToDelete)}
        title={t.deleteHabit}
        message="Are you sure you want to delete this habit and all its logged history?"
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        isDestructive={true}
        onConfirm={() => {
          if (habitToDelete) {
            deleteHabit(habitToDelete.id);
            setHabitToDelete(null);
          }
        }}
        onClose={() => setHabitToDelete(null)}
      />

      {/* Delete Goal Modal */}
      <ConfirmationModal
        isOpen={Boolean(goalToDelete)}
        title={t.deleteGoal}
        message="Are you sure you want to permanently delete this goal?"
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        isDestructive={true}
        onConfirm={() => {
          if (goalToDelete) {
            deleteGoal(goalToDelete.id);
            setGoalToDelete(null);
          }
        }}
        onClose={() => setGoalToDelete(null)}
      />
    </div>
  );
};
