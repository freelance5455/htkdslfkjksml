import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Calendar } from 'lucide-react';
import { Goal, GoalMilestone } from '../../types';
import { useApp } from '../../context/AppContext';

interface GoalModalProps {
  isOpen: boolean;
  goalToEdit?: Goal | null;
  onClose: () => void;
}

export const GoalModal: React.FC<GoalModalProps> = ({ isOpen, goalToEdit, onClose }) => {
  const { addGoal, updateGoal, t } = useApp();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<Goal['category']>('personal');
  const [targetDate, setTargetDate] = useState('');
  const [progress, setProgress] = useState<number>(0);
  const [milestones, setMilestones] = useState<GoalMilestone[]>([]);
  const [newMilestoneText, setNewMilestoneText] = useState('');
  const [color, setColor] = useState('#8b5cf6');

  useEffect(() => {
    if (goalToEdit) {
      setTitle(goalToEdit.title);
      setDescription(goalToEdit.description || '');
      setCategory(goalToEdit.category);
      setTargetDate(goalToEdit.targetDate);
      setProgress(goalToEdit.progress);
      setMilestones(goalToEdit.milestones || []);
      setColor(goalToEdit.color || '#8b5cf6');
    } else {
      setTitle('');
      setDescription('');
      setCategory('personal');
      // default 3 months ahead
      const future = new Date();
      future.setMonth(future.getMonth() + 3);
      setTargetDate(future.toISOString().split('T')[0]);
      setProgress(0);
      setMilestones([
        { id: `m-${Date.now()}-1`, title: 'Define actionable roadmap and resources', completed: false },
        { id: `m-${Date.now()}-2`, title: 'Reach 50% midpoint review', completed: false },
      ]);
      setColor('#8b5cf6');
    }
    setNewMilestoneText('');
  }, [goalToEdit, isOpen]);

  if (!isOpen) return null;

  const handleAddMilestone = () => {
    if (!newMilestoneText.trim()) return;
    setMilestones((prev) => [
      ...prev,
      {
        id: `m-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        title: newMilestoneText.trim(),
        completed: false,
      },
    ]);
    setNewMilestoneText('');
  };

  const handleRemoveMilestone = (id: string) => {
    setMilestones((prev) => prev.filter((m) => m.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !targetDate) return;

    if (goalToEdit) {
      updateGoal({
        ...goalToEdit,
        title: title.trim(),
        description: description.trim(),
        category,
        targetDate,
        progress: Math.min(100, Math.max(0, Number(progress))),
        milestones,
        color,
      });
    } else {
      addGoal({
        title: title.trim(),
        description: description.trim(),
        category,
        targetDate,
        progress: Math.min(100, Math.max(0, Number(progress))),
        milestones,
        color,
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-6 shadow-2xl transition-all max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Close"
        >
          <X size={18} />
        </button>

        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-5">
          {goalToEdit ? t.editGoal : t.addGoal}
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t.goalTitle} *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={t.goalTitlePlaceholder}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-violet-500"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t.goalDescription}
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Why this goal matters to you..."
              className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-violet-500"
            />
          </div>

          {/* Target Date & Domain */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Calendar size={14} />
                <span>{t.targetDate} *</span>
              </label>
              <input
                type="date"
                required
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-violet-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                {t.goalCategory}
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Goal['category'])}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-violet-500 capitalize"
              >
                <option value="career">Career & Work</option>
                <option value="spiritual">Spiritual & Quran</option>
                <option value="health">Health & Fitness</option>
                <option value="learning">Education & Skills</option>
                <option value="personal">Personal Growth</option>
                <option value="finance">Finance</option>
              </select>
            </div>
          </div>

          {/* Manual Progress Slider */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                {t.progressPercent}
              </label>
              <span className="text-sm font-bold font-mono text-violet-600 dark:text-violet-400">
                {progress}%
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={progress}
              onChange={(e) => setProgress(Number(e.target.value))}
              className="w-full accent-violet-600 cursor-pointer"
            />
          </div>

          {/* Milestones list */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
              {t.milestones}
            </label>
            <div className="space-y-2 mb-3 max-h-40 overflow-y-auto">
              {milestones.map((m) => (
                <div
                  key={m.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs"
                >
                  <span className="truncate pr-2 text-slate-800 dark:text-slate-200">{m.title}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveMilestone(m.id)}
                    className="text-slate-400 hover:text-rose-500 p-1"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
            </div>

            {/* Add milestone input */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={newMilestoneText}
                onChange={(e) => setNewMilestoneText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddMilestone();
                  }
                }}
                placeholder={t.milestonePlaceholder}
                className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-hidden focus:ring-2 focus:ring-violet-500"
              />
              <button
                type="button"
                onClick={handleAddMilestone}
                className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1"
              >
                <Plus size={14} />
                <span>Add</span>
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-sm font-semibold text-white shadow-xs active:scale-95 transition-all"
            >
              {t.saveGoal}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
