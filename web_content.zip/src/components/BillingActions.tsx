"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ApiError, apiPost } from "@/lib/client/api";
import { Spinner, useToast } from "./ui";

export default function BillingActions({ planKey, isAdmin }: { planKey: string; isAdmin: boolean }) {
  const router = useRouter();
  const { show, node } = useToast();
  const [busy, setBusy] = useState(false);

  if (planKey === "free") {
    return (
      <div className="flex flex-wrap gap-2">
        {node}
        <Link href="/pricing" className="btn btn-primary btn-sm">
          Upgrade plan
        </Link>
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-2">
      {node}
      {isAdmin ? (
        <Link href="/admin" className="btn btn-ghost btn-sm">
          ⚙️ Admin dashboard
        </Link>
      ) : null}
      <button
        type="button"
        className="btn btn-ghost btn-sm"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          try {
            await apiPost("/api/billing", { planKey: "free" });
            show("Subscription canceled — you're back on Free limits.");
            router.refresh();
          } catch (error) {
            show(error instanceof ApiError ? error.message : "Could not cancel", "bad");
          } finally {
            setBusy(false);
          }
        }}
      >
        {busy ? <Spinner /> : "Cancel subscription"}
      </button>
    </div>
  );
}
