import React, { useEffect, useRef, useState } from "react";
import {
  ChevronRight,
  Globe,
  LogOut,
  Monitor,
  Moon,
  Shield,
  Sun,
  Trash2,
  UserCheck,
} from "lucide-react";
import type {
  AppPage,
  AppSettings,
  LanguagePreference,
  ServerHealth,
  ThemePreference,
  UserProfile,
} from "../types/chat";

interface SettingsPageProps {
  settings: AppSettings;
  onUpdateSettings: (next: AppSettings) => void;
  chatCount: number;
  onRequestClearHistory: () => void;
  health: ServerHealth | null;
  user: UserProfile;
  onSignInGoogleUser: (user: UserProfile) => void;
  onSignOut: () => void;
  onNavigate: (page: AppPage) => void;
}

declare global {
  interface Window {
    google?: {
      accounts?: {
        id?: {
          initialize: (cfg: {
            client_id: string;
            callback: (res: { credential?: string }) => void;
          }) => void;
          renderButton: (
            el: HTMLElement,
            options: { theme?: string; size?: string; width?: number }
          ) => void;
        };
      };
    };
  }
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  settings,
  onUpdateSettings,
  chatCount,
  onRequestClearHistory,
  health,
  user,
  onSignInGoogleUser,
  onSignOut,
  onNavigate,
}) => {
  const googleBtnRef = useRef<HTMLDivElement | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    if (
      !health?.googleAuthConfigured ||
      !health.googleClientId ||
      user.mode === "google"
    ) {
      return;
    }

    let cancelled = false;
    const clientId = health.googleClientId;

    const initGsi = () => {
      if (cancelled || !window.google?.accounts?.id || !googleBtnRef.current) {
        return;
      }
      window.google.accounts.id.initialize({
        client_id: clientId,
        callback: async (response) => {
          if (!response.credential) return;
          setAuthError(null);
          try {
            const res = await fetch("/api/auth/google", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ idToken: response.credential }),
            });
            const data = await res.json();
            if (!res.ok || !data.user) {
              setAuthError(data.message || "Google Sign-In failed.");
              return;
            }
            onSignInGoogleUser(data.user);
          } catch {
            setAuthError("Network error while verifying Google Sign-In.");
          }
        },
      });
      googleBtnRef.current.innerHTML = "";
      window.google.accounts.id.renderButton(googleBtnRef.current, {
        theme: "outline",
        size: "large",
        width: 240,
      });
    };

    if (window.google?.accounts?.id) {
      initGsi();
    } else {
      const existing = document.getElementById("google-gsi-script");
      if (!existing) {
        const script = document.createElement("script");
        script.id = "google-gsi-script";
        script.src = "https://accounts.google.com/gsi/client";
        script.async = true;
        script.defer = true;
        script.onload = initGsi;
        document.head.appendChild(script);
      } else {
        existing.addEventListener("load", initGsi);
      }
    }

    return () => {
      cancelled = true;
    };
  }, [health?.googleAuthConfigured, health?.googleClientId, user.mode, onSignInGoogleUser]);

  const themeOptions: Array<{
    value: ThemePreference;
    label: string;
    icon: React.ReactNode;
  }> = [
    { value: "light", label: "Light", icon: <Sun className="w-4 h-4" /> },
    { value: "dark", label: "Dark", icon: <Moon className="w-4 h-4" /> },
    { value: "system", label: "System", icon: <Monitor className="w-4 h-4" /> },
  ];

  const languageOptions: Array<{
    value: LanguagePreference;
    label: string;
    hint: string;
  }> = [
    {
      value: "auto",
      label: "Auto-detect",
      hint: "Replies in English, বাংলা, or हिन्दी based on your question",
    },
    { value: "en", label: "English", hint: "Always reply in English" },
    { value: "bn", label: "বাংলা (Bengali)", hint: "সবসময় বাংলায় উত্তর দিন" },
    { value: "hi", label: "हिन्दी (Hindi)", hint: "हमेशा हिन्दी में उत्तर दें" },
  ];

  return (
    <div className="flex-1 overflow-y-auto mih-scroll">
      <div className="max-w-3xl mx-auto px-4 sm:px-8 py-6 sm:py-10 space-y-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            Settings
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Customize appearance, language preference, account mode, and chat data.
          </p>
        </div>

        {/* Appearance */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Appearance
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Choose Light, Dark, or match your device theme.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {themeOptions.map((opt) => {
              const active = settings.theme === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() =>
                    onUpdateSettings({ ...settings, theme: opt.value })
                  }
                  className={`min-h-[44px] px-3 py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2 border transition-colors ${
                    active
                      ? "bg-blue-600 border-blue-600 text-white"
                      : "bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                  }`}
                >
                  {opt.icon}
                  <span>{opt.label}</span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Language Preference */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div className="flex items-start gap-2.5">
            <Globe className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 shrink-0" />
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Response Language
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Auto-detect identifies English, Bengali (বাংলা), or Hindi (हिन्दी) automatically.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {languageOptions.map((opt) => {
              const active = settings.language === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() =>
                    onUpdateSettings({ ...settings, language: opt.value })
                  }
                  className={`text-left p-3.5 rounded-xl border transition-colors ${
                    active
                      ? "bg-blue-50 dark:bg-blue-950/40 border-blue-500 text-slate-900 dark:text-white"
                      : "bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                  }`}
                >
                  <div className="text-sm font-semibold">{opt.label}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {opt.hint}
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Account & Authentication */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
          <div className="flex items-start gap-2.5">
            <UserCheck className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 shrink-0" />
            <div className="flex-1">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Account &amp; Sign-In
              </h2>
              {user.mode === "google" ? (
                <div className="mt-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div>
                    <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                      {user.name}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {user.email} · Signed in with Google
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={onSignOut}
                    className="min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 w-fit"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out to Demo Mode</span>
                  </button>
                </div>
              ) : health?.googleAuthConfigured ? (
                <div className="mt-2 space-y-3">
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    Currently running in <strong>Local Demo Mode</strong>. You can
                    sign in with Google below or continue using MIH.AI without an
                    account.
                  </p>
                  <div ref={googleBtnRef} />
                  {authError && (
                    <p className="text-xs text-red-600 dark:text-red-400">
                      {authError}
                    </p>
                  )}
                </div>
              ) : (
                <div className="mt-1.5 space-y-1.5">
                  <div className="text-sm font-medium text-slate-800 dark:text-slate-200">
                    Local Demo Mode (No login required)
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    Google Sign-In is not configured on this server (optional{" "}
                    <code className="font-mono px-1 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                      GOOGLE_CLIENT_ID
                    </code>{" "}
                    is unset). MIH.AI operates honestly in Local Demo Mode and saves
                    your conversations locally in your browser.
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Data Management */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Clear Chat History
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
              {chatCount} saved {chatCount === 1 ? "conversation" : "conversations"}{" "}
              stored locally in this browser.
            </p>
          </div>
          <button
            type="button"
            disabled={chatCount === 0}
            onClick={onRequestClearHistory}
            className="min-h-[44px] px-4 py-2 rounded-xl text-sm font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40 hover:bg-red-100 dark:hover:bg-red-950/70 disabled:opacity-40 inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear All Chats</span>
          </button>
        </section>

        {/* Navigation Links to Privacy & About */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 divide-y divide-slate-200 dark:divide-slate-800 overflow-hidden">
          <button
            type="button"
            onClick={() => onNavigate("about")}
            className="w-full min-h-[56px] px-5 py-3.5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
          >
            <div className="flex items-center gap-3">
              <Shield className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <div>
                <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                  Privacy Policy &amp; About MIH.AI
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Data handling, capabilities, and server setup guide
                </div>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        </section>
      </div>
    </div>
  );
};
