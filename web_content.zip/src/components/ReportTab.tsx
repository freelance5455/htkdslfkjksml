import React, { useState } from 'react';
import {
  BarChart3,
  Calendar,
  TrendingUp,
  DollarSign,
  Receipt,
  Package,
  Printer,
  ChevronDown,
  Sparkles,
  ArrowUpRight,
} from 'lucide-react';
import type { AppDatabase } from '../types/pharmacy.ts';
import { formatIQD, formatDateArabic, calculateProfitReport } from '../utils/calculations.ts';

interface ReportTabProps {
  db: AppDatabase;
}

type PeriodPreset = 'last7Days' | 'thisMonth' | 'lastMonth' | 'thisYear' | 'custom';

export const ReportTab: React.FC<ReportTabProps> = ({ db }) => {
  const [preset, setPreset] = useState<PeriodPreset>('thisMonth');

  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];

  // Helper date generators
  const getPresetDates = (p: PeriodPreset): { start: string; end: string; label: string } => {
    const now = new Date();
    if (p === 'last7Days') {
      const past = new Date(now);
      past.setDate(past.getDate() - 7);
      return {
        start: past.toISOString().split('T')[0],
        end: now.toISOString().split('T')[0],
        label: 'آخر 7 أيام',
      };
    }
    if (p === 'thisMonth') {
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      return {
        start: start.toISOString().split('T')[0],
        end: now.toISOString().split('T')[0],
        label: 'الشهر الحالي',
      };
    }
    if (p === 'lastMonth') {
      const start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const end = new Date(now.getFullYear(), now.getMonth(), 0);
      return {
        start: start.toISOString().split('T')[0],
        end: end.toISOString().split('T')[0],
        label: 'الشهر السابق',
      };
    }
    if (p === 'thisYear') {
      const start = new Date(now.getFullYear(), 0, 1);
      return {
        start: start.toISOString().split('T')[0],
        end: now.toISOString().split('T')[0],
        label: `سنة ${now.getFullYear()}`,
      };
    }
    return {
      start: customStart,
      end: customEnd,
      label: 'فترة مخصصة',
    };
  };

  const initialDates = getPresetDates('thisMonth');
  const [customStart, setCustomStart] = useState(initialDates.start);
  const [customEnd, setCustomEnd] = useState(initialDates.end);

  const activeDates = preset === 'custom' ? { start: customStart, end: customEnd, label: 'فترة مخصصة' } : getPresetDates(preset);

  const report = calculateProfitReport(
    db.purchases,
    db.sales,
    db.expenses,
    activeDates.start,
    activeDates.end,
    activeDates.label
  );

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4 pb-20 animate-fadeIn print:m-0 print:p-0">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs print:hidden">
        <div>
          <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <BarChart3 className="h-6 w-6 text-emerald-700" />
            تقرير الأرباح والجدوى المالية
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            حساب كلفة البضاعة المباعة (COGS) بدقة والأرباح الصافية لكل مادة دوائية
          </p>
        </div>

        <button
          onClick={handlePrint}
          className="flex items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 transition self-start sm:self-auto shadow-2xs"
        >
          <Printer className="h-4 w-4 text-slate-500" />
          طباعة التقرير / PDF
        </button>
      </div>

      {/* Period Selection Controls */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3 print:hidden">
        <label className="block text-xs font-bold text-slate-700">تحديد الفترة الزمنية للتقرير:</label>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setPreset('last7Days')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
              preset === 'last7Days'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            آخر 7 أيام
          </button>
          <button
            onClick={() => setPreset('thisMonth')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
              preset === 'thisMonth'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            الشهر الحالي
          </button>
          <button
            onClick={() => setPreset('lastMonth')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
              preset === 'lastMonth'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            الشهر السابق
          </button>
          <button
            onClick={() => setPreset('thisYear')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
              preset === 'thisYear'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            السنة الحالية
          </button>
          <button
            onClick={() => setPreset('custom')}
            className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
              preset === 'custom'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            نطاق مخصص (من - إلى)
          </button>
        </div>

        {preset === 'custom' && (
          <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">من تاريخ</label>
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-1.5 text-xs font-bold focus:border-emerald-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">إلى تاريخ</label>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-1.5 text-xs font-bold focus:border-emerald-500 focus:outline-hidden"
              />
            </div>
          </div>
        )}
      </div>

      {/* Printable Report Header for export/print */}
      <div className="hidden print:block p-4 border-b border-slate-300 mb-4 text-center">
        <h1 className="text-xl font-bold">دفتر الجرد والأرباح - مذخر ومستودع الأدوية</h1>
        <p className="text-sm text-slate-600">
          تقرير الأرباح للفترة من {formatDateArabic(activeDates.start)} إلى{' '}
          {formatDateArabic(activeDates.end)}
        </p>
      </div>

      {/* Main Profit KPI Banner */}
      <div className="rounded-2xl bg-gradient-to-br from-emerald-700 via-teal-800 to-slate-900 p-5 text-white shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/15 pb-3">
          <div>
            <span className="text-xs font-bold text-emerald-200">
              تقرير الأرباح: {activeDates.label}
            </span>
            <div className="text-xs text-white/70 mt-0.5">
              من {formatDateArabic(activeDates.start)} إلى {formatDateArabic(activeDates.end)}
            </div>
          </div>
          <span className="rounded-full bg-emerald-500/30 px-3 py-1 text-xs font-bold text-emerald-200 border border-emerald-400/30 self-start sm:self-auto">
            هامش صافي الربح: {report.profitMarginPercent.toFixed(1)}%
          </span>
        </div>

        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <span className="text-xs font-bold text-emerald-100 flex items-center gap-1.5">
              <TrendingUp className="h-4 w-4" />
              صافي الربح النهائي (Net Profit)
            </span>
            <div className="text-3xl font-black tracking-tight mt-1">
              {formatIQD(report.netProfit)}
            </div>
            <p className="text-xs text-emerald-200/80 mt-1">
              الربح بعد خصم كلفة البضاعة المباعة وجميع المصاريف التشغيلية
            </p>
          </div>

          <div>
            <span className="text-xs font-bold text-emerald-100">
              إجمالي الربح التشغيلي (Gross Profit)
            </span>
            <div className="text-2xl font-black mt-1">{formatIQD(report.grossProfit)}</div>
            <p className="text-xs text-emerald-200/80 mt-1">
              إجمالي المبيعات ({formatIQD(report.totalSales)}) - كلفة البضاعة ({formatIQD(report.cogs)})
            </p>
          </div>
        </div>
      </div>

      {/* Financial Metrics Cards Breakdown */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
        <div className="rounded-xl bg-white p-3 border border-slate-200/80 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500">إجمالي المبيعات</span>
          <div className="text-sm sm:text-base font-black text-indigo-950 mt-1">
            {formatIQD(report.totalSales)}
          </div>
        </div>

        <div className="rounded-xl bg-white p-3 border border-slate-200/80 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500">كلفة البضاعة المباعة (COGS)</span>
          <div className="text-sm sm:text-base font-black text-slate-900 mt-1">
            {formatIQD(report.cogs)}
          </div>
        </div>

        <div className="rounded-xl bg-emerald-50/70 p-3 border border-emerald-200/70 shadow-xs">
          <span className="text-[11px] font-bold text-emerald-800">إجمالي الربح التشغيلي</span>
          <div className="text-sm sm:text-base font-black text-emerald-700 mt-1">
            {formatIQD(report.grossProfit)}
          </div>
        </div>

        <div className="rounded-xl bg-amber-50/70 p-3 border border-amber-200/70 shadow-xs">
          <span className="text-[11px] font-bold text-amber-800">المصاريف التشغيلية</span>
          <div className="text-sm sm:text-base font-black text-amber-700 mt-1">
            {formatIQD(report.totalExpenses)}
          </div>
        </div>
      </div>

      {/* Profit per Medicine Table */}
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
            <Package className="h-4 w-4 text-emerald-700" />
            أرباح المواد الدوائية المباعة خلال الفترة ({report.medicineProfits.length})
          </h3>
          <span className="text-xs text-slate-400">مرتبة حسب الأكثر ربحية</span>
        </div>

        {report.medicineProfits.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            لا توجد مبيعات مسجلة خلال الفترة المحددة.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-bold">
                <tr>
                  <th className="p-3">المادة الدوائية</th>
                  <th className="p-3 text-center">الكمية المباعة</th>
                  <th className="p-3">الإيراد (المبيعات)</th>
                  <th className="p-3">كلفة البضاعة</th>
                  <th className="p-3 text-emerald-700">صافي الربح</th>
                  <th className="p-3 text-center">نسبة الهامش</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {report.medicineProfits.map((item, index) => (
                  <tr key={item.barcode + index} className="hover:bg-slate-50/70 transition">
                    <td className="p-3 font-bold text-slate-900">
                      <div>{item.medicineName}</div>
                      <div className="text-[10px] font-mono text-slate-400">{item.barcode}</div>
                    </td>
                    <td className="p-3 text-center font-bold text-slate-800">{item.qtySold}</td>
                    <td className="p-3 font-mono font-bold text-slate-900">
                      {formatIQD(item.revenue)}
                    </td>
                    <td className="p-3 font-mono text-slate-600">{formatIQD(item.cogs)}</td>
                    <td className="p-3 font-mono font-black text-emerald-700">
                      {formatIQD(item.grossProfit)}
                    </td>
                    <td className="p-3 text-center">
                      <span className="inline-block rounded-md bg-emerald-50 px-2 py-0.5 font-bold text-emerald-700">
                        {item.marginPercent.toFixed(1)}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
