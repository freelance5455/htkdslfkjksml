import React, { useState } from 'react';
import {
  Trophy,
  Zap,
  Target,
  Award,
  Crown,
  Flame,
  Shield,
  Sparkles,
  Dumbbell,
  Medal,
  TrendingUp,
  CheckCircle,
  BookOpen,
  Star,
  CalendarCheck,
  Lock,
  Unlock,
  Filter,
} from 'lucide-react';
import type { Achievement, AchievementCategory, AchievementRarity } from '../types/achievements.ts';
import type { Player, AppState } from '../types/index.ts';
import { calculatePlayerAchievements } from '../utils/achievementsLogic.ts';

interface AchievementsGalleryProps {
  players: Player[];
  selectedPlayerId: string;
  onSelectPlayer: (id: string) => void;
  state: AppState;
}

export const AchievementsGallery: React.FC<AchievementsGalleryProps> = ({
  players,
  selectedPlayerId,
  onSelectPlayer,
  state,
}) => {
  const [categoryFilter, setCategoryFilter] = useState<'all' | AchievementCategory>('all');

  const selectedPlayer = players.find((p) => p.id === selectedPlayerId) || players[0];
  const achievements = calculatePlayerAchievements(selectedPlayer?.id || '', state);

  const unlockedCount = achievements.filter((a) => a.isUnlocked).length;
  const totalCount = achievements.length;
  const progressPercent = Math.round((unlockedCount / totalCount) * 100);

  const filteredAchievements =
    categoryFilter === 'all'
      ? achievements
      : achievements.filter((a) => a.category === categoryFilter);

  const getIcon = (name: string, unlocked: boolean) => {
    const props = { className: `w-5 h-5 ${unlocked ? 'text-emerald-400' : 'text-neutral-500'}` };
    switch (name) {
      case 'Zap': return <Zap {...props} />;
      case 'Target': return <Target {...props} />;
      case 'Award': return <Award {...props} />;
      case 'Crown': return <Crown {...props} className={unlocked ? 'text-amber-400' : 'text-neutral-500'} />;
      case 'Flame': return <Flame {...props} className={unlocked ? 'text-amber-500' : 'text-neutral-500'} />;
      case 'Shield': return <Shield {...props} />;
      case 'Sparkles': return <Sparkles {...props} className={unlocked ? 'text-purple-400' : 'text-neutral-500'} />;
      case 'Trophy': return <Trophy {...props} className={unlocked ? 'text-amber-400' : 'text-neutral-500'} />;
      case 'Dumbbell': return <Dumbbell {...props} />;
      case 'Medal': return <Medal {...props} className={unlocked ? 'text-amber-400' : 'text-neutral-500'} />;
      case 'TrendingUp': return <TrendingUp {...props} />;
      case 'CheckCircle': return <CheckCircle {...props} />;
      case 'BookOpen': return <BookOpen {...props} />;
      case 'Star': return <Star {...props} className={unlocked ? 'text-amber-400' : 'text-neutral-500'} />;
      case 'CalendarCheck': return <CalendarCheck {...props} />;
      default: return <Trophy {...props} />;
    }
  };

  const getRarityLabel = (rarity: AchievementRarity) => {
    switch (rarity) {
      case 'comum': return { label: 'Comum', style: 'text-neutral-400 border-neutral-700 bg-neutral-800' };
      case 'raro': return { label: 'Raro', style: 'text-blue-400 border-blue-800 bg-blue-950/60' };
      case 'epico': return { label: 'Épico', style: 'text-purple-400 border-purple-800 bg-purple-950/60' };
      case 'lendario': return { label: 'Lendário', style: 'text-amber-400 border-amber-800 bg-amber-950/60' };
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Player Switch */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Trophy className="w-5 h-5 text-amber-400" />
              <h2 className="text-xl font-extrabold text-white">Galeria de Conquistas e Títulos</h2>
            </div>
            <p className="text-xs text-neutral-400">
              Honrarias oficiais por recordes, disciplina semanal e domínio de manobras.
            </p>
          </div>

          {/* Player select */}
          <div className="flex items-center gap-2 bg-neutral-950 p-1.5 rounded-xl border border-neutral-800">
            <span className="text-[11px] text-neutral-500 pl-2">Jogador:</span>
            <select
              value={selectedPlayer?.id}
              onChange={(e) => onSelectPlayer(e.target.value)}
              className="bg-neutral-800 border-0 rounded-lg text-xs font-bold text-white px-2 py-1 focus:ring-1 focus:ring-emerald-500"
              aria-label="Selecionar jogador para ver conquistas"
            >
              {players.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Global Progress Bar */}
        <div className="mt-6 pt-5 border-t border-neutral-800">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-bold text-neutral-300">
              Progresso de {selectedPlayer?.name}
            </span>
            <span className="font-mono-numbers font-extrabold text-emerald-400">
              {unlockedCount} de {totalCount} desbloqueadas ({progressPercent}%)
            </span>
          </div>
          <div className="w-full h-2.5 bg-neutral-950 rounded-full overflow-hidden border border-neutral-800">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-neutral-900 border border-neutral-800 rounded-xl overflow-x-auto">
        <button
          onClick={() => setCategoryFilter('all')}
          className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            categoryFilter === 'all'
              ? 'bg-neutral-800 text-white border border-neutral-700'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          Todas ({achievements.length})
        </button>
        <button
          onClick={() => setCategoryFilter('recorde')}
          className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            categoryFilter === 'recorde'
              ? 'bg-neutral-800 text-white border border-neutral-700'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          Recordes
        </button>
        <button
          onClick={() => setCategoryFilter('consistencia')}
          className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            categoryFilter === 'consistencia'
              ? 'bg-neutral-800 text-white border border-neutral-700'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          Consistência
        </button>
        <button
          onClick={() => setCategoryFilter('vitorias')}
          className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            categoryFilter === 'vitorias'
              ? 'bg-neutral-800 text-white border border-neutral-700'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          Vitórias & Títulos
        </button>
        <button
          onClick={() => setCategoryFilter('geral')}
          className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            categoryFilter === 'geral'
              ? 'bg-neutral-800 text-white border border-neutral-700'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          Manobras & Geral
        </button>
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredAchievements.map((item) => {
          const rarity = getRarityLabel(item.rarity);
          const isDone = item.isUnlocked;

          return (
            <div
              key={item.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                isDone
                  ? 'bg-neutral-900 border-neutral-700/80 shadow-md shadow-emerald-950/20'
                  : 'bg-neutral-900/50 border-neutral-800/60 opacity-80'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center border shadow-inner ${
                        isDone
                          ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-400'
                          : 'bg-neutral-950 border-neutral-800 text-neutral-600'
                      }`}
                    >
                      {getIcon(item.iconName, isDone)}
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-white flex items-center gap-2">
                        <span>{item.title}</span>
                      </h4>
                      <span className={`text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded border inline-block mt-0.5 ${rarity.style}`}>
                        {rarity.label}
                      </span>
                    </div>
                  </div>

                  {isDone ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-800/80 px-2 py-0.5 rounded-full">
                      <Unlock className="w-3 h-3" />
                      <span>Conquistado</span>
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[11px] font-semibold text-neutral-500 bg-neutral-950 border border-neutral-800 px-2 py-0.5 rounded-full">
                      <Lock className="w-3 h-3" />
                      <span>Bloqueado</span>
                    </span>
                  )}
                </div>

                <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                  {item.description}
                </p>
              </div>

              {/* Progress bar if not done */}
              <div className="mt-4 pt-3 border-t border-neutral-800/60">
                <div className="flex items-center justify-between text-[11px] text-neutral-500 mb-1">
                  <span>Requisito</span>
                  <span className="font-mono-numbers text-neutral-300 font-bold">
                    {item.progress.current} / {item.progress.max} {item.progress.unit || ''}
                  </span>
                </div>
                <div className="w-full h-1.5 bg-neutral-950 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      isDone ? 'bg-emerald-400' : 'bg-neutral-700'
                    }`}
                    style={{
                      width: `${Math.min(100, (item.progress.current / item.progress.max) * 100)}%`,
                    }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
