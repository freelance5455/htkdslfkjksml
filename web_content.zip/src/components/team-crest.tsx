import { useState } from "react";
import { cn } from "@/lib/cn";
import { initials } from "@/lib/engine/math";

export function TeamCrest({
  name,
  src,
  size = "sm",
}: {
  name: string;
  src?: string;
  size?: "sm" | "md";
}) {
  const [failed, setFailed] = useState(false);
  const dim = size === "md" ? "size-8" : "size-6";
  if (!src || failed) {
    return (
      <span
        className={cn(
          dim,
          "inline-flex shrink-0 items-center justify-center rounded-full bg-elevated text-[9px] font-bold tracking-wide text-fg shadow-[var(--shadow-border)]",
        )}
      >
        {initials(name)}
      </span>
    );
  }
  return (
    <img
      src={src}
      alt=""
      width={size === "md" ? 32 : 24}
      height={size === "md" ? 32 : 24}
      className={cn(dim, "shrink-0 rounded-full bg-elevated object-contain p-0.5")}
      crossOrigin="anonymous"
      onError={() => setFailed(true)}
    />
  );
}
