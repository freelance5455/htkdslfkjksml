"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { LogoMark } from "@/components/logo-mark";
import { NAV_ITEMS } from "@/lib/site";

export function SiteHeader() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close the mobile menu whenever the route changes.
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const isActive = (href: string) =>
    pathname === href || (href !== "/" && pathname.startsWith(`${href}/`));

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled || open
          ? "border-b border-gold/15 bg-navy-deep/90 shadow-[0_18px_40px_-28px_rgba(0,0,0,0.7)] backdrop-blur-md"
          : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between gap-6 px-5 py-4 lg:px-8">
        <Link
          className="group flex items-center gap-3 text-ivory"
          aria-label="لأنه الله — الصفحة الرئيسية"
          href="/"
        >
          <span className="grid size-10 place-items-center rounded-full border border-gold/50 bg-gradient-to-br from-royal to-navy text-gold transition-transform duration-500 group-hover:rotate-45">
            <LogoMark className="size-5" />
          </span>
          <span className="font-serif text-2xl leading-none font-bold">لأنه الله</span>
        </Link>

        <nav aria-label="التنقل الرئيسي" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {NAV_ITEMS.map((item) => {
              const active = isActive(item.href);
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={active ? "page" : undefined}
                    className={`relative rounded-full px-3.5 py-2 text-sm transition-colors hover:text-ivory ${
                      active ? "text-gold-light" : "text-ivory/75"
                    }`}
                  >
                    {item.label}
                    {active && (
                      <span className="absolute inset-x-3.5 -bottom-0.5 h-px bg-gradient-to-l from-transparent via-gold to-transparent" />
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <Link
          className="hidden rounded-full border border-gold/60 bg-gold/10 px-5 py-2 text-sm font-medium text-gold-light transition-all hover:bg-gold hover:text-navy lg:inline-flex"
          href="/quran"
        >
          ابدأ التلاوة
        </Link>

        <button
          type="button"
          className="inline-flex items-center gap-2 rounded-full border border-gold/50 bg-gold/10 px-4 py-2 text-sm font-medium text-gold-light transition-colors hover:bg-gold hover:text-navy lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-4" aria-hidden="true" /> : <Menu className="size-4" aria-hidden="true" />}
          {open ? "إغلاق" : "الأقسام"}
        </button>
      </div>

      <nav
        id="mobile-nav"
        aria-label="التنقل في الجوال"
        className={`overflow-hidden transition-[max-height] duration-500 lg:hidden ${
          open ? "max-h-[32rem]" : "max-h-0"
        }`}
      >
        <ul className="grid grid-cols-2 gap-2 px-5 pb-6">
          {NAV_ITEMS.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                className={`block rounded-full border px-4 py-3 text-center transition-colors hover:border-gold hover:bg-gold hover:text-navy ${
                  isActive(item.href)
                    ? "border-gold bg-gold/15 text-gold-light"
                    : "border-white/10 bg-white/5 text-ivory/90"
                }`}
              >
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
