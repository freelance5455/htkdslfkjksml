/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import { audioEngine } from '../services/audioEngine';
import { VisualizerMode } from '../types';

interface LiveWaveformCanvasProps {
  mode: VisualizerMode;
  isPlaying: boolean;
  className?: string;
}

export const LiveWaveformCanvas: React.FC<LiveWaveformCanvasProps> = ({
  mode,
  isPlaying,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameId = useRef<number | null>(null);
  const peakValuesRef = useRef<number[]>([]);
  const rotationAngleRef = useRef<number>(0);
  const beatFlashRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI display
    const handleResize = () => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    // Peak decay setup
    const barCount = 48;
    if (peakValuesRef.current.length !== barCount) {
      peakValuesRef.current = new Array(barCount).fill(0);
    }

    // Audio reactive loop
    const render = () => {
      animFrameId.current = requestAnimationFrame(render);

      const rect = canvas.getBoundingClientRect();
      const width = rect.width;
      const height = rect.height;

      // Update engine audio metrics & beat detection
      audioEngine.updateMetrics();
      if (audioEngine.isBeat) {
        beatFlashRef.current = 1.0;
      } else {
        beatFlashRef.current *= 0.88;
      }

      // Clear with slight alpha fade for motion trail
      ctx.fillStyle = 'rgba(7, 8, 14, 0.45)';
      ctx.fillRect(0, 0, width, height);

      // Subtle beat flash background pulse
      if (beatFlashRef.current > 0.05) {
        const flashGrad = ctx.createRadialGradient(
          width / 2, height / 2, 0,
          width / 2, height / 2, Math.max(width, height) / 1.5
        );
        flashGrad.addColorStop(0, `rgba(0, 240, 255, ${beatFlashRef.current * 0.18})`);
        flashGrad.addColorStop(0.6, `rgba(176, 38, 255, ${beatFlashRef.current * 0.08})`);
        flashGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = flashGrad;
        ctx.fillRect(0, 0, width, height);
      }

      const analyser = audioEngine.analyser;
      if (!analyser) {
        // Fallback idle wave
        drawIdleAnimation(ctx, width, height);
        return;
      }

      const bufferLength = analyser.frequencyBinCount;
      const freqData = new Uint8Array(bufferLength);
      const timeData = new Uint8Array(bufferLength);
      analyser.getByteFrequencyData(freqData);
      analyser.getByteTimeDomainData(timeData);

      // Render according to selected mode
      switch (mode) {
        case 'waveform':
          drawOscilloscopeWaveform(ctx, width, height, timeData, isPlaying);
          break;
        case 'spectrum':
          drawSpectrumBars(ctx, width, height, freqData, peakValuesRef.current, isPlaying);
          break;
        case 'circular':
          drawCircularVisualizer(ctx, width, height, freqData, rotationAngleRef, isPlaying);
          break;
        case 'lasers':
          drawLaserStageVisualizer(ctx, width, height, freqData, isPlaying);
          break;
        case 'matrix':
          drawMatrixEqualizer(ctx, width, height, freqData, isPlaying);
          break;
        default:
          drawOscilloscopeWaveform(ctx, width, height, timeData, isPlaying);
      }
    };

    render();

    return () => {
      if (animFrameId.current) cancelAnimationFrame(animFrameId.current);
      window.removeEventListener('resize', handleResize);
    };
  }, [mode, isPlaying]);

  // Mode 1: Neon Oscilloscope Waveform
  const drawOscilloscopeWaveform = (
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    data: Uint8Array,
    active: boolean
  ) => {
    const centerY = h / 2;
    const sliceWidth = w / data.length;

    // Glowing Neon Gradient
    const gradient = ctx.createLinearGradient(0, 0, w, 0);
    gradient.addColorStop(0, '#00f0ff');
    gradient.addColorStop(0.5, '#b026ff');
    gradient.addColorStop(1, '#ff0055');

    // Draw main glowing wave
    ctx.save();
    ctx.shadowBlur = active ? 18 : 6;
    ctx.shadowColor = '#00f0ff';
    ctx.strokeStyle = gradient;
    ctx.lineWidth = active ? 3.5 : 2;
    ctx.beginPath();

    let x = 0;
    for (let i = 0; i < data.length; i++) {
      const v = active ? data[i] / 128.0 : 1.0 + Math.sin(i * 0.05 + Date.now() * 0.003) * 0.05;
      const y = (v * h) / 2;

      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
      x += sliceWidth;
    }
    ctx.stroke();

    // Mirror reflection wave with lower opacity
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#ff0055';
    ctx.strokeStyle = 'rgba(255, 0, 85, 0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    x = 0;
    for (let i = 0; i < data.length; i++) {
      const v = active ? data[i] / 128.0 : 1.0;
      const offset = (v - 1.0) * h * 0.4;
      const y = centerY - offset;

      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
      x += sliceWidth;
    }
    ctx.stroke();

    // Subtle horizontal baseline
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, centerY);
    ctx.lineTo(w, centerY);
    ctx.stroke();

    ctx.restore();
  };

  // Mode 2: Multi-colored Neon Sound Bars with Peak Caps
  const drawSpectrumBars = (
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    data: Uint8Array,
    peaks: number[],
    active: boolean
  ) => {
    const count = peaks.length;
    const gap = 3;
    const barWidth = (w - (count - 1) * gap) / count;
    const step = Math.floor(data.length / (count * 1.5));

    for (let i = 0; i < count; i++) {
      let val = 0;
      if (active) {
        // Average small chunk
        let sum = 0;
        for (let j = 0; j < step; j++) {
          sum += data[i * step + j] || 0;
        }
        val = sum / step;
      } else {
        val = 20 + Math.sin(i * 0.4 + Date.now() * 0.004) * 15;
      }

      const percent = Math.min(1, val / 230);
      const barHeight = Math.max(4, percent * (h * 0.78));
      const x = i * (barWidth + gap);
      const y = h - barHeight;

      // Peak hold animation
      if (barHeight > peaks[i]) {
        peaks[i] = barHeight;
      } else {
        peaks[i] = Math.max(0, peaks[i] - 1.8);
      }

      // Bar gradient (Cyan -> Purple -> Laser Red)
      const grad = ctx.createLinearGradient(0, h, 0, y);
      grad.addColorStop(0, '#00f0ff');
      grad.addColorStop(0.6, '#b026ff');
      grad.addColorStop(1, '#ff0055');

      ctx.save();
      ctx.fillStyle = grad;
      ctx.shadowBlur = active ? 10 : 2;
      ctx.shadowColor = percent > 0.7 ? '#ff0055' : '#00f0ff';

      // Rounded top bar
      ctx.beginPath();
      const radius = Math.min(barWidth / 2, 4);
      ctx.roundRect(x, y, barWidth, barHeight, [radius, radius, 0, 0]);
      ctx.fill();

      // Peak cap dot
      const peakY = Math.max(2, h - peaks[i] - 4);
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = '#ffffff';
      ctx.shadowBlur = 8;
      ctx.fillRect(x, peakY, barWidth, 3);

      ctx.restore();
    }
  };

  // Mode 3: Circular DJ Ring Visualizer
  const drawCircularVisualizer = (
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    data: Uint8Array,
    rotationRef: React.MutableRefObject<number>,
    active: boolean
  ) => {
    const cx = w / 2;
    const cy = h / 2;
    const baseRadius = Math.min(w, h) * 0.22;
    const spikeCount = 64;

    rotationRef.current += active ? 0.008 : 0.002;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(rotationRef.current);

    // Outer audio reactive spikes
    for (let i = 0; i < spikeCount; i++) {
      const angle = (i / spikeCount) * Math.PI * 2;
      const dataIndex = Math.floor((i / spikeCount) * (data.length * 0.5));
      const val = active ? data[dataIndex] || 0 : 25 + Math.sin(i * 0.5) * 15;
      const spikeLength = (val / 255) * (Math.min(w, h) * 0.28);

      const x1 = Math.cos(angle) * baseRadius;
      const y1 = Math.sin(angle) * baseRadius;
      const x2 = Math.cos(angle) * (baseRadius + spikeLength);
      const y2 = Math.sin(angle) * (baseRadius + spikeLength);

      const grad = ctx.createLinearGradient(x1, y1, x2, y2);
      grad.addColorStop(0, '#00f0ff');
      grad.addColorStop(0.7, '#b026ff');
      grad.addColorStop(1, '#ff0055');

      ctx.strokeStyle = grad;
      ctx.lineWidth = 2.5;
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#00f0ff';

      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }

    // Inner glowing ring
    ctx.beginPath();
    ctx.arc(0, 0, baseRadius - 4, 0, Math.PI * 2);
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 2.5;
    ctx.shadowBlur = 14;
    ctx.shadowColor = '#00f0ff';
    ctx.stroke();

    // Center DJ SUNNY Crest
    ctx.beginPath();
    ctx.arc(0, 0, baseRadius * 0.65, 0, Math.PI * 2);
    ctx.fillStyle = '#0a0b14';
    ctx.fill();
    ctx.strokeStyle = '#ff0055';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.restore();
  };

  // Mode 4: Cyber Laser & 3D Stage Grid Show
  const drawLaserStageVisualizer = (
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    data: Uint8Array,
    active: boolean
  ) => {
    const horizon = h * 0.45;
    const bass = active ? data[2] / 255 : 0.2;
    const treble = active ? data[40] / 255 : 0.2;

    ctx.save();

    // 1. Perspective 3D Neon Dancefloor Grid
    const lineCount = 14;
    ctx.strokeStyle = `rgba(0, 240, 255, ${0.15 + bass * 0.4})`;
    ctx.lineWidth = 1.2;
    ctx.shadowBlur = 6;
    ctx.shadowColor = '#00f0ff';

    // Horizontal depth lines
    for (let i = 1; i <= 8; i++) {
      const y = horizon + Math.pow(i / 8, 2) * (h - horizon);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // Perspective vanishing lines
    const cx = w / 2;
    for (let i = -lineCount / 2; i <= lineCount / 2; i++) {
      const xBottom = cx + i * (w / (lineCount * 0.65));
      ctx.beginPath();
      ctx.moveTo(cx, horizon);
      ctx.lineTo(xBottom, h);
      ctx.stroke();
    }

    // 2. High-energy Stage Laser Beams shooting from corners
    const laserColors = ['#00f0ff', '#ff0055', '#b026ff', '#00ffaa'];
    const time = Date.now() * 0.002;

    for (let i = 0; i < 4; i++) {
      const originX = i % 2 === 0 ? 0 : w;
      const originY = i < 2 ? 0 : horizon * 0.8;
      const angle = Math.sin(time + i * 1.5) * 0.6 + (i % 2 === 0 ? 0.8 : -0.8);
      const targetX = cx + Math.cos(angle) * (w * 0.6);
      const targetY = h * 0.85 + Math.sin(time * 2 + i) * 60;

      ctx.strokeStyle = laserColors[i];
      ctx.lineWidth = 2 + treble * 4;
      ctx.shadowBlur = 18;
      ctx.shadowColor = laserColors[i];

      ctx.beginPath();
      ctx.moveTo(originX, originY);
      ctx.lineTo(targetX, targetY);
      ctx.stroke();

      // Laser impact light burst
      ctx.beginPath();
      ctx.arc(targetX, targetY, 4 + bass * 12, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
    }

    ctx.restore();
  };

  // Mode 5: Matrix LED Rackmount Equalizer
  const drawMatrixEqualizer = (
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    data: Uint8Array,
    active: boolean
  ) => {
    const cols = 32;
    const rows = 18;
    const gapX = 3;
    const gapY = 3;
    const blockWidth = (w - (cols - 1) * gapX) / cols;
    const blockHeight = (h - (rows - 1) * gapY) / rows;
    const step = Math.floor(data.length / (cols * 1.5));

    for (let c = 0; c < cols; c++) {
      let sum = 0;
      if (active) {
        for (let s = 0; s < step; s++) {
          sum += data[c * step + s] || 0;
        }
        sum /= step;
      } else {
        sum = 25 + Math.sin(c * 0.4 + Date.now() * 0.003) * 20;
      }

      const activeBlocks = Math.round((sum / 255) * rows);

      for (let r = 0; r < rows; r++) {
        const x = c * (blockWidth + gapX);
        const y = h - (r + 1) * (blockHeight + gapY);
        const isLit = r <= activeBlocks;

        // Color coding: bottom green/cyan, mid purple, top red
        let blockColor = '#1e293b';
        let glowColor = 'transparent';

        if (isLit) {
          if (r < rows * 0.5) {
            blockColor = '#00f0ff';
            glowColor = '#00f0ff';
          } else if (r < rows * 0.8) {
            blockColor = '#b026ff';
            glowColor = '#b026ff';
          } else {
            blockColor = '#ff0055';
            glowColor = '#ff0055';
          }
        }

        ctx.save();
        ctx.fillStyle = blockColor;
        if (isLit && active) {
          ctx.shadowBlur = 6;
          ctx.shadowColor = glowColor;
        }
        ctx.fillRect(x, y, blockWidth, blockHeight);
        ctx.restore();
      }
    }
  };

  const drawIdleAnimation = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.25)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    const cy = h / 2;
    for (let x = 0; x < w; x++) {
      const y = cy + Math.sin(x * 0.03 + Date.now() * 0.002) * 12;
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  };

  return (
    <div className={`relative overflow-hidden rounded-xl border border-cyan-500/20 bg-[#07080f]/90 ${className}`}>
      <canvas ref={canvasRef} className="w-full h-full block" />
      
      {/* Top Overlay Badge */}
      <div className="absolute top-2 left-3 flex items-center gap-2 pointer-events-none">
        <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
        <span className="text-[10px] font-bold tracking-widest uppercase text-cyan-400 font-dj">
          LIVE AUDIO ENGINE • 60 FPS
        </span>
      </div>
    </div>
  );
};
