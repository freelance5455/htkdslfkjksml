/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ArrowDown, ArrowUp, Activity, Gauge } from 'lucide-react';

interface SpeedometerGaugeProps {
  downloadMbps: number;
  uploadMbps: number;
  maxScaleMbps?: number;
  pingMs: number;
  jitterMs: number;
  bufferbloatGrade: string;
}

export const SpeedometerGauge: React.FC<SpeedometerGaugeProps> = ({
  downloadMbps,
  uploadMbps,
  maxScaleMbps = 500,
  pingMs,
  jitterMs,
  bufferbloatGrade,
}) => {
  const [activeMetric, setActiveMetric] = useState<'download' | 'upload'>('download');

  const currentVal = activeMetric === 'download' ? downloadMbps : uploadMbps;
  // Calculate angle on 240-degree arc (-120 to +120 deg)
  const normalized = Math.min(Math.max(currentVal / maxScaleMbps, 0), 1);
  const strokeDashoffset = 440 - (normalized * 440 * 0.75); // for 270 deg circle

  return (
    <div className="relative rounded-2xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-slate-800/80 p-5 shadow-lg backdrop-blur-sm overflow-hidden">
      {/* Background ambient glow */}
      <div 
        className={`absolute -top-12 left-1/2 -translate-x-1/2 w-48 h-48 rounded-full blur-3xl opacity-20 pointer-events-none transition-colors duration-500 ${
          activeMetric === 'download' ? 'bg-cyan-500' : 'bg-purple-500'
        }`} 
      />

      {/* Header Metric Switcher Tabs */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-medium text-slate-300">Live Throughput</span>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center p-0.5 rounded-lg bg-slate-950 border border-slate-800/80">
          <button
            onClick={() => setActiveMetric('download')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
              activeMetric === 'download'
                ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ArrowDown className="w-3 h-3 text-cyan-400" />
            <span>Down</span>
          </button>
          <button
            onClick={() => setActiveMetric('upload')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
              activeMetric === 'upload'
                ? 'bg-purple-500/15 text-purple-400 border border-purple-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ArrowUp className="w-3 h-3 text-purple-400" />
            <span>Up</span>
          </button>
        </div>
      </div>

      {/* Circular Speedometer Arc */}
      <div className="relative flex flex-col items-center justify-center my-1">
        <svg className="w-52 h-44 -rotate-90 transform" viewBox="0 0 200 200">
          {/* Background Track */}
          <circle
            cx="100"
            cy="100"
            r="70"
            fill="none"
            stroke="#1e293b"
            strokeWidth="12"
            strokeDasharray="440"
            strokeDashoffset="110"
            strokeLinecap="round"
          />

          {/* Active Gradient Meter */}
          <circle
            cx="100"
            cy="100"
            r="70"
            fill="none"
            stroke={activeMetric === 'download' ? '#06b6d4' : '#a855f7'}
            strokeWidth="12"
            strokeDasharray="440"
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-300 ease-out"
          />
        </svg>

        {/* Center Readout */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pt-2">
          <span className="text-4xl font-extrabold tracking-tight text-white font-mono">
            {currentVal.toFixed(1)}
          </span>
          <span className="text-xs uppercase font-medium tracking-wider text-slate-400 mt-0.5">
            Mbps {activeMetric === 'download' ? 'Download' : 'Upload'}
          </span>

          <div className="flex items-center gap-2 mt-2 text-[11px] text-slate-400">
            <span>Scale: 0–{maxScaleMbps} Mbps</span>
          </div>
        </div>
      </div>

      {/* Bottom Summary Bar */}
      <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-800/80 text-center">
        <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/60">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Ping Latency</div>
          <div className="text-sm font-semibold text-white font-mono mt-0.5">{pingMs} <span className="text-[10px] text-slate-400">ms</span></div>
        </div>

        <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/60">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Jitter</div>
          <div className="text-sm font-semibold text-white font-mono mt-0.5">{jitterMs} <span className="text-[10px] text-slate-400">ms</span></div>
        </div>

        <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/60">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">Bufferbloat</div>
          <div className="text-sm font-bold text-cyan-400 font-mono mt-0.5">Grade {bufferbloatGrade}</div>
        </div>
      </div>
    </div>
  );
};
